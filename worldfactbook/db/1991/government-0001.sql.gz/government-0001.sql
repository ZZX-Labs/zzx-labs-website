SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('784858641a473fad21e1d62ea532c852643b629e74ddffdb9f5448bfa3e6827a',1991,'ZW','Zimbabwe','government',17,'_#_Long-form name: Republic of Afghanistan
_#_Type: authoritarian
_#_Capital: Kabul
_#_Administrative divisions: 30 provinces (velayat,
singular--velayat); Badakhshan, Badghis, Baghlan, Balkh,
Bamian, Farah, Faryab, Ghazni, Ghowr, Helmand,
Herat, Jowzjan, Kabol, Kandahar, Kapisa, Konar,
Kondoz, Laghman, Lowgar, Nangarhar, Nimruz, Oruzgan,
Paktia, Paktika, Parvan, Samangan, Sar-e Pol,
Takhar, Vardak, Zabol; note--there may be a new province of
Nurestan (Nuristan)
_#_Independence: 19 August 1919 (from UK)
_#_Constitution: adopted 30 November 1987, revised May 1990
_#_Legal system: has not accepted compulsory ICJ jurisdiction
_#_National holiday: Anniversary of the Saur Revolution, 27 April
(1978)
_#_Executive branch: president, four vice presidents, prime minister,
deputy prime minister, Council of Ministers (cabinet)
_#_Legislative branch: bicameral National Assembly (Meli Shura)
consists of an upper house or Council of Elders (Sena) and a lower house
or Council of Representatives (Wolosi Jirga)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--President (Mohammad)
NAJIBULLAH (Ahmadzai) (since 30 November 1987); First Vice President
Abdul Wahed SORABI (since 7 January 1991); Prime Minister Fazil Haq
KHALIQYAR (since 21 May 1990)
_#_Political parties and leaders: main party--Hizbi Watan Homeland
Party (formerly known as the People''s Democratic Party of Afghanistan
or PDPA); there are other, much smaller political parties recognized by
the government
_#_Suffrage: universal, male ages 15-50
_#_Elections:
Senate--last held NA April 1988 (next to be held April 1991);
results--Hizbi Watan was the only party;
seats--(192 total, 128 elected) Hizbi Watan 128;
House of Representatives--last held NA April 1988 (next to be held
April 1993);
results--Hizbi Watan was the only party;
seats--(234 total) Hizbi Watan 184, opposition 50;
note--members may or may not be affiliated with a political party
_#_Communists: Hizbi Watan Homeland Party (formerly the People''s
Democratic Party of Afghanistan or PDPA) claims 200,000 members and no
longer considers itself a Communist party
_#_Other political or pressure groups: the military and other branches
of internal security have been rebuilt by the USSR; insurgency continues
throughout the country; widespread antiregime sentiment and opposition on
religious and political grounds
_#_Member of: AsDB, CP, ESCAP, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IDB, IFAD, IFC, ILO, IMF, INTELSAT, IOC, ITU,
LORCS, NAM, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WMO, WTO;
note--Afghanistan was suspended from the OIC in January 1980, but in
March 1989 the self-proclaimed Mujaheddin Government of Afghanistan
was given membership
_#_Diplomatic representation: Minister-Counselor, Charge d''Affaires
Abdul Ghafur JOUSHAN; Chancery at 2341 Wyoming Avenue NW, Washington
DC 20008;
telephone (202) 234-3770 or 3771;
US--Charge d''Affaires (vacant); Embassy at Ansari Wat, Wazir
Akbar Khan Mina, Kabul; telephone 62230 through 62235 or 62436;
note--US Embassy in Kabul was closed in January 1989
_#_Flag: three equal horizontal bands of black (top), red, and green
with the national coat of arms superimposed on the hoist side of the
black and red bands; similar to the flag of Malawi which is shorter and
bears a radiant, rising red sun centered in the black band
_#_Long-form name: Republic of Albania
_#_Type: nascent democracy with strong Communist party influence;
basic law has dropped all references to socialism
_#_Capital: Tirane
_#_Administrative divisions: 26 districts (rrethe, singular--rreth);
Berat, Dibre, Durres, Elbasan, Fier, Gjirokaster, Gramsh,
Kolonje, Korce, Kruje, Kukes, Lezhe, Librazhd, Lushnje,
Mat, Mirdite, Permet, Pogradec, Puke, Sarande, Shkoder,
Skrapar, Tepelene, Tirane, Tropoje, Vlore
_#_Independence: 28 November 1912 (from Ottoman Empire);
People''s Socialist Republic of Albania declared 11 January 1946
_#_Constitution: an interim basic law was approved by the People''s
Assembly on 29 April 1991; a new constitution is to be drafted for
adoption in four to six months
_#_Legal system: has not accepted compulsory ICJ jurisdiction
_#_National holiday: Liberation Day, 29 November (1944)
_#_Executive branch: president, prime minister of the Council of
Ministers, one deputy prime minister of the Council of Ministers
_#_Legislative branch: unicameral People''s Assembly (Kuvendi
Popullor)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President of the Republic Ramiz ALIA (since 22
November 1982);
Head of Government--Prime Minister of the interim Council of
Ministers Ylli BUFI (since 5 June 1991);
_#_Political parties and leaders: Albanian Workers Party (AWP),
Ramiz ALIA, first secretary;
Democratic Party (DP), Sali BERISHA, chairman and cofounder with
Gramoz PASHKO;
Albanian Republican Party, Sabri GODO;
Ecology Party, Namik HOTI;
Omonia (Greek minority party), leader NA;
Agrarian Party, leader NA;
note--in December 1990 President ALIA allowed new political parties
to be formed in addition to the AWP for the first time since 1944
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
President--last held 30 April 1991 (next to be held spring 1992);
results--President Ramiz ALIA was reelected with token opposition;
People''s Assembly--last held 31 March 1991 (next to be held
spring 1992);
results--AWP 68%, DP 25%;
seats--(250 total) preliminary results AWP 168, DP 75, Omonia 5,
Veterans Association 1, other 1;
note--the AWP''s votes came mostly from the countryside while the DP
won majorities in the six-largest cities;
_#_Communists: 147,000 party members (November 1986); note--in
March 1991 the Albanian Workers'' Party announced that it considered
itself no longer Communist but socialist
_#_Member of: ECE, FAO, IAEA, IOC, ISO, ITU, LORCS, UN, UNCTAD,
UNESCO, UNIDO, UPU, WFTU, WHO, WMO
_#_Diplomatic representation: the Governments of the United States and
Albania agreed to reestablish diplomatic relations to be effective
from 15 March 1991 and to exchange diplomatic missions at the level
of ambassador
_#_Flag: red with a black two-headed eagle in the center below a red
five-pointed star outlined in yellow
_#_Long-form name: Democratic and Popular Republic of Algeria
_#_Type: republic
_#_Capital: Algiers
_#_Administrative divisions: 48 provinces (wilayat, singular--wilaya);
Adrar, Ain Defla, Ain Temouchent, Alger, Annaba, Batna, Bechar,
Bejaia, Biskra, Blida, Bordj Bou Arreridj, Bouira, Boumerdes, Chlef,
Constantine, Djelfa, El Bayadh, El Oued, El Tarf, Ghardaia, Guelma,
Illizi, Jijel, Khenchela, Laghouat, Mascara, Medea, Mila, Mostaganem,
M''sila, Naama, Oran, Ouargla, Oum el Bouaghi, Relizane, Saida, Setif,
Sidi Bel Abbes, Skikda, Souk Ahras, Tamanghasset, Tebessa, Tiaret,
Tindouf, Tipaza, Tissemsilt, Tizi Ouzou, Tlemcen
_#_Independence: 5 July 1962 (from France)
_#_Constitution: 19 November 1976, effective 22 November 1976
_#_Legal system: socialist, based on French and Islamic law; judicial
review of legislative acts in ad hoc Constitutional Council composed of
various public officials, including several Supreme Court justices; has
not accepted compulsory ICJ jurisdiction
_#_National holiday: Anniversary of the Revolution, 1 November (1954)
_#_Executive branch: president, prime minister, Council of Ministers
(cabinet)
_#_Legislative branch: unicameral National People''s Assembly
(Al-Majlis Ech-Chaabi Al-Watani)
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State--President Chadli BENDJEDID (since 7 February 1979);
Head of Government--Prime Minister Sid Ahmed GHOZALI (since
6 June 1991)
_#_Political parties and leaders:
National Liberation Front (FLN), Chadli BENDJEDID, president;
Islamic Salvation Front (FIS), Abassi MADANI;
the government established a multiparty system in September 1989 and as
of 31 December 1990 over 30 legal parties existed
_#_Suffrage: universal at age 18
_#_Elections:
President--last held on 22 December 1988 (next to be held December
1993); results--President BENDJEDID was reelected without opposition;
National People''s Assembly--last held on 26 February 1987 (next
were to be held 27 June 1991 but postponed indefinitely because
of civil unrest);
results--FLN was the only party;
seats--(281 total) FLN 281; note--the government held multiparty
elections (municipal and wilaya) in June 1990, the first in Algerian
history; results--FIS 55%, FLN 27.5%, other 17.5%, with 65% of the voters
participating
_#_Communists: 400 (est.); Communist party banned 1962
_#_Member of: ABEDA, AfDB, AFESD, AL, AMF, AMU, CCC, ECA, FAO, G-19,
G-24, G-77, IAEA, IBRD, ICAO, IDA, IDB, IFAD, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS, NAM, OAPEC, OAS
(observer), OAU, OIC, OPEC, UN, UNAVEM, UNCTAD, UNESCO, UNHCR, UNIDO,
UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Abderrahmane BENSID;
Chancery at 2118 Kalorama Road NW, Washington DC 20008; telephone
(202) 328-5300;
US--Ambassador Christopher W. S. ROSS; Embassy at 4 Chemin Cheich
Bachir El-Ibrahimi, Algiers (mailing address is B. P. Box 549,
Alger-Gare, 16000 Algiers); telephone [213] (2) 601-425 or 255, 186;
there is a US Consulate in Oran
_#_Flag: two equal vertical bands of green (hoist side) and white
with a red five-pointed star within a red crescent; the crescent,
star, and color green are traditional symbols of Islam (the state
religion)
_#_Long-form name: Territory of American Samoa
_#_Type: unincorporated and unorganized territory of the US
_#_Capital: Pago Pago
_#_Administrative divisions: none (territory of the US)
_#_Independence: none (territory of the US)
_#_Constitution: ratified 1966, in effect 1967
_#_National holiday: Flag Day, 17 April (1900)
_#_Executive branch: President of the US, governor, lieutenant
governor
_#_Legislative branch: bicameral Legislative Assembly (Fono) consists
of an upper house or Senate and a lower house or House of Representatives
_#_Judicial branch: High Court
_#_Leaders:
Chief of State--President George BUSH (since 20 January 1989);
Vice President Dan QUAYLE (since 20 January 1989);
Head of Government--Governor Peter Tali COLEMAN (since 20
January 1989);
Lieutenant Governor Galea''i POUMELE (since NA 1989)
_#_Suffrage: universal at age 18; indigenous inhabitants are US
nationals, not US citizens
_#_Elections:
Governor--last held 7 November 1988 (next to be held November
1992); results--Peter T. COLEMAN was elected (percent of vote NA);
Senate--last held 7 November 1988 (next to be held November
1992);
results--senators elected by county councils from 12 senate
districts;
seats--(18 total) number of seats by party NA;
House of Representatives--last held NA November 1990 (next to be
held November 1992);
results--representatives popularly elected from 17 house districts;
seats--(21 total, 20 elected and 1 nonvoting delegate from Swain''s
Island);
US House of Representatives--last held 19 November 1990 (next
to be held November 1992);
results--Eni R. F. H. FALEOMAVAEGA reelected as a nonvoting delegate
_#_Communists: none
_#_Member of: IOC, SPC
_#_Diplomatic representation: none (territory of the US)
_#_Flag: blue with a white triangle edged in red that is based on the
fly side and extends to the hoist side; a brown and white American bald
eagle flying toward the hoist side is carrying two traditional Samoan
symbols of authority, a staff and a war club
_#_Note: administered by the US Department of Interior, Office of
Territorial and International Affairs; indigenous inhabitants are US
nationals, not citizens of the US
_#_Long-form name: Principality of Andorra
_#_Type: unique coprincipality under formal sovereignty of president
of France and Spanish bishop of Seo de Urgel, who are represented locally
by officials called verguers
_#_Capital: Andorra la Vella
_#_Administrative divisions: 7 parishes (parroquies,
singular--parroquia); Andorra, Canillo, Encamp, La Massana, Les
Escaldes, Ordino, Sant Julia de Loria
_#_Independence: 1278
_#_Constitution: none; some pareatges and decrees, mostly custom and
usage
_#_Legal system: based on French and Spanish civil codes; no judicial
review of legislative acts; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Mare de Deu de Meritxell, 8 September
_#_Executive branch: two co-princes (president of France, bishop of
Seo de Urgel in Spain), two designated representatives (French veguer,
Episcopal veguer), two permanent delegates (French prefect for the
department of Pyrenees-Orientales, Spanish vicar general for the Seo
de Urgel diocese), president of government, Executive Council
_#_Legislative branch: unicameral General Council of the Valleys
(Consell General de las Valls)
_#_Judicial branch: civil cases--Supreme Court of Andorra at Perpignan
(France) or the Ecclesiastical Court of the bishop of Seo de Urgel
(Spain); criminal cases--Tribunal of the Courts (Tribunal des Cortes)
_#_Leaders:
Chiefs of State--French Co-Prince Francois MITTERRAND (since 21
May 1981), represented by Veguer de Franca Jean Pierre COURTOIS;
Spanish Episcopal Co-Prince Mgr. Joan MARTI y Alanis (since 31
January 1971), represented by Veguer Episcopal Francesc BADIA Batalla;
Head of Government--Oscar RIBAS Reig (since NA January 1990)
_#_Political parties and leaders: political parties not yet legally
recognized; traditionally no political parties but partisans for
particular independent candidates for the General Council on the basis of
competence, personality, and orientation toward Spain or France; various
small pressure groups developed in 1972; first formal political party,
Andorran Democratic Association, was formed in 1976 and reorganized in
1979 as Andorran Democratic Party
_#_Suffrage: universal at age 18
_#_Elections:
General Council of the Valleys--last held 11 December 1989
(next to be held December 1993);
results--percent of vote NA;
seats--(28 total) number of seats by party NA
_#_Communists: negligible
_#_Member of: CSCE, INTERPOL, IOC
_#_Diplomatic representation: Andorra has no mission in the US;
US--includes Andorra within the Barcelona (Spain) Consular District
and the US Consul General visits Andorra periodically; Consul General
Ruth A. DAVIS; Consulate General at Via Layetana 33, Barcelona 3, Spain
(mailing address APO NY 09286); telephone [34] (3) 319-9550
_#_Flag: three equal vertical bands of blue (hoist side), yellow, and
red with the national coat of arms centered in the yellow band; the coat
of arms features a quartered shield; similar to the flags of Chad and
Romania which do not have a national coat of arms in the center
lar to the
_#_Long-form name: People''s Republic of Angola
_#_Type: in transition from a one-party Marxist state to a multiparty
democracy with a strong presidential system
_#_Capital: Luanda
_#_Administrative divisions: 18 provinces (provincias,
singular--provincia); Bengo, Benguela, Bie, Cabinda, Cuando Cubango,
Cuanza Norte, Cuanza Sul, Cunene, Huambo, Huila, Luanda, Lunda Norte,
Lunda Sul, Malanje, Moxico, Namibe, Uige, Zaire
_#_Independence: 11 November 1975 (from Portugal)
_#_Constitution: 11 November 1975; revised 7 January 1978, 11
August 1980, and 6 March 1991
_#_Legal system: based on Portuguese civil law system and customary
law; recently modified to accommodate multipartyism and increased use of
free markets
_#_National holiday: Independence Day, 11 November (1975)
_#_Executive branch: president, chairman of the Council of Ministers,
Council of Ministers (cabinet)
_#_Legislative branch: unicameral People''s Assembly (Assembleia do
Povo)
_#_Judicial branch: Supreme Court (Tribunal da Relacao)
_#_Leaders:
Chief of State and Head of Government--President Jose Eduardo dos
SANTOS (since 21 September 1979)
_#_Political parties and leaders: only one party exists--the
Popular Movement for the Liberation of Angola-Labor Party
(MPLA), Jose Eduardo dos SANTOS--although others are expected to
form as legalization of a multiparty system proceeds;
National Union for the Total Independence of Angola (UNITA) lost to
the MPLA and Cuban military support forces in the immediate
postindependence struggle, but is to receive recognition as a legal party
_#_Suffrage: universal at age 18
_#_Elections: first nationwide, multiparty elections to be held
between September and November 1992
_#_Member of: ACP, AfDB, CEEAC (observer), ECA, FAO,
FLS, G-77, ICAO, IFAD, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, ITU,
LORCS, NAM, OAU, SADCC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO,
WIPO, WMO, WTO
_#_Diplomatic representation: none
_#_Flag: two equal horizontal bands of red (top) and black with a
centered yellow emblem consisting of a five-pointed star within half a
cogwheel crossed by a machete (in the style of a hammer and sickle)
_#_Long-form name: none
_#_Type: dependent territory of the UK
_#_Capital: The Valley
_#_Administrative divisions: none (dependent territory of the UK)
_#_Independence: none (dependent territory of the UK)
_#_Constitution: 1 April 1982
_#_Legal system: based on English common law
_#_National holiday: Anguilla Day, 30 May
_#_Executive branch: British monarch, governor, chief minister,
Executive Council (cabinet)
_#_Legislative branch: unicameral House of Assembly
_#_Judicial branch: High Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor Brian G. J. CANTY (since NA 1989);
Head of Government--Chief Minister Emile GUMBS (since NA March
1984, served previously from February 1977 to May 1980)
_#_Political parties and leaders:
Anguilla National Alliance (ANA), Emile GUMBS;
Anguilla United Party (AUP), Ronald WEBSTER;
Anguilla Democratic Party (ADP), Victor BANKS
_#_Suffrage: universal at age 18
_#_Elections:
House of Assembly--last held 27 February 1989 (next to
be held February 1994);
results--percent of vote by party NA;
seats--(11 total, 7 elected) ANA 3, AUP 2, ADP 1, independent 1
_#_Communists: none
_#_Member of: CARICOM (observer), CDB
_#_Diplomatic representation: none (dependent territory of the UK)
_#_Flag: two horizontal bands of white (top, almost triple width) and
light blue with three orange dolphins in an interlocking circular design
centered in the white band; a new flag may have been in use since
30 May 1990
_#_Long-form name: none
_#_Type: The Antarctic Treaty, signed on 1 December 1959 and entered
into force on 23 June 1961, established for at least 30 years a legal
framework for peaceful use, scientific research, and deferral of legal
questions regarding territorial claims. Administration is carried out
through consultative member meetings--the last meeting was held in Madrid
(Spain) in April 1991.
Consultative (voting) members include seven nations that claim
portions of Antarctica as national territory (some claims overlap) and
nonclaimant nations. The US and other nations have made no claims, but
have reserved the right to claim territory. The US does not recognize the
claims of others. The year in parentheses indicates when an acceding
nation was voted to full consultative (voting) status, while no date
indicates an original 1959 treaty signatory. Claimant nations
are--Argentina, Australia, Chile, France, New Zealand, Norway, and the
UK. Nonclaimant consultative nations are--Belgium, Brazil (1983),
China (1985), Ecuador (1990), Finland (1989), Germany (1981), India
(1983), Italy (1987), Japan, South Korea (1989), Netherlands (1990), Peru
(1989), Poland (1977), South Africa, Spain (1988), Sweden (1988), Uruguay
(1985), the US, and the USSR.
Acceding (nonvoting) members, with year of accession in parenthesis,
are--Austria (1987), Bulgaria (1978), Canada (1988), Colombia (1988),
Cuba (1984), Czechoslovakia (1962), Denmark (1965), Greece (1987),
Hungary (1984), North Korea (1987), Papua New Guinea (1981), Romania
(1971), and Switzerland (1990).
Antarctic Treaty Summary:
Article 1--area to be used for peaceful purposes only; military
activity, such as weapons testing, is prohibited, but military personnel
and equipment may be used for peaceful scientific and logistics purposes;
Article 2--freedom of scientific investigation and cooperation
shall continue;
Article 3--free exchange of information and personnel in
cooperation with the UN and other international agencies;
Article 4--does not recognize, dispute, or establish territorial
claims and no new claims shall be asserted while the treaty is in force;
Article 5--prohibits nuclear explosions or disposal of radioactive
wastes;
Article 6--includes under the treaty all land and ice shelves
south of 60o 00%19 south, but that the water areas be covered by
international law;
Article 7--treaty-state observers have free access, including
aerial observation, to any area and may inspect all stations,
installations, and equipment; advance notice of all activities
and the introduction of military personnel must be given;
Article 8--allows for jurisdiction over observers and scientists
by their own states;
Article 9--frequent consultative meetings take place among
member nations;
Article 10--treaty states will discourage activities by any
country in Antarctica that are contrary to the treaty;
Article 11--disputes to be settled peacefully by the parties
concerned or, ultimately, by the ICJ;
Articles 12, 13, 14--deal with upholding, interpreting, and
amending the treaty among involved nations.
Other agreements: more than 150 recommendations adopted at
treaty consultative meetings and ratified by governments
include--Agreed Measures for the Conservation of Antarctic Fauna and
Flora (1964); Convention for the Conservation of Antarctic Seals (1972);
Convention on the Conservation of Antarctic Marine Living Resources
(1980); a mineral resources agreement was signed in 1988 but was
subsequently rejected by some signatories and is likely to be replaced in
1991 by a comprehensive environmental protection agreement that defers
minerals development for a long period.
_#_Long-form name: none
_#_Type: parliamentary democracy
_#_Capital: Saint John''s
_#_Administrative divisions: 6 parishes and 2 dependencies*; Barbuda*,
Redonda*, Saint George, Saint John, Saint Mary, Saint Paul, Saint Peter,
Saint Philip
_#_Independence: 1 November 1981 (from UK)
_#_Constitution: 1 November 1981
_#_Legal system: based on English common law
_#_National holiday: Independence Day, 1 November (1981)
_#_Executive branch: British monarch, governor general, prime
minister, deputy prime minister, Cabinet
_#_Legislative branch: bicameral Parliament consists of an upper house
or Senate and a lower house or House of Representatives
_#_Judicial branch: Eastern Caribbean Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor General Sir Wilfred Ebenezer JACOBS (since 1
November 1981, previously Governor since 1976);
Head of Government--Prime Minister Vere Cornwall BIRD, Sr. (since
NA 1976)
_#_Political parties and leaders:
Antigua Labor Party (ALP), Vere C. BIRD, Sr., Lester BIRD;
United National Democratic Party (UNDP), Dr. Ivor HEATH
_#_Suffrage: universal at age 18
_#_Elections:
House of Representatives--last held 9 March 1989 (next to be
held 1994);
results--percentage of vote by party NA;
seats--(17 total) ALP 15, UNDP 1, independent 1
_#_Communists: negligible
_#_Other political or pressure groups: Antigua Caribbean Liberation
Movement (ACLM), a small leftist nationalist group led by Leonard (Tim)
HECTOR; Antigua Trades and Labor Union (ATLU), headed by Noel THOMAS
_#_Member of: ACP, C, CARICOM, CDB, ECLAC, FAO, G-77, GATT, IBRD,
ICAO, ICFTU, IFAD, IFC, ILO, IMF, IMO, INTERPOL, IOC, ITU, NAM
(observer), OAS, OECS, OPANAL, UN, UNCTAD, UNESCO, WCL, WHO, WMO
_#_Diplomatic representation: Ambassador Edmund Hawkins LAKE;
Chancery at Suite 2H, 3400 International Drive NW, Washington DC 20008;
telephone (202) 362-5211 or 5166, 5122, 5225; there is an Antiguan
Consulate in Miami;
US--the US Ambassador to Barbados is accredited to Antigua and
Barbuda, and in his absence, the Embassy is headed by Charge d''Affaires
Bryant SALTER; Embassy at Que','fb8f872df784b9a249fbc2e152beda41e9387aa2122ae8c360bb6e0cf8bb7f29','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03e7de3ea8eea8f708553441ced5b3988981e31634e13a729f16d71951c45140',1991,'ZW','Zimbabwe','government',18,'en Elizabeth Highway, Saint John''s
(mailing address is FPO Miami 34054); telephone (809) 462-3505 or 3506
_#_Flag: red with an inverted isosceles triangle based on the top edge
of the flag; the triangle contains three horizontal bands of black (top),
light blue, and white with a yellow rising sun in the black band
_#_Long-form name: Argentine Republic
_#_Type: republic
_#_Capital: Buenos Aires (tentative plans to move to Viedma by
1990 indefinitely postponed)
_#_Administrative divisions: 22 provinces (provincias,
singular--provincia), 1 national territory* (territorio nacional), and 1
district** (distrito); Buenos Aires, Catamarca, Chaco, Chubut, Cordoba,
Corrientes, Distrito Federal**, Entre Rios, Formosa, Jujuy, La Pampa,
La Rioja, Mendoza, Misiones, Neuquen, Rio Negro, Salta, San Juan, San
Luis, Santa Cruz, Santa Fe, Santiago del Estero, Tierra del Fuego,
Antartida e Islas del Atlantico Sur*, Tucuman; note--the national
territory is in the process of becoming a province; the US does not
recognize claims to Antarctica
_#_Independence: 9 July 1816 (from Spain)
_#_Constitution: 1 May 1853
_#_Legal system: mixture of US and West European legal systems; has
not accepted compulsory ICJ jurisdiction
_#_National holiday: Revolution Day, 25 May (1810)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: bicameral National Congress (Congreso Nacional)
consists of an upper chamber or Senate (Senado) and a lower chamber or
Chamber of Deputies (Camara de Diputados)
_#_Judicial branch: Supreme Court (Corte Suprema)
_#_Leaders:
Chief of State and Head of Government--President Carlos Saul
MENEM (since 8 July 1989); Vice President Eduardo DUHALDE (since 8 July
1989)
_#_Political parties and leaders:
Justicialist Party (JP), Carlos Saul MENEM, Peronist umbrella political
organization;
Radical Civic Union (UCR), Raul ALFONSIN, moderately left of center;
Union of the Democratic Center (UCD), Alvaro ALSOGARAY, conservative
party;
Intransigent Party (PI), Dr. Oscar ALENDE, leftist party;
several provincial parties
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 14 May 1989 (next to be held May 1995);
results--Carlos Saul MENEM was elected;
Chamber of Deputies--last held 14 May 1989 (next to be
held October 1991); results--JP 47%, UCR 30%, UCD 7%, other 16%;
seats--(254 total); JP 122, UCR 93, UCD 11, other 28
_#_Communists: some 70,000 members in various party organizations,
including a small nucleus of activists
_#_Other political or pressure groups: Peronist-dominated labor
movement, General Confederation of Labor (Peronist-leaning umbrella labor
organization), Argentine Industrial Union (manufacturers'' association),
Argentine Rural Society (large landowners'' association), business
organizations, students, the Roman Catholic Church, the Armed Forces
_#_Member of: AfDB, AG (observer), CCC, ECLAC, FAO, G-6, G-11,
G-19, G-24, G-77, GATT, IADB, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IFAD,
IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC, IOM, ISO, ITU,
LAES, LAIA, LORCS, NAM, OAS, PCA, RG, UN, UNAVEM, UNCTAD,
UNESCO, UNHCR, UNIDO, UNIIMOG, UNTSO, UPU, WCL, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Ortiz de ROZAS;
Chancery at 1600 New Hampshire Avenue NW, Washington DC 20009; telephone
(202) 939-6400 through 6403; there are Argentine Consulates General in
Houston, Miami, New Orleans, New York, San Francisco, and San Juan
(Puerto Rico), and Consulates in Baltimore, Chicago, and Los Angeles;
US--Ambassador Terence A. TODMAN; Embassy at 4300 Colombia,
1425 Buenos Aires (mailing address is APO Miami 34034);
telephone [54] (1) 774-7611 or 8811, 9911
_#_Flag: three equal horizontal bands of light blue (top), white, and
light blue; centered in the white band is a radiant yellow sun with a
human face known as the Sun of May
_#_Long-form name: none
_#_Type: part of the Dutch realm--full autonomy in internal affairs
obtained in 1986 upon separation from the Netherlands Antilles
_#_Capital: Oranjestad
_#_Administrative divisions: none (self-governing part of the
Netherlands)
_#_Independence: none (part of the Dutch realm); note--in 1990 Aruba
requested and received from the Netherlands cancellation of the
agreement to automatically give independence to the island in 1996
_#_Constitution: 1 January 1986
_#_Legal system: based on Dutch civil law system, with some English
common law influence
_#_National holiday: Flag Day, 18 March
_#_Executive branch: Dutch monarch, governor, prime minister, Council
of Ministers (cabinet)
_#_Legislative branch: unicameral legislature (Staten)
_#_Judicial branch: Joint High Court of Justice
_#_Leaders:
Chief of State--Queen BEATRIX Wilhelmina Armgard (since 30 April
1980), represented by Governor General Felipe B. TROMP (since 1 January
1986);
Head of Government--Prime Minister Nelson ODUBER (since NA February
1989)
_#_Political parties and leaders:
Electoral Movement Party (MEP), Nelson ODUBER;
Aruban People''s Party (AVP), Henny EMAN;
National Democratic Action (ADN), Pedro Charro KELLY;
New Patriotic Party (PPN), Eddy WERLEMEN;
Aruban Patriotic Party (PPA), Leo CHANCE;
Aruban Democratic Party (PDA), Leo BERLINSKI;
Democratic Action ''86 (AD''86), Arturo ODUBER;
governing coalition includes the MEP, PPA, and ADN
_#_Suffrage: universal at age 18
_#_Elections:
Legislature--last held 6 January 1989 (next to be held by January
1993);
results--percent of vote by party NA;
seats--(21 total) MEP 10, AVP 8, ADN 1, PPN 1, PPA 1
_#_Member of: ECLAC (associate), INTERPOL, IOC, UNESCO (associate),
WCL, WTO (associate)
_#_Diplomatic representation: none (self-governing part of the
Netherlands)
_#_Flag: blue with two narrow horizontal yellow stripes across the
lower portion and a red, four-pointed star outlined in white in the upper
hoist-side corner
_#_Long-form name: Territory of Ashmore and Cartier Islands
_#_Type: territory of Australia administered by the Australian
Ministry for Territories and Local Government
_#_Administrative divisions: none (territory of Australia)
_#_Legal system: relevant laws of the Northern Territory of Australia
_#_Note: administered by the Australian Minister for Arts, Sports, the
Environment, Tourism, and Territories Roslyn KELLY
_#_Diplomatic representation: none (territory of Australia)
_#_Long-form name: Commonwealth of Australia
_#_Type: federal parliamentary state
_#_Capital: Canberra
_#_Administrative divisions: 6 states and 2 territories*; Australian
Capital Territory*, New South Wales, Northern Territory*, Queensland,
South Australia, Tasmania, Victoria, Western Australia
_#_Dependent areas: Ashmore and Cartier Islands, Christmas Island,
Cocos (Keeling) Islands, Coral Sea Islands, Heard Island and McDonald
Islands, Norfolk Island
_#_Independence: 1 January 1901 (federation of UK colonies)
_#_Constitution: 9 July 1900, effective 1 January 1901
_#_Legal system: based on English common law; accepts compulsory ICJ
jurisdiction, with reservations
_#_National holiday: Australia Day (last Monday in January), 29
January 1990
_#_Executive branch: British monarch, governor general, prime
minister, deputy prime minister, Cabinet
_#_Legislative branch: bicameral Federal Parliament consists of an
upper house or Senate and a lower house or House of Representatives
_#_Judicial branch: High Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since February 1952),
represented by Governor General William George HAYDEN (since NA February
1989);
Head of Government--Prime Minister Robert James Lee HAWKE (since
11 March 1983); Deputy Prime Minister Paul KEATING (since 3 April 1990)
_#_Political parties and leaders:
government--Australian Labor Party, Robert James Lee HAWKE;
opposition--Liberal Party, John HEWSON;
National Party, Timothy FISCHER;
Australian Democratic Party, Janet POWELL
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
Senate--last held 11 July 1987 (next to be held by July 1993);
results--Labor 43%, Liberal-National 42%, Australian Democrats 8%,
independents 2%;
seats--(76 total) Labor 32, Liberal-National 34, Australian
Democrats 7, independents 3;
House of Representatives--last held 24 March 1990 (next to be
held by November 1993);
results--Labor 39.7%, Liberal-National 43%, Australian Democrats
and independents 11.1%;
seats--(148 total) Labor 78, Liberal-National 69, independent 1
_#_Communists: 4,000 members (est.)
_#_Other political or pressure groups: Australian Democratic Labor
Party (anti-Communist Labor Party splinter group); Peace and Nuclear
Disarmament Action (Nuclear Disarmament Party splinter group)
_#_Member of: AfDB, AG (observer), ANZUS, APEC, AsDB, BIS, C, CCC, CP,
EBRD, ESCAP, FAO, GATT, G-8, IAEA, IBRD, ICAO, ICC, ICFTU, IDA,
IEA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC, IOM,
ISO, ITU, LORCS, NAM (guest), NEA, OECD, PCA, SPC, SPF, UN, UNCTAD,
UNESCO, UNFICYP, UNHCR, UNIIMOG, UNTAG, UNTSO, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Michael J. COOK; Chancery at
1601 Massachusetts Avenue NW, Washington DC 20036; telephone (202)
797-3000; there are Australian Consulates General in Chicago, Honolulu,
Houston, Los Angeles, New York, Pago Pago (American Samoa), and San
Francisco;
US--Ambassador Melvin F. SEMBLER; Moonah Place, Yarralumla,
Canberra, Australian Capital Territory 2600 (mailing address is APO San
Francisco 96404); telephone [61] (6) 270-5000; there are US Consulates
General in Melbourne, Perth, and Sydney, and a Consulate in Brisbane
_#_Flag: blue with the flag of the UK in the upper hoist-side quadrant
and a large seven-pointed star in the lower hoist-side quadrant; the
remaining half is a representation of the Southern Cross constellation in
white with one small five-pointed star and four, larger, seven-pointed
stars
_#_Long-form name: Republic of Austria
_#_Type: federal republic
_#_Capital: Vienna
_#_Administrative divisions: 9 states (bundeslander,
singular--bundesland); Burgenland, Karnten, Niederosterreich,
Oberosterreich, Salzburg, Steiermark, Tirol, Vorarlberg, Wien
_#_Independence: 12 November 1918 (from Austro-Hungarian Empire)
_#_Constitution: 1920, revised 1929 (reinstated 1945)
_#_Legal system: civil law system with Roman law origin; judicial
review of legislative acts by a Constitutional Court; separate
administrative and civil/penal supreme courts; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: National Day, 26 October (1955)
_#_Executive branch: president, chancellor, vice chancellor, Council
of Ministers (cabinet)
_#_Legislative branch: bicameral Federal Assembly (Bundesversammlung)
consists of an upper council or Federal Council (Bundesrat) and a lower
council or National Council (Nationalrat)
_#_Judicial branch: Supreme Judicial Court (Oberster Gerichtshof) for
civil and criminal cases, Administrative Court (Verwaltungsgerichtshof)
for bureaucratic cases, Constitutional Court (Verfassungsgerichtshof) for
constitutional cases
_#_Leaders:
Chief of State--President Kurt WALDHEIM (since 8 July 1986);
Head of Government--Chancellor Franz VRANITZKY (since 16 June
1986); Vice Chancellor Josef RIEGLER (since 19 May 1989)
_#_Political parties and leaders:
Socialist Party of Austria (SPO), Franz VRANITZKY, chairman;
Austrian People''s Party (OVP), Josef RIEGLER, chairman;
Freedom Party of Austria (FPO), Jorg HAIDER, chairman;
Communist Party (KPO), Franz MUHRI, chairman;
Green Alternative List (GAL), Andreas WABL, chairman
_#_Suffrage: universal at age 19; compulsory for presidential
elections
_#_Elections:
President--last held 8 June 1986 (next to be held May 1992);
results of Second Ballot--Dr. Kurt WALDHEIM 53.89%, Dr. Kurt STEYRER
46.11%;
National Council--last held 7 October 1990 (next to be
held October 1994);
results--SP0 43%, OVP 32.1%, FPO 16.6%, GAL 4.5%, KPO 0.7%,
other 0.32%;
seats--(183 total) SP0 80, OVP 60, FP0 33, GAL 10
_#_Communists: membership 15,000 est.; activists 7,000-8,000
_#_Other political or pressure groups: Federal Chamber of Commerce and
Industry; Austrian Trade Union Federation (primarily Socialist); three
composite leagues of the Austrian People''s Party (OVP) representing
business, labor, and farmers; OVP-oriented League of Austrian
Industrialists; Roman Catholic Church, including its chief lay
organization, Catholic Action
_#_Member of: AfDB, AG (observer), AsDB, BIS, CCC, CE, CERN, CSCE,
EBRD, ECE, EFTA, ESA, FAO, G-9, GATT, IADB, IAEA, IBRD, ICAO, ICC, ICFTU,
IDA, IEA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, IOM, ISO,
ITU, LORCS, NAM (guest), NEA, OAS (observer), OECD, PCA, UN, UNCTAD,
UNESCO, UNDOF, UNFICYP, UNHCR, UNIDO, UNIIMOG, UNTSO, UPU, WCL,
WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Friedrich HOESS; Embassy at
2343 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
483-4474; there are Austrian Consulates General in Chicago, Los Angeles,
and New York;
US--Ambassador Roy Michael HUFFINGTON; Embassy at Boltzmanngasse
16, A-1091, Vienna (mailing address is APO New York 09108-0001);
telephone [43] (222) 31-55-11; there is a US Consulate General in Salzburg
_#_Flag: three equal horizontal bands of red (top), white, and red
_#_Long-form name: The Commonwealth of The Bahamas
_#_Type: commonwealth
_#_Capital: Nassau
_#_Administrative divisions: 21 districts; Abaco, Acklins Island,
Andros Island, Berry Islands, Biminis, Cat Island, Cay Lobos, Crooked
Island, Eleuthera, Exuma, Grand Bahama, Harbour Island, Inagua, Long Cay,
Long Island, Mayaguana, New Providence, Ragged Island, Rum Cay, San
Salvador, Spanish Wells
_#_Independence: 10 July 1973 (from UK)
_#_Constitution: 10 July 1973
_#_Legal system: based on English common law
_#_National holiday: Independence Day, 10 July (1973)
_#_Executive branch: British monarch, governor general, prime
minister, deputy prime minister, Cabinet
_#_Legislative branch: bicameral Parliament consists of an upper house
or Senate and a lower house or House of Assembly
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Acting Governor General Sir Henry TAYLOR (since 26 June
1988);
Head of Government--Prime Minister Sir Lynden Oscar PINDLING (since
16 January 1967)
_#_Political parties and leaders:
Progressive Liberal Party (PLP), Sir Lynden O. PINDLING;
Free National Movement (FNM), Hubert Alexander INGRAHAM
_#_Suffrage: universal at age 18
_#_Elections:
House of Assembly--last held 19 June 1987 (next to be held
by June 1992);
results--percent of vote by party NA;
seats--(49 total) PLP 32, FNM 17
_#_Communists: none known
_#_Other political or pressure groups: Vanguard Nationalist and
Socialist Party (VNSP), a small leftist party headed by Lionel CAREY;
Trade Union Congress (TUC), headed by Arlington MILLER
_#_Member of: ACP, C, CCC, CARICOM, CDB, ECLAC, FAO, G-77, IADB,
IBRD, ICAO, ICFTU, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, ITU,
LORCS, NAM, OAS, OPANAL, UN, UNCTAD, UNESCO, UNIDO, UPU, WHO, WIPO,
WMO
_#_Diplomatic representation: Ambassador Margaret E. McDONALD;
Chancery at Suite 865, 600 New Hampshire Avenue NW, Washington DC 20037;
telephone (202) 944-3390; there are Bahamian Consulates General in Miami
and New York;
US--Ambassador Chic HECHT; Embassy at Mosmar Building,
Queen Street, Nassau (mailing address is P. O. Box N-8197, Nassau);
telephone (809) 322-1181 or 328-2206
_#_Flag: three equal horizontal bands of aquamarine (top), gold, and
aquamarine with a black equilateral triangle based on the hoist side
_#_Long-form name: State of Bahrain
_#_Type: traditional monarchy
_#_Capital: Manama
_#_Administrative divisions: 12 municipalities (baladiyat,
singular--baladiyah); Al Hadd, Al Manamah,
Al Mintaqah al Gharbiyah, Al Mintaqah al Wusta,
Al Mintaqah ash Shamaliyah, Al Muharraq,
Ar Rifa wa al Mintaqah al Janubiyah, Jidd Hafs,
Madinat Hamad, Madinat Isa, Mintaqat Juzur Hawar,
Sitrah
_#_Independence: 15 August 1971 (from UK)
_#_Constitution: 26 May 1973, effective 6 December 1973
_#_Legal system: based on Islamic law and English common law
_#_National holiday: National Day, 16 December
_#_Executive branch: amir, crown prince and heir apparent, prime
minister, Cabinet
_#_Legislative branch: unicameral National Assembly was dissolved
26 August 1975 and legislative powers were assumed by the Cabinet
_#_Judicial branch: High Civil Appeals Court
_#_Leaders:
Chief of State--Amir Isa bin Salman Al KHALIFA (since
2 November 1961); Heir Apparent Hamad bin Isa Al KHALIFA (son of Amir;
born 28 January 1950);
Head of Government--Prime Minister Khalifa bin Salman Al KHALIFA,
(since 19 January 1970)
_#_Political parties and pressure groups: political parties
prohibited; several small, clandestine leftist and Shia fundamentalist
groups are active
_#_Suffrage: none
_#_Elections: none
_#_Communists: negligible
_#_Member of: ABEDA, AFESD, AL, AMF, ESCWA, FAO, G-77, GCC, IBRD,
ICAO, IDB, ILO, IMF, IMO, INMARSAT, INTERPOL, IOC, ISO (correspondent),
ITU, LORCS, NAM, OAPEC, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO,
WMO
_#_Diplomatic representation: Ambassador Ghazi Muhammad AL-QUSAYBI;
Chancery at 3502 International Drive NW, Washington DC 20008; telephone
(202) 342-0741 or 342-0742; there is a Bahraini Consulate General in
New York;
US--Ambassador Dr. Charles W. HOSTLER; Embassy at Building
No. 979, Road No. 3119, Block/Area 331, Manama ZINJ (mailing address is
P. O. 26431, Manama, or FPO New York 09526-6210); telephone [973]
273-300 or 275-126
_#_Flag: red with a white serrated band (eight white points) on the
hoist side
_#_Long-form name: none
_#_Type: unincorporated territory of the US administered by the Fish
and Wildlife Service of the US Department of the Interior as part of the
National Wildlife Refuge system
_#_Long-form name: People''s Republic of Bangladesh
_#_Type: republic
_#_Capital: Dhaka
_#_Administrative divisions: 64 districts (zillagulo,
singular--zilla); Bagerhat, Bandarban, Barguna, Barisal,
Bhola, Bogra, Brahmanbaria, Chandpur, Chapai Nawabganj,
Chattagram, Chuadanga, Comilla, Cox''s Bazar, Dhaka,
Dinajpur, Faridpur, Feni, Gaibandha, Gazipur, Gopalganj,
Habiganj, Jaipurhat, Jamalpur, Jessore, Jhalakati, Jhenaidah,
Khagrachari, Khulna, Kishorganj, Kurigram, Kushtia, Laksmipur,
Lalmonirhat, Madaripur, Magura, Manikganj, Meherpur,
Moulavibazar, Munshiganj, Mymensingh, Naogaon, Narail,
Narayanganj, Narsingdi, Nator, Netrakona, Nilphamari,
Noakhali, Pabna, Panchagar, Parbattya Chattagram,
Patuakhali, Pirojpur, Rajbari, Rajshahi, Rangpur,
Satkhira, Shariyatpur, Sherpur, Sirajganj, Sunamganj, Sylhet,
Tangail, Thakurgaon
_#_Independence: 16 December 1971 (from Pakistan; formerly East
Pakistan)
_#_Constitution: 4 November 1972, effective 16 December 1972,
suspended following coup of 24 March 1982, restored 10 November 1986,
amended NA March 1991
_#_Legal system: based on English common law
_#_National holiday: Independence Day, 26 March (1971)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: unicameral National Parliament (Jatiya Sangsad)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Abdur Rahman BISWAS (since
8 October 1991)
Head of Government--Prime Minister Khaleda ZIAUR Rahman
(since 20 March 1991)
_#_Political parties and leaders:
Bangladesh Nationalist Party, Khaleda ZIAUR Rahman;
Awami League, Sheikh Hasina WAZED;
Jatiyo Party, Hussain Mohammad ERSHAD;
Jamaat-E-Islami, Ali KHAN;
Bangladesh Communist Party (pro-Soviet), Saifuddin Ahmed MANIK;
National Awami Party (Muzaffar);
Workers Party, leader NA;
Jatiyo Samajtantik Dal (National Socialist Party--SIRAJ), M. A. JALIL;
Ganotantri Party, leader NA;
Islami Oikya Jote, leader NA;
National Democratic Party, leader NA;
Muslim League, Khan A. SABUR;
Democratic League, Khondakar MUSHTAQUE Ahmed;
United People''s Party, Kazi ZAFAR Ahmed
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 8 October 1991 (next to be held by October
1996);
results--Abdur Rahman BISWAS received 52.1% of parliamentary vote
National Parliament--last held 27 February 1991 (next to be held
February 1996); results--percent of vote by party NA;
seats--(330 total, 300 elected and 30 seats reserved for women)
BNP 168, AL 93, JP 35, JI 20, CBP 5, National Awami Party (Muzaffar) 1,
Workers Party 1, SIRAJ 1, Ganotantri Party 1, Islami Oikya Jote 1,
NDP 1, independents 3
_#_Communists: 5,000 members (1987 est.)
_#_Member of: AsDB, C, CCC, CP, ESCAP, FAO, G-77, GATT, IAEA, IBRD,
ICAO, ICFTU, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC,
ISO, ITU, LORCS, NAM, OIC, SAARC, UN, UNCTAD, UNESCO, UNIDO, UNIIMOG,
UPU, WHO, WFTU, WIPO, WCL, WMO, WTO
_#_Diplomatic representation: Ambassador A. H. S. Ataul KARIM;
Chancery at 2201 Wisconsin Avenue NW, Washington DC 20007; telephone
(202) 342-8372 through 8376; there is a Bangladesh Consulate General in
New York;
US--Ambassador William B. MILAM; Embassy at Diplomatic
Enclave, Madani Avenue, Baridhara, Dhaka (mailing address
is G. P. O. Box 323, Dhaka 1212); telephone [880] (2) 884700-22
_#_Flag: green with a large red disk slightly to the hoist side of
center; green is the traditional color of Islam
_#_Long-form name: none
_#_Type: parliamentary democracy
_#_Capital: Bridgetown
_#_Administrative divisions: 11 parishes; Christ Church, Saint Andrew,
Saint George, Saint James, Saint John, Saint Joseph, Saint Lucy,
Saint Michael, Saint Peter, Saint Philip, Saint Thomas; note--there may
be a new city of Bridgetown
_#_Independence: 30 November 1966 (from UK)
_#_Constitution: 30 November 1966
_#_Legal system: English common law; no judicial review of
legislative acts
_#_National holiday: Independence Day, 30 November (1966)
_#_Executive branch: British monarch, governor general, prime
minister, deputy prime minister, Cabinet
_#_Legislative branch: bicameral Parliament consists of an upper
house or Senate and a lower house or House of Assembly
_#_Judicial branch: Supreme Court of Judicature
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor General Sir Hugh SPRINGER (since 24 February
1984);
Head of Government--Prime Minister Lloyd Erskine SANDIFORD (since
2 June 1987)
_#_Political parties and leaders:
Democratic Labor Party (DLP), Erskine SANDIFORD;
Barbados Labor Party (BLP), Henry FORDE;
National Democratic Party (NDP), Richie HAYNES
_#_Suffrage: universal at age 18
_#_Elections:
House of Assembly--last held 22 January 1991 (next to be held by
January 1996);
results--DLP 49.8%;
seats--(28 total) DLP 18, BLP 10
_#_Communists: negligible
_#_Other political or pressure groups: Industrial and General Workers
Union, Sir Frank WALCOTT; People''s Progressive Movement, Eric SEALY;
Workers'' Party of Barbados, Dr. George BELLE
_#_Member of: ACP, C, CARICOM, CDB, ECLAC, FAO, G-77, GATT, IADB,
IBRD, ICAO, ICFTU, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC,
ISO (correspondent), ITU, LAES, LORCS, NAM, OAS, OPANAL, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Sir William DOUGLAS; Chancery
at 2144 Wyoming Avenue NW, Washington DC 20008; telephone (202) 939-9200
through 9202; there is a Barbadian Consulate General in New York and a
Consulate in Los Angeles;
US--Ambassador G. Philip HUGHES; Embassy at Canadian
Imperial Bank of Commerce Building, Broad Street, Bridgetown (mailing
address is P. O. Box 302, Bridgetown or FPO Miami 34054); telephone (809)
436-4950 through 4957
_#_Flag: three equal vertical bands of blue (hoist side), yellow, and
blue with the head of a black trident centered on the gold band; the
trident head represents independence and a break with the past (the
colonial coat of arms contained a complete trident)
_#_Long-form name: none
_#_Type: French possession administered by Commissioner of the
Republic Daniel CONSTANTIN, resident in Reunion
_#_Long-form name: Kingdom of Belgium
_#_Type: constitutional monarchy
_#_Capital: Brussels
_#_Administrative divisions: 9 provinces (French--provinces,
singular--province; Flemish--provincien, s','29b9d3f3597f183b5827117cf55e6383d25fe69ea886117f2b877d72f794e589','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db09cb8504927ed7285ac97f4622250371fd9ce5d4a8392d022cb91eadcb0fa4',1991,'ZW','Zimbabwe','government',19,'ingular--provincie);
Antwerpen, Brabant, Hainaut, Liege, Limburg, Luxembourg, Namur,
Oost-Vlaanderen, West-Vlaanderen
_#_Independence: 4 October 1830 (from the Netherlands)
_#_Constitution: 7 February 1831, last revised 8-9 August 1980; the
government is in the process of revising the Constitution, with the aim
of federalizing the Belgian state
_#_Legal system: civil law system influenced by English constitutional
theory; judicial review of legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
_#_National holiday: National Day, 21 July (ascension of King Leopold
to the throne in 1831)
_#_Executive branch: monarch, prime minister, five deputy prime
ministers, Cabinet
_#_Legislative branch: bicameral Parliament consists of an upper
chamber or Senate (Flemish--Senaat, French--Senat) and a lower chamber
or Chamber of Representatives (Flemish--Kamer van
Volksvertegenwoordigers, French--Chambre des Representants)
_#_Judicial branch: Supreme Court of Justice (Flemish--Hof van
Cassatie, French--Cour de Cassation)
_#_Leaders:
Chief of State--King BAUDOUIN I (since 17 July 1951);
Heir Apparent Prince ALBERT of Liege (brother of the King; born 6
June 1934);
Head of Government--Prime Minister Wilfried MARTENS,
(since April 1979, with a 10-month interruption in 1981)
_#_Political parties and leaders:
Flemish Social Christian (CVP), Herman van ROMPUY, president;
Walloon Social Christian (PSC), Gerard DEPREZ, president;
Flemish Socialist (SP), Frank VANDENBROUCKE, president;
Walloon Socialist (PS), Guy SPITAELS, president;
Flemish Liberal (PVV), Guy VERHOFSTADT, president;
Walloon Liberal (PRL), Antoine DUQUESNE, president;
Francophone Democratic Front (FDF), Georges CLERFAYT, president;
Volksunie (VU), Jaak GABRIELS, president;
Communist Party (PCB), Louis van GEYT, president;
Vlaams Blok (VB), Karel DILLEN;
other minor parties
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
Senate--last held 13 December 1987 (next to be held by
January 1992);
results--CVP 19.2%, PS 15.7%, SP 14.7%, PVV 11.3%, PRL 9.3%,
VU 8.1%, PSC 7.8%, ECOLO-AGALEV 7.7%, VB 2.0%, VDF 1.3%,
other 1.96%;
seats--(106 total) CVP 22, PS 20, SP 17, PRL 12, PVV 11, PSC 9, VU 8,
ECOLO-AGALEV 5, VB 1, FDF 1;
Chamber of Representatives--last held 13 December 1987
(next to be held by January 1992);
results--CVP 19.45%, PS 15.66%, SP 14.88%, PVV 11.55%, PRL 9.41%,
PSC 8.01%, VU 8.05%, ECOLO-AGALEV 7.05%, VB 1.90%, FDF 1.16%, other
2.88%;
seats--(212 total) CVP 43, PS 40, SP 32, PVV 25, PRL 23,
PSC 19, VU 16, ECOLO-AGALEV 9, FDF 3, VB 2
_#_Communists: under 5,000 members (December 1985 est.)
_#_Other political or pressure groups: Christian and Socialist Trade
Unions; Federation of Belgian Industries; numerous other associations
representing bankers, manufacturers, middle-class artisans, and the legal
and medical professions; various organizations represent the cultural
interests of Flanders and Wallonia; various peace groups such as the
Flemish Action Committee Against Nuclear Weapons and Pax Christi
_#_Member of: ACCT, AfDB, AG (observer), AsDB, Benelux, BIS, CCC, CE,
CERN, COCOM, CSCE, EBRD, EC, ECE, EIB, ESA, FAO, G-9, G-10, GATT, IADB,
IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IEA, IFAD, IFC, ILO, IMF, IMO,
INMARSAT, INTELSAT, INTERPOL, IOC, IOM, ISO, ITU, LORCS, NATO, NEA, OAS
(observer), OECD, PCA, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UNMOGIP,
UNRWA, UPU, WCL, WEU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Juan CASSIERS; Chancery at
3330 Garfield Street NW, Washington DC 20008; telephone (202) 333-6900;
there are Belgian Consulates General in Atlanta, Chicago, Houston, Los
Angeles, and New York;
US--Ambassador Maynard W. GLITMAN; Embassy at 27 Boulevard du
Regent, B-1000 Brussels (mailing address is APO New York 09667-1000);
telephone [32] (2) 513-3830; there is a US Consulate General in Antwerp
_#_Flag: three equal vertical bands of black (hoist side), yellow,
and red; the design was based on the flag of France
_#_Long-form name: none
_#_Type: parliamentary democracy
_#_Capital: Belmopan
_#_Administrative divisions: 6 districts; Belize, Cayo, Corozal,
Orange Walk, Stann Creek, Toledo
_#_Independence: 21 September 1981 (from UK; formerly British
Honduras)
_#_Constitution: 21 September 1981
_#_Legal system: English law
_#_National holiday: Independence Day, 21 September
_#_Executive branch: British monarch, governor general, prime
minister, deputy prime minister, Cabinet
_#_Legislative branch: bicameral National Assembly consists of an
upper house or Senate and a lower house or House of Representatives
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor General Dame Elmira Minita GORDON (since 21
September 1981);
Head of Government--Prime Minister George Cadle PRICE (since 4
September 1989)
_#_Political parties and leaders:
People''s United Party (PUP), George PRICE, Florencio MARIN, Said MUSA;
United Democratic Party (UDP), Manuel ESQUIVEL, Dean LINDO, Dean BARROW;
Belize Popular Party (BPP), Louis SYLVESTRE
_#_Suffrage: universal at age 18
_#_Elections:
National Assembly--last held 4 September 1989 (next to be
held September 1994);
results--percent of vote by party NA; seats--(28 total)
PUP 15 seats, UDP 13 seats; note--in January 1990 one
member expelled from UDP joined PUP, making the seat count
16 PUP, UDP 12
_#_Communists: negligible
_#_Other political or pressure groups: Society for the Promotion
of Education and Research (SPEAR) headed by former PUP minister;
United Workers Front
_#_Member of: ACP, C, CARICOM, CDB, ECLAC, FAO, G-77, GATT, IBRD, IDA,
IFAD, IFC, ILO, IMF, INTERPOL, IOC, IOM, (observer), ITU, LORCS,
NAM, OAS, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WMO
_#_Diplomatic representation: Ambassador James V. HYDE; Chancery at
Suite 2J, 3400 International Drive NW, Washington DC 20008; telephone
(202) 363-4505;
US--Ambassador Eugene L. SCASSA; Embassy at Gabourel Lane and
Hutson Street, Belize City (mailing address is P. O. Box 286, Belize
City); telephone [501] 77161 through 77163
_#_Flag: blue with a narrow red stripe along the top and the bottom
edges; centered is a large white disk bearing the coat of arms; the coat
of arms features a shield flanked by two workers in front of a mahogany
tree with the related motto SUB UMBRA FLOREO (I Flourish in the
Shade) on a scroll at the bottom, all encircled by a green garland
_#_Long-form name: Republic of Benin
_#_Type: dropped Marxism-Leninism December 1989; democratic reforms
adopted February 1990; transition to multiparty system completed 4
April 1991
_#_Capital: Porto-Novo (official), Cotonou (de facto)
_#_Administrative divisions: 6 provinces; Atakora, Atlantique, Borgou,
Mono, Oueme, Zou
_#_Independence: 1 August 1960 (from France; formerly Dahomey)
_#_Constitution: 2 December 1990
_#_Legal system: based on French civil law and customary law; has not
accepted compulsory ICJ jurisdiction
_#_National holiday: National Day, 1 August (1990)
_#_Executive branch: president, cabinet
_#_Legislative branch: unicameral National Assembly (Assemblee
Nationale)
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State and Head of Government--President Nicephore
SOGLO (since 4 April 1991)
_#_Political parties and leaders: the People''s Revolutionary Party
of Benin (PRPB) headed by President Mathieu KEREKOU, chairman of
the Central Committee, was dissolved 30 April 1990;
Alliance of the Democratic Union for the Forces of Progress (UDFP),
Timothee ADANLIN;
Movement for Democracy and Social Progress (MDPS), Jean-Roger AHOYO; and
the Union for Liberty and Development (ULD), Marcellin DEGBE;
Alliance of the National Party for Democracy and Development (PNDD) and
the Democratic Renewal Party (PRD), Pascal Chabi KAO;
Alliance of the Social Democratic Party (PSD) and the National Union
for Solidarity and Progress (UNSP), Bruno AMOUSSOU;
Our Common Cause (NCC), Albert TEVEODJRE;
National Rally for Democracy (RND), Joseph KEKE;
Alliance of the National Movement for Democracy and Development (MNDD);
Movement for Solidarity, Union, and Progress (MSUP);
and Union for Democracy and National Reconstruction (UDRN), Bertin BORNA;
Union for Democracy and National Solidarity (UDS), Mama Amadou N''DIAYE;
Assembly of Liberal Democrats for National Reconstruction (RDL),
Severin ADJOVI;
Alliance of the Alliance for Social Democracy (ASD) and Bloc for
Social Democracy (BSD), Robert DOSSOU;
Alliance of the Alliance for Democracy and Progress (ADP) and
Democratic Union for Social Renewal (UDRS), Bio Gado Seko N''GOYE;
National Union for Democracy and Progress (UNDP), Robert TAGNON;
numerous other small parties
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 10 and 24 March 1991 (next to be held
March 1996);
results--Nicephore SOGLO 68%, Mathieu KEREKOU 32%;
National Assembly--last held 10 and 24 March 1991 (next to be held
March 1996);
results--NA percent of the vote;
seats--(64 total) UDFP-MDPS-ULD 12, PNDD/PRD 9, PSD/UNSP 8, NCC 7,
RND 7, MNDD/MSUP/UDRN 6, UDS 5, RDL 4, ASD/BSD 3, ADP/UDRS 2, UNDP 1
_#_Communists: Communist Party of Dahomey (PCD) remains active
_#_Member of: ACCT, ACP, AfDB, CEAO, ECA, ECOWAS, Entente, FAO, FZ,
G-77, GATT, IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, ITU, LORCS, NAM, OAU, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU,
WADB, WCL, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Candide AHOUANSOU; Charge
d''Affaires Corneille MEHISSOU; Chancery at 2737 Cathedral Avenue NW,
Washington DC 20008; telephone (202) 232-6656;
US--Ambassador Harriet ISOM; Embassy at Rue Caporal Anani Bernard,
Cotonou (mailing address is B. P. 2012, Cotonou); telephone [229]
30-06-50
_#_Flag: two equal horizontal bands of yellow (top) and red with a
vertical green band on the hoist side
_#_Long-form name: none
_#_Type: dependent territory of the UK
_#_Capital: Hamilton
_#_Administrative divisions: 9 parishes and 2 municipalities*;
Devonshire, Hamilton, Hamilton*, Paget, Pembroke, Saint George*,
Saint George''s, Sandys, Smiths, Southampton, Warwick
_#_Independence: none (dependent territory of the UK)
_#_Constitution: 8 June 1968
_#_Legal system: English law
_#_National holiday: Bermuda Day, 22 May
_#_Executive branch: British monarch, governor, deputy governor,
premier, deputy premier, Executive Council (cabinet)
_#_Legislative branch: bicameral Parliament consists of an upper house
or Senate and a lower house or House of Assembly
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor Sir Desmond LANGLEY (since NA October 1988);
Head of Government--Premier John William David SWAN (since NA
January 1982)
_#_Political parties and leaders:
United Bermuda Party (UBP), John W. D. SWAN;
Progressive Labor Party (PLP), Frederick WADE;
National Liberal Party (NLP), Gilbert DARRELL
_#_Suffrage: universal at age 21
_#_Elections:
House of Assembly--last held 9 February 1989 (next to be
held by February 1994); results--percent of vote by party NA;
seats--(40 total) UBP 23, PLP 15, NLP 1, other 1
_#_Communists: negligible
_#_Other political or pressure groups: Bermuda Industrial Union (BIU),
headed by Ottiwell SIMMONS
_#_Member of: CARICOM (observer), ICFTU, IOC
_#_Diplomatic representation: as a dependent territory of the UK,
Bermuda''s interests in the US are represented by the UK;
US--Consul General L. Ebersole GAINES; Consulate General at
Crown Hill, 16 Middle Road, Devonshire, Hamilton (mailing address is
P. O. Box HM325, Hamilton HMBX, or FPO New York 09560-5300); telephone
(809) 295-1342
_#_Flag: red with the flag of the UK in the upper hoist-side quadrant
and the Bermudian coat of arms (white and blue shield with a red lion
holding a scrolled shield showing the sinking of the ship Sea Venture off
Bermuda in 1609) centered on the outer half of the flag
_#_Long-form name: Kingdom of Bhutan
_#_Type: monarchy; special treaty relationship with India
_#_Capital: Thimphu
_#_Administrative divisions: 18 districts (dzongkhag, singular
and plural); Bumthang, Chhukha, Chirang, Daga, Geylegphug, Ha, Lhuntshi,
Mongar, Paro, Pemagatsel, Punakha, Samchi, Samdrup Jongkhar, Shemgang,
Tashigang, Thimphu, Tongsa, Wangdi Phodrang
_#_Independence: 8 August 1949 (from India)
_#_Constitution: no written constitution or bill of rights
_#_Legal system: based on Indian law and English common law; has not
accepted compulsory ICJ jurisdiction
_#_National holiday: National Day (Ugyen Wangchuck became first
hereditary king), 17 December (1907)
_#_Executive branch: monarch, chairman of the Royal Advisory Council,
Royal Advisory Council (Lodoi Tsokde), chairman of the Council of
Ministers, Council of Ministers (Lhengye Shungtsog)
_#_Legislative branch: unicameral National Assembly (Tshogdu)
_#_Judicial branch: High Court
_#_Leaders:
Chief of State and Head of Government--King Jigme Singye WANGCHUCK
(since 24 July 1972)
_#_Political parties: no legal parties
_#_Suffrage: each family has one vote in village-level elections
_#_Elections: no national elections
_#_Communists: no overt Communist presence
_#_Other political or pressure groups: Buddhist clergy, Indian
merchant community; ethnic Nepalese organizations leading militant
antigovernment campaign
_#_Member of: AsDB, CP, ESCAP, FAO, G-77, IBRD, ICAO, IDA, IFAD, IMF,
IOC, ITU, NAM, SAARC, UN, UNCTAD, UNESCO, UNIDO, UPU, WHO
_#_Diplomatic representation: no formal diplomatic relations, although
informal contact is maintained between the Bhutanese and US Embassies in
New Delhi (India); the Bhutanese mission to the UN in New York has
consular jurisdiction in the US
_#_Flag: divided diagonally from the lower hoist side corner; the
upper triangle is orange and the lower triangle is red; centered along
the dividing line is a large black and white dragon facing away from the
hoist side
_#_Long-form name: Republic of Bolivia
_#_Type: republic
_#_Capital: La Paz (seat of government); Sucre (legal capital and seat
of judiciary)
_#_Administrative divisions: 9 departments (departamentos,
singular--departamento); Chuquisaca, Cochabamba, El Beni, La Paz, Oruro,
Pando, Potosi, Santa Cruz, Tarija
_#_Independence: 6 August 1825 (from Spain)
_#_Constitution: 2 February 1967
_#_Legal system: based on Spanish law and Code Napoleon; has not
accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 6 August (1825)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: bicameral National Congress (Congreso Nacional)
consists of an upper chamber or Chamber of Senators (Camara de
Senadores) and a lower chamber or Chamber of Deputies (Camara de
Diputados)
_#_Judicial branch: Supreme Court (Corte Suprema)
_#_Leaders:
Chief of State and Head of Government--President Jaime
PAZ Zamora (since 6 August 1989); Vice President Luis OSSIO Sanjines
(since 6 August 1989)
_#_Political parties and leaders:
Movement of the Revolutionary Left (MIR), Jaime PAZ Zamora;
Nationalist Democratic Action (ADN), Hugo BANZER Suarez;
Nationalist Revolutionary Movement (MNR), Gonzalo SANCHEZ de Lozada;
Christian Democratic Party (PDC), Jorge AGREDO;
Free Bolivia Movement (MBL), led by Antonio ARANIBAR;
United Left (IU), a coalition of leftist parties which includes
Patriotic National Convergency Axis (EJE-P) led by Walter DELGADILLO,
and Bolivian Communist Party (PCB) led by Humberto RAMIREZ;
Conscience of the Fatherland (CONDEPA), Carlos PALENQUE Aviles;
Revolutionary Vanguard-9th of April (VR-9), Carlos SERRATE Reich;
Civic Union Solidarity (UCS), Max FERNANDEZ
_#_Suffrage: universal and compulsory at age 18 (married) or 21
(single)
_#_Elections:
President--last held 7 May 1989 (next to be held May 1993);
results--Gonzalo SANCHEZ de Lozada (MNR) 23%, Hugo BANZER Suarez
(ADN) 22%, Jaime PAZ Zamora (MIR) 19%; no candidate received a
majority of the popular vote; Jaime PAZ Zamora (MIR) formed a
coalition with Hugo BANZER (ADN); with ADN support PAZ Zamora
won the congressional runoff election on 4 August and was inaugurated
on 6 August 1989;
Senate--last held 7 May 1989 (next to be held May 1993);
results--percent of vote NA;
seats (27 total) MNR 9, ADN 7, MIR 8, CONDEPA 2, PDC 1;
Chamber of Deputies--last held 7 May 1989 (next to be held May
1993); results--percent of vote by party NA;
seats (130 total) MNR 40, ADN 35, MIR 33, IU 10, CONDEPA 9,
PDC 3
_#_Member of: AG, ECLAC, FAO, G-11, G-77, GATT, IADB, IAEA, IBRD,
ICO, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, IOM,
ITU, LAES, LAIA, LORCS, NAM, OAS, OPANAL, PCA, RG, UN, UNCTAD, UNESCO,
UNIDO, UPU, WCL, WFTU, WHO, WMO, WTO
_#_Diplomatic representation: Ambassador Jorge CRESPO; Chancery at
3014 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
483-4410 through 4412; there are Bolivian Consulates General in Houston,
Los Angeles, Miami, New Orleans, New York, and San Francisco;
US--Ambassador Robert S. GELBARD; Embassy at Banco Popular del Peru
Building, corner of Calles Mercado y Colon, La Paz (mailing address is
P. O. Box 425, La Paz, or APO Miami 34032); telephone [591] (2)
350251 or 350120
_#_Flag: three equal horizontal bands of red (top), yellow, and green
with the coat of arms centered on the yellow band; similar to the flag of
Ghana, which has a large black five-pointed star centered in the yellow
band
_#_Long-form name: Republic of Botswana
_#_Type: parliamentary republic
_#_Capital: Gaborone
_#_Administrative divisions: 10 districts; Central, Chobe, Ghanzi,
Kgalagadi, Kgatleng, Kweneng, Ngamiland, North-East, South-East,
Southern; note--in addition, there may now be 4 town councils named
Francistown, Gaborone, Lobaste, Selebi-Pikwe
_#_Independence: 30 September 1966 (from UK; formerly Bechuanaland)
_#_Constitution: March 1965, effective 30 September 1966
_#_Legal system: based on Roman-Dutch law and local customary law;
judicial review limited to matters of interpretation; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: Botswana Day, 30 September (1966)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: bicameral National Assembly consists of an
upper house or House of Chiefs and a lower house or National Assembly
_#_Judicial branch: High Court, Court of Appeal
_#_Leaders:
Chief of State and Head of Government--President Quett K. J. MASIRE
(since 13 July 1980); Vice President Peter S. MMUSI (since 3 January
1983)
_#_Political parties and leaders:
Botswana Democratic Party (BDP), Quett MASIRE;
Botswana National Front (BNF), Kenneth KOMA;
Botswana People''s Party (BPP), Knight MARIPE;
Botswana Independence Party (BIP), Motsamai MPHO
_#_Suffrage: universal at age 21
_#_Elections:
President--last held 7 October 1989 (next to be held October
1994);
results--President Quett K. J. MASIRE was reelected by the National
Assembly;
National Assembly--last held 7 October 1989 (next to be
held October 1994); results--percent of vote by party NA;
seats--(38 total, 34 elected) BDP 35, BNF 3
_#_Communists: no known Communist organization; Kenneth Koma of BNF
has long history of Communist contacts
_#_Member of: ACP, AfDB, C, CCC, ECA, FAO, FLS, G-77, GATT, IBRD,
ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, INTERPOL, IOC, ITU,
LORCS, NAM, OAU, SACU, SADCC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO,
WMO
_#_Diplomatic representation: Ambassador Botsweletse Kingsley
SEBELE; Chancery at Suite 404, 4301 Connecticut Avenue NW, Washington
DC 20008; telephone (202) 244-4990 or 4991;
US--Ambassador David PASSAGE; Embassy at Botswana Road, Gaborone
(mailing address is P. O. Box 90, Gaborone); telephone [267] 353-982
through 353-984
_#_Flag: light blue with a horizontal white-edged black stripe
in the center
_#_Long-form name: none
_#_Type: territory of Norway','5fe5b3d922cffc4cac1b7eb626fb1face8ffd23f48d5cb931d1617ce07c7fb80','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2719e84727a3f77f4998de8f2de872f88553a4f8cffbde631332db2e74134b2',1991,'AQ','Antarctica','government',27,'_#_Long-form name: Federative Republic of Brazil
_#_Type: federal republic
_#_Capital: Brasilia
_#_Administrative divisions: 26 states (estados, singular--estado)
and 1 federal district* (distrito federal); Acre, Alagoas, Amapa,
Amazonas, Bahia, Ceara, Distrito Federal*, Espirito Santo, Goias,
Maranhao, Mato Grosso, Mato Grosso do Sul, Minas Gerais, Para,
Paraiba, Parana, Pernambuco, Piaui, Rio de Janeiro, Rio Grande do
Norte, Rio Grande do Sul, Rondonia, Roraima, Santa Catarina, Sao
Paulo, Sergipe, Tocantins; note--the former territories of Amapa and
Roraima became states in January 1991
_#_Independence: 7 September 1822 (from Portugal)
_#_Constitution: 5 October 1988
_#_Legal system: based on Latin codes; has not accepted compulsory ICJ
jurisdiction
_#_National holiday: Independence Day, 7 September (1822)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: bicameral National Congress (Congresso
Nacional) consists of an upper chamber or Federal Senate (Senado
Federal) and a lower chamber or Chamber of Deputies (Camara dos
Deputados)
_#_Judicial branch: Supreme Federal Tribunal
_#_Leaders:
Chief of State and Head of Government--President Fernando
Affonso COLLOR de Mello (since 15 March 1990); Vice President
Itamar FRANCO (since 15 March 1990)
_#_Political parties and leaders:
National Reconstruction Party (PRN), Daniel TOURINHO, president;
Brazilian Democratic Movement Party (PMDB), Orestes QUERCIA,
president;
Liberal Front Party (PFL), Hugo NAPOLEAO, president;
Workers'' Party (PT), Luis Ignacio (Lula) da SILVA, president;
Brazilian Labor Party (PTB), Luiz GONZAGA de Paiva Muniz, president;
Democratic Labor Party (PDT), Leonel BRIZOLA, president;
Democratic Social Party (PDS), Amaral NETTO, president;
Brazilian Social Democracy Party (PSDB), Mario COVAS, president;
Brazilian Communist Party (PCB), Salomao MALINA, secretary general;
Communist Party of Brazil (PCdoB), Joao AMAZONAS, president;
Christian Democratic Party (PDC), Eduardo CAMPOS, president
_#_Suffrage: voluntary at age 16; compulsory between ages 18 and 70;
voluntary at age 70
_#_Elections:
President--last held 15 November 1989, with runoff on 17
December 1989 (next to be held November 1994);
results--Fernando COLLOR de Mello 53%, Luis Inacio da SILVA 47%;
note--first free, direct presidential election since 1960;
Senate--last held 3 October 1990 (next to be held November 1994);
results--percent of vote by party NA;
seats--(81 total as of 3 February 1991) PMDB 27, PFL 15, PSDB 10,
PTB 8, PDT 5, other 16;
Chamber of Deputies--last held 3 October 1990 (next to be held
November 1994);
results--PMDB 21%, PFL 17%, PDT 9%, PDS 8%, PRN 7.9%, PTB 7%, PT 7%,
other 23.1%;
seats--(503 total as of 3 February 1991) PMDB 108, PFL 87,
PDT 46, PDS 43, PRN 40, PTB 35, PT 35, other 109;
_#_Communists: about 30,000
_#_Other political or pressure groups: left wing of the Catholic
Church and labor unions allied to leftist Worker''s Party are critical of
government''s social and economic policies
_#_Member of: AfDB, AG (observer), CCC, ECLAC, FAO, G-11, G-19,
G-24, G-77, GATT, IADB, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IFAD, IFC,
ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC, IOM (observer), ISO,
ITU, LAES, LAIA, LORCS, NAM (observer), OAS, OPANAL, PCA, RG, UN, UNAVEM,
UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Marcilio Marques MOREIRA;
Chancery at 3006 Massachusetts Avenue NW, Washington DC 20008; telephone
(202) 745-2700; there are Brazilian Consulates General in Atlanta,
Chicago, Los Angeles, Miami, New Orleans, and New York, and Consulates in
Dallas, Houston, and San Francisco;
US--Ambassador Richard MELTON; Embassy at Avenida das Nocoes,
Lote 3, Brasilia, Distrito Federal (mailing address is APO Miami 34030);
telephone [55] (6) 321-7272; there are US Consulates General in Rio de
Janeiro and Sao Paulo, and Consulates in Porto Alegre and Recife
_#_Flag: green with a large yellow diamond in the center bearing a
blue celestial globe with 23 white five-pointed stars (one for each
state) arranged in the same pattern as the night sky over Brazil; the
globe has a white equatorial band with the motto ORDEM E PROGRESSO
(Order and Progress)
_#_Long-form name: British Indian Ocean Territory (no short-form
name); abbreviated BIOT
_#_Type: dependent territory of the UK
_#_Capital: none
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952);
Head of Government--Commissioner and Administrator R. EDIS
(since NA 1988); note--resides in the UK
_#_Diplomatic representation: none (dependent territory
of the UK)
_#_Flag: white with the flag of the UK in the upper hoist-side
quadrant and six blue wavy horizontal stripes bearing a palm tree and
yellow crown centered on the outer half of the flag
_#_Long-form name: none
_#_Type: dependent territory of the UK
_#_Capital: Road Town
_#_Administrative divisions: none (dependent territory of the UK)
_#_Independence: none (dependent territory of the UK)
_#_Constitution: 1 June 1977
_#_Legal system: English law
_#_National holiday: Territory Day, 1 July
_#_Executive branch: British monarch, governor, chief minister,
Executive Council (cabinet)
_#_Legislative branch: unicameral Legislative Council
_#_Judicial branch: Eastern Caribbean Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor John Mark Ambrose HERDMAN (since NA 1986);
Head of Government--Chief Minister H. Lavity STOUTT (since NA 1986)
_#_Political parties and leaders:
United Party (UP), Conrad MADURO;
Virgin Islands Party (VIP), H. Lavity STOUTT;
Independent People''s Movement (IPM), Cyril B. ROMNEY
_#_Suffrage: universal at age 18
_#_Elections:
Legislative Council--last held 12 November 1990 (next to be
held by November 1995); results--percent of vote by party NA;
seats--(9 total) VIP 6, IPM 1, independent 2
_#_Communists: probably none
_#_Member of: CARICOM (observer), CDB, ECLAC (associate), IOC,
OECS (associate), UNESCO (associate)
_#_Diplomatic representation: none (dependent territory of the UK)
_#_Flag: blue with the flag of the UK in the upper hoist-side quadrant
and the Virgin Islander coat of arms centered in the outer half of the
flag; the coat of arms depicts a woman flanked on either side by a
vertical column of six oil lamps above a scroll bearing the Latin word
VIGILATE (Be Watchful)
_#_Long-form name: Negara Brunei Darussalam
_#_Type: constitutional sultanate
_#_Capital: Bandar Seri Begawan
_#_Administrative divisions: 4 districts (daerah-daerah,
singular--daerah); Belait, Brunei and Muara, Temburong, Tutong
_#_Independence: 1 January 1984 (from UK)
_#_Constitution: 29 September 1959 (some provisions suspended
under a State of Emergency since December 1962, others since
independence on 1 January 1984)
_#_Legal system: based on Islamic law
_#_National holiday: National Day, 23 February (1984)
_#_Executive branch: sultan, prime minister, Council of Cabinet
Ministers
_#_Legislative branch: unicameral Legislative Council
(Majlis Masyuarat Megeri)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--Sultan and Prime Minister
Sir Muda HASSANAL BOLKIAH Muizzaddin Waddaulah (since 5 October 1967)
_#_Political parties and leaders:
Brunei United National Party (inactive), Anak HASANUDDIN, chairman;
Brunei National Democratic Party (the first legal political party and now
banned), leader NA
_#_Suffrage: none
_#_Elections:
Legislative Council--last held in March 1962; in 1970
the Council was changed to an appointive body by decree of the sultan
and no elections are planned
_#_Communists: probably none
_#_Member of: APEC, ASEAN, C, ESCAP, ICAO, IDB, IMO, INTERPOL, IOC,
ISO (correspondent), ITU, OIC, UN, UNCTAD, UPU, WHO, WMO
_#_Diplomatic representation: Ambassador Dato Paduka Haji Mohamed SUNI
bin Haji Idris; Chancery at 2600 Virginia Avenue NW, Washington DC 20037;
telephone (202) 342-0159;
US--Ambassador Christopher H. PHILLIPS; Embassy at Third Floor,
Teck Guan Plaza, Jalan Sultan, Bandar Seri Begawan (mailing address
is P. O. Box 2991, Bandar Seri Begawan and Box B, APO San Francisco,
96528); telephone [673] (2) 229-670
_#_Flag: yellow with two diagonal bands of white (top, almost double
width) and black starting from the upper hoist side; the national emblem
in red is superimposed at the center; the emblem includes a
swallow-tailed flag on top of a winged column within an upturned crescent
above a scroll and flanked by two upraised hands
_#_Long-form name: Republic of Bulgaria
_#_Type: emerging democracy, continuing significant Communist party
influence
_#_Capital: Sofia
_#_Administrative divisions: 9 provinces (oblasti, singular--oblast);
Burgas, Grad Sofiya, Khaskovo, Lovech, Mikhaylovgrad, Plovdiv, Razgrad,
Sofiya, Varna
_#_Independence: 22 September 1908 (from Ottoman Empire)
_#_Constitution: 16 May 1971, effective 18 May 1971; a new
constitution is likely to be adopted in 1991
_#_Legal system: based on civil law system, with Soviet law influence;
judicial review of legislative acts in the State Council; has accepted
compulsory ICJ jurisdiction
_#_National holiday: Liberation of Bulgaria from the Ottoman Empire,
3 March (1878)
_#_Executive branch: president, chairman of the Council of Ministers
(premier), three deputy chairmen of the Council of Ministers,
Council of Ministers
_#_Legislative branch: unicameral National Assembly (Narodno
Sobranie)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Zhelyu ZHELEV (since 1 August 1990);
Head of Government--Chairman of the Council of Ministers
(Premier) Dimitur POPOV (since 19 December 1990);
Deputy Chairman of the Council of Ministers Aleksandur TOMOV
(since 19 December 1990);
Deputy Chairman of the Council of Ministers Viktor VULKOV (since
19 December 1990);
Deputy Chairman of the Council of Ministers Dimitur LUDZHEV
(since 19 December 1990);
_#_Political parties and leaders: government--Bulgarian
Socialist Party (BSP), formerly Bulgarian Communist Party (BCP),
Aleksandur LILOV, chairman;
opposition--Union of Democratic Forces (UDF), Filip DIMITROV,
chairman, consisting of Nikola Petkov Bulgarian Agrarian National
Union, Milan DRENCHEV, secretary of Permanent Board;
Bulgarian Social Democratic Party, Petur DERTLIEV;
Green Party;
Christian Democrats;
Radical Democratic Party;
Rights and Freedoms Movement (pro-Muslim party), Ahmed DOGAN;
Bulgarian Agrarian National Union (BZNS), Viktor VULKOV
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
Chairman of the State Council--last held 1 August 1990
(next to be held May 1991);
results--Zhelyo ZHELEV was elected by the National Assembly;
National Assembly--last held 10 and 17 June 1990 (next to be held
in autumn 1991);
results--BSP 48%, UDF 32%;
seats--(400 total) BSP 211, UDF 144, Rights and Freedoms Movement
23, Agrarian Party 16, Nationalist parties 3, independents and other 3
_#_Communists: Bulgarian Socialist Party (BSP), formerly
Bulgarian Communist Party (BCP), 501,793 members
_#_Other political or pressure groups: Ecoglasnost; Podkrepa
(Support) Labor Confederation; Fatherland Union; Bulgarian
Democratic Youth (formerly Communist Youth Union); Confederation
of Independent Trade Unions of Bulgaria (KNSB);
Committee for Defense of National Interests;
Peasant Youth League; National Coalition of Extraparliamentary
Political Forces;
numerous regional, ethnic, and national interest groups with various
agendas
_#_Member of: BIS, CCC, CSCE, ECE, FAO, G-9, IAEA, IBEC,
ICAO, IIB, ILO, IMO, INMARSAT, IOC, ISO, ITU, LORCS, PCA, UN, UNCTAD,
UNESCO, UNIDO, UPU, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Ognyan PISHEV;
Chancery at 1621 22nd Street NW, Washington DC 20008; telephone (202)
387-7969;
US--Ambassador H. Kenneth HILL; Embassy at 1 Alexander Stamboliski
Boulevard, Sofia (mailing address is APO New York 09213-5740);
telephone [359] (2) 88-48-01 through 05
_#_Flag: three equal horizontal bands of white (top), green, and red;
the national emblem formerly on the hoist side of the white stripe has
been removed--it contained a rampant lion within a wreath of wheat ears
below a red five-pointed star and above a ribbon bearing the dates 681
(first Bulgarian state established) and 1944 (liberation from Nazi
control)
_#_Long-form name: Burkina Faso
_#_Type: military; established by coup on 4 August 1983
_#_Capital: Ouagadougou
_#_Administrative divisions: 30 provinces; Bam, Bazega, Bougouriba,
Boulgou, Boulkiemde, Ganzourgou, Gnagna, Gourma, Houet, Kadiogo,
Kenedougou, Komoe, Kossi, Kouritenga, Mouhoun, Namentenga, Naouri,
Oubritenga, Oudalan, Passore, Poni, Sanguie, Sanmatenga, Seno,
Sissili, Soum, Sourou, Tapoa, Yatenga, Zoundweogo
_#_Independence: 5 August 1960 (from France; formerly Upper Volta)
_#_Constitution: none; constitution of 27 November 1977 was abolished
following coup of 25 November 1980; constitutional referendum scheduled
for June 1991
_#_Legal system: based on French civil law system and customary law
_#_National holiday: Anniversary of the Revolution, 4 August (1983)
_#_Executive branch: chairman of the Popular Front, Council of
Ministers
_#_Legislative branch: unicameral National Assembly (Assemblee
Nationale) was dissolved on 25 November 1980
_#_Judicial branch: Appeals Court
_#_Leaders:
Chief of State and Head of Government--Chairman of the
Popular Front Captain Blaise COMPAORE (since 15 October 1987)
_#_Political parties and leaders: all political parties banned
following November 1980 coup
_#_Suffrage: none
_#_Elections: the National Assembly was dissolved 25 November 1980;
presidential elections are scheduled for 3 November 1991 and legislative
elections for 8 December 1991
_#_Communists: small Communist party front group; some sympathizers
_#_Other political or pressure groups: committees for the defense of
the revolution, watchdog/political action groups throughout the country
in both organizations and communities
_#_Member of: ACCT, ACP, AfDB, CCC, CEAO, ECA, ECOWAS, Entente, FAO,
FZ, G-77, GATT, IBRD, ICAO, ICC, ICFTU, IDA, IDB, IFAD, IFC, ILO, IMF,
INTELSAT, INTERPOL, IOC, ITU, LORCS, NAM, OAU, OIC, PCA, UN, UNCTAD,
UNESCO, UNIDO, UPU, WADB, WCL, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Paul Desire KABORE;
Chancery at 2340 Massachusetts Avenue NW, Washington DC 20008;
telephone (202) 332-5577 or 6895;
US--Ambassador Edward P. BRYNN; Embassy at Avenue Raoul Follerau,
Ouagadougou (mailing address is 01 B. P. 35, Ouagadougou);
telephone [226] 30-67-23 through 25 and [226] 33-34-22
_#_Flag: two equal horizontal bands of red (top) and green with a
yellow five-pointed star in the center; uses the popular pan-African
colors of Ethiopia
_#_Long-form name: Union of Burma; note--the local official name is
Pyidaungzu Myanma Naingngandaw which has been translated by the US
Government as Union of Myanma and by the Burmese as Union of Myanmar
_#_Type: military regime
_#_Capital: Rangoon (sometimes translated as Yangon)
_#_Administrative divisions: 7 divisions* (yin-mya, singular--yin) and
7 states (pyine-mya, singular--pyine); Chin State, Irrawaddy*, Kachin
State, Karan State, Kayah State, Magwe*, Mandalay*, Mon State, Pegu*,
Rakhine State, Rangoon*, Sagaing*, Shan State, Tenasserim*
_#_Independence: 4 January 1948 (from UK)
_#_Constitution: 3 January 1974 (suspended since 18 September 1988)
_#_Legal system: martial law in effect throughout most of the
country; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 4 January (1948)
_#_Executive branch: chairman of the State Law and Order Restoration
Council, State Law and Order Restoration Council
_#_Legislative branch: unicameral People''s Assembly (Pyithu Hluttaw)
was dissolved after the coup of 18 September 1988
_#_Judicial branch: Council of People''s Justices was abolished after
the coup of 18 September 1988
_#_Leaders:
Chief of State and Head of Government--Chairman of the State Law
and Order Restoration Council Gen. SAW MAUNG (since 18 September 1988)
_#_Political parties and leaders:
National Unity Party (NUP; proregime), THA KYAW;
National League for Democracy (NLD), U TIN OO and AUNG SAN SUU KYI;
League for Democracy and Peace, U NU
_#_Suffrage: universal at age 18
_#_Elections:
People''s Assembly--last held 27 May 1990, but Assembly never
convened;
results--NLD 80%;
seats--(485 total) NLD 396, the regime-favored NUP 10, other 79
_#_Communists: several hundred (est.) in Burma Communist Party (BCP)
_#_Other political or pressure groups: Kachin Independence Army (KIA),
United Wa State Army (UWSA), Karen National Union (KNU), several Shan
factions, including the Shan United Army (SUA) (all ethnically-based
insurgent groups)
_#_Member of: AsDB, CP, ESCAP, FAO, G-77, GATT, IAEA, IBRD, ICAO, IDA,
IFAD, IFC, ILO, IMF, IMO, INTERPOL, IOC, ITU, LORCS, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WMO
_#_Diplomatic representation: Ambassador U MYO AUNG; Chancery at
2300 S Street NW, Washington DC 20008; telephone (202) 332-9044 through
9046; there is a Burmese Consulate General in New York;
US--Ambassador (vacant); Deputy Chief of Mission Franklin P.
HUDDLE, Jr.; Embassy at 581 Merchant Street, Rangoon (mailing address
is G. P. O. Box 521, Rangoon or Box B, APO San Francisco 96346);
telephone 82055 or 82181
_#_Flag: red with a blue rectangle in the upper hoist-side corner
bearing, all in white, 14 five-pointed stars encircling a cogwheel
containing a stalk of rice; the 14 stars represent the 14 administrative
divisions
_#_Long-form name: Republic of Burundi
_#_Type: republic
_#_Capital: Bujumbura
_#_Administrative divisions: 15 provinces; Bubanza, Bujumbura, Bururi,
Cankuzo, Cibitoke, Gitega, Karuzi, Kayanza, Kirundo, Makamba, Muramvya,
Muyinga, Ngozi, Rutana, Ruyigi
_#_Independence: 1 July 1962 (from UN trusteeship under Belgian
administration)
_#_Constitution: 20 November 1981; suspended following the coup of
3 September 1987; referendum for a new constitution scheduled for
March 1992
_#_Legal system: based on German and Belgian civil codes and
customary law; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 1 July (1962)
_#_Executive branch: president; chairman of the Central Committee
of the National Party of Unity and Progress (UPRONA), prime minister
_#_Legislative branch: unicameral National Assembly (Assemblee
Nationale) was dissolved following the coup of 3 September 1987;
at an extraordinary party congress held from 27 to 29 December 1990,
the Central Committee of the National Party of Unity and Progress
(UPRONA) replaced the Military Committee for National Salvation, and
became the supreme governing body during the transition to constitutional
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State--President Pierre BUYOYA (since 9 September 1987);
Head of Government Prime Minister Adrien SIBOMANA (since 26
October 1988)
_#_Political parties and leaders: only party--National Party of
Unity and Progress (UPRONA), President Pierre BUYOYA, chairman, and
Nicolas MAYUGI, secretary general
_#_Suffrage: universal adult at age NA
_#_Elections:
National Assembly--dissolved after the coup of 3 September
1987;
note--The National Unity Charter outlining the principles for
constitutional government was adopted by a national referendum on 5
February 1991
_#_Communists: no Communist party
_#_Member of: ACCT, ACP, AfDB, CCC, CEEAC, CEPGL, ECA, FAO, G-77,
GATT, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, INTERPOL, ITU,
LORCS, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Julien KAVAKURE; Chancery at
Suite 212, 2233 Wisconsin Avenue NW, Washington DC 20007;
telephone (202) 342-2574;
US--Ambassador Cynthia Shepherd PERRY; Embassy at Avenue du Zaire,
Bujumbura (mailing address is B. P. 1720, Avenue des Etats-Unis,
Bujumbura); telephone 234-54 through 56
_#_Flag: divided by a white diagonal cross into red panels (top and
bottom) and green panels (hoist side and outer side) with a white disk
superimposed at the center bearing three red six-pointed stars outlined
in green arranged in a triangular design (one star above, two stars
below)
_#_Long-form name: none
_#_Type: disputed between the National Government of Cambodia (NGC)
led by Prince NORODOM SIHANOUK, and the State of Cambodia (SOC) led by
HENG SAMRIN
_#_Capital: Phnom Penh
_#_Administrative divisions: NGC--18 provinces (khet, singular and
plural) and 1 capital city* (rottatheanei);
Batdambang, Kampong Cham, Kampong Chhnang,
Kampong Spoe, Kampong Thum, Kampot, Kandal, Kaoh Kong,
Kracheh, Mondol Kiri, Phnum Penh*, Pouthisat, Preah
Vihear, Prey Veng, Rotanokiri, Siemreab-Otdar
Meanchey, Stoeng Treng, Svay Rieng, Takev; note--the SOC adds
a province of Banteay Meanchey and an autonomous municipality of
Kampong Saom to the NGC administrative structure
_#_Independence: 9 November 1953 (from France)
_#_Constitution: SOC--27 June 1981
_#_National holidays: NGC--Independence Day, 17 April (1975);
SOC--Liberation Day, 7 January (1979)
_#_Executive branch: NGC--president, prime minister; SOC--chairman
of the Council of State, Council of State, chairman of the Council of
Ministers, Council of Ministers
_#_Legislative branch: NGC--none; SOC--unicameral National Assembly
_#_Judicial branch: NGC--none; SOC--Supreme People''s Court
_#_Leaders:
Chief of State--NGC--President Prince NORODOM SIHANOUK
(since NA July 1982); SOC--Chairman of the Council of State HENG
SAMRIN (since 27 June 1981)
Head of Government--NGC--Prime Minister SON SANN (since NA July
1982);
SOC--Chairman of the Council of Ministers HUN SEN (since 14 January 1985)
_#_Political parties and leaders: NGC--three resistance groups
including:
Democratic Kampuchea (DK, also known as the Khmer Rouge) under KHIEU
SAMPHAN;
Khmer People''s National Liberation Front (KPNLF) under SON SANN;
and National United Front for an Independent, Neutral, Peaceful, and
Cooperative Cambodia (FUNCINPEC) under Prince NORODOM RANNARIDH;
SOC--Kampuchean People''s Revolutionary Party (KPRP) led by HENG SAMRIN
_#_Suffrage: NGC--none; SOC--universal at age 18
_#_Elections:
NGC--none;
SOC--National Assembly--last held 1 May 1981; in February 1986 the
Assembly voted to extend its term for five years; results--KPRP is the
only party;
seats--(123 total) KPRP 123
_#_Member of: AsDB, CP, ESCAP, FAO, G-77, IAEA, IBRD, ICAO, IDA,
ILO, IMF, IMO, INTERPOL, ITU, LORCS, NAM, PCA, UN, UNCTAD, UNESCO, UPU,
WFTU, WHO, WMO, WTO
_#_Diplomatic representation: none
_#_Flag:
NGC--three horizontal bands of blue (top), red (double width), and blue
with a white stylized three-towered temple representing Angkor Wat
centered on the red band;
SOC--two equal horizontal bands of red (top) and blue with a gold
stylized five-towered temple representing Angkor Wat in the center
_#_Long-form name: Republic of Cameroon
_#_Type: unitary republic; multiparty presidential regime (opposition
parties legalized 1990)
_#_Capital: Yaounde
_#_Administrative divisions: 10 provinces; Adamaoua, Centre, Est,
Extreme-Nord, Littoral, Nord, Nord-Ouest, Ouest, Sud, Sud-Ouest
_#_Independence: 1 January 1960 (from UN trusteeship under
French administration; formerly French Cameroon)
_#_Constitution: 20 May 1972
_#_Legal system: based on French civil law system, with common law
influence; has not accepted compulsory ICJ jurisdiction
_#_National holiday: National Day, 20 May (1972)
_#_Executive branch: president, Cabinet
_#_Legislative branch: unicameral National Assembly (Assemblee
Nationale)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State President Paul BIYA (since 6 November 1982);
Head of Government interim Prime Minister Sadou HAYATOU (since
25 April 1991)
_#_Political parties and leaders: Cameroon People''s Democratic
Movement (RDPC), Paul BIYA, president, is government-controlled and was
formerly the only party; 17 parties formed by 1 May 1991
_#_Suffrage: universal at age 21
_#_Elections:
President--last held 24 April 1988 (next to be','c73d3f9feaa26ab757c6abf0f560ad0fea6f1b51e80b3b9af85b561c619785be','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d90ea5470bcdd48278097bf5644a78e809bb2461740931003d1e77a1c3a4ffd7',1991,'AQ','Antarctica','government',28,'held April 1993);
results--President Paul BIYA reelected without opposition;
National Assembly--last held 24 April 1988 (next to be
held by the end of 1992);
results--RDPC was the only party;
seats--(180 total) RDPC 180
_#_Communists: no Communist party or significant number of
sympathizers
_#_Other political or pressure groups: NA
_#_Member of: ACCT (associate), ACP, AfDB, BDEAC, CCC, CEEAC, ECA,
FAO, FZ, G-19, G-77, GATT, IAEA, IBRD, ICAO, ICC, IDA, IDB, IFAD, IFC,
ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, ITU, LORCS, NAM, OAU, OIC, PCA,
UDEAC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Paul PONDI; Chancery at
2349 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
265-8790 through 8794;
US--Ambassador Frances D. COOK; Embassy at Rue Nachtigal, Yaounde
(mailing address is B. P. 817, Yaounde); telephone [237] 234014; there is
a US Consulate General in Douala
_#_Flag: three equal vertical bands of green (hoist side), red, and
yellow with a yellow five-pointed star centered in the red band; uses the
popular pan-African colors of Ethiopia
_#_Long-form name: none
_#_Type: confederation with parliamentary democracy
_#_Capital: Ottawa
_#_Administrative divisions: 10 provinces and 2 territories*; Alberta,
British Columbia, Manitoba, New Brunswick, Newfoundland,
Northwest Territories*, Nova Scotia, Ontario, Prince Edward Island,
Quebec, Saskatchewan, Yukon Territory*
_#_Independence: 1 July 1867 (from UK)
_#_Constitution: amended British North America Act 1867 patriated to
Canada 17 April 1982; charter of rights and unwritten customs
_#_Legal system: based on English common law, except in Quebec, where
civil law system based on French law prevails; accepts compulsory ICJ
jurisdiction, with reservations
_#_National holiday: Canada Day, 1 July (1867)
_#_Executive branch: British monarch, governor general, prime
minister, deputy prime minister, Cabinet
_#_Legislative branch: bicameral Parliament (Parlement) consists of an
upper house or Senate (Senat) and a lower house or House of Commons
(Chambre des Communes)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor General Raymond John HNATSHYN (since 29 January
1990);
Head of Government--Prime Minister (Martin) Brian MULRONEY (since
4 September 1984); Deputy Prime Minister Donald Frank MAZANKOWSKI (since
NA June 1986)
_#_Political parties and leaders:
Progressive Conservative, Brian MULRONEY;
Liberal, Jean CHRETIEN;
New Democratic, Audrey McLAUGHLIN
_#_Suffrage: universal at age 18
_#_Elections:
House of Commons--last held 21 November 1988 (next to be
held by November 1993);
results--Progressive Conservative 43.0%, Liberal 32%,
New Democratic Party 20%, other 5%;
seats--(295 total) Progressive Conservative 159, Liberal 80, New
Democratic Party 44, independent 12
_#_Communists: 3,000
_#_Member of: ACCT, AfDB, AG (observer), APEC, AsDB,
BIS, C, CCC, CDB, COCOM, CP, CSCE, EBRD, ECE, ECLAC, FAO, G-7, G-8, G-10,
GATT, IADB, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IEA, IFAD, IFC, ILO, IMF,
IMO, INMARSAT, INTELSAT, INTERPOL, IOC, IOM (observer), ISO, ITU,
LORCS, NATO, NEA, OAS, OECD, PCA, UN, UNCTAD, UNDOF, UNESCO, UNFICYP,
UNHCR, UNIDO, UNIIMOG, UNTSO, UPU, WCL, WHO, WIPO, WMO,
WTO
_#_Diplomatic representation: Ambassador Derek BURNEY; Chancery at
1746 Massachusetts Avenue NW, Washington DC 20036; telephone (202)
785-1400; there are Canadian Consulates General in Atlanta, Boston,
Buffalo, Chicago, Cleveland, Dallas, Detroit, Los Angeles, Minneapolis,
New York, Philadelphia, San Francisco, and Seattle;
US--Ambassador Edward N. NEY; Embassy at 100 Wellington Street,
K1P 5T1, Ottawa (mailing address is P. O. Box 5000, Ogdensburg, NY
13669-0430); telephone (613) 248-25256, 25106, 25271, and 25170; there
are US Consulates General in Calgary, Halifax, Montreal, Quebec, Toronto,
and Vancouver
_#_Flag: three vertical bands of red (hoist side), white (double
width, square), and red with a red maple leaf centered in the white band
_#_Long-form name: Republic of Cape Verde
_#_Type: republic
_#_Capital: Praia
_#_Administrative divisions: 14 districts (concelhos,
singular--concelho); Boa Vista, Brava, Fogo, Maio, Paul, Praia, Porto
Novo, Ribeira Grande, Sal, Santa Catarina, Santa Cruz, Sao Nicolau,
Sao Vicente, Tarrafal
_#_Independence: 5 July 1975 (from Portugal)
_#_Constitution: 7 September 1980; amended 12 February 1981,
NA December 1988, and 28 September 1990 (legalized opposition parties)
_#_National holiday: Independence Day, 5 July (1975)
_#_Executive branch: president, prime minister, deputy minister,
secretaries of state, Council of Ministers (cabinet)
_#_Legislative branch: unicameral People''s National Assembly
(Assembleia Nacional Popular)
_#_Judicial branch: Supreme Tribunal of Justice (Supremo Tribunal de
Justia)
_#_Leaders:
Chief of State--President Antonio Mascarenhas MONTEIRO (since
22 March 1991);
Head of Government--Prime Minister Carlos VEIGA (since
13 January 1991)
_#_Political parties and leaders:
Movement for Democracy (MPD), Prime Minister Carlos VEIGA, founder and
chairman;
African Party for Independence of Cape Verde (PAICV), Pedro
Verona Rodrigues PIRES, chairman
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 17 February 1991 (next to be held
February 1996);
results--Antonio Mascarenhas MONTEIRO (MPD) received 72.6% of vote;
People''s National Assembly--last held 13 January 1991 (next
to be held January 1996);
results--percent of vote by party NA;
seats--(79 total) MPD 56, PAICV 23; note--this multiparty Assembly
election ended 15 years of single-party rule
_#_Communists: no Communist party
_#_Member of: ACP, AfDB, ECA, ECOWAS, FAO, G-77, IBRD, ICAO, IDA,
IFAD, ILO, IMF, IMO, INTERPOL, IOM (observer), ITU, LORCS,
NAM, OAU, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WMO
_#_Diplomatic representation: Ambassador Luis de Matos Monteiro da
FONSECA; Chancery at 3415 Massachusetts Avenue NW, Washington DC 20007;
telephone (202) 965-6820; there is a Cape Verdean Consulate General in
Boston;
US--Ambassador Francis T. (Terry) McNAMARA; Embassy at Rua Hojl Ya
Yenna 81, Praia (mailing address is C. P. 201, Praia); telephone
[238] 614-363 or 614-253
_#_Flag: two equal horizontal bands of yellow (top) and green with
a vertical red band on the hoist side; in the upper portion of the red
band is a black five-pointed star framed by two corn stalks and a
yellow clam shell; uses the popular pan-African colors of Ethiopia;
similar to the flag of Guinea-Bissau which is longer and has an
unadorned black star centered in the red band
_#_Long-form name: none
_#_Type: dependent territory of the UK
_#_Capital: George Town
_#_Administrative divisions: 8 districts; Creek, Eastern, Midland,
South Town, Spot Bay, Stake Bay, West End, Western
_#_Independence: none (dependent territory of the UK)
_#_Legal system: British common law and local statutes
_#_Constitution: 1959, revised 1972
_#_National holiday: Constitution Day (first Monday in July), 1 July
1991
_#_Executive branch: British monarch, governor, Executive Council
(cabinet)
_#_Legislative branch: unicameral Legislative Assembly
_#_Judicial branch: Grand Court, Cayman Islands Court of Appeal
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor Alan James SCOTT (since NA 1987);
Head of Government--Governor and President of the Executive Council
Alan James SCOTT (since NA 1987)
_#_Political parties and leaders: no formal political parties
_#_Suffrage: universal at age 18
_#_Elections:
Legislative Assembly--last held NA November 1988 (next to be held
November 1992); results--percent of vote NA;
seats--(15 total, 12 elected)
_#_Communists: none
_#_Member of: CDB, IOC
_#_Diplomatic representation: as a dependent territory of the UK,
Caymanian interests in the US are represented by the UK;
US--none
_#_Flag: blue with the flag of the UK in the upper hoist-side quadrant
and the Caymanian coat of arms on a white disk centered on the outer half
of the flag; the coat of arms includes a pineapple and turtle above a
shield with three stars (representing the three islands) and a scroll at
the bottom bearing the motto HE HATH FOUNDED IT UPON THE SEAS
_#_Long-form name: Central African Republic (no short-form name);
abbreviated CAR
_#_Type: republic, one-party presidential regime since 1986
_#_Capital: Bangui
_#_Administrative divisions: 14 prefectures (prefectures,
singular--prefecture) and 2 economic prefectures* (prefectures
economiques, singular--prefecture economique); Bamingui-Bangoran,
Basse-Kotto, Gribingui*, Haute-Kotto, Haute-Sangha, Haut-Mbomou,
Kemo-Gribingui, Lobaye, Mbomou, Nana-Mambere, Ombella-Mpoko, Ouaka,
Ouham, Ouham-Pende, Sangha*, Vakaga; note--there may be a new
autonomous commune of Bangui
_#_Independence: 13 August 1960 (from France; formerly Central African
Empire)
_#_Constitution: 21 November 1986
_#_Legal system: based on French law
_#_National holiday: National Day (proclamation of the republic),
1 December (1958)
_#_Executive branch: president, Council of Ministers (cabinet)
_#_Legislative branch: unicameral National Assembly (Assemblee
Nationale) advised by the Economic and Regional Council (Conseil
Economique et Regional); when they sit together this is known
as the Congress (Congres)
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State and Head of Government--President
Andre-Dieudonne KOLINGBA (since 1 September 1981)
_#_Political parties and leaders: only party--Centrafrican Democrtic
Rally Party (RDC), Andre-Dieudonne KOLINGBA
_#_Suffrage: universal at age 21
_#_Elections:
President--last held 21 November 1986 (next to be held November
1993);
results--President KOLINGBA was reelected without opposition;
National Assembly--last held 31 July 1987 (next to be
held July 1992);
results--RDC is the only party;
seats--(52 total) RDC 52
_#_Communists: small number of Communist sympathizers
_#_Member of: ACCT, ACP, AfDB, BDEAC, CCC, CEEAC, ECA, FAO, FZ,
G-77, GATT, IBRD, ICAO, ICFTU, IDA, IFAD, ILO, IMF, INTELSAT, INTERPOL,
IOC, ITU, LORCS, NAM, OAU, UDEAC, UN, UNCTAD, UNESCO, UNIDO,
UPU, WCL, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Jean-Pierre SOHAHONG-KOMBET;
Chancery at 1618 22nd Street NW, Washington DC 20008; telephone (202)
483-7800 or 7801;
US--Ambassador Daniel H. SIMPSON; Embassy at Avenue du President
David Dacko, Bangui (mailing address is B. P. 924, Bangui);
telephone 61-02-00 or 61-25-78, 61-43-33
_#_Flag: four equal horizontal bands of blue (top), white, green, and
yellow with a vertical red band in center; there is a yellow five-pointed
star on the hoist side of the blue band','ffcdd321f86f564d72c74a7e3277c9b106d0e3d202920ce4f5de7468055ad549','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aeda9e4dba849a3230033a83f140947f9a9c1cdb85f047050572d80deea6cdcf',1991,'NG','Nigeria','government',34,'_#_Long-form name: Republic of Chad
_#_Type: republic
_#_Capital: N''Djamena
_#_Administrative divisions: 14 prefectures (prefectures,
singular--prefecture); Batha, Biltine, Borkou-Ennedi-Tibesti,
Chari-Baguirmi, Guera, Kanem, Lac, Logone Occidental, Logone Oriental,
Mayo-Kebbi, Moyen-Chari, Ouaddai, Salamat, Tandjile
_#_Independence: 11 August 1960 (from France)
_#_Constitution: 22 December 1989, suspended 3 December 1990;
Provisional National Charter 1 March 1991
_#_Legal system: based on French civil law system and Chadian
customary law; has not accepted compulsory ICJ jurisdiction
_#_National holiday: NA
_#_Executive branch: president, Council of State (cabinet)
_#_Legislative branch: the National Consultative Council (Conseil
National Consultatif) was disbanded 3 December 1990 and replaced by
the Provisional Council of the Republic; 30 members appointed by
President DEBY on 8 March 1991
_#_Judicial branch: Court of Appeal
_#_Leaders:
Chief of State--Col. Idriss DEBY (since 4 December 1990);
Head of Government--Prime Minister Jean LINGUE Bawoyeu
(since 8 March 1991)
_#_Political parties and leaders: Patriotic Salvation Movement (MPS;
former dissident group), Idriss DEBY, chairman; President DEBY has
promised political pluralism, a new constitution, and free elections by
September 1993; numerous dissident groups
_#_Suffrage: universal at age NA
_#_Elections:
President--last held 10 December 1989 (next to be held NA);
results--President Hissein HABRE was elected without opposition;
note--the government of then President HABRE fell on 1 December 1990
and Idriss DEBY seized power on 3 December 1990;
National Consultative Council--last held 8 July 1990;
disbanded 3 December 1990
_#_Communists: no front organizations or underground party; probably a
few Communists and some sympathizers
_#_Other political or pressure groups: NA
_#_Member of: ACCT, ACP, AfDB, BDEAC, CEEAC, ECA, FAO, FZ, G-77,
GATT, IBRD, ICAO, ICFTU, IDA, IDB, IFAD, ILO, IMF, INTELSAT, INTERPOL,
IOC, ITU, LORCS, NAM, OAU, OIC, UDEAC, UN, UNCTAD, UNESCO,
UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Mahamat Ali ADOUM; Chancery
at 2002 R Steet NW, Washington DC 20009; telephone (202) 462-4009;
US--Ambassador Richard W. BOGOSIAN; Embassy at Avenue Felix
Eboue, N''Djamena (mailing address is B. P. 413, N''Djamena); telephone
[235] (51) 62-18, 40-09
_#_Flag: three equal vertical bands of blue (hoist side), yellow, and
red; similar to the flag of Romania; also similar to the flag of
Andorra which has a national coat of arms featuring a quartered shield
centered in the yellow band; design was based on the flag of France
_#_Long-form name: Republic of Chile
_#_Type: republic
_#_Capital: Santiago
_#_Administrative divisions: 13 regions (regiones,
singular--region); Aisen del General Carlos Ibanez del Campo,
Antofagasta, Araucania, Atacama, Bio-Bio, Coquimbo, Libertador
General Bernardo O''Higgins, Los Lagos, Magallanes y de la Antartica
Chilena, Maule, Region Metropolitana, Tarapaca, Valparaiso;
note--the US does not recognize claims to Antarctica
_#_Independence: 18 September 1810 (from Spain)
_#_Constitution: 11 September 1980, effective 11 March 1981;
amended 30 July 1989
_#_Legal system: based on Code of 1857 derived from Spanish law and
subsequent codes influenced by French and Austrian law; judicial review
of legislative acts in the Supreme Court; has not accepted compulsory ICJ
jurisdiction
_#_National holiday: Independence Day, 18 September (1810)
_#_Executive branch: president, Cabinet
_#_Legislative branch: bicameral National Congress (Congreso
Nacional) consisting of an upper house or Senate (Senado) and a lower
house or Chamber of Deputies (Camara de Diputados)
_#_Judicial branch: Supreme Court (Corte Suprema)
_#_Leaders:
Chief of State and Head of Government--President Patricio
AYLWIN (since 11 March 1990)
_#_Political parties and leaders:
Concertation of Parties for Democracy now consists mainly of six
parties--Christian Democratic Party (PDC), Andres ZALDIVAR;
Party for Democracy (PPD), Erich SCHNAKE;
Radical Party (PR), Mario ASTORGA;
Democratic Socialist Radical Party (PRSD), Jorge IBANEZ;
Social Democratic Party (PSD), Rene ABELIUK; and
Socialist Party, Jorge ARRATE;
National Renovation (RN), Andres ALLAMAND;
Independent Democratic Union (UDI), Joaquin LAVIN;
Communist Party of Chile (PCCh), Volodia TEITELBOIM;
Movement of Revolutionary Left (MIR) is splintered, no single
leader
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
President--last held 14 December 1989 (next to be held December
1993 or January 1994);
results--Patricio AYLWIN (PDC) 55.2%, Hernan BUCHI 29.4%, other 15.4%;
Senate--last held 14 December 1989 (next to be held December
1993 or January 1994); seats--(46 total, 38 elected)
Concertation of Parties for Democracy 22 (PDC 13, PPD 5, PR 2, PSD 1,
PRSD 1), RN 6, UDI 2, independents 8;
Chamber of Deputies--last held 14 December 1989 (next to be held
December 1993 or January 1994); seats--(120 total)
Concertation of Parties for Democracy 72 (PDC 38, PPD 17, PR 5, other
12), RN 29, UDI 11, right-wing independents 8
_#_Communists: The PCCh is currently in the process of regaining
legal party status and has less than 60,000 members
_#_Other political or pressure groups: revitalized university student
federations at all major universities dominated by opposition political
groups; labor--United Labor Central (CUT) includes trade unionists from
the country''s five-largest labor confederations; Roman Catholic Church
_#_Member of: CCC, ECLAC, FAO, G-11, G-77, GATT, IADB, IAEA, IBRD,
ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL,
IOC, IOM, ISO, ITU, LAES, LAIA, LORCS, OAS, OPANAL, PCA, RG, UN,
UNCTAD, UNESCO, UNIDO, UNMOGIP, UNTSO, UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Patricio SILVA Echenique;
Chancery at 1732 Massachusetts Avenue NW, Washington DC 20036; telephone
(202) 785-1746; there are Chilean Consulates General in Chicago, Houston,
Los Angeles, Miami, New York, and San Francisco;
US--Ambassador Charles A. GILLESPIE, Jr.; Embassy at Codina
Building, 1343 Agustinas, Santiago (mailing address is APO Miami 34033);
telephone [56] (2) 710133 or 710190, 710326, 710375
_#_Flag: two equal horizontal bands of white (top) and red; there is a
blue square the same height as the white band at the hoist-side end of
the white band; the square bears a white five-pointed star in the center;
design was based on the US flag
_#_Long-form name: People''s Republic of China; abbreviated PRC
_#_Type: Communist Party-led state
_#_Capital: Beijing
_#_Administrative divisions: 23 provinces (sheng, singular and
plural), 5 autonomous regions* (zizhiqu, singular and plural), and 3
municipalities** (shi, singular and plural); Anhui, Beijing**, Fujian,
Gansu, Guangdong, Guangxi*, Guizhou, Hainan, Hebei, Heilongjiang, Henan,
Hubei, Hunan, Jiangsu, Jiangxi, Jilin, Liaoning, Nei Mongol*, Ningxia*,
Qinghai, Shaanxi, Shandong, Shanghai**, Shanxi, Sichuan, Tianjin**,
Xinjiang*, Xizang*, Yunnan, Zhejiang; note--China considers Taiwan its
23rd province
_#_Independence: unification under the Qin (Ch''in) Dynasty 221 BC,
Qing (Ch''ing or Manchu) Dynasty replaced by the Republic on 12 February
1912, People''s Republic established 1 October 1949
_#_Constitution: 4 December 1982
_#_Legal system: a complex amalgam of custom and statute, largely
criminal law; rudimentary civil code in effect since 1 January 1987; new
legal codes in effect since 1 January 1980; continuing efforts are being
made to improve civil, administrative, criminal, and commercial law
_#_National holiday: National Day, 1 October (1949)
_#_Executive branch: president, vice president, premier, five vice
premiers, State Council
_#_Legislative branch: unicameral National People''s Congress (Quanguo
Renmin Daibiao Dahui)
_#_Judicial branch: Supreme People''s Court
_#_Leaders:
Chief of State and Head of Government (de facto)--DENG
Xiaoping (since mid-1977);
Chief of State--President YANG Shangkun (since 8 April 1988);
Vice President WANG Zhen (since 8 April 1988);
Head of Government--Premier LI Peng (Acting Premier since
24 November 1987, Premier since 9 April 1988);
Vice Premier YAO Yilin (since 2 July 1979);
Vice Premier TIAN Jiyun (since 20 June 1983);
Vice Premier WU Xueqian (since 12 April 1988);
Vice Premier ZOU Jiahua (since 8 April 1991);
Vice Premier ZHU Rongji (since 8 April 1991)
_#_Political parties and leaders: only party--Chinese Communist Party
(CCP), JIANG Zemin, general secretary of the Central Committee (since
NA June 1989)
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 8 April 1988 (next to be held March 1993);
YANG Shangkun was nominally elected by the Seventh National People''s
Congress;
National People''s Congress--last held NA March 1988 (next to
be held March 1993); results--CCP is the only party but there are
also independents;
seats--(2,976 total) CCP and independents 2,976 (indirectly elected
at county or xian level)
_#_Communists: 49,000,000 party members (1990 est.)
_#_Other political or pressure groups: such meaningful opposition as
exists consists of loose coalitions, usually within the party and
government organization, that vary by issue
_#_Member of: AfDB, AsDB, CCC, ESCAP, FAO, IAEA, IBRD, ICAO,
IDA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC, ISO,
ITU, LORCS, PCA, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UN Security
Council, UN Trusteeship Council, UPU, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador ZHU Qizhen; Chancery at
2300 Connecticut Avenue NW, Washington DC 20008;
telephone (202) 328-2500 through 2502; there are Chinese Consulates
General in Chicago, Houston, Los Angeles, New York, and San Francisco;
US--Ambassador James R. LILLEY; Embassy at Xiu Shui Bei Jie 3,
Beijing (mailing address is 100600, PRC Box 50, Beijing or FPO San
Francisco 96655-0001); telephone [86] (1) 532-3831; there are US
Consulates General in Chengdu, Guangzhou, Shanghai, and Shenyang
_#_Flag: red with a large yellow five-pointed star and four smaller
yellow five-pointed stars (arranged in a vertical arc toward the middle
of the flag) in the upper hoist-side corner
_#_Long-form name: Territory of Christmas Island
_#_Type: territory of Australia
_#_Capital: The Settlement
_#_Administrative divisions: none (territory of Australia)
_#_Independence: none (territory of Australia)
_#_Constitution: Christmas Island Act of 1958
_#_Legal system: under the authority of the governor general of','d2a68de6e1be3a5b122492ec7a4869d87b705db29f283b8348cc701cfbf4d7a1','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('865a44ff9c6998c22f16b4da77b5b31329edda7d0f3914faf7113892b4a99cd1',1991,'AU','Australia','government',37,'_#_National holiday: NA
_#_Executive branch: British monarch, governor general of Australia,
administrator, Advisory Council (cabinet)
_#_Legislative branch: none
_#_Judicial branch: none
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952);
Head of Government--Administrator A. D. TAYLOR (since NA)
_#_Communists: none
_#_Member of: none
_#_Diplomatic representation: none (territory of Australia)
_#_Flag: the flag of Australia is used
_#_Long-form name: none
_#_Type: French possession administered from French Polynesia
by High Commissioner of the Republic Jean MONTPEZAT; note--may have
become a dependency of French Polynesia
_#_Long-form name: Territory of Cocos (Keeling) Islands
_#_Type: territory of Australia
_#_Capital: West Island
_#_Administrative divisions: none (territory of Australia)
_#_Independence: none (territory of Australia)
_#_Constitution: Cocos (Keeling) Islands Act of 1955
_#_Legal system: based upon the laws of Australia and local laws
_#_National holiday: NA
_#_Executive branch: British monarch, governor general of Australia,
administrator, chairman of the Islands Council
_#_Legislative branch: unicameral Islands Council
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952);
Head of Government--Administrator D. LAWRIE (since NA 1989);
Chairman of the Islands Council Parson Bin YAPAT (since NA)
_#_Suffrage: NA
_#_Elections: NA
_#_Member of: none
_#_Diplomatic representation: none (territory of Australia)
_#_Flag: the flag of Australia is used
_#_Long-form name: Republic of Colombia
_#_Type: republic; executive branch dominates government structure
_#_Capital: Bogota
_#_Administrative divisions: 23 departments (departamentos,
singular--departamento), 5 commissariats* (comisarias,
singular--comisaria), and 4 intendancies** (intendencias,
singular--intendencia);
Amazonas*, Antioquia, Arauca**, Atlantico, Bolivar, Boyaca, Caldas,
Caqueta, Casanare**, Cauca, Cesar, Choco, Cordoba, Cundinamarca,
Guainia*, Guaviare*, Huila, La Guajira, Magdalena, Meta, Narino,
Norte de Santander, Putumayo**, Quindio, Risaralda, San Andres y
Providencia**, Santander, Sucre, Tolima, Valle del Cauca, Vaupes*,
Vichada*; note--there may be a new special district (distrito especial)
named Bogota; the Constitution of 5 July 1991 states that the
commissariats and intendancies are to become full departments and a
capital district (distrito capital) of Santa Fe de Bogota is to be
established by 1997
_#_Independence: 20 July 1810 (from Spain)
_#_Constitution: 5 July 1991
_#_Legal system: based on Spanish law; judicial review of legislative
acts in the Supreme Court; accepts compulsory ICJ jurisdiction, with
reservations
_#_National holiday: Independence Day, 20 July (1810)
_#_Executive branch: president, presidential designate, Cabinet
_#_Legislative branch: bicameral Congress (Congreso) consists of a
nationally elected upper chamber or Senate (Senado) and a regionally
elected lower chamber or Chamber of Representatives (Camara de
Representantes)
_#_Judicial branch: Supreme Court of Justice (Corte Suprema de
Justica)
_#_Leaders:
Chief of State and Head of Government--President Cesar
GAVIRIA Trujillo (since 7 August 1990)
_#_Political parties and leaders:
Liberal Party (PL), Cesar GAVIRIA Trujillo, president, and
Alfonso LOPEZ Michelsen, party head;
Social Conservative Party (PCS), Misael PASTRANA Borrero;
National Salvation Movement (MSN), Alvaro GOMEZ Hurtado;
Democratic Alliance (AD) is headed by 19th of April Movement (M-19)
leader Antonio NAVARRO Wolf, coalition of small leftist parties and
dissident liberals and conservatives;
Patriotic Union (UP), is a legal political party formed by
Revolutionary Armed Forces of Colombia (FARC) and Colombian
Communist Party (PCC), Carlos ROMERO
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 27 May 1990 (next to be held May 1994);
results--Cesar GAVIRIA Trujillo (Liberal) 47%, Alvaro GOMEZ Hurtado
(National Salvation Movement) 24%, Antonio NAVARRO Wolff (M-19) 13%,
Rodrigo LLOREDA (Conservative) 12%;
Senate--last held 11 March 1990 (next to be held 27 October
1991);
results--percent of vote by party NA;
seats--(114 total) Liberal 72, Conservative 40, UP 1, vacant 1;
Chamber of Representatives last held 11 March 1990 (next to be
held 27 October 1991); results--percent of vote by party NA;
seats--(199 total) Liberal 122, Conservative 68, UP 3, M-19 1, other 5;
note--on 5 July 1991 the new Constitution dissolved Congress and
replaced it with a multiparty 36-member legislative commission until
a new congress, to be elected on 27 October 1991, takes office on 1
December 1991
_#_Communists: 18,000 members (est.), including Communist Party Youth
Organization (JUCO)
_#_Other political or pressure groups: three insurgent groups are
active in Colombia--Revolutionary Armed Forces of Colombia (FARC),
led by Manuel MARULANDA and Alfonso CANO; National Liberation Army (ELN),
led by Manuel PEREZ; and dissidents of the recently demobilized People''s
Liberation Army (EPL) led by Francisco CARABALLO
_#_Member of: AG, CDB, CG, ECLAC, FAO, G-3, G-11, G-24, G-77, GATT,
IADB, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO,
INMARSAT, INTELSAT, INTERPOL, IOC, IOM, ISO, ITU, LAES, LAIA, LORCS,
NAM, OAS, OPANAL, PCA, RG, UN, UNCTAD, UNESCO, UNHCR, UNIDO,
UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Jaime GARCIA Parra; Chancery
at 2118 Leroy Place NW, Washington DC 20008; telephone (202) 387-8338;
there are Colombian Consulates General in Chicago, Houston, Miami, New
Orleans, New York, San Francisco, and San Juan (Puerto Rico), and
Consulates in Atlanta, Boston, Detroit, Ft. Lauderdale, Los Angeles,
San Diego, and Tampa;
US--Ambassador-designate Morris D. BUSBY; Embassy at Calle 38,
No.8-61, Bogota (mailing address is P. O. Box A. A. 3831, Bogota or
APO Miami 34038); telephone [57] (1) 285-1300 or 1688; there is a US
Consulate in Barranquilla
_#_Flag: three horizontal bands of yellow (top, double-width), blue,
and red; similar to the flag of Ecuador which is longer and bears the
Ecuadorian coat of arms superimposed in the center
_#_Long-form name: Federal Islamic Republic of the Comoros
_#_Type: independent republic
_#_Capital: Moroni
_#_Administrative divisions: 3 islands; Anjouan, Grande Comore,
Moheli; note--there may also be 4 municipalities named Domoni, Fomboni,
Moroni, and Mutsamudu
_#_Independence: 6 July 1975 (from France)
_#_Constitution: 1 October 1978, amended October 1982 and January 1985
_#_Legal system: French and Muslim law in a new consolidated code
_#_National holiday: Independence Day, 6 July (1975)
_#_Executive branch: president, Council of Ministers (cabinet)
_#_Legislative branch: unicameral Federal Assembly (Assemblee
Federale)
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State and Head of Government--President Said
Mohamed DJOHAR (since 11 March 1990)
_#_Political parties:
Comoran Union for Progress (Udzima), Said Mohamed DJOHAR, president;
National Union for Democracy (UNDC), Mohamed TAKI
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 11 March 1990 (next to be held March 1996);
results--Said Mohamed DJOHAR (Udzima) 55%; Mohamed TAKI Abdulkarim
(UNDC) 45%;
Federal Assembly--last held 22 March 1987 (next to be held March
1992);
results--percent of vote by party NA;
seats--(42 total) Udzima 42
_#_Member of: ACCT, ACP, AfDB, ECA, FAO, FZ, G-77, IBRD, ICAO, IDA,
IDB, IFAD, ILO, IMF, ITU, NAM, OAU, OIC, UN, UNCTAD, UNESCO,
UNIDO, UPU, WHO, WMO
_#_Diplomatic representation: Ambassador Amini Ali MOUMIN; Chancery
(temporary) at the Comoran Permanent Mission to the UN, 336 East 45th
Street, 2nd Floor, New York, NY 10017; telephone (212) 972-8010;
US--Ambassador Kenneth N. PELTIER; Embassy at address NA, Moroni
(mailing address B. P. 1318, Moroni); telephone 73-22-03, 73-29-22
_#_Flag: green with a white crescent placed diagonally (closed side of
the crescent points to the upper hoist-side corner of the flag); there
are four white five-pointed stars placed in a line between the points of
the crescent; the crescent, stars, and color green are traditional
symbols of Islam; the four stars represent the four main islands of the
archipelago--Mwali, Njazidja, Nzwani, and Mayotte (which is a territorial
collectivity of France, but claimed by the Comoros)
_#_Long-form name: Republic of the Congo
_#_Type: republic
_#_Capital: Brazzaville
_#_Administrative divisions: 9 regions (regions,
singular--region); Bouenza, Cuvette, Kouilou, Lekoumou, Likouala,
Niari, Plateaux, Pool, Sangha; note--there may be a new capital district
of Brazzaville
_#_Independence: 15 August 1960 (from France; formerly
Congo/Brazzaville)
_#_Constitution: 8 July 1979, currently being modified
_#_Legal system: based on French civil law system and customary law
_#_National holiday: National Day, 15 August (1960)
_#_Executive branch: president, prime minister, Council of Ministers
(cabinet)
_#_Legislative branch: unicameral National People''s Assembly
(Assemblee Nationale Populaire)
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State--President Denis SASSOU-NGUESSO (since 8 February
1979);
Head of Government--Prime Minister Brig. Gen. Louis-Sylvain
GOMA (since 9 January 1991)
_#_Political parties and leaders: Congolese Labor Party
(PCT), President Denis SASSOU-NGUESSO, leader; note--multiparty system
legalized, with over 50 parties established
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 26-31 July 1989 (next to be held July 1994);
results--President SASSOU-NGUESSO unanimously reelected leader of the
PCT by the Party Congress, which automatically made him president;
People''s National Assembly--last held 24 September 1989 (next
to be held NA 1994); results--PCT was the only party;
seats--(153 total) single list of candidates nominated by the PCT
_#_Communists: unknown number of Communists and sympathizers
_#_Other political or pressure groups: Union of Congolese Socialist
Youth (UJSC), Congolese Trade Union Congress (CSC), Revolutionary Union
of Congolese Women (URFC), General Union of Congolese Pupils and Students
(UGEEC)
_#_Member of: ACCT, ACP, AfDB, BDEAC, CCC, CEEAC, ECA, FAO, FZ, G-77,
GATT, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL,
IOC, ITU, LORCS, NAM, OAU, UDEAC, UN, UNAVEM, UNCTAD, UNESCO, UNIDO, UPU,
WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Roger ISSOMBO; Chancery at
4891 Colorado Avenue NW, Washington DC 20011; telephone (202) 726-5500;
US--Ambassador James Daniel PHILLIPS; Embassy at Avenue
Amilcar Cabral, Brazzaville (mailing address is B. P. 1015, Brazzaville,
or Box C, APO New York 09662-0006); telephone (242) 83-20-70 or 83-26-24
_#_Flag: red with the national emblem in the upper hoist-side corner;
the emblem includes a yellow five-pointed star above a crossed hoe and
hammer (like the hammer and sickle design) in yellow, flanked by two
curved green palm branches; uses the popular pan-African colors of','5c39a6013172706a072fb3059432cb4e173ea389ae5b5de83efc457b3491bdc9','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7a9683bbdb091c0acd1bc39676ce9a3adf28ea27fe8fb9f585980b1ee5f6e22',1991,'ET','Ethiopia','government',45,'_#_Long-form name: none
_#_Type: self-governing in free association with New Zealand; Cook
Islands fully responsible for internal affairs; New Zealand retains
responsibility for external affairs, in consultation with the Cook
Islands
_#_Capital: Avarua
_#_Administrative divisions: none
_#_Independence: became self-governing in free association with
New Zealand on 4 August 1965 and has the right at any time to move to
full independence by unilateral action
_#_Constitution: 4 August 1965
_#_National holiday: NA
_#_Executive branch: British monarch, representative of the UK,
representative of New Zealand, prime minister, deputy prime minister,
Cabinet
_#_Legislative branch: unicameral Parliament; note--the House of
Arikis (chiefs) advises on traditional matters, but has no legislative
powers
_#_Judicial branch: High Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952);
Representative of the UK Sir Tangaroa TANGAROA (since NA);
Representative of New Zealand Adrian SINCOCK (since NA);
Head of Government--Prime Minister Geoffrey HENRY
(since NA February 1989); Deputy Prime Minister Inatio AKARURU (since NA
February 1989)
_#_Political parties and leaders:
Cook Islands Party, Geoffrey HENRY;
Democratic Tumu Party, Vincent INGRAM;
Democratic Party, Dr. Vincent Pupuke ROBATI;
Cook Islands Labor Party, Rena JONASSEN;
Cook Islands People''s Party, Sadaraka SADARAKA
_#_Suffrage: universal adult at age NA
_#_Elections:
Parliament--last held 19 January 1989 (next to be held by
January 1994); results--percent of vote by party NA;
seats--(24 total) Cook Islands Party 12, Democratic
Tumu Party 2, opposition coalition (including Democratic Party) 9,
independent 1
_#_Member of: AsDB, ESCAP (associate), FAO, ICAO, IOC, SPC,
SPF, UNESCO, WHO
_#_Diplomatic representation: none (self-governing in free association
with New Zealand)
_#_Flag: blue with the flag of the UK in the upper hoist-side quadrant
and a large circle of 15 white five-pointed stars (one for every island)
centered in the outer half of the flag
_#_Long-form name: Coral Sea Islands Territory
_#_Type: territory of Australia administered by the Minister for
Arts, Sport, the Environment, Tourism, and Territories Roslyn
KELLY
_#_Flag: the flag of Australia is used
_#_Long-form name: Republic of Costa Rica
_#_Type: democratic republic
_#_Capital: San Jose
_#_Administrative divisions: 7 provinces (provincias,
singular--provincia); Alajuela, Cartago, Guanacaste, Heredia, Limon,
Puntarenas, San Jose
_#_Independence: 15 September 1821 (from Spain)
_#_Constitution: 9 November 1949
_#_Legal system: based on Spanish civil law system; judicial review of
legislative acts in the Supreme Court; has not accepted compulsory ICJ
jurisdiction
_#_National holiday: Independence Day, 15 September (1821)
_#_Executive branch: president, two vice presidents, Cabinet
_#_Legislative branch: unicameral Legislative Assembly (Asamblea
Legislativa)
_#_Judicial branch: Supreme Court (Corte Suprema)
_#_Leaders:
Chief of State and Head of Government--President Rafael Angel
CALDERON Fournier (since 8 May 1990); First Vice President German
SERRANO Pinto (since 8 May 1990); Second Vice President Arnoldo LOPEZ
Echandi (since 8 May 1990)
_#_Political parties and leaders:
National Liberation Party (PLN), Rolando ARAYA Monge;
Social Christian Unity Party (PUSC), Rafael Angel CALDERON Fournier;
Marxist Popular Vanguard Party (PVP), Humberto VARGAS Carbonell;
New Republic Movement (MNR), Sergio Erick ARDON Ramirez;
Progressive Party (PP), Isaac Felipe AZOFEIFA Bolanos;
People''s Party of Costa Rica (PPC), Lenin ChACON Vargas;
Radical Democratic Party (PRD), Juan Jose ECHEVERRIA Brealey
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
President--last held 4 February 1990 (next to be held February
1994);
results--Rafael Angel CALDERON Fournier 51%, Carlos Manuel
CASTILLO 47%;
Legislative Assembly--last held 4 February 1990 (next to be held
February 1994);
results--percent of vote by party NA;
seats--(57 total) PUSC 29, PLN 25, PVP/PPC 1, regional parties 2
_#_Communists: 7,500 members and sympathizers
_#_Other political or pressure groups: Costa Rican Confederation of
Democratic Workers (CCTD; Liberation Party affiliate), Confederated Union
of Workers (CUT; Communist Party affiliate), Authentic Confederation of
Democratic Workers (CATD; Communist Party affiliate), Chamber of Coffee
Growers, National Association for Economic Development (ANFE), Free Costa
Rica Movement (MCRL; rightwing militants), National Association of
Educators (ANDE)
_#_Member of: AG (observer), BCIE, CACM, ECLAC, FAO, G-77, GATT, IADB,
IAEA, IBRD, ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, IOM, ITU, LAES, LAIA (observer), LORCS, NAM (observer),
OAS, OPANAL, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Gonzalo FACIO Segreda;
Chancery at Suite 211, 1825 Connecticut Avenue NW, Washington DC 20009;
telephone (202) 234-2945 through 2947; there are Costa Rican Consulates
General at Albuquerque, Boston, Houston, Los Angeles, Miami, New Orleans,
New York, San Antonio, San Diego, San Francisco, San Juan (Puerto Rico),
and Tampa, and Consulates in Austin, Buffalo, Honolulu, and Raleigh;
US--Ambassador (vacant); Charge d''Affaires Robert O. HOMME;
Embassy at Pavas Road, San Jose (mailing address is APO Miami 34020);
telephone [506] 20-39-39
_#_Flag: five horizontal bands of blue (top), white, red (double
width), white, and blue with the coat of arms in a white disk on the
hoist side of the red band
_#_Long-form name: Republic of Cuba
_#_Type: Communist state
_#_Capital: Havana
_#_Administrative divisions: 14 provinces (provincias,
singular--provincia) and 1 special municipality* (municipio especial);
Camaguey, Ciego de Avila, Cienfuegos, Ciudad de La Habana, Granma,
Guantanamo, Holguin, Isla de la Juventud*, La Habana, Las Tunas,
Matanzas, Pinar del Rio, Sancti Spiritus, Santiago de Cuba, Villa
Clara
_#_Independence: 20 May 1902 (from Spain 10 December 1898;
administered by the US from 1898 to 1902)
_#_Constitution: 24 February 1976
_#_Legal system: based on Spanish and American law, with large
elements of Communist legal theory; does not accept compulsory ICJ
jurisdiction
_#_National holiday: Revolution Day, 1 January (1959)
_#_Executive branch: president of the Council of State, first vice
president of the Council of State, Council of State, president of the
Council of Ministers, first vice president of the Council of Ministers,
Council of Ministers
_#_Legislative branch: unicameral National Assembly of the People''s
Power (Asamblea Nacional del Poder Popular)
_#_Judicial branch: People''s Supreme Court
_#_Leaders:
Chief of State and Head of Government--President of the Council of
State and President of the Council of Ministers Fidel CASTRO Ruz
(became Prime Minister in February 1959 and President since 2 December
1976);
First Vice President of the Council of State and First Vice President
of the Council of Ministers Gen. Raul CASTRO Ruz (since 2 December
1976)
_#_Political parties and leaders: only party--Cuban Communist Party
(PCC), Fidel CASTRO Ruz, first secretary
_#_Suffrage: universal at age 16
_#_Elections:
National Assembly of the People''s Power--last held NA December
1986 (next to be held December 1991);
results--PCC is the only party;
seats--(510 total) PCC 510 (indirectly elected)
_#_Communists: about 600,000 full and candidate members
_#_Member of: CCC, ECLAC, FAO, G-77, GATT, IAEA, IBEC,
ICAO, IFAD, IIB, ILO, IMO, INTERPOL, IOC, ISO, ITU, LAES,
LAIA (observer), LORCS, NAM, OAS (excluded from formal participation
since 1962), OPANAL (observer), PCA, UN, UNCTAD, UNESCO, UNIDO, UPU,
WCL, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: none; protecting power in the US is
Switzerland--Cuban Interests Section; Counselor Jose Antonio ARBESU
Fraga; 2630 and 2639 16th Street NW, Washington DC 20009; telephone (202)
797-8518 or 8519, 8520, 8609, 8610;
US--protecting power in Cuba is Switzerland--US Interests Section;
Principal Officer Alan H. FLANIGAN; Calzada entre L y M, Vedado Seccion,
Havana (mailing address is USINT, c/o International Purchasing Group,
2052 NW 93rd Avenue, Miami, FL 33172); telephone 329-700
_#_Flag: five equal horizontal bands of blue (top and bottom)
alternating with white; a red equilateral triangle based on the hoist
side bears a white five-pointed star in the center
_#_Long-form name: Republic of Cyprus
_#_Type: republic; a disaggregation of the two ethnic communities
inhabiting the island began after the outbreak of communal strife in
1963; this separation was further solidified following the Turkish
invasion of the island in July 1974, which gave the Turkish Cypriots de
facto control in the north; Greek Cypriots control the only
internationally recognized government; on 15 November 1983 Turkish
Cypriot President Rauf Denktash declared independence and the formation
of a Turkish Republic of Northern Cyprus, which has been recognized
only by Turkey; both sides publicly call for the resolution of
intercommunal differences and creation of a new federal system of
_#_Capital: Nicosia
_#_Administrative divisions: 6 districts; Famagusta, Kyrenia,
Larnaca, Limassol, Nicosia, Paphos
_#_Independence: 16 August 1960 (from UK)
_#_Constitution: 16 August 1960; negotiations to create the basis for
a new or revised constitution to govern the island and to better
relations between Greek and Turkish Cypriots have been held
intermittently; in 1975 Turkish Cypriots created their own Constitution
and governing bodies within the Turkish Federated State of Cyprus, which
was renamed the Turkish Republic of Northern Cyprus in 1983; a new
Constitution for the Turkish area passed by referendum in May 1985
_#_Legal system: based on common law, with civil law modifications
_#_National holiday: Independence Day, 1 October
_#_Executive branch: president, Council of Ministers (cabinet);
note--there is a president, prime minister, and Council of Ministers
(cabinet) in the Turkish area
_#_Legislative branch: unicameral House of Representatives (Vouli
Antiprosopon); note--there is a unicameral Assembly of the Republic
(Cumhuriyet Meclisi) in the Turkish area
_#_Judicial branch: Supreme Court; note--there is also a Supreme Court
in the Turkish area
_#_Leaders:
Chief of State and Head of Government--President George VASSILIOU
(since February 1988); note--Rauf R. DENKTASH has been president
of the Turkish area since 13 February 1975
_#_Political parties and leaders:
Greek Cypriot--Progressive Party of the Working People (AKEL;
Communist Party), Dimitrios CHRISTOFIAS,
Democratic Rally (DESY), Glafcos CLERIDES;
Democratic Party (DEKO), Spyros KYPRIANOU;
United Democratic Union of the Center (EDEK), Vassos LYSSARIDES;
Socialist Democratic Renewal Movement (ADESOK), Pavlos DINGLIS, chairman;
Liberal Party, Nikos ROLANDIS;
Turkish area--National Unity Party (UBP), Dervis EROGLU;
Communal Liberation Party (TKP), Mustafa AKINCI;
Republican Turkish Party (CTP), Ozker OZGUR;
New Cyprus Party (NKP), Alpay DURDURAN;
New Dawn Party (YDP), Ali Ozkan ALTINISHIK;
Free Democratic Party, Ismet KOTAK; note--CTP, TKP, and YDP joined
in the coalition Democratic Struggle Party (DMP) for the 22 April
1990 legislative election
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 14 February and 21 February 1988 (next
to be held February 1993);
results--George VASSILIOU 52%, Glafcos CLERIDES 48%;
House of Representatives--last held 8 December 1985 (next to
be held 19 May 1991);
results--DESY 33.56%, DEKO 27.65%, AKEL (Communist) 27.43%, EDEK 11.07%;
seats--(56 total) DESY 19, DEKO 16, AKEL (Communist) 15, EDEK 6;
Turkish Area: President--last held 22 April 1990 (next to be
held April 1995);
results--Rauf R. DENKTASH 66%, Ismail BOZKURT 32.05%;
Turkish Area: Assembly of the Republic--last held 6 May 1990
(next to be held May 1995);
results--UBP (conservative) about 55%, DMP NA%;
seats--(50 total) UBP (conservative) 34, CTP (Communist) 7,
TKP (center-right) 7, New Dawn Party 2
_#_Communists: about 12,000
_#_Other political or pressure groups: United Democratic Youth
Organization (EDON; Communist controlled); Union of Cyprus Farmers (EKA;
Communist controlled); Cyprus Farmers Union (PEK; pro-West); Pan-Cyprian
Labor Federation (PEO; Communist controlled); Confederation of Cypriot
Workers (SEK; pro-West); Federation of Turkish Cypriot Labor Unions
(Turk-Sen); Confederation of Revolutionary Labor Unions (Dev-Is)
_#_Member of: C, CCC, CE, CSCE, EBRD, ECE, FAO, G-77, GATT, IAEA,
IBRD, ICAO, ICC, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, IOM, ISO, ITU, NAM, OAS (observer), UN, UNCTAD,
UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Michael E. SHERIFIS;
Chancery at 2211 R Street NW, Washington DC 20008; telephone (202)
462-5772; there is a Cypriot Consulate General in New York;
US--Ambassador Robert E. LAMB; Embassy at the corner of Therissos
Street and Dositheos Street, Nicosia (mailing address is FPO New York
09530); telephone [357] (2) 4651511
_#_Flag: white with a copper-colored silhouette of the island (the
name Cyprus is derived from the Greek word for copper) above two green
crossed olive branches in the center of the flag; the branches symbolize
the hope for peace and reconciliation between the Greek and Turkish
communities
_#_Long-form name: Czech and Slovak Federal Republic; note--on
23 March 1990 the Czechoslovak Socialist Republic was renamed the
Czechoslovak Federative Republic; Slovak concerns about their
status in the federation prompted the Federal Assembly to approve the
name Czech and Slovak Federative Republic on 20 April 1990; on 23 April
1990 the name was modified to Czech and Slovak Federal Republic
_#_Type: federal republic in transition to a confederative republic
_#_Capital: Prague
_#_Administrative divisions: 2 republics (republiky,
singular--republika); Czech Republic (Ceska Republika),
Slovak Republic (Slovenska Republika)
_#_Independence: 28 October 1918 (from Austro-Hungarian Empire)
_#_Constitution: 11 July 1960; amended in 1968 and 1970; new
Czech, Slovak, and federal constitutions to be drafted in 1991-92
_#_Legal system: civil law system based on Austro-Hungarian codes,
modified by Communist legal theory; no judicial review of legislative
acts; has not accepted compulsory ICJ jurisdiction; legal code in
process of modification to bring it in line with Conference on
Security and Cooperation in Europe (CSCE) obligations and to expunge
Marxist-Leninist legal theory
_#_National holiday: National Liberation Day, 9 May (1945) and
Founding of the Republic, 28 October (1918)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: bicameral Federal Assembly (Federalni
Shromazdeni) consists of an upper house or Chamber of Nations
(Snemovna Narodu) and a lower house or Chamber of the People
(Snemovna Lidu)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Vaclav HAVEL;
(interim president from 29 December 1989 and president since
5 July 1990);
Head of Government--Premier Marian CALFA (since
10 December 1989);
Deputy Premier Vaclav VALES (since 28 June 1990);
Deputy Premier Jiri DIENSTBIER (since 28 June 1990);
Deputy Premier Jozef MIKLOSKO (since 28 June 1990);
Deputy Premier Pavel RYCHETSKY (since 28 June 1990)
_#_Political parties and leaders:
Civic Forum, Vaclav KLAUS, chairman;
Public Against Violence, Fedor GAL, chairman;
Christian and Democratic Union, Vaclav BENDA;
Christian Democratic Movement, Jan CARNOGURSKY;
Communist Party of Czechoslovakia (KSC), Pavol KANIS, chairman;
KSC toppled from power in November 1989 by massive antiregime
demonstrations, minority role in coalition government since 10 December
1989
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 5 July 1990 (next to be held July 1992);
results--Vaclav HAVEL elected by the Federal Assembly;
Federal Assembly--last held 8-9 June 1990 (next to be held June
1992);
results--Civic Forum/Public Against Violence coalition 46%, KSC 13.6%;
seats--(300 total) Civic Forum/Public Against Violence coalition 170,
KSC 47, Christian and Democratic Union/Christian Democratic
Movement 40, Czech, Slovak, Moravian, and Hungarian groups 43
_#_Communists: 760,000 party members (September 1990); about
1,000,000 members lost since November 1989
_#_Other political or pressure groups: Czechoslovak Socialist Party,
Czechoslovak People''s Party, Czechoslovak Social Democracy, Slovak
Nationalist Party, Slovak Revival Party, Christian Democratic Party;
over 80 registered political groups fielded candidates in the 8-9 June
1990 legislative election
_#_Member of: BIS, CCC, CSCE, ECE, FAO, GATT, IAEA, IBEC,
ICAO, IIB, ILO, IMF, IMO, INMARSAT, IOC, ISO, ITU, LORCS, PCA, UN,
UNAVEM, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Rita KLIMOVA;
Chancery at 3900 Linnean Avenue NW, Washington DC 20008; telephone (202)
363-6315 or 6316;
US--Ambassador Shirley Temple BLACK; Embassy at Trziste 15,
125 48, Prague 1 (mailing address is AMEM, Box 5630, APO New York
09213-5630); telephone [42] (2) 536641 through 536649
_#_Flag: two equal horizontal bands of white (top) and red with a blue
isosceles triangle based on the hoist side
_#_Long-form name: Kingdom of Denmark
_#_Type: constitutional monarchy
_#_Capital: Copenhagen
_#_Administrative divisions: metropolitan Denmark--14 counties (amter,
singular--amt) and 1 city* (stad); Arhus, Bornholm, Frederiksborg,
Fyn, Kobenhavn, Nordjylland, Ribe, Ringkobing, Roskilde,
Sonderjylland, Staden Kobenhavn*, Storstrom, Vejle, Vestsjaelland,
Viborg; note--see separate entries for the Faroe Islands and Greenland
which are part of the Danish realm and self-governing administrative
divisions
_#_Independence: became a constitutional monarchy in 1849
_#_Constitution: 5 June 1953
_#_Legal system: civil law system; judicial review of legislative
acts; accepts compulsory ICJ jurisdiction, with reservations
_#_National holiday: Birthday of the Queen, 16 April (1940)
_#_Executive branch: monarch, heir apparent, prime minister, Cabinet
_#_Legislative branch: unicameral Parliament (Folketing)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen MARGRETHE II (since January 1972);
Heir Apparent Crown Prince FREDERIK, elder son of the Queen (born 26
May 1968);
Head of Government--Prime Minister Poul SCHLUTER (since 10
September 1982)
_#_Political parties and leaders: Social Democratic, Svend AUKEN;
Conservative, Poul SCHLUTER;
Liberal, Uffe ELLEMANN-JENSEN;
Socialist People''s, Holger K. NIELSEN;
Progress Party, Pia KJAERSGAARD;
Center Democratic, Mimi Stilling JAKOBSEN;
Radical Liberal, Marianne JELVED;
Christian People''s, Flemming KOTOED-SVENDSEN;
Left Socialist, Elizabeth BRUN-OLESEN;
Justice, Poul Gerhard KRISTIANSEN;
Socialist Workers Party, leader NA;
Communist Workers'' Party (KAP), leader NA;
Common Course, Preben Moller HANSEN;
Green Party, Inger BORLEHMANN
_#_Suffrage: universal at age 21
_#_Elections:
Parliament--last held 12 December 1990 (next to be held by
December 1994);
results--Social Democratic 37.4%, Conservative 16.0%, Liberal 15.8%,
Socialist People''s 8.3%, Progress Party 6.4%, Center Democratic 5.1%,
Radical Liberal 3.5%, Christian People''s 2.3%, other 5.2%;
seats--(175 total; includes 2 from Greenland and 2 from the Faroe
Islands) Social Democratic 69, Conservative 30, Liberal 29,
Socialist People''s 15, Progress Party 12, Center Democratic 9, Radical
Liberal 7, Christian People''s 4
_#_Member of: AfDB, AG (observer), AsDB, BIS, CCC, CE, CERN, COCOM,
CSCE, EBRD, EC, ECE, EIB, ESA, FAO, G-9, GATT, IADB, IAEA, IBRD, ICAO,
ICC, ICFTU, IDA, IEA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT,
INTERPOL, IOC, IOM, ISO, ITU, LORCS, NATO, NC, NEA, NIB, OECD,
PCA, UN, UNCTAD, UNESCO, UNFICYP, UNHCR, UNIDO, UNIIMOG,
UNMOGIP, UNTSO, UPU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Peter Pedersen DYVIG;
Chancery at 3200 Whitehaven Street NW, Washington DC 20008; telephone
(202) 234-4300; there are Danish Consulates General at Chicago, Houston,
Los Angeles, and New York;
US--Ambassador Keith L. BROWN; Embassy at Dag Hammarskjolds Alle
24, 2100 Copenhagen O (mailing address is APO New York 09170);
telephone [45] (31) 42 31 44
_#_Flag: red with a white cross that extends to the edges of the flag;
the vertical part of the cross is shifted to the hoist side and that
design element of the Dannebrog (Danish flag) was subsequently
adopted by the other Nordic countries of Finland, Iceland, Norway, and','e76a3c740210acc03eeea5415c5689f58205e23aaeb3658507395b898119d92e','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7945ea6ec25009e7118a61dc8c172d024422beb0588d0822d1e9025be5d8ac2c',1991,'SE','Sweden','government',50,'_#_Long-form name: Republic of Djibouti
_#_Type: republic
_#_Capital: Djibouti
_#_Administrative divisions: 5 districts (cercles, singular--cercle);
Ali Sabih, Dikhil, Djibouti, Obock, Tadjoura
_#_Independence: 27 June 1977 (from France; formerly French Territory
of the Afars and Issas)
_#_Constitution: partial constitution ratified January 1981 by the
National Assembly
_#_Legal system: based on French civil law system, traditional
practices, and Islamic law
_#_National holiday: Independence Day, 27 June (1977)
_#_Executive branch: president, prime minister, Council of Ministers
_#_Legislative branch: National Assembly (Assemblee Nationale)
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State--President Hassan GOULED Aptidon (since 24 June
1977);
Head of Government--Prime Minister BARKAT Gourad Hamadou (since 30
September 1978)
_#_Political parties and leaders: only party--People''s Progress
Assembly (RPP), Hassan GOULED Aptidon
_#_Suffrage: universal adult at age NA
_#_Elections:
President--last held 24 April 1987 (next to be held April 1993);
results--President Hassan GOULED Aptidon was reelected without
opposition;
National Assembly--last held 24 April 1987 (next to be
held April 1992); results--RPP is the only party; seats--(65 total)
RPP 65
_#_Communists: NA
_#_Member of: ACCT, ACP, AfDB, AFESD, AL, ECA, FAO, G-77, IBRD, ICAO,
IDA, IDB, IFAD, IFC, IGADD, ILO, IMF, IMO, INTERPOL, IOC, ITU,
LORCS, NAM, OAU, OIC, UN, UNESCO, UNCTAD, UPU, WHO, WMO
_#_Diplomatic representation: Ambassador Roble OLHAYE; Chancery
(temporary) at the Djiboutian Permanent Mission to the UN; 866 United
Nations Plaza, Suite 4011, New York, NY 10017; telephone (212) 753-3163;
US--Ambassador Robert S. BARRETT IV; Embassy at Villa Plateau du
Serpent, Boulevard Marechal Joffre, Djibouti (mailing address is B. P.
185, Djibouti); telephone [253] 35-39-95
_#_Flag: two equal horizontal bands of light blue (top) and light
green with a white isosceles triangle based on the hoist side bearing a
red five-pointed star in the center
_#_Long-form name: Commonwealth of Dominica
_#_Type: parliamentary democracy
_#_Capital: Roseau
_#_Administrative divisions: 10 parishes; Saint Andrew, Saint David,
Saint George, Saint John, Saint Joseph, Saint Luke, Saint Mark,
Saint Patrick, Saint Paul, Saint Peter
_#_Independence: 3 November 1978 (from UK)
_#_Constitution: 3 November 1978
_#_Legal system: based on English common law
_#_National holiday: Independence Day, 3 November (1978)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: unicameral House of Assembly
_#_Judicial branch: Eastern Caribbean Supreme Court
_#_Leaders:
Chief of State--President Sir Clarence Augustus SEIGNORET (since
19 December 1983);
Head of Government--Prime Minister (Mary) Eugenia CHARLES (since 21
July 1980, elected for a third term 28 May 1990)
_#_Political parties and leaders:
Dominica Freedom Party (DFP), (Mary) Eugenia CHARLES;
Dominica Labor Party (DLP), Michael DOUGLAS;
United Workers Party (UWP), Edison JAMES
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 20 December 1988 (next to be held December
1993); the president is elected by the House of Assembly;
House of Assembly--last held 28 May 1990 (next to be held May
1995); results--percent of vote by party NA;
seats--(30 total; 9 appointed senators and 21 elected representatives)
DFP 11, UWP 6, DLP 4
_#_Communists: negligible
_#_Other political or pressure groups: Dominica Liberation Movement
(DLM), a small leftist group
_#_Member of: ACCT, ACP, C, CARICOM, CDB, ECLAC, FAO, G-77, IBRD,
ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTERPOL, LORCS, NAM (observer),
OAS, OECS, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WMO
_#_Diplomatic representation: there is no Chancery in the US;
US--no official presence since the Ambassador resides in Bridgetown
(Barbados), but travels frequently to Dominica
_#_Flag: green with a centered cross of three equal bands--the
vertical part is yellow (hoist side), black, and white--the horizontal
part is yellow (top), black, and white; superimposed in the center of the
cross is a red disk bearing a sisserou parrot encircled by 10 green
five-pointed stars edged in yellow; the 10 stars represent the 10
administrative divisions (parishes)
_#_Long-form name: Dominican Republic (no short-form name)
_#_Type: republic
_#_Capital: Santo Domingo
_#_Administrative divisions: 29 provinces (provincias,
singular--provincia) and 1 district* (distrito); Azua, Baoruco, Barahona,
Dajabon, Distrito Nacional*, Duarte, Elias Pina, El Seibo,
Espaillat, Hato Mayor, Independencia, La Altagracia, La Romana, La Vega,
Maria Trinidad Sanchez, Monsenor Nouel, Monte Cristi, Monte Plata,
Pedernales, Peravia, Puerto Plata, Salcedo, Samana, Sanchez
Ramirez, San Cristobal, San Juan, San Pedro De Macoris, Santiago,
Santiago Rodriguez, Valverde
_#_Independence: 27 February 1844 (from Haiti)
_#_Constitution: 28 November 1966
_#_Legal system: based on French civil codes
_#_National holiday: Independence Day, 27 February (1844)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: bicameral National Congress (Congreso Nacional)
consists of an upper chamber or Senate (Senado) and lower chamber or
Chamber of Deputies (Camara de Diputados)
_#_Judicial branch: Supreme Court (Corte Suprema)
_#_Leaders:
Chief of State and Head of Government--President Joaquin BALAGUER
Ricardo (since 16 August 1986, fifth elected term began 16 August 1990);
Vice President Carlos A. MORALES Troncoso (since 16 August 1986)
_#_Political parties and leaders:
Major parties--
Social Christian Reformist Party (PRSC), Joaquin BALAGUER Ricardo;
Dominican Revolutionary Party (PRD), Jose Francisco PENA Gomez;
Dominican Liberation Party (PLD), Juan BOSCH Gavino;
Independent Revolutionary Party (PRI), Jacobo MAJLUTA;
Minor parties--
National Veterans and Civilian Party (PNVC), Juan Rene BEAUCHAMPS Javier;
Liberal Party of the Dominican Republic (PLRD), Andres Van Der HORST;
Democratic Quisqueyan Party (PQD), Elias WESSIN Chavez;
Constitutional Action Party (PAC), Luis ARZENO Rodriguez;
National Progressive Force (FNP), Marino VINICIO Castillo;
Popular Christian Party (PPC), Rogelio DELGADO Bogaert;
Dominican Communist Party (PCD), Narciso ISA Conde;
Anti-Imperialist Patriotic Union (UPA), Ivan RODRIGUEZ;
note--in 1983 several leftist parties, including the PCD, joined to
form the Dominican Leftist Front (FID); however, they still retain
individual party structures
_#_Suffrage: universal and compulsory at age 18 or if married; members
of the armed forces and police cannot vote
_#_Elections:
President--last held 16 May 1990 (next to be held May 1994);
results--Joaquin BALAGUER (PRSC) 35.7%, Juan BOSCH Gavino (PLD)
34.4%;
Senate--last held 16 May 1990 (next to be held May 1994);
results--percent of vote by party NA;
seats--(30 total) PRSC 16, PLD 12, PRD 2;
Chamber of Deputies--last held 16 May 1990 (next to be
held May 1994);
results--percent of vote by party NA;
seats--(120 total) PLD 44, PRSC 41, PRD 33, PRI 2
_#_Communists: an estimated 8,000 to 10,000 members in several legal
and illegal factions; effectiveness limited by ideological differences,
organizational inadequacies, and severe funding shortages
_#_Member of: CARICOM (observer), ECLAC, FAO, G-11, G-77, GATT, IADB,
IAEA, IBRD, ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, IOM, ITU, LAES, LAIA (observer), LORCS, NAM (guest),
OAS, OPANAL, PCA, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WMO,
WTO
_#_Diplomatic representation: Ambassador Carlos A. MORALES Troncoso
(serves concurrently as Vice President); Chancery at
1715 22nd Street NW, Washington DC 20008; telephone (202) 332-6280;
there are Dominican Consulates General in Boston, Chicago, Los Angeles,
Mayaguez (Puerto Rico), Miami, New Orleans, New York, Philadelphia, San
Juan (Puerto Rico), and Consulates in Charlotte Amalie (Virgin Islands),
Detroit, Houston, Jacksonville, Minneapolis, Mobile, Ponce (Puerto
Rico), and San Francisco;
US--Ambassador Paul D. TAYLOR; Embassy at the corner of
Calle Cesar Nicolas Penson and Calle Leopoldo Navarro, Santo Domingo
(mailing address is APO Miami 34041-0008); telephone [809] 541-2171
_#_Flag: a centered white cross that extends to the edges, divides the
flag into four rectangles--the top ones are blue (hoist side) and red,
the bottom ones are red (hoist side) and blue; a small coat of arms is at
the center of the cross
_#_Long-form name: Republic of Ecuador
_#_Type: republic
_#_Capital: Quito
_#_Administrative divisions: 21 provinces (provincias,
singular--provincia); Azuay, Bolivar, Canar, Carchi, Chimborazo,
Cotopaxi, El Oro, Esmeraldas, Galapagos, Guayas, Imbabura, Loja,
Los Rios, Manabi, Morona-Santiago, Napo, Pastaza, Pichincha,
Sucumbios, Tungurahua, Zamora-Chinchipe
_#_Independence: 24 May 1822 (from Spain; Battle of Pichincha)
_#_Constitution: 10 August 1979
_#_Legal system: based on civil law system; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 10 August (1809, independence
of Quito)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: unicameral National Congress (Congreso
Nacional)
_#_Judicial branch: Supreme Court (Corte Suprema)
_#_Leaders:
Chief of State and Head of Government--President Rodrigo BORJA
Cevallos (since 10 August 1988); Vice President Luis PARODI Valverde
(since 10 August 1988)
_#_Political parties and leaders:
Right to center parties--
Social Christian Party (PSC), former President Leon FEBRES Cordero
Rivadeneira;
Conservative Party (PC), Alberto DAHIK, leader;
Radical Liberal Party (PLR), Blasco Manuel PENAHERRERA Padilla,
director;
Centrist parties--
Concentration of Popular Forces (CFP), Averroes BUCARAM Saxida, director;
Radical Alfarist Front (FRA), Cecilia CALDERON de Castro, leader;
People, Change, and Democracy (PCD), Aquiles RIGAIL Santistevan,
director;
Revolutionary Nationalist Party (PNR), Carlos Julio AROSEMENA Monroy,
leader;
Center-left parties--
Democratic Left (ID), President Rodrigo BORJA Cevallos, leader;
Roldosist Party of Ecuador (PRE), Abdala BUCARAM Ortiz, director;
Popular Democracy (DP), Vladimiro ALVAREZ, president;
Christian Democratic (CD), Julio Cesar TRUJILLO;
Democratic Party (PD), Francisco HUERTA Montalvo, leader;
Far-left parties--
Broad Leftist Front (FADI), Rene MAUGE Mosquera, director;
Socialist Party (PSE), Victor GRANDA Aguilar, secretary general;
Democratic Popular Movement (MPD), Jaime HURTADO Gonzalez, leader;
Ecuadorian National Liberation (LN), Alfredo CASTILLO, president;
Popular Revolutionary Action Party (APRE), Lt. Gen. Frank VARGAS Pazzos,
leader
_#_Suffrage: universal at age 18; compulsory for literate persons ages
18-65, optional for other eligible voters
_#_Elections:
President--first round held 31 January 1988 and second round on
8 May 1988 (next first round to be held May 1992 and second round
June 1992);
results--Rodrigo BORJA Cevallos (ID) 54%, Abdala BUCARAM Ortiz
(PRE) 46%;
Chamber of Representatives--last held 17 June 1990
(next to be held June 1992);
results--percent of vote by party NA;
seats--(72 total) PSC 16, ID 14, PRE 13, PSE 8, DP 7, CFP 3,
PC 3, PLR 3, FADI 2, FRA 2, MPD 1
_#_Communists: Communist Party of Ecuador (PCE, pro-Moscow), Rene
Mauge Mosquera, secretary general, 5,000 members; Communist Party of
Ecuador/Marxist Leninist (PCMLE, Maoist), 3,000 members; Socialist
Party of Ecuador (PSE, pro-Cuba), 5,000 members (est.); National
Liberation Party (PLN, Communist), 5,000 members (est.)
_#_Member of: AG, ECLAC, FAO, G-11, G-77, IADB, IAEA, IBRD, ICAO, ICC,
ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, IOM, ITU,
LAES, LAIA, LORCS, NAM, OAS, OPANAL, OPEC, PCA, RG, UN, UNCTAD, UNESCO,
UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Jaime MONCAYO; Chancery at
2535 15th Street NW, Washington DC 20009; telephone (202) 234-7200;
there are Ecuadorian Consulates General in Chicago, Houston, Los Angeles,
Miami, New Orleans, New York, and San Francisco, and a Consulate in San
Diego;
US--Ambassador Paul C. LAMBERT; Embassy at Avenida Patria
120, on the corner of Avenida 12 de Octubre, Quito (mailing address is
P. O. Box 538, Quito, or APO Miami 34039); telephone [593] (2) 562-890;
there is a US Consulate General in Guayaquil
_#_Flag: three horizontal bands of yellow (top, double width), blue,
and red with the coat of arms superimposed at the center of the flag;
similar to the flag of Colombia which is shorter and does not bear a coat
of arms','5e84af167d110936c1f654d14dccc13f91c27a84ba42eca3d2cedb3e059c2195','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9eb54b53a4a843b200fc7275a7ab23726f533255ff275c729f95994d12303c8',1991,'MX','Mexico','government',56,'_#_Long-form name: Arab Republic of Egypt
_#_Type: republic
_#_Capital: Cairo
_#_Administrative divisions: 24 governorates (muhafazat,
singular--muhafazah); Ad Daqahliyah, Al Bahr al Ahmar,
Al Buhayrah, Al Fayyum, Al Gharbiyah, Al Iskandariyah,
Al Ismailiyah, Al Jizah, Al Minufiyah, Al Minya,
Al Qahirah, Al Qalyubiyah, Al Wadi al Jadid, Ash
Sharqiyah, As Suways, Aswan, Asyut, Bani Suwayf, Bur
Said, Dumyat, Janub Sina, Matruh,
Shamal Sina, Suhaj
_#_Independence: 28 February 1922 (from UK); formerly United Arab
Republic
_#_Constitution: 11 September 1971
_#_Legal system: based on English common law, Islamic law, and
Napoleonic codes; judicial review by Supreme Court and Council of State
(oversees validity of administrative decisions); accepts compulsory ICJ
jurisdiction, with reservations
_#_National holiday: Anniversary of the Revolution, 23 July (1952)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: unicameral People''s Assembly (Majlis
al-Chaab); note--there is an Advisory Council (Majlis al-Shura) that
functions in a consultative role
_#_Judicial branch: Supreme Constitutional Court
_#_Leaders:
Chief of State--President Mohammed Hosni MUBARAK (was made acting
President on 6 October 1981 upon the assassination of President Sadat and
sworn in as President on 14 October 1981);
Head of Government--Prime Minister Atef Mohammed Najib SEDKY
(since 12 November 1986)
_#_Political parties and leaders: formation of political parties must
be approved by government;
National Democratic Party (NDP), President Mohammed Hosni MUBARAK,
leader, is the dominant party;
legal opposition parties are
Socialist Liberal Party (SLP), Kamal MURAD;
Socialist Labor Party, Ibrahim SHUKRI;
National Progressive Unionist Grouping (NPUG), Khalid MUHYI-AL-DIN;
Umma Party, Ahmad al-SABAHI;
New Wafd Party (NWP), Fuad SIRAJ AL-DIN;
Misr al-Fatah Party (Young Egypt Party), Ali al-Din SALIH;
Democratic Unionist Party, Muhammad Abd al-Mun''im TURK;
The Greens Party, Hasan RAJAB
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
President--last held 5 October 1987 (next to be held October
1993); results--President Hosni MUBAREK was reelected;
People''s Assembly--last held 29 November 1990 (next to be held
November 1995); results--NDP 78.4%, NPUG 1.4%, independents 18.7%;
seats--(454 total, 444 elected)--including NDP 348,
NPUG 6, independents 83; note--most opposition parties boycotted;
Advisory Council--last held 8 June 1989 (next to be held June
1995);
results--NDP 100%;
seats--(258 total, 172 elected) NDP 172
_#_Communists: about 500 party members
_#_Other political or pressure groups: Islamic groups are illegal, but
the largest one, the Muslim Brotherhood, is tolerated by the government;
trade unions and professional associations are officially sanctioned
_#_Member of: ABEDA, ACC, ACCT (associate), AfDB, AFESD, AG (observer),
AL, AMF, CAEU, CCC, EBRD, ECA, ESCWA, FAO, G-19, G-24, G-77, GATT, IAEA,
IBRD, ICAO, ICC, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT,
INTERPOL, IOC, IOM (observer), ISO, ITU, LORCS, NAM, OAPEC,
OAS (observer), OAU, OIC, PCA, UN, UNCTAD, UNESCO, UNIDO, UNRWA, UPU,
WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador El Sayed Abdel Raouf EL
REEDY; Chancery at 2310 Decatur Place NW, Washington DC 20008;
telephone (202) 232-5400; there are Egyptian Consulates General in
Chicago, Houston, New York, and San Francisco;
US--Ambassador Frank G. WISNER; Embassy at Lazougi Street,
Garden City, Cairo (mailing address is APO New York 09674-0006);
telephone [20] (2) 355-7371; there is a US Consulate General in
Alexandria
_#_Flag: three equal horizontal bands of red (top), white, and black
with the national emblem (a shield superimposed on a golden eagle facing
the hoist side above a scroll bearing the name of the country in Arabic)
centered in the white band; similar to the flag of Yemen which has a
plain white band; also similar to the flag of Syria which has two green
stars and of Iraq which has three green stars (plus an Arabic
inscription) in a horizontal line centered in the white band
_#_Long-form name: Republic of El Salvador
_#_Type: republic
_#_Capital: San Salvador
_#_Administrative divisions: 14 departments (departamentos,
singular--departamento); Ahuachapan, Cabanas, Chalatenango,
Cuscatlan, La Libertad, La Paz, La Union, Morazan, San Miguel,
San Salvador, Santa Ana, San Vicente, Sonsonate, Usulutan
_#_Independence: 15 September 1821 (from Spain)
_#_Constitution: 20 December 1983
_#_Legal system: based on civil and Roman law, with traces of common
law; judicial review of legislative acts in the Supreme Court; accepts
compulsory ICJ jurisdiction, with reservations
_#_National holiday: Independence Day, 15 September (1821)
_#_Executive branch: president, vice president, Council of Ministers
(cabinet)
_#_Legislative branch: unicameral Legislative Assembly (Asamblea
Legislativa)
_#_Judicial branch: Supreme Court (Corte Suprema)
_#_Leaders:
Chief of State and Head of Government--President Alfredo CRISTIANI
(since 1 June 1989); Vice President Jose Francisco MERINO (since 1 June
1989)
_#_Political parties and leaders: National Republican Alliance
(ARENA), Armando CALDERON Sol;
Christian Democratic Party (PDC), Fidel CHAVEZ Mena;
National Conciliation Party (PCN), Ciro CRUZ Zepeda;
National Democratic Union (UDN), Mario AGUINADA Carranza;
the Democratic Convergence (CD) is a coalition of three
parties--the Social Democratic Party (PSD), Wilfredo BARILLAS;
the National Revolutionary Movement (MNR), Rene FLORES;
and the Popular Social Christian Movement (MPSC), Ruben ZAMORA;
Authentic Christian Movement (MAC), Julio REY PRENDES;
Democratic Action (AD), Ricardo GONZALEZ Camacho
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 19 March 1989 (next to be held March 1994);
results--Alfredo CRISTIANI (ARENA) 53.8%, Fidel CHAVEZ Mena (PDC) 36.6%,
other 9.6%;
Legislative Assembly--last held 10 March 1991 (next to be
held March 1994);
results--ARENA 44.3%, PDC 27.96%, CD 12.16%, PCN 8.99%, MAC 3.23%,
UDN 2.68%;
seats--(84 total) ARENA 39, PDC 26, PCN 9, CD 8, UDN 1, MAC 1
_#_Other political or pressure groups:
Leftist revolutionary movement--Farabundo Marti National
Liberation Front (FMLN), leadership body of the insurgency, four
factions--Popular Liberation Forces (FPL), Armed Forces of National
Resistance (FARN), People''s Revolutionary Army (ERP), Salvadoran
Communist Party/Armed Forces of Liberation (PCES/FAL), and Central
American Workers'' Revolutionary Party (PRTC)/Popular Liberation
Revolutionary Armed Forces (FARLP);
Leftist political parties--National Democratic Union (UDN),
National Revolutionary Movement (MNR), and Popular Social Movement
(MPSC);
FMLN front organizations:
Labor fronts include--National Union of Salvadoran Workers (UNTS),
leftist umbrella front group, leads FMLN front network;
National Federation of Salvadoran Workers (FENASTRAS), best
organized of front groups and controlled by FMLN''s National Resistance
(RN); Social Security Institute Workers Union (STISSS), one of the most
militant fronts, is controlled by FMLN''S Armed Forces of National
Resistance (FARN) and RN;
Association of Telecommunications Workers (ASTTEL);
Centralized Union Federation of El Salvador (FUSS);
Treasury Ministry Employees (AGEMHA);
Nonlabor fronts include--Committee of Mothers and Families of Political
Prisoners, Disappeared Persons, and Assassinated of El Salvador
(COMADRES);
Nongovernmental Human Rights Commission (CDHES);
Committee of Dismissed and Unemployed of El Salvador (CODYDES);
General Association of Salvadoran University Students (AGEUS);
National Association of Salvadoran Educators (ANDES-21 DE JUNIO);
Salvadoran Revolutionary Student Front (FERS), associated with the
Popular Forces of Liberation (FPL);
Association of National University Educators (ADUES);
Salvadoran University Students Front (FEUS);
Christian Committee for the Displaced of El Salvador (CRIPDES),
an FPL front;
The Association for Communal Development in El Salvador (PADECOES),
controlled by the People''s Revolutionary Army (ERP);
Confederation of Cooperative Associations of El Salvador (COACES);
Labor organizations--Federation of Construction and Transport
Workers Unions (FESINCONSTRANS), independent;
Salvadoran Communal Union (UCS), peasant association;
Unitary Federation of Salvadoran Unions (FUSS), leftist;
National Federation of Salvadoran Workers (FENASTRAS), leftist;
Democratic Workers Central (CTD), moderate;
General Confederation of Workers (CGT), moderate;
National Unity of Salvadoran Workers (UNTS), leftist;
National Union of Workers and Peasants (UNOC),
moderate labor coalition of democratic labor organizations;
United Workers Front (FUT);
Business organizations--National Association of Private Enterprise
(ANEP), conservative;
Productive Alliance (AP), conservative;
National Federation of Salvadoran Small Businessmen (FENAPES),
conservative
_#_Member of: BCIE, CACM, ECLAC, FAO, G-77, IADB, IAEA, IBRD, ICAO,
ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, IOC, IOM, ITU, LAES,
LORCS, NAM (observer), OAS, OPANAL, PCA, UN, UNCTAD, UNESCO, UNIDO, UPU,
WCL, WFTU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Miguel Angel SALAVERRIA;
Chancery at 2308 California Street NW, Washington DC 20008; telephone
(202) 265-3480 through 3482; there are Salvadoran Consulates General in
Houston, Los Angeles, Miami, New Orleans, New York, and San Francisco;
US--Ambassador William G. WALKER; Embassy at 25 Avenida Norte No.
1230, San Salvador (mailing address is APO Miami 34023); telephone [503]
26-7100
_#_Flag: three equal horizontal bands of blue (top), white, and blue
with the national coat of arms centered in the white band; the coat of
arms features a round emblem encircled by the words REPUBLICA DE EL
SALVADOR EN LA AMERICA CENTRAL; similar to the flag of Nicaragua which
has a different coat of arms centered in the white band--it features a
triangle encircled by the words REPUBLICA DE NICARAGUA on top and
AMERICA CENTRAL on the bottom; also similar to the flag of Honduras
which has five blue stars arranged in an X pattern centered in the
white band
_#_Long-form name: Republic of Equatorial Guinea
_#_Type: republic
_#_Capital: Malabo
_#_Administrative divisions: 2 provinces (provincias,
singular--provincia); Bioko, Rio Muni; note--there may now be 6 provinces
named Bioko Norte, Bioko Sur, Centro Sur, Kie-Ntem, Litoral, Wele Nzas
_#_Independence: 12 October 1968 (from Spain; formerly Spanish Guinea)
_#_Constitution: 15 August 1982
_#_Legal system: in transition; partly based on Spanish civil law and
tribal custom
_#_National holiday: Independence Day, 12 October (1968)
_#_Executive branch: president, prime minister, deputy prime minister,
Council of Ministers (cabinet)
_#_Legislative branch: unicameral House of Representatives of the
People (Camara de Representantes del Pueblo)
_#_Judicial branch: Supreme Tribunal
_#_Leaders:
Chief of State--President Brig. Gen. (Ret.) Teodoro OBIANG NGUEMA
MBASOGO (since 3 August 1979);
Head of Government--Prime Minister Cristino SERICHE BIOKO MALABO
(since 15 August 1982); Deputy Prime Minister Isidoro Eyi MONSUY ANDEME
(since 15 August 1989)
_#_Political parties and leaders: only party--Democratic Party for
Equatorial Guinea (PDGE), Brig. Gen. (Ret.) Teodoro OBIANG NGUEMA
MBASOGO, party leader
_#_Suffrage: universal adult at age NA
_#_Elections:
President--last held 25 June 1989 (next to be held 25 June 1996);
results--President Brig. Gen. (Ret.) Teodoro OBIANG NGUEMA MBASOGO was
reelected without opposition;
Chamber of People''s Representatives--last held 10 July 1988 (next
to be held 10 July 1993);
results--PDGE is the only party;
seats--(41 total) PDGE 41
_#_Communists: no significant number
_#_Member of: ACP, AfDB, BDEAC, CEEAC, ECA, FAO, FZ, G-77, IBRD,
ICAO, IDA, IFAD, ILO, IMF, IMO, INTERPOL, IOC, ITU, LORCS (associate),
NAM, OAS (observer), OAU, UDEAC, UN, UNCTAD, UNESCO, UNIDO, UPU, WHO
_#_Diplomatic representation: Ambassador Damaso OBIANG NDONG; Chancery
at 801 Second Avenue, Suite 1403, New York, NY 10017; telephone (212)
599-1523;
US--Ambassador (vacant); Charge d''Affaires William MITHOEFER;
Embassy at Calle de Los Ministros, Malabo (mailing address is P. O.
Box 597, Malabo; telephone [240] (9) 2185, 2406, 2507
_#_Flag: three equal horizontal bands of green (top), white, and red
with a blue isosceles triangle based on the hoist side and the coat of
arms centered in the white band; the coat of arms has six yellow
six-pointed stars (representing the mainland and five offshore islands)
above a gray shield bearing a silk-cotton tree and below which is a
scroll with the motto UNIDAD, PAZ, JUSTICIA (Unity, Peace, Justice)
_#_Long-form name: People''s Democratic Republic of Ethiopia
_#_Type: on 28 May 1991 the Ethiopian People''s Revolutionary
Democratic Front (EPRDF) took control in Addis Ababa; on 29 May 1991
Issayas AFEWORKE, secretary general of the Eritrean People''s Liberation
Front (EPLF), announced the formation of a provisional government in
Eritrea, in preparation for an eventual referendum on independence
for the province
_#_Capital: Addis Ababa
_#_Administrative divisions: 25 administrative regions (astedader
akababiwach, singular--astedader akababi) and 5
autonomous regions* (rasgez akababiwach, singular--rasgez
akababi); Addis Abeba (Addis Ababa), Arsi, Aseb*,
Asosa, Bale, Borena, Debub Gonder, Debub Shewa, Debub Welo, Dire
Dawa*, Ertra (Eritrea)*, Gambela, Gamo Gofa, Ilubabor, Kefa,
Metekel, Mirab Gojam, Mirab Harerge, Mirab Shewa, Misrak Gojam,
Misrak Harerge, Nazaret, Ogaden*, Omo, Semen Gonder,
Semen Shewa, Semen Welo, Sidamo, Tigray*, Welega
_#_Independence: oldest independent country in Africa and one of the
oldest in the world--at least 2,000 years
_#_Constitution: 12 September 1987
_#_Legal system: complex structure with civil, Islamic, common, and
customary law influences; has not accepted compulsory ICJ jurisdiction
_#_National holiday: National Revolution Day, 12 September (1974)
_#_Executive branch: president, vice president, Council of State
prime minister, five deputy prime ministers, Council of Ministers
_#_Legislative branch: unicameral National Assembly (Shengo)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Interim President Meles ZENAWI (since 1 June
1991);
Head of Government--Acting Prime Minister Tamrat LAYNE (since 6
June 1991)
_#_Political parties and leaders: only party--Workers'' Party of
Ethiopia (WPE)
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 10 September 1987 (next to be held September
1992);
results--MENGISTU Haile-Mariam elected by the National Assembly, but
resigned and left Ethiopia on 21 May 1991;
National Assembly--last held 14 June 1987 (next to be
held NA);
results--WPE was the only party;
seats--(835 total) WPE 835
_#_Other political or pressure groups: Oromo Liberation Front;
Ethiopian People''s Revolutionary Party (EPRP)
_#_Member of: ACP, AfDB, CCC, ECA, FAO, G-24, G-77,
IAEA, IBRD, ICAO, IDA, IFAD, IFC, IGADD, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, ISO, ITU, LORCS, NAM, OAU, UN, UNCTAD, UNESCO,
UNIDO, UPU, WFTU, WHO, WMO, WTO
_#_Diplomatic representation: Counselor, Charge d''Affaires ad
interim GIRMA Amare; Chancery at 2134 Kalorama Road NW, Washington DC
20008; telephone (202) 234-2281 or 2282;
US--Charge d''Affaires Robert G. HOUDEK; Embassy at Entoto Street,
Addis Ababa (mailing address is P.O. Box 1014, Addis Ababa);
telephone [251] (01) 550666
_#_Flag: three equal horizontal bands of green (top), yellow, and red;
Ethiopia is the oldest independent country in Africa and the colors of
her flag were so often adopted by other African countries upon
independence that they became known as the pan-African colors','2b64d3bd49527dfbd8452e2356c3d7cb7e4a4d7ba8bfed9e04cf8149967ec363','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bf8b0d60a707c47bf75f877cf47444cf45e9a408c086d92393d034162e6596a',1991,'SA','Saudi Arabia','government',68,'_#_Long-form name: none
_#_Type: French possession administered by Commissioner of
the Republic Daniel CONSTANTIN, resident in Reunion
_#_Long-form name: Colony of the Falkland Islands
_#_Type: dependent territory of the UK
_#_Capital: Stanley
_#_Administrative divisions: none (dependent territory of the UK)
_#_Independence: none (dependent territory of the UK)
_#_Constitution: 3 October 1985
_#_Legal system: English common law
_#_National holiday: Liberation Day, 14 June (1982)
_#_Executive branch: British monarch, governor, Executive Council
_#_Legislative branch: unicameral Legislative Council
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952);
Head of Government--Governor William Hugh FULLERTON (since NA
1988)
_#_Political parties: NA
_#_Suffrage: universal at age 18
_#_Elections:
Legislative Council--last held 11 October 1989 (next to be
held October 1994); results--percent of vote by party NA;
seats--(10 total, 8 elected) number of seats by party NA
_#_Member of: ICFTU
_#_Diplomatic representation: none (dependent territory of the UK)
_#_Flag: blue with the flag of the UK in the upper hoist-side quadrant
and the Falkland Island coat of arms in a white disk centered on the
outer half of the flag; the coat of arms contains a white ram (sheep
raising is the major economic activity) above the sailing ship Desire
(whose crew discovered the islands) with a scroll at the bottom bearing
the motto DESIRE THE RIGHT
_#_Long-form name: none
_#_Type: part of the Danish realm; self-governing overseas
administrative division of Denmark
_#_Capital: Torshavn
_#_Administrative divisions: none (self-governing overseas
administrative division of Denmark)
_#_Independence: part of the Danish realm; self-governing overseas
administrative division of Denmark
_#_Constitution: Danish
_#_Legal system: Danish
_#_National holiday: Birthday of the Queen, 16 April (1940)
_#_Executive branch: Danish monarch, high commissioner, prime
minister, deputy prime minister, Cabinet (Landsstyri)
_#_Legislative branch: unicameral Parliament (Logting)
_#_Judicial branch: none
_#_Leaders:
Chief of State--Queen MARGRETHE II (since 14 January 1972),
represented by High Commissioner Bent KLINTE (since NA);
Head of Government--Prime Minister Atli P. DAM (since 15
January 1991)
_#_Political parties and leaders:
two-party ruling coalition--Social Democratic Party, Atli P. DAM;
People''s Party, Jogvan SUNDSTEIN;
opposition--Cooperation Coalition Party, Pauli ELLEFSEN;
Republican Party, Signer HANSEN;
Progressive and Fishing Industry Party-Christian People''s Party
(PFIP-CPP), leader NA; Progress Party, leader NA; Home Rule Party, Hilmar
KASS
_#_Suffrage: universal at age 20
_#_Elections:
Faroese Parliament--last held 17 November 1990 (next to be held
November 1994); results--Social Democratic 27.4%, People''s Party 21.9%,
Cooperation Coalition Party 18.9%, Republican Party 14.7%, Home Rule
8.8%, PFIP-CPP 5.9%, other 2.4%;
seats--(32 total) two-party coalition 17 (Social Democratic 10, People''s
Party 7), Cooperation Coalition Party 6, Republican Party 4,
Home Rule 3, PFIP-CPP 2;
Danish Parliament--last held on 12 December 1990 (next to be
held by December 1994);
results--percent of vote by party NA;
seats--(2 total) Social Democratic 1, People''s Party 1; note--the
Faroe Islands elects two representatives to the Danish Parliament
_#_Communists: insignificant number
_#_Member of:
_#_Diplomatic representation: none (self-governing overseas
administrative division of Denmark)
_#_Flag: white with a red cross outlined in blue that extends to the
edges of the flag; the vertical part of the cross is shifted to the
hoist side in the style of the Dannebrog (Danish flag)
_#_Long-form name: Republic of Fiji
_#_Type: military coup leader Major General Sitiveni Rabuka formally
declared Fiji a republic on 6 October 1987
_#_Capital: Suva
_#_Administrative divisions: 4 divisions and 1 dependency*; Central,
Eastern, Northern, Rotuma*, Western
_#_Independence: 10 October 1970 (from UK)
_#_Constitution: 10 October 1970 (suspended 1 October 1987);
a new Constitution was proposed on 23 September 1988 and promulgated
on 25 July 1990
_#_Legal system: based on British system
_#_National holiday: Independence Day, 10 October (1970)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: the bicameral Parliament, consisting of an
upper house or Senate and a lower house or House of Representatives,
was dissolved following the coup of 14 May 1987; the Constitution of 23
September 1988 provides for a bicameral Parliament
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Ratu Sir Penaia Kanatabatu GANILAU
(since 5 December 1987);
Head of Government--Prime Minister Ratu Sir Kamisese MARA (since 5
December 1987); Deputy Prime Minister Josefata KAMIKAMICA (since NA
October 1991);
note--Ratu Sir Kamisese MARA served as prime minister from 10 October
1970 until the 5-11 April 1987 election; after a second coup led by
Maj. Gen. Sitiveni RABUKA on 25 September 1987, Ratu Sir Kamisese
MARA was reappointed as prime minister
_#_Political parties and leaders:
Fijian Political Party (primarily Fijian), leader NA;
National Federation (primarily Indian), Siddiq KOYA;
Western United Front (Fijian), Ratu Osea GAVIDI;
Fiji Labor Party, Adi Kuini BAVADRA
_#_Suffrage: none
_#_Elections:
House of Representatives--last held 14 May 1987 (next to be
held July 1992);
results--percent of vote by party NA;
seats--(70 total, with ethnic Fijians allocated 37 seats, ethnic
Indians 27 seats, and independents and other 6 seats) number of seats
by party NA
_#_Communists: some
_#_Member of: ACP, AsDB, CP, ESCAP, FAO, G-77, IBRD, ICAO, ICFTU, IDA,
IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, ITU, LORCS, PCA,
SPC, SPF, UN, UNCTAD, UNESCO, UNIDO, UNIFIL, UPU, WHO, WIPO, WMO
_#_Diplomatic representation: Charge d''Affaires Ratu Finau MARA;
Chancery at Suite 240, 2233 Wisconsin Avenue NW, Washington, DC 20007;
telephone (202) 337-8320; there is a Fijian Consulate in New York;
US--Ambassador Evelyn I. H. TEEGEN; Embassy at 31 Loftus Street,
Suva (mailing address is P. O. Box 218, Suva); telephone [679] 314-466 or
314-069
_#_Flag: light blue with the flag of the UK in the upper hoist-side
quadrant and the Fijian shield centered on the outer half of the flag;
the shield depicts a yellow lion above a white field quartered by the
cross of Saint George featuring stalks of sugarcane, a palm tree,
bananas, and a white dove
_#_Long-form name: Republic of Finland
_#_Type: republic
_#_Capital: Helsinki
_#_Administrative divisions: 12 provinces (laanit,
singular--laani); Ahvenanmaa, Hame, Keski-Suomi, Kuopio, Kymi,
Lappi, Mikkeli, Oulu, Pohjois-Karjala, Turku ja Pori, Uusimaa, Vaasa
_#_Independence: 6 December 1917 (from Soviet Union)
_#_Constitution: 17 July 1919
_#_Legal system: civil law system based on Swedish law; Supreme Court
may request legislation interpreting or modifying laws; accepts
compulsory ICJ jurisdiction, with reservations
_#_National holiday: Independence Day, 6 December (1917)
_#_Executive branch: president, prime minister, deputy prime minister,
Council of State (Valtioneuvosto)
_#_Legislative branch: unicameral Eduskunta
_#_Judicial branch: Supreme Court (Korkein Oikeus)
_#_Leaders:
Chief of State--President Mauno KOIVISTO (since 27 January 1982);
Head of Government--Prime Minister Esko AHO (since 26 April 1991);
Deputy Prime Minister Ilkka KANERVA (since 26 April 1991)
_#_Political parties and leaders:
government coalition--Center Party, Esko AHO;
National Coalition (Conservative) Party, Ilkka SUOMINEN; and
Swedish People''s Party, (Johan) Ole NORRBACK;
other parties--Social Democratic Party, Pertti PAASIO;
Leftist Alliance (Communist) consisting of People''s Democratic League and
Democratic Alternative, Claes ANDERSSON;
Green League, Heidi HAUTALA;
Rural Party, Heikki RIIHIJAERVI;
Finnish Christian League, Esko ALMGREN;
Liberal People''s Party, Kyosti LALLUKKA
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 31 January-1 February and 15 February
1988 (next to be held January 1994);
results--Mauno KOIVISTO 48%, Paavo VAYRYNEN 20%, Harri HOLKERI 18%;
Eduskunta--last held 17 March 1991 (next to be held March
1995);
results--Center Party 24.8%, Social Democratic Party 22.1%, National
Coalition (Conservative) Party 19.3%, Leftist Alliance (Communist)
10.1%, Green League 6.8%, Swedish People''s Party 5.5%, Rural 4.8%,
Finnish Christian League 3.1%, Liberal People''s Party 0.8%;
seats--(200 total) Center Party 55, Social Democratic Party 48,
National Coalition (Conservative) Party 40, Leftist Alliance (Communist)
19, Swedish People''s Party 12, Green League 10, Finnish Christian League
8, Rural 7, Liberal People''s Party 1
_#_Communists: 28,000 registered members; an additional 45,000 persons
belong to People''s Democratic League
_#_Other political or pressure groups:
Finnish Communist Party-Unity, Esko-Juhani TENNILA;
Constitutional Rightist Party;
Finnish Pensioners Party;
Communist Workers Party, Timo LAHDENMAKI
_#_Member of: AfDB, AG (observer), AsDB, BIS, CCC, CE, CSCE, EBRD,
ECE, EFTA, ESA (associate), FAO, G-9, GATT, IADB, IAEA, IBRD, ICAO, ICC,
ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC,
IOM (observer), ISO, ITU, LORCS, NAM (guest), NC, NEA, NIB, OAS
(observer), OECD, PCA, UN, UNCTAD, UNDOF, UNESCO, UNFICYP,
UNHCR, UNIDO, UNIFIL, UNIIMOG, UNMOGIP, UNTSO, UPU, WHO, WIPO,
WMO, WTO
_#_Diplomatic representation: Ambassador Jukka VALTASAARI; Chancery at
3216 New Mexico Avenue NW, Washington DC 20016; telephone (202) 363-2430;
there are Finnish Consulates General in Los Angeles and New York,
and Consulates in Chicago and Houston;
US--Ambassador John G. WEINMANN; Embassy at Itainen Puistotie
14A, SF-00140, Helsinki (mailing address is APO New York 09664);
telephone [358] (0) 171931
_#_Flag: white with a blue cross that extends to the edges of the
flag; the vertical part of the cross is shifted to the hoist side in
the style of the Dannebrog (Danish flag)
_#_Long-form name: French Republic
_#_Type: republic
_#_Capital: Paris
_#_Administrative divisions: metropolitan France--22 regions
(regions, singular--region); Alsace, Aquitaine, Auvergne,
Basse-Normandie, Bourgogne, Bretagne, Centre, Champagne-Ardenne, Corse,
Franche-Comte, Haute-Normandie, Ile-de-France, Languedoc-Roussillon,
Limousin, Lorraine, Midi-Pyrenees, Nord-Pas-de-Calais,
Pays de la Loire, Picardie, Poitou-Charentes,
Provence-Alpes-Cote d''Azur, Rhone-Alpes;
note--the 22 regions are subdivided into 96 departments; see separate
entries for the overseas departments (French Guiana, Guadeloupe,
Martinique, Reunion) and the territorial collectivities (Mayotte,
Saint Pierre and Miquelon)
_#_Dependent areas: Bassas da India, Clipperton Island, Europa Island,
French Polynesia, French Southern and Antarctic Lands, Glorioso Islands,
Juan de Nova Island, New Caledonia, Tromelin Island, Wallis and Futuna;
note--the US does not recognize claims to Antarctica
_#_Independence: unified by Clovis in 486, First Republic proclaimed
in 1792
_#_Constitution: 28 September 1958, amended concerning election of
president in 1962
_#_Legal system: civil law system with indigenous concepts; review of
administrative but not legislative acts
_#_National holiday: Taking of the Bastille, 14 July (1789)
_#_Executive branch: president, prime minister, Council of Ministers
(cabinet)
_#_Legislative branch: bicameral Parliament (Parlement) consists of an
upper house or Senate (Senat) and a lower house or National Assembly
(Assemblee Nationale)
_#_Judicial branch: Court of Cassation (Cour de Cassation)
_#_Leaders:
Chief of State--President Francois MITTERRAND (since 21 May
1981);
Head of Government--Prime Minister Edith CRESSON (since 15 May
1991)
_#_Political parties and leaders:
Rally for the Republic (RPR, formerly UDR), Jacques CHIRAC;
Union for French Democracy (UDF, federation of PR, CDS, and RAD),
Valery Giscard d''ESTAING;
Republican Party (PR), Gerard LONGUET;
Center for Social Democrats (CDS), Pierre MEHAIGNERIE;
Radical (RAD), Yves GALLARD;
Socialist Party (PS), Pierre MAUROY;
Left Radical Movement (MRG), Yves COLLIN;
Communist Party (PCF), Georges MARCHAIS;
National Front (FN), Jean-Marie LE PEN
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 8 May 1988 (next to be held May 1995);
results--Second Ballot Francois MITTERRAND 54%, Jacques CHIRAC 46%;
Senate--last held 24 September 1989 (next to be held September
1992); results--percent of vote by party NA;
seats--(321 total; 296 metropolitan France, 13 for overseas departments
and territories, and 12 for French nationals abroad) RPR 93,
UDF 143 (PR 53, CDS 65, RAD 25), PS 64, PCF 16, independents 2,
unknown 3;
National Assembly--last held 5 and 12 June 1988 (next to be held
June 1993);
results--Second Ballot PS-MRG 48.7%, RPR 23.1%, UDF 21%, PCF 3.4%,
other 3.8%;
seats--(577 total) PS 275, RPR 132, UDF 90, UDC 40, PCF 25, independents
15
_#_Communists: 700,000 claimed but probably closer to 150,000;
Communist voters, 2.8 million in 1988 election
_#_Other political or pressure groups: Communist-controlled labor
union (Confederation Generale du Travail) nearly 2.4 million
members (claimed); Socialist-leaning labor union (Confederation
Francaise Democratique du Travail or CFDT) about 800,000 members
est.; independent labor union (Force Ouvriere) 1 million members
(est.); independent white-collar union (Confederation Generale
des Cadres) 340,000 members (claimed); National Council of French
Employers (Conseil National du Patronat Francais--CNPF or Patronat)
_#_Member of: ACCT, AfDB, AG (observer), AsDB, BDEAC,
BIS, CCC, CDB, CE, CERN, COCOM, CSCE, EBRD, EC, ECA (associate),
ECE, ECLAC, EIB, ESA, ESCAP, FAO, FZ, GATT, G-5, G-7, G-10, IABD, IAEA,
IBRD, ICAO, ICC, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, IOM (observer), ISO, ITU, LORCS,
NATO, NEA, OAS (observer), OECD, PCA, SPC, UN, UNCTAD, UNESCO, UNHCR,
UNIDO, UNIFIL, UNRWA, UN Security Council, UN Trusteeship Council,
UNTSO, UPU, WCL, WEU, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Jacques ANDREANI; Chancery at
4101 Reservoir Road NW, Washington DC 20007; telephone (202) 944-6000;
there are French Consulates General in Boston, Chicago, Detroit, Houston,
Los Angeles, New Orleans, Miami, New York, San Francisco, and San Juan
(Puerto Rico);
US--Ambassador Walter J. P. CURLEY; Embassy at 2 Avenue
Gabriel, 75382 Paris Cedex 08 (mailing address is APO New York 09777);
telephone [33] (1) 42-96-12-02 or 42-61-80-75; there are US Consulates
General in Bordeaux, Lyon, Marseille, and Strasbourg
_#_Flag: three equal vertical bands of blue (hoist side), white, and
red; known as the French Tricouleur (Tricolor); the design and
colors have been the basis for a number of other flags, including those
of Belgium, Chad, Ireland, Ivory Coast, and Luxembourg; the official flag
for all French dependent areas
_#_Long-form name: Department of Guiana
_#_Type: overseas department of France
_#_Capital: Cayenne
_#_Administrative divisions: none (overseas department of France)
_#_Independence: none (overseas department of France)
_#_Constitution: 28 September 1958 (French Constitution)
_#_Legal system: French legal system
_#_National holiday: Taking of the Bastille, 14 July (1789)
_#_Executive branch: French president, commissioner of the republic
_#_Legislative branch: unicameral General Council and a unicameral
Regional Council
_#_Judicial branch: highest local court is the Court of Appeals
based in Martinique with jurisdiction over Martinique, Guadeloupe, and
_#_Long-form name: Kingdom of Saudi Arabia
_#_Type: monarchy
_#_Capital: Riyadh
_#_Administrative divisions: 14 emirates (imarat,
singular--imarah); Al Bahah, Al Hudud ash Shamaliyah,
Al Jawf, Al Madinah, Al Qasim, Al Qurayyat, Ar Riyad, Ash
Sharqiyah, Asir, Hail, Jizan, Makkah, Najran,
Tabuk
_#_Independence: 23 September 1932 (unification)
_#_Constitution: none; governed according to Sharia (Islamic law)
_#_Legal system: based on Islamic law, several secular codes have been
introduced; commercial disputes handled by special committees; has not
accepted compulsory ICJ jurisdiction
_#_National holiday: Unification of the Kingdom, 23 September (1932)
_#_Executive branch: monarch and prime minister, crown prince and
deputy prime minister, Council of Ministers
_#_Legislative branch: none
_#_Judicial branch: Supreme Council of Justice
_#_Leaders:
Chief of State and Head of Government--King and Prime Minister
FAHD bin Abd al-Aziz Al Saud (since 13 June 1982);
Crown Prince and Deputy Prime Minister ABDALLAH bin Abd al-Aziz Al
Saud (half-brother to the King, appointed heir to the throne 13 June
1982)
_#_Suffrage: none
_#_Elections: none
_#_Communists: negligible
_#_Member of: ABEDA, AfDB, AFESD, AL, AMF, CCC, ESCWA, FAO, G-19,
G-77, GCC, IAEA, IBRD, ICAO, ICC, IDA, IDB, IFAD, IFC, ILO, IMF, IMO,
INMARSAT, INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS, NAM,
OAPEC, OAS (observer), OIC, OPEC, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU,
WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador BANDAR Bin Sultan; Chancery
at 601 New Hampshire Avenue NW, Washington DC 20037; telephone (202)
342-3800; there are Saudi Arabian Consulates General in Houston, Los
Angeles, and New York;
US--Ambassador Charles W. FREEMAN, Jr.; Embassy at Collector Road
M, Diplomatic Quarter, Riyadh (mailing address is P. O. Box 9041, Riyadh
11143, or APO New York 09038); telephone [966] (1) 488-3800; there are US
Consulates General in Dhahran and Jiddah (Jeddah)
_#_Flag: green with large white Arabic script (that may be translated
as There is no God but God; Muhammad is the Messenger of God) above a
white horizontal saber (the tip points to the hoist side); green is the
traditional color of Islam
_#_Long-form name: Republic of Senegal
_#_Type: republic under multiparty democratic rule
_#_Capital: Dakar
_#_Administrative divisions: 10 regions (regions,
singular--region); Dakar, Diourbel, Fatick, Kaolack, Kolda, Louga,
Saint-Louis, Tambacounda, Thies, Ziguinchor
_#_Independence: 4 April 1960 (from France); The Gambia and Senegal
signed an agreement on 12 December 1981 (effective 1 February 1982) that
called for the creation of a loose confederation to be known as
Senegambia, but the agreement was dissolved on 30 September 1989
_#_Constitution: 3 March 1963, last revised in 1984
_#_Legal system: based on French civil law system; judicial review of
legislative acts in Supreme Court, which also audits the government''s
accounting office; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 4 April (1960)
_#_Executive branch: president, prime minister, Council of Ministers
(cabinet)
_#_Legislative branch: unicameral National Assembly (Assemblee
Nationale)
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State--President Abdou DIOUF (since 1 January 1981);
Head of Government--Prime Minister Habib THIAM (since 7 April
1991)
_#_Political parties and leaders:
Socialist Party (PS), President Abdou DIOUF;
Senegalese Democratic Party (PDS), Abdoulaye WADE;
13 other small uninfluential parties
_#_Suffrage: universal at age 21
_#_Elections:
President--last held 28 February 1988 (next to be held February
1993);
results--Abdou DIOUF (PS) 73%, Abdoulaye WADE (PDS) 26%, other 1%;
National Assembly--last held 28 February 1988 (next to be
held February 1993);
results--PS 71%, PDS 25%, other 4%;
seats--(120 total) PS 103, PDS 17
_#_Communists: small number of Communists and sympathizers
_#_Other political or pressure groups: students, teachers, labor,
Muslim Brotherhoods
_#_Member of: ACCT, ACP, AfDB, CCC, CEAO, ECA, ECOWAS, FAO, FZ, G-77,
GATT, IAEA, IBRD, ICAO, ICC, IDA, IDB, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, IOC, ISO (correspondent), ITU, LORCS, NAM,
OAU, OIC, PCA, UN, UNCTAD, UNESCO, UNIDO, UNIIMOG, UPU, WADB, WCL,
WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Ibra Deguene KA; Chancery at
2112 Wyoming Avenue NW, Washington DC 20008; telephone (202) 234-0540
or 0541;
US--Ambassador George E. MOOSE; Embassy on Avenue Jean XXIII at the
corner of Avenue Kleber, Dakar (mailing address is B. P. 49, Dakar);
telephone [221] 23-42-96 or 23-34-24
_#_Flag: three equal vertical bands of green (hoist side), yellow, and
red with a small green five-pointed star centered in the yellow band;
uses the popular pan-African colors of Ethiopia
_#_Long-form name: Republic of Seychelles
_#_Type: republic
_#_Capital: Victoria
_#_Administrative divisions: 23 administrative districts;
Anse aux Pins, Anse Boileau, Anse Etoile, Anse Louis, Anse Royale,
Baie Lazare, Baie Sainte Anne, Beau Vallon, Bel Air, Bel Ombre, Cascade,
Glacis, Grand'' Anse (on Mahe Island), Grand'' Anse (on Praslin Island),
La Digue, La Riviere Anglaise, Mont Buxton, Mont Fleuri, Plaisance,
Pointe La Rue, Port Glaud, Saint Louis, Takamaka
_#_Independence: 29 June 1976 (from UK)
_#_Constitution: 5 June 1979
_#_Legal system: based on English common law, French civil law, and
customary law
_#_National holiday: Liberation Day (anniversary of coup), 5 June
(1977)
_#_Executive branch: president, Council of Ministers
_#_Legislative branch: unicameral People''s Assembly (Assemblee
du Peuple)
_#_Judicial branch: Court of Appeal, Supreme Court
_#_Leaders:
Chief of State and Head of Government--President France Albert
RENE (since 5 June 1977)
_#_Political parties and leaders: only party--Seychelles People''s
Progressive Front (SPPF), France Albert RENE
_#_Suffrage: universal at age 17
_#_Elections:
President--last held 9-11 June 1989 (next to be held June 1994);
results--President France Albert RENE reelected without opposition;
National Assembly--last held 5 December 1987 (next to be
held December 1992);
results--SPPF is the only party;
seats--(25 total, 23 elected) SPPF 23
_#_Communists: negligible, although some Cabinet ministers
espouse pro-Soviet line
_#_Other political or pressure groups: trade unions, Roman Catholic
Church
_#_Member of: ACCT, ACP, AfDB, C, ECA, FAO, G-77, IBRD, ICAO, ICFTU,
IFAD, IFC, ILO, IMF, IMO, INTERPOL, IOC, NAM, OAU, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCL, WHO, WMO
_#_Diplomatic representation: Second Secretary, Charge d''Affaires
ad interim Marc R. MARENGO; Chancery (temporary) at 820 Second Avenue,
Suite 201, New York, NY 10017; telephone (212) 687-9766;
US--Ambassador James B. MORAN; Embassy at 4th Floor, Victoria
House, Victoria (mailing address is Box 148, Victoria, and Victoria
House, Box 251, Victoria, Mahe, Seychelles, or APO New York 09030-0006);
telephone (248) 25256
_#_Flag: three horizontal bands of red (top), white (wavy), and green;
the white band is the thinnest, the red band is the thickest
_#_Long-form name: Republic of Sierra Leone
_#_Type: republic under presidential regime
_#_Capital: Freetown
_#_Administrative divisions: 4 provinces; Eastern, Northern, Southern,
Western
_#_Independence: 27 April 1961 (from UK)
_#_Constitution: 14 June 1978
_#_Legal system: based on English law and customary laws indigenous to
local tribes; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Republic Day, 27 April (1961)
_#_Executive branch: president, two vice presidents, Cabinet
_#_Legislative branch: unicameral House of Representatives
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--President Gen. Joseph
Saidu MOMOH (since 28 November 1985); First Vice President Abu Bakar
KAMARA (since 4 April 1987); Second Vice President Salia JUSU-SHERIFF
(since 4 April 1987)
_#_Political parties and leaders: only party--All People''s Congress
(APC), Gen. Joseph Saidu MOMOH; note--constitutional referendum to
adopt a multiparty system is scheduled for June 1991
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 1 October 1985 (next to be held October 1992);
results--Gen. Joseph Saidu MOMOH was elected without opposition;
House of Representatives-','3dc4c98c0bafc68fd6aaaec457121d190c4dc878250ec8246b103e05d8c136c6','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('beaf516909ca8b9a8d0831fee1b83f9c6ec85bff1d7ccd1d571c9e4606443984',1991,'SA','Saudi Arabia','government',69,'-last held 30 May 1986 (next to be
held February 1992);
results--APC is the only party;
seats--(127 total, 105 elected) APC 105
_#_Communists: no party, although there are a few Communists and a
slightly larger number of sympathizers
_#_Member of: ACP, AfDB, C, CCC, ECA, ECOWAS, FAO, G-77, GATT, IAEA,
IBRD, ICAO, ICFTU, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INTERPOL, IOC,
ITU, LORCS, NAM, OAU, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO,
WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador George CAREW; Chancery at
1701 19th Street NW, Washington DC 20009; telephone (202) 939-9261;
US--Ambassador Johnny YOUNG; Embassy at the corner of Walpole and
Siaka Stevens Street, Freetown; telephone [232] (22) 26481
_#_Flag: three equal horizontal bands of light green (top), white, and
light blue
_#_Long-form name: Republic of Singapore
_#_Type: republic within Commonwealth
_#_Capital: Singapore
_#_Administrative divisions: none
_#_Independence: 9 August 1965 (from Malaysia)
_#_Constitution: 3 June 1959, amended 1965; based on preindependence
State of Singapore Constitution
_#_Legal system: based on English common law; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: National Day, 9 August (1965)
_#_Executive branch: president, prime minister, two deputy prime
ministers, Cabinet
_#_Legislative branch: unicameral Parliament
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President WEE Kim Wee (since 3 September 1985);
Head of Government--Prime Minister GOH Chok Tong (since 28 November
1990); Deputy Prime Minister LEE Hsien Loong (since 28 November 1990);
Deputy Prime Minister ONG Teng Cheong (since 2 January 1985)
_#_Political parties and leaders:
government--People''s Action Party (PAP), LEE Kuan Yew, secretary
general;
opposition--Workers'' Party (WP), J. B. JEYARETNAM;
Singapore Democratic Party (SDP), CHIAM See Tong;
National Solidarity Party (NSP), SOON Kia Seng;
United People''s Front (UPF), Harbans SINGH;
Barisan Sosialis (BS, Socialist Front), leader NA
_#_Suffrage: universal and compulsory at age 20
_#_Elections:
President--last held 31 August 1989 (next to be held August 1993);
results--President WEE Kim Wee was reelected by Parliament without
opposition;
Parliament--last held 3 September 1988 (next to be held 31
August 1991);
results--PAP 61.8%, WP 18.4%, SDP 11.5%, NSP 3.7%, UPF 1.3%, other 3.3%;
seats--(81 total) PAP 80, SDP 1; note--BS has 1 nonvoting seat
_#_Communists: 200-500; Barisan Sosialis infiltrated by Communists;
note--Communist party illegal
_#_Member of: APEC, AsDB, ASEAN, C, CCC, CP, ESCAP, G-77, GATT, IAEA,
IBRD, ICAO, ICC, ICFTU, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL,
IOC, ISO, ITU, LORCS, NAM, UN, UNCTAD, UPU, WHO, WMO
_#_Diplomatic representation: Ambassador S. R. NATHAN;
Chancery at 1824 R Street NW, Washington DC 20009; telephone (202)
667-7555;
US--Ambassador Robert D. ORR; Embassy at 30 Hill Street,
Singapore 0617 (mailing address is FPO San Francisco 96699); telephone
[65] 338-0251
_#_Flag: two equal horizontal bands of red (top) and white; near
the hoist side of the red band, there is a vertical, white crescent
(closed portion is toward the hoist side) partially enclosing five white
five-pointed stars arranged in a circle
_#_Long-form name: none
_#_Type: independent parliamentary state within Commonwealth
_#_Capital: Honiara
_#_Administrative divisions: 7 provinces and 1 town*; Central,
Guadalcanal, Honiara*, Isabel, Makira, Malaita, Temotu, Western
_#_Independence: 7 July 1978 (from UK; formerly British Solomon
Islands)
_#_Constitution: 7 July 1978
_#_Legal system: common law
_#_National holiday: Independence Day, 7 July (1978)
_#_Executive branch: British monarch, governor general, prime
minister, Cabinet
_#_Legislative branch: unicameral National Parliament
_#_Judicial branch: High Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor General George LEPPING (since 27 June 1989,
previously acted as governor general since 7 July 1988);
Head of Government--Prime Minister Solomon MAMALONI (since 28
March 1989);
Deputy Prime Minister Sir Baddeley DEVESI (since NA October 1990)
_#_Political parties and leaders:
People''s Alliance Party (PAP);
United Party (UP), Sir Peter KENILOREA;
Solomon Islands Liberal Party (SILP), Bartholemew ULUFA''ALU;
Nationalist Front for Progress (NFP), Andrew NORI;
Labor Party (LP), Joses TUHANUKU
_#_Suffrage: universal at age 21
_#_Elections:
National Parliament--last held 22 February 1989 (next to be held
February 1993);
results--percent of vote by party NA;
seats--(38 total) PAP 13, UP 6, NFP 4, SILP 4, LP 2, independents 9
_#_Member of: ACP, AsDB, C, ESCAP, FAO, G-77, IBRD, ICAO, IDA, IFAD,
IFC, ILO, IMF, IMO, IOC, ITU, SPC, SPF, UN, UNCTAD, UPU, WFTU, WHO,
WMO
_#_Diplomatic representation: Ambassador (vacant) resides in Honiara
(Solomon Islands);
US--the ambassador in Papua New Guinea is accredited to the
Solomon Islands; Embassy at Mud Alley, Honiara (mailing address is
American Embassy, P. O. Box 561, Honiara); telephone (677) 23890
_#_Flag: divided diagonally by a thin yellow stripe from the lower
hoist-side corner; the upper triangle (hoist side) is blue with five
white five-pointed stars arranged in an X pattern; the lower
triangle is green
_#_Long-form name: Somali Democratic Republic
_#_Type: republic
_#_Capital: Mogadishu
_#_Administrative divisions: 16 regions (plural--NA,
singular--gobolka); Bakool, Banaadir, Bari, Bay, Galguduud, Gedo,
Hiiraan, Jubbada Dhexe, Jubbada Hoose, Mudug, Nugaal, Sanaag, Shabeellaha
Dhexe, Shabeellaha Hoose, Togdheer, Woqooyi Galbeed
_#_Independence: 1 July 1960 (from a merger of British Somaliland,
which became independent from the UK on 26 June 1960, and Italian
Somaliland, which became independent from the Italian-administered UN
trusteeship on 1 July 1960, to form the Somali Republic)
_#_Constitution: 25 August 1979, presidential approval 23 September
1979
_#_National holiday: Anniversary of the Revolution, 21 October (1969)
_#_Executive branch: president, two vice presidents, prime minister,
Council of Ministers (cabinet)
_#_Legislative branch: unicameral People''s Assembly (Golaha Shacbiga)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Interim President ALI Mahdi Mohamed (since 27
January 1991);
Head of Government--Prime Minister OMAR Arteh Ghalib
(since 27 January 1991); Deputy Prime Minister MOHAMED Abshir Mussa
(since 27 January 1991)
_#_Political parties and leaders: the United Somali Congress (USC)
ousted the former regime on 27 January 1991; note--formerly the only
party was the Somali Revolutionary Socialist Party (SRSP), headed by
former President and Commander in Chief of the Army Maj. Gen. Mohamed
Siad BARRE
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 23 December 1986 (next to be held
NA);
results--President Siad was reelected without opposition;
People''s Assembly--last held 31 December 1984 (next to be held NA);
results--SRSP was the only party;
seats--(177 total, 171 elected) SRSP 171;
note--the United Somali Congress (USC) ousted the regime of Maj. Gen.
Mohamed SIAD Barre on 27 January 1991; the provisional government
has promised that a democratically elected government will be
established
_#_Communists: probably some Communist sympathizers in the government
hierarchy
_#_Member of: ACP, AfDB, AFESD, AL, AMF, CAEU, ECA, FAO, G-77, IBRD,
ICAO, IDA, IDB, IFAD, IFC, IGADD, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC,
IOM (observer), ITU, LORCS, NAM, OAU, OIC, UN, UNCTAD, UNESCO,
UNHCR, UNIDO, UPU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador ABDIKARIM Ali Omar; Chancery
at Suite 710, 600 New Hampshire Avenue NW, Washington DC 20037;
telephone (202) 342-1575; there is a Somali Consulate General in
New York;
US--Ambassador James K. BISHOP; Embassy at K-7, AFGOI Road,
Mogadishu (mailing address is P. O. Box 574, Mogadishu); telephone
[252] (01) 39971; note--US Embassy evacuated and closed indefinitely in
January 1991
_#_Flag: light blue with a large white five-pointed star in the
center; design based on the flag of the UN (Italian Somaliland was a UN
trust territory)
_#_Long-form name: Republic of South Africa; abbreviated RSA
_#_Type: republic
_#_Capital: administrative, Pretoria; legislative, Cape Town;
judicial, Bloemfontein
_#_Administrative divisions: 4 provinces; Cape, Natal, Orange Free
State, Transvaal; there are 10 homelands not recognized by the US--4
independent (Bophuthatswana, Ciskei, Transkei, Venda) and 6 other
(Gazankulu, Kangwane, KwaNdebele, KwaZulu, Lebowa, QwaQwa)
_#_Independence: 31 May 1910 (from UK)
_#_Constitution: 3 September 1984
_#_Legal system: based on Roman-Dutch law and English common law;
accepts compulsory ICJ jurisdiction, with reservations
_#_National holiday: Republic Day, 31 May (1910)
_#_Executive branch: state president, Executive Council (cabinet),
Ministers'' Councils (from the three houses of Parliament)
_#_Legislative branch: tricameral Parliament (Parlement) consists of
the House of Assembly (Volksraad; whites), House of Representatives
(Raad van Verteenwoordigers; Coloreds), and House of Delegates
(Raad van Afgevaardigdes; Indians)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--State President
Frederik W. DE KLERK (since 13 September 1989)
_#_Political parties and leaders:
white political parties and leaders--National Party (NP), Frederik
W. DE KLERK (majority party);
Conservative Party (CP), Dr. Andries P. TREURNICHT (official opposition
party);
Herstigte National Party (HNP), Jaap MARAIS;
Democratic Party (DP), Zach DE BEER;
Colored political parties and leaders--Labor Party (LP), Allan
HENDRICKSE (majority party);
Democratic Reform Party (DRP), Carter EBRAHIM;
United Democratic Party (UDP), Jac RABIE;
Freedom Party;
Indian political parties and leaders--Solidarity, J. N. REDDY
(majority party);
National People''s Party (NPP), Amichand RAJBANSI;
Merit People''s Party
_#_Suffrage: universal at age 18, but voting rights are racially based
_#_Elections:
House of Assembly (whites)--last held 6 September 1989 (next to
be held by March 1995);
results--NP 58%, CP 23%, DP 19%;
seats--(178 total, 166 elected) NP 103, CP 41, DP 34;
House of Representatives (Coloreds)--last held 6 September 1989
(next to be held by September 1994);
results--percent of vote by party NA;
seats--(85 total, 80 elected) LP 69, DRP 5, UDP 3, Freedom Party 1,
independents 2;
House of Delegates (Indians)--last held 6 September 1989
(next to be held by September 1994);
results--percent of vote by party NA;
seats--(45 total, 40 elected) Solidarity 16, NPP 9, Merit People''s
Party 3, United Party 2, Democratic Party 2, People''s Party 1,
National Federal Party 1, independents 6
_#_Communists: small Communist party legalized in 1990 after
30-year ban, Daniel TLOOME, chairman, and Joe SLOVO, general secretary
_#_Other political or pressure groups:
African National Congress (ANC), Nelson MANDELA, president;
Pan-Africanist Congress (PAC), Clarence MAKWETU, president
_#_Member of: BIS, CCC, ECA, GATT, IAEA, IBRD, ICAO, ICC, IDA, IFC,
IMF, INTELSAT, ISO, ITU, LORCS, SACU, UN, UNCTAD, WFTU, WHO, WIPO,
WMO (suspended)
_#_Diplomatic representation: Ambassador Harry SCHWARZ;
Chancery at 3051 Massachusetts Avenue NW, Washington DC 20008;
telephone (202) 232-4400; there are South African Consulates General
in Beverly Hills (California), Chicago, Houston, and New York;
US--Ambassador William L. SWING; Embassy at Thibault House,
225 Pretorius Street, Pretoria; telephone [27] (12) 28-4266; there are
US Consulates General in Cape Town, Durban, and Johannesburg
_#_Flag: actually four flags in one--three miniature flags reproduced
in the center of the white band of the former flag of the Netherlands
which has three equal horizontal bands of orange (top), white, and blue;
the miniature flags are a vertically hanging flag of the old Orange Free
State with a horizontal flag of the UK adjoining on the hoist side and a
horizontal flag of the old Transvaal Republic adjoining on the other side
_#_Long-form name: South Georgia and the South Sandwich Islands (no
short-form name)
_#_Type: dependent territory of the UK
_#_Capital: Grytviken on South Georgia is the garrison town
_#_Administrative divisions: none (dependent territory of the UK)
_#_Independence: none (dependent territory of the UK)
_#_Constitution: 3 October 1985
_#_Legal system: English common law
_#_National holiday: Liberation Day, 14 June (1982)
_#_Executive branch: British monarch, commissioner
_#_Legislative branch: none
_#_Judicial branch: none
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Commissioner William Hugh FULLERTON (since 1988; resident
at Stanley, Falkland Islands)
_#_Long-form name: Union of Soviet Socialist Republics; abbreviated
USSR
_#_Type: in transition to multiparty federal system
_#_Capital: Moscow
_#_Administrative divisions: 1 soviet federative socialist republic*
(sovetskaya federativnaya sotsialistcheskaya respublika) and 14 soviet
socialist republics (sovetskiye sotsialisticheskiye respubliki,
singular--sovetskaya sotsialisticheskaya respublika);
Armenian Soviet Socialist Republic, Azerbaijan Soviet Socialist Republic,
Belorussian (Byelorussian) Soviet Socialist Republic,
Estonian Soviet Socialist Republic, Georgian Soviet Socialist Republic,
Kazakh Soviet Socialist Republic, Kirghiz Soviet Socialist Republic,
Latvian Soviet Socialist Republic, Lithuanian Soviet Socialist Republic,
Russian Soviet Federative Socialist Republic*,
Soviet Socialist Republic of Moldova, Tajik Soviet Socialist Republic,
Turkmen Soviet Socialist Republic, Ukrainian Soviet Socialist Republic,
Uzbek Soviet Socialist Republic; note--Russian Soviet Federative
Socialist Republic is often abbreviated RSFSR and Soviet Socialist
Republic is often abbreviated SSR; the parliaments in Armenia,
Azerbaijan, Estonia, Georgia, Latvia, and Lithuania have removed the
words Soviet Socialist from the names of their republics, but the central
government has not recognized those changes; the parliament in Kirghiziya
changed the name Kirghiz Soviet Socialist Republic to Republic of
Kyrgyzstan, but the central government has not recognized that change
_#_Independence: 30 December 1922 (Union of Soviet Socialist Republics
established)
_#_Constitution: 7 October 1977
_#_Legal system: civil law system as modified by Communist legal
theory; no judicial review of legislative acts; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: Great October Socialist Revolution,
7-8 November (1917)
_#_Executive branch: president
_#_Legislative branch: the Congress of People''s Deputies (S''ezd
Narodnykh Deputatov) is the supreme organ of USSR state power and
selects the bicameral Supreme Soviet (Verkhovnyi Sovyet) which
consists of two coequal houses--Soviet of the Union (Soviet Soiuza)
and Soviet of Nationalities (Soviet Natsional''nostei)
_#_Judicial branch: Supreme Court of the USSR
_#_Leaders:
Chief of State--President Mikhail Sergeyevich GORBACHEV
(since 14 March 1990; former General Secretary of the Central Committee
of the Communist Party since 11 March 1985--resigned August 1991);
Head of Government--Prime Minister (vacant); Chairman of the
Committee for the Operational Management of the USSR National
Economy Ivan SILAYEV (since 24 August 1991)
_#_Political parties and leaders: nascent multiparty system
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 14 March 1990 (next to be held NA 1995);
results--Mikhail Sergeyevich GORBACHEV was elected by the Congress of
People''s Deputies;
Congress of People''s Deputies--last held 17 December 1990
(next to be held NA);
results--NA;
seats--(2,250 total) CPSU NA, non-CPSU NA;
note--dissolved September 1991
USSR Supreme Soviet--consists of the Council of the Union and
the Council of Republics;
Council of the Union--last held Spring 1991
(next to be held Fall 1991);
results--NA;
seats--(271 total) CPSU NA, non-CPSU NA;
Council of Republics--last held Spring 1991
(next to be held Fall 1991);
results--NA;
seats--(271 total) CPSU NA, non-CPSU NA;
note--to be reconstituted as a new legislature--date not set
_#_Communists: prior to August 1991 about 15 million party members,
with membership declining
_#_Other political or pressure groups: formal parties, regional
popular fronts, trade unions, and informal organizations
_#_Member of: CSCE, ECE, ESCAP, IAEA, IBEC, ICAO, ICFTU,
IIB, ILO, IMO, INMARSAT, INTERPOL, IOC, ISO, ITU, LORCS, PCA, UN, UNCTAD,
UNESCO, UNIDO, UN Security Council, UN Trusteeship Council, UNTSO, UPU,
WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Viktor KOMPLEKTOV;
Chancery at 1125 16th Street NW, Washington DC 20036;
telephone (202) 628-7551 or 8548; there is a Soviet Consulate General
in San Francisco;
US--Ambassador Robert S. STRAUSS; Embassy at Ulitsa Chaykovskogo
19/21/23, Moscow (mailing address is APO New York 09862);
telephone [7] (095) 252-2450 through 59; there is a US Consulate General
in St. Petersburg (formerly Leningrad)
_#_Flag: red with the yellow silhouette of a crossed hammer and sickle
below a yellow-edged five-pointed red star in the upper hoist-side corner
_#_Long-form name: Kingdom of Spain
_#_Type: parliamentary monarchy
_#_Capital: Madrid
_#_Administrative divisions: 17 autonomous communities (comunidades
autonomas, singular--comunidad autonoma); Andalucia, Aragon,
Asturias, Canarias, Cantabria, Castilla-La Mancha, Castilla y Leon,
Cataluna, Communidad Valencia, Extremadura, Galicia, Islas Baleares,
La Rioja, Madrid, Murcia, Navarra, Pais Vasco; note--there are five
places of sovereignty on and off the coast of Morocco (Ceuta, Mellila,
Islas Chafarinas, Penon de Alhucemas, and Penon de Velez
de la Gomera) with administrative status unknown
_#_Independence: 1492 (expulsion of the Moors and unification)
_#_Constitution: 6 December 1978, effective 29 December 1978
_#_Legal system: civil law system, with regional applications;
does not accept compulsory ICJ jurisdiction
_#_National holiday: National Day, 12 October
_#_Executive branch: monarch, president of the government (prime
minister), deputy prime minister, Council of Ministers (cabinet),
Council of State
_#_Legislative branch: bicameral The General Courts or National
Assembly (Las Cortes Generales) consists of an upper house or Senate
(Senado) and a lower house or Congress of Deputies (Congreso de los
Diputados)
_#_Judicial branch: Supreme Court (Tribunal Supremo)
_#_Leaders:
Chief of State--King JUAN CARLOS I (since 22 November 1975);
Head of Government--Prime Minister Felipe GONZALEZ Marquez
(since 2 December 1982); Deputy Prime Minister Narcis SERRA (since
13 March 1991)
_#_Political parties and leaders: principal national parties, from
right to left--Popular Party (PP), Jose Maria AZNAR;
Popular Democratic Party (PDP), Luis DE GRANDES;
Social Democratic Center (CDS), Adolfo SUAREZ Gonzalez;
Spanish Socialist Workers Party (PSOE), Felipe GONZALEZ Marquez;
Socialist Democracy Party (DS), Ricardo Garcia DAMBORENEA;
Spanish Communist Party (PCE), Julio ANGUITA;
chief regional parties--
Convergence and Unity (CiU), Jordi PUJOL Saley, in Catalonia;
Basque Nationalist Party (PNV), Xabier ARZALLUS;
Basque Solidarity (EA), Carlos GARAICOETXEA Urizza;
Basque Popular Unity (HB), Jon IDIGORAS;
Basque Left (EE), Kepa AULESTIA;
Andalusian Party (PA), Pedro PACHECO;
Independent Canary Group (AIC);
Aragon Regional Party (PAR);
Valencian Union (UV)
_#_Suffrage: universal at age 18
_#_Elections:
Senate --last held 29 October 1989 (next to be held October 1993);
results--NA;
seats (208) PSOE 106, PP 79, CiU 10, PNV 4, HB 3, AIC 1, other 5;
Congress of Deputies--last held 29 October 1989 (next to be held
October 1993); results--PSOE 39.6%, PP 25.8%, CDS 9%, Communist-led
coalition (IU) 9%, CiU 5%, Basque Nationalist Party 1.2%, HB 1%,
Andalusian Party 1%, other 8.4%;
seats--(350 total) PSOE 175, PP 106, CiU 18, IU 17, CDS 14, PNV 5,
HB 4, other 11
_#_Communists: PCE membership declined from a possible high of
160,000 in 1977 to roughly 60,000 in 1987; the party gained almost
1 million voters and 10 deputies in the 1989 election; voters came
mostly from the disgruntled socialist left; remaining strength is in
labor, where it dominates the Workers Commissions trade union (one of
the country''s two major labor centrals), which claims a membership of
about 1 million; experienced a modest recovery in 1986 national
election, nearly doubling the share of the vote it received in 1982
_#_Other political or pressure groups: on the extreme left, the Basque
Fatherland and Liberty (ETA) and the First of October Antifascist
Resistance Group (GRAPO) use terrorism to oppose the government; free
labor unions (authorized in April 1977) include the Communist-dominated
Workers Commissions (CCOO); the Socialist General Union of Workers (UGT),
and the smaller independent Workers Syndical Union (USO); the Catholic
Church; business and landowning interests; Opus Dei; university students
_#_Member of: AG (observer), AsDB, BIS, CCC, CE, CERN, CSCE, EBRD,
EC, ECE, ECLAC, EIB, ESA, FAO, G-8, GATT, IADB, IAEA, IBRD, ICAO, ICC,
ICFTU, IDA, IEA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL,
IOC, IOM (observer), ISO, ITU, LAIA (observer), LORCS, NAM (guest),
NATO, NEA, OAS (observer), OECD, PCA, UN, UNAVEM, UNCTAD, UNESCO, UNIDO,
UPU, WCL, WEU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Jaime de OJEDA; Chancery at
2700 15th Street NW, Washington DC 20009; telephone (202) 265-0190 or
0191; there are Spanish Consulates General in Boston, Chicago, Houston,
Los Angeles, Miami, New Orleans, New York, San Francisco, and San Juan
(Puerto Rico);
US--Ambassador Joseph ZAPPALA; Embassy at Serrano 75, 28006 Madrid
(mailing address is APO New York 09285); telephone [34] (1) 577-4000;
there is a US Consulate General in Barcelona and a Consulate in Bilbao
_#_Flag: three horizontal bands of red (top), yellow (double width),
and red with the national coat of arms on the hoist side of the yellow
band; the coat of arms includes the royal seal framed by the Pillars of
Hercules which are the two promontories (Gibraltar and Ceuta) on either
side of the eastern end of the Strait of Gibraltar
_#_Long-form name: none
_#_Long-form name: Democratic Socialist Republic of Sri Lanka
_#_Type: republic
_#_Capital: Colombo
_#_Administrative divisions: 24 districts; Amparai, Anuradhapura,
Badulla, Batticaloa, Colombo, Galle, Gampaha, Hambantota, Jaffna,
Kalutara, Kandy, Kegalla, Kurunegala, Mannar, Matale, Matara, Moneragala,
Mullaittivu, Nuwara Eliya, Polonnaruwa, Puttalam, Ratnapura, Trincomalee,
Vavuniya; note--the administrative structure may now include 8 provinces
(Central, North Central, North Eastern, North Western, Sabaragamuwa,
Southern, Uva, and Western) and 25 districts (with Kilinochchi added to
the existing districts)
_#_Independence: 4 February 1948 (from UK; formerly Ceylon)
_#_Constitution: 31 August 1978
_#_Legal system: a highly complex mixture of English common law,
Roman-Dutch, Muslim, and customary law; has not accepted compulsory ICJ
jurisdiction
_#_National holiday: Independence and National Day, 4 February (1948)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: unicameral Parliament
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Ranasinghe PREMADASA (since 2 January
1989);
Head of Government--Prime Minister Dingiri Banda WIJETUNGE (since
6 March 1989)
_#_Political parties and leaders:
United National Party (UNP), Ranasinghe PREMADASA;
Sri Lanka Freedom Party (SLFP), Sirimavo BANDARANAIKE;
Sri Lanka Muslim Congress (SLMC), M. H. M. ASHRAFF;
All Ceylon Tamil Congress (ACTC), Kumar PONNAMBALAM;
People''s United Front (MEP, or Mahajana Eksath Peramuna), Dinesh
GUNAWARDENE;
Eelam Democratic Front (EDF), Edward Sebastian PILLAI;
Tamil United Liberation Front (TULF), leader (vacant);
Eelam Revolutionary Organization of St','3825570199b3b0f88132888e4e876de3dd65ffa193651aee0eb1bae2b9dbac8a','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c314384ec3ae5b83a1ee999203b6ae90436492ddd2bc9752eabd7109bf2e0a5',1991,'SA','Saudi Arabia','government',70,'udents (EROS), Velupillai
BALAKUMARAN;
New Socialist Party (NSSP, or Nava Sama Samaja Party),
Vasudeva NANAYAKKARA;
Lanka Socialist Party/Trotskyite (LSSP, or Lanka Sama Samaja Party),
Colin R. de SILVA;
Sri Lanka People''s Party (SLMP, or Sri Lanka Mahajana Party),
Chandrika Bandaranaike KUMARANATUNGA;
Communist Party/Moscow (CP/M), K. P. SILVA;
Communist Party/Beijing (CP/B), N. SHANMUGATHASAN;
note--the United Socialist Alliance (USA) includes the NSSP, LSSP,
SLMP, CP/M, and CP/B
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 19 December 1988 (next to be held
December 1994);
results--Ranasinghe PREMADASA (UNP) 50%,
Sirimavo BANDARANAIKE (SLFP) 45%, other 5%;
Parliament--last held 15 February 1989
(next to be held by February 1995);
results--UNP 51%, SLFP 32%, SLMC 4%, TULF 3%, USA 3%, EROS 3%, MEP 1%,
other 3%;
seats--(225 total) UNP 125, SLFP 67, other 33
_#_Other political or pressure groups: Liberation Tigers of Tamil
Eelam (LTTE) and other smaller Tamil separatist groups; Janatha Vimukthi
Peramuna (JVP or People''s Liberation Front); Buddhist clergy; Sinhalese
Buddhist lay groups; labor unions
_#_Member of: AsDB, C, CCC, CP, ESCAP, FAO, G-24, G-77, GATT, IAEA,
IBRD, ICAO, ICC, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS, NAM, PCA, SAARC, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador W. Susanta De ALWIS; Chancery
at 2148 Wyoming Avenue NW, Washington DC 20008; telephone (202) 483-4025
through 4028; there is a Sri Lankan Consulate in New York;
US--Ambassador Marion V. CREEKMORE, Jr.; Embassy at 210 Galle Road,
Colombo 3 (mailing address is P. O. Box 106, Colombo); telephone [94] (1)
448007
_#_Flag: yellow with two panels; the smaller hoist-side panel has two
equal vertical bands of green (hoist side) and orange; the other panel is
a large dark red rectangle with a yellow lion holding a sword and there
is a yellow bo leaf in each corner; the yellow field appears as a border
that goes around the entire flag and extends between the two panels
_#_Long-form name: Republic of the Sudan
_#_Type: military; civilian government suspended and martial law
imposed after 30 June 1989 coup
_#_Capital: Khartoum
_#_Administrative divisions: 9 states (wilayat,
singular--wilayat or wilayah*); Aali an Nil,
Al Wusta*, Al Istiwaiyah*, Al Khartum,
Ash Shamaliyah*, Ash Sharqiyah*, Bahr al Ghazal,
Darfur, Kurdufan
_#_Independence: 1 January 1956 (from Egypt and UK; formerly
Anglo-Egyptian Sudan)
_#_Constitution: 12 April 1973, suspended following coup of 6 April
1985; interim constitution of 10 October 1985 suspended following coup of
30 June 1989
_#_Legal system: based on English common law and Islamic law;
as of 20 January 1991, the Revolutionary Command Council imposed Islamic
law in the six northern states of Al Wusta, Al Khartum, Ash
Shamaliyah, Ash Sharqiyah, Darfur, and Kurdufan; the
council is still studying criminal provisions under Islamic law; Islamic
law will apply to all residents of the six northern states regardless of
their religion; some separate religious courts; accepts compulsory ICJ
jurisdiction, with reservations
_#_National holiday: Independence Day, 1 January (1956)
_#_Executive branch: executive and legislative authority vested in a
13-member Revolutionary Command Council (RCC); chairman of the RCC acts
as prime minister; in July 1989 RCC appointed a predominately civilian
22-member cabinet to function as advisers
_#_Legislative branch: none
_#_Judicial branch: Supreme Court, Special Revolutionary Courts
_#_Leaders:
Chief of State and Head of Government--Revolutionary Command
Council Chairman and Prime Minister Lt. Gen. Umar Hasan Ahmad
al-BASHIR (since 30 June 1989);
Deputy Chairman of the Command Council and Deputy Prime Minister
Maj. Gen. al-Zubayr Muhammad SALIH Ahmed (since 9 July 1989)
_#_Political parties and leaders: none; banned following
30 June 1989 coup
_#_Suffrage: none
_#_Elections: none
_#_Member of: ABEDA, ACP, AfDB, AFESD, AL, AMF, CAEU, CCC, ECA, FAO,
G-77, IAEA, IBRD, ICAO, IDA, IDB, IFAD, IFC, IGADD, ILO, IMF, IMO,
INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS, NAM, OAU, OIC, PCA, UN, UNCTAD,
UNESCO, UNHCR, UNIDO, UPU, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Abdallah Ahmad ABDALLAH;
Chancery at 2210 Massachusetts Avenue NW, Washington DC 20008; telephone
(202) 338-8565 through 8570; there is a Sudanese Consulate General in New
York;
US--Ambassador James R. CHEEK; Embassy at Shar''ia Ali Abdul Latif,
Khartoum (mailing address is P. O. Box 699, Khartoum, or APO New York
09668); telephone 74700 or 74611
_#_Flag: three equal horizontal bands of red (top), white, and black
with a green isosceles triangle based on the hoist side
_#_Long-form name: Republic of Suriname
_#_Type: republic
_#_Capital: Paramaribo
_#_Administrative divisions: 10 districts (distrikten,
singular--distrikt); Brokopondo, Commewijne, Coronie, Marowijne,
Nickerie, Para, Paramaribo, Saramacca, Sipaliwini, Wanica
_#_Independence: 25 November 1975 (from Netherlands; formerly
Netherlands Guiana or Dutch Guiana)
_#_Constitution: ratified 30 September 1987
_#_Legal system: NA
_#_National holiday: Independence Day, 25 November (1975)
_#_Executive branch: president, vice president and prime minister,
Cabinet of Ministers, Council of State; note--commander in chief of the
National Army maintains significant power
_#_Legislative branch: unicameral National Assembly (Assemblee
Nationale)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--President
Ronald VENETIAAN (since 16 September 1991); Vice President and
Prime Minister Jules AJODHIA (since 16 September 1991)
_#_Political parties and leaders:
traditional ethnic-based parties--The New Front (NF), Henck
ARRON, a coalition formed of four parties following the 24 December
1990 military coup--Progressive Reform Party (VHP), Jaggernath LACHMON;
National Party of Suriname (NPS), Henck ARRON;
Indonesian Peasants Party (KTPI), Willy SOEMITA; and
Suriname Labor Party (SLP), Frank DERBY;
promilitary New Democratic Party (NDP), Jules Albert WIJDENBOSCH,
Frank PLAYFAIR;
Democratic Alternative ''91 (DA ''91),
Gerard BRUNINGS, a coalition of five parties formed in
January 1991--Alternative Forum, Gerard BRUNINGS, Winston JESSURUN;
Reformed Progressive Party (HPP), Panalall PARMISSER;
Party for Brotherhood and Unity in Politics (BEP), Caprino ALLENDY;
Pendawalima, Marsha JAMIN; and
Independent Progressive Group, Karam RAMSUNDERSINGH;
leftists--Revolutionary People''s Party (RVP), Michael NAARENDORP;
Progressive Workers and Farmers (PALU), Iwan KROLIS
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 6 September 1991 (next to be held May
1996);
results--elected by the National Assembly--Ronald VENETIAAN (NF)
80% (645 votes), Jules WIJDENBOSCH (NDP) 14% (115 votes), Hans PRADE
(DA ''91) 6% (49 votes)
National Assembly--last held 25 May 1991 (next to be held
May 1996);
results--percent of vote NA;
seats--(51 total) NF 30, NDP 12, DA ''91 9
_#_Member of: ACP, CARICOM (observer), ECLAC, FAO, GATT, G-77, IADB,
IBRD, ICAO, ICFTU, IFAD, ILO, IMF, IMO, INTERPOL, IOC, ITU, LAES,
LORCS, NAM, OAS, OPANAL, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WIPO,
WMO
_#_Diplomatic representation: Ambassador Willem A. UDENHOUT; Chancery
at Suite 108, 4301 Connecticut Avenue NW, Washington DC 20008;
telephone (202) 244-7488 or 7490 through 7492; there is a Surinamese
Consulate General in Miami;
US--Ambassador John (Jack) P. LEONARD; Embassy at Dr. Sophie
Redmonstraat 129, Paramaribo (mailing address is P. O. Box 1821,
Paramaribo); telephone [597] 72900, 77881, or 76459
_#_Flag: five horizontal bands of green (top, double width), white,
red (quadruple width), white, and green (double width); there is a large
yellow five-pointed star centered in the red band
_#_Long-form name: none
_#_Type: territory of Norway administered by the Ministry of Industry,
Oslo, through a governor (sysselmann) residing in Longyearbyen,
Spitsbergen; by treaty (9 February 1920) sovereignty was given to Norway
_#_Capital: Longyearbyen
_#_Leaders:
Chief of State--King HARALD V (since 17 January 1991);
Head of Government--Governor Leif ELDRING (since NA)
_#_Member of: none
_#_Flag: the flag of Norway is used
_#_Long-form name: Kingdom of Swaziland
_#_Type: monarchy; independent member of Commonwealth
_#_Capital: Mbabane (administrative); Lobamba (legislative)
_#_Administrative divisions: 4 districts; Hhohho, Lubombo, Manzini,
Shiselweni
_#_Independence: 6 September 1968 (from UK)
_#_Constitution: none; constitution of 6 September 1968 was suspended
on 12 April 1973; a new constitution was promulgated 13 October 1978, but
has not been formally presented to the people
_#_Legal system: based on South African Roman-Dutch law in statutory
courts, Swazi traditional law and custom in traditional courts; has not
accepted compulsory ICJ jurisdiction
_#_National holiday: Somhlolo (Independence) Day, 6 September (1968)
_#_Executive branch: monarch, prime minister, Cabinet
_#_Legislative branch: bicameral Parliament is advisory and consists
of an upper house or Senate and a lower house or House of Assembly
_#_Judicial branch: High Court, Court of Appeal
_#_Leaders:
Chief of State--King MSWATI III (since 25 April 1986);
Head of Government--Prime Minister Obed DLAMINI (since 12 July
1989)
_#_Political parties: none; banned by the Constitution promulgated on
13 October 1978
_#_Suffrage: none
_#_Elections: no direct elections
_#_Communists: no Communist party
_#_Member of: ACP, AfDB, C, CCC, ECA, FAO, G-77, IBRD, ICAO, ICFTU,
IDA, IFAD, IFC, ILO, IMF, INTELSAT, INTERPOL, IOC, ITU, LORCS, NAM, OAU,
PCA, SACU, SADCC, UN, UNCTAD, UNESCO, UNIDO, UPU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Absalom Vusani MAMBA;
Chancery at 4301 Connecticut Avenue NW, Washington DC 20008;
telephone (202) 362-6683;
US--Ambassador Stephen H. ROGERS; Embassy at Central Bank Building,
Warner Street, Mbabane (mailing address is P. O. Box 199, Mbabane);
telephone [268] 46441 through 5
_#_Flag: three horizontal bands of blue (top), red (triple width), and
blue; the red band is edged in yellow; centered in the red band is a
large black and white shield covering two spears and a staff decorated
with feather tassels, all placed horizontally
_#_Long-form name: Kingdom of Sweden
_#_Type: constitutional monarchy
_#_Capital: Stockholm
_#_Administrative divisions: 24 provinces (lan, singular and
plural); Alvsborgs Lan, Blekinge Lan, Gavleborgs Lan,
Goteborgs och Bohus Lan, Gotlands Lan, Hallands Lan, Jamtlands
Lan, Jonkopings Lan, Kalmar Lan, Kopparbergs Lan,
Kristianstads Lan, Kronobergs Lan, Malmohus Lan, Norrbottens
Lan, Orebro Lan, Ostergotlands Lan, Skaraborgs Lan,
Sodermanlands Lan, Stockholms Lan, Uppsala Lan, Varmlands
Lan, Vasterbottens Lan, Vasternorrlands Lan, Vastmanlands
Lan
_#_Independence: 6 June 1809, constitutional monarchy established
_#_Constitution: 1 January 1975
_#_Legal system: civil law system influenced by customary law; accepts
compulsory ICJ jurisdiction, with reservations
_#_National holiday: Day of the Swedish Flag, 6 June
_#_Executive branch: monarch, prime minister, Cabinet
_#_Legislative branch: unicameral Parliament (Riksdag)
_#_Judicial branch: Supreme Court (Hogsta Domstolen)
_#_Leaders:
Chief of State--King CARL XVI Gustaf (since 19 September 1973);
Heir Apparent Princess VICTORIA Ingrid Alice Desiree, daughter of the
King (born 14 July 1977);
Head of Government--Prime Minister Carl BILDT (since 3 October
1991)
_#_Political parties and leaders:
ruling four-party coalition consists of the
Moderate Party (conservative), Carl BILDT;
Liberal People''s Party, Bengt WESTERBERG;
Center Party, Olof JOHANSSON; and the
Christian Democratic Party, Alf SVENSSON;
Social Democratic Party, Ingvar CARLSSON;
New Democracy Party, Count Ian WACHMEISTER;
Left Party (VP; Communist), Lars WERNER;
Swedish Communist Party (SKP), Rune PETTERSSON;
Communist Workers'' Party, Rolf HAGEL;
Green Party, no formal leader
_#_Suffrage: universal at age 18
_#_Elections:
Riksdag--last held 15 September 1991 (next to be held
September 1994);
results--Social Democratic 37.6%, Moderate (conservative)
21.9%, Liberal People''s Party 9.1%, Center Party 8.5%, Christian
Democrats 7.1%, New Democracy 6.7%, Left Party (Communist) 4.5%, Green
Party 3.4%, other 1.2%;
seats--(349 total) Social Democratic 138, Moderate (conservative) 80,
Liberal People''s Party 33, Center Party 31, Christian Democrats 26, New
Democracy 25, Left Party (Communist) 16; note: the Green Party leaves
the Riksdag because it received less than the required 4% of the vote
_#_Communists: VP and SKP; VP, formerly the Left Party-Communists,
is reported to have roughly 17,800 members and attracted 5.8% of the vote
in the 1988 election; VP dropped the Communist label in 1990, but
maintains a Marxist ideology
_#_Member of: AfDB, AG (observer) AsDB, BIS, CCC, CE, CERN, CSCE,
EBRD, ECE, EFTA, ESA, FAO, G-6, G-8, G-9, G-10, GATT, IADB, IAEA, IBRD,
ICAO, ICC, ICFTU, IDA, IEA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTERPOL,
INTELSAT, IOC, IOM (observer), ISO, ITU, LORCS, NAM (guest), NC,
NEA, NIB, OECD, PCA, UN, UNCTAD, UNESCO, UNFICYP, UNHCR, UNIDO,
UNIFIL, UNIIMOG, UNMOGIP, UNTSO, UPU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Anders THUNBORG; Chancery at
Suite 1200, 600 New Hampshire Avenue NW, Washington DC 20037;
telephone (202) 944-5600; there are Swedish Consulates General in
Chicago, Los Angeles, Minneapolis, and New York;
US--Ambassador Charles E. REDMAN; Embassy at Strandvagen 101,
S-115 89 Stockholm; telephone [46] (8) 783-5300
_#_Flag: blue with a yellow cross that extends to the edges of the
flag; the vertical part of the cross is shifted to the hoist side in the
style of the Dannebrog (Danish flag)
_#_Long-form name: Swiss Confederation
_#_Type: federal republic
_#_Capital: Bern
_#_Administrative divisions: 26 cantons (cantons, singular--canton in
French; cantoni, singular--cantone in Italian; kantone, singular--kanton
in German); Aargau, Ausser-Rhoden, Basel-Landschaft, Basel-Stadt, Bern,
Fribourg, Geneve, Glarus, Graubunden, Inner-Rhoden, Jura, Luzern,
Neuchatel, Nidwalden, Obwalden, Sankt Gallen, Schaffhausen, Schwyz,
Solothurn, Thurgau, Ticino, Uri, Valais, Vaud, Zug, Zurich
_#_Independence: 1 August 1291
_#_Constitution: 29 May 1874
_#_Legal system: civil law system influenced by customary law;
judicial review of legislative acts, except with respect to federal
decrees of general obligatory character; accepts compulsory ICJ
jurisdiction, with reservations
_#_National holiday: Anniversary of the Founding of the Swiss
Confederation, 1 August (1291)
_#_Executive branch: president, vice president, Federal Council
(German--Bundesrat, French--Conseil Federal, Italian--Consiglio
Federale)
_#_Legislative branch: bicameral Federal Assembly
(German--Bundesversammlung, French--Assemblee Federale,
Italian--Assemblea Federale) consists of an upper council or Council
of States (German--Standerat, French--Conseil des Etats,
Italian--Consiglio degli Stati) and a lower council or National
Council (German--Nationalrat, French--Conseil National,
Italian--Consiglio Nazionale)
_#_Judicial branch: Federal Supreme Court
_#_Leaders:
Chief of State and Head of Government--President Flavio COTTI
(1991 calendar year; presidency rotates annually); Vice President Rene
FELBER (term runs concurrently with that of president)
_#_Political parties and leaders:
Free Democratic Party (FDP), Bruno HUNZIKER, president;
Social Democratic Party (SPS), Helmut HUBACHER, chairman;
Christian Democratic People''s Party (CVP), Eva SEGMULLER-WEBER,
chairman;
Swiss People''s Party (SVP), Hans UHLMANN, president;
Green Party (GPS), Peter SCHMID, president;
Automobile Party (AP), DREYER;
Alliance of Independents'' Party (LdU), Dr. Franz JAEGER, president;
Swiss Democratic Party (SD), NA;
Evangelical People''s Party (EVP), Max DUNKI, president;
Workers'' Party (PdA; Communist), Jean SPIELMANN, general secretary;
Ticino League, leader NA
Liberal Party (LPS), Gilbert COUTAU, president;
National Action Party (NA), Rudolph KELLER, chairman;
Republican Party (RP), Franz BAUMGARTNER, president;
Progressive Organizations of Switzerland (POCH), Georg DEGEN, secretary;
Unitary Socialist Party (PSU), Dario ROBBIANI, president
_#_Suffrage: universal at age 20
_#_Elections:
Council of States--last held throughout 1991 (next to be
held 1995;
results--percent of vote by party NA;
seats--(46 total) FDP 15, CVP 14, SVP 4, LPS 3, LDU 1; note--9
seats require run-off elections, to be held in November1991
National Council--last held 20 October 1991 (next to be
held October 1995);
results--FDP %, SPS %, CVP %, SVP %, GPS %,
LPS %, AP %, LDU %,SD %, EVP %, Workers Party %,
Ticino League 23%, other %;
seats--(200 total) FDP 44, SPS 42, CVP 37, SVP 25, GPS 14, LPS 10,
AP 8, LDU 6, SD 5, EVP 3, Workers Party 2, Ticino League 2, other 2
_#_Communists: 4,500 members (est.)
_#_Member of: AfDB, AG (observer), AsDB, BIS, CCC, CE, CERN, CSCE,
EBRD, ECE, EFTA, ESA, FAO, G-8, G-10, GATT, IADB, IAEA, ICAO, ICC, ICFTU,
IEA, IFAD, ILO, IMF (observer), IMO, INMARSAT, INTELSAT, INTERPOL, IOC,
IOM, ISO, ITU, LORCS, NAM (guest), NEA, OAS (observer), OECD, PCA,
UN (observer), UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WCL, WHO, WIPO,
WMO, WTO
_#_Diplomatic representation: Ambassador Edouard BRUNNER; Chancery at
2900 Cathedral Avenue NW, Washington DC 20008; telephone (202) 745-7900;
there are Swiss Consulates General in Atlanta, Chicago, Houston, Los
Angeles, New York, and San Francisco;
US--Ambassador Joseph B. GILDENHORN; Embassy at
Jubilaeumstrasse 93, 3005 Bern; telephone [41] (31) 437-011;
there is a Branch Office of the Embassy in Geneva and a
Consulate General in Zurich
_#_Flag: red square with a bold, equilateral white cross in the
center that does not extend to the edges of the flag
_#_Long-form name: Syrian Arab Republic
_#_Type: republic; under leftwing military regime since March 1963
_#_Capital: Damascus
_#_Administrative divisions: 14 provinces (muhafazat,
singular--muhafazah); Al Hasakah, Al Ladhiqiyah, Al
Qunaytirah, Ar Raqqah, As Suwayda, Dara, Dayr az Zawr,
Dimashq, Halab, Hamah, Hims, Idlib, Rif Dimashq,
Tartus
_#_Independence: 17 April 1946 (from League of Nations mandate under
French administration); formerly United Arab Republic
_#_Constitution: 13 March 1973
_#_Legal system: based on Islamic law and civil law system; special
religious courts; has not accepted compulsory ICJ jurisdiction
_#_National holiday: National Day, 17 April (1946)
_#_Executive branch: president, three vice presidents, prime minister,
three deputy prime ministers, Council of Ministers (cabinet)
_#_Legislative branch: unicameral People''s Council (Majlis al-Chaab)
_#_Judicial branch: Supreme Constitutional Court, High Judicial
Council, Court of Cassation, State Security Courts
_#_Leaders:
Chief of State--President Hafiz al-ASAD (since 22 February
1971); Vice Presidents Abd al-Halim KHADDAM, Rifat al-ASAD, and
Muhammad Zuhayr MASHARIQA (since 11 March 1984);
Head of Government--Prime Minister Mahmud ZUBI (since 1 November
1987);
Deputy Prime Minister Lt. Gen. Mustafa TALAS (since 11 March 1984);
Deputy Prime Minister Salim YASIN (since NA December 1981);
Deputy Prime Minister Mahmud QADDUR (since NA May 1985)
_#_Political parties and leaders: ruling party is the Arab Socialist
Resurrectionist (Bath) Party;
the Progressive National Front is dominated by Bathists but includes
independents and members of the Syrian Arab Socialist Party (ASP),
Arab Socialist Union (ASU),
Syrian Communist Party (SCP),
Arab Socialist Unionist Movement, and
Democratic Socialist Union Party
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 10-11 February 1985 (next to be held February
1992);
results--President Hafiz al-ASAD was reelected without opposition;
People''s Council--last held 22-23 May 1990 (next to be
held May 1994);
results--Bath 53.6%, ASU 3.2%, SCP 3.2%, Arab Socialist Unionist
Movement 2.8%, ASP 2%, Democratic Socialist Union Party 1.6%,
independents 33.6%;
seats--(250 total) Bath 134, ASU 8, SCP 8,
Arab Socialist Unionist Movement 7, ASP 5, Democratic Socialist Union
Party 4, independents 84;
the People''s Council was expanded to 250 seats total prior to the
May 1990 election
_#_Communists: mostly sympathizers, numbering about 5,000
_#_Other political or pressure groups: non-Bath parties have little
effective political influence; Communist party ineffective; greatest
threat to Asad regime lies in factionalism in the military; conservative
religious leaders; Muslim Brotherhood
_#_Member of: ABEDA, AFESD, AL, AMF, CAEU, CCC, ESCWA, FAO, G-24,
G-77, IAEA, IBRD, ICAO, ICC, IDA, IDB, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS, NAM, OAPEC, OIC, UN,
UNCTAD, UNESCO, UNIDO, UNRWA, UPU, WFTU, WHO, WMO, WTO
_#_Diplomatic representation: Ambassador Walid MOUALEM;
Chancery at 2215 Wyoming Avenue NW, Washington DC 20008; telephone (202)
232-6313;
US--Ambassador Edward P. DJEREJIAN; Embassy at Abu Rumaneh,
Al Mansur Street No.2, Damascus (mailing address is P. O. Box 29,
Damascus); telephone [963] (11) 333052 or 332557, 330416, 332814, 332315,
714108, 337178, 333232, 334352
_#_Flag: three equal horizontal bands of red (top), white, and black
with two small green five-pointed stars in a horizontal line centered
in the white band; similar to the flag of Yemen which has a plain white
band and of Iraq which has three green stars (plus an Arabic
inscription) in a horizontal line centered in the white
band; also similar to the flag of Egypt which has a symbolic eagle
centered in the white band
_#_Long-form name: United Republic of Tanzania
_#_Type: republic
_#_Capital: Dar es Salaam; some government offices have been
transferred to Dodoma, which is planned as the new national capital in
the 1990s
_#_Administrative divisions: 25 regions; Arusha, Dar es Salaam,
Dodoma, Iringa, Kigoma, Kilimanjaro, Lindi, Mara, Mbeya, Morogoro,
Mtwara, Mwanza, Pemba North, Pemba South, Pwani, Rukwa, Ruvuma,
Shinyanga, Singida, Tabora, Tanga, Zanzibar Central/South, Zanzibar
North, Zanzibar Urban/West, Ziwa Magharibi
_#_Independence: Tanganyika became independent 9 December 1961 (from
UN trusteeship under British administration); Zanzibar became independent
19 December 1963 (from UK); Tanganyika united with Zanzibar 26 April 1964
to form the United Republic of Tanganyika and Zanzibar; renamed United
Republic of Tanzania 29 October 1964
_#_Constitution: 15 March 1984 (Zanzibar has its own Constitution but
remains subject to provisions of the union Constitution)
_#_Legal system: based on English common law; judicial review of
legislative acts limited to matters of interpretation; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: Union Day, 26 April (1964)
_#_Executive branch: president, first vice president and prime
minister of the union, second vice president and president of Zanzibar,
Cabinet
_#_Legislative branch: unicameral National Assembly (Bunge)
_#_Judicial branch: Court of Appeal, High Court
_#_Leaders:
Chief of State--President Ali Hassan MWINYI (since 5 November
1985); First Vice President John MALECELA (since 9 November 1990);
Second Vice President Salmin AMOUR (since 9 November 1990);
Head of Government--Prime Minister John MALECELA (since 9
November 1990)
_#_Political parties and leaders: only party--Chama Cha MAPINDUZI
(CCM or Revolutionary Party), Ali Hassan MWINYI, party chairman
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 28 October 1990 (next to be held
October 1995);
results--Ali Hassan MWINYI was elected without opposition;
National Assembly--last held 28 October 1990 (next to be held
October 1995);
results--CCM is the only party;
seats--(241 total, 168 elected) CCM 168
_#_Communists: no Communist party; a few Communist sympathizers
_#_Member of: ACP, AfDB, C, CCC, EADB, ECA, FAO, FLS, G-6, G-77,
GATT, IAE','b405a7a0079811f19fbb0056fa41d13366ac3459670cd480de9a74ebf9238575','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('184f69115d02d9a58858f9b61505ff474565f879d8baa45fca3b6412013bab7f',1991,'SA','Saudi Arabia','government',71,'A, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, ISO, ITU, LORCS, NAM, OAU, SADCC, UN, UNCTAD,
UNESCO, UNHCR, UNIDO, UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador-designate Charles Musama
NYIRABU; Chancery at 2139 R Street NW, Washington DC 20008;
telephone (202) 939-6125;
US--Ambassador Edmund DE JARNETTE; Embassy at 36 Laibon Road (off
Bagamoyo Road), Dar es Salaam (mailing address is P. O. Box 9123,
Dar es Salaam); telephone [255] (51) 37501 through 37504
_#_Flag: divided diagonally by a yellow-edged black band from the
lower hoist-side corner; the upper triangle (hoist side) is green and the
lower triangle is blue','ca7de4b0ac9c39a2181176e58b6b98187716c2b9b82725d8165b9f02f0cbb9c5','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a34294ef8142905de60a22d0f320d52eeb68134da8bf05c9441e912ed6f40c1',1991,'GF','French Guiana','government',72,'_#_Leaders:
Chief of State--President Francois MITTERRAND (since 21 May
1981);
Head of Government--Commissioner of the Republic Jean-Francois
DI CHIARA (since NA 1990)
_#_Political parties and leaders:
Guianese Socialist Party (PSG), Gerard HOLDER;
Rally for the Republic (RPR), Paulin BRUNE;
Guyanese Democratic Action (ADG), Andre Lecante;
Union for French Democracy (UDF), Claude Ho A CHUCK;
National Front (FN), Guy MALON;
Popular and National Party of Guiana (PNPG), Claude ROBO;
National Anti-Colonist Guianese Party (PANGA), Michel KAPEL
_#_Suffrage: universal at age 18
_#_Elections:
Regional Council--last held 16 March 1986 (next to be
held NA 1991);
results--PSG 43%, RPR 27.7%, ADG 12.2%, UDF 8.9%, FN 3.7%,
PNPG 1.4%, other 3.1%;
seats--(31 total) PSG 15, RPR 9, ADG 4, UDF 3;
French Senate--last held 24 September 1989 (next to be held
September 1992);
results--percent of vote by party NA;
seats--(1 total) PSG 1;
French National Assembly--last held 24 September 1989 (next to be
held September 1992);
results--percent of vote by party NA;
seats--(2 total) PSG 1, RPR 1
_#_Communists: Communist party membership negligible
_#_Member of: FZ, WCL, WFTU
_#_Diplomatic representation: as an overseas department of France
the interests of French Guiana are represented in the US by France
_#_Flag: the flag of France is used
_#_Long-form name: Territory of French Polynesia
_#_Type: overseas territory of France since 1946
_#_Capital: Papeete
_#_Administrative divisions: none (overseas territory of France);
there are no first-order administrative divisions as defined by the US
Government, but there are 5 archipelagic divisions named
Archipel des Marquises, Archipel des Tuamotu, Archipel des Tubuai, Iles
du Vent, and Iles Sous-le-Vent; note--Clipperton Island is administered
from French Polynesia and may have become a dependency of French
Polynesia
_#_Independence: none (overseas territory of France)
_#_Constitution: 28 September 1958 (French Constitution)
_#_Legal system: based on French system
_#_National holiday: Taking of the Bastille, 14 July (1789)
_#_Executive branch: French president, high commissioner of the
republic, president of the Council of Ministers, vice president of the
Council of Ministers, Council of Ministers
_#_Legislative branch: unicameral Territorial Assembly
_#_Judicial branch: Court of Appeal
_#_Leaders:
Chief of State--President Francois MITTERRAND (since
21 May 1981); High Commissioner of the Republic Jean MONTPEZAT
(since NA November 1987);
Head of Government--President of the Council of Ministers
Gaston FLOSSE (since 10 May 1991);
Vice President of the Council of Ministers NA
_#_Political parties and leaders:
People''s Rally (Tahoeraa Huiraatira; Gaullist), Gaston FLOSSE;
Polynesian Union Party (Te Tiarama; centrist), Alexandre LEONTIEFF;
New Fatherland Party (Ai''a Api), Emile VERNAUDON;
Polynesian Liberation Front (Tavini Huiraatira), Oscar TEMARU;
other small parties
_#_Suffrage: universal at age 18
_#_Elections:
Territorial Assembly--last held 17 March 1991 (next to be held
March 1996); results--percent of vote by party NA;
seats--(41 total) People''s Rally (Gaullist) 18, Polynesian Union Party
14, New Fatherland Party 5, other 4;
French Senate--last held 24 September 1989 (next to be held
September 1992); results--percent of vote by party NA;
seats--(1 total) party NA;
French National Assembly last held 5 and 12 June 1988 (next to be
held June 1993); results--percent of vote by party NA;
seats--(2 total) People''s Rally (Gaullist) 1, New Fatherland Party 1
_#_Member of: FZ, SPC, WMO
_#_Diplomatic representation: as an overseas territory of France,
French Polynesian interests are represented in the US by France
_#_Flag: the flag of France is used
_#_Long-form name: Territory of the French Southern and Antarctic
Lands
_#_Type: overseas territory of France since 1955; governed by High
Administrator Bernard de GOUTTES (since NA May 1990), who is
assisted by a 7-member Consultative Council and a 12-member Scientific
Council
_#_Administrative divisions: none (overseas territory of France);
there are no first-order administrative divisions as defined by
the US Government, but there are 3 districts named Ile Crozet, Iles
Kerguelen, and Iles Saint-Paul et Amsterdam; excludes Terre Adelie
claim in Antarctica that is not recognized by the US
_#_Flag: the flag of France is used
_#_Long-form name: Gabonese Republic
_#_Type: republic; multiparty presidential regime (opposition parties
legalized 1990)
_#_Capital: Libreville
_#_Administrative divisions: 9 provinces; Estuaire, Haut-Ogooue,
Moyen-Ogooue, Ngounie, Nyanga, Ogooue-Ivindo, Ogooue-Lolo,
Ogooue-Maritime, Woleu-Ntem
_#_Independence: 17 August 1960 (from France)
_#_Constitution: 21 February 1961, revised 15 April 1975
_#_Legal system: based on French civil law system and customary law;
judicial review of legislative acts in Constitutional Chamber of the
Supreme Court; compulsory ICJ jurisdiction not accepted
_#_National holiday: Renovation Day (Gabonese Democratic Party
established), 12 March (1968)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: unicameral National Assembly (Assemblee
Nationale)
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State--President El Hadj Omar BONGO (since 2 December
1967);
Head of Government--Prime Minister Casimir OYE-MBA (since 3
May 1990)
_#_Political parties and leaders: Gabonese Democratic Party (PDG,
former sole party), El Hadj Omar BONGO, president;
National Recovery Movement-Lumberjacks (Morena-Bucherons);
Gabonese Party for Progress (PGP);
National Recovery Movement (Morena-Original);
Association for Socialism in Gabon (APSG);
Gabonese Socialist Union (USG);
Circle for Renewal and Progress (CRP);
Union for Democracy and Development (UDD)
_#_Suffrage: universal at age 21
_#_Elections:
President--last held on 9 November 1986 (next to be held
November 1993);
results--President Omar BONGO was reelected without opposition;
National Assembly--last held on 28 October 1990 (next to be
held by February 1992);
results--percent of vote NA;
seats--(120 total, 111 elected) PDG 62, National Recovery
Movement-Lumberjacks (Morena-Bucherons) 19, PGP 18, National Recovery
Movement (Morena-Original) 7, ASPG 6, USG 4, CRP 1, independent 3
_#_Communists: no organized party; probably some Communist
sympathizers
_#_Member of: ACCT, ACP, AfDB, BDEAC, CCC, CEEAC, ECA, FAO, FZ, G-24,
G-77, GATT, IAEA, IBRD, ICAO, ICC, IDA, IDB, IFAD, IFC, ILO, IMF, IMO,
INMARSAT, INTELSAT, INTERPOL, IOC, ITU, LORCS (associate), NAM,
OAU, OIC, OPEC, UDEAC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WIPO,
WMO, WTO
_#_Diplomatic representation: Ambassador-designate Alexandre
SAMBAT; Chancery at 2034 20th Street NW, Washington DC 20009; telephone
(202) 797-1000;
US--Ambassador Keith L. WAUCHOPE; Embassy at Boulevard de la Mer,
Libreville (mailing address is B. P. 4000, Libreville); telephone 762003
or 762004, 743492
_#_Flag: three equal horizontal bands of green (top), yellow, and blue
_#_Long-form name: Republic of The Gambia
_#_Type: republic
_#_Capital: Banjul
_#_Administrative divisions: 5 divisions and 1 city*; Banjul*, Lower
River, MacCarthy Island, North Bank, Upper River, Western
_#_Independence: 18 February 1965 (from UK); The Gambia and Senegal
signed an agreement on 12 December 1981 (effective 1 February 1982)
that called for the creation of a loose confederation to be known as
Senegambia, but the agreement was dissolved on 30 September 1989
_#_Constitution: 24 April 1970
_#_Legal system: based on a composite of English common law,
Koranic law, and customary law; accepts compulsory ICJ jurisdiction,
with reservations
_#_National holiday: Independence Day, 18 February (1965)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: unicameral House of Representatives
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--President Alhaji Sir Dawda
Kairaba JAWARA (since 24 April 1970); Vice President Bakary Bunja DARBO
(since 12 May 1982)
_#_Political parties and leaders:
People''s Progressive Party (PPP), Dawda K. JAWARA, secretary general;
National Convention Party (NCP), Sheriff DIBBA;
Gambian People''s Party (GPP), Assan Musa CAMARA;
United Party (UP);
People''s Democratic Organization of Independence and Socialism (PDOIS)
_#_Suffrage: universal at age 21
_#_Elections:
President--last held on 11 March 1987 (next to be held March 1992);
results--Sir Dawda JAWARA (PPP) 61.1%, Sherif Mustapha DIBBA (NCP) 25.2%,
Assan Musa CAMARA (GPP) 13.7%;
House of Representatives--last held on 11 March 1987 (next to
be held by March 1992);
results--PPP 56.6%, NCP 27.6%, GPP 14.7%, PDOIS 1%;
seats--(43 total, 36 elected) PPP 31, NCP 5
_#_Communists: no Communist party
_#_Member of: ACP, AfDB, C, CCC, ECA, ECOWAS, FAO, G-77, GATT, IBRD,
ICAO, ICFTU, IDA, IDB, IFAD, IFC, IMF, IMO, INTERPOL, IOC, ITU,
LORCS, NAM, OAU, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL,
WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Ousman A. SALLAH; Chancery at
Suite 720, 1030 15th Street NW, Washington DC 20005;
telephone (202) 842-1356 or 842-1359;
US--Ambassador Arlene RENDER; Embassy at Pipeline Road
(Kairaba Avenue), Fajara, Banjul (mailing address is P. M. B. No. 19,
Banjul); telephone Serrekunda [220] 92856 or 92858, 91970, 91971
_#_Flag: three equal horizontal bands of red (top), blue with white
edges, and green
_#_Long-form name: none
_#_Note: The Gaza Strip is currently governed by Israeli military
authorities and Israeli civil administration. It is US policy that the
final status of the Gaza Strip will be determined by negotiations among
the concerned parties. These negotiations will determine how this area is
to be governed.
_#_Long-form name: Federal Republic of Germany
_#_Type: federal republic
_#_Capital: Berlin; note--the shift from Bonn to Berlin will take
place over a period of years with Bonn retaining many administrative
functions
_#_Administrative divisions: 16 states (lander, singular--land);
Baden-Wurttemberg, Bayern, Berlin, Brandenburg, Bremen, Hamburg,
Hessen, Mecklenburg-Vorpommern, Niedersachsen, Nordrhein-Westfalen,
Rheinland-Pfalz, Saarland, Sachsen, Sachsen-Anhalt, Schleswig-Holstein,
Thuringen
_#_Independence: 18 January 1871 (German Empire unification); divided
into four zones of occupation (UK, US, USSR, and later, France) in 1945
following World War II; Federal Republic of Germany (FRG or West Germany)
proclaimed 23 May 1949 and included the former UK, US, and French zones;
German Democratic Republic (GDR or East Germany) proclaimed 7 October
1949 and included the former USSR zone; unification of West Germany and
East Germany took place 3 October 1990; all four power rights formally
relinquished 15 March 1991
_#_Constitution: 23 May 1949, provisional constitution known as
Basic Law
_#_Legal system:
civil law system with indigenous concepts; judicial review of
legislative acts in the Federal Constitutional Court; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: 3 October 1990, German Unity Day
_#_Executive branch: president, chancellor, Cabinet
_#_Legislative branch: bicameral parliament (no official name
for the two chambers as a whole) consists of an upper chamber or
Federal Council (Bundesrat) and a lower chamber or Federal Diet
(Bundestag)
_#_Judicial branch:
Federal Constitutional Court (Bundesverfassungsgericht)
_#_Leaders:
Chief of State--President Dr. Richard von WEIZSACKER
(since 1 July 1984);
Head of Government--Chancellor Dr. Helmut KOHL
(since 4 October 1982)
_#_Political parties and leaders:
Christian Democratic Union (CDU), Helmut KOHL, chairman;
Christian Social Union (CSU), Theo WAIGEL;
Free Democratic Party (FDP), Otto Count LAMBSDORFF, chairman;
Social Democratic Party (SPD), Bjoern ENGHOLM, chairman;
Green Party--Volmer LUDGER, Christine WEISKE, co-chairmen
(after the 2 December 1990 election the East and West German
Green Parties united);
Alliance 90 includes three parties--New Forum, Jens REICH, Sebastian
PFLUGBEIL, spokespersons; Democracy Now, Konrad WEISS, spokesperson;
and Initiative, Peace, and Human Rights Party, Gerd POPPE;
Party of Democratic Socialism (PDS, formerly the East German
Communist Party), Gregor GYSI, chairman;
Republikaner, Franz SCHONHUBER;
National Democratic Party (NPD), Martin MUSSGNUG;
Communist Party (DKP), Herbert MIES
_#_Suffrage: universal at age 18
_#_Elections:
Federal Diet--last held 2 December 1990 (next to be held
by December 1994); results--CDU 36.7%, SPD 33.5%, FDP 11.0%, CSU 7.1%,
Green Party (West Germany) 3.9%, PDS 2.4%, Republikaner 2.1%,
Alliance 90/Green Party (East Germany) 1.2%, other 2.1%;
seats--(662 total, 656 statutory with special rules to allow for
slight expansion) CDU 268, SPD 239, FDP 79, CSU 51, PDS 17, Alliance
90/Green Party (East Germany) 8; note--special rules for this
election allowed former East German parties to win seats if they
received at least 5% of vote in eastern Germany
_#_Communists:
West--about 40,000 members and supporters;
East--284,000 party members (December 1990)
_#_Other political or pressure groups: expellee, refugee, and veterans
groups
_#_Member of: AfDB, AG (observer), AsDB, BDEAC, BIS, CCC, CE, CERN,
COCOM, CSCE, EBRD, EC, ECE, EIB, ESA, FAO, G-5, G-7, G-10, GATT, IADB,
IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IEA, IFAD, IFC, ILO, IMF, IMO,
INMARSAT, INTELSAT, INTERPOL, IOC, IOM, ISO, ITU, LORCS, NATO, NEA,
OAS (observer), OECD, PCA, UN, UNCTAD, UNESCO, UNIDO, UNHCR, UPU,
WEU, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation:
Ambassador Jeurgen RUHFUS; Chancery at 4645 Reservoir Road NW,
Washington DC 20007; telephone (202) 298-4000; there are German
Consulates General in Atlanta, Boston, Chicago, Detroit, Houston,
Los Angeles, San Francisco, Seattle, and New York, and Consulates
in Miami and New Orleans;
US--Ambassador-designate Robert M. KIMMITT; Embassy at Deichmanns
Avenue, 5300 Bonn 2 (mailing address is APO New York 09080); telephone
[49] (228) 3391; there is a US Branch Office in Berlin and US Consulates
General in Frankfurt, Hamburg, Leipzig, Munich, and Stuttgart
_#_Flag:
three equal horizontal bands of black (top), red, and yellow
_#_Long-form name: Republic of Ghana
_#_Type: military
_#_Capital: Accra
_#_Administrative divisions: 10 regions; Ashanti, Brong-Ahafo,
Central, Eastern, Greater Accra, Northern, Upper East, Upper West, Volta,
Western
_#_Independence: 6 March 1957 (from UK, formerly Gold Coast)
_#_Constitution: 24 September 1979; suspended 31 December 1981
_#_Legal system: based on English common law and customary law;
has not accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 6 March (1957)
_#_Executive branch: chairman of the Provisional National Defense
Council (PNDC), PNDC, Cabinet
_#_Legislative branch: unicameral National Assembly dissolved after 31
December 1981 coup, and legislative powers were assumed by the
Provisional National Defense Council
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--Chairman of the Provisional
National Defense Council Flt. Lt. (Ret.) Jerry John RAWLINGS (since
31 December 1981)
_#_Political parties and leaders: none; political parties outlawed
after 31 December 1981 coup
_#_Suffrage: none
_#_Elections: none
_#_Communists: a small number of Communists and sympathizers
_#_Member of: ACP, AfDB, C, CCC, ECA, ECOWAS, FAO, G-24, G-77, GATT,
IAEA, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL,
IOC, IOM (observer), ISO, ITU, LORCS, NAM, OAU, UN, UNCTAD,
UNESCO, UNIDO, UNIFIL, UNIIMOG, UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Dr. Joseph ABBEY; Chancery at
2460 16th Street NW, Washington DC 20009; telephone (202) 462-0761;
there is a Ghanaian Consulate General in New York;
US--Ambassador Raymond C. EWING; Embassy at Ring Road East, East of
Danquah Circle, Accra (mailing address is P. O. Box 194, Accra);
telephone [233] (21) 775347 through 775349
_#_Flag: three equal horizontal bands of red (top), yellow, and green
with a large black five-pointed star centered in the gold band; uses the
popular pan-African colors of Ethiopia; similar to the flag of Bolivia
which has a coat of arms centered in the yellow band
_#_Long-form name: none
_#_Type: dependent territory of the UK
_#_Capital: Gibraltar
_#_Administrative divisions: none (dependent territory of the UK)
_#_Independence: none (dependent territory of the UK)
_#_Constitution: 30 May 1969
_#_Legal system: English law
_#_National holiday: Commonwealth Day (second Monday of March),
12 March 1990
_#_Executive branch: British monarch, governor, chief minister,
Gibraltar Council, Council of Ministers (cabinet)
_#_Legislative branch: unicameral House of Assembly
_#_Judicial branch: Supreme Court, Court of Appeal
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor and Commander in Chief Adm. Sir Derek
REFFELL (since NA 1989);
Head of Government--Chief Minister Joe BOSSANO (since 25 March
1988)
_#_Political parties and leaders:
Socialist Labor Party (SL), Joe BOSSANO;
Gibraltar Labor Party/Association for the Advancement of Civil
Rights (GCL/AACR), Adolfo CANEPA;
Independent Democratic Party, Joe PITALUGA
_#_Suffrage: universal at age 18, plus other UK subjects resident six
months or more
_#_Elections:
House of Assembly: last held on 24 March 1988 (next to be held
March 1992);
results--percent of vote by party NA;
seats--(18 total, 15 elected) SL 8, GCL/AACR 7
_#_Communists: negligible
_#_Other political or pressure groups: Housewives Association, Chamber
of Commerce, Gibraltar Representatives Organization
_#_Diplomatic representation: none (dependent territory of the UK)
_#_Flag: two horizontal bands of white (top, double-width) and red
with a three-towered red castle in the center of the white band; hanging
from the castle gate is a gold key centered in the red band
_#_Long-form name: none
_#_Type: French possession administered by Commissioner of the
Republic Daniel CONSTANTIN, resident in Reunion
_#_Long-form name: Hellenic Republic
_#_Type: presidential parliamentary government; monarchy rejected by
referendum 8 December 1974
_#_Capital: Athens
_#_Administrative divisions: 51 departments (nomoi,
singular--nomos); Aitolia kai Akarnania, Akhaia, Argolis,
Arkadhia, Arta, Attiki, Dhodhekanisos, Drama, Evritania,
Evros, Evvoia, Florina, Fokis, Fthiotis, Grevena, Ilia,
Imathia, Ioannina, Iraklion, Kardhitsa, Kastoria, Kavala,
Kefallinia, Kerkira, Khalkidhiki, Khania, Khios, Kikladhes,
Kilkis, Korinthia, Kozani, Lakonia, Larisa, Lasithi,
Lesvos, Levkas, Magnisia, Messinia, Pella, Pieria, Preveza,
Rethimni, Rodhopi, Samos, Serrai, Thesprotia, Thessaloniki,
Trikala, Voiotia, Xanthi, Zakinthos
_#_Independence: 1827 (from the Ottoman Empire)
_#_Constitution: 11 June 1975
_#_Legal system: NA
_#_National holiday: Independence Day (proclamation of the war of
independence), 25 March (1821)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: unicameral Greek Chamber of Deputies
(Vouli ton Ellinon)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Constantinos KARAMANLIS (since 5 May
1990);
Head of Government--Prime Minister Constantinos MITSOTAKIS
(since 11 April 1990)
_#_Political parties and leaders:
New Democracy (ND; conservative), Constantinos MITSOTAKIS;
Panhellenic Socialist Movement (PASOK), Andreas PAPANDREOU;
Democratic Renewal (DIANA), Constantine STEFANOPOULOS;
Communist Party (KKE), Aleka PAPARIGA;
Greek Left Party (EAR), Leonidas KYRKOS;
Ecologist-Alternative List, leader NA;
note--KKE and EAR have joined in the Left Alliance, Maria DAMANAKI,
president
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
President--last held 4 May 1990 (next to be held May 1995);
results--Constantinos KARAMANLIS was elected by Parliament;
Parliament--last held on 8 April 1990 (next to be held
April 1994);
results--ND 46.89%, PASOK 38.62%, Left Alliance 10.27%, PASOK/Left
Alliance 1.02%, Ecologist-Alternative List 0.77%, DIANA 0.67%,
Muslim independents 0.5%;
seats--(300 total) ND 150, PASOK 123, Left Alliance 19,
PASOK-Left Alliance 4, Muslim independents 2, DIANA 1,
Ecologist-Alternative List 1;
note--one DIANA deputy joined ND in July, giving ND 151 seats; in
November a special electoral court ruled in favor of ND on a
contested seat, giving ND 152 seats and taking one from PASOK (now 122)
_#_Communists: an estimated 60,000 members and sympathizers
_#_Member of: BIS, CCC, CE, CERN, COCOM, CSCE, EBRD, EC, ECE, EIB,
FAO, G-6, GATT, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IEA, IFAD, IFC, ILO,
IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC, IOM, ISO, ITU, LORCS,
NAM (guest), NATO, NEA, OAS (observer), OECD, PCA, UN, UNCTAD, UNESCO,
UNHCR, UNIDO, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Christos ZACHARAKIS; Chancery
at 2221 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
667-3168; there are Greek Consulates General in Atlanta, Boston, Chicago,
Los Angeles, New York, and San Francisco, and a Consulate in New Orleans;
US--Ambassador Michael G. SOTIRHOS; Embassy at 91 Vasilissis
Sophias Boulevard, 10160 Athens (mailing address is APO New York
09255-0006); telephone [30] (1) 721-2951 or 721-8401; there is a US
Consulate General in Thessaloniki
_#_Flag: nine equal horizontal stripes of blue (top and bottom)
alternating with white; there is a blue square in the upper hoist-side
corner bearing a white cross; the cross symbolizes Christianity, the
established religion of the country
_#_Long-form name: none
_#_Type: part of the Danish realm; self-governing overseas
administrative division
_#_Capital: Nuuk (Godthab)
_#_Administrative divisions: 3 municipalities (kommuner,
singular--kommun); Nordgronland, Ostgronland, Vestgronland
_#_Independence: part of the Danish realm; self-governing overseas
administrative division
_#_Constitution: Danish
_#_Legal system: Danish
_#_National holiday: Birthday of the Queen, 16 April (1940)
_#_Executive branch: Danish monarch, high commissioner, home rule
chairman, prime minister, Cabinet (Landsstyre)
_#_Legislative branch: unicameral Landsting
_#_Judicial branch: High Court (Landsret)
_#_Leaders:
Chief of State--Queen MARGRETHE II (since 14 January 1972),
represented by High Commissioner Bent KLINTE (since NA);
Head of Government--Home Rule Chairman Lars Emil JOHANSEN
(since 15 March 1991)
_#_Political parties and leaders: two-party ruling
coalition--Siumut (a moderate socialist party that advocates more
distinct Greenlandic identity and greater autonomy from Denmark), Lars
Emil JOHANSEN, chairman; and Inuit Ataqatigiit (IA; a Marxist-Leninist
party that favors complete independence from Denmark rather than home
rule);
Atassut Party (a more conservative party that favors continuing close
relations with Denmark), leader NA;
Polar Party (conservative-Greenland nationalist), leader NA;
Center Party (a new nonsocialist protest party), leader NA
_#_Suffrage: universal at age 18
_#_Elections:
Landsting--last held on 5 March 1991 (next to be held 5 March
1995);
results--percent of vote by party NA;
seats--(27 total) Siumut 11, Atassut Party 8, Inuit Ataqatigiit
5, Center Party 2, Polar Party 1;
Danish Folketing--last held on 12 December 1990 (next to be held by
December 1994); Greenland elects two representatives to the Folketing;
results--percent of vote by party NA;
seats--(2 total) Siumut 1, Atassut 1
_#_Member of: NC
_#_Diplomatic representation: none (self-governing overseas
administrative division of Denmark)
_#_Flag: two equal horizontal bands of white (top) and red with a
large disk slightly to the hoist side of center--the top half of the
disk is red, the bottom half is white
_#_Long-form name: none
_#_Type: parliamentary democracy
_#_Capital: Saint George''s
_#_Administrative divisions: 6 parishes and 1 dependency*; Carriacou
and Little Martinique*, Saint Andrew, Saint David, Saint George, Saint
John, Saint Mark, Saint','744a773c98ee07914f08be02e2a4225192cea5a8637cc58797e474fd4532bf66','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1dde25f42e49299bc3a4fd1f1d67566ce4f0e8c5cf89bf92729c5f223da5c438',1991,'GF','French Guiana','government',73,'Patrick
_#_Independence: 7 February 1974 (from UK)
_#_Constitution: 19 December 1973
_#_Legal system: based on English common law
_#_National holiday: Independence Day, 7 February (1974)
_#_Executive branch: British monarch, governor general, prime
minister, Ministers of Government (cabinet)
_#_Legislative branch: bicameral Parliament consists of an upper
house or Senate and a lower house or House of Representatives
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor General Sir Paul SCOON (since 30 September 1978);
Head of Government--Prime Minister Nicholas BRATHWAITE
(since 13 March 1990)
_#_Political parties and leaders:
National Democratic Congress (NDC), Nicholas BRATHWAITE;
Grenada United Labor Party (GULP), Sir Eric GAIRY;
The National Party (TNP), Ben JONES; New National Party (NNP), Keith
MITCHELL;
Maurice Bishop Patriotic Movement (MBPM), Terrence MERRYSHOW;
New Jewel Movement (NJM), Bernard COARD
_#_Suffrage: universal at age 18
_#_Elections:
House of Representatives--last held on 13 March 1990 (next
to be held by March 1996);
results--percent of vote by party NA;
seats--(15 total) NDC 8, GULP 3, TNP 2, NNP 2
_#_Communists: about 450 members of the New Jewel Movement
(pro-Soviet) and the Maurice Bishop Patriotic Movement (pro-Cuban)
_#_Member of: ACP, C, CARICOM, CDB, ECLAC, FAO, G-77, IBRD, ICAO,
ICFTU, IDA, IFAD, IFC, ILO, IMF, INTERPOL, IOC, ITU, LAES, LORCS,
NAM, OAS, OECS, OPANAL, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL,
WHO, WTO
_#_Diplomatic representation: Ambassador Denneth MODESTE; Chancery at
1701 New Hampshire Avenue NW, Washington DC 20009; telephone (202)
265-2561; there is a Grenadian Consulate General in New York;
US--Charge d''Affaires Annette VELER; Embassy at Ross Point Inn,
Saint George''s (mailing address is P. O. Box 54, Saint George''s);
telephone (809) 444-1173 through 1178
_#_Flag: a rectangle divided diagonally into yellow triangles (top and
bottom) and green triangles (hoist side and outer side) with a red border
around the flag; there are seven yellow five-pointed stars with three
centered in the top red border, three centered in the bottom red border,
and one on a red disk superimposed at the center of the flag; there is
also a symbolic nutmeg pod on the hoist-side triangle (Grenada is the
world''s second-largest producer of nutmeg, after Indonesia); the seven
stars represent the seven administrative divisions
_#_Long-form name: Department of Guadeloupe
_#_Type: overseas department of France
_#_Capital: Basse-Terre
_#_Administrative divisions: none (overseas department of France)
_#_Independence: none (overseas department of France)
_#_Constitution: 28 September 1958 (French Constitution)
_#_Legal system: French legal system
_#_National holiday: Taking of the Bastille, 14 July (1789)
_#_Executive branch: government commissioner
_#_Legislative branch: unicameral General Council and unicameral
Regional Council
_#_Judicial branch: Court of Appeal (Cour d''Appel) with jurisdiction
over Guadeloupe, French Guiana, and Martinique
_#_Leaders:
Chief of State--President Francois MITTERRAND (since
21 May 1981);
Head of Government--Commissioner of the Republic Jean-Paul PROUST
(since November 1989)
_#_Political parties and leaders:
Rally for the Republic (RPR), Marlene CAPTANT;
Communist Party of Guadeloupe (PCG), Christian Medard CELESTE;
Socialist Party (PSG), Dominique LARIFLA;
Independent Republicans;
Union for French Democracy (UDF);
Union for a New Majority (UNM)
_#_Suffrage: universal at age 18
_#_Elections:
General Council --last held NA 1986 (next to be held by NA 1992);
results--percent of vote by party NA;
seats--(42 total) number of seats by party NA;
Regional Council--last held on 16 March 1986 (next to be held
by 16 March 1992);
results--RPR 33.1%, PS 28.7%, PCG 23.8%, UDF 10.7%, other 3.7%;
seats--(41 total) RPR 15, PS 12, PCG 10, UDF 4;
French Senate--last held on 5 and 12 June 1988 (next to be
held June 1994); Guadeloupe elects two representatives;
results--percent of vote by party NA;
seats--(2 total) PCG 1, PS 1;
French National Assembly--last held on 5 and 12 June 1988
(next to be held June 1994); Guadeloupe elects four representatives;
results--percent of vote by party NA;
seats--(4 total) PS 2 seats, RPR 1 seat, PCG 1 seat
_#_Communists: 3,000 est.
_#_Other political or pressure groups: Popular Union for the
Liberation of Guadeloupe (UPLG); Popular Movement for Independent
Guadeloupe (MPGI); General Union of Guadeloupe Workers (UGTG); General
Federation of Guadeloupe Workers (CGT-G); Christian Movement for
the Liberation of Guadeloupe (KLPG)
_#_Member of: FZ, WCL, WFTU
_#_Diplomatic representation: as an overseas department of France,
the interests of Guadeloupe are represented in the US by France
_#_Flag: the flag of France is used
_#_Long-form name: Territory of Guam
_#_Type: organized, unincorporated territory of the US
_#_Capital: Agana
_#_Administrative divisions: none (territory of the US)
_#_Independence: none (territory of the US)
_#_Constitution: Organic Act of 1 August 1950
_#_Legal system: NA
_#_National holiday: Guam Discovery Day (first Monday in March),
6 March 1989
_#_Executive branch: President of the US, governor,
lieutenant governor, Cabinet
_#_Legislative branch: unicameral Legislature
_#_Judicial branch: Superior Court of Guam (Federal District Court)
_#_Leaders:
Chief of State--President George BUSH (since 20 January 1989);
Head of Government--Governor Joseph A. ADA (since NA November
1986); Lieutenant Governor Frank F. BLAS
_#_Political parties and leaders:
Democratic Party (controls the legislature);
Republican Party (party of the Governor)
_#_Suffrage: universal at age 18; US citizens, but do not vote in US
presidential elections
_#_Elections:
Governor--last held on 6 November 1990 (next to be held
November 1994);
Legislature--last held on 6 November 1990 (next to be held
November 1992);
results--percent of vote by party NA;
seats--(21 total) Democratic 11, Republican 10;
US House of Representatives--last held 6 November
1990 (next to be held November 1992);
Guam elects one nonvoting delegate;
results--percent of vote by party NA;
seats--(1 total) Republican 1
_#_Communists: none
_#_Note: relations between Guam and the US are under the jurisdiction
of the Office of Territorial and International Affairs, US Department of
the Interior
_#_Member of: ESCAP (associate), IOC, SPC
_#_Diplomatic representation: none (territory of the US)
_#_Flag: dark blue with a narrow red border on all four sides;
centered is a red-bordered, pointed, vertical ellipse containing a
beach scene, outrigger canoe with sail, and a palm tree with the word
GUAM superimposed in bold red letters
_#_Long-form name: Republic of Guatemala
_#_Type: republic
_#_Capital: Guatemala
_#_Administrative divisions: 22 departments (departamentos,
singular--departamento); Alta Verapaz, Baja Verapaz, Chimaltenango,
Chiquimula, El Progreso, Escuintla, Guatemala, Huehuetenango, Izabal,
Jalapa, Jutiapa, Peten, Quetzaltenango, Quiche, Retalhuleu,
Sacatepequez, San Marcos, Santa Rosa, Solola, Suchitepequez,
Totonicapan, Zacapa
_#_Independence: 15 September 1821 (from Spain)
_#_Constitution: 31 May 1985, effective 14 January 1986
_#_Legal system: civil law system; judicial review of legislative
acts; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 15 September (1821)
_#_Executive branch: president, vice president, Council of Ministers
(cabinet)
_#_Legislative branch: unicameral Congress of the Republic
(Congreso de la Republica)
_#_Judicial branch: Supreme Court of Justice (Corte Suprema de
Justicia)
_#_Leaders:
Chief of State and Head of Government--President Jorge SERRANO
Elias (since 14 January 1991); Vice President Gustavo ESPINA Salguero
(since 14 January 1991)
_#_Political parties and leaders:
National Centrist Union (UCN), Jorge CARPIO Nicolle;
Solidarity Action Movement (MAS), Jorge SERRANO Elias;
Christian Democratic Party (DCG), Alfonso CABRERA Hidalgo;
National Advancement Party (PAN), Alvaro ARZU Irigoyen;
National Liberation Movement (MLN), Mario SANDOVAL Alarcon;
Social Democratic Party (PSD), Mario SOLARZANO Martinez;
Popular Alliance 5 (AP-5), Max ORLANDO Molina;
Revolutionary Party (PR), Carlos CHAVARRIA;
National Authentic Center (CAN), Hector MAYORA Dawe;
Alliance for ''90 led by Rios MONTT, consisting of three
parties--Democratic Institutional Party (PID), Oscar RIVAS;
Nationalist United Front (FUN), Gabriel GIRON;
Guatemalan Republican Front (FRG), Berna ROLANDO Mendez
_#_Suffrage: universal at age 18
_#_Elections:
President--runoff held on 11 January 1991 (next to be held
11 November 1995);
results--Jorge SERRANO Elias (MAS) 68.1%, Jorge CARPIO
Nicolle (UCN) 31.9%;
Congress--last held on 11 November 1990 (next to be held
11 November 1995);
results--UCN 25.6%, MAS 24.3%, DCG 17.5%, PAN 17.3%, MLN 4.8%,
PSD/AP-5 3.6%, PR 2.1%;
seats--(116 total) UCN 41, DCG 28, MAS 18, PAN 12, Alliance for ''90
11, MLN 4, PR 1, PSD/AP-5 1
_#_Communists: Guatemalan Labor Party (PGT); main radical left
guerrilla groups--Guerrilla Army of the Poor (EGP), Revolutionary
Organization of the People in Arms (ORPA), Rebel Armed Forces (FAR),
and PGT dissidents
_#_Other political or pressure groups: Federated Chambers of Commerce
and Industry (CACIF), Mutual Support Group (GAM), Unity for Popular and
Labor Action (UASP), Agrarian Owners Group (UNAGRO), Committee for
Campesino Unity (CUC)
_#_Member of: BCIE, CACM, CCC, ECLAC, FAO, G-24, G-77, IADB, IAEA,
IBRD, ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL,
IOC, IOM, ITU, LAES, LAIA (observer), LORCS, OAS, OPANAL, PCA, UN,
UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Juan Jose CASO Fanjul;
Chancery at 2220 R Street NW, Washington DC 20008; telephone (202)
745-4952 through 4954;
there are Guatemalan Consulates General in Chicago, Houston, Los Angeles,
Miami, New Orleans, New York, and San Francisco;
US--Ambassador Thomas F. STROOCK; Embassy at 7-01 Avenida de la
Reforma, Zone 10, Guatemala City (mailing address is APO Miami 34024);
telephone [502] (2) 31-15-41
_#_Flag: three equal vertical bands of light blue (hoist side),
white, and light blue with the coat of arms centered in the white
band; the coat of arms includes a green and red quetzal (the national
bird) and a scroll bearing the inscription LIBERTAD 15 DE
SEPTIEMBRE DE 1821 (the original date of independence from Spain)
all superimposed on a pair of crossed rifles and a pair of crossed
swords and framed by a wreath
_#_Long-form name: Bailiwick of Guernsey
_#_Type: British crown dependency
_#_Capital: Saint Peter Port
_#_Administrative divisions: none (British crown dependency)
_#_Independence: none (British crown dependency)
_#_Constitution: unwritten; partly statutes, partly common law and
practice
_#_Legal system: English law and local statute; justice is
administered by the Royal Court
_#_National holiday: Liberation Day, 9 May (1945)
_#_Executive branch: British monarch, lieutenant governor, bailiff,
deputy bailiff
_#_Legislative branch: unicameral Assembly of the States
_#_Judicial branch: Royal Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952);
Head of Government--Lieutenant Governor Lt. Gen. Sir Michael
WILKINS (since 1990); Bailiff Sir Charles FROSSARD (since 1982)
_#_Political parties and leaders: none; all independents
_#_Suffrage: universal at age 18
_#_Elections:
Assembly of the States--last held NA (next to be held NA);
results--percent of vote NA;
seats--(60 total, 33 elected), all independents
_#_Communists: none
_#_Member of: none
_#_Diplomatic representation: none (British crown dependency)
_#_Flag: white with the red cross of Saint George (patron saint of
England) extending to the edges of the flag
_#_Long-form name: Republic of Guinea
_#_Type: republic
_#_Capital: Conakry
_#_Administrative divisions: 29 administrative regions (regions
administratives, singular--region administrative); Beyla, Boffa,
Boke, Conakry, Dabola, Dalaba, Dinguiraye, Dubreka, Faranah,
Forecariah, Fria, Gaoual, Gueckedou, Kankan, Kerouane, Kindia,
Kissidougou, Koundara, Kouroussa, Labe, Macenta, Mali, Mamou,
Nzerekore, Pita, Siguiri, Telimele, Tougue, Yomou
_#_Independence: 2 October 1958 (from France; formerly French Guinea)
_#_Constitution: 23 December 1990 (Loi Fundamentale)
_#_Legal system: based on French civil law system, customary law,
and decree; legal codes currently being revised; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: Anniversary of the Second Republic, 3 April
(1984)
_#_Executive branch: president, Transitional Committee for National
Recovery (Comite Transitionale de Redressement National or CTRN)
replaced the Military Committee for National Recovery (Comite
Militaire de Redressement National or CMRN); Council of Ministers
(cabinet)
_#_Legislative branch: People''s National Assembly (Assemblee
Nationale Populaire) was dissolved after the 3 April 1984 coup
_#_Judicial branch: Court of Appeal (Cour d''Appel)
_#_Leaders:
Chief of State and Head of Government--Gen. Lansana CONTE (since
5 April 1984)
_#_Political parties and leaders: none; following the 3 April 1984
coup all political activity was banned
_#_Suffrage: none
_#_Elections: none
_#_Communists: no Communist party, although there are some
sympathizers
_#_Member of: ACCT, ACP, AfDB, CEAO (observer), ECA, ECOWAS, FAO, FZ,
G-77, IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL,
IOC, ISO (correspondent), ITU, LORCS, NAM, OAU, OIC, UN,
UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador (vacant); Chancery at
2112 Leroy Place NW, Washington DC 20008; telephone (202) 483-9420;
US--Ambassador Dane F. SMITH, Jr.; Embassy at 2nd Boulevard and 9th
Avenue, Conakry (mailing address is B. P. 603, Conakry); telephone (224)
44-15-20 through 24
_#_Flag: three equal vertical bands of red (hoist side), yellow, and
green; uses the popular pan-African colors of Ethiopia; similar to the
flag of Rwanda which has a large black letter R centered in the
yellow band
_#_Long-form name: Republic of Guinea-Bissau
_#_Type: republic; highly centralized one-party regime since September
1974; the African Party for the Independence of Guinea-Bissau and Cape
Verde (PAIGC) held an extraordinary party congress in December 1990 and
established a two-year transition program during which the constitution
will be revised, allowing for multiple political parties and a
presidential election in 1993
_#_Capital: Bissau
_#_Administrative divisions: 9 regions (regioes,
singular--regiao); Bafata, Biombo, Bissau, Bolama, Cacheu, Gabu,
Oio, Quinara, Tombali
_#_Independence: 24 September 1973 (from Portugal; formerly Portuguese
Guinea)
_#_Constitution: 16 May 1984
_#_Legal system: NA
_#_National holiday: Independence Day, 24 September (1973)
_#_Executive branch: president of the Council of State, vice
presidents of the Council of State, Council of State, Council of
Ministers (cabinet)
_#_Legislative branch: unicameral National People''s Assembly
(Assembleia Nacional Popular)
_#_Judicial branch: none; there is a Ministry of Justice in the
Council of Ministers
_#_Leaders:
Chief of State and Head of Government--President of the
Council of State Brig. Gen. Joao Bernardo VIEIRA (assumed power 14
November 1980 and elected President of Council of State on 16 May 1984);
First Vice President Col. Iafai CAMARA (since 7 November 1985); Second
Vice President Vasco CABRAL (since 21 June 1989)
_#_Political parties and leaders: only party--African Party for the
Independence of Guinea-Bissau and Cape Verde (PAIGC), President
Joao Bernardo VIEIRA, leader; the party decided to retain the
binational title despite its formal break with Cape Verde
_#_Suffrage: universal at age 15
_#_Elections:
President of Council of State--last held 19 June 1989
(next to be held NA 1993);
results--Brig. Gen. Joao Bernardo VIEIRA was reelected without
opposition by the National People''s Assembly;
National People''s Assembly--last held 15 June 1989 (next
to be held 15 June 1994);
results--PAIGC is the only party;
seats--(150 total) PAIGC 150, appointed by Regional Councils
_#_Communists: a few Communists, some sympathizers
_#_Member of: ACCT (associate), ACP, AfDB, ECA, ECOWAS, FAO, G-77,
IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, IOM (observer), ITU,
LORCS, NAM, OAU, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU,
WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Alfredo Lopes CABRAL;
Chancery (temporary) at the Guinea-Bissauan Permanent Mission to the UN,
Suite 604, 211 East 43rd Street, New York, NY 10017; telephone (212)
661-3977;
US--Ambassador William L. JACOBSEN, Jr.; Embassy at 17 Avenida
Domingos Ramos, Bissau (mailing address is 1067 Bissau Codex, Bissau,
Guinea-Bissau); telephone [245] 20-1139, 20-1145, 20-1113
_#_Flag: two equal horizontal bands of yellow (top) and green with a
vertical red band on the hoist side; there is a black five-pointed star
centered in the red band; uses the popular pan-African colors of
Ethiopia; similar to the flag of Cape Verde which has the black star
raised above the center of the red band and is framed by two corn stalks
and a yellow clam shell','382e0eb880dd537146b679866c5cb3cd21a17c56ec5b27d45263b0599cedcb1d','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96c806b9bc4a3eabb8776b2eb3ae76c2dc1485c45cbbcee6b965278f0a6668b7',1991,'ES','Spain','government',84,'_#_Long-form name: Co-operative Republic of Guyana
_#_Type: republic
_#_Capital: Georgetown
_#_Administrative divisions: 10 regions; Barima-Waini,
Cuyuni-Mazaruni, Demerara-Mahaica, East Berbice-Corentyne, Essequibo
Islands-West Demerara, Mahaica-Berbice, Pomeroon-Supenaam,
Potaro-Siparuni, Upper Demerara-Berbice, Upper Takutu-Upper Essequibo
_#_Independence: 26 May 1966 (from UK; formerly British Guiana)
_#_Constitution: 6 October 1980
_#_Legal system: based on English common law with certain admixtures
of Roman-Dutch law; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Republic Day, 23 February (1970)
_#_Executive branch: executive president, first vice president,
prime minister, first deputy prime minister, Cabinet
_#_Legislative branch: unicameral National Assembly
_#_Judicial branch: Supreme Court of Judicature
_#_Leaders:
Chief of State--Executive President Hugh Desmond HOYTE (since 6
August 1985); First Vice President Hamilton GREEN (since 6 August 1985);
Head of Government--Prime Minister Hamilton GREEN (since
NA August 1985)
_#_Political parties and leaders:
People''s National Congress (PNC), Hugh Desmond HOYTE;
People''s Progressive Party (PPP), Cheddi JAGAN;
Working People''s Alliance (WPA), Eusi KWAYANA, Rupert ROOPNARINE, Moses
BHAGWAN;
Democratic Labor Movement (DLM), Paul TENNASSEE;
People''s Democratic Movement (PDM), Llewellyn JOHN;
National Democratic Front (NDF), Joseph BACCHUS;
United Force (UF), Marcellus Feilden SINGH;
United Republican Party (URP), Leslie RAMSAMMY;
National Republican Party (NRP), Robert GANGADEEN
_#_Suffrage: universal at age 18
_#_Elections:
Executive President--last held on 9 December 1985 (next to be
held mid-1991); Hugh Desmond HOYTE was elected president (the
leader of the party with the most votes in the National Assembly
elections);
National Assembly--last held on 9 December 1985 (next to be held
mid-1991);
results--PNC 78%, PPP 16%, UF 4%, WPA 2%;
seats--(65 total, 53 elected) PNC 42, PPP 8, UF 2, WPA 1
_#_Communists: 100 (est.) hardcore within PPP; top echelons of PPP
and PYO (Progressive Youth Organization, militant wing of the PPP)
include many Communists; small but unknown number of orthodox
Marxist-Leninists within PNC, some of whom formerly belonged to the PPP
_#_Other political or pressure groups: Trades Union Congress (TUC);
Guyanese Action for Reform and Democracy (GUARD) includes various labor
groups as well as several of the smaller parties; Guyana Council of
Indian Organizations (GCIO); Civil Liberties Action Committee (CLAC);
the latter two organizations are small and active but not well
organized; Guyanese Action for Reform and Democracy (GUARD) includes
various labor groups, as well as several of the smaller political
parties
_#_Member of: ACP, C, CARICOM, CCC, CDB, ECLAC, FAO, G-77, GATT, IADB,
IBRD, ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTERPOL, IOC, ITU,
LAES, LORCS, NAM, OAS, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO,
WMO
_#_Diplomatic representation: Ambassador Dr. Cedric Hilburn GRANT;
Chancery at 2490 Tracy Place NW, Washington DC 20008; telephone (202)
265-6900; there is a Guyanese Consulate General in New York;
US--Ambassador George JONES; Embassy at 31 Main Street,
Georgetown; telephone [592] (02) 54900 through 54909
_#_Flag: green with a red isosceles triangle (based on the hoist side)
superimposed on a long yellow arrowhead; there is a narrow black border
between the red and yellow, and a narrow white border between the yellow
and the green
_#_Long-form name: Republic of Haiti
_#_Type: republic
_#_Capital: Port-au-Prince
_#_Administrative divisions: 9 departments, (departements,
singular--departement); Artibonite, Centre, Grand''Anse, Nord, Nord-Est,
Nord-Ouest, Ouest, Sud, Sud-Est
_#_Independence: 1 January 1804 (from France)
_#_Constitution: 27 August 1983, suspended February 1986; draft
constitution approved March 1987, suspended June 1988, most articles
reinstated March 1989; March 1987 Constitution fully observed by
government installed on 7 February 1991
_#_Legal system: based on Roman civil law system; accepts compulsory
ICJ jurisdiction
_#_National holiday: Independence Day, 1 January (1804)
_#_Executive branch: president, Council of Ministers (cabinet)
_#_Legislative branch: bicameral National Assembly (Assemblee
Nationale) consisting of an upper house or Senate and a lower house or
House of Deputies
_#_Judicial branch: Court of Appeal (Cour de Cassation)
_#_Leaders:
Chief of State--President Jean-Bertrand ARISTIDE (since 7 February
1991);
Head of Government--Prime Minister Rene PREVAL (since
13 February 1991)
_#_Political parties and leaders:
National Front for Change and Democracy (FNCD) led by Jean-Bertrand
ARISTIDE, including Congress of Democratic Movements (CONACOM), Victor
BENOIT; National Konbite Movement (MKN), Volvick Remy JOSEPH;
National Alliance for Democracy and Progress (ANDP), a coalition
consisting of Movement for the Installation of Democracy in Haiti (MIDH),
Marc BAZIN; National Progressive Revolutionary Party (PANPRA), Serge
GILLES; and National Patriotic Movement of November 28 (MNP-28), Dejean
BELIZAIRE;
National Agricultural and Industrial Party (PAIN), Louis DEJOIE;
Movement for National Reconstruction (MRN), Rene THEODORE;
Haitian Christian Democratic Party (PDCH), Sylvio CLAUDE;
Assembly of Progressive National Democrats (RDNP), Leslie MANIGAT;
National Party of Labor (PNT), Thomas DESULME;
Mobilization for National Development (MDN), Hubert DE RONCERAY;
Democratic Movement for the Liberation of Haiti (MODELH), Francois
LATORTUE;
Haitian Social Christian Party (PSCH), Gregoire EUGENE;
Movement for the Organization of the Country (MOP), Gesner COMEAU
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 16 December 1990 (next election to be held
by December 1995);
results--Rev. Jean-Bertrand ARISTIDE 67.5%, Marc BAZIN 14.2%, Louis
DEJOIE 4.9%;
Senate--last held 16 December 1990, with runoff held 20 January
1991 (next to be held by December 1992);
results--percent of vote NA;
seats--(27) FNCD 13, ANDP 6, PAIN 2, MRN 2, PDCH 1, RDNP 1, PNT 1,
independent 1;
Chamber of Deputies--last held 16 December 1990, with runoff
held 20 January 1991 (next to be held by December 1994);
results--percent of vote NA;
seats--(83) FNCD 27, ANDP 17, PDCH 7, PAIN 6, RDNP 6, MDN 5, PNT 3,
MKN 2, MODELH 2, MRN 1, independent 5, other 2
_#_Communists: United Party of Haitian Communists (PUCH), Rene
THEODORE (roughly 2,000 members)
_#_Other political or pressure groups: Democratic Unity Confederation
(KID), Roman Catholic Church, Confederation of Haitian Workers (CTH),
Federation of Workers Trade Unions (FOS), Autonomous Haitian Workers
(CATH), National Popular Assembly (APN)
_#_Member of: ACCT, CARICOM (observer), CCC, ECLAC, FAO, G-77, GATT,
IADB, IAEA, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, ITU, LAES, LORCS, OAS, OPANAL, PCA, UN, UNCTAD, UNESCO,
UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador (vacant), Charge
d''Affaires Raymond Alcide JOSEPH; Chancery at 2311 Massachusetts Avenue
NW, Washington DC 20008; telephone (202) 332-4090 through 4092; there
are Haitian Consulates General in Boston, Chicago, Miami, New York,
and San Juan (Puerto Rico);
US--Ambassador Alvin P. ADAMS, Jr.; Embassy at Harry Truman
Boulevard, Port-au-Prince (mailing address is P. O. Box 1761,
Port-au-Prince), telephone [509] (1) 20-354 or 20-368, 20-200, 20-612
_#_Flag: two equal horizontal bands of blue (top) and red with a
centered white rectangle bearing the coat of arms which contains a palm
tree flanked by flags and two cannons above a scroll bearing the motto
L''UNION FAIT LA FORCE (Union Makes Strength)
_#_Long-form name: Territory of Heard Island and McDonald Islands
_#_Type: territory of Australia administered by the Antarctic Division
of the Department of Science in Canberra (Australia)
_#_Long-form name: Republic of Honduras
_#_Type: republic
_#_Capital: Tegucigalpa
_#_Administrative divisions: 18 departments (departamentos,
singular--departamento); Atlantida, Choluteca, Colon, Comayagua,
Copan, Cortes, El Paraiso, Francisco Morazan, Gracias a Dios,
Intibuca, Islas de la Bahia, La Paz, Lempira, Ocotepeque, Olancho,
Santa Barbara, Valle, Yoro
_#_Independence: 15 September 1821 (from Spain)
_#_Constitution: 11 January 1982, effective 20 January 1982
_#_Legal system: rooted in Roman and Spanish civil law; some influence
of English common law; accepts ICJ jurisdiction, with reservations
_#_National holiday: Independence Day, 15 September (1821)
_#_Executive branch: president, Council of Ministers (cabinet)
_#_Legislative branch: unicameral National Congress (Congreso
Nacional)
_#_Judicial branch: Supreme Court of Justice (Corte Suprema de
Justica)
_#_Leaders:
Chief of State and Head of Government--Rafael Leonardo CALLEJAS
Romero (since 26 January 1990)
_#_Political parties and leaders:
Liberal Party (PLH)--faction leaders, Carlos FLORES Facusse (leader of
Florista Liberal Movement), Carlos MONTOYA (Azconista subfaction), Ramon
VILLEDA Bermudez and Jorge Arturo REINA (M-Lider faction);
National Party (PNH), Jose Celin DISCUA, party president;
PNH faction leaders--Oswaldo RAMOS Soto and Rafael Leonardo CALLEJAS
(Monarca faction);
National Innovation and Unity Party-Social Democrats (PINU-SD), Enrique
AGUILAR Cerrato Paz;
Christian Democratic Party (PDCH), Jorge ILLESCAS;
Democratic Action (AD), Walter LOPEZ Reyes
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
President--last held on 26 November 1989 (next to be held
November 1993);
results--Rafael Leonardo CALLEJAS (PNH) 51%,
Carlos FLORES Facusse (PLH) 43.3%, other 5.7%;
National Congress--last held on 26 November 1989 (next to be held
November 1993);
results--PNH 51%, PLH 43%, PDCH 1.9%, PINU 1.5%, other 2.6%;
seats--(128 total) PNH 71, PLH 55, PINU 2
_#_Communists: up to 1,500; Honduran leftist groups--Communist Party
of Honduras (PCH), Party for the Transformation of Honduras (PTH),
Morazanist Front for the Liberation of Honduras (FMLH), People''s
Revolutionary Union/Popular Liberation Movement (URP/MPL), Popular
Revolutionary Forces-Lorenzo Zelaya (FPR/LZ), Socialist Party of Honduras
Central American Workers Revolutionary Party (PASO/PRTC)
_#_Other political or pressure groups: National Association of
Honduran Campesinos (ANACH), Honduran Council of Private Enterprise
(COHEP), Confederation of Honduran Workers (CTH), National Union of
Campesinos (UNC), General Workers Confederation (CGT), United Federation
of Honduran Workers (FUTH), Committee for the Defense of Human Rights in
Honduras (CODEH), Coordinating Committee of Popular Organizations (CCOP)
_#_Member of: BCIE, CACM, ECLAC, FAO, G-77, IADB, IBRD, ICAO, ICFTU,
IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, IOM, ITU, LAES,
LAIA (observer), LORCS, OAS, OPANAL, PCA, UN, UNCTAD, UNESCO, UNIDO,
UPU, WCL, WFTU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Jorge Ramon HERNANDEZ
Alcerro; Chancery at Suite 100, 4301 Connecticut Avenue NW, Washington
DC 20008; telephone (202) 966-7700 through 7702; there are Honduran
Consulates General in Chicago, Los Angeles, Miami, New Orleans, New York,
and San Francisco, and Consulates in Baton Rouge, Boston, Detroit,
Houston, and Jacksonville;
US--Ambassador S. Crescencio ARCOS; Embassy at Avenida La Paz,
Tegucigalpa (mailing address is APO Miami 34022); telephone [504] 32-3120
_#_Flag: three equal horizontal bands of blue (top), white, and blue
with five blue five-pointed stars arranged in an X pattern centered
in the white band; the stars represent the members of the former Federal
Republic of Central America--Costa Rica, El Salvador, Guatemala,
Honduras, and Nicaragua; similar to the flag of El Salvador which
features a round emblem encircled by the words REPUBLICA DE EL
SALVADOR EN LA AMERICA CENTRAL centered in the white band; also
similar to the flag of Nicaragua which features a triangle
encircled by the words REPUBLICA DE NICARAGUA on top and AMERICA
CENTRAL on the bottom, centered in the white band
_#_Long-form name: none; abbreviated HK
_#_Type: dependent territory of the UK; scheduled to revert to
China in 1997
_#_Capital: Victoria
_#_Administrative divisions: none (dependent territory of the UK)
_#_Independence: none (dependent territory of the UK); the UK
signed an agreement with China on 19 December 1984 to return Hong Kong to
China on 1 July 1997; in the joint declaration, China promises to respect
Hong Kong''s existing social and economic systems and lifestyle for 50
years after transition
_#_Constitution: unwritten; partly statutes, partly common law and
practice; new Basic Law approved in March 1990 in preparation for 1997
_#_Legal system: based on English common law
_#_National holiday: Liberation Day, 29 August (1945)
_#_Executive branch: British monarch, governor, chief secretary of the
Executive Council
_#_Legislative branch: Legislative Council
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952);
Head of Government--Governor Sir David Clive WILSON (since 9
April 1987);
Chief Secretary Sir David Robert FORD (since NA February 1987)
_#_Political parties:
United Democrats of Hong Kong (UDHK), Martin LEE Chu-ming;
Liberal Democratic Federation (LDF), HU Fa-kuang;
Hong Kong Democratic Foundation (HKDF), Patrick SHIU Kin-ying;
Association for Democracy and People''s Livelihood (ADPL),
Frederick FUNG Kin-kee;
Meeting Point, Anthony CHEUNG Bing-leung;
Progressive Hong Kong Society (PHKS), Maria TAM Wai-chu
_#_Suffrage: direct election--universal at age 21
as a permanent resident living in the territory of Hong Kong for
the past seven years; indirect election--limited to about 100,000
professionals of electoral college and functional constituencies
_#_Elections:
Legislative Council--indirect elections last held 12 September 1991
and direct elections held 15 September 1991 (next to be held by
September 1995);
results--percent of vote by party NA;
seats--(60 total;
21 indirectly elected by functional constituencies, 18 directly elected,
18 appointed by governor, 3 ex officio members) indirect
elections--number of seats by functional constituency NA; direct
elections--UDHK 12, Meeting Point 2, ADPL 1, other 3; note--direct
elections were held for the first time in September 1991
_#_Communists: 5,000 (est.) cadres affiliated with Communist Party
of China
_#_Other political or pressure groups:
Federation of Trade Unions (pro-China), Hong Kong and Kowloon Trade
Union Council (pro-Taiwan), Confederation of Trade Unions (prodemocracy),
Hong Kong General Chamber of Commerce, Chinese General Chamber of
Commerce (pro-China), Federation of Hong Kong Industries, Chinese
Manufacturers'' Association of Hong Kong, Hong Kong Professional Teachers''
Union, Hong Kong Alliance in Support of the Patriotic Democratic Movement
in China
_#_Member of: AsDB, CCC, ESCAP (associate), GATT, ICFTU,
IMO (associate), IOC, ISO (correspondent), WCL, WMO
_#_Diplomatic representation: as a dependent territory of the UK,
the interests of Hong Kong in the US are represented by the UK;
US--Consul General Richard L. WILLIAMS; Consulate General at
26 Garden Road, Hong Kong (mailing address is Box 30, Hong Kong, or
FPO San Francisco 96659-0002); telephone [852] (5) 845-1598
_#_Flag: blue with the flag of the UK in the upper hoist-side quadrant
with the Hong Kong coat of arms on a white disk centered on the outer
half of the flag; the coat of arms contains a shield (bearing two junks
below a crown) held by a lion (representing the UK) and a dragon
(representing China) with another lion above the shield and a banner
bearing the words HONG KONG below the shield
_#_Long-form name: none
_#_Type: unincorporated territory of the US administered by the Fish
and Wildlife Service of the US Department of the Interior as part of the
National Wildlife Refuge System
_#_Long-form name: Republic of Hungary
_#_Type: republic
_#_Capital: Budapest
_#_Administrative divisions: 19 counties (megyek, singular--megye)
and 1 capital city* (fovaros); Bacs-Kiskun, Baranya, Bekes,
Borsod-Abauj-Zemplen, Budapest*, Csongrad, Fejer,
Gyor-Moson-Sopron, Hajdu-Bihar, Heves, Jasz-Nagykun-Szolnok,
Komarom-Esztergom, Nograd, Pest, Somogy, Szabolcs-Szatmar-Bereg,
Tolna, Vas, Veszprem, Zala
_#_Independence: 1001, unification by King Stephen I
_#_Constitution: 18 August 1949, effective 20 August 1949, revised
19 April 1972; 18 October 1989 revision ensures legal rights for
individuals and constitutional checks on the authority of the prime
minister and established the principle of parliamentary oversight
_#_Legal system: in process of revision, moving toward rule of law
based on Western model
_#_National holiday: October 23 (1956); commemorates the Hungarian
uprising
_#_Executive branch: president, prime minister
_#_Legislative branch: unicameral National Assembly
(Orszaggyules)
_#_Judicial branch: Supreme Court, may be restructured as part of
ongoing government overhaul
_#_Leaders:
Chief of State--President Arpad GONCZ (since 3 August 1990;
previously interim President from 2 May 1990);
Head of Government--Prime Minister Jozsef ANTALL
(since 23 May 1990)
_#_Political parties and leaders:
Democratic Forum, Jozsef ANTALL, chairman;
Free Democrats, Janos KIS, chairman;
Independent Smallholders, Ferenc Jozsef NAGY, president;
Hungarian Socialist Party (MSP), Gyula HORN, chairman;
Young Democrats, Gabor FODOR, head;
Christian Democrats, Dr. Lazlo SURJAN, president;
note--the Hungarian Socialist (Communist) Workers'' Party (MSZMP)
renounced Communism and became the Hungarian Socialist Party (MSP) in
October 1989
_#_Suffrage: universal at age 18
_#_Elections:
President last held 3 August 1990 (next to be held August 1995);
elected by the National Assembly with a total of 294 votes out of 304;
President GONCZ was elected by the National Assembly as interim President
from 2 May 1990 until elected President;
National Assembly--last held on 25 March 1990 (first round, with
the second round held 8 April 1990);
results--percent of vote by party NA;
seats--(394 total) Democratic Forum 165, Free Democrats 92,
Independent Smallholders 43, Hungarian Socialist Party (MSP) 33,
Young Democrats 21, Christian Democrats 21, independent candidates
or jointly sponsored candidates 19
_#_Communists: fewer than 100,000 (December 1989)
_#_Member of: BIS, CCC, CE, CSCE, ECE, FAO, G-9, GATT,
IAEA, IBEC, IBRD, ICAO, IDA, IFC, IIB, ILO, IMF, IMO, INTERPOL, IOC, ISO,
ITU, LORCS, PCA, UN, UNCTAD, UNESCO, UNIDO, UNIIMOG, UPU, WFTU,
WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador (vacant);
Chancery at 3910 Shoemaker Street NW, Washington DC 20008; telephone
(202) 362-6730; there is a Hungarian Consulate General in New York;
US--Ambassador Charles THOMAS; Embassy at V. Szabadsag
Ter 12, Budapest (mailing address is APO New York 09213); telephone [36]
(1) 112-6450
_#_Flag: three equal horizontal bands of red (top), white, and green
_#_Long-form name: Republic of Iceland
_#_Type: republic
_#_Capital: Reykjavik
_#_Administrative divisions: 23 counties (syslar, singular--sysla)
and 14 independent towns* (kaupstadhir, singular--kaupstadhur); Akranes*,
Akureyri*, Arnessysla, Austur-Bardhastrandarsysla,
Austur-Hunavatnssysla, Austur-Skaftafellssysla,
Borgarfjardharsysla, Dalasysla, Eyjafjardharsysla,
Gullbringusysla, Hafnarfjordhur*, Husavik*, Isafjordhur*,
Keflavik*, Kjosarsysla, Kopavogur*, Myrasysla,
Neskaupstadhur*, Nordhur-Isafjardharsysla, Nordhur-Mulasysla,
Nordhur-Thingeyjarsysla, Olafsfjordhur*, Rangarvallasysla,
Reykjavik*, Saudharkrokur*, Seydhisfjordhur*, Siglufjordhur*,
Skagafjardharsysla, Snaefellsnes-og Hnappadalssysla, Strandasysla,
Sudhur-Mulasysla, Sudhur-Thingeyjarsysla, Vestmannaeyjar*,
Vestur-Bardhastrandarsysla, Vestur-Hunavatnssysla,
Vestur-Isafjardharsysla, Vestur-Skaftafellssysla
_#_Independence: 17 June 1944 (from Denmark)
_#_Constitution: 16 June 1944, effective 17 June 1944
_#_Legal system: civil law system based on Danish law; does not accept
compulsory ICJ jurisdiction
_#_National holiday: Anniversary of the Establishment of the Republic,
17 June (1944)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: bicameral Althingi with an Upper
House (Efri Deild) and a Lower House (Nedri Deild)
_#_Judicial branch: Supreme Court (Haestirettur)
_#_Leaders:
Chief of State--President Vigdis FINNBOGADOTTIR (since 1
August 1980);
Head of Government--Prime Minister David ODDSSON (since
30 April 1991)
_#_Political parties and leaders:
Independence (conservative), David ODDSSON;
Progressive, Steingrimur HERMANNSSON;
Social Democratic, Jon Baldvin HANNIBALSSON;
People''s Alliance (left socialist), Olafur Ragnar GRIMSSON;
Citizens Party (conservative nationalist), Julius SOLNES;
Women''s List
_#_Suffrage: universal at age 20
_#_Elections:
President--last held on 29 June 1980 (next scheduled for June
1992); results--there were no elections in 1984 and 1988 as President
Vigdis FINNBOGADOTTIR was unopposed;
Althing--last held on 20 April 1991 (next to be held by
April 1995);
results--Independence 38.6%, Progressive 18.9%, Social Democratic 15.5%,
People''s Alliance 14.4%, Womens List 8.13%, Liberals 1.2%, other 3.27%
seats--(63 total) Independence 26, Progressive 13, Social Democratic 10,
People''s Alliance 9, Womens List 5
_#_Communists: less than 100 (est.), some of whom participate in the
People''s Alliance
_#_Member of: BIS, CCC, CE, CSCE, EBRD, ECE, EFTA, FAO, GATT, IAEA,
IBRD, ICAO, ICC, ICFTU, IDA, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC,
ISO (correspondent), ITU, LORCS, NATO, NC, NEA, NIB, OECD, PCA, UN,
UNCTAD, UNESCO, UPU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Tomas A. TOMASSON; Chancery
at 2022 Connecticut Avenue NW, Washington DC 20008; telephone (202)
265-6653 through 6655; there is an Icelandic Consulate General in New
York;
US--Ambassador Charles E. COBB, Jr.; Embassy at Laufasvegur 21,
Box 40, Reykjavik (mailing address is FPO New York 09571-0001); telephone
[354] (1) 29100
_#_Flag: blue with a red cross outlined in white that extends to the
edges of the flag; the vertical part of the cross is shifted to the hoist
side in the style of the Dannebrog (Danish flag)
_#_Long-form name: Republic of India
_#_Type: federal republic
_#_Capital: New Delhi
_#_Administrative divisions: 25 states and 7 union territories*;
Andaman and Nicobar Islands*, Andhra Pradesh, Arunachal Pradesh,
Assam, Bihar, Chandigarh*, Dadra and Nagar Haveli*,
Daman and Diu*, Delhi*, Goa, Gujarat, Haryana,
Himachal Pradesh, Jammu and Kashmir, Karnataka, Kerala,
Lakshadweep*, Madhya Pradesh, Maharashtra, Manipur, Meghalaya,
Mizoram, Nagaland, Orissa, Pondicherry*, Punjab, Rajasthan,
Sikkim, Tamil Nadu, Tripura, Uttar Pradesh, West Bengal
_#_Independence: 15 August 1947 (from UK)
_#_Constitution: 26 January 1950
_#_Legal system: based on English common law; limited judicial review
of legislative acts; accepts compulsory ICJ jurisdiction, with
reservations
_#_National holiday: Anniversary of the Proclamation of the Republic,
26 January (1950)
_#_Executive branch: president, vice president, prime minister,
Council of Ministers
_#_Legislative branch: bicameral Parliament (Sansad) consists of an
upper house or Council of States (Rajya Sabha) and a lower house or
House of the People (Lok Sabha)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Ramaswamy Iyer VENKATARAMAN (since 25
July 1987); Vice President Dr. Shankar Dayal SHARMA (since 3 September
1987);
Head of Government--Prime Minister P. V. Narasimha RAO (since
21 June 1991)
_#_Political parties and leaders:
Congress (I) Party, P. V. Narasimha RAO, president;
Bharatiya Janata Party, L. K. ADVANI;
Janata Dal Party, V. P. SINGH;
Communist Party of India/Marxist (CPI/M), E. M. S. NAMBOODIRIPAD;
Communist Party of India (CPI), C. Rajeswara RAO;
Telugu Desam (a regional party in Andhra Pradesh), N. T. Rama RAO;
All-India Anna Dravida Munnetra Kazagham','716925c7bf4f48be6f2d98c9f49ecd2b28c510592aa857853329b9ddc3021f5e','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e81feb77544333fabbfeeea9cd6c9fca304444ac6a352eb3485dc84979da4b3',1991,'ES','Spain','government',85,'(AIADMK; a regional party
in Tamil Nadu), JAYALALITHA;
Samajwadi Janata Party, CHANDRA SHEKHAR;
Shiv Sena, Bal THACKERAY;
Revolutionary Socialist Party (RSP), Tridip CHOWDHURY;
Bahujana Samaj Party (BSP), Kanshi RAM;
Congress (S) Party, leader NA;
Communist Party of India/Marxist-Leninist (CPI/ML), Satyanarayan SINGH;
Dravida Munnetra Kazagham (a regional party in Tamil Nadu),
M. KARUNANIDHI;
Akali Dal factions representing Sikh religious community in the Punjab;
National Conference (NC; a regional party in Jammu and Kashmir), Farooq
ABDULLAH;
Asom Gana Parishad (a regional party in Assam), Prafulla MAHANTA
_#_Suffrage: universal at age 18
_#_Elections:
People''s Assembly--last held 21 May, 12 and 15 June
1991 (next to be held by November 1996);
results--percent of vote by party NA;
seats--(545 total), 509 elected--Congress (I) Party 225,
Bharatiya Janata Party 117,
Janata Dal Party 55,
Communist Party of India (Marxist) 35,
Communist Party of India 13,
Telugu Desam 12,
AIADMK 11,
Samajwadi Janata Party 5,
Shiv Sena 4,
RSP 4,
BSP 1,
Congress (S) Party 1, other 26; note--second and third rounds of
voting were delayed because of the assassination of Congress
President Rajiv GANDHI on 21 May 1991
_#_Communists: 466,000 members claimed by CPI, 361,000 members claimed
by CPI/M; Communist extremist groups, about 15,000 members
_#_Other political or pressure groups: various separatist groups
seeking greater communal autonomy; numerous religious or
militant/chauvinistic organizations, including Adam Sena, Anand Marg,
Vishwa Hindu Parishad, and Rashtriya Swayamsevak Sangh
_#_Member of: AfDB, AG (observer), AsDB, C, CCC, CP, ESCAP, FAO, G-6,
G-19, G-24, G-77, GATT, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IFAD, IFC,
ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS,
NAM, PCA, SAARC, UN, UNAVEM, UNCTAD, UNESCO, UNIDO, UNIIMOG, UPU,
WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Abid HUSSEIN;
Chancery at 2107 Massachusetts Avenue NW, Washington DC 20008;
telephone (202) 939-7000; there are Indian Consulates General in
Chicago, New York, and San Francisco;
US--Ambassador William CLARK, Jr.; Embassy at Shanti Path,
Chanakyapuri 110021, New Delhi; telephone [91] (11) 600651; there are US
Consulates General in Bombay, Calcutta, and Madras
_#_Flag: three equal horizontal bands of orange (top), white, and
green with a blue chakra (24-spoked wheel) centered in the white
band; similar to the flag of Niger which has a small orange disk centered
in the white band
_#_Long-form name: Republic of Indonesia
_#_Type: republic
_#_Capital: Jakarta
_#_Administrative divisions: 24 provinces (propinsi-propinsi,
singular--propinsi), 2 special regions* (daerah-daerah istimewa,
singular--daerah istimewa), and 1 special capital city district**
(daerah khusus ibukota); Aceh*, Bali, Bengkulu, Irian Jaya, Jakarta
Raya**, Jambi, Jawa Barat, Jawa Tengah, Jawa Timur, Kalimantan Barat,
Kalimantan Selatan, Kalimantan Tengah, Kalimantan Timur, Lampung, Maluku,
Nusa Tenggara Barat, Nusa Tenggara Timur, Riau, Sulawesi Selatan,
Sulawesi Tengah, Sulawesi Tenggara, Sulawesi Utara, Sumatera Barat,
Sumatera Selatan, Sumatera Utara, Timor Timur, Yogyakarta*
_#_Independence: 17 August 1945 (from Netherlands; formerly
Netherlands or Dutch East Indies)
_#_Constitution: August 1945, abrogated by Federal Constitution of
1949 and Provisional Constitution of 1950, restored 5 July 1959
_#_Legal system: based on Roman-Dutch law, substantially modified by
indigenous concepts and by new criminal procedures code; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 17 August (1945)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: unicameral House of Representatives
(Dewan Perwakilan Rakyat or DPR); note--the People''s Consultative
Assembly (Majelis Permusyawaratan Rakyat or MPR) includes the DPR plus
500 indirectly elected members who meet every five years to elect the
president and vice president and, theoretically, to determine national
policy
_#_Judicial branch: Supreme Court (Mahkamah Agung)
_#_Leaders:
Chief of State and Head of Government--President Gen. (Ret.)
SOEHARTO (since 27 March 1968); Vice President Lt. Gen. (Ret.) SUDHARMONO
(since 11 March 1983)
_#_Political parties and leaders:
GOLKAR (quasi-official party based on functional groups), Lt. Gen. (Ret.)
WAHONO, general chairman;
Indonesia Democracy Party (PDI--federation of former Nationalist and
Christian Parties), SOERYADI, chairman;
Development Unity Party (PPP, federation of former Islamic parties),
Ismail Hasan METAREUM, chairman
_#_Suffrage: universal at age 17 and married persons regardless of age
_#_Elections:
House of Representatives--last held on 23 April 1987
(next to be held 23 April 1992);
results--Golkar 73%, UDP 16%, PDI 11%;
seats--(500 total--400 elected, 100 appointed) Golkar 299, UDP 61, PDI 40
_#_Communists: Communist Party (PKI) was officially banned in March
1966; current strength about 1,000-3,000, with less than 10% engaged in
organized activity; pre-October 1965 hardcore membership about 1.5
million
_#_Member of: APEC, AsDB, ASEAN, CCC, CP, ESCAP, FAO, G-19, G-77,
GATT, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IDB, IFAD, IFC, ILO, IMF, IMO,
INMARSAT, INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS, NAM, OIC,
OPEC, UN, UNCTAD, UNESCO, UNIDO, UNIIMOG, UPU, WCL, WFTU, WHO, WIPO,
WMO, WTO
_#_Diplomatic representation: Ambassador Abdul Rachman RAMLY;
Chancery at 2020 Massachusetts Avenue NW, Washington DC 20036;
telephone (202) 775-5200; there are Indonesian Consulates General in
Houston, New York, and Los Angeles, and Consulates in Chicago and San
Francisco;
US--Ambassador John C. MONJO; Embassy at Medan Merdeka Selatan 5,
Jakarta (mailing address is APO San Francisco 96356);
telephone [62] (21) 360-360; there are US Consulates in Medan and
Surabaya
_#_Flag: two equal horizontal bands of red (top) and white; similar to
the flag of Monaco which is shorter; also similar to the flag of Poland
which is white (top) and red
_#_Long-form name: Islamic Republic of Iran
_#_Type: theocratic republic
_#_Capital: Tehran
_#_Administrative divisions: 24 provinces (ostanha,
singular--ostan); Azarbayjan-e Bakhtari,
Azarbayjan-e Khavari, Bakhtaran, Bushehr,
Chahar Mahall va Bakhtiari, Esfahan, Fars,
Gilan, Hamadan, Hormozgan, Ilam, Kerman,
Khorasan, Khuzestan, Kohkiluyeh va Buyer
Ahmadi, Kordestan, Lorestan, Markazi, Mazandaran,
Semnan, Sistan va Baluchestan, Tehran, Yazd, Zanjan
_#_Independence: 1 April 1979, Islamic Republic of Iran proclaimed
_#_Constitution: 2-3 December 1979; revised 1989 to expand powers of
the presidency and eliminate the prime ministership
_#_Legal system: the new Constitution codifies Islamic principles of
_#_National holiday: Islamic Republic Day, 1 April (1979)
_#_Executive branch: cleric (faqih), president, Council of Ministers
_#_Legislative branch: unicameral Islamic Consultative Assembly
(Majles-e-Shura-ye-Eslami)
_#_Judicial branch: Supreme Court
_#_Leaders:
Cleric and functional Chief of State--Leader of the Islamic
Revolution Ayatollah Ali Hoseini-KHAMENEI (since 4 June 1989);
Head of Government--President Ali Akbar HASHEMI-RAFSANJANI
(since 3 August 1989);
_#_Political parties and leaders: there are at least 14 licensed
parties; the three most important are--Tehran Militant Clergy
Association, Mohammad Reza MAHDAVI-KANI;
Militant Clerics Association, Mehdi MAHDAVI-KARUBI and Mohammad Asqar
MUSAVI-KHOINIHA;
Fedaiyin Islam Organization, Sadeq KHALKHALI
_#_Suffrage: universal at age 15
_#_Elections:
President--last held NA July 1989 (next to be held April 1993);
results--Ali Akbar HASHEMI-RAFSANJANI was elected with only token
opposition;
Islamic Consultative Assembly--last held 8 April 1988 (next
to be held June 1992); results--percent of vote by party
NA;
seats--(270 seats total) number of seats by party NA
_#_Communists: 1,000 to 2,000 est. hardcore; 15,000 to 20,000 est.
sympathizers; crackdown in 1983 crippled the party; trials of captured
leaders began in late 1983 and remain incomplete
_#_Other political or pressure groups: groups that generally
support the Islamic Republic include Hizballah, Hojjatiyeh Society,
Mojahedin of the Islamic Revolution, Muslim Students Following the Line
of the Imam; armed political groups that have been almost completely
repressed by the government include Mojahedin Khalq Organization (MKO),
People''s Fedayeen, and Kurdish Democratic Party; the Society for the
Defense of Freedom is a group of liberal nationalists that has been
repressed by the government for accusing it of corruption
_#_Member of: CCC, CP, ESCAP, FAO, G-19, G-24, G-77, IAEA, IBRD,
ICAO, ICC, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT,
INTERPOL, IOC, ISO, ITU, LORCS, NAM, OIC, OPEC, PCA, UN, UNCTAD,
UNESCO, UNHCR, UNIDO, UPU, WFTU, WHO, WMO, WTO
_#_Diplomatic representation: none; protecting power in the US is
Algeria--Iranian Interests Section, 2209 Wisconsin Avenue NW,
Washington DC 20007; telephone (202) 965-4990;
US--protecting power in Iran is Switzerland
_#_Flag: three equal horizontal bands of green (top), white, and red;
the national emblem (a stylized representation of the word Allah) in red
is
centered
in the white band; Allah Akbar (God is Great) in white Arabic
script is repeated 11 times along the bottom edge of the green band and
11 times along the top edge of the red band
_#_Long-form name: Republic of Iraq
_#_Type: republic
_#_Capital: Baghdad
_#_Administrative divisions: 18 provinces (muhafazat,
singular--muhafazah); Al Anbar, Al Basrah, Al Muthanna,
Al Qadisiyah, An Najaf, Arbil, As Sulaymaniyah, At
Tamim, Babil, Baghdad, Dahuk, Dhi Qar, Diyala,
Karbala, Maysan, Ninawa, Salah ad Din, Wasit
_#_Independence: 3 October 1932 (from League of Nations mandate under
British administration)
_#_Constitution: 22 September 1968, effective 16 July 1970 (interim
Constitution); new constitution drafted in 1990 but not adopted
_#_Legal system: based on Islamic law in special religious courts,
civil law system elsewhere; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Anniversary of the Revolution, 17 July (1968)
_#_Executive branch: president, vice president, chairman of the
Revolutionary Command Council, vice chairman of the Revolutionary Command
Council, prime minister, first deputy prime minister, Council of
Ministers
_#_Legislative branch: unicameral National Assembly (Majlis Watani)
_#_Judicial branch: Court of Cassation
_#_Leaders:
Chief of State--President Saddam HUSAYN (since 16 July 1979);
Vice President Taha Muhyi al-Din MARUF (since 21 April 1974);
Vice President Taha Yasin RAMADAN (since 23 March 1991);
_#_Head of Government--Prime Minister Sadun HAMMADI (since 27 March
1991); Deputy Prime Minister Tariq AZIZ (since NA 1979);
Deputy Prime Minister Muhammad Hamza al-ZUBAYDI (since 27 March 1991)
_#_Political parties: National Progressive Front is a coalition of the
Arab Bath Socialist Party, Kurdistan Democratic Party, and Kurdistan
Revolutionary Party
_#_Suffrage: universal adult at age 18
_#_Elections:
National Assembly--last held on 1 April 1989 (next to be held NA);
results--Sunni Arabs 53%, Shia Arabs 30%, Kurds 15%, Christians
2% est.; seats--(250 total) number of seats by party NA
_#_Communists: about 1,500 hardcore members
_#_Other political or pressure groups: political parties and activity
severely restricted; possibly some opposition to regime from disaffected
members of the regime, Army officers, and religious and ethnic dissidents
_#_Member of: ABEDA, ACC, AFESD, AL, AMF, CAEU, ESCWA, FAO, G-19,
G-77, IAEA, IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS, NAM, OAPEC, OIC, OPEC,
PCA, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: no Iraqi representative in Washington;
Chancery at 1801 P Street NW, Washington DC 20036; telephone (202)
483-7500;
US--no US representative in Baghdad since mid-January 1991;
Embassy in Masbah Quarter (opposite the Foreign Ministry Club), Baghdad
(mailing address is P. O. Box 2447 Alwiyah, Baghdad); telephone [964] (1)
719-6138 or 719-6139, 718-1840, 719-3791
_#_Flag: three equal horizontal bands of red (top), white, and black
with three green five-pointed stars in a horizontal line centered in the
white band; the phrase Allahu Akbar (God is Great) in green Arabic
script--Allahu to the right of the middle star and Akbar to the left of
the middle star--was added in January 1991 during the Persian Gulf
crisis; similar to the flag of Syria that has two stars but no script
and the flag of Yemen that has a plain white band; also similar to the
flag of Egypt that has a symbolic eagle centered in the white band
_#_Long-form name: none
_#_Type: joint administration by Iraq and Saudi Arabia; in December
1981, Iraq and Saudi Arabia signed a boundary agreement that divides
the zone between them, but the agreement must be ratified before it
becomes effective
_#_Long-form name: none
_#_Type: republic
_#_Capital: Dublin
_#_Administrative divisions: 26 counties; Carlow, Cavan, Clare, Cork,
Donegal, Dublin, Galway, Kerry, Kildare, Kilkenny, Laois, Leitrim,
Limerick, Longford, Louth, Mayo, Meath, Monaghan, Offaly, Roscommon,
Sligo, Tipperary, Waterford, Westmeath, Wexford, Wicklow
_#_Independence: 6 December 1921 (from UK)
_#_Constitution: 29 December 1937; adopted 1937
_#_Legal system: based on English common law, substantially modified
by indigenous concepts; judicial review of legislative acts in Supreme
Court; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Saint Patrick''s Day, 17 March
_#_Executive branch: president, prime minister, deputy prime minister,
Cabinet
_#_Legislative branch: bicameral Parliament (Oireachtas) consists of
an upper house or Senate (Seanad Eireann) and a lower house or House of
Representatives (Dail Eireann)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Mary Bourke ROBINSON (since 9 November
1990);
Head of Government--Prime Minister Charles J. HAUGHEY (since
12 July 1989, the fourth time elected as Prime Minister)
_#_Political parties and leaders:
Fianna Fail, Charles HAUGHEY;
Labor Party, Richard SPRING;
Fine Gael, John BRUTON;
Communist Party of Ireland, Michael O''RIORDAN;
Workers'' Party, Proinsias DEROSSA;
Sinn Fein, Gerry ADAMS;
Progressive Democrats, Desmond O''MALLEY;
note--Prime Minister HAUGHEY heads a coalition consisting of the
Fianna Fail and the Progressive Democrats
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 9 November 1990 (next to be held November
1997); results--Mary Bourke ROBINSON 52.8%, Brian LENIHAN 47.2%;
Senate--last held on 17 February 1987 (next to be held February
1992);
results--percent of vote by party NA;
seats--(60 total, 49 elected) Fianna Fail 30, Fine Gael 16, Labor 3,
Independents 11;
House of Representatives--last held on 12 July 1989 (next to be
held NA June 1994);
results--Fianna Fail 44.0%, Fine Gael 29.4%, Labor Party 9.3%,
Progressive Democrats 5.4%, Workers'' Party 4.9%, Sinn Fein 1.1%,
independents 5.9%;
seats--(166 total) Fianna Fail 77, Fine Gael 55, Labor Party 15,
Workers'' Party 7, Progressive Democrats 6, independents 6
_#_Communists: under 500
_#_Member of: BIS, CCC, CE, CSCE, EBRD, EC, ECE, EIB, ESA, FAO, GATT,
IAEA, IBRD, ICAO, ICC, IDA, IEA, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, ISO, ITU, LORCS, NEA, OECD, UN, UNCTAD, UNESCO, UNFICYP,
UNIDO, UNIFIL, UNIIMOG, UNTSO, UPU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Padraic N. MACKERNAN;
Chancery at 2234 Massachusetts Avenue NW, Washington DC 20008; telephone
(202) 462-3939; there are Irish Consulates General in Boston, Chicago,
New York, and San Francisco;
US--Ambassador Richard A. MOORE; Embassy at 42 Elgin Road,
Ballsbridge, Dublin; telephone [353] (1) 688777
_#_Flag: three equal vertical bands of green (hoist side), white, and
orange; similar to the flag of the Ivory Coast which is shorter and
has the colors reversed--orange (hoist side), white, and green; also
similar to the flag of Italy which is shorter and has colors of green
(hoist side), white, and red
_#_Long-form name: State of Israel
_#_Type: republic
_#_Capital: Israel proclaimed Jerusalem its capital in 1950, but the
US, like nearly all other countries, maintains its Embassy in Tel Aviv
_#_Administrative divisions: 6 districts (mehozot, singular--mehoz);
Central, Haifa, Jerusalem, Northern, Southern, Tel Aviv
_#_Independence: 14 May 1948 (from League of Nations mandate under
British administration)
_#_Constitution: no formal constitution; some of the functions of a
constitution are filled by the Declaration of Establishment (1948), the
basic laws of the parliament (Knesset), and the Israeli citizenship law
_#_Legal system: mixture of English common law, British Mandate
regulations, and, in personal matters, Jewish, Christian, and Muslim
legal systems; in December 1985 Israel informed the UN Secretariat that
it would no longer accept compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 10 May 1989; Israel declared
independence on 14 May 1948, but the Jewish calendar is lunar and the
holiday may occur in April or May
_#_Executive branch: president, prime minister, vice prime minister,
Cabinet
_#_Legislative branch: unicameral parliament (Knesset)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Chaim HERZOG (since 5 May 1983);
Head of Government--Prime Minister Yitzhak SHAMIR (since 20 October
1986)
_#_Political parties and leaders: Israel currently has a coalition
government comprising eleven parties that hold 66 of the Knesset''s
120 seats;
Members of the government--Likud bloc, Prime Minister Yitzhak
SHAMIR;
Sephardic Torah Guardians (SHAS), Minister of Interior Arieh DER''I;
National Religious Party, Minister of Education Zevulun HAMMER;
Agudat Yisrael, Moshe Zeev FELDMAN;
Degel HaTorah, Avraham RAVITZ;
Moriya, Minister of Immigrant Absorption, Yitzhak PERETZ;
Ge''vlat Yisrael, Elizer MIZRAHI;
Party for the Advancement of Zionist Ideology (PAZI), Minister of
Finance Yitzhak MODAI;
Tehiya Party, Minister of Science, Technology, Energy, and Infrastructure
Yuval NE''EMAN;
Tzomet Party, Minister of Agriculture Rafael EITAN;
Unity for Peace and Aliyah, Efrayim GUR;
Moledet Party, Rehavam ZE''EVI;
Opposition parties--Labor Party, Shimon PERES;
Citizens'' Rights Movement, Shulamit ALONI;
United Workers'' Party (MAPAM), Yair TZABAN;
Center Movement-Shinui, Amnon RUBENSTEIN;
New Israeli Communist Party (MAKI), Meir WILNER;
Progressive List for Peace, Muhammad MI''ARI;
Arab Democratic Party, Abd Al Wahab DARAWSHAH;
Black Panthers, Charlie BITON
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 23 February 1988 (next to be held February
1994); results--Chaim HERZOG reelected by Knesset;
Knesset--last held 1 November 1988 (next to be held by
November 1992);
seats--(120 total) Labor Party 38, Likud bloc 37, SHAS 5, National
Religious Party 5, Citizens'' Rights Movement 5, Agudat Yisrael 4,
PAZI 3, MAKI 3, Tehiya Party 3, MAPAM 3, Tzomet Party 2, Moledet Party 2,
Degel HaTorah 2, Center Movement-Shinui 2, Progressive List for Peace 1,
Arab Democratic Party 1; Black Panthers 1, Moriya 1, Ge''ulat
Yisrael 1, Unity for Peace and Aliyah 1
_#_Communists: Hadash (predominantly Arab but with Jews in its
leadership) has some 1,500 members
_#_Other political or pressure groups: Gush Emunim, Jewish
nationalists advocating Jewish settlement on the West Bank and Gaza
Strip; Peace Now, critical of government''s West Bank/Gaza Strip and
Lebanon policies
_#_Member of: AG (observer), CCC, EBRD, FAO, GATT, IADB, IAEA, IBRD,
ICAO, ICC, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT,
INTERPOL, IOC, IOM, ISO, ITU, OAS (observer), PCA, UN, UNCTAD, UNESCO,
UNHCR, UNIDO, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Zalman SHOVAL; Chancery at
3514 International Drive NW, Washington DC 20008; telephone (202)
364-5500; there are Israeli Consulates General in Atlanta, Boston,
Chicago, Houston, Los Angeles, Miami, New York, Philadelphia, and San
Francisco;
US--Ambassador William A. BROWN; Embassy at 71 Hayarkon Street,
Tel Aviv (mailing address is APO New York 09672); telephone [972] (3)
654338; there is a US Consulate General in Jerusalem
_#_Flag: white with a blue hexagram (six-pointed linear star) known as
the Magen David (Shield of David) centered between two equal horizontal
blue bands near the top and bottom edges of the flag
_#_Long-form name: Italian Republic
_#_Type: republic
_#_Capital: Rome
_#_Administrative divisions: 20 regions (regioni, singular--regione);
Abruzzi, Basilicata, Calabria, Campania, Emilia-Romagna, Friuli-Venezia
Giulia, Lazio, Liguria, Lombardia, Marche, Molise, Piemonte, Puglia,
Sardegna, Sicilia, Toscana, Trentino-Alto Adige, Umbria, Valle d''Aosta,
Veneto
_#_Independence: 17 March 1861, Kingdom of Italy proclaimed
_#_Constitution: 1 January 1948
_#_Legal system: based on civil law system, with ecclesiastical law
influence; appeals treated as trials de novo; judicial review under
certain conditions in Constitutional Court; has not accepted compulsory
ICJ jurisdiction
_#_National holiday: Anniversary of the Republic, 2 June (1946)
_#_Executive branch: president, prime minister (president of the
Council of Ministers)
_#_Legislative branch: bicameral Parliament (Parlamento) consists of
an upper chamber or Senate of the Republic (Senato della Repubblica)
and a lower chamber or Chamber of Deputies (Camera dei Deputati)
_#_Judicial branch: Constitutional Court (Corte Costituzionale)
_#_Leaders:
Chief of State--President Francesco COSSIGA (since 3 July 1985);
Head of Government--Prime Minister Giulio ANDREOTTI (since 22 July
1989, heads the government for the seventh time); Deputy Prime Minister
Claudio MARTELLI (since 23 July 1989)
_#_Political parties and leaders:
Christian Democratic Party (DC), Arnaldo FORLANI (general secretary),
Ciriaco De MITA (president);
Socialist Party (PSI), Bettino CRAXI (party secretary);
Social Democratic Party (PSDI), Antonio CARIGLIA (party secretary);
Liberal Party (PLI), Renato ALTISSIMO (secretary general);
Democratic Party of the Left (PDS--was Communist Party, or PCI, until
January 1991), Achille OCCHETTO (secretary general);
Italian Social Movement (MSI), Giuseppe (Pino) RAUTI (national
secretary);
Republican Party (PRI), Giorgio La MALFA (political secretary);
Lega Nord, Umberto BOSSI, president;
Italy''s 50th postwar government was formed on 13 April 1991,
with Prime Minister ANDREOTTI, a Christian Democrat, presiding over a
four-party coalition consisting of the Christian Democrats, Socialists,
Social Democrats, and Liberals
_#_Suffrage: universal at age 18 (except in senatorial elections,
where minimum age is 25)
_#_Elections:
Senate--last held 14-15 June 1987 (next to be held by June 1992);
results--DC 33.9%, PCI 28.3%, PSI 10.7%, other 27.1%;
seats--(320 total, 315 elected) DC 125, PCI 100, PSI 36, other 54;
Chamber of Deputies--last held 14-15 June 1987 (next to be held by
June 1992);
results--DC 34.3%, PCI 26.6%, PSI 14.3%, MSI 5.9%, PRI 3.7%, PSDI 3.0%,
Radicals 2.6%, Greens 2.5%, PLI 2.1%, Proletarian Democrats 1.7%,
other 3.3%;
seats--(630 total) DC 234, PCI 177, PSI 94, MSI 35, PRI 21, PSDI 17,
Radicals 13, Greens 13, PLI 11, Proletarian Democrats 8, other 7
_#_Communists: 1.3 million (1990)
_#_Other political or pressure groups: the Roman Catholic Church;
three major trade union confederations (CGIL--Communist dominated,
CISL--Christian Democratic, and UIL--Social Democratic, Socialist, and
Republican); Italian manufacturers association (Confindustria);
organized farm groups (Confcoltivatori, Confagricoltura)
_#_Member of: AfDB, AG (observer), AsDB, BIS, CCC, CE, CERN, COCOM,
CSCE, EBRD, EC, ECE, EIB, ESA, FAO, G-7, G-10, GATT, IADB, IAEA, IBRD,
ICAO, ICC, ICFTU, IDA, IFAD, IEA, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT,
INTERPOL, IOC, IOM, ISO, ITU, LORCS, NATO, NEA, OAS (observer),
O','5cf5114eea6316291d390188f8d00d839c04e5a0ea25cdaa6881bded7bf3cdab','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cd4b29bbfe78b6475a3707e43323025f4b8b89aa7a37bc353bf2b7187a6abd1',1991,'ES','Spain','government',86,'ECD, PCA, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UNIFIL, UNIIMOG, UNMOGIP,
UNTSO, UPU, WCL, WEU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Rinaldo PETRIGNANI; Chancery
at 1601 Fuller Street NW, Washington DC 20009; telephone (202) 328-5500;
there are Italian Consulates General in Boston, Chicago, Houston, New
Orleans, Los Angeles, Philadelphia, San Francisco, and Consulates in
Detroit and Newark (New Jersey);
US--Ambassador Peter F. SECCHIA; Embassy at Via Veneto 119/A,
00187-Rome (mailing address is APO New York 09794); telephone [39] (6)
46741; there are US Consulates General in Florence, Genoa, Milan, Naples,
and Palermo (Sicily)
_#_Flag: three equal vertical bands of green (hoist side), white, and
red; similar to the flag of Ireland which is longer and is green (hoist
side), white, and orange; also similar to the flag of the Ivory Coast
which has the colors reversed--orange (hoist side), white, and green
_#_Long-form name: Republic of the Ivory Coast; note--the local
official name is Republique de Cote d''Ivoire
_#_Type: republic; multiparty presidential regime established 1960
_#_Capital: Abidjan (capital city changed to Yamoussoukro in March
1983 but not recognized by US)
_#_Administrative divisions: 49 departments (departements,
singular--(departement); Abengourou, Abidjan, Aboisso, Adzope,
Agboville, Bangolo, Beoumi, Biankouma, Bondoukou, Bongouanou,
Bouafle, Bouake, Bouna, Boundiali, Dabakala, Daloa, Danane,
Daoukro, Dimbokro, Divo, Duekoue, Ferkessedougou, Gagnoa,
Grand-Lahou, Guiglo, Issia, Katiola, Korhogo, Lakota,
Man, Mankono, Mbahiakro, Odienne, Oume, Sakassou, San-Pedro,
Sassandra, Seguela, Sinfra, Soubre, Tabou, Tanda, Tengrela,
Tiassale, Touba, Toumodi, Vavoua, Yamoussoukro, Zuenoula
_#_Independence: 7 August 1960 (from France)
_#_Constitution: 3 November 1960
_#_Legal system: based on French civil law system and customary law;
judicial review in the Constitutional Chamber of the Supreme Court; has
not accepted compulsory ICJ jurisdiction
_#_National holiday: National Day, 7 December
_#_Executive branch: president, Council of Ministers (cabinet)
_#_Legislative branch: unicameral National Assembly (Assemblee
Nationale)
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State and Head of Government--President Dr. Felix
HOUPHOUET-BOIGNY (since 27 November 1960); Prime Minister Allassane
OUATTARE (since 7 November 1990)
_#_Political parties and leaders:
Democratic Party of the Ivory Coast (PDCI), Dr. Felix
HOUPHOUET-BOIGNY;
Ivorian Popular Front (FPI), Laurent GBAGBO;
Ivorian Worker''s Party (PIT), Francis WODIE;
Ivorian Socialist Party (PSI), Morifere BAMBA;
over 20 smaller parties
_#_Suffrage: universal at age 21
_#_Elections:
President--last held 28 October 1990 (next to be held October
1995);
results--President Felix HOUPHOUET-BOIGNY received 81% of the vote
in his first contested election; he is currently serving his seventh
consecutive five-year term;
National Assembly--last held 25 November 1990 (next to be held
November 1995);
results--percent of vote by party NA;
seats--(175 total) PDCI 163, FPI 9, PIT 1, independents 2
_#_Communists: no Communist party; possibly some sympathizers
_#_Member of: ACCT, ACP, AfDB, CCC, CEAO, ECA, ECOWAS, Entente, FAO,
FZ, G-24, G-77, GATT, IAEA, IBRD, ICAO, ICC, IDA, IFAD, IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS, NAM, OAU, UN,
UNCTAD, UNESCO, UNIDO, UPU, WADB, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Charles GOMIS; Chancery at
2424 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
797-0300;
US--Ambassador Kenneth L. BROWN; Embassy at 5 Rue Jesse Owens,
Abidjan (mailing address is 01 B. P. 1712, Abidjan); telephone [225]
21-09-79 or 21-46-72
_#_Flag: three equal vertical bands of orange (hoist side), white, and
green; similar to the flag of Ireland which is longer and has the colors
reversed--green (hoist side), white, and orange; also similar to the flag
of Italy which is green (hoist side), white, and red; design was based on
the flag of France
_#_Long-form name: none
_#_Type: parliamentary democracy
_#_Capital: Kingston
_#_Administrative divisions: 14 parishes; Clarendon, Hanover,
Kingston, Manchester, Portland, Saint Andrew, Saint Ann, Saint Catherine,
Saint Elizabeth, Saint James, Saint Mary, Saint Thomas, Trelawny,
Westmoreland
_#_Independence: 6 August 1962 (from UK)
_#_Constitution: 6 August 1962
_#_Legal system: based on English common law; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: Independence Day (first Monday in August),
6 August 1990
_#_Executive branch: British monarch, governor general, prime
minister, Cabinet
_#_Legislative branch: bicameral Parliament consists of an upper house
or Senate and a lower house or House of Representatives
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor General Sir Florizel A. GLASSPOLE (since 2 March
1973);
Head of Government--Prime Minister Michael MANLEY
(since 13 February 1989)
_#_Political parties and leaders:
People''s National Party (PNP), Michael MANLEY;
Jamaica Labor Party (JLP), Edward SEAGA;
Workers'' Party of Jamaica (WPJ), Trevor MUNROE
_#_Suffrage: universal at age 18
_#_Elections:
House of Representatives--last held 9 February 1989 (next to be
held by February 1994);
results--PNP 57%, JLP 43%;
seats--(60 total) PNP 45, JLP 15
_#_Communists: Workers'' Party of Jamaica (Marxist-Leninist)
_#_Other political or pressure groups:
Rastafarians (black religious/racial cultists, pan-Africanists)
_#_Member of: ACP, C, CARICOM, CCC, CDB, ECLAC, FAO, G-19, G-77,
GATT, IADB, IAEA, IBRD, ICAO, ICFTU, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, ISO, ITU, LAES, LORCS, NAM, OAS, OPANAL, UN,
UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Richard BERNAL;
Chancery at Suite 355, 1850 K Street NW, Washington DC 20006; telephone
(202) 452-0660; there are Jamaican Consulates General in Miami and New
York;
US--Ambassador Glen A. HOLDEN; Embassy at 3rd Floor, Jamaica Mutual
Life Center, 2 Oxford Road, Kingston; telephone (809) 929-4850
_#_Flag: diagonal yellow cross divides the flag into four
triangles--green (top and bottom) and black (hoist side and fly side)
_#_Long-form name: none
_#_Type: territory of Norway
_#_Note: administered by a governor (sysselmann) resident in
Longyearbyen (Svalbard)
_#_Long-form name: none
_#_Type: constitutional monarchy
_#_Capital: Tokyo
_#_Administrative divisions: 47 prefectures (fuken, singular and
plural); Aichi, Akita, Aomori, Chiba, Ehime, Fukui, Fukuoka, Fukushima,
Gifu, Gumma, Hiroshima, Hokkaido, Hyogo, Ibaraki, Ishikawa, Iwate,
Kagawa, Kagoshima, Kanagawa, Kochi, Kumamoto, Kyoto, Mie, Miyagi,
Miyazaki, Nagano, Nagasaki, Nara, Niigata, Oita, Okayama, Okinawa,
Osaka, Saga, Saitama, Shiga, Shimane, Shizuoka, Tochigi, Tokushima,
Tokyo, Tottori, Toyama, Wakayama, Yamagata, Yamaguchi, Yamanashi
_#_Independence: 660 BC, traditional founding by Emperor Jimmu
_#_Constitution: 3 May 1947
_#_Legal system: civil law system with English-American influence;
judicial review of legislative acts in the Supreme Court; accepts
compulsory ICJ jurisdiction, with reservations
_#_National holiday: Birthday of the Emperor, 23 December (1933)
_#_Executive branch: emperor, prime minister, Cabinet
_#_Legislative branch: bicameral Diet (Kokkai) consists of an upper
house or House of Councillors (Sangi-in) and a lower house or House of
Representatives (Shugi-in)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Emperor AKIHITO (since 7 January 1989);
Head of Government--Prime Minister Kiichi MIYAZAWA (since 5
November 1991)
_#_Political parties and leaders:
Liberal Democratic Party (LDP), Toshiki KAIFU, president; Keizo OBUCHI,
secretary general;
Japan Socialist Party (JSP), T. DOI, chairman;
Democratic Socialist Party (DSP), Keigo OUCHI, chairman;
Japan Communist Party (JCP), K. MIYAMOTO, Presidium chairman;
Komeito (Clean Government Party, CGP), Koshiro ISHIDA, chairman
_#_Suffrage: universal at age 20
_#_Elections:
House of Councillors--last held on 23 July 1989 (next to be held
23 July 1992); results--percent of vote by party NA;
seats--(252 total, 100 elected) LDP 109, JSP 67, CGP 21, JCP 14,
other 41;
House of Representatives--last held on 18 February 1990
(next to be held by February 1993);
results--percent of vote by party NA;
seats--(512 total) LDP 275, JSP 136, CGP 45, JCP 16, DSP 14,
other parties 5, independents 21; note--9 independents are expected
to join the LDP, 5 the JSP
_#_Communists: about 490,000 registered Communist party members
_#_Member of: AfDB, AG (observer), APEC, AsDB, BIS, CCC, COCOM, CP,
EBRD, ESCAP, FAO, G-2, G-5, G-7, G-8, G-10, GATT, IADB, IAEA, IBRD, ICAO,
ICC, ICFTU, IDA, IEA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT,
INTERPOL, IOC, IOM (observer), ISO, ITU, LORCS, NEA, OAS (observer),
OECD, PCA, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UNRWA, UPU, WHO, WIPO, WMO,
WTO
_#_Diplomatic representation: Ambassador Ryohei MURATA; Chancery at
2520 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
939-6700; there are Japanese Consulates General in Agana (Guam),
Anchorage, Atlanta, Boston, Chicago, Honolulu, Houston, Kansas City
(Missouri), Los Angeles, New Orleans, New York, San Francisco, Seattle,
and Portland (Oregon), and a Consulate in Saipan (Northern Mariana
Islands);
US--Ambassador Michael H. ARMACOST; Embassy at 10-1, Akasaka
1-chome, Minato-ku (107), Tokyo (mailing address is APO San Francisco
96503); telephone [81] (3) 3224-5000; there are US Consulates General
in Naha (Okinawa), Osaka-Kobe, and Sapporo and a Consulate in Fukuoka
_#_Flag: white with a large red disk (representing the sun without
rays) in the center
_#_Long-form name: none (territory of the US)
_#_Type: unincorporated territory of the US administered by the Fish
and Wildlife Service of the US Department of the Interior as part of the
National Wildlife Refuge System
_#_Long-form name: Bailiwick of Jersey
_#_Type: British crown dependency
_#_Capital: Saint Helier
_#_Administrative divisions: none (British crown dependency)
_#_Independence: none (British crown dependency)
_#_Constitution: unwritten; partly statutes, partly common law and
practice
_#_Legal system: English law and local statute
_#_National holiday: Liberation Day, 9 May (1945)
_#_Executive branch: British monarch, lieutenant governor, bailiff
_#_Legislative branch: unicameral Assembly of the States
_#_Judicial branch: Royal Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952);
Head of Government--Lieutenant Governor and Commander in Chief
Air Marshal Sir John SUTTON (since NA 1990); Bailiff Peter CRILL (since
NA)
_#_Political parties and leaders: none; all independents
_#_Suffrage: universal adult at age NA
_#_Elections:
Assembly of the States--last held NA (next to be held NA);
results--percent of vote NA;
seats--(56 total, 52 elected) 52 independents
_#_Communists: probably none
_#_Member of: none
_#_Diplomatic representation: none (British crown dependency)
_#_Flag: white with the diagonal red cross of Saint Patrick (patron
saint of Ireland) extending to the corners of the flag','14786082b6377eaed4c3ac7bad5f5cf1dca7fd4a0d0d9ffe67bb1ecd8eb01b5c','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f340ddef835187df82ce85a18a349192d5ac41813df56fe718edfb1f8ba930f',1991,'FR','France','government',101,'_#_Long-form name: none (territory of the US)
_#_Type: unincorporated territory of the US administered by the US
Defense Nuclear Agency (DNA) and managed cooperatively by DNA and the
Fish and Wildlife Service of the US Department of the Interior as part of
the National Wildlife Refuge system
_#_Diplomatic representation: none (territory of the US)
_#_Flag: the flag of the US is used
_#_Long-form name: Hashemite Kingdom of Jordan
_#_Type: constitutional monarchy
_#_Capital: Amman
_#_Administrative divisions: 8 governorates (muhafazat,
singular--muhafazah); Al Balqa, Al Karak, Al Mafraq,
Amman, At Tafilah, Az Zarqa, Irbid, Maan
_#_Independence: 25 May 1946 (from League of Nations mandate under
British administration; formerly Trans-Jordan)
_#_Constitution: 8 January 1952
_#_Legal system: based on Islamic law and French codes; judicial
review of legislative acts in a specially provided High Tribunal; has not
accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 25 May (1946)
_#_Executive branch: monarch, prime minister, deputy prime minister,
Cabinet
_#_Legislative branch: bicameral National Assembly (Majlis al-Umma)
consists of an upper house or House of Notables (Majlis al-Aayan) and a
lower house or House of Deputies (Majlis al-Nuwaab); note--the
House of Deputies was dissolved by King Hussein on 30 July 1988 as
part of Jordanian disengagement from the West Bank and in November 1989
the first parliamentary elections in 22 years were held, with no seats
going to Palestinians on the West Bank
_#_Judicial branch: Court of Cassation
_#_Leaders:
Chief of State--King HUSSEIN Ibn Talal I (since 11 August 1952);
Head of Government--Prime Minister Tahir al-MASRI (since 17 June
1991)
_#_Political parties and leaders: none; after the 1989 parliamentary
elections, King Hussein promised to allow the formation of political
parties; a national charter that sets forth the ground rules for
democracy in Jordan--including the creation of political parties--has
been completed but not yet approved
_#_Suffrage: universal at age 20
_#_Elections:
House of Representatives--last held 8 November 1989 (next to be
held November 1993); results--percent of vote by party NA;
seats--(80 total) Muslim Brotherhood 22, Independent Islamic bloc
10, Democratic bloc (mostly leftist) 15, Liberal bloc (traditionalist)
7, Nationalist bloc (traditionalist) 14, independent 12
_#_Communists: party actively repressed, membership less than 500
(est.)
_#_Member of: ABEDA, ACC, AFESD, AL, AMF, CAEU, CCC, ESCWA, FAO, G-77,
IAEA, IBRD, ICAO, ICC, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, ISO (correspondent), ITU, LORCS, NAM, OIC, UN,
UNAVEM, UNCTAD, UNESCO, UNIDO, UNRWA, UPU, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Hussein A. HAMMAMI;
Chancery at 3504 International Drive NW, Washington DC 20008;
telephone (202) 966-2664;
US--Ambassador Roger Gram HARRISON; Embassy on Jebel Amman, Amman
(mailing address is P. O. Box 354, Amman, or APO New York 09892);
telephone [962] (6) 644-371
_#_Flag: three equal horizontal bands of black (top), white, and green
with a red isosceles triangle based on the hoist side bearing a small
white seven-pointed star; the seven points on the star represent the
seven fundamental laws of the Koran
_#_Long-form name: none
_#_Type: French possession administered by Commissioner of the
Republic Daniel CONSTANTIN, resident in Reunion
_#_Long-form name: Republic of Kenya
_#_Type: republic
_#_Capital: Nairobi
_#_Administrative divisions: 7 provinces and 1 area*; Central, Coast,
Eastern, Nairobi Area*, North-Eastern, Nyanza, Rift Valley, Western
_#_Independence: 12 December 1963 (from UK; formerly British East
Africa)
_#_Constitution: 12 December 1963, amended as a republic 1964;
reissued with amendments 1979, 1983, 1986, and 1988
_#_Legal system: based on English common law, tribal law, and Islamic
law; judicial review in High Court; accepts compulsory ICJ jurisdiction,
with reservations; constitutional amendment in 1982 made Kenya a de jure
one-party state
_#_National holiday: Independence Day, 12 December (1963)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: unicameral National Assembly (Bunge)
_#_Judicial branch: Court of Appeal, High Court
_#_Leaders:
Chief of State and Head of Government--President Daniel Teroitich
arap MOI (since 14 October 1978); Vice President George SAITOTI
(since 10 May 1989)
_#_Political parties and leaders: only party--Kenya African National
Union (KANU), Daniel T. arap MOI, president
_#_Suffrage: universal at age 18
_#_Elections:
President--last held on 21 March 1988 (next to be held
by March 1993);
results--President Daniel T. arap MOI was reelected;
National Assembly--last held on 21 March 1988
(next to be held by March 1993); results--KANU is the only party;
seats--(202 total, 188 elected) KANU 200
_#_Communists: may be a few Communists and sympathizers
_#_Other political or pressure groups: labor unions; exile
opposition--Mwakenya and other groups
_#_Member of: ACP, AfDB, C, CCC, EADB, ECA, FAO, G-77, GATT, IAEA,
IBRD, ICAO, IDA, IFAD, IFC, IGADD, ILO, IMF, IMO, INTELSAT, INTERPOL,
IOC, IOM, ISO, ITU, LORCS, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO, UNIIMOG,
UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Denis Daudi AFANDE; Chancery
at 2249 R Street NW, Washington DC 20008; telephone (202) 387-6101; there
are Kenyan Consulates General in Los Angeles and New York;
US--Ambassador Smith HEMPSTONE, Jr.; Embassy at the corner of Moi
Avenue and Haile Selassie Avenue, Nairobi (mailing address is P. O. Box
30137, Nairobi or APO New York 09675); telephone [254] (2) 334141; there
is a US Consulate in Mombasa
_#_Flag: three equal horizontal bands of black (top), red, and green;
the red band is edged in white; a large warrior''s shield covering crossed
spears is superimposed at the center
_#_Long-form name: none
_#_Type: unincorporated territory of the US administered by the
US Navy
_#_Long-form name: Republic of Kiribati; note--pronounced Kiribas
_#_Type: republic
_#_Capital: Tarawa
_#_Administrative divisions: 3 units; Gilbert Islands, Line Islands,
Phoenix Islands; note--a new administrative structure of 6 districts
(Banaba, Central Gilberts, Line Islands, Northern Gilberts, Southern
Gilberts, Tarawa) may have been changed to 20 island councils (one for
each of the inhabited islands) named Abaiang, Abemama, Aranuka, Arorae,
Banaba, Beru, Butaritari, Kiritimati, Kuria, Maiana, Makin, Marakei,
Nikunau, Nonouti, Onotoa, Tabiteuea, Tabuaeran, Tamana, Tarawa, Teraina
_#_Independence: 12 July 1979 (from UK; formerly Gilbert Islands)
_#_Constitution: 12 July 1979
_#_National holiday: Independence Day, 12 July (1979)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: unicameral House of Assembly (Maneaba Ni
Maungatabu)
_#_Judicial branch: Court of Appeal, High Court
_#_Leaders:
Chief of State and Head of Government--President Ieremia TABAI
(since 12 July 1979); Vice President Teatao TEANNAKI (since 20 July 1979)
_#_Political parties and leaders:
Gilbertese National Party;
Christian Democratic Party, Teburoro TITO, secretary;
essentially not organized on the basis of political parties
_#_Suffrage: universal at age 18
_#_Elections:
President--last held on 12 May 1987 (next to be held May 1991);
results--Ieremia TABAI 50.1%, Tebruroro TITO 42.7%, Tetao
TEANNAKI 7.2%;
House of Assembly--last held on 19 March l987 (next to be held
May 1991); results--percent of vote by party NA;
seats--(40 total; 39 elected) percent of seats by party NA
_#_Member of: ACP, AsDB, C, ESCAP (associate), IBRD, ICAO, ICFTU,
IDA, IFC, IMF, INTERPOL, ITU, SPC, SPF, UNESCO, UPU, WHO
_#_Diplomatic representation: Ambassador (vacant) lives in Tarawa
(Kiribati);
US--none
_#_Flag: the upper half is red with a yellow frigate bird flying over
a yellow rising sun and the lower half is blue with three horizontal wavy
white stripes to represent the ocean
_#_Long-form name: Democratic People''s Republic of Korea; abbreviated
DPRK
_#_Type: Communist state; dictatorship
_#_Capital: P''yongyang
_#_Administrative divisions: 9 provinces (do, singular and plural) and
3 special cities* (jikhalsi, singular and plural); Chagang-do,
Hamgyong-namdo, Hamgyong-bukto, Hwanghae-namdo, Hwanghae-bukto,
Kaesong-si*, Kangwon-do, Namp''o-si*, P''yongan-bukto,
P''yongan-namdo, P''yongyang-si*, Yanggang-do
_#_Independence: 9 September 1948
_#_Constitution: adopted 1948, revised 27 December 1972
_#_Legal system: based on German civil law system with Japanese
influences and Communist legal theory; no judicial review of legislative
acts; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 9 September (1948)
_#_Executive branch: president, two vice presidents, premier, eleven
vice premiers, State Administration Council (cabinet)
_#_Legislative branch: unicameral Supreme People''s Assembly (Ch''oego
Inmin Hoeui)
_#_Judicial branch: Central Court
_#_Leaders:
Chief of State--President KIM Il-song (since 28 December 1972);
Designated Successor KIM Chong-il (son of President, born 16 February
1942);
Head of Government--Premier YON Hyong-muk (since NA December 1988)
_#_Political parties and leaders: major party--Korean Workers'' Party
(KWP), KIM Il-song, general secretary, and his son, KIM Chong-il,
secretary, Central Committee;
Korean Social Democratic Party, YI Kye-paek, chairman;
Chondoist Chongu Party, CHONG Sin-hyok, chairman
_#_Suffrage: universal at age 17
_#_Elections:
President--last held 24 May 1990 (next to be held 1994);
results--President KIM Il-song was reelected without opposition;
Supreme People''s Assembly--last held on 24 May 1990 (next
to be held 1994);
results--percent of vote by party NA;
seats--(687 total) the KWP approves a single list of candidates
who are elected without opposition; minor parties hold a few seats
_#_Communists: KWP claims membership of about 3 million
_#_Member of: FAO, G-77, IAEA, ICAO, IFAD, IMF (observer), IMO, IOC,
ISO, ITU, LORCS, NAM, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU,
WHO, WIPO, WMO, WTO
_#_Diplomatic representation: none
_#_Flag: three horizontal bands of blue (top), red (triple width), and
blue; the red band is edged in white; on the hoist side of the red band
is a white disk with a red five-pointed star
_#_Long-form name: Republic of Korea; abbreviated ROK
_#_Type: republic
_#_Capital: Seoul
_#_Administrative divisions: 9 provinces (do, singular and plural) and
6 special cities* (jikhalsi, singular and plural); Cheju-do,
Cholla-bukto, Cholla-namdo, Ch''ungch''ong-bukto,
Ch''ungch''ong-namdo, Inch''on-jikhalsi*, Kangwon-do,
Kwangju-jikhalsi*, Kyonggi-do, Kyongsang-bukto,
Kyongsang-namdo, Pusan-jikhalsi*, Soul-t''ukpyolsi*,
Taegu-jikhalsi*, Taejon-jikhalsi*
_#_Independence: 15 August 1948
_#_Constitution: 25 February 1988
_#_Legal system: combines elements of continental European civil law
systems, Anglo-American law, and Chinese classical thought; has not
accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 15 August (1948)
_#_Executive branch: president, prime minister, deputy prime minister,
State Council (cabinet)
_#_Legislative branch: unicameral National Assembly (Kuk Hoe)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President ROH Tae Woo (since 25 February 1988);
Head of Government--Prime Minister CHUNG Won Shik (since 24
May 1991); Deputy Prime Minister CHOI Kak Kyu (since 19 February
1991)
_#_Political parties and leaders:
ruling party--Democratic Liberal Party (DLP), ROH Tae Woo,
president, KIM Young Sam, chairman;
note--the DLP resulted from a merger of the Democratic Justice Party
(DJP), Reunification Democratic Party (RDP), and New Democratic
Republican Party (NDRP) on 9 February 1990;
opposition--New Democratic Party (NDP, formerly Party for Peace
and Democracy or PPD), KIM Dae Jung, president; Democratic Party (DP),
YI Ki Taek; several smaller parties
_#_Suffrage: universal at age 20
_#_Elections:
President--last held on 16 December 1987 (next to be held
December 1992);
results--ROH Tae Woo (DJP) 35.9%, KIM Young Sam (RDP) 27.5%,
KIM Dae Jung (PPD) 26.5%, other 10.1%;
National Assembly--last held on 26 April 1988 (next to be held
April 1992);
results--DJP 34%, RDP 24%, PPD 19%, NDRP 15%, other 8%;
seats--(299 total) DJP 125, PPD 70, RDP 59, NDRP 35, other 10;
note--on 9 February 1990 the DJP, RDP, and NDRP merged to form the DLP;
also the PPD became the NDP; as a result the distribution
of seats changed to DLP 218, NDP 70, other 11 (June 1990)
_#_Communists: Communist party activity banned by government
_#_Other political or pressure groups: Korean National Council of
Churches; National Democratic Alliance of Korea; National Council of
College Student Representatives; National Federation of Farmers''
Associations; National Council of Labor Unions; Federation of Korean
Trade Unions; Korean Veterans'' Association; Federation of Korean
Industries; Korean Traders Association
_#_Member of: AfDB, APEC, AsDB, CCC, CP, EBRD, ESCAP, FAO, G-77,
GATT, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IFAD, IFC, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, IOM, ISO, ITU, LORCS, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador HYUN Hong Joo;
Chancery at 2320 Massachusetts Avenue NW, Washington DC 20008; telephone
(202) 939-5600; there are Korean Consulates General in Agana (Guam),
Anchorage, Atlanta, Chicago, Honolulu, Houston, Los Angeles, New York,
San Francisco, and Seattle;
US--Ambassador Donald P. GREGG; Embassy at 82 Sejong-Ro,
Chongro-ku, Seoul (mailing address is APO San Francisco 96301);
telephone [82] (2) 732-2601 through 2618; there is a US Consulate
in Pusan
_#_Flag: white with a red (top) and blue yin-yang symbol in the
center; there is a different black trigram from the ancient I Ching
(Book of Changes) in each corner of the white field
_#_Long-form name: State of Kuwait
_#_Type: nominal constitutional monarchy
_#_Capital: Kuwait
_#_Administrative divisions: 4 governorates (muhafazat,
singular--muhafazah); Al Ahmadi, Al Jahrah, Al Kuwayt,
Hawalli; note--there may be a new governorate of Farwaniyyah
_#_Independence: 19 June 1961 (from UK)
_#_Constitution: 16 November 1962 (some provisions suspended since 29
August 1962)
_#_Legal system: civil law system with Islamic law significant in
personal matters; has not accepted compulsory ICJ jurisdiction
_#_National holiday: National Day, 25 February
_#_Executive branch: amir, prime minister, deputy prime minister,
Council of Ministers (cabinet)
_#_Legislative branch: National Assembly (Majlis al Umma) dissolved
3 July 1986
_#_Judicial branch: High Court of Appeal
_#_Leaders:
Chief of State--Amir Shaykh Jabir al-Ahmad al-Jabir al-SABAH
(since 31 December 1977);
Head of Government--Prime Minister and Crown Prince Sad
al-Abdallah al-Salim al-SABAH (since 8 February 1978); Deputy
Prime Minister Salim al-Sabah al-Salim al-SABAH
_#_Political parties and leaders: none
_#_Suffrage: adult males who resided in Kuwait before 1920 and their
male descendants at age 21; note--out of all citizens, only 8.3% are
eligible to vote and only 3.5% actually vote
_#_Elections:
National Assembly--dissolved 3 July 1986; new elections are
scheduled for October 1992
_#_Communists: insignificant
_#_Other political or pressure groups: large (150,000) Palestinian
community; several small, clandestine leftist and Shia fundamentalist
groups are active; prodemocracy opposition
_#_Member of: ABEDA, AfDB, AFESD, AL, AMF, BDEAC, CAEU, ESCWA, FAO,
G-77, GATT, GCC, IAEA, IBRD, ICAO, ICC, IDA, IDB, IFAD, IFC, ILO, IMF,
IMO, INMARSAT, INTELSAT, INTERPOL, IOC, ISO (correspondent), ITU,
LORCS, NAM, OAPEC, OIC, OPEC, UN, UNCTAD, UNESCO, UNIDO, UPU,
WFTU, WHO, WMO, WTO
_#_Diplomatic representation: Ambassador Shaykh Saud Nasir al-SABAH;
Chancery at 2940 Tilden Street NW, Washington DC 20008;
telephone (202) 966-0702;
US--Ambassador Edward (Skip) GNEHM; Embassy at Bneid al-Gar
(opposite the Hilton Hotel), Kuwait City (mailing address is P. O. Box 77
Safat, 13001 Safat, Kuwait City); telephone [965] 242-4151 through 4159
_#_Flag: three equal horizontal bands of green (top), white, and
red with a black trapezoid based on the hoist side
_#_Long-form name: Lao People''s Democratic Republic
_#_Type: Communist state
_#_Capital: Vientiane
_#_Administrative divisions: 16 provinces (khoueng, singular and
plural) and 1 municipality* (kampheng nakhon, singular and plural);
Attapu, Bokeo, Bolikhamsai, Champasak, Houaphan, Khammouan, Louang
Namtha, Louangphrabang, Oudomxai, Phongsali, Saravan, Savannakhet,
Sekong, Vientiane, Vientiane*, Xaignabouri, Xiangkhoang
_#_Independence: 19 July 1949 (from France)
_#_Constitution: draft constitution under discussion since 1976
_#_Legal system: based on civil law system; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: National Day (proclamation of the Lao People''s
Democratic Republic), 2 December (1975)
_#_Executive branch: president, chairman and four vice chairmen of the
Council of Ministers, Council of Ministers (cabinet)
_#_Legislative branch: Supreme People''s Assembly
_#_Judicial branch: People''s Supreme Court
_#_Leaders:
Chief of State--President KAYSONE PHOMVIHAN (since 15
August 1991);
Head of Government--Chairman of the Council of Ministers General
Gen. KHAMTAI SIPHANDON (since 15 August 1991)
_#_Political parties and leaders:
Lao People''s Revolutionary Party (LPRP), KAYSONE PHOMVIHAN, party
chairman;
includes Lao Patriotic Front and Alliance Committee of Patriotic
Neutralist Forces;
other parties moribund
_#_Suffrage: universal at age 18
_#_Elections:
Supreme People''s Assembly--last held on 26 March 1989 (next to be
held NA); results--percent of vote by party NA;
seats--(79 total) number of seats by party NA
_#_Other political or pressure groups: non-Communist political groups
moribund; most leaders have fled the country
_#_Member of: ACCT (associate), AsDB, CP, ESCAP,
FAO, G-77, IBRD, ICAO, IDA, IFAD, ILO, IMF, INTERPOL, IOC, ITU,
LORCS, NAM, PCA, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WMO, WTO
_#_Diplomatic representation: Charge d''Affaires LINTHONG PHETSAVAN;
Chancery at 2222 S Street NW, Washington DC 20008;
telephone (202) 332-6416 or 6417;
US--Charge d''Affaires Charles B. SALMON, Jr.; Embassy at Rue
Bartholonie, Vientiane (mailing address is B. P. 114, Vientiane, or
Box V, APO San Francisco 96346); telephone 2220, 2357, 2384
_#_Flag: three horizontal bands of red (top), blue (double width), and
red with a large white disk centered in the blue band
_#_Note: Between early 1975 and late 1976 Lebanon was torn by civil
war between its Christians--then aided by Syrian troops--and its Muslims
and their Palestinian allies. The cease-fire established in October
1976 between the domestic political groups generally held for about six
years, despite occasional fighting. Syrian troops constituted as the Arab
Deterrent Force by the Arab League have remained in Lebanon. Syria''s
move toward supporting the Lebanese Muslims and the Palestinians and
Israel''s growing support for Lebanese Christians brought the two sides
into rough equilibrium, but no progress was made toward national
reconciliation or political reforms--the original cause of the war.
Continuing Israeli concern about the Palestinian presence in
Lebanon led to the Israeli invasion of Lebanon in June 1982. Israeli
forces occupied all of the southern portion of the country and mounted a
summer-long siege of Beirut, which resulted in the evacuation of the
PLO from Beirut in September under the supervision of a multinational
force (MNF) made up of US, French, and Italian troops.
Within days of the departure of the MNF, Lebanon''s newly elected
president, Bashir Gemayel, was assassinated. In the wake of his death,
Christian militiamen massacred hundreds of Palestinian refugees in two
Beirut camps. This prompted the return of the MNF to ease the security
burden on Lebanon''s weak Army and security forces. In late March 1984
the last MNF units withdrew.
Lebanese Parliamentarians met in Taif, Saudi Arabia in late 1989
and concluded a national reconciliation pact that codified a new
power-sharing formula, specifiying a Christian president but giving
Muslims more authority. Rene Muawad was subsequently elected president on
4 November 1989, ending a 13-month period during which Lebanon had no
president and rival Muslim and Christian governments. Muawad was
assassinated 17 days later, on 22 November; on 24 November Ilyas Harawi
was elected to succeed Muawad.
In October 1990, the chances for ending the 16 year old civil war
and implementing Ta''if were markedly improved when Syrian and Lebanese
forces ousted renegade Christian General Awn from his stronghold in East
Beirut. Awn had defied the legitimate government and established a
separate mini-state within East Beirut after being appointed acting
Prime Minister by outgoing President Gemayel in 1988. Awn and his
supporters feared Ta''if would diminish Christian power in Lebanon
and increase the influence of Syria.
Since the removal of Awn, the Lebanese Government has reunited the
capital city and implemented a phased plan to disarm the militias
and gradually reestablish authority throughout Lebanon. The army has
deployed from Beirut north along the coast road to Tripoli, southeast
into the Shuf mountains, and south to the vicinity of Sidon. Many
militiamen from Christian and Muslim groups have evacuated Beirut
for their strongholds in the north, south, and east of the country.
Some heavy weapons possessed by the militias have been turned over to
the government, which has begun a plan to integrate some militiamen
into the military and the internal security forces.
Lebanon and Syria signed a treaty of friendship and cooperation in
May 1991. Lebanon continues to be partially occupied by Syrian troops,
which are deployed in East and West Beirut, its southern suburbs,
the Bekaa Valley, and throughout northern Lebanon.
Iran also maintains a small contingent of revolutionary guards
in the Bekaa Valley and South Lebanon to support Lebanese Islamic
fundamentalist groups.
Israel withdrew the bulk of its forces from the south in 1985,
although it still retains troops in a 10-km-deep security zone north
of its border with Lebanon. Israel arms and trains the Army of South
Lebanon (ASL), which also occupies the security zone and is Israel''s
first line of defense against attacks on its northern border.
The following description is based on the present constitutional
and customary practices of the Lebanese system.
_#_Long-form name: Republic of Lebanon; note--may be changed to
Lebanese Republic
_#_Type: republic
_#_Capital: Beirut
_#_Administrative divisions: 5 governorates (muhafazat,
singular--muhafazah); Al Biqa, Al Janub, Ash Shamal,
Bayrut, Jabal Lubnan
_#_Independence: 22 November 1943 (from League of Nations mandate
under French administration)
_#_Constitution: 26 May 1926 (amended)
_#_Legal system: mixture of Ottoman law, canon law, Napoleonic code,
and civil law; no judicial review of legislative acts; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 22 November (1943)
_#_Executive branch: president, prime minister, Cabinet; note--by
custom, the president is a Maronite Christian, the prime minister is a
Sunni Muslim, and the speaker of the legislature is a Shia Muslim
_#_Legislative branch: unicameral National Assembly (Arabic--Majlis
Alnuwab, French--Assemblee Nationale)
_#_Judicial branch: four Courts of Cassation (three courts for civil
and commercial cases and one court for criminal cases)
_#_Leaders:
Chief of State--Ilyas HARAWI (since 24 November 1989);
Head of Government--Prime Minister Umar KARAMI (since 20
December 1990)
_#_Political parties and leaders: political party activity is
organized along largely sectarian lines; numerous political groupings
exist, consisting of individual political figures and followers
motivated by religious, clan, and economic','218cead110d2218d126162f6d2453dd7cc4c62976a2f976f0d8aa10fc6d2e916','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45fe35331b088c4ea693c2fe1c8c5af8f1059bb65998f7756bb714874cd8300c',1991,'FR','France','government',102,'considerations; most parties
have well-armed militias, which are still involved in occasional clashes
_#_Suffrage: compulsory for all males at age 21; authorized for women
at age 21 with elementary education
_#_Elections:
National Assembly--elections should be held every four years
but security conditions have prevented elections since May 1972
_#_Communists: the Lebanese Communist Party was legalized in 1970;
members and sympathizers estimated at 2,000-3,000
_#_Member of: ABEDA, ACCT, AFESD, AL, AMF, CCC, ESCWA, FAO, G-24,
G-77, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IDB, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, IOC, ITU, LORCS, NAM, OIC, PCA, UN, UNCTAD,
UNESCO, UNHCR, UNIDO, UNRWA, UPU, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Nassib S. LAHOUD;
Chancery at 2560 28th Street NW, Washington DC 20008; telephone (202)
939-6300; there are Lebanese Consulates General in Detroit, New York, and
Los Angeles;
US--Ambassador Ryan C. CROCKER; Embassy at Antelias, Beirut
(mailing address is P. O. Box 70-840, Beirut, and FPO New York 09530);
telephone [961] 417774 or 415802, 415803, 402200, 403300
_#_Flag: three horizontal bands of red (top), white (double width),
and red with a green and brown cedar tree centered in the white band
_#_Long-form name: Kingdom of Lesotho
_#_Type: constitutional monarchy
_#_Capital: Maseru
_#_Administrative divisions: 10 districts; Berea, Butha-Buthe, Leribe,
Mafeteng, Maseru, Mohales Hoek, Mokhotlong, Qachas Nek, Quthing,
Thaba-Tseka
_#_Independence: 4 October 1966 (from UK; formerly Basutoland)
_#_Constitution: 4 October 1966, suspended January 1970
_#_Legal system: based on English common law and Roman-Dutch law;
judicial review of legislative acts in High Court and Court of Appeal;
has not accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 4 October (1966)
_#_Executive branch: monarch, chairman of the Military Council,
Military Council, Council of Ministers (cabinet)
_#_Legislative branch: none--the bicameral Parliament was dissolved
following the military coup in January 1986; note--a National Constituent
Assembly convened in June 1990 to rewrite the constitution and debate
issues of national importance, but it has no legislative authority
_#_Judicial branch: High Court, Court of Appeal
_#_Leaders:
Chief of State--King LETSIE III (since 12 November 1990 following
dismissal of his father, exiled King MOSHOESHOE II, by Maj. Gen.
LEKHANYA);
Head of Government--Chairman of the Military Council Col.
Elias Phisoana RAMAEMA (since 30 April 1991)
_#_Political parties and leaders:
Basotho National Party (BNP), Matete MAJARA (interim leader);
Basutoland Congress Party (BCP), Ntsu MOKHEHLE;
National Independent Party (NIP), A. C. MANYELI;
Marematlou Freedom Party (MFP), S. H. MAPHELEBA;
United Democratic Party, Charles MOFELI;
Communist Party of Lesotho (CPL), Jacob KENYA
_#_Suffrage: universal at age 21
_#_Elections:
National Assembly--dissolved following the military coup in
January 1986; military has pledged elections will take place in June 1992
_#_Communists: small Lesotho Communist Party
_#_Member of: ACP, AfDB, C, CCC, ECA, FAO, G-77, GATT, IBRD, ICAO,
ICFTU, IDA, IFAD, IFC, ILO, IMF, INTERPOL, IOC, ITU, LORCS,
NAM, OAU, SACU, SADCC, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WCL,
WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador W. T. VAN TONDER; Chancery at
2511 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
797-5 534;
US--Ambassador Leonard H.O. SPEARMAN, Jr.; Embassy at address NA,
Maseru (mailing address is P. O. Box 333, Maseru 100); telephone [266]
312666
_#_Flag: divided diagonally from the lower hoist side corner; the
upper half is white bearing the brown silhouette of a large shield with
crossed spear and club; the lower half is a diagonal blue band with a
green triangle in the corner
_#_Long-form name: Republic of Liberia
_#_Type: republic
_#_Capital: Monrovia
_#_Administrative divisions: 13 counties; Bomi, Bong, Grand Bassa,
Grand Cape Mount, Grand Jide, Grand Kru, Lofa, Margibi, Maryland,
Montserrado, Nimba, Rivercess, Sino
_#_Independence: 26 July 1847
_#_Constitution: 6 January 1986
_#_Legal system: dual system of statutory law based on Anglo-American
common law for the modern sector and customary law based on unwritten
tribal practices for indigenous sector
_#_National holiday: Independence Day, 26 July (1847)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: bicameral National Assembly consists of an
upper house or Senate and a lower house or House of Representatives
_#_Judicial branch: People''s Supreme Court
_#_Leaders:
Chief of State and Head of Government--interim President Dr.
Amos SAWYER (since 15 November 1990); interim Vice President Ronald DIGGS
(since 15 November 1990); note--this is an interim government appointed
by the Economic Community of West African States (ECOWAS) that will be
replaced after elections are held under a West African-brokered
peace plan; rival rebel factions led by Prince Y. JOHNSON and Charles
TAYLOR are challenging the Sawyer government''s legitimacy while
observing a tenuous cease fire; the former president, Gen. Dr. Samuel
Kanyon DOE, was ousted and killed on 9 September 1990 in a coup led by
Prince Y. JOHNSON
_#_Political parties and leaders:
National Democratic Party of Liberia (NDPL), Augustus CAINE, chairman;
Liberian Action Party (LAP), Emmanuel KOROMAH, chairman;
Unity Party (UP), Carlos SMITH, chairman;
United People''s Party (UPP), Gabriel Baccus MATTHEWS, chairman
_#_Suffrage: universal at age 18
_#_Elections:
President--last held on 15 October 1985 (next to be held NA);
results--Gen. Dr. Samuel Kanyon DOE (NDPL) 50.9%, Jackson DOE (LAP)
26.4%, other 22.7%; note--President Doe was killed by rebel forces
on 9 September 1990;
Senate--last held on 15 October 1985 (next to be held NA);
results--percent of vote by party NA;
seats--(26 total) NDPL 21, LAP 3, UP 1, LUP 1;
House of Representatives--last held on 15 October 1985 (next
to be held NA); results--percent of vote by party NA;
seats--(64 total) NDPL 51, LAP 8, UP 3, LUP 2
_#_Member of: ACP, AfDB, CCC, ECA, ECOWAS, FAO, G-77, IAEA, IBRD,
ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTERPOL, IOC, ITU,
LORCS, NAM, OAU, UN, UNCTAD, UNESCO, UPU, WCL, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Eugenia A.
WORDSWORTH-STEVENSON; Chancery at 5201 16th Street NW, Washington DC
20011; telephone (202) 723-0437 through 0440; there is a Liberian
Consulate General in New York;
US--Ambassador Peter J. de VOS; Embassy at 111 United Nations
Drive, Monrovia (mailing address is P. O. Box 98, Monrovia, or APO New
York 09155); telephone [231] 222991 through 222994
_#_Flag: 11 equal horizontal stripes of red (top and bottom)
alternating with white; there is a white five-pointed star on a blue
square in the upper hoist-side corner; the design was based on the US
flag
_#_Long-form name: Socialist People''s Libyan Arab Jamahiriya
_#_Type: Jamahiriya (a state of the masses); in theory, governed by
the populace through local councils; in fact, a military dictatorship
_#_Capital: Tripoli
_#_Administrative divisions: 46 municipalities (baladiyat,
singular--baladiyah); Ajdabiya, Al Abyar, Al
Aziziyah, Al Bayda, Al Jufrah, Al Jumayl, Al Khums, Al
Kufrah, Al Marj, Al Qarabulli, Al Qubbah, Al Ujaylat, Ash
Shati, Awbari, Az Zahra, Az Zawiyah, Banghazi,
Bani Walid, Bin Jawwad, Darnah, Ghadamis, Gharyan,
Ghat, Jadu, Jalu, Janzur, Masallatah, Misratah,
Mizdah, Murzuq, Nalut, Qaminis, Qasr Bin Ghashir, Sabha,
Sabratah, Shahhat, Surman, Surt, Tajura,
Tarabulus, Tarhunah, Tubruq, Tukrah, Yafran, Zlitan,
Zuwarah; note--the number of municipalities may have been reduced to
13 named Al Jabal al-Akhdar, Al Jabal al-Gharbi, Al Jabal al-Khums, Al
Batnam, Al Kufrah, Al Marqab, Al Marzuq, Az Zawiyah, Banghazi,
Khalij Surt, Sabha, Tripoli, Wadi al-Hayat
_#_Independence: 24 December 1951 (from Italy)
_#_Constitution: 11 December 1969, amended 2 March 1977
_#_Legal system: based on Italian civil law system and Islamic law;
separate religious courts; no constitutional provision for judicial
review of legislative acts; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Revolution Day, 1 September (1969)
_#_Executive branch: revolutionary leader, chairman of the General
People''s Committee, General People''s Committee (cabinet)
_#_Legislative branch: unicameral General People''s Congress
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Revolutionary Leader Col. Muammar Abu Minyar
al-QADHAFI (since 1 September 1969);
Head of Government--Chairman of the General People''s Committee
(Premier) Abu Zayd Umar DURDA (since 7 October 1990)
_#_Political parties and leaders: none
_#_Suffrage: universal and compulsory at age 18
_#_Elections: national elections are indirect through a hierarchy of
revolutionary committees
_#_Political parties: none
_#_Communists: no organized party, negligible membership
_#_Other political or pressure groups: various Arab nationalist
movements and the Arab Socialist Resurrection (Ba''th) party with
almost negligible memberships may be functioning clandestinely, as
well as some Islamic elements
_#_Member of: ABEDA, AfDB, AFESD, AL, AMF, AMU, CAEU, CCC, ECA, FAO,
G-77, IAEA, IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, ITU, LORCS, NAM, OAPEC, OAU, OIC, OPEC, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: none
_#_Flag: plain green; green is the traditional color of Islam (the
state religion)
_#_Long-form name: Principality of Liechtenstein
_#_Type: hereditary constitutional monarchy
_#_Capital: Vaduz
_#_Administrative divisions: 11 communes (gemeinden,
singular--gemeinde); Balzers, Eschen, Gamprin, Mauren, Planken, Ruggell,
Schaan, Schellenberg, Triesen, Triesenberg, Vaduz
_#_Independence: 23 January 1719, Imperial Principality of
Liechtenstein established
_#_Constitution: 5 October 1921
_#_Legal system: local civil and penal codes; accepts compulsory ICJ
jurisdiction, with reservations
_#_National holiday: Saint Joseph''s Day, 19 March
_#_Executive branch: reigning prince, hereditary prince, head
of government, deputy head of government
_#_Legislative branch: unicameral Diet (Landtag)
_#_Judicial branch: Supreme Court (Oberster Gerichtshof) for criminal
cases and Superior Court (Obergericht) for civil cases
_#_Leaders:
Chief of State--Prince HANS ADAM II (since 13 November 1989;
assumed executive powers 26 August 1984);
Heir Apparent Prince ALOIS von und zu Liechtenstein (born 11 June 1968);
Head of Government--Hans BRUNHART (since 26 April 1978);
Deputy Head of Government Dr. Herbert WILLE (since 2 February 1986)
_#_Political parties and leaders:
Fatherland Union (VU), Dr. Otto HASLER;
Progressive Citizens'' Party (FBP), Emanuel VOGT;
Free Electoral List (FW)
_#_Suffrage: universal at age 18
_#_Elections:
Diet--last held on 5 March 1989 (next to be held by March 1993);
results--percent of vote by party NA;
seats--(25 total) VU 13, FBP 12
_#_Communists: none
_#_Member of: CE, CSCE, EBRD, EFTA, IAEA, INTELSAT, INTERPOL, IOC,
ITU, LORCS, UN, UNCTAD, UPU, WIPO
_#_Diplomatic representation: in routine diplomatic matters,
Liechtenstein is represented in the US by the Swiss Embassy;
US--the US has no diplomatic or consular mission in Liechtenstein,
but the US Consul General at Zurich (Switzerland) has consular
accreditation at Vaduz
_#_Flag: two equal horizontal bands of blue (top) and red with a
gold crown on the hoist side of the blue band
_#_Long-form name: Grand Duchy of Luxembourg
_#_Type: constitutional monarchy
_#_Capital: Luxembourg
_#_Administrative divisions: 3 districts; Diekirch, Grevenmacher,
_#_Long-form name: Mongolian People''s Republic; abbreviated MPR
_#_Type: in transition from Communist state to republic
_#_Capital: Ulaanbaatar
_#_Administrative divisions: 18 provinces (aymguud, singular--aymag)
and 3 municipalities* (hotuud, singular--hot); Arhangay, Bayanhongor,
Bayan-Olgiy, Bulgan, Darhan*, Dornod, Dornogovi, Dundgovi,
Dzavhan, Erdenet*, Govi-Altay, Hentiy, Hovd, Hovsgol,
Omnogovi, Ovorhangay, Selenge, Suhbaatar, Tov,
Ulaanbaatar*, Uvs
_#_Independence: 13 March 1921 (from China; formerly Outer Mongolia)
_#_Constitution: 6 July 1960
_#_Legal system: blend of Russian, Chinese, and Turkish systems of
law; no constitutional provision for judicial review of legislative acts;
has not accepted compulsory ICJ jurisdiction
_#_National holiday: People''s Revolution Day, 11 July (1921)
_#_Executive branch: chairman and deputy chairman of the Presidium of
the People''s Great Hural, premier, deputy premiers, Cabinet
_#_Legislative branch: People''s Great Hural, People''s Small Hural
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Punsalmaagiyn OCHIRBAT (since 3
September 1990); Vice President Radnaasumbereliyn GONCHIGDORJ (since
7 September 1990);
Head of Government--Premier Dashiyn BYAMBASUREN (since 11
September 1990);
_#_Political parties and leaders:
ruling party--Mongolian People''s Revolutionary Party (MPRP),
Budragchagiin DASH-YONDON, general secretary;
opposition--Social Democratic Party (SDP), Batbayar;
Mongolian Democratic Association, Sanjasuren DZORIG, chief coordinator;
Mongolian Party of National Progress, Ganbold;
other--Mongolian Democratic Party (MDP), Batuul;
Free Labor Party, Maam;
note--opposition parties were legalized in May 1990
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 3 September 1990 (next to be held July 1994);
results--Punsalmaagiyn OCHIRBAT elected by the People''s Great Hural;
People''s Great Hural--last held on 29 July 1990 (next to be held
July 1994);
results--MPRP 84.6, MDP 3.8%, PNP 1.4%, SDP 1%, independents 9.2%;
seats--(430 total) MPRP 343;
People''s Small Hural--last held on 29 July 1990 (next to be
held July 1994);
results--MPRP 62.3%, MDP 24.5%, SDP 7.5%, PNP 5.7%;
seats--(50 total) MPRP 33
_#_Communists: MPRP membership 90,000 (1990 est.)
_#_Member of: AsDB, ESCAP, FAO, IAEA, IBEC, IBRD, ICAO, IIB, ILO, IMF,
IOC, ISO, ITU, LORCS, NAM, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO,
WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Gendengiyn NYAMDOO;
Chancery, Tel. (202) 983-1962;
US--Ambassador Joseph E. LAKE; Deputy Chief of Mission
Michael J. SENKO; Embassy at Ulaanbaatar, c/o American Embassy
Beijing; Tel. 29095 and 29639
_#_Flag: three equal, vertical bands of red (hoist side), blue, and
red; centered on the hoist-side red band in yellow is a five-pointed star
above the national emblem (soyombo--a columnar arrangement of
abstract and geometric representations for fire, sun, moon, earth, water,
and the yin-yang symbol)
_#_Long-form name: none
_#_Type: dependent territory of the UK
_#_Capital: Plymouth
_#_Administrative divisions: 3 parishes; Saint Anthony, Saint Georges,
Saint Peter
_#_Independence: none (dependent territory of the UK)
_#_Constitution: 1 January 1960
_#_Legal system: English common law and statute law
_#_National holiday: Celebration of the Birthday of the Queen (second
Saturday of June)
_#_Executive branch: monarch, governor, Executive Council (cabinet),
chief minister
_#_Legislative branch: unicameral Legislative Council
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor David TAYLOR (since NA 1990);
Head of Government--Chief Minister John A. OSBORNE (since NA
1978)
_#_Political parties and leaders:
People''s Liberation Movement (PLM), John OSBORNE;
Progressive Democratic Party (PDP), Howell BRAMBLE;
United National Front (UNF), Dr. George IRISH;
National Development Party (NDP), Bertrand OSBORNE
_#_Suffrage: universal at age 18
_#_Elections:
Legislative Council--last held on 25 August 1987 (next to be
held NA 1992);
results--percent of vote by party NA;
seats--(11 total, 7 elected) PLM 4, NDP 2, PDP 1
_#_Communists: probably none
_#_Member of: CARICOM, CDB, ECLAC (associate), ICFTU, OECS, WCL
_#_Diplomatic representation: none (dependent territory of the UK)
_#_Flag: blue with the flag of the UK in the upper hoist-side quadrant
and the Montserratian coat of arms centered in the outer half of the
flag; the coat of arms features a woman standing beside a yellow harp
with her arm around a black cross
_#_Long-form name: Kingdom of Morocco
_#_Type: constitutional monarchy
_#_Capital: Rabat
_#_Administrative divisions: 37 provinces (aqalim,
singular--iqlim) and 5 municipalities* (wilayat,
singular--wilayah); Agadir, Al Hoceima, Azilal, Beni Mellal, Ben
Slimane, Boulemane, Casablanca*, Chaouen, El Jadida, El Kelaa des
Srarhna, Er Rachidia, Essaouira, Fes, Fes*, Figuig, Guelmim, Ifrane,
Kenitra, Khemisset, Khenifra, Khouribga, Laayoune, Larache, Marrakech,
Marrakech*, Meknes, Meknes*, Nador, Ouarzazate, Oujda, Rabat-Sale*,
Safi, Settat, Sidi Kacem, Tanger, Tan-Tan, Taounate, Taroudannt, Tata,
Taza, Tetouan, Tiznit
_#_Independence: 2 March 1956 (from France)
_#_Constitution: 10 March 1972
_#_Legal system: based on Islamic law and French and Spanish civil law
system; judicial review of legislative acts in Constitutional Chamber of
Supreme Court
_#_National holiday: National Day (anniversary of King Hassan II''s
accession to the throne), 3 March (1961)
_#_Executive branch: monarch, prime minister, Council of Ministers
(cabinet)
_#_Legislative branch: unicameral House of Representatives (Majlis
Nawab)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--King HASSAN II (since 3 March 1961);
Head of Government--Prime Minister Dr. Azzedine LARAKI (since
30 September 1986)
_#_Political parties and leaders: Morocco has 15 political parties;
the major ones are
Istiqlal Party, M''Hamed BOUCETTA;
Socialist Union of Popular Forces (USFP), Abderrahim BOUABID;
Popular Movement (MP), Secretariat General;
National Assembly of Independents (RNI), Ahmed OSMAN;
National Democratic Party (PND), Mohamed Arsalane EL-JADIDI;
Party for Progress and Socialism (PPS), Ali YATA;
Constitutional Union (UC), Maati BOUABID
_#_Suffrage: universal at age 21
_#_Elections:
Chamber of Representatives--last held on 14 September 1984 (were
scheduled for September 1990, but postponed until NA 1992);
results--percent of vote by party NA;
seats--(306 total, 206 elected) CU 83, RNI 61, MP 47, Istiqlal 41,
USFP 36, PND 24, other 14
_#_Communists: about 2,000
_#_Member of: ABEDA, ACCT (associate), AfDB, AFESD, AL, AMF, AMU, CCC,
EBRD, ECA, FAO, G-77, GATT, IAEA, IBRD, ICAO, ICC, IDA, IDB, IFAD, IFC,
IIB, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS,
OAS (observer), NAM, OIC, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WHO,
WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Mohamed BELKHAYAT;
Chancery at 1601 21st Street NW, Washington DC 20009; telephone (202)
462-7979; there is a Moroccan Consulate General in New York;
US--Ambassador E. Michael USSERY; Embassy at 2 Avenue de Marrakech,
Rabat (mailing address is P. O. Box 120, Rabat, or APO New York 09284);
telephone [212] (7) 76-22-65; there are US Consulates General in
Casablanca
_#_Flag: red with a green pentacle (five-pointed, linear star) known
as Solomon''s seal in the center of the flag; green is the traditional
color of Islam
_#_Long-form name: Republic of Mozambique
_#_Type: republic
_#_Capital: Maputo
_#_Administrative divisions: 10 provinces (provincias,
singular--provincia); Cabo Delgado, Gaza, Inhambane, Manica, Maputo,
Nampula, Niassa, Sofala, Tete, Zambezia
_#_Independence: 25 June 1975 (from Portugal)
_#_Constitution: 30 November 1990
_#_Legal system: based on Portuguese civil law system and customary
law
_#_National holiday: Independence Day, 25 June (1975)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: unicameral Assembly of the Republic
(Assembleia da Republica)
_#_Judicial branch: People''s Courts at all levels
_#_Leaders:
Chief of State--President Joaquim Alberto CHISSANO (since 6
November 1986);
Head of Government--Prime Minister Mario da Graca MACHUNGO
(since 17 July 1986)
_#_Political parties and leaders:
Front for the Liberation of Mozambique (FRELIMO)--formerly a Marxist
organization with close ties to the USSR--was the only legal party before
30 November 1990 when the new Constitution went into effect establishing
a multiparty system; note--the government has announced that multiparty
elections will be held in 1991; parties such as
the Liberal Democratic Party of Mozambique (PALMO),
the Mozambique National Union (UNAMO),
and the Mozambique National Movement (MONAMO) have already emerged
_#_Suffrage: universal adult at age 18
_#_Elections: electoral law--to be ratified in 1991--will provide
for periodic, direct presidential and Assembly elections
_#_Communists: about 200,000 FRELIMO members; note--FRELIMO no
longer considers itself a Communist party
_#_Member of: ACP, AfDB, CCC, ECA, FAO, FLS, G-77,
IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, ITU,
LORCS, NAM, OAU, SADCC, UN, UNCTAD, UNESCO, UNIDO, UPU, WHO, WMO
_#_Diplomatic representation: Ambassador Hipolito PATRICIO; Chancery
at Suite 570, 1990 M Street NW, Washington DC 20036; telephone (202)
293-7146;
US--Ambassador Townsend B. FRIEDMAN, Jr.; Embassy at Avenida
Kenneth Kuanda, 193 Maputo (mailing address is P. O. Box 783, Maputo);
telephone [258] (1) 49-27-97, 49-01-67, 49-03-50
_#_Flag: three equal horizontal bands of green (top), black, and
yellow with a red isosceles triangle based on the hoist side; the black
band is edged in white; centered in the triangle is a yellow five-pointed
star bearing a crossed rifle and hoe in black superimposed on an open
white book
_#_Long-form name: Republic of Namibia
_#_Type: republic
_#_Capital: Windhoek
_#_Administrative divisions: the former administrative structure of
26 districts has been abolished and 14 temporary regions are still in
the process of being determined; note--the 26 districts were Bethanien,
Boesmanland, Caprivi Oos, Damaraland, Gobabis, Grootfontein, Hereroland
Oos, Hereroland Wes, Kaokoland, Karasburg, Karibib, Kavango,
Keetmanshoop, Luderitz, Maltahohe, Mariental, Namaland, Okahandja,
Omaruru, Otjiwarongo, Outjo, Owambo, Rehoboth, Swakopmund, Tsumeb,
Windhoek
_#_Independence: 21 March 1990 (from South African mandate)
_#_Constitution: ratified 9 February 1990
_#_Legal system: based on Roman-Dutch law and 1990 constitution
_#_National holiday: Independence Day, 21 March 1990
_#_Executive branch: president, Cabinet
_#_Legislative branch: bicameral; House of Review (upper house,
to be established with elections in 1992 by planned new regional
authorities); National Assembly (lower house elected by universal
suffrage)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--President Sam NUJOMA
(since 21 March 1990)
_#_Political parties and leaders: South-West Africa People''s
Organization (SWAPO), Sam NUJOMA;
Democratic Turnhalle Alliance (DTA), Dirk MUDGE;
United Democratic Front (UDF), Justus GAROEB;
Action Christian National (ACN), Kosie PRETORIUS;
National Patriotic Front (NPF), Moses KATJIUONGUA;
Federal Convention of Namibia (FCN), Hans DIERGAARDT;
Namibia National Front (NNF), Vekuii RUKORO
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 16 February 1990 (next to be
held March 1995); Sam NUJOMA was elected president by the Constituent
Assembly (now the National Assembly);
National Assembly--last held on 7-11 November 1989
(next to be held by November 1994);
results--percent of vote by party NA;
seats--(72 total) SWAPO 41, DTA 21, UDF 4, ACN 3, NNF 1, FCN 1, NPF 1
_#_Communists: no Communist party
_#_Other political or pressure groups: NA
_#_Member of: C, ECA (associate), FAO, FLS, IAEA, IBRD,
ILO, IMF, ITU, NAM, OAU, SACU, SADCC, UN, UNCTAD, UNESCO, UNHCR,
UNIDO, WCL, WFTU, WHO
_#_Diplomatic representation: Ambassador Tuliameni KALOMOH;
Chancery at 1413 K Street NW, 7th Floor, Washington, DC 20005
(mailing address is PO Box 34738, Washington DC 20043);
telephone (202) 289-3871;
US--Ambassador Ge','4dd28977d884e8e64395b12770d9b1a0d3e7dbb3e6d48d685947bea4b98dd6f6','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('720c5324b895764fdec8ffc32d5a7cb3299977a8a682027a045d3d31199f63ce',1991,'FR','France','government',103,'nta Hawkins HOLMES; Embassy at Ausplan Building,
14 Lossen St., Windhoek (mailing address is P. O. Box 9890, Windhoek
9000, Namibia); telephone [264] (61) 221-601, 222-675, 222-680
_#_Flag: a large blue triangle with a yellow sunburst fills the
upper left section, and an equal green triangle (solid) fills the lower
right section; the triangles are separated by a red stripe which is
contrasted by two narrow white edge borders
_#_Long-form name: Republic of Nauru
_#_Type: republic
_#_Capital: no capital city as such; government offices in Yaren
District
_#_Administrative divisions: 14 districts; Aiwo, Anabar, Anetan,
Anibare, Baiti, Boe, Buada, Denigomodu, Ewa, Ijuw, Meneng, Nibok, Uaboe,
Yaren
_#_Independence: 31 January 1968 (from UN trusteeship under Australia,
New Zealand, and UK); formerly Pleasant Island
_#_Constitution: 29 January 1968
_#_Legal system: own Acts of Parliament and British common law
_#_National holiday: Independence Day, 31 January (1968)
_#_Executive branch: president, Cabinet
_#_Legislative branch: unicameral Parliament
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--President Bernard DOWIYOGO
(since 12 December 1989)
_#_Political parties and leaders: none
_#_Suffrage: universal and compulsory at age 20
_#_Elections:
President--last held 9 December 1989 (next to be held December
1992);
results--Bernard DOWIYOGO elected by Parliament;
Parliament--last held on 9 December 1989 (next to be held
December 1992);
results--percent of vote NA;
seats--(18 total) independents 18
_#_Member of: C (special), ESCAP, ICAO, INTERPOL, ITU, SPC, SPF, UPU
_#_Diplomatic representation: Ambassador-designate Theodore
Conrad MOSES resident in Melbourne (Australia); there is a Nauruan
Consulate in Agana (Guam);
US--the US Ambassador to Australia is accredited to Nauru
_#_Flag: blue with a narrow, horizontal, yellow stripe across the
center and a large white 12-pointed star below the stripe on the hoist
side; the star indicates the country''s location in relation to the
Equator (the yellow stripe) and the 12 points symbolize the 12 original
tribes of Nauru
_#_Long-form name: none (territory of the US)
_#_Type: unincorporated territory of the US administered by the US
Coast Guard
_#_Long-form name: Kingdom of Nepal
_#_Type: constitutional monarchy
_#_Capital: Kathmandu
_#_Administrative divisions: 14 zones (anchal, singular and plural);
Bagmati, Bheri, Dhawalagiri, Gandaki, Janakpur,
Karnali, Kosi, Lumbini, Mahakali, Mechi,
Narayani, Rapti, Sagarmatha, Seti
_#_Independence: 1768, unified by Prithyi Narayan Shah
_#_Constitution: 9 November 1990
_#_Legal system: based on Hindu legal concepts and English common law;
has not accepted compulsory ICJ jurisdiction
_#_National holiday: Birthday of His Majesty the King, 28 December
(1945)
_#_Executive branch: monarch, prime minister, Council of Ministers
_#_Legislative branch: bicameral Parliament consists of
an upper house or National Council and a lower house or House of
Representatives
_#_Judicial branch: Supreme Court (Sarbochha Adalat)
_#_Leaders:
Chief of State--King BIRENDRA Bir Bikram Shah Dev (since 31 January
1972, crowned King 24 February 1985); Heir Apparent Crown Prince DIPENDRA
Bir Bikram Shah Dev, son of the King (born 21 June 1971);
Head of Government--Prime Minister Girija Prasad KOIRALA (since
29 May 1991)
_#_Political parties and leaders:
ruling party--Nepali Congress Party (NCP), Girija Prasad KOIRALA,
Ganesh Man SINGH, Krishna Prasad BHATTARAI;
center--the NDP has two factions: National Democratic
Party/Chand (NDP/Chand), Lokinra Bahadur CHAND, and
National Democratic Party/Thapa (NDP/Thapa), Surya Bahadur THAPA;
Terai Rights Sadbhavana (Goodwill) Party, G. N. Naryan SINGH;
Communist--Communist Party of Nepal/United Marxist and
Leninist (CPN/UML), Man Mohan ADIKHARY;
United People''s Front (UPF), N. K. PRASAI;
Rohit Party, N. M. BIJUKCHHE;
Democratic Party, leader NA
_#_Suffrage: universal at age 18
_#_Elections:
House of Representatives--last held on 12 May 1991 (next to be
held May 1996);
results--NCP 38%, CPN/UML 28%, NDP/Chand 6%, UPF 5%, NDP/Thapa
5%, Terai Rights Sadbhavana Party 4%, Rohit 2%, CPN (Democratic) 1%,
independent 4%, other 7%;
seats--(205 total) NCP 110, CPN/UML 69, UPF 9, Terai Rights
Sadbhavana Party 6, NDP/Chand 3, Rohit 2, CPN (Democratic) 2,
NDP/Thapa 1, independent 3;
note--the new Constitution of 9 November 1990 gives Nepal a multiparty
democracy system for the first time in 32 years
_#_Communists: Communist Party of Nepal (CPN)
_#_Other political or pressure groups: numerous small, left-leaning
student groups in the capital; several small, radical Nepalese
antimonarchist groups
_#_Member of: AsDB, CCC, CP, ESCAP, FAO, G-77, IBRD, ICAO, IDA,
IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, ITU, LORCS, NAM,
SAARC, UN, UNCTAD, UNESCO, UNIDO, UNIFIL, UPU, WHO, WMO, WTO
_#_Diplomatic representation: Ambassador Mohan Man SAINJU; Chancery at
2131 Leroy Place NW, Washington DC 20008; telephone (202) 667-4550; there
is a Nepalese Consulate General in New York;
US--Ambassador Julia Chang BLOCH; Embassy at Pani Pokhari,
Kathmandu; telephone [977] (1) 411179 or 412718, 411601, 411613, 413890
_#_Flag: red with a blue border around the unique shape of two
overlapping right triangles; the smaller, upper triangle bears a white
stylized moon and the larger, lower triangle bears a white 12-pointed sun
_#_Long-form name: Kingdom of the Netherlands
_#_Type: constitutional monarchy
_#_Capital: Amsterdam, but government resides at The Hague
_#_Administrative divisions: 12 provinces (provincien,
singular--provincie); Drenthe, Flevoland, Friesland, Gelderland,
Groningen, Limburg, Noord-Brabant, Noord-Holland, Overijssel, Utrecht,
Zeeland, Zuid-Holland
_#_Dependent areas: Aruba, Netherlands Antilles
_#_Independence: 1579 (from Spain)
_#_Constitution: 17 February 1983
_#_Legal system: civil law system incorporating French penal theory;
judicial review in the Supreme Court of legislation of lower order rather
than Acts of the States General; accepts compulsory ICJ jurisdiction,
with reservations
_#_National holiday: Queen''s Day, 30 April (1938)
_#_Executive branch: monarch, prime minister, vice prime minister,
Cabinet, Cabinet of Ministers
_#_Legislative branch: bicameral legislature (Staten Generaal)
consists of an upper chamber or First Chamber (Eerste Kamer) and a lower
chamber or Second Chamber (Tweede Kamer)
_#_Judicial branch: Supreme Court (De Hoge Raad)
_#_Leaders:
Chief of State--Queen BEATRIX Wilhelmina Armgard (since 30 April
1980); Heir Apparent WILLEM-ALEXANDER, Prince of Orange, son of Queen
Beatrix (born 27 April 1967);
Head of Government--Prime Minister Ruud (Rudolph) F. M. LUBBERS
(since 4 November 1982); Vice Prime Minister Wim KOK (since 2 November
1989)
_#_Political parties and leaders:
Christian Democratic Appeal (CDA), Willem van VELZEN;
Labor (PvdA), Wim KOK;
Liberal (VVD), Joris VOORHOEVE;
Democrats ''66 (D''66), Hans van MIERIO;
Communist (CPN), Henk HOEKSTRA;
a host of minor parties
_#_Suffrage: universal at age 18
_#_Elections:
First Chamber--last held on 9 June l987 (next to be held 9 June
1991); results--elected by the country''s 12 provincial councils;
seats--(75 total) percent of seats by party NA;
Second Chamber--last held on 6 September 1989 (next to be held by
September 1993);
results--CDA 35.3%, PvdA 31.9%, VVD 14.6%, D''66 7.9%, other 10.3%;
seats--(150 total) CDA 54, PvdA 49, VVD 22, D''66 12, other 13
_#_Communists: about 6,000
_#_Other political or pressure groups: large multinational firms;
Federation of Netherlands Trade Union Movement (comprising Socialist and
Catholic trade unions) and a Protestant trade union; Federation of
Catholic and Protestant Employers Associations; the nondenominational
Federation of Netherlands Enterprises; and IKV--Interchurch Peace Council
_#_Member of: AfDB, AG (observer), AsDB, Benelux, BIS, CCC, CE, CERN,
COCOM, CSCE, EBRD, EC, ECE, ECLAC, EIB, EMS, ESA, ESCAP, FAO, G-10, GATT,
IADB, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IEA, IFAD, IFC, ILO, IMF, IMO,
INMARSAT, INTELSAT, INTERPOL, IOC, IOM, ISO, ITU, LORCS, NATO, NEA,
OAS (observer), OECD, PCA, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UNTSO, UPU,
WCL, WEU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Johan Hendrick MEESMAN;
Chancery at 4200 Linnean Avenue NW, Washington DC 20008; telephone (202)
244-5300; there are Dutch Consulates General in Chicago, Houston, Los
Angeles, New York, and San Francisco;
US--Ambassador C. Howard WILKINS, Jr.; Embassy at Lange Voorhout
102, The Hague (mailing address APO New York 09159);
telephone [31] (70) 362-4911; there is a US Consulate General in
Amsterdam
_#_Flag: three equal horizontal bands of red (top), white, and blue;
similar to the flag of Luxembourg which uses a lighter blue and is longer
_#_Long-form name: none
_#_Type: part of the Dutch realm--full autonomy in internal affairs
granted in 1954
_#_Capital: Willemstad
_#_Administrative divisions: none (part of the Dutch realm)
_#_Independence: none (part of the Dutch realm)
_#_Constitution: 29 December 1954, Statute of the Realm of the
Netherlands, as amended
_#_Legal system: based on Dutch civil law system, with some English
common law influence
_#_National holiday: Queen''s Day, 30 April (1938)
_#_Executive branch: Dutch monarch, governor, prime minister, vice
prime minister, Council of Ministers (cabinet)
_#_Legislative branch: legislature (Staten)
_#_Judicial branch: Joint High Court of Justice
_#_Leaders:
Chief of State--Queen BEATRIX Wilhelmina Armgard (since 30 April
1980), represented by Governor General Jaime SALEH (since October 1989);
Head of Government--Prime Minister Maria LIBERIA-PETERS (since 17
May 1988, previously served from September 1984 to November 1985)
_#_Political parties and leaders: political parties are indigenous
to each island:
Curacao--National People''s Party (PNP), Maria
LIBERIA-PETERS;
New Antilles Movement (MAN), Domenico Felip MARTINA;
Workers'' Liberation Front (FOL), Wilson (Papa) GODETT;
Socialist Independent (SI), George HUECK and Nelson MONTE;
Democratic Party of Curacao (DP), Augustin DIAZ;
Nos Patria, Chin BEHILIA;
Bonaire--Patriotic Union of Bonaire (UPB), C. V. Winklaar;
Democratic Party of Bonaire (PDB), John Evert (Jopie) ABRAHAM;
New Force, Rudy ELLIS;
Sint Maarten--Democratic Party of Sint Maarten (DP-St.M),
Claude WATHEY;
Patriotic Movement of Sint Maarten (SPM), Romeo PAPLOPHLET;
Sint Eustatius--Democratic Party of Sint Eustatius (DP-St.E),
Albert
K. Van PUTTEN; Windward Islands People''s Movement (WIPM), Eric HENRIQUEZ;
Saba--Windward Islands People''s Movement (WIPM Saba), Will
JOHNSTON; Saba Democratic Labor Movement, Vernon HASSELL; Saba Unity
Party, Carmen SIMMONDS
_#_Suffrage: universal at age 18
_#_Elections:
Staten--last held on 16 March 1990 (next to be held March 1994);
results--percent of vote by party NA;
seats--(22 total) PNP 7, FOL-SI-Curacao 3, UPB 3, MAN 2,
Democratic Party of Sint Maarten 2, Democratic Party of Curacao 1,
SPM-Sint Maarten 1, WIPM 1, Democratic Party of Sint Eustatius 1,
Nos Patria-Curacao 1; note--the government of Prime
Minister Maria LIBERIA-PETERS is a coalition of several parties
_#_Communists: small leftist groups
_#_Member of: CARICOM (observer), ECLAC (associate), ICFTU, INTERPOL,
IOC, UNESCO (associate), UPU, WCL, WMO, WTO (associate)
_#_Diplomatic representation: as an autonomous part of the
Netherlands, Netherlands Antillean interests in the US are represented by
the Netherlands;
US--Consul General Sharon P. WILKINSON; Consulate General at
Sint Anna Boulevard 19, Willemstad, Curacao (mailing address P. O.
Box 158, Willemstad, Curacao); telephone [599] (9) 613066
_#_Flag: white with a horizontal blue stripe in the center
superimposed on a vertical red band also centered; five white
five-pointed stars are arranged in an oval pattern in the center of the
blue band; the five stars represent the five main islands of Bonaire,
Curacao, Saba, Sint Eustatius, and Sint Maarten
_#_Long-form name: Territory of New Caledonia and Dependencies
_#_Type: overseas territory of France since 1956
_#_Capital: Noumea
_#_Administrative divisions: none (overseas territory of France);
there are no first-order administrative divisions as defined by the
US Government, but there are 3 provinces named Iles Loyaute, Nord,
and Sud
_#_Independence: none (overseas territory of France); note--a
referendum on independence will be held in 1998, with a review of the
issue in 1992
_#_Constitution: 28 September 1958 (French Constitution)
_#_Legal system: the 1988 Matignon Accords grant substantial autonomy
to the islands; formerly under French law
_#_National holiday: Taking of the Bastille, 14 July (1789)
_#_Executive branch: high commissioner, Consultative Committee
(cabinet)
_#_Legislative branch: unicameral Territorial Assembly
_#_Judicial branch: Court of Appeal
_#_Leaders:
Chief of State--President Francois MITTERRAND (since 21 May
1981);
Head of Government High Commissioner and President of the Council
of Government Bernard GRASSET (since 15 July 1988)
_#_Political parties:
white-dominated Rassemblement pour la Caledonie dans la Republique
(RPCR), conservative, Jacques LAFLEUR--affiliated to France''s
Rassemblement pour la Republique (RPR);
Melanesian proindependence Kanak Socialist National Liberation Front
(FLNKS), Paul NEAOUTYINE;
Melanesian moderate Kanak Socialist Liberation (LKS), Nidoish
NAISSELINE;
National Front (FN), extreme right, Guy GEORGE;
Caledonie Demain (CD), right-wing, Bernard MARANT;
Union Oceanienne (UO), conservative, Michel HEMA;
Front Uni de Liberation Kanak (FULK), proindependence, Yann
CELENE
_#_Suffrage: universal adult at age 18
_#_Elections:
Territorial Assembly--last held 11 June 1989 (next to be held NA
1993);
results--percent of vote by party--RPCR 44.5%, FLNKS 28.5%, FN 7%, CD
5%, UO 4%, other 11%;
seats--(54 total) RPCR 27, FLNKS 19, FN 3, other 5; note--election
boycotted by FULK;
French Senate--last held 24 September 1989 (next to be
held September 1992);
results--percent of vote by party NA;
seats--(1 total) RPCR 1;
French National Assembly--last held 5 and 12 June 1988
(next to be held June 1993);
results--percent of vote by party--RPR 83.5%, FN 13.5%, other 3%;
seats--(2 total) RPCR 2
_#_Communists: number unknown; Palita extreme left party; some
politically active Communists deported during 1950s; small number of
North Vietnamese
_#_Member of: FZ, SPC, WFTU, WMO
_#_Diplomatic representation: as an overseas territory of France,
New Caledonian interests are represented in the US by France
_#_Flag: the flag of France is used
_#_Long-form name: none; abbreviated NZ
_#_Type: parliamentary democracy
_#_Capital: Wellington
_#_Administrative divisions: 93 counties, 9 districts*, and
3 town districts**; Akaroa, Amuri, Ashburton, Bay of Islands, Bruce,
Buller, Chatham Islands, Cheviot, Clifton, Clutha, Cook, Dannevirke,
Egmont, Eketahuna, Ellesmere, Eltham, Eyre, Featherston, Franklin, Golden
Bay, Great Barrier Island, Grey, Hauraki Plains, Hawera*, Hawke''s Bay,
Heathcote, Hikurangi**, Hobson, Hokianga, Horowhenua, Hurunui, Hutt,
Inangahua, Inglewood, Kaikoura, Kairanga, Kiwitea, Lake, Mackenzie,
Malvern, Manaia**, Manawatu, Mangonui, Maniototo, Marlborough, Masterton,
Matamata, Mount Herbert, Ohinemuri, Opotiki, Oroua, Otamatea,
Otorohanga*, Oxford, Pahiatua, Paparua, Patea, Piako, Pohangina, Raglan,
Rangiora*, Rangitikei, Rodney, Rotorua*, Runanga, Saint Kilda,
Silverpeaks, Southland, Stewart Island, Stratford, Strathallan, Taranaki,
Taumarunui, Taupo, Tauranga, Thames-Coromandel*, Tuapeka, Vincent,
Waiapu, Waiheke, Waihemo, Waikato, Waikohu, Waimairi, Waimarino, Waimate,
Waimate West, Waimea, Waipa, Waipawa*, Waipukurau*, Wairarapa South,
Wairewa, Wairoa, Waitaki, Waitomo*, Waitotara, Wallace, Wanganui,
Waverley**, Westland, Whakatane*, Whangarei, Whangaroa, Woodville
_#_Dependent areas: Cook Islands, Niue, Tokelau
_#_Independence: 26 September 1907 (from UK)
_#_Constitution: no formal, written constitution; consists of various
documents, including certain acts of the UK and New Zealand Parliaments;
Constitution Act 1986 was to have come into force 1 January 1987, but has
not been enacted
_#_Legal system: based on English law, with special land legislation
and land courts for Maoris; accepts compulsory ICJ jurisdiction, with
reservations
_#_National holiday: Waitangi Day (Treaty of Waitangi established
British sovereignty), 6 February (1840)
_#_Executive branch: British monarch, governor general, prime
minister, deputy prime minister, Cabinet
_#_Legislative branch: unicameral House of Representatives (commonly
called Parliament)
_#_Judicial branch: High Court, Court of Appeal
_#_Leaders:
Chief of State--Queen ELIZABETH II ( since 6 February 1952),
represented by Governor General Dame Catherine TIZARD (since 12
December 1990);
Head of Government--Prime Minister James BOLGER (since
29 October 1990); Deputy Prime Minister Donald McKINNON (since 2
November 1990)
_#_Political parties and leaders:
National Party (NP; government), James BOLGER;
New Zealand Labor Party (NZLP; opposition), Michael MOORE;
New Labor Party (NLP), Jim ANDERTON;
Democratic Party, Neil MORRISON;
Green Party, no official leader;
Socialist Unity Party (SUP; pro-Soviet), Kenneth DOUGLAS
_#_Suffrage: universal at age 18
_#_Elections:
House of Representatives--last held on 27 October 1990 (next to be
held October 1993);
results--NP 49%, LP 35%, Green Party 7%, New Labor 5%;
seats--(97 total) NP 67, LP 29, NLP 1
_#_Communists: SUP about 140, other groups, about 200
_#_Member of: ANZUS (US suspended security obligations to NZ on
11 August 1986), APEC, AsDB, C, CCC, CP, EBRD, ESCAP, FAO, GATT, IAEA,
IBRD, ICAO, ICFTU, IDA, IEA, IFAD, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, IOM (observer), ISO, ITU, LORCS, OECD, PCA,
SPC, SPF, UN, UNCTAD, UNESCO, UNIDO, UNIIMOG, UNTSO, UPU, WHO, WIPO,
WMO
_#_Diplomatic representation: Ambassador-designate Denis Bazely
Gordon McLEAN; Chancery at 37 Observatory Circle NW, Washington DC 20008;
telephone (202) 328-4800; there are New Zealand Consulates General in Los
Angeles and New York;
US--Ambassador Della M. NEWMAN; Embassy at 29 Fitzherbert Terrace,
Thorndon, Wellington (mailing address is P. O. Box 1190, Wellington, or
FPO San Francisco 96690-0001); telephone [64] (4) 722-068; there is a US
Consulate General in Auckland
_#_Flag: blue with the flag of the UK in the upper hoist-side quadrant
with four red five-pointed stars edged in white centered in the outer
half of the flag; the stars represent the Southern Cross constellation
_#_Long-form name: Republic of Nicaragua
_#_Type: republic
_#_Capital: Managua
_#_Administrative divisions: 9 administrative regions encompassing 16
departments (departamentos, singular--departamento); Boaco, Carazo,
Chinandega, Chontales, Esteli, Granada, Jinotega, Leon, Madriz,
Managua, Masaya, Matagalpa, Nueva Segovia, Rio San Juan, Rivas,
Zelaya; note--Zelaya may have been replaced by 2 autonomous regions
(regiones autonomistas, singular--region autonomista) named
North Atlantic Coast and South Atlantic Coast
_#_Independence: 15 September 1821 (from Spain)
_#_Constitution: January 1987
_#_Legal system: civil law system; Supreme Court may review
administrative acts
_#_National holiday: Independence Day, 15 September (1821)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: National Assembly (Asamblea Nacional)
_#_Judicial branch: Supreme Court (Corte Suprema) and municipal courts
_#_Leaders:
Chief of State and Head of Government--President Violeta
Barrios de CHAMORRO (since 25 April 1990);
Vice President Virgilio GODOY (since 25 April 1990)
_#_Political parties and leaders:
ruling coalition--National Opposition Union (UNO) is a
14-party alliance--National Conservative Party (PNC), Silviano MATAMOROS;
Conservative Popular Alliance Party (PAPC), Myriam ARGUELLO;
National Conservative Action Party (PANC), Hernaldo ZUNIGA;
National Democratic Confidence Party (PDCN), Augustin JARQUIN;
Independent Liberal Party (PLI), Wilfredo NAVARRO;
Neo-Liberal Party (PALI), Andres ZUNIGA;
Liberal Constitutionalist Party (PLC), Jose Ernesto SOMARRIBA;
National Action Party (PAN), Eduardo RIVAS;
Nicaraguan Socialist Party (PSN), Gustavo TABLADA;
Communist Party of Nicaragua (PCdeN), Eli ALTIMIRANO;
Popular Social Christian Party (PPSC), Luis HUMBERTO;
Nicaraguan Democratic Movement (MDN), Roberto URROZ;
Social Democratic Party (PSD), Guillermo POTOY;
Central American Integrationist Party (PIAC), Alejandro PEREZ;
opposition parties--Sandinista National Liberation Front (FSLN),
Daniel ORTEGA;
Central American Unionist Party (PUCA), Blanca ROJAS;
Democratic Conservative Party of Nicaragua (PCDN), Jose BRENES;
Liberal Party of National Unity (PLUIN), Eduardo CORONADO;
Movement of Revolutionary Unity (MUR), Francisco SAMPER;
Social Christian Party (PSC), Erick RAMIREZ;
Revolutionary Workers'' Party (PRT), Bonifacio MIRANDA;
Social Conservative Party (PSOC), Fernando AGUERRO;
Popular Action Movement--Marxist-Leninist (MAP-ML), Isidro TELLEZ;
Popular Social Christian Party (PPSC), Mauricio DIAZ
_#_Suffrage: universal at age 16
_#_Elections:
President--last held on 25 February 1990 (next to be held February
1996);
results--Violeta Barrios de CHAMORRO (UNO) 54.7%, Daniel ORTEGA Saavedra
(FSLN) 40.8%, other 4.5%;
National Assembly--last held on 25 February 1990
(next to be held February 1996);
results--UNO 53.9%, FSLN 40.8%, PSC 1.6%, MUR 1.0%;
seats--(92 total) UNO 51, FSLN 39, PSC 1, MUR 1
_#_Communists: 15,000-20,000
_#_Other political or pressure groups: Permanent Congress of Workers
(CPT), Confederation of Labor Unification (CUS), Autonomous Nicaraguan
Workers'' Central (CTN-A), Independent General Confederation of Workers
(CTG-I), Communist Labor Action and Unity Central (CAUS), Nicaraguan
Workers'' Central (CST); Superior Council of Private Enterprise (COSEP) is
an umbrella group of 11 different business groups, including the Chamber
of Commerce, the Chamber of Industry, and the Nicaraguan Development
Institute (INDE)
_#_Member of: BCIE, CACM, ECLAC, FAO, G-77, GATT,
IADB, IAEA, IBRD, ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, IOM, ITU, LAES, LORCS, NAM, OAS, OPANAL, PCA, UN,
UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Ernesto PALAZIO;
Chancery at 1627 New Hampshire Avenue NW, Washington DC 20009; telephone
(202) 387-4371 or 4372;
US--Ambassador Harry W. SHLAUDEMAN; Embassy at Kilometer 4.5
Carretera Sur., Managua (mailing address is APO Miami 34021); telephone
[505] (2) 666010 or 666013, 666015 through 18, 666026, 666027, 666032
through 34
_#_Flag: three equal horizontal bands of blue (top), white, and blue
with the national coat of arms centered in the white band; the coat of
arms features a triangle encircled by the words REPUBLICA DE
NICARAGUA on the top and AMERICA CENTRAL on the bottom; similar
to the flag of El Salvador which features a round emblem encircled by the
words REPUBLICA DE EL SALVADOR EN LA AMERICA CENTRAL centered in
the white band; also similar to the flag of Honduras, which has five blue
stars arranged in an X pattern centered in the white band
_#_Long-form name: Republic of Niger
_#_Type: republic; presidential system in which military officers
hold key offices
_#_Capital: Niamey
_#_Administrative divisions: 7 departments (departements,
singular--departement); Agadez, Diffa, Dosso, Maradi, Niamey, Tahoua,
Zinder
_#_Independence: 3 August 1960 (from France)
_#_Constitution: adopted NA December 1989 after 15 years of
military rule
_#_Legal system: based on French civil law system and customary law;
has not accepted compulsory ICJ jurisdiction
_#_National holidays: Republic Day, 18 December (1958)
_#_Executive branch: president, prime minister, Council of Ministers
(cabinet)
_#_Legislative branch: National Assembly (Assemblee Nationale)
_#_Judicial branch: State Court (Cour d''Etat), Court of Appeal
(','96c0504ba80d35d641f1a331d0c067a80d8239fcf14764397f65c865836787d3','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d56fe6a2b7597ef5a5fe7ac4b15e1bcc8b47077f5d65bad7d2be913cac44e38b',1991,'FR','France','government',104,'Cour d''Apel)
_#_Leaders:
Chief of State--President Brig. Gen. Ali SAIBOU (since 14
November 1987);
Head of Government--Prime Minister Aliou MAHAMIDOU (since 2 March
1990)
_#_Political parties and leaders: National Movement for the
Development Society (MNSD), leader NA; other political parties now
forming
_#_Suffrage: universal adult at age 18
_#_Elections:
President--last held December 1989 (next to be held NA 1996);
results--President Ali SAIBOU was reelected without opposition;
National Assembly--last held 10 December 1989 (next to be
held NA); results--MNSD was the only party;
seats--(150 total) MNSD 150 (indirectly elected);
note--Niger is to hold a national conference to decide upon a
transitional government and an agenda for multiparty elections
_#_Communists: no Communist party; some sympathizers in outlawed
Sawaba party
_#_Member of: ACCT, ACP, AfDB, CCC, CEAO, ECA, ECOWAS, Entente, FAO,
FZ, G-77, GATT, IAEA, IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF,
INTELSAT, INTERPOL, IOC, ITU, LORCS, NAM, OAU, OIC, UN,
UNCTAD, UNESCO, UNIDO, UPU, WADB, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Moumouni Adamou DJERMAKOYE;
Chancery at 2204 R Street NW, Washington DC 20008; telephone (202)
483-4224 through 4227;
US--Ambassador Carl C. CUNDIFF; Embassy at Avenue des
Ambassades, Niamey (mailing address is B. P. 11201, Niamey); telephone
[227] 72-26-61 through 64
_#_Flag: three equal horizontal bands of orange (top), white, and
green with a small orange disk (representing the sun) centered in the
white band; similar to the flag of India which has a blue, spoked wheel
centered in the white band
_#_Long-form name: Federal Republic of Nigeria
_#_Type: military government since 31 December 1983
_#_Capital: Lagos; note--some government departments have relocated
to the designated new capital in Abuja
_#_Administrative divisions: 21 states and 1 territory*;
Abuja Capital Territory*, Akwa Ibom, Anambra, Bauchi, Bendel, Benue,
Borno, Cross River, Gongola, Imo, Kaduna, Kano, Katsina, Kwara, Lagos,
Niger, Ogun, Ondo, Oyo, Plateau, Rivers, Sokoto
_#_Independence: 1 October 1960 (from UK)
_#_Constitution: 1 October 1979, amended 9 February 1984, revised 1989
_#_Legal system: based on English common law, Islamic, and tribal law
_#_National holiday: Independence Day, 1 October (1960)
_#_Executive branch: president of the Armed Forces Ruling Council,
Armed Forces Ruling Council, National Council of State, Council of
Ministers (cabinet)
_#_Legislative branch: National Assembly was dissolved after the
military coup of 31 December 1983
_#_Judicial branch: Supreme Court, Federal Court of Appeal
_#_Leaders:
Chief of State and Head of Government--President and Commander in
Chief of Armed Forces Gen. Ibrahim BABANGIDA (since 27 August 1985)
_#_Political parties and leaders: two political parties established by
the government in 1989--Social Democratic Party (SDP) and National
Republican Convention (NRC)
_#_Suffrage: universal at age 21
_#_Elections:
President--scheduled for 1 October 1992;
National Assembly--scheduled for early 1992
_#_Communists: the pro-Communist underground consists of a small
fraction of the Nigerian left; leftist leaders are prominent in the
country''s central labor organization but have little influence on the
_#_Member of: ACP, AfDB, C, CCC, ECA, ECOWAS, FAO, G-19, G-24, G-77,
GATT, IAEA, IBRD, ICAO, ICC, IDA, IFAD, IFC, ILO, IMO, IMF, INMARSAT,
INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS, NAM, OAU, OIC, OPEC,
PCA, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UNIIMOG, UPU, WCL, WHO, WMO, WTO
_#_Diplomatic representation: Ambassador Hamzat AHMADU; Chancery at
2201 M Street NW, Washington DC 20037; telephone (202) 822-1500;
there are Nigerian Consulates General in Atlanta, New York and San
Francisco;
US--Ambassador Lannon WALKER; Embassy at 2 Eleke Crescent,
Victoria Island, Lagos (mailing address is P. O. Box 554, Lagos);
telephone [234] (1) 610097; there is a US Consulate General in Kaduna
_#_Flag: three equal vertical bands of green (hoist side), white, and
green
_#_Long-form name: none
_#_Type: self-governing territory in free association with New
Zealand; Niue fully responsible for internal affairs; New Zealand
retains responsibility for external affairs
_#_Capital: Alofi
_#_Administrative divisions: none
_#_Independence: became a self-governing territory in free
association with New Zealand on 19 October 1974
_#_Constitution: 19 October 1974 (Niue Constitution Act)
_#_Legal system: English common law
_#_National holiday: Waitangi Day (Treaty of Waitangi established
British sovereignty), 6 February (1840)
_#_Executive branch: British monarch, premier, Cabinet
_#_Legislative branch: Legislative Assembly
_#_Judicial branch: Appeal Court of New Zealand, High Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by New Zealand Representative John SPRINGFORD (since 1974);
Head of Government--Premier Sir Robert R. REX (since NA October
1974)
_#_Suffrage: universal adult at age 18
_#_Political parties and leaders:
Niue Island Party (NIP), Young VIVIAN
_#_Elections:
Legislative Assembly--last held on 8 April 1990 (next to be
held March 1993);
results--percent of vote NA;
seats--(20 total, 6 elected) independents 5, NIP 1
_#_Member of: ESCAP (associate), SPC, SPF
_#_Diplomatic representation: none (self-governing territory in free
association with New Zealand)
_#_Flag: yellow with the flag of the UK in the upper hoist-side
quadrant; the flag of the UK bears five yellow five-pointed stars--a
large one on a blue disk in the center and a smaller one on each arm of
the bold red cross
_#_Long-form name: Territory of Norfolk Island
_#_Type: territory of Australia
_#_Capital: Kingston (administrative center), Burnt Pine (commercial
center)
_#_Administrative divisions: none (territory of Australia)
_#_Independence: none (territory of Australia)
_#_Constitution: Norfolk Island Act of 1957
_#_Legal system: wide legislative and executive responsibility under
the Norfolk Island Act of 1979; Supreme Court
_#_National holiday: Pitcairners Arrival Day Anniversary, 8 June
(1856)
_#_Executive branch: British monarch, governor general of Australia,
administrator, Executive Council (cabinet)
_#_Legislative branch: unicameral Legislative Assembly
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Administrator H. B. MACDONALD (since NA 1989), who is
appointed by the Governor General of Australia;
Head of Government--Assembly President and Chief Minister John
Terence BROWN (since NA)
_#_Political parties and leaders: NA
_#_Suffrage: universal at age 18
_#_Elections:
Legislative Assembly--last held 1989 (held every three years);
results--percent of vote by party NA;
seats--(9 total) percent of seats by party NA
_#_Member of: none
_#_Diplomatic representation: none (territory of Australia)
_#_Flag: three vertical bands of green (hoist side), white, and green
with a large green Norfolk Island pine tree centered in the slightly
wider white band
_#_Long-form name: Commonwealth of the Northern Mariana Islands
_#_Type: commonwealth associated with the US and administered by the
Office of Territorial and International Affairs, US Department of the
Interior
_#_Capital: Saipan
_#_Administrative divisions: none
_#_Independence: none (commonwealth associated with the US)
_#_Constitution: Covenant Agreement effective 3 November 1986
_#_Legal system: NA
_#_National holiday: Commonwealth Day, 8 January (1978)
_#_Executive branch: governor, lieutenant governor
_#_Legislative branch: bicameral Legislature consists of an upper
house or Senate and a lower house or House of Representatives
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President George BUSH (since 20 January 1989);
Vice President Dan QUAYLE (since 20 January 1989);
Head of Government--Governor Lorenzo I. DeLeon GUERRERO
(since NA 1990);
Lieutenant Governor Benjamin T. MANGLONA (since NA 1990)
_#_Political parties and leaders: Republican Party, Alonzo IGISOMAR;
Democratic Party, Felicidad OGUMORO
_#_Suffrage: universal at age 18; indigenous inhabitants are US
citizens but do not vote in US presidential elections
_#_Elections:
Governor--last held on NA November 1989 (next to be held
November 1993);
results--Lorenzo I. DeLeon GUERRERO, Republican Party, was elected
governor;
Senate--last held on NA November 1989 (next to be held November
1991);
results--percent of vote by party NA;
seats--(9 total) number of seats by party NA;
House of Representatives--last held on NA November 1989 (next to
be held November 1991);
results--percent of vote by party NA;
seats--(15 total) number of seats by party NA;
US House of Representatives--last held NA November 1989 (next to
be held NA);
results--percent of vote by party NA;
seats--(1 total) party of nonvoting delegate NA
_#_Member of: ESCAP (associate), SPC
_#_Diplomatic representation: none
_#_Flag: blue with a white five-pointed star superimposed on the gray
silhouette of a latte stone (a traditional foundation stone used in
building) in the center
_#_Long-form name: Kingdom of Norway
_#_Type: constitutional monarchy
_#_Capital: Oslo
_#_Administrative divisions: 19 provinces (fylker, singular--fylke);
Akershus, Aust-Agder, Buskerud, Finnmark, Hedmark, Hordaland, More
og Romsdal, Nordland, Nord-Trondelag, Oppland, Oslo, Ostfold,
Rogaland, Sogn og Fjordane, Sor-Trondelag, Telemark, Troms,
Vest-Agder, Vestfold
_#_Independence: 26 October 1905 (from Sweden)
_#_Constitution: 17 May 1814, modified in 1884
_#_Dependent areas: Bouvet Island, Jan Mayen, Svalbard
_#_Legal system: mixture of customary law, civil law system, and
common law traditions; Supreme Court renders advisory opinions to
legislature when asked; accepts compulsory ICJ jurisdiction, with
reservations
_#_National holiday: Constitution Day, 17 May (1814)
_#_Executive branch: monarch, prime minister, State Council (cabinet)
_#_Legislative branch: unicameral Parliament (Stortinget)
with an Upper Chamber (Lagting) and a Lower Chamber (Odelsting)
_#_Judicial branch: Supreme Court (Hoiesterett)
_#_Leaders:
Chief of State--King HARALD V (since 17 January 1991); Heir
Apparent Crown Prince HAAKON MAGNUS (born 20 July 1973);
Head of Government--Prime Minister Gro Harlem BRUNDTLAND
(since 3 November 1990)
_#_Political parties and leaders:
Labor, Gro Harlem BRUNDTLAND;
Conservative, Kaci Kullmann FIVE;
Center Party, Anne Enger LAHNSTEIN;
Christian People''s, Kjell Magne BONDEVIK;
Socialist Left, Eric SOLHEIM;
Norwegian Communist, Kare Andre NILSEN;
Progress, Carl I. HAGEN; Liberal, Arne FJORTOFT;
Finnmark List, leader NA
_#_Suffrage: universal at age 18
_#_Elections:
Storting--last held on 11 September 1989 (next to be held
6 September 1993);
results--Labor 34.3%, Conservative 22.2%, Progress 13.0%, Socialist Left
10.1%, Christian People''s 8.5%, Center Party 6.6%, Finnmark List 0.3%,
other 5%;
seats--(165 total) Labor 63, Conservative 37, Progress 22, Socialist
Left 17, Christian People''s 14, Center Party 11, Finnmark List 1
_#_Communists: 15,500 est.; 5,500 Norwegian Communist Party (NKP);
10,000 Workers Communist Party Marxist-Leninist (AKP-ML, pro-Chinese)
_#_Member of: AfDB, AsDB, BIS, CCC, CE, CERN, COCOM, CSCE, EBRD,
ECE, EFTA, ESA, FAO, GATT, IADB, IAEA, IBRD, ICAO, ICC, ICFTU, IDA,
IEA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL,
IOC, IOM, ISO, ITU, LORCS, NATO, NC, NEA, NIB, OECD, PCA, UN, UNAVEM,
UNCTAD, UNESCO, UNHCR, UNIDO, UNIFIL, UNIIMOG, UNMOGIP, UNTSO, UPU,
WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Kjeld VIBE; Chancery at
2720 34th Street NW, Washington DC 20008; telephone (202) 333-6000;
there are Norwegian Consulates General in Houston, Los Angeles,
Minneapolis, New York, and San Francisco, and Consulates in Miami and New
Orleans;
US--Ambassador Loret Miller RUPPE; Embassy at Drammensveien 18,
0244 Oslo 2 (mailing address is APO New York 09085); telephone [47]
(2) 44-85-50
_#_Flag: red with a blue cross outlined in white that extends to the
edges of the flag; the vertical part of the cross is shifted to the hoist
side in the style of the Dannebrog (Danish flag)
_#_Long-form name: Sultanate of Oman
_#_Type: absolute monarchy; independent, with residual UK influence
_#_Capital: Muscat
_#_Administrative divisions: there are no first-order administrative
divisions as defined by the US Government, but there are 7 planning
regions (manatiq takhtitiyah, singular--mintaqah
takhtitiyah) that include 1 governorate* (muhafazah)
and 50 districts (wilayat, singular--wilayah);
al-Batinah--Awabi, Barka, Khabura, Liwa, Musanaa, Nakhl, Rustaq,
Saham, Shinas, Sohar, Suwaiq, Wadi al-Maawil;
al-Dakhiliah--Adam, al-Hamra, Bahla, Bidbid, Haima, Izki, Manah,
Nizwa, Sumail;
al-Dhahirah--al-Buraimi, Dhank, Ibri, Mhadha, Yanqul;
al-Janubiah--Dhalqut, Mirbat, Rokhyut, Sadah, Salalah, Shalim,
Taqa, Thamrait;
al-Sharqiya--al Kamil and al-Wafi, al-Mudhaiby, al-Qabil,
Bidiya, Dimaa and Tayin, Ibra, Jaalan Bani Bu Ali,
Jaalan Bani Bu Hassan, Masirah, Sur, Wadi Bani Khalid;
Musandam--Daba al-Biya, Bukha, Khasab, Madha;
Muscat--Muscat*, Quriyat
_#_Independence: 1650, expulsion of the Portuguese
_#_Constitution: none
_#_Legal system: based on English common law and Islamic law; ultimate
appeal to the sultan; has not accepted compulsory ICJ jurisdiction
_#_Executive branch: sultan, Cabinet
_#_Legislative branch: State Consultative Assembly (advisory
function only)
_#_Judicial branch: none; traditional Islamic judges and a nascent
civil court system
_#_National holiday: National Day, 18 November
_#_Leaders:
Chief of State and Head of Government--Sultan and Prime Minister
QABOOS bin Said Al Said (since 23 July 1970)
_#_Political parties: none
_#_Suffrage: none
_#_Elections: none
_#_Other political or pressure groups: outlawed Popular Front for the
Liberation of Oman (PFLO), based in Yemen
_#_Member of: ABEDA, AFESD, AL, AMF, ESCWA, FAO, G-77, GCC, IBRD,
ICAO, IDA, IDB, IFAD, IFC, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC,
ISO (correspondent), ITU, NAM, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU,
WHO, WMO
_#_Diplomatic representation: Ambassador Awadh Bader AL-SHANFARI;
Chancery at 2342 Massachusetts Avenue NW, Washington DC 20008; telephone
(202) 387-1980 through 1982;
US--Ambassador Richard W. BOEHM; Embassy at address NA, Muscat
(mailing address is P. O. Box 50200 Madinat Qaboos, Muscat); telephone
698-989
_#_Flag: three horizontal bands of white (top, double width), red,
and green (double width) with a broad, vertical, red band on the hoist
side; the national emblem (a khanjar dagger in its sheath
superimposed on two crossed swords in scabbards) in white is centered at
the top of the vertical band
_#_Long-form name: Trust Territory of the Pacific Islands
(no short-form name); may change to Republic of Palau after independence;
note--Belau, the native form of Palau, is sometimes used
_#_Type: UN trusteeship administered by the US; constitutional
government signed a Compact of Free Association with the US on
10 January 1986, after approval in a series of UN-observed plebiscites;
until the UN trusteeship is terminated with entry into force of the
Compact, Palau remains under US administration as the Palau District of
the Trust Territory of the Pacific Islands
_#_Capital: Koror; a new capital is being built about 20 km northeast
in eastern Babelthuap
_#_Administrative divisions: none
_#_Independence: still part of the US-administered UN trusteeship
(the last polity remaining under the trusteeship; the Republic of the
Marshall Islands, Federated States of Micronesia, and Commonwealth of the
Northern Marianas have left); administered by the Office of Territorial
and International Affairs, US Department of Interior
_#_Constitution: 11 January 1981
_#_Legal system: based on Trust Territory laws, acts of the
legislature, municipal, common, and customary laws
_#_National holiday: Constitution Day, 9 July (1979)
_#_Executive branch: US president, US vice president, national
president, national vice president
_#_Legislative branch: bicameral Parliament (Olbiil Era Kelulau or
OEK) consists of an upper house or Senate and a lower house or House of
Delegates
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President George BUSH (since 20 January
1989); represented by the Assistant Secretary for Territorial Affairs,
US Department of the Interior, Stella GUERRA (since NA July 1989);
Head of Government--President Ngiratkel ETPISON (since 2 November
1988)
_#_Political parties: no formal parties
_#_Suffrage: universal at age 18
_#_Elections:
President--last held on 2 November 1988 (next to be held November
1992); Ngiratkel ETPISON 26.3%, Roman TMETUCHL 25.9%,
Thomas REMENGESAU 19.5%, other 28.3%;
Senate--last held 2 November 1988 (next to be held November 1992);
results--percent of vote NA;
seats--(18 total);
House of Delegates--last held 2 November 1988 (next to be held
November 1992);
results--percent of vote NA;
seats--(16 total)
_#_Member of: ESCAP (associate), SPC, SPF (observer)
_#_Diplomatic representation: none;
US--US Liaison Officer Lloyd MOSS; US Liaison Office at Top
Side, Neeriyas, Koror (mailing address: P. O. Box 6028, Koror, Republic
of Palau 96940); telephone 160-680-920 or 990
_#_Flag: light blue with a large yellow disk (representing the moon)
shifted slightly to the hoist side
_#_Long-form name: Islamic Republic of Pakistan
_#_Type: parliamentary with strong executive, federal republic
_#_Capital: Islamabad
_#_Administrative divisions: 4 provinces, 1 territory*, and 1
capital territory**; Balochistan, Federally Administered Tribal
Areas*, Islamabad Capital Territory**, North-West Frontier,
Punjab, Sindh; note--the Pakistani-administered portion of the disputed
Jammu and Kashmir region includes Azad Kashmir and the Northern Areas
_#_Independence: 15 August 1947 (from UK; formerly West Pakistan)
_#_Constitution: 10 April 1973, suspended 5 July 1977,
restored with amendments, 30 December 1985
_#_Legal system: based on English common law with provisions to
accommodate Pakistan''s stature as an Islamic state; accepts compulsory
ICJ jurisdiction, with reservations
_#_National holiday: Pakistan Day (proclamation of the republic),
23 March (1956)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: bicameral Parliament (Mijlis-e-Shoora)
consists of an upper house or Senate and a lower house or National
Assembly
_#_Judicial branch: Supreme Court, Federal Islamic (Shariat) Court
_#_Leaders:
Chief of State--President GHULAM ISHAQ Khan (since 13 December
1988);
Head of Government--Prime Minister Mian Nawaz SHARIF (since 6
November 1990);
_#_Political parties and leaders: Islamic Democratic
Alliance (Islami Jamuri Ittehad or IJI)--the Pakistan Muslim League
(PML) led by Mohammed Khan JUNEJO is the main party in the IJI;
Pakistan People''s Party (PPP), Benazir BHUTTO; note--in September 1990
the PPP announced the formation of the People''s Democratic Alliance
(PDA), an electoral alliance including the following four
parties--PPP, Solidarity Movement (Tehrik Istiqlal), Movement for the
Implementation of Shia Jurisprudence (Tehrik-i-Nifaz Fiqh Jafariya
or TNFJ), and the PML (Malik faction);
Muhajir Qaumi Movement (MQM), Altaf HUSSAIN;
Awami National Party (ANP), Khan Abdul Wali KHAN;
Jamiat-ul-Ulema-i-Islam (JUI), Fazlur RAHMAN;
Jamhoori Watan Party (JWP), Mohammad Akbar Khan BUGTI;
Pakistan National Party (PNP), Mir Ghaus Bakhsh BIZENJO;
Pakistan Khawa Milli Party (PKMP), leader NA;
Assembly of Pakistani Clergy (Jamiat-ul-Ulema-e-Pakistan or JUP),
Maulana Shah Ahmed NOORANI;
Jamaat-i-Islami (JI), Qazi Hussain AHMED
_#_Suffrage: universal at age 21
_#_Elections:
President--last held on 12 December 1988 (next to be held
December 1993); results--Ghulam Ishaq KHAN was elected by Parliament
and the four provincial assemblies;
Senate--last held March 1991 (next to be held March 1994);
results--elected by provincial assemblies;
seats--(87 total) IJI 57, Tribal Area Representatives (nonparty) 8,
PPP 5, ANP 5, JWP 4, MQM 3, PNP 2, PKMP 1, JUI 1, independent 1;
National Assembly--last held on 24 October 1990 (next to be held
by October 1995);
results--percent of vote by party NA;
seats--(217 total) IJI 107, PDA 45, MQM 15, ANP 6, JUI 6, JWP 2, PNP 2,
PKMP 1, independent 14, religious minorities 10, Tribal Area
Representatives (nonparty) 8, vacant 1
_#_Communists: the Communist party is officially banned but is
allowed to operate openly
_#_Other political or pressure groups: military remains dominant
political force; ulema (clergy), industrialists, and small merchants also
influential
_#_Member of: AsDB, C, CCC, CP, ESCAP, FAO, G-19, G-24, G-77, GATT,
IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IDB, IFAD, IFC, ILO, IMF, IMO,
INMARSAT, INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS, NAM, OAS
(observer), OIC, PCA, SAARC, UN, UNCTAD, UNESCO, UNHCR, UNIDO,
UPU, WCL, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Najmuddin SHAIKH; Chancery
at 2315 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
939-6200; there is a Pakistani Consulate General in New York;
US--Ambassador Robert B. OAKLEY; Embassy at Diplomatic Enclave,
Ramna 5, Islamabad (mailing address is P. O. Box 1048,
Islamabad or APO New York 09614); telephone [92] (51) 826161
through 79; there are US Consulates General in Karachi and Lahore, and a
Consulate in Peshawar
_#_Flag: green with a vertical white band on the hoist side; a large
white crescent and star are centered in the green field; the crescent,
star, and color green are traditional symbols of Islam
_#_Long-form name: none
_#_Type: unincorporated territory of the US; privately owned, but
administered by the Office of Territorial and International Affairs,
US Department of the Interior
_#_Long-form name: Republic of Panama
_#_Type: centralized republic
_#_Capital: Panama
_#_Administrative divisions: 9 provinces (provincias,
singular--provincia) and 1 territory* (comarca); Bocas del Toro,
Chiriqui, Cocle, Colon, Darien, Herrera, Los Santos, Panama,
San Blas*, Veraguas
_#_Independence: 3 November 1903 (from Colombia; became independent
from Spain 28 November 1821)
_#_Constitution: 11 October 1972; major reforms adopted April 1983
_#_Legal system: based on civil law system; judicial review of
legislative acts in the Supreme Court of Justice; accepts compulsory
ICJ jurisdiction, with reservations
_#_National holiday: Independence Day, 3 November (1903)
_#_Executive branch: president, two vice presidents, Cabinet
_#_Legislative branch: unicameral Legislative Assembly (Asamblea
Legislativa)
_#_Judicial branch: Supreme Court of Justice (Corte Suprema
de Justicia) currently being reorganized
_#_Leaders:
Chief of State and Head of Government--President Guillermo ENDARA
(since 20 December 1989, elected 7 May 1989);
First Vice President Ricardo ARIAS Calderon (since 20 December 1989,
elected 7 May 1989);
Second Vice President Guillermo FORD (since 20 December 1989,
elected 7 May 1989)
_#_Political parties and leaders:
government alliance--Nationalist Republican Liberal Movement
(MOLIRENA), Alfredo RAMIREZ;
Authentic Liberal Party (PLA);
Arnulfista Party (PA), Francisco ARTOLA;
opposition parties--Christian Democratic Party (PDC),
Ricardo ARIAS Calderon;
Democratic Revolutionary Party (PRD, ex-official government party),
Gerardo GONZALEZ;
Agrarian Labor Party (PALA), Carlos ELETA Almaran;
Liberal Party (PL);
People''s Party (PdP, Soviet-oriented Communist party), Ruben DARIO
Sousa Batista;
Democratic Workers Party (PDT, leftist), Eduardo RIOS;
National Action Party (PAN, rightist);
Popular Action Party (PAPO), Carlos Ivan ZUNIGA;
Socialist Workers Party (PST, leftist), Jose CAMBRA;
Revolutionary Workers Party (PRT, leftist), Graciela DIXON
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
President--last held on 7 May 1989, annulled but later upheld
(next to be held May 1994);
results--anti-NORIEGA coalition believed to have won about 75% of the
total votes cast;
Le','8b1857c2bfc29b250a3408e4611f1ec46684c764890e29ef3b046574c8e2cfaa','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fb566e41a36739c3ee9a3192bda104cde08a6217134d6bd50a59521b86a60d6',1991,'FR','France','government',105,'gislative Assembly--last held on 27 January 1991 (next to
be held May 1994);
results--percent of vote by party NA;
seats--(67 total) progovernment parties--PDC 28, MOLIRENA 16,
PA 6, PLA 5;
opposition parties--PRD 10, PALA 1, PL 1;
note--the PDC went into opposition after President Guillermo ENDARA
ousted the PDC from the coalition government in April 1991
_#_Communists: People''s Party (PdP), pro-Soviet mainline Communist
party, did not obtain the necessary 3% of the total vote in the
1984 election to retain its legal status; about 3,000 members
_#_Other political or pressure groups: National Council of Organized
Workers (CONATO); National Council of Private Enterprise (CONEP);
Panamanian Association of Business Executives (APEDE); National Civic
Crusade; National Committee for the Right to Life
_#_Member of: AG (associate), CG, ECLAC, FAO, G-77, IADB, IAEA, IBRD,
ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT,
INTERPOL, IOC, IOM, ITU, LAES, LAIA (observer), LORCS, NAM, OAS,
OPANAL, PCA, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO,
WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Jaime FORD;
Chancery at 2862 McGill Terrace NW, Washington DC 20008; telephone
(202) 483-1407; the status of the Consulates General and Consulates has
not yet been determined;
US--Ambassador Deane R. HINTON; Embassy at Avenida Balboa and
Calle 38, Apartado 6959, Panama City 5 (mailing address is Box E,
APO Miami 34002); telephone [507] 27-1777
_#_Flag: divided into four, equal rectangles; the top quadrants are
white with a blue five-pointed star in the center (hoist side) and plain
red, the bottom quadrants are plain blue (hoist side) and white with a
red five-pointed star in the center
_#_Long-form name: Independent State of Papua New Guinea
_#_Type: parliamentary democracy
_#_Capital: Port Moresby
_#_Administrative divisions: 20 provinces; Central, Chimbu, Eastern
Highlands, East New Britain, East Sepik, Enga, Gulf, Madang, Manus, Milne
Bay, Morobe, National Capital, New Ireland, Northern, North Solomons,
Sandaun, Southern Highlands, Western, Western Highlands, West New Britain
_#_Independence: 16 September 1975 (from UN trusteeship under
Australian administration)
_#_Constitution: 16 September 1975
_#_Legal system: based on English common law
_#_National holiday: Independence Day, 16 September (1975)
_#_Executive branch: British monarch, governor general, prime
minister, deputy prime minister, National Executive Council (cabinet)
_#_Legislative branch: unicameral National Parliament (sometimes
referred to as the House of Assembly)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen Elizabeth II (since 6 February 1952),
represented by Governor General Vincent ERI (since 18 January 1990);
Head of Government--Prime Minister Rabbie NAMALIU (since 4 July
1988); Deputy Prime Minister Ted DIRO (since 29 April 1990);
note--Deputy Prime Minister Ted DIRO has the title only since he has
been suspended pending trial for alleged corruption charges
_#_Political parties:
Papua New Guinea United Party (Pangu Party), Rabbie NAMALIU;
People''s Progress Party (PPP), Sir Julius CHAN;
United Party (UP), Paul TORATO;
Papua Party (PP), Galeva KWARARA;
National Party (NP), Paul PORA;
Melanesian Alliance (MA), Fr. John MOMIS
_#_Suffrage: universal at age 18
_#_Elections:
National Parliament--last held 13 June-4 July 1987 (next to be held
4 July 1992);
results--PP 14.7%, PDM 10.8%, PPP 6.1%, MA 5.6%, NP 5.1%, PAP 3.2%,
independents 42.9%, other 11.6%;
seats--(109 total) PP 26, PDM 17, NP 12, MA 7, PAP 6, PPP 5, independents
22, other 14
_#_Communists: no significant strength
_#_Member of: ACP, AsDB, ASEAN (observer), C, CP, ESCAP, FAO, G-77,
IBRD, ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL,
IOC, ISO, ITU, LORCS, NAM (observer), SPC, SPF, UN, UNCTAD, UNESCO,
UNIDO, UPU, WHO, WMO
_#_Diplomatic representation: Ambassador Margaret TAYLOR; Chancery at
Suite 350, 1330 Connecticut Avenue NW, Washington DC 20036;
telephone (202) 659-0856;
US--Ambassador Robert W. FERRAND; Embassy at Armit Street, Port
Moresby (mailing address is P. O. Box 1492, Port Moresby); telephone
[675] 211-455 or 594, 654
_#_Flag: divided diagonally from upper hoist-side corner; the upper
triangle is red with a soaring yellow bird of paradise centered; the
lower triangle is black with five white five-pointed stars of the
Southern Cross constellation centered
_#_Long-form name: none
_#_Long-form name: Republic of Paraguay
_#_Type: republic
_#_Capital: Asuncion
_#_Administrative divisions: 19 departments (departamentos,
singular--departamento); Alto Paraguay, Alto Parana, Amambay,
Boqueron, Caaguazu, Caazapa, Canindeyu, Central, Chaco,
Concepcion, Cordillera, Guaira, Itapua, Misiones, Neembucu,
Nueva Asuncion, Paraguari, Presidente Hayes, San Pedro
_#_Independence: 14 May 1811 (from Spain)
_#_Constitution 25 August 1967
_#_Legal system: based on Argentine codes, Roman law, and French
codes; judicial review of legislative acts in Supreme Court of Justice;
does not accept compulsory ICJ jurisdiction
_#_National holiday: Independence Days, 14-15 May (1811)
_#_Executive branch: president, Council of Ministers (cabinet),
Council of State
_#_Legislative branch: bicameral Congress (Congreso)
consists of an upper chamber or Chamber of Senators (Camara de
Senadores) and a lower chamber or Chamber of Deputies (Camara de
Diputados)
_#_Judicial branch: Supreme Court of Justice (Corte Suprema de
Justicia)
_#_Leaders:
Chief of State and Head of Government--President Gen. Andres
RODRIGUEZ Pedotti (since 15 May 1989)
_#_Political parties and leaders:
Colorado Party, Luis Maria ARGANA, acting president;
Authentic Radical Liberal Party (PLRA), Juan Manuel BENITEZ Florentin;
Christian Democratic Party (PDC), Jorge Dario CRISTALDO;
Febrerista Revolutionary Party (PRF), Euclides ACEVEDO;
Popular Democratic Party (PDP), Hugo RICHER
_#_Suffrage: universal and compulsory at age 18 and up to age 60
_#_Elections:
President--last held 1 May 1989 (next to be held February 1993);
results--Gen. RODRIGUEZ 75.8%, Domingo LAINO 19.4%;
Chamber of Senators--last held 1 May 1989 (next to be held by
May 1993);
results--percent of vote by party NA;
seats--(36 total) Colorado Party 24, PLRA 10, PLR 1, PRF 1;
Chamber of Deputies--last held on 1 May 1989 (next to be held by
May 1994);
results--percent of vote by party NA;
seats--(72 total) Colorado Party 48, PLRA 19, PRF 2, PDC 1, PL 1, PLR 1
_#_Communists: Oscar Creydt faction and Miguel Angel SOLER faction
(both illegal); 3,000 to 4,000 (est.) party members and sympathizers in
Paraguay, very few are hard core; party beginning to return from exile is
small and deeply divided
_#_Other political or pressure groups: Confederation of Workers (CUT);
Roman Catholic Church
_#_Member of: AG (observer), CCC, ECLAC, FAO, G-77, IADB, IAEA, IBRD,
ICAO, IDA, IFAD, IFC, ILO, IMF, INTELSAT, INTERPOL, IOC, IOM, ITU, LAES,
LAIA, LORCS, OAS, OPANAL, PCA, RG, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL,
WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Marcos MARTINEZ MENDIETA;
Chancery at 2400 Massachusetts Avenue NW, Washington DC 20008; telephone
(202) 483-6960 through 6962; there are Paraguayan Consulates General in
New Orleans and New York, and a Consulate in Houston;
US--Ambassador Jon GLASSMAN; Embassy at 1776 Avenida Mariscal
Lopez, Asuncion (mailing address is C. P. 402, Asuncion, or APO Miami
34036-0001); telephone [595] (21) 213-715
_#_Flag: three equal, horizontal bands of red (top), white, and blue
with an emblem centered in the white band; unusual flag in that the
emblem is different on each side; the obverse (hoist side at the left)
bears the national coat of arms (a yellow five-pointed star within a
green wreath capped by the words REPUBLICA DEL PARAGUAY, all within
two circles); the reverse (hoist side at the right) bears the seal of the
treasury (a yellow lion below a red Cap of Liberty and the words Paz y
Justicia (Peace and Justice) capped by the words REPUBLICA DEL
PARAGUAY, all within two circles)
_#_Long-form name: Republic of Peru
_#_Type: republic
_#_Capital: Lima
_#_Administrative divisions: 24 departments (departamentos,
singular--departamento) and 1 constitutional province*
(provincia constitucional); Amazonas, Ancash, Apurimac, Arequipa,
Ayacucho, Cajamarca, Callao*, Cusco, Huancavelica, Huanuco, Ica,
Junin, La Libertad, Lambayeque, Lima, Loreto, Madre de Dios,
Moquegua, Pasco, Piura, Puno, San Martin, Tacna, Tumbes, Ucayali;
note--the 1979 Constitution and legislation enacted from 1987 to
1990 mandate the creation of regions (regiones, singular--region)
intended to function eventually as autonomous economic and
administrative entities; so far, 12 regions have been constituted
from 23 existing departments--Amazonas (from Loreto), Andres
Avelino Caceres (from Huanuco, Pasco, Junin), Arequipa (from
Arequipa), Chavin (from Ancash), Grau (from Tumbes, Piura), Inca
(from Cusco, Madre de Dios, Apurimac), La Libertad (from La Libertad),
Los Libertadores-Huari (from Ica, Ayacucho, Huancavelica), Mariategui
(from Moquegua, Tacna, Puno), Nor Oriental del Maranon (from
Lambayeque, Cajamarca, Amazonas), San Martin (from San Martin),
Ucayali (from Ucayali); formation of another region has been delayed by
the reluctance of the constitutional province of Callao to merge with the
department of Lima; because of inadequate funding from the central
government, the regions have yet to assume their reponsibilities and at
the moment co-exist with the departmental structure
_#_Independence: 28 July 1821 (from Spain)
_#_Constitution: 28 July 1980 (often referred to as the 1979
Constitution because the Constituent Assembly met in 1979, but the
Constitution actually took effect the following year); reestablished
civilian government with a popularly elected president and bicameral
legislature
_#_Legal system: based on civil law system; has not accepted
compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 28 July (1821)
_#_Executive branch: president, two vice presidents, prime minister,
Council of Ministers (cabinet)
_#_Legislative branch: bicameral Congress (Congreso) consists of an
upper chamber or Senate (Senado) and a lower chamber or Chamber of
Deputies (Camara de Diputados)
_#_Judicial branch: Supreme Court of Justice (Corte Suprema de
Justicia)
_#_Leaders:
Chief of State--President Alberto FUJIMORI (since 28 July 1990);
Vice President Maximo SAN ROMAN (since 28 July 1990);
Vice President Carlos GARCIA (since 28 July 1990);
Head of Government--Prime Minister Carlos TORRES Y TORRES Lara
(since 15 February 1991)
_#_Political parties and leaders:
Change 90 (Cambio 90), Alberto FUJIMORI;
Democratic Front (FREDEMO), a loosely organized three-party
coalition--Popular Christian Party (PPC), Luis BEDOYA Reyes;
Popular Action Party (AP), Fernando BELAUNDE Terry;
and Liberty Movement;
American Popular Revolutionary Alliance (APRA), Luis ALVA Castro;
National Front of Workers and Peasants (FRENATRACA), Roger CACERES;
United Left (IU), run by committee;
Socialist Left (IS), Enrique BERNALES
_#_Suffrage: universal at age 18
_#_Elections:
President--last held on 10 June 1990 (next to be held April 1995);
results--Alberto FUJIMORI 56.53%, Mario VARGAS Llosa 33.92%, other
9.55%;
Senate--last held on 8 April 1990 (next to be held April 1995);
results--percent of vote by party NA;
seats--(60 total) FREDEMO 20, APRA 16, Change 90 14, IU 6, IS 3,
FRENATRACA 1;
Chamber of Deputies--last held 8 April 1990 (next to be held April
1995);
results--percent of vote by party NA;
seats--(180 total) FREDEMO 62, APRA 53, Change 90 32, IU 16, IS 4,
FRENATRACA 3, other 10
_#_Communists: Peruvian Communist Party-Unity (PCP-U), pro-Soviet,
2,000; other minor Communist parties
_#_Other political or pressure groups:
leftist guerrilla groups--Shining Path, leader Abimael GUZMAN;
Tupac Amaru Revolutionary Movement, Nestor CERPA and Victor POLLAY
_#_Member of: AG, CCC, ECLAC, FAO, G-11, G-19, G-24, G-77, GATT,
IADB, IAEA, IBRD, ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, IOM, ISO, ITU, LAES, LAIA, LORCS, NAM, OAS,
OPANAL, PCA, RG, UN, UNCTAD, UNESCO, UNIDO, UNIIMOG, UPU, WCL,
WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Roberto G. MACLEAN; Chancery
at 1700 Massachusetts Avenue NW, Washington DC 20036; telephone (202)
833-9860 through 9869); Peruvian Consulates General are located in
Chicago, Houston, Los Angeles, Miami, New York, Paterson (New Jersey),
San Francisco, and San Juan (Puerto Rico);
US--Ambassador Anthony C.E. QUAINTON; Embassy at the corner of
Avenida Inca Garcilaso de la Vega and Avenida Espana, Lima (mailing
address is P. O. Box 1995, Lima 100, or APO Miami 34031); telephone
[51] (14) 338-000
_#_Flag: three equal, vertical bands of red (hoist side), white, and
red with the coat of arms centered in the white band; the coat of arms
features a shield bearing a llama, cinchona tree (the source of quinine),
and a yellow cornucopia spilling out gold coins, all framed by a green
wreath
_#_Long-form name: Republic of the Philippines
_#_Type: republic
_#_Capital: Manila
_#_Administrative divisions: 73 provinces and 61 chartered cities*;
Abra, Agusan del Norte, Agusan del Sur, Aklan, Albay, Angeles*, Antique,
Aurora, Bacolod*, Bago*, Baguio*, Bais*, Basilan, Basilan City*, Bataan,
Batanes, Batangas, Batangas City*, Benguet, Bohol, Bukidnon, Bulacan,
Butuan*, Cabanatuan*, Cadiz*, Cagayan, Cagayan de Oro*, Calbayog*,
Caloocan*, Camarines Norte, Camarines Sur, Camiguin, Canlaon*, Capiz,
Catanduanes, Cavite, Cavite City*, Cebu, Cebu City*, Cotabato*, Dagupan*,
Danao*, Dapitan*, Davao City* Davao, Davao del Sur, Davao Oriental,
Dipolog*, Dumaguete*, Eastern Samar, General Santos*, Gingoog*, Ifugao,
Iligan*, Ilocos Norte, Ilocos Sur, Iloilo, Iloilo City*, Iriga*, Isabela,
Kalinga-Apayao, La Carlota*, Laguna, Lanao del Norte, Lanao del Sur,
Laoag*, Lapu-Lapu*, La Union, Legaspi*, Leyte, Lipa*, Lucena*,
Maguindanao, Mandaue*, Manila*, Marawi*, Marinduque, Masbate, Mindoro
Occidental, Mindoro Oriental, Misamis Occidental, Misamis Oriental,
Mountain, Naga*, Negros Occidental, Negros Oriental, North Cotabato,
Northern Samar, Nueva Ecija, Nueva Vizcaya, Olongapo*, Ormoc*,
Oroquieta*, Ozamis*, Pagadian*, Palawan, Palayan*, Pampanga, Pangasinan,
Pasay*, Puerto Princesa*, Quezon, Quezon City*, Quirino, Rizal, Romblon,
Roxas*, Samar, San Carlos* (in Negros Occidental), San Carlos* (in
Pangasinan), San Jose*, San Pablo*, Silay*, Siquijor, Sorsogon, South
Cotabato, Southern Leyte, Sultan Kudarat, Sulu, Surigao*, Surigao del
Norte, Surigao del Sur, Tacloban*, Tagaytay*, Tagbilaran*, Tangub*,
Tarlac, Tawitawi, Toledo*, Trece Martires*, Zambales, Zamboanga*,
Zamboanga del Norte, Zamboanga del Sur
_#_Independence: 4 July 1946 (from US)
_#_Constitution: 2 February 1987, effective 11 February 1987
_#_Legal system: based on Spanish and Anglo-American law; accepts
compulsory ICJ jurisdiction, with reservations
_#_National holiday: Independence Day (from Spain), 12 June (1898)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: bicameral Congress (Kongreso) consists of
an upper house or Senate (Senado) and a lower house or House of
Representatives (Kapulungan Ng Mga Kinatawan)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--President Corazon C. AQUINO
(since 25 February 1986); Vice President Salvador H. LAUREL (since
25 February 1986)
_#_Political parties and leaders:
PDP-Laban, Aquilino PIMENTEL;
Struggle of Philippine Democrats (LDP), Neptali GONZALES;
Nacionalista Party, Salvador LAUREL, Juan Ponce ENRILE;
Liberal Party, Jovito SALONGA
_#_Suffrage: universal at age 15
_#_Elections:
President--last held 7 February 1986 (next election to be
held May 1992); results--Corazon C. AQUINO elected, precipitating the
fall of the MARCOS regime;
Senate--last held 11 May 1987 (next to be held May 1992);
results--pro-Aquino LDP 63%,
liberal LDP and PDP-Laban (Pimentel wing) 25%,
opposition Nationalista Party 4%,
independent 8%;
seats--(24 total) pro-Aquino LDP 15, liberal
LDP-Laban (Pimentel wing) 6, opposition Nationalista Party
1, independent 2;
House of Representatives--last held on 11 May 1987 (next to be
held May 1992);
results--pro-Aquino LDP 73%, liberal LDP and PDP-Laban
(Pimentel wing) 10%, opposition Nationalista Party 17%;
seats--(250 total, 180 elected) number of seats by party NA
_#_Communists: the Communist Party of the Philippines (CPP) controls
about 18,000-23,000 full-time insurgents and is not recognized as a legal
party; a second Communist party, the pro-Soviet Philippine Communist
Party (PKP), has quasi-legal status
_#_Member of: APEC, AsDB, ASEAN, CCC, CP, ESCAP, FAO, G-24, G-77,
GATT, IAEA, IBRD, ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, IOM, ISO, ITU, LORCS, NAM (observer), UN,
UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Emmanuel PELAEZ; Chancery at
1617 Massachusetts Avenue NW, Washington DC 20036; telephone (202)
483-1414; there are Philippine Consulates General in Agana (Guam),
Chicago, Honolulu, Houston, Los Angeles, New York, San Francisco, and
Seattle;
US--Ambassador Nicholas PLATT; Embassy at 1201 Roxas Boulevard,
Manila (mailing address is APO San Francisco 96528); telephone [63] (32)
211-101 through 3; there is a US Consulate in Cebu
_#_Flag: two equal horizontal bands of blue (top) and red with a white
equilateral triangle based on the hoist side; in the center of the
triangle is a yellow sun with eight primary rays (each containing three
individual rays) and in each corner of the triangle is a small yellow
five-pointed star
_#_Long-form name: Pitcairn, Henderson, Ducie, and Oeno Islands
_#_Type: dependent territory of the UK
_#_Capital: Adamstown
_#_Administrative divisions: none (dependent territory of the UK)
_#_Independence: none (dependent territory of the UK)
_#_Constitution: Local Government Ordinance of 1964
_#_Legal system: local island by-laws
_#_National holiday: Celebration of the Birthday of the Queen (second
Saturday in June), 10 June 1989
_#_Executive branch: British monarch, governor, island magistrate
_#_Legislative branch: unicameral Island Council
_#_Judicial branch: Island Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by the Governor and UK High Commissioner to New Zealand
David Joseph MOSS (since NA 1990);
Head of Government--Island Magistrate and Chairman of the Island
Council Brian YOUNG (since NA 1985)
_#_Political parties and leaders: NA
_#_Suffrage: universal at age 18 with three years residency
_#_Elections:
Island Council--last held NA (next to be held NA);
results--percent of vote by party NA;
seats--(11 total, 5 elected) number of seats by party NA
_#_Communists: none
_#_Other political or pressure groups: NA
_#_Member of: SPC
_#_Diplomatic representation: none (dependent territory of the UK)
_#_Flag: blue with the flag of the UK in the upper hoist-side quadrant
and the Pitcairn Islander coat of arms centered on the outer half of the
flag; the coat of arms is yellow, green, and light blue with a shield
featuring a yellow anchor
_#_Long-form name: Republic of Poland
_#_Type: democratic state
_#_Capital: Warsaw
_#_Administrative divisions: 49 provinces (wojewodztwa,
singular--wojewodztwo); Biala Podlaska, Bialystok, Bielsko,
Bydgoszcz, Chelm, Ciechanow, Czestochowa, Elblag, Gdansk,
Gorzow, Jelenia Gora, Kalisz, Katowice, Kielce, Konin, Koszalin,
Krakow, Krosno, Legnica, Leszno, Lodz, Lomza, Lublin,
Nowy Sacz, Olsztyn, Opole, Ostroleka, Pila, Piotrkow,
Plock, Poznan, Przemysl, Radom, Rzeszow, Siedlce, Sieradz,
Skierniewice, Slupsk, Suwalki, Szczecin, Tarnobrzeg, Tarnow,
Torun, Walbrzych, Warszawa, Wloclawek, Wroclaw, Zamosc,
Zielona Gora
_#_Independence: 11 November 1918, independent republic proclaimed
_#_Constitution: the Communist-imposed Constitution of 22 July 1952
will probably be replaced by a democratic Constitution in 1992
_#_Legal system: mixture of Continental (Napoleonic) civil law and
Communist legal theory; no judicial review of legislative acts; has not
accepted compulsory ICJ jurisdiction
_#_National holiday: Constitution Day, 3 May (1794)
_#_Executive branch: president, prime minister, Council of Ministers
(cabinet)
_#_Legislative branch: bicameral National Assembly (Zgromadzenie
Narodowe) consists of an upper house or Senate (Senat) and a lower house
or Diet (Sejm)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Lech WALESA (since 22 December
1990);
Head of Government--Prime Minister Jan Krzysztof BIELECKI (since
4 January 1991)
_#_Political parties and leaders:
center-right agrarian parties--Polish Peasant Party (PSL), Roman
BARTOSZCZE, chairman;
Polish Peasant Party-Solidarity, Gabriel JANOWSKI, chairman;
other center-right parties--Center Alliance, Jaroslaw KACZYNSKI,
chairman;
Christian National Union, Wieslaw CHRZANOWSKI, chairman;
Christian Democratic Labor Party, Wladyslaw SILA-NOWICKI, chairman;
Democratic Party, Jerzy JOZWIAK, chairman;
center-left parties--Polish Socialist Party, Jan Jozef LIPSKI,
chairman;
Democratic Union, Tadeusz MAZOWIECKI, chairman;
ROAD, Wladyslaw FRASYNIUK and Zbigniew BUJAK, chairmen;
left-wing parties--Polish Socialist Party-Democratic Revolution,
Piotr IKONOWICZ;
other--Social Democracy of the Republic of Poland (formerly the
Communist party or Polish United Workers'' Party/PZPR), Aleksander
KWASNIEWSKI, chairman;
Union of the Social Democracy of the Republic of Poland (breakaway
faction of the PZPR), Tadeusz FISZBACH, chairman
_#_Suffrage: universal at age 18
_#_Elections:
President--first round held 25 November 1990, second round
held 9 December 1990 (next to be held November 1995);
results--second round Lech WALESA 74.7%, Stanislaw TYMINSKI 25.3%;
Senate--last held 4 and 18 June 1989 (next to be held late
1991);
results--percent of vote by party NA;
seats--(100 total) Solidarity 99, independent 1;
Diet--last held 4 and 18 June 1989 (next to be held late 1991);
results--percent of vote by party NA;
seats--(460 total) Communists 173, Solidarity 161, Polish Peasant
Party 76, Democratic Party 27, Christian National Union 23; note--rules
governing the election limited Solidarity''s share of the vote to 35%
of the seats; future elections, which will probably be held before
late 1991, are to be freely contested
_#_Communists: 70,000 members in the Communist successor parties
(1990)
_#_Other political or pressure groups: powerful Roman Catholic Church;
Confederation for an Independent Poland (KPN), a nationalist group;
Solidarity (trade union); All Poland Trade Union Alliance (OPZZ),
populist program; Clubs of Catholic Intellectuals (KIKs); Freedom and
Peace (WiP), a pacifist group; Independent Student Union (NZS)
_#_Member of: BIS, CCC, CERN (observer, but scheduled to become
a member l July 1991), CSCE, ECE, FAO, GATT, IAEA, IBEC, IBRD, ICAO,
ICFTU, IDA, IIB, ILO, IMF, IMO, INMARSAT, IOC, ISO, ITU, LORCS, PCA, UN,
UNCTAD, UNESCO, UNDOF, UNIDO, UNIIMOG, UPU, WCL, WFTU, WHO, WIPO, WMO,
WTO
_#_Diplomatic representation: Ambassador Kazimierz DZIEWANOWSKI;
Chancery at 2640 16th Street NW, Washington DC 20009;
telephone (202) 234-3800 through 3802; there are Polish Consulates
General in Chicago, Los Angeles, and New York;
US--Ambassador Thomas W. SIMONS, Jr.; Embassy at Aleje
Ujazdowskie 29/31, Warsaw (mailing address is American Embassy Warsaw,
c/o American Consulate General (WAW) or APO New York 09213-5010);
telephone [48] (22) 283041 through 283049; there is a US Consulate
General in Krakow and a Consulate in Poznan
_#_Flag: two equal horizontal bands of white (top) and red--a crowned
eagle is to be added; similar to the flags of Indonesia and Monaco which
are red (top) and white
_#_Long-form name: Portuguese Republic
_#_Type: republic
_#_Capital: Lisbon
_#_Administrative divisions: 18 districts (distritos,
singular--distrito) and 2 autonomou','33d764d7196c20ce531235378065635eb8c7d1282cceb7cc6e7cbd61cecc1b97','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cced78d4b400a45c4834957b7765fdc2553f1e7b695eb9ad863c5246ecd5735',1991,'FR','France','government',106,'s regions* (regioes autonomas,
singular--regiao autonoma); Aveiro, Acores (Azores)*, Beja, Braga,
Braganca, Castelo Branco, Coimbra, Evora, Faro, Guarda, Leiria,
Lisboa, Madeira*, Portalegre, Porto, Santarem, Setubal,
Viana do Castelo, Vila Real, Viseu
_#_Dependent area: Macau (scheduled to become a Special Administrative
Region of China in 1999)
_#_Independence: 1140; independent republic proclaimed 5 October 1910
_#_Constitution: 25 April 1976, revised 30 October 1982 and
1 June 1989
_#_Legal system: civil law system; the Constitutional Tribunal reviews
the constitutionality of legislation; accepts compulsory ICJ
jurisdiction, with reservations
_#_National holiday: Day of Portugal, 10 June
_#_Executive branch: president, Council of State, prime minister,
deputy prime minister, Council of Ministers (cabinet)
_#_Legislative branch: unicameral Assembly of the Republic
(Assembleia da Republica)
_#_Judicial branch: Supreme Tribunal of Justice (Supremo Tribunal de
Justica)
_#_Leaders:
Chief of State--President Dr. Mario Alberto Nobre Lopes SOARES
(since 9 March 1986);
Head of Government--Prime Minister Anibal CAVACO SILVA (since 6
November 1985)
_#_Political parties and leaders:
Social Democratic Party (PSD), Anibal CAVACO Silva;
Portuguese Socialist Party (PS), Jorge SAMPAIO;
Party of Democratic Renewal (PRD), Herminio MARTINHO;
Portuguese Communist Party (PCP), Alvaro CUNHAL;
Social Democratic Center (CDS), Andriano MORREIRA (interim);
National Solidarity Party, Manuel SERGIO
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 13 February 1991 (next to be held February
1996);
results--Dr. Mario Lopes SOARES 70%, Basilio HORTA 14%, Carlos
CARVALHAS 13%, Carlos MARQUES 3%;
Assembly of the Republic--last held 6 October 1991
(next to be held October 1995);
results--Social Democrats 50.4%,
Socialists 29.3%,
United Democratic Coalition (CDU; Communists) 8.8%,
Christian Democrats 4.4%,
National Solidarity Party 1.7%,
Democratic Renewal 0.6%, other 4.8%;
seats--(230 total) Social Democrats 132, Socialists 70, United
Democratic Coalition (CDU; Communists) 17,
Christian Democrats 5,
National Solidarity Party 1; after absentee ballots counted five
seats to be allocated
_#_Communists: Portuguese Communist Party claims membership of 200,753
(December 1983)
_#_Member of: AfDB, BIS, CCC, CE, CERN, COCOM, CSCE, EBRD, EC, ECE,
ECLAC, EIB, FAO, GATT, IADB, IAEA, IBRD, ICAO, ICC, ICFTU, IEA, IFAD,
IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC, IOM, ISO, ITU,
LAIA (observer), LORCS, NAM (guest), NATO, NEA, OAS (observer),
OECD, PCA, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WEU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Joao Eduardo M. PEREIRA
BASTOS; Chancery at 2125 Kalorama Road NW, Washington DC 20008;
telephone (202) 328-8610; there are Portuguese Consulates General in
Boston, New York, and San Francisco, and Consulates in Los Angeles,
Newark (New Jersey), New Bedford (Massachusetts), and Providence (Rhode
Island);
US--Ambassador Everett E. BRIGGS; Embassy at Avenida das Forcas
Armadas, 1600 Lisbon (mailing address is APO New York 09678-0002);
telephone [351] (1) 726-6600 or 6659, 8670, 8880; there is a US
Consulate in Ponta Delgada (Azores)
_#_Flag: two vertical bands of green (hoist side, two-fifths) and red
(three-fifths) with the Portuguese coat of arms centered on the dividing
line
_#_Long-form name: Commonwealth of Puerto Rico
_#_Type: commonwealth associated with the US
_#_Capital: San Juan
_#_Administrative divisions: none (commonwealth associated with
the US)
_#_Independence: none (commonwealth associated with the US)
_#_Constitution: ratified 3 March 1952; approved by US Congress 3
July 1952; effective 25 July 1952
_#_National holiday: Constitution Day, 25 July (1952)
_#_Legal system: based on Spanish civil code
_#_Executive branch: US president, US vice president, governor
_#_Legislative branch: bicameral Legislative Assembly consists of an
upper house or Senate and a lower house or House of Representatives
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President George BUSH (since 20 January
1989); Vice President Dan QUAYLE (since 20 January 1989);
Head of Government Governor Rafael HERNANDEZ Colon (since 2
January 1989)
_#_Political parties and leaders:
Popular Democratic Party (PPD), Rafael HERNANDEZ Colon;
New Progressive Party (PNP), Carlos ROMERO Barcelo;
Puerto Rican Socialist Party (PSP), Juan MARI Bras and Carlos
GALLISA;
Puerto Rican Independence Party (PIP), Ruben BERRIOS Martinez;
Puerto Rican Communist Party (PCP), leader(s) unknown
_#_Suffrage: universal at age 18; indigenous inhabitants are US
citizens, but do not vote in US presidential elections
_#_Elections:
Governor--last held 8 November 1988 (next to be held 3 November
1992);
results--Rafael HERNANDEZ Colon (PPD) 48.7%, Baltasar CORRADA Del Rio
(PNP) 45.8%, Ruben BERRIOS Martinez (PIP) 5.5%;
Senate--last held 8 November 1988 (next to be held 3 November
1992);
results--percent of vote by party NA;
seats--(27 total) PPD 18, PNP 8, PIP 1;
House of Representatives--last held 8 November 1988 (next to be
held 3 November 1992);
results--percent of vote by party NA;
seats--(53 total) PPD 36, PNP 15, PIP 2;
US House of Representatives--last held 8 November 1988 (next to be
held 3 November 1992); results--Puerto Rico elects one nonvoting
representative
_#_Other political or pressure groups: all have engaged in terrorist
activities--Armed Forces for National Liberation (FALN), Volunteers of
the Puerto Rican Revolution, Boricua Popular Army (also known as the
Macheteros), Armed Forces of Popular Resistance
_#_Member of: ECLAC, ICFTU, IOC, WCL, WFTU, WTO (associate)
_#_Diplomatic representation: none (commonwealth associated with the
US)
_#_Flag: five equal horizontal bands of red (top and bottom)
alternating with white; a blue isosceles triangle based on the hoist side
bears a large white five-pointed star in the center; design based on the
US flag
_#_Long-form name: State of Qatar
_#_Type: traditional monarchy
_#_Capital: Doha
_#_Administrative divisions: none
_#_Independence: 3 September 1971 (from UK)
_#_Constitution: provisional constitution enacted 2 April 1970
_#_Legal system: discretionary system of law controlled by the amir,
although civil codes are being implemented; Islamic law is significant in
personal matters
_#_National holiday: Independence Day, 3 September (1971)
_#_Executive branch: amir, Council of Ministers (cabinet)
_#_Legislative branch: unicameral Advisory Council (Majlis al-Shura)
_#_Judicial branch: Court of Appeal
_#_Leaders:
Chief of State and Head of Government--Amir and Prime Minister
Khalifa bin Hamad Al THANI (since 22 February 1972); Heir Apparent Hamad
bin Khalifa AL THANI (appointed 31 May 1977; son of Amir)
_#_Political parties and leaders: none
_#_Suffrage: none
_#_Elections:
Advisory Council--constitution calls for elections for part
of this consultative body, but no elections have been held;
seats--(30 total)
_#_Member of: ABEDA, AFESD, AL, AMF, ESCWA, FAO, G-77, GCC, IAEA,
IBRD, ICAO, IDB, IFAD, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC,
ITU, LORCS, NAM, OAPEC, OIC, OPEC, UN, UNCTAD, UNESCO, UNIDO, UPU,
WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Hamad Abd al-Aziz
AL-KAWARI, Chancery at Suite 1180, 600 New Hampshire Avenue NW,
Washington DC 20037; telephone (202) 338-0111;
US--Ambassador Mark G. HAMBLEY; Embassy at 149 Ali Bin Ahmed St.,
Farig Bin Omran (opposite the television station), Doha (mailing address
is P. O. Box 2399, Doha); telephone [0974] 864701 through 864703
_#_Flag: maroon with a broad white serrated band (nine white points)
on the hoist side
_#_Long-form name: Department of Reunion
_#_Type: overseas department of France
_#_Capital: Saint-Denis
_#_Administrative divisions: none (overseas department of France)
_#_Independence: none (overseas department of France)
_#_Constitution: 28 September 1958 (French Constitution)
_#_Legal system: French law
_#_National holiday: Taking of the Bastille, 14 July (1789)
_#_Executive branch: French president, commissioner of the Republic
_#_Legislative branch: unicameral General Council, unicameral Regional
Council
_#_Judicial branch: Court of Appeals (Cour d''appel)
_#_Leaders:
Chief of State--President Francois MITTERRAND
(since 21 May 1981);
Head of Government--Commissioner of the Republic Daniel CONSTANTIN
(since September 1989)
_#_Political parties and leaders:
Rally for the Republic (RPR), Francois MAS;
Union for French Democracy (UDF), Gilbert GERARD;
Communist Party of Reunion (PCR), Paul VERGES;
France-Reunion Future (FRA), Andre THIEN AH KOON;
Socialist Party (PS), Jean-Claude FRUTEAU;
Social Democrats (CDS), other small parties
_#_Suffrage: universal at age 18
_#_Elections:
General Council--last held March 1986 (next to be held 1992);
results--percent of vote by party NA;
seats--(36 total) number of seats by party NA;
Regional Council--last held 16 March 1986
(next to be held March 1991);
results--RPR/UDF 36.8%, PCR 28.2%, FRA and other right wing 17.3%,
PS 14.1%, other 3.6%;
seats--(45 total) RPR/UDF 18, PCR 13, FRA and other right wing 8, PS 6;
French Senate--last held 24 September 1989 (next to be held
September 1992);
results--percent of vote by party NA;
seats--(3 total) RPR-UDF 1, PS 1, independent 1;
French National Assembly--last held 5 and 12 June 1988
(next to be held June 1993);
results--percent of vote by party NA;
seats--(5 total) PCR 2, RPR 1, UDF-CDS 1, FRA 1
_#_Communists: Communist party small but has support among sugarcane
cutters, the minuscule Popular Movement for the Liberation of Reunion
(MPLR), and in the district of Le Port
_#_Member of: FZ, WFTU
_#_Diplomatic representation: as an overseas department of France,
Reunionese interests are represented in the US by France
_#_Flag: the flag of France is used
_#_Long-form name: none
_#_Type: in transition from Communist state to republic
_#_Capital: Bucharest
_#_Administrative divisions: 40 counties (judete, singular--judet)
and 1 municipality* (municipiu); Alba, Arad, Arges, Bacau, Bihor,
Bistrita-Nasaud, Botosani, Braila, Brasov, Bucuresti*,
Buzau, Calarasi, Caras-Severin, Cluj, Constanta, Covasna,
Dimbovita, Dolj, Galati, Gorj, Giurgiu, Harghita, Hunedoara,
Ialomita, Iasi, Maramures, Mehedinti, Mures, Neamt, Olt,
Prahova, Salaj, Satu Mare, Sibiu, Suceava, Teleorman, Timis, Tulcea,
Vaslui, Vilcea, Vrancea
_#_Independence: 1881 (from Turkey); republic proclaimed 30 December
1947
_#_Constitution: 21 August 1965; new constitution being drafted
_#_Legal system: former mixture of civil law system and Communist
legal theory that increasingly reflected Romanian traditions is being
revised
_#_National holiday: National Day of Romania, 1 December (1990)
_#_Executive branch: president, vice president, prime minister,
Council of Ministers (cabinet)
_#_Legislative branch: bicameral Parliament consists of an upper
house or Senate (Senat) and a lower house or House of Deputies
(Adunarea Deputatilor)
_#_Judicial branch: Supreme Court of Justice
_#_Leaders:
Chief of State--President Ion ILIESCU (since 20 June 1990,
previously President of Provisional Council of National Unity since
23 December 1989);
Head of Government--Prime Minister Teodor STOLOJAN
(since 2 October 1991)
_#_Political parties and leaders:
National Salvation Front (FSN), Ion STOICA;
Magyar Democratic Union (UDMR), Geza DOMOKOS;
National Liberal Party (PNL), Radu CAMPEANU;
National Peasants'' Christian and Democratic Party (PNTCD), Corneliu
COPOSU;
Ecology Movement (MER), leader NA;
Romanian National Unity Party (AUR), Radu CEONTEA;
there are now more than 100 other parties; note--although the Communist
Party has ceased to exist, a small proto-Communist party, the Socialist
Labor Party, has been formed
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 20 May 1990 (next to be held NA 1992);
results--Ion ILIESCU 85%, Radu CAMPEANU 10.5%, Ion RATIU 3.8%;
Senate--last held 20 May 1990 (next to be held NA 1992);
results--FSN 67%, other 33%;
seats--(118 total) FSN 92, UDMR 12, PNL 9, AUR 2, PNTCD 1, MER 1,
other 1;
House of Deputies--last held 20 May 1990 (next to be held NA
1992);
results--FSN 66%, UDMR 7%, PNL 6%, MER 2%, PNTCD 2%, AUR 2%,
other 15%;
seats--(387 total) FSN 263, UDMR 29, PNL 29, PNTCD 12, MER 12,
AUR 9, other 33
_#_Communists: 3,400,000 (November 1984); Communist Party has ceased
to exist
_#_Member of: BIS, CCC, CSCE, ECE, FAO, G-9, G-77, GATT,
IAEA, IBEC, IBRD, ICAO, IFAD, IFC, IIB, ILO, IMF, IMO, INTERPOL, IOC,
ITU, LORCS, NAM (guest), PCA, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO,
WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Virgil CONSTANTINESCU;
Chancery at 1607 23rd Street NW, Washington DC 20008; telephone
(202) 232-4747;
US--Ambassador Alan GREEN, Jr.; Embassy at Strada Tudor Arghezi
7-9, Bucharest (mailing address is APO New York 09213); telephone [40]
(0) 10-40-40
_#_Flag: three equal vertical bands of blue (hoist side), yellow, and
red; the national coat of arms that used to be centered in the yellow
band, has been removed; now similar to the flags of Andorra and Chad
_#_Long-form name: Republic of Rwanda
_#_Type: republic; presidential system in which military leaders hold
key offices; on 31 December 1990, the government announced a
National Political Charter to serve as a basis for transition
to a presidential/parliamentary political system; the charter will be
voted upon in a national referendum to be held June 1991
_#_Capital: Kigali
_#_Administrative divisions: 10 prefectures (prefectures,
singular--prefecture in French; plural--NA, singular--prefegitura in
Kinyarwanda); Butare, Byumba, Cyangugu, Gikongoro, Gisenyi, Gitarama,
Kibungo, Kibuye, Rigali, Ruhengeri
_#_Constitution: 17 December 1978
_#_Independence: 1 July 1962 (from UN trusteeship under Belgian
administration)
_#_Legal system: based on German and Belgian civil law systems and
customary law; judicial review of legislative acts in the Supreme Court;
has not accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 1 July (1962)
_#_Executive branch: president, Council of Ministers (cabinet)
_#_Legislative branch: unicameral National Development Council
(Conseil National de Developpement)
_#_Judicial branch: Constitutional Court (consists of the Court of
Cassation and the Council of State in joint session)
_#_Leaders:
Chief of State and Head of Government--President Maj. Gen.
Juvenal HABYARIMANA (since 5 July 1973)
_#_Political parties and leaders: only party--National Revolutionary
Movement for Development (MRND), Maj. Gen. Juvenal HABYARIMANA;
note--the MRND is officially a development movement, not a party
_#_Suffrage: universal adult, exact age NA
_#_Elections:
President--last held 19 December 1988 (next to be held December
1993); results--President Maj. Gen. Juvenal HABYARIMANA reelected;
National Development Council--last held 19 December 1988 (next
to be held December 1993);
results--MRND is the only party;
seats--(70 total); MRND 70
_#_Communists: no Communist party
_#_Member of: ACCT, ACP, AfDB, ECA, CCC, CEEAC, CEPGL, FAO, G-77,
GATT, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, INTELSAT, INTERPOL, IOC,
ITU, LORCS, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL,
WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Aloys UWIMANA; Chancery at
1714 New Hampshire Avenue NW, Washington DC 20009; telephone (202)
232-2882;
US--Ambassador Robert A. FLATEN; Embassy at Boulevard
de la Revolution, Kigali (mailing address is B. P. 28, Kigali);
telephone [250] 75601 through 75603 or 72126 through 72128
_#_Flag: three equal vertical bands of red (hoist side), yellow, and
green with a large black letter R centered in the yellow band; uses
the popular pan-African colors of Ethiopia; similar to the flag of
Guinea, which has a plain yellow band
_#_Long-form name: none
_#_Type: dependent territory of the UK
_#_Capital: Jamestown
_#_Administrative divisions: 2 dependencies and 1 administrative
area*; Ascension*, Saint Helena, Tristan da Cunha
_#_Independence: none (dependent territory of the UK)
_#_Constitution: 1 January 1967
_#_Legal system: NA
_#_National holiday: Celebration of the Birthday of the Queen (second
Saturday in June), 10 June 1989
_#_Executive branch: British monarch, governor, Executive Council
(cabinet)
_#_Legislative branch: unicameral Legislative Council
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952);
Head of Government--Governor and Commander in Chief Robert
F. STIMSON (since 1987)
_#_Political parties and leaders:
Saint Helena Labor Party, G. A. O. THORNTON;
Saint Helena Progressive Party, leader unknown;
note--both political parties inactive since 1976
_#_Suffrage: NA
_#_Elections:
Legislative Council--last held October 1984 (next to be held NA);
results--percent of vote by party NA;
seats--(15 total, 12 elected) number of seats by party NA
_#_Communists: probably none
_#_Member of: ICFTU
_#_Diplomatic representation: none (dependent territory of the UK)
_#_Flag: blue with the flag of the UK in the upper hoist-side
quadrant and the Saint Helenian shield centered on the outer half of the
flag; the shield features a rocky coastline and three-masted sailing ship
_#_Long-form name: Federation of Saint Kitts and Nevis
_#_Type: constitutional monarchy
_#_Capital: Basseterre
_#_Administrative divisions: 14 parishs; Christ Church Nichola Town,
Saint Anne Sandy Point, Saint George Basseterre, Saint George Gingerland,
Saint James Windward, Saint John Capisterre, Saint John Figtree, Saint
Mary Cayon, Saint Paul Capisterre, Saint Paul Charlestown, Saint Peter
Basseterre, Saint Thomas Lowland, Saint Thomas Middle Island, Trinity
Palmetto Point
_#_Independence: 19 September 1983 (from UK)
_#_Constitution: 19 September 1983
_#_Legal system: based on English common law
_#_National holiday: Independence Day, 19 September (1983)
_#_Executive branch: British monarch, governor general, prime
minister, deputy prime minister, Cabinet
_#_Legislative branch: unicameral National Assembly
_#_Judicial branch: Eastern Caribbean Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor General Sir Clement Athelston ARRINDELL (since
19 September 1983, previously Governor General of the Associated State
since NA November 1981);
Head of Government--Prime Minister Dr. Kennedy Alphonse SIMMONDS
(since 19 September 1983, previously Premier of the Associated State
since NA February 1980); Deputy Prime Minister Michael Oliver POWELL
(since NA)
_#_Political parties and leaders:
People''s Action Movement (PAM), Kennedy SIMMONDS;
Saint Kitts and Nevis Labor Party (SKNLP), Lee MOORE;
Nevis Reformation Party (NRP), Simeon DANIEL;
Concerned Citizens Movement (CCM), Vance AMORY
_#_Suffrage: universal adult at age NA
_#_Elections:
House of Assembly--last held 21 March 1989
(next to be held by 21 March 1994);
seats--(14 total, 11 elected) PAM 6, SKNLP 2, NRP 2, CCM 1
_#_Communists: none known
_#_Member of: ACP, C, CARICOM, CDB, ECLAC, FAO, IBRD, ICFTU, IDA,
IFAD, IMF, INTERPOL, OAS, OECS, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO
_#_Diplomatic representation: Minister-Counselor (Deputy Chief of
Mission), Charge d''Affaires ad interim Erstein M. EDWARDS;
Chancery at Suite 540, 2501 M Street NW, Washington DC 20037;
telephone (202) 833-3550;
US--none
_#_Flag: divided diagonally from the lower hoist side by a broad black
band bearing two white five-pointed stars; the black band is edged in
yellow; the upper triangle is green, the lower triangle is red
_#_Long-form name: none
_#_Type: parliamentary democracy
_#_Capital: Castries
_#_Administrative divisions: 11 quarters; Anse-la-Raye, Castries,
Choiseul, Dauphin, Dennery, Gros-Islet, Laborie, Micoud, Praslin,
Soufriere, Vieux-Fort
_#_Independence: 22 February 1979 (from UK)
_#_Constitution: 22 February 1979
_#_Legal system: based on English common law
_#_National holiday: Independence Day, 22 February (1979)
_#_Executive branch: British monarch, governor general, prime
minister, Cabinet
_#_Legislative branch: bicameral Parliament consists of an upper
house or Senate and a lower house or House of Assembly
_#_Judicial branch: Eastern Caribbean Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Acting Governor General Sir Stanislaus Anthony JAMES
(since 10 October 1988);
Head of Government--Prime Minister John George Melvin COMPTON
(since 3 May 1982)
_#_Political parties and leaders:
United Workers'' Party (UWP), John COMPTON;
Saint Lucia Labor Party (SLP), Julian HUNTE;
Progressive Labor Party (PLP), George ODLUM
_#_Suffrage: universal at age 18
_#_Elections:
House of Assembly--last held 6 April 1987 (next to be held by
April 1992);
results--percent of vote by party NA;
seats--(17 total) UWP 10, SLP 7
_#_Communists: negligible
_#_Member of: ACCT (associate), ACP, C, CARICOM, CDB, ECLAC, FAO,
G-77, IBRD, ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTERPOL,
LORCS, NAM, OAS, OECS, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO,
WMO
_#_Diplomatic representation: Ambassador Dr. Joseph Edsel EDMUNDS;
Chancery at Suite 309, 2100 M Street NW, Washington DC 30037;
telephone (202) 463-7378 or 7379; there is a Saint Lucian Consulate
General in New York;
US--none
_#_Flag: blue with a gold isosceles triangle below a black arrowhead;
the upper edges of the arrowhead have a white border
_#_Long-form name: Territorial Collectivity of Saint Pierre and
Miquelon
_#_Type: territorial collectivity of France
_#_Capital: Saint-Pierre
_#_Administrative divisions: none (territorial collectivity of France)
_#_Independence: none (territorial collectivity of France);
note--has been under French control since 1763
_#_Constitution: 28 September 1958 (French Constitution)
_#_Legal system: French law
_#_National holiday: National Day, 14 July (Taking of the Bastille)
_#_Executive branch: commissioner of the Republic
_#_Legislative branch: unicameral General Council
_#_Judicial branch: Superior Tribunal of Appeals (Tribunal Superieur
d''Appel)
_#_Leaders:
Chief of State--President Francois MITTERRAND (since 21 May
1981);
Head of Government--Commissioner of the Republic Jean-Pierre
MARQUIE (since February 1989); President of the General Council Marc
PLANTEGENEST (since NA)
_#_Political parties and leaders: Socialist Party (PS);
Union for French Democracy (UDF/CDS), Gerard GRIGNON
_#_Suffrage: universal at age 18
_#_Elections:
General Council--last held September-October 1988 (next to be
held September 1994);
results--percent of vote by party NA;
seats--(19 total) Socialist and other left-wing parties 13, UDF and
right-wing parties 6;
French President--last held 8 May 1988 (next to be held May 1995);
results--(second ballot) Jacques CHIRAC 56%, Francois MITTERRAND 44%;
French Senate--last held 24 September 1989 (next
to be held September 1992);
results--percent of vote by party NA;
seats--(1 total) PS 1;
French National Assembly--last held 5 and 12 June 1988
(next to be held June 1993);
results--percent of vote by party NA;
seats--(1 total) UDF/CDS 1
_#_Member of: FZ, WFTU
_#_Diplomatic representation: as a territorial collectivity of France,
local interests are represented in the US by France
_#_Flag: the flag of France is used','e40b16c7ba3c32b94f242b496552976ed62d9f499073821e0b27409e5053b4de','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01350254e09c0b79065a7c2606ef27efabdad6eb44e1bd502005ab30d75c34e7',1991,'LU','Luxembourg','government',107,'_#_Independence: 1839
_#_Constitution: 17 October 1868, occasional revisions
_#_Legal system: based on civil law system; accepts compulsory ICJ
jurisdiction
_#_National holiday: National Day (public celebration of the Grand
Duke''s birthday), 23 June (1921)
_#_Executive branch: grand duke, prime minister, vice prime minister,
Council of Ministers (cabinet)
_#_Legislative branch: unicameral Chamber of Deputies (Chambre des
Deputes); note--the Council of State (Conseil d''Etat) is an advisory
body whose views are considered by the Chamber of Deputies
_#_Judicial branch: Superior Court of Justice (Cour Superieure de
Justice)
_#_Leaders:
Chief of State--Grand Duke JEAN (since 12 November 1964);
Heir Apparent Prince HENRI (son of Grand Duke Jean, born 16 April 1955);
Head of Government--Prime Minister Jacques SANTER (since 21 July
1984); Vice Prime Minister Jacques F. POOS (since 21 July 1984)
_#_Political parties and leaders:
Christian Social Party (CSV), Jacques SANTER;
Socialist Workers Party (LSAP), Jacques POOS;
Liberal (DP), Colette FLESCH;
Communist (KPL), Andre HOFFMANN;
Green Alternative (GAP), Jean HUSS
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
Chamber of Deputies--last held on 18 June 1989 (next to be held
by June 1994);
results--CSV 31.7%, LSAP 27.2%, DP 16.2%, Greens 8.4%, PAC 7.3%,
KPL 5.1%, other 4.1%;
seats--(60 total) CSV 22, LSAP 18, DP 11, Greens 4, PAC 4, KPL 1
_#_Communists: 500 party members (1982)
_#_Other political or pressure groups: group of steel industries
representing iron and steel industry, Centrale Paysanne representing
agricultural producers; Christian and Socialist labor unions; Federation
of Industrialists; Artisans and Shopkeepers Federation
_#_Member of: ACCT, Benelux, CCC, CE, COCOM, CSCE, EBRD, EC, ECE, EIB,
EMS, FAO, GATT, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IEA, IFAD, IFC, ILO,
IMF, INTELSAT, INTERPOL, IOC, IOM, ITU, LORCS, NATO, NEA, OECD, PCA,
UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WEU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Andre PHILIPPE; Chancery at
2200 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
265-4171; there are Luxembourg Consulates General in New York and San
Francisco;
US--Ambassador Edward M. ROWELL; Embassy at 22 Boulevard
Emmanuel-Servais, 2535 Luxembourg City (mailing address is APO New York
09132); telephone [352] 460123
_#_Flag: three equal horizontal bands of red (top), white, and light
blue; similar to the flag of the Netherlands which uses a darker blue and
is shorter; design was based on the flag of France','d1629d040d93442a106a268623983781ec8f2949d328464dbb72a3a8ee57ed7c','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a3eb748c8a5c66f3cbe452237efa87f32cdc9a8268a3a07060bc4d399ed2d0d',1991,'CN','China','government',111,'_#_Long-form name: none
_#_Type: overseas territory of Portugal; scheduled to revert to China
in 1999
_#_Capital: Macau
_#_Administrative divisions: 2 districts (concelhos,
singular--concelho); Ilhas, Macau
_#_Independence: none (territory of Portugal); Portugal signed an
agreement with China on 13 April 1987 to return Macau to China on 20
December 1999; in the joint declaration, China promises to respect
Macau''s existing social and economic systems and lifestyle for 50 years
after transition
_#_Constitution: 17 February 1976, Organic Law of Macau
_#_Legal system: Portuguese civil law system
_#_National holiday: Day of Portugal, 10 June
_#_Executive branch: president of Portugal, governor,
Consultative Council (cabinet)
_#_Legislative branch: Legislative Assembly
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President (of Portugal) Mario Alberto SOARES
(since 9 March 1986);
Head of Government--Governor Gen. Vasco Joachim Rocha VIEIRA
(since 20 March 1991)
_#_Political parties and leaders:
Association to Defend the Interests of Macau;
Macau Democratic Center;
Group to Study the Development of Macau;
Macau Independent Group
_#_Suffrage: universal at age 18
_#_Elections:
Legislative Assembly--last held on 9 November 1988 (next to be
held November 1991);
results--percent of vote by party NA;
seats--(17 total; 6 elected by universal suffrage, 6 by indirect
suffrage) number of seats by party NA
_#_Other political or pressure groups: wealthy Macanese and Chinese
representing local interests, wealthy pro-Communist merchants
representing China''s interests; in January 1967 the Macau Government
acceded to Chinese demands that gave China veto power over administration
_#_Member of: GATT, WTO (associate)
_#_Diplomatic representation: as Chinese territory under Portuguese
administration, Macanese interests in the US are represented by Portugal;
US--the US has no offices in Macau and US interests are monitored
by the US Consulate General in Hong Kong
_#_Flag: the flag of Portugal is used
_#_Long-form name: Democratic Republic of Madagascar
_#_Type: republic
_#_Capital: Antananarivo
_#_Administrative divisions: 6 provinces (plural--NA,
singular--faritanin); Antananarivo, Antsiranana, Fianarantsoa,
Mahajanga, Toamasina, Toliara
_#_Independence: 26 June 1960 (from France; formerly Malagasy
Republic)
_#_Constitution: 21 December 1975
_#_Legal system: based on French civil law system and traditional
Malagasy law; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 26 June (1960)
_#_Executive branch: president, Supreme Council of the Revolution,
prime minister, Council of Ministers
_#_Legislative branch: unicameral Popular National Assembly
(Assemblee Nationale Populaire)
_#_Judicial branch: Supreme Court (Cour Supreme), High
Constitutional Court (Haute Cour Constitutionnelle)
_#_Leaders:
Chief of State--President Adm. Didier RATSIRAKA (since 15 June
1975);
Head of Government--Prime Minister Guy RASANAMAZY (since
8 August 1991)
_#_Political parties and leaders: a presidential decree issued early
last year, legalized the existence of political parties outside of the
Ruling Front; some thirty political parties now exist in Madagascar, the
most important of which are the
Advance Guard of the Malagasy Revolution (AREMA), Didier RATSIRAKA;
Congress Party for Malagasy Independence (AKFM), RAKOTOVAO-ANDRIATIANA;
Congress Party for Malagasy Independence-Revival (AKFM-R), Pastor Richard
ANDRIAMANJATO;
Movement for National Unity (VONJY), Dr. Marojama RAZANABAHINY;
Malagasy Christian Democratic Union (UDECMA), Norbert ANDRIAMORASATA;
Militants for the Establishment of a Proletarian Regime (MFM), Manandafy
RAKOTONIRINA;
National Movement for the Independence of Madagascar (MONIMA), Monja
JAONA;
Socialist Organization Monima (VSM, an offshoot of MONIMA), Tsihozony
MAHARANGA
_#_Suffrage: universal at age 18
_#_Elections:
President--last held on 12 March 1989 (next to be held March 1996);
results--Didier RATSIRAKA (AREMA) 62%, Manandafy RAKOTONIRINA (MFM/MFT)
20%, Dr. Jerome Marojama RAZANABAHINY (VONJY) 15%, Monja JAONA
(MONIMA) 3%;
Popular National Assembly--last held on 28 May 1989 (next to
be held May 1994);
results--AREMA 88.2%, MFM 5.1%, AKFM 3.7%, VONJY 2.2%, other 0.8%;
seats--(137 total) AREMA 120, MFM 7, AKFM 5, VONJY 4, MONIMA 1
_#_Communists: Communist party of virtually no importance; small and
vocal group of Communists has gained strong position in leadership of
AKFM, the rank and file of which is non-Communist
_#_Member of: ACP, AfDB, CCC, ECA, FAO, G-77, GATT, IAEA, IBRD,
ICAO, ICC, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, ITU,
LORCS, NAM, OAU, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WCL,
WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Pierrot Jocelyn
RAJAONARIVELO; Chancery at 2374 Massachusetts Avenue NW, Washington DC
20008; telephone (202) 265-5525 or 5526; there is a Malagasy Consulate
General in New York;
US--Ambassador Howard K. WALKER; Embassy at 14 and 16 Rue
Rainitovo, Antsahavola, Antananarivo (mailing address is B. P. 620,
Antananarivo); telephone 212-57, 209-56, 200-89, 207-18
_#_Flag: two equal horizontal bands of red (top) and green with a
vertical white band of the same width on hoist side
_#_Long-form name: Republic of Malawi
_#_Type: one-party state
_#_Capital: Lilongwe
_#_Administrative divisions: 24 districts; Blantyre, Chikwawa,
Chiradzulu, Chitipa, Dedza, Dowa, Karonga, Kasungu, Lilongwe,
Machinga (Kasupe), Mangochi, Mchinji, Mulanje, Mwanza, Mzimba, Ncheu,
Nkhata Bay, Nkhota Kota, Nsanje, Ntchisi, Rumphi, Salima, Thyolo, Zomba
_#_Independence: 6 July 1964 (from UK; formerly Nyasaland)
_#_Constitution: 6 July 1964; republished as amended January 1974
_#_Legal system: based on English common law and customary law;
judicial review of legislative acts in the Supreme Court of Appeal; has
not accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 6 July (1964)
_#_Executive branch: president, Cabinet
_#_Legislative branch: unicameral National Assembly
_#_Judicial branch: High Court, Supreme Court of Appeal
_#_Leaders:
Chief of State and Head of Government--President Dr. Hastings
Kamuzu BANDA (since 6 July 1966; sworn in as President for Life 6 July
1971)
_#_Political parties and leaders: only party--Malawi Congress Party
(MCP), Maxwell PASHANE, administrative secretary; John TEMBO, treasurer
general; top party position of secretary general vacant since 1983
_#_Suffrage: universal at age 21
_#_Elections:
President--President BANDA sworn in as President for Life on
6 July 1971;
National Assembly--last held 27-28 May 1987 (next to be held
by May 1992);
results--MCP is the only party;
seats--(133 total, 112 elected) MCP 133
_#_Communists: no Communist party
_#_Member of: ACP, AfDB, C, CCC, ECA, FAO, G-77, GATT, IBRD, ICAO,
ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, ISO
(correspondent), ITU, LORCS, NAM, OAU, SADCC, UN,
UNCTAD, UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Robert B. MBAYA; Chancery at
2408 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
797-1007;
US--Ambassador George A. TRAIL, III; Embassy in new capital city
development area, address NA (mailing address is P. O. Box 30016,
Lilongwe); telephone [265] 730-166
_#_Flag: three equal horizontal bands of black (top), red, and green
with a radiant, rising, red sun centered in the black band; similar to
the flag of Afghanistan which is longer and has the national coat of arms
superimposed on the hoist side of the black and red bands
_#_Long-form name: none
_#_Type: Federation of Malaysia formed 9 July 1963; constitutional
monarchy nominally headed by the paramount ruler (king) and a bicameral
Parliament; Peninsular Malaysian states--hereditary rulers in all
but Penang and Melaka, where governors are appointed by Malaysian
Government; powers of state governments are limited by federal
Constitution; Sabah--self-governing state, holds 20 seats in House of
Representatives, with foreign affairs, defense, internal security, and
other powers delegated to federal government; Sarawak--self-governing
state within Malaysia, holds 27 seats in House of Representatives, with
foreign affairs, defense, internal security, and other powers delegated
to federal government
_#_Capital: Kuala Lumpur
_#_Administrative divisions: 13 states (negeri-negeri,
singular--negeri) and 2 federal territories* (wilayah-wilayah
persekutuan, singular--wilayah persekutuan); Johor, Kedah, Kelantan,
Labuan*, Melaka, Negeri Sembilan, Pahang, Perak, Perlis, Pulau Pinang,
Sabah, Sarawak, Selangor, Terengganu, Wilayah Persekutuan*
_#_Independence: 31 August 1957 (from UK)
_#_Constitution: 31 August 1957, amended 16 September 1963 when
Federation of Malaya became Federation of Malaysia
_#_Legal system: based on English common law; judicial review of
legislative acts in the Supreme Court at request of supreme head of the
federation; has not accepted compulsory ICJ jurisdiction
_#_National holiday: National Day, 31 August (1957)
_#_Executive branch: paramount ruler, deputy paramount ruler, prime
minister, deputy prime minister, Cabinet
_#_Legislative branch: bicameral Parliament (Parlimen) consists of an
upper house or Senate (Dewan Negara) and a lower house or House of
Representatives (Dewan Rakyat)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Paramount Ruler AZLAN Muhibbuddin Shah ibni Sultan
Yusof Izzudin (since 26 April 1989); Deputy Paramount Ruler JA''AFAR ibni
Abdul Rahman (since 26 April 1989);
Head of Government--Prime Minister Dr. MAHATHIR bin Mohamad (since
16 July 1981); Deputy Prime Minister Abdul GHAFAR Baba (since 7 May 1986)
_#_Political parties and leaders: Peninsular Malaysia--
National Front, a confederation of 13 political parties dominated by
United Malays National Organization Baru (UMNO Baru), MAHATHIR bin
Mohamad;
Malaysian Chinese Association (MCA), LING Liong Sik;
Gerakan Rakyat Malaysia, Datuk LIM Keng Yaik;
Malaysian Indian Congress (MIC), Datuk S. Samy VELLU;
Sabah--Berjaya Party, Datuk Haji Mohammed NOOR Mansor;
Bersatu Sabah (PBS), Joseph Pairin KITINGAN;
United Sabah National Organizaton (USNO), Tun Datu Haji MUSTAPHA;
Sarawak--coalition Sarawak National Front composed of the Party
Pesaka Bumiputra Bersatu (PBB), Datuk Patinggi Amar Haji Abdul TAIB
Mahmud;
Sarawak United People''s Party (SUPP), Datuk Amar Stephen YONG Kuet Tze;
Sarawak National Party (SNAP), Datuk James WONG Kim Min;
Parti Bansa Dayak Sarawak (PBDS), Datuk Leo MOGGIE;
major opposition parties are
Democratic Action Party (DAP), LIM Kit Siang
and Pan-Malaysian Islamic Party (PAS), Fadzil NOOR
_#_Suffrage: universal at age 21
_#_Elections:
House of Representatives--last held 21 October 1990 (next to be
held by August 1995);
results--National Front 52%, other 48%;
seats--(180 total) National Front 127, DAP 20, PAS 7, independents 4,
other 22; note--within the National Front, UMNO got 71 seats and MCA 18
seats
_#_Communists: Peninsular Malaysia--about 1,000 armed insurgents on
Thailand side of international boundary and about 200 full time inside
Malaysia surrendered on 2 December 1989; about 50 Communist insurgents in
Sarawak surrendered on 17 October 1990
_#_Member of: APEC, AsDB, ASEAN, C, CCC, CP, ESCAP, FAO, G-77, GATT,
IAEA, IBRD, ICAO, ICFTU, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS, NAM, OIC, UN, UNCTAD,
UNESCO, UNIDO, UNIIMOG, UPU, WCL, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Abdul MAJID Mohamed; Chancery
at 2401 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
328-2700; there are Malaysian Consulates General in Los Angeles and
New York;
US--Ambassador Paul M. CLEVELAND; Embassy at 376 Jalan Tun Razak,
50400 Kuala Lumpur (mailing address is P. O. Box No. 10035, 50700 Kuala
Lumpur); telephone [60] (3) 248-9011
_#_Flag: fourteen equal horizontal stripes of red (top) alternating
with white (bottom); there is a blue rectangle in the upper hoist-side
corner bearing a yellow crescent and a yellow fourteen-pointed star; the
crescent and the star are traditional symbols of Islam; the design was
based on the flag of the US
_#_Long-form name: Republic of Maldives
_#_Type: republic
_#_Capital: Male
_#_Administrative divisions: 19 district (atolls); Aliff, Baa, Daalu,
Faafu, Gaafu Aliff, Gaafu Daalu, Haa Aliff, Haa Daalu, Kaafu, Laamu,
Laviyani, Meemu, Naviyani, Noonu, Raa, Seenu, Shaviyani, Thaa, Waavu
_#_Independence: 26 July 1965 (from UK)
_#_Constitution: 4 June 1964
_#_Legal system: based on Islamic law with admixtures of English
common law primarily in commercial matters; has not accepted compulsory
ICJ jurisdiction
_#_National holiday: Independence Day, 26 July (1965)
_#_Executive branch: president, Cabinet
_#_Legislative branch: unicameral Citizens'' Council (Majlis)
_#_Judicial branch: High Court
_#_Leaders:
Chief of State and Head of Government--President Maumoon Abdul
GAYOOM (since 11 November 1978)
_#_Political parties and leaders: no organized political parties;
country governed by the Didi clan for the past eight centuries
_#_Suffrage: universal at age 21
_#_Elections:
President--last held 23 September 1988 (next to be held September
1994);
results--President Maumoon Abdul GAYOOM reelected;
Citizens'' Council--last held on 7 December 1989 (next to be held
7 December 1994);
results--percent of vote NA;
seats--(48 total, 40 elected)
_#_Communists: negligible
_#_Member of: AsDB, C, CP, ESCAP, FAO, G-77, GATT, IBRD, ICAO, IDA,
IDB, IFAD, IFC, IMF, IMO, INTERPOL, IOC, ITU, NAM, OIC,
SAARC, UN, UNCTAD, UNESCO, UNIDO, UPU, WHO, WMO, WTO
_#_Diplomatic representation: Maldives does not maintain an embassy
in the US, but does have a UN mission in New York;
US--the US Ambassador to Sri Lanka is accredited to Maldives and
makes periodic visits there; US Consular Agency, Midhath Hilmy,
Male; telephone 2581
_#_Flag: red with a large green rectangle in the center bearing a
vertical white crescent; the closed side of the crescent is on the hoist
side of the flag
_#_Long-form name: Republic of Mali
_#_Type: republic; the single-party constitutional government
was overthrown on 26 March 1991; the new ruling National
Reconciliation Council has promised a multiparty democracy
_#_Capital: Bamako
_#_Administrative divisions: 7 regions (regions,
singular--region); Gao, Kayes, Koulikoro, Mopti, Segou, Sikasso,
Tombouctou; note--there may be a new capital district of Bamako
_#_Independence: 22 September 1960 (from France; formerly French
Sudan)
_#_Constitution: 2 June 1974, effective 19 June 1979; amended
September 1981 and March 1985; suspended following the coup of
26 March 1991
_#_Legal system: based on French civil law system and customary law;
judicial review of legislative acts in Constitutional Section of Court of
State; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Anniversary of the Proclamation of the Republic,
22 September (1960)
_#_Executive branch: National Conciliation Council led by the
military, following the coup of 26 March 1991
_#_Legislative branch: unicameral National Assembly (Assemble
Nationale)
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State--following the military coup of 26 March 1991
President Gen. Moussa TRAORE was deposed and the National
Reconciliation Council, led by Lt. Col. Amadou Toumani TOURE and Lt. Col.
Kafougouna KONE, was installed;
Head of Government--Interim Premier Soumana SACKO (since 2
April 1991)
_#_Political parties and leaders: formerly the only party, the
Democratic Union of Malian People (UDPM), was disbanded after the coup of
26 March 1991, and the new regime legalized the formation of political
parties on 5 April 1991; new political parties are--Union of Democratic
Forces (UFD), Demba DIALLO;
Union for Democracy and Development (UDD), Moussa Bala COULIBALY;
Sudanese Union/African Democratic Rally (US-RDA), Mamadou Madeira KEITA;
African Party for Solidarity and Justice (ADEMA), Alpha Oumar KONARE;
Party for Democracy and Progress (PDP), Idrissa TRAORE;
Democratic Party for Justice (PDJ), Abdul BA;
Rally for Democracy and Progress (RDP), Almany SYLLA;
Party for the Unity of Malian People (PUPM), Nock AGATTIA;
Hisboulah al Islamiya, Hamidou DRAMERA;
Union of Progressive Forces (UFP), Yacouba SIDIBE;
National Congress of Democratic Initiative (CNID), Mountaga TALL;
Assembly for Justice and Progress, Kady DRAME;
other parties forming
_#_Suffrage: universal at age 21
_#_Elections:
President--last held on 9 June 1985 (next to be held June 1991);
results--General Moussa TRAORE was reelected without opposition;
National Assembly--last held on 26 June 1988 (next to be held June
1991); results--UDPM is the only party; seats--(82 total) UDPM 82;
note--following the military coup of 26 March 1991 President TRAORE
was deposed and the UDPM was disbanded; the new ruling National
Reconciliation Council, formed of 17 soldiers, has promised to
institute a multiparty democracy and is expected to hold elections
by December 1991
_#_Communists: a few Communists and some sympathizers (no legal
Communist party)
_#_Member of: ACCT, ACP, AfDB, CCC, CEAO, ECA, ECOWAS, FAO, FZ, G-77,
IAEA, IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF, INTELSAT, INTERPOL, IOC,
ITU, LORCS, NAM, OAU, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU,
WADB, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Mohamed Alhousseyni TOURE;
Chancery at 2130 R Street NW, Washington DC 20008; telephone (202)
332-2249 or 939-8950;
US--Ambassador Herbert D. GELBER; Embassy at Rue Rochester NY and
Rue Mohamed V., Bamako (mailing address is B. P. 34, Bamako); telephone
[223] 223712
_#_Flag: three equal vertical bands of green (hoist side), yellow, and
red; uses the popular pan-African colors of Ethiopia
_#_Long-form name: Republic of Malta
_#_Type: parliamentary democracy
_#_Capital: Valletta
_#_Administrative divisions: none (administration directly from
Valletta)
_#_Independence: 21 September 1964 (from UK)
_#_Constitution: 26 April 1974, effective 2 June 1974
_#_Legal system: based on English common law and Roman civil law; has
accepted compulsory ICJ jurisdiction, with reservations
_#_National holiday: Freedom Day, 31 March
_#_Executive branch: president, prime minister, deputy prime minister,
Cabinet
_#_Legislative branch: unicameral House of Representatives
_#_Judicial branch: Constitutional Court and Court of Appeal
_#_Leaders:
Chief of State--President Vincent (Censu) TABONE (since 4 April
1989);
Head of Government--Prime Minister Dr. Edward (Eddie) FENECH
ADAMI (since 12 May 1987); Deputy Prime Minister Dr. Guido DE MARCO
(since 14 May 1987)
_#_Political parties and leaders:
Nationalist Party, Edward FENECH ADAMI;
Malta Labor Party, Karmenu MIFSUD BONNICI
_#_Suffrage: universal at age 18
_#_Elections:
House of Representatives--last held on 9 May 1987 (next to be
held by May 1992);
results--NP 51.1%, MLP 48.9%;
seats--(usually 65 total, but additional seats are given to the party
with the largest popular vote to ensure a legislative majority; current
total 69) MLP 34, NP 31 before popular vote adjustment; MLP 34, NP 35
after adjustment
_#_Communists: fewer than 100 (est.)
_#_Member of: C, CCC, CE, CSCE, EBRD, ECE, FAO, G-77, GATT, IBRD,
ICAO, ICFTU, IFAD, ILO, IMF, IMO, INTERPOL, IOC, ITU, NAM, PCA,
UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Salvatore J. STELLINI;
Chancery at 2017 Connecticut Avenue NW, Washington DC 20008; telephone
(202) 462-3611 or 3612; there is a Maltese Consulate General in New York;
US--Ambassador Sally J. NOVETZKE; Embassy at 2nd Floor, Development
House, Saint Anne Street, Floriana, Valletta (mailing address is P. O.
Box 535, Valletta); telephone [356] 240424, 240425, 243216, 243217,
243653, 223654
_#_Flag: two equal vertical bands of white (hoist side) and red; in
the upper hoist-side corner is a representation of the George Cross,
edged in red
_#_Long-form name: none
_#_Type: British crown dependency
_#_Capital: Douglas
_#_Administrative divisions: none (British crown dependency)
_#_Independence: none (British crown dependency)
_#_Constitution: 1961, Isle of Man Constitution Act
_#_Legal system: English law and local statute
_#_National holiday: Tynwald Day, 5 July
_#_Executive branch: British monarch, lieutenant governor, prime
minister, Executive Council (cabinet)
_#_Legislative branch: bicameral Tynwald consists of an upper
house or Legislative Council and a lower house or House of Keys
_#_Judicial branch: High Court of Justice
_#_Leaders:
Chief of State--Lord of Mann Queen ELIZABETH II (since 6 February
1952), represented by Lieutenant Governor Air Marshal Sir Laurence JONES
(since NA 1990);
Head of Government--President of the Legislative Council Sir
Charles KERRUISH (since NA 1990)
_#_Political parties and leaders: there is no party system and
members sit as independents
_#_Suffrage: universal at age 21
_#_Elections:
House of Keys--last held in 1986 (next to be held 1991);
results--percent of vote NA;
seats--(24 total) independents 24
_#_Communists: probably none
_#_Member of: none
_#_Diplomatic representation: none (British crown dependency)
_#_Flag: red with the Three Legs of Man emblem (Trinacria), in
the center; the three legs are joined at the thigh and bent at the knee;
in order to have the toes pointing clockwise on both sides of the flag, a
two-sided emblem is used
_#_Long-form name: Republic of the Marshall Islands
_#_Type: constitutional government in free association with the US;
the Compact of Free Association entered into force 21 October 1986
_#_Capital: Majuro
_#_Administrative divisions: none
_#_Independence: 21 October 1986 (from the US-administered UN
trusteeship; formerly the Marshall Islands District of the Trust
Territory of the Pacific Islands)
_#_Constitution: 1 May 1979
_#_Legal system: based on adapted Trust Territory laws, acts of the
legislature, municipal, common, and customary laws
_#_National holiday: Proclamation of the Republic of the Marshall
Islands, 1 May (1979)
_#_Executive branch: president, Cabinet
_#_Legislative branch: unicameral Nitijela
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--President Amata KABUA
(since 1979)
_#_Political parties and leaders: no formal parties; President KABUA
is chief political (and traditional) leader
_#_Suffrage: universal at age 18
_#_Elections:
President--last held NA November 1987 (next to be held November
1991); results--President Amata KABUA was reelected;
Parliament--last held NA November 1987 (next to be held November
1991); results--percent of vote NA;
seats--(33 total)
_#_Communists: none
_#_Member of: ESCAP (associate), ICAO, SPC, SPF, UN
_#_Diplomatic representation: Ambassador Wilfred I. KENDALL;
Chancery at 2433 Massachusetts Avenue, NW, Washington DC 20008;
telephone (202) 234-5414;
US--Ambassador William BODDE, Jr.; Embassy at NA address
(mailing address is P. O. Box 680, Majuro, Republic of the Marshall
Islands 96960-4380); telephone 692-4011
_#_Flag: blue with two stripes radiating from the lower hoist-side
corner--orange (top) and white; there is a white star with four large
rays and 20 small rays on the hoist side above the two stripes
_#_Long-form name: Department of Martinique
_#_Type: overseas department of France
_#_Capital: Fort-de-France
_#_Administrative divisions: none (overseas department of France)
_#_Independence: none (overseas department of France)
_#_Constitution: 28 September 1958 (French Constitution)
_#_Legal system: French legal system
_#_National holiday: Taking of the Bastille, 14 July (1789)
_#_Executive branch: government commissioner
_#_Legislative branch: unicameral General Council and unicameral
Regional Council
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Francois MITTERRAND (since
21 May 1981);
Head of Government--Government Commissioner Jean Claude ROURE
(since 5 May 1989); President of t','80754e2ed8e0eccecf9caffbdb6b8bf9475c829b7646e387b5590044fa1fbb88','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31975b36eba87195906beb99253daabf22ef09d8bcd0029f61e49b873486b7ea',1991,'CN','China','government',112,'he General Council Emile MAURICE
(since NA 1988)
_#_Political parties:
Rally for the Republic (RPR), Stephen BAGO;
Union of the Left composed of the Progressive Party of Martinique (PPM),
Aime CESAIRE;
Socialist Federation of Martinique, Michael YOYO;
and
the Communist Party of Martinique (PCM), Armand NICOLAS;
Union for French Democracy (UDF), Jean MARAN
_#_Suffrage: universal at age 18
_#_Elections:
General Council--last held on NA October 1988
(next to be held by March 1991); results--percent of vote by party NA;
seats--(44 total) number of seats by party NA;
Regional Assembly--last held on 16 March 1986 (next to be held by
March 1992); results--UDF/RPR coalition 49.8%, PPM/FSM/PCM
coalition 41.3%, other 8.9%;
seats--(41 total) PPM/FSM/PCM coalition 21, UDF/RPR coalition 20;
French Senate--last held 24 September 1989 (next to be held
September 1992); results--percent of vote by party NA;
seats--(2 total) UDF 1, PPM 1;
French National Assembly--last held on 5 and 12 June 1988 (next
to be held June 1993); results--percent of vote by party NA;
seats--(4 total) PPM 1, FSM 1, RPR 1, UDF 1
_#_Communists: 1,000 (est.)
_#_Other political or pressure groups: Proletarian Action Group (GAP);
Alhed Marie-Jeanne Socialist Revolution Group (GRS), Martinique
Independence Movement (MIM), Caribbean Revolutionary Alliance (ARC),
Central Union for Martinique Workers (CSTM), Marc Pulvar; Frantz Fanon
Circle; League of Workers and Peasants
_#_Member of: FZ, WCL, WFTU
_#_Diplomatic representation: as an overseas department of France,
Martiniquais interests are represented in the US by France;
US--Consul General Raymond G. ROBINSON; Consulate General at 14 Rue
Blenac, Fort-de-France (mailing address is B. P. 561, Fort-de-France
97206); telephone [590] 63-13-03
_#_Flag: the flag of France is used
_#_Long-form name: Islamic Republic of Mauritania
_#_Type: republic; military first seized power in bloodless coup
10 July 1978; a palace coup that took place on 12 December 1984 brought
President Taya to power
_#_Capital: Nouakchott
_#_Administrative divisions: 12 regions (regions,
singular--region); Adrar, Brakna, Dakhlet Nouadhibou, El Acaba,
Gorgol, Guidimaka, Hodh ech Chargui, Hodh el Gharbi, Inchiri, Tagant,
Tiris Zemmour, Trarza; note--there may be a new capital district of
Nouakchott
_#_Independence: 28 November 1960 (from France)
_#_Constitution: 20 May 1961, abrogated after coup of 10 July 1978;
provisional constitution published 17 December 1980 but abandoned in
1981; new constitutional charter published 27 February 1985
_#_Legal system: based on Islamic law
_#_National holiday: Independence Day, 28 November (1960)
_#_Executive branch: president, Military Committee for National
Salvation (CMSN), Council of Ministers (cabinet)
_#_Legislative branch: unicameral National Assembly (Assemblee
Nationale), dissolved after 10 July 1978 coup; legislative power
resides with the CMSN
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State and Head of Government--President Col. Maaouya Ould
SidAhmed TAYA (since 12 December 1984)
_#_Political parties and leaders: suspended
_#_Suffrage: none
_#_Elections: last presidential election August 1976; National
Assembly dissolved 10 July 1978; no national elections are scheduled
_#_Communists: no Communist party, but there is a scattering of Maoist
sympathizers
_#_Member of: ABEDA, ACCT (associate), ACP, AfDB, AFESD, AL, AMF, AMU,
CAEU, CCC, CEAO, ECA, ECOWAS, FAO, G-77, GATT, IBRD, ICAO, IDA,
IDB, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, ITU, LORCS,
NAM, OAU, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Abdellah OULD DADDAH;
Chancery at 2129 Leroy Place NW, Washington DC 20008; telephone (202)
232-5700;
US--Ambassador William H. TWADDELL; Embassy at address NA,
Nouakchott (mailing address is B. P. 222, Nouakchott); telephone [222]
(2) 252-660 or 252-663
_#_Flag: green with a yellow five-pointed star above a yellow,
horizontal crescent; the closed side of the crescent is down; the
crescent, star, and color green are traditional symbols of Islam
_#_Long-form name: none
_#_Type: parliamentary democracy
_#_Capital: Port Louis
_#_Administrative divisions: 9 districts and 3 dependencies*;
Agalega Islands*, Black River, Cargados Carajos*, Flacq, Grand Port,
Moka, Pamplemousses, Plaines Wilhems, Port Louis, Riviere du Rempart,
Rodrigues*, Savanne
_#_Independence: 12 March 1968 (from UK)
_#_Constitution: 12 March 1968
_#_Legal system: based on French civil law system with elements of
English common law in certain areas
_#_National holiday: Independence Day, 12 March (1968)
_#_Executive branch: British monarch, governor general, prime
minister, deputy prime minister, Council of Ministers (cabinet)
_#_Legislative branch: unicameral Legislative Assembly
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor General Sir Veerasamy RINGADOO (since 17 January
1986);
Head of Government--Prime Minister Sir Anerood JUGNAUTH (since 12
June 1982); Deputy Prime Minister Prem NABABSING (since 26 September
1990)
_#_Political parties and leaders:
government coalition--Militant Socialist Movement (MSM), A.
JUGNAUTH; Mauritian Militant Movement (MMM), Paul BERENGER;
Organization of the People of Rodrigues (OPR), Louis Serge CLAIR;
Democratic Labor Movement (MTD), Anil BAICHOO;
opposition--Mauritian Labor Party (MLP), Navin RAMGOOLMAN;
Socialist Workers Front, Sylvio MICHEL;
Mauritian Social Democratic Party (PMSD), G. DUVAL
_#_Suffrage universal at age 18
_#_Elections:
Legislative Assembly--last held on 15 September 1991 (next to be
held by 15 September 1996);
results--MSM/MMM 53%, MLP/PMSD 38%;
seats--(70 total, 62 elected) MSM/MMM alliance 59 (MSM 29, MMM 26,
OPR 2, MTD 2); opposition 3
_#_Communists: may be 2,000 sympathizers; several Communist
organizations; Mauritius Lenin Youth Organization, Mauritius Women''s
Committee, Mauritius Communist Party, Mauritius People''s Progressive
Party, Mauritius Young Communist League, Mauritius Liberation Front,
Chinese Middle School Friendly Association, Mauritius/USSR Friendship
Society
_#_Other political or pressure groups: various labor unions
_#_Member of: ACCT, ACP, AfDB, C, CCC, ECA, FAO, G-77, GATT, IAEA,
IBRD, ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL,
IOC, ISO (correspondent), ITU, LORCS, NAM, OAU, PCA, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Chitmansing JESSERAMSING;
Chancery at Suite 134, 4301 Connecticut Avenue NW, Washington DC 20008;
telephone (202) 244-1491 or 1492;
US--Ambassador Penne Percy KORTH; Embassy at 4th Floor, Rogers
House, John Kennedy Street, Port Louis; telephone [230] 208-9763 through
208-9767
_#_Flag: four equal horizontal bands of red (top), blue, yellow,
and green
_#_Long-form name: Territorial Collectivity of Mayotte
_#_Type: territorial collectivity of France
_#_Capital: Dzaoudzi
_#_Administrative divisions: none (territorial collectivity of France)
_#_Independence: none (territorial collectivity of France)
_#_Constitution: 28 September 1958 (French Constitution)
_#_Legal system: French law
_#_National holiday: Taking of the Bastille, 14 July (1789)
_#_Executive branch: government commissioner
_#_Legislative branch: unicameral General Council (Conseil
General)
_#_Judicial branch: Supreme Court (Tribunal Superieur d''Appel)
_#_Leaders:
Chief of State--President Francois MITTERRAND (since 21 May
1981);
Head of Government--Prefect, Representative of the French
Government Daniel LIMODIN (since NA 1990);
President of the General Council Youssouf BAMANA (since NA 1976)
_#_Political parties and leaders:
Mahoran Popular Movement (MPM), Younoussa BAMANA;
Party for the Mahoran Democratic Rally (PRDM), Daroueche MAOULIDA;
Mahoran Rally for the Republic (RMPR), Mansour KAMARDINE;
Union of the Center (UDC)
_#_Suffrage: universal at age 18
_#_Elections:
General Council--last held NA June 1988 (next to be held June
1993);
results--percent of vote by party NA;
seats--(17 total) MPM 9, RPR 6, other 2;
French Senate--last held on 24 September 1989 (next to be held
September 1992);
results--percent of vote by party NA;
seats--(1 total) MPM 1;
French National Assembly--last held 5 and 12 June 1988 (next to
be held June 1993);
results--percent of vote by party NA;
seats--(1 total) UDC 1
_#_Communists: probably none
_#_Member of: FZ
_#_Diplomatic representation: as a territorial collectivity of France,
Mahoran interests are represented in the US by France
_#_Flag: the flag of France is used
_#_Long-form name: United Mexican States
_#_Type: federal republic operating under a centralized government
_#_Capital: Mexico
_#_Administrative divisions: 31 states (estados, singular--estado) and
1 federal district* (distrito federal); Aguascalientes, Baja California,
Baja California Sur, Campeche, Chiapas, Chihuahua, Coahuila, Colima,
Distrito Federal*, Durango, Guanajuato, Guerrero, Hidalgo, Jalisco,
Mexico, Michoacan, Morelos, Nayarit, Nuevo Leon, Oaxaca, Puebla,
Queretaro, Quintana Roo, San Luis Potosi, Sinaloa, Sonora, Tabasco,
Tamaulipas, Tlaxcala, Veracruz, Yucatan, Zacatecas
_#_Independence: 16 September 1810 (from Spain)
_#_Constitution: 5 February 1917
_#_Legal system: mixture of US constitutional theory and civil law
system; judicial review of legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
_#_National holiday: Independence Day, 16 September (1810)
_#_Executive branch: president, Cabinet
_#_Legislative branch: bicameral National Congress (Congreso de la
Union) consists of an upper chamber or Senate (Camara de Senadores)
and a lower chamber or Chamber of Deputies (Camara de Diputados)
_#_Judicial branch: Supreme Court of Justice (Suprema Corte de
Justicia)
_#_Leaders:
Chief of State and Head of Government--President Carlos SALINAS de
Gortari (since 1 December 1988)
_#_Political parties and leaders: (recognized parties)
Institutional Revolutionary Party (PRI), Luis Donaldo COLOSIO Murrieta;
National Action Party (PAN), Luis ALVAREZ;
Popular Socialist Party (PPS), Indalecio SAYAGO Herrera;
Democratic Revolutionary Party (PRD), Cuauhtemoc CARDENAS Solorzano;
Cardenist Front for the National Reconstruction Party (PFCRN), Rafael
AGUILAR Talamantes;
Authentic Party of the Mexican Revolution (PARM), Carlos Enrique CANTU
Rosas
_#_Suffrage: universal and compulsory (but not enforced) at age 18
_#_Elections:
President--last held on 6 July 1988 (next to be held September
1994); results--Carlos SALINAS de Gortari (PRI) 50.74%,
Cuauhtemoc CARDENAS Solorzano (FDN) 31.06%,
Manuel CLOUTHIER (PAN) 16.81%; other 1.39%; note--several of the smaller
parties ran a common candidate under a coalition called the National
Democratic Front (FDN);
Senate--last held on 6 July 1988 (next to be held mid-year
1991); results--PRI 94%, FDN (now PRD) 6%;
seats--(64 total) number of seats by party NA;
Chamber of Deputies--last held on 6 July 1988 (next to be held
mid-year 1991);
results--PRI 53%, PAN 20%, PFCRN 10%, PPS 6%, PARM 7%, PMS (now part of
PRD) 4%;
seats--(500 total) number of seats by party NA
_#_Other political or pressure groups: Roman Catholic Church,
Confederation of Mexican Workers (CTM), Confederation of Industrial
Chambers (CONCAMIN), Confederation of National Chambers of Commerce
(CONCANACO), National Peasant Confederation (CNC), UNE (no expansion),
Revolutionary Workers Party (PRT), Mexican Democratic Party (PDM),
Revolutionary Confederation of Workers and Peasants (CROC), Regional
Confederation of Mexican Workers (CROM), Confederation of Employers of
the Mexican Republic (COPARMEX), National Chamber of Transformation
Industries (CANACINTRA), Business Coordination Council (CCE)
_#_Member of: AG (observer), CCC, CDB, CG, EBRD, ECLAC, FAO, G-3, G-6,
G-11, G-19, G-24, G-77, GATT, IADB, IAEA, IBRD, ICAO, ICC, ICFTU, IDA,
IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, IOM (observer), ISO,
ITU, LAES, LAIA, LORCS, NAM (observer), OAS, OPANAL, PCA, RG, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Gustavo PETRICIOLI Iturbide;
Chancery at 1911 Pennsylvania Avenue NW, Washington DC 20006; telephone
(202) 728-1600; there are Mexican Consulates General in Chicago, Dallas,
Denver, El Paso, Houston, Los Angeles, New Orleans, New York, San
Francisco, San Antonio, San Diego, and Consulates in Albuquerque,
Atlanta, Austin, Boston, Brownsville (Texas), Calexico (California),
Corpus Christi, Del Rio (Texas), Detroit, Douglas (Arizona), Eagle Pass
(Texas), Fresno (California), Kansas City (Missouri), Laredo, McAllen
(Texas), Miami, Nogales (Arizona), Oxnard (California), Philadelphia,
Phoenix, Presidio (Texas), Sacramento, St. Louis, St. Paul (Minneapolis),
Salt Lake City, San Bernardino, San Jose, San Juan (Puerto Rico), and
Seattle;
US--Ambassador John D. NEGROPONTE, Jr.; Embassy at Paseo de la
Reforma 305, 06500 Mexico, D.F. (mailing address is P. O. Box 3087,
Laredo, TX 78044-3087); telephone [52] (5) 211-0042; there are US
Consulates General in Ciudad Juarez, Guadalajara, Monterrey, and Tijuana,
and Consulates in Hermosillo, Matamoros, Mazatlan, Merida, and Nuevo
Laredo
_#_Flag: three equal vertical bands of green (hoist side), white, and
red; the coat of arms (an eagle perched on a cactus with a snake is its
beak) is centered in the white band','3c0a9675feb000090f2229269734eaed12078862754bf596c34d69eb59d4c2fb','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe0259b133ae8bd1b33b026b276c3669448e84dae46f1116c8596eaf82c01d2b',1991,'ID','Indonesia','government',118,'_#_Long-form name: Federated States of Micronesia (no short-form name)
_#_Type: constitutional government in free association with the US;
the Compact of Free Association entered into force 3 November 1986
_#_Capital: Kolonia (on the island of Pohnpei); note--a new capital is
being built about 10 km southwest in the Palikir valley
_#_Administrative divisions: 4 states; Kosrae, Pohnpei, Chuuk, Yap
_#_Independence: 3 November 1986 (from the US-administered UN
Trusteeship; formerly the Kosrae, Pohnpei, Truk, and Yap districts of the
Trust Territory of the Pacific Islands)
_#_Constitution: 10 May 1979
_#_Legal system: based on adapted Trust Territory laws, acts of the
legislature, municipal, common, and customary laws
_#_National holiday: Proclamation of the Federated States of
Micronesia, 10 May (1979)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: unicameral Congress
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--President Bailey OLTER
(since 11 May 1991); Vice President Jacob NENA (since 11 May 1991)
_#_Political parties and leaders: no formal parties
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 5 March 1991 (next to be held March 1994);
results--Vice President Bailey OLTER elected president;
Congress--last held on 5 March 1991 (next to be
held March 1993);
results--percent of vote NA;
seats--(14 total)
_#_Communists: none
_#_Member of: ESCAP (associate), ICAO, SPC, SPF, UN
_#_Diplomatic representation: Ambassador Jesse B. MAREHALAU;
Embassy at 706 G Street SE, Washington DC 20003; telephone (202)
544-2640;
US--Ambassador Aurelia BRAZEAL; Embassy at address NA, Kolonia
(mailing address is P. O. Box 1286, Pohnpei, Federated States of
Micronesia 96941); telephone 691-320-2187
_#_Flag: light blue with four white five-pointed stars centered; the
stars are arranged in a diamond pattern
_#_Long-form name: none
_#_Type: unincorporated territory of the US administered by the US
Navy, under command of the Barbers Point Naval Air Station in Hawaii and
managed cooperatively by the US Navy and the Fish and Wildlife Service of
the US Department of the Interior as part of the National Wildlife Refuge
System
_#_Diplomatic representation: none (territory of the US)
_#_Flag: the US flag is used
_#_Long-form name: Principality of Monaco
_#_Type: constitutional monarchy
_#_Capital: Monaco
_#_Administrative divisions: 4 quarters (quartiers,
singular--quartier); Fontvieille, La Condamine, Monaco-Ville, Monte-Carlo
_#_Independence: 1419, rule by the House of Grimaldi
_#_Constitution: 17 December 1962
_#_Legal system: based on French law; has not accepted compulsory ICJ
jurisdiction
_#_National holiday: National Day, 19 November
_#_Executive branch: prince, minister of state, Council of Government
(cabinet)
_#_Legislative branch: National Council (Conseil National)
_#_Judicial branch: Supreme Tribunal (Tribunal Supreme)
_#_Leaders:
Chief of State--Prince RAINIER III (since November 1949); Heir
Apparent Prince ALBERT Alexandre Louis Pierre (born 14 March 1958);
Head of Government Minister of State Jean AUSSEIL (since 10
September 1985)
_#_Political parties and leaders:
National and Democratic Union (UND),
Democratic Union Movement (MUD),
Monaco Action,
Monegasque Socialist Party (PSM)
_#_Suffrage: universal adult at age 25
_#_Elections:
National Council--last held on 24 January 1988 (next to be held 24
January 1993);
results--percent of vote by party NA;
seats--(18 total) UND 18
_#_Member of: ACCT, CSCE, ICAO, IMF (observer), IMO, INTELSAT,
INTERPOL, IOC, ITU, LORCS, UN (observer), UNCTAD, UNESCO, UPU, WHO, WIPO
_#_Diplomatic representation: Monaco maintains honorary consulates
general in Boston, Chicago, Los Angeles, New Orleans, New York, and San
Francisco, and honorary consulates in Dallas, Honolulu, Palm Beach,
Philadelphia, and Washington;
US--no mission in Monaco, but the US Consul General in Marseille,
France, is accredited to Monaco; Consul General R. Susan WOOD; Consulate
General at 12 Boulevard Paul Peytral, 13286 Marseille Cedex (mailing
address APO NY 09777); telephone [33] (91) 549-200
_#_Flag: two equal horizontal bands of red (top) and white; similar to
the flag of Indonesia which is longer and the flag of Poland which is
white (top) and red','cb1392aa39cc496fd9435eb813eac0131276890efaef676e5b0f46523ab2013c','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab547332a5163e53720875bfb235065d0b34eba9f73ea462adc9650701da986b',1991,'GD','Grenada','government',122,'_#_Long-form name: none
_#_Type: constitutional monarchy
_#_Capital: Kingstown
_#_Administrative divisions: 6 parishes; Charlotte, Grenadines,
Saint Andrew, Saint David, Saint George, Saint Patrick
_#_Independence: 27 October 1979 (from UK)
_#_Constitution: 27 October 1979
_#_Legal system: based on English common law
_#_National holiday: Independence Day, 27 October (1979)
_#_Executive branch: British monarch, governor general, prime
minister, Cabinet
_#_Legislative branch: unicameral House of Assembly
_#_Judicial branch: Eastern Caribbean Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor General David JACK (since 29 Septermber 1989);
Head of Government--Prime Minister James F. MITCHELL (since 30 July
1984)
_#_Political parties and leaders:
New Democratic Party (NDP), James (Son) MITCHELL;
Saint Vincent Labor Party (SVLP), Vincent BEACH;
United People''s Movement (UPM), Adrian SAUNDERS;
Movement for National Unity (MNU), Ralph GONSALVES;
National Reform Party (NRP), Joel MIGUEL
_#_Suffrage: universal at age 18
_#_Elections:
House of Assembly--last held 16 May 1989
(next to be held July 1994);
results--percent of vote by party NA;
seats--(21 total; 15 elected representatives and 6 appointed senators)
NDP 15
_#_Member of: ACP, C, CARICOM, CDB, ECLAC, FAO, G-77, IBRD, ICAO,
ICFTU, IDA, IFAD, IMF, IMO, INTERPOL, IOC, ITU, LORCS, OAS, OECS,
UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO
_#_Diplomatic representation: none
_#_Flag: three vertical bands of blue (hoist side), gold (double
width), and green; the gold band bears three green diamonds arranged in a
V pattern
_#_Long-form name: Republic of San Marino
_#_Type: republic
_#_Capital: San Marino
_#_Administrative divisions: 9 municipalities (castelli,
singular--castello); Acquaviva, Borgo Maggiore, Chiesanuova, Domagnano,
Faetano, Fiorentino, Monte Giardino, San Marino, Serravalle
_#_Independence: 301 AD (by tradition)
_#_Constitution: 8 October 1600; electoral law of 1926 serves some of
the functions of a constitution
_#_Legal system: based on civil law system with Italian law
influences; has not accepted compulsory ICJ jurisdiction
_#_National holiday: Anniversary of the Foundation of the Republic,
3 September
_#_Executive branch: two captains regent, Congress of State (cabinet);
real executive power is wielded by the secretary of state for foreign
affairs and the secretary of state for internal affairs
_#_Legislative branch: unicameral Great and General Council (Consiglio
Grande e Generale)
_#_Judicial branch: Council of Twelve (Consiglio dei XII)
_#_Leaders:
Co-Chiefs of State--Captain Regent Aldamiro BARTOLINI and
Captain Regent Ottaviano ROSSI (since 1 April 1990);
Head of Government--Prime Minister Gabriele GATTI (since July
1986)
_#_Political parties and leaders:
Christian Democratic Party (DCS), Gabriele GATTI;
San Marino Democratic Progressive Party (PPDS) formerly San Marino
Communist Party (PCS), Gilberto GHIOTTI;
San Marino Socialist Party (PSS), Remy GIACOMINI;
Democratic Movement (MD), Emilio Della BALDA;
San Marino Social Democratic Party (PSDS), Augusto CASALI;
San Marino Republican Party (PRS), Cristoforo BUSCARINI
_#_Suffrage: universal at age 18
_#_Elections:
Grand and General Council--last held 29 May 1988
(next to be held by May 1993);
results--percent of vote by party NA;
seats--(60 total) DCS 27, PCS 18, PSU 8, PSS 7
_#_Communists: about 300 members
_#_Other political parties or pressure groups: political parties
influenced by policies of their counterparts in Italy
_#_Member of: CE, CSCE, ICAO, ICFTU, ILO, IMF (observer), IOC, IOM
(observer), ITU, LORCS, NAM (guest), UN (observer), UNCTAD, UNESCO, UPU,
WHO, WTO
_#_Diplomatic representation: San Marino maintains honorary
Consulates General in Washington and New York, and an honorary Consulate
in Detroit;
US--no mission in San Marino, but the Consul General in Florence
(Italy) is accredited to San Marino; Consulate General at
Lungarno Amerigo Vespucci, 38, 50123 Firenze, Italy (mailing address is
APO New York 09019-0007); telephone [39] (55) 239-8276 through 8279 and
217-605
_#_Flag: two equal horizontal bands of white (top) and light blue
with the national coat of arms superimposed in the center; the coat
of arms has a shield (featuring three towers on three peaks) flanked by a
wreath, below a crown and above a scroll bearing the word LIBERTAS
(Liberty)
_#_Long-form name: Democratic Republic of Sao Tome and Principe
_#_Type: republic
_#_Capital: Sao Tome
_#_Administrative divisions: 2 districts (concelhos,
singular--concelho); Principe, Sao Tome
_#_Independence: 12 July 1975 (from Portugal)
_#_Constitution: 5 November 1975, approved 15 December 1982
_#_Legal system: based on Portuguese law system and customary law; has
not accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 12 July (1975)
_#_Executive branch: president, prime minister, Council of Ministers
(cabinet)
_#_Legislative branch: unicameral People''s National Assembly
(Assembleia Popular Nacional)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Miguel TROVOADA (since 4 April 1991);
Head of Government--Prime Minister Daniel Lima Dos Santos DAIO
(since 21 January 1991)
_#_Political parties and leaders:
Party for Democratic Convergence-Reflection Group (PCD-GR),
Prime Minister Daniel Lima Dos Santos DAIO, secretary general;
Movement for the Liberation of Sao Tome and Principe (MLSTP),
Carlos da GRACIA;
Christian Democratic Front (FDC), Alphonse Dos SANTOS;
Democratic Opposition Coalition (CODO), leader NA; other small parties
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 3 March 1991 (next to be held March
1996);
results--Miguel TROVOADA was elected without opposition in Sao Tome''s
first multiparty presidential election;
National People''s Assembly--last held 20 January 1991 (next to be
held January 1996);
results--PCD-GR 54.4%, MLSTP 30.5%, CODO 5.2%, FDC 1.5%, other 8.3%;
seats--(55 total) PCD-GR 33, MLSTP 21, CODO 1; note--this was the first
National Assembly multiparty election in Sao Tome
_#_Member of: ACP, AfDB, CEEAC, ECA, FAO, G-77, IBRD, ICAO, IDA, IFAD,
ILO, IMF, INTERPOL, ITU, LORCS, NAM, OAU, UN, UNCTAD, UNESCO,
UNIDO, UPU, WHO, WMO, WTO
_#_Diplomatic representation: Ambassador Joaquim Rafael BRANCO;
Chancery (temporary) at 801 Second Avenue, Suite 1504, New York, NY
10017; telephone (212) 697-4211;
US--Ambassador Keith L. WAUCHOPE in Gabon is accredited to Sao
Tome and Principe on a nonresident basis and makes periodic visits to the
islands
_#_Flag: three horizontal bands of green (top), yellow (double
width), and green with two black five-pointed stars placed side by side
in the center of the yellow band and a red isosceles triangle based on
the hoist side; uses the popular pan-African colors of Ethiopia','ffbc88152fc68b7612f0d56729ed4ece284ba575380da92122728e6798d66287','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de1661f2e6d7606f4b7fd60d86c3f47cd9373c6426192941305bb55dfc2be9f7',1991,'SG','Singapore','government',127,'_#_Long-form name: Kingdom of Thailand; under martial law since
military takeover 23 February 1991
_#_Type: constitutional monarchy; under martial law since
military coup of 23 February 1991
_#_Capital: Bangkok
_#_Administrative divisions: 73 provinces (changwat, singular and
plural); Ang Thong, Buriram, Chachoengsao, Chai Nat, Chaiyaphum,
Chanthaburi, Chiang Mai, Chiang Rai, Chon Buri, Chumphon, Kalasin,
Kamphaeng Phet, Kanchanaburi, Khon Kaen, Krabi, Krung Thep Mahanakhon,
Lampang, Lamphun, Loei, Lop Buri, Mae Hong Son, Maha Sarakham, Nakhon
Nayok, Nakhon Pathom, Nakhon Phanom, Nakhon Ratchasima, Nakhon Sawan,
Nakhon Si Thammarat, Nan, Narathiwat, Nong Khai, Nonthaburi, Pathum
Thani, Pattani, Phangnga, Phatthalung, Phayao, Phetchabun, Phetchaburi,
Phichit, Phitsanulok, Phra Nakhon Si Ayutthaya, Phrae, Phuket, Prachin
Buri, Prachuap Khiri Khan, Ranong, Ratchaburi, Rayong, Roi Et, Sakon
Nakhon, Samut Prakan, Samut Sakhon, Samut Songkhram, Sara Buri, Satun,
Sing Buri, Sisaket, Songkhla, Sukhothai, Suphan Buri, Surat Thani, Surin,
Tak, Trang, Trat, Ubon Ratchathani, Udon Thani, Uthai Thani, Uttaradit,
Yala, Yasothon
_#_Independence: 1238 (traditional founding date); never colonized
_#_Constitution: 22 December 1978; interim constitution promulgated
by National Peace-Keeping Council on 1 March 1991
_#_Legal system: based on civil law system, with influences of
common law; has not accepted compulsory ICJ jurisdiction; martial
law in effect since 23 February 1991 military coup
_#_National holiday: Birthday of His Majesty the King, 5 December
(1927)
_#_Executive branch: monarch, interim prime minister, three
interim deputy prime ministers, interim Council of Ministers (cabinet),
Privy Council; following the military coup of 23 February 1991
a National Peace-Keeping Council was set up
_#_Legislative branch: bicameral National Assembly (Rathasatha)
consists of an upper house or Senate (Vuthisatha) and a lower house or
House of Representatives (Saphaphoothan-Rajsadhorn); following the
military coup of 23 February 1991 the National Assembly was dissolved
and a new interim National Legislative Assembly has been formed until
elections are held in April 1992
_#_Judicial branch: Supreme Court (Sarndika)
_#_Leaders:
Chief of State--King PHUMIPHON ADUNLAYADET (since 9 June 1946);
Heir Apparent Crown Prince WACHIRALONGKON (born 28 July 1952);
Head of Government--Interim Prime Minister ANAN Panyarachun
(since 4 March 1991);
Interim Deputy Prime Minister SANO Unakun (since 6 March 1991);
Interim Deputy Prime Minister Police Gen. PHAO Sarasin (since 6 March
1991);
Interim Deputy Prime Minister MICHAI Ruchupan (since 6 March 1991);
National Peace-Keeping Council (ruling junta)--Chairman
Gen. SUNTHON Khongsomphong;
Vice Chairman Gen. SUCHINDA Khraprayun;
Vice Chairman Adm. PRAPHAT Kritsanachan;
Vice Chairman Air Chief Mar. KASET Rotchananin;
Vice Chairman Police Gen. SAWAT Amonwiwat
_#_Political parties and leaders: under martial law political
parties are prohibited from meeting; leaders of several parties have
resigned and other parties are fragmenting; it is unclear which of
the following parties functioning at the time of the military
coup will still be in existence by the time new elections are
held;
Thai Nation Party (TNP);
Solidarity Party;
Thai Citizens Party (TCP);
People''s Party (Ratsadon);
Thai People''s Party;
Social Action Party (SAP);
Democrat Party (DP);
Mass Party;
Force of Truth Party (Phalang Dharma);
People''s Party (Prachachon);
New Aspiration Party;
United Democracy Party;
Liberal Party;
Social Democratic Force
_#_Suffrage: universal at age 21
_#_Elections:
House of Representatives--last held 24 July 1988 (next to be
held by April 1992 for a new National Legislative Assembly according
to the National Peace-Keeping Council);
results--TNP 27%, SAP 15%, DP 13%, TCP 9%, other 36%;
seats--(357 total) TNP 96, Solidarity 62, SAP 53, DP 48, TCP 31,
People''s Party (Ratsadon) 21, Thai People''s Party (Prachachon) 17,
Force of Truth Party (Phalang Dharma) 15, United Democracy Party 5,
Mass Party 5, Liberal 3, Social Democratic Force 1; note--the
House of Representatives was dissolved 23 February 1991; the
new interim National Legislative Assembly has 292 seats with 148 of
the seats held by active and retired military officers
_#_Communists: illegal Communist party has 500 to 1,000 members;
armed Communist insurgents throughout Thailand total 300 to 500
(est.)
_#_Member of: APEC, AsDB, ASEAN, CCC, CP, ESCAP, FAO, G-77, GATT,
IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, IOM, ISO, ITU, LORCS, PCA, UN, UNCTAD, UNESCO,
UNHCR, UNIDO, UPU, WCL, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador-designate PHIRAPHONG
Kasemsi; Embassy at 2300 Kalorama Road NW, Washington DC 20008;
telephone (202) 483-7200; there are Thai Consulates General in Chicago,
Los Angeles, and New York;
US--Ambassador Daniel A. O''DONAHUE; Embassy at 95 Wireless Road,
Bangkok (mailing address is APO San Francisco 96346); telephone [66] (2)
252-504019; there is a US Consulate General in Chiang Mai and Consulates
in Songkhla and Udorn
_#_Flag: five horizontal bands of red (top), white, blue (double
width), white, and red
_#_Long-form name: Republic of Togo
_#_Type: republic; one-party presidential regime
_#_Capital: Lome
_#_Administrative divisions: 21 circumscriptions (circonscriptions,
singular--circonscription); Amlame (Amou), Aneho (Lacs),
Atakpame (Ogou), Badou (Wawa), Bafilo (Assoli), Bassar (Bassari),
Dapaong (Tone), Kante (Keran), Klouto (Kloto), Kpagouda (Binah),
Lama-Kara (Kozah), Lome (Golfe), Mango (Oti), Niamtougou (Doufelgou),
Notse (Haho), Sotouboua, Tabligbo (Yoto), Tchamba, Tchaoudjo,
Tsevie (Zio), Vogan (Vo); note--the 21 units may now be called
prefectures (prefectures, singular--prefecture) and reported name
changes for individual units are included in parentheses
_#_Independence: 27 April 1960 (from UN trusteeship under French
administration, formerly French Togo)
_#_Constitution: 30 December 1979, effective 13 January 1980
_#_Legal system: French-based court system
_#_National holiday: Liberation Day (anniversary of coup), 13 January
(1967)
_#_Executive branch: president, Council of Ministers (cabinet)
_#_Legislative branch: unicameral National Assembly (Assemblee
Nationale)
_#_Judicial branch: Court of Appeal (Cour d''Appel), Supreme Court
(Cour Supreme)
_#_Leaders:
Chief of State--President Gen. Gnassingbe EYADEMA (since 14
April 1967);
Head of Government--interim Prime Minister Kokou KOFFIGOH (since 28
August 1991)
_#_Political parties and leaders: Rally of the Togolese
People (RPT) led by President EYADEMA was the only party until the
formation of multiple parties was legalized 12 April 1991; more than
10 parties formed as of mid-May, though none yet legally registered;
a national conference to determine transition regime took place
10-20 June 1991
_#_Suffrage: universal adult at age NA
_#_Elections:
President--last held 21 December 1986 (next to be held December
1993);
results--Gen. EYADEMA was reelected without opposition;
National Assembly--last held 4 March 1990 (next to be held 14
June 1992);
results--RPT was the only party;
seats--(77 total) RPT 77
_#_Communists: no Communist party
_#_Member of: ACCT, ACP, AfDB, CEAO (observer), ECA, ECOWAS, Entente,
FAO, FZ, G-77, GATT, IBRD, ICAO, ICC, IDA, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, IOC, ITU, LORCS, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO,
UPU, WADB, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Ellom-Kodjo SCHUPPIUS;
Chancery at 2208 Massachusetts Avenue NW, Washington DC 20008;
telephone (202) 234-4212 or 4213;
US--Ambassador Harmon E. KIRBY; Embassy at Rue Pelletier
Caventou and Rue Vauban, Lome (mailing address is B. P. 852, Lome);
telephone [228] 21-29-91 through 94 and 21-77-17
_#_Flag: five equal horizontal bands of green (top and bottom)
alternating with yellow; there is a white five-pointed star on a red
square in the upper hoist-side corner; uses the popular pan-African
colors of Ethiopia','83d2fe3e7a96581b519b4c60eef11eafd8efe3b6fb97bc24aceeb3e0a184683c','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f5f23688c441345f77673077d1cad65dfe7262ee4f99664c237efcd9349e9e7',1991,'WS','Samoa','government',132,'_#_Long-form name: none
_#_Type: territory of New Zealand
_#_Capital: none, each atoll has its own administrative center
_#_Administrative divisions: none (territory of New Zealand)
_#_Independence: none (territory of New Zealand)
_#_Constitution: administered under the Tokelau Islands Act of 1948,
as amended in 1970
_#_Legal system: British and local statutes
_#_National holiday: Waitangi Day (Treaty of Waitangi established
British sovereignty over New Zealand), 6 February (1840)
_#_Executive branch: administrator (appointed by the Minister of
Foreign Affairs in New Zealand), official secretary
_#_Legislative branch: Council of Elders (Taupulega) on each atoll
_#_Judicial branch: High Court in Niue, Supreme Court in New Zealand
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952);
Head of Government--Administrator Neil WALTER; Official Secretary
M. NORRISH, Office of Tokelau Affairs
_#_Suffrage: NA
_#_Elections: NA
_#_Communists: probably none
_#_Member of: SPC
_#_Diplomatic representation: none (territory of New Zealand)
_#_Flag: the flag of New Zealand is used
_#_Long-form name: Kingdom of Tonga
_#_Type: hereditary constitutional monarchy
_#_Capital: Nukualofa
_#_Administrative divisions: three island groups; Haapai, Tongatapu,
Vavau
_#_Independence: 4 June 1970 (from UK; formerly Friendly Islands)
_#_Constitution: 4 November 1875, revised 1 January 1967
_#_Legal system: based on English law
_#_National holiday: Emancipation Day, 4 June (1970)
_#_Executive branch: monarch, prime minister, deputy prime minister,
Council of Ministers (cabinet), Privy Council
_#_Legislative branch: unicameral Legislative Assembly (Fale Alea)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--King Taufa''ahau TUPOU IV (since 16 December 1965);
Head of Government--Prime Minister Prince Fatafehi TU''IPELEHAKE
(since 16 December 1965)
_#_Political parties and leaders: Democratic Reform Movement,
''Akolisi POHIVA
_#_Suffrage: all literate, tax-paying males and all literate females
over 21
_#_Elections:
Legislative Assembly--last held 14-15 February 1990
(next to be held NA February 1993);
results--percent of vote NA;
seats--(29 total, 9 elected) 6 proreform, 3 traditionalist
_#_Communists: none known
_#_Member of: ACP, AsDB, C, ESCAP, FAO, G-77, IBRD, ICAO, IDA, IFAD,
IFC, IMF, INTERPOL, IOC, ITU, LORCS, SPC, SPF, UNCTAD, UNESCO, UNIDO,
UPU, WHO
_#_Diplomatic representation: Ambassador Siosaia a''Ulupekotofa
TUITA resides in London;
US--the US has no offices in Tonga; the Ambassador to Fiji is
accredited to Tonga and makes periodic visits
_#_Flag: red with a bold red cross on a white rectangle in the upper
hoist-side corner
_#_Long-form name: Republic of Trinidad and Tobago
_#_Type: parliamentary democracy
_#_Capital: Port-of-Spain
_#_Administrative divisions: 8 counties, 3 municipalities*, and
1 ward**; Arima*, Caroni, Mayaro, Nariva, Port-of-Spain*, Saint Andrew,
Saint David, Saint George, Saint Patrick, San Fernando*, Tobago**,
Victoria
_#_Independence: 31 August 1962 (from UK)
_#_Constitution: 31 August 1976
_#_Legal system: based on English common law; judicial review of
legislative acts in the Supreme Court; has not accepted compulsory ICJ
jurisdiction
_#_National holiday: Independence Day, 31 August (1962)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: bicameral Parliament consists of an upper
house or Senate and a lower house or House of Representatives
_#_Judicial branch: Court of Appeal, Supreme Court
_#_Leaders:
Chief of State--President Noor Mohammed HASSANALI (since 18 March
1987);
Head of Government--Prime Minister Arthur Napoleon Raymond ROBINSON
(since 18 December 1986)
_#_Political parties and leaders:
National Alliance for Reconstruction (NAR), A. N. R. ROBINSON;
People''s National Movement (PNM), Patrick MANNING;
United National Congress (UNC), Basdeo PANDAY;
Movement for Social Transformation (MOTION), David ABDULLAH
_#_Suffrage: universal at age 18
_#_Elections:
House of Representatives--last held 15 December 1986 (next to be
held by December 1991);
results--NAR 66%, PNM 32%, other 2%;
seats--(36 total) NAR 33, PNM 3; note--in 1989 six members
were expelled from the NAR and formed the UNC, while retaining
their parliamentary seats; as a result seats held are NAR 27,
UNC 6, PNM 3
_#_Communists: Communist Party of Trinidad and Tobago; Trinidad and
Tobago Peace Council, James MILLETTE
_#_Other political pressure groups: National Joint Action Committee
(NJAC), radical antigovernment black-identity organization; Trinidad and
Tobago Peace Council, leftist organization affiliated with the World
Peace Council; Trinidad and Tobago Chamber of Industry and Commerce;
Trinidad and Tobago Labor Congress, moderate labor federation; Council of
Progressive Trade Unions, radical labor federation
_#_Member of: ACP, C, CARICOM, CCC, CDB, ECLAC, FAO, G-24, G-77, GATT,
IADB, IBRD, ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, ISO, ITU, LAES, LORCS, NAM, OAS, OPANAL, UN, UNCTAD,
UNESCO, UNIDO, UPU, WFTU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Angus Albert KHAN; Chancery
at 1708 Massachusetts Avenue NW, Washington DC 20036; telephone
(202) 467-6490; Trinidad and Tobago has a Consulate General in New York;
US--Ambassador Charles A. GARGANO; Embassy at 15 Queen''s Park West,
Port-of-Spain (mailing address is P. O. Box 752, Port-of-Spain);
telephone (809) 622-6372 through 6376, 6176
_#_Flag: red with a white-edged black diagonal band from the upper
hoist side
_#_Long-form name: none
_#_Type: French possession administered by Commissioner of the
Republic Daniel CONSTANTIN, resident in Reunion
_#_Long-form name: Republic of Tunisia; note--may be changed to
Tunisian Republic
_#_Type: republic
_#_Capital: Tunis
_#_Administrative divisions: 23 governorates (wilayat,
singular--wilayah); Al Kaf, Al Mahdiyah, Al Munastir,
Al Qasrayn, Al Qayrawan, Aryanah, Bajah, Banzart,
Bin Arus, Jundubah, Madanin, Nabul, Qabis, Qafsah,
Qibili, Safaqis, Sidi Bu Zayd, Silyanah, Susah,
Tatawin, Tawzar, Tunis, Zaghwan
_#_Independence: 20 March 1956 (from France)
_#_Constitution: 1 June 1959
_#_Legal system: based on French civil law system and Islamic law;
some judicial review of legislative acts in the Supreme Court in joint
session
_#_National holiday: National Day, 20 March (1956)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: unicameral Chamber of Deputies (Majlis
al-Nuwaab)
_#_Judicial branch: Court of Cassation (Cour de Cassation)
_#_Leaders:
Chief of State--President Gen. Zine el Abidine BEN ALI
(since 7 November 1987);
Head of Government--Prime Minister Hamed KAROUI (since 26 September
1989)
_#_Political parties and leaders:
Constitutional Democratic Rally Party (RCD), President BEN ALI (official
ruling party);
Movement of Democratic Socialists (MDS), Ahmed Mestiri;
five other political parties are legal, including the Communist Party
_#_Suffrage: universal at age 20
_#_Elections:
President--last held 2 April 1989 (next to be held April 1994);
results--Gen. Zine el Abidine BEN ALI was reelected without opposition;
Chamber of Deputies--last held 2 April 1989
(next to be held April 1994);
results--RCD 80.7%, independents/Islamists 13.7%, MDS 3.2%, other 2.4%;
seats--(141 total) RCD 141
_#_Communists: a small number of nominal Communists, mostly students
_#_Member of: ABEDA, ACCT, AfDB, AFESD, AL, AMF, AMU, CCC, ECA, FAO,
G-77, GATT, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IDB, IFAD, IFC, ILO, IMF,
IMO, INMARSAT, INTELSAT, INTERPOL, IOC, ISO, ITU, LORCS, NAM,
OAU, OIC, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador-designate Habib LAZREG;
Chancery at 1515 Massachusetts Avenue NW, Washington DC 20005;
telephone (202) 862-1850;
US--Ambassador Robert H. PELLETREAU, Jr.; Embassy at
144 Avenue de la Liberte, 1002 Tunis-Belvedere; telephone [216] (1)
782-566
_#_Flag: red with a white disk in the center bearing a red crescent
nearly encircling a red five-pointed star; the crescent and star are
traditional symbols of Islam','d8884e5a190ab10d5bba2e158c6a9ba2b0732bf26c3738dd03f8288653e47589','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfdc52145c4d3c36b95f5971c80e56c18c1856e0354e9092ced9dccdf7d1856a',1991,'DZ','Algeria','government',140,'_#_Long-form name: Republic of Turkey
_#_Type: republican parliamentary democracy
_#_Capital: Ankara
_#_Administrative divisions: 73 provinces (iller, singular--il);
Adana, Adiyaman, Afyon, Agri, Aksaray, Amasya, Ankara, Antalya,
Artvin, Aydin, Balikesir, Batman, Bayburt, Bilecik, Bingol, Bitlis,
Bolu, Burdur, Bursa, Canakkale, Cankiri, Corum, Denizli,
Diyarbakir, Edirne, Elazig, Erzincan, Erzurum, Eskisehir, Gaziantep,
Giresun, Gumushane, Hakkari, Hatay, Icel, Isparta,
Istanbul, Izmir, Kahraman Maras, Karaman, Kars, Kastamonu,
Kayseri, Kirikkale, Kirklareli, Kirsehir, Kocaeli, Konya, Kutahya,
Malatya, Manisa, Mardin, Mugla, Mus, Nevsehir, Nigde, Ordu,
Rize, Sakarya, Samsun, Siirt, Sinop, Sirnak, Sivas, Tekirdag, Tokat,
Trabzon, Tunceli, Urfa, Usak, Van, Yozgat, Zonguldak
_#_Independence: 29 October 1923 (successor state to the Ottoman
Empire)
_#_Constitution: 7 November 1982
_#_Legal system: derived from various continental legal systems;
accepts compulsory ICJ jurisdiction, with reservations
_#_National holiday: Anniversary of the Declaration of the Republic,
29 October (1923)
_#_Executive branch: president, Presidential Council, prime minister,
deputy prime minister, Cabinet
_#_Legislative branch: unicameral Grand National Assembly (Buyuk
Millet Meclisi)
_#_Judicial branch: Court of Cassation
_#_Leaders:
Chief of State--President Turgut OZAL (since 9 November 1989);
Head of Government--Prime Minister Mesut YILMAZ (since 30
June 1991); Deputy Prime Minister Ekrem PAKDAMIRLI (since 30 June
1991)
_#_Political parties and leaders:
Motherland Party (ANAP), Mesut YILMAZ;
Social Democratic People''s Party (SHP), Erdal INONU;
Correct Way Party (DYP), Suleyman DEMIREL;
People''s Labor Party (HEP), Fehmi ISIKLAR;
Socialist Unity Party (SBP), leader NA;
Democratic Center Party (DMP), Bedrettin DALAN;
Great Anatolia Party (BAP), leader NA;
Democratic Left Party (DSP), Bulent ECEVIT;
Refah Party (RP), Necmettin ERBAKAN;
Democratic Center Party (DSP), Bedrettin DALAN;
Grand National Party (GNP), leader NA
_#_Suffrage: universal at age 21
_#_Elections:
Grand National Assembly--last held 29 November 1987
(next to be held November 1992);
results--ANAP 36%, SHP 25%, DYP 19%, other 20%;
seats--(450 total) ANAP 275, SHP 82, DYP 60, HEP 9, SBP 4,
DMP 2, BAP 1, independent 6, vacant 11
_#_Communists: strength and support negligible
_#_Member of: AsDB, BIS, CCC, CE, CERN (observer), COCOM, CSCE, EBRD,
ECE, FAO, GATT, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IDB, IEA, IFAD, IFC,
ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, IOM (observer), ISO, ITU, LORCS,
NATO, NEA, OECD, OIC, PCA, UN, UNCTAD, UNESCO, UNHCR, UNIDO,
UNIIMOG, UNRWA, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Nuzhet KANDEMIR; Chancery at
1606 23rd Street NW, Washington DC 20008; telephone (202) 387-3200;
there are Turkish Consulates General in Chicago, Houston, Los Angeles,
and New York;
US--Ambassador Morton ABRAMOWITZ; Embassy at 110 Ataturk Boulevard,
Ankara (mailing address is APO New York 09257-0006);
telephone [90] (4) 126 54 70; there are US Consulates General in
Istanbul and Izmir, and a Consulate in Adana
_#_Flag: red with a vertical white crescent (the closed portion is
toward the hoist side) and white five-pointed star centered just outside
the crescent opening
_#_Long-form name: none
_#_Type: dependent territory of the UK
_#_Capital: Grand Turk (Cockburn Town)
_#_Administrative divisions: none (dependent territory of the UK)
_#_Independence: none (dependent territory of the UK)
_#_Constitution: introduced 30 August 1976, suspended in 1986, and a
Constitutional Commission is currently reviewing its contents
_#_Legal system: based on laws of England and Wales with a small
number adopted from Jamaica and The Bahamas
_#_National holiday: Constitution Day, 30 August (1976)
_#_Executive branch: British monarch, governor, Executive Council
_#_Legislative branch: unicameral Legislative Council
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1953),
represented by Governor Michael J. BRADLEY (since 1987);
Head of Government--Chief Minister Oswald O. SKIPPINGS (since
3 March 1988)
_#_Political parties and leaders:
People''s Democratic Movement (PDM), Oswald SKIPPINGS;
Progressive National Party (PNP), Dan MALCOLM and Norman SAUNDERS;
National Democratic Alliance (NDA), Ariel MISSICK
_#_Suffrage: universal at age 18
_#_Elections:
Legislative Council--last held on 3 March 1988
(next to be held NA);
results--PDM 60%, PNP 30%, other 10%;
seats--(20 total, 13 elected) PDM 11, PNP 2
_#_Communists: none
_#_Member of: CDB
_#_Diplomatic representation: as a dependent territory of the UK, the
interests of the Turks and Caicos Islands are represented in the US by
the UK;
US--none
_#_Flag: blue with the flag of the UK in the upper hoist-side
quadrant and the colonial shield centered on the outer half of the flag;
the shield is yellow and contains a conch shell, lobster, and cactus
_#_Long-form name: none
_#_Type: democracy
_#_Capital: Funafuti
_#_Administrative divisions: none
_#_Independence: 1 October 1978 (from UK; formerly Ellice Islands)
_#_Constitution: 1 October 1978
_#_National holiday: Independence Day, 1 October (1978)
_#_Executive branch: British monarch, governor general, prime
minister, deputy prime minister, Cabinet
_#_Legislative branch: unicameral Parliament (Palamene)
_#_Judicial branch: High Court
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952),
represented by Governor General Tupua LEUPENA (since 1 March 1986);
Head of Government--Prime Minister Bikenibeu PAENIU (since 16
October 1989); Deputy Prime Minister Dr. Alesana SELUKA (since October
1989)
_#_Political parties and leaders: none
_#_Suffrage: universal at age 18
_#_Elections:
Parliament--last held 28 September 1989 (next to be held by
September 1993);
results--percent of vote NA;
seats--(12 total)
_#_Member of: ACP, C (special), ESCAP, SPC, SPF, UPU
_#_Diplomatic representation: Ambassador (vacant);
US--none
_#_Flag: light blue with the flag of the UK in the upper hoist-side
quadrant; the outer half of the flag represents a map of the country with
nine yellow five-pointed stars symbolizing the nine islands
_#_Long-form name: Republic of Uganda
_#_Type: republic
_#_Capital: Kampala
_#_Administrative divisions: 10 provinces; Busoga, Central, Eastern,
Karamoja, Nile, North Buganda, Northern, South Buganda, Southern, Western
_#_Independence: 9 October 1962 (from UK)
_#_Constitution: 8 September 1967, in process of constitutional
revision
_#_Legal system: government plans to restore system based on English
common law and customary law and reinstitute a normal judicial system;
accepts compulsory ICJ jurisdiction, with reservations
_#_National holiday: Independence Day, 9 October (1962)
_#_Executive branch: president, prime minister, three deputy prime
ministers, Cabinet
_#_Legislative branch: unicameral National Resistance Council
_#_Judicial branch: Court of Appeal, High Court
_#_Leaders:
Chief of State--President Lt. Gen. Yoweri Kaguta MUSEVENI (since
29 January 1986); Vice President Samson Babi Mululu KISEKKA (since
NA January 1991);
Head of Government--Prime Minister George Cosmas ADYEBO (since NA
January 1991)
_#_Political parties and leaders: only party--National Resistance
Movement (NRM); note--the Uganda Patriotic Movement (UPM), Ugandan
People''s Congress (UPC), Democratic Party (DP), and Conservative Party
(CP) are all proscribed from conducting public political activities
_#_Suffrage: universal at age 18
_#_Elections:
National Resistance Council--last held 11-28 February 1989
(next to be held after January 1995);
results--NRM is the only party;
seats--(278 total, 210 indirectly elected) 210 members elected
without party affiliation
_#_Other political parties or pressure groups:
Uganda People''s Front (UPF),
Uganda People''s Christian Democratic Army (UPCDA),
Ruwenzori Movement
_#_Communists: possibly a few sympathizers
_#_Member of: ACP, AfDB, C, CCC, EADB, ECA, FAO, G-77, GATT, IAEA,
IBRD, ICAO, ICFTU, IDA, IDB, IFAD, IFC, IGADD, ILO, IMF, INTELSAT,
INTERPOL, IOC, ITU, LORCS, NAM, OAU, OIC, PCA, UN, UNCTAD,
UNESCO, UNHCR, UNIDO, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Stephen Kapimpina
KATENTA-APULI; 5909 16th Street NW, Washington DC 20011; telephone (202)
726-7100 through 7102;
US--Ambassador James CARSON; Embassy at Parliament
Avenue, Kampala (mailing address is P. O. Box 7007, Kampala); telephone
[256] (41) 259792, 259793, 259795
_#_Flag: six equal horizonal bands of black (top), yellow, red, black,
yellow, and red; a white disk is superimposed at the center and depicts
a red-crested crane (the national symbol) facing the staff side
_#_Long-form name: United Arab Emirates (no short-form name);
abbreviated UAE
_#_Type: federation with specified powers delegated to the UAE central
government and other powers reserved to member emirates
_#_Capital: Abu Dhabi
_#_Administrative divisions: 7 emirates (imarat,
singular--imarah); Abu Zaby (Abu Dhabi), Ajman, Al Fujayrah,
Ash Shariqah, Dubayy, Ras al Khaymah, Umm al Qaywayn
_#_Independence: 2 December 1971 (from UK; formerly Trucial States)
_#_Constitution: 2 December 1971 (provisional)
_#_Legal system: secular codes are being introduced by the UAE
Government and in several member shaykhdoms; Islamic law remains
influential
_#_National holiday: National Day, 2 December (1971)
_#_Executive branch: president, vice president, Supreme Council of
Rulers, prime minister, Council of Ministers
_#_Legislative branch: unicameral Federal National Council (Majlis
Watani Itihad)
_#_Judicial branch: Union Supreme Court
_#_Leaders:
Chief of State--President Shaykh Zayid bin Sultan Al NUHAYYAN,
(since 2 December 1971), ruler of Abu Dhabi;
Vice President Shaykh Maktum bin Rashid al-MAKTUM (since 8 October 1990),
ruler of Dubayy;
Head of Government--Prime Minister Shaykh Maktum bin Rashid
al-MAKTUM (since 8 October 1990), ruler of Dubayy;
Deputy Prime Minister Sultan bin Zayid Al NUHAYYAN (since 20 November
1990)
_#_Political parties and leaders: none
_#_Suffrage: none
_#_Elections: none
_#_Communists: NA
_#_Other political or pressure groups: a few small clandestine
groups are active
_#_Member of: ABEDA, AFESD, AL, AMF, CAEU, CCC, ESCWA, FAO, G-77,
GCC, IAEA, IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, ISO (correspondent), ITU, LORCS, NAM, OAPEC,
OIC, OPEC, UN, UNCTAD, UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Abdullah bin Zayid
Al NUHAYYAN; Chancery at Suite 740, 600 New Hampshire Avenue NW,
Washington DC 20037; telephone (202) 338-6500;
US--Ambassador Edward S. WALKER, Jr.; Embassy at Al-Sudan Street,
Abu Dhabi (mailing address is P. O. Box 4009, Abu Dhabi); telephone [971]
(2) 336691; there is a US Consulate General in Dubayy (Dubai)
_#_Flag: three equal horizontal bands of green (top), white, and black
with a thicker vertical red band on the hoist side
_#_Long-form name: United Kingdom of Great Britain and Northern
Ireland; abbreviated UK
_#_Type: constitutional monarchy
_#_Capital: London
_#_Administrative divisions: 47 counties, 7 metropolitan counties,
26 districts, 9 regions, and 3 islands areas;
England--39 counties, 7 metropolitan counties*; Avon, Bedford,
Berkshire, Buckingham, Cambridge, Cheshire, Cleveland, Cornwall, Cumbria,
Derby, Devon, Dorset, Durham, East Sussex, Essex, Gloucester, Greater
London*, Greater Manchester*, Hampshire, Hereford and Worcester,
Hertford, Humberside, Isle of Wight, Kent, Lancashire, Leicester,
Lincoln, Merseyside*, Norfolk, Northampton, Northumberland,
North Yorkshire, Nottingham, Oxford, Shropshire, Somerset, South
Yorkshire*, Stafford, Suffolk, Surrey, Tyne and Wear*, Warwick, West
Midlands*, West Sussex, West Yorkshire*, Wiltshire;
Northern Ireland--26 districts; Antrim, Ards, Armagh, Ballymena,
Ballymoney, Banbridge, Belfast, Carrickfergus, Castlereagh, Coleraine,
Cookstown, Craigavon, Down, Dungannon, Fermanagh, Larne, Limavady,
Lisburn, Londonderry, Magherafelt, Moyle, Newry and Mourne, Newtownabbey,
North Down, Omagh, Strabane;
Scotland--9 regions, 3 islands areas*; Borders, Central, Dumfries
and Galloway, Fife, Grampian, Highland, Lothian, Orkney*, Shetland*,
Strathclyde, Tayside, Western Isles*;
Wales--8 counties; Clwyd, Dyfed, Gwent, Gwynedd, Mid Glamorgan,
Powys, South Glamorgan, West Glamorgan
_#_Independence: 1 January 1801, United Kingdom established
_#_Constitution: unwritten; partly statutes, partly common law and
practice
_#_Dependent areas: Anguilla, Bermuda, British Indian Ocean Territory,
British Virgin Islands, Cayman Islands, Falkland Islands, Gibraltar,
Guernsey, Hong Kong (scheduled to become a Special Administrative Region
of China in 1997), Jersey, Isle of Man, Montserrat, Pitcairn Islands,
Saint Helena, South Georgia and the South Sandwich Islands, Turks and
Caicos Islands
_#_Legal system: common law tradition with early Roman and modern
continental influences; no judicial review of Acts of Parliament; accepts
compulsory ICJ jurisdiction, with reservations
_#_National holiday: Celebration of the Birthday of the Queen (second
Saturday in June), 10 June 1989
_#_Executive branch: monarch, prime minister, Cabinet
_#_Legislative branch: bicameral Parliament consists of an upper
house or House of Lords and a lower house or House of Commons
_#_Judicial branch: House of Lords
_#_Leaders:
Chief of State--Queen ELIZABETH II (since 6 February 1952);
Heir Apparent Prince CHARLES (son of the Queen, born 14 November 1948);
Head of Government--Prime Minister John MAJOR (since 28 November
1990)
_#_Political parties and leaders:
Conservative and Unionist Party, John MAJOR;
Labor Party, Neil KINNOCK;
Social and Liberal Democratic Party (SLDP; formed from the merger of the
Liberal Party and the Social Democratic Party), Jeremy (Paddy) ASHDOWN;
Scottish National Party, Alex SALMOND;
Welsh National Party (Plaid Cymru), Dafydd THOMAS;
Ulster Unionist Party (Northern Ireland), James MOLYNEAUX;
Democratic Unionist Party (Northern Ireland), Rev. Ian PAISLEY;
Ulster Popular Unionist Party (Northern Ireland), James KILFEDDER;
Social Democratic and Labor Party (SDLP, Northern Ireland), John HUME;
Sinn Fein (Northern Ireland), Gerry ADAMS;
Alliance Party (Northern Ireland), John ALDERDICE;
Communist Party, Nina TEMPLE
_#_Suffrage: universal at age 18
_#_Elections:
House of Commons--last held 11 June 1987 (next to be held
by June 1992);
results--Conservative 43%, Labor 32%, Liberal/Social Democratic
23%, other 2%;
seats--(650 total) Conservative 376, Labor 228,
Liberal/Social Democratic 22,
Ulster Unionist (Northern Ireland) 9,
Scottish National 4,
Welsh National 3,
Democratic Unionist (Northern Ireland) 3,
Social Democratic and Labor (Northern Ireland) 3,
Ulster Popular Unionist (Northern Ireland) 1,
Sinn Fein (Northern Ireland) 1;
note--the Liberal Party and the Social Democratic Party merged
to become the Social and Liberal Democratic Party in 1988
_#_Communists: 15,961
_#_Other political or pressure groups: Trades Union Congress,
Confederation of British Industry, National Farmers'' Union, Campaign for
Nuclear Disarmament
_#_Member of: AfDB, AG (observer), AsDB, BIS, C,
CCC, CDB, CE, CERN, COCOM, CP, CSCE, EBRD, EC, ECA (associate), ECE,
ECLAC, EIB, ESCAP, ESA, FAO, G-5, G-7, G-10, GATT, IADB, IAEA, IBRD,
ICAO, ICC, ICFTU, IDA, IEA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT,
INTERPOL, IOC, IOM (observer), ISO, ITU, LORCS, NATO, NEA, OECD,
PCA, SPC, UN, UNCTAD, UNFICYP, UNHCR, UNIDO, UNRWA, UN Security Council,
UN Trusteeship Council, UPU, WCL, WEU, WHO, WIPO, WMO
_#_Diplomatic representation: Ambassador Sir Antony ACLAND; Chancery
at 3100 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
462-1340; there are British Consulates General in Atlanta, Boston,
Chicago, Cleveland, Houston, Los Angeles, New York, and San Francisco,
and Consulates in Dallas, Miami, and Seattle;
US--Ambassador Raymond SEITZ; Embassy at 24/31 Grosvenor Square,
London, W.1A1AE, (mailing address is FPO New York 09509);
telephone [44] (71) 499-9000; there are US Consulates General in Belfast
and Edinburgh
_#_Flag: blue with the red cross of Saint George (patron saint of
England) edged in white superimposed on the diagonal red cross of
Saint Patrick (patron saint of Ireland) which is superimposed on the
diagonal white cross of Saint Andrew (patron saint of Scotland); known as
the Union Flag or Union Jack; the design and colors (especially the
Blue Ensign) have been the basis for a number of other flags including
dependencies, Commonwealth countries, and others
_#_Long-form name: United States of America; abbreviated US or USA
_#_Type: federal republic; strong democratic tradition
_#_Capital: Washington, DC
_#_Administrative divisions: 50 states and 1 district*; Alabama,
Alaska, Arizona, Arkansas, California, Colorado, Connecticut, Delaware,
District of Columbia*, Florida, Georgia, Hawaii, Idaho, Illinois,
Indiana, Iowa, Kansas, Kentucky, Louisiana, Maine, Maryland,
Massachusetts, Michigan, Minnesota, Mississippi, Missouri, Montana,
Nebraska, Nevada, New Hampshire, New Jersey, New Mexico, New York, North
Carolina, North Dakota, Ohio, Oklahoma, Oregon, Pennsylvania, Rhode
Island, South Carolina, South Dakota, Tennessee, Texas, Utah, Vermont,
Virginia, Washington, West Virginia, Wisconsin, Wyoming
_#_Independence: 4 July 1776 (from England)
_#_Constitution: 17 September 1787, effective 4 June 1789
_#_Dependent areas: American Samoa, Baker Island, Guam, Howland
Island; Jarvis Island, Johnston Atoll, Kingman Reef, Midway Islands,
Navassa Island, Northern Mariana Islands, Palmyra Atoll, Puerto Rico,
Virgin Islands, Wake Island.
Since 18 July 1947, the US has administered the Trust Territory of the
Pacific Islands, but recently entered into a new political relationship
with three of the four political units. The Northern Mariana Islands is
a Commonwealth associated with the US (effective 3 November 1986). Palau
concluded a Compact of Free Association with the US that was approved by
the US Congress but to date the Compact process has not been completed in
Palau, which continues to be administered by the US as the Trust
Territory of the Pacific Islands. The Federated States of Micronesia
signed a Compact of Free Association with the US (effective 3 November
1986). The Republic of the Marshall Islands signed a Compact of Free
Association with the US (effective 21 October 1986).
_#_Legal system: based on English common law; judicial review of
legislative acts; accepts compulsory ICJ jurisdiction, with reservations
_#_National holiday: Independence Day, 4 July (1776)
_#_Executive branch: president, vice president, Cabinet
_#_Legislative branch: bicameral Congress consists of an upper house
or Senate and a lower house or House of Representatives
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--President George BUSH
(since 20 January 1989); Vice President Dan QUAYLE (since
20 January 1989)
_#_Political parties and leaders:
Republican Party, Clayton YEUTTER, national committee chairman; Jeanie
AUSTIN, co-chairman;
Democratic Party, Ronald H. BROWN, national committee chairman;
several other groups or parties of minor political significance
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 8 November 1988
(next to be held 3 November 1992);
results--George BUSH (Republican Party) 53.37%,
Michael DUKAKIS (Democratic Party) 45.67%, other 0.96%;
Senate--last held 6 November 1990
(next to be held 3 November 1992);
results--Democratic Party 51%, Republican Party 47%, other 2%;
seats--(100 total) Democratic Party 56, Republican Party 44;
House of Representatives--last held 6 November 1990
(next to be held 3 November 1992);
results--Democratic Party 52%, Republican Party 44%, other 4%;
seats--(435 total) Democratic Party 267, Republican Party 167,
Socialist 1
_#_Communists: Communist Party (claimed 15,000-20,000 members), Gus
HALL, general secretary; Socialist Workers Party (claimed 1,800 members),
Jack BARNES, national secretary
_#_Member of: AfDB, AG (observer), ANZUS, APEC, AsDB, BIS,
CCC, COCOM, CP, CSCE, EBRD, ECE, ECLAC, FAO, ESCAP, G-2, G-5, G-7, G-8,
G-10, GATT, IADB, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IEA, IFAD, IFC, ILO,
IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC, IOM, ISO, ITU, LORCS,
NATO, NEA, OAS, OECD, PCA, SPC, UN, UNCTAD, UNHCR, UNIDO, UNRWA, UN
Security Council, UN Trusteeship Council, UNTSO, UPU, WCL, WHO, WIPO,
WMO, WTO
_#_Diplomatic representation: US Representative to the UN,
Ambassador Thomas R. PICKERING; Mission at 799 United Nations Plaza,
New York, NY 10017; telephone (212) 415-4444 (afternoon hours)
_#_Flag: thirteen equal horizontal stripes of red (top and bottom)
alternating with white; there is a blue rectangle in the upper hoist-side
corner bearing 50 small white five-pointed stars arranged in nine offset
horizontal rows of six stars (top and bottom) alternating with rows of
five stars; the 50 stars represent the 50 states, the 13 stripes
represent the 13 original colonies; known as Old Glory; the design and
colors have been the basis for a number of other flags including Chile,
Liberia, Malaysia, and Puerto Rico
_#_Long-form name: Oriental Republic of Uruguay
_#_Type: republic
_#_Capital: Montevideo
_#_Administrative divisions: 19 departments (departamentos,
singular--departamento); Artigas, Canelones, Cerro Largo, Colonia,
Durazno, Flores, Florida, Lavalleja, Maldonado, Montevideo, Paysandu,
Rio Negro, Rivera, Rocha, Salto, San Jose, Soriano, Tacuarembo,
Treinta y Tres
_#_Independence: 25 August 1828 (from Brazil)
_#_Constitution: 27 November 1966, effective February 1967, suspended
27 June 1973, new constitution rejected by referendum 30 November 1980
_#_Legal system: based on Spanish civil law system; accepts compulsory
ICJ jurisdiction
_#_National holiday: Independence Day, 25 August (1828)
_#_Executive branch: president, vice president, Council of Ministers
(cabinet)
_#_Legislative branch: bicameral General Assembly (Asamblea General)
consists of an upper chamber or Chamber of Senators (Camara de
Senadores) and a lower chamber or Chamber of Representatives (Camera de
Representantes)
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--President Luis Alberto
LACALLE (since 1 March 1990); Vice President Gonzalo AGUIRRE (since
1 March 1990)
_#_Political parties and leaders:
National (Blanco) Party, Luis Alberto LACALLE Herrera;
Colorado Party, Jorge BATLLE Ibanez;
Broad Front Coalition, Liber SEREGNI Mosquera--includes Communist Party
led by Jaime PEREZ
and National Liberation Movement (MLN) or Tupamaros led by Eleuterio
FERNANDEZ Huidobro;
New Space Coalition consists of the Party of the Government
of the People (PGP), Hugo BATALLA;
Christian Democratic Party (PDC), Hector LESCANO;
and Civic Union, Humberto CIGANDA
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
President--last held 26 November 1989 (next to be held November
1994);
results--Luis Alberto LACALLE Herrera (Blanco) 37%, Jorge BATLLE
Ibanez (Colorado) 29%, Liber SEREGNI Mosquera (Broad Front) 20%;
Chamber of Senators--last held 26 November 1989 (next to be held
November 1994);
results--Blanco 40%, Colorado 30%, Broad Front 23% New Space 7%;
seats--(30 total) Blanco 12, Colorado 9, Broad Front 7, New Space 2;
Chamber of Representatives--last held NA November 1989 (next to
be held November 1994);
results--Blanco 39%, Colorado 30%, Broad Front 22%, New Space 8%, other
1%;
seats--(99 total) number of seats by party NA
_#_Communists: 50,000
_#_Member of: AG (observer), CCC, ECLAC, FAO, G-11, G-77, GATT, IADB,
IAEA, IBRD, ICAO, ICC, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC,
IOM, ISO (correspondent), ITU, LAES, LAIA, LORCS, NAM
(observer), OAS, OPANAL, PCA, RG, UN, UNCTAD, UNESCO, UNIDO, UNIIMOG,
UNMOGIP, UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Eduardo MACGILLICUDDEY;
Chancery at 19','a6a35b6ea7279a6912abcbbd6a04bea592be465dae080f5d7b85fad6806fa5f2','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb5a98fc7572179f08f1f27e919c3a327240b5709da8558e142d35dcf0cdb91b',1991,'DZ','Algeria','government',141,'18 F Street NW, Washington DC 20006; telephone (202)
331-1313 through 1316; there are Uruguayan Consulates General in Los
Angeles, Miami, and New York, and a Consulate in New Orleans;
US--Ambassador Richard C. BROWN; Embassy at Lauro Muller 1776,
Montevideo (mailing address is APO Miami 34035); telephone [598] (2)
23-60-61
_#_Flag: nine equal horizontal stripes of white (top and bottom)
alternating with blue; there is a white square in the upper hoist-side
corner with a yellow sun bearing a human face known as the Sun of May
and 16 rays alternately triangular and wavy
_#_Long-form name: Republic of Vanuatu
_#_Type: republic
_#_Capital: Port-Vila
_#_Administrative divisions: 11 island councils; Ambrym, Aoba/Maewo,
Banks/Torres, Efate, Epi, Malakula, Paama, Pentecote, Santo/Malo,
Shepherd, Tafea
_#_Independence: 30 July 1980 (from France and UK; formerly New
Hebrides)
_#_Constitution: 30 July 1980
_#_Legal system: unified system being created from former dual French
and British systems
_#_National holiday: Independence Day, 30 July (1980)
_#_Executive branch: president, prime minister, Council of Ministers
(cabinet)
_#_Legislative branch: unicameral Parliament; note--the National
Council of Chiefs advises on matters of custom and land
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Frederick TIMAKATA (since 30 January
1989);
Head of Government--Prime Minister Father Walter Hadye LINI (since
30 July 1980); Deputy Prime Minister (vacant)
_#_Political parties and leaders:
National Party (Vanua''aku Pati), Donald KALPOKAS;
Union of Moderate Parties, Maxine CARLOT;
Melanesian Progressive Party, Barak SOPE
_#_Suffrage: universal at age 18
_#_Elections:
Parliament--last held 30 November 1987 (next to be held
by November 1991); byelections were held in December 1988 to fill
vacancies resulting from the expulsion of opposition members for
boycotting sessions; results--percent of vote by party NA;
seats--(46 total)
National Party 26, Union of Moderate Parties 19, independent 1
_#_Member of: ACCT, ACP, AsDB, C, ESCAP, FAO, G-77, IBRD, ICAO,
ICFTU, IDA, IFC, IMF, IMO, IOC, ITU, NAM, SPC, SPF, UN, UNCTAD, UNIDO,
UPU, WFTU, WHO, WMO
_#_Diplomatic representation: Vanuatu does not have a mission in
Washington;
US--the ambassador in Papua New Guinea is accredited to Vanuatu
_#_Flag: two equal horizontal bands of red (top) and green (bottom)
with a black isosceles triangle (based on the hoist side) all separated
by a black-edged yellow stripe in the shape of a horizontal Y (the
two points of the Y face the hoist side and enclose the triangle);
centered in the triangle is a boar''s tusk encircling two crossed
namele leaves, all in yellow
_#_Long-form name: State of the Vatican City; note--the Vatican City
is the physical seat of the Holy See, which is the central government of
the Roman Catholic Church
_#_Type: monarchical-sacerdotal state
_#_Capital: Vatican City
_#_Independence: 11 February 1929 (from Italy)
_#_Constitution: Apostolic Constitution of 1967 (effective 1 March
1968)
_#_National holiday: Installation Day of the Pope (John Paul II),
22 October (1978); note--Pope John Paul II was elected on 16 October 1978
_#_Executive branch: pope
_#_Legislative branch: unicameral Pontifical Commission
_#_Judicial branch: none; normally handled by Italy
_#_Leaders:
Chief of State--Pope JOHN PAUL II (Karol WOJTYLA; since 16
October 1978);
Head of Government--Secretary of State Archbishop Angelo SODANO
_#_Political parties and leaders: none
_#_Suffrage: limited to cardinals less than 80 years old
_#_Elections:
Pope--last held 16 October 1978 (next to be held after the death of
the current pope);
results--Karol WOJTYlA was elected for life by the College of Cardinals
_#_Communists: NA
_#_Other political or pressure groups: none (exclusive of influence
exercised by church officers)
_#_Member of: CSCE, IAEA, ICFTU, IMF (observer), INTELSAT, IOM
(observer), ITU, OAS (observer), UN (observer), UNCTAD, UNHCR, UPU,
WIPO, WTO (observer)
_#_Diplomatic representation: Apostolic Pro-Nuncio Archbishop
Agostino CACCIAVILLAN; 3339 Massachusetts Avenue NW, Washington DC 20008;
telephone (202) 333-7121;
US--Ambassador Thomas P. MELADY; Embassy at Villino Pacelli,
Via Aurelia 294, 00165 Rome (mailing address is APO New York 09794);
telephone [396] 639-0558
_#_Flag: two vertical bands of yellow (hoist side) and white with
the crossed keys of Saint Peter and the papal tiara centered in the white
band','b2a87b3c0ca1fb55b16558795b2a4fc473abc682f2287fe28bb45418707cd4f6','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca4d847358e1751ff2a8ecc68f4bfe3147c739cc2b942c4f834332be27a9aef3',1991,'IT','Italy','government',145,'_#_Long-form name: Republic of Venezuela
_#_Type: republic
_#_Capital: Caracas
_#_Administrative divisions: 20 states (estados, singular--estado),
2 territories* (territorios, singular--territorio), 1 federal district**
(distrito federal), and 1 federal dependence*** (dependencia federal);
Amazonas*, Anzoategui, Apure, Aragua, Barinas, Bolivar, Carabobo,
Cojedes, Delta Amacuro*, Dependencias Federales***, Distrito Federal**,
Falcon, Guarico, Lara, Merida, Miranda, Monagas, Nueva Esparta,
Portuguesa, Sucre, Tachira, Trujillo, Yaracuy, Zulia; note--the federal
dependence consists of 11 federally controlled island groups with a total
of 72 individual islands
_#_Independence: 5 July 1811 (from Spain)
_#_Constitution: 23 January 1961
_#_Legal system: based on Napoleonic code; judicial review of
legislative acts in Cassation Court only; has not accepted compulsory ICJ
jurisdiction
_#_National holiday: Independence Day, 5 July (1811)
_#_Executive branch: president, Council of Ministers (cabinet)
_#_Legislative branch: bicameral Congress of the Republic
(Congreso de la Republica) consists of an upper chamber or Senate
(Senado) and a lower chamber or Chamber of Deputies (Camara de
Diputados)
_#_Judicial branch: Supreme Court of Justice (Corte Suprema de
Justica)
_#_Leaders:
Chief of State and Head of Government--President Carlos Andres
PEREZ (since 2 February 1989)
_#_Political parties and leaders:
Social Christian Party (COPEI), Eduardo FERNANDEZ, secretary general;
Democratic Action (AD), Gonzalo BARRIOS, president, and Humberto CELLI,
secretary general;
Movement Toward Socialism (MAS), Argelia LAYA, president, and
Freddy MUNOZ, secretary general
_#_Suffrage: universal and compulsory at age 18, though poorly
enforced
_#_Elections:
President--last held 4 December 1988 (next to be held
December 1993);
results--Carlos Andres PEREZ (AD) 54.6%,
Eduardo FERNANDEZ (COPEI) 41.7%, other 3.7%;
Senate--last held 4 December 1988
(next to be held December 1993);
results--percent of vote by party NA;
seats--(49 total) AD 23, COPEI 22, other 4;
note--3 former presidents (1 from AD, 2 from COPEI) hold lifetime
senate seats;
Chamber of Deputies--last held 4 December 1988
(next to be held December 1993);
results--AD 43.7%, COPEI 31.4%, MAS 10.3%, other 14.6%;
seats--(201 total) AD 97, COPEI 67, MAS 18, other 19
_#_Communists: 10,000 members (est.)
_#_Other political or pressure groups: FEDECAMARAS, a conservative
business group; Venezuelan Confederation of Workers, the Democratic
Action-dominated labor organization
_#_Member of: AG, CDB, CG, ECLAC, FAO, G-3, G-11, G-19, G-24, G-77,
GATT, IADB, IAEA, IBRD, ICAO, ICC, ICFTU, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, IOC, IOM, ISO, ITU, LAES, LAIA, LORCS, NAM, OAS,
OPANAL, OPEC, PCA, RG, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WFTU, WHO,
WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Simon Alberto CONSALVI
Bottaro; Chancery at 2445 Massachusetts Avenue NW, Washington DC 20008;
telephone (202) 797-3800; there are Venezuelan Consulates General in
Baltimore, Boston, Chicago, Houston, Miami, New Orleans, New York,
Philadelphia, San Francisco, and San Juan (Puerto Rico);
US--Ambassador Michael Martin SKOL; Embassy at Avenida Francisco
de Miranda and Avenida Principal de la Floresta, Caracas (mailing address
is P. O. Box 62291, Caracas 1060-A, or APO Miami 34037);
telephone [58] (2) 285-3111 or 2222; there is a US Consulate in Maracaibo
_#_Flag: three equal horizontal bands of yellow (top), blue, and red
with the coat of arms on the hoist side of the yellow band and an arc of
seven white five-pointed stars centered in the blue band
_#_Long-form name: Socialist Republic of Vietnam; abbreviated SRV
_#_Type: Communist state
_#_Capital: Hanoi
_#_Administrative divisions: 41 provinces (tinh, singular and plural),
3 municipalities* (thanh pho, singular and plural); An Giang,
Bac Thai, Ben Tre, Binh Dinh, Cao Bang, Cuu Long, Dak Lak, Dong Nai,
Dong Thap, Gia Lai-Kon Tum, Ha Bac, Hai Hung, Hai Phong*, Ha Nam Ninh,
Ha Noi*, Ha Son Binh, Ha Tuyen, Hau Giang, Hoang Lien Son, Ho Chi Minh*,
Khanh Hoa, Kien Giang, Lai Chau, Lam Dong, Lang Son, Long An, Minh Hai,
Nghe Tinh, Phu Yen, Quang Binh, Quang Nam-Da Nang, Quang Ngai,
Quang Ninh, Quang Tri, Song Be, Son La, Tay Ninh, Thai Binh, Thanh Hoa,
Thua Thien, Thuan Hai, Tien Giang, Vinh Phu, Vung Tau-Con Dao;
note--diacritical marks are not included
_#_Independence: 2 September 1945 (from France)
_#_Constitution: 18 December 1980
_#_Legal system: based on Communist legal theory and French civil law
system
_#_National holiday: Independence Day, 2 September (1945)
_#_Executive branch: chairman of the Council of State, Council of
State, chairman of the Council of Ministers, Council of Ministers
_#_Legislative branch: unicameral National Assembly (Quoc-Hoi)
_#_Judicial branch: Supreme People''s Court
_#_Leaders:
Chief of State--Chairman of the Council of State Vo Chi CONG (since
18 June 1987);
Head of Government--Chairman of the Council of Ministers (Premier)
Vo Van KIET (since 9 August 1991)
_#_Political parties and leaders: only party-- Vietnam Communist Party
(VCP), Nguyen Van LINH
_#_Suffrage: universal at age 18
_#_Elections:
National Assembly--last held 19 April 1987
(next to be held April 1992);
results--VCP is the only party;
seats--(496 total) VCP or VCP-approved 496
_#_Communists: nearly 2 million
_#_Member of: ACCT, AsDB, ESCAP, FAO, G-77, IAEA, IBEC, IBRD, ICAO,
IDA, IFAD, IFC, IIB, IMF, IMO, INTELSAT, IOC, ISO, ITU, LORCS, NAM, UN,
UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: none
_#_Flag: red with a large yellow five-pointed star in the center','8ffe8bf4de165733a124007f27dec9a15685768bcbb19647b0c8c3e964e3100d','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b7be1a7f3d56fea48dd7cfb8e4448a82ab771b29d63d4ee92f242833611a3c5',1991,'MT','Malta','government',149,'_#_Long-form name: Virgin Islands of the United States
_#_Type: organized, unincorporated territory of the US administered by
the Office of Territorial and International Affairs, US Department of the
Interior
_#_Capital: Charlotte Amalie
_#_Administrative divisions: none (territory of the US)
_#_Independence: none (territory of the US)
_#_Constitution: Revised Organic Act of 22 July 1954 serves as the
constitution
_#_Legal system: based on US
_#_National holiday: Transfer Day (from Denmark to US), 31 March
(1917)
_#_Executive branch: US president, governor, lieutenant governor
_#_Legislative branch: unicameral Senate
_#_Judicial branch: US District Court handles civil matters over
$50,000, felonies (persons 15 years of age and over), and federal cases;
Territorial Court handles civil matters up to $50,000 small claims,
juvenile, domestic, misdemeanors, and traffic cases
_#_Leaders:
Chief of State and Head of Government--President George
BUSH (since 20 January 1989), represented by Governor Alexander A.
FARRELLY (since 5 January 1987); Lieutenant Governor Derek HODGE (since
5 January 1987)
_#_Political parties and leaders:
Democratic Party, Marilyn STAPLETON;
Independent Citizens'' Movement (ICM), Virdin BROWN;
Republican Party, Charlotte-Poole DAVIS
_#_Suffrage: universal at age 18; indigenous inhabitants are US
citizens, but do not vote in US presidential elections
_#_Elections:
Governor--last held NA 1986 (next to be held NA 1990);
results--Alexander FARRELLY (Democratic Party) defeated
Adelbert BRYAN (ICM);
Senate--last held 6 November 1990 (next to be held 3 November
1992);
results--percent of vote by party NA;
seats--(15 total) number of seats by party NA;
US House of Representatives--last held 6 November 1990
(next to be held 3 November 1992);
results--the Virgin Islands elects one nonvoting representative
_#_Member of: ECLAC (associate), IOC
_#_Diplomatic representation: none (territory of the US)
_#_Flag: white with a modified US coat of arms in the center between
the large blue initials V and I; the coat of arms shows an
eagle holding an olive branch in one talon and three arrows in the other
with a superimposed shield of vertical red and white stripes below a blue
panel
_#_Long-form name: none
_#_Type: unincorporated territory of the US administered by the US Air
Force (under an agreement with the US Department of Interior) since
24 June 1972
_#_Flag: the US flag is used
_#_Long-form name: Territory of the Wallis and Futuna Islands
_#_Type: overseas territory of France
_#_Capital: Mata-Utu (on Ile Uvea)
_#_Administrative divisions: none (overseas territory of France)
_#_Independence: none (overseas territory of France)
_#_Constitution: 28 September 1958 (French Constitution)
_#_Legal system: French
_#_National holiday: Taking of the Bastille, 14 July (1789)
_#_Executive branch: French president, high administrator; note--there
are three traditional kings with limited powers
_#_Legislative branch: unicameral Territorial Assembly
(Assemblee Territoriale)
_#_Judicial branch: none; justice generally administered under French
law by the chief administrator, but the three traditional kings
administer customary law and there is a magistrate in Mata-Utu
_#_Leaders:
Chief of State--President Francois MITTERRAND
(since 21 May 1981);
Head of Government--Chief Administrator Roger DUMEC
(since 15 July 1988)
_#_Political parties and leaders:
Rally for the Republic (RPR);
Union Populaire Locale (UPL);
Union Pour la Democratie Francaise (UDF);
Lua kae tahi (Giscardians);
Mouvement des Radicaux de Gauche (MRG)
_#_Suffrage: universal adult at age 18
_#_Elections:
Territorial Assembly--last held 15 March 1987
(next to be held March 1992);
results--percent of vote by party NA;
seats--(20 total) RPR 7, UPL 6, UDF and Lua kae tahi 7;
French Senate--last held NA September 1989
(next to be held by September 1992);
results--percent of vote by party NA;
seats--(1 total) RPR 1;
French National Assembly--last held 12 June 1988 (next to be held
by September 1992);
results--percent of vote by party NA;
seats--(1 total) MRG 1
_#_Member of: FZ, SPC
_#_Diplomatic representation: as an overseas territory of France,
local interests are represented in the US by France
_#_Flag: the flag of France is used
_#_Long-form name: none
_#_Note: The West Bank is currently governed by Israeli military
authorities and Israeli civil administration. It is US policy that the
final status of the West Bank will be determined by negotiations among
the concerned parties. These negotiations will determine how the area
is to be governed.
_#_Long-form name: none
_#_Type: legal status of territory and question of sovereignty
unresolved; territory contested by Morocco and Polisario Front (Popular
Front for the Liberation of the Saguia el Hamra and Rio de Oro), which
in February 1976 formally proclaimed a government in exile of the
Sahrawi Arab Democratic Republic (SADR); territory partitioned between
Morocco and Mauritania in April 1976, with Morocco acquiring northern
two-thirds; Mauritania, under pressure from Polisario guerrillas,
abandoned all claims to its portion in August 1979; Morocco moved to
occupy that sector shortly thereafter and has since asserted
administrative control; the Polisario''s government in exile was seated as
an OAU member in 1984; guerrilla activities continue sporadically.
_#_Capital: none
_#_Administrative divisions: none (under de facto control of Morocco)
_#_Leaders: none
_#_Member of: none
_#_Diplomatic representation: none
_#_Long-form name: Independent State of Western Samoa
_#_Type: constitutional monarchy under native chief
_#_Capital: Apia
_#_Administrative divisions: 11 districts; Aana, Aiga-i-le-Tai,
Atua, Faasaleleaga, Gagaemauga, Gagaifomauga, Palauli, Satupaitea,
Tuamasaga, Vaa-o-Fonoti, Vaisigano
_#_Independence: 1 January 1962 (from UN trusteeship administered
by New Zealand)
_#_Constitution: 1 January 1962
_#_Legal system: based on English common law and local customs;
judicial review of legislative acts with respect to fundamental rights of
the citizen; has not accepted compulsory ICJ jurisdiction
_#_National holiday: National Day, 1 June
_#_Executive branch: monarch, Executive Council, prime minister,
Cabinet
_#_Legislative branch: unicameral Legislative Assembly (Fono)
_#_Judicial branch: Supreme Court, Court of Appeal
_#_Leaders:
Chief of State--Susuga Malietoa TANUMAFILI II (Co-Chief of State
from 1 January 1962 until becoming sole Chief of State on 5 April 1963);
Head of Government--Prime Minister TOFILAU Eti Alesana (since
7 April 1988)
_#_Political parties and leaders:
Human Rights Protection Party (HRPP), TOFILAU Eti, chairman;
Samoan National Development Party (SNDP), VA''AI Kolone,
chairman
_#_Suffrage: universal adult at age NA, but only matai (head of
family) are able to run for the Legislative Assembly
_#_Elections:
Legislative Assembly--last held NA February 1991
(next to be held by February 1994);
results--percent of vote by party NA;
seats--(47 total) HRPP 30, SNDP 14, independent 3
_#_Member of: ACP, AsDB, C, ESCAP, FAO, G-77, IBRD, ICFTU, IDA, IFAD,
IFC, IMF, IOC, ITU, LORCS, SPC, SPF, UN, UNCTAD, UNESCO, UPU, WHO
_#_Diplomatic representation: Ambassador Fili (Felix) Tuaopepe
WENDT; Chancery (temporary) at the Western Samoan Mission to the UN,
820 2nd Avenue, New York, NY 10017 (212) 599-6196;
US--the ambassador to New Zealand, Della Newman, is accredited to
Western Samoa (mailing address is P.O. Box 3430, Apia); telephone (685)
21-631
_#_Flag: red with a blue rectangle in the upper hoist-side quadrant
bearing five white five-pointed stars representing the Southern Cross
constellation
_#_Administrative divisions: 170 sovereign nations plus 72 dependent,
other, and miscellaneous areas
_#_Legal system: varies among each of the entities; 162 are parties
to the United Nations International Court of Justice (ICJ) or World Court
_#_Diplomatic representation: there are 159 members of the UN
_#_Long-form name: Republic of Yemen
_#_Type: republic
_#_Capital: Sanaa
_#_Administrative divisions: 17 governorates (muhafazat,
singular--muhafazah); Abyan, Adan, Al Bayda,
Al Hudaydah, Al Jawf, Al Mahrah, Al Mahwit, Dhamar,
Hadramawt, Hajjah, Ibb, Lahij, Marib, Sadah, Sana,
Shabwah, Taizz
_#_Independence: Republic of Yemen was established on 22 May 1990
with the merger of the Yemen Arab Republic [Yemen (Sanaa) or North
Yemen] and the Marxist-dominated People''s Democratic Republic of Yemen
[Yemen (Aden) or South Yemen]; previously North Yemen had become
independent on NA November 1918 (from the Ottoman Empire) and South
Yemen had become independent on 30 November 1967 (from the UK); the
union is to be solidified during a 30-month transition period, which
coincides with the remainder of the five-year terms of both legislatures
_#_Constitution: 16 April 1991
_#_Legal system: based on Islamic law, Turkish law, English common
law, and local customary law; does not accept compulsory ICJ jurisdiction
_#_National holiday: Proclamation of the Republic, 22 May (1990)
_#_Executive branch: five-member Presidential Council (president,
vice president, two members from northern Yemen and one member from
southern Yemen), prime minister
_#_Legislative branch: unicameral House of Representatives;
note--northern Yemen''s Consultative Assembly (Majlis Chura) and
southern Yemen''s Supreme People''s Council (Majlis al-Shab al-Ala)
will combine to form the basis for the new unicameral House of
Representatives
_#_Judicial branch: North--State Security Court; South--Federal
High Court
_#_Leaders:
Chief of State and Head of Government President Ali Abdallah
SALIH (since 22 May 1990, the former president of North Yemen); Vice
President Ali Salim al-BIDH (since 22 May 1990, secretary general of the
Yemeni Socialist Party); Presidential Council Member Salim Salih
MUHAMMED (southern Yemen); Presidential Council Member Kadi Abdul-Karim
al-ARASHI (northern Yemen); Presidential Council Member Abdul-Aziz
ABDUL-GHANI (northern Yemen); Prime Minister Haydar Abu Bakr
al-ATTAS (since 22 May 1990, former president of South Yemen)
_#_Political parties and leaders:
General People''s Congress, Ali Abdallah SALIH;
Yemeni Socialist Party (YSP; formerly South Yemen''s ruling party--a
coalition of National Front, Bath, and Communist Parties), Ali Salim
al-BIDH
_#_Suffrage: universal at age 18
_#_Elections:
House of Representatives--last held NA (next to be held
26-27 May, 12 June, and 24 July 1991);
results--percent of vote NA;
seats--(301); number of seats by party NA; note--the 301 members of
the new House of Representatives will come from North Yemen''s
Consultative Assembly (159 members), South Yemen''s Supreme People''s
Council (111 members), and appointments by the New Presidential Council
(31 members)
_#_Communists: small number in North, greater but unknown number
in South
_#_Other political or pressure groups: conservative tribal groups,
Muslim Brotherhood, leftist factions--pro-Iraqi Bathists, Nasirists,
National Democratic Front (NDF)
_#_Member of: ACC, AFESD, AL, AMF, CAEU, ESCWA, FAO, G-77,
IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC,
ITU, LORCS, NAM, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WIPO,
WMO, WTO
_#_Diplomatic representation: Ambassador Muhsin Ahmad al-AYNI;
Chancery at Suite 840, 600 New Hampshire Avenue NW, Washington DC 20037;
telephone (202) 965-4760 or 4761; there is a Yemeni Consulate General in
Detroit and a Consulate in San Francisco;
US--Ambassador Charles F. DUNBAR; Embassy at Dhahr Himyar Zone,
Sheraton Hotel District, Sanaa (mailing address is P. O. Box 22347 Sanaa,
Republic of Yemen or Sanaa--Department of State, Washington, D. C.
20521-6330); telephone [967] (2) 238-842 through 238-852
_#_Flag: three equal horizontal bands of red (top), white, and black;
similar to the flag of Syria which has two green stars and of
Iraq which has three green stars (plus an Arabic inscription) in a
horizontal line centered in the white band; also similar to the flag of
Egypt which has a symbolic eagle centered in the white band','63e9429ce15ba8e6162a759bb71593c18ad5f787c630aa0b7dde45d44894912a','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69ad047863a758853489f591d6c3d90f305ac5bc4daae79f1dd8b632b6aeb746',1991,'DJ','Djibouti','government',153,'_#_Long-form name: Socialist Federal Republic of Yugoslavia;
abbreviated SFRY
_#_Type: federal republic in form; four of six republics have
non-Communist governments
_#_Capital: Belgrade
_#_Administrative divisions: 6 republics (republike,
singular--republika); Bosna i Hercegovina (Bosnia and Hercegovina),
Crna Gora (Montenegro), Hrvatska (Croatia), Makedonija (Macedonia),
Slovenija (Slovenia), Srbija (Serbia);
note--there are two nominally autonomous provinces (autonomne pokajine,
singular--autonomna pokajina) within Srbija--Kosovo and Vojvodina
_#_Independence: 1 December 1918; independent monarchy established
from the Kingdoms of Serbia and Montenegro, parts of the Turkish Empire,
and the Austro-Hungarian Empire; SFRY proclaimed 29 November 1945
_#_Constitution: 21 February 1974, amendments to the Constitution
have passed the Federal Assembly and are being considered at the
republic level
_#_Legal system: mixture of civil law system and Communist legal
theory; has not accepted compulsory ICJ jurisdiction; a new legal
code is being formulated
_#_National holiday: Proclamation of the Socialist Federal Republic of
Yugoslavia, 29 November (1945)
_#_Executive branch: president of the Presidency, vice president of
the Presidency, Presidency, president of the Federal Executive
Council, two vice presidents of the Federal Executive Council, Federal
Executive Council
_#_Legislative branch: bicameral Federal (Skupstina) consists of
an upper chamber or Chamber of Republics and Provinces (Vece Republika
i Pokrajina) and a lower chamber or Federal Chamber
_#_Judicial branch: Federal Court (Savezna Sud), Constitutional Court
_#_Leaders:
Chief of State--President of the Presidency Stjepan MESIC
from Hrvatska (Croatia), one-year term expires 15 May 1992;
Vice President of the Presidency Branko KOSTIC from Crna Gora
(Montenegro), one-year term expires 15 May 1992; note--the offices of
president and vice president rotate annually among members of the
Presidency with the current vice president assuming the
presidency and a new vice president selected from area which has gone the
longest without filling the position (the current sequence is
Hrvatska, Crna Gora, Vojvodina, Kosovo, Makedonija, Bosna i
Hercegovina, Slovenija, and Srbija);
Head of Government--President of the Federal Executive Council
Ante MARKOVIC (since 16 March 1989); Vice President of the Federal
Executive Council Aleksandar MITROVIC (since 16 March 1989);
Vice President of the Federal Executive Council Zivko PREGL
(since 16 March 1989)
_#_Political parties and leaders: there are over 100 political
parties operating, some only in one republic and others country-wide
_#_Suffrage: at age 16 if employed, universal at age 18
_#_Elections: direct federal elections may never be held because of
inter-republic differences over Yugoslavia''s future structure
_#_Other political or pressure groups: there are no national
political groups; all significant groups are found within the republics
_#_Member of: AfDB, AG (observer), BIS, CCC, CERN (observer),
CSCE, ECE, FAO, G-9, G-19, G-24, G-77, GATT, IADB, IAEA, IBRD, ICAO, ICC,
IDA, IFAD, IFC, ILO, IMF, IMO, INTELSAT, INTERPOL, IOC, IOM (observer),
ISO, ITU, LORCS, NAM, OECD (special), PCA, UN, UNAVEM, UNCTAD, UNESCO,
UNHCR, UNIDO, UNIIMOG, UPU, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Dzevad MUJEZINOVIC;
Chancery at 2410 California Street NW, Washington DC 20008; telephone
(202) 462-6566; there are Yugoslav Consulates General in Chicago,
Cleveland, New York, Pittsburgh, and San Francisco;
US--Ambassador Warren ZIMMERMAN; mailing address Box 5070,
Belgrade or APO New York 09213-5070; telephone [38] (11) 645-655; there
is a US Consulate General in Zagreb
_#_Flag: three equal horizontal bands of blue (top), white, and red
with a large red five-pointed star edged in yellow superimposed in the
center over all three bands
_#_Long-form name: Republic of Zaire
_#_Type: republic with a strong presidential system
_#_Capital: Kinshasa
_#_Administrative divisions: 10 regions (regions,
singular--region) and 1 town* (ville); Bandundu, Bas-Zaire,
Equateur, Haut-Zaire, Kasai-Occidental, Kasai-Oriental, Kinshasa*,
Maniema, Nord-Kivu, Shaba, Sud-Kivu
_#_Independence: 30 June 1960 (from Belgium; formerly Belgian Congo,
then Congo/Leopoldville, then Congo/Kinshasa)
_#_Constitution: 24 June 1967, amended August 1974, revised 15
February 1978; amended 1990; new constitution to be promulgated in
1991
_#_Legal system: based on Belgian civil law system and tribal law;
has not accepted compulsory ICJ jurisdiction
_#_National holiday: Anniversary of the Regime (Second Republic),
24 November (1965)
_#_Executive branch: president, prime minister, Executive Council
(cabinet)
_#_Legislative branch: unicameral Legislative Council (Conseil
Legislatif)
_#_Judicial branch: Supreme Court (Cour Supreme)
_#_Leaders:
Chief of State--President Marshal MOBUTU Sese Seko Kuku Ngbendu wa
Za Banga (since 24 November 1965);
Head of Government--Prime Minister Bernadin MUNGUL DIAKA
(since 23 October 1991)
_#_Political parties and leaders: sole legal party until January
1991--Popular Movement of the Revolution (MPR); other parties include
Union for Democracy and Social Progress (UDPS), Etienne TSHISEKEDI
wa Mulumba;
Democratic Social Christian Party (PDSC),
Union of Federalists and Independent Republicans (UFERI);
and Congolese National Movement-Lumumba (MNC-L)
_#_Suffrage: universal and compulsory at age 18
_#_Elections:
President--last held 29 July 1984 (next to be held before
December 1991);
results--President MOBUTU was reelected without opposition;
Legislative Council--last held 6 September 1987
(next to be held in 1991, probably on a multiparty basis);
results--MPR was the only party;
seats--(210 total) MPR 210; note--MPR still holds majority of seats
but some deputies have joined other parties
_#_Communists: no Communist party
_#_Member of: ACCT, ACP, AfDB, APC, CCC, CEEAC, CEPGL, CIPEC, ECA,
FAO, G-19, G-24, G-77, GATT, IAEA, IBRD, ICAO, ICC, IDA, IFAD, IFC, ILO,
IMF, IMO, INTELSAT, INTERPOL, IOC, ITU, LORCS, NAM, OAU, PCA, UN, UNCTAD,
UNESCO, UNHCR, UNIDO, UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador TATANENE Manata;
Chancery at 1800 New Hampshire Avenue NW, Washington DC 20009;
telephone (202) 234-7690 or 7691;
US--Ambassador Melissa F. WELLS; Embassy at 310 Avenue des
Aviateurs, Kinshasa (mailing address is APO New York 09662); telephone
[243] (12) 21532; there is a US Consulate General in Lubumbashi
_#_Flag: light green with a yellow disk in the center bearing a black
arm holding a red flaming torch; the flames of the torch are blowing away
from the hoist side; uses the popular pan-African colors of Ethiopia
_#_Long-form name: Republic of Zambia
_#_Type: multiparty system; on 17 December 1990, President Kenneth
KAUNDA signed into law the constitutional amendment that officially
reintroduced the multiparty system in Zambia and ending 17 years of
one-party rule
_#_Capital: Lusaka
_#_Administrative divisions: 9 provinces; Central, Copperbelt,
Eastern, Luapula, Lusaka, Northern, North-Western, Southern, Western
_#_Independence: 24 October 1964 (from UK; formerly Northern Rhodesia)
_#_Constitution: 25 August 1973
_#_Legal system: based on English common law and customary law;
judicial review of legislative acts in an ad hoc constitutional council;
has not accepted compulsory ICJ jurisdiction
_#_National holiday: Independence Day, 24 October (1964)
_#_Executive branch: president, prime minister, Cabinet
_#_Legislative branch: unicameral National Assembly
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State--President Dr. Kenneth David KAUNDA (since 24
October 1964);
Head of Government--Prime Minister Gen. Malimba MASHEKE (since
15 March 1989)
_#_Political parties and leaders:
United National Independence Party (UNIP), Kenneth KAUNDA;
Movement for Multiparty Democracy (MMD), Frederick CHILUBA;
National Democratic Alliance (NADA), leader NA;
Democratic Party, leader NA; note--the first Extraordinary
Congress of UNIP began on 6 August 1991
_#_Suffrage: universal at age 18
_#_Elections:
President--last held 26 October 1988
(next to be held mid-1991);
results--President Kenneth KAUNDA was reelected without opposition;
National Assembly--last held 26 October 1988
(next to be held mid-1991);
results--UNIP was the only party;
seats--(136 total, 125 elected) UNIP 125
_#_Communists: no Communist party
_#_Member of: ACP, AfDB, C, CCC, ECA, FAO, FLS, G-19, G-77, GATT,
IAEA, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, INTELSAT, INTERPOL, IOC, ITU,
LORCS, NAM, OAU, SADCC, UN, UNCTAD, UNESCO, UNIDO, UNIIMOG, UPU,
WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Ambassador Paul J. F. LUSAKA; Chancery
at 2419 Massachusetts Avenue NW, Washington DC 20008; telephone (202)
265-9717 through 9721;
US--Ambassador Gordon L. STREET; Embassy at corner of Independence
Avenue and United Nations Avenue, Lusaka (mailing address is P. O. Box
31617, Lusaka); telephone [2601] 228-595, 228-596, 228-598, 228-601,
228-602, 228-603, 251-419
_#_Flag: green with a panel of three vertical bands of red (hoist
side), black, and orange below a soaring orange eagle, on the outer
edge of the flag
_#_Long-form name: Republic of Zimbabwe
_#_Type: parliamentary democracy
_#_Capital: Harare
_#_Administrative divisions: 8 provinces; Manicaland, Mashonaland
Central, Mashonaland East, Mashonaland West, Masvingo (Victoria),
Matabeleland North, Matabeleland South, Midlands
_#_Independence: 18 April 1980 (from UK; formerly Southern Rhodesia)
_#_Constitution: 21 December 1979
_#_Legal system: mixture of Roman-Dutch and English common law
_#_National holiday: Independence Day, 18 April (1980)
_#_Executive branch: executive president, 2 vice presidents, Cabinet
_#_Legislative branch: unicameral Parliament
_#_Judicial branch: Supreme Court
_#_Leaders:
Chief of State and Head of Government--Executive President Robert
Gabriel MUGABE (since 31 December 1987);
Co-Vice President Simon Vengai MUZENDA (since 31 December 1987);
Co-Vice President Joshua M. NKOMO (since 6 August 1990)
_#_Political parties and leaders:
Zimbabwe African National Union-Patriotic Front (ZANU-PF), Robert MUGABE;
Zimbabwe African National Union-Sithole (ZANU-S), Ndabaningi SITHOLE;
Zimbabwe Unity Movement (ZUM), Edgar TEKERE
_#_Suffrage: universal at age 18
_#_Elections:
Executive President--last held 28-30 March 1990 (next to be held
NA March 1995);
results--Robert MUGABE 78.3%; Edgar TEKERE 21.7%;
Parliament--last held 28-30 March 1990 (next to be held
NA March 1995);
results--percent of vote by party NA;
seats--(150 total, 120 elected) ZANU 117, ZUM 2, ZANU-S 1
_#_Communists: no Communist party
_#_Member of: ACP, AfDB, C, CCC, ECA, FAO, FLS, G-77, GATT, IAEA,
IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, INTELSAT, INTERPOL, IOC, IOM
(observer), ITU, LORCS, NAM, OAU, PCA, SADCC, UN, UNCTAD, UNESCO, UNIDO,
UPU, WCL, WHO, WIPO, WMO, WTO
_#_Diplomatic representation: Counselor (Political Affairs), Head of
Chancery, Ambassador Stanislaus Garikai CHIGWEDERE; Chancery at
2852 McGill Terrace NW, Washington DC 20008; telephone (202) 332-7100;
US--Ambassador (vacant); Embassy at 172 Herbert Chitapo
Avenue, Harare (mailing address is P. O. Box 3340, Harare);
telephone [263] (4) 794-521
_#_Flag: seven equal horizontal bands of green, yellow, red, black,
red, yellow, and green with a white equilateral triangle edged in black
based on the hoist side; a yellow Zimbabwe bird is superimposed on a red
five-pointed star in the center of the triangle','310cd0112f691e158c8c5afb186e4e228c55adf9df0748e2ddd83f194c0f2180','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

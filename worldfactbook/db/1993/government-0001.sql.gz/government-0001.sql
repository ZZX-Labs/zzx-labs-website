SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c7289e8e865b59c80daf63894f61be469962dce8784abd6dd79cb2aa69ea93f',1993,'AU','Australia','government',22,'Australian Labor Party, Paul John KEATING
opposition:
Liberal Party, John HEWSON; National Party, Timothy FISCHER; Australian
Democratic Party, John COULTER
Other political or pressure groups:
Australian Democratic Labor Party (anti-Communist Labor Party splinter
group); Peace and Nuclear Disarmament Action (Nuclear Disarmament Party
splinter group)
Suffrage:
18 years of age; universal and compulsory
Elections:
House of Representatives:
last held 13 March 1993 (next to be held by NA May 1996); results - percent
of vote by party NA; seats - (147 total) Labor 80, Liberal-National 65,
independent 2
Senate:
last held 13 March 1993 (next to be held by NA May 1999); results - percent
of vote by party NA; seats - (76 total) Liberal-National 36, Labor 30,
Australian Democrats 7, Greens 2, independents 1
Executive branch:
British monarch, governor general, prime minister, deputy prime minister,
Cabinet
Legislative branch:
bicameral Federal Parliament consists of an upper house or Senate and a
lower house or House of Representatives
Judicial branch:
High Court
*Australia, Government
Leaders:
Chief of State:
Queen ELIZABETH II (since 6 February 1952), represented by Governor General
William George HAYDEN (since 16 February 1989)
Head of Government:
Prime Minister Paul John KEATING (since 20 December 1991); Deputy Prime
Minister Brian HOWE (since 4 June 1991)
Member of:
AfDB, AG (observer), ANZUS, APEC, AsDB, Australia Group, BIS, C, CCC, COCOM,
CP, EBRD, ESCAP, FAO, GATT, G-8, IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IEA,
IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC, IOM, ISO, ITU,
LORCS, MINURSO, MTCR, NAM (guest), NEA, NSG, OECD, PCA, SPARTECA, SPC, SPF,
UN, UNCTAD, UNESCO, UNHCR, UNIDO, UNOSOM, UNTAC, UNTSO, UPU, WFTU, WHO,
WIPO, WMO, ZC
Diplomatic representation in US:
chief of mission: Ambassador Michael J. COOK
chancery:
1601 Massachusetts Avenue NW, Washington, DC 20036
telephone:
(202) 797-3000
consulates general:
Chicago, Honolulu, Houston, Los Angeles, New York, Pago Pago (American
Samoa), and San Francisco
US diplomatic representation:
chief of mission:
(vacant)
embassy:
Moonah Place, Yarralumla, Canberra, Australian Capital Territory 2600
mailing address:
APO AP 96549
telephone:
[61] (6) 270-5000
FAX:
[61] (6) 270-5970
consulates general:
Melbourne, Perth, and Sydney
consulate:
Brisbane
Flag:
blue with the flag of the UK in the upper hoist-side quadrant and a large
seven-pointed star in the lower hoist-side quadrant; the remaining half is a
representation of the Southern Cross constellation in white with one small
five-pointed star and four, larger, seven-pointed stars
*Australia, Economy
Overview:
Australia has a prosperous Western-style capitalist economy, with a per
capita GDP comparable to levels in industrialized West European countries.
Rich in natural resources, Australia is a major exporter of agricultural
products, minerals, metals, and fossil fuels. Of the top 25 exports, 21 are
primary products, so that, as happened during 1983-84, a downturn in world
commodity prices can have a big impact on the economy. The government is
pushing for increased exports of manufactured goods, but competition in
international markets continues to be severe.
National product:
GDP - purchasing power equivalent - $293.5 billion (1992)
National product real growth rate:
2.5% (1992)
National product per capita:
$16,700 (1992)
Inflation rate (consumer prices):
0.8% (September 1992)
Unemployment rate:
11.3% (December 1992)
Budget:
revenues $68.5 billion; expenditures $78.0 billion, including capital
expenditures of $NA (FY93)
Exports: $41.7 billion (f.o.b., FY91)
commodities:
coal, gold, meat, wool, alumina, wheat, machinery and transport equipment
partners:
Japan 26%, US 11%, NZ 6%, South Korea 4%, Singapore 4%, UK, Taiwan, Hong
Kong
Imports:
$37.8 billion (f.o.b., FY91)
commodities:
machinery and transport equipment, computers and office machines, crude oil
and petroleum products
partners:
US 24%, Japan 19%, UK 6%, FRG 7%, NZ 4% (1990)
External debt:
$130.4 billion (June 1991)
Industrial production:
growth rate NA%; accounts for 32% of GDP
Electricity:
40,000,000 kW capacity; 150,000 million kWh produced, 8,475 kWh per capita
(1992)
Industries:
mining, industrial and transportation equipment, food processing, chemicals,
steel
Agriculture:
accounts for 5% of GDP and 37% of export revenues; world''s largest exporter
of beef and wool, second-largest for mutton, and among top wheat exporters;
major crops - wheat, barley, sugarcane, fruit; livestock - cattle, sheep,
poultry
Illicit drugs:
Tasmania is one of the world''s major suppliers of licit opiate products;
government maintains strict controls over areas of opium poppy cultivation
and output of poppy straw concentrate
Economic aid:
donor - ODA and OOF commitments (1970-89), $10.4 billion
Currency:
1 Australian dollar ($A) = 100 cents
*Australia, Economy
Exchange rates:
Australian dollars ($A) per US$1 - 1.4837 (January 1993), 1.3600 (1992),
1.2836 (1991), 1.2799 (1990), 1.2618 (1989), 1.2752 (1988)
Fiscal year:
1 July - 30 June
*Australia, Communications
Railroads:
40,478 km total; 7,970 km 1.600-meter gauge, 16,201 km 1.435-meter standard
gauge, 16,307 km 1.067-meter gauge; 183 km dual gauge; 1,130 km electrified;
government owned (except for a few hundred kilometers of privately owned
track) (1985)
Highways:
837,872 km total; 243,750 km paved, 228,396 km gravel, crushed stone, or
stabilized soil surface, 365,726 km unimproved earth
Inland waterways:
8,368 km; mainly by small, shallow-draft craft
Pipelines:
crude oil 2,500 km; petroleum products 500 km; natural gas 5,600 km
Ports:
Adelaide, Brisbane, Cairns, Darwin, Devonport, Fremantle, Geelong, Hobart,
Launceston, Mackay, Melbourne, Sydney, Townsville
Merchant marine:
82 ships (1,000 GRT or over) totaling 2,347,271 GRT/3,534,926 DWT; includes
2 short-sea passenger, 8 cargo, 7 container, 8 roll-on/roll-off, 1 vehicle
carrier, 17 oil tanker, 3 chemical tanker, 4 liquefied gas, 30 bulk, 2
combination bulk
Airports:
total:
481
usable:
439
with permanent-surface runways:
243
with runways over 3,659 m:
1
with runways 2,440-3,659 m:
20
with runways 1,220-2,439 m:
268
Telecommunications:
good international and domestic service; 8.7 million telephones; broadcast
stations - 258 AM, 67 FM, 134 TV; submarine cables to New Zealand, Papua New
Guinea, and Indonesia; domestic satellite service; satellite stations - 4
Indian Ocean INTELSAT, 6 Pacific Ocean INTELSAT earth stations
*Australia, Defense Forces
Branches:
Australian Army, Royal Australian Navy, Royal Australian Air Force
Manpower availability:
males age 15-49 4,830,068; fit for military service 4,198,622; reach
military age (17) annually 135,591 (1993 est.)
Defense expenditures:
exchange rate conversion - $7.1 billion, 2.4% of GDP (FY92/93)
*Austria, Geography
Location:
Central Europe, between Germany and Hungary
Map references:
Africa, Arctic Region, Europe, Standard Time Zones of the World
Area:
total area: 83,850 km2
land area:
82,730 km2
comparative area:
slightly smaller than Maine
Land boundaries:
total 2,496 km, Czech Republic 362 km, Germany 784 km, Hungary 366 km, Italy
430 km, Liechtenstein 37 km, Slovakia 91 km, Slovenia 262 km, Switzerland
164 km
Coastline:
0 km (landlocked)
Maritime claims:
none; landlocked
International disputes:
none
Climate:
temperate; continental, cloudy; cold winters with frequent rain in lowlands
and snow in mountains; cool summers with occasional showers
Terrain:
in the west and south mostly mountains (Alps); along the eastern and
northern margins mostly flat or gently sloping
Natural resources:
iron ore, petroleum, timber, magnesite, aluminum, lead, coal, lignite,
copper, hydropower
Land use:
arable land:
17%
permanent crops:
1%
meadows and pastures:
24%
forest and woodland:
39%
other:
19%
Irrigated land:
40 km2 (1989)','fe44d4072ec2b0cfbe80041bf338aa9813f5ba61b60c6c2fddc6feebe6a5ec4b','internet-archive','theciaworldfactb00087gut','txt','6946a8c02ad1600040a72d937bae90d11dbd49cbf680b92059bb2100c4893e08','https://archive.org/download/theciaworldfactb00087gut/87.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('515a933612687a3d1189a6a450b6cd8c23c60e7dea73b99338a4991efadc4a37',1993,'LI','Liechtenstein','government',129,'Legislative branch:
unicameral Diet (Landtag)
Judicial branch:
Supreme Court (Oberster Gerichtshof) for criminal cases, Superior Court
(Obergericht) for civil cases
Leaders:
Chief of State:
Prince Hans ADAM II (since 13 November 1989; assumed executive powers 26
August 1984); Heir Apparent Prince ALOIS von und zu Liechtenstein (born 11
June 1968)
Head of Government:
Markus BUECHEL (since 7 February 1993); Deputy Head of Government Dr.
Herbert WILLE (since 2 February 1986)
Member of:
CE, CSCE, EBRD, ECE, EFTA, IAEA, INTELSAT, INTERPOL, IOC, ITU, LORCS, UN,
UNCTAD, UPU, WCL, WIPO
Diplomatic representation in US:
in routine diplomatic matters, Liechtenstein is represented in the US by the
Swiss Embassy
*Liechtenstein, Government
US diplomatic representation:
the US has no diplomatic or consular mission in Liechtenstein, but the US
Consul General at Zurich (Switzerland) has consular accreditation at Vaduz
Flag:
two equal horizontal bands of blue (top) and red with a gold crown on the
hoist side of the blue band
*Liechtenstein, Economy
Overview:
The prosperous economy is based primarily on small-scale light industry and
tourism. Industry accounts for 53% of total employment, the service sector
45% (mostly based on tourism), and agriculture and forestry 2%. The sale of
postage stamps to collectors is estimated at $10 million annually. Low
business taxes (the maximum tax rate is 20%) and easy incorporation rules
have induced about 25,000 holding or so-called letter box companies to
establish nominal offices in Liechtenstein. Such companies, incorporated
solely for tax purposes, provide 30% of state revenues. The economy is tied
closely to Switzerland''s economy in a customs union, and incomes and living
standards parallel those of the more prosperous Swiss groups.
National product:
GDP - purchasing power equivalent - $630 million (1990 est.)
National product real growth rate:
NA%
National product per capita:
$22,300 (1990 est.)
Inflation rate (consumer prices):
5.4% (1990)
Unemployment rate:
1.5% (1990)
Budget:
revenues $259 million; expenditures $292 million, including capital
expenditures of $NA (1990)
Exports:
$1.6 billion
commodities:
small specialty machinery, dental products, stamps, hardware, pottery
partners:
EFTA countries 20.9% (Switzerland 15.4%), EC countries 42.7%, other 36.4%
(1990)
Imports:
$NA
commodities:
machinery, metal goods, textiles, foodstuffs, motor vehicles
partners:
NA
External debt:
$NA
Industrial production:
growth rate NA%
Electricity:
23,000 kW capacity; 150 million kWh produced, 5,230 kWh per capita (1992)
Industries:
electronics, metal manufacturing, textiles, ceramics, pharmaceuticals, food
products, precision instruments, tourism
Agriculture:
livestock, vegetables, corn, wheat, potatoes, grapes
Economic aid:
none
Currency:
1 Swiss franc, franken, or franco (SwF) = 100 centimes, rappen, or centesimi
Exchange rates:
Swiss francs, franken, or franchi (SwF) per US$1 - 1.4781 (January 1993),
1.4062 (1992), 1.4340 (1991), 1.3892 (1990), 1.6359 (1989), 1.4633 (1988)
Fiscal year:
calendar year
*Liechtenstein, Communications
Railroads:
18.5 km 1.435-meter standard gauge, electrified; owned, operated, and
included in statistics of Austrian Federal Railways
Highways:
130.66 km main roads, 192.27 km byroads
Airports:
none
Telecommunications:
limited, but sufficient automatic telephone system; 25,400 telephones;
linked to Swiss networks by cable and radio relay for international
telephone, radio, and TV services
*Liechtenstein, Defense Forces
Note:
defense is responsibility of Switzerland
*Lithuania, Geography
Location:
Eastern Europe, bordering the Baltic Sea, between Sweden and Russia
Map references:
Asia, Europe, Standard Time Zones of the World
Area:
total area:
65,200 km2
land area:
65,200 km2
comparative area:
slightly larger than West Virginia
Land boundaries:
total 1,273 km, Belarus 502 km, Latvia 453 km, Poland 91 km, Russia
(Kaliningrad) 227 km
Coastline:
108 km
Maritime claims:
territorial sea:
12 nm
International disputes:
dispute with Russia (Kaliningrad Oblast) over the position of the Neman
River border presently located on the Lithuanian bank and not in midriver as
by international standards
Climate:
maritime; wet, moderate winters
Terrain:
lowland, many scattered small lakes, fertile soil
Natural resources:
peat
Land use:
arable land:
49.1%
permanent crops:
0%
meadows and pastures:
22.2%
forest and woodland:
16.3%
other:
12.4%
Irrigated land:
430 km2 (1990)','974cd153b32d1f2626607fdb27dac1d21c3e696f6c53fdfe67a580b5022c3a63','internet-archive','theciaworldfactb00087gut','txt','6946a8c02ad1600040a72d937bae90d11dbd49cbf680b92059bb2100c4893e08','https://archive.org/download/theciaworldfactb00087gut/87.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71ab1fee694b69e67bf5e99ff3e6c869c6d55aa8255997c83747c3a4de09b3bb',1993,'PK','Pakistan','government',163,'Pakistan Muslim League-Nawaz (PML-N), Mian Nawaz SHARIF; Jamhoori Watan
Party (JWP), Mohammad Akbar Khan BUGTI; Jamiat Ulema-i-Islam (JUI),
Fazl-ur-REHMAN and Sami-ul-HAQ; Awami National Party (ANP), Khan Abdul WALI
KHAN; Jamiat Ulema-i-Pakistan-Niazi, Maulana Abdul Sattar Khan NIAZI;
Pakhtun Khwa Milli Awami Party (PKMAP), Mahmood Khan ACHAKZAI
opposition:
Pakistan Peoples Party (PPP), Benazir BHUTTO and Nusrat BHUTTO; Pakistan
Muslim League-Chattha (PML-C), Hamid Nasir CHATTHA; Jamaat-i-Islami (JI),
Qazi Hussain AHMED; National People''s Party (NPP), Ghulam Mustapha JATOI
(formerly the PNP); Tehrik-i-Istiqlal (TI), Air Marshal (Ret.) Mohammad
ASGHAR KHAN; Tehrik-i-Nifaz-i-Fiqah-i-Jafaria (TNFJ), Agha Hamid Ali MUSAVI;
Jamiat Ulema-i-Pakistan-Noorani (JUP-Noorani), Maulana Shah Ahmed NOORANI;
Mohajir Quami Mahaz-Haqiqi (MQM-H), Afaq AHMED
Other political or pressure groups:
military remains important political force; ulema (clergy), landowners,
industrialists, and small merchants also influential
Suffrage:
21 years of age; universal
Elections:
President:
last held on 12 December 1988 (next to be held by NA November 1993); results
- Ghulam ISHAQ KHAN was elected by Parliament and the four provincial
assemblies
*Pakistan, Government
Senate:
last held March 1991 (next to be held NA March 1994); seats - (87 total) PML
52, Tribal Area Representatives (nonparty) 8, PPP 5, ANP 5, JWP 4, MQM 3,
PNP 2 (name later chaged to NPP), JI 2, JUP 2, JUI 2, PKMAP 1, independent 1
National Assembly:
last held on 24 October 1990 (next to be held by October 1995); results -
percent of vote by party NA; seats - (217 total) number of seats by party
NA; note - President GHULAM ISHAQ Khan dismissed the National Assembly on 18
April 1993; it was reestablished, however, on 26 May 1993 by the Supreme
Court, which ruled the dismissal order unconstitutional
Executive branch:
president, prime minister, Cabinet
Legislative branch:
bicameral Parliament (Majlis-e-Shoora) consists of an upper house or Senate
and a lower house or National Assembly
Judicial branch:
Supreme Court, Federal Islamic (Shari''at) Court
Leaders:
Chief of State:
President Ghulam ISHAQ KHAN (since 13 December 1988)
Head of Government:
Prime Minister Mian Nawaz SHARIF (since 6 November 1990); note - President
GHULAM ISHAQ Khan dismissed Prime Minister SHARIF on 18 April 1993, but he
was reinstated by the Supreme Court on 26 May 1993
Member of:
AsDB, C, CCC, CP, ECO, ESCAP, FAO, G-19, G-24, G-77, GATT, IAEA, IBRD, ICAO,
ICC, ICFTU, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT,
INTERPOL, IOC, IOM (observer), ISO, ITU, LORCS, MINURSO, NAM, OAS
(observer), OIC, PCA, SAARC, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UNIKOM,
UNOSOM, UNTAC, UPU, WCL, WFTU, WHO, WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission:
(vacant)
chancery:
2315 Massachusetts Avenue NW, Washington, DC 20008
telephone:
(202) 939-6200
consulate general:
New York
US diplomatic representation:
chief of mission:
Ambassador John MONJO
embassy:
Diplomatic Enclave, Ramna 5, Islamabad
mailing address:
P. O. Box 1048, PSC 1212, Box 2000, Islamabad or APO AE 09812-2000
telephone:
[92] (51) 826161 through 79
FAX:
[92] (51) 822004
consulates general:
Karachi, Lahore
consulate:
Peshawar
Flag:
green with a vertical white band (symbolizing the role of religious
minorities) on the hoist side; a large white crescent and star are centered
in the green field; the crescent, star, and color green are traditional
symbols of Islam
*Pakistan, Economy
Overview:
Pakistan is a poor Third World country faced with the usual problems of
rapidly increasing population, sizable government deficits, and heavy
dependence on foreign aid. In addition, the economy must support a large
military establishment. A real economic growth rate averaging 5-6% in recent
years has helped the country to cope with these problems. Almost all
agriculture and small-scale industry is in private hands. In 1990, Pakistan
embarked on a sweeping economic liberalization program to boost foreign and
domestic private investment and lower foreign aid dependence. The SHARIF
government denationalized several state-owned firms and attracted some
foreign investment. Pakistan likely will have difficulty raising living
standards because of its rapidly expanding population. At the current rate
of growth, population would double in 25 years.
National product:
GNP - exchange rate conversion - $48.3 billion (FY92 est.)
National product real growth rate:
6.4% (FY92 est.)
National product per capita:
$410 (FY92 est.)
Inflation rate (consumer prices):
12.7% (FY91)
Unemployment rate:
10% (FY91 est.)
Budget:
revenues $9.4 billion; expenditures $10.9 billion, including capital
expenditures of $3.1 billion (FY93 est.)
Exports:
$6.8 billion (f.o.b., FY92)
commodities:
cotton, textiles, clothing, rice
partners:
EC 35%, US 11%, Japan 8% (FY91)
Imports:
$9.1 billion (f.o.b., FY92)
commodities:
petroleum, petroleum products, machinery, transportation, equipment,
vegetable oils, animal fats, chemicals
partners:
EC 29%, Japan 13%, US 12% (FY91)
External debt:
$16.5 billion (1992 est.)
Industrial production:
growth rate 5.7% (FY91); accounts for almost 20% of GNP
Electricity:
10,000,000 kW capacity; 43,000 million kWh produced, 350 kWh per capita
(1992)
Industries:
textiles, food processing, beverages, construction materials, clothing,
paper products, shrimp
Agriculture:
25% of GNP, over 50% of labor force; world''s largest contiguous irrigation
system; major crops - cotton, wheat, rice, sugarcane, fruits, vegetables;
livestock products - milk, beef, mutton, eggs; self-sufficient in food grain
Illicit drugs:
illicit producer of opium and hashish for the international drug trade;
government eradication efforts on poppy cultivation of limited success;
largest producer of Southwest Asian heroin
*Pakistan, Economy
Economic aid:
(including Bangladesh prior to 1972) US commitments, including Ex-Im
(FY70-89), $4.5 billion; Western (non-US) countries, ODA and OOF bilateral
commitments (1980-89), $9.1 billion; OPEC bilateral aid (1979-89), $2.3
billion; Communist countries (1970-89), $3.2 billion
Currency:
1 Pakistani rupee (PRe) = 100 paisa
Exchange rates:
Pakistani rupees (PRs) per US$1 - 25.904 (January 1993), 25.083 (1992),
23.801 (1991), 21.707 (1990), 20.541 (1989), 18.003 (1988)
Fiscal year:
1 July - 30 June
*Pakistan, Communications
Railroads:
8,773 km total; 7,718 km broad gauge, 445 km 1-meter gauge, and 610 km less
than 1-meter gauge; 1,037 km broad-gauge double track; 286 km electrified;
all government owned (1985)
Highways:
101,315 km total (1987); 40,155 km paved, 23,000 km gravel, 29,000 km
improved earth, and 9,160 km unimproved earth or sand tracks (1985)
Pipelines:
crude oil 250 km; natural gas 4,044 km; petroleum products 885 km (1987)
Ports:
Gwadar, Karachi, Port Muhammad bin Qasim
Merchant marine:
29 ships (1,000 GRT or over) totaling 350,916 GRT/530,855 DWT; includes 3
passenger-cargo, 24 cargo, 1 oil tanker, 1 bulk
Airports:
total:
111
usable:
104
with permanent-surface runways:
75
with runways over 3,659 m:
1
with runways 2,440-3,659 m:
31
with runways 1,220-2,439 m:
42
Telecommunications:
the domestic telephone system is poor, adequate only for government and
business use; about 7 telephones per 1,000 persons; the system for
international traffic is better and employs both microwave radio relay and
satellites; satellite ground stations - 1 Atlantic Ocean INTELSAT and 2
Indian Ocean INTELSAT; broadcast stations - 19 AM, 8 FM, 29 TV
*Pakistan, Defense Forces
Branches:
Army, Navy, Air Force, Civil Armed Forces, National Guard
Manpower availability:
males age 15-49 28,657,084; fit for military service 17,585,542; reach
military age (17) annually 1,337,352 (1993 est.)
Defense expenditures:
exchange rate conversion - $3.2 billion, 6% of GNP (FY91/92)
*Palmyra Atoll, Header
Affiliation:
(territory of the US)
*Palmyra Atoll, Geography
Location:
in the North Pacific Ocean, 1,600 km south-southwest of Honolulu, almost
halfway between Hawaii and American Samoa
Map references:
Oceania
Area:
total area:
11.9 km2
land area:
11.9 km2
comparative area:
about 20 times the size of The Mall in Washington, DC
Land boundaries:
0 km
Coastline:
14.5 km
Maritime claims:
contiguous zone:
12 nm
continental shelf:
200 m (depth)
exclusive economic zone:
200 nm
territorial sea:
12 nm
International disputes:
none
Climate:
equatorial, hot, and very rainy
Terrain:
low, with maximum elevations of about 2 meters
Natural resources:
none
Land use: arable land:
0%
permanent crops:
0%
meadows and pastures:
0%
forest and woodland:
100%
other:
0%
Irrigated land:
0 km2','2e023f14cb5338c82ae78baf4e2489655dca3aea6de6d9ecae39cecfc22d290f','internet-archive','theciaworldfactb00087gut','txt','6946a8c02ad1600040a72d937bae90d11dbd49cbf680b92059bb2100c4893e08','https://archive.org/download/theciaworldfactb00087gut/87.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f513a7284d8096be36b320b17bb7b04f98e14dd5f8ac399204d00b402673371',1993,'SG','Singapore','government',188,'People''s Action Party (PAP), GOH Chok Tong, secretary general
opposition:
Workers'' Party (WP), J. B. JEYARETNAM; Singapore Democratic Party (SDP),
CHIAM See Tong; National Solidarity Party (NSP), leader NA; Barisan Sosialis
(BS, Socialist Front), leader NA
Suffrage:
20 years of age; universal and compulsory
Elections:
President:
last held 31 August 1989 (next to be held NA August 1993); results -
President WEE Kim Wee was reelected by Parliament without opposition
Parliament:
last held 31 August 1991 (next to be held 31 August 1996); results - percent
of vote by party NA; seats - (81 total) PAP 77, SDP 3, WP 1
Executive branch:
president, prime minister, two deputy prime ministers, Cabinet
Legislative branch:
unicameral Parliament
Judicial branch:
Supreme Court
Leaders:
Chief of State:
President WEE Kim Wee (since 3 September 1985)
Head of Government:
Prime Minister GOH Chok Tong (since 28 November 1990); Deputy Prime Minister
LEE Hsien Loong (since 28 November 1990); Deputy Prime Minister ONG Teng
Cheong (since 2 January 1985)
Member of:
APEC, AsDB, ASEAN, C, CCC, COCOM (cooperating country), CP, ESCAP, G-77,
GATT, IAEA, IBRD, ICAO, ICC, ICFTU, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT,
INTERPOL, IOC, ISO, ITU, LORCS, NAM, UN, UNAVEM II, UNCTAD, UNIKOM, UPU,
WHO, WIPO, WMO
Diplomatic representation in US:
chief of mission:
Ambassador S. R. NATHAN
*Singapore, Government
chancery:
1824 R Street NW, Washington, DC 20009 telephone:
(202) 667-7555
US diplomatic representation:
chief of mission:
Ambassador Jon M. HUNTSMAN, Jr.
embassy:
30 Hill Street, Singapore 0617
mailing address:
FPO AP 96534
telephone:
[65] 338-0251
FAX:
[65] 338-4550
Flag:
two equal horizontal bands of red (top) and white; near the hoist side of
the red band, there is a vertical, white crescent (closed portion is toward
the hoist side) partially enclosing five white five-pointed stars arranged
in a circle
*Singapore, Economy
Overview:
Singapore has an open entrepreneurial economy with strong service and
manufacturing sectors and excellent international trading links derived from
its entrepot history. The economy appears to have pulled off a soft landing
from the 9% growth rate of the late 1980s, registering higher than expected
growth in 1992 while stemming inflation. Economic activity slowed early in
1992, primarily as a result of slackened demand in Singapore''s export
markets. But after bottoming out in the second quarter, the economy picked
up in line with a gradual recovery in the United States. The year''s best
performers were the construction and financial services industries and
manufacturers of computer-related components. Rising labor costs continue to
be a threat to Singapore''s competitiveness, but there are indications that
productivity is catching up. Government surpluses and the rate of gross
national savings remain high. In technology, per capita output, and labor
discipline, Singapore is well on its way toward its goal of becoming a
developed country.
National product:
GDP - exchange rate conversion - $45.9 billion (1992)
National product real growth rate:
5.8% (1992)
National product per capita:
$16,500 (1992)
Inflation rate (consumer prices):
2.3% (1992)
Unemployment rate:
2.7% (June 1992)
Budget:
revenues $10.4 billion; expenditures $9.4 billion, including capital
expenditures of $NA (1993)
Exports:
$61.5 billion (f.o.b., 1992)
commodities:
computer equipment, rubber and rubber products, petroleum products,
telecommunications equipment
partners:
US 21%, Malaysia 13%, Hong Kong 8%, Japan 7%, Thailand 6%
Imports:
$66.4 billion (f.o.b., 1992)
commodities:
aircraft, petroleum, chemicals, foodstuffs
partners:
Japan 21%, US 16%, Malaysia 14%, Taiwan 4%
External debt:
$0 Singapore is a net creditor
Industrial production:
growth rate 2.3% (1992); accounts for 28% of GDP
Electricity:
4,860,000 kW capacity; 18,000 million kWh produced, 6,420 kWh per capita
(1992)
Industries:
petroleum refining, electronics, oil drilling equipment, rubber processing
and rubber products, processed food and beverages, ship repair, entrepot
trade, financial services, biotechnology
Agriculture:
occupies a position of minor importance in the economy; self-sufficient in
poultry and eggs; must import much of other food; major crops - rubber,
copra, fruit, vegetables
*Singapore, Economy
Illicit drugs:
transit point for Golden Triangle heroin going to the US, Western Europe,
and the Third World; also a major money-laundering center
Economic aid:
US commitments, including Ex-Im (FY70-83), $590 million; Western (non-US)
countries, ODA and OOF bilateral commitments (1970-89), $1.0 billion
Currency:
1 Singapore dollar (S$) = 100 cents
Exchange rates:
Singapore dollars (S$) per US$1 - 1.6531 (January 1993), 1.6290 (1992),
1.7276 (1991), 1.8125 (1990), 1.9503 (1989), 2.0124 (1988)
Fiscal year:
1 April - 31 March
*Singapore, Communications
Railroads:
38 km of 1.000-meter gauge
Highways:
2,644 km total (1985)
Ports:
Merchant marine:
492 ships (1,000 GRT or over) totaling 9,763,511 GRT/15,816,384 DWT;
includes 1 passenger-cargo, 125 cargo, 72 container, 7 roll-on/roll-off
cargo, 4 refrigerated cargo, 18 vehicle carrier, 1 livestock carrier, 165
oil tanker, 8 chemical tanker, 7 combination ore/oil, 2 specialized tanker,
5 liquefied gas, 74 bulk, 3 combination bulk; note - many Singapore flag
ships are foreign owned
Airports:
total:
10
usable:
10
with permanent-surface runways:
10
with runways over 3,659 m:
2
with runways 2,440-3,659 m:
4
with runways 1,220-2,439 m:
3
Telecommunications:
good domestic facilities; good international service; good radio and
television broadcast coverage; 1,110,000 telephones; broadcast stations - 13
AM, 4 FM, 2 TV; submarine cables extend to Malaysia (Sabah and peninsular
Malaysia), Indonesia, and the Philippines; satellite earth stations - 1
Indian Ocean INTELSAT and 1 Pacific Ocean INTELSAT
*Singapore, Defense Forces
Branches:
Army, Navy, Air Force, People''s Defense Force, Police Force
Manpower availability:
males age 15-49 853,440; fit for military service 629,055 (1993 est.)
Defense expenditures:
exchange rate conversion - $1.7 billion, 4% of GDP (1990 est.)
*Slovakia, Geography
Location:
Eastern Europe, between Hungary and Poland
Map references:
Ethnic Groups in Eastern Europe, Europe, Standard Time Zones of the World
Area:
total area:
48,845 km2
land area:
48,800 km2
comparative area:
about twice the size of New Hampshire
Land boundaries:
total 1,355 km, Austria 91 km, Czech Republic 215 km, Hungary 515 km, Poland
444 km, Ukraine 90 km
Coastline:
0 km (landlocked)
Maritime claims: none; landlocked
International disputes:
Gabcikovo-Nagymaros Dam dispute with Hungary; unresolved property issues
with Czech Republic over redistribution of former Czechoslovak federal
property; establishment of international border between the Czech Republic
and Slovakia
Climate:
temperate; cool summers; cold, cloudy, humid winters
Terrain:
rugged mountains in the central and northern part and lowlands in the south
Natural resources:
brown coal and lignite; small amounts of iron ore, copper and manganese ore;
salt; gas
Land use:
arable land:
NA%
permanent crops:
NA%
meadows and pastures:
NA%
forest and woodland:
NA%
other:
NA%
Irrigated land:
NA km2','e4aefd61d6a12358eb5f59d2be4f469bd81941aa98c505ee5a9ce12492befc37','internet-archive','theciaworldfactb00087gut','txt','6946a8c02ad1600040a72d937bae90d11dbd49cbf680b92059bb2100c4893e08','https://archive.org/download/theciaworldfactb00087gut/87.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

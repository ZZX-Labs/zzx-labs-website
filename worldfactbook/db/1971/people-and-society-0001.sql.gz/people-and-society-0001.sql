SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e57bb14e08cdfc4f31f2c98592d2c30ced8f723aedcd1e674596135f40b0cd5a',1971,'','','people-and-society',2,'Population: 38,198,000, average annual growth rate 2.6%
(10/65-10/70)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force','49fded7edad1505d176731698caed4da46556420727747bae87bb3d1dba995fc','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13c74ce62a3dbc82b0cc5a4a9893e7cc7a6a10cf006f93074e9ee471124002d6',1971,'UY','Uruguay','people-and-society',4,'Population: 43,767,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and_ Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 16.4 million; 61% agriculture, 13% industry,
25% service; substantial shortage of skilled labor; ample
unskilled labor_(1978)
Organized labor: 12% of labor force','b3be774a70e97b42b56eab0897304b7fe2e4ba82dbcc0a8e815e1168ee37187e','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d9fb7f3b1744e976b5450ac9d2c8a04eaead47309348f55d05be2a3974b5dfb',1971,'TV','Tuvalu','people-and-society',9,'Population: 6,000 (preliminary total from census of 8
December 1973)
Ethnic divisions: Polynesian
Religion: Protestant
Literacy: less than 50%','71c6fec5a487b746bbff47adacd4268d5e738eb3f75fcdfd86e912a45c23f6dc','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5aeac9d644862cdd74fadcd8f1a7c8d68743d306f27a0c58c1d2ecc48da760cf',1971,'','','people-and-society',2,'Population: 38,198,000, average annual growth rate 2.6%
(10/65-10/70)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force','49fded7edad1505d176731698caed4da46556420727747bae87bb3d1dba995fc','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c7feac3e2b6917d96fb90030d590e881786ff15312d1e8b4cb37e6976b34c1f',1971,'TH','Thailand','people-and-society',3,'Population: 44,236,000 (July 1979), average annual
growth rate 2.5% (current) 2
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 85% Turkish, 12% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish) - . ,
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 17.2 million; 57% agriculture, 18% industry,
25% service; substantial shortage of skilled Jabor; ample
unskilled labor (1978)
Organized labor: 25% of labor force
“SECRET
“SEGREL_
''TURKEY','ce3b376e10fc5e3a157f57875953b44003b707f40a7aaade114ae7e9325da507','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18df0e2150d9381b5e3e7d67c71d24d65035db1f623351ff84a094f63865321c',1971,'','','people-and-society',2,'Population: 37,717,000, average annual growth rate 2.6%
(current) ,
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English ;
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force
ARABIA','f8b7605ba1b2a23088aac7fcfb362b6313b7efb6c969c93029fd1c2dc7706c95','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0016cb2a8da758cb58bd30a2c491f9eb56d61c93c7c6afd6410333139e8514e6',1971,'','','people-and-society',2,'Population: about 18 million, average annual growth rate
2.5% (FY65-70); males 15-49, about 4.5 million; 2.4
million fit for military service; about 165,000 reach
military age (22) annually
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9% Uzbeks,
9% Hazaras, minor ethnic groups include Chahar,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 40% Pushtu, 40% Afghan Persian (Dari), 10% Turkic languages (primarily
Uzbeki and Turkmeni), 10% 30 minor languages (primarily Baluchi and Pashai);
much bilingualism
Literacy: under 10%
Labor force: about 3.7 million (official est., considered low); 75%-80%
agriculture and animal husbandry; 15%-25% commerce, small industry,
services; massive shortage of skilled labor
Organized labor: none
Population: 2,183,000, average annual growth rate 2.7%
(current); males 15-49, 515,000; 425,000 fit for mili-
tary service; 22,000 reach military age (19) annually
Ethnic divisions: 96% Albanian; remaining 4% are Greeks,
Vlachs, Gypsies, and Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10% Roman
Catholic (observances prohibited; Albania claims to be the world''s first
atheist state)
Language: Albanian Greek
Literacy: about 70%; no reliable current statistics available, but probably
greatly improved
Labor force: 911,000 (1967); 60.5% agriculture, 17.9% industry, 21.6% other
nonagricul tural
Population: 14,200,000, average annual growth rate 3.1%
(FY69); males 15-49, 3,374,000; 1,940,000 fit for
military service; average number reaching military age
(19) annually 35,000
Ethnic divisions: 99% Arab-Berbers, less than 1% Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 2.8 million; 47% agriculture, 8% industry, 24% other (military,
police, civil service, transportation workers, teachers, merchants,
construction workers); 40% of urban labor unemployed
Organized labor: 17% of labor force claimed; General Union of Algerian
Workers (UGTA) is the only labor organization and is subordinate to the
National Liberation Front
Population: 23,000, average annual growth rate 9.6% (FY65-69)
Ethnic divisions: Catalan stock; 44% Andorrans, 50%
Spanish, 3% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan; many also speak some French and
Castilian KiBERA
Labor force: unorganized; largely shepherds and farmers ne
Population: 5,575,000, average annual growth rate 1.3%
(FY68); males 15-49, 1,386,000, fit for military
service, 660,000; average number reaching military
age (20) annually about 50,000
Ethnic aaa 93.6% Negro, 5% Europeans, 1.4% mulatto
(1960
Religion: about 84% animist, 12% Roman Catholic,
4% Protestant
Language: Portuguese (official), many native dialects
Literacy: 10%-15%
Labor force: 2.6 million economically active (1964); 531,000 wage workers (1967)
Population: 65,000, average annual growth rate 1.6% (FY69)
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other
Protestant sects and some Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000
Population: 23,638,000, average annual growth rate 1.6%
(September 60-70); males 15-49, 6,091,000; 4,510,000
fit for military service; average number reaching
military age (20) annually about 215,000
Ethnic divisions: approximately 85% white; 15% mestizo,
Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic (less than 20%
practicing Roman Catholics), 2% Protestant, 2%
Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 9.5 million; 19% agriculture, 25% manufacturing, 11% commerce,
35% other, 4%-5% unemployed
Organized labor: 25% of labor force (est.)
Population: 7,421,000, average annual growth rate 0.3%
(FY69); males 15-49, 1,666,000; 1,340,000 fit for
military service; average number reaching military age
(19) annually about 49,000
Ethnic divisions: 98.1% German, .7% Croatian, .3% Slovene,
.9% other
Religion: 88% Roman Catholic, 7% Protestant, 5% none or
other
Language: German
Literacy: 98%
Labor force: 3,190,500 (of which 828,200 are self-employed); 18% agriculture
and forestry, 49% industry and crafts, 18% trade and communications, 7%
professions, 6% public service, 2% other; 2.0% registered unemployed; an
estimated 200,000 Austrians are employed in other European countries; foreign
labor about 87,000 (1970)
Organized labor: about 2/3 of wage and salary workers','b54a95117ee2f9eba30c0770c2e09bdcbd317c457d5d4d41e155928b55e8fec7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d367c427def5190045530a41efb66f53fcada8820cd0c4a45c525ce80f68d33',1971,'DZ','Algeria','people-and-society',25,'Population: 219,000, average annual growth rate 3.1%
(FY67-68); males 15-49, 58,000; fit for military
service 30,000
Ethnic divisions: almost entirely Arab
Religion: Muslim
Language: Arabic
Literacy: about 30%
Labor force: 53,274 (1965)
Population: 9,759,000, average annual growth rate 0.6%
(FY61-69); males 15-49, 2,262,000; 1,805,000 fit for
military service; average number reaching military
age (19) annually 71,000
Pe Ethnic divisions: 55% Flemings, 33% Walloons, 12% mixed
or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch); divided along ethnic lines
Literacy: 97%
Labor force: 3.9 million; 5.5% agriculture, forestry, hunting, and fishing; 43%
mining, manufacturing and construction; 39% commerce and services; 8%
transportation; 1.8% insured unemployed; shortage of unskilled labor, none
Organized labor: 48% of labor force (1969)
eae 53,000, average annual growth rate 2.0%
FY69 j 4
Ethnic divisions: approximately 63% African, 37% white BRAZIL
Religion: 47.5% Church of England, 10.2% Catholic, a ee
38.2% other Protestant, 4.2% other
Language: English
Literacy: virtually 100%
Labor force: 19,498 employed (1960)
Population: 750,000 (official est. for 1 duly 1968); males
15-49, 195,000; 100,000 fit for military service;
about 8,000 reach military age (18) annually
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese,
15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25% Buddhist-inf luenced
Hinduism
Language: Bhotias speak various Tibetan dialects; most
widely spoken dialect is Druk-ke, the official language; Nepalese speak
various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry; massive Tack of skilled
Tabor
Population: 4,773,000, average annual growth rate 2.5%
(current); males 15-49 1,185,000; 750,000 fit for
military service; average number reaching military age
(19) annually about 57,000
Ethnic divisions: 50%-75% Indian, 20%-35% Mestizo,
5%-15% white
Religion: predominantly Roman Catholic
Language: Spanish and Indian (Aymara and Quechua)
Literacy: 35%-40%
Labor force: 1.9 million (1965); 61.9% agriculture, 3.3% mining, 9.6% services
and utilities, 8% manufacturing, 10% other
Organized labor: 40%-50% of labor force
Population: 668,000, average annual growth rate 3.0% (FY69);
98.9% Bantu; males 15-49, 150,000; 75,000 fit for
military service; 8,000 reach military age (18) annually
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% European
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: less than 25% in English; about 33% in Tswana;
less than 1% secondary school graduates
Labor force: most are engaged in sheep raising and
subsistence agriculture (statistics unavailable); about 25,000 in internal
cash economy, another 40,000 spend at least 6 to 9 months per year as
wage earners in South Africa (1964)
Organized labor: negligible
Population: 94,537,000, average annual growth rate 2.8%
(September 60-70); males 15-49,
21,500,000; 13,135,000 fit for military service;
1,130,000 reach military age (18) annually
Ethnic divisions: 61.8% white, 26.6% brown, 11% Negro,
ey (Brazilian census color classifications,
950
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: about 61% over age 14
Labor force: 31 million in 1968 (est.); 54% agriculture and mining, 13%
manufacturing industries, 33% commerce and services
Organized labor: about 50% of labor force; only about 1.5 million pay dues
Population: 124,000, average annual growth rate 3.6%
(FY69); males 15-49, 31,000; 16,000 fit for military
service; about 1,000 reach military age (18) annually
Ethnic divisions: 52% Malays, 28% Chinese, 15% indigenous
tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8%
Christian; 32% other (Buddhist and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture; 32.8% industry, manufacturing, and
construction; 33.8% trade, transport, services; 2.9% other
Organized labor: 8.4% of labor force
Population: 8,568,000, average annual growth rate 0.8%
(current); males 15-49, 2,259,000; 1,885,000 fit for
military service; about 69,000 reach military age (19)
annually
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsies, 2.5% Macedonians, 0.3% Armenians, 0.2%
Russians, 0.3% other
Religion: regime promotes atheism; religious background of population is 85%
Bulgarian Orthodox, 13% Muslim, 0.8% Jewish, 0.7% Roman Catholic, 0.5%
Protestant, Gregorian-Armenian and other
Language: Bulgarian; secondary languages closely correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 4.4 million (July 1970); 38% agriculture, 33% industry, 29% other
GOVERN
BURMA
262,000 sq. mi.; 23% arable, of which 12% is cultivated,
67% forest, 10% urban and other area (1965)
Limits of territorial waters: 12 n. mi. (extended base
lines 15 November 1968)
Population: 28,202,000, average annual growth rate 2.2%
(FY69); males 15-49, 6,834,000; 2,965,000 fit for
military service; about 275,000 males and 266,000
females reach military age (18) annually; both are
liable for military service
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2%
Kachin, 2% Chin, 2% Chinese, 3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their own languages
Literacy: 60% (official claim)
Labor force: 10 million; 67% agriculture; 13% industry; 20% services, commerce,
and transportation
Organized labor: no figure available; old labor organizations have been
disbanded, and government is forming one central Tabor organization
MENT:
Legal name: Union of Burma
Type: military dictatorship since suspension of constitution in 1962
Capital: Rangoon :
Political subdivisions: Burma proper, 4 other constituent states and 1 special
division for the ethnic minorities; subdivided into divisions, districts,
muncipalities, townships, and villages
Legal system: based on English common law and incorporates Buddhist, Hindu,
and Islamic relgious law; constitution of 1947 superseded by acts of the
new Revolutionary Government, which seized power in 1962; legal education
at Universities of Rangoon and Mandalay; has not accepted compulsory ICJ
jurisdiction
Branches: Revolutionary Council rules through a Council of Ministers
Government leader: Chairman of Revolutionary Council, Gen. Ne Win
Suffrage: universal: over. age. 18 under suspended constitution
Elections: none held under present regime
Political parties and leaders: government-sponsored Burmese Socialist Program
Party only legal party
Communists: 5,000
Member of: Colombo Plan, FAQ, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF,
ITU, U.N., UNESCO, UPU, WHO, WMO
11,000 sq. mi.; about 37% arable (about two-thirds of
arable land cultivated), 23% pasture, 10% scrub
and forest, 30% other
Population: 3,617,000, average annual growth rate 2.0%
(FY69); males 15-49, 851,000; 409,000 fit for military
service; 39,000 reach military age (16) annually
Ethnic divisions: Africans -- 86% Hutu (Bantu), 13% Tutsi
(Hamitic), 1% Twa (Pigmy); non-Africans include (late
1968) 3,000 Europeans, 1,000 Asians
Religion: over 60% Christian (50% Catholic, 10% Protestant) ;
rest mostly animist plus small number of Muslims
Language: Kirundi and French official
Literacy: about 55% in Kirundi, 10% in Swahili, or 6% in French
Labor force: 1,865,471 (1970 est.)
Organized labor: sole group is the Union of Burundi Workers (UTB), membership
about 30,000, affiliated with government party
Population: 6,999,000, average annual growth rate 2.2%
(FY69); males 15-49, 1,572,000; 875,000 fit for
military service; 81,000 reach military age (18)
annual ly
Ethnic divisions: 89% Khmer (Cambodian), 3% Vietnamese,
5% Chinese, 3% other minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian
Literacy: 55% (est.)
Labor force: 2.56 million; 80.9% agriculture; 5.5% sales; 4.7% manufacturing,
transport, communications; 3.9% professional, administrative, clerical;
3.5% defense; 1.5% unemployed
Organized labor: .5% of labor force
Population: 5,938,000, average annual growth rate 1.7%
(FY70); males 15-49, 1,286,000; 670,000 fit for
military service; average number reaching military
age (18) annually about 55,000
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroon Highlanders, 19% Equatorial
Bantu, 8% North West Bantu, 10% Fulani, 7% Eastern
Nigritic, 11% Kirdi, 13% other African, less than 1% non-African
Religion: about one-half animist, one-third Christian; rest Muslim
Language: English and French official, 24 major African language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence agriculture; 200,000 wage
earners (maximum) including 22,000 government employees, 63,000 paid
agricultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force
Population: 1,580,000, average annual growth rate 2.0%
(FY69); males 15-49, 411,000; 195,000 fit for
military service
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and linguistic
characteristics; Banda (32%) and Baya (29%) are
largest single groups; 6,500 Europeans, of whom 6,000
are French and majority of the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 27% animist, 5% Muslim; animistic
beliefs and practices strongly influence the Christian majority, however
Language: French official; Sangho, the lingua franca and unofficial national
language
Literacy: estimated by the C.A.R. Government at 18%
Labor force: about half the population economically active, 80% of whom are in
agriculture; between 50,000 and 85,000 salaried workers (1966)
Organized labor: 1% of labor force
Population: 12,802,000, average annual growth rate 2.3%
(FY68-69); males 15-49, 3,081,000; 2,320,000 fit for
military service; 140,000 reach military age (18)
annually
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor,
2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6%
Muslim, 1% other
Language: Sinhala official, spoken by about 70% of population; Tamil spoken by
about 22%; English commonly used in government and spoken by about 10%
of the population
Literacy: 82% (1970 est.)
Labor force: 3.6 million; 10% unemployed and substantial underemployment ;
employed persons ~~ 53.4% agriculture, 14.8% mining and manufacturing,
12.4% trade and transport, 19.4% services and other
Organized labor: 33% of labor force, over 50% of which employed on tea, rubber,
and coconut estates
Population: 3,612,000, average annual growth rate 1.4%
(FY69); males 15-49, 915,000; 455,000 fit for military
service; average number reaching military age (20)
annually about 33,000
Ethnic divisions: over 240 tribes representing 12 ethnic
groups -- white Muslims (Arabs, Toubou, and Fulani)
and black Muslims (Kotoko, Hausa, Kanembou, Baguirmi,
Boulala, and Wadai) in the north and center and non-
Muslims (Sara, Mayo-Kebbi, and Chari) in the south;
some 150,000 nonindigenous, 5,000 of them French
Religion: about half Muslim, 5% Christian, remainder animist
Language: French official; Chadian Arabic is lingua franca in north, Sara and
Sangho in south
Literacy: about 7%
Labor force: only 55% of population in economically active group, of which 90%
are engaged in unpaid subsistence farming, herding, and fishing; most are
wage earners in industry and civil service
Organized labor: about 20% of wage labor force
Population: 9,037,000, average annual growth rate 1.9%
(November 60-April 70); males 15-49, 2,226,000;
1,660,000 fit for military service; average number
reaching military age (19) annually about 100,000
Ethnic divisions: 85%-90% mestizo, 3% Indian, 7% European,
Asiatic, and other
Religion: 90% Roman Catholic, 5% (est.) Evangelical, 5% other
Language: Spanish
Literacy: 84%
Labor force: 3.1 million (1969); 28% agricultural, 24% industry and construction,
24% services, 10% commerce, 4% mining, 10% other (1962)
Organized labor: 20% of labor force
Population: 854,943,000, average annual growth rate 2.2% a AUETRALIA
(current)
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur, Hui, Yi, Tibetan, Miao,
Manchu, Mongol, Pu-I, Korean, and numerous lesser nationalities
Religion: most people, even before 1949, have been pragmatic and eclectic --
not seriously religious; most important elements of religion are Confucian-
ism, Taoism, Buddhism, ancestor worship; about 2%-3% Muslim, 1% Christian
Language: Chinese (Mandarin mainly; also Cantonese, Wu, Fukienese, Amoy, Hsiang,
Kan, Hakka dialects); and minority languages (see ethnic divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85% agriculture, 15% other; shortage of
skilled labor (managerial, technical, mechanics, etc.); surplus of unskilled
labor
Population: 14,835,000 (excluding the population of
Quemoy and Matsu Islands and foreigners), average
annual growth rate 2.3% (January 70-71); males 15-49,
3,438,000; 2,620,000 fit for military service; average
number currently reaching military age (19) annually
175,000
Ethnic divisions: 84% Taiwanese, 14% Mainland Chinese, 2% aborigines
Religion: 93% mixture of Buddhism, Confucianism, and Taoism; 4.5% Christian;
2.5% other
Language: Mandarin, Taiwanese, Japanese, English
Literacy: about 90%
Labor force: 4.5 million; 41% agriculture, forestry, fishing; 18% manufacturing;
15% services; 15% commerce; 5% transportation and communications ;
A% construction; 2% mining; all percentages based on 1968 data
Organized labor: about 10% of 1968 labor force (government controlled)
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
440 ,000 sq. mi.; 6% cultivated, 18% meadows and pastures, erage
53% forested, 5% inland water, 18% built-up area
(est. 1964)
Limits of territorial waters: 12 n. mi.
Population: 22,553,000, average annual growth rate 3.2%
(current); males 15-49, 5,284,000; 3,200,000 fit for
military service; average number reaching military
age (18) annually about 239,000
Ethnic divisions: 58% mestizo, 14% mulatto, 3% zambos, 20%
white, 4% Negro, 1% Indian
Religion: 95% Roman Catholic, 1% other or none
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 42% agriculture, 15% manufacturing, 20% services,
23% other (1962)
Organized labor: 13% of labor force
Population: 953,000, average annual growth rate 2.0%
(current); males 15-49, 221,000; 105,000 fit for
military service; about 8,000 reach military age
(20) annually
Ethnic divisions: about 15 ethnic groups divided into some
75 tribes, almost all Bantu; most important ethnic
groups are Kongo (45%) in south, Teke (17%) in center, M''Bochi (12%) and
Sangha (20%) in north; about 8,500 Europeans, mostly French
Religion: about half animist, half nominally Christian, less than 1% Muslim
Language: French official, many African languages with Lingala and Kikongo
most widely used
Literacy: about 20%
Labor force: about 40% the population economically active, most engaged in
subsistence agriculture; 79,000 wage earners; 40,000-60,000 unemployed
Organized labor: 16% (est.) of total labor force (1965)
Population: 22,285,000, average annual growth rate 2.3%
(FY68); males 15-49, 5,438,000; 2,605,000 fit for
military service
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes -- Mongo, Luba,
Kongo (all Bantu), and the Mangbetu-Azande (Hamitic)
make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo, and Chiluba are all
classified as official languages
Literacy: 5% fluent in French, about 35% have an acquaintance with French
Labor force: about 8 million, but only about 13% in wage structure
Population: 1,792,000, average annual growth rate 3.1%
(FY69); males 15-49, 382,000; 269,000 fit for military
service; average number reaching military age (18)
annually about 21,000 -
Ethnic divisions: 98% white (including mestizo), 2% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: approximately 80%
Labor force: 457,000 (1968); 46.3% agriculture; 13.2% manufacturing; 11% commerce;
8% construction, transportation, and communications; 21.5% other; shortage
of skilled labor
Organized labor: about 10% of labor force
Population: 8,645,000, average annual growth rate 1.3%
(current); males 15-49, 1,054,000; 145,000 fit for
military service; about 76,000 males and 73,000
females reach military age (17) annually; both liable
for service
Ethnic divisions: 51% mulatto, 37% white, 11% Negro,
1% Chinese
Religion: at least 85% nominally Roman Catholic before Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.6 million; 34% agriculture, 17% industry, 6% construction, 6%
transportation, 29% services, 8% unemployed and underemployed
Organized labor: 70% of total force
a Population: 14,526,000, average annual growth rate 0.4%
: (current); males 15-49, 3,658,000; 2,815,000 fit for
military service; about 130,000 reach military age
(18) annually
Ethnic divisions: 64.5% Czechs, 29.6% Slovaks, 3.9% Magyars,
1% Germans, 1% Ukrainians, Jews, Poles
- Religion: 77% Roman Catholic, 20% Protestant, 2%
Orthodox, 1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.1 million; 18% agriculture, 37% industry, 11% services, 34%
construction, communications and others
SAUDI 2 n
ARABIA pc
Population: 2,795,000, average annual growth rate 2.8%
(FY65-68); males 15-49, 662,000; 320,000 fit for mili-
tary service; about 29,000 males and 27,000 females
reach military age (18) annually; both sexes liable
for military service
Ethnic divisions: 99% Africans (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba), 5,500 Europeans
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most common vernaculars in south,
at least 6 major tribal languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture; 15% civil service,
artisans, and industry
Organized labor: approximately 75% of wage earners, divided among two major
and several minor unions
Population: 4,959,000, average annual growth rate 0.7%
(FY66-69); males 15-49, 1,186,000; 1,040,000 fit for
military service; 38,000 reach military age (20) Sy ALGERIA
a annual ly E
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 1% other
Language: Danish; small German-speaking minority
Literacy: 99%
Labor force: 2.4 million; 14.5% agriculture, forestry, fishing; 29.4% mining and
manufacturing; 8.1% construction; 15.0% commerce; 6.6% transportation and
communications; 23.6% services; 0.2% other; 2.6% unemployed
Organized labor: 65% of labor force
Population: 4,197,000, average annual growth rate 3.0%
(August 60-January 70); males 15-49, 1,033,000;
630,000 fit for military service; 51,000 reach military
age (18) annually
Ethnic divisions: 70% mulatto, 15% white, 15% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 35% to 40% of adult population
Labor force: 1.3 million; 73% agriculture, 8% industry, 19% services and other
Organized labor: 12% of labor force
Population: 8,824,000, average annual growth rate 2.4%
(March 60-70); males 15-49, 2,035,000; 1,090,000 fit
for military service; 105,000 reach military age (18)
annual ly
Ethnic divisions: 99.8% Negroid African (major tribes
Fanti, Ashanti, Ewe), 0.2% European and other
Religion: 45% animists, 42.8% Christian, 12% Muslim
Language: English official; African languages include Akan 44%, Mole-Dagbani 162,
Ewe 13%, and Ga-Adangbe 8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing; 16.8% industry; 15.2%
sales and clerical; 4.1% services, transportation, and communications ;
2.9% professional; 400,000 unemployed
Organized labor: 10.3% of labor force
Population: 27,000 (official estimate for 31 December
1968); males 15-49, about 6,000; about 3,000 fit for
military service
Ethnic divisions: mostly Italian, English, Maltese, and
Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages ;
Italian, Portuguese, and Russian also spoken; English
used in the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian laborers
Organized labor: 3,369, in 27 registered trade unions
caecol ALGERIA
Population: 8,747,000, average annual growth rate 0.4%
(March 61-71); males 15-49, 2,126,000; 1,710,000 fit
for military service; about 68,000 reach military age
(21) annually
Ethnic divisions: 96% Greek, 2% Turkish, 1% Albanian,
1% other .
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total about 82%
Labor force: 3.7 million (1967 est.); 50% agriculture, 15% industry, 9% trade,
26% other; unemployment and underemployment, 20% total in all fields;
shortage of skilled labor in nonagricultural sectors aggravated by large-
scale emigration
Organized labor: 10% of labor force
Population: 52,000, average annual growth rate 4.7% (FY68);
males 15-49, included with Denmark
Ethnic divisions: 86% Greenlander (Eskimos and Greenland-
born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep breeding
Population: 5,421,000, average annual growth rate 2.8%
(current); males 15-49, 11,326,000; 670,000 fit for
military service; about 60,000 reach military age
(18) annually
Ethnic divisions: 44% Indian, 56% Ladino (mestizo and
Indian -- Westernized)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks an Indian language as
a primary tongue
Literacy: about 30%
Labor force: 1.5 million (1969); 63.2% agriculture, 12.4% manufacturing, 11.8%
services, 12.6% other, 2% unemployed; severe shortage of skilled labor;
oversupply of unskilled labor; of this total an estimated 10% are unemployed
at any one time
Organized labor: 6.5% of labor force (1969)
Population: 4,968,000, average annual growth rate 2.1%
(FY69); males 15-49, 1,240,000; 660,000 fit for
military service; about 51,000 reach military age
(18) annually
Ethnic divisions: over 90% Negro, nearly 10% mulatto, few
whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of
which an overwhelming majority also practice Voodoo)
Language: French (official) spoken by only 10% of population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.6 million (est. January 1968); 86% agriculture, 12% industry,
2% unemployed; shortage of skilled Jabor; unskilled labor abundant
Organized labor: less than 1% of labor force
Population: 2,667,000, average annual growth rate 3.4%
(FY69); males 15-49, 661,000; 390,000 fit for military
service; about 28,000 reach military age (18) annually
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: Roman Catholic
Language: Spanish
Literacy: 47% of persons 10 years of age and over
Labor force: approx. 750,000 (1969); 66% agriculture, 12% services, 8%
manufacturing, 5% commerce, 6% unemployed, 3% unspecified
Organized labor: 5% of labor force (1969)
Population: 4,174,000, average annual growth rate 2.1%
(FY69-70); males 15-49, 1,058,000; 815,000 fit for
military service; about 47,000 reach military age
(18) annually
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local
religions
Language: Chinese, English
Literacy: 75%
Labor force (1969 est.): 1.52 million; 40% manufacturing; 28% services; 11%
construction, mining, quarrying and utilities; 11% commerce; 5% agriculture,
forestry, fisheries, and hunting; 6% communications; 2% other; under-
employment is a serious problem
Organized labor: 12% of 1969 labor force
Population: 10,372,000, average annual growth rate 0.4%
(current); males 15-49, 2,644,000; 2,120,000 fit for
military services; about','4860114bcef955baad7d75746e6091c5e7cf28b1ba8368a9f0c89f584465c1ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbc004f755dfcc0e958a15042166be4eb870ce6513322f99e00a798622f66d3f',1971,'DZ','Algeria','people-and-society',26,'95,000 reach military age
(18) annually
Ethnic divisions: 96.3% Magyar, 2.5% German, 1.2% other
Religion: 67.5% Roman Catholic, 20% Calvinist, 5%
Lutheran, 7.5% atheist and other
Language: 96.2% Magyar, 2.5% German, 1.3% other
Literacy: 97%
Labor force: 5.0 million; 30% agriculture, 40% industry and building, 29%
other nonagricultural
Population: 209,000, average annual growth rate 1.4%
(FY66-69); males 15-49, 49,000; 40,000 fit for military
service (Iceland has no conscription or compulsory
military service) i
Ethnic divisions: homogeneous white population peRUT
Religion: 95% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 80,000; 22.6% agriculture, forestry, fishing; 25.6% mining and
manufacturing; 10.7% construction; 12.8% commerce; 7.8% transportation and
communications; 15.2% services; and 4.0% other; 1.3% unemployed
Organized labor: 60% of labor force
Population: 550,166 ,000 (including Sikkim and the Indian-
held part of disputed Jammu-Kashmir), average annual
growth rate 2.2% (March 61-April 71); males 15-49, 135 ,066 ,000;
75,750,000 fit for military service; about 5,975,000 reach military age (17)
annually
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.5% Christian, .7% Buddhist,
.8% other
Language: 24 languages spoken by a million or more persons each; numerous
other languages and dialects, for the most part mutually unintelligible;
Hindi is the national language and primary tongue of 30% of the people;
English enjoys “associate” status but is the most important language for
national, political, and commercial communication; Hindustani, a popular
variant of Hindi/Urdu, is spoken widely throughout northern India
Literacy: males 27%; females 13%; both sexes 24% (1961 census )
Labor force: about 220 million; 72% agriculture, more than 10% unemployed and
underemployed; shortage of skilled labor is significant and unemployment is
rising
Organized labor: 2.5% to 3% of total labor force’
Population: 122,451,000 (including West Irian),
average annual growth rate 2.5% (FY68); males 15-49, AUSTRALIA
28,068,000; 15,980,000 fit for military service; about
1,440,000 reach military age (18) annually
Ethnic divisions: 45% Javanese, 14% Sundanése, 7.5%
Madurese, 7.5% Coastal Malays, 26% other
Religion: 90% Muslim, 4% Christian, 2% Buddhist, 2% Hindu, 2% other
Language: Indonesia (modified form of Malay) official; English leading
foreign language
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 41 million; 70% agriculture, 15% industry, 15% miscellaneous and
unemployed
Organized labor: 10% of labor force
Population: 29,588,000, average annual growth rate 3.0%
(FY69); males 15-49, 6,985,000; 4,125,000 fit for
military service; about 304,000 reach military
age (21) annually
Ethnic divisions: 63% Ethnic Persians, 3% Kurds, 13% other
Iranian, 18% Turkic, 3% Arab and other Semitic, 1% other
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2% Zoroastrians, Jews, and Christians
Language: Farsi (Persian), Turki, Kurdish, Arabic
Literacy: about 30% of those 10 years of age and older
Labor force: 7.5 million; 47% agriculture; 53% industry, commerce, services,
etc.; shortage of skilled labor substantial
Organized labor: 1.1% of labor force
Population: 9,681,000, average annual growth rate 3.5%
(FY69); males 15-49, 2,179,000; 1,225,000 fit for
military service; about 113,000 reach military age
(18) annually
- Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7% Assyrians ,
2.4% Turkomans, 7.7% other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry, 6.7% government,
16.8% other; rural underemployment high, but not serious because low
subsistence levels make it easy to care for unemployed; severe shortage
of technically trained personnel
Organized labor: 11% of labor force
Population: 2,959,000, average annual growth rate 0.5% ;
(FY67-70); males 15-49, 674,000; 530,000 fit for military
service; about 28,000 reach military age (17) annual ly
Ethnic divisions: racially homogeneous Celts
ad Religion: 94% Roman Catholic, 4% Episcopalian, 2% other
Language: English and Gaelic official; English is general ly
spoken
Literacy: 98%-99%
Labor force: about 1,130,000; 28% agriculture, forestry, fishing; 19% manufac-
turing; 15% commerce; 6% construction; 5% transportation; 4% government;
18% other
Organized labor: 36% of labor force
Population: 4,392,000, average annual growth rate 2.3%
(FY69); males 15-49, 1,521,000; 455,000 fit for
military service
Ethnic divisions: 7 major indigenous ethnic groups; no
single tribe more than 15% of population; most impor-
tant are Agni, Baoule, Krou, Senoufou, Mandingo; approx. 1 million foreign
Africans, mostly Voltaics; about 33,000 non-Africans (25,000 French)
Religion: 67% animist, 22% Muslim, 11% Christian
Language: French official, over 60 native dialects, Dioula most widely spoken
Literacy: about 20%
Labor force: over 85% of population engaged in agriculture, forestry, livestock
raising; about 11% of labor force are wage earners, nearly half in agricul-
ture, remainder in government, industry, commerce, and professions
Organized labor: 20% of wage labor force
® Population: 1,900,000, average annual growth rate 1.5%
(April 60-70); males 15-49, 398,000; 270,000 fit for
military service; no conscription; average number
currently reaching minimum volunteer age (18) 22,000
Ethnic divisions: African 76.3%, Afro-European 15.1%,
PY European 0.8%, Chinese and Afro-Chinese 1.2%, East
Indian and Afro-East Indian 3.4%, other 3.2%
Religion: predominantly Protestant, some Roman Catholic (12%), some spiritualist
cults
Language: English
Literacy: Ministry of Education estimates between 43% and 57% of adult population
truly literate
Labor force: about 687,000; 33% in agriculture, 1% forestry and fishing, 13%
manufacturing, 7% construction, 8% commerce, 2% transportation and communi-
cations, 13% services, 23% unaccounted for; 16% to 18% (est.) unemployed
(seasonal unemployment in agriculture can push the unemployment figure to
25%) 3 shortage of technical and managerial personnel
Organized labor: about 25% of labor force (1966)
Population: 2,395,000, average annual growth rate 3.9% (FY67-69); males 15-49,
553,000; 405,000 fit for military service; average number currently reaching
military age (18) annually 26,000
Ethnic divisions: 97% Arab, 2% Circassian, 1% Armenian
Religion: 94% Sunni Muslim, 6% Christian
Language: Arabic official; English widely understood among upper and middle
classes
Literacy: 33% West Jordan, 32% East Jordan
Labor force: 434,000; 33% unemployed
Organized labor: 5% of labor force
Population: 11,474,000, average annual growth rate 2.9%
(FY69); males 15-49, 2,673,000;
1,295,000 fit for military service; no conscription
Ethnic divisions: 97% native African (including Bantu,
Nilotic, Hamitic and Nilo-Hamitic); 3% European,
Asian, and Arab
Religion: 56% Christian, 36% animist, 7% Muslim, 1% Hindu
Language: English and Swahili official; each tribe has own language
Literacy: 20% to 25%
Labor force: 2.5 million; about 977,000, (39%) in monetary economy (1967)
Organized labor: about 215,000
Population: 14,561,000, average annual growth rate 2.8%
(current); males 15-49, 3,201,000; 1,900,000 fit. for
military service; 150,000 reach military age (18)
annually
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities
now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 5.7 million; 50% agriculture, 50% industry; shortage of skilled and
unskilled labor
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
38,000 sq. mi.; 23% arable (22% cultivated), 10% urban
and other, 67% forested (1968)
Limits of territorial waters: 3 n. mi.
Population: 31,913,000, average annual growth rate 1.9%
(October 66-70); males 15-49, 7,680,000; 4,860,000 fit
for military service; average number reaching military
age (18) annually 334,000
Ethnic divisions: homogeneous; small Chinese minority
(approx. 20,000)
Religion: strong Confucian tradition; pervasive folk
religion (Shamanism); vigorous Christian minority
(5.5% of population); Buddhism (including estimated 20,000 members of Soka
Gakkai); Chondokyo (religion of the heavenly way), eclectic religion with
nationalist overtones founded in 19th century, claims about 1.5 million
adherents
Language: Korean
Literacy: about 90%
Labor force: about 10.5 million (September 1969); 53% agriculture, fishing,
forestry, 27.5% services, 12% mining and manufacturing, 3.5% construction,
4% unemployed
Organized labor: about 10% of nonagricultural labor force
Population: 818,000, average annual growth rate 9.4%
(FY65-70); males 15-49, about 282,000; about 150,000
fit for military service
Ethnic divisions: 37% Kuwaiti Arabs; 40% immigrant Arabs;
23% Iranians, Indians, Pakistani, other
Religion: 98% Muslim (75% Sunni, 25% Shiah); 2% Christian,
Hindu, Parsi, other
Language: Arabic; English commonly used foreign language
Literacy: about 55%
Labor force: 185,000; 9% manufacturing, 16% construction, 45% services, 13%
commerce
Organized labor: labor unions, first authorized in 1964, formed in oil industry
and among government personnel
Population: 3,033,000, average annual growth rate 2.4%
(FY69); males 15-49, 724,000; 380,000 fit for military
service; average number currently reaching usual
military age (18) annually, 32,000; ho conscription
age specified
Ethnic divisions: 47% Lao; 14% Tai; 25% Phoutheng (Kha),
Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant foreign language also used in
administration
Literacy: about 12%
‘Labor force: about 1,268,000; over 90% agriculture; 159,286 engaged in
manufacturing and services; 11,864 government employees
Organized labor: only civil servants are organized
Population: 2,780,000, average annual growth rate 2.5%
(FY69); males 15-49, 678,000; 400,000 fit for military viens
service; average of about 28,000 reach military age ie es SAUDI
(18) annually eee ARABIA
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1% other
(official estimates); Muslims believed to constitute
slight majority
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically active; 49% agriculture, 11% industry,
14% commerce, 26% other; moderate unemployment
Organized labor: about 55,000
Population: 919,000, average annual growth rate 1.6%
(FY69); males 15-49, 184,000; fit for
military service 95,000
Ethnic divisions: 99.7% Bantu, 1,600 Europeans, 800 Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%.
Labor force: 87.4% of resident population engaged in sub-
sistence agriculture; 150,000 to 250,000 spend 6 months to many years as
wage earners in South Africa
Organized labor: negligible
Population: 1,576,000, average annual growth rate 3.5%
(January 70-71); males 15-49, 282,000; 155,000 fit for
military service; no conscription
Ethnic divisions: 5% coastal descendants of immigrant
Negroes; 95% indigenous Negroid African tribes
including Gola, Kissi, Vai, Kpelle, Kru, and Mandingo
Religion: probably more Muslims than Christians; 80%-90%
animist
Language: English official; 28 tribal languages or dialects, pidgin English used
by about 20%
Literacy: about 24% over age 5
Labor force: 450,000, of which 360,000 are in tribal, nonmonetary economy; of
90,000 in modern economy, 45% in agriculture; 23% government services; 20%
mining, construction, and manufacturing; and 12% in trade and transportation;
about 3,000 non-African foreigners hold about 95% of the top level manage-
ment and engineering jobs
Organized labor: 2% of labor force
Population: 2,008,000, average annual growth rate 3.7%
(FY69); males 15-49, 468,000; 280,000 fit for military
service; about 20,000 reach military age (17) annually;
conscription now being implemented
Ethnic divisions: 97% Berber and Arab with some Negroid
stock; some Greeks, Maltese, Jews, Italians
Religion: 100% Muslim
Language: Arabic; Italian and English widely understood in major cities
Literacy: 35%
Labor force: 458,000-500,000; between ages 15-64, 405,000-430,000; 61% of labor
force in agriculture (1964)
Population: 24,000, average annual growth rate 4.8% (FY69)
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: about 7,000 domestic force; some 3,500 foreign
Population: 343,000, average annual growth rate 0.8% 4
(FY61-69); males 15-49, 78,000; 62,000 fit for military |
service; about 2,000 reach military age (19) annually
Ethnic divisions: 83% Luxembourger, including an estimated
5% of Italian descent; remainder French, German,
Belgian, etc.
Religion: more than 90% Roman Catholic
Language: Luxembourgish, German, French; most educated Luxembourgers also speak
English
Literacy: 98%
Labor force: (1969) 139,000; 11.1% agriculture (including forestry and fishing),
44.2% industry, 44.7% services, no significant unemployment; shortage of
skilled labor 1,000
Organized labor: 45% of labor force
Population: 254,000 (official estimate for 1 July 1968) ;
males 15-49, 67,000; 42,000 fit for military service
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about one-
half are Chinese
Language: Chinese 98%, Portuguese 2%
Literacy: almost 100% among Portuguese and Macanese; no data on Chinese
population
Labor force: 5% agriculture, 30% manufacturing, 3% construction, 1% utilities,
27% commerce, 8% transportation and communications, 26% services (1960 data)
MALAGASY REPUBLIC
230,000 sq. mi.; 5% cultivated, 58% pastureland, 21%
forested, 8% wasteland, 2% rivers and lakes, 6% other
(1965)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.) |
Population: 6,903,000, average annual growth rate 2.3%
(FY70); males 15-49, 1,546,000; 910,000 fit for
military service; average number reaching military age
(20) annually about 60,000
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting of Merina (1,643,000)
and related Betsileo (760,000), on the one hand, and coastal tribes with
mixed Negroid, Malayo-Indonesian, and Arab ancestry on the other; coastal
tribes include Betsimisaraka 941,000, Tsimihety 442,000, Sakalava 375,000,
Antaisaka 415,000; there are also 38,000 French, 66,000 other
Religion: more than half animist; about 35% Christian, less than 10% Muslim
Language: French and Malagasy official
Literacy: 30% to 35%
Labor force: about 3.4 million, of which 90% are nonsalaried family workers
engaged in subsistence agriculture; of 175,000 wage and salary earners,
26% agriculture, 17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscellaneous
Organized labor: 4% of labor force
~~ oe Population: 5,144,000, average annual growth rate 3.0%
(FY69-70); males 15-49, 1,088,000; about 550,000 fit
for military service
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
aid Language: English and Chichewa official; Lomwe is second
African language
Literacy: 6% of population over 21 years old
Labor force: 120,000-150,000 wage earners (1966); 6,000 Europeans permanently
employed; 300,000 live and work in Rhodesia, South Africa, and Zambia; 30%
agriculture, 11% construction, 10% commerce, 13% manufacturing, 10% admini-
stration, 26% miscellaneous services
Organized labor: smal] minority of wage earners are unionized
Population: 10,765,000, average annual growth rate 2.7% (current)
West Malaysia: 9,089,000, average annual growth rate 2.7% (dune 57-August 70);
males 15-49, 2,117,000; 1,295,000 fit for military service
Sabah: 645,000, average annual growth rate 3.3% (July 60-August 70); males
15-49, 155,000; 93,000 fit for military service
Sarawak: 1,031,000, average annual growth rate 2.8% (June 60-August 70);
males 15-49, 248,000; 150,000 fit for military service; conscription age
for Malaysia is 21 -- an age reached by about 112,000 annual ly
Ethnic divisions:
Malaysia: 44% Malay, 36% Chinese, 8% tribal, 10% Indian and Pakistani,
2% other
West Malaysia: 50.1% Malay, 36.9% Chinese, 11% Indian and Pakistani,
2% other
Sabah: 23.1% Chinese, 67.3% indigenous tribes, 9.6% other
Sarawak: 31.5% Chinese, 50% indigenous tribes, 17.5% Malay, 1% other
Religion:
West Malaysia: Malays nearly all Muslim; Chinese predominantly Buddhists;
Indians predominantly Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist, 16% Christian, 35%
tribal religion, 2% other
Language:
West Malaysia: Malay (official); English, Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dialects; Mandarin and Hakka dialects
predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal languages
Literacy:
West Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 3.45 million (1967)
West Malaysia: 2.9 million; 55% agriculture, forestry, and fishing; 11%
manufacturing and construction; 34% trade, transport, and services
Sabah: 213,000 (1967); 80% agriculture, forestry, and fishing; 6% manu-
facturing and construction; 13% trade and transportation; 1% other
197
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Labor force (cont''d): :
Sarawak: 341,000 (1967); 80% agriculture, forestry, and fishing; 6% manu-
facturing and construction; 13% trade, transportation, and services;
1% other
Organized labor: 370,000 members -- official 1967 estimate -- (about 10.5% of
total labor force; 28% of wage labor force); unemployment about 8% of total -
labor force, but higher in urban areas
GOVERNMENT : ~ah.
Legal name: Malaysia
Type: Pa
Malaysia: constitutional monarchy nominally headed by Paramount Ruler (King)
West Malaysian states: hereditary rulers in al? but Penang and Malacca where ;
Governors appointed by Malaysian Government; powers of state governments pon
limited by federal constitution
Sabah: self-governing state within Malaysia in which it holds 16 seats in
House of Representatives; foreign affairs, defense, internal security,
and other powers delegated to federal government
Sarawak: self-governing state within Malaysia in which it holds 24 seats in
House of Representatives; foreign affairs, defense, and internal security,
and other powers are delegated to federal government
Capital: ;
West Malaysia: Kuala Lumpur 7
Sabah: Kota Kinabalu (formerly Jesselton)
Sarawak: Kuching
Political subdivisions: 13 states (including Sabah and Sarawak)
Legal system: based on English common law; constitution came into force 1963;
judicial review of legislative acts in the Supreme Court at request of
Supreme Head of the Federation; has not accepted compulsory ICJ jurisdiction
Branches: 9 state rulers alternate as Paramount Ruler for 5-year terms; locus of
executive power vested in Prime Minister and cabinet, who are responsible
to bicameral parliament; following communal rioting in May 1969, govern-
ment imposed state of emergency and suspended constitutional rights of all
parliamentary bodies; parliamentary democracy is now scheduled to be
resumed in February 1971
West Malaysia: executive branches of 11 states vary in detail but are similar
in design; a Chief Minister, appointed by hereditary ruler or Governor,
heads an executive council (cabinet) which is responsible to an elected,
unicameral legislature
Sarawak and Sabah: executive branch headed by Governor appointed by central
government, largely ceremonial role; executive power exercised by Chief aon
Minister who heads parliamentary cabinet responsible to unicameral si
legislature; judiciary part of Malaysian judicial system
Government leader: Head of State, Tun Abdul Razak
Suffrage: universal over age 20 ~
Elections: minimum of every 5 years
Political parties and leaders:
West Malaysia: Alliance Party consisting of United Malays National Organiza-
tion (UMNO), Tun Abdul Razak; Malaysian Chinese Association (MCA), Tan
Siew Sin; and Malaysian Indian Congress (MIC), V.T. Sambanthan; major
opposition parties -- Pan Malayan Islamic Party (PMIP), Dato Asri bin Haji
198
ae Te ae EE Te a EE aS ae ee ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GOVERNMENT (cont''d):
Political parties and leaders (cont''d):
West Malaysia (cont''d):
Muda (acting); Labor Party of Malaya (LPM), Lim Kean Siew (acting);
Democratic Action Party (DAP); Gerakan Rakyat Malaysia (GRM); minor
opposition parties -- Party Rakyat (PR), People''s Progressive Party (PPP),
United Malaysian Chinese Organization (UMCO); Communist Party illegal
Sabah: United Sabah National Organization (USNO), Tun Mustapha bin Dato
Harun; Sabah Chinese Association (SCA), Khoo Siak Chiew; no organized
opposition
Sarawak: coalition composed of Sarawak Alliance and Sarawak United Peoples
Party (SUPP), Ong Kee Hui; Opposition Sarawak National Party, Stephen
Ningkan
Voting strength:
West Malaysia: (1969 election) Alliance Party controls 9 of 11 state
legislatures, won estimated 49% of total vote; Pan-Malaysian Islamic
Party polled 24%; Democratic Action Party polled 12%; Gerakan 7%
Sabah: (April 1967 Assembly elections) USNO and SCA polled 50% of votes;
United Pasok-Momogun Kadazan Organization (UPKO) (now dissolved) 41%;
remainder cast for independent candidates
Sarawak: (1970 elections) Alliance 24 seats, SNAP 12 seats, SUPP 11 seats;
SUPP has joined the Alliance to form a coalition state government
Member of: ADB, ASEAN, ASPAC, Commonwealth, FAQ, GATT, IAEA, IBRD, ICAO, IFC,
ILO, IMF, ITU, U.N., UNESCO, UPU, WHO, WMO
Population: 112,000, average annual growth rate 1.9% (FY69 )
Ethnic divisions: presumed Aryan stock with Arab admixtures
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs almost all the male
population
Population: 5,144,000, average annual growth rate 2.4%
(FY69-70); males 15-49, 1,217,000; 680,000 fit for
military service; no conscription
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African languages,
of which Mande group most widespread
Literacy: under 5%
Labor force: approximately 60,000 salaried, 40,000 of whom are civil servants;
most of population engaged in agriculture and animal husbandry
Organized labor: UNTM, which claimed all eligible employees, dissolved and
activity tightly controlled
Pa Population: 328,000, average annual growth rate 0.9% (FY70);
a males 15-49, 71,000; 54,000 fit for military service
Ethnic divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
; Language: English and Maltese
ae Literacy: about 70%; compulsory education introduced in 1946
Labor force: 98,700; 58% industry, 6% agriculture, 10% military base support,
19% government, 2% other; 5% unemployed (est.)
Organized labor: approximately 33% of labor force
Population: 1,199,000, average annual growth rate 2.3%
(FY67-68); males 15-49, 284,000; 150,000 fit for
military service; conscription law not imp] emented
Ethnic divisions: 80% Moor, 20% Negro
Religion: nearly 100% Muslim
Language: French and Arabic official
Literacy: under 5%
Labor force: about 18,000 wage earners (1964); remainder of population in
farming and herding .
Organized labor: 18,000 union members claimed by single union, Mauritanian
Workers! Union
Population: 849,000, average annual growth rate 1.5%
(FY69); males 15-49, 198,','87663bbe3bd08699f1b18d67bf0287133674320f6c276f06c1824ac26bfee2cb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e07fcc53513c3409ef82e15168c1c2772a534b10693849eb09da7880046dc75d',1971,'DZ','Algeria','people-and-society',27,'000; 95,000 fit for military
service
Ethnic divisions: Hindus 51%, Muslims 16%, Creoles 29%,
Chinese 3.5%, English and French 0.5%
Religion: 51% Hindu, 33% Christian (mostly Catholic with a few Anglican
Protestants), 16% Muslim
Language: English official language; Hindi, Chinese, French Creole
Literacy: not known, but very high (90% of school age children in school )
Labor force: 120,000; 65% agriculture, 5% industry; 30% are unemployed, under-
employed, or self-employed
Organized labor: about 10% of labor force
Population: 24,000 (official estimate for 1 January 1970)
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
Literacy: almost complete
Labor force: not available
Organized labor: not available
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 40 . MONGOLIA
LAND:
604,100 sq. mi.; almost 90% of land area is pasture or
desert wasteland, varying in usefulness, Tess than
1% arable, 10% forested (1970)
Population: 1,324,000, average annual growth rate 3.0%
(current); males 15-49, 276,000; 185,000 fit for
military service; average number reaching military
age (18) annually, about 13,000
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese, 2% Wenneenss
Russian, 2% other
Religion: predominantly Tibetan Buddhists; about 4%
Muslims; limited religious activity because of Communist regime
Languages: Khalkha Mongol used by over 90% of population; minor languages
include Turkic, Russian, and Chinese
Literacy: about 80%
Labor force: no reliable information available, but primarily agricultural; over
half the population is in the labor force, including a large percentage of
Mongolian women; acute shortage of both skilled and unskilled labor
GOVERN
Population: 9,750,000, average annual growth rate 0.9%
(FY61-69); males 15-49, 2,468,000; 1,905,000 fit for military service;
average number reaching military age (20) annually, about 81,000
Ethnic divisions: homogeneous Mediterranean stock in mainland, Azores, Madeira
Islands; no racial or linguistic groups of importance
Religion: 97% Roman Catholic, 1% Protestant sects, 2% other
Language: Portuguese
Literacy: 65%
Labor force: 3.1 million (1968); 37% agriculture, 33% industry, 30% services;
unemployed 60,000 (1967 est.)
Organized labor: 33.3% of labor force in government-controlled syndicates
Population: 532,000, average annual growth rate 0.2%
(FY69); males 15-49, 127,000; 71,000 fit for
military service
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes);
less than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese official, numerous African languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in subsistence agriculture
Population: 63,000 (official est. 1 July 1969); males
15-49, 15,000; 7,000-8,000 fit for military service
Ethnic divisions: 51.2% Arab, Berber, and Negro nomads;
48.8% Spanish
Religion: 51% Muslim, 49% Catholic
Language: Spanish (official), local Arabic or Hassania
Literacy: among Spanish, probably nearly 100%; among nomads,
perhaps 5%
Labor force: 12,000; 50% agriculture, 50% other
Organized labor: none
Population: 15,676,000, average annual growth rate 2.4%
(FY67-70); males 15-49, 3,573,000; 2,125,000 fit for
military service; average number reaching military
age (18) annually, 180,000
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23% pagan, 4% Christian
ios tiy in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects of Nilotic, Nilo-Hamitic,
and Sudanic languages, English; program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15% industry, commerce, services,
etc.; labor shortages exist for almost all categories of employment
Population: 417,000, average annual growth rate 3.5% (FY68-69); |
males 15-49, 99,000; 55,000 fit for military service
Ethnic divisions: 35.5% Creole (Negro and mixed), 34.7%
Hindustani (East Indian), 14.9% Javanese, 8.5% Bush
Negro, 2.2% Amerindian, 1.6% Chinese, 1.3% Europeans,
1.3% other and unknown
Religion: Muslim, Hindu, Moravian, Roman Catholic, other -- in order of size
(% figures unknown)
Language: Dutch official; English widely spoken; Taki-Taki (Surinam Creole)
is native language of Creoles and lingua franca; Hindi; Javanese
Literacy: 70% to 75%
Labor force: 80,190 (1964); 24.9% agriculture, 6.9% mining, 10% industry, 2.8%
building trades, 13.5% trade and transport, 6.7% services, 22.2% government
employees, 3.1% unclassified, 9.9% unemployed and seeking work
Organized labor: approx. 10% of labor force
Population: 435,000, average annual growth rate 3.0%
(FY65-69); males 15-49, 99,000; 50,000 fit for
military service
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence agriculture; 55-60,000
wage earners, many only intermittently, with 31% agriculture, 11% government,
11% manufacturing, 12% mining and forestry, 35% other (1968 est.); 7,900
employed in South African mines (1969)
Organized labor: about 15% of wage earners are unionized
Population: 8,132,000, average annual growth rate 1.1%
(FY70); males 15-49, 1,909,000; 1,635,000 fit for
military service; 53,000 reach military age (19)
annually
Ethnic divisions: homogeneous white population; smal]
Lappish minority
Religion: 92% Evangelical Lutheran, 7% other Protestant,
Roman Catholic, Eastern Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking minorities
Literacy: 99%
Labor force: 3.5 million; 11.8% agriculture, forestry, Fishing; 33.5% mining
and manufacturing; 9.6% construction; 15.5% commerce; 7.2% transportation
and communications; 20.9% services; 1.5% unemployed
Organized labor: 70% of labor force
Population: 6,381,000, average annual growth rate 1.3%
(FY69); males 15-49, 1,532,000; 1,325,000 fit for
military service; 45,000 reach military age (20)
annually
Ethnic divisions: total population -- 69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals -- 74% German, 20% French, 4% Italian,
1% Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals -- 74% German, 20% French, 4% Italian, 1% Romansch,
1% other; total population -- 69% German, 19% French, 10% Italian, 1%
Romansch, 1% other
Literacy: 98%
Labor force: 2.5 million; 16% agriculture and forestry, 47% industry and crafts,
20% trade and transportation, 5% professions, 2% in public service, 10%
domestic and other; no significant unemployment shortage of both skilled and
unskilled labor -- 4,400 unfilled vacancies in January 1971
Organized labor: 20% of labor force
362,800 sq. mi. (including islands of Zanzibar and Pemba,
1,020 sq. mi.); 6% inland water, 8% cultivated, 9%
used for grazing, 76% forest, woodland, or grassland
on mainland; 50% arable, of which 40% cultivated
on islands of Zanzibar and Pemba (1965)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Population: 13,629,000, average annual growth rate 2.7%
(FY70); males 15-49, 3,244,000; 1,790,000 fit for
military service
Ethnic divisions: 99% native Africans consisting of well
over 100 tribes; 1% Asian, European, and Arab
Religion: Tanganyika -- 45% animist, 29% Christian, 25% Muslim; Zanzibar --
almost all Muslim
Language: Swahili official; English often used as administrative language;
primary language of about 89% of the population is one of the many Bantu,
Nilotic, Nilo-Hamitic, and Hamitic languages; 10% Swahili; 1% English
Literacy: 5% to 10%
Labor force: under 400,000 in paid employment, 90% in agriculture
Organized labor: 15% of labor force
Population: 36,923,000, average annual growth rate 3.1%
(FY70); males 15-49, 9,326,000; 5,690,000, fit for
military service; about 400,000 reach military age
(18) annually
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
* Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70% :
Labor force: 88% agriculture, 9% commerce, 3% industry
Population: 2,068,000, average annual growth rate 2.5%
(FY67-70); males 15-49, 410,000; 200,000 fit for
military service; no conscription
Ethnic divisions: some 40 tribes; largest and most
important are Ewe in south and Cabrais in north;
under 1% European and Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of commerce; major African languages
are Ewe and Mina in south and Dagoma, Tim, and Cabrais in north
Literacy: 5% to 10%
Labor force: bulk of population engaged in subsistence agriculture; about
30,000 wage earners, evenly divided between public and private sectors
Population: 87,000, average annual growth rate 2.5% (FY69)
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children
between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized
Population: 961,000, average annual growth rate 1.3%
(FY61-70); males 15-49, 212,000; 150,000 fit for
military service
Ethnic divisions: 43% Negro, 36% East Indian, 16% mixed,
2% white, 3% other
Religion: 35% Protestant, 29% Roman Catholic, 23% Hindu, 6% Muslim, 7% unknown
Language: English
Literacy: 80%
Labor force: about 363,700 (of which, at least 15% unemployed); about 20.4%
agriculture; 18.3% mining, quarrying, and manufacturing; 15.8% commerce;
14.6% construction and utilities; 6.9% transportation and communications;
20.8% services (1965); shortage of technical and managerial personnel
Organized labor: 24% of labor force
Population: 179,000 (census of 15 March - 16 April 1968);
males 15-49, about 43,000; about 22,000 fit for
military service
Religion: Muslim (96%)
Language: Arabic
Literacy: 20% est.
Labor force: population engaged in herding and fishing; growing number of
skilled laborers, many Indian, Pakistani, and Iranians
Population: 5,249,000, average annual growth rate 2.9%
(current); males 15-49, 1,256,000; 720,000 fit for
military service; about 45,000 reach military age
(20) annually
Ethnic divisions: 98% Arab, 1% European, less than 1%
Jewish
Religion: 98% Muslim, 1% Christian, less than 1% Hebrew
Language: Arabic (official), Arabic and French (commerce)
Literacy: about 30%
Labor force: 1.5 million; 70% agriculture, 10% manufacturing and construction,
20% other; 25% underemployed; shortage of skilled labor
Organized labor: 10% of labor force; General Union of Tunisian Workers (UGTT),
subordinate to Destourian Socialist Party
Population: 36,296,000, average annual “growth rate 2.6%
(October 65-October 70); males 15-49, 9,141,000;
5,395,000 fit for military service; about 358,000
reach military age (20) annually.
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.7 million; 72% agriculture, 28% industry, commerce, service,
etc.; substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force
Population: 10,045,000, average annual growth rate 2.9%
(August 69-July 70); males 15-49, about 2,343 ,000;
about 1,300,000 fit for military service
Ethnic divisions: 98.7% African, 1.3% European, Asian,
Arab
Religion: about 60% nominally Christian, rest Muslim
or pagan
Language: English official; Luganda and Swahili widely used; other Bantu and
Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which 256,799 in paid labor, remaining
in subsistence activities
Organized labor: 123,284 union members
Population: 245,051,000, average annual growth rate 0.9%
(current)
Ethnic divisions: 77% Slavic, 23% among some 170 ethnic groups
Religion: 70% atheist, 18% Russian Orthodox, 9% Muslim, 3% other
Language: more than 200 languages and dialects (at least 18 with more than 1
million speakers); 76% Slavic group, 8% other Indo-European, 11% Altaic,
3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: 125.8 million (1970), 32% agriculture, 68% industry and other non-
agricultural fields, unemployed not reported, shortage of skilled labor
not reported, no shortage of unskilled labor
Population: 34,178,000, average annual growth rate 2.5%
(FY70); males 15-49, 7,852,000; 4,955,000 fit for
military service; about 370,000 reach military age
(20) annually
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek,
Italian, Syro-Lebanese
Religion: 94% Muslim, 6% Copt and other
Language: Arabic official, English and French widely understood by educated
classes
Literacy: around 40%
Labor force: 12.3 million; 60% agriculture, 10% industry, 10% trade, 20%
services and other; serious shortage of skilled labor
Organized labor: 8% of labor force
Population: 5,492,000, average annual growth rate 2.0%
(FY70); males 15-49, 1,301,000; 630,000 fit for
military service; no conscription
Ethnic divisions: more than 50 tribes; principal tribe
is Mossi (about 2.5 million); other important groups
are Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to Sudanic family, spoken
by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active population engaged in animal
husbandry, subsistence farming, and related agricultural pursuits; 1.5%
are wage and salary earners; about 20% of male labor force migrates
annually to neighboring countries for seasonal employment
Organized labor: less than 30,000 wage earners
Population: 2,920,000, average annual growth rate 1.2%
(FY70); males 15-49, 706,000; 555,000 fit for
military service; no conscription
Ethnic divisions: 85%-90% white, 5% Negro, 5%-10% mestizo
Religion: 66% Roman Catholic (less than half adult
population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed in important sectors --
25% government; 53% trade and service; 28% manufacturing and construction;
19% agriculture, forestry, fishing and mining; no shortage of skilled labor
Organized labor: about 25% of labor force (largely Communist influenced)
Population: 1,000 (official estimate for 1 July 1964)
Ethnic divisions: primarily Italians but also many
other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees divided
into 3 categories -- executives, officeworkers,
and salaried employees
Organized labor: none
Population: 10,776,000 (excluding Indian jungle population
estimated at 32,000 in 1961), average annual growth
rate 3.6% (FY70); males 15-49, 2,472,000; 1,700,000
fit for military service; 119,000 reach military age
(18) annually
Ethnic divisions: 65% mestizo, 10%-18% white or
predominantly white, 10%-20% Negro, 3%-7% Indian
Religion: 96% Roman Catholic, 1% Protestant, 1% Jewish, 2% other or none
Language: Spanish
Literacy: 72% (claimed)
Labor force: 3 million (1969), 24% agriculture, 23% industry, 2% mining and
petroleum, 17% commerce, 35% services and other, an estimated 7% considered
unemployed
Organized labor: 50% of labor force
Population: 20,538,000, average annual growth rate 2.0%
(current)
Ethnic divisions: 85%-90% predominantly Vietnamese; ethnic
minorities include Muong, Thai, Meo, and Man
Religion: Confucianism, Buddhism, Taoism, Catholicism
Language: closely corresponds to the breakdown of ethnic groups
Literacy: claimed to be 95% (1964)
Labor force: (1 January 1970) 9.6 million, not including military; about 70%
agriculture and 10% industry
Population: 18,809,000, average annual growth rate 2.6%
(FY69); males 15-49, 4,497,000; 2,590,000 fit for
military service; 116,000 reach military age (18)
annual ly
Ethnic divisions: 85% Vietnamese, 6% Chinese, 5% mountain
tribesmen, 3% Cambodian, 1% other
Religion: 50%-60% nominal Buddhist (10% Hoa Hao), 10%-20% active Buddhist, 5%
Cao Dai, 8%-12% Catholic, 15%-30% no affiliation or animist; most Buddhists
are of Mahayana school or practice combination of Buddhism, Taoism, and
Confucianism
Language: Vietnamese, French, Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian), Cham (Malayo-Polynesian dialect)
Labor force: employed work force 6.5 million (not including armed forces);
80.2% agriculture, 3.2% transport and communications, 2.4% fishing, 2.4%
construction, 2.3% commerce and finance, 2.1% domestic and personal services,
4.3% government, 2.4% manufacturing, 0.7% plantation and public utilities
Organized labor: 6% of labor force','15f979374dca142c1c565e9c11848ede67b90b174f0141301951232131d6bc46','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d51c4be168530cb89b6e7466cb1cce29af8e7c32299fc41cf2a861f338a634e',1971,'BR','Brazil','people-and-society',31,'we Population: 296,000, average annual growth rate 1.8% (FY69)
males 15-49, 73,000; 35,000 fit for military service
Ethnic divisions: indigenous population of Fernando Po
primarily Bubi, some Fernandinos; of Rio Muni
primarily Fang; some 30,000 Nigerians, mostly on
‘ Fernando Po; less than 1,000 Europeans, primarily
Spanish and French
Religion: natives all nominally Christian and predominantly Roman Catholic; some
pagan practices retained
Language: Spanish official language of government and business; also pidgin
Spanish, Fang
Literacy: approximately 90% among younger generation
Labor force: most Equatorial Guineans involved in subsistence agriculture;
small wage labor force dominated by nonindigenous, including some 20,000
Nigerian contract laborers
455,000 sq. mi.; 9.5% cropland and orchards, 54.6% meadows vasigsau 9
and natural pastures, 6.5% forests and woodlands,
29.4% wasteland, built-on areas, and other
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Population: 25,922,000, average annual growth rate 2.3%
(FY69); males 15-49, 6,640,000; 3,425,000 fit for
military service
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%,
Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%, Gurage
2%, other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Muslims, 15%-20% animist, 5% other
Language: Amharic official; many local languages and dialects; English major
foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10% government, military,
and quasi-government
Organized labor: 35,000 registered labor union members
Population: 40,000, average annual growth rate 1.4% (FY65-
68); males 15-49 included with Denmark
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faeroese (derived from Old Norse), Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufacturing, transportation,
and commerce
Population: 2,000 (official est. for 31 December 1968)
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); over 95% (est.) in agriculture, mostly sheepherding
Population: 547,000, average annual growth rate 2.7%
(FY70); males 15-49, 141,000; 75,000 fit for military
service; 6,000 reach military age (18) annually
‘ Ethnic divisions: 42% Fijian, 50% Indian, 8% European,
Chinese and others
Religion: Fijians mainly Christian, Indians are Hindu with
a Muslim minority
Language: English and Fijian (official), Hindustani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no breakdown on remainder
Organized labor: about 50% of labor force organized into 22 unions; unions
organized along lines of work, breakdown by ethnic origin causes further
fragmentation
Population: 4,687,000, average annual growth rate -0.2%
(FY70); males 15-49, 1,199,000; 900,000 fit for military
service; 41,000 reach military age (17) annually :
Ethnic divisions: homogeneous white population, small “y
Lappish minority .
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox,
1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and Russian-speaking minorities
Literacy: 99%
Labor force: 2.3 million;. 28.1% agriculture, forestry, and fishing; 24.2% mining
and manufacturing; 9.0% construction; 13.7% commerce; 6.6% transportation and
communications; 16.5% services; 1.9% unemployed
Organized labor: 60% of labor force
LIBYA [U,A.R
Population: 51,208,000, average annual growth rate 0.8%
(FY66-70); males 15-49, 12,386,000; fit for military
service 9,975,000; 432,000 reach military age (18)
annually
Ethnic divisions: 45% Celtic; remainder Latin, Germanic,
Siav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1%
Muslim (North African workers), 13% unaffiliated
Language: French (100% of population); rapidly declining regional patois --
Provencal, Breton, Germanic, Corsican, Catalan, Basque, Flemish
Literacy: 97%
Labor force: 20,002,200; 15% agriculture, 38% industry, 45% services;
2% unemployed
Organized labor: 15%-20% of labor force, 20%-25% of salaried labor force','fd16718a8982fa6255f73760be53118cc75e06a8272cab8e85bff32e7b3afc6d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2d10f0b406a023147b164030b444583ebdf07bbf1a7e291a29989a4e8935f34',1971,'LY','Libya','people-and-society',35,'Population: 52,000, average annual growth rate 4.3%
(FY69); males 15-49, 12,000; 8,000
fit for military service
Ethnic divisions: 95% Negro or mulatto, 5% white or Indian
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: approximately 13,600; breakdown not available
Organized labor: 7% of labor force','5597a062fb39586136c39e235c34122765999d95129f93cad6fad06d76f5ac2c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ef4edaf93da562cac05a0e53aecf4086ef23568c9dbb8f28ddb47f7c93830d2',1971,'GP','Guadeloupe','people-and-society',37,'Population: 125,000 (official estimate for 1 July 1967);
males 15-49, about 30,000; about 15,000 fit for
military service
Ethnic divisions: 59,350 Somalis (large number of the
Somalis are temporary immigrants from Somalia -- not
citizens of territory), 53,650 Afars, 6,000 Arabs,
7,000 French (inclusive of French military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at port
Organized labor: some 3,000 railway workers organized','8972b6278014c0c0b4a854ccc2c4837a28f49e7a3058588172e06d8d24ef55cc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c03625f4003c199987be3dca3cad89158572a1c730103cadc792702cee73774',1971,'CO','Colombia','people-and-society',40,'Population: 678,000, average annual growth rate 1.7% (FY69); » BRAZIL
about evenly divided between Martinique and Guadeloupe;
males 15-49, included with France
Ethnic divisions: 90% African and African-Caucasian-Indian
mixture, 5% East Indian, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 220,000; 41% agriculture, approximately 50% food processing
industries, 9% unspecified
Organized labor: 11% of labor force
Population: 496,000, average annual growth rate 1.1%
(FY65-68); males 15-49, 121,000; 58,000 fit for
military service; 5,000 reach military age (18)
annually
Ethnic divisions: about 40 Bantu tribes, including 8 major
tribal groupings (Omiene, Fang, Eshira, Bakota, Mbede,
Seke, Okande, Bakele); about 3,000 Pygmies; 10,000 to
12,000 non-Africans
Religion: 55% to 75% Christian, less than 1% Muslim, remainder animist
Language: French official language and medium of instruction in schools; Fang
is a major vernacular language
Literacy: about 12%
Labor force: about 280,000 of whom 56,000 in modern sector
Organized labor: less than 30% of wage labor force
Population: 371,000, average annual growth rate 2.0% (FY69);
males 15-49, 88,000; 42,000 fit for military service
Ethnic divisions: over 99% Africans (Malinke 41%, Fulani
14%, Wolof 12%, remainder made up of several smaller
tribal groups), fewer than 1% Europeans and Lebanese
Religion: 85% Muslim, 15% animist and Christiar:
Language: English official; Malinke most widely used vernacular
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in subsistence farming; about
25,000 are wage earners (government, trade, services)
Organized labor: 25% to 30% of wage labor force at most
Population: 17,040,000 (including East Berlin), average
annual growth rate -0.01% (current); males 15-49,
3,768,000; 3,055,000 fit for military service; about
134,000 reach military age (18) annually
Ethnic divisions: 99.7% German, .3% Slavic
Religion: 59.3% Protestant, 8.1% Roman Catholic, 32.6%
unaffiliated or other; less than 5% of Protestants and
about 25% of Roman Catholics actively participate
Language: German
Literacy: over 90%
Labor force: 8.5 million; 16% agriculture, 39% industry, 45% other nonagricul tural','aeb98dc4e4054ce312f91a424d7b7523bfcb81003005dc259168931009b0e05f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1203a55b1b812f0deaa2923c67315b2e5cf3b78d16c97829c1c71f4ff67bb1cc',1971,'MA','Morocco','people-and-society',44,'158,000 sq. mi.; 19% farmland and orchard, 19% pasture,
ees and esparto, 42% desert, waste, or urban
1965
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Population: 16,071,000, average annual growth rate 3.2%
(FY69); males 15-49, 3,828,000; 2,610,000 fit for
military service; about 184,000 reach military age (18)
annually; limited conscription
Ethnic divisions: 97.5% Arab-Berber, .8% Hebrew, 1.7%
non-Moroccan
Religion: 97.5% Muslim, 1.7% Christian, .8% Jewish
Language: Arabic (official); several Berber dialects; French is Tanguage of much
business, government, diplomacy, and education
Literacy: 10% to 15%
Labor force: 4.4 million; 70% agriculture, 15% industry, 15% other (military,
police, civil service, transportation, mines, teachers, merchants,
construction workers )
Organized labor: 10% to 15% of labor force
MENT:
Legal name: Kingdom of Morocco
Type: constitutional monarchy (constitution adopted 1970)
Capital: Rabat
Political subdivisions: 19 provinces and 2 prefectures
Legal system: based on Islamic law and French and Spanish civil law system;
judicial review of legislative acts in Constitutional Chamber of Supreme
Court; modern legal education at branches of Mohamed V University in Rabat
and Casablanca and Karouine University in Fes; has not accepted compulsory
ICJ jurisdiction
Branches: constitution provides for Prime Minister and ministers named by and
responsible to King; King has paramount executive powers; unicameral
legislature; judiciary independent of other branches
Government leaders: King Hassan II; Prime Minister Ahmed Laraki
Suffrage: universal over age 20
Elections: 150 members of parliament indirectly elected on 21 August 1970 and
remaining 90 directly elected on 28 August 1970
Political parties and leaders: Istiqlal Party, Allal el-Fassi; Popular Movement
(MP), Mahjoubi Aherdan; Constitutional and Democratic Popular Movement
(MPCD), Dr. Abdelkrim Khatib; National Union of Popular Forces (UNFP),
collegial leadership of Abderrahim Bouabid, Abdallah Ibrahim, and Mahjoub
Ben Seddik; Democratic Socialist Party (PSD), Ahmed Reda Guedira; Party for
Liberation and Socialism (PLS), established in June 1968 and banned September
1969, is front for Moroccan Communist Party (MCP), which was proscribed in
1959, Ali Yata; Istiqlal and the UNFP formed a National Front in July 1970
to oppose the new constitution and to boycott the parliamentary elections
Voting strength: (1970 election) not yet available; new parliament is composed
of 158 Independents, 60 Popular Movement, 9 Istiqlal, 2 UNFP, 11 other
Communists: 400 est. .
Member of: Arab League, EEC (until 1974), FAO, IAEA, IBRD, ICAO, IDA, ILO, IMC,
IMCO, IMF, ITU, OAU, U.N., UNESCO, UPU, WHO, WMO
217
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Population: 7,743,000, average annual growth rate 2.1%
(FY68); males 15-49, 1,805,000; 905,000 fit for
military service
Ethnic divisions: 97.5% native Africans, 2.5% Europeans
and Asians
Religion: primarily animist, 1,100,000 Muslims, 860,000 Christians
Language: Portuguese (official); many tribal dialects
Literacy: 7%
Labor force: (1963 est.) 610,000; 50,000 non-African wage earners, 560,000
African wage earners in Mozambique; 290,000 additional African wage earners
temporarily working in Rhodesia and South Africa; unemployment serious
problem; most native Africans provide unskilled labor or remain in
subsistence agricultural sector
Organized labor: approx. 44,000 (end of 1970); 75% are white
Population: 11,242,000, average annual growth rate 1.8%
(FY69); males 15-49, 2,472,000; 1,415,000 fit for
military service; 115,000 reach military age (17)
annually
Ethnic divisions: two main categories -- Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%) --
representing considerable intermixture of Indo-Aryan and
Mongolian racial strains; country divided among many quasi-tribal communities
Religion: only official Hindu Kingdom in world, although no sharp distinction
between many Hindu and Buddhist groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided into numerous dialects;
Nepali official language and lingua franca for much of the country; same
script as Hindi
Literacy: about 8%
Labor force: 4.1 million; 95% agriculture, 5% industry; great lack of skilled
labor
Population: 13,173,000, average annual growth rate 1.1%
(current); males 15-49, 3,299,000; 2,960,000 fit for
military service; average number reaching military age
(20) annually 119,000 ArGeRiA
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 41% Protestant, 40% Roman Catholic, 19% unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24% services, 16% commerce, 10%
agriculture, 9% construction, 7% transportation and communications, 4%
other; 1.05% registered unemployed; no shortage of skilled labor but shortage
of semi-skilled labor; 129,000 unfilled vacancies reported by employers in
January, 1971
Organized labor: 33% of labor force
Population: 224,000, average annual growth rate 1.4%
(FY69); males 15-49, 57,000; 30,000 fit for military
service; about 2,000 reach military age (20) annually
Ethnic divisions: 85% largely mixed Negro stock except on
Aruba where 12% Negro and approx. 55% mixed Carib
Indian and European; rest European with some Chinese,
especially on Aruba
Religion: predominantly Roman Catholic; sizable Protestant, smaller Jewish
minorities
Language: officially Dutch; predominantly English; colloquial "papiamento," a
Spanish-Portuguese-Dutch-English mixture
Literacy: 75%-80%
Labor force: 66,000; 1% agriculture, 21% industry, 21% unemployed, 8%
construction, 41% government and services, 8% other
Organized labor: approx. 15% of labor force
Population: 2,035,000, average annual growth rate 3.5%
(current); males 15-49, 494,000; 295,000
fit for military service; 23,000 reach military age if
(18) annually BRAZIL
Ethnic divisions: 75% mestizo, 15% white, 10% Negro, Indian ;
or mulatto
Religion: 96% Roman Catholic
Language: Spanish (official); small English-speaking minority on Atlantic coast
Literacy: 50% of population 10 years of age and over
Labor force: 561,000 (est. January 1967); 59% agriculture, 12% manufacturing, 14%
services, 15% other; shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: less than 4% of labor force
7 Population: 4,126,000, average annual growth rate 2.7%
we (FY70); males 15-49, 916,000; 515,000 fit for military
service; about 33,000 reach military age (18) annually
Ethnic divisions: main Negroid groups 75% lof which, Hausa
50%, Djerma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
Pal includes Fulani
cai Religion: 80% Muslim, remainder largely animists and a very
few Christians
Language: French official, many African languages; Hausa used for trade
Literacy: about 5%
Labor force: 26,000 wage earners; bulk of population engaged in subsistence
agriculture and animal husbandry
Organized labor: negligible
a Population: 565,000 (official est. 1 July 1966); males
“ 15-49, 137,000; 71,000 fit for military service
Ethnic divisions: almost entirely Arab with small groups
of Iranians, Baluchis, and Indians
Religion: Muslim
* Language: Arabic
Literacy: very low
Population: 116,597 ,000* (excluding Junagardh, Manavador,
Gilgit, Baltistan, and the disputed area of Jammu-
Kashmir), average annual growth rate 2.1% (FY69); males
15-49, 27,918,000; 14,980,000 fit for military service;
1,455,000 reach military age (17) annually
Ethnic divisions: 54% Bengalis, 30% Punjabi, 5% Pushtuns, 2% Sindhis, 2% Baluchis,
7% other
Religion: 88% Muslim, 10% Hindu, 2% other
Language: official languages -- Urdu (spoken in West Pakistan) and Bengali
(spoken in East Pakistan); total spoken languages -- 4% Urdu, 55% Bengali,
25% Punjabi, 6% Pushtu; 10% minor languages (Sindhi, Baluchi, Brahui);
English is lingua franca
Literacy: about 16%
Labor force: 30 million (est. 1961); 73% agriculture, 10% industry, 5% commerce,
10% service, 2% unemployed; substantial shortage of skilled labor; seasonal
shortages of unskilled labor in some areas; severe underemployment
Organized labor: 5% of labor force
Population: 1,475,000, average annual growth rate 3.0%
(December 60 - May 70); males 15-49, 358,000; 245 ,000
fit for military service; no conscription
ri Ethnic divisions: 70% mestizo, 14% Negro, 9% white,
7% Indian and other
Religion: over 90% Roman Catholic, remainder mainly Protestant
Language: Spanish; about 14% speak English as native tongue; many Panamanians
bilingual
Literacy: 80% of population 10 years of age and over
Labor force: 390,000 (1967 est.); 49.1% agriculture, 19.9% services, 9.8%
commerce, 8.4% manufacturing, 3.6% construction, 2.6% transportation and
communications, 1% other (1964 est.); 5.6% Canal Zone; national average of
5% or less unemployed; 25% to 30% of unemployed in Panama City and Colon;
shortage of skilled labor but an oversupply of unskilled labor
Organized labor: 5% of labor force
Population: 2,463,000 (Papua 659,000 excluding territory
transferred to New Guinea, average annual growth rate
2.5% (FY64-69); New Guinea 1,804,000 including terri-
tory previously a part of Papua, average annual growth
rate 2.2% (FY64-69); males 15-49, 624,000 (Papua
166,000, New Guinea 465,000); about 325,000 fit for
military service (Papua 85,000, New Guinea 245,000)
Ethnic divisions: predominantly Melanesian and Papuan, some Negrito, Micronesian,
and Polynesian types
Religion: over one-half of population nominally Christian (490,000 Catholic,
320,000 Lutheran, other Protestant sects); remainder animist
Language: 700 indigenous languages; pidgin English and 2 or 3 native languages
are linguae francae for over one-half of population; English spoken by
1% to 2% of population
Literacy: 1%; in English, 0.1%
Labor force: no available figures; mostly subsistence farmers
Population: 2,460,000, average annual growth rate 3.1%
(FY69); males 15-49, 592,000; 395,000
fit for military service; average number currently
reaching military age (17) annually, 27,000
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 715,000 (1968 est.); 55% agriculture, forestry, fishing;
8% transport and other services; 19% manufacturing and construction;
13% commerce and professions; 5% miscellaneous (est. 1962)
Organized labor: about 6% of labor force
Population: 14,013,000 (excluding Indian jungle population
which was estimated at 101,000 in 1961), average annual
growth rate 3.1% (FY70); males 15-49, 3,230,000;
2,190,000 fit for military service; average number
currently reaching military age (20) annually, 121,000
Ethnic divisions: 46% Indian; 38% mestizo (white-Indian);
15% white; 1% Negro, Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 3.5 million (1967); 46% agriculture, 17% services, 14% manufacturing,
9% trade, 4% construction, 4% transportation, 2% mining, 4% other
Organized labor: 25% of labor force
Population: 39,876,000, average annual growth rate 3.6%
(FY70); males 15-49, 9,112,000; 5,965,000 fit for
military service; about 390,000 reach military
age (20) annually
Ethnic divisions: 91.5% Filipino (Malay), 4% Moros (Malay),
1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4% Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national language of the Philippine
Republic; English is the language of school instruction and government
business
Literacy: about 75%
Labor force: 11 million; 60% agriculture, forestry, fishing; 12% manufacturing;
10.5% commerce; 10.5% government and services (business, recreation, domestic,
personal); 3.5% transport, storage, communication; 3% construction; 0.5% other
Population: 32,746,000, average annual growth rate 0.9%
(current); males 15-49, 8,546,000; 6,750,000 fit for
military service; 349,000 reach military age (19)
annually
Ethnic divisions: 98.7% Polish, .6% Ukrainians, .5% LIBYA [UAsRiy BAUOT A
* Belorussians, less than .05% Jews, .2% other
Religion: 95% Roman Catholic (about 75% practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26% industry, 46% other nonagricultural*','13d5414f74f9db3d14641ed53bbffa9165071d096923bd567f2ec8fe36d3a137','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0ed59f3da85c8df82a9279ff48528acda5808cbea792f245d5dcad217b19d45',1971,'AU','Australia','people-and-society',50,'Population: 622,000, average annual growth rate 2.1% (FY69)
Ethnic divisions: 95% indigenous Timorese belonging to
the Malay racial group; 9 ethnic divisions, each
speaking a distinct dialect of Malay structure;
approx. 4,600 Chinese and 10,000 halfcastes
Religion: 17% Christian (almost equally divided between Catholic and
Protestant); remainder practice animism
Language: an estimated 9-15 dialects, of Malay origin but mutually unintelligible;
75% of the population speaks the Tetum dialect
Literacy: rate of literacy is unknown, but is very low; educational system being
expanded under first Five Year Development Plan; by 1967 total school
enrollment was 25,000 out of total school-age population of 80,000; 5% of
natives can speak Portuguese
Labor force: 90% engaged in primitive village subsistence economy; 10% engaged
as town laborers and domestics
Population: 2,751,000, average annual growth rate 1.1%
(FY69)
Ethnic divisions: 80% white, 20% mixed (with Indian and
Negro elements ) Pet
Religion: predominantly Roman Catholic
Language: Spanish, English
Literacy: 88%
Labor force: 706,000; 19% agriculture, 14% manufacturing, 7% construction, 39%
government services and trade, 8% other, 13% unemployed
Organized labor: 45% of labor force
Population: 123,000, average annual growth rate 10.8%
(FY65-69); males 15-49, about 29,000; about 17,000
fit for military service
Religion: Muslim
Language: Arabic
Literacy: very low
Labor force: small skilled labor force employed by oi]
companies, many are Indians
Population: 457,000, average annual growth rate 2.3% (FY69)
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy,
Chinese, and Indian origin
Religion: predominantly Roman Catholic
Language: French official language; Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers ; high seasonal unemployment
Population: 5,446,000, average annual growth rate 3.3%
(FY67-70); males 15-49, 1,268,000; 770,000 fit for
military service; average number reaching military
age (18) annually, 60,000
Ethnic divisions: 96% African, 3% European, less than
1% Coloreds and Asians
Religion: 51% syncretic (part Christian, part animist); 24% Christian;
24% animist; a few Muslim
Language: English official; Chishona and Sindebele also widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: 48,000 wage earners (1968); 663,000 Africans (including many
migrants from Zambia and Malawi), 85,000 Europeans; 35% agriculture,
25% mining, manufacturing, construction, 40% transport and services
Organized labor: most European wage earners are unionized, but only a small
minority of Africans
Population: 20,481,000, average annual growth rate 1.1%
(current); males 15-49, 5,300,000; 4,468,000 fit for
military service; 182,000 reach military age (20)
annual ly
- Ethnic divisions: 87% Romanian, 8% Hungarian, 2% German,
3% other
Religion: 14,000,000 Romanian Orthodox, 1,000,000 Roman
Catholic, 1,000,000 Protestants, 100,000 Jews, 30,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population |
Labor force: 10.4 million (est. 1 July 1966); 57% agriculture, 19% industry,
24% other nonagricultural
Population: 3,733,000 (African population only), average
annual growth rate 3.1% (FY65-67); males 15-49,
870,000; 420,000 fit for military service; no
conscription; 39,000 reach military age (18} annually
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa (Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French official; Kiswahili language of African commerce;
Kinyarwanda language of interior and used in National Assembly
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy
Population: about 994,000, average annual growth rate
1.1% (FY65-69); males 15-49, 235,000; 178,000 fit for
military service
Ethnic divisions: homogeneous; no significant minorities
Religion: basically animist; no significant minorities
Language: Japanese (strong local dialect)
Literacy: 95%
Labor force: 423,000; about 33.6% agriculture, forestry, fishing; 28.4% trade
and services; 16.9% industry; 11.6% government and utilities; 9% employed
by U.S. forces; .5% unemployed (19705
Organized labor: 8% of labor force
Population: 56,000 (official estimate for 31 December 1967)
Ethnic divisions: mainly of African Negro descent
Religion: Church of England, other Protestant sects, Roman
Catholic BRAZIL
Language: English
Literacy: about 80%
Labor force: not available
Organized labor: 6,700
Population: 116,000, average annual growth rate 2.4%
(FY67-69)
Ethnic divisions: mainly of African Negro descent BRAZIL
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 27,000 (1960); 50% agriculture
Organized labor: 20% of labor force
Population: 99,000, average annual growth rate 2.2% (FY69)
Ethnic divisions: mainly of African Negro descent; remainder
mixed with some white and East Indian and Carib Indian SRRSIL
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 24,000 (1960); about 40% in agriculture
Organized labor: 10% of labor force
Population: 19,000, average annual growth rate 1.9%
(FY65-70)
Ethnic divisions: composite of Mediterranean, Alpine,
Adriatic, and Nordic racial types
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of Sanmarinese Workers (affiliated
with ICFTU) has about 1,800 members; Communist-dominated Camera del Lavoro,
about 1,000 members
Population: about 5.5 million, average annual growth rate
2.8% (current); males 15-49, 1,332,000; 715,000 fit
for military service; about 65,000 reach military age
(18) annually
Ethnic divisions: 90% Arab, 10% Afro-Asian (est.)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 25% of population; 40% agriculture and herding, 12%
construction, 12% service, 12% government, 11% commerce
Population: 3,977,000, average annual growth rate 2.6%
(FY69); males 15-49, 914,000; 440,000 fit for military
service; 40,000 reach military age (18) annually
Ethnic divisions: 36% Wolof, 18% Fulani, 17% Serer, 9%
Tukulor, 9% Dyola, 7% Malinke, 2.5% other African,
1.5% Europeans and Lebanese
Religion: 80% Muslim, 10% animist, 10% Christian
Language: French official, but regular use limited to literate minority; most
Senegalese speak own tribal language; use of Wolof vernacular spreading
as lingua franca among non-Wolof tribesmen
Literacy: 5% (est.)
Labor force: 1.7 million, about 80% subsistence agricultural workers
Organized labor: majority of wage-labor force represented by unions; however,
dues-paying membership very limited
Population: 53,000, average annual growth rate 2.0% (FY69);
males 15-49, 12,000; 6,000 fit for military service
Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans )
Religion: 90% Roman Catholic
Language: English official; Creole most widely spoken
Literacy: limited
Labor force: 22,000 agriculture
Organized labor: 3 major trade unions
Population: 2,988,000, average annual growth rate 1.5%
(FY69); males 15-49, 609,000; 614,000 fit for military
service; no conscription
Ethnic divisions: over 99% native African, rest European
and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to literate minority;
principal vernaculars are Mende in south and Temne in north; "Creole," a
form of pidgin English, is also widely spoken
Literacy: about 10%
Labor force: about 1.5 million; most of population engages in subsistence
agriculture; only small minority, some 100,000, earn wages
Organized labor: 35% of wage earners (35,000)
Population: 2,084,000, average annual growth rate 1.6%
(FY70); males 15-49, 482,000; 330,000 fit for military
service
Ethnic divisions: 78% Chinese, 12% Malay, 7% Indians and
Pakistani, 3% other
Religion: majority of Chinese are Buddhists or atheists;
Malays nearly all Muslim; minorities include Christians,
Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay, Tamil, and English are
official languages
Literacy: 88% (1967)
Labor force: 577,000; 3% agriculture and fishing; 24% manufacturing and
construction; 67% trade, transportation, communications, and other services;
6% other
Organized labor: 26% of labor force
Population: 2,854,000, average annual growth rate 2.2%
(FY69); males 15-49, 692,000; 365,000 fit for military
service; no conscription
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000
Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (but no written form); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled laborers; 70% pastoral
nomads, 30% agriculturists, government employees, traders, fishermen,
handicraftsmen, other
Organized labor: all labor organizations are banned under the military government
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
472,000 sq. mi. (1970) (includes enclave of Walvis Bay,
434 sq. mi.); 12% cultivable, 2% forested, 86% desert,
waste, or urban
Limits of territorial waters: 6 n. mi. (fishing, 12 n. mi.)
Population: 21,861,000, average annual growth rate 2.4%
(FY69); males 15-49, 5,015,000; 3,035,000 fit for
military service; obligation for service in Citizen
Force begins at 18; volunteers for service in permanent
force must be 17
Ethnic divisions: 19% European, 68.5% Bantu, 9.5%
Coloured, 3% Asian
Religion: primarily Christian except Asian and Bantu; 60% of Bantu are animists
Language: Afrikaans and English official, Bantu have many vernacular Janguages
Literacy: almost all white population literate; government estimates 35% of
Bantu literate
Labor force: 8.7 million (total of economically active, 1960); 53% agriculture,
8% manufacturing, 7% mining, 5% commerce, 27% miscellaneous services
Organized labor: about 5% of total labor force is unionized (mostly white
workers); nonwhites have no bargaining power
Population: 636,000, average annual growth rate 1.7% (FY69);
males 15-49, about 150,000; about 75,000 fit for
military service
Ethnic divisions: 14% white, 81% Africans, 5% Coloured
(mulattoes); almost half the Africans belong to Ovambo
tribe; Herero, Okavango, Nama, and Damara tribes have
about 30,000 members each
Religion: whites predominantly Christian, nonwhites either animist or Christian
Language: Afrikaans principal language of about 70% of white population, German
of 22%, and English of 8%; several African languages
Literacy: high for white population; low for nonwhite
Labor force: 75,000 African wage earners (1964 est.); 68% agriculture, 15%
railroads, 13% mining, 4% fishing
Organized labor: no trade unions, although some white wage earners belong to
South African unions
Population: 33,635,000, average annual growth rate 1.0%
(FY70); males 15-49, 8,195,000; 6,290,000 fit for
military service; 260,000 reach military age (20)
annual ly
Ethnic divisions: homogeneous composite of Mediterranean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great majority; but 17% speak Catalan,
7% Galician, and 2% Basque
Literacy: about 90%
Labor force (1969): 12.6 million; 30.2% agriculture, 36.9% industry, 32.9%
services; registered unemployment is 1% of labor force
Organized labor: 90% of labor force in compulsory government-controlled
syndicates
Population: 146,000, average annual growth rate 2.4%
(FY67-70)
Ethnic divisions: Polynesians, about 12,000 Euronesians
(persons of European and Polynesian blood), 700
Europeans
Religion: 99.7% Christian (about half of population
associated with the London Missionary Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all children from 7-15 years)
Labor force: agriculture 19,148; mining and manufacturing 1,716 (1961)
Organized labor: unorganized
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
112,000 sq. mi.; border with Saudi Arabia undefined; only
about 1% arable (of which less than 25% cultivated)
Limits of territorial waters: 12 n. mi. (fishing 12 n. mi.)
Population: 1,272,000**, average annual growth rate 2.1%
(FY69); males 15-49, 308,000; 160,000 fit for military
service
Ethnic divisions: almost all Arabs; a few Indians,
Somalis, and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 5,893,000, average annual growth rate 2.8%
(FY66-70); males 15-49, 1,427,000; 765,000 fit for
military service; about 50,000 reach military age (18)
annually; universal military conscription law (10
January 1963) makes military service obligatory for
all Yemeni males 18-30 ;
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and herding','f97c5e7961981fad2dce21f4e0590aabbb6ea023e78b73fdbfe5fd4d61a80bc0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9be8d8fabc6c32cf33a09e1dd40f0359d16e36ed8f7aca7f87ea59f43d12855',1971,'JP','Japan','people-and-society',57,'Population: 20,784,000, average annual growth rate 1.1%
(current); males 15-49, 5,471,000; 4,450,000 fit for
military service; 200,000 reach military age (19)
annual ly
Ethnic divisions: 41% Serb, 22% Croat, 9% Slovene,
8% Macedonian, 3% Montenegrin, 5% Albanian, 3% Hungarian,
9% other
Religion: 41% Serbian Orthodox, 32% Roman Catholic, 12% Muslim, 3% other, 12%
none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Albanian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 9.0 million (1967); 49.6% agriculture, 16% mining and manufacturing,
34.4% other nonagricultural activities; reported unemployment averaged 8%
of registered labor force (social sector) in 1967
Population: 4,242,000, average annual growth rate 2.4%
(May 63-August 69); males 15-49, 988,000; 485,000
fit for military service
Ethnic divisions: 98.7% African, 1.1% European, .2% other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
Literacy: 28%
Labor force: 372,000 wage earners; 345,000 Africans, 27,000 non-Africans ;
15% mining, 9% agriculture, 9% domestic service, 19%
construction, 9% commerce, 10% manufacturing, 23% government and miscellaneous
services, 6% transport
Organized labor: 100,000 wage earners, primarily in industrial sector, are
unionized (early 1968)','9ea6874e2b2f3cad4bc1c8d7c2033b684ecae9a3ef95385e20398fbd11871df2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b028d64434640e36cd899eb3f2f757d88a9c3afe5c49c2d7ff0f0a5ba9482bd',1971,'US','United States','people-and-society',60,'Population: 207,071,000, average annual growth rate 1.1% (current)
Ethnic divisions: population basically of West European extraction, modified
by subsequent waves of immigration
Religion: total membership in religious bodies, 119,333,000; Protestant
78,952,000, Roman Catholic 30,699,000, Jewish 3,868,000, other religions
1,545,000 (1969)
Language: English, predominantly
Literacy: almost complete
Labor force: about 82 million
Organized labor: 28.8% of total','515d5fecb5b275cc6d4cf3b095116de8c49b6a90719cb1cb8998151fc137bb2d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d68d40ceba1c37311656871e3c0eb58c8fcd9d85c38902be42282b19d465d30a',1971,'','','people-and-society',5,'Population: 2,212,000, average annual growth rate 2.7%
(current); males 15-49, 525,000; 432,000 fit for mili-
tary service; 24,000 reach military age (19) annually
Ethnic divisions: 96% Albanian, remaining 4% are Greeks, Vlachs, Gypsies, and
Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10% Roman Catholic (observances
prohibited; Albania claims to be the world''s first atheist state)
Language: Albanian Greek
Literacy: about 70%; no reliable current statistics available, but probably
greatly improved
Labor force: 911,000 (1967); 60.5% agriculture, 17.9% industry, 21.6% other
nonagricul tural
Population: 14,422,000, average annual growth rate 3.1%
(FY69); males 15-49, 3,453,000; 1,980,000 fit for
military service; average number reaching military age
(19) annually 135,000
Ethnic divisions: 99% Arab-Berbers, less than 1% Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 2.8 million; 47% agriculture, 8% industry, 24% other (military,
police, civil service, transportation workers, teachers, merchants,
construction workers); 40% of urban Tabor unemployed
Organized labor: 17% of labor force claimed; General Union of Algerian
Workers (UGTA) is the only labor organization and is subordinate to the
National Liberation Front
Population: 73,000, average annual growth rate 2.6% } BRAZIL
(April 60-70) Ren
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other Protestant sects and some
Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000
Population: 23,823,000, average annual growth rate 1.6%
(September 60-70); males 15-49, 6,124,000; 4,535,000
fit for military service; average number reaching military age (20) annually
about 215,000
Ethnic divisions: approximately 85% white, 15% mestizo, Indian, or other
nonwhite groups ;
Religion: 90% nominally Roman Catholic (less than 20% practicing Roman Catholics),
2% Protestant, 2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 9.5 million; 19% agriculture, 25% manufacturing, 11% commerce,
35% other, 4%-5% unemployed
Organized labor: 25% of labor force (est.)
Population: 7,453,000, average annual growth rate 0.2%
(March 70-71); males 15-49, 1,670,000; 1,345,000 fit for
military service; average number reaching military age
(19) annually about 51,000
Ethnic divisions: 98.1% German, .7% Croatian, .3% Slovene,
.9% other =
Religion: 85% Roman Catholic, 7% Protestant, 8% none or other
Language: German
Literacy: 98%
Labor force: 3,248,000 (of which 828,200 are self-employed); 18% agriculture
and forestry, 49% industry and crafts, 18% trade and communications, 7%
professions, 6% public service, 2% other; 2.4% registered unemployed; an
estimated 200,000 Austrians are employed in other European countries;
foreign labor about 75,000 (1970)
Organized labor: about 2/3 of wage and salary workers (1971)
Population: 179,000, average annual growth rate 3.4%
(November 63-April 70) BRAZIL
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: mainly Church of England; some Protestant,
Greek Orthodox, and Roman Catholic
Language: English
Labor force: 60,000 (1963)
Population: 223,000, average annual growth rate 3.1%
(FY67-68); males 15-49, 59,000; fit for military
service 32,000
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani, and Indian, 3% other
Religion: Muslim
Language: Arabic
Literacy: about 30% (1965)
Labor force: 53,274 (1965)','1fc7069e5775296bdaf2abfaa1d762f0360361748ba51890d8ff65541dece5f5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a59d580be60763cc7b8d64097564464c4c177657be8ea829cfd2806e79f6260c',1971,'BR','Brazil','people-and-society',6,'Population: 4,832,000, average annual growth rate 2.5%
(current); males 15-49 1,131,000; 715,000 fit for ARCENTINE
military service; average number reaching military age
(19) annually about 54 ,000
Ethnic divisions: 50%-75% Indian, 20%-35% Mes tizo,
5%-15% white
Religion: predominantly Roman Catholic
Language: Spanish and Indian (Aymara and Quechua)
Literacy: 35%-40%
Labor force: 1.9 million (1967); 69.1% agriculture, 3.3% mining, 9.6% services
and utilities, 8% manufacturing, 10% other
Organized labor: 40%-50% of labor force
Population: 553,000, average annual growth rate 2.3%
(October 60-April 70)
Ethnic divisions: approximately 63% African, 37% white
Religion: 47.5% Church of England, 10.2% Catholic, 38.2% other Protestant, 4.2%
other
Language: English
Literacy: virtually 100%
Labor force: 19,498 employed (1960)
Population: 750,000 (official est. for 1 July 1968); males
15-49, 195,000; 100,000 fit for military service;
about 8,000 reach military age (18) annually
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese,
15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25% Buddhist-influenced
Hinduism
Language: Bhotias speak various Tibetan dialects, most widely spoken dialect is
Druk-ke, the official language; Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry; massive lack of skilled
labor
D:
220,000 sq. mi.; about 6% arable, less than 1% under
cultivation, mostly desert (1970)
Land boundaries: 2,345 mi.
Population: 678,000, average annual growth rate 3.0% (FY69)
98.9% Bantu; males 15-49, 162,000; 82,000 fit for
military service; 8,000 reach military age (18) annuall
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% European
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: less than 25% in English; about 33% in Tswana;
less than 1% secondary school graduates
Labor force: most are engaged in sheep raising and subsistence agriculture
(statistics unavailable); about 25,000 in internal cash economy, another
40,000 spend at least 6 to 9 months per year as wage earners in South
Africa (1964)
Organized labor: negligible
Population: 96,818,000, average annual growth rate 2.9%
(September 60-70); males 15-49, 22,031,000; 14,375,000
fit for military service; 1,130 reach military age (18) annually
Ethnic divisions: 61.8% white, 26.6% brown, 11% Negro, 0.6% yellow (Brazilian
census color classifications, 1950)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: about 61% over age 14
Labor force: 33 million in 1970 (est.); 41% agriculture, 12%
manufacturing industries, 33% commerce and services
Organized labor: about 50% of labor force; only about 1.5 million pay dues
Population: 127,000, average annual growth rate 3.6%
(FY69); males 15-49, 32,000; 17,000 fit for military
service; about 1,000 reach military age (18) annually
Ethnic divisions: 52% Malays, 28% Chinese, 15% indigenous tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8% Christian; 32% other (Buddhist
and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture, 32.8% industry, manufacturing, and
construction, 33.8% trade, transport, services, 2.9% other
Organized labor: 8.4% of labor force
Population: 8,601,000, average annual growth rate 0.8%
(current); males 15-49, 2,263,000; 1,885,000 fit for
military service; about 68,000 reach military age (19) annually
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6% Gypsies, 2.5% Macedonians ,
0.3% Armenians, 0.2% Russians, 0.6% other
Religion: regime promotes atheism; religious background of population is 85%
Bulgarian Orthodox, 13% Muslim, 0.8% Jewish, 0.7% Roman Catholic, 0.5%
Protestant, Gregorian-Armenian and other
Language: Bulgarian; secondary languages closely correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 4.4 million (July 1970); 38% agriculture, 33% industry, 29% other
Population: 28,517,000, average annual growth rate 2.2%
(FY69); males 15-49, 6,834,000; 2,965,000 fit for
military service; about 275,000 males and 266,000 females reach military age
(18) annually; both are liable for military service
Ethnic divisions: 72% Burman, 7% Karen, 6%°Shan, 2% Kachin, 2% Chin, 2% Chinese,
3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their own languages
Literacy: 60% (official claim)
Labor force: 10 million; 67% agriculture, 13% industry, 20% services, commerce,
and transportation
Organized labor: no figure available; old labor organizations have been
disbanded, and government is forming one central labor organization
11,000 sq. mi.; about 37% arable (about 66% cultivated),
23% pasture, 10% scrub and forest, 30% other
Land boundary: 605 mi.
Population: 3,654,000, average annual growth rate 2.0%
(FY69); males 15-49, 850,000; 410,000 fit for military
service; 42,000 reach military age (16) annually
Ethnic divisions: Africans -- 86% Hutu (Bantu), 13% Tutsi
(Hamitic), 1% Twa (Pigmy); non-Africans include (late
1968) 3,000 Europeans, 1,000 Asians
Religion: over 60% Christian (50% Catholic, 10% Protestant);
rest mostly animist plus small number of Muslims
Language: Kirundi and French official
Literacy: about 55% in Kirundi, 10% in Swahili, or 6% in French
Labor force: 1,865,471 (1970 est.)
Organized labor: sole group is the Union of Burundi Workers (UTB), membership
about 30,000, affiliated with government party
Population: 7,075,000 average annual growth rate 2.2%
(FY69); males 15-49, 1,589,000; 885,000 fit for
military service; 83,000 reach military age (18)
annually
Ethnic divisions: 89% Khmer (Cambodian), 3% Vietnamese, 5% Chinese, 3% other
minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian
Literacy: 55% (est.)
Labor force: 2.56 million; 80.9% agriculture, 5.5% sales, 4.7% manufacturing,
transport, communications, 3.9% professional, administrative, clerical,
3.5% defense; 1.5% unemployed
Organized labor: .5% of labor force
Population: 5,989,000, average annual growth rate 1.7%
(FY70); males 15-49, 1,352,000; 705,000 fit for
military service; average number reaching military
age (18) annually about 61,000
Ethnic divisions: about 200 tribes of widely differing background; 31% Cameroon
Highlanders, 19% Equatorial Bantu, 8% North West Bantu, 10% Fulani, 7%
Eastern Nigritic, 11% Kirdi, 13% other African, less than 1% non-African
Religion: about one-half animist, one-third Christian; rest Muslim
Language: English and French official, 24 major African language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence agriculture; 200,000 wage
earners (maximum) including 22,000 government employees, 63,000 paid
agricultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force
Population: 1,596,000, average annual growth rate 2.0%
(FY69); males 15-49, 415,000; 200,000 fit for
military service
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and linguistic
characteristics; Banda (32%) and Baya-Mandjia (29%) are —— =
largest single groups; 6,500 Europeans, of whom 6,000 are French and majority
of the rest Portuguese -
Religion: 40% Protestant, 28% Catholic, 27% animist, 5% Muslim; animistic
beliefs and practices strongly influence the Christian majority
Language: French official; Sangho, the lingua franca and unofficial national
language
Literacy: estimated at 5%-10%
Labor force: about half the population economically active, 80% of whom are in
agriculture; between 50,000 and 85,000 salaried workers (1966)
Organized labor: 1% of labor force
Population: 12,814,000, average annual growth rate 2.3%
(July 63-September 71); males 15-49, 3,086,000;
2,315,000 fit for military service; 143,000 reach
military age (18) annually
7 Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor, 2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6% Muslim, 1% other
Language: Sinhala official, spoken by about 70% of population; Tamil spoken by
about 22%; English commonly used in government and spoken by about 10%
of the population
Literacy: 82% (1970 est.)
Labor force: 4 million; at least 14% unemployed or underemployed; employed
persons -- 53.4% agriculture, 14.8% mining and manufacturing, 12.4% trade
and transport, 19.4% services and other
Organized labor: 43% of labor force, over 50% of which employed on tea, rubber,
and coconut estates
Population: 3,842,000, average annual growth rate 2.4%
(current); males 15-49, 933,000; 485,000 fit for military
service; average number reaching military age (20)
annually about 35,000
Ethnic divisions: over 240 tribes representing 12 ethnic
groups -- white Muslims (Arabs, Toubou, and Fulani )
and black Muslims (Kotoko, Hausa, Kanembou, Baguirmi,
Boulala, and Wadai) in the north and center and non-Muslims (Sara, Mayo-Kebbi,
and Chari) in the south; some 150,000 nonindigenous , 5,000 of them French
Religion: about half Muslim, 5% Christian, remainder animist
Language: French official; Chadian Arabic is lingua franca in north, Sara and
Sangho in south
Literacy: about 7%
Labor force: only 55% of population in economically active group, of which 90%
are engaged in unpaid subsistence farming, herding, and fishing; 60,000
wage earners in industry and civil service
Organized labor: about 20% of wage labor force
286,000 sq. mi; 2% cultivated, 7% other arable, 15%
permanent pasture, grazing, 29% forest, 47% barren
mountains, deserts, and cities (1965)
Land boundaries: 3,930 mi.
Limits of territorial waters: claim 3 n. mi.
(fishing, 200 n. mi.)
Coastline: 4,000 mi.
Population: 9,124,000, average annual growth rate 1.9%
(November 60-Aprit 70); males 15-49, 2,177,000; 1,620,000 fit for military
service; average number reaching military age (19) annually about 90,000
Ethnic divisions: 85%-90% mestizo, 3% Indian, 7% European, Asiatic, and other
Religion: 90% Roman Catholic, 5% (est.) Evangelical, 5% other
Language: Spanish :
Literacy: 84% .
Labor force: 3.1 million (1969); 28% agricultural, 24% industry and construction,
24% services, 10% commerce, 4% mining, 10% other (1962)
Organized labor: 20% of labor force
Population: 864,530,000, average annual growth rate 2.3% (current)
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur, Hui, Yi, Tibetan, Miao,
Manchu, Mongol, Pu-I, Korean, and numerous lesser nationalities
Religion: most people, even before 1949, have been pragmatic and eclectic,
not seriously religious; most important elements of religion are Confucian-
ism, Taoism, Buddhism, ancestor worship; about 22-3% Muslim, 1% Christian
Language: Chinese (Mandarin mainly; also Cantonese, Wu, Fukienese, Amoy, Hsiang,
Kan, Hakka dialects), and minority languages (see ethnic divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85% agriculture, 15% other; shortage of
skilled labor (managerial, technical, mechanics, etc.); surplus of unskilled
labor
Population: 15,003,000 (excluding the population of
Quemoy and Matsu Islands and foreigners), average
annual growth rate 2.3% (January 70-71); males 15-49,
3,595,000; 2,720,000 fit for military service; average
number currently reaching military age (19) annually
180,000
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese, 2% aborigines
Religion: 93% mixture of Buddhism, Confucianism, and Taoism; 4.5% Christian;
2.5% other
Language: Mandarin, Taiwanese, Japanese, English
Literacy: about 90%
Labor force: 4.5 million; 41% agriculture, forestry, fishing, 18% manufacturing,
15% services, 15% commerce, 5% transportation and communications,
4% construction, 2% mining (1968)
Organized labor: about 10% of 1968 labor force (government controlled)
Population: 22,913,000, average annual growth rate 3.2%
(current); males 15-49, 5,380,000; 3,255,000 fit for
military service; average number reaching military
age (18) annually about 244,000
Ethnic divisions: 70% mestizo, 20% white, 5% Negro, 5% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 42% agriculture, 15% manufacturing, 20% services,
23% other (1962)
Organized labor: 13% of labor force
Population: 962,000, average annual growth rate 2.0%
(current); males 15-49, 236,000; 113,000 fit for
military service; about 10,000 reach military age (20) annually
Ethnic divisions: about 15 ethnic groups divided into some 75 tribes, almost all
Bantu; most important ethnic groups are Kongo (48%) in south, Teke (17%) in
center, M''Bochi (12%) and Sangha (20%) in north;- about 8,500 Europeans,
mostly French
Religion: about half animist, half nominally Christian, less than 1% Muslim
Language: French official, many African languages with Lingala and Kikongo
most widely used
Literacy: about 20%
Labor force: about 40% of population economically active, most engaged in
subsistence agriculture; 79,100 wage earners; 40,000-60,000 unemployed
Organized labor: 16% of total labor force (1965 est.)
Population: 1,820,000, average annual growth rate 3.1%
(FY69); males 15-49, 392,000; 265,000 fit for military
service; average number reaching military age (18)
annually about 22,000
Ethnic divisions: 98% white (including mestizo), 2% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: approximately 80%
Labor force: 457,000 (1968); 46.3% agriculture; 13.2% manufacturing; 11% commerce;
8% construction, transportation, and communications ; 21.5% other; shortage
of skilled labor
Organized labor: about 10% of labor force
Population: 8,702,000, average annual growth rate 1.3%
(current); males 15-49, 2,076,000; 1,155,000 fit for
military service; about 77,000 males and 74,000
females reach military age (17) annually
Ethnic divisions: 51% mulatto, 37% white, 11% Negro, 1% Chinese
Religion: at least 85% nominally Roman Catholic before Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.6 million; 34% agriculture, 17% industry, 6% construction, 6%
transportation, 29% services, 8% unemployed and underemployed
Organized labor: 70% of total force
Population: 14,426,000, average annual growth rate 0.4%
(current); males 15-49, 3,668,000; 2,822,000 fit for
military service; about 128,000 reach military age
(18) annually
Ethnic divisions: 64.5% Czechs, 29.6% Slovaks, 3.9% Magyars, Leva leo yeR Ayan tae
1% Germans, 1% Ukrainians, Jews, Poles ~ Fie
Religion: 77% Roman Catholic, 20% Protestant, 2% Orthodox,
1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.1 million; 18% agriculture, 37% industry, 11% services, 34%
construction, communications and others
Population: 2,834,000, average annual growth rate 2.8%
(FY65-68); males 15-49, 662,000; 320,000 fit for mili-
tary service; about 29,000 males and 27,000 females reach military age (18)
annually; both sexes liable for military service
Ethnic divisions: 99% Africans (42 ethnic groups, most important being Fon, Adja,
Yoruba, Bariba), 5,500 Europeans
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba-most common vernaculars in south,
at least 6 major tribal languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture; 15% civil service,
artisans, and industry
Organized labor: approximately 75% of wage earners, divided among two major
and several minor unions
Population: 4,259,000, average annual growth rate 3.0%
(August 60-January 70); males 15-49, 981,000; 620,000
fit for military service; 48,000 reach military age (18) annually
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 35% to 40% of adult population
Labor force: 1.3 million; 73% agriculture, 8% industry, 19% services and other
Organized labor: 12% of labor force
Population: 6,412,000 (excluding nomadic Indian tribes),
average annual rate of growth 3.4% (FY69); males 15-49
1,494,000; 955,000 fit for military service; average
number reaching military age (20) annually 63,000
Ethnic divisions: 41% mestizo, 39% Indian, 10% white, 5% Negro, 5% Oriental and
other
Religion: 95% Roman Catholic (majority nonpracticing), trace of Evangelical
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 55% agriculture, 16% manufacturing, 4%
construction, 7% trade, 9% services, 9% other; shortage of skilled labor
Organized labor: 12% of labor force
Population: 34,614,000, average annual growth rate 2.5% (FY70); males 15-49,
7,913,000; 4,995,000 fit for military service; about 352,000 reach military
age (20) annually
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek, Italian, Syro-Lebanese
Religion: 94% Muslim, 6% Copt and other
Language: Arabic official, English and French widely understood by educated
classes
Literacy: around 40%
Labor force: 12.3 million; 60% agriculture, 10% industry, 10% trade, 20%
services and other; serious shortage of skilled labor
Organized labor: 8% of labor force
Population: 3,741,000, average annual growth rate 3.4%
(FY67-70); males 15-49, 863,000; 530,000 fit for mili-
tary service; 36,000 reach military age (18) annually
Ethnic divisions: 84%-88% mestizo; Indian and white minorities, 6%-8% each
Religion: predominantly Roman Catholic, probably 97%-98%
Language: Spanish
Literacy: 50% of population 10 years of age and over (1966 est.)
Labor force: 1,048,000 (est. January 1970); 57% agriculture, 14% services,
14% manufacturing, 6% commerce, 9% other; shortage of skiiled labor, but
manpower training programs improving large pool of unskilled labor
Organized labor: 4.5% of total labor force; 8% of nonagricultural labor force
Population: 296,000, average annual growth rate 1.8% (FY69) 3}
Rio Muni, 214 ;000, average annual growth rate 1.5%
(FY69); Fernando Po, 85,000, average annual growth rate
2.6% (FY69); males 15-49, 73,000; 35,000 fit for military service
Ethnic divisions: indigenous population of Fernando Po primarily Bubi, some
Fernandinos; of Rio Muni primarily Fang; some 10,000-20,000 Nigerians, mostly
on Fernando Po; Jess than 1,000 Europeans, primarily Spanish
Religion: natives all nominally Christian and predominantly Roman Catholic; some
pagan practices retained
Language: Spanish official language of government and business; also pidgin
English, Fang
Literacy: approximately 90% among younger generation
Labor force: most Equatorial Guineans involved in subsistence nes
small wage labor force dominated by Nigerian contract laborers
Population: 26,220,000, average annual growth rate 2.3%
(FY69); males 15-49, 6,640,000; 3,425,000 fit for
military service
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%, Sidamo 9%, Shankella 6%,
Somali 6%, Afar 4%, Gurage 2%, other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Muslims, 15%-20% animist, 5% other
Language: Amharic official; many local languages and dialects; English major
foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10% government, military,
and quasi-government
Organized labor: 60,000 registered labor union members
FAEROE ISLANDS
540 sq. mi.; less than 5% arable, of which only a fraction
cultivated; archipelago consisting of 18 inhabited
islands and a few uninhabited islets (1966)
Limits of territorial waters: 3 n. mi.; fishing, 12 n. mi.
(from extended base lines)
Coastline: 475 mi.
Population: 38,000, average annual growth rate 0.7% (FY67-
70); males 15-49 included with Denmark
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faeroese (derived from Old Norse), Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufacturing, transportation,
and commerce
Population: 2,000 (official est. for 1 July 1970)
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); over 95% (est.) in agriculture, mostly sheepherding
Population: 539,000, average annual growth rate 2.8%
(FY69); males 15-49, 139,000; 75,000 fit for military
service; 6,000 reach military age (18) annually
Ethnic divisions: 42% Fijian, 50% Indian, 8% European,
Chinese and others
Religion: Fijians mainly Christian, Indians are Hindu with a Muslim minority
Language: English and Fijian (official), Hindustani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no breakdown on remainder
Organized labor: about 50% of labor force organized into 22 unions; unions
organized along lines of work, breakdown by ethnic origin causes further
fragmentation
Population: 4,683,000, average annual growth rate 0.1%
(FY69-70); males 15-49, 1,203,000; 900,000 fit for
military service; 40,000 reach military age (17)
annually
Ethnic divisions: homogeneous white population, small Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox, 1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and Russian-speaking minorities
Literacy: 99%
Labor force: 2.3 million; 28.1% agriculture, forestry, and fishing, 24.2% mining
and manufacturing, 9.0% construction, 13.7% commerce, 6.6% transportation and
communications, 16.5% services; 1.9% unemployed
Organized labor: 60% of labor force
ALG
SAUDI
rN
LIBYA TEGYPE, ARABIA
BA
Population: 51,443,000, average annual growth rate 0.8% scgehin
(FY66-70); males 15-49, 12,454,000; fit for military
service 10,035,000; 422,000 reach military age (18)
annually
Ethnic divisions: 45% Celtic; remainder Latin, Germanic, Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1% Muslim (North African
workers), 11% unaffiliated
Language: French (100% of population); rapidly declining regional patois --
Provencal, Breton, Germanic, Corsican, Catalan, Basque, Flemish
Literacy: 97%
Labor force: 20,002,240; 15.4% agriculture, 39.5% industry, 44.9% services,
2% unemployed
Organized labor: 17% of labor force, 23.4% of salaried labor force
Population: 55,000, average annual growth rate 5.0%
(FY67-70); males 15-49, 13,000; 9,000
fit for military service
Ethnic divisions: 95% Negro or mulatto, 5% caucasian or East Indian
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%, construction 21%, agricul ture
18%, industry 8%, transportation 4%; information on unemployment unavailable
Organized labor: 7% of labor force
Population: 125,000 (official estimate for 1 July 1967):
males 15-49, about 30,000; about 15,000 fit for
military service
Ethnic divisions: 59,350 Somalis (large number of the Somalis are temporary
immigrants from Somalia -- not citizens of territory), 53,650 Afars, 6,000
Arabs, 7,000 French (inclusive of French military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at port
Organized labor: some 3,000 railway workers organized
Population: 513,000, average annual growth rate 1.7%
(FY66-70); males 15-49, 126,000; 63,000 fit for
military service; 5,000 reach military age (18)
annually
Ethnic divisions: about 40 Bantu tribes, including 8 major tribal groupings
(Omiene, Fang, Eshira, Bakota, Mbede, Seke, Okande, Bakele); about 3,000
Pygmies; 10,000 to 12,000 non-Africans
Religion: 55% to 75% Christian, less than 1% Muslim, remainder animist
Language: French official language and medium of instruction in schools; Fang
is a major vernacular language
Literacy: about 12%
Labor force: about 280,000 of whom 56,000 in modern sector
Organized labor: less than 30% of wage labor force
Population: 375,000, average annual growth rate 2.0% (FY69) LL
males 15-49, 89,000; 43,000 fit for military service
Ethnic divisions: over 99% Africans (Malinke 41%, Fulani 14%, Wolof 12%, remainder
made up of several smaller groups), fewer than 1% Europeans and Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Malinke most widely used vernacular
Literacy: about 1','a1cfc076c05f753e62b93529a0efa91586c5f77fcac2371b6739b940787d8a91','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('895c80aa7d0af9f4f4141c40d3b91715d5a12fc2019f5ba008dc1e7287730f8c',1971,'BR','Brazil','people-and-society',7,'0%
Labor force: approx. 165,000, mostly engaged in subsistence farming; about
25,000 are wage earners (government, trade, services)
Organized labor: 25% to 30% of wage labor force at most
Population: 17,039,000 (including East Berlin), average Fiat ate
annual growth rate -0% (current); males 15-49,
3,791,000; 3,076,000 fit for military service; about
133,000 reach military age (18) annually
Ethnic divisions: 99.7% German, .3% Slavic and other
Religion: 80% Protestant, 9% Roman Catholic, 11% unaffiliated or other; less than
5% of Protestants and about 25% of Roman Catholics actively participate
Language: German, small Sorbin (West Slavic) minority
Literacy: 99%
Labor force: 8.2 million; 36.5% industry; 5.2% handicrafts; 7.4% construction;
12.8% agriculture; 7.3% transport and communications; 11.0% commerce; 17.5%
services; 2.3% other
Organized labor: 86% of total labor force
Population: 8,932,000, average annual growth rate 2.4%
(March 60-70); males 15-49, 2,035,000; 1,090,000 fit
for military service; 105,000 reach military age (18)
annual ly
Ethnic divisions: 99.8% Negroid African (major tribes
Fanti, Ashanti, Ewe), 0.2% European and other
Religion: 45% animists, 42.8% Christian, 12% Muslim
Language: English official; African languages include Akan 44%, Mole-Dagbani 16%,
Ewe 13%, and Ga-Adangbe 8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing, 16.8% industry, 15.2%
sales and clerical, 4.1% services, transportation, and communications ,
2.9% professional; 400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor force
Approved For Release 2004/08/34 « GA-RDP79-01051A000400010002-1
Population: 4,026,000, average annual growth rate 2.3%
(March 61-71); males 15-49, 1,021,000; 790,000 fit for
military service; about 45,000 reach military age
(18) annually
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local religions
Language: Chinese, English
Literacy: 75%
Labor force (1969 est.): 1.52 million; 40% manufacturing, 28% services, 11%
construction, mining, quarrying and utilities, 11% commerce, 5% agriculture,
forestry, fisheries, and hunting, 6% communications, 2% other; under-
employment is a serious problem
Organized labor: 12% of 1969 labor force
Population: 10,358,000, average annual growth rate 0.3%
(current); males 15-49, 2,651,000; 2,134,000 fit for
military service; about 94,000 reach military age
(18) annually
Ethnic divisions: 96.3% Magyar, 2.5% German, 1.2% other
Religion: 67.5% Roman Catholic, 20% Calvinist, 5%
Lutheran, 7.5% atheist and other
Language: 96.2% Magyar, 2.5% German, 1.3% other
Literacy: 97%
Labor force: 5.0 million; 26% agriculture, 44% industry and building, 30%
other nonagricul tural
IBYA SAuDI ¥
u jeover sae Nadi,
: :
Population: 123,979,000 (including West Irian),
average annual growth rate 2.5% (FY68); males 15-49,
28 596,000; 16,300,000 fit for military service; about
1,486,000 reach military age (18) annually
Ethnic divisions: 45% Javanese, 14% Sundanese, 7.5% Madurese, 7.5% Coastal Malays,
26% other
Religion: 90% Muslim, 4% Christian, 2% Buddhist, 2% Hindu, 2% other
Language: Indonesian (modified form of Malay) official; English, and Dutch
leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 41 million; 70% agriculture, 15% industry, 15% miscellaneous and
unemployed
Organized labor: 10% of labor force
Population: 9,814,000, average annual growth rate 3.2%
(October 65-70); males 15-49, 2,219 ,000; 1,200 ,000 Fit
” for military service; about 119,000 reach military age (18) annual ly
Ethnic divisions: 70.9% Arabs» 18.3% Kurds, 0.7% Assyrians » 9.4% Turkomans » 7.7%
other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry» 6.7% government,
16.8% others rural underemployment high, but not serious because low
subsistence levels make it easy to care for unemployed; severe shortage
of technically trained personnel
Organized Jabor: 11% of labor force
Population: 2,967,000, average annual growth rate 0.5%
(FY67-70); males 15-49, 674,000; 530,000 fit for military
service; about 28,000 reach military age (17) annually
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Eptscopalian, 2% other
Language: English and Gaelic official; English is generally spoken
Literacy: 98%-99%
Labor force: about 1,130,000; 28% agriculture, forestry, fishing; 19% manufac-
turing; 15% commerce; 6% construction; 5% transportation; 4% government;
18% other
Organized labor: 36% of labor force
Population: 4,471,000, average annual growth rate 2.5%
(current); males 15-49, 1,521,000; 455,000 fit for
military service
Ethnic divisions: 7 major indigenous ethnic groups; no single tribe more than
15% of population; most important are Agni, Baoule, Krou, Senoufou, Mandingo;
approx. 1 million foreign Africans, mostly Voltaics; about 33,000 non-Africans
(25,000 French)
Religion: 67% animist, 22% Muslim, 11% Christian
Language: French official, over 60 native dialects, Dioula most widely spoken
Literacy: about 20%
Labor force: over 85% of population engaged in agriculture, forestry, livestock
raising; about 11% of labor force are wage earners, nearly half in agricul-
ture, remainder in government, industry, commerce, and professions
Organized labor: 20% of wage labor force
c¢ Approved For Release 2004/08/34 am@tAaRDP79-01051A000400010002-1
4,410 sq. mi.; 21% arable, 23% meadows and pastures, 19%
forested, 37% waste, urban, or other (1964)
Limits of territorial waters: 12 n. mi:
Coastline: 635 mi.
‘VENEZUELA
ete ey
COSTA RICA i
PANAMA’
Population: 1,909,000, average annual growth rate 1.5%
(April 60-70); males 15-49, 401,000 270,000 fit for
military service; no conscription; average number
currently reaching minimum volunteer age (18) 22,000
Ethnic divisions: African 76.3%, Afro-European 15.1%, European 0.8%, Chinese
and Afro-Chinese 1.2%, East Indian and Afro-East Indian 3.4%, other 3.2%
Religion: predominantly Protestant, some Roman Catholic (12%), some spiritualist
cults
Language: English
Literacy: Ministry of Education estimates between 43% and 57% of adult population
truly literate
Labor force: about 687,000; 33% in agriculture, 1% forestry and fishing, 13%
manufacturing, 7% construction, 8% commerce, 2% transportation and communi -
cations, 13% services, 23% unaccounted for; 16% to 18% (est.) unemployed
{seasonal unemployment in agriculture can push the unemployment figure to
25%); shortage of technical and managerial personnel
Organized labor: about 25% of labor force (1966)
Population: 108,000, average annual growth rate 2.6% (May
63-March 69)
Ethnic divisions: Melanesian-Polynesian admixture, over
28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian-Polynesian aialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese laborers were imported for
plantations and mines in pre-World War II period; immigrant labor now
coming from Wallis Islands, New Hebrides, and French Polynesia
Organized labor: unorganized
Population: 4,182,000, average annual growth rate 2.7%
(FY70); males 15-49, 988,000; 555,000 fit for military
service; about 33,000 reach military age (18) annually
Ethnic divisions: main Negroid groups 75% (of which, Hausa
50%, Djerma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks ; mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a very
few Christians
Language: French official, many African languages; Hausa used for trade
Literacy: about 5%
Labor force: 26,000 wage earners; bulk of population engaged in subsistence
agriculture and animal husbandry
Organized labor: negligible
Population: about 57,000,000, average annual growth rate
2.7% (current) ; males 15-49, 12,940,000 ; 6,270,000 fit
. for military service
Ethnic divisions: 250 tribal groups, of which most important are Hausa-Fulani
(north), Ibo and Yoruba (south); these 3 tribes total over 60% of population;
about 27,000 non-Africans
Religion: 47% Muslim, 34.5% Christian, 18.3% other
Literacy: est. 25%
Language: English official; Hausa, Yoruba, and Ibo also widely used
Labor force: approx. 26.6 million; about 48% of total population, 80% of those 11
to 55 years of age of both sexes, are accounted "economically active"; only
about 700,000 are wage earners, of whom 8% are in agriculture, forestry,
hunting, and fishing; 7% mining and quarrying; 8% manufacturing; 22%
construction; 2% electricity; 8% commerce; 8% transportation and communication;
37% services
Organized labor: about 530,000 wage earners; approx. 2% of total labor force,
belong to some 666 unions
Population: 3,926,000, average annual growth rate 0.9%
(current); males 15-49, 907,000; 732,000 fit for
military service; average number reaching military
age (20) annually, 31,000
Ethnic divisions: homogeneous white population, small Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant and Roman Catholic, 1%
other
Language: Norwegian, smal] Lapp and Finnish-speaking minorities
Literacy: 99%
Labor force: 1.6 million; 19.5% agriculture, forestry, fishing, 27.0% mining and
manufacturing, 9.5% construction, 13.3% commerce, 11.9% transportation and
communication, 17.7% services ; 1.1% unemployed
Organized labor: 60% of labor force
Approved For Release 2004/08/74, 5 CIA-RDP79-01051A000400010002-1
q TURKEY
About 82,000 sq. mi.; negligible amount forested,
remainder desert, waste, or urban ae
Land boundaries: 860 mi. Ecver,
SAUDI =
& ARABIA
Limits of territorial waters: 3 n. mi.
Coastline: 1,300 mi.
Population: 688,000 (official est. 1 July 1966), average
annual growth rate 3.1% (current); males
15-49, 166,000; 85,000 fit for military service
Ethnic divisions: almost entirely Arab with small groups
of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low
Population: 117,827 ,000* (excluding Junagardh, Manavador, Gilgit, Baltistan, and
the disputed area of Jammu-Kashmir, and including several million refugees
who entered India from East Pakistan during 1971), average annual growth rate
2.1% (FY70); East Pakistan 62,408,000, average annual growth rate 1.9% (FY70);
West Pakistan 55,419,000, average annual growth rate 2.4% (FY70); males 15-49,
28,332,000; 15,150,000 fit for military service; 1,484,000 reach military age
(17) annually
Ethnic divisions: West Pakistan -- 66.4% Punjabi, 12.6% Sindhis, 7.6% Urdu,
4.6% other; East Pakistan -- 98.4% Bengali, 1.6% other
Religion: 88% Muslim, 10% Hindu, 2% other
Language: official, Urdu (West Pakistan) and Bengali (East Pakistan); total
spoken languages -- 4% Urdu, 55% Bengali, 25% Punjabi, 6% Pushtu, 10% minor
languages (Sindhi, Baluchi, Brahui); English is lingua franca
Literacy: about 16%
Labor force: 30 million (est. 1961); 73% agriculture, 10% industry, 5% commerce,
10% service, 2% unemployed; substantial shortage of skilled labor; seasonal
shortages of unskilled labor in some areas; severe underemployment
Organized labor: 5% of labor force
Population: 1,497,000, average annual growth rate 3.0%
(December 60 - May 70); males 15-49, 364,000; 250,000 fit for military
service; no conscription
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7% Indian and other
Religion: over 90% Roman Catholic, remainder mainly Protestant
Language: Spanish; about 14% speak English as native tongue; many Panamanians
bilingual
Literacy: 80% of population 10 years of age and over
Labor force: 390,000 (1967 est.); 49.1% agriculture, 19.9% services, 9.8%
commerce, 8.4% manufacturing, 3.6% construction, 2.6% transportation and
communications, 1% other (1964 est.); 5.6% Canal Zone; national average of
5% or less unemployed; 25% to 30% of unemployed in Panama and Colon;
shortage of skilled labor but an oversupply of unskilled labor
Organized labor: 5% of labor force ;
Population: 2,498,000, average annual growth rate 3.1%
(FY69); males 15-49, 602,000; 415,000 fit for military
service; average number currently reaching military
age (17) annually, 25,000
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but probably much lower (40%)
Labor force: 715,000 (1968 est.); 55% agriculture, forestry, fishing; 8%
transport and other services ; 19% manufacturing and construction; 13%
commerce and professions; 5% miscellaneous (est. 1962)
Organized labor: about 6% of labor force
Population: 14,233,000 (excluding Indian jungle population
which was estimated at 101,000 in 1961), average annual
growth rate 3.1% (FY70); males 15-49, 3,293,000; 2,230,000 fit for military
service; average number currently reaching military age (20) annually,
138,000
Ethnic divisions: 46% Indian; 38% mes tizo (whi te- Indian) ; 15% white; 1% Negro,
Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 3.5 million (1967); 46% agriculture, 17% services, 14% manufacturing,
9% trade, 4% construction, 4% transportation, 2% mining, 4% other
Organized labor: 25% of labor force
Population: 38,931,000, average annual growth rate 3.1%
(February 60-May 70); males 15-49, 8,853,000; 5,790,000
fit for military service; about 394,000 reach military
age (20) annually
Ethnic divisions: 91.5% Filipino (Malay), 4% Moros (Malay), 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4% Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national language of the Philippine
Republic; English is the language of school instruction and government
business
Literacy: about 75%
Labor force: 11 million; 60% agriculture, forestry, fishing, 12% manufacturing,
10.5% commerce, 10.5% government and services (business, recreation, domestic,
personal), 3.5% transport, storage, communication, 3% construction; 0.5% other
Population: 32,892,000, average annual growth rate 0.9% yess
(current); males 15-49, 8,638,000; 6,824,000 fit for uBva leGyeT BURia
military service; 355,000 reach military age (19)
annually
Ethnic divisions: 98.7% Polish, .6% Ukrainians, .5% Belorussians, less than
.05% Jews, .2% other
Religion: 95% Roman Catholic (about 75% practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26% industry, 36% other nonagricul tural*
Population: metropolitan Portugal 8,668,182 (1970); Cape Verde Islands 250,300
(1969); males 15-49, 2,199,000; 1,700,000 fit for military service; average
number reaching military age (20) annually, about 74,000
Ethnic divisions: homogeneous Mediterranean stock in mainland, Azores, Madeira
Islands; small number of black workers from the Cape Verde Islands
Religion: 97% Roman Catholic, 1% Protestant sects, 2% other
Language: Portuguese
Literacy:-65% (a figure considered very high by some sources )
Labor force: 3.3 million (1970); 32% agriculture, 34% industry, 34% services;
unemployment virtually nil, but underemployment widespread
Organized labor: 33.3% of labor force in syndicates subject to varying degrees
of government control
Population: 488,000, average annual growth rate 0.2%
(FY69); males 15-49, 116,000; 65,000 fit for
military service ;
Ethnic divisions: about 99% African (Balanta 30%, Fulani 20%, Mandyako 14%,
Malinke 13%, and 23% other tribes); less than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese official, numerous African languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in subsistence agricul ture
Population: 620,000, average annual growth rate 1.8% (FY66-69) |
Ethnic divisions: 95% indigenous Timorese belonging to
the Malay racial group; 9 ethnic divisions, each
speaking a distinct dialect of Malay structure;
approx. 4,600 Chinese and 10,000 halfcastes
Religion: 17% Christian (almost equally divided between Catholic and
Protestant)» remainder practice animism
Language: an estimated 9-15 dialects, of Malay origin but mutually unintelligible;
75% of the population speaks the Tetum dialect
Literacy: rate of literacy is unknown, but is very low; educational system being
expanded under first Five Year Development Plan; by 1967 total school
enrollment was 25,000 out of total school-age population of 80,000; 5% of
natives can speak Portuguese
Labor force: 90% engaged in primitive village subsistence economy > 10% engaged
as town laborers and domes tics
SET ETEey: 2,766,000, average annual growth rate 1.1%
FY69
Ethnic divisions: 80% white, 20% mixed (with Indian and
Negro elements )
Religion: predominantly Roman Catholic
Language: Spanish, English
Literacy: 88%
Labor force: 706,000; 19% agriculture, 14% manufacturing, 7% construction, 39%
government services and trade, 8% other, 13% unemployed
Organized labor: 45% of labor force
Population: 129,000, average annual growth rate 10.8%
(FY65-69); males 15-49, about 31,000; about 18,000
fit for military service
Ethnic divisions: 56% Arab; 23% Iranian; 14% Pakistani; 7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: 48,000 (1969)
Population: 5,537,000, average annual growth rate 3.3%
(FY67-70); males 15-49, 1,284,000; 785,000 fit for
military service; average number reaching military
age (18) annually, 53,000
Ethnic divisions: 96% African, 3% European, less than
1% Coloreds and Asians
Religion: 51% syncretic (part Christian, part animist), 24% Christian,
24% animist, a few Muslim
Language: English official; Chishona and Sindebele also widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1971) 776,000 Africans (including many migrants from Zambia and
Malawi), Europeans, Asians, and coloreds (people of mixed heritage); 35%
agriculture, 25% mining, manufacturing, construction, 40% transport and
services
Organized labor: about one-third of European wage earners are unionized, but
only a small minority of Africans (1966)
Population: 20,596,000, average annual growth rate 1.1%
(current); males 15-49, 5,368,000; 4,510,000 fit for
military service; 187,000 reach military age (20)
annually
Ethnic divisions: 87% Romanian, 8% Hungarian, 2% German, 3% other
Religion: 14,000,000 Romanian Orthodox, 1,000,000 Roman Catholic, 1,000,000
Protestants, 100,000 Jews, 30,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.4 million (est. 1 July 1966); 57% agriculture, 19% industry,
24% other nonagricul tural
Population: 425,000, average annual growth rate 3.6% (FY70);
males 15-49, 101,000; 56,000 fit for military service
Ethnic divisions: 35.5% Creole (Negro and mixed), 34.7% Hindustani (East Indian),
14.9% Javanese, 8.5% Bush Negro, 2.2% Amerindian, 1.6% Chinese, 1.3% Europeans,
1.3% other and unknown
Religion: Muslim, Hindu, Moravian, Roman Catholic, other -- in order of size
t figures unknown)
Language: Dutch official; English widely spoken; Taki-Taki (Surinam Creole)
is native language of Creoles and lingua franca; Hindi; Javanese
Literacy: 70% to 75%
Labor force: 80,190 (1964); 24.9% agriculture, 6.9% mining, 10% industry, 2.8%
building trades, 13.5% trade and transport, 6.7% services, 22.2% government
employees, 3.1% unclassified, 9.9% unemployed and seeking work
Organized labor: approx. 10% of labor force
Population: 427,000 (African population only), average
annual growth rate 3.0% (FY70); males 15-49, 98,000;
50,000 fit for military service
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence agriculture; 55-60 ,000
wage earners, many only intermittently, with 31% agricul ture, 11% government,
11% manufacturing, 12% mining and forestry, 35% other (1968 est.); 7,900
employed in South African mines (1969)
Organized labor: about 15% of wage earners are unionized
Population: 8,159,000, average annual growth rate 1.0%
(January 70-71); males 15-49, 1,905,000; 1,637,000 fit
for military service; 59,000°reach military age (19)
annually
Ethnic divisions: homogeneous white population; small Lappish minority
Religion: 92% Evangelical Lutheran, 7% other Protestant, Roman Catholic, Eastern
Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking minorities
Literacy: 99%
Labor force: 3.5 million; 11.8% agriculture, forestry, fishing; 33.5% mining
and manufacturing; 9.6% construction; 15.5% commerce; 7.2% transportation
and communications; 20.9% services; 4.0% unemployed
Organized labor: 70% of labor force
Sauor
—
LIBYA JEGYP RO ARABIA “Sige
Population: 6,386,000, average annual growth rate 1.0%
(January 67-71); males 15-49, 1,524,000; 1,320,000 ©
fit for military service; 45,000 reach military age (20))
annually PS
Ethnic divisions: total population -- 69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals -- 74% German, 20% French, 4% Italian,
1% Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals -- 74% German, 20% French, 4% Italian, 1% Romansch,
1% other; total population -- 69% German, 19% French, 10% Italian, 1%
Romansch, 1% other
Literacy: 98%
Labor force: 2.5 million; 16% agriculture and forestry, 47% industry and crafts,
20% trade and transportation, 5% professions, 2% in public service, 10%
domestic and other; no significant unemployment shortage of both skilled and
unskilled labor -- 4,400 unfilled vacancies in January 197]
Organized labor: 20% of labor force','2135e8039cdbb30f626e08ff210763094238f4216b60770766dd66b10a98ae8d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68ffc30931983454d224b2e158738aaf70cf1586b4e1367479fe183ded3da0d4',1971,'IE','Ireland','people-and-society',24,'2.5 sq. mi.
Land boundaries: 1 mi.
Limits of territorial waters: 3 n. mi.
Coastline: 7.5 mi.
Population: 28,000 (official estimate for 31 December ;
1969); males 15-49, about 6,000; about 3,000 fit for Medes
military service
Ethnic divisions: mostly Italian, English, Maltese, and
Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages; Italian, Portuguese, and
Russian also spoken; English used in the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian laborers
Organized labor: 3,369, in 27 registered trade unions
Population: 8,765,000, average annual growth rate 0.4%
(March 61-71); males 15-49, 2,143,000; 1,725,000 fit
for military service, about 69,000 reach military age
(21) annually
Ethnic divisions: 96% Greek, 2% Turkish, 1% Albanian, 1% other
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total about 82%
Labor force: 3.7 million (1967 est.); 50% agriculture, 15% industry, 9% trade,
26% other; unemployment and underemployment , 20% total in all fields;
shortage of skilled labor in nonagricultural sectors aggravated by large-
scale emigration
Organized labor: 10% of labor force
Population: 5,497,000, average annual growth rate 2.8%
(current); males 15-49, 11,348,000; 680,000 fit for
military service; about 60,000 reach military age
(18) annually :
Ethnic divisions: 44% Indian, 56% Ladino (mestizo and Indian -- Wes ternized)
Religion: predominantly Roman Catholic ;
Language: Spanish, but over 40% of the population speaks an Indian language as
a primary tongue
Literacy: about 30%
Labor force: 1.5 million (1969); 63.2% agriculture, 12.4% manufacturing, 11.8%
services, 12.6% other, 2% unemployed; severe shortage of skilled labor;
oversupply of unskilled labor; of this total an estimated 10% are unemployed
at any one time
Organized labor: 6.5% of labor force (1969)
Population: 3,965,000, average annual growth rate 2.6%
(FY67); males 15-49, 937,000; 450,000
fit for military service
Ethnic divisions: 99% African (3 major tribes - Fulani,
Py Malinke, Soussou; and 13 smaller tribes)
Religion: 80% Muslim, 19% animist, 1% Christian
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written language
Labor force: 1.5 million, of which less than 10% are wage earners; most of
population engages in subsistence agriculture
Organized labor: virtually 100% of wage labor force loosely affiliated with the
National Confederation of Guinean Workers, which is closely tied to the PDG','572a88d15b5d191b42e68f0831027c24b5d4d193dc3b111cd955e98c0ff35fc9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce81a74a64755c7f1b3bf2ca96f5aeaf75cef1973a855ac5c578e79bdad9e1b5',1971,'ET','Ethiopia','people-and-society',29,'Population: 2,443,000, average annual growth rate 3.9% (FY67-69); males 15-49,
571,000; 435,000 fit for military service; average number currently reaching
military age (18) annually 25,000
Ethnic divisions: 97% Arab, 2% Circassian, 1% Armenian
Religion: 94% Sunni Muslim, 6% Christian
Language: Arabic official, English widely understood among upper and middle
classes
Literacy: 33% West Jordan, 32% East Jordan
Labor force: 434,000; 33% unemployed
Organized labor: 5% of labor force
Population: 11,711,000, average annual growth rate 2.9%
(FY69); males 15-49, 2,610,000;
1,270,000 fit for military service; no conscription
Ethnic divisions: 97% native African (including Bantu, Nilotic, Hamitic and
Nilo-Hamitic); 3% European, Asian, and Arab
Religion: 56% Christian, 36% animist, 7% Muslim, 1% Hindu
Language: English and Swahili official; each tribe has own language
Literacy: 20% to 25%
Labor force: 2.5 million; about 977,000, (39%) in monetary economy (1967)
Organized labor: about 215,000
Population: 14,765,000, average annual growth rate 2.8%
(current); males 15-49, 3,260,000; 1,935,000 fit for
military service; 164,000 reach military age (18)
annually
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 5.7 million; 50% agriculture, 50% industry; shortage of skilled and
unskilled labor
Population: 32,219,000, average annual growth rate 1.9%
(October 66-70); males 15-49, 7,773,000; 4,920,000 fit
for military service; average number reaching military
age (18) annually 338,000
Ethnic divisions: homogeneous; small Chinese minority (approx. 20,000)
Religion: strong Confucian tradition; pervasive folk religion (Shamanism) ;
vigorous Christian minority (5.5% of population); Buddhism (including
estimated 20,000 members of Soka Gakkai); Chondokyo (religion of the heavenly
way), eclectic religion with nationalist overtones founded in 19th century,
claims about 1.5 million adherents
Language: Korean
Literacy: about 90%
Labor force: about 10.0 million (1970); 48.3% agriculture, fishing,
forestry, 30.0% services, 13.6% mining and manufacturing, 2.8% construction,
4.5% unemployed
Organized labor: about 10% of nonagricultural labor force
Population: 857,000, average annual growth rate 9.4%
(April 65-70); males 15-49, about 292,000; about 160,000
fit for military service
Ethnic divisions: 87% Arabs, 12% Iranians, Indians, and Pakistani, 1% other
Religion: 95% Muslim, 5% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign language
Literacy: about 55% (1965)
Labor force: 250,000 (1969); 9% manufacturing, 16% construction, 45% services,
13% commerce
Organized labor: labor unions, first authorized in 1964, formed in oil industry
and among government personnel
Population: 3,069,000, average annual growth rate 2.4%
(FY70); males 15-49, 733,000; 390,000 fit for military
service; average number currently reaching usual
military age (18) annually, 33,000; no conscription
age specified .
Ethnic divisions: 47% Lao; 14% Tai; 25% Phoutheng (Kha), Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant foreign language also used in
administration
Literacy: about 12%
Labor force: about 1,268,000; 80%-90% agriculture; 159,286 engaged in
manufacturing and services; 11,864 government employees
Organized. labor: only civil servants are organized
Population: 2,918,000 (including Lebanese nationals living
outside the country who are on the population register,
but excluding registered Palestinian refugees numbering ss
“ 171, 517 on 30 June 1969), average annual. growth rate 3.1% (current); males
15-49, 704,000; 415,000 fit for military service; average of about 30,000
reach military age (18) annually
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1% other (official estimates);
Muslims believed to constitute slight majority
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically active; 49% agriculture, 11% industry,
14% commerce, 26% other; moderate. unemployment
Organized Tabor: about 55,000
Population: 926,000, average annual growth rate 1.6%
(FY69); males 15-49, 188,000; fit for
military service 95,000
Ethnic divisions: 99.7% Bantu, 1,600 Europeans, 800 Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in subsistence agricul ture;
150,000 to 250,000 spend 6 months to many years as wage earners in South
Africa
Organized labor: negligible
Population: 1,592,000, average annual growth rate 3.0%
(current); males 15-49, 282,000; 155,000 fit for
military service; no conscription
Ethnic divisions: 5% coastal descendants of immigrant Negroes; 95% indigenous
Negroid African tribes including Gola, Kissi, Vai, Kpelle, Kru, and Mandingo
Religion: probably more Muslims than Christians; 80%-90% animist
Language: English official; 28 tribal languages or dialects, pidgin English used
by about 20%
Literacy: about 24% over age 5
Labor force: 450,000, of which 360,000 are in tribal, nonmonetary economy ; of
90,000 in modern economy » 45% in agriculture; 23% government services; 20%
mining, construction, and manufacturing; and 12% in trade and transportation;
about 3,000 non-African foreigners hold about 95% of the top level manage-
ment and engineering jobs
Organized labor: 2% of labor force
Population: 2,045,000, average annual growth rate 3.7%
(current); males 15-49, 468,000; 280,000 fit for militar
service; about 20,000 reach military age (17) annually;
conscription now being implemented
Ethnic divisions: 97% Berber and Arab with some Negroid stock; some Greeks,
Maltese, Jews, Italians
Religion: 100% Muslim
Language: Arabic; Italian and English widely understood in major cities
Literacy: 35%
Labor force: 458,000-500,000; between ages 15-64, 405,000-430 ,000; 61% of labor
force in agriculture (1964)','18a26c0263941146dccd5f1c5c3f0f9e0cbd46565a8adfa36ad658bac495d221','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('234af4a90174bc407456427cf7c6c574e6c05876b8074350636a9cc6d7c904a6',1971,'NO','Norway','people-and-society',33,'Population: 25,000, average annual growth rate 4.8% (FY69)
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers; 59% industry ,
20% trade and commerce, 13% professional and other, 8%
agriculture
Population: 342,000, average annual growth rate 0.8% apkaiaae
(January 61-71); males 15-49, 78,000; 62,000 fit for
military service; about 2,500 reach military age (19)
annually
Ethnic divisions: 83% Luxembourger, including an estimated
5% of Italian descent; remainder French, German,
Belgian, etc.
Religion: more than 90% Roman Catholic
Language: Luxembourgish, German, French; most educated Luxembourgers also speak
English
Literacy: 98%
Labor force: (1969) 139,000; 11.1% agriculture (including forestry and fishing),
44.2% industry, 44.7% services, no significant unemployment; shortage of
skilled labor 800 (1970)
Organized labor: 45% of labor force
Population: 244,000 (official estimate for | July 1969);
males 15-49, 67,000; 42,000 fit for military service
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about one-
half are Chinese
Language: Chinese 98%, Portuguese 2%
Literacy: almost 100% among Portuguese and Macanese; no data on Chinese
population
Labor force: 5% agriculture, 30% manufacturing, 3% construction, 1% utilities,
27% commerce, 8% transportation and communications, 26% services (1960 data)
Population: 6,982,000, average annual growth rate 2.3%
(FY70); males 15-49, 1,574,000; 925,000 fit for
military service; average number reaching military age
(20) annually about 65,000
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting of Merina (1,643,000)
and related Betsileo (760,000), on the one hand, and coastal tribes with
mixed Negroid, Malayo-Indonesian, and Arab ancestry on the other; coastal
tribes include Betsimisaraka 941,000, Tsimihety 442,000, Sakalava 375,000,
Antaisaka 415,000; there are also 38,000 French, 66,000 other
Religion: more than half animist; about 35% Christian, less than 10% Muslim
Language: French and Malagasy official
Literacy: 30% to 35%
Labor force: about 3.4 million, of which 90% are nonsalaried family workers
engaged in subsistence agriculture; of 175,000 wage and salary earners,
26% agriculture, 17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscellaneous
Organized labor: 4% of labor force
Population: 4,736,000, average annual growth rate 3.0%
(FY69-70); males 15-49, 983,000; about 495,000 fit
for military service
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is second
African language
Literacy: 6% of population over 21 years old
Labor force: 120,000-150,000 wage earners (1966); 6,000 Europeans permanently
employed; 300,000 live and work in Rhodesia, South Africa, and Zambia; 30%
agriculture, 11% construction, 10% commerce, 13% manufacturing, 10% admini-
stration, 26% miscellaneous services
Organized Tabor: small minority of wage earners are unionized
Population: 10,912,000, average annual growth rate 2.7% (current)
West Malaysia: 9,210,000, average annual growth rate 2.7% (June 57-August 70);
males 15-49, 2,154,000; 1,320,000 fit for military service
Sabah: 655,000, average annual growth rate 3.3% (July 60-August 70); males
15-49, 156,000; 92,000 fit for military service
Sarawak: 1,047,000, average annual growth rate 3.0% (June 60-August 70);
males 15-49, 249,000; 148,000 fit for military service; conscription age
for Malaysia is 21 -- an age reached by about 1121,000 annually
Ethnic divisions:
Malaysia: 44% Malay, 36% Chinese, 8% tribal, 10% Indian and Pakistani,
2%. other
West Malaysia: 50.1% Malay, 36.9% Chinese, 11% Indian and Pakistani,
2% other
Sabah: 23.1% Chinese, 67.3% indigenous tribes, 9.6% other
Sarawak: 31.5% Chinesé, 50% indigenous tribes, 17.5% Malay, 1% other
Religion:
West Malaysia: Malays nearly all Muslim, Chinese predominantly Buddhists,
Indians predominantly Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist, 16% Christian, 35%
tribal religion, 2% other
Language:
West Malaysia: Malay (official); English, Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dialects, Mandarin and Hakka dialects
predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal languages
Literacy:
West Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 3.45 million (1967)
West Malaysia: 2.9 million; 55% agriculture, forestry, and fishing, 11%
manufacturing and construction, 34% trade, transport, and services
199
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Labor force (cont''d):
Sabah: 213,000 (1967); 80% agriculture, forestry, and fishing, 6% manu-
facturing and construction, 13% trade and transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture, forestry, and fishing, 6% manu-
facturing and construction, 13% trade, transportation, and services,
1% other
Organized labor: 370,000 (official 1967 est.) about 10.5% of total labor force;
28% of wage labor force; unemployment about 8% of total
labor force, but higher in urban areas
Population: 113,000, average annual growth rate 1.9% (FY69)
Ethnic divisions: presumed Aryan stock with Arab admixtures
Religion: official Sunni Mus lim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs almost all the male population
Population: 5,206,000, average annual growth rate 2.4%
(FY69-70); males 15-49, 1,230,000; 690,000 fit for
ie military service; no conscription
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
* Language: French official; several African languages »
of which Mande group most widespread
Labor force: approximately 60,000 salaried, 40,000 of whom are civil servants;
most of population engaged in agriculture and animal husbandry
Organized labor: UNTM, which claimed all eligible employees, dissolved; thirteen
national unions currently directed by a government control led Coordination
Committee of Mali Trade Unions (CCSM)
Population: 323,000 (official estimate for 30 September
1970); males 15-49, 86,000; 65,000 fit for military
service
Ethnic divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in 1946
Labor force: 99,000; 39% services, 28% government, 22% manufacturing, 7%
agriculture, 4% unemployed
Organized labor: approximately 33% of labor force
Population: 1,213,000, average annual growth rate 2.3%
(FY67-68); males 15-49, 287,000; 140,000 fit for
military service; conscription law not implemented
Ethnic divisions: 80% Moor, 20% Negro
Religion: nearly 100% Muslim
Language: French and Arabic official
Literacy: under 5%
Labor force: about 18,000 wage earners (1964); remainder of population in
farming and herding
Organized labor: 18,000 union members claimed by single union, Mauritanian
Workers'' Union
Population: 855,000, average annual growth rate 1.5%
(FY69); males 15-49, 201,000; 100,000 fit for military
service
Ethnic divisions: Indians 67%, Creoles 29%, Chinese 3.5%, English and French 0.5%
Religion: 51% Hindu, 33% Christian (mostly Catholic with a few Anglican
Protestants), 16% Muslim
Language: English official language; Hindi, Chinese, French Creole
Literacy: not known, but very high (90% of school age children in school)
Labor force: 120,000; 65% agriculture, 5% industry; 30% are unemployed, under-
employed, or self-employed
Organized labor: about 10% of labor force
Population: 24,000 (official estimate for 30 September 1970)
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
Literacy: almost complete
Labor force: not available
Organized labor: not available
Population: 1,344,000, average annual growth rate 3.0%
(current); males 15-49, 286,000; 185,000 fit for
military service; average number reaching military
age (18) annually, about 14,000 =
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese, 2% AUSTRALIA
Russian, 2% other
Religion: predominantly Tibetan Buddhist, about 4% Muslim, limited religious
activity because of Communist regime
Languages: Khalkha Mongol used by over 90% of population; minor languages
include Turkic, Russian, and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the population is in the labor
force, including a large percentage of Mongolian women; acute shortage of
both skilled and unskilled labor (no reliable information available)
Population: 16,324,000, average annual growth rate 3.2%
(FY69); males 15-49, 3,897,000; 2,645,000 fit for
military service; about 180,000 reach military age (18)
annually; limited conscription
Ethnic divisions: 98.9% Arab-Berber, .25% Hebrew, 1% non-Moroccan
Religion: 9% Muslim, 1% Christian, .25% Jewish
Language: Arabic (official); several Berber dialects; French is language of much
business, government, diplomacy, and education
Literacy: 10% to 15%
Labor force: 4.4 million; 70% agriculture, 15% industry, 15% other (military,
police, civil service, transportation, mines, teachers, merchants,
construction workers)
Organized labor: 10% to 15% of labor force
Population: 8,421,000, average annual growth rate 2.2%
(September 60-December 70); males 15-49, 1,953,000;
* 940,000 fit for military service
Ethnic divisions: 97.5% native Africans, 2.5% Europeans and Asians
Religion: primarily animist, 1,100,000 Muslims, 860,000 Christians
Language: Portuguese (official); many tribal dialects
Literacy: 7%
Labor force: (1963 est.) 610,000; 50,000 non-African wage earners; 560 ,000
African wage earners in Mozambique; 290,000 additional African wage earners
temporarily working in Rhodesia and South Africa; unemployment serious
problem, most native Africans provide unskilled labor or remain in
subsistence agricultural sector
Organized labor: approx. 44,000 (end of 1970); 75% are white
8.2 sq. mi.; insignificant arable land, no urban areas,
extensive phosphate mines (1970)
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Coastline: 15 mi.','fd3f9d47ace3a80c9f7bb4f970c198c3732bd422181542de01cc5a2960684691','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d3e057cb53e43e0a84c8711c3fb50e12a03c2270ff679f27c049a8facccfd57',1971,'AU','Australia','people-and-society',37,'Population: 7,000 (official estimate for 30 June 1969);
males 15-49, about 1,800; fit for military service,
about 950; average number reaching military age (18)
annually, 1971-75, less than 100
Ethnic divisions: 2,921 Nauruans, 1,167 Chinese, 428
Europeans, 1,532 other Pacific Islanders
Religion: Christian (2/3 Protestant, 1/3 Catholic)
Language: Nauruan, a distinct Pacific Island tongue; English, the language of
school instruction, spoken and understood by nearly all
Literacy: nearly universal
Population: 11,343,000, average annual growth rate 1.8%
(FY69); males 15-49, 2,796,000; 1,410,000 fit for
military service; 129,000 reach military age (17)
annually
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%),
representing considerable intermixture of Indo-Aryan and
Mongolian racial strains; country divided among many quasi-tribal communities
Religion: only official Hindu Kingdom in world, although no sharp distinction
between many Hindu and Buddhist groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided into numerous dialects;
Nepali official language and lingua franca for much of the country; same
script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5% industry; great lack of skilled
labor
Population: 13,261,000, average annual growth rate 1.1%
(current); males 15-49, 3,320,000; 2,980,000 fit for
military service; average number reaching military age
(20) annually 116,000
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 41% Protestant, 40% Roman Catholic, 19% unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24% services, 16% commerce, 10%
agriculture, 9% construction, 7% transportation and communications, 4%
other; 1.05% registered unemployed; no shortage of skilled labor but shortage
of semi-skilled labor; 129,000 unfilled vacancies reported by employers in
January, 197]
Organized labor: 33% of labor force
Population: 226,000, average annual growth rate 1.4%
(FY69); males 15-49, 58,000; 30,000 fit for military
service; about 2,000 reach military age (20) annually
Ethnic divisions: 85% largely mixed Negro stock except on
Aruba where 12% Negro and approx. 55% mixed Carib
Indian and European; rest European with some Chinese,
especially on Aruba
Religion: predominantly Roman Catholic; sizable Protestant, smaller Jewish
minorities
Language: officially Dutch; predominantly English; colloquial "papiamento," a
Spanish-Portuguese-Dutch-English mixture
Literacy: 75%-80%
Labor force: 66,000; 1% agriculture, 21% industry, 21% unemployed, 8%
construction, 41% government and services, 8% other
Organized labor: approx. 15% of labor force
Population: 2,566,000, average annual growth rate 2.8%
(FY67-70); males 15-49, 668,000 (Papua 173,000, New
Guinea 485,000); about 345,000 fit for military service
(Papua 90,000, New Guinea 255 ,000)
Ethnic divisions: predominantly Melanesian and Papuan, some Negrito, Micronesian,
and Polynesian types
Religion: over one-half of population nominally Christian (490,000 Catholic,
320,000 Lutheran, other Protestant sects); remainder animist
Language: 700 indigenous languages ; pidgin English and 2 or 3 native languages
are linguae francae for over one-half of population; English spoken -by
1% to 2% of population
Literacy: 1%; in English, 0.1%
Labor force: no available figures; mostly subsistence farmers
Population: 88,000, average annual growth rate 2.5% (FY69)
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized
Population: 179,000 (census of 15 March - 16 April 1968);
males 15-49, about 43,000; about 22,000 fit for
military service
Ethnic divisions: Arabs 72%; others include Iranians, Pakistanis, and Indians
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 20% est. (1968)
Labor force: 77,000 (1968)
Population: 5,325,000, average annual growth rate 2.9%
(current); males 15-49, 1,274,000; 680,000 fit for
military service; about 49,000 reach military age
(20) annually
Ethnic divisions: 98% Arab, 1% European, less than 1% Jewish
Religion: 98% Muslim, 1% Christian, less than 1% Hebrew
Language: Arabic (official), Arabic and French (commerce)
Literacy: about 30%
Labor force: 1.5 million; 70% agriculture, 10% manufacturing and construction,
20% other; 25% underemployed; shortage of skilled labor
Organized labor: 10% of labor force; General Union of Tunisian Workers (UGTT),
subordinate to Destourian Socialist Party
Population: 36,765,000, average annual growth rate 2.6%
(October 65-70); males 15-49, 9,302,000; 5,490,000
fit for military service; about 378,000 reach military age (20) annually
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.7 million; 72% agriculture, 28% industry, commerce, service,
etc.; substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force
Population: 10,190,000, average annual growth rate 2.9%
(August 69-July 70); males 15-49, about 2,361,000;
about 1,310,000 fit for military service
Ethnic divisions: 98.7% African, 1.3% European, Asian,
Arab
Religion: about 60% nominally Christian, rest Muslim or pagan
Language: English official; Luganda and Swahili widely used; other Bantu and
Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which 256,799 in paid labor, remaining
in subsistence activities
Organized labor: 123,284 union members
Population: 246,129,000, average annual growth rate 0.9%
(current)
Ethnic divisions: 77% Slavic, 23% among some 170 ethnic groups
Religion: 70% atheist, 18% Russian Orthodox, 9% Muslim, 3% other
Language: more than 200 languages and dialects (at least 18 with more than 1
million speakers); 76% Slavic group, 8% other Indo-European, 11% Altaic,
3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: 125.8 million (1970) , 32% agriculture, 68% industry and other non-
agricultural fields, unemployed not reported, shortage of skilled labor
not reported, no shortage of unskilled labor
Population: 5,547,000, average annual growth rate 2.0%
(FY70); males 15-49, 1,310,000; 630,000 fit for
military service; no conscription
Ethnic divisions: more than 50 tribes; principal tribe
is Mossi (about 2.5 million); other important groups
are Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to Sudanic family, spoken
by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active population engaged in animal
husbandry, subsistence farming, and related agricultural pursuits; 1.9%
are wage and salary earners; about 20% of male labor force migrates
annually to neighboring countries for seasonal employment
Organized labor: less than 30,000 wage earners
Population: 1,000 (official estimate for 1 July 1964)
Ethnic divisions: primarily Italians but also many
other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees divided
into 3 categories -- executives, officeworkers,
and salaried employees
Organized labor: none
Population: 10,972,000 (excluding Indian jungle population
estimated at 32,000 in 1961), average annual growth
rate 3.6% (FY70); males 15-49, 2,514,000; 1,730,000
fit for military service; 120,000 reach military age
(18) annually
Ethnic divisions: 67% mestizo, 21% white, 10% Negro, 2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 72% (claimed)
Labor force: 3 million (1969), 24% agriculture, 6% construction, 17% manufacturing,
6% transportation, 18% commerce, 25% services, 4% petroleum, utilities, and
other
Organized labor: 45% of labor force
Population: 20,086,000, average annual growth rate 1.5%
(current)
Ethnic divisions: 85%-90% predominantly Vietnamese; ethnic minorities include
. Muong, Thai, Meo, and Man
Religion: Confucianism, Buddhism, Taoism, Catholicism
Language: closely corresponds to the breakdown of ethnic groups
Literacy: claimed to be 95% (1964)
Labor force: (1 January 1970) 9.6 million, not including military; about 70%
agriculture and 10% industry
Population: 146,000, average annual growth rate 2.4%
(FY67-70)
Ethnic divisions: Polynesians, about 12,000 Euronesians
(persons of European and Potynesian blood), 700
Europeans
Religion: 99.7% Christian (about half of population associated with the London
Missionary Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all children from 7-15 years)
Labor force: agriculture 19,148; mining and manufacturing 1,716 (1961)
Organized labor: unorganized
Population: 1,338 ,000**, average annual growth rate 3.0%
(current); males 15-49, 324,000; 175,000 fit for military
service ;
Ethnic divisions: almost all Arabs; a few Indians, Somalis, and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 5,975,000, average annual growth rate 2.8%
(FY66-70); males 15-49, 1,446,000; 770,000 fit for
military service; about 50,000 reach military age (18)
annually; universal military conscription law (10
January 1963) makes military service obligatory for
all Yemeni males 18-30
Ethnic divisions: Que aAra~, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agricul ture and herding','5d09482561985aa11f81accf7e82fcf7d98fdbfdbf11ded0b1187ee38f4698cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7316d906de8c4aec7ec3aa76a18673b07a0d0e8388e6bcd41edb13a44e825e1',1971,'CO','Colombia','people-and-society',42,'Population: 104,000, average annual growth rate 1.6% Saaz
(April 60-70)
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 27,000 (1960); 50% agriculture
Organized labor: 20% of labor force
Population: 91,000, average annual growth rate 1.1% (April
60-70 ) } BRAZIL
Ethnic divisions: mainly of African Negro descent; remainder
mixed with some white and East Indian and Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 24,000 (1960); about 40% in agriculture
Organized labor: 10% of labor force
Population: 20,000, average annual growth rate 1.9%
(FY65-70)
Ethnic divisions: composite of Mediterranean, Alpine,
Adriatic, and Nordic racial types
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of Sanmarinese Workers (affiliated
with ICFTU) has about 1,800 members; Communist-dominated Camera del Lavoro,
about 1,000 members
Population: 4,029,000, average annual growth rate 2.6%
(FY69); males 15-49, 952,000; 455,000 fit for military
service; 42,000 reach military age (18) annually
7 Ethnic divisions: 36% Wolof, 18% Fulani, 17% Serer, 9%
Tukulor, 9% Dyola, 7% Malinke, 3% other African,
1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly Roman Catholic)
Language: French official, but regular use limited to literate minority; most
Senegalese speak own tribal language; use of Wolof vernacular spreading --
now spoken to some degree by nearly half the population
Literacy: 10% (est.) in 14 plus age group
Labor force: 1,732,000; about 70% subsistence agricultural workers; about 125,000
wage earners
Organized labor: majority of wage-labor force represented by unions; however,
dues-paying membership very limited
156 sq. mi.; 54% arable land, nearly all of it is under
Approved For Release 2004(Q8/#1 |: hIA-RDP79-01051A000400010002-1
cultivation, 17% wood and forest land, 29% other
(mainly reefs and other surfaces unsuited for
agriculture) ; 40 granitic and 43 coral islands
Limits of territorial waters: 3 n. mi.
Coastline: 305 mi. (Mahe Island 58 mi.)
Population: 54,000, average annual growth rate 2.0% (FY69);
males 15-49, 13,000; 7,000 fit for military service
Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans )
Religion: 90% Roman Catholic
Language: English official; Creole most widely spoken
Literacy: limited
Labor force: 22,000 agriculture
Organized labor: 3 major trade unions
Population: 2,607,000, average annual growth rate 1.5%
¢ (FY69); males 15-49, 616,000; 295,000 fit for military
service; no conscription
Ethnic divisions: over 99% native African, rest European and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to literate minority;
principal vernaculars are Mende in south and Temne in north; "Creole," a
form of pidgin English, is also widely spoken
Literacy: about 10%
Labor force: about 1.5 million; most of population engages in subsistence
agriculture; only small minority, some 100,000, earn wages
Organized labor: 35% of wage earners (35,000)
Population: 2,127,000, average annual growth rate 1.6%
(FY70); males 15-49, 492,000; 335,000 fit for military
service
Ethnic divisions: 78% Chinese, 12% Malay, 7% Indians and
Pakistani, 3% other
Religion: majority of Chinese are Buddhists or atheists; Malays nearly all Mus lim;
minorities include Christians, Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay, Tamil, and English are
official languages
Literacy: 88% (1967)
Labor force: 577,000; 3% agriculture and fishing; 24% manufacturing and
construction; 67% trade, transportation, communications, and other services ;
6% other
Organized labor: 26% of labor force
Population: 2,886,000, average annual growth rate 2.2%
(FY69); males 15-49, 700,000; 365,000 fit for military
service; no conscription
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000 Arabs, 3,000 Europeans,
800 Asians
Religion: almost entirely Muslim
Language: Somali (but no written form); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled laborers; 70% pastoral
nomads, 30% agriculturists, government employees, traders, fishermen,
handicraftsmen, other
Organized labor: law providing for government-controlled labor union promulgated
in June 1971, but union so far not established
Population: 22,118,000, average annual growth rate 2.4%
(FY69); males 15-49, 5,060,000; 3,065,000 fit for
military service; obligation for service in Citizen
Force begins at 18; volunteers for service in permanent
force must be 17
Ethnic divisions: 17.8% white, 69.9% Bantu, 9.4% Colored, 2.9% Asian
Religion: primarily Christian except Asian and Bantu; 60% of Bantu are animists
Language: Afrikaans and English official, Bantu have many vernacular languages
Literacy: almost all white population literate; government estimates 35% of
Bantu literate
Labor force: 8.7 million (total of economically active, 1960); 53% agricul ture,
8% manufacturing, 7% mining, 5% commerce, 27% miscellaneous services
Organized labor: about 5% of total labor force is unionized (mostly white
workers); nonwhites have no bargaining power
Population: 773,000, average annual growth rate 1.9%
(FY60-65); males 15-49, about 155,000; about 90,000
fit for military service
Ethnic divisions: 14% white, 81% Africans, 5% Coloured
(mulattoes); almost half the Africans belong to Ovambo
tribe; Herero, Okavango, Nama, and Damara tribes have
about 30,000 members each
Religion: whites predominantly Christian, nonwhites either animist or Christian
Language: Afrikaans principal language of about 70% of white population, German
of 22%, and English of 8%; several African languages
Literacy: high for white population; low for nonwhite
Labor force: 75,000 African wage earners (1964 est.); 68% agriculture, 15%
railroads, 13% mining, 4% fishing
Organized labor: no trade unions, although some white wage earners belong to
South African unions
Population: 33,833,000, average annual growth rate 1.1% (January 70-71); males
15-49, 8,263,000; 6,345,000 fit for military service; 289,000 reach military
age (20) annually
Ethnic divisions: homogeneous composite of Mediterranean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great majority; but 17% speak Catalan,
7% Galician, and 2% Basque
Literacy: about 90%
Labor force (1969): 12.6 million; 30.2% agriculture, 36.9% industry, 32.9%
services; registered unemployment is 1% of labor force
Organized labor: 90% of labor force in compulsory government-controlled
syndicates
Population: 63,000 (official est. 1 July 1969); males
15-49, 15,000; 7,000-8,000 fit for military service
Ethnic divisions: 51.2% Arab, Berber, and Negro nomads;
48.8% Spanish ;
Religion: 51% Muslim, 49% Catholic
Language: Spanish (official), local Arabic or Hassania
Literacy: among Spanish, probably nearly 100%; among nomads, perhaps 5%
Labor force: 12,000; 50% agriculture, 50% other
Organized labor: none
Population: 16,289,000, average annual growth rate 2.5%
(FY70); males 15-49, 3,708,000; 2,200,000 fit for
military service; average number reaching military
age (18) annually, 160,000
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro, 2% foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23% pagan, 4% Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects of Nilotic, Nilo-Hamitic,
and Sudanic languages, English; program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 89% agriculture, 15% industry, commerce, services,
etc.; labor shortages exist for almost all categories of employment','b9bd589705b346552b2c74bc375543f1582c01ef7fd1942551377a3e2fbf29ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e38d7a25f4bab4ad81ff87de054c9cac9b626bc6fc1852bc45e6da4b584b868',1971,'SD','Sudan','people-and-society',50,'Population: 13,812,000, average annual growth rate 2.7%
(FY70); males 15-49, 3,203,000; 1,775,000 fit for military service
Ethnic divisions: 99% native Africans consisting of well over 100 tribes; 1%
Asian, European, and Arab
Religion: Tanganyika -- 45% animist, 29% Christian, 25% Muslim; Zanzibar -~
almost all Muslim
Language: Swahili official; English often used as administrative language;
primary language of about 89% of the population is one of the many Bantu,
Nilotic, Nilo-Hamitic, and Hamitic languages; 10% Swahili; 1% English
Literacy: 5% to. 10%
Labor force: under 400,000 in paid employment, over 90% in agriculture
Organized labor: 15% of labor force
Population: 2,095,000, average annual growth rate 2.5%
(FY67-70); males 15-49, 494,000; .246,000 fit for
military service; no conscription
Ethnic divisions: some 40 tribes; largest and most important are Ewe in south and
Cabrais in north; under 1% European and Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of commerce; major African languages
are Ewe and Mina in south and Dagoma, Tim, and Cabrais in north
Literacy: 5% to 10%
Labor force: bulk of population engaged in subsistence agriculture; about
30,000 wage earners, evenly divided between public and private sectors','495dd406e60fa5bfa0f49e23e204a1e28628e8d91748579b566a37f67cf79ebf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('561990ff52d1402e499a4bc17ba716a83c53d9a37bf12bf588be3a383749abab',1971,'JP','Japan','people-and-society',53,'Population: 20,641,000, average annual growth rate 0.9%
(current); males 15-49, 5,494,000; 4,445,000 fit for
military service; 204,000 reach military age (19)
annual ly
Ethnic divisions: 41% Serb, 22% Croat, 9% Slovene, 8% Macedonian, 3% Montenegrin,
5% Albanian, 3% Hungarian, 9% other. (1961 census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic, 12% Muslim, 3% other, 12%
none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Albanian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 13.5 million (1970); 49.6% agriculture, 16% mining and manufacturing,
34.4% other nonagricultural activities; reported unemployment averaged 8%
of registered labor force (social sector) in 1967
Population: 22,542,000, average annual growth rate 2.3%
(FY68); males 15-49, 5,500,000; 2,640,000 fit for
military service
Ethnic divisions: over 200 African ethnic groups, the majority are Bantu; four
largest tribes -- Mongo, Luba, Kongo (all Bantu), and the Mangbetu-Azande
(Hamitic) make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo, and Chiluba are all
classified as official languages
Literacy: 5% fluent in French, about 35% have an acquaintance with French
Labor force: about 8 million, but only about 13% in wage structure
288,000 sq. mi.; 5% under cultivation, 5% arable, 10%
Approved For Release 2004/08/44, 5 GIA-RDP79-01051A000400010002-1
grazing, 13% dense forest, 6% marsh, 61% scattered
trees and grassland (1970)
Land boundaries: 3,730 mi.
Population: 4,294,000, average annual growth rate 2.4%
(May 63-August 69); males 15-49, 996,000; 480,000
fit for military service
Ethnic divisions: 98.7% African, 1.1% European, .2% other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous languages
Literacy: 28%
Labor force: 372,000 wage earners; 345,000 Africans, 27,000 non-Africans;
15% mining, 9% agriculture, 9% domestic service, 19%
construction, 9% commerce, 10% manufacturing, 23% government and miscellaneous
services, 6% transport
Organized labor: 100,000 wage earners, primarily in industrial sector, are
unionized (early 1968)
Population: 208,206,000, average annual growth rate 1.1% (current)
%, Ethnic divisions: population basically of West European extraction, modified
by subsequent waves of immigration
Religion: total membership in religious bodies, 128,470,000; Protestant
69,424,000, Roman Catholic 47,873,000, Jewish 5,780,000, other religions
5,393,000
Language: English, predominantly
Literacy: almost complete
Labor force: about 82 million
Organized labor: 28.8% of total','be96bda077eb0cd18540945b9f3cd5459a3a25533741239d079a3ad84c790bf3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44929c39e31bf2d14fb62a104df9f015022ad9492a8802beb7c0419b6db0222b',1971,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
_ Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Fahri Koruturk, Prime Minister Naim Talu
Suffrage: universal over age 21
mar erhse National Assembly and Senate (1/3 of seats) (October 1973); Presidential
1980
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
Peopic''s Party (RPP), Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Repiblican Reliance Party (RRP), Turhan Feyzioglu; National Action Party
(NAP), Alparslan Turkes; Nation Party (NP), Osman Bolukbasi; Unity Party (UP),
Mustafa Timisi; Communist Party 1]]lega]
Communists: strength and support negligible
Other political or pressure groups: military forced resignation of Demirel
government in March 1971 and remains an influential force in government
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECD, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO
345
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998','ab13b7d52498cd92944d61b57e729cf5486b777d25f34bb9dbaa98cdf50e7cd0','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7169b8153c660abdc385c37fa016f63ad6baa35f3140959d8dfe55d5131abba9',1971,'UY','Uruguay','government',5,'Legal name: Republic of Turkey
210
Type: republic
‘Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal
systems; constitution adopted 1961; judicial review of
legislative acts by Constitutional Court; legal education at
Universities of Ankara and Istanbul; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Republic Day, 29 October
Branches: President elected by parliament; Prime Minis-
ter appointed by President from members of parliament;
Prime Minister is effective executive; cabinet, selected by
Prime Minister and approved by President, must command
majority support in lower house; parliament bicameral
under constitution promulgated in 1961; National Assembly
has 450 members serving 4 years; Senate has 150 elected
- members, one-third elected every 2 years, 15 appointed by
the President to 6-year terms (one-third appointed every 2
years), and 19 life members; highest court for ordinary
criminal and civil cases is Court of Cassation, which hears
appeals directly from criminal, commercial, basic, and peace
courts
- Government leaders: President Fahri Koruturk, Prime
Minister Bulent Ecevit
Suffrage: universal over age 21
Elections: National Assembly and Senate (1/3 of seats),
Republican People’s Party won a plurality in June 1977,
Presidential (1980)
Political parties and leaders: Justice Party (JP),
Suleyman Demirel; Republican People’s Party (RPP), Bulent
Ecevit; National Salvation Party (NSP), Necmettin Erbakan;
Democratic Party (DP), Ferruh Bozbeyli; Republican
Reliance Party (RRP), Turhan Feyzioglu; Nationalist Action
Party (NAP), Alpaslan Turkes; Unity Party (UP), Mustafa
Timisi; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced
resignation of Demirel government in March 1971 and
remains an influential force in national affairs
Member of: ASSIMER, CENTO, Council of Europe, EC
(associate member), ECOSOC, FAO, GATT, IAEA, IBRD,
ICAC, ICAO, IDA, IEA, IFC, IHO, ILO, IMCO, IMF,
1O0C, IPU, ITC, ITU, NATO, OECD, Regional Coopera-
tion for Development, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG, WTO','41fba0988e8c7d82b7162fa89ea52dde1c9f7a425df0650d26b34f629e768764','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92b2a61aef5824db06dbafff9cf50255b6e540f2bc2897e6887bd2d0e716b22b',1971,'TV','Tuvalu','government',10,'Legal name: Tuvalu
Type: independent state within commonwealth
Capital: Funafuti .
House of Assembly: eight members
Government leader: Prime Minister Toalipi Lauti','819e66a045ff3d1eecf365ac3f3e9f61688709035be878b92e320ed52bed0b56','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('489ef2fb4473bbe83a9bc04f8128b2b388fdbf84214b234a2f8008158475cb6c',1971,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and ci vil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts :
Government leaders: President Fahri Koruturk, Prime Minister Naim Talu
Suffrage: universal over age 21
ey ais National Assembly and Senate (1/3 of seats) (October 1973); Presidential
0
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party (RPP), Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Republican Reliance Party (RRP), Turhan Feyzioglu; National Action Party
(NAP), Alparslan Turkes; Nation Party (NP), Osman Bolukbasi; Unity Party (UP),
Mustafa Timisi; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced resignation of Demirel
government in March 1971 and remains an influenti a? force in government
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO. IMCO, IMF, ITU, NATO, OECD, Regional
rather has Development, Seabeds Committee (observer), U.N., UNESCO,
447
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
Sere','49099b5e9c45b3b5d46175efa1d3065c75b0f852d14bdef354a8a20e1a861556','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('705c559e9e03bcda4e4f660e03c344c996d45dc91bbec320a5f25a1ed12dac94',1971,'TH','Thailand','government',4,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal
systems; constitution adopted 1961; judicial review of
legislative acts by Constitutional Court; legal education at
Universities of Ankara and Istanbul; accepts compulsory IC]
jurisdiction, with reservations
National holiday: Republic Day, 29 October
Branches: President elected by parliament; Prime Minis-
ter appointed by President from members of parliament;
Prime Minister is effective executive; cabinet, selected by
Prime Minister and approved by President, must command
majority support in lower house; parliament bicameral
under constitution promulgated in 1961; National Assembly
has 450 members serving 4 years; Senate has 150 elected
members, one-third elected every 2 years, 15 appointed by
the President to 6-year terms (one-third appointed every 2
years), and 19 life members; highest court for ordinary
criminal and civil cases is Court of Cassation, which hears
appeals directly from criminal, commercial, basic, and peace
courts
Government leaders: President Fahri Koruturk; Prime
Minister Bulent Ecevit
Suffrage: universal over age 2]
Elections: National Assembly and Senate (1/3 of seats),
Republican People’s Party won a plurality in June 1977;
Presidential (1980)
Political parties and leaders: Justice Party (JP),
Suleyman Demirel; Republican People’s Party (RPP), Bulent
Ecevit; National Salvation Party (NSP), Necmettin Erbakan;
Democratic Party (DP), Faruk Sukan; Republican Reliance
Party (RRP), Turhan Feyzioglu; Nationalist Action Party
(NAP), Alpaslan Turkes; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced
resignation of Demirel government-in March 1971 and -
remains an influential force in national affairs
Member of: ASSIMER, Council of Europe, EC (associate
member), ECOSOC, FAO, GATT, IAEA, IBRD, ICAC,
ICAO, IDA, IEA, IFC, IHO, ILO, IMCO, IMF, IOOC, IPU,
ITC, ITU, NATO, OECD, Regional’ Cooperation for
Development, U.N., UNESCO, UPU, WHO, WIPO, WMO,
WSG, WTO','ee13dc06ddd6e05c7c25be75fec842843c31b043d0bef5dd2fc66a050603ff16','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b767dee9e9922bddcd0dbb230416e13564611c016e66760f0bf7871398713cec',1971,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Cevdet Sunay, Acting Prime Minister Ferit Melen
Suffrage: universal over age 21
Elections: National Assembly (1973); Presidential (1973)
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party eh Bulent Ecevit; Democrats Party (DP), Ferruh Bozbeyli;
Reliance Party (RP), Turhan Feyziogiu; New Turkey Party (NIP), Yusuf Azizoglu;
Nationalist Movement Party (NMP), Alparslan Turkes; Nation Party (NP), Osman
Bolukbas{; Unity Party (UP), Mustafa Timisi; Republican Party (RP), Kemal
Satir (formed in 1972); Communist Party illegal
Voting strength: 1969 National Assembly elections -- 46.6% JP, 27.5% RPP, 3.3%
NP, 2.2% NTP, 2.6% TLP, 5.7% independent, 6.4% RP, 3.1% NMP, 2.5% UP; 1968
Senatorial elections (1/3 of Senate seats) -- 49.9% JP, 27.1% RPP, 6.0% NP,
8.5% Reliance Party, 4.7% TLP, 2.0% RPNP
Communists: strength and support negligible
Other political or pressure groups: military overthrew government in 1960, forced
resignation of Demirel government in March 1971 and remains the dominant
force behind the new government
437
SECRER-
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
“SECRET.
GOVERNMENT (cont''d):
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECO, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO','f4f1ddb6b130a5df944f2a48ea3a62bd2ed409297de9eded809ce7b08c85e07a','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8b64cfcd4be958634dbebdb6c81361ea4e09d941a654d07e8a0d274cb98efb7',1971,'','','government',3,'Legal name: Kingdom of Afghanistan
Type: constitutional monarchy
Capital: Kabul
Political subdivisions: 28 provinces with centrally appointed governors
Legal system: based on Islamic law; constitution adopted 1964; although provided
for in the law on judicial organization, there has as yet been no judicial
review of legislative acts; legal education at University of Kabul; has not
accepted compulsory ICJ jurisdiction
Branches: bicameral legislature with cabinet responsible to lower house
(People''s Council); although elected Parliament is exerting increasing
influence, it has not as yet established effective control over the
centralized administration and has no real voice in military matters;
progressive forces led by King liberalizing the regime; independent
judiciary established in October 1967, has not yet had a major institutional
impact; it is too early to assess its future role
Government leaders: King Mohammad Zahir Shah; Prime Minister Nur Ahmad Etemadi
Suffrage: universal over age 20
Elections: first free nationwide direct elections by secret ballot and universal
suffrage (under 1964 Constitution) held for Parliament September 1965; second
elections held August and September 1969; lower house of Parliament (216
deputies) and third of upper house (Council of Elders -- 28 Senators)
elected for 4-year terms; 28 Senators appointed by King; remaining 28
Senators to be elected by Provincial Councils when formed
Political parties and leaders: no political parties permitted yet, but enabling
legislation has been passed by Parliament and awaits the King''s signature;
several groups have begun to meet informally, extremists of left and right
best organized
Communists: there are 2 nascent Communist groups which are ideologically
pro-Soviet; size is reported to be about 350-500 active members; several
other far leftist groups with a total of 225-250 members and sympathizers
Other political or pressure groups: progressive forces led by King Zahir and
cabinet dominate current situation with nascent leftist and rightist groups
forming for action when parties are permitted
1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GOVERNMENT (cont''d):
Member of: ADB, Colombo Plan, FAO, FUND, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO,
ITU, U.N., UNESCO, UPU, WHO, WMO
Legal name: People''s Republic of Albania
Type: Communist state
Capital: Tirana
Political subdivisons: 27 rethet (districts), including capital, 200 localities,
2,600 villages
Legal system: based on Soviet law; constitution adopted 1950; judicial review
of legislative acts only in the Presidium of the People''s Assembly, which
js not a true court; legal education at State University of Tirana; has not
accepted compulsory ICJ jurisdiction
Branches: People''s Assembly, Council of Ministers, judiciary
Government leaders: President, Presidium of the People''s Assembly, Haxhi Lleshi;
Chairman of Ministers, Mehmet Shehu
Suffrage: universal and compulsory over age 18
Elections: national elections theoretically held every 4 years; last elections
September 1970
Political parties and leaders: Albanian Workers Party only; First Secretary,
Enver Hoxha
Voting strength (1970 election); 99.9% Communist
Communists: 75,637 (1970)
Member of: CEMA, IAEA, ITU, U.N., UNESCO, UPU, WHO, WMO; has not participated
in CEMA since rift with U.S.S.R. in 1961; officially withdrew from Warsaw
Pact 13 September 1968
Legal name: Democratic and Popular Republic of Algeria
Type: republic
Capital: Algiers
Political subdivisions: 15 Wilayas (departments or provinces)
Legal system: based on French and Islamic law, with socialist principles;
constitution adopted by referendum 1963; judicial review of legislative acts
in ad hoc Constitutional Council composed of various public officials,
including several Supreme Court justices; Supreme Court divided into 4
chambers; legal education at University of Algiers; has not accepted
compulsory ICJ jurisdiction
* Branches: executive dominant, unicameral legislature has not met since June
1965 coup d''etat but was never formally suspended, judiciary
Government leader: Houari Boumediene, President of Council of the Revolution
and President of the Council of Ministers, overthrew elected President
Ahmed Ben Bella 19 June 1965
Suffrage: universal over age 19
Elections: presidential 15 September 1963; departmental assemblies 25 May 1969;
local councils 5 February 1967
Political parties and leaders: National Liberation Front (FLN), Ahmed Kaid
Voting strength (1963 election): 100% FLN
Communists: 750; Communist Party illegal (banned 1962)
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, ILO, IMCO, IMF, ITU, OAU,
OPEC, U.N., UNESCO, UPU, WHO
Legal name: The Valleys of Andorra
Capital: Andorra la Vella
Political subdivisions: 6 districts -- Andorra la Vella, Sant Julia de Loria,
Encamp, Canillo, La Massana, and Ordino
Type: unique coprincipality under formal sovereignty of President of France and
Spanish Bishop of Lerida, who are represented by veguers
Legal system: based on French and Spanish civil codes; Plan of Reform adopted
1866 serves as constitution; no judicial review of legislative acts; has
not accepted compulsory ICJ jurisdiction
Branches: legislature (General Council) of 24 members with one-half elected
every 2 years for 4-year term; executive -- syndic and a deputy sub-syndic
chosen by General Council for 3-year terms; judiciary chosen by coprinces
who appoint 2 civil judges, a judge of appeals, and 2 Batles (court
prosecutors)
Suffrage: males of 25 or over who are third generation Andorrans vote for
General Council members; same right granted to women in April 1970
Elections: half of General Council chosen every 2 years
Political parties and leaders: generally 2 main factions in the General Council
Voting strength: traditional conservatives won easily in election of 12
December 1967
Legal name: Province of Angola
Type: overseas province of Portugal
Capital: Luanda
Political subdivisions: 15 administrative districts including the coastal
exclave of Cabinda
Legal system: Portuguese civil codes and customary law; legal education
obtained in Portugal
Branches: Governor General appointed by Ministry of Overseas in Lisbon is
executive officer responsible for internal administration; he also has
prescribed legislative functions which he shares with Legislative Council
of elected and nominated members; al] action in province may be vetoed by
Minister of Overseas; independent judiciary
Government leader: Governor General Lt. Col. Camilo Rebocho Vaz
Suffrage: all adults able to read and write Portuguese and in full possession
of political and civil rights
Political parties and leaders: only legal group is Portuguese National Popular
Action (ANP), formerly the National Union (UN)
Other political or pressure groups: principal opposition groups which are
carrying out insurgency are Angola People''s Union (UPA), led by Holden
Roberto; Popular Movement for the Liberation of Angola (MPLA), led by
Agostinho Neto; and National Union for the Total Independence of Angola
(UNITA), led by Jonas Savimbi
Legal name: Associated State of Antigua
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: St. John''s
Political subdivisions: 6 parishes, 2 dependencies (Barbuda, Redonda)
Legal system: based on English law; British Caribbean Court of Appeal has
exclusive original jurisdiction and an appellate jurisdiction, consists of
Chief Justice and 5 justices
Government leaders: Premier George Herbert Walter; Governor Wilfred Ebenezer Jacobs
Suffrage: universal adult suffrage
Elections: every 5 years; last general election 11 February 1971; last by-election
August 1968
Political parties and leaders: Antigua Labor Party (ALP), Vere C. Bird;
Progressive Labor Movement (PL) , George Herbert Walter;
Antigua People''s Party (APP), J. Rowan Henry
Voting strength: 1971 election -- Legislative Council seats -- ALP 4, PLM 13,
other 4 unknown
Communists: none known
Member of: CARIFTA
Legal name: Argentine Republic
Type: republic; military regime in control since coup in June 1966
Capital: Buenos Aires
Political subdivisions: 22 provinces, 1 district (Federal Capital), and 1
territory
Legal system: based on Spanish and French civil codes; constitution adopted
1853 partially superseded in 1966 by the Statute of the Revolution which
takes precedence over the constitution when the two are in conflict;
judicial review of legislative acts; legal education at University of
Buenos Aires and other public and private universities; has not accepted
compulsory ICJ jurisdiction
Branches: presidency; national judiciary; legislature dismissed after June
1966 coup
Government leader: Gen. Alesandro Lanusse, President until 1 January 1973, when
the Air Force member of the 3-man junta, that removed Brig. Gen. Roberto
Levingston on 23 March 1971, is scheduled to replace him
Suffrage: universal and compulsory age 18 and over
Elections: present government has announced plans for holding elections
by April 1974
Political parties: ban imposed in 1966 now lifted and parties in process of
reorganizing
Voting strength: the old political groupings probably continue to
command the loyalty of the populace according to the following figures
(est.) -- Peronists (of all types), 35%; Radicals (former People''s Radical
Civic Union, UCRP), 25%; Conservatives (former National Federation of
Centrist Parties), 5%; minor parties, 10%; nonaligned, 25%
Other political or pressure groups: Argentine armed forces, Peronist-dominated
labor movement, The Hour of the People (loose grouping of moderate politicians
with various party affiliations), National Meeting of the Argentines (loose
grouping of communist and leftist politicians), Argentine Industrial Union
(manufacturers! association), Argentine Rural Society (large landowners''
association), business organizations, students, and the Catholic Church
Member of: FAO, IADB, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, LAFTA,
OAS, U.N., UNESCO, UPU, WHO, WMO
13
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2','69cdc0700ad91ea20f99bfb7a06de755dac47f9da94d4bf455d95588361e0d16','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d156d704a26393e48419cbf87bd3dab12ba7a13c814636279931679bd4cd910',1971,'DZ','Algeria','government',6,'Legal name: Republic of Austria
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states (Laender) including the capital
Legal system: civil law system with Roman law origin; constitution adopted 1920,
repromulgated in 1945; judicial review of legislative acts by a Constitutional
Court; separate administrative and civil/penal supreme courts; legal education
at Universities of Vienna, Graz, Innsbruck, Salzburg, and Linz; has not
accepted compulsory [CJ jurisdiction
Branches: bicameral Parliament, directly elected President whose functions are
largely representational, independent federal judiciary
Government leaders: Chancellor Bruno Kreisky; President Franz Jonas
Suffrage: universal over age 19; compulsory for presidential elections
Elections: presidential, every 6 years (next 1971); parliamentary, every 4
years (next 1974)
Political parties and leaders: Socialist Party of Austria (SPOe), Bruno Kreisky,
Chairman; Austrian People''s Party (OeVP), Herman Withalm, Chairman; Liberal
Party (FPOe), Friedrich Peter, Chairman; Communist Party, Franz Muhri,
Chairman
Voting strength (1970 election): 48.4% SPOe, 44.7% OeVP, 5.4% FPOe, 0.4% dissident
Socialist, 1% Communist
Communists: membership 26,000; activists 7,000-8,000; 46,700 votes in 1970 election
Member of: Council of Europe, ECE, EFTA, IAEA, ICAO, OECD, U.N., UNESCO, WHO
Legal name: Colony of the Bahamas
Type: British dependent territory with full internal autonomy under U.K. rule
Capital: Nassau (New Providence Island)
Legal system: based on English law
Branches: Governor (appointed by Queen); bicameral legislature (appointed
Senate, elected House); Executive (Premier and cabinet); judiciary
Government leaders: Prime Minister Lynden 0. Pindling; Governor Sir Francis
Cumming-Bruce
Elections: House of Assembly (10 April 1968); next elections must be held by
10 April 1973
Political parties and leaders: Progressive Liberal Party (PLP), predominantly
Negro, Lynden 0. Pindling; National Democratic Party (NDP), Paul L.
Adderley; United Bahamian Party (UBP), white establishment, Sir Roland
Symonette; Commonwealth Labor Party (CLP), M.H.A. Fawkes (opposition party);
Free Progressive Liberal Party (Free PLP), Cecil Wallace Whitefield
Voting strength (1968 election): 73% PLP, 27% UBP; House of Assembly -- PLP
29 seats, UBP 7 seats, LP 1 seat, independent 1 seat
Communists: none known
Legal name: Sheikhdom of Bahrain
Type: ruled by Khalifah family with a special treaty relationship whereby U.K.
conducts all foreign relations; control point for British political com-
mitments in Persian Gulf through British Political Resident; British-
officered police force protects U.K. interests
Capital: Manama
Legal system: based on Islamic law and English common law
Government leader: Sheikh ''Isa ibn Salman Al~Khalifah
Political parties and pressure groups: various Arab nationalist movements ;
most important -- National Liberation Front (Communist aligned)
Communists: few known
Legal name: Barbados
Type: independent state since November 1966, recognizing Elizabeth II as chief
of state
Capital: Bridgetown
Regional breakdown: 1] parishes administered by 3 district councils
Legal system: English common law; constitution came into effect upon
independence in 1966; no judicial review of legislative acts; has not
accepted compulsory ICJ jurisdiction
Branches: legislature consisting of a 2l-member appointed Senate and a
24-member elected House of Assembly; cabinet headed by Prime Minister
Government leader: Prime Minister Errol Barrow
Suffrage: universal over age 18
Elections: House of Assembly members have terms no longer than 5 years;
general election held 3 November 1966
Political parties and leaders: Democratic Labor Party (DLP), Errol Barrow;
Barbados National Party (BNP), Ernest D. Mottley; Barbados Labor Party
(BLP), H. Bernard St. John, J. M. G. "Tom" Adams
Voting strength (1966 election): Democratic Labor Party (DLP), 49.5%; Barbados
National Party, 10.1%; Barbados Labor Party, 32.7%; Independent, 7.7%;
House of Assembly seats -- DLP 14, BLP 9, BNP 1
Communists: not significant
Other political or pressure groups: People''s Progressive Movement (PPM), a
small pro-Castro black-nationalist group led by Calvin Alleyne
Member of: CARIFTA, Commonwealth, ICAO, IMF, OAS, U.N.
Legal name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: 9 provinces
Legal system: civil law system influenced by English constitutional theory;
constitution adopted 1831, since amended; judicial review of legislative
acts; legal education at 4 law schools; accepts compulsory ICJ jurisdiction,
_ With reservations
Branches: executive branch consists of King and cabinet; cabinet responsible to
bicameral parliament; independent judiciary; coalition governments are usual
Government leader: Prime Minister Gaston Eyskens
Suffrage: universal over age 2]
Elections: must be held at least every 4 years (last March 1968)
Political parties and leaders: Social Christian, Senator Robert Houben, party
president; Socialist, Edmund LeBurton and Joris Van Eynde, co-presidents;
Liberty and Progress, Senator P. Descamps, party president; Francophone
Democratic Front-Walloon Rally (Walloon nationalist), Jean Duvieusart,
party president; Volksunie (Flemish Nationalist), Wim Jorrisen, party
president; Communist, Marc Drumeaux, president of political bureau
Voting strength (1968 election): 31.7% Social Christian, 28.0% Socialist, 3.3%
Communist, 20.9% Liberty and Progress, 9.8% Volksunie, 6.6% other
v Communists: 12,160; splinter parties (Chinese-oriented) 400; 170,700 votes in
1968 election
Member of: Benelux, BLEU (Belgium-Luxembourg Economic Union), Council of Europe,
ECE, ECSC, ECOSOC, EEC, EMA, EURATOM, FAO, TAEA, ICAO, IMF, NATO, OECD, U.N.,
UNESCO, WEU, WHO
Patil ECONOMY :
GNP: $22.5 billion (1970 est.), $2,630 per capita (1970 est.), 64% consumption,
22% investment, 13% government, 1% net exports of goods and services;
1970 growth rate 5.5%, 1963 constant prices
Agriculture: livestock production predominates; main crops -- grains, beets,
potatoes; 80% self-sufficient in food; food shortages -- edible and coarse
rains, fats and oils; caloric intake, 3,150 calories per day per capita
(1967-68 est.)
Major industries: engineering and metal products, processed food and beverages,
chemicals, basic metals, textiles, and petroleum
25
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Shortages: iron ore, nonferrous minerals, petroleum, cotton, wool, wood
Crude steel: capacity 14.3 million metric tons (1969); 12.8 million metric tons
produced (1969); 1,330 kilograms per capita
Electric power: 6,855,000 kw. capacity (1970); 29,306 million kw.-hr. produced :
(1970); 2,910 kw.-hr. per capita :
Exports: $11,600 million (f.o.b., 1970) motor vehicles, refined copper, iron and =
steel products, finished or semifinished precious stones, textile products
Imports: $11,350 million (c.i.f., 1970) crude materials, food, fuels, automotive q
parts, nonelectrical machinery and appliances, clothing
Major trade partners: (Belgium-Luxembourg Economic Union, 1969) West Germany
22.8%, Netherlands 19.3%, France 20.9%, U.S. 6.9%, U.K. 4.0%, Italy 4.22;
EEC 64.5%, EFTA 11.3%, Communist countries 1.6% :
Aid: E
economic -- received - U.S., $751.6 million authorized (FY46-69); none e
since FY69;
military -- received - $1,253.6 million authorized (FY46-69), $1.9 million
in FY68, none since FY68; net official economic aid to less developed areas
and multilateral agencies -- $884 million (FY60-69), $116 million in 1969
Monetary conversion rate: 50 francs=US$1 (official rate)
Fiscal year: calendar year
Legal name: Colony of Bermuda
Type: British crown colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English law
Branches: elected House of Assembly; appointed Legislative Council; Executive
Council (cabinet)
Government leaders: Governor Lord Martonmere; Prime Minister Sir Henry Tucker
Suffrage: universal over age 21; compulsory
Elections: at least once every 5 years; last general election, May 1968
Political parties and leaders: United Bermuda Party (UBP), Sir Henry Tucker;
Progressive Labor Party (PLP), Lois Browne-Evans (PLP parliamentary
leader); Bermuda Democratic Labor Party (BDP), Arnold A. Francis,
Charles W. Mayne
Voting strength (1968 elections): UBP 56.5%, PLP 34.4%, BDP 6.7%, Independents
2.4%; House of Assembly seats -- UBP 30, PLP 10
Legal name: Kingdom of Bhutan
Type: monarchy; special treaty relationship with India
Capital: Thimphu
Political subdivisions: 4 regions (east, central, west, south), further
divided into 15-18 subdivisions
Legal system: based on Indian law and English common law; in 1964 the
King assumed full power -- no constitution existed beforehand; a supreme
court hears appeals from district administrators; has not accepted
compulsory ICJ jurisdiction
Branches: appointed minister and indirectly elected assembly consisting of
village elders, monastic representatives , and all district and senior
government administrators
Government leader: King Jigme Dorji Wangchuck
Suffrage: each family has one vote
Elections: popular elections on village level held every 3 years
Political parties: all parties illegal; some indications of rapproachement
between King and Bhutan Congress Party which operates from Nepal and India
Communist: no overt Communist presence
Other political or pressure groups: Buddhist clergy
Member of: Colombo Plan, UPU
Legal name: Republic of Bolivia
Type: republic; government under military control since September 1969
Capital: La Paz (seat of government); Sucre (judicial capital)
Political subdivisions: 9 departments with limited autonomy
Legal system: based on Spanish law and Code Napoleon; constitution adopted 1967;
constitution in force except where contrary to the revolutionary mandate of
the armed forces and to the dispositions dictated by the revolutionary
government; judicial review of legislative acts in the Supreme Court; legal
education at University of San Andres and several others; has not accepted
compulsory ICd jurisdiction
Branches: executive; congress of two chambers (Senate and Chamber of Deputies),
congress disbanded after 26 September 1969 ouster of President Siles;
judiciary
Government leaders: President Juan Jose Torres Gonzalez
Suffrage: universal and compulsory at age 18 if married, 21 if single
Elections: none scheduled
Political parties and leaders: at least 20 political parties, relatively inactive;
the most important are: Movimiento Popular Cristiano (MPC) Hugo Bozo Alcocer;
Partido Revolucionario Autentico (PRA) Walter Guevara Arze; Partido de la
Izquierda Revolucionaria (PIR) Ricardo Anaya Arze; Partido Social Democratica
(PSD) Hugo Sandoval Saavedra; Falange Socialista Boliviana (FSB) divided into
several factions, one led by Mario Gutierrez Gutierrez and another led by
Juan Jose Loria; Partido Revolucionario de Izquierda Nacionalista (PRIN) Juan
Lechin Oquendo; Movimiento Nacionalista Revolucionario (MNR) Victor Paz
Estenssoro (in exile); Partido Democrata Cristiano (PDC) and Remodi Natale
Benjamin Miguel
Voting strength (1966 elections): Frente de la Revolucion Boliviana (a coalition
composed of the MPC, PIR, PRA, PSD, and two interest groups, the campesinos
and Chaco War Veterans) 61%, FSB 12%, MNR 10%, other 17%
Member of: IAEA, IADB, ICAO, LAFTA and Andean Sub-Regional Group (created in
May 1969 within LAFTA), OAS, U.N.
Legal name: Republic of Botswana
Type: republic since independence in September 1966
Capital: Gaberone
Political subdivisions: 12 administrative districts
Legal system: based on English common law and local customary law; constitution
came into effect 1966; judicial review limited to matters of interpretation;
legal education at University of Botswana, Lesotho and Swaziland (located
in Lesotho); has not accepted compulsory ICJ jurisdiction
Branches: executive -- President appoints and is the chief minister in the
cabinet which is responsible to Legislative Assembly; legislative --
Legislative Assembly with 31 popularly elected members and 4 members elected
by the 31 representatives, House of Chiefs with deliberative powers only;
judicial -- African courts administer customary law, High Court and
subordinate courts have criminal jurisdiction over all residents, Court of
Appeal has appellate jurisdiction
Government leader: President Seretse Khama
Suffrage: universal for adults
Elections: general elections held 18 October 1969
Political parties and leaders: Botswana Democratic Party (BDP), Seretse Khama;
Bechuanaland People''s Party (BPP), P.G. Matante; Botswana Independence
Party (BIP), Motsamai Mpho; Botswana National Front (BNF), Kenneth Koma
Voting strength: (October 1969 election) 68% BDP (24 seats); 13.5% BPP (3 seats);
12% BNF (3 seats); 6% BIP (1 seat)
Communists: no known Communist organization; Koma of BNF has long history of
Communist contacts
Member of: Commonwealth, FAO, OAU, U.N., WMO
Legal name: Federative Republic of Brazil
Type: federal republic; military-backed presidential regime since April 1964
Capital: Brasilia
Political subdivisions: 22 states, 4 territories, federal district (Brasilia)
Legal system: based on Latin codes; dual system of courts, state and federal;
constitution adopted 1967 and extensively amended in 1969; has not accepted
compulsory ICJ jurisdiction
Branches: strong executive with very broad powers; bicameral legislature
(powers of the two bodies have been sharply reduced); 11-man Supreme Court
Government leader: President Emilio Garrastazu Medici
Suffrage: compulsory over age 18, except illiterates and those stripped of their
political rights; approximately 30 million registered voters in October 1970
Elections: President Medici''s successor will be chosen on 15 January 1974 and
will take office in March
Political parties and leaders: National Renewal Alliance (ARENA), pro-government;
Brazilian Democratic Movement (MDB), opposition
Communists: less than 13,000; 100,000 sympathizers (est.)
Member of: FAQ, GATT, IADB, IAEA, IBRD, ICAO, IHB, ILO, IMCO, IMF, ITU, LAFTA,
OAS, U.N., UNESCO, UPU, WHO, WMO
Legal name: Colony of British Honduras
Type: British crown colony; obtained full internal self-government in January
1964
Capital: Belize City; seat of government in Belmopan
Legal system: English law; constitution came into force in 1964, although
country remains a British colony
Branches: 18-member elected National Assembly and 8-member Senate (either house
may choose its speaker or president, respectively, from outside its
elected membership); cabinet; judiciary
Government leader: Premier George Price
Suffrage: universal adult
Elections: within 5 years of last election held 5 December 1969
Political parties and leaders: People''s United Party (PUP), George Price;
National Independence Party (NIP), Philip Goldson; People''s Development
Movement (PDM), Dean Lindo
Voting strength (1969 election): 57.6% PUP, 39.8% NIP, 2.6% void ballots
Communists: none identified
Other political or pressure groups: Christian Workers'' Union (CWU) which is
Sug with PUP; United Black Association for Development (UBAD),
van Hyde
Legal name: State of Brunei
Type: British protectorate; constitutional sultanate
Capital: Bandar Sei Begawan
Political subdivisions: 4 administrative districts
Legal system: based on Islamic Jaw; constitution promulgated by the Sultan in
1959, though Brunei remains British protectorate; scheduled to become
independent in late 1970
Branches: chief of state is Sultan (advised by appointed Privy Council) who
appoints Executive Council and majority of Legislative Council
Government leader: Sultan Hassanal Bolkiah
Suffrage: universal age 21 and over; 3-tiered system of indirect elections;
popular vote cast for lowest level (district councilors)
Elections: last elections -- March 1965
Political parties and leaders: antigovernment People''s Independence Front
(Baker), Pengiran Dato Ali, chairman
Voting strength (1965 election): 6 of 10 elective seats won by defunct
antigovernment Partai Ra''ayat members
Legal name: People''s Republic of Bulgaria
Type: Communist state
Capital: Sofia
Political subdivisions: 28 okrugs (districts), including capital city of Sofia
Legal system: based on civil law system, with Soviet law influence; constitution
adopted 1947; new constitution to be voted in 1971; judicial review of
legislative acts in the Presidium; legal education at University of Sofia;
has not accepted compulsory ICJ jurisdiction
Branches: legislative (National Assembly), Council of Ministers, judiciary
Government leaders: Premier Todor Zhivkov; Georgi Traykov, Chairman, National
Assembly Presidium (chief of state)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every 4 years for National Assembly; last elections
held on 27 February 1966; 99.6% of the electorate voted
Political parties and leaders: Bulgarian Communist Party, Todor Zhivkov, First
Secretary; Bulgarian National Agrarian Union, a puppet party, Georgi Traykov,
secretary
Communists: 637,000 full members (April 1970)
Mass organizations and front groups: Fatherland Front, Dimitrov Communist Youth
League, Central Council of Trade Unions, National Committee for Defense of
Peace, Union of Fighters Against Fascism and Capitalism, Committee of
Bulgarian Women, All-National Committee for Bulgarian-Soviet Friendship
Member of: CEMA, GATT, IAEA, ICAO, ILO, IMCO, ITU, U.N., UNESCO, UPU, WHO,
WMO, Warsaw Pact, International Organization of Journalists, International
Medical Association, International Radio and Television Organization
Legal name: Republic of Burundi ;
Type: republic; military government since November 1966; no constitution
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into 18 arrondissements and 78
communes
Legal system: based on German and French civil codes and customary law; has not
accepted compulsory [CJ jurisdiction
Branches: presidential cabinet with Council of Ministers; no legislature
Government leader: President Michel Micombero
Elections: latest legislative election May 1965
Political parties and leaders: National Party of Unity and Progress (UPRONA),
a predominantly Tutsi party, is only legitimate party; other parties, mostly
Hutu, since 1961 have been subverted, suppressed, intimidated by UPRONA, and
have ceased to exist
Voting strength (1965 elections): UPRONA won 21 of 33 Assembly seats; Hutu-
dominated People''s Party won 10
Communists: no Communist party, but some members of the Tutsi ruling group favor
close ties with Communist China, whose ambassador was expelled from the
country in 1965; U.S.S.R. and North Korea have diplomatic missions in Burundi
Member of: EAMA, ECA, IBRD, ICAO, ILO, IMO, OAU, U.N., UNESCO, WHO, WMO
Legal name: Government of the Khmer Republic
Type: constitution being revised to support presidential parliamentary system
Capital: Phnom Penh :
Political subdivisions: 20 provinces with centrally appointed governors,
3 independent municipalities
Legal system: based on French civil law system; constitution adopted 1947 and
amended 1960; no judicial review of legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
Branches: bicameral legislature; upper house -- Senate; lower house -- National
Assembly; Prime Minister Lon Nol theoretically responsible to lower house
Government leader: chief of state, Cheng Heng
Suffrage: universal over age 20
Elections: held every 4 years; parliamentary reelections postponed until 197]
Political parties and leaders: none
Communists: party strength unknown
Member of: ADB, Colombo Plan, IAEA, IBRD pending, ICAO, IMF pending, U.N., WMO
Legal name: Federal Republic of Cameroon
Type: federal republic; one-party presidential regime
Capital: Yaounde
Political subdivisions: East Cameroon and West Cameroon make up two parts of
federation, divided into 9 divisions (West), 30 departments (East),
6 administrative regions
Legal system: based on French civil law system, with common law influence;
constitution adopted 1961; judicial review in Federal Court of Justice, when
a question of constitutionality is referred to it by the President of the
Republic; has not accepted compulsory ICJ jurisdiction
Branches: federal -- executive, legislative, judicial; East Cameroon and West
Cameroon each has own government as well
Government leader: President Ahmadou Ahidjo
Suffrage: universal over age 21
Elections: presidential elections held 28 March 1970; federal parliamentary
elections last held 7 June 1970
Political parties and leaders: single party, Cameroonian Nation Union (UNC),
President Ahmadou Ahidjo
Voting strength: (1970 elections - 98% in presidential; 94% in parliamentary
Communists: no Communist Party or significant sympathizers
Other political or pressure groups: Cameroon People''s Union (UPC), illegal exile
group which has engaged in guerrilla warfare in the past and continues to
carry out sporadic terror against the government
Member of: African Development Bank, EAMA, FAO, GATT, IAEA, IBRD, ICAO, ILO,
IMCO, IMF, ITU, Lake Chad Basin Commission, OAU, UDEAC, U.N., UNESCO, UPU,
WHO, WMO
Legal name: Central African Republic
Type: republic; constitution abrogated following military coup in January 1966
Capital: Bangui
Political subdivisions: 14 prefectures, 47 subprefectures
Legal system: based on French, Islamic, and tribal law; in 1966 the Chief of
State assumed all power and abrogated the existing constitution; has not
accepted compulsory ICJ jurisdiction
Branches: Gen. Bokassa heads government and rules by decree; assisted by
cabinet called Council of Ministers; judiciary, including Supreme Court,
court of appeals, criminal. court, and numerous lower courts
Government leader: President Jean-Bedel Bokassa
Suffrage: universal over age 21
Elections: none have been held under Bokassa regime
Political parties and leaders: Black African Social Evolution Movement (MESAN),
ruling party under former regime, still in existence but plays little role,
President Jean-Bedel Bokassa
Communists: no Communist Party or significant number of sympathizers
Member of: EAMA, FAO, GATT, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM, UDEAC, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Dominion of Ceylon (rarely used)
Type: independent state since 1948; recognizes Elizabeth II as sovereign
Capital: Colombo
Political subdivisions: 9 provinces, 22 administrative districts, and four
categories of semiautonomous elected local governments
Legal system: a highly complex mixture of English common law, Roman-Dutch,
Muslim and customary law; constitution adopted 1946-47, new constitution
to be adopted in 1971; no judicial review of legislative acts; legal
education at Ceylon Law College and University of Ceylon, Peradeniya; has
not accepted compulsory ICd jurisdiction
Branches: unitary parliamentary form of government; bicameral legislature
and independent judiciary
Government leader: Prime Minister Sirimavo Bandaranaike
Suffrage: universal over age 18, but approximately 1.1 million Indian Tamils
not enfranchised
Elections: national elections, ordinarily held every 5 years (last election
held May 1970); must be held more frequently if government loses
confidence vote
Political parties and leaders: Sri Lanka Freedom Party, Sirimavo Ratwatte Dias
Bandaranaike, President; Lanka Sama Samaja Party (Trotskyite), N. M.
Perera, President; Mahajana Eksath Peramuna, D. P. R. Gunawardena,
President; Federal Party, E. M. V. Naganathan, President; United National
Party, Dudley Senanayake, President; Ceylon Communist Party/Moscow,
Pieter Keuneman, Secretary General; Ceylon Communist Party/Peking, N.
Shanmugathasan Faction; Ceylon Communist Party/Peking, P. Kumarasiri
Faction; Sinhala Mahajana Paksaya, R. G. Senanayake, leader; All Ceylon
Tamil Congress, G. G. Ponnambalam, President
Voting strength (1970 election): 37% Sri Lanka Freedom Party, 38% United
National Party, 9% Lanka Sama Samaja Party','26126e2c02a838a2bbe35d35fc89232f804bc94c6d65033afc74a265c47544ba','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df32d1ab75621addc68f9b4c10a13fb7e6bb89b106d5f7e0c290af39f9292a39',1971,'DZ','Algeria','government',7,', 3.5% Communist Party/Moscow,
5% Federal Party, minor parties and independents accounted for remainder
55
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GOVERNMENT (cont‘d):
Other political or pressure groups: Buddhist clergy, Sinhalese Buddhist lay
groups
Member of: ADB, Colombo Plan, Commonwealth, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMCO, IMF, ITU, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Chad
Type: republic; one-party presidential regime since 1962
Capital: Fort-Lamy
Political subdivisions: 14 prefectures
Legal system: based on French civil law system and Chadian customary Taw;
constitution adopted 1962; judicial review of legislative acts in theory a
power of the Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: President, who has sweeping powers, elected by universal adult suffrage
to 7-year term; separate popularly elected unicameral National Assembly
with 5-year term; independent judiciary
Government leader: President Francois Tombalbaye ;
Elections: presidential elections held June 1969, parliamentary elections last
held December 1969
Political parties and leaders: Chadian Progressive Party (PPT), only legal
party, led by Francois Tombalbaye
Voting strength: (1969 elections) 93% in presidential, 97% in parliamentary
Communists: no front organizations or underground party; probably a few
Communists and some sympathizers
Other political or pressure groups: Muslim rebel bands, apparently achieving
some degree of organization although still lightly armed, have been
sporadically harassing government forces since October 1965 in east-central
and since August 1969 in northern Chad; in 1971, eight prefectures were
affected by dissidence
Member of: EAMA, FAO, GATT, ICAO, IBRD, IDA, ILO, IMF, ITU, Lake Chad Basin
Commission, OAU, OCAM, UEAC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Chile
Type: republic
Capital: Santiago
Political subdivisions: 25 provinces
Legal system: based on Code 1857 derived from Spanish law and subsequent codes
influenced by French and Austrian law; constitution adopted 1925, amended
since then; judicial review of legislative acts in the Supreme Court; legal
education at University of Chile, Catholic University, and several others;
has not accepted compulsory ICJ jursidiction
Branches: president; bicameral legislature; independent judiciary
Government leader: President Salvador Allende
Suffrage: universal (except enlisted military and police) and compulsory at
age 18
Elections: next presidential election (1976); next Chamber of Deputies election
(1973); 20 senators (1973)
Political parties and leaders: Communist Party, Luis Corvalan; Socialist Party,
Salvador Allende and Carlos Altamirano; Popular Socialist Union, Raul Ampuero;
Christian Democratic Party, Eduardo Frei and Rodomiro Tomic; Radical Party,
Carlos Norales; National Party, Sergio Onofre Jarpa
Voting strength (1970 presidential election): 36.6% Marxist coalition, 35.3%
conservative independent, 28.1% Christian Democrat; (1969 Congressional
saad election) 12.9% Radical, 29.7% Christian Democrat, 12.2% Socialist, 15.7%
Communist, 20.0% National, 9.5% other
Communists: 65,000; sympathizers, 100,000
Other political or pressure groups: organized labor; business organizations;
landowners’ associations (SNA -- Sociedad Nacional de Agricultura);
* terrorist MIR (Movement of Revolutionary Left)
Member of: ECOSOC, IADB, IAEA, IBRD, ICAQ, IDB, IHB, IMF, LAFTA and Andean Sub-
Regional Group (created in May 1969 within LAFTA), OAS, U.N.
Legal name: People''s Republic of China
Type: Communist state; since beginning of "Cultural Revolution," real authority
has become increasingly diffused as result of persistent rivalries within
the top leadership
Capital: Peking (Peiping)
Political subdivisions: 21 provinces, 3 centrally governed municipalities, and
5 autonomous regions
Legal system: before 1966 a complex structure of indigenous concepts, civil and
common law, and Communist legal theory; highest judicial organ is the
Supreme People''s Court; constitution adopted 1954; not a party to the ICJ
Statute and has not accepted compulsory jurisdiction; whole system largely
suspended during "Cultural Revolution"
Branches: prior to 1966 control was exercised by Chinese Communist Party, through
State Council, which supervised more than 50 ministries, commissions, bureaus,
etc., all technically under the standing committee of the National People''s
Congress; this system broke down under "Cultural Revolution" pressures and
is currently in process of being reconsolidated and streamlined
Government leader: Premier of State Council, Chou En-lai; Chairman, People''s
Republic of China (chief of state, a ceremonial post currently vacant); both
subordinate to central committee of CCP, under Chairman Mao Tse-tung and
Vice Chairman Lin Piao
Suffrage: universal over age 18, though this is academic
Elections: no meaningful elections
Political parties and leaders: Chinese Communist Party (CCP), headed by Mao
Tse-tung and his deputy, Defense Minister Lin Piao; Mao is Chairman of
political bureau, usually real locus of power in China, and also Chairman
of Central Committee; a new central committee was formed at the 9th Party
Congress held in April 1969; otherwise, process of reconstructing CCP below
the national level moving slowly; by 1 April 1971 nearly half the province-
level units in China had formed party committees
Voting strength: 100% Communist for practical purposes; no political nonconformity
permitted
Communists: about 20 million in 1965; perhaps somewhat reduced
61
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GOVERNMENT (cont''d):
Other political or pressure groups: party rule traditionally supplemented before
1966 by a united-front facade of non-Communist parties and mass organizations;
youth, organized as Red Guards and revolutionary rebels, were principal
pressure groups from August 1966 to July 1968; army (PLA) has been increas-
ingly evident as the major internal political force since August 1968,
although industrial workers said to be the “leading force” since July 1968
Member of: no international bodies
Legal name: Republic of China
Type: republic; one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 4 cities, 1 special municipality (Taipei)
Legal system: based on civil law system; constitution adopted 1947, amended 1960
to permit Chiang Kai-shek to be reelected; some judicial review of legislative
acts; accepts compulsory ICJ jurisdiction, with reservations
Branches: 5 independent branches (executive, legislative, judicial, plus traditional
Chinese functions of examination and control), dominated by executive branch;
President and Vice President elected by National Assembly
Government leaders: President Chiang Kai-shek; Vice President, Premier Yen
Chia-kan; Vice-Premier, Chairman Council for International Economic
Cooperation and Development Chiang Ching-kuo
Suffrage: universal over age 20
Elections: national level -- legislative yuan every 3 years but not held since
1948 election on mainland (partial election for Taiwan province representatives
December 1969); local level -- provincial assembly, county and municipal
executives every 4 years; county and municipal assemblies every 4 years
Political parties and leaders: Kuomintang, or National Party, led by Director
General Chiang Kai-shek, has no real opposition; 2 insignificant parties
are Democratic Socialist Party, Young China Party
Voting strength (1968 provincial assembly election): 61 seats Kuomintang,
10 seats independents
Member of: IAEA, IBRD, ICAO, IDA, IHB, ILO, IMCO, IMF, ITU, SC, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Republic of Colombia
Type: republic; executive branch dominates government structure
Capital: Bogota
Political subdivisions: 22 departamentos, 4 intendencias, 4 comisarias, 1 federal
district
Legal system: based on Spanish law; religious courts regulate marriage and
divorce; constitution decreed in 1886, amendments codified in 1946; judicial
review of legislative acts in the Supreme Court; accepts compulsory ICJ
jurisdiction, with reservations
Branches: President, bicameral legislature, judiciary
Government leader: President Misael Pastrana
Suffrage: universal over age 21
Elections: every fourth year; last presidential and congressional elections
April 1970; municipal and departmental elections, 1972
Political parties and leaders: Liberal Party, Carlos Lleras Restrepo, Alfonso
Lopez Michelsen, Julio Cesar Turbay; Conservative Party, Unionista Wing,
Mariano Ospina Perez, Misael Pastrana; Conservative Party, Alzatista Wing,
Alvaro Gomez Hurtado; National Popular Alliance (ANAPO), General Gustavo
Rojas Pinilla, Maria Eugenia Rojas de Moreno; Liberals probably command
majority of votes over conservatives, but constitution under the National
Front Coalition calls for 50-50 representation of Liberals and Conservatives
in the National Congress until 1974; in local legislative bodies, parity
terminated with the 1970 election; Conservative Party united with progovernment
and Ospina wing in August 1969 to choose National Front presidential
candidate; opposition wing (Lauro-Alzatista) led by Gomez
Voting strength: 1970 presidential election -- Misael Pastrana 1.61 million
votes, General Gustavo Rojas Pinilla 1.54 million votes, Belisario Betancur
Cuartas .46 million votes, Evardisto Sourdis .3 million votes
Other political or pressure groups: Communist Party (PCC), Gilberto Vieira
White; MRL del Pueblo, Communist front for electoral purposes; PCC/ML, Chinese
Line Communist Party, led by Pedro Lupo Leon Arboleda Roldan
Member of: FAO, IADB, IAEA, IBRD, ICAO, IFC, IHB, ILO, IMF, ITU, LAFTA and
Andean Sub-Regional Group (created in May 1969 within LAFTA), OAS, U.N.,
UNESCO, UPU, WHO, WMO
65
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: People''s Republic of the Congo
Type: republic; military regime established September 1968
Political subdivisions: 9 regions divided into districts
Legal system: based on French civil law system and customary law; constitution
adopted 1963 and 1969
Branches: President, Council of State; National Assembly dissolved August 1968;
judiciary presumably still functions according to provisions of 1963
constitution; all policy made by Congolese Workers Party Central Committee
and Politburo
Government leader: President, Maj. Marien Ngouabi
Suffrage: universal over age 18
Elections: last legislative elections December 1963; none scheduled
Political parties and leaders: Congolese Workers Party (PCT) is only legal party;
40 member Central Committee, 10 member Politburo, President, Maj. Manen
Ngouabi, First Secretary, Claude Ndalla Graille
Voting strength: no elections held since PCT formed
Communists: some Communists and sympathizers
Other political or pressure groups: Union of Congolese Socialist Youth (UJSC),
Congolese Trade Union Congress (CSC), Revolutionary Union of Congolese
Union (URFC), General Union of Congolese Pupils and Students (UGEEC)
Member of: EAMA, EEC (associate), FAO, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM,
UDEAC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Democratic Republic of the Congo
Type: republic; constitution establishes strong presidential system
Capital: Kinshasa (Leopoldville)
Political subdivisions: 8 provinces and federal district of Kinshasa
Legal system: based on Belgian civil law system and tribal law; new constitution
promulgated 1967; legal education at Lovanium and Congo Official University;
has not accepted compulsory [Cd jurisdiction
Branches: president elected 1970 for seven-year term; National Assembly of 420
members elected for five-year term
Government leaders: Gen. Joseph Mobutu, President
Elections: presidential and legislative elections in October and November 1970
Political parties and leaders: Mouvement Populaire Revolutionnaire (MPR), only
legal party, organized from above with actual grassroots popularity not
clearly definable
Communists: no Communist Party, but some Congolese politicians are subject to
Communist influence
Member of: EAMA, FAQ, IAEA, ICAO, IHB, ILO, ITU, OAU, OCAM, UDEAC, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Republic of Costa Rica
Type: unitary republic
Capital: San Jose
Political subdivisions: 7 provinces
Legal system: based on Spanish civil law system; constitution adopted 1949;
judicial review of legislative acts in the Supreme Court; legal education
at University of Costa Rica; has not accepted compulsory ICJ jurisdiction
Branches: President, unicameral legislature, Supreme Court elected by
legislature
Government leader: President Jose Figueres
Suffrage: universal and compulsory age 20 and over
Elections: every 4 years; next, February 1974
Political parties and leaders: National Liberation Party (PLN), Jose Figueres;
National Union Party (PUN), Otilio Ulate; Republican Party (PR), Rafael
Calderon Guardia; Authentic Republican Union Party (PURA), Mario Echandi;
Christian Democratic Party (PDC), Jorge Monge Zamora; Third Front (PFN) »
Virgilio Calvo; Socialist Action Party (PASO), Marcial Aguiluz; Revolutionary
Civic Union Party (PUCR), Frank Marshall; Popular Vanguard Party (PVP).
Manuel Mora, illegal
Voting strength (1970 election): National Unification (coalition of PUN, PR, and
PURA), 41.1%; PLN, 55%; PFN, 1.7%; PDC, 0.9%; PASO, 1.3%
Member of: CACM, IADB, IAEA, ICAO, OAS, U.N.
Legal name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: 6 provinces
Legal system: based on Spanish and American law, with large elements of
Communist legal theory; Fundamental Law of 1959 replaced constitution
of 1940; legal education at Universities of Havana, Oriente, and Las Villas;
does not accept compulsory ICJ jurisdiction
Branches: executive; no legislature; controlled judiciary
Government leader: Premier Fidel Castro Ruz
Political parties and leaders: Cuban Communist Party (PCC), First Secretary
Fidel Castro Ruz, Second Secretary Raul Castro Ruz
Communists: approx. 120,000 party members
Member of: CEMA (observer status), ECLA, FAO, GATT, IADB (nonparticipant), IAEA,
ICAO, IHB, ILO, IMCO, International Rice Commission, International Sugar
Council, International Wheat Agreement, ITU, OAS (nonparticipant), Permanent
Court of Arbitration, Postal Union of the Americas and Spain, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Republic of Cyprus
Type: republic since March 1961; separate de facto Greek, Cypriot, and Turkish
governments have evolved since outbreak of communal strife in 1963
Capital: Nicosia
Political subdivisions: 6 administrative districts
Legal system: based on common law, with civil law modifications; constitution
came into force upon independence in 1960, but has often been in abeyance
since then; has not accepted compulsory ICJ jurisdiction
Branches: currently a rump government consisting basically of Greek Cyriot parts
of bodies provided for by constitution; headed by President of the Republic
and comprised of Council of Ministers, House of Representatives, and
Supreme Court
Government leaders: President, Archbishop Makarios III (Greek); Vice President,
Dr. Fazil Kucuk (Turk)
Elections: held every 5 years; 1965 elections suspended; 1968 elections only for
President and Vice President; 1970 parliamentary elections demonstrate
notable increase in strength of Communist Party (AKEL)
Political parties and leaders: Reform Party of the Working People (AKEL)
(Communist Party), Ezekias Papaioannou; Unified Party (UP), Glafkos Clerides;
Progressive Movement (PM) (pro-Makarios), Andreas Azinas; Democratic
National Party (DEK), Takis Evdokas; United Democratic Union of the Center
(EDEK), Vassos Lyssarides; Turkish National Union Party (TNUP), Rauf Denktash
Voting strength: (1968 Presidential and Vice Presidential elections) Greek
é Cypriot President Makarios 90%; Turkish Cypriot Vice President Fazil Kucuk
aaa unopposed; (1970 parliamentary elections) 39% of Greek Cypriot vote for
Reform Party of the Working People, 21% of the Greek Cypriot vote for the
Progressive Movement, 9% of the Greek Cypriot vote for the Democratic National
Party as well as 9% for the United Democratic Union of the Center, 4% of the
* Greek Cypriot vote for independents, 76% of the Greek Cypriot electorate
voted; 80% of the Turkish Cypriot community voted and overwhelmingly elected
15 of Rauf Denktash''s supporters to the Turk Cypriot House contingent in a
separate election
Communists: 12,000; sympathizers 60,000
Other political or pressure groups: United Democratic Youth Organization (EDON)
(Communist-controlled); Pan Cyprian Confederation of Labor (PEO)
(Communist-controlled); Cyprus Confederation of Labor (SEK) (pro-U.S.);
Cyprus Turkish Federation of Trade Unions (KTBIF)
75
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GOVERNMENT (cont''d):
Member of: Commonwealth, Council of Europe, FAO, IAEA, IBRD, ICAO, IDA, IFC,
ILO, IMF, ITU, U.N., UNESCO, UPU, WHO
Legal name: Czechoslovak Socialist Republic
Type: Communist state
Capital: Prague
Political subdivisions: 2 separate autonomous republics (Czech Socialist
Republic and Slovak Socialist Republic); 7 regions (kraj) in Czech lands,
three regions in Slovakia; national capitals of Prague and Bratislava have
regional status
Legal system: civil law system based on German codes, modified by Communist
legal theory; revised constitution adopted 1960 under revision; no judicial
review of legislative acts; legal education at Universita Komenskeho School
of Law; has not accepted compulsory ICJ jurisdiction
Branches: executive --- President, cabinet (appointed by President); legislative
-- Federal Assembly (elected directly), Czech and Slovak National Councils
(also elected directly) legislate on limited area of Czech and Slovak affairs;
judiciary -- Supreme Court (elected by Federal Assembly); entire governmental
structure dominated by Communist Party
Government leader: President Ludvik Svoboda
Suffrage: universal and compulsory over age 18
Elections: governmental bodies every 4 years; President every 5 years (provisions
suspended after Soviet invasion, August 1968); elections expected in late 1971
Dominant political party and leader: Communist Party of Czechoslovakia (KSC),
Gustav Husak, First Secretary; Communist Party of Slovakia has status of
"provincial KSC organization"
Voting strength (1964 election): 99.4% Communist-sponsored single slate
: Communists: 1.2 million
wa Other political groups: puppet parties -- Czechoslovak Socialist Party,
Czechoslovak People''s Party, Slovak Freedom Party, Slovak Revival Party
Member of: CEMA, GATT, IAEA, ICAO, U.N., Warsaw Pact
Legal name: Republic of Dahomey
Type: republic
Capital: Porto Novo (official), Cotonou (de facto)
Political subdivisions: 6 departments, 30 arrondissements
Legal system: based on French civil law and customary Taw; presidential charter
adopted 1970; judicial review by 4-chambered Supreme Court; legal education
generally obtained in France; has not accepted compulsory ICJ jurisdiction
Branches: executive -- 3-man Presidential Council, but actual executive authority
vested in rotating presiding officer who also serves as Premier; no
legislature; independent judiciary
Government leaders: Hubert Maga, Premier and presiding officer of Presidential
Council that functions as chief of state; Justin Ahomadegbe, member of
Presidential Council; Sourou-Migan Apithy member of Presidential Council
Suffrage: universal for adults whenever elections or referendums are held
Elections: current government has held no elections and none are scheduled
Political parties: none
Communists: some; probably some sympathizers
Member of: EAMA, Entente, FAO, ICAO, ILO, ITU, OAU, OCAM, U.N., UNESCO, UPU, WHO,
WMO
Legal name: Kingdom of Denmark
Type: constitutional monarchy
Capital: Copenhagen
Political subdivisions: 14 counties, 277 communes, 88 towns
Legal system: civil law system; constitution adopted 1953; judicial review of
legislative acts; legal education at Universities of Copenhagen and Arhus;
accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament
(Folketing); executive power vested in Crown but exercised by cabinet
responsible to parliament; Supreme Court, 2 superior courts, 106 lower courts
Government leader: King Frederick IX; Prime Minister Hilmar Baunsgaard
Suffrage: universal, but not compulsory, over age 2]
Elections: held every 4 years (next in 1971)
Political parties and leaders: Social Democratic, Jens Otto Krag; Moderate
Liberal, Poul Hartling; Conservative, Knud Thestrup; Radical Liberal, Soren
Bjerregaard; Socialist Peoples, Sigurd Omann; Communist, Knud Jespersen;
Left Socialist, Erik Sigsgaard
Voting strength (1968 election): 34.2% Social Democratic, 18.6% Moderate Liberal,
20.4% Conservative, 15.0% Radical Liberal, 6.1% Socialist Peoples, 1.0%
Communist, 2.0% Left Socialist, 2.7% other
Communists: 5,000; a number of sympathizers, as indicated by 29,700 Communist
ee votes cast in 1968 elections
a Member of: Council of Europe, EFTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IMB,
ILO, IMCO, IMF, ITU, NATO, Nordic Council, OECD, U.N., UNESCO, UPU, WHO, WMO
Legal name: Associated State of Dominica
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Roseau
Political subdivisions: 10 parishes
Legal system: based on English common law; three local magistrate courts and
the British Caribbean Court of Appeals
Government leaders: Premier Edward 0. LeBlanc; U.K. Governor Louis Cools-Lartigue
Suffrage: universal adult suffrage (age 18 effective June 1971)
cea every 5 years; most recent October 1970 (by-election held December
1970
Political parties and leaders: Dominica Labor Party (DLP), Edward 0. LeBlanc;
Dominica Freedom Party (DFP), Miss M. Eugenia Charles
Voting strength: Legislative Council seats -- DFP 2 seats, DLP 8 seats, indepen-
dent 1 seat
Communists: negligible
Member of: CARIFTA
Legal name: Dominican Republic
Type: republic
Capital: Santo Domingo
Political subdivisions: 26 provinces and the National District
Legal system: based on French civil codes; 1966 constitution
Branches: President popularly elected for a 4-year term; bicameral legislature
consisting of Senate (27 seats) and Chamber of Deputies (74 eante) elected
for 4-year terms; members of Supreme Court elected by Senate
Government leader: President Joaquin Balaguer
Suffrage: universal and compulsory, over age 18 or married
Elections: national, May 1970
Political parties and leaders: Reformist Party (PR), Joaquin Balaguer; Dominican
Revolutionary Party (PRD), Juan Bosch Gavino; Democratic Quisqueyan
Party (PQD), Elias Wessin y Wessin; Revolutionary Social Christian Party
(PRSC), Alfonso Moreno Martinez; Movement for National Conciliation (MNC),
Jaime Manuel Fernandez Gonzalez; Anti-reelection Movement of Democratic
Integration (MIDA) Francisco Augusto Lora; Fourteenth of June Revolutionary
Movement (MR-1J4), split into several factions, illegal; Dominican Communist
Party (PCD), central committee, illegal; Dominican Popular Movement (MPD),
Maximiliano Gomez Horacio, illegal; Communist Party of the Dominican Republic
(PCRD), Luis Montas Gonzalez, illegal; Popular Socialist Party (PSP), illegal
Voting strength (1970 election): 56% PR, (abstained) PRD, 5% PRSC, 14% PQD, 3%
MCN, 4.7% other
Member of: IADB, IAEA, ICAO, IHB, OAS, U.N.
Legal name: German Democratic Republic
Type: Communist state
Capital: Eastern Sector of Berlin (this claim is not officially recognized by
U.S., U.K., and France which together with the U.S.S.R. have special rights
and responsibilities in Berlin)
Political subdivisions: (excluding East Berlin) 14 districts (Bezirke), 217
counties (Kreise), 8,95','e8761b2f11d426211413f70fe7a071e46bbfd2ad6f308ba1e1ca7f420fee2a16','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9dc2826e86935d35674852bc2ab3940d065cf725cb3a6f3e3e082e36d8ad20a',1971,'DZ','Algeria','government',8,'0 communities (Gemeinden) (according to East German
statistics published in February 1970)
Legal system: Communist legal theory; new constitution adopted 1968 by approx.
95% of the voters in country''s first referendum which was held under coercive
conditions; no judicial review of legislative acts; legal education at School
of Political Science and Law "Walter Ulbricht"; has not accepted compulsory
ICJ jurisdiction; new penal code reflecting more stringent Socialist ideology
adopted 1968
Branches: legislative, executive, and judicial systems dominated by Communist
Party through interlocking directorates
Government leaders: Premier Willi Stoph; Chairman, Council of State,
Walter Ulbricht
Suffrage: all citizens age 18 and over
Elections: national and local alternating every 2 years; prepared by an electoral
commission of the National Front; ballot supposed to be secret and voters
permitted to strike names off ballot; recent change allows more candidates
than offices available; parliamentary elections held 2 July 1967; local
elections, 22 March 1970
Political parties and leaders: Socialist Unity (Communist) Party (SED), headed
by First Secretary Walter Ulbricht, dominates the regime; 4 other token
parties (Christian Democratic Union, National Democratic Party, Liberal
Democratic Party, and German Peasants'' Party) and an amalgam of pseudo-
political parties and pressure groups participate in National Front ;
Voting strength: 97.98% of those eligible to vote cast ballots and 99.85% of
these voted the regime slate (1970 local elections); similar results were
obtained in the 1967 parliamentary elections
Communists: 1.9 million
Other political groups: Free German Youth, Free German Trade Unions Association,
Democratic Women''s League of Germany, German Democratic Cultural Association
(all Communist dominated)
Member of: CEMA, Warsaw Pact
115
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Republic of Ghana
Type: republic; independent since March 1957
Capital: Accra
Political subdivisions: 8 administrative regions and separate Greater Accra
Area; regions subdivided into 47 districts
Legal system: based on English common Taw and customary law; Supreme Court has
power of judicial review; new constitution adopted 1969; legal education at
University of Ghana (Legon) and Ghana Law School (Accra); has not accepted
compulsory ICd jurisdiction
Branches: executive authority vested primarily in prime minister, although
president has some appointive powers; unicameral legislature; independent
judiciary
Government leaders: chief of state, President Edward Akufo-Addo; Prime Minister,
Kofi A. Busia
Suffrage: universal over 21
Elections: 140-man National Assembly elected to five-year term in August, 1969;
105 seats won by Progress Party which now governs
Political parties and leaders: two major parties are Progress Party led by
Kofi Busia and Justice Party led by E. R. Madjitey and Joe Appiah
Communists: a small number of Communists and sympathizers, without influence
since Nkrumah''s overthrow
Member of: Commonwealth, FAO, IAEA, IBRD, ICAQ, ILO, IMCO, IMF, ITU, OAU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Colony of Gibraltar
Type: U.K. colony
Capital: none
Legal system: English law; constitutional talks in July 1968; new system
effected in 1969 after electoral enquiry
Branches: parliamentary system comprised of the Gibraltar House of the Assemb ly
(15 elected members and 2 ex officio members), the Council of Ministers
headed by the Chief Minister, and the Gibraltar Council; the Governor is
appointed by the Crown
Government leaders: Governor and Commander in Chief, Adm. of the Fleet Sir
Vary] Begg; Chief Minister, Maj. Robert Peliza; Deputy Chief Minister,
Peter Isola
Suffrage: all adult Gibraltarians, plus other U.K. subjects resident 6 months
or more
Elections: every 5 years; last held in July 1969
Political parties and leaders: Association for Advancement of Civil Rights
(AACR), Sir Joshua Hassan; Labor, Sir Joshua Hassan; Independents, Peter
Isola; Integrationists (IWBP), Maj. Robert Peliza
Voting strength: In 1969, the AACR won 7 seats in the Assembly, the IWBP won 5,
the Independents won 3; a coalition between the latter two parties was formed
Communists: none known
Other political or pressure groups: the Housewives Association; the Chamber
of Commerce
Legal name: Kingdom of Greece
Type: constitutional monarchy; power in hands of ex-military leaders since
April 1967
Capital: Athens
Political subdivisions: 52 departments (nomoi) administered by the central
government (probably will be altered)
Legal system: based on Roman and Byzantine law, substantially altered by civil
codes of 1946-51; legal training at University of Athens; compulsory ICJ
jurisdiction not accepted
Branches: new constitution implemented in November 1968, except for certain
articles concerning individual rights, political activity, and powers of the
courts theoretically implemented through new legislation in 1969; however,
in practice repression of these rights still exists; Consultative Assembly
elected in 1970
Government leaders: King Constantine, head of state (in exile); Lt. Gen. George
Zoitakis, Regent; actual authority lies in hands of-ex-military triumvirate
headed by Georgis Papadopoulos, Prime Minister, Minister of Defense, and
Foreign Minister; Stylianos Pattakos, Deputy Prime Minister and Minister of
Interior; Nikolaos Makarezos, Minister of Coordination
Suffrage: universal age 21 and over
Elections: subject to scheduling of government
Political parties and leaders: political activities suppressed; party leadership
and organization in disarray
Communists: 12% of electorate in February 1964; hard-core elements imprisoned;
Communist Party (KKE) outlawed since 1947
Member of: EEC (associate member), FAO, FUND, IAEA, IBRD, ICAO, IDA, IFC, IHB,
ILO, IMCO, ITU, NATO, OECD, U.N., UNESCO, UPU, WHO, WMO
Legal name: Greenland
Type: province of Kingdom of Denmark; 2 representatives in Danish parliament;
separate Minister for Greenland in the Danish cabinet
Capital: Godthab (administrative center)
Political subdivisions: 3 counties, 19 communes
Legal system: Danish law; transformed from colony to province in 1953
Branches: legislative authority rests jointly with Crown and Danish parliament;
executive power vested in Crown, acting through provincial governor
responsible to Minister for Greenland; local affairs handled by provincial
council] (Landsra@d) subject to approval of provincial governor; 19 lower courts
Government leader: King Frederick IX; Governor N.0. Christensen
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years (next June 1971)
Political parties: Inuit (advocating close ties with Denmark); Sukaq (moderate
socialist, advocating more distinct Greenland identity)
Legal name: Associated State of Grenada
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: St. George''s
Political subdivisions: 6 parishes
Legal system: based on English common law
Government leaders: Premier Eric Matthew Gairy; U.K. Governor Dr. Hilda Bynoe
Suffrage: universal adult suffrage
Elections: every 5 years; most recent election August 1967
Political parties and leaders: Grenada United Labor Party (GULP), Eric Matthew
Gairy; Grenada National Party (GNP), Herbert A. Blaize
Voting strength (1967 election): GULP 53.9%, GNP 46.1%; Legislative Council
seats, GULP 7, GNP 3
Communists: negligible
Member of: CARIFTA
Legal name: Republic of Guatemala
Type: republic
Capital: Guatemala City
Political subdivisions: 22 departments
Legal system: civil law system; constitution came into effect 1966; judicial
review of legislative acts; legal education at University of San Carlos of
Guatemala; has not accepted compulsory ICJ jurisdiction
Branches: traditionally dominant executive; elected unicameral legislature;
7-member (minimum) Supreme Court
Government leader: President Carlos Arana
Suffrage: universal over age 18, compulsory for literates, optional for illiterates
Elections: next elections (President and Congress) March 1974
Political parties and leaders: Democratic Institutional Party (PID), Donaldo
Alvarez Ruiz; Revolutionary Party (PR), Alberto Fuentes Mohr (Sec. Gen.);
National Liberation Movement (MLN), Mario Sandoval Alarcon; Guatemalan
Christian Democratic Party (DCG), Danilo Barillas Rodriguez
Voting strength: for President -- MLN-PID 251,135 (40%), PR 202,241 (32.5%), DCG
125,948 (20%) null, 7.5%; for congressional seats -- PR 16, MLN-PID 34, DCG 5
Other political or pressure groups: outlawed (Communist) Guatemalan Labor Party
(PGT), Bernardo Alvarado; Revolutionary Democratic Unity (URD), Francisco
Villagran Kramer
Member of: CACM, IADB, IAEA, ICAO, IHB, OAS, ODECA, U.N.
Legal name: Republic of Guinea
Type: republic; under one-party presidential regime
Capital: Conakry
Political subdivisions: 30 administrative regions, 204 arrondissements, about
8,000 local entities of village or district level
Legal system: based on French civil law system and customary law; constitution
adopted 1958; no constitutional provision for judicial review of legislative
acts; has not accepted compulsory ICJ jurisdiction
Branches: executive branch dominant, with power concentrated in President''s
hands and a small group who are both ministers and members of the party''s
politburo; unicameral National Assembly; separate judiciary
Government leader: President Ahmed Sekou Toure, who has been designated
"The Supreme Leader of the Revolution"
Suffrage: universal over age 18
Elections: approximate schedule -- 5 years parliamentary, latest in 1968;
7 years Presidential, latest in 1968
Political parties and leaders: only party is Democratic Party of Guinea (PDG),
headed by Sekou Toure
Communists: no Guinean Communists have been identified, although there are some
sympathizers
Member of: FAO, ICAO, ILO, ITU, OAU, U.N., UNESCO, UPU, WHO, WMO
Legal name: Guyana
Type: republic within Commonwealth
Capital: Georgetown
Political subdivisions: 9 administrative districts
Legal system: based on English common law with certain admixtures of Roman-
Dutch law; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers presided over by Prime Minister; 53-member
unicameral legislative National Assembly (elected); Supreme Court
Government leader: Prime Minister L.F.S. Burnham
Suffrage: universal over age 21
Elections: last held in December 1968; next elections 1973
Political parties and leaders: People''s Progressive Party (PPP), Cheddi Jagan;
People''s National Congress (PNC), L.F.S. Burnham; United Force (UF),
Feilden Singh
Voting strength (1968 election): 36.5% PPP, 55.8% PNC, 7.4% UF, 0.3% other
Communists: unknown; top echelons of PPP and PYO (Progressive Youth Organization,
militant wing of the PPP) include many Communists, but rank and file is
non-Communist
Other political or pressure groups: Justice Party, Guyana United Muslim Party,
Guyana All-Indian League, African Society for Cultural Relations with
Independent Africa, Progressive Youth Organization (PPP affiliate), Young
Socialist Movement (PNC affiliate), Guyana United Youth Society (UF
affiliate), Afro-Asian-American Association, Committee for National
Reconstruction, Guyana National Party (GNP)
Member of: CARIFTA, FAQ, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, U.N., UNESCO, UPU,
WHO, WMO
Legal name: Republic of Haiti
Type: republic under the 14-year dictatorship of Francois Duvalier who was
succeeded upon his death on 21 April 1971 by his constitutional successor,
his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: 5 departments (despite constitutional provision for 9)
Legal system: based on Roman civil law system; constitution adopted 1964; legal
education at State University in Port-au-Prince and private law colleges
in Cap Haitien, Les Cayes, Gonaives, and Jeremie; accepts compulsory ICJ
jurisdiction
Branches: lifetime President, powerless unicameral legislature, judiciary
appointed by President
Government leader: Jean-Claude Duvalier
Suffrage: universal over age 18
Election: constitution provides for lifetime presidency; provisions for
presidential succession not specified; legislative elections to be held
every 6 years
Political parties: National Unity Party, only legal party; United Haitian
Communist Party (PUCH), illegal (Communist)
Voting strength (1967 legislative elections): 100% National Unity Party
(Duvalier)
Member of: GATT, IADB, IAEA, ICAO, IMF, IBRD, OAS, U.N.
Legal name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Political subdivisions: 18 departments
Legal system: based on Roman and Spanish civil law; some influence of English
common law; constitution adopted 1965; judicial review of legislative acts
in Supreme Court; legal education at University of Honduras in Tegucigalpa;
accepts compulsory ICJ jurisdiction, with reservations”
Branches: constitution provides for elected President, unicameral legislature,
and national judicial branch
Government leader: President Ramon Ernesto Cruz
Suffrage: universal and compulsory over age 18
Elections: February 1971, Nationalist Party candidate won election; next
election February 1977
Political parties and leaders: Liberal Party (PLH), Carlos Roberto Reina --
President of Central Executive Council, Jorge Bueso Arias, Ramon Villeda
Morales, Modesto Rodas Alvonado, Max Velasquez, Leonardo Godoy, Nationalist
Party (PNH), Ramon Ernesto Cruz, Ricardo Zuniga Augustinus, Mario Rivera
Lopez, Martin Aquevole, Manuel Acosta Bonilla; Popular Progressive Party
(PPP-uninscribed), Gonzalo Carias Castillo; Orthodox Republican Party (PRO-
uninscribed), Roque Jacinto Rivera; Communist Party of Honduras (PCH-outlawed),
Dionisio Ramos Bejarano, Tomas Ezra Pena; Christian Democrat (uninscribed),
Miguel Andonie Fernandez, Napoleon Alcerro Olivia
Voting strength (1971 elections): Nationalist Party (PNH) 304,753; Liberal
Party (PLH) 276,091
Member of: IADB, ICAO, ILO, OAS, CACM, U.N.
Capital: Victoria
Type: U.K. crown colony
Political subdivisions: Hong Kong, Kowloon, and New Territories
Legal system: English common law
Branches: Governor assisted by advisory Executive Council; he legislates with
advice and consent of Legislative Council; Urban Council which alone includes
elected representatives, responsible for health, recreation, and resettlement;
New Territories divided into 4 districts, each presided over by a District
Officer advised by a locally elected Rural Committee; independent judiciary
Government leader: present Governor and Commander in Chief Sir David Trench is
scheduled to be replaced by C. M. MacLehose in late 1971
Suffrage: limited to 200,000 to 300,000 professional or skilled persons
Elections: every 2 years to select one-half of elected membership of Urban
Council; other Urban Council members appointed by the Governor
Political parties and leaders: Civic Association, Hu Pai-fu; Reform Club, B. A.
Bernacchi; Socialist Democratic Party, Sun Po-kong; Hong Kong Labour Party,
Tang Hon-tsai
Voting strength: (elected Urban Council members) Civic Association 4, Reform
Club 3, and 7 independent
Other political or pressure groups: Federation of Trade Unions (Communist
controlled), Hong Kong and Kowloon Trade Union Council (Nationalist Chinese
dominated), Hong Kong General Chamber of Commerce, Chinese General Chamber
of Commerce (Communist controlled), Federation of Hong Kong Industries,
Chinese Manufacturers’ Association of Hong Kong
Legal name: Hungarian People''s Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 Megyes (counties), 5 autonomous cities in county
status, 113 Jaras (districts)
Legal system: based on Communist legal theory, with both civil law system (civil
code of 1960) and common law elements; constitution adopted 1949; Supreme
Court renders decisions of principle that sometimes have the effect of
declaring legislative acts unconstitutional; legal education at Eotvos
Lorand Tudomanyegyetem School of Law in Budapest and 2 other schools of law;
has not accepted compulsory ICJ jurisdiction
Branches: executive -- Presidential Council (elected by Parliament); legislative
-- Parliament (elected by direct suffrage); judicial -- Supreme Court
(elected by Parliament)
Government leaders: Jeno Fock, Chairman, Council of Ministers; Pal Losonczi,
President, Presidential Council
Suffrage: universal over age 18
Elections: every 4 years
Political parties and leaders: Hungarian Socialist (Communist) Workers'' Party
(sole party); Janos Kadar is First Secretary of Central Committee
Voting strength (1967 election): 7,086,596 (99.7%) for Communist-approved
candidates; 19,113 (0.3%) negative votes; total eligible electorate about
7.2 million
Communists: 662,397 (November 1970)
Member of: U.N. (FAO, IAEA, ILO, ITU, UNESCO, UPU, WHO), CEMA, Warsaw Pact
Legal name: Republic of Iceland
Type: republic
Capital: Reykjavik
Political subdivisions: 16 districts, 213 rural communes, 14 towns
Legal system: civil law system based on Danish law; constitution adopted 1944;
legal education at University of Iceland; does not accept compulsory
ICd jurisdiction
Branches: legislative authority rests jointly with President and parliament
(Althing); executive power vested in President but exercised by cabinet
responsible to parliament; Supreme Court and 26 lower courts
Government leaders: President Kristjan Eldjarn; Prime Minister Johann Hafstein
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in June 1971); presidential, every
4 years (next in 1972)
Political parties and leaders: Independence (conservative), Johann Hafstein;
Progressive, Olafur Johannesson; Social Democratic, Gylfi Gislason; Labor
Alliance (Communist front), Ragnar Arnalds; Organization of Liberals,
Hannibal Valdimarsson
Voting strength (1967 election): 37.5% Independence, 28.1% Progressive, 15.7%
Social Democratic, 17.6% Labor Alliance, 1.1% other
Communists: 1,000; a number of sympathizers, as indicated by 13,400 votes cast
for Labor Alliance in 1967 election
Member of: Council of Europe, EFTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IMB,
ILO, IMCO, IMF, ITU, NATO, Nordic Council, OECD, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of India
Type: federal republic
Capital: New Delhi
Political subdivisions: 18 states, 10 union territories, 1 protectorate (Sikkim),
1 substate (Meghalaya)
Legal system: based on English common law; constitution adopted 1950; judicial
review of legislative acts; accepts compulsory ICJ jurisdiction, with
reservations
Branches: parliamentary government, national and state; independent judiciary
Government leader: Prime Minister Indira Gandhi
Suffrage: universal over age 21
Elections: national and state elections ordinarily held every 5 years; may be
postponed in emergency and may be held more frequently if government loses
confidence vote; next general election to be held by March 1976
Political parties and leaders: Indian National Congress split into two factions
in 1969, largest faction (the Ruling Congress) loyal to Prime Minister Gandhi
led by D. Sanjivayya, and smaller faction (the Organization Congress) led by
S. Nijalingappa; Communist Party of India (CPI),
S. A. Dange, general secretary; Communist Party of India/Marxist (CPI/M),
P. Sundarayya, general secretary; Swatantra, N. Dandekar, president (acting);
Bharatiya Jana Sangh, A. B. Vajpayee, president; Samyukta Socialist, Kappori
Thakur, chairman; Praja Socialist Party, N. G. Goray, chairman; Dravida Munnetra
Kazhagam (DMK), N. Karunanidhi, president
Voting strength (1971 election): 43.7% Ruling Congress, 10.5% Organization Congress,
7.4% Bharatiya Jana Sangh, 3.1% Swatantra, 4.8% CPI, 5.2% CPI/M, 1.1% Praja
Socialist, 2.4% Samyukta Socialist, 3.7% DMK, 18.1% other
Member of: ADB, Colombo Plan, Commonwealth, FAO, IAEA, ICAO, IDA, IFC, IHB, ILO,
IMCO, IMF, U.N., UNESCO, UPU, WHO, WMO
145
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Republic of Indonesia
Type: republic
Capital: Djakarta
Political subdivisions: 26 first-level administrative subdivisions or provinces
which are further subdivided into 219 second-level areas
Legal system: based on Roman-Dutch law, substantial ly modified by indigenous
concepts; constitution of 1945 is legal basis of government; Jegal education
at University of Indonesia, Djakarta; has not accepted compulsory ICJ
jurisdiction .
Branches: executive headed by President who is chief of state, titular head of
cabinet, and Minister for Defense and Security; cabinet selected by President;
unicameral legislature (Parliament) theoretically independent of executive;
second and larger body (Congress), which includes legislature, elects
President and Vice President, and decides outline of national policy; both
now composed of appointed members; judiciary consists of Supreme Court and
system of state courts
Government leader: President Suharto (elected by Congress March 1968)
Suffrage: universal over age 17 and married persons regardless of age
Elections: scheduled for July 1971
Political parties and leaders: Indonesian National Party (PNI), Mohamad Isnaeni
(acting); Nahdlatul Ulama (NU), Idham Chalid; Indonesian Muslim Party (PMI),
Mintaredja :
Voting strength (1955 election): 22.3% National Party, 18.4% Nahdlatul Ulama,
16.4% Communist, 20.9% Masjumi (now banned), 22% other
Communists: Communist Party (PKI) was officially banned in March 1966; current
strength est. at 3,000-4,000, with less than 10% engaged in organized
activity; pre-October 1965 hard core membership has been estimated at 1.5
million
Minor legal parties: Catholic Party, Christian Party, Islamic Unity Party (PSII),
Association of Supporters of Indonesian Independence (IPKI), Islamic Unity
Party (PERTI), Murba
Member of: ADB, ASEAN, FAO, IAEA, ICAO, IHB, ILO, IMF, U.N. (resumed membership
in September 1966 and is now active in U.N. affiliated organizations),
UNESCO
147
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Empire of Iran (becoming obsolete)
Type: constitutional monarchy, actually controlled by the Shah
Capital: Teheran
Political subdivisions: 13 provinces and 6 independent governorates, subdivided
into counties, municipalities, and rural districts
Legal system: based largely on Belgian law, with elements drawn from other
continental systems; personal law based on Islamic practice generally with
residual traces of Roman law; constitution adopted 1906 and constitutional
-law of 1907; High Court of Appeal may judge disputes relating to government
departments acting according to law; legal education at University of Teheran;
has not accepted compulsory ICJ jurisdiction
Branches: executive power rests in Shah who appoints a Prime Minister; Prime
Minister must be approved by lower house (Majlis); while Cabinet theoretically
responsibility of Prime Minister, Shah usually exerts strong influence over
its selection; bicameral legislature; Majlis has 219 seats (with 2 vacant
for islands of the Persian Gulf) elected to 4-year terms, and Senate 60
members serving 4-year terms; half of Senate members appointed by Shah,
other half elected; no provision for judicial review of constitutionality
of legislative acts
Government leaders: Shah Mohammad Reza Pahlavi and Prime Minister Amir
Abbas Hoveyda
Suffrage: universal over age 20
Elections: Majlis every 4 years; Senate every 4 years; latest national elections
August 1967, district and provincial elections in September 1970
Political parties and leaders: New Iran Party, Manuchehr Kalali; Mardom (Peoples)
Party, Yahya Ad1; Pan Iranist Party, Mohsen Pezeshkpur (apparently moribund)
Voting strength (1967 election): Majlis -- New Iran Party, 151 seats; Mardom
Party, 30 seats; Pan Iranist Party, 5 seats; Independent, 1 seat (the
speaker of','1b636b417093c6082afca0ea85ad88adc69072fcbbe5fc1a2d6e4e5c1b4445bf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1811a31a21e168b3bcd4c605fd9b5ae178b2b108979c1fa135828a83c04d40b9',1971,'DZ','Algeria','government',9,'the Majlis); Senate -- New Iran Party, 48 seats; Mardom Party,
11 seats; Independent, 1 seat (the President of the Senate); all candidates
government approved
Communists: 1,000-2,000 (hard-core, est.); sympathizers (15,000-20,000 est.);
mostly pro-U.S.S.R. but pro-Chinese faction developing
Other political or pressure groups: Tudeh Party (Communist, illegal); National
Front (coalition of neutralist urban elements virtually discredited because
a ae to Shah''s reform program); Confederation of Iranian Students
illegal
Member of: CENTO, Colombo Plan, FAQ, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO,
IMF, ITU, OPEC, RCD, U.N., UNESCO, UPU, WHO, WMO
149
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Republic of Iraq
Type: republic; one-party military regime established in July 1968
Capital: Baghdad
Political subdivisions: 16 provinces under centrally appointed officials
Legal system: based on Islamic law in special religious courts, civil law system
elsewhere; provisional constitution adopted in 1968; judicial review was
suspended; legal education at University of Baghdad; has not accepted
compulsory ICJ jurisdiction
Branches: moderate wing of Ba''th Party of Iraq has been in power since 1968 coup
Government leaders: President Hasan al-Bakr; Deputy Chairman of the Revolutionary
Command Council Saddam Tikriti
Suffrage: no elective bodies exist
Elections: none since overthrow of Monarchy in 1958
Communists: Communist Party repressed and disorganized
Political or pressure groups: political parties banned, major opposition to
regime is from leftwing of the Ba''th Party, Communist Party and Nasirist
groups, disaffected members of the regime and army officers
Member of: Arab League, FAQ, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OPEC,
U.N. , UNESCO, UPU, WHO, WMO
Legal name: Republic of Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law, substantially modified by indigenous
concepts; constitution adopted 1937; judicial review of legislative acts in
Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: elected President; bicameral parliament reflecting proportional and
vocational representation; judiciary appointed by President on advice of
Government leader: Taoiseach (Prime Minister) John (Jack) Lynch
Suffrage: universal over age 2]
Elections: Dail (lower house) elected every 5 years -- last election June 1969;
President elected for 7-year term
Political parties and leaders: Fianna Fail, John (Jack) Lynch; Labor Party ,
Brendan Corish; Fine Gael, Liam Cosgrave; Irish Workers’ Party (Communist),
Michael O''Riordan
Voting strength (1969 election): 75 seats Fianna Fail, 50 seats Fine Gael,
18 seats Labor Party, 10 Independents
Communists: approximately 200
Member of: Council of Europe, FAQ, IBRD, ICAO, ILO, IMCO, IMF, ITU, U.N., UNESCO,
- UPU, WHO, WMO
?
Legal name: Republic of Ivory Coast
Type: republic, one-party presidential regime
Capital: Abidjan
Political subdivisions: 6 departments subdivided into 127 subprefectures
Legal system: based on French civil law system and customary law; constitution
adopted 1960, amended 1963; judicial review in the Constitutional Chamber
of the Supreme Court; legal education at Abidjan School of Law; has not
accepted compulsory ICJ jurisdiction
Branches: President has sweeping powers, unicameral legislature, separate
judiciary
Government leader: President Felix Houphouet-Boigny
Suffrage: universal over age 21
Elections: uncontested Presidential and legislative elections held in November
1965; similar elections held November 1970
Political parties and leaders: Parti Democratique de la Cote d''Ivoire (PDCI),
(only party); official party leader is Secretary General Philippe Yace, but
Houphouet-Boigny is in control
Communists: no Communist party; some Communists and probably some sympathizers
Member of: EAMA, Entente, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, OAU, OCAM,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Jamaica
Type: independent state within Commonwealth since August 1962, recognizing
Elizabeth II as head of state
Capital: Kingston
Political subdivisions: 12 parishes and the Kingston-St. Andrew corporate area
Legal system: based on English common law; has not accepted compulsory ICJ
jurisdiction
Branches: cabinet headed by Prime Minister; 53-member elected House of Represent-
atives; 21-member Senate (13 nominated by the Prime Minister, 8 by opposition
leader); judiciary follows British tradition under a Chief Justice
Government leader: Prime Minister Hugh Shearer
Suffrage: universal, age 21 and over
Elections: at discretion of Governor-General upon advice of Prime Minister but
within 5 years; latest held 21 February 1967
Political parties and leaders: Jamaica Labor Party (JLP), Sir Alexander
Bustamante, Hugh Shearer; People''s National Party (PNP), Michael Manley
Voting strength (1969 local elections): 48.59% JLP, 51.54% PNP, 0.24% other
Communists: a few hundred Marxist and Communist sympathizers
Other political or pressure groups: New World Group (Caribbean regionalists,
nationalists, and leftist intellectual fraternity); Rastafarians (Negro
religious/racial cultists, pan-Africanists); New Creation International
Peacemakers Tabernacle (leftist group)
Member of: CARIFTA, FAO, GATT, IAEA, IBRD, ICAO, IFC, ILO, IMF, OAS, Pan
¥ American Health Organization, U.N.; wishes to gain Associated Overseas
i Territory status with EEC if U.K. joins
ee
Legal name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital: ''Amman
Political subdivisions: 8 districts (3 are under Israeli occupation) under
centrally appointed officials
Legal system: based on Islamic law and French codes; constitution adopted 1952;
judicial review of legislative acts in a specially provided High Tribunal;
has not accepted compulsory ICJ jurisdiction
Branches: executive branch holds balance of power; King is effective ruler with
Prime Minister exercising executive authority in name of King; Cabinet
appointed by King and responsible to parliament; bicameral parliament with
Chamber of Deputies chosen by national elections, Senate appointed by King;
each house contains equal representation from East and West Jordan; present
parliament subservient to executive as a result of rigged elections (April
1967); secular court system based on differing legal systems of the former
Transjordan and Palestine; law Western in concept and structure; Sharia
(religious) courts for Muslims, and religious community council courts for
non-Muslim communities; desert police carry out quasi-judicial functions
in desert areas
Government leader: King Husayn ibn Talal al-Hashimi
Suffrage: male citizens over age 20
Political parties and leaders: political party activity illegal since 1957;
Palestine Liberation Organization and Fatah, Yasir Arafat; various smaller
fedayeen groups; Ba''th Party of Jordan, Dr. Mun''if Razzaz; National
Socialist Party, Sulayman al-Nabulusi; Communist Party actively repressed;
Muslim Brethren
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
167
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Republic of Kenya
Type: republic within Commonwealth since December 1963
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi Area
Legal system: based on English common law, tribal law and Islamic law;
constitution enacted 1963; judicial review in Supreme Court; legal education
at University Kenya School of Law in Nairobi; accepts compulsory ICJ
jurisdiction, with reservations
Branches: President and Cabinet responsible to unicameral legislature (National
Assembly) of 170 seats, 158 directly elected by constituencies and 12
specially elected by the Assembly; Assembly must be reelected at least every
5 years; High Court, with Chief Justice and at least 11 justices, has
unlimited original jurisdiction to hear and determine any civil or criminal
proceeding; provision for systems of courts of appeal with ultimate appeal
to East African Court of Appeals
Government leader: President Jomo Kenyatta
Suffrage: universal over age 21
Elections: general election (December 1969) elected present National Assembly
Political party and leaders: Kenyan African National Union (KANU), president -
Jomo Kenyatta, 8 vice presidents
Voting strength: KANU controls National Assembly; holds all seats
Communists: may be a few Communists and sympathizers
Member of: EAC, IAEA, ICAO, OAU, U.N.
Legal name: Democratic People''s Republic of Korea
Type: Communist state; one-man rule
Capital: P''yongyang
Political subdivisions: 9 provinces, 3 special cities (P''yongyang, Hamhung,
Ch''ongjin), and 1 special district (Kaesong)
Legal system: based on German civil law system with Japanese influences and
Communist legal theory; constitution adopted 1948; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
Branches: constitution provides for a Supreme People''s Assembly (SPA), with
provincial government under complete control of central authorities
Government and party leaders: Kim I1-song, Premier and General Secretary
of the Korean Labor Party
Suffrage: universal at age 18
Elections: election to SPA every 4 years, but this constitutional provision not
necessarily followed -- last election (November 1967), with claimed 100% of
electorate voting for official slate
Political party: Korean Labor (Communist) Party; claimed membership of about
1.6 million, or about 12% of population
Legal name: Republic of Korea
Type: republic; power centralized in a strong executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities; heads centrally appointed
Legal system: combines elements of continental European civil law systems,
Anglo-American law, and Chinese classical thought; constitution approved
1962; judicial review of legislative acts in Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: executive, legislative (unicameral), and judiciary
Government leaders: President Pak Chong-hui; Prime Minister Paek Tu-chin
Suffrage: universal over age 20
Elections: presidential and National Assembly elections must be held every 4
years; next elections due in 1971; National Assembly elections due about 1
month after Presidential elections
Principal political parties and leaders: Democratic Republican Party, Pak
Chong-hui; New Democratic Party, Yu Chin-san; Masses Party, So Min-ho
Voting strength: April 1971 presidential election -- Democratic Republican Party,
51.1%; New Democratic Party, 43.4%; minor parties, 1.5%; invalid, 4.0% June
1967 National Assembly elections -- Democratic Republican Party, 50.6%; New
Democratic Party, 32.7%; minor parties, 16.7%; composition of legislature
(1 June 1970) -- Democratic Republican Party, 112 seats; New Democratic Party,
42 seats; Political Friends Society (a group of unaffiliated assemblymen) ,
10 seats; Masses Party, 1 seat; independents, 6 seats, 4 vacancies;
referendum to remove prohibition on third term for President Pak, 67.5%
yes, 32.5% no
Other political or pressure groups: Federation of Korean Trade Unions; Korean
Veterans'' Association; large volatile student population concentrated in Seoul
Member of: ADB, Asian Parliamentary Union, Asian People''s Anti-Coimmunist League
(APACL), ASPAC, Colombo Plan, ECAFE, FAQ, GATT, Geneva Conventions of 1949
for the protection of war victims, IAEA, IBRD, ICAQ, IDA, IFC, IHB, IMCO, IMF,
INTELSAT, Inter-Parliamentary Union, INTERPOL, ITU, UNESCO, U.N. Special Fund,
UPU, WHO, WMO, World Anti-Communist League (WACL); does not hold U.N. membership
173
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Kuwait
Political subdivisions: 3 governates, 10 voting constituencies
Legal system: based on Islamic law in personal matters, civil law system else-
where; constitution adopted 1962; judicial review of legislative acts not
yet determined; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers appointed by ruler; 50-member National Assembly
Government leader: Amir Sabah Al Salim Al Sabah
Suffrage: universal and compulsory over age 21 for all native-born literate males
Elections: latest election January 197]
Communists: insignificant
Member of: Arab League, FAQ, FUND, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO, ITU,
OPEC, OAPEC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Laos
Type: constitutional monarchy
Capital: Vientiane (Louangphrabang royal capital)
Political subdivisions: 16 provinces subdivided into districts, cantons, and
villages
Legal system: based on civil law system; constitution of 1947 superseded by
international agreements of 1962 and subsequent events; has not accepted
compulsory ICJ jurisdiction
Branches: King, 59-member National Assembly, 12-member King''s Council; provisional
coalition government formally composed of 3 "tendencies" -- neutralists,
Communists, rightists -- but Communists not participating
Government leaders: King Savang Vatthana; Premier Souvanna Phouma, neutralist;
Deputy Premier Prince Souphanouvong, Communist (absent); Deputy Premier
Leuam Insisiengmay, rightist
Suffrage: universal over age 18
Elections: National Assembly designated by King; general election last held
in 1967
Political parties and leaders: Neo Lao Hak Sat, Communist-front organization
which includes the Lao People''s Party (Communist), only party active
Communists: Lao People''s Party (clandestine) membership unknown
Other political or pressure groups: Communists are resisting "neutralist"
government; insurgent Communist forces with North Vietnamese backing
pose serious threat to existing government; other political groups are
informal and associated with regional family and military leaders; Prince
Boun Oum is the acknowledged, though not formal leader of the Laotian
rightists; Royal Armed Forces (FAR) leaders, Commander in Chief Quan
Rathikoun, and Generals Kouprasith Abhay, Phasouk Somly, and Vang Pao
Member of: Colombo Plan, ECAFE, ICAO, IMF, Mekong Committee, SEAMES, U.N., UNCTAD
Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law, and civil law system; consti-
tution mandated in 1920; no judicial review of legislative acts; legal
education at University of Lebanon; has not accepted compulsory ICJ
jurisdiction
Branches: power lies with President elected by parliament (Chamber of Deputies);
Cabinet appointed by President, approved by parliament; independent secular
courts on French pattern; religious courts for matters of marriage, divorce,
inheritance, etc.; by custom, President is a Maronite Christian, Prime
Minister a Sunni Muslim, and president of parliament a Shia Muslim; each of
9 religious communities represented in parliament in proportion to national
numerical strength
Government leader: President Sulayman Franjiyyah
Suffrage: compulsory for all males over 21; authorized for women over 21 with
elementary education
Elections: for Chamber of Deputies, held every 4 years or within 3 months of
dissolution of Chamber; held March-April 1968
Political parties and leaders: political party activity is organized along
sectarian lines; numerous political groupings exist, consisting of individual
political figures and followers motivated by religious, clan, and economic
considerations; political stability dependent on maintenance of balance
between religious communities; Communist Party one of largest in Middle
East, was made a legal party on 15 August 1970
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Lesotho
Type: constitutional monarchy under King Moshoeshoe II
Capital: Maseru
Political subdivisions: 9 administrative districts
Legal system: based on English common law and Roman-Dutch law; constitution came
into effect 1966; judicial review of legislative acts in High Court and
Court of Appeal; legal education at University of Botswana, Lesotho, and
Swaziland (located in Lesotho); has not accepted compulsory ICJ jurisdiction
Branches: executive, divided between a largely ceremonial King and a Prime
Minister who leads cabinet of at least 7 members; a bicameral legislature
consisting of a National Assembly (60 seats) and a Senate (33 seats);
judicial -- 63 Lesotho courts administer customary law for Africans, High
Court and subordinate courts have criminal jurisdiction over all residents,
Court of Appeal at Maseru has appellate jurisdiction
Government leader: Prime Minister Chief Leabua Jonathan
Suffrage: universal for adults
Elections: elections held in January 1970; nullified allegedly because of election
irregularities; subsequent elections promised at unspecified date
Political parties and leaders: Basutoland Congress Party (BCP), Ntsu Mokhele;
Marema-tlou Freedom Party (MFP), Dr. Seth Makotoko; National Party (BNP),
Chief Leabua Jonathan; Marema-tlou Party (MTP), Chief $.S. Matete; Lesotho
Democratic Party (LDP), Charles Mofeli; Communist Party of Lesotho, split
into two factions, one led by John Motloheloa, and the other by Jacob M. Kena
Voting strength: National Assembly -- BNP 32 seats, BCP 22 seats, MFP 2 seats,
LDP 2 seats, 2 seats vacant; Senate -- BNP holds 24 of 33 seats (1965
elections)
Communists: Communist Party of Lesotho banned in early 1970, although in past
it received support from Chinese Communists
Member of: Commonwealth, FAO, ILO, ITU, U.N., UNESCO, UPU, WHO
Legal name: Republic of Liberia
Type: republic; dominated by President Tubman since 1944
Capital: Monrovia
Political subdivisions: country divided into 9 counties; President appoints all
officials of significance
Legal system: based on U.S. constitutional theory; recent codes drawn up by
Cornell University; constitution adopted 1847; amended 1907, 1926, 1934,
and 1955; no constitutional provision for, judicial review of legislative
acts; legal education at Louis Arthur Grimes School of Law, University of
Liberia; accepts compulsory ICJ jurisdiction, with reservations
Branches: President, elected by popular vote initially for 8-year term and
eligible for successive 4-year terms, controls through appointive powers and
authority over national expenditures; 2-house legislature elected by popular
vote is rubber stamp; judiciary consisting of Supreme Court and variety of
lower courts theoretically independent but in fact subordinate to executive
Government leader: President William V.S. Tubman
Suffrage: universal over age 21
Elections: members of House of Representatives elected for 4-year terms, most
recently in May 1971; Senate members elected for 6-year terms, one-half
elected in May 1971; President Tubman reelected without opposition to seventh
term in May 197]
Political parties and leaders: True Whig Party, in power since 1878, only
political party; President Tubman is leader
Voting strength: 1971 elections uncontested; True Whig Party won all] but a
handful of votes
Communists: no Communist Party and only a few sympathizers
Member of: ECA, FAQ, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, OAU, U.N., UNESCO,
UPU, WHO
Legal name: Libyan Arab Republic
Type: republic; under military control following ouster of king on 1 September
1969; provisional constitution promulgated December 1969
Capital: Tripoli (defacto)
Political subdivisions: 10 administrative provinces closely controlled by
central government; district commissioners appointed by Revolutionary
Command Council
Legal system: based on Italian civil law system and Islamic law; separate
religious courts; no constitutional provision for judicial review of legislative
acts; legal education at Law School, at University of Libya at Benghazi; has
not accepted compulsory ICJ jurisdiction
Branches: paramount political power and authority rests with the Revolutionary
Command Council; cabinet of 12 ministers; Parliament has been dissolved
Government leaders: Revolutionary Command Council President Lt. Colonel Mu''ammar
Qadhafi
Elections: last held in May 1965, none scheduled
Political parties and leaders: political parties banned
Communists: no organized party, negligible membership
Other political or pressure groups: various Arab nationalist movements and the
Arab Socialist Resurrection (Ba''th) Party with small, almost negligible
memberships may be functioning clandestinely
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
OPEC, OAPEC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Principality of Liechtenstein
Type: constitutional monarchy
Capital: Vaduz
Political subdivisions: 11 districts
Legal system: based on Swiss law; constitution adopted 1921; judicial review of
legislative acts in a special Constitutional Court; accepts compulsory ICJ
jurisdiction, with reservations
Branches: unicameral Parliament, hereditary Prince, independent judiciary
Government leaders: Head of State, Prince Franz Joseph II; Chief of Government,
Dr. Alfred Hilbe
Suffrage: males age 20 and over
Elections: every 4 years; next elections 1974
Political parties and leaders: Fatherland Union Party (VU), Dr. Alfred Hilbe;
Progressive Citizens Party (PCP), Dr. Gerard Batliner
Voting strength (1970 election): 50.5% VU, 49.5% PCP
Communists: none
Member of: IAEA; under a 1923 treaty, Switzerland handles Liechtenstein''s post
and telegraph systems, customs, and foreign relations
Legal name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for administrative purposes has 3
districts (Luxembourg, Diekirch, Grevenmacher) and 12 cantons
Legal system: based on civil law system; constitution adopted 1868; judicial
review of legislative acts in the Cassation Court only; accepts compulsory
ICJ jurisdiction
Branches: parliamentary democracy; seven ministers comprise Council of Government
headed by President, which constitutes the executive; it is responsible to
the unicameral legislature, the Chamber of Deputies; the Council of State,
appointed for indefinite term, exercises some powers of an upper house; judicial
power exercised by independent courts
Government leader: Pierre Werner, Minister of State and President of the Govern-
ment as well as Minister of Treasury
Suffrage: universal and compulsory over age 2]
Elections: every 5 years for entire Chamber of Deputies; latest elections Dec-
ember 1968; next election, December 1973
Political parties and leaders: Christian Social Union, Pierre Werner and Jean
Dupong (Party President); Socialist, Antone Wehenkel (Party President); Social
Democrat, Ernst Lay (Party President); Democratic, Gaston Thorn (Party
President and Foreign Minister); Communist, Dominique Urbany
Voting strength (1968 election, approx.): 32% Socialist, 35% Christian Socialist,
15% Communist, 17% Democratic, 1% other; it should be noted that these are
percentages of votes cast rather than voters, since Luxembourg has a weighted
proportional representation system in which voters in most populous areas
have largest multiple votes
Communists: 520 party members
Other political or pressure groups: group of steel industries representing iron
and steel industry, Centrale Paysanne representing agricultural producers ;
Christian and Socialist labor unions, Federation of Industrialists; Artisans
and Shopkeepers Federation
Member of: Benelux, BLEU (Belgium-Luxembourg Economic Union), Council of Europe,
ECSC, EEC, EURATOM, FAO, IAEA, IBRD, ICAO, IFC, ILO, IMF, NATO, OECD, U.N.,
UPU, WEU, WHO, WMO
189
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Province of Macao
Type: overseas province of Portugal
Capital: Lisbon (Portugal)
Political','9376b22a6ba4e7514d006236e536330ca0ad695c94e69d997f0cd265e65f4b33','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('374181467d4c4f2d9242b1103c7e0515713d6d90a317dc9c51d45c8e07c0e991',1971,'DZ','Algeria','government',10,'subdivisions: municipality of Macao, and 2 islands
Legal system: Portuguese civil law system
Branches: Governor, who dominates legislative and executive branches, assisted
by Legislative Council with unknown number of appointed and 8 elected
members; the Urban Council with 3 Governor-appointed and 4 elected members ;
all high-ranking officials appointive under provisions of revised Organic
Overseas Law
Government leader: Brigadier Jose Manuel Nobre De Carvalho, Governor
Suffrage: restricted to Portuguese citizens
Elections: conducted every 4 years; last held November 1968
Political parties and leaders: Portuguese National Union (Uniao Nacional) only
legal party, as in Portugal; Governor is leading political figure
Other political or pressure groups: wealthy Macanese and Chinese representing
local interests, wealthy pro-Communist merchants representing Communist
China''s interests; in January 1967 Macao Government acceded to Chinese
demands which gave Chinese Communists veto power over administration of
the enclave
Legal name: Malagasy Republic
Type: republic; under one-party rule since independence in June 1960
Capital: Tananarive
Political subdivisions: 6 provinces
Legal system: based on French civil law system and Islamic law; constitution
adopted 1959, amended 1960 and 1962; judicial review of legislative acts in
High Council of Institutions; legal education at National School of Law,
University of Tananarive; has not accepted compulsory ICJ jurisdiction
Branches: executive -- President has wide powers, elected for 7-year term by
direct universal suffrage; legislative -- bicameral (National Assembly and
Senate); judicial -- patterned after French system
Government leader: President Philibert Tsiranana
Suffrage: universal for adults
Elections: held regularly but opposition parties are hampered by restrictions
on campaigning
Political parties and leaders: Parti Social Democrate (PSD), led by Secretary
General Andre Resampa; leading opposition party is AKFM (Congress Party
for the Independence of Madagascar), led by Pastor Richard Andriamanjato
Voting strength: (1970 elections) President Tsiranana received 97% of votes cast;
PSD candidates for National Assembly won 94%; AKFM 3%
Communists: small Communist party under close surveillance by government
security forces; Communist party virtually of no importance; smal] and
vocal group of Communists has gained strong position in leadership
of AKFM, the rank and file of which is non-Communist
Ga FAO, IAEA, ICAO, ILO, IMCO, ITU, OAU, OCAM, U.N., UNESCO, UPU,
’
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Republic of Malawi
Type: republic since July 1966; independent member of Commonwealth
Capital: Zomba
Political subdivisions: local government unit is the. district
Legal system: based on English common law and customary law; constitution
adopted 1964; judicial review of legislative acts in the Supreme Court of
Appeal; has not accepted compulsory ICJ jurisdiction
Branches: strong presidential system with cabinet appointed by President; uni-
cameral National Assembly of 60 elected and 15 nominated members; High
Court with Chief Justice and at least 2 justices
Government leader: President Hastings Kamuzu Banda
Suffrage: universal adult
Elections: scheduled for April 1964; not held since MCP candidates were unopposed
Political parties and leaders: Malawi Congress Party (MCP), Dr. Hastings Kamuzu
Banda
Communists: no Communist Party; may be a few Communist sympathizers
Member of: FAO, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU, U.N., UNESCO, WHO, WMO
Legal name: Republic of Maldives
Type: republic
Capital: Male
Political subdivisions: 19 administrative areas broken down by clusters of atolls
Legal system: based on Islamic law with admixtures of English common law primari-
ly in commercial matters; has not accepted compulsory ICJ jurisdiction
Branches: popularly elected unicameral national legislature (Majilis) (members
elected for 5-year terms); elected President, chief executive; appointed
Chief Justice responsible for administration of Islamic law
Government leaders: President Ibrahim Nasir
Suffrage: universal over age 21
Political parties and leaders: no organized political parties; country governed
by the Didi clan for the past eight centuries
Member of: Colombo Plan, U.N.
Legal name: Republic of Mali
Type: republic; under military regime since November 1968
Capital: Bamako
Political subdivisions: 6 administrative regions; 42 administrative districts
(cercles), arrondissements, villages; all subordinate to central government
Legal system: based on French civil law system and customary law; constitution
adopted 1960, amended 1961; judicial review of legislative acts in Constitu-
tional Section of Court of State; has not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by Military Conmittee of National
Liberation (MCNL) composed of 11 army officers; under MCNL functional
cabinet composed of civilians and army officers; judiciary
Government leaders: Lt. Moussa Traore, president of MCNL, Chief of State and
head of government
Suffrage: universal over age 21
Political parties and leaders: former Union Soudanaise-RDA dissolved and political
activity proscribed by military government
Elections: MCNL promises elections at unspecified date
Communists: there are a few Communists and a somewhat larger number of sympathizers;
some are under detention by MCNL
Member of: EAMA, FAO, IAEA, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UPU, WHO, WMO
Legal name: Malta
Type: independent state since September 1964, recognizing Elizabeth II as chief
of state
Capital: Valleta
Political subdivisions: 2 main populated islands, Malta and Gozo, divided into
10 electoral districts (divisions)
Legal system: based on English common law; constitution adopted 1961, came into
force 1964; has accepted compulsory ICJ jurisdication, with reservations
Branches: executive, consisting of prime minister and cabinet; legislative,
comprising 50-member House of Representatives; independent judiciary
Government leader: Prime Minister George Borg Olivier
Suffrage: universal over age 21; registration required
Elections: last held in March 1966; next statutory election (1971)
Political parties and leaders: Nationalist Party George Borg Olivier (Prime
Minister); Malta Labor Party, Dom Mintoff; Christian Workers'' Party, Anthony
Pellegrini; Progressive Constitutional Party, Mabel Strickland; the Christian
Workers’ Party and the Progressive Constitutional Party, although without
representation in parliament, continue to publicize their views through
party organs and news conferences
Voting strength (1966 election): 48% Nationalist, 42% Malta Labor Party, 10% other
Member of: Commonwealth, Council of Europe, FAQ, GATT, ICAO, ILO, IMF, TDB, U.N.,
UNESCO, WHO
Legal name: Islamic Republic of Mauritania
Type: republic; one-party presidential rule since 1960
Capital: Nouakchott
Political subdivisions: 7 regions and a capital administration
Legal system: based on French civil law system and Islamic law; constitution
adopted 1961; judicial review of legislative acts in the Supreme Court;
has not accepted compulsory ICJ jurisdiction
Branches: president; unicameral National Assembly of 40 elected members ;
separate judiciary (appointed by president)
Government leader: President Moktar Ould Daddah
Suffrage: universal for adults
Elections: parliamentary elections held May 1965; uncontested presidential
election held August 1966; 5-year terms for both
Political parties and leaders: Mauritanian People''s Party is only legal party,
Secretary General Moktar Ould Daddah
Communists: no Communist Party; sympathizers exist, particularly for Chinese
Communists
Member of: EAMA, FAO, ICAO, ILO, IMCO, ITU, OAU, Organization of Riparian States
of the Senegal River (OERS), U.N., UNESCO, WHO, WMO
Legal name: Mauritius
Type: independent state since 1968, recognizing Elizabeth II
as chief of state
Capital: Port Louis
Political subdivisions: 5 “organized municipalities" and various island
dependencies
Legal system: based on French civil law system with elements of English common
law in certain areas; constitution adopted 6 March 1968
Branches: executive power exercised by Prime Minister and 15-man Council of
Ministers; unicameral legislature (National Assembly) with 62 members elected
by direct suffrage and 8 specially elected
Government leader: Prime Minister Dr. S. Ramgoolam
Suffrage: universal over age 2]
Elections: last held in August 1967; next scheduled in 1972 postponed at Jeast
4 years by constitutional amendment
Political parties and leaders: a loose government coalition consisting of Labor
Party (S. Ramgoolam), Muslim Committee of Action (A. R. Mohamed), and Parti
Mauricien Social Democrate (G. Duval); Independent Forward Bloc (S.
Bissoondoyal); Mauritius Democratic Union (M. Lesale); a few independents ;
Mouvement Militant Mauritian (P. Berenger)
Voting strength: Muslim Committee of Action, 6 seats; Independent Forward Bloc,
7 seats; Mauritius Labor Party, 32 seats; Mauritius Democratic Union, 12 seats;
Parti Mauricien Social Democrate, 10 seats; independent 2 seats; Mouvement
Militant Mauritian 1 seat
Communists: may be 2,000 sympathizers; several Communist organizations; Mauritius
Lenin Youth Organization, Mauritius Women''s Committee, Mauritius Communist
Party, Mauritius People''s Progressive Party, Mauritius Young Communist League,
Mauritius Liberation Front, Chinese Middle School Friendly Association,
Mauritius/USSR Friendship Society
Other political or pressure groups: Tamil United Party, Mauritius Workers Party
Member of: Commonwealth, OAU, OCAM, U.N.
209
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco-Ville
Political subdivisions: 4 sections
Legal system: based on French law; new constitution adopted 1962; has not
accepted compulsory ICJ jurisdiction
Branches: National Council (18 members); Communal Council (15 members, headed
by a mayor)
Government leader: Prince Rainier ITI
Suffrage: universal
Elections: National Council every 5 years; most recent 1968
Political parties and leaders: National Union of Independents, National Democratic
Entente (1965)
Voting strength: figures for 1968 election not available; (1958) 61% National
Union of Independents, 39% National Democratic Entente
Communists: not available
Member of: IAEA, IHB, ITU, U.N., UNESCO, UPU, WHO
Legal name: "Mongolian People''s Republic"
Type: Communist state
Capital: Ulaanbaatar
Political subdivisions: 18 provinces and 2 autonomous municipalities (Ulaanbaatar
and Darhan)
Legal system: blend of Russian, Chinese, and Turkish systems of law; constitution
adopted 1940; no constitutional provision for judicial review of legislative
acts; legal education at Ulaanbaatar State University; has not accepted
compulsory ICJ jurisdiction
Branches: constitution provides for a Great People''s Hural (national assembly)
and a highly centralized administration
Party and government leader: Y. Tsedenbal, First Secretary of the MPRP and
Chairman of the Council of Ministers
Suffrage: universal; age 18 and over
Elections: national assembly elections held in June 1969; next elections
scheduled for 1972
Political party: Mongolian People''s Revolutionary (Communist) Party (MPRP);
estimated membership, 48,500 (less than 5% of the population)
Member of: CEMA, ECAFE, U.N., WHO
Legal name: Republic of Portugal
Type: republic, with single legal party controlled by a Prime Minister
Capital: Lisbon
Political subdivisions: 18 districts in mainland Portugal and 4 “autonomous
districts" in Azores and Madeira Islands; 7 overseas provinces in Africa
and Asia
Legal system: civil law system; constitution adopted 1933, frequently amended
since; no judicial review of legislative acts; legal education at Universities
of Lisbon and Coimbra; accepts compulsory ICJ jurisdiction, with reservations
Branches: executive with President, Council of State, and Council of Ministers;
legislative with National Assembly dominated by executive and a Corporative
Chamber, the latter consultative and advisory; and judicial completely
controlled by executive branch
Government leader: Prime Minister Marcello Caetano, appointed September 1968
Suffrage: all citizens over age 21 who are literate and have not been deprived
of their civil rights
Elections: national elections for National Assembly held every 4 years, next to
be held in 1973; local parish board elections held every 4 years
Political parties and leaders: government-controlled National Popular Action
(ANP) -- formerly called National Union party -- only legally recognized
partys; Monarchist Cause group is tolerated by regime; various opposition
groups include -- Communist Party (PCP) whose secretary, Alvaro Cunhal, is
in exile; a Communist-affiliated exile group, Patriotic Front of National
Liberation (FPLN); Popular Action Front (FAP), a pro-Chinese Communist group
inactive since 1967; and several small non-Communist groups such as Democratic
Social Action (ADS); Portuguese Socialist Action (ASP) formed in July 1966,
leader Mario Soares; extremist opposition group, League of Revolutionary Union
and Action (LUAR), formed about November 1966, leader, Herminio de Palma
Inacio; Armed Revolutionary Action (ARA) is radical and violence-prone group
which appeared in October 1970 and claimed credit for several sabotage acts
Voting strength (1969 election): National Union, as ANP was then called, won all
130 seats in National Assembly in first contested election
Communists: 2,000-7,000 est.; sympathizers cannot be determined
257
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GOVERNMENT (cont''d):
Other political or pressure groups: Portuguese Legion, Portuguese Youth,
Association for the Study of Economic and Social Development (SEDES)
authorized in October 1970 as a discussion group with political overtones
Member of: EFTA, FAO, IAEA, IBRD, ICAO, IHB, ILO, IMF, ITU, NATO, OECD, U.N.,
UPU, WHO, WMO
Legal name: Province of Portuguese Guinea
Type: overseas province of Portugal
Capital: Bissau
Political subdivisions: 9 municipalities (concelhos-areas containing Europeans
and Educated Africans), 3 circumscriptions (predominantly indigenous population)
Legal system: based on Portuguese law
Branches: Governor General appointed by Ministry of Overseas has wide local
authority; he is assisted by an appointed Secretary-General and an 8-man
Government Council; a 15-member Legislative Council, 11 of whose members
are elected by various groups, represents economic and tribal interests of
province; Minister of Overseas can nullify any provincial legislation or
Governor''s decision; judiciary based on Portuguese system
Government leader: Governor General Antonio Sebastiao Ribeiro de Spinola
Political parties and leaders: National Popular Action Party of Portugal only
legal party; opposition parties (i]1legal) include Partido Africano da
Independencia da Guinee e Cabo Verde (PAIGC), led by Amilcar Cabral, a
Communist-supported nationalist party which is chief political force conducting
current rebellion against Portuguese rule and which operates mainly from
Republic of Guinea; Front de Lutte pour 1''Independence Nationale de la Guinee
(FLING), a loose coalition of Senegal-based nationalist elements opposed both
to the Portuguese and the PAIGC, leadership fragmented, headed by Benjamin
Pinto-Bull; other nationalist factions
Suffrage: limited to those satisfying fairly rigid economic and cul tural
requirements
Legal name: (The) Spanish State
Type: nominally a monarchy, but without a king; actually a dictatorship under
Generalissimo Franco with Prince Juan Carlos designated to succeed him as
chief of state and become king
Capital: Madrid
Political subdivisions: metropolitan Spain, including the Canaries and Balearics,
divided into 50 provinces with governors appointed by the central government;
also 1 province and 5 places of sovereignty (presidios) in Africa; Ifni
province ceded by Spain to Morocco in June 1969; 2 former provinces com-
prising Equatorial Guinea were granted independence in October 1968
Legal system: civil law system, with regional applications of customary law;
7 basic laws including Organic Law of the State of January 1967 serve as
a constitution; legal education at 14 schools of law; does not accept
compulsory ICJ jurisdiction
Branches: executive, with chief of government dominating all branches of
government through his appointive powers and authority to legislate by
decree; legislative with unicameral Cortes controlled by executive; judicial,
completely subservient and limited to interpretation of laws
Government leader: Generalissimo Francisco Franco -- who is also Chief of State,
Commander in Chief of the armed forces, and head of the National Movement
(formerly called the Falange)
Suffrage: universal in national referendums, over age 21
Elections: only two types of direct election other than referendum provided:
representatives to municipal councils for which only heads of households
vote and, under new constitutional law of 1967, 104 members of the Cortes
elected by heads of households and married women for a 4-year term
Political parties and leaders: National Movement (formerly called Falange) only
legally recognized party, headed by Franco; Torcuato Fernandez Miranda,
minister-secretary general of the movement; various semiclandestine opposition
groups include -- Christian Democratic factions under Jose Maria Gil Robles
and Joaquin Ruiz Gimenez; the Socialists, whose secretary general, Rodolfo
Llopis, is in exile; “Internal Socialists" under Enrique Tierno Galan; the
Anarchists; Republicans; Monarchists; smaller regional and national splinter
303
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GOVERNMENT (cont''d):
Political parties and leaders (cont''d):
groups; the Communist Party, whose secretary general, Santiago Carrillo
Solares, is in exile; and a pro-Chinese Communist faction Marxist-Leninist
Communist Party of Spain
Voting strength: 554 seats, but only 534 members as some hold more than one
seat -- 19% representing the family elected directly; 45% representing
municipalities, syndicates, and professions elected indirectly under close
regime control; and 36% are appointed by regime or are ex officio
Communists: (inside and outside Spain, est.) 5,000; sympathizers up to 20,000
Other political or pressure groups: the state-controlled organization of
syndicates, comprising representatives of management and labor, an illegal
labor group called the Workers'' Commissions, the Catholic Church, business
and land owning interests, Opus Dei, Catholic Action, university students
Member of: FAO, IAEA, IBRD, ICAO, ILO, IHB, IMF, ITU, OECD, U.N., UNESCO, UPU, *
WHO, WMO
Legal name: Province of Spanish Sahara
Type: province of Spain, subordinate to Ministry of the Presidency
Capital: E1 Aiun
Political subdivisions: two regions -- Rio de Oro and Saguia el Hamra
Legal system: based on Spanish civil law system and customary law
Branches: Provincial Council; 80 members, of whom half are elected natives
Government leader: Governor General responsible to Director General of African
Provinces in Madrid, (Br. Gen. Fernando de Santiago y Diaz de Mendivil)
Suffrage: heads of families only
Elections: 40 members of Provincial Council, August 1967; half of municipal
councillors May 1969
Political party: National Movement
Communists: party proscribed; Communist sympathizers, few (if any)
Other political or pressure groups: none
Legal name: Democratic Republic of the Sudan
Type: republic under military control since coup in May 1969
Capital: Khartoum
Political subdivisions: 9 provinces, provincial and local administrations
controlled by central government
Legal system: based on English common law and Islamic law; some separate
religious courts; constitution adopted 1956, suspended 1958, restored on an
interim basis in 1964; suspended with military coup in May 1969; Revolutionary
Command Council rules by Republic orders and other decrees; legal
education at University of Khartoum and extension of Cairo University at
Khartoum; accepts compulsory ICJ jurisdiction, with reservations
Government leader: RCC President and Prime Minister Ja''far al-Numayri
Suffrage: universal adult but franchise has not been exercised under present regime
Elections: parliamentary elections, first after 6 years of military rule held
in April and May 1965 in 6 northern provinces; latest elections in April
1968; military regime in power has not scheduled elections
Political parties and leaders: all parties outlawed since May 1969; the ban has
not been enforced on the Sudan Communist Party
Voting strength: not tabulated by party
Communists: 5,000-10,000; several thousand sympathizers; with supporters, obtained
dominant position in October 1964 transitional government and hastily formed
national front organization; main strength in labor unions, some professional
associations, and university student groups; Communists hold posts at all
levels of civil service
Member of: Arab League, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU, U.N.,
UPU, WMO
Legal name: Surinam
Type: territory within Kingdom of the Netherlands, enjoying complete domestic
autonomy
Capital: Paramaribo
Political subdivisions: 9 districts, each headed by district commissioner
responsible to Minister of Internal Affairs
Legal system: Dutch civil law system; country statute of 1955 serves as
constitution
Branches: Council of Ministers headed by a Minister-President, which constitutes
the Cabinet; 39-member legislative council (Staten) popularly elected for
4-year term; court system administered by Attorney-General under Minister
of Justice and Police
Government leader: Minister-President, Jules Sedney
Suffrage: universal over age 23
Elections: every 4 years or earlier upon request of Minister-President
Political parties and leaders: National Party of Surinam (NPS), (temporary
leader M. Ch. Calor); Party of the People''s Welfare (VHP), J. Lachmon; Action
Group (AG), R. Janki; Progressive National Party (PNP), Frank E. Essed;
Surinam Democratic Party (SDP), B. F. J. Oostburg; United Indonesian People''s
Party (SRI), F. Karsowidijojo; Javanese Farmers'' Party (KTPI), H. I. Soemita;
Nationalist Republic Party (PNR), Edward Bruma (principal leftist party)
Voting strength (1969): 27.7% NPS, 35.1% VHP, .2% AG, 23.3% PNP, 1.1% SDP, 3.4%
SRI, 8.8% other
Communists: no overt Communist Party
Member of: EEC (associate), WHO
Legal name: Kingdom of Swaziland
Type: constitutional monarchy, under King Sobhuza II; independent member of
Commonwealth since September 1968
Capital: Mbabane (administrative), Lobamba (royal and legislative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-Dutch law in statutory courts,
Swazi traditional law and custom in traditional courts; constitution
adopted in 1968; legal education at University of Botswana, Lesotho, and
Swaziland (located in Lesotho); has not accepted compulsory ICJ jurisdiction
Branches: executive authority vested in King but exercised through Prime Min-
ister and cabinet; cabinet appointed by King from legislative majority;
House of Assembly (24 elected, 6 appointed by King plus Speaker and Attorney
General) and Senate (6 elected by House of Assembly, 6 appointed by King,
Speaker) -- 17 Swazi courts administer customary law for Africans, High
Court and Subordinate Courts have criminal jurisdiction over all residents,
Court of Appeal has appellate jurisdiction
Government leader: Head of State King Sobhuza II; Prime Minister Makhosini
Dalmini
Suffrage: universal for adults
Elections: f','99edec14e07e2cb3a1c99307fe08689cbc0b348fa8eedb455fdb61334311183a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f8a63deaedf69d5abf312b8c99935c8b3ec6f0127d7ae00235e009589fbf0be',1971,'DZ','Algeria','government',11,'irst elections for Legislative Council held in June 1964; latest
in April 1967
Political parties and leaders: Imbokodvo, the traditionalist party, controlled
by King Sobhuza II; Ngwane National Liberatory Congress (NNLC), led by
Dr. Ambrose Zwane, is only active opposition
Voting strength: Imbokodvo won 80% of vote in 1967 elections and all seats in
parliament; NNLC won 20% of vote but no seats
Communists: no Swaziland Communist Party
Member of: OAU, U.N.
Legal name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 provinces, 624 communes , 224 towns
Legal system: civil law system influenced by customary law; Acts of 1809,
1886, 1910, and 1949 serve as constitution; judicial review of legislative
acts in Supreme Court; legal education at Universities of Lund, Stockholm,
and Uppsala; accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament (Riksdag) ;
executive power vested in Crown but exercised by cabinet responsible to
parliament; Supreme Court, 6 superior courts, 152 lower courts
Government leaders: King Gustav VI Adolf; Prime Minister Olof Palme
Suffrage: universal, but not compulsory, over age 20
Elections: every 3 years (next in 1973)
Political parties and leaders: Conservative, Gosta Bohman; Center, Gunnar
Hedlund; Liberal, Gunnar Helen; Social Democratic, Olof Palme; Communist,
Carl-Henrik Hermansson; Communist League of Marxists-Leninists (KFML), Gunnar
Bylin
Voting strength (1970 election): 11.5% Conservative, 19.9% Center, 16.2% Liberal,
45.3% Social Democratic, 4.8% Communist, 0.4% KFML, 1.8% other
Communists: 17,000; a number of sympathizers as indicated by the 236,700
Communist votes cast in 1970 elections; an additional 21,200 votes cast for
Maoist KFML
Member of: Council of Europe, EFTA, FAQ, GATT, IAEA, IBRD, ICAO, IDA, IFC, THB,
ILO, IMCO, IMF, ITU, Nordic Council, OECD, U.N., UNESCO, UPU, WHO, WMO
Legal name: Swiss Confederation
Type: federal republic
Capital: Bern
Political subdivisions: 22 cantons (3 divided into half cantons)
Legal system: civil law system influenced by customary law; constitution adopted
1874, amended since; judicial review of legislative acts, except with
respect to Federal decrees of general obligatory character; legal education
at Universities of Bern, Geneva and Lausanne, and four other university
schools of law; accepts compulsory ICU jurisdiction, with reservations
Branches: bicameral parliament has legislative authority; federal council
(Bundesrat) has executive authority; justice left chiefly to cantons
Government leader: Rudolf Gnaegi, President
Suffrage: universal over age 20
Elections: held every 4 years; next elections 1971
Political parties and leaders: Social Democratic Party (SPS), Fritz Gruetter,
president; Radical Democratic Party (FDP), Henri Schmitt, president;
Christian Conservative People''s Party (KCVP), Franz Josef Kurmann, president;
Farmer, Artisan, and Middle Class Party (BGBP), Hans Conzett, president;
Communist Party (PdA), Jacob Lechleiter, Jean Vincent, Andre Muret, all
Secretariat members
Voting strength (1967 election): 23.5% FDP, 21.9% KCVP, 24.1% SPS, 11.3% BGBP,
2.9% Communist, 16.3% other
Communists: 3,600; splinter parties 250; 28,521 votes in 1967 election
Member of: Council of Europe, EFTA, FAO, IAEA, ICAO, OECD, U.N. (permanent
observer), WHO, WMO, has applied for associate membership EEC
Legal name: Syrian Arab Republic
Type: republic; under left-wing military regime since March 1963
Capital: Damascus
Political subdivisions: 13 provinces and city of Damascus administered as
separate unit ;
Legal system: based on Islamic law and civil law system; special religious courts;
provisional constitution promulgated in 1964; legal education at Damascus
University and University of Aleppo; has not accepted compulsory ICJ
jurisdiction
Branches: legislative and executive powers vested in President and Council
of Ministers; seat of power is the Ba''th Party Regional (Syrian) Command
Government leaders: President Hafiz Al-Asad
Suffrage: universal over age 18
Elections: no electoral laws in force; last elections in December 1961; presidential
referendum in 1971
Political parties and leaders: Arab Socialist Resurrection (Ba''th) Party only
recognized party
Other political or pressure groups: all officially banned; conservative Populist
and Nationalist Parties have lost all effective political influence;
Communist Party ineffective; small pro-Nasir organizations (United Socialist
Movement, Arab National Front, Arab Nationalist Movement) constitute greatest
threat to Ba''thist regime aside from factionalism in Ba''th Party itself
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: United Republic of Tanzania
Type: republic; single parties dominate both on the mainland and on Zanzibar
Capital: Dar es Salaam
Political subdivisions: 23 regions ~- 19 on mainland, 4 on Zanzibar islands
Legal system: based on English common law, Islamic law, customary law, and German
civil law system; interim constitution adopted 1965; judicial review of
legislative acts limited to matters of interpretation; legal education at
University College, Dar es Salaam; has not accepted compulsory ICJ jurisdiction
Branches: President Julius Nyerere has full executive authority; National Assembly
dominated by Nyerere and the Tanganyika African National Union (TANU), consists
of 120 elected members, 17 ex officio members, and up to 25 appointed members
from mainland, and 3 ex officio members and up to 52 appointed members from
Zanzibar; First Vice President Abeid Karume and the Revolutionary Council
still run Zanzibar despite the efforts of Nyerere to integrate the islands
into the political system of the mainland
Government leader: President Julius Nyerere
Suffrage: universal adult
Political party and leaders: Tanganyika African National Union (TANU), only main-
land political party, dominated by Nyerere with Second Vice President Rashidi
Kawawa as his top lieutenant; Karume''s Afro-Shirazi Party in Zanzibar is
Supposed to merge with TANU eventually
Voting strength (October 1970 national elections): 5 million registered voters;
Nyerere received 95% of 3.6 million votes cast
Communists: a few Communists and sympathizers
Member of: Commonwealth, EAC, FAQ, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions: 71 centrally controlled provinces
Legal system: based on civil law system, with influences of common law; new
constitution promulgated in 1968; legal education at Thammasat University;
has not accepted compulsory ICJ jurisdiction
Branches: King is head of state with nominal powers; Prime Minister, with strong
personal powers, assisted by Council of Ministers (cabinet); bicameral
legislature consists of appointed Senate and elected House of Representatives ;
judiciary relatively independent except in important political subversive
cases
Government leaders: King Phumiphon Adundet; Field Marshal Thanom Kittikachorn,
Prime Minister; General Praphat Charusathien, Deputy Prime Minister
Suffrage: universal
Elections: House of Representatives every 4 years; first under new constitution
held mid-February 1969
Member of: ADB, ASA, ASEAN, ASPAC, Colombo Plan, ECAFE, FAO, IAEA, ICAO, IDA,
IFC, IHB, ILO, ITU, SEAMES, SEATO, U.N., UNESCO, UNICEF, UPU, WHO, WMO
Legal name: Republic of Togo
Type: republic; under military rule since January 1967
Capital: Lome
Political subdivisions: 18 circumscriptions
Legal system: based on French civil law and customary practice; draft constitution
presented to President in 1968, no indication of when it will be submitted
to referendum; has not accepted compulsory ICJ jurisdiction
Branches : military government, with civilian participation in the cabinet, took
over on 14 April 1967, replacing provisional government created after
January coup; no legislature; separate judiciary including State Security
Court established 1970
Government leader: Brig. Gen. Etienne Eyadema, President
Suffrage: universal adult
Elections: no elections since 1963 and none scheduled
Political parties: single party formed by President Eyadema in September 1969;
Rassemblement de Peuple Togolais, structure and staffing of party closely
controlled by government
Communists: no Communist Party; there may be a few Communists and sympathizers
Member of: EAMA, ENTENTE, FAO, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM, U.N
UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Tonga
Type: constitutional monarchy
Capital: Nukualofa
Political subdivisions: 3 main island groups (Tongatapu, Haapi, Vavau)
Legal system: based on English law
Branches: Executive (King and Privy Council); Legislative (Legislative Assemb ly
composed of 7 nobles elected by their peers, 7 elected representatives of
the people, 7 Ministers of the Crown; the King appoints one of the 7 nobles
to rae speaker); Judiciary (Supreme Court, magistrate courts, Land
Court
Government leaders: King Taufa''ahau Tupou IV; Premier, Prince Tu''ipelehake
(younger brother of the King)
Suffrage: granted to all literate adults over 21 years of age who pay taxes
Elections: held triennially
Communists: none known
Member of: Commonwealth
Legal name: Trinidad and Tobago
Type: independent state since August 1962; recognizes Elizabeth II as chief
of state
Capital: Port of Spain
Political subdivisions: 8 counties (29 wards, Tobago is 30th)
Legal system: based on English common law; constitution came into effect
1962; judicial review of legislative acts in the Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: legislative branch consists of 36-member elected House of
Representatives and 24-member Senate (13 nominated by Prime Minister,
4 by opposition leader, 7 at discretion of Governor General); executive is
cabinet led by the Prime Minister; judiciary is Supreme Court
Government leader: Prime Minister, Dr. Eric Williams
Suffrage: universal over age 21
Elections: last election 7 November 1966
Political parties and leaders: People''s National Movement (PNM), Dr. Eric
Williams; Democratic Labor Party (DLP), Vernon Jamadar; People''s Democratic
Party (PDP), Bhadase Sagan Maraj; Liberal Party (LP), Peter Farquhar; Workers
and Farmers Party (WFP), (Marxist-oriented) Stephen Maharaj; United
National Independence Party, James Millette
Voting strength (1966 election): 52.3% PNM, 34% DLP, 8.9% LP, 3.5% WFP, 1.3%
other
Communists: not significant
Other political pressure groups: Tapia House Group (headed by Lioyd Best);
National Youth Congress (NYC); Oilfield Workers Trade Union (OWTU), pro-
Marxist leadership; National Joint Action Committee (NJAC), antigovernment,
extremist organization
Member of: CARIFTA, Commonwealth, GATT, IBRD, ICAO, IDB, IMF, OAS, U.N.
Legal name: Trucial States (7 amirates)
Type: ruled by traditional leading families; protected states of U.K.
Legal system: based on Islamic law with ultimate appeal to the Sheikh; some
influence of English common law in commercial matters
States and rulers: Abu Dhabi, Zayid ibn Sultan; ‘Ajman, Rashid ibn Humayd;
Dubai, Rashid ibn Sa''id; Fujairah, Muhammad ibn Hamad; Ras al Khaimah,
Saqr ibn Muhammad; Sharjah, Khalid ibn Muhammad; Umm al Qaiwain, Ahmad
ibn Rashid
Legal name: Republic of Tunisia
Type: republic
Capital: Tunis
Political subdivisions: 13 governorates (provinces)
Legal system: based on French civil law system and Islamic law; constitution
patterned on Turkish and U.S. constitutions adopted 1959; some judicial
review of legislative acts in the Supreme Court in joint session; legal
education at Institute of Higher Studies and Ecole Superieure de Droit in
Tunis; has not accepted compulsory ICJ jurisdiction
Branches: executive dominant; unicameral legislative largely advisory; judicial,
patterned on French system and Koranic law
Government leader: President Habib Bourguiba; Prime Minister Heidi Novira
Suffrage: universal over age 21
Elections: national elections held every 5 years; last elections 2 November 1969
Political party and leader: Destourian Socialist Party, Habib Bourguiba
Voting strength (1969 election): 100% Destourian Socialist Party
Communists: 250; a few sympathizers; Tunisian Communist Party proscribed in 1962
Member of: Arab League, EEC (association until 1974), FAO, IAEA, IBRD, ICAO, IDA,
IFC, ILO, IMCO, IMF, ITU, OAU, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Cevdet Sunay, Prime Minister Nihat Erim
Suffrage: universal over age 21
Elections: National Assembly (1973)
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party (RPP), Ismet Inonu; Democrats Party (DP), Ferruh Bozbeyli;
Reliance Party (RP), Turhan Feyzioglu; New Turkey Party (NTP), Yusuf Azizoglu;
Nationalist Movement Party (NMP), Alparslan Turkes; Nation Party (NP), Osman
Bolukbasi; Turkish Labor Party (TLP), Behice Boran; Unity Party (UP), Mustafa
Timisi; Communist Party illegal; National Order Party (NOP), Necmettin Erbakan
Voting strength: 1969 National Assembly elections -- 46.6% JP, 27.5% RPP, 3.3%
NP, 2.2% NTP, 2.6% TLP, 5.7% independent, 6.4% RP, 3.1% NMP, 2.5% UP; 1968
Senatorial elections (1/3 of Senate seats) -- 49.9% JP, 27.1% RPP, 6.0% NP,
8.5% RP, 4.7% TLP, 2.0% RPNP
Communists: strength and support negligible
Member of: CENTO, Council of Europe, EEC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECD, Regional
Cooperation for Development, U.N., UNESCO, UPU, WHO, WMO
335
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Republic of Uganda
Type: republic independent since October 1962
Capital: Kampala
Political subdivisions: 20 districts
Legal system: based on English common law and customary law; constitution
adopted 1967; judicial review of legislative acts; legal education at
Makerere University, Kampala; accepts compulsory ICJ jurisdiction, with
reservations
Branches: Gen. Amin rules by decree; assisted by Council of Ministers
Government leader: President Gen Idi Amin
Suffrage: universal adult
Elections: none scheduled by military government
Political party and leader: Uganda People''s Congress (UPC), principal party
before 1971 coup, not banned but inactive
Communists: possibly a few sympathizers
Member of: Commonwealth, EAC, IAEA, ICAO, ILO, OAU, U.N., UNESCO, WHO
Legal name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow
Political subdivisions: 15 union republics, 20 autonomous republics, 6 krays,
114 oblasts, and 8 autonomous oblasts
Legal system: civil law system as modified by Communist legal theory; consitution
adopted 1936; no judicial review of legislative acts; legal education at 18
universities and 4 law institutes; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers (executive), Supreme Soviet (legislative), Supreme
Court of U.S.S.R. (judicial)
Government leaders: Leonid I. Brezhnev, General Secretary of the Central Committee
of the Communist Party; Aleksey N. Kosygin, Chairman of the Council of
Ministers; Nikolay V. Podgornyy, Chairman of the Presidium of the U.S.S.R.
Supreme Soviet
Suffrage: universal over age 18; direct, equal
Elections: to Supreme Soviet every 4 years; 1,517 deputies elected in 1970;
72.3% party members
Political parties and leaders: Communist Party of the Soviet Union (CPSU) only
party permitted
Voting strength (1970 election): 153,237,112 persons over 18; claimed 99.96%
voted
Communists: 14 million
Other political or pressure groups: Komsomol, trade unions, and other organizations
which facilitate Communist control
Member of: CEMA, IAEA, ICAO (has applied for membership), ILO, IMCO, ITU, U.N.,
UNESCO, UPU, Warsaw Pact, WHO, WMO
Legal name: United Arab Republic
Type: republic; under presidential rule since June 1956
Capital: Cairo
Political subdivisions: 25 governorates
Legal system: based on English common law, Islamic law, and Napoleonic codes;
interim constitution of 1964; judicial review of limited nature in Supreme
Court, also in Council of State which oversees validity of administrative
decisions; legal education at Cairo University; accepts compulsory ICJ
jurisdiction, with reservations
Branches: executive power vested in President, who appoints cabinet; National
Assembly has little actual power (serves mainly for discussion and automa-
tic approval); independent judiciary administered by Minister of Justice
Government leader: Anwar Sadat
Suffrage: universal over age 18
Elections: elections to National Assembly every 5 years (most recent January
1969); presidential elections every 6 years
Political parties and leaders: political parties banned; all candidates for
election must be members of Arab Socialist Union, the only officially
sanctioned sociopolitical grouping
Member of: AAPSO, Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO,
IMF, ITU, OAU, U.N., UNESCO, UPU, WHO, WMO, WPC
Legal name: Republic of Upper Volta
Type: republic; transitional military regime in power since January 1966, will
rule until 1974
Capital: Ouagadougou
Political subdivisions: 5 departments consisting of 44 cercles
Legal system: based on French civil law system and customary law; constitution
adopted 1970; judicial review of legislative acts in Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: President is an army officer; 57-man National Assembly was elected in
December 1970; 4 year transition period will follow during which President
will rule over 15-man cabinet, one-third of which will be military; separate
judiciary
Government leader: President Gen. Sangoule Lamizana
Suffrage: universal for adults
Elections: National Assembly elections were in late December 1970; RDA-UDV won
37 seats, PRA 12, MLN 6; Prime Minister Gerard Kango Ouedraogo; of voters
officially reported as approving unopposed candidates of former Yameogo
regime; next elections scheduled for 1970
Political parties and leaders: 7 legally recognized parties; Voltan Democratic
Union-African Democratic Rally (UDV_RDA)., Gerard Kango Quedraogo; African
Regroupment Party (PRA), Diongolo Traore; Movement for National Liberation
(MLN); People''s Action Group (GAP), Nohoun Sigue; Union for the New Voltaic
Republic (UNR), Blaise Bassoleth; Party of National Regroupment (PRN),
Francois Bassolet; Party of Voltan Workers (PTV), George Kabore
Communists: possibly some Communists and sympathizers
Other political or pressure groups: labor organizations are badly splintered
Member of: EAMA, ENTENTE, FAO, ICAO, ILO, ITU, OAU, OCAM, U.N., UNESCO, WHO, WMO
Legal name: Oriental Republic of Uruguay
Type: republic
Capital: Montevideo
Political subdivisions: 19 departments with limited autonomy
Legal system: based on Spanish civil law system; new constitution implemented
1967; judicial review of legislative acts in Supreme Court, legal education
at University of the Republic at Montevideo; accepts compulsory ICJ
jurisdiction
Branches: executive, headed by President; bicameral legislature (30 Senators
plus Vice President who presides and has voice and vote, and 99-member
Chamber of Deputies) elected by popular vote under a complicated system
using proportional representation; national judiciary headed by Supreme
Court
Government leader: President Jorge Pacheco Areco
Suffrage: universal over age 18
Elections: every 5 years; next in 197]
Political parties and leaders: National (Blanco) Party, President of Party
Directorate Alberto Heber Usher, main factions include Martin Echegoyen''s
"Alianza" faction, List 400 (Washington Beltran), Rocha Movement (Alberto
Gallinal), Orthodox Herreristas (Alberto Heber Usher), and Por La Patria
(Wilson Ferreira Aldunate); Colorado Party, main factions include Colorado
and Batllista Union (Jorge Pacheco Areco), List 15 (Jorge Batlle), List 315
(Amilcar Vasconcellos); Broad Front (Frente Amplio), leftwing coalition of
dissident factions from both the Blanco and Colorado parties, and including
FIDEL, the Christian Democrats, and other splinter groups; Leftist Liberation
Front (FIDEL), Communist Front
Voting strength (1966 elections): 49.3% Colorado, 40.3% Blanco, 5.7% FIDEL,
3% Christian Democrat, 0.9% Socialists, 0.8% other
Other political or pressure groups: Communist Party (PCU), Rodney Arismendi;
Christian Democratic Party (PDC); Socialist Party of Uruguay (PSU); Movement
of the Revolutionary Left (MIR), pro-Chinese Communist party; Revolutionary
Movement of Uruguay (MRO) pro-Cuban Communist Party; National Liberation
Movement (MLN-Tupamaros) Marxist Revolutionary terrorist group
Member of: IADB, IAEA, IBRD, ICAO, ILO, IMF, LAFTA, OAS, U.N.
347
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes St. Peter''s, the Vatican Palace
and Museum and neighboring buildings covering: more than 13 acres; 13
buildings in Rome, although outside the boundaries, enjoy extraterritorial
rights
Legal system: Canon law; constitutional laws of 1929 serve some of the functions
of a constitution
Branches: the Pope possesses full executive, legislative, and judicial powers;
he delegates these powers to the governor of Vatican City, who is subject
to pontifical appointment and recall; high Vatican offices include the
Secretariat of State, the College of Cardinals (chief papal advisers), the
Roman Curia (which carries on the central administration of the Roman
Catholic Church) the Presidence of the Prefecture for the Economy, and
the synod of bishops (created in 1965)
Government leader: Supreme Pontiff, Paul VI, (Giovanni Battista Montini, born
26 September 1897, elected Pope 21 June 1963)
Suffrage: limited to cardinals
Elections: Supreme Pontiff elected for life by College of Cardinals
Communists: none known
Other political parties and pressure groups: none (exclusive of influence
exercised by other church officers in universal Roman Catholic Church)
Member: IAEA
Legal name: Republic of Venezuela
Type: republic
Capital: Caracas
Political subdivisions: 20 states, 1 federal district, 2 federal territories
Legal system: based on Spanish civil law system with influence of U.S. law;
constitution promulgated 1961; judicial review of legislative acts in
Cassation Court only; dual court system, state and federal; legal education
at Central University of Venezuela; has not accepted compulsory ICJ
jurisdiction
Branches: executive (President), bicameral legislature, judiciary
Government leader: President Rafael Caldera
Suffrage: universal and compulsory over age 18
Elections: every 5 years; most recent December 1968
Political parties and leaders:','8de36d7c594b1641abe9bc792ff41e26a4b53c82fde907253f88919612b30913','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a516f5313d55cac63d0a822eec3a0384a9caca8eba85ec3fb74e0cd0f0107146',1971,'DZ','Algeria','government',12,'Accion Democratica {AD), Gonzalo Barrios; Comite
por Organizacion Electoral Independiente (COPEI), known as Social Christian
party, Rafael Caldera; Popular Electoral Movement (MEP), Luis Beltran Prieto;
Cruzada Civica Nacional (CCN), Marcos Perez Jimenez, leader, and Luis
Damiani, president; Union Republicana Democratica (URD), Jovito Villalba;
Partido Comunista de Venezuela (PCV), Secretary-General Jesus Faria;
Movimiento Izquierdista Revolucionario (MIR), political activities suspended
by government, several leaders; Fuerza Democratica Popular (FDP), Wolfgang
Larrazabal resigned without replacement; Frente Nacional Democratico (FND),
Pedro Segnini La Cruz; Partido Revolucionario Izquierdista Nacionalista
(PRIN), Jose Manzo Gonzalez and Domingo Alberto Rangel
Voting strength (1968 election): 25.6% AD, 24.1% COPEI, 10.9% CCN, 9.3% URD,
5.3% FDP, 2.8% Union for Advancement (Communist front), 2.6% FND, 2.3% PRIN
Member of: FAO, IADB, IAEA, IBRD, ICAO, IDB, IFC, ILO, ITU, OAS, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Democratic Republic of Vietnam
Type: Communist state
Capital: Hanoi
Political subdivisions: 2 autonomous regions (of 3 and 5 provinces, respectively),
17 other provinces, 2 centrally governed municipalities, 1 special zone
Legal system: based on Communist legal theory and French civil law system;
constitution enacted 1960
Branches: constitution provides for a National Assembly and highly centralized
executive nominally subordinate to it
Party and government leaders: Le Duan, First Secretary; Ton Duc Thang, President
of DRV; Pham Van Dong, Premier; Truong Chinh, Chairman, Standing Committee
of National Assembly; Vo Nguyen Giap, Minister of National Defense
Suffrage: over age 18
Elections: pro forma elections held for national and local assemblies
Political parties: ruled by Lao Dong Party with no organized opposition;
membership approximately 900,000 (about 4% of population)
Legal name: Republic of Vietnam
Type: republic
Capital: Saigon
Political subdivisions: 4 regions (corresponding to 4 military regions), 1 special
region (corresponding to Capital Special Zone), divided into 44 provinces
and 11 autonomous municipalities
Legal system: based on French civil law system; legal education at Universities
of Saigon and Hue
Branches: constitution provides for modified presidential system with executive,
legislative, and judicial branches
Government leaders: President Nguyen Van Thieu; Vice President Nguyen Cao Ky;
Prime Minister Tran Thien Khiem
Elections: Presidential elections slated for October 1970
Political parties and leaders: numerous small parties reflecting an emphasis on
personal leadership rather than ideological content; parties supporting
government and opposition groups are fragmented and poorly organized;
pro-government parties include two old-line political parties (Revolutionary
Dai Viet and Vietnamese Nationalist-VNQDD) and several:Catholic parties; An
Quang (militant) Buddhists are an important opposition group; the independent
Aggressive Nationalist Movement has considerable strength in the southern
part of the country; Hoa Hao and Cao Dai politico-religious sects exert
strong influence in local areas
Communists: The People''s Revolutionary Party operates through and within the
National Front for the Liberation of South Vietnam (NLFS and the Alliance of
National, Democratic, and Peace Forces (ANDPF), and the Provisional Revolu-
tionary Government (PRG) designed to rival the legal government
Member of: Colombo Plan, FAQ, IAEA, ICAO, ILO, IMCO, ITU, U.N. (certain specialized
U.N. agencies and maintains observer team), UNESCO, UPU, WHO, WMO
355
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2','e19bf955dce16b715dde3083faf7a4454ff8aa7c14a1db9fd794258957c92111','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ded707545a43b2e662131422c6549cea619198245f32992ec4fc872d5a9341a',1971,'BR','Brazil','government',29,'Legal name: Republic of Ecuador
Type: republic
Capital: Quito
Political subdivisions: 19 provinces and 1 territory (Galapagos Islands)
Legal system: based on civil law system; modified 1946 Constitution replaced
1967 Constitution in June 1970, legal education at 4 state and 2 private
universities; has not accepted compulsory ICU jurisdiction
Branches: President and bicameral legislature elected in June 1968, under 1967
constitution; legislature closed following assumption of dictatorial power
by Velasco on 23 June 1970; judiciary
Government leader: President Jose Maria Velasco
Suffrage: all literate over age 18; compulsory
Elections: next presidential and congressional, June 1972
Political parties and leaders: National Velasquista Front, Jose Maria Velasco;
Radical Liberal Party, Ignacio Hidalgo Villavicencio; Social Christian Party,
Camilo Ponce; Conservative Party, Galo Pico Mantillas; Concentration of
Popular Forces, Assad Bucaram; National Revolutionary Party, Carlos Julio
Arosemena
Voting strength: in June 1968 national elections, Velasquistas, a center-left
coalition, and a rightist coalition each got approximately one-third
Member of: ECOSOC, IADB, IAEA, ICAO, LAFTA and Andean Sub-Regional Group
(formed in May 1969 within LAFTA), OAS, U.N.
Legal name: Republic of E] Salvador
Type: republic
Capital: San Salvador
Political subdivisions: 14 departments
Legal system: based on Spanish law, with traces of common Taw; constitution
adopted 1962; judicial review of legislative acts in the Supreme Court;
legal education at University of E] Salvador; accepts compulsory ICJ
jurisdiction, with reservations
Branches: traditionally dominant executive, unicameral legislature, Supreme
Court
Government leader: President Fidel Sanchez Hernandez
Suffrage: universal over age 18
Elections: legislative elections every 2 years; presidential elections every 5
years; legislative and municipal elections March 1972, presidential elections
May 1972
Political parties and leaders: National Conciliation Party (PCN), President
Fidel Sanchez Hernandez, Dr. Enrique Mayorga Rivas, Rafael Rodriguez
Gonzalez, Dr. Francisco Jose Guerrero; Christian Democratic Party (PDC),
Dr. Pablo Mauricio Alberque, Roberto Lara Velado; Dr. Abraham Rodriguez,
Jose Napoleon Duarte; Revolutionary Party (PR -- formerly Renovating Action
Party), not legally recognized, Shafick Handal, Dr. Fabio Castillo Figueroa,
Julio Ernesto Contreras; Salvadoran Popular Party (PPS), Benjamin Wilfredo
i Navarrete, Dr. Rafael Antonio Carbello, Dr. Jose Antonio Guzman; Communist
we Party of El Salvador (PCES), illegal, Jorge Shafick Handal, Raul Castellanos
e Figueroa; National Revolutionary Movement (MNR), Dr. Guillermo Manuel Ungo,
Italo Lopez Vallecillos, Rodrigo Antonio Gamero, National Democratic Union
ats (PUDN), Francisco Roberto Lima, Julio Ernesto Contreras, Julio Castro
: Belloso
ba Voting strength: March 1967 presidential election -- PCN 54.4%, PDC 21.6%,
PAR 14.4%, PPS 9.6%; March 1970 legislative election -- PCN 60%, PDC 27%,
PPS 5%, MNR 2%, PUDN 6%
Other political or pressure groups: the "14" prominent families; General
Confederation of Trade Unions (CGS); Unifying Federation of Salvadoran
Trade Unions (FUSS), Communist dominated; Federation of Construction and
Transport Workers Unions (FESINCONSTRANS), independent; Catholic Church;
the military; Salvadoran National Association of Educators (Andes)
Member of: Central American Common Market, IADB, IAEA, OAS, ODECA, U.N.
89
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Republic of Equatorial Guinea
Type: republic, one-party presidential regime since 1968
Capital: Santa Isabel, Fernando Po
Political subdivisions: 2 provinces (Fernando Po and Rio Muni)
Branches: elected President has strong executive power; elected Assembly of
the Republic; elected Provincial Councils with broad responsibilities for
administrative and social affairs; Council of Republic (3 members elected
by each Provincial Council) has powers of judicial review, mediates disputes
between executive and legislative branches and between national provincial
governments; judiciary includes Supreme Court
Government leader: President Francisco Macias Nguema
Suffrage: universal age 21 and over
Elections: national and provincial elections held September 1968
Political parties and leaders: in January 1970 government abolished the five
political parties existing at time of independence and the Council of
Ministers approved the creation of the National Unity Party (PUN)
Communists: no significant Communist activity
Member of: IBRD, IMF, OAU, U.N.
Legal name: Empire of Ethiopia
Type: constitutional monarchy, but in effect an absolute monarchy
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred to as governorates -general] )
Legal system: complex structure with civil, Islamic, common and customary law
influences; constitution adopted 1955; no specific constitutional provision
for review by courts but all legislation inconsistent with the constitution
is declared null and void; legal education at Haile Selassie I University;
has not accepted compulsory ICJ jurisdiction
Branches: Emperor is all-powerful, with advisory cabinet and Prime Minister;
legislature composed of elected Chamber of Deputies and appointed Senate;
judiciary at higher levels based on Western pattern, at lower levels on
traditional pattern, without jury system in either
Government leader: Emperor Haile Selassie I
Suffrage: universal over age 21
Political parties and leaders: only amorphous reform groups especially among
younger, better educated Ethiopians
Member of: ECA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UPU,
WHO, WMO
Legal name: The Faeroe Islands
Type: self-governing province within the Kingdom of Denmark; 2 representatives
in Danish parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, 1 town
Legal system: based on Danish law; Home Rule Act enacted 1948
Branches: legislative authority rests jointly with Crown, acting through appointed
High Commissioner, and provincial parliament (Lagting) in matters of strictly
Faeroese concern; executive power vested in Crown, acting through High
Commissioner, but exercised by provincial cabinet responsible to provincial
parliament
Government leaders: King Frederick IX; Prime Minister, Atli Dam
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years; next election 1974
Political parties and leaders: Peoples, Hakun Djurhuus; Republican, Erlendur
Patursson; Home Rule, Samuel Petersen; Progressive, Kjartan Mohr; Social
Democratic, Atli Dam; Union, Kristian Djurhuus
Voting strength (1970 election): Peoples 20.0%, Republican 20.0%, Home Rule
5.6%, Progressive 3.5%, Social Democratic 27.2%, Union 21.7%
Member of: Nordic Council
Legal name: Crown Colony of the Falkland Islands
Type: British crown colony
Capital: Port Stanley
Political subdivisions: local government is confined to capital
Legal system: English common law
Branches: Governor, Executive Council, Legislative Council
Government leader: Governor and Commander in Chief Sir Cosmo Haskard (also
High Commissioner for British Antarctic Colony)
Suffrage: universal
Legal name: The Commonwealth of Fiji
Type: independent state.since 1970
Capital: Suva
Political subdivisions: 14 provinces
Legal system: based on British
Branches: executive -- Prime Minister; legislative -- existing colonial Legis-
lative Council to continue as first House of Representatives, first elections
probably in 1971, to elect a 52-member House of Representatives, there will
also be a 22-member appointed Senate (interim solution of equal representa-
tion for Fijians and Indians); problem of ethnic representation to be
examined and settled before second elections
Government leader: Prime Minister Ratu Sir Kanisese Mara
Suffrage: universal adult
Elections: every 5 years unless House dissolves earlier
Political parties: Alliance, primarily Fijian, headed by Ratu Mara; National
Federation, primarily Indian, headed by S. M. Koya
Communists: few, no figures available
Member of: Commonwealth, U.N.
Legal name: Republic of Finland
Type: republic
Capital: Helsinki
Political subdivisions: 12 provinces; 443 communes, 78 towns
Legal system: civil law system based on Swedish law; constitution adopted 1919;
Supreme Court may request legislation interpreting or modifying laws; legal
education at Universities of Helsinki and Turku; accepts compulsory ICJ
jurisdiction, with reservations
Branches: legislative authority rests jointly with President and parliament
(Eduskunta); executive power vested in President and-exercised through
cabinet responsible to parliament; Supreme Court, 4 superior courts,
193 lower courts
Government leader: President Urho K. Kekkonen; Prime Minister Ahti Karjalainen
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1974); presidential, every
6 years (next in 1974)
Political parties and leaders: Social Democratic, Rafael Paasio; Center,
Johannes Virolainen; Peoples Democratic League (Communist front), Ele
Alenius; Conservative, Harri Holker; Liberal, Pekka Tarjanne; Swedish Peoples,
Jan-Magnus Jansson; Rural, Veikko Vennamo; Social Democratic League,
Uuno Nokelainen; Communist, Aarne Saarinen
Voting strength (1970 election): 23.4% Social Democratic, 17.1% Center, 16.6%
Peoples Democratic League, 18.0% Conservative, 6.0% Liberal, 5.6% Swedish
Peoples, 10.5% Rural, 1.4% Social Democratic League, 14% other
Communists: 47,000; an additional 65,000 persons belong to Peoples
Democratic League; a further number of sympathizers, as indicated by
421,000 votes cast for Peoples Democratic League in 1970 elections
Member of: EFTA (associate), FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO,
IMCO, IMF, ITU, Nordic Council, OECD, U.N., UNESCO, UPU, WHO, WMO','3a791ffe0d1af01b3b31ef913a5afcd711c6713e5a8ba2385e78cfd04a269c42','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce621e0c123f24549bdb6d4199d03c5f4c15e781e86b964603eaf88441b08c09',1971,'LY','Libya','government',32,'Legal name: French Republic
Type: republic, with president having wide powers
Capital: Paris
Political subdivisions: 95 departments, 21 "regional action districts”
Legal system: civil law system with indigenous concepts; new constitution
adopted 1958, amended concerning election of President in 1962; judicial
review of administrative but not legislative acts; legal education at over
25 schools of law; accepts compulsory ICJ jurisdiction, with reservations
Branches: presidentially appointed Prime Minister heads Council of Ministers,
which is formally responsible to National Assembly; bicameral jegislature
-- National Assembly (487 members), Senate (273 members) restricted to a
delaying action; judiciary independent in principle
Government leader: President Georges Pompidou
Suffrage: universal over age 21; not compulsory
Elections: National Assembly -- every 5 years, last election June 1968, direct
universal suffrage, 2 ballots; Senate -- indirect collegiate system for 9
years, renewable by one-third every 3 years; President -- direct, universal
suffrage every 7 years, 2 ballots, last election June 1969
Political parties and leaders: Union of Democrats for the Republic (UDR), Rene
Tomasini; Independent Republicans, Valery Giscard d''Estaing; Communist (PCF),
Waldeck Rochet, George Marchais (acting); Progress and Modern Democracy (PDM),
Jacques Duhamel; Radical Socialists, Maurice Faute; Socialist Party, Alain
Savary; United Socialist Party (PSU), Michel Rocard
Voting strength (first ballot, 1968 election): 43.6% UDR, 20% PCF, 16.5%
Federation of Democratic and Socialist Left (grouping of parties of left),
10.3% Center, 9.6% other
Communists: 250,000-300,000 (est.); Communist voters, 5 million average
Other political or pressure groups: Communist-controlled labor union
(Confederation Generale du Travail) nearly 1,000,000 members (est.),
National Council of French Employers (Conseil National de Patronat
Francais -- CNPF or Patronat)
Member of: Council of Europe, EEC, ECSC, EURATOM, FAO, IAEA, IBRD, ICAO, IHB,
ILO, IMCO, IMF, ITU, NATO (signatory), OECD, SEATO, South Pacific Commission,
U.N., UNESCO, UPU, WEU, WHO, WMO
103
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Overseas Department of French Guiana
Type: overseas department of France; represented by one deputy in French National
Assembly and one senator in French Senate; not used as penal colony since 1945
Capital: Cayenne
Political subdivisions: 2 arrondissements, alternately termed territories (coastal
Territoire de la Guyane and interior Territoire de 1''Inini); 14 communes with
locally elected municipal councils within each territory
Legal system: based on Napoleonic codes; court of first instance in Cayenne and
a Superior Court of Appeal
Branches: popularly elected 15-member General Council advises Paris-appointed
Prefect, Jean Monfraix
Government leader: Prefect
Suffrage: universal over age 21
Elections: General Council elections coincide with those for the French National
Assembly, normally every 5 years; last election March 1967
Political parties and leaders: Parti Socialiste Guyanais (PSG), Leopold Heder;
Union Progressiste Guyanaise (UPG), weak, leftist allied with, but also
reported to have been absorbed by, the PSG; Mouvement Populaire Guyanais
(MPG), Hector Rivierez, Gaullist, delegate to French National Assembly
Communists: UPG includes Communist sympathizers, but has little measurable
following','fd8eefc763ba8fa58abb14fcf99585eeceae8588dc56b5da0c107c3ef7a6d080','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90f1ae8eb3757e834b5f0dbc23c65710d8f9e07cb53f79594d2ae028895151dd',1971,'GP','Guadeloupe','government',38,'Legal name: French Territory of Afars and Issas
Type: overseas territory of France; represented by one deputy in French National
Assembly and by one senator in French Senate
Capital: Djibouti
Legal system: based on French civil law system and customary law
Branches: President of Council of Government; 8-member Council of Government
appointed by 32-member Chamber of Deputies; ultimate political authority
exercised by Paris-appointed President of the Council of Government, some-
times referred to as Prime Minister
Government leader: Ali Aref Bourhan
Suffrage: universal
Elections: Chamber of Deputies election held November 1968
Political parties and leaders: Parti du Mouvement Populaire, Moussa Ahmed Idriss;
Rassemblement Democratique Afar, Ali Aref Bourhan; Union Democratique Afar,
Mohamed Kamil; Union Populaire Africaine, Hassan Guled','a7e3beb796eaeae249994660b143c623ad438cad3def54e7dad3868f09aa4101','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2554deada7c21c15a32108bf3018464a9973969af60eb72f36b3bfbde6a37c5f',1971,'CO','Colombia','government',41,'Legal name: Overseas Department of Guadeloupe; Overseas Department of Martinique
Type: overseas departments of France; each represented by 3 deputies in the
French National Assembly and 2 deputies in the Senate
Capital: Fort de France (Martinique); Basse-Terre (Guadeloupe)
Legal system: French civil law system; highest court is a regional court of
appeal with jurisdiction over Guadeloupe, Guiana, and Martinique
Branches: each is administered by a Prefect appointed by Paris; both islands
have popularly-elected councils of 36 members
Government leaders: Prefects -- Jean Terrade (Martinique); Pierre Brunon
(Guadeloupe)
Suffrage: universal over age 21
Political parties and leaders: Martinique -- Union for New Republic (UNR),
Camille Petit; Martinique Domestic Union (UDM), Leon Valere; Federation of
the Left (FDS), leader unknown; Socialist Party (SFIO), Emmanuel Hermance
Verg; Martinique Progressive Party (PPM), Aime Cesaire; Communist Party
(PCM), Armand Nicolas; Guadeloupe -- Union for New Republic (UNR), Medard
Albrond; Socialist Party (SFICO) , Pierre Monnerville; Federation of the
Left (FDS), leader unknown; Socialist Dissident, leader unknown; Center
Independent, leader unknown; Leftist Independent, leader unknown; Communist
Party (PCG), Evremont Gene
Voting strength (1967 national election): Martinique -- 39.8% UNR, 8.7% UDM,
9.4% FDS, 20.3% PPM, 16.2% PCM, 5.6% Independent; Guadeloupe -- 29.7%
UNR, 37.7% PCG, 10.2% FDS, 9.1% Socialist Dissident, 10.2% Center Indep-
endent, 3.1% Leftist Independent; seats in 1968 French Chamber of Deputies
election -- Martinique 3 Gaullist, Guadeloupe 2 Gaullist and 1 Communist
Communists: Martinique -- 2,000, sympathizers, 10,000; Guadeloupe -- 2,000,
sympathizers, 11,000
Other political or pressure groups: Organization of the Anti-colonialist
Martinique Youth (OJAM); National Organization of Guadeloupe (GONG),
Chinese-Communist oriented; National Front of Guadeloupe, extremist-Marxist
oriented
109
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Gabonese Republic
Type: republic; one-party presidential regime since 1964
Capital: Libreville
Political subdivisions: 9 regions, 6 communes, 4,500 villages
Legal system: based on French civil law system and customary law; constitution
adopted 1961; judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; legal education at Centre of Higher and Legal Studies
at Libreville; compulsory ICJ jurisdiction not accepted
Branches: power centralized in President, elected by universal suffrage for
7-year term; unicameral 47-member National Assembly has limited powers ;
judiciary
Government leaders: President Albert-Bernard Bongo
Suffrage: universal over age 21
Elections: Presidential and parliamentary elections last held March 1967
Political parties and leaders: Gabonese Democratic Party (PDG) led by President
Bongo is only legal party
Communists: possibly some Communists and probably some Communist sympathizers
Member of: EAMA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM, UDEAC, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Republic of Gambia
Type: republic; independent since February 1968
Capital: Bathurst
Political subdivisions: Bathurst and 4 divisions
Legal system: based on English common law and customary law; constitution came
into force upon independence in 1965, new republican constitution adopted in
April 1970; accepts compulsory ICJ jurisdiction, with reservations
Branches: Executive Council of 8 ministers; 36-member House of Representatives,
in which 4 seats are reserved for chiefs and 32 are filled by election for
5-year term; independent judiciary
Government leader: Dawda K. Jawara, President ’
Political parties and leaders: People''s Progressive Party (PPP), Secretary
General Dawda K. Jawara; opposition coalition, People''s Progressive Alliance
(PPA) and United Party (up)
Elections: general elections held May 1966; PPP won 24 seats, alliance of UP and
PPA won 5
Communists: probably some Communists and sympathizers
Member of: Commonwealth, OAU, U.N.','7c5a06c4e32741483be33946adb9ce3d0eda889dca300c0dd8029649de75ac43','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d83b64254cfd66105cb109964855e07d37093135b9c5784dd48c831ba6bf180',1971,'MA','Morocco','government',48,'Legal name: Province of Mozambique
Type: overseas province of Portugal
Capital: Lourenco Marques
Political subdivisions: province divided into 10 districts administered by
district governors; municipalities governed by appointed official
Legal system: based on Portuguese civil law system and customary law
Branches: Governor General appointed by Lisbon is chief executive officer for
internal administration; he also has certain legislative powers which he
exercises with a legislative council; all action in province may be vetoed
by Minister of Overseas in Lisbon; judiciary is constitutionally independent
Government leader: Governor General Eng. Eduardo Arantese Oliveira
Suffrage: all adults able to read and write Portuguese and in full possession of
political and civil rights
Political parties and leaders: National Popular Action (ANP), formerly the
National Union (UN), provincial president Manuel Montiero Ribeiro Jeloso; no
legal opposition political parties
Other political or pressure groups: the National Liberation Front (FRELIMO), led
by Moises Samora Machel, operates primarily from Tanzania; Revolutionary
Committee (COREMO), led by Paulo Gumane, based in Zambia
Legal name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se; government offices in Uaboe District
Political subdivisions: 14 districts
Branches: President elected from and by Parliament for an unfixed term; popularly
elected unicameral legislature, the Parliament; Cabinet to assist the
President, four members, appointed by President from Parliament members
Government leader: President Hammer De Roburt
Suffrage: universal adult
Political parties and leaders: De Roburt is only significant political figure;
has almost universal support of Nauruans
Member of: no present plans to join U.N. or other international agencies; enjoys
"special membership" in Commonwealth
Legal name: Kingdom of Nepal
Type: constitutional monarchy; King Mahendra exercises autocratic control over
multitiered panchayat system of government
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and English common law; legal
education at Nepal Law College in Kathmandu; has not accepted compulsory
ICJ jurisdiction
Branches: Council of Ministers appointed by the King; indirectly elected
National Panchayat (Assembly)
Government leader: King Mahendra Bir Bikram Shah Deva; Prime Minister Kirti Nidhi
Bista
Suffrage: universal over age 21
Elections: village and town councils (panchayats) elected by universal suffrage;
district, zonal, and National Panchayat members indirectly elected, most
for 6-year terms
Political parties and leaders: all political parties outlawed
Member of: FAQ, FUND, IBRD, ICAO, IDA, ILO, ITU, U.N., UNESCO, UPU, WHO
Legal name: Kingdom of the Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government resides at The Hague
Political subdivisions: 11 provinces governed by centrally appointed commissioners
of Queen
Legal system: civil law system incorporating French penal theory; constitution
of 1815 frequently amended, reissued 1947; judicial review in the Supreme
Court of legislation of lower order than Acts of Parliament; legal education
at six law schools; accepts compulsory ICd jurisdiction, with reservations
Branches: executive, (Queen and Cabinet of Ministers), which is responsible to
bicameral states general (parliament); independent judiciary
Government leader: Petrus J.S. de Jong, Minister-President
Suffrage: universal over age 21
Elections: must be held at least every 4 years for lower house (most recent
April 1971), and every 3 years for upper house (most recent July 1969)
Political parties and leaders: Catholic People''s Party (KVP), A.P. van der Stee;
Antirevolutionary (ARP), A. Veerman; Labor (PvdA), Andre van der Louw; Liberal
(VVD), Mrs. H. van Someren-Downer; Christian Historical Union (CHU),
Prof. J. W. van Hulst; Democrats ''66 (D-66), J. Beekmans; Communist (CPN),
Henk Hoekstra; Pacifist Socialist (PSP), H. Wiebenga; Political Reformed
(SGP), H. G. Abma; Reformed Political Union (GVP), W. G. Beeftink; Radical
Party (PPR), J. Tonnaer; Democratic Socialist ''70 (DS-70), Dr. Wilhelm
Dress, Jr.
Voting strength (1971 election): 21.9% KVP, 10.3% VVD, 8.6% ARP, 6.3% CHU, 24.6%
PyvdA, 5.8% D-66, 5.3% DS-70, 3.9% CPN, 1.4% PSP, 1.8% PRP, 2.4% SGP, 1.6% GVP
Communists: 10,200; 248,000 votes in 1967 election
Member of: Benelux, Council of Europe, ECE, ECSC, EEC, EMA, EURATOM, FAQ, IAEA,
IBRD, ICAO, IHB, NATO, OECD, U.N., UNESCO, WEU, WHO
Legal name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands, enjoying complete domestic
autonomy
Capital: Willemstad; Curacao, center of government
Political subdivisions: 4 island territories -- Aruba, Bonaire, Curacao, and the
Windward Islands -- St. Eustatius, southern part of St. Martin (northern
part is French), Saba
Legal system: based on civil law system, with some English common law influence;
Dutch Country Statute of 1955 serves as constitution
Branches: executive power, under nominal head of Governor (appointed by the
Crown), exercised by 8-member Council of Ministers or Cabinet; legislative
power rests with 22-member Legislative Council; independent court system
under control of Chief Justice of Supreme Court of Justice (administrative
functions under Minister of Justice); each island territory has island
council headed by Lieutenant Governor for local administration
Government leaders: Minister President Ramez Jorge Isa (new government formed
6 February 1971)
Suffrage: universal over age 21
Elections: held every 4 years
Political parties and leaders: the Democratic Party (DP); the Aruba Patriotic
Party (PPA) led by S.J. Trompe; the National People''s Party (NVP), S.D. Abbad;
the Aruba People''s Party (AVP) led by Dominico Guzman Croes; the National
Aruban Union Party/Independent Aruban Party (UNA/PIA) led by A. Werleman/M.
Croes; Bonaire Democratic Party led by L.A. Abraham; Windward Island
Democratic Party led by A. C. Wathey; Social Progressive Action Party, S. R.
Goeloe; Antillean Reform Union (URA), Roberto Suriel; Curacao Independent
Party (COP), Peter Vander Hoven; Radical Peoples Party (PRP), Max de Castro;
Workers'' Party (Frente Obrero) -- coalition in power includes DP, PPA, and
Workers'' Party
Voting strength (1969 local election): 46% DP/PPA; 15% NVP; 14% Worker Front;
14% AVP; 11% other (new elections may be called soon)
Member of: EEC (associate), WHO
227
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Overseas Territory of New Caledonia
Type: French overseas territory; represented in French parliament by one deputy
and one Senator
Capital: Noumea
Political subdivisions: 4 islands or island group dependencies -- Isle of Pines,
Loyalty Islands, Huon Islands, Island of New Caledonia
Legal system: French law 7
Branches: administered by Governor, who is also High Commissioner for France in
the Pacific; responsible to French Ministry for Overseas France and
Governing Council; Assemblee Territoriale
Government leader: Jean Risterucci, Governor and French High Commissioner
Suffrage: restricted (1957 election roll listed 32,370 males and females over
21 years of age, of whom 18,964 were classed as indigenous inhabitants)
Elections: Assembly elections in 1967
Political parties and leaders: Union Caledonienne, Jed by M. Rock Pidjot; Entente
Caledonienne, Lafleur; Caledonie Nouvelle; Union des Patentes
Voting strength (1967 election): Union Caledonienne, 22 seats; Entente Caledon-
jienne, (alliance of R. C. Caledonienne and United Nouvelle Republique), 10
seats; Caledonie Nouvelle, 2 seats; Union des Patentes, 1 seat
Communists: number unknown; Union Caledonienne strongly leftist; some political-
ly active Communists were deported during 1950''s; small number of North
Vietnamese
Other political parties and pressure groups: several lesser parties
Member of: no membership in international organizations
Legal name: Republic of Nicaragua
Type: republic; dominated by president
Capital: Managua
Political subdivisions: 1 national district and 16 departments
Legal system: based on Spanish civil law system; constitution adopted in 1950;
judicial review of legislative acts in the Supreme Court; legal education
at Universidad Nacional de Nicaragua; accepts compulsory ICJ jurisdiction
Branches: President, bicameral legislature, judiciary elected by legislature,
and Supreme Electoral Tribunal (4th branch)
Government leader: President Anastasio Somoza Debayle
Suffrage: universal over age 18 if married or literate, otherwise 21
Elections: every 5 years; however, due to agreement between liberal and conservative
parties, next elections will not be held until mid-1974
Political parties and leaders: Nationalist Liberal Party (PLN), Anastasio Somoza,
Ramiro Sacasa, Francisco Urcuyo, Alfonso Callejas; Traditionalist Conservative
Party (PCT), Fernando Aguero Rocha, Pedro Joaquin Chamorro; Nicaraguan
Conservative Party (PCN), Alejandro Abaunza Marenco, Enrique Belli Chamorro;
Independent Liberal Party (PLI), not legal, Victor Manuel Ordonez, Arges
Sequeiva, Juan Manuel Gutierrez; Social Christian Party (PSC), not legal,
Ignacio Zelaya
Voting strength (1967 elections): PLN 480,162 votes (74%), PCN 14,650 votes (2%);
PCT and supporting parties, 157,432 votes (24%)
Member of: CACM, FAO, GATT, IADB, IAEA, ICAO, ICJ, ILO, INTELSAT, ITU, OAS,
ODECA, U.N., UNESCO, UNICEF, UPU, WHO, WMO
Legal name: Republic of Niger
Type: republic; one-party rule established 1960
Capital: Niamey
Political subdivisions: 7 departments, 32 arrondissements
Legal system: based on French civil law system and customary law; constitution
adopted 1960; judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: President selected for 5 years by direct universal suffrage; unicameral,
60-member National Assembly elected for 5 years; judiciary constitutional ly
independent of executive and legislature
Government leader: President Diori Hamani
Suffrage: universal over age 2]
Elections: presidential and parliamentary elections in 1970; about 99% of voters
approved unopposed official candidates
Political parties and leaders: Parti Progressiste Nigerien (PPN), led by Diori
Hamani
Communists: some Communists and Communist sympathizers, especially among supporters
of outlawed Sawaba party
Member of: EAMA, Entente, FAO, GATT, IBRD, ICAO, ILO, IMF, ITU, Lake Chad Basin
Commission, OAU, OCAM, U.N., UNESCO, UPU, WHO, WMO
Legal name: Federal Republic of Nigeria
Type: federal republic since 1963; under military rule since January 1966,
military rule scheduled to last until 1976
Capital: Lagos
Political subdivisions: 12 states, each headed by a military governor
Legal system: based on English common law, tribal law, and Islamic law; new
constitution to be drafted; legal education at Universities of Ife, Ahmadu
Bello, and Lagos; accepts compulsory ICJ jurisdiction, with reservations
Branches: Federal Military Government, administered by Supreme Military Council
and Federal Executive Council, which includes 12 civilian commissioners
(ministers )
Government leader: Maj. Gen. Yakubu Gowon, Head of Federal Military Government
and Commander in Chief of Nigerian Armed Forces
Suffrage: universal adult suffrage (except for women in former Northern Region)
Elections: sometime in next 6 years
Political parties and leaders: political parties and politically active tribal
a societies were dissolved by decree on 24 May 1966; some subrosa political
activity continues
Member of: Commonwealth, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, OAU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 20 counties, 404 communes, 47 towns
Legal system: mixture of customary law, civil law system, and common law traditions;
constitution adopted 1814, modified 1884; Supreme Court renders advisory
opinions to legislature when asked; legal education at University of Oslo;
accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament (Storting) ;
executive power vested in Crown but exercised by cabinet responsible to
parliament; Supreme Court, 5 superior courts, 104 lower courts
Government leaders: King Olav V; Prime Minister Per Borten
Suffrage: universal, but not compulsory, over age 20
Elections: held every 4 years (next in 1973)
Political parties and leaders: Conservative, Kare Willoch; Christian Peoples,
Lars Korvald; Center, John Austrheim; Liberal, Helge Seip; Labor, Trygve
Bratteli; Socialist Peoples, Finn Gustavsen; Communist, Reidar Larsen
Voting strength (1969 election): 19.6% Conservative; 9.4% Christian Peoples;
10.5% Center; 9.4% Liberal; 46.5% Labor; 3.5% Socialist Peoples; 1.0%
ues Communist
me Communists: 2,000; a number of sympathizers as indicated by the 22,500 Communist
‘ votes cast in the 1969 election
Member of: Council of Europe, EFTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHB,
ILO, IMCO, IMF, ITU, NATO, Nordic Council, OECD, U.N., UNESCO, UPU, WHO, WMO
Legal name: Sultanate of Oman
Type: absolute monarchy; nominally independent but under strong U.K. influence
Capital: Muscat
Legal system: based on English common law and Islamic law; no constitution;
ultimate appeal to the Sultan; has not accepted compulsory ICd jurisdiction
Government leader: Sultan Qabus ibn Sa''id Al Bu Sa''id
Legal name: Islamic Republic of Pakistan
Type: republic; under transitional military rule since March 1969; East Pakistan,
which tried to become independent as Bang Ja Desh in April 1971, is under
military occupation
Capital: Islamabad; many government offices functioning in Rawalpindi, temporary
capital
Political subdivisions: 2 noncontiguous wings -- West Pakistan and East Pakistan;
East Pakistan is one province, and West Pakistan has 4 provinces -- Punjab,
Sind, Baluchistan, Northwest Frontier -- with the capital territory of
Islamabad and certain tribal areas centrally administered
Legal system: based on English common law; constitution of 1962 abrogated by
martial law regime, but country governed as closely as possible in accordance
with it, although several important basic rights have been rescinded; judicial
review of legislative acts in the Supreme Court; six law schools, including
University of Punjab School of Law in Lahore; accepts compulsory ICd
jurisdiction, with reservations
Branches: Martial Law Administration holds executive and legislative powers;
judiciary relatively unaffected and relatively unaffected by martial law
in West Pakistan
Government leaders: President and Martial Law Administrator Yahya Khan, assisted
by Deputy Martial Law Administrators Vice Admiral Muzaffar Hasan, Air Marshal
A. Rahim Khan, and Gen. Abdul Hamid Khan
Suffrage: universal over age 21
*Based on data reported by Pakistan''s Central Statistical Office, the Pakistani
population was est. at 116,597,000 on 1 July 1971. Projections based on estimates
used by Pakistan''s Planning Commission, which allows for an underenumeration of 8%
in the 1961 census, suggest, however, that the population may be as high as 134 million.
243
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GOVERNMENT (cont''d):
Elections: national elections for 313-member constituent assembly, based on
one-man/one-vote formula, scheduled for 7 December 1970; assembly to be
given 120 days to draw up constitution which must be authenticated by
President; provincial elections to be held 17 December 1970
Political parties and leaders: Awami League (AL) (outlawed), Mujibur Rahman
(jailed), Tajuddin Ahmed (in exile); Pakistan People''s Party (PPP), Z. A.
Bhutto; Council Muslim League (CML), Mumtaz Daultana; Jama''at-i-Islam (JI),
Maulana Madoodi; Pakistan Democratic Party (PDP), Nurul Amin; National Awami
Party/Left (NAP/L), Naulana Bhashani; National Awami Party/Requisitionist
(NAP/R), Abdul Wali Khan; All Pakistan Muslim League (PML/Qaiyum), Abdul
Qaiyum Khan; Markazi Jamiat-ul-Ulema-i-Pakistan (MJUP), Khamaja Qamar-u-Din
Sialvi; Jamiat-ul-Ulema-i-Islam (JUI), Jaulana Ghulam Ghaus Hazarvi, Mufti
Mahmud
Member of: ADB, CENTO, Colombo Plan, Commonwealth, FAO, IAEA, IBRD, ICAO, IDA,
IFC, IHB, ILO, IMCO, IMF, ITU, RCD, SEATO, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Panama
Type: republic; under military rule since October 1968
Capital: Panama City
Political subdivisions: 9 provinces, 1 Indian reservation
Legal system: based on civil law system; constitution adopted in. 1946; judicial
review of legislative acts in the Supreme Court; legal education at
University of Panama; accepts compulsory ICd jurisdiction, with reservations
Branches: popularly elected executive and unicameral legislature (currently
disbanded), presidentially appointed Supreme Court
Government leaders: elected President Arias ousted by military Junta on 11
October 1968; locus of power remains with National Guard Commandant, General
Omar Torrijos; Demetrio Lakas is President of the Provisional Junta
Government and Chief of State
Suffrage: universal and compulsory over age 21
Elections: May 1968 elections won by National Union (NU) coalition candidate
Arnulfo Arias Madrid, who assumed presidency on 1 October 1968; elections
held every 4 years; no elections are scheduled or planned
Political parties and leaders: political parties suspended pending revision of
electoral code
Voting strength (1968 election): 55% Arnulfo Arias Madrid (National Union
Coalition), 42% David Samudio (People''s Alliance), 3% Antonio Gonzalez
Revilla (Christian Democratic Party)
Member of: IADB, IAEA, ICAO, OAS, U.N.
ae ECONOMY :
GNP: $1.32 billion (purchasing power parity estimate, 1970), $915 per capita;
63% private consumption, 12% government consumption, 23% gross fixed
investment, +2% net foreign balance (1968); real growth rate 1970, 7.0%
Agriculture: main crops -- bananas, rice, corn, coffee, sugarcane; self-sufficient
in most basic foods; 2,400 calories per day per capita (1965-66)
Major industries: food processing, metal products, construction materials,
petroleum products, clothing
245
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Electric power: 218,000 kw. capacity (1969 est.}; 621 million kw.-hr. produced
(1969 est.), 480 kw.-hr. per capita
Exports: $117 million (f.o.b., 1969); bananas, petroleum products, shrimp,
sugar, coffee
Imports: $294 million (c.i.f., 1969); manufactures, transportation equipment,
crude petroleum, foodstuffs, chemicals =
Major trade partners: U.S. 43%, Venezuela 15%, Canal Zone 9%, Colon Free Zone i
6% (1969) ‘ J
Aid: 7
economic -- extensions from U.S. (1946-69), $146.4 million loans, $96.7
million grants; from international organizations (FY46-69), $53.5 million;
from other Western countries (1960-68), $14.0 million;
military -- assistance from U.S. (FY61-69), $3.2 million
Monetary conversion rate: 1 balboa=US$1 (official)
Fiscal year: calendar year
Ahab
Legal name: Territory of Papua and New Guinea
Type: dependent territory under Administrator appointed by Australia
Capital: Port Moresby
Political subdivisions: 18 administrative districts (12 in New Guinea, 6 in Papua);
New Guinea (including Bismarck archipelago and Bougainville) is a U.N. Trust
Territory
Legal system: based on English common law; highest judicial organ is High Court
of Australia
Branches: executive -- Administrator and Executive Council; legislature --
House of Assembly (94 members, including 10 appointed); judiciary -- court
system consists of Supreme Court of Territory of Papua and New Guinea and
various inferior courts (District Courts, Local Courts, Children''s Courts,
Wardens'' Courts); Supreme Court decisions may be appealed to High Court
of Australia
Government leader: Administrator, L. W. Johnson
Elections: preferential-type elections for 84 members of 94-member House of
Assembly every 4 years; 10 are appointed "official" members; last elections
in February-March 1968
Political parties: proindependence Pangu Pati is principal political group; 5 or
6 other small parties and numerous independents
Suffrage: universal adult suffrage
Voting strength (1968 election): 1.18 million registered voters, of which an
estimated 65% to 75% voted; Pangu Pati and pro-Pangu Pati sympathizers won
21-26 assembly seats, minor parties and independents won remainder
Communists: no significant strength
Member of: no membership in international organizations
Legal name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncion
Political subdivisions: 16 departments and the national capital, 154 municipalities
Legal system: based on Argentine codes, Roman law, and French codes; constitution
promulgated 1967; judicial review of legislative acts in Supreme Court; legal
education at National University of Asuncion and Catholic University of Our
Lady of the Assumption; does not accept compulsory ICJ jurisdiction
Branches: President heads executive; bicameral legislature; judiciary headed
by Supreme Court
Government leader: President (General) Alfredo Stroessner
Suffrage: universal; compulsory between ages of 18-60
Elections: President and Congress elected together every 5 years; 4-party
participation for first time in 1968 elections
Political parties and leaders: Colorado Party, Juan Ramon Chavez; Levi-Liberal
Party, Carlos Levi Ruffinelli; Febrerista Party, Ignacio Iramain; Radical
Liberal Party, Carlos Alberto Gonzalez; Christian Democratic Party (not
officially inscribed), Alfredo Ayala Haedo
Voting strength (February 1968 general election): 71% Colorado Party, 22% Radical
Liberal Party, 4% Liberal Party, 3% Febrerista Party
Communists: Oscar Creydt faction and Miguel Angel Soler faction (both illegal);
perhaps several thousand party members and sympathizers in Paraguay, very
few are hard core; party in exile is small and deeply divided
Other political or pressure groups: Popular Colorado Movement (MoPoCo) led by
Epifanio Mendez Fleitas, in exile
Member of: FAO, IADB, IAEA, IBRD, ICAO, IMF, LAFTA, OAS, U.N., WHO
Legal name: Republic of Peru
Type: republic; under military regime since October 1968
Capital: Lima
Political subdivisions: 23 departments with limited autonomy plus constitutional
Province of Callao
Legal system: based on civil law system; military government rules by decree;
legal education at the National Universities in Lima, in Trujillo, in Arequipa,
and in Cuzco; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative, judicial; congress disbanded after 3 October
1968 ouster of President Fernando Belaunde Terry
Government leader: President Juan Velasco Alvarado
Suffrage: literacy requirement
Elections: presidential and congressional elections held every 6 years; all
elections canceled after the coup
Political parties and leaders: Popular Action Party (AP), Fernando Belaunde Terry
in exile; Christian Democratic Party (PDC), Hector Cornejo Chavez; Popular
American Revolutionary Alliance Party (APRA), Victor Raul Haya de Ja Torre;
Popular Christian Party (PPC), Luis Bedoya Reyes
Voting Stengel (1963 election): 39% AP-PDC, 34% APRA, 25% UNO, 1% Communist,
1% other
Member of: GATT, IADB, IAEA, ICAO, LAFTA and Andean Sub-Regional Group (created
in May 1969 within LAFTA), OAS, U.N.
Legal name: Republic of the Philippines
Type: republic
Capital: Manila (Quezon City)
Political subdivisions: 66 provinces
Legal system: based on Spanish, Islamic, and Anglo-American law; constitution
passed 1935, ratified as amended 1947; judicial review of legislative acts
in the Supreme Court; legal education at University of the Philippines,
Ateneo de Manila University, and 71 other law schools; accepts compulsory
ICJ j','5d900cd59fe5dbfef94ada7c12bbaf368d45b845c82a0c1d8be8bbd96b5b9acb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('861484b977ed09032df81ceb9b434885c2300d6bc0e6e77d48033607b75de313',1971,'MA','Morocco','government',49,'urisdiction, with reservations
Branches: strong executive branch with Presidential Cabinet; bicameral
legislature -- Senate and House of Representatives; judicial branch headed
by Supreme Court with descending authority in a Court of Appeals, Courts
of First Instance in various provinces, municipal courts in chartered
cities, and justices of the peace in towns and municipalities; these
justices have considerably more authority than do justices of the peace
in the U.S.
Government leader: President Ferdinand E. Marcos
Suffrage: universal over age 21, and literate
Elections: elections for President and House of Representatives held every 4 years;
Senate elections staggered with one-third membership elected every 2 years
Political parties and leaders: Liberal Party, Gerardo M. Roxas; Nacionalista
Party, Gil J. Puyat
Voting strength (1970): Senate -- Nacionalista Party, 19 seats; Liberal Party,
> seats; House of Representatives -- Nacionalista Party, 92; Liberal Party,
8
Communists: under 1,000; sympathizers, 5,000-6,000 (est.)
Member of: ADB, ASEAN, ASPAC, Cotombo Plan, ECAFE, IAEA, ICAO, IHB, SEATO,
U.N., UNESCO, UNICEF, WHO
Legal name: Polish People''s Republic (PRL)
Type: Communist state
Capital: Warsaw
Political subdivisions: 17 provinces, 5 city provinces, 391 districts
Legal system: mixture of Continental (Napoleonic) civil law and Communist Tegal
theory; constitution adopted 1952; court system parallels administrative
divisions with Supreme Court, composed of 104 justices, at apex; no
judicial review of legislative acts; legal education at 7 law schools; has
not accepted compulsory ICJ jurisdiction
Branches: legislative, executive, judicial system dominated by parallel
Communist Party apparatus
Government leader: Piotr Jaroszewicz, Premier; Jozef Cyrankiewicz, chairman
of Council of State (president)
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government every 4 years
Dominant political party and leader: Polish United Workers '' Party (PZPR)
(Communist) Edward Bierek, First Secretary
Voting strength (1969 election): 97% voted for Communist-approved single slate
Communists: 2,200,000 (February 1971)
Other political or pressure groups: National Unity Front (FJN), including United
Peasant Party (ZSL), Democratic Party (SD), progovernment pseudo-Catholic
Pax Association and Christian Social Association, Catholic independent Znak
group; powerful Roman Catholic Church, Stefan Cardinal Wyszynski, Primate
Member of: CEMA, GATT, ICAO, IHB, Indochina Truce Commission, Korea Truce
Commission, U.N. and all specialized agencies except IMF and IBRD, Warsaw Pact','65ef4f01b590992fb0d7310cece910b368221c6ca12f33d4bfb7bf14eb51f672','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e330999572599a7229748cce1b4ae42d169ab31f102611fce4e2aaa7867bea7',1971,'AU','Australia','government',51,'Legal name: Province of Portuguese Timor
Type: overseas province of Portugal
Capital: Dili
Political subdivisions: 12 administrative districts
Legal system: based on Portuguese law
Branches: Governor General appointed by Portuguese Minister of Overseas; advised
by a 7-member council composed of 4 ex offico members and 3 members elected
from the Legislative Council of 14 members (3 ex officio and''11 elected);
usual executive departments such as Treasury, Health, Justice, Education,
Transportation exist, each of which is headed by a director
Government leader: Governor Brig. Jose Noqoueira Valente Pires (appointed 1968)
Suffrage: high school education required
Elections: Timor elects one representative to the Portuguese National Assembly,
scarcely more than a gesture
Political parties and leaders: single party only, the National Popular Action Party
on Timor
Voting strength: limited to Portuguese on Timor and small group of Timorese
who fulfill requirement
Communists: prior to 1 October 1965, infiltration by Indonesian Communist Party
from Indonesian Timor, especially in the Ocussi enclave
Legal name: Commonwealth of Puerto Rico
Type: commonwealth voluntarily associated with U.S.
Capital: San Juan
Political subdivisions: 76 municipalities
Legal system: based on civil codes; constitution came into effect 1952, U.S.
Constitution also applies; local courts and U.S. federal court; legal
education at University of Puerto Rico Law School
Branches: elected Governor and bicameral legislature; 9-judge Supreme Court
appointed by Governor
Government leader: Governor Luis A. Ferre
Elections: every 4 years, last election November 1968; plebescite held July
1967 on question of opting for statehood, continued commonwealth status, or
full independence; 60.5% for commonwealth status, 38.9% for statehood, 0.6%
for independence
Suffrage: universal over age 21
Political parties and leaders: Popular Democratic Party (PPD), Luis Negron Lopez;
Republican Statehood Party (PER); New Progressive Party (NPP), Luis A. Ferre;
Christian Action Party (PAC), Catholic Church; Independence Party (PI);
People''s Party (formed August 1968), Roberto Sanchez
Voting strength (1968 election): 44.6% NPP, 42.2% PPD, 9.4% People''s Party;
distribution of house seats -- NPP 26, PPD 25; distribution of Senate seats
-- PPD 16, NPP 11
Legal name: Sheikhdom of Qatar
Type: absolute monarchy; U.K. controls foreign relations
Capital: Doha
Legal system: discretionary system of law controlled by the Sheikh
Government leader: Sheikh Ahmad ibn ‘Ali al Thani
Legal name: Overseas Province of Reunion
Type: overseas department of France; represented in French Parliament by three
Deputies and two Senators
Capital: Saint Denis
Legal system: French law
Branches: Reunion is administered by a Prefect appointed by the French Minister
of Interior, assisted by a Secretary-General and an elected 36-man General
Council
Government leader: Prefect Jean Vaudeville
Suffrage: universal adult
Elections: last municipal elections in 1969; parliamentary election June 1968
Political parties and leaders: Reunion Communist Party (RCP) led by Paul Verges,
only organized political movement on island; other political candidates
affiliated with metropolitan French parties, which do not maintain permanent
organizations on Reunion
Voting strength (parliamentary election 1968): Gaullist candidates swept all 3
districts
Communists: Communist Party small -- probably only 15-20 hard-line Communists --
but has support among peasant Sugarcane cutters and in Le Port district
Legal name: Colony of Southern Rhodesia
Type: self-proclaimed independent state since 1965; U.S. does not recognize
independence from U.K.
Capital: Salisbury
Political subdivisions: 11 magisterial districts
Legal system: Smith government implemented a republican constitution on 2 March
1970 which institutionalized white rule
Branches: President Dupont is ceremonial head of state; executive council
(cabinet) lead by Prime Minister Smith, National Assembly gives highly
disproportionate representation to white minority -- 50 white constituency
seats and 16 black constituency seats
Government leaders: Prime Minister lan Smith and President Clifford Dupont
Suffrage: franchise is based on income, property holdings, and education; there
are separate rolls for Africans and non-Africans
Elections: must be held every 5 years
Political parties and leaders: Rhodesian Front, Prime Minister Smith; Centre
Party, Pat Bashford
Voting strength (1970 elections): Rhodesian Front won all 50 white constituency
seats in Parliament
Communists: negligible
Other pressure groups and leaders: African nationalist organizations banned
from political activity -- Zimbabwe African People''s Union, Joshua Nkomo;
Zimbabwe African National Union, Ndabaningi Sithole; these leaders detained
by government; exiled leaders in Lusaka, Zambia, are James Chikerema (ZAPU)
and Herbert Chitepo (ZANU)
Legal name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 39 counties and 46 municipalities, including Bucharest
Legal system: mixture of civil law system and Communist legal theory which
increasingly reflects Romanian traditions; constitution adopted 1965; legal
education at University of Bucharest and two other law schools, has not
accepted compulsory ICJ jurisdiction
Branches: Council of Ministers; the Grand National Assembly, under which is
Office of Prosecutor General and Supreme Court; Council of State is a
collective head of state
Government leaders: Ion Gheorghe Maurer, President of the Council of Ministers,
head of government; Nicolae Ceausescu, President of Council of State,
titular head of state
Suffrage: universal over age 18, compulsory
Elections: elections in Romania held every 2 years for the local people''s
councils and every 4 years for Grand National Assembly deputies
Political parties and leaders: Communist Party of Romania only functioning party,
Nicolae Ceausescu, General Secretary
Voting strength (1969 election): overall participation reached 99.96%; of those
registered to vote (13,577,143), 99.75% voted for party candidates
Communists: 2,089,085 party members (December 1970)
+ Member of: CEMA, FAO, IAEA, ICAO, ILO, ITU, U.N., UNESCO, UPU, Warsaw Pact,
WHO, WMO
Legal name: Republic of Rwanda
Type: republic, formerly combined with Burundi in U.N. trusteeship under Belgium;
became separate independent country in July 1962
Capital: Kigali
Political subdivisions: 10 prefectures, subdivided into 141 communes
Legal system: based on German and Belgian civil law systems and customary law;
constitution adopted 1962; judicial review of legislative acts in the
Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: executive consists of President, popularly elected for 4-year term,
and 14 cabinet ministers; single house 47-member National Assembly, popularly
elected for 4-year terms; 6-member Supreme Court appointed by President
Government leader: President Gregoire Kayibanda
Suffrage: universal and compulsory over age 18
Elections: last legislative election September 1969, president reelected September
1969; both elected for 4-year terms
Political parties and leaders: Party of the Hutu Emancipation Movement
(PARMEHUTU), led by President Gregoire Kayibanda, dominates at all levels
Member of EAMA, IBRD, ICAO, ILO, IMF, ITU, OCAM, OAU, U.N., UNESCO, WHO, WMO
Legal name: Ryukyu Islands
Type: U.S.-administered territory; will revert to Japan in 1972
Capital: Naha
Political subdivisions: 3 main island groups (Okinawa, Yaeyama, Miyako); 60
cities, towns, and villages
Legal system: based on Japanese civil law with specific U.S. enactments dealing
with the islands; U.S. Executive Order of 1957 functions as constitution
Branches: executive, judicial, and legislative branches
Government leader: Chief Executive, Chobyo Yara
Suffrage: universal over age 20
Elections: Japanese Diet elections held every four years pr upon dissolution of
Lower House, triennially for one half of Upper House; Legislative Assembly,
every 3 years
Political parties and leaders: Okinawa Liberal Democratic Party (OLDP), Seisaku
Ota, president; Okinawa Socialist Masses Party (OSMP), Tsumichiyo Asato,
chairman; Okinawa People''s Party (OPP) (pro-Communist), Kamejiro Senaga,
chairman; Okinawa Prefecture Headquarters Japan Socialist Party (OJSP)
Seiei Sakahima, chairman
Voting strength: seats in Legislative Assembly following 1968 election -- OLDP
18, OSMP 9, OPP 3, OJSP 2
3
Legal name: Associated State of St. Chris topher-Nevis
Type: dependent territory with full internal autonomy as a British "Associated
State"; Anguilla formally seceded in May 1967 but has not been recognized
as an independent state by any government; in July 1968 a legislative
council headed by Ronald Webster was elected to govern Anguilla; in March
1969 the U.K. sent troops to Anguilla, placing the island again under
colonial rule
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law; constitution of 1960; highest judicial
organ is Court of Appeal of Leeward and Windward Islands
Government leaders: Premier, Robert L. Bradshaw; U.K. Governor, M. P. Allen
Suffrage: universal adult suffrage
Elections: at least every 5 years; most recent 25 July 1966
Political parties and leaders: St. Kitts-Nevis-Anguilla Labor Party, Robert L.
Bradshaw; People''s Action Movement (PAM), William Herbert; United National
Movement, Eugene Walwyn
Voting strength (1966 election): St. Kitts-Nevis-Anguilla Labor Party won 7 seats
in legislative council, PAM won 2, United National Movement won 1
Communists: none known
Member of: CARIFTA
Legal name: Associated State of St. Lucia
Type: dependent territory with full internal autonomy as a British “Associated
State"
Capital: Castries
Political subdivisions: 14 parishes
Legal system: based on English common law; constitution of 1960; highest judicial
body is Court of Appeal of Leeward and Windward Islands
Government leaders: Premier John Compton; U.K. Governor Frederick Clarke
Suffrage: universal adult suffrage
Elections: every 5 years; most recent April 1969
Political parties and leaders: United Worker''s Party (UWP), John Compton; St.
Lucia Labor Party (SLP), Martin Jean Baptiste; St. Lucia Labor Party United
Front (LPUF) led by George Charles
Voting strength (1969 election): UWP won 6 of the 10 elected seats in Legislative
Council; SLP won 3 seats; LPUF won 1 seat
Communists: negligible
Member of: CARIFTA
Legal name: Associated State of St. Vincent
Type: dependent territory with full internal autonomy as a British “Associated
State"
Capital: Kingstown
Political subdivisions: 10 local government authorities
Legal system: based on English common law; constitution of 1960; highest
judicial body is Court of Appeal of Leeward and Windward Islands
Government leader: Premier, R. Milton Cato; Administrator (U.K.) Rupert John
Suffrage: universal adult suffrage
Elections: every 5 years; most recent May 1967
Political parties and leaders: People''s Political Party (PPP), Ebenezer Joshua;
St. Vincent Labor Party (LP), R. Milton Cato
Voting strength (1967 election): LP won 6 seats to PPP''s 3 in the Legislative
Council
Communists: negligible
Member of: CARIFTA
Legal name: Republic of San Marino
Type: republic (dates from 4th century A.D.); in 1862 the Kingdom of Italy
concluded a treaty guaranteeing the independence of San Marino; although
legally sovereign, San Marino is vulnerable to pressure from the Italian
Capital: San Marino
Political subdivisions: San Marino is divided into 9 sections: Guaita, Fratta,
Serravalle, Domagnano, Acquaviva, Fiorentino, Montegiardino, Faetano,
Chiesanuova
Legal system: based on civil law system with Italian law influences; electoral
law of 1926 serves some of the functions of a constitution; has not accepted
compulsory ICJ jurisdiction
Branches: the Grand and General Council is the legislative body elected by popular
vote; its 60 members serve 5-year terms; Council in turn elects two Captains-
Regent who exercise executive power for term of 6 months, the Council of
State whose members head government administrative departments and the Council
of Twelve, the supreme judicial body; actual executive power is wielded by
the Secretary of State for Foreign Affairs and the Secretary of State for
Internal Affairs
Government leaders: Secretary of State for Foreign Affairs Federico Bigi
(Christian Democratic party); Secretary of State for Internal Affairs Gian
Luigi Berti (Christian Democratic party)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General Council required at least every
5 years; next elections 1974
Political parties and leaders: Christian Democratic party (DCS), Federico Bigi
Social Democratic Party (PSDIS), Alvaro Casali; Socialist Party (PSS), Gino
Giacomini, Domenico Forcellini; Communist Party (PCS), Umberto Barulli
Voting strength (1969 election): 45% DCS, 25% PCS, 18.3% PSDIS, 11.7% PSS
Communists: approx. 300 members (number of sympathizers cannot be determined) ;
PCS is technically autonomous but in fact closely tied to Italian Communist
Party (PCI); PCS-PSS coalition dominated San Marino Government until 1957;
PSS, unlike its Italian counterpart, remains securely allied with PCS
Other political parties and pressure groups: political parties influenced by
policies of their counterparts in Italy, but the two Socialist parties are
not united as in Italy
Member of: ICJ, International Institute for Unification of Private Law,
International Relief Union, IRC, UPU
285
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Kingdom of Saudi Arabia
Type: absolute monarchy
Capital: Riyadh; foreign ministry and foreign diplomatic representatives located
in Jidda
Political subdivisions: 18 amirates
Legal system: based on Islamic law; commercial disputes handled by special
committees formed in larger towns; constitution under preparation; legal
education at Islamic University, Medina; has not accepted compulsory ICJ
jurisdiction
Branches: King Faysal (Al Saud, Faysal ibn Abd al-Aziz) rules in consultation
with Council of Ministers and religious leaders
Government leader: King Faysal
Communists: negligible
Member of: Arab League, FAO, IAEA, IATA, IBRD, ICAO, IDA, IFC, IMF, ITU, OAPEC,
OPEC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Senegal
Type: republic; only one legal party since 1966
Capital: Dakar
Political subdivisions: 7 regions, each subdivided into departments (totaling
28) and arrondissements Ceotating 90)
Legal system: based on French civil law system; laws dealing with marriage,
inheritance, succession, etc., based on Islamic law with elements of
traditional practices; constitution adopted 1960, revised 1963 and 1970;
judicial review of legislative acts in Supreme Court (which also audits
the government''s accounting office); legal education at University of Dakar;
has not accepted compulsory ICJ jurisdiction
Branches: Government dominated by President who is assisted by Prime Minister,
appointed by President and subject to dismissal by President or censure by
National Assembly; 80-member National Assembly, elected for 5 years
(effective 1968); President elected for 5-year term (effective 1968) by
universal suffrage; judiciary headed by Supreme Court, with members appointed
by President
Government leaders: Leopold Sedar Senghor, President; Abdou Diouf, Prime Minister
Suffrage: universal adult
Political parties and leaders: Union Progressiste Senegalaise (UPS), ruling
party led by President Leopold Senghor, has absorbed all major opposition
parties; minor parties include illegal Communist-backed Parti Africain
de 1''Independence (PAI), led by Majmout Diop, and Parti Communiste Senegalais,
a pro~Peking splinter group
Elections: single party (UPS) presidential and legislative elections held
February 1968
Communists: a few Communists and sympathizers; PAI is pro-Moscow Communist-front
party; some pro-Peking elements broke off in 1965 to form Parti Communiste
Senegalais
Member of: EAMA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, OCAM, Organization
of Senegal River States (OERS), U.N., UNESCO, UPU, WHO, WMO
Legal name: Colony of the Seychelles
Type: British crown colony
Capital: Victoria, Mahe Island
Legal system: based on English common law, French civil law system, and
customary law
Branches: Governor, Council of Ministers, Legislative Assembly
Government leader: Governor Sir Bruce Greatbatch
Suffrage: universal adult
Elections: November 1970
Political parties and leaders: Seychelles Democratic Party (SDP), James R.
Mancham, President; Seychelles Peoples United Party (SPUP), France
Albert Rene, President
Voting strength: SDP won 4 seats on Governing Council with 52.8% popular vote
in 1970 election; SPUP won 5 seats with 47.2% of votes
Communists: negligible
Other political or pressure groups: trade unions which are appendages of
political parties
Legal name: Republic of Sierra Leone
Type: republic under presidential regime since April 1971
Capital: Freetown
Political subdivisions: 3 provinces; divided into 12 districts with 146 chief-
doms, where paramount chief and council of elders constitute basic unit of
government; plus western area, which comprises Freetown and other coastal
areas of the former colony
Legal system: based on English law and customary laws indigenous to local
tribes; constitution adopted April 1970; highest court of appeal is the
Sierra Leone Court of Appeals; has not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by President; parliament consists of 78
members, 66 of whom are elected representatives and 12 paramount chiefs
representing tribal councils in provincial districts; independent judiciary
Government leader: Siaka Stevens, President, heads APC government composed
of members of his political party, and paramount chiefs
Elections: the maximum life of an elected parliament is 5 years, but it may be
dissolved earlier by the President; last election March 1967; President is
elected by parliament for 5 year term; next election 1976
Political parties and leaders: All People''s Congress (APC), headed by Stevens;
Sierra Leone People''s Party (SLPP) is the opposition party
Communists: no party, although there are a few Communists and a slightly larger
number of sympathizers
Member of: Commonwealth, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Republic of Singapore
Type: republic within Commonwealth since separation from Malaysia in August 1965
Capital: Singapore
Legal system: based on English common law; constitution based on preindependence
State of Singapore constitution; legal education at University of Singapore;
has not accepted compulsory ICJ jurisdiction
Branches: ceremonial President; executive power exercised by Prime Minister and
cabinet responsible to unitary legislature
Government leaders: President, Dr. Benjamin Sheares; Prime Minister, Lee Kuan Yew
Suffrage: universal over age 20; voting compulsory
Elections: normally every 5 years
Political parties and leaders: government -- People''s Action Party (PAP), Lee
Kuan Yew; opposition ~- Barisan Sosialis Party (BSP), Dr. Lee Siew Choh;
Communist Party illegal
Voting strength (1968 election): PAP returned unopposed in 51 of 58 constituencies;
in remaining 7 constituencies PAP received 84% of vote, independents 9%;
Worker''s Party 4%; BSP boycotted election
Member of: ASEAN, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, U.N., UNESCO, UPU, WHO,
WMO
Legal name: Somali Democratic Republic
Type: republic; under military rule since October 1969
Capital: Mogadiscio
Political subdivisions: 8 regions, 47 districts
Organization: the junta has assumed all authority, calling itself the Supreme
Revolutionary Council, membership of which consists of 21 army and 5 police
officers; the Council has abrogated the constitution, dissolved the parliament,
and banned political parties
Government leader: President of the Supreme Revolutionary Council, Gen. Mohamed
Siad Barre
Member of: EAMA, FAO, IBRD, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UNICEF, UPU,
WHO
Legal name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative, Cape Town; judicial, Bloemfontein
Political subdivisions: 4 provinces, each headed by centrally appointed
administrator; provincial councils, elected by white electorate, retain
limited powers
Legal system: based on Roman-Dutch law and English common law; constitution
enacted 1961, changing the Union of South Africa into a Republic; possibility
of judicial review of Acts of Parliament concerning dual official languages;
accepts compulsory ICJ jurisdiction, with reservations
Branches: President as formal chief of state; Prime Minister as head of
government; Cabinet responsible to bicameral legislature; lower house
elected directly by white electorate; upper house indirectly elected and
appointed; judiciary maintains substantial independence of government
influence
Government leader: Prime Minister Balthazar J. Vorster
Suffrage: general suffrage limited to whites over 18 (17 in Natal Province)
Elections: must be held at least every 5 years; last elections April 1970
Political parties and leaders: National Party, B. J. Vorster, P. W. Botha,
B. J. Shoeman, M. C. Botha, Jan De Klerk; United Party, Sir De Villiers
Graaf; Progressive Party, Jan Steytler, Helen Suzman; Herstigte Nasionale
Party, Albert Hertzog, Jaap Marais
Voting strength (1970 general elections): of 166 legislative seats, National
Party 118, United Party 47, Progressive Party 1
Communists: small Communist Party illegal since 1950; party in exile maintains
headquarters in London; Dr. Yasuf Dadoo, Michael Harmel, Joe Slovo
Other political groups: (insurgent groups in exile) African National Congress (ANC),
Oliver Tambo; Pan-Africanist Congress (PAC), leadership in dispute
Member of: IAEA, IBRD, ICAO, IHB, IMF, ITU, U.N., UPU, WHO, WMO
Legal name: Territory of South-West Africa
Type: administered as part of Republic of South Africa, under a League of
Nations mandate; U.N. formally ended South Africa''s mandate, and status now
in dispute
Capital: Windhoek
Political subdivisions: police zone (police-protected area, consisting of 17
magisterial districts, in which all-white settlement and several Bantu
reserves are found), northern territories (exclusively Bantu magisterial
districts under control of officials of South African Department of Bantu
Administration and Development)
Legal system: based on Roman-Dutch Taw and customary law
Branches: administrator, appointee of South African Government, principal
local executive; structure similar to that of a province of the Republic;
South-West Africa elects 4 Senators and 6 lower house members to the
Republic''s legislature; judicial system patterned on that of Republic
Government leader: J.G. van der Wath, Administrator
Suffrage: limited to white adults
Elections: last general election, 1970
Political parties and leaders: white parties -- National Party (NP), led in
South-West Africa by A. H. du Plessis; United National South-West Party
(UNSWP), J. P. Niehaus; nonwhite parties -- South-West Africa People''s
Organization (SWAPO), almost exclusively based on Ovambo tribe led by Sam
Nujoma, in exile; South-West Africa National Union (SWANU), primarily based
on Herero tribe, leaders in exile; National Unity Democratic Organization
(NUDO), primarily based on Herero tribe led by Clements Kapuuo
Voting strength: NP (1970 election) won all 10 seats in Republic legislature
and all 18 seats in South-West Africa Legislative Assembly
Communists: no Communist Party, but some influence by South African Communists
and other Communists on South-West African Bantu outside territory
301
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: The Independent State of Western Samo','7ef2d988b3fec73ccc317c53bb79fbce813d7ff04d37d722a4d412175a6dc337','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1cc1c42930ef6a95133ba35a6a66af732556bb66df18d2adeb02f882e183167',1971,'AU','Australia','government',52,'a
Type: constitutional monarchy under native chief; special treaty relationship
with New Zealand
Capital: Apia
Legal system: based on English common law and local customs; constitution came
into effect upon independence in 1962; judicial review of legislative acts
with respect to fundamental rights of the citizen; has not accepted
compulsory ICJ jurisdiction
Branches: Head of State and Executive Council; Legislative Assembly; Supreme
Court, Court of Appeal, Land and Titles Court, village courts
Government leaders: Head of State, Malietoa Tanumafili I1; Prime Minister,
Tupua Tamasese Leaof IV
Suffrage: 45 Samoan members of Legislative Assembly are elected by holders of
matai (heads of family) titles (about 5,000); 2 European members are elected
by universal adult suffrage
Elections: held triennially
Political parties and leaders: no clearly defined political party structure
Communists: unknown
Member of: ADB, WHO
Legal name: People''s Democratic Republic of Yemen
Type: republic, but without constitution
Capital: Aden; Medinat al-Shaab, administrative capital
Political subdivisions: 6 provinces
Legal system: based on Islamic law (for personal matters) and English common
jaw (for commercial matters); highest judicial organ, Federal High Court,
interprets constitution and determines disputes between states
Branches: General Command of the National Front (NF) acts as legislature pending
adoption of a constitution; Presidential Council, cabinet
Government leaders: 5-man Presidential Council, Prime Minister Muhammed Ali
Haytham; NF Secretary General Abd Al-Fattah Ismail (the real government
strongman)
Political parties and leaders: National Front (NF), only legal party
Communists: few known
Member of: U.N.
Legal name: Yemen Arab Republic
Type: republic
Capital: Sana
Political subdivisions: 8 provinces
Legal system: based on Turkish law, Islamic law, and local customary law; first
constitution promulgated December 1970; has not accepted compulsory ICd
jurisdiction
Branches: President, Prime Minister, Republican Council
Government leaders: President Abd al-Rahman Iryani; acting Prime Minister
abd al-Salam Sabrah
Member of: Arab League, FAO, ICAO, ITU, U.N., UNESCO, UPU, WHO','137ab389c6b38eb4447a23f4246d5e1f67d4f07b6af644ad2911d71ae7368086','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4274cd946b60bd910b6a63c3d302700bc8240c3941730db42788eeacb8412507',1971,'JP','Japan','government',58,'Legal name: Socialist Federal Republic of Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
Political subdivisions: 6 republics with 2 autonomous provinces (within the
Republic of Serbia)
Legal system: mixture of civil law system and Communist legal theory; constitution
adopted 1963 and amended in 1967 and 1968; in early stage of development is
a system of judicial review of legislative acts in Constitutional Court
(a quasi-judicial body); legal education at several law schools; has not
accepted compulsory ICJ jurisdiction
Branches: parliament (Federal Assembly) constitutionally supreme; executive
includes cabinet (Federal Executive Council) and the Federal Administration;
independent judiciary; President of Republic is largely a figurehead post
but current President, because of personal status, wields great power both
in making and executing policy
Government leader: Josip Broz Tito, President of Republic and President of
League of Communists of Yugoslavia
Suffrage: universal over age 18
Elections: Federal Assembly elected every 4 years
Political parties and leaders: League of Communists of Yugoslavia (LCY) only;
leaders are President Tito and influential presidium executive bureau
members Edvard Kardelj, Veljko Vlahovic, Mijalko Todorovic, Vladimir
Bakaric, and Krste Crvenkovski
Voting strength: Voter participation in national elections has declined, as
follows -- 1963, 95.5%; 1965, 93.6%; 1967, 89%; 1969, 88%
Communists: 1.2 million
Other political or pressure groups: Socialist Alliance of Working People of
Yugoslavia (SAWPY), the major mass front organization for the LCY;
Confederation of Trade Unions of Yugoslavia (CTUY), Union of Youth of
Yugoslavia (UYY), Federation of Yugoslav War Veterans (SUBNOR)
Member of: CEMA (participates in certain commissions), EEC (trade agreement with
EEC initiated 3 Feb 1970), FAO, GATT, IAEA, IBRD, ICAO, IHB, ILO, IMCO,
IMF, ITU, OECD (participant in some activities), U.N., UNESCO, UPU, WHO, WMO
363
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Legal name: Republic of Zambia
Type: republic since October 1964
Capital: Lusaka
Political subdivisions: 8 provinces
Legal system: based on English common law and customary law; constitution adopted
1964; judicial review of legislative acts in an ad hoc constitutional
council; legal education at University of Zambia in Lusaka; has not accepted
compulsory ICJ jurisdiction
Branches: modified presidential system; unicameral legislature; judiciary
Government leader: President Kenneth Kaunda
Suffrage: universal adult
Elections: last general election December 1968
Political parties and leaders: United National Independence Party (UNIP),
Kenneth Kaunda; African National Congress (ANC), Harry Nkumbula
Voting strength (1968 election): UNIP had 73% of vote, but 30 of its candidates
were unopposed; strength probably would have been over 80% if these seats
had been contested
Communists: no Communist Party, but sympathizers of socialism in upper levels
of government, UNIP, and labor unions
Member of: Commonwealth, FAO, IAEA, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU, U.N.,
UNESCO, UPU, WHO, WMO','68136c9d48170e2d30ca1701a75a9a814a60ec0217975ddf22c753f82ab8d6c0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c65b951bda98415e421e0e3c829e76357ba212b9c9b320408120637cd8a7a5c7',1971,'US','United States','government',61,'Legal name: United States of America
Legal system: based on English common law; dual system of courts, state and
federal; constitution adopted 1789; judicial review of legislative acts;
accepts compulsory ICJ jurisdiction, with reservations
Voting strength (1968 presidential election): Republican Party (Nixon),
31,770,237; Democratic Party (Humphrey), 31,270,533; Independent (Wallace),
9,897,141; minor parties, 239,910
Communists: Party membership, 10,000-11,000 (est.); General Secretary, Gus Hall','c116dc3ce33393cd79730fb543cf5f03b82b73a162756c5d16b20fcbdc29b6ac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('776d2b744a6c3d414db79dac34a5310aa71c617c7cc0f2a2d291dec2b7d9a805',1971,'','','government',2,'Legal name: Kingdom of Afghanistan
Type: constitutional monarchy
Capital: Kabul
Political subdivisions: 28 provinces with centrally appointed governors
Legal system: based on Islamic law; constitution adopted 1964; although provided
for in the law on judicial organization, there has as yet been no judicial
review of legislative acts; legal education at University of Kabul; has not
accepted compulsory ICJ jurisdiction
Branches: bicameral legislature with cabinet responsible to lower house
_ (People''s Council); although elected Parliament is exerting ‘increasing
influence, it has not as yet passed much significant legislation or established
effective control over the centralized administration and has no real voice
in military matters; progressive forces led by King liberalizing the regime;
independent judiciary established in 1967, has not yet had a major institutional
impact; it is too early to assess its future role
Government leaders: King Mohammad Zahir Shah; Prime Minister Abdul Zahir
Suffrage: universal over age 20
Elections: first free nationwide direct elections by secret ballot and universal
suffrage (under 1964 Constitution) held for Parliament August and September
1965; second elections held August and September 1969; lower house of Parliament
(216 deputies) and one-third (28 Senators) of upper house (Council of Elders)
elected for 4-year terms; 28 Senators appointed by King; remaining 28
Senators to be elected by Provincial Councils when formed
Political parties and leaders: no political parties permitted yet, but enabling
legislation has been passed by Parliament and awaits the King''s signature;
several groups have begun to meet informally, extremists of left and right
best organized
Communists: there are 2 pro-Moscow Communist groups which are ideologically
pro-Soviet; size is reported to be about 350-500 active members; several
other groups, further to left, with several hundred members and sympathizers
Other political or pressure groups: progressive forces led by King Zahir and
cabinet dominate current situation with nascent leftist and rightist groups
forming for action when parties are permitted
1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GOVERNMENT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Member of: ADB, Colombo Plan, FAO, FUND, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO,
ITU, U.N., UNESCO, UPU, WHO, WMO
Legal name: People''s Republic of Albania
Type: Communist state
Capital: Tirane
Political subdivisons: 27 rethet (districts), including capital, 200 localities,
2,600 villages
Legal system: based on Soviet law; constitution adopted 1950; judicial review
of legislative acts only in the Presidium of the People''s Assembly, which
is not a true court; legal education at State University of Tirane; has not
accepted compulsory ICJ jurisdiction
Branches: People''s Assembly, Council of Ministers, judiciary
Government leaders: President, Presidium of the People''s Assembly, Haxhi Lleshi;
Chairman of Ministers, Mehmet Shehu
Suffrage: universal and compulsory over age 18
Elections: national elections theoretically held every 4 years; last elections
September 1970
Political parties and leaders: Albanian Workers Party only; First Secretary,
Enver Hoxha
Voting strength (1970 election); 99.9% Communist
Communists: 75,637 party members (1970)
Member of: CEMA, IAEA, ITU, U.N., UNESCO, UPU, WHO, WMO; has not participated
in CEMA since rift with U.S.S.R. in 1961; officially withdrew from Warsaw
Pact 13 September 1968
Legal name: Democratic and Popular Republic of Algeria
Type: republic
Capital: Algiers
Political subdivisions: 15 Wilayas (departments or provinces)
Legal system: based on French and Islamic law, with socialist principles;
constitution adopted by referendum 1963; judicial review of legislative acts
in ad hoc Constitutional Council composed of various public officials,
including several Supreme Court justices; Supreme Court divided into 4
chambers; legal education at University of Algiers; has not accepted
compulsory ICJ jurisdiction
Branches: executive dominant, unicameral legislature has not met since June
1965 coup d''etat but was never formally suspended, judiciary
Government leader: Houari Boumediene, President of Council of the Revolution
and President of the Council of Ministers, overthrew elected President
Ahmed Ben Bella 19 June 1965
Suffrage: universal over age 19
Elections: presidential 15 September 1963; departmental assemblies 25 May 1969;
local councils 14 February 1971
% Political parties and leaders: National Liberation Front (FLN), Ahmed Kaid
Voting strength (1963 election): 100% FLN
Communists: 400 (est.); Communist Party illegal (banned 1962)
Member of: Arab League, FAO, IAEA, IBRD, ICAQ, IDA, ILO, IMCO, IMF, ITU, OAU,
OPEC, U.N., UNESCO, UPU, WHO
Legal name: The Valleys of Andorra
Capital: Andorra
Political subdivisions: 6 districts -- Andorra la Vella, Sant Julia de Loria,
Encamp, Canillo, La Massana, and Ordino
Type: unique coprincipality under formal sovereignty of President of France and
Spanish Bishop of Seo de Urgel, who are represented by veguers
Legal system: based on French and Spanish civil codes; Plan of Reform adopted
1866 serves as constitution; no judicial review of legislative acts; has
not accepted compulsory ICJ jurisdiction
Branches: legislature (General Council) of 24 members with one-half elected
every 2 years for 4-year term; executive -- syndic and a deputy sub-syndic
chosen by General Council for 3-year terms; judiciary chosen by coprinces
who appoint 2 civil judges, a judge of appeals, and 2 Batles (court
prosecutors )
Suffrage: males of 25 or over who are third generation Andorrans vote for
General Council members; same right granted to women in April 1970
Elections: half of General Council chosen every 2 years, last election December
1971
Political parties and leaders: no political parties but only partisans for
particular independent candidates for the General Council, on the basis of
competence and personal ity
Legal name: Province of Angola
Type: overseas province of Portugal
Capital: Luanda
Political subdivisions: 15 administrative districts including the coastal
exclave of Cabinda
Legal system: Portuguese civil codes and customary law; legal education
obtained in Portugal
Branches: Governor General appointed by Ministry of Overseas in Lisbon is
executive officer responsible for internal administration; he also has
prescribed legislative functions which he shares with Legislative Council
of elected and nominated members; all action in Province may be vetoed by
Minister of Overseas; independent judiciary
Government leader: Governor General Lt. Col. Camilo Rebocho Vaz
Suffrage: all adults able to read and write Portuguese and in full possession
of political and civil rights
Political parties and leaders:. only legal group is Portuguese National Popular
Action (ANP), formerly the National Union (UN)
Other political or pressure groups: principal opposition groups which are
carrying out insurgency are Revolutionary Government of Angola in exile (GRAE),
led by Holden Roberto; Popular Movement for the Liberation of Angola (MPLA),
led by Agostinho Neto; and National Union for the Total Independence of Angola
(UNITA), led by Jonas Savimbi
Legal name: State of Antigua
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: St. Johns
Political subdivisions: 6 parishes, 2 dependencies (Barbuda, Redonda)
Legal system: based on English law; British Caribbean Court of Appeal has
exclusive original jurisdiction and an appellate jurisdiction, consists of
Chief Justice and 5 justices
Government leaders: Premier George Herbert Walter; Governor Wilfred Ebenezer Jacobs
Suffrage: universal suffrage age 21 and over
Elections: every 5 years; last general election 11 February 1971; last by-election
August 1968
Political parties and leaders: Antigua [aber Party (ALP), Vere C. Bird;
Progressive Labor Movement (PLM), George Herbert Walter;
Antigua People''s Party (APP), J. Rowan Henry
Voting strength: 1971 election -- Legislative Council seats -- ALP 4, PLM 13,
other 4 unknown
Communists: none known
Member of: CARIFTA
Legal name: Argentine Republic
Type: republic; military regime in control since coup in June 1966
Capital: Buenos Aires
Political subdivisions: 22 provinces, 1 district (Federal Capital), and 1
territory
Legal system: based on Spanish and French civil codes; constitution adopted
1853 partially superseded in 1966 by the Statute of the Revolution which
takes precedence over the constitution when the two are in conflict;
judicial review of legislative acts; legal education at University of
Buenos Aires and other public and private universities; has not accepted
compulsory ICJ jurisdiction
Branches: presidency; national judiciary; legislature dismissed after June
1966 coup
Government leader: Gen. Alesandro Lanusse, President until 1 January 1973, when
the Air Force member of the 3-man junta, that removed Brig. Gen. Roberto
Levingston on 23 March 1971, is scheduled to replace him
Suffrage: universal and compulsory age 18 and over
Elections: present government has announced plans for holding elections
by 25 March 1973
Political parties: ban imposed in 1966 now lifted and parties in process of
reorganizing
Voting strength: the old political groupings probably continue to
command the loyalty of the populace according to the following figures
(est.) -- Peronists (of all types), 35%; Radicals (former People''s Radical
Civic Union, UCRP), 25%; Conservatives (former National Federation of
Centrist Parties), 5%; minor parties, 10%; nonaligned, 25%
Other political or pressure groups: Argentine armed forces, Peronist-dominated
labor movement, The Hour of the People (loose grouping of moderate politicians
with various party affiliations), National Meeting of the Argentines (loose
grouping of communist and leftist politicians), Argentine Industrial Union
(manufacturers'' association), Argentine Rural Society (large landowners!
association), business organizations, students, and the Catholic Church
Approved For Release 2004/08/31 : ClA-RDP79-01051A000400010002-1
GOVERNMENT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Member of: FAO, IADB, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, LAFTA,
OAS, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Austria
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states (Laender) including the capital
Legal system: civil law system with Roman law origin; constitution adopted 1920,
repromulgated in 1945; judicial review of legislative acts by a Constitutional
Court; separate administrative and civil/penal supreme courts; legal education
at Universities of Vienna, Graz, Innsbruck, Salzburg, and Linz; has not
accepted compulsory ICJ jurisdiction
Branches: bicameral Parliament, directly elected President whose functions are
largely representational, independent federal judiciary
Government leaders: Chancellor Bruno Kreisky; President Franz Jonas
Suffrage: universal over age 19; compulsory for presidential elections
Elections: presidential, every 6 years (next 1977); parliamentary, every 4
years (next 1975) ;
Political parties and leaders: Socialist Party of Austria (SPO0e), Bruno Kreisky,
Chairman; Austrian People''s Party (OeVP), Karl Schleimzer, Chairman; Liberal
Party (FPOe), Friedrich Peter, Chairman; Communist Party, Franz Muhri,
Chairman
Yoting strength (1970 election): 50.2% SPOe, 43.0% OeVP, 5.4% FPOe, 0.4% dissident
Socialist, 1.4% Communist
Communists: membership 26,000; activists 7,000-8,000; 60,705 votes in 1971 election
salar of: Council of Europe, ECE, EFTA, IAEA, ICAO, OECD, Seabeds Committee, U.N.,
NESCO, WHO
Legal name: Commonwealth of the Bahama Islands
Type: British dependent territory with full internal autonomy under U.K. rule
Capital: Nassau (New Providence Island)
Legal system: based on English law
Branches: Governor (appointed by Queen); bicameral legislature (appointed
Senate, elected House); Executive (Premier and Cabinet); judiciary
Government leaders: Prime Minister Lynden 0. Pindling; Governor Sir Francis
Cumming-Bruce
Elections: House of Assembly (10 April 1968); next elections must be held by
10 April 1973
Political parties and leaders: Progressive Liberal Party (PLP), predominantly
Negro, Lynden 0. Pindling; United Bahamian Party (UBP), white establishment,
Sir Roland Symonette; Free Progressive Liberal Party (Free PLP), Cecil
Wallace Whitefield
Voting strength (1968 election): 73% PLP, 27% UBP; House of Assembly -- PLP
29 seats, UBP 7 seats, LP 1 seat, independent 1 seat
Communists: none known
Legal name: State of Bahrain
Type: traditional monarchy; independence declared in 1971
Capital: Al Manamah
Legal system: based on Islamic law and English common law
Government leader: Amir ''Isa ibn Salman Al-Khalifah
Political parties and pressure groups: political parties prohibited; no significant
pressure groups although numerous small clandestine groups are active
Communists: few known
Member of: Arab League, U.N.
Legal name: Barbados
Type: independent state since November 1966, recognizing Elizabeth II as chief
of state
Capital: Bridgetown
Regional breakdown: 11 parishes administered by 3 district councils
Legal system: English common law; constitution came into effect upon
independence in 1966; no judicial review of legislative acts; has not
accepted compulsory ICJ jurisdiction
Branches: legislature consisting of a 21-member appointed Senate and a
24-member elected House of Assembly; cabinet headed by Prime Minister
Government leader: Prime Minister Errol Barrow
Suffrage: universal over age 18
Elections: House of Assembly members have terms no longer than 5 years;
general election held 3 November 1966
Political parties and leaders: Democratic Labor Party (DLP), Errol Barrow;
Barbados National Party (BNP), Ernest D. Mottley; Barbados Labor Party
(BLP), H. Bernard St. John, J. M. G. "Tom" Adams
Voting strength (1966 election): Democratic Labor Party (DLP), 49.5%; Barbados
National Party, 10.1%; Barbados Labor Party, 32.7%; Independent, 7.7%;
House of Assembly seats -- DLP 14, BLP 9, BNP 1
Communists: not significant
Other political or pressure groups: People''s Progressive Movement (PPM), a
small pro-Castro black-nationalist group led by Calvin Alleyne
Member of: CARIFTA, Commonwealth, ICAO, IMF, OAS, Seabeds Committee (observer),
U.N.','30fb35d3a4724c5237f359a5504ea04d49ac3e3afb8ddbdd0ee2944e8ff23db7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('031491a826617a12a3bcab9a2226029dc90c3a8eadb185869b9feb2cbf79146a',1971,'BR','Brazil','government',8,'Legal name: Republic of Bolivia
Type: republic; de-facto military-civilian coalition government by the Popular
Nationalist Front
Capital: La Paz (seat of government); Sucre (judicial capital)
Political subdivisions: 9 departments with limited autonomy
Legal system: based on Spanish law and Code Napoleon; constitution adopted 1967;
constitution in force except where contrary to dispositions dictated by
revolutionary governments since 1969; legal education at University of San
Andres and several others; has not accepted compulsory ICJ jurisdiction
Branches: executive; congress of two chambers (Senate and Chamber of Deputies),
congress disbanded after 26 September 1969 ouster of President Siles;
judiciary
Government leaders: President Hugo Banzer Suarez
Suffrage: universal and compulsory at age 18 if married, 21 if single
Elections: none scheduled
Political parties and leaders: The Nationalist Revolutionary Movement (MNR) led
by Victor Paz Estenssoro and the Bolivian Socialist Falange (FSB) led by Mario
Gutierrez are part of the governing coalition and the only significant parties
in the country; other political parties, although numerous, are relatively
inactive and exert little influence including Nationalist Leftist Revolutionary
Party (PRIN) Juan Lechin Oquendo (in exile), Christian Democratic Party (PDC)
Benjamin Miguel, Revolutionary Christian Democratic Party (PDCR) Alfonso Camacho,
Socialist Party (PS) Marcelo Quiroga and Alberto Baily, and Leftist Revolutionary
Movement (MIR) Pablo Ramos Sanchez (in exile); with the exception of the
Authentic Revolutionary Party (PRA) led by Walter Guevara Arze, the parties of
the FRB coalition have practically disappeared including Popular Christian
Movement (MPC) Hugo Bozo, Leftist Revolutionary Party (PIR) Ricardo Anaya, and
Social Democratic Party (PSD) Hugo Sandoval
Voting strength (1966 elections): Frente de la Revolucion Boliviana (a coalition
composed of the MPC, PIR, PRA, PSD, and two interest groups, the campesinos
and Chaco War Veterans) 61%, FSB 12%, MNR 10%, other 17%
Member of: IAEA, IADB, ICAO, International Tin Council, LAFTA and Andean Sub-Regional
Group (created in May 1969 within LAFTA), OAS, U.N.
31
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
svanpaanusionm canara cane
Approved Fo
r Release 2004/08/31 : CIA-RDP79-01051A0004
- 00010002-1
Legal name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: 9 provinces
Legal system: civil law system influenced by English constitutional theory ;
constitution adopted 1831, since amended; judicial review of legislative
acts; legal education at 4 law schools; accepts compulsory ICdJ jurisdiction,
with reservations
Branches: executive branch consists of King and cabinet; cabinet responsible to
bicameral parliament; independent judiciary; coalition governments are usual
Government leader: Prime Minister Gaston Eyskens
Suffrage: universal over age 2]
Elections: held 7 November 1971 (held at least once every 4 years)
Political parties and leaders: Social Christian, Senator Robert Houben, party
president; Socialist, Edmund LeBurton and Joris Van Eynde, co-presidents ;
Liberty and Progress, Senator P. Descamps , party president; Francophone
Democratic Front-Walloon Rally (Walloon nationalist), Jean Duvieusart,
party president; Volksunie (Flemish Nationalist), Wim Jorrisen, party
president; Communist, Marc Drumeaux, president of political bureau
Voting strength (1971 election): 67 seats Social Christian, 61 seats Socialist,
5 seats Conmunist, 34 seats Liberty and Progress, 21 seats Volksunie, 2]
seats Walloon nationalist
Communists: 439; splinter parties (Chinese-oriented) 400
Member of: Benelux, BLEU (Bel gium-Luxembourg Economic Union), Council of Europe,
ECE, ECOSOC, EC, EMA, FAO, TAEA, ICAO, IMF, NATO, OECD, Seabeds Committee,
U.N., UNESCO, WEU, WHO
Legal name: Colony of Bermuda
Type: British crown colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English Taw
Branches: elected House of Assembly; appointed Legislative Council; Executive
Couricil (cabinet)
Government leaders: Governor Lord Martonmere; Prime Minister Sir Henry Tucker
Suffrage: universal over age 21; compulsory
Elections: at least once every 5 years; last general election, May 1968
Political parties and leaders: United Bermuda Party (UBP), Sir Henry Tucker;
Progressive Labor Party (PLP), Lois Browne-Evans (PLP parliamentary
leader); Bermuda Democratic Labor Party (BDP), Arnold A. Francis,
Charles W. Mayne
Voting strength (1968 elections): UBP 56.5%, PLP 34.4%, BDP 6.7%, Independents
2.4%; House of Assembly seats -- UBP 30, PLP 10
Legal name: Kingdom of Bhutan
Type: monarchy; special treaty relationship with India
Capital: Thimphu
Political subdivisions: 4 regions (east, central, west, south), further
divided into 15-18 subdivisions
Legal system: based on Indian law and English common Jaw; in 1964 the
King assumed full power -- no constitution existed beforehand; a supreme
court hears appeals from district administrators; has not accepted
compulsory ICJ jurisdiction
Branches: appointed minister and indirectly elected assembly consisting of
village elders, monastic representatives, and all district and senior
government administrators
Government leader: King Jigme Dorji Wangchuck
Suffrage: each family has one vote :
Elections: popular elections on village level held every 3 years
Political parties: all parties illegal
Communists: no overt Communist presence
Other political or pressure groups: Buddhist clergy
Member of: Colombo Plan, UPU, U.N.
Legal name: Republic of Botswana
Type: republic since independence in September 1966
Capital: Gaberone
Political subdivisions: 12 administrative districts
Legal system: based on English common law and local customary law; constitution
came into effect 1966; judicial review limited to matters of interpretation;
legal education at University of Botswana, Lesotho and Swaziland (located
in Lesotho); has not accepted compulsory ICJ jurisdiction
Branches: executive -- President appoints and is the chief minister in the
cabinet which is responsible to Legislative Assembly; legislative --
Legislative Assembly with 31 popularly elected members and 4 members elected
by the 31 representatives, House of Chiefs with deliberative powers only;
judicial -- African courts administer customary law, High Court and
subordinate courts have criminal jurisdiction over all residents, Court of
Appeal has appellate jurisdiction
Government leader: President Seretse Khama
Suffrage: universal, age 21 and over
Elections: general elections held 18 October 1969
Political parties and leaders: Botswana Democratic Party (BDP), Seretse Khama;
Bechuanaland People''s Party (BPP), P.G. Matante; Botswana Independence
Party (BIP), Motsamai Mpho; Botswana National Front (BNF), Kenneth Koma
Voting strength: (October 1969 election) 68% BDP (24 seats); 13.5% BPP (3 seats);
12% BNF (3 seats); 6% BIP (1 seat)
Communists: no known Communist organization; Koma of BNF has long history of
Communist contacts
Member of: Commonwealth, FAO, OAU, U.N., WMO
Legal name: Federative Republic of Brazil
Type: federal republic; military-backed presidential regime since April 1964
Capital: Brasilia
Political subdivisions: 22 states, 4 territories, federal district (Brasilia)
Legal system: based on Latin codes; dual system of courts, state and federal;
constitution adopted 1967 and extensively amended in 1969; has. not accepted
compulsory ICJ jurisdiction
Branches: strong executive with very broad powers; bicameral legislature
(powers of the two bodies have been sharply reduced); 11-man Supreme Court
Government leader: President Emilio Garrastazu Medici
Suffrage: compulsory over age 18, except illiterates and those stripped of their
political rights; approximately 30 million registered voters in October 1970
Elections: President Medici''s successor will be chosen on 15 January 1974 and
will take office in March
Political parties and leaders: National Renewal Alliance (ARENA), pro-government;
Brazilian Democratic Movement (MDB), opposition
Communists: less than 13,000; 100,000 sympathizers (est. )
Member of: FAO, GATT, IADB, IAEA, IBRD, ICAO, IHB, ILO, IMCO, IMF, ITU, LAFTA,
OAS, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Colony of British Honduras
Type: British crown colony; obtained full internal self-government in January
1964
Capital: Belize City; seat of government in Belmopan
Legal system: English law; constitution came into force in 1964, although
country remains a British colony .
Branches: 18-member elected National Assembly and 8-member Senate (either house
may choose its speaker or president, respectively, from outside its
elected membership); cabinet; judiciary
Government leader: Premier George Price
Suffrage: universal adult (probably 21)
Elections: within 5 years of last election held 5 December 1969
Political parties and leaders: People''s United Party (PUP), George Price;
National Independence Party (NIP), Philip Goldson; People''s Development
Movement (POM) , Dean Lindo
Voting strength (1969 election): 57.6% PUP, 39.8% NIP, 2.6% void ballots
Communists: none identified
Other political or pressure groups: Christian Workers! Union (CWU) which is
connected with PUP; United Black Association for Development (UBAD) ,
Evan Hyde
Legal name: State of Brunei
Type: British protectorate; constitutional sultanate
Capital: Bandar Seri Begawan
Political subdivisions: 4 administrative districts
Legal system: based on Islamic law; constitution promulgated by the Sultan in
1959, though Brunei remains British protectorate; scheduled to become
independent in late 1970 é
Branches: chief of state is Sultan (advised by appointed Privy Council) who
appoints Executive Council and majority of Legislative Council
Government leader: Sultan Hassanal Bolkiah
Suffrage: universal age 21 and over; 3-tiered system of indirect elections;
popular vote cast for lowest level (district councilors)
Elections: last elections -- March 1965
Political parties and leaders: antigovernment People''s Independence Front
(Baker), Pengiran Dato Ali, chairman
Voting strength (1965 election): 6 of 10 elective seats won by defunct
antigovernment Partai Ra''ayat members
Legal name: People''s Republic of Bulgaria
Type: Communist state
Capital: Sofiya
Political subdivisions: 28 okrugs (districts), including capital city of Sofia
Legal system: based on civil law system, with Soviet law influence; new
constitution adopted in 1971; judicial review of legislative acts in the
State Council; legal education at University of Sofiya; has not accepted
compulsory ICJ jurisdiction
Branches: legislative (National Assembly), Council of Ministers, judiciary
Government leaders: Todor Zhivkov, Chairman, State Council (chief of state);
Stanko Todorov, Chairman, Council of Ministers (premier)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every 4 years for National Assembly; last elections
held on 27 June 1971; 99.8% of the electorate voted
Political parties and leaders: Bulgarian Communist Party, Todor Zhivkov, First
Secretary; Bulgarian National Agrarian Union, a puppet party, Georgi Traykov,
secretary
Communists: 699,000 full members (April 1971)
Mass organizations and front groups: Fatherland Front, Dimitrov Communist Youth
League, Central Council of Trade Unions, National Committee for Defense of
Peace, Union of Fighters Against Fascism and Capitalism, Committee of
Bulgarian Women, All-National Committee for Bulgarian-Soviet Friendship
Member of: CEMA, GATT, IAEA, ICAO, ILO, IMCO, ITU, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO, Warsaw Pact, International Organization of Journalists,
International Medical Association, International Radio and Television
Organization
Legal name: Union of Burma
Type: military dictatorship since suspension of constitution in 1962
Capital: Rangoon
Political subdivisions: Burma proper, 4 other constituent states and 1 special
division for the ethnic minorities; subdivided into divisions, districts,
muncipalities, townships, and villages
Legal system: based on English common law and incorporates Buddhist, Hindu,
and Islamic relgious law; constitution of 1947 superseded by acts of the
new Revolutionary Government, which seized power in 1962; legal education
at Universities of Rangoon and Mandalay; has not accepted compulsory ICJ
jurisdiction
Branches: Revolutionary Council rules through a Council of Ministers
Government leader: Chairman of Revolutionary Council, Gen. Ne Win
Suffrage: universal over age 18 under suspended constitution
Elections: none held under present regime
Political parties and leaders: government-sponsored Burmese Socialist Program
Party only legal party
Communists: 5,000
Member of: Colombo Plan, FAQ, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF,
ITU, Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Burundi
Type: republic; military government since November 1966; no constitution
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into 18 arrondissements and 78
communes
Legal system: based -on German and French civil codes and customary Taw; has not
accepted compulsory ICJ jurisdiction
Branches: presidential cabinet with Council of Ministers; no legislature
Government leader: President Michel Micombero
Elections: latest legislative election May 1965
Political parties and leaders: National Party of Unity and Progress (UPRONA),
a predominantly Tutsi party, is only legitimate party; other parties, mostly
Hutu, since 1961 have been subverted, suppressed, intimidated by UPRONA, and
have ceased to exist
Voting strength (1965 elections): UPRONA won 21 of 33 Assembly seats; Hutu-
dominated People''s Party won 10
Communists: no Communist party; resumed diplomatic relations with The People''s
Republic of China in October 1971 following a six-year suspension; U.S.S.R.
and North Korea have diplomatic missions in Burundi
Member of: EAMA, ECA, IBRD, ICAO, ILO, IMO, OAU, U.N., UNESCO, WHO, WMO
Legal name: Khmer Republic
Type: constitution being revised to support presidential parliamentary system
Capital: Phnom Penh
Political subdivisions: 20 provinces with centrally appointed governors,
3 independent municipalities
Legal system: based on French civil law system; constitution adopted 1947 and
amended 1960; no judicial review of legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
Branches: constituent assembly replaced legislature October 1971 for purpose of
writing new constitution
Government leader: chief of state, Cheng Heng; Prime Minister, Lon Nol; Prime
Minister Delegate, Sirik Matak
Suffrage: universal over age 20
Elections: postponed indefinitely
Political parties and leaders: none
Communists: party strength unknown; known Communist troops in excess of 15,000
Member of: ADB, Colombo Plan, IAEA, IBRD pending, ICAO, IMF pending, U.N., WMO
Legal name: Federal Republic of Cameroon
Type: federal republic; one-party presidential regime
Capital: Yaounde
Political subdivisions: East Cameroon and West Cameroon make up two parts of
federation, divided into 9 divisions (West), 30 departments (East),
6 administrative regions
Legal system: based on French civil law system, with common law influence;
constitution adopted 1961; judicial review in Federal Court of Justice, when
a question of constitutionality is referred to it by the President of the
Republic; has not accepted compulsory ICJ jurisdiction
Branches: federal -- executive, legislative, judicial; East Cameroon and West
Cameroon each has own government as well
Government leader: President Ahmadou Ahidjo
Suffrage: universal over age 2]
Flections: presidential elections held 28 March 1970; federal parliamentary
elections last held 7 June 1970
Political parties and leaders: single party, Cameroonian National Union (UNC),
President Ahmadou Ahidjo
Voting strength: (1970 elections - 98% in presidential; 94% in parliamentary
Communists: no Communist Party or significant sympathizers
Other political or pressure groups: Cameroon People''s Union (UPC), illegal exile
group which has engaged in guerrilla warfare in the past and continues to
carry out sporadic terror against the government
Member of: African Development Bank, EAMA, FAO, GATT, IAEA, IBRD, ICAO, ILO,
IMCO, IMF, ITU, Lake Chad Basin Commission, OAU, Seabeds Committee, UDEAC,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Central African Republic
Type: republic; constitution abrogated following military coup in January 1966
Capital: Bangui
Political subdivisions: 14 prefectures, 47 subprefectures
Legal system: based ‘on French, Islamic, and tribal law; in 1966 the Chief of
State assumed all power and abrogated the existing constitution; has not
accepted compulsory ICJ jurisdiction
Branches: Gen. Bokassa heads government and rules by decree; assisted by
cabinet called Council of Ministers; judiciary, including Supreme Court,
court of appeals, criminal court, and numerous lower courts
Government leader: President Jean-Bedel Bokassa
Suffrage: universal over age 2]
Elections: none have been held under Bokassa regime
Political parties and leaders: Black African Social Evolution Movement (MESAN),
ruling party under former regime, still in existence but plays little role,
led by. President Jean-Bedel Bokassa
Communists: no Communist Party or significant number of sympathizers
Member of: EAMA, FAO, GATT, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM, UDEAC, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Dominion of Ceylon (rarely used)
Type: independent state since 1948; recognizes Elizabeth II as sovereign
Capital: Colombo
Political subdivisions: 9 provinces, 22 administrative districts, and four
categories of semiautonomous elected local governments
Legal system: a highly complex mixture of English common law, Roman-Dutch,
Muslim and customary law; constitution adopted 1946-47, new constitution
to be adopted soon; no judicial review of legislative acts; legal
education at Ceylon Law College and University of Ceylon, Peradeniya; has
not accepted compulsory ICJ jurisdiction
Branches: unitary parliamentary form of government; unicameral legislature
and independent judiciary
Government leader: Prime Minister Sirimavo Bandaranaike
Suffrage: universal over age 18, but approximately 1.1 million Indian Tamils
not enfranchised
Elections: national elections, ordinarily held every 5 years (last election
held May 1970); must be held more frequently if government loses
. confidence vote
Political parties and leaders: Sri Lanka Freedom Party, Sirimavo Ratwatte Dias
Bandaranaike, President; Lanka Sama Samaja Party (Trotskyite), N. M.
Perera, President; Mahajana Eksath Peramuna, Philip Gunawardena, President;
Federal Party, S. J. V. Chelvanayakam, leader; United National Party, Dudley
* Senanayake, President; Ceylon Communist Party/Moscow, Pieter Keuneman,
Secretary General; Ceylon Communist Party/Peking, N. Shanmugathasan Faction;
Ceylon Communist Party/Peking, P. Kumarasiri Faction; All Ceylon Tami]
Congress, G. G. Ponnambalam, President
Voting strength (1970 election): 37% Sri Lanka Freedom Party, 38% United
National Party, 9% Lanka Sama Samaja Party, 3.5% Communist Party/Moscow,
5% Federal Party, minor parties and independents accounted for remainder
Communists: approximately 169,000 voted for the Communist Party in the May 1970
general election; Communist Party/Moscow approximately 2,000, Communist
Party/Peking 532 (1968 est.)
55
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
: - 79-01051A000400010002-1
GOVERNMENT ARBROVEe For Release 2004/08/31 : CIA-RDP
Other political or pressure groups: Buddhist clergy, Sinhalese Buddhist lay
groups
Member of: ADB, Colombo Plan, Commonwealth, FAQ, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMCO, IMF, ITU, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Chad
Type: republic; one-party presidential regime since 1962
Capital: Fort-Lamy
Political subdivisions: 14 prefectures
Legal system: based on French civil law system and Chadian customary law;
constitution adopted 1962; judicial review of legislative acts in theory a
power of the Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: President, who has sweeping powers, elected by universal adult suffrage
to 7-year term; separate popularly elected unicameral National Assembly
with 5-year term; independent judiciary
Government leader: President Francois Tombalbaye
Elections: presidential elections held June 1969, parliamentary elections last
held December 1969
Political parties and leaders: Chadian Progressive Party (PPT), only legal
party, led by Francois Tombalbaye
Voting strength: (1969 elections) 93% in presidential, 97% in parliamentary
Communists: no front organizations or underground party; probably a few
Communists and some sympathizers
Other political or pressure groups: lightly armed Muslim rebel bands have been
sporadically harassing government forces since October 1965 in east-central
and since August 1969 in northern Chad; in 1971, this dissidence was
concentrated mainly in the north and east
Member of: EAMA, FAQ, GATT, ICAO, IBRD, IDA, ILO, IMF, ITU, Lake Chad Basin
Commission, OAU, OCAM, UEAC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Chile
Type: republic
Capital: Santiago
Political subdivisions: 25 provinces
Legal system: based on Code 1857 derived from Spanish law and subsequent codes
influenced by French and Austrian law; constitution adopted 1925, amended
since then; judicial review of legislative acts in the Supreme Court; legal
education at University of Chile, Catholic University, and several others;
has not accepted compulsory ICJ jursidiction _
Branches: president; bicameral legislature; independent judiciary
Government leader: President Salvador Allende
me universal (except enlisted military and police) and compulsory at
age. 18
Elections: next presidential election (1976); next Chamber of Deputies election
(1973); 20 senators (1973)
Political parties and leaders: Communist Party, Luis Corvalan; Socialist Party,
Salvador Allende and Carlos Altamirano; Popular Socialist Union, Raul Ampuero;
Christian Democratic Party, Eduardo Frei and Rodomiro Tomic; Radical Party,
Carlos Morales; National Party, Sergio Onofre Jarpa
Voting strength (1970 presidential election): 36.6% Marxist-led coalition, 35.3%
conservative independent, 28.1% Christian Democrat; (1969 Congressional
election) 12.9% Radical, 29.7% Christian Democrat, 12.2% Socialist, 15.7%
Communist, 20.0% National, 9.5% other
Communists: 65,000; sympathizers, 100,000
Other political or pressure groups: organized labor; business organizations;
landowners’ associations (SNA -- Sociedad Nacional de Agricultura);
terrorist MIR (Movement of Revolutionary Left)
Member of: ECOSOC, IADB, IAEA, IBRD, ICAO, IDB, IHB, IMF, LAFTA and Andean Sub-
he a Group (created in May 1969 within LAFTA), OAS, Seabeds Committee,
59
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECUNOMY :
GNP: $8.3 billion (purchasing power parity estimate, 1970), $850 per capita;
73% private consumption, 14% government consumption, 13% gross investment
(1970 est.); real growth rate 1970, 2% fest.)
Agriculture: main crops -- wheat, other cereals, potatoes; about 75% self-
sufficient; 2,600 calories per day per capita (1970 est.)
Fishing: catch 1.08 million tons; exports $25.4 million, imports $0.2 million
Major industries: copper, nitrates, foodstuffs, fish processing, textiles and
apparel, iron and steel, pulp and paper
Crude steel: 0.7 million metric tons capacity (1967); 0.6 million metric tons
produced (1969), 60 kg. per capita
Electric power: 2.55 million kw. capacity (1970 est.); 8.9 billion kw.-hr.
produced (1970 est.), 910 kw.-hr. per capita
Exports: $1,130 million (f.o.b., 1970 est.); copper, nitrates, iron
Imports: $1,020 million (c.i.f., 1970 est.); machinery and equipment, chemicals,
petroleum, foodstuffs
Majo','2ec99965666c178a52567ca78478ed4e0a11d2e81b70151129d5af82fdfe85a7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d2c1064b58ccb0fe881ceb76ed871c015522fa850037f9480d2b0625a116a59',1971,'BR','Brazil','government',9,'r trade partners: exports -- EC 42%, U.K. 12%, U.S. 14%, Japan 12%, LAFTA
10%; imports -- U.S. 37%, EC 21%, U.K. 6%, Japan 3%, LAFTA 21% (1970)
Aid:
economic -- extensions from U.S. (FY46-70) -- $1,559.7 million ($1,354.2
million loans, $200.7 million grants); from international organizations
(FY46-70) -- $566.3 million (of which IBRD $232.7 million, IDB $253.9
million); from other Western countries (1960-66) -- $170.6 million; from
Communist countries (1967-70) -- $59.8 million;
military (FY46-70) -- from U.S., $20.1 million in loans, $123.8 million in
grants
Monetary conversion rate: multiple exchange rate system; 28.03 escudos=US$1
nontrade (broker) rate; 12.23 escudos=US$1 trade rate; varying taxes drive
effective rate as high as 43 escudos=US$1 for some purposes; black market
rate is upwards of 65 escudos=US$1 (September 1971)
Fiscal year: calendar year
Legal name: People''s Republic of China
Type: Communist state; since beginning of Cultural Revolution, real authority
has become increasingly diffused as result of persistent rivalries within
the top leadership
Capital: Peking (Peiping)
Political subdivisions: 21 provinces, 3 centrally governed municipalities, and
5 autonomous regions
Legal system: before 1966, a complex amalgam of custom and statute, largely
criminal; little ostensible development of uniform code of administrative
and-civil law; highest judicial organ is Supreme People''s Court although
legal activity centered in parallel network of Public Security organs; laws
and legal procedure clearly subordinated to priorities of party policy; whole
system largely suspended during Cultural Revolution and only gradually being
revived under military tutelage
Branches: prior to 1966 control was exercised by Chinese Communist Party, through
State Council, which supervised more than 50 minjstries, commissions, bureaus,
etc., all technically under the standing committee of the National People''s
Congress; this system broke down under "Cultural Revolution" pressures and
is currently in process of being reconsolidated and streamlined
Government leader: Premier of State Council, Chou En-lai; Chairman, People''s
Republic of China (chtef of state, a ceremonial post currently vacant); both
subordinate to central committee of CCP, under Chairman Mao Tse-tung
Suffrage: universal over age 18, though this is academic
Elections: no meaningful elections
61
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GOVERNMENASpsoved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Political parties and leaders: Chinese Communist Party (CCP), headed by Mao
Tse-tung; Mao is Chairman of political bureau, usually real locus of power
in China, and also Chairman of Central Committee; a new central committee
was formed at the 9th Party Congress held in April 1969 but the National
People''s Congress, the body which would confirm the new constitution, has
not yet been held; all 29 provincial level party committees were reestablished
by 19 August 1971 and most sub-provincial levels now have party committees
Voting strength: 100% Communist for practical purposes; no political nonconformity
permitted
Communists: about 20 million in 1965
Other political or pressure groups: pre-Cultural Revolution mass organizations
have not yet resumed their former roles of a united front facade; army (PLA)
is dominant force in countryside, with soldiers performing a wide range of
civil political-administrative duties
Member of: U.N., Red Cross, other international bodies
Legal name: Republic of China
Type: republic; one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 4 cities, 1 special municipality (Taipei)
Legal system: based on civil law system; constitution adopted 1947, amended 1960
to permit Chiang Kai-shek to be reelected; some judicial review of legislative
acts; accepts compulsory ICJ jurisdiction, with reservations
Branches: 5 independent branches (executive, legislative, judicial, plus traditional
Chinese functions of examination and control), dominated by executive branch;
President and Vice President elected by National Assembly
Government leaders: President Chiang Kai-shek; Vice President, Premier Yen
Chia-kan; Vice-Premier, Chairman Council for International Economic
Cooperation and Development Chiang Ching-kuo
Suffrage: universal over age 20
Elections: national level -- legislative yuan every 3 years but not held since
1948 election on mainland (partial election for Taiwan province representatives
December 1969); local level -- provincial assembly, county and municipal
executives every 4 years; county and municipal assemblies every 4 years
Political parties and leaders: Kuomintang, or National Party, led by Director
General Chiang Kai-shek, has no real opposition; 2 insignificant parties
are Democratic Socialist Party, Young China Party
Voting strength (1968 provincial assembly election): 61 seats Kuomintang,
10 seats independents
Member of: expelled from U.N. General Assembly and Security Council on 25 October
1971 and withdrew on same date from other charter-designated subsidiary organs;
attempting to retain membership in specialized agencies, such as IAEA, IBRD,
ICAO, IDA, IHB, IMCO, IMF, ITU, UPU, WHO, WMO
63
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $4.8 billion (1969), $320 per capita; real growth, 9%
Agriculture: most arable land intensely farmed -- 60% cultivated land under
irrigation; main crops -- rice, sweet potatoes, sugarcane, bananas,
pineapples, citrus fruits; 90% self-sufficient; food shortages -- wheat
Fishing: catch 561,000 tons, $146 million (1969)
Major industries: textile manufacturing, chemicals, plywood, electronics, sugar
milling, food processing, cement
Electric power: 2,345,000 kw. capacity (1969); 11.3 billion kw.-hr. produced
(1969); 819 kw.-hr. per capita
Exports: $1,428 million (f.o.b., 1970); textiles 22%, metals and manufactures
25%, canned foods 5%, lumber and plywood 4%, bananas 5%, sugar 4%
Imports: $1,524 million (c.i.f., 1970)
Major trade partners: exports -- 37% U.S., 15% Japan; imports -- 38% Japan,
30% U.S.
Aid:
economic -- U.S. (FY53-69) $1.3 billion committed; IBRD (1964-68) $104
million committed;
military -- U.S. (FY49-70) $3.4 billion committed
Monetary conversion rate: NT$40 (New Taiwan)=US$1
Fiscal year: 1 July - 30 June
Legal name: Republic of Colombia
Type: republic; executive branch dominates government structure
Capital: Bogota
Political subdivisions: 22 departamentos, 4 intendencias, 4 comisarias, 1 federal
district
Legal system: based on Spanish law; religious courts regulate marriage and
divorce; constitution decreed in 1886, amendments codified in 1946; judicial
review of legislative acts in the Supreme Court; accepts compulsory ICJ
jurisdiction, with reservations
Branches: President, bicameral legislature, judiciary
Government leader: President Misael Pastrana
Suffrage: universal over age 21
Elections: every fourth year; last presidential and congressional elections
April 1970; municipal and departmental elections, 1972
Political parties and leaders: "Progressive Liberals," Carlos Lleras Restrepo,
Alfonso Lopez Michelsen; Liberal Party, Julio Cesar Turbay; Conservative Party,
Unionista Wing, Mariano Ospina Perez, Misael Pastrana; Conservative Party,
Alzatista Wing, Alvaro Gomez Hurtado; National Popular Alliance (ANAPO), General
Gustavo Rojas Pinilla, Maria Eugenia Rojas de Moreno; Liberals probably command
majority of votes over conservatives, but constitution under the National
Front Coalition calls for 50-50 representation of Liberals and Conservatives
in the National Congress until 1974; in local legislative bodies, parity
terminated with the 1970 election; Conservative Party united with progovernment
and Ospina wing in August 1969 to choose National Front presidential
Candidate; opposition wing (Lauro-Alzatista) led by Gomez
Voting strength: 1970 presidential election -- Misael Pastrana 1.61 million
votes, General Gustavo Rojas Pinilla 1.54 million votes, Belisario Betancur
Cuartas .46 million votes, Evardisto Sourdis .3 million votes
Other political or pressure groups: Communist Party (PCC), Gilberto Vieira
White; MRL del Pueblo, Communist front for electoral purposes; PCC/ML, Chinese
Line Communist Party, led by Pedro Lupo Leon Arboleda Roldan
Member of: FAO, TADB, IAEA, IBRD, ICAO, IFC, IHB, ILO, IMF, ITU, LAFTA and
Andean Sub-Regional Group (created in May 1969 within LAFTA), OAS, U.N.,
UNESCO, UPU, WHO, WMO
65
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $10.4 billion (purchasing power parity estimate, 1970), $480 per capita;
72% private consumption, 7% public consumption, 21% gross investment (1969);
real growth rate 1970, 7.0%
Agriculture: main crops -- coffee, rice, corn, sugarcane, plantains, bananas,
cotton, potatoes, yucca; Caloric intake, 2,220 calories per day per capita
(1965)
Fishing: catch 70,600 tons; exports $2.9 million (1969), imports $5 million (1969)
Major industries: textiles, food processing, clothing and footwear, beverages ,
chemicals, and metal products
Crude steel: 0.4 million metric tons capacity (1965); 0.26 million metric tons
production (1969), 10 kilograms per capita
Electric power: 22 million kw, capacity (1970); 8.8 billion kw.-hr. produced
(1970), 396 kw.-hr. per capita
Exports: $638 million (f.o.b., 1969); coffee, petroleum, bananas, tobacco,
cotton, sugar, textiles, cattle and hides
Imports: $724 million (c.i.f., 1969); industrial metals and raw materials,
transportation equipment, machinery, fuels, fertilizers, paper and paper
products, wheat
Major trade partners: U.S. 44%, West Germany 11%, other EC 9%, EFTA 9% Latin
America 6%, Communist countries 4% (1968)
Monetary conversion rate: 20.38 pesos=US$1 (September 1971, changes frequently)
Fiscal year: calendar year
Legal name: People''s Republic of the Congo
Type: republic; military regime established September 1968
Capital: Brazzaville
Political subdivisions: 9 regions divided into districts
Legal system: based on French civil law system and customary law; constitution
adopted 1963 and 1969
Branches: President, Council of State; National Assembly dissolved August 1968;
judiciary presumably still functions according to provisions of 1963
constitution; all policy made by Congolese Workers Party Central Committee
and Politburo
Government leader: President, Maj. Marien Ngouabi
Suffrage: universal over age 18
Elections: last legislative elections December 1963; none scheduled
Political parties and leaders: Congolese Workers Party (PCT) is only legal party;
40 member Central Committee, 10 member Politburo, President, Maj. Manen
Ngouabi, First Secretary, Claude Ndalla Graille
Voting strength: no elections held since PCT formed
Communists: some Communists and sympathizers
Other political or pressure groups: Union of Congolese Socialist Youth (UJSC),
Congolese Trade Union Congress (CSC), Revolutionary Union of Congolese °
Union (URFC), General Union of Congolese Pupils and Students (UGEEC)
Member of: EAMA, EC (associate), FAQ, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM,
UDEAC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Costa Rica
Type: unitary republic
Capital: San Jose
Political subdivisions: 7 provinces
Legal system: based on Spanish civil law system; constitution adopted 1949;
judicial review of legislative acts in the Supreme Court; legal education
at University of Costa Rica; has not accepted compulsory ICJ jurisdiction
Branches: President, unicameral legislature, Supreme Court elected by
legislature
Government leader: President Jose Figueres
Suffrage: universal and compulsory age 18 and over
Elections: every 4 years; next, February 1974
Political parties and leaders: National Liberation Party (PLN), Jose Figueres ;
National Union Party (PUN), Otilio Ulate; Republican Party (PR), former leader
died in dune 1970 (no new one as yet); Authentic Republican Union Party (PURA) ,
Mario Echandi; Christian Democratic Party (PDC), Jorge Monge Zamora; Third
Front (PFN), Virgilio Calvo; Socialist Action Party (PASO), Marcial Aguiluz;
Revolutionary Civic Union Party (PUCR), Frank Marshall; Popular Vanguard Party
(PVP, Communist, illegal), Manuel Mora
Voting strength (1970 election): National Unification (coalition of PUN, PR, and
PURA), 41.1%; PLN, 55%; PFN, 1.7%; PDC, 0.92; PASO ,~1.3%
Member of: CACM, IADB, IAEA, ICAO, OAS, U.N.
Legal name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: 6 provinces
Legal system: based on Spanish and American law, with large elements of
Communist legal theory; Fundamental Law of 1959 replaced constitution
of 1940; legal education at Universities of Havana, Oriente, and Las Villas;
does not accept compulsory ICd jurisdiction
Branches: executive; no legislature; controlled judiciary
Government leader: Premier Fidel Castro Ruz
Political parties and leaders: Cuban Communist Party (PCC), First Secretary
Fidel Castro Ruz, Second Secretary Raul Castro Ruz
Communists: approx. 120,000 party members
Member of: CEMA (observer status), ECLA, FAO, GATT, IADB (nonparticipant), IAEA,
ICAO, IHB, ILO, IMCO, International Rice Commission, International Sugar
Council, International Wheat Agreement, ITU, OAS (nonparticipant), Permanent
Court of Arbitration, Postal Union of the Americas and Spain, Seabeds
Committee (observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Cyprus
Type: republic since March 1961; separate de facto Greek/Cypriot, and Turkish/
Cypriot governments have evolved since outbreak of communal strife in 1963
Capital: Nicosia
Political subdivisions: 6 administrative districts
Legal system: based on common law, with civil law modifications; constitution
came into force upon independence in 1960, but has often been in abeyance
since then; has not accepted compulsory ICJ jurisdiction
Branches: currently a rump government consisting basically of Greek Cyriot parts
of bodies provided for by constitution; headed by President of the Republic
and comprised of Council of Ministers, House of Representatives, and
Supreme Court
Government leaders: President, Archbishop Makarios III (Greek); Vice President,
Dr. Fazil Kucuk (Turk)
Elections: held every 5 years; 1965 elections suspended; 1968 elections only for
President and Vice President; 1970 parliamentary elections demonstrate
notable increase in strength of Communist Party (AKEL)
Political parties and leaders: Reform Party of the Working People (AKEL)
(Communist Party), Ezekias Papaioannou; Unified Party (UP), Glafkos Clerides;
Progressive Movement (PM) (pro-Makarios), Andreas Azinas; Democratic
National Party (DEK), Takis Evdokas; United Democratic Union of the Center
(EDEK), Vassos Lyssarides; Turkish National Union Party (TNUP), Rauf Denktash
Voting strength: (1968 Presidential and Vice Presidential elections) Greek
Cypriot President Makarios 90%; Turkish Cypriot Vice President Fazil Kucuk
unopposed; (1970 parliamentary elections) 39% of Greek Cypriot vote for
Reform Party of the Working People, 21% of the Greek Cypriot vote for the
Progressive Movement, 9% of the Greek Cypriot vote for the Democratic National
Party as well as 9% for the United Democratic Union of the Center, 4% of the
Greek Cypriot vote for independents, 76% of the Greek Cypriot electorate
voted; 80% of the Turkish Cypriot community voted and overwhelmingly elected
15 of Rauf Denktash''s supporters to the Turk Cypriot House contingent in a
separate election
Communists: 12,000; sympathizers 60,000
73
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GOVERNMENT ARBOYE? For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Other political or pressure groups: United Democratic Youth Organization (EDON)
(Communist-controlled); Pan Cyprian Confederation of Labor (PEO)
(Communist-controlled); Cyprus Confederation of Labor (SEK) (pro-U.S.);
Cyprus Turkish Federation of Trade Unions (KTBIF)
Member of: Commonwealth, Council of Europe, FAO, IAEA, IBRD, ICAO, IDA, IFC,
ILO, IMF, ITU, U.N., UNESCO, UPU, WHO
Legal name: Czechoslovak Socialist Republic
Type: Communist state
Capital: Prague
Political subdivisions: 2 separate autonomous republics (Czech Socialist
Republic and Slovak Socialist Republic); 7 regions (kraj) in Czech lands,
three regions in Slovakia; national capitals of Prague and Bratislava have
regional status
Legal system: civil law system based on German codes, modified by Communist
legal theory; revised constitution adopted 1960 under revision; no judicial
review of legislative acts; legal education at Universita Komenskeho School
of Law; has not accepted compulsory ICJ jurisdiction
Branches:: executive --- President, cabinet (appointed by President); legislative
-- Federal Assembly (elected directly), Czech and Slovak National Councils
(also elected directly) legislate on limited area of Czech and Slovak affairs;
judiciary -- Supreme Court (elected by Federal Assembly); entire governmental
structure dominated by Communist Party
Government leader: President Ludvik Svoboda
Suffrage: universal over age 18
Elections: governmental bodies every 5 years; President every 5 years (provisions
suspended after Soviet invasion, August 1968); elections scheduled for
November 1971
Dominant political party and leader: Communist Party of Czechoslovakia (KSC),
Gustav Husak, General Secretary; Communist Party of Slovakia has status of
"provincial KSC organization"
Voting strength (1964 election): 99.4% Communist-sponsored single slate
Communists: 1.2 million party members
Other political groups: puppet parties -- Czechoslovak Socialist Party,
Czechoslovak People''s Party, Slovak Freedom Party, Slovak Revival Party
Member of: CEMA, GATT, IAEA, ICAO, Seabeds Committee, U.N., Warsaw Pact
Legal name: Republic of Dahomey
Type: republic
Capital: Porto-Novo (official), Cotonou (de facto)
Political subdivisions: 6 departments, 30 arrondissements
Legal system: based on French civil law and customary law; presidential charter
adopted 1970; judicial review by 4-chambered Supreme Court; legal education
generally obtained in France; has not accepted compulsory ICJ jurisdiction
Branches: executive -- 3-man Presidential Council, but actual executive authority
vested in rotating presiding officer who also serves as Premier; no
legislature; independent judiciary
Government leaders: Hubert Maga, Premier and presiding officer of Presidential
Council that functions as chief of state; Justin Ahomadegbe, member of
Presidential Council; Sourou-Migan Apithy member of Presidential Council
Suffrage: universal for adults whenever elections or referendums are held
Elections: current government has held no elections and none are scheduled
Political parties: none
Communists: some; probably some sympathizers
Member of: EAMA, Entente, FAQ, ICAO, ILO, ITU, OAU, OCAM, U.N., UNESCO, UPU,
WHO, WMO
Legal name: Kingdom of Denmark
Type: constitutional monarchy
Capital: Copenhagen
Political subdivisions: 14 counties, 277 communes, 88 towns
Legal system: civil law system; constitution adopted 1953; judicial review of
legislative acts; legal education at Universities of Copenhagen and Arhus ;
accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament
(Folketing); executive power vested in Crown but exercised by cabinet
responsible to parliament; Supreme Court, 2 superior courts, 106 lower courts
Government leader: King Frederick IX; Prime Minister Jens Otto Krag
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years (next in 1975)
Political parties and leaders: Social Democratic, Jens Otto Krag; Moderate
Liberal, Poul Hartling; Conservative, Knud Thestrup; Radical Liberal, Soren
Bjerregaard; Socialist Peoples, Sigurd Omann; Communist, Knud Jespersen;
Left Socialist, Erik Sigsgaard
Voting strength (1971 election): 37.4% Social Democratic, 15.7% Moderate Liberal,
16.7% Conservative, 14.3% Radical Liberal, 9.1% Socialist Peoples, 1.4%
Communist, 5.3% other
Communists: 5,000; a number of sympathizers, as indicated by 39,344 Communist
votes cast in 1971 elections
Member of: Council of Europe, EFTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHB,
ILO, IMCO, IMF, ITU, NATO, Nordic Council, OECD, Seabeds Committee (observer),
U.N., UNESCO, UPU, WHO, WMO
Legal name: State of Dominica
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Roseau
Political subdivisions: 10 parishes
Legal system: based on English common law; three local magistrate courts and
the British Caribbean Court of Appeals
Government leaders: Premier Edward 0. LeBlanc; U.K. Governor Louis Cools-Lartigue
Suffrage: universal adult suffrage (age 18 effective June 1971)
mae eo every 5 years; most recent October 1970 (by-election held December
1970
Political parties and leaders: Dominica Labor Party (DLP), Edward 0. LeBlanc;
Dominica Freedom Party (DFP), Miss M. Eugenia Charles
Voting strength: Legislative Council seats -- DFP 2 seats, DLP 8 seats, indepen-
dent 1 seat
Communists: negligible
Member of: CARIFTA
Legal name: Dominican Republic
Type: republic
Capital: Santo Domingo
Political subdivisions: 26 provinces and the National District
Legal system: based on French civil codes; 1966 constitution
Branches: President popularly elected for a 4-year term; bicameral legislature
consisting of Senate (27 seats) and Chamber of Deputies (74 seats) elected
for 4-year terms; members of Supreme Court elected by Senate
Government leader: President Joaquin Balaguer
Suffrage: universal and compulsory, over age 18 or married
Elections: national, May 1974
Political parties and leaders: Reformist Party (PR), Joaquin Balaguer; Dominican
Revolutionary Party (PRD), Juan Bosch Gavino; Democratic Quisqueyan
Party (PQD), Elias Wessin y Wessin; Revolutionary Social Christian Party
(PRSC), Alfonso Moreno Martinez; Movement for National Conciliation (MNC),
Jaime Manuel Fernandez Gonzalez; Anti-reelection Movement of Democratic
Integration (MIDA) Francisco Augusto Lora; Fourteenth of June Revolutionary
Movement (MR~1J4), split into several factions, illegal; Dominican Communist
Party (PCD), central committee, illegal; Dominican Popular Movement (MPD),
Rafael Taveras Rosario, illegal; Communist Party of the Dominican Republic
(PCRD), Luis Montas Gonzalez, illegal; Popular Socialist Party (PSP), illegal
Voting strength (1970 election): 57% PR, (abstained) PRD, 5% PRSC, 14% PQD, 3%
MCN, 21% MIDA
Member of: IADB, IAEA, ICAO, IHB, OAS, U.N.
Legal name: Republic of Ecuador
Type: republic
Capital: Quito
Political subdivisions: 19 provinces and 1 territory (Galapagos Islands)
Legal system: based on civil law system; modified 1946 Constitution replaced
1967 Constitution in June 1970, legal education at 4 state and 2 private
universities; has not accepted compulsory ICJ jurisdiction
Branches: President and bicameral legislature elected in June 1968, under 1967
constitution; legislature closed following assumption of dictatorial power
by Velasco on 23 June 1970; judiciary
Government leader: President Jose Maria Velasco
Suffrage: all literate over age 18; compulsory
Elections: next presidential and congressional, June 1972
Political parties and leaders: National Velasquista Front, Jose Maria Velasco;
Radical Liberal Party, Ignacio Hidalgo Villavicencio; Social Christian Party,
Camilo Ponce; Conservative Party, Galo Pico Mantilla; Concentration of
Popular Forces, Assad Bucaram; National Revolutionary Party, Carlos Julio
Arosemena
Voting strength: in June 1968 national elections, Velasquistas, a center-left
coalition, and a rightist coalition each got approximately one-third
Member of: ECOSOC, IADB, IAEA, ICAO, LAFTA and Andean Sub-Regional Group
(formed in May 1969 within LAFTA), OAS, Seabeds Committee (observer), U.N.
Legal name: Arab Republic of Egypt
Type: republic; under presidential rule sin','be75e9eb54f1d4320b16467117ae72ae9f9499224188481af4262b2ebb6617ab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b07796c547ef4ced1d7a355a7b0600bb6915820a8c732220d1cc866fc0150779',1971,'BR','Brazil','government',10,'ce June 1956
Capital: Cairo
Political subdivisions: 25 governorates
Legal system: based on English common law, Islamic law, and Napoleonic codes;
dnterim constitution of 1964; judicial review of limited nature in Supreme
Court, also in Council of State which oversees validity of administrative
decisions; legal education at Cairo University; accepts compulsory ICJ
jurisdiction, with reservations
Branches: executive power vested in President, who appoints cabinet; National
Assembly has little actual power (serves mainly for discussion and automa-
tic approval); independent judiciary administered by Minister of Justice
Government leader: Anwar Sadat
Suffrage: universal over age 18
Elections: elections to People''s Assembly every 5 years (most recent October
1971); presidential elections every 6 years
Political parties and leaders: political parties banned; all candidates for
election must be members of Arab Socialist Union, the only officially
sanctioned sociopolitical grouping
Member of: AAPSO, Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO,
IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO, WPC
Legal name: Republic of £1 Salvador
Type: republic
Capital: San Salvador
Political subdivisions: 14 departments
Legal system: based on Spanish law, with traces of common law; constitution
adopted 1962; judicial review of legislative acts in the Supreme Court;
legal education at University of E1 Salvador; accepts compulsory ICdJ
jurisdiction, with reservations
Branches: traditionally dominant executive, unicameral legislature, Supreme
Court
Government leader: President Fidel Sanchez Hernandez
Suffrage: universal over age 18
Elections: legislative elections every 2 years; presidential elections every 5
years; presidential elections February 1972, legislative and municipal elections
March 1972
Political parties and leaders: National Conciliation Party (PCN), President
Fidel Sanchez Hernandez, Dr. Enrique Mayorga Rivas, Rafael Rodriguez
Gonzalez, Col. Arturo Armando Molina; Christian Democratic Party (PDC),
Dr. Pablo Mauricio Alberque, Roberto Lara Velado; Dr. Abraham Rodriguez,
Jose Napoleon Duarte; Revolutionary Party (PR -- formerly Renovating Action
Party), not legally recognized, Shafick Handal, Dr. Fabio Castillo Figueroa,
Julio Ernesto Contreras; Salvadoran Popular Party (PPS), Benjamin Wilfredo
Navarrete, Dr. Rafael Antonio Carbello, Dr. Jose Antonio Guzman; Communist
Party of El Salvador (PCES), illegal, Jorge Shafick Handal; National
Revolutionary Movement (MNR), Dr. Guillermo Manuel Ungo; National Democratic
Union Party (PUDN), Francisco Roberto Lima, Julio Ernesto Contreras, Julio
Castro Belloso
Voting strength: March 1967 presidential election -- PCN 54.4%, PDC 21.6%,
PAR 14.4%, PPS 9.6%; March 1970 legislative election -- PCN 60%, PDC 27%,
PPS 5%, MNR 2%, PUDN 6%
Other political or pressure groups: the "14" prominent families; General
Confederation of Trade Unions (CGS); Unifying Federation of Salvadoran
Trade Unions (FUSS), Communist dominated; Federation of Construction and
89
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RD - -
COVERNMENT ened) A P79-01051A000400010002-1
Other political or pressure groups (cont''d):
Transport Workers Unions (FESINCONSTRANS) , independent; Catholic Church,
the military; Salvadoran National Association of Educators (ANDES)
Member of: Central American Common Market, IADB, IAEA, OAS, ODECA, Seabeds
Committee, U.N.
Legal name: Republic of Equatorial Guinea
Type: republic, one-party presidential regime since 1968
Capital: Santa Isabel, Fernando Po
Political subdivisions: 2 provinces (Fernando Po and Rio Muni)
Branches: elected President has strong executive power; elected Assembly of
the Republic; elected Provincial Councils with broad responsibilities for
administrative and social affairs; Council of Republic (3 members elected
by each Provincial Council) has powers of judicial review, mediates disputes
between executive and legislative branches and between national provincial
governments; judiciary includes Supreme Court
Government leader: President Francisco Macias Nguema
Suffrage: universal age 2] and over
Elections: national and provincial elections held September 1968
Political parties and leaders: in January 1970 government abolished the five
political parties existing at time of independence and the Council of
Ministers approved the creation of the National Unity Party (PUN)
Communists: no significant Communist activity
Member of: IBRD, IMF, OAU, U.N.
Legal name: Empire of Ethiopia
Type: constitutional monarchy, but in effect an absolute monarchy
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred to as governorates-general )
Legal system: complex structure with civil, Islamic, common and customary law
influences; constitution adopted 1955; no specific constitutional provision
for review by courts but all legislation inconsistent with the constitution
is declared null and void; legal education at Haile Selassie I University;
has not accepted compulsory ICJ jurisdiction
Branches: Emperor is all-powerful, with advisory cabinet and Prime Minister;
legislature composed of elected Chamber of Deputies and appointed Senate;
judiciary at higher levels based on Western pattern, at lower levels on
traditional pattern, without jury system in either
Government leader: Emperor Haile Selassie I
Suffrage: universal over age 21
Political parties and leaders: only amorphous reform groups especially among
younger, better educated Ethiopians
Member of: ECA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UPU,
WHO, WMO
Legal name: Colony of the Falkland Islands
Type: British crown colony
Capital: Stanley
Political subdivisions: local government is confined to capital
Legal system: English common Taw
Branches: Governor, Executive Council, Legislative Council
Government leader: Governor and Commander in Chief Sir Cosmo Haskard (also
High Commissioner for British Antarctic Colony)
Suffrage: universal
Legal name: Fiji
Type: independent state since 1970
Capital: Suva
Political subdivisions: 14 provinces
Legal system: based on British
Branches: executive -- Prime Minister; legislative -- existing colonial Legis-
lative Council to continue as first House of Representatives, first elections
probably in 1972, to elect a 52-member House of Representatives, there will
also be a 22-member appointed Senate (interim solution of equal representa-
tion for Fijians and Indians); problem of ethnic representation to be
examined and settled before second elections
Government leader: Prime Minister Ratu Sir Kamisese Mara
Suffrage: universal adult
Elections: every 5 years unless House dissolves earlier
Political parties: Alliance, primarily Fijian, headed by Ratu Mara; National
Federation, primarily Indian, headed by S. M. Koya
Communists: few, no figures available
Member of: Commonwealth, U.N.
Legal name: Republic of Finland
Type: republic
Capital: Helsinki
Political subdivisions: 12 provinces; 443 communes, 78 towns
Legal system: civil law system based on Swedish law; constitution adopted 1919;
Supreme Court may request legislation interpreting or modifying laws; legal
education at Universities of Helsinki and Turku; accepts compulsory ICJ
jurisdiction, with reservations
Branches: legislative authority rests jointly with President and parliament
(Eduskunta); executive power vested in President and exercised through
cabinet responsible to parliament; Supreme Court, 4 superior courts,
193 lower courts
Government leader: President Urho K. Kekkonen; Prime Minister Ahti Karjalainen
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1974); presidential, every
6 years (next in 1974)
Political parties and leaders: Social Democratic, Rafael Paasio; Center,
Johannes Virolainen; Peoples Democratic League (Communist front), Ele
Alenius; Conservative, Harri Holker; Liberal, Pekka Tarjanne; Swedish Peoples,
Jan-Magnus Jansson; Rural, Veikko Vennamo; Social Democratic League,
Uuno Nokelainen; Communist, Aarne Saarinen
Voting strength (1970 election): 23.4% Social Democratic, 17.1% Center, 16 .6%
Peoples Democratic League, 18.0% Conservative, 6.0% Liberal, 5.6% Swedish
Peoples, 10.5% Rural, 1.4% Social Democratic League, 1.4% other
Communists: 47,000; an additional 65,000 persons belong to Peoples
Democratic League; a further number of sympathizers, as indicated by
421,000 votes cast for Peoples Democratic League in 1970 elections
Member of: EFTA (associate), FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO,
IMCO, IMF, ITU, Nordic Council, OECD, Seabeds Committee (observer), U.N.,
UNESCO, UPU, WHO, WMO
101
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $9 billion (1970), $1,910 per capita; 53.4% consumption, 29.7%
investment, 17.5% government, -0.6% net exports of goods and services; 1970
growth rate 8.9%, current prices
Agriculture: animal husbandry, especially dairying, predominates; forestry
important secondary occupation for rural population; main crops -- cereals,
sugar beets, potatoes; 85% self-sufficient; shortages -- food and fodder
grains; caloric intake 2,890 calories per day per capita (1968-69)
Major industries: include metal manufacturing and shipbuilding, forestry and
wood processing (pulp, paper), copper refining
Shortages: fossil fuels; industrial raw materials, except wood, and iron ore
Crude steel: 1,168,837 metric tons produced (1970), 250 kilograms per capita
Electric power: 4,800,000 kw. capacity (1970); 22,313 million kw.-hr. produced
(1970), 4,000 kw.-hr. per capita
Exports: $2,306 million (f.o.b., 1970); timber, paper and pulp, ships, machinery,
iron and steel, clothing and footwear
Imports: $2,638 million (c.i.f., 1970); foodstuffs, petroleum and petroleum
products, chemicals, transport equipment, iron and steel, machinery, textile
yarn and fabrics
Major trade partners (1969): 25.6% EC, 39.5% EFTA, 13.1% West Germany,
15.8% U.K., 14.2% Sweden, 5.6% U.S., 13.3% U.S.S.R., 17.2% Communist countries
Aid: U.S. $158.3 million authorized 1946-70, none in 1968 or 1969, $7.6 million
in 1970; IBRD -- $221.5 million authorized through 1946-68, $22 million in 1969,
$13 million in 1971; Finnish foreign aid programs have amounted to $23 million
1961-69, $15,000 in 1970
Monetary conversion rate: new markka (Fmk) 4.20=US$1 (official)
Fiscal year: calendar year
Legal name: French Republic
Type: republic, with president having wide powers
Capital: Paris
Political subdivisions: 95 departments, 21 "regional action districts"
Legal system: civil law system with indigenous concepts; new constitution
adopted 1958, amended concerning election of President in 1962; judicial
review of administrative but not legislative acts; legal education at over
25 schools of law; accepts compulsory ICJ jurisdiction, with reservations
Branches: presidentially appointed Prime Minister heads Council of Ministers,
which is formally responsible to National Assembly; bicameral legislature
~~ National Assembly (487 members), Senate (283 members) restricted to a
delaying action; judiciary independent in principle
Government leader: President Georges Pompidou
Suffrage: universal over age 21; not compulsory
Elections: National Assembly -- every 5 years, last election June 1968, direct
universal suffrage, 2 ballots; Senate -- indirect collegiate system for 9
years, renewable by one-third every 3 years; President -- direct, universal
suffrage every 7 years, 2 ballots, last election June 1969
Political parties and leaders: Union of Democrats for the Republic (UDR), Rene
Tomasini; Independent Republicans, Valery Giscard d''Estaing; Communist (PCF),
Waldeck Rochet, George Marchais (acting); Progress and Modern Democracy (PDM)
Jacques Duhamel; Radical Socialists, Jean-Jacques Servan-Schreiber; Socialist
Party, Francois Mitterrand; Unified Socialist Party (PSU), Michel Rocard
Voting strength (first ballot, 1968 election): 43.6% UDR, 20% PCF, 16.5%
Federation of Democratic and Socialist Left (grouping of parties of left),
10.3% Center, 9.6% other
Communists: 250,000-300,000 (est.); Communist voters, 5 million average
Other political or pressure groups: Communist-controlled labor union
(Confederation Generale du Travail) nearly 1,000,000 members (est.),
National Council of French Employers (Conseil National de Patronat
Francais -- CNPF or Patronat)
103
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
>
A ;
GOVERNMENT (cont''d): pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Member of: Council of Europe, EC, FAO, IAEA, IBRD, ICAO, IHB, ILO, IMCO, IMF, ITU,
NATO (signatory), OECD, Seabeds Committee, SEATO, South Pacific Commission,
U.N., UNESCO, UPU, WEU, WHO, WMO
Legal name: Overseas Department of French Guiana
Type: overseas department of France; represented by one deputy in French National
Assembly and one senator in French Senate
Capital: Cayenne
Political subdivisions: 2 arrondissements, 19 communes each with a locally elected
municipal council
Legal system: French legal system; highest court is Court of Appeal based in
Martinique with jurisdiction over Martinique, Guadeloupe, and French Guiana
Branches: executive: prefect appointed by Paris; legislative: popularly elected
16-member General Council; judicial, under jurisdiction of French judicial
system
Government leader: Prefect, Jean Monfraix
Suffrage: universal over age 21
Elections: General Council elections coincide with those for the French National
Assembly, normally every 5 years; last election March 1970
Political parties and leaders: Parti Socialiste Guyanais (PSG), Leopold Heder,
Senator; Union Progressiste Guyanaise (UPG), weak, leftist allied with, but
also reported to have been absorbed by, the PSG; Union of Democrats for the
Republic (UDR), Hector Rivierez, delegate to French National Assembly
Communists: UPG includes Communist sympathizers, but has little measurable
following; no organized Communist party
Legal name: Overseas Territory of Afars and Issas
Type: overseas territory of France; represented by one deputy in French National
Assembly and by one senator in French Senate
Capital: Djibouti
Legal system: based on French civil law system and customary law
Branches: President of Council of Government; 8-member Council of Government
appointed by 32-member Chamber of Deputies; ultimate political authority
exercised by Paris-appointed President of the Council of Government, some-
times referred to as Prime Minister
Government leader: Ali Aref Bourhan
Suffrage: universal
Elections: Chamber of Deputies election held November 1968
Political parties and leaders: Parti du Mouvement Populaire, Moussa Ahmed Idriss;
Rassemblement Democratique Afar, Ali Aref Bourhan; Union Democratique Afar,
Mohamed Kamil; Union Populaire Africaine, Hassan Guled
Legal name: Gabonese Republic
Type: republic; one-party presidential regime since 1964
Capital: Libreville
Political subdivisions: 9 regions, 6 communes, 4,500 villages
Legal system: based on French civil law system and customary law; constitution
adopted 1961; judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; legal education at Centre of Higher and Legal Studies
at Libreville; compulsory ICJ jurisdiction not accepted
Branches: power centralized in President, elected by universal suffrage for
7-year term; unicameral 47-member National Assembly has limited powers ;
judiciary
Government leaders: President Albert-Bernard Bongo
Suffrage: universal over age 21
Elections: Presidential and parliamentary elections last held March 1967
Political parties and leaders: Gabonesé Democratic Party (PDG) led by President
Bongo is only legal party
Communists: possibly some Communists and probably some Communist sympathizers
Member of: EAMA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM, UDEAC, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Republic of The Gambia
Type: republic; independent since February 1968
Capital: Bathurst
Political subdivisions: Bathurst and 4 divisions
Legal system: based on English common law and customary law; constitution came
into force upon independence in 1965, new republican constitution adopted in
April 1970; accepts compulsory ICJ jurisdiction, with reservations
Branches: Executive Council of 8 ministers; 36-member House of Representatives,
in which 4 seats are reserved for chiefs and 32 are filled by election for
5-year term; independent judiciary
Government leader: Dawda K. Jawara, President
Political parties and leaders: People''s Progressive Party (PPP), Secretary
General Dawda K. Jawara; opposition coalition, People''s Progressive Alliance
(PPA) and United Party (up)
Elections: general elections held May 1966; PPP won 24 seats, alliance of UP and
PPA won 5
Communists: probably some Communists and sympathizers
Member of: Commonwealth, OAU, U.N.
Legal name: German Democratic Republic
Type: Communist state
Capital: East Berlin (not officially recognized by U.S., U.K., and France, which
together with the U.S.S.R,. have special rights and responsibilities in Berlin)
Political subdivisions: (excluding East Berlin) 14 districts (Bezirke), 217
counties (Kreise), 8,867 communities (Gemeinden)
Legal system: Civil law system modified by Communist legal theory; new constitution
adopted 1968 by approx. 95% of the voters in national "referendum;" court
system parallels administrative divisions; no judicial review of legislative
acts; legal education at Universities of Berlin, Leipsig, Haile and Jena;
has not accepted compulsory ICJ jurisdiction; more stringent penal code
adopted 1968
Branches: legislative -- Volkskammer (elected directly); executive -- Chairman
of Council of State, Chairman of Council of Ministers, Cabinet (elected by
Volkskammer); judiciary -- Supreme Court; entire structure dominated by
Socialist Unity (Communist) Party
Government leaders: Walter Ulbricht (Head of State); Chairman, Council of Ministers, |
Willi Stoph (Head of Government)
Suffrage: all citizens age 18 and over
Elections: national and local alternating every 2 years; prepared by an electoral
commission of the National Front; ballot supposed to be secret and voters
permitted to strike names off ballot; more candidates than offices available;
parliamentary elections held 2 July 1967; local elections, 22 March 1970; new
parliamentary elections scheduled for 14 November 197]
Political parties and leaders: Socialist Unity (Communist) Party (SED), headed
by First Secretary Erich Honecker, dominates the regime; 4 token parties
(Christian Democratic Union, National Democratic Party, Liberal Democratic
Party, and Democratic Peasants’ Party) and an amalgam of special interest
organizations participate with the SED in National Front
Voting strength: 1967 parliamentary elections: 99.93% voted the regime slate; 197
local elections: 99.85% voted the regime slate
Communists: 1.9 million party members
115
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GOVERNMENT (cont''d):
Other special interest groups:
Federation, Democratic Women''s Federation of Germany ,
Federation (all Communist dominated)
Member of: CEMA, Warsaw Pact
Free German Youth, Free German Trade Union
German Cultural
Legal name: Republic of Ghana
Type: republic; independent since March 1957
Capital: Accra
Political subdivisions: 8 administrative regions and separate Greater Accra
Area; regions subdivided into 47 districts
Legal system: based on English common law and customary law; Supreme Court has
power of judicial review; new constitution adopted 1969; legal education at
University of Ghana (Legon) and Ghana Law School (Accra); has not accepted
compulsory ICJ jurisdiction
Branches: executive authority vested primarily in prime minister, although
president has some appointive powers ; unicameral legislature; independent
judiciary
Government leaders: chief of state, President Edward Akufo-Addo; Prime Minister,
Kofi A. Busia
Suffrage: universal over 21
Elections: 140-man National Assembly elected to five-year term in August, 1969;
105 seats won by Progress Party which now governs
Political parties and leaders: two major parties are Progress Party led by
Kofi Busia and Justice Party led by E. R. Madjitey and Joe Appiah
Communists: a small number of Communists and sympathizers, without influence
since Nkrumah''s overthrow
Member of: Commonwealth, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, OAU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Guyana
Type: republic within Commonweal th
Capital: Georgetown
Political subdivisions: 9 administrative districts
Legal system: based on English common law with certain admixtures of Roman-
Dutch law; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers presided over by Prime Minister; 53-member
unicameral legislative National Assembly (elected); Supreme Court
Suffrage: universal over age 2]
Elections: last held in December 1968; next elections 1973
Political parties and leaders: People''s Progressive Party (PPP), Cheddi Jagan;
People''s National Congress (PNC), L.F.S. Burnham; United Force (UF),
Feilden Singh
Voting strength (1968 election): 36.5% PPP, 55.8% PNC, 7.4% UF, 0.3% other
Communists: unknown; top echelons of PPP and PYO (Progressive Youth Organization,
militant wing of the PPP) include many Communists, but rank and file is
non-Communist
Other political or Pressure groups: Justice Party, Guyana United Muslim Party,
Guyana All-Indian League, African Society for Cultural Relations with
i Independent Africa, Progressive Youth Organization (PPP affiliate), Young
Socialist Movement (PNC affiliate), Guyana United Youth Society (UF
affiliate), Afro-Asian-American Association, Committee for National
Reconstruction, Guyana National Party (GNP)
Member of: CARIFTA, FAQ, GATT, IBRD, ICAQ, IFC, ILO, IMF, ITU, Seabeds Committee
- (observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Haiti
Type: republic under the 14-year dictatorship of Francois Duvalier who was
succeeded upon his death on 21 April 1971 by his constitutional successor,
his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: 5 departments (despite constitutional provision for 9)
Legal system: based on Roman civil law system; constitution adopted 1964 and
amended 1970; legal education at State University in Port-au-Prince and private
law colleges in Cap-Haitien, Les Cayes, Gonaives, and Jeremie; accepts
compulsory ICJ jurisdiction
Branches: lifetime President, powerless unicameral 58-member legislature, judiciary
appointed by President
Government leader: Jean-Claude Duvalier
Suffrage: universal over age 18
Election: constitution provides for lifetime presidency; provisions for
presidential succession not specified in the constitution as amended in 1970;
legislative elections to be held every 6 years
Political parties: National Unity Party, only legal party; United Haitian
Communist Party (PUCH), illegal (Communist)
Voting strength (1967 legislative elections): 100% National Unity Party
(Duvalier)
Member of: GATT, IADB, IAEA, ICAO, IMF, IBRD, OAS, U.N.
Legal name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Political subdivisions: 18 departments
Legal system: based on Roman and Spanish civil law; some influence of English
common law; constitution adopted 1965; judicial review of legislative acts
in Supreme Court; legal education at University of Honduras in Tegucigalpa;
accepts compulsory ICJ jurisdiction, with reservations
Branches: constitution provides for elected President, unicameral legislature,
and national judicial branch
Government leader: President Ramon Ernesto Cruz
Suffrage: universal and compulsory over age 18
Elections: May 1971, Nationalist Party candidate won election; next
election February 1977
Political parties and leaders: Liberal Party (PLH), Carlos Roberto Reina --
President of Centra','b667cc6d6e4750486ac3294ea474d94a53fbbb3c504c2f21bcfc476300491538','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ad8c47266e59b5308f780a9ed5c979f3ce99891f762d56f8614cb06eed760ff',1971,'BR','Brazil','government',11,'l Executive Council, Jorge Bueso Arias, Modesto Rodas
Alvarado, Max Velasquez, Leonardo Godoy; Nationalist Party (PNH), Ramon
Ernesto Cruz, Ricardo Zuniga Augustinus, General Oswaldo Lopez Arellano,
Mario Rivera Lopez, Martin Aquero, Manuel Acosta Bonilla; Popular Progressive
Party (PPP-uninscribed), Gonzalo Carias Castillo; Orthodox Republican Party
(PRO-uninscribed), Roque Jacinto Rivera; Communist Party of Honduras
(PCH-outlawed), Dionisio Ramos Bejarano, Tomas Erazo Pena; Christian Democrat
(uninscribed), Miguel Andonie Fernandez, Napoleon Alcerro Olivia
Voting strength (1971 elections): Nationalist Party (PNH) 306,028; Liberal
Party (PLH) 276,777
Member of: IADB, ICAO, ILO, OAS, CACM, U.N.
Legal name: Colony of Hong Kong
Capital: Victoria
Type: U.K. crown colony
Political subdivisions: Hong Kong, Kowloon, and New Territories
Legal system: English common Taw
Branches: Governor assisted by advisory Executive Council; he legislates with
advice and consent of Legislative Council; Urban Council which alone includes
elected representatives, responsible for health, recreation, and resettlement;
New Territories divided into 4 districts, each presided over by a District
Officer advised by a locally elected Rural Committee; independent judiciary
Government leader: present Governor and Commander in Chief Sir David Trench is
scheduled to be replaced by C. M. MacLehose in late 1971
Suffrage: limited to 200,000 to 300,000 professional or skilled persons
Elections: every 2 years to select one-half of elected membership of Urban
Council; other Urban Council members appointed by the Governor
Political parties and leaders: Civic Association, Hu Pai-fu; Reform Club, B. A.
Bernacchi; Socialist Democratic Party, Sun Po-kong; Hong Kong Labour Party,
Tang Hon-tsai
Voting strength: (elected Urban Council members) Civic Association 4, Reform
Club 3, and 1 independent
Other political or pressure groups: Federation of Trade Unions (Communist
controlled), Hong Kong and Kowloon Trade Union Council (Nationalist Chinese
dominated), Hong Kong General Chamber of Commerce, Chinese General Chamber
of Commerce (Communist controlled), Federation of Hong Kong Industries,
Chinese Manufacturers’ Association of Hong Kong
Legal name: Hungarian People''s Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 Megyes (counties), 5 autonomous cities in county
status, 113 Jaras (districts)
Legal system: based on Communist legal theory, with both civil law system (civil
code of 1960) and common Taw elements; constitution adopted 1949; Supreme
Court renders decisions of principle that sometimes have the effect of
declaring legislative acts unconstitutional; legal education at Eotvos
Lorand Tudomanyegyetem School of Law in Budapest and 2 other schools of Taw;
has not accepted compulsory ICJ jurisdiction
Branches: executive -- Presidential Counci] (elected by Parliament); legislative
-- Parliament (elected by direct suffrage); judicial -- Supreme Court
(elected by Parliament)
Government leaders: Jeno Fock, Chairman, Council of Ministers; Pal Losonczi,
President, Presidential Council
Suffrage: universal over age 18
Elections: every 4 years
Political parties and leaders: Hungarian Socialist (Communist) Workers'' Party
(sole party); Janos Kadar is First Secretary of Central Committee
Voting strength (1967 election): 7,086,596 (99.7%) for Communist-approved
candidates; 19,113 (0.3%) negative votes; total eligible electorate about
7.2 million
Communists: about 662,000 party members (November 1970)
Member of: CEMA, FAO, IAEA, ICAO, ILO, ITU, UNESCO, U.N., UPU, Warsaw Pact, WHO
Legal name: Republic of Iceland
Type: republic
Capital: Reykjavik
Political subdivisions: 16 districts, 212 rural communes, 14 towns
Legal system: civil law system based on Danish law; constitution adopted 1944;
legal education at University of Iceland; does not accept compulsory
ICJ jurisdiction
Branches: legislative authority rests jointly with President and parliament
(Althing); executive power vested in President but exercised by cabinet
responsible to parliament; Supreme Court and 26 lower courts
Government leaders: President Kristjan Eldjarn; Prime Minister Olafur Johannesson
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1975); presidential, every
4 years (next in 1972)
Political parties and leaders: Independence (conservative), Johann Hafstein;
Progressive, Olafur Johannesson; Social Democratic, Gylfi Gislason; Labor
Alliance (Communist front), Ragnar Arnalds; Organization of Liberals,
Hannibal Valdimarsson
Voting strength (1971 election): 36.2% Independence, 25.2% Progressive, 10.4%
Social Democratic, 17.1% Labor Alliance, organization of leftists and liberals
8.9%
Communists: 1,000; a number of sympathizers, as indicated by 18,055 votes cast
for Labor Alliance in 1971 election
Member of: Council of Europe, EFTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHB,
ILO, IMCO, IMF, ITU, NATO, Nordic Council, OECD, Seabeds Conmittee, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Republic of India
Type: federal republic
Capital: New Delhi
Political subdivisions: 18 states, 10 union territories, 1 protectorate (Sikkim),
1 substate (Meghalaya)
Legal system: based on English common law; constitution adopted 1950; judicial
review of legislative acts; accepts compulsory ICd jurisdiction, with
reservations
Branches: parliamentary government, national and state; independent judiciary
Government leader: Prime Minister Indira Gandhi
Suffrage: universal over age 21
Elections: national and state elections ordinarily held every 5 years; may be
postponed in emergency and may be held more frequently if government loses
confidence vote; next general election to be held by March 1976, several state
polls by March 1972
Political parties and leaders: Indian National Congress split into two factions
in 1969, largest faction (the Ruling Congress) loyal to Prime Minister Gandhi
led by D. Sanjivayya, and smaller faction (the Organization Congress) led by
Sadiq Ali; Communist Party of India (CPT),
S. A. Dange, general secretary; Communist Party of India/Marxist (CPI/M) ,
P, Sundarayya, general secretary; Communist Party of India/Marxist-Leninist
(CPI/ML), Charu Mazumdar, Chairman; Swatantra, N. Dandekar, president (acting);
Bharatiya Jana Sangh, A. B. Vajpayee, president; The Socialist Party, Kappori
Thakur, chairman; Dravida Munnetra Kazhagam (DMK), N. Karunanidhi, president
Approved For Release 2004/08/31 : t4A-RDP79-01051A000400010002-1
Approved Fo :
GOVERNMENT (cont''d): pp r Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Voting strength (1971 election): 43.7% Ruling Congress ; 10.5% Organization Congress ;
7.4% Bharatiya Jana Sangh, 3.1% Swatantra, 4.8% CPI, 5.2% CPI/M, 3.5% Socialist
Parties, 3.7% DMK, 18.1% other
Communists: 70,000 members of CPI (est.), 70,000 members of CPI/M;
Communist sympathizers » 13 million
Member of: ADB, Colombo Plan, Commonwealth, FAO, IAEA, ICAO, IDA, IFC; IHB, ILO,
IMCO, IMF, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Indonesia
Type: republic
Capital: Djakarta
Political subdivisions: 26 first-level administrative subdivisions or provinces
which are further subdivided into 281 second-level areas
Legal system: based on Roman-Dutch law, substantially modified by indigenous
concepts; constitution of 1945 is legal basis of government; legal education
at University of Indonesia, Djakarta; has not accepted compulsory ICJ
jurisdiction
Branches: executive headed by President who is chief of state and head of
cabinet (president Suharto is concurrently Minister of Defense and Security);
cabinet selected by President; unicameral legislature (Parliament); of 460
members (100 appointed, 360 elected) second and larger body (Congress) and
460 other members (chosen by several processes, but not directly elected)
includes the legislature of 920 members, elects President and Vice President,
and theoretically determines national policy
Government leader: President Suharto (elected by Congress March 1968)
Suffrage: universal over age 17 and married persons regardless of age
Political parties and leaders: Golkar (quasi-official "party" based on functional
groups), S. Sokowati; Indonesian National Party (PNI), Mohamad Isnaeni
(acting); Nahdlatul Ulama (NU), Idham Chalid; Indonesian Muslim Party (PMI),
Mintaredja
Voting strength (1971 election): Golkar 236 seats (62.8%), NU 58 seats (18.7%),
PNI 20 seats (6.9%), PMI 24 seats (5.4%), PSII 10 seats, Parkindo 7 seats,
Catholic 3 seats, Perti 2 seats
Communists: Communist Party (PKI) was officially banned in March 1966; current
strength est. at 1,000, with less than 10% engaged in organized activity;
pre-October 1965 hard core membership has been estimated at 1.5 million
Minor legal parties: Catholic Party, Christian Party, Islamic Unity Party (PSII),
Association of Supporters of Indonesian Independence (IPKI), Islamic Unity
Party (PERTI), Murba
Member of: ADB, ASEAN, FAO, IAEA, ICAO, IHB, ILO, IMF, U.N. (resumed membership
in September 1966 and is now active in U.N. affiliated organizations), UNESCO
149
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $9.5 billion (1970), less than $100 per capita; real average annual growth
(1965-70) 3% i
Agriculture: subsistence food production, and smallholder and plantation |
production for export; main crops -- rice, rubber, copra, other tropical
products; substantially self-sufficient; food shortage -- rice
Fishing: catch 1.2 million tons (1969); exports $1.5 million (1969), imports $.6
million (1969)
Major industries: processing agricultural products and petroleum, textiles,
cement, mining
Electric power: 960,000 kw. capacity (1969); 2.35 billion kw.-hr. produced (1969),
20 kw.-hr. per capita Py
Exports: $1,181 million (f.0.b., 1970); petroleum, rubber, tin, copra, tea, coffee,
tobacco, palm oi]
Imports: $1,145 million (f.o.b., 1970); rice, other foodstuffs, textiles, chemicals,
jron and steel products, machinery, transport equipment, consumer durables
Major trade partners: exports (1970) -- 16%°U.S., 55% Japan, 4% Singapore, 9% 4
West Germany; imports -- 22% U.S., 55% Japan, 9% West Germany, 13% Singapore
Monetary conversion rate: 415 rupiah=US$1
Fiscal year: 1 April - 31 March
Legal name: Empire of Iran (becoming obsolete)
Type: constitutional monarchy, actually controlled by the Shah
Capital: Tehran
Political subdivisions: 13 provinces and 6 independent governorates, subdivided
into counties, municipalities, and rural districts
Legal system: based largely on Belgian law, with elements drawn from other
continental systems; personal Jaw based on Islamic practice generally with
residual traces of Roman law; constitution adopted 1906 and constitutional
law of 1907; High Court of Appeal may judge disputes relating to government
departments acting according to law; legal education at University of Teheran;
has not accepted compulsory ICJ jurisdiction
Branches: executive power rests in Shah who appoints a Prime Minister; Prime
Minister must be approved by lower house (Majlis); while Cabinet theoretically
responsibility of Prime Minister, Shah usually exerts strong influence over
its selection; bicameral legislature; Majlis has 268 seats (with 2 vacant
for islands of the Persian Gulf) elected to 4-year terms, and Senate 60
members serving 4-year terms; half of Senate members appointed by Shah,
other half elected; no provision for judicial review of constitutionality
of legislative acts
Government leaders: Shah Mohammad Reza Pahlavi and Prime Minister Amir
Abbas Hoveyda
Suffrage: universal over age 20
Elections: Majlis every 4 years; Senate every 4 years; latest national elections
July 1971, district and provincial elections in September 1970
Political parties and leaders: New Iran Party, Manuchehr Kalali; Mardom (Peoples)
Party, Alinagi Kani; Iranians Party, Dr. Fazlollah Sadr; Pan Iranist Party,
Mohsen Pezeshkpur (apparently moribund)
Voting strength (1971 election): Majlis -- New Iran Party, 231 seats; Mardom
Party, 36 seats; Iranians Party, 1 seat; Senate -- New Iran Party, 28 seats;
Mardom Party, 2 seats; plus 30 seats appointed by the Shah; all candidates
government approved
Communists: 1,000-2,000 (hard-core, est.); sympathizers (15,000-20,000 est.);
mostly pro-U.S.S.R. but pro-Chinese faction developing
Approved For Release 2004/08/34 ! CIA-RDP79-01051A000400010002-1
Approved For R : zi
GOVERNMENT (cont''d): pp elease 2004/08/31 : CIA-RDP79-01051A000400010002-1
Other political or pressure groups : Tudeh Party (Communist, illegal); National
Front (coalition of neutralist urban elements virtually discredited because
of opposition to Shah''s reform program) ; Confederation of Iranian Students
(illegal)
Member of: CENTO, Colombo Plan, FAQ, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO,
IMF, ITU, OPEC, RCD, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Iraq
Type: republic; one-party military regime established in July 1968
Capital: Baghdad
Political subdivisions : 16 provinces under centrally appointed officials
Legal system: based on Islamic law qn special religious courts » civil law system
elsewhere; provisional constitution adopted in 1968; judicial review was
suspended; jegal education at University of Baghdad; has not accepted
compulsory IcJ jurisdiction
Branches : moderate wing of Ba''th Party of Iraq has been in power since 1968 coup
Government leaders: President Hasan al-Bakr; Deputy Chairman of the Revolutionary
Command Council Saddam Tikriti
Suffrage: 0 elective bodies exist
Elections: none since overthrow of monarchy in 1958
Communists: Communist Party repressed and disorganized
Political or pressure groups : political parties banned, major opposition to
regime is from leftwing of the Ba''th Party > Communist Party and Nasirist
groups » disaffected members of the regime and army officers
Member of: Arab League» FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OPEC,
“ U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law, substantially modified by indigenous
concepts; constitution adopted 1937; judicial review of legislative acts in
Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: elected President; bicameral parliament reflecting proportional and
vocational representation; judiciary appointed by President on advice of
Government leader: Taoiseach (Prime Minister) John (Jack) Lynch
Suffrage: universal over age 2]
Elections: Dail (lower house) elected every 5 years -- last election June 1969;
President elected for 7-year term
Political parties and leaders: Fianna Fail, John (Jack) Lynch; Labor Party,
Brendan Corish; Fine Gael, Liam Cosgrave; Irish Workers’ Party (Communist),
Michael O''Riordan
Voting strength (1969 election): 75 seats Fianna Fail, 50 seats Fine Gael,
18 seats Labor Party, 10 Independents
Communists: approximately 200
Member of: Council of Europe, FAO, IBRD, ICAO, ILO, IMCO, IMF, ITU, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution provides for establishment of 20 regions;
5 (Sicilia, Sardegna, Trentino-Alto Adige, Friuli-Venezia Giulia, and Valle
d''Aosta) have been created and are functioning; some but not all aspects of
enabling legislation providing for remaining 15 regions have been enacted;
93 provinces
Legal system: based on civil law system, with ecclesiastical law influence;
constitution came into effect 1 January 1948; judicial review of legislative
acts in Constitutional Court; has not accepted compulsory ICJ jurisdiction
Branches: executive -- President empowered to dissolve Parliament and call national
election; he is also Commander of the Armed Forces and presides over the
Supreme Defense Council; otherwise, authority to govern invested in Council
of Ministers; legislative power invested in bicameral, popularly elected
Parliament; Italy has an independent judicial establishment
Government leaders: President Giuseppe Saragat; Premier Emilio Colombo
Suffrage: universal over age 21 (except in Senatorial elections where minimum
age of voter is 25)
Elections: national elections for Parliament held every 5 years (most recent,
May 1968); provincial and municipal elections held every 5 years with some
out of phase; regional elections every 5 years
Political parties and leaders: Christian Democratic party (DC), Arnaldo Forlani
(party secretary) Emilio Colombo (Premier), Aldo Moro, Amintore Fanfani
(Senate President); Communist Party (PCI), Luigi Longo, Enrico Berlinguer;
Italian Socialist Party (PSI), Pietro Nenni (ex-party secretary), Francesco
De Martino (Vice Premier), Unitary Socialist Party (PSU), Mauro Ferri (party
Approved For Release 2004/08/31 > ClA-RDP79-01051A000400010002-1
Approved For R :
GOVERNMENT (cont''d): pp elease 2004/08/31 : CIA-RDP79-01051A000400010002-1
Political parties and leaders (cont''d):
secretary); Socialist Party of Proletarian Unity (PSIUP). Tullio Vecchietti,
Liberal Party (PLI). Giovanni Malagodi; Italian Social Movement (MSI),
Giorgio Almirante; Italian Democratic Party of Monarchist Unity (PODIUM),
Alfredo Covelli; Republican Party (PRI), Ugo La Malfa
Voting strength (1968 election): 39.1% DC, 26.9% PCI, 14,5% PSI, 5.8% PLI, 4.5%
PSIUP, 4.5% MSI, 2% PRI, 1.3% PDIUM, 1.4% other
Communists: 1,500,000 members; number of sympathizers cannot be determined
Other political or pressure groups : the Vatican, whose influence on the Christian
Democratic party is important factor in that party''s policies; three major
trade union confederations (CGIL -- Communist dominated, CISL -- Christian
Democratic, and UIL -- Social Democratic and Republican) ; Italian manufac-
turers association (Confindustria) ; organized farm groups
Member of: ECSC, EC, FAO, IBRD, ICAO, IAEA, IHB, ILO, IMCO, IMF, ITU, NATO,
Seabeds Committee, U.N.; UNESCO, UPU, WHO, WMO
Legal name: Republic of Ivory Coast
Type: republic, one-party presidential regime
Capital: Abidjan
Political subdivisions: 6 departments subdivided into 127 subprefectures
Legal system: based on French civil law system and customary law; constitution
adopted 1960, amended 1963; judicial review in the Constitutional Chamber
of the Supreme Court; legal education at Abidjan School of Law; has not
accepted compulsory ICJ jurisdiction
Branches: President has sweeping powers, unicameral legislature, separate
judiciary
Government leader: President Felix Houphouet-Boigny
Suffrage: universal over age 21
Elections: uncontested Presidential and legislative elections held in November
1965; similar elections held November 1970
Political parties and leaders: Parti Democratique de la Cote d''Ivoire (PDCI),
(only party); official party leader is Secretary General Philippe Yace, but
Houphouet-Boigny is in control
Communists: no Communist party; some Communists and probably some sympathizers
Member of: EAMA, Entente, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, OAU, OCAM,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Jamaica
Type: independent state within Commonwealth since August 1962, recognizing
Elizabeth II as head of state
Capital: Kingston
Political subdivisions: 12 parishes and the Kingston-St. Andrew corporate area
Legal system: based on English common law; has not accepted compulsory ICJ
jurisdiction
Branches: cabinet headed by Prime Minister; 53-member elected House of Represent-
atives; 21l-member Senate (13 nominated by the Prime Minister, 8 by opposition
leader); judiciary follows British tradition under a Chief Justice
Government leader: Prime Minister Hugh Shearer
Suffrage: universal, age 21 and over
Elections: at discretion of Governor-General upon advice of Prime Minister but
within 5 years; latest held 21 February 1967
Political parties and leaders: Jamaica Labor Party (JLP), Sir Alexander
Bustamante, Hugh Shearer; People''s National Party (PNP), Michael Manley
Voting strength (1969 local elections): 48.59% JLP, 51.54% PNP, 0.24% other
Communists: a few hundred Marxist and Communist sympathizers
Other political or pressure groups: New World Group (Caribbean regionalists,
nationalists, and leftist intellectual fraternity); Rastafarians (Negro
religious/racial cultists, pan-Africanists); New Creation International
Peacemakers Tabernacle (leftist group)
Member of: CARIFTA, FAQ, GATT, IAEA, IBRD, ICAO, IFC, ILO, IMF, OAS, Pan
American Health Organization, Seabeds Committee (observer), U.N.; wishes to
gain Associated Overseas Territory status with EC if U.K. joins
165
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Sa Oe
Legal name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands, enjoying complete domestic
autonomy
Capital: Willemstad; Curacao, center of government
Political subdivisions: 4 island territories -- Aruba, Bonaire, Curacao, and the
Windward Islands -- St. Eustatius, southern part of St. Martin (northern
part is French), Saba
Legal system: based on civil law system, with some English common law influence;
Dutch Country Statute of 1955 serves as constitution
Branches: executive power, under nominal head of Governor (appointed. by the
Crown), exercised by 8-member Council of Ministers or Cabinet; legislative
power rests with 22-member Legislative Council; independent court system
under control of Chief Justice of Supreme Court of Justice (administrative
functions under Minister of Justice); each island territory has island
council headed by Lieutenant Governor for local administration
Government leaders: Minister President Ramez Jorge Isa (new government formed
6 February 1971)
Suffrage: universal over age 2]
Elections: held every 4 years
Political parties and leaders: the Democratic Party (DP); Antilles Social Progress
Movement (MASA) led by Ciro Kroon; the Aruba Patriotic Party (PPA) led by S.J.
Trompe; the National People''s Party (NVP), S.D. Abbad; the Aruba People''s Party
(AVP) led by Dominico Guzman Croes; the National Aruban Union Party/ Independent
Aruban Party (UNA/PIA) led by A. Werleman/M. Croes; Bonaire Democratic Party
led by L.A. Abraham; Windward Island Democratic Party led by A. C. Wathey;
Social Progressive Action Party, S. R. Goeloe; Antillean Reform Union (URA),
Roberto Suriel; Curacao Independent Party (COP), Peter Vander Hoven; Radical
Peoples Party (PRP), Max de Castro; Workers'' Party (Frente Obrero) -- coalition
in power includes DP, PPA, and Workers'' Party
Voting strength (1969 local election): 46% DP/PPA; 15% NVP; 14% Worker Front;
14% AVP; 11% other (new elections may be called soon)
Member of: EC (associate), WHO
2
Approved For Release 2004/08/31 3$1a-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $254 million (1967), $1,190 per capita; real growth rate 1967, 3.6%
Agriculture: little production
Major industries: petroleum refining on Curacao and Aruba; tourism on Curacao,
Aruba, and St. Martin; phosphate mining on Curacao
Electric power: 288,500 kw. capacity (1969); 1.3 billion kw.-hr. produced (1969
est.), 5,909 kw.-hr. per capita
Exports: $625 million (f.0.b., 1969); petroleum products, phosphate
Imports: $830 million (c.i.f., 1969); crude petroleum, food manufactures
Major trade partners: exports -- U.S. 43%, EC 16%, Latin America 13%, U.K. 10%,
Canada 7%; imports -- Venezuela 72%, U.S. 10%, Netherlands 4% (1968)
Monetary conversion rate: 1.88 Netherlands Antillean florins (NAF)=US$1 (official)
Fiscal year: calendar year
Legal name: Overseas Territory of New Caledonia
Type: French overseas territory; represented in French parliament by one deputy
and one Senator
Capital: Noumea
Political subdivisions: 4 islands or island group dependencies -- Isle of Pines,
Loyalty Islands, Huon Islands, Island of New Caledonia
Legal system: French Taw
Branches: administered by Governor, who is also High Commissioner for France in
the Pac','e39b09b8277c3a0656c78c479f904ea536635d0a13ab0f45ffb756992072c497','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f63f8467ba1be388075ffbe38b405d19309f66cbbd06c89cf7b71ce348c95d0b',1971,'BR','Brazil','government',12,'ific; responsible to French Ministry for Overseas France and
Governing Council; Assemblee Territoriale
Government leader: Jean Risterucci, Governor and French High Commissioner
Suffrage: restricted (1957 election roll listed 32,370 males and females over
21 years of age, of whom 18,964 were classed as indigenous inhabitants )
Elections: Assembly elections in 1967
Political parties and leaders: Union Caledonienne, led by M. Rock Pidjot; Entente
Caledonienne, Lafleur; Caledonie Nouvelle; Union des Patentes
Voting strength (1967 election): Union Caledonienne, 22 seats; Entente Caledon-
jenne, (alliance of R. C. Caledonienne and United Nouvelle Republique), 10
seats; Caledonie Nouvelle, 2 seats; Union des Patentes, 1 seat
Communists: number unknown; Union Caledonienne strongly leftist; some political-
ly active Communists were deported during 1950''s; small number of North
Vietnamese
Other political parties and pressure groups: several lesser parties
Legal name: Republic of Nicaragua
Type: republics dominated by president
Capital: Managua
Political subdivisions: 1 national district and 16 departments
Legal system: based on Spanish civil law system; constitution adopted in 1950;
judicial review of legislative acts in the Supreme Court; legal education
at Universidad Nacional de Nicaragua; accepts compulsory ICdJ jurisdiction
Branches: President, bicameral legislature, judiciary elected by legislature,
and Supreme Electoral Tribunal (4th branch)
Government leader: President Anastasio Somoza Debayle
Suffrage: universal over age 18 if married or literate, otherwise 21
Elections: every 5 years; however, due to agreement between liberal and conservative
parties, next elections will not be held until mid-1974
Political parties and leaders: Nationalist Liberal Party (PLN), Anastasio Somoza,
Ramiro Sacasa, Francisco Urcuyo; Alfonso Callejas; Traditionalist Conservative
Party (PCT), Fernando Aguero Rocha; Nicaraguan Conservative Party (PCN),
Alejandro Abaunza Marenco, Enrique Belli Chamorro; Independent Liberal Party
(PLI), not legal, Victor Manuel Ordonez, Arges Sequeira, Juan Manuel Gutierrez;
Social Christian Party (PSC), not legal, Ignacio Zelaya, Cesar Delgadillo
(President) and Roberto Ferrey (Secretary General )
Voting strength (1967 elections): PLN 480,162 votes (74%), PCN 14,650 votes (2%) »
PCT and supporting parties, 157,432 votes (24%)
Member of: CACM, FAO, GATT, IADB, IAEA, ICAO, ICJ, ILO, INTELSAT, ITU, OAS,
ODECA, Seabeds Committee (observer) U.N., UNESCO, UNICEF, UPU, WHO, WMO
Legal name: Republic of Niger
Type: republic; one-party rule established 1960
Capital: Niamey
Political subdivisions: 7 departments, 32 arrondissements
Legal system: based on French civil law system and customary law; constitution
adopted 1960; judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: President selected for 5 years by direct universal suffrage; unicameral ,
60-member National Assembly elected for 5 years; judiciary constitutionally
independent of executive and legislature
Government leader: President Diori Hamani
Suffrage: universal over age 21
Elections: presidential and parliamentary elections in 1970; about 99% of voters
approved unopposed official candidates
Political parties and leaders: Parti Progressiste Nigerien (PPN), led by Diori
Hamani
Communists: some Communists and Communist sympathizers, especially among supporters
of outlawed Sawaba party
Member of: EAMA, Entente, FAO, GATT, IBRD, ICAO, ILO, IMF, ITU, Lake Chad Basin
Commission, OAU, OCAM, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Nigeria
Type: federal republic since 1963; under military rule since January 1966,
military rule scheduled to last until 1976
Capital: Lagos
Political subdivisions: 12 states, each headed by a military governor
Legal system: based on English common law, tribal law, and Islamic law; new
constitution to be drafted; legal education at Universities of Ife, Ahmadu ,
Bello, and Lagos; accepts compulsory ICJ jurisdiction, with reservations
Branches: Federal Military Government, administered by Supreme Military Council
and Federal Executive Council, which includes 13 civilian commissioners
(ministers
Government leader: Maj. Gen. Yakubu Gowon, Head of Federal Military Government
and Commander in Chief of Nigerian Armed Forces
Suffrage: universal adult suffrage (except for women in former Northern Region)
¥ Elections: sometime in next 6 years
Political parties and leaders: political parties and politically active tribal
societies were dissolved by decree on 24 May 1966; some subrosa political
activity continues
Member of: Commonwealth, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, OAU, Seabeds
. Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 20 counties, 404 communes, 47 towns
Legal system: mixture of customary law, Civil law system, and common Jaw traditions;
constitution adopted 1814, modified 1884; Supreme Court renders advisory
opinions to legislature when asked; legal education at University of Oslo;
accepts compulsory ICU jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament (Storting) ;
executive power vested in Crown but exercised by cabinet responsible to
parliament; Supreme Court, 5 superior courts, 104 lower courts
Government leaders: King Olav V; Prime Minister Trygve Bratteli
Suffrage: universal, but not compulsory, over age 20
Elections: held every 4 years (next in 1973)
Political parties and leaders: Conservative, Kare Willoch; Christian Peoples,
Lars Korvald; Center, John Austrheim; Liberal, Helge Seip; Labor, Trygve
Bratteli; Socialist Peoples, Finn Gustavsen; Communist, Reidar Larsen
Voting strength (1969 election): 19.6% Conservative; 9.4% Christian Peoples;
10.5% Center; 9.4% Liberal; 46.5% Labor; 3.5% Socialist Peoples; 1.0%
Communist
Communists: 2,000; a number of sympathizers as indicated by the 22,500 Communist
votes cast in the 1969 election
Member of: Council of Europe, EFTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IMB,
ILO, IMCO, IMF, ITU, NATO, Nordic Council, OECD, Seabeds Committee, U.N..
UNESCO, UPU, WHO, WMO
245
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approve F
ECONOMY : Pp d For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $11.1 billion (1970), $2,860 per capita; 55.1% consumption; 28.8% inves ment,
including government; 17.8% government, including defense (current); net {
foreign balance -1.7%; 1969 growth rate 4.8%, in 1969 constant prices
Agricul ture: animal husbandry predominates ; main crops -- feed grains, potatoes,
fruits, vegetables; 40% self-sufficient; food shortages -- food grains, sugar: ry
caloric intake, 2,910 calories per day per capita (1968-69)
Fishing: catch 2,695,633 metric tons (1970), $14.7 million; exports $190 million,
imports $11 million
Major industries: food processing, wood pulp, paper products, metals, machinery,
chemicals, shipbuilding
Shortages: feed and bread grains, coal, petroleum and petroleum products , cotton, «
wool
Crude steel: 870,133 metric tons produced (1970), 220 kilograms per capita
Electric power: 12,580,000 kw. capacity (1970); 57,204 million kw.-hr. produced
(1970), 14,500 kw.-hr. per capita
Exports: $2,498 million (f.o.b., 1969); principal items -- fish and fish .
products, metal and metal products, pulp and paper, chemicals, ships
Imports: $3,670 million (c.i.f., 1969); principal items -- ships, machinery,
fuels, foodstuffs
Major trade partners: 17.2% Sweden, 15.3% U.K. 14.7% West Germany, 7% U.S.;
6.9% Denmark; 26.2% EC; 44.6% EFTA; 2.6% Communist countries (1969)
Aid:
economic -- U.S., $355.2 million authorized (1946-70), $1.2 million in 1967,
$2.1 million in 1970; IBRD, $145 million authorized through 1970,
none since. 1964; net official economic aid given to less developed areas and
multilateral agencies, $134.2 million (1960-69), $26.6 million (1968), $37.8
million (1969);
military -- U.S., $900 million authorized (1946-70), $24.2 million (1968),
$11.0 million (1969), $0.3 million (1970)
Monetary conversion rate: 7.14 kroner=US$1 (official )
Fiscal year: calendar year
!
!
Legal name: Sultanate of Oman
Type: absolute monarchy; nominally independent but under strong U.K. influence
Capital: Muscat
Legal system: based on English common law and Islamic law; no constitution,
ultimate appéal to the Sultan; has not accepted compulsory ICJ jurisdiction
Government leader: Sultan Qabus ibn Sa‘id Al Bu Sa''id
Member of: Arab League, U.N.
Legal name: Islamic Republic of Pakistan
Type: republic (by late 1971 Pakistan''s future as a unified state was gravely in
doubt as a result of the open rebellion of the Bengalis in East Pakistan who
are demanding independence as the nation of Bangla Desh; the outbreak of the
hostilities between India and Pakistan in early December, and New Delhi''s
subsequent recognition of Bangla Desh would appear to mark the beginning of
the end of West Pakistan''s authority over the eastern wing of the country )
Capital: Islamabad; many government offices functioning in Rawalpindi, temporary
capital
Political subdivisions: 2 noncontiguous wings -- West Pakistan and East Pakistan;
East Pakistan is one province, and West Pakistan has 4 provinces -- Punjab,
Sind, Baluchistan, Northwest Frontier -- with the capital territory of
Islamabad and certain tribal areas centrally administered
*Based on data reported by Pakistan''s Central Statistical Office, the Pakistani
population was est. at 117,827,000 on 1 January 1972. Projections based on estimates
used by Pakistan''s Planning Commission, which allows for an underenumeration of 8%
in the 1961 census suggest, however, that the population may be as high as 135 million.
249
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GOVERNMENT (cont''d) Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Legal system: based on English common law; constitution of 1962 abrogated by
martial law regime, but country governed as closely as possible in accordance
vith it, although several important basic rights have been rescinded; judicial
review of legislative acts in the Supreme Court; six law schools, including
University of Punjab School of Law in Lahore; accepts compulsory ICJ
jurisdiction, with reservations
Government leaders: President and Martial Law Administrator Yahya Khan, assisted
by Deputy Martial Law Administrators Vice Admiral Muzaffar Hasan, Air Marshal
A. Rahim Khan, and Gen. Abdul Hamid Khan
Suffrage: universal over age 21
Elections: national elections for 313-member National Assembly based on one-man/
one-vote formula, and for provincial assemblies were held in December 1970;
subsequently about half of the East Pakistanis elected were disqualified
Political parties and leaders: Awami League (AL) (outlawed), Mujibur Rahman
(jailed), Tajuddin Ahmed (in exile); Pakistan People''s Party (PPP), Z. A.
Bhutto; Council Muslim League (CML), Mumtaz Daultana; Jama''at-i-Islam (JI),
Maulana Madoodi; Pakistan Democratic Party (PDP), Nurul Amin; National Awami
Party/Left (NAP/L), Maulana Bhashani (in exile); National Awami Party/
Requisitionist (NAP/R), Abdul Wali Khan; All Pakistan Muslim League (PML/
Qaiyum), Abdul Qaiyum Khan; Markazi Jamiat-ul-Ulema-i-Pakistan (MJUP) ,
Khamaja Qamar-u-Din Sialvi; Jamiat-ul-Ulema-i-Islam (JUI), Maulana Ghulam
Ghaus Hazarvi, Mufti Mahmud
Member of: ADB, CENTO, Colombo Plan, Commonwealth, FAO, IAEA, IBRD, ICAO, IDA,
IFC, IHB, ILO, IMCO, IMF, ITU, RCD, Seabeds Committee, SEATO, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Republic of Panama
Type: republic; under military rule since October 1968
Capital: Panama
Political subdivisions: 9 provinces, 1 Indian reservation
Legal system: based on civil law system; constitution adopted in 1946; judicial
review of legislative acts in the Supreme Court; legal education at
University of Panama; accepts compulsory ICd jurisdiction, with reservations
Branches: popularly elected executive and unicameral legislature (currently
disbanded), presidentially appointed Supreme Court
Government leaders: elected President Arias ousted by military Junta on 11
October 1968; locus of power remains with National Guard Commandant, General
Omar Torrijos; Demetrio Lakas is President of the Provisional Junta
Government and Chief of State
Suffrage: universal and compulsory over age 21
Elections: May 1968 elections won by National Union (NU) coalition candidate
Arnulfo Arias Madrid, who assumed presidency on | October 1968; elections
held every 4 years; elections for assembly of representatives of the
corregimientos to be held by August 1972
Political parties and leaders: political parties suspended pending revision of
electoral code
Voting strength (1968 election): 55% Arnulfo Arias Madrid (National Union
Coalition), 42% David Samudio (People''s Alliance), 3% Antonio Gonzalez
Revilla (Christian Democratic Party)
Member of: IADB, IAEA, ICAO, OAS, U.N.
253
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Seances Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $1.32 billion (purchasing power parity estimate, 1970), $900 per capita;
68% private consumption, 14% government consumption, 22% gross fixed
investment, -4% net foreign balance (1969); real growth rate 1970, 7.0%
Agriculture: main crops -- bananas, rice, corn, coffee, sugarcane; self-sufficient
in most basic foods; 2,400 calories per day per capita (1965-66)
Fishing: catch 32,000 tons, $8 million (1970); exports $10.9 million (1969);
imports $1.5 million (1969)
Major industries: food processing, metal products, construction materials,
petroleum products, clothing
Electric power: 218,000 kw. capacity (1969 est.); 621 million kw.-hr. produced
(1969 est.), 480 kw.-hr. per capita
Exports: $114 million (f.o.b., 1970); bananas, petroleum products, shrimp,
sugar, coffee
Imports: $353 million (c.i.f., 1970); manufactures, transportation equipment,
crude petroleum, foodstuffs, chemicals
Major trade partners: U.S. 43%, Venezuela 15%, Canal Zone 9%, Colon Free Zone
6% (1969)
Aid:
economic -- extensions from U.S. (FY46-70), $153.1 million loans, $101.6
million grants; from international organizations (FY46-69), $53.5 million;
from other Western countries (1960-68), $14.0 million;
military -- assistance from U.S. (FY61-70), $4 million
Monetary conversion rate: 1 balboa=US$1 (official)
Fiscal year: calendar year
Legal name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncion
Political subdivisions: 16 departments and the national capital, 154 municipalities
Legal system: based on Argentine codes, Roman law, and French codes; constitution
promulgated 1967; judicial review of legislative acts in Supreme Court; legal
education at National University of Asuncion and Catholic University of Our
Lady of the Assumption; does not accept compulsory ICJ jurisdiction
Branches: President heads executive; bicameral legislature; judiciary headed
by Supreme Court
Government leader: President (General) Alfredo Stroessner
Suffrage: universal; compulsory between ages of 18-60
Elections: President and Congress elected together every 5 years; 4-party
participation for first time in 1968 elections
Political parties and leaders: Colorado Party, Juan Ramon Chavez; Levi-Liberal
Party, Carlos Levi Ruffinelli; Febrerista Party, Ignacio Iramain; Radical
Liberal Party, Carlos Alberto Gonzalez; Christian Democratic Party (not
officially inscribed), Alfredo Ayala Haedo
Voting strength (February 1968 general election): 71% Colorado Party, 22% Radical
Liberal Party, 4% Liberal Party, 3% Febrerista Party
Communists: Oscar Creydt faction and Miguel Angel Soler faction (both illegal);
perhaps several thousand party members and sympathizers in Paraguay, very
few are hard core; party in exile is small and deeply divided
Other political or pressure groups: Popular Colorado Movement (MoPoCo) led by
Epifanio Mendez Fleitas, in exile
Member of: FAQ, IADB, IAEA, IBRD, ICAO, IMF, LAFTA, OAS, U.N., WHO
Legal name: Republic of Peru
Type: republic; under military regime since October 1968
Capital: Lima
Political subdivisions: 23 departments with limited autonomy plus constitutional
Province of Callao
Legal system: based on civil law system; military government rules by decree;
legal education at the National Universities in Lima, in Trujillo, in Arequipa,
and in Cuzco; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative, judicial; congress disbanded after 3 October
1968 ouster of President Fernando Belaunde Terry
Government leader: President Juan Velasco Alvarado
Suffrage: literacy requirement
Elections: presidential and congressional elections held every 6 years; all
elections canceled after the coup
Political parties and leaders: Popular Action Party (AP), Fernando Belaunde Terry
in exile; Christian Democratic Party (PDC), Hector Cornejo Chavez; Popular
American Revolutionary Alliance Party (APRA), Victor Raul Haya de la Torre;
Popular Christian Party (PPC), Luis Bedoya Reyes
Needs strength (1963 election): 39% AP-PDC, 34% APRA, 25% UNO, 1% Communist,
% other
Member of: GATT, IADB, IAEA, ICAO, LAFTA and Andean Sub-Regional Group (created
in May 1969 within LAFTA), OAS, Seabeds Committee, U.N.
Legal name: Republic of the Philippines
Type: republic
Capital: Quezon
Political subdivisions: 67 provinces
Legal system: based on Spanish, Islamic, and Anglo-American law; constitution
passed 1935, ratified as amended 1947; judicial review of legislative acts
in the Supreme Court; legal education at University of the Philippines ,
Ateneo de Manila University, and 71 other law schools; accepts compulsory
IcJ jurisdiction, with reservations
Branches: strong executive branch with Presidential Cabinet; bicameral
legislature -- Senate and House of Representatives ; judicial branch headed
by Supreme Court with descending authority in a Court of Appeals, Courts
of First Instance in various provinces, municipal courts in chartered
cities, and justices of the peace in towns and municipalities; these
justices have considerably more authority than do justices of the peace
in the U.S.
Government leader: President Ferdinand E. Marcos
Suffrage: universal over age 21, and literate
Elections: elections for President and House of Representatives held every 4 years;
Senate elections staggered with one-third membership elected every 2 years
Political parties and leaders: Liberal Party, Gerardo M. Roxas; Nacionalista
Party, Gil J. Puyat
Voting strength (1971): Senate -- Nacionalista Party, 19 seats; Liberal Party,
2 seats; House of Representatives -- Nacionalista Party, 923 Liberal Party,
8
Communists: under 1,000; sympathizers, 5,000-6,000 (est.)
Member of: ADB, ASEAN, ASPAC, Colombo Plan, ECAFE, IAEA, ICAO, IHB, Seabeds
Committee (observer), SEATO, U.N., UNESCO, UNICEF, WHO
Legal name: Polish People''s Republic (PRL)
Type: Communist state
Capital: Warsaw
Political subdivisions: 17 provinces, 5 city provinces, 391 districts
Legal system: mixture of Continental (Napoleonic) civil law and Communist legal
theory; constitution adopted 1952; court system parallels administrative
divisions with Supreme Court, composed of 104 justices, at apex; no
judicial review of legislative acts; legal education at 7 law schools; has
not accepted compulsory ICJ jurisdiction
Branches: legislative, executive, judicial system dominated by parallel
Communist Party apparatus
Government leader: Piotr Jaroszewicz, Premier; Jozef Cyrankiewicz, chairman
of Council of State (president) .
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government every 4 years
Dominant political party and leader: Polish United Workers'' Party (PZPR)
(Communist) Edward Gierek, First Secretary
Voting strength (1969 election): 97% voted for Communist-approved single slate
Communists: 2,100,000 party members (September 1971)
Other political or pressure groups: National Unity Front (FUN), including United
Peasant Party (ZSL), Democratic Party (SD), progovernment pseudo-Catholic
Pax Association and Christian Social Association, Catholic independent Znak
group; powerful Roman Catholic Church, Stefan Cardinal Wyszynski, Primate
Member of: CEMA, GATT, ICAO, IHB, Indochina Truce Commission, Korea Truce
Commission, Seabeds Committee, U.N. and all specialized agencies except IMF
and IBRD, Warsaw Pact
Legal name: Republic of Portugal
Type: republic, with single legal party controlled by a Prime Minister
Capital: Lisbon
Political subdivisions: 18 districts in mainland Portugal and 4 “autonomous
districts" in Azores and Madeira Islands; 7 overseas provinces in Africa
and Asia
Legal system: civil law system; constitution adopted 1933, frequently amended
since; no judicial review of legislative acts; legal education at Universities
of Lisbon and Coimbra; accepts compulsory ICJ jurisdiction, with reservations
Branches: executive with President, Council of State, and Council of Ministers;
legislative with National Assembly dominated by executive and a Corporative
Chamber, the latter consultative and advisory; and judicial completely
controlled by executive branch
Government leader: Prime Minister Marcello Caetano, appointed September 1968
Suffrage: all citizens over age 21 who are literate and have not been deprived
of their civil rights
Elections: National Assembly, direct but government-controlled, held every 4 years,
next in 1973; local direct parish board elections held every 4 years, next in
1975; President, by government-controlled electoral college every 7 years,
next in 1972
Political parties and leaders: government-controlled National Popular Action
(ANP) -- formerly called National Union -- only legally recognized political
organization; Monarchist Cause group is tolerated by regime; various opposition
groups include -- Communist Party (PCP) whose secretary, Alvaro Cunhal, is
in exile; a dissident Communist exile group, Patriotic Front of National
Liberation (FPLN); and several small non-Communist groups such as the moribund
Democratic Social Action (ADS); Portuguese Socialist Action (ASP) leader Mario
Soares; extremist opposition group, League of Revolutionary Union
265
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GOVERNMENT (cont ''¢\\pProved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Political parties and leaders (cont''d):
and Action (LUAR) has been dormant since 1970, with leader, Herminio de Palma
Inacio in exile abroad; Armed Revolutionary Action (ARA) is radical and
violence-prone group which appeared in October 1970 and claimed credit for
‘several sabotage acts
Voting strength (1969 election): National Union, as ANP was then called, won all
130 seats in National Assembly in first contested election
Communists: 2,000-7,000 est.; sympathizers cannot be determined
Other political or pressure groups: Portuguese Legion, Portuguese Youth,
Association for the Study of Economic and Social Development (SEDES)
authorized in October 1970 as a discussion group with political overtones
Member of: EFTA, FAO, IAEA, IBRD, ICAO, IHB, ILO, IMF, ITU, NATO, OECD, Seabeds
Committee (observer), U.N., UPU, WHO, WMO
Legal name: Province of Guinea
Type: overseas province of Portugal
Capital: Bissau
Political subdivisions: 9 municipalities (concelhos-areas containing Europeans
and Educated Africans), 3 circumscriptions (predominantly indigenous population)
Legal system: based on Portuguese law
Branches: Governor General appointed by Ministry of Overseas has wide local
authority; he is assisted by an appointed Secretary-General and an 8-man
Government Council; a 15-member Legislative Council, 11 of whose members
are elected by various groups, represents economic and tribal interests of
province; Minister of Overseas can nullify any provincial legislation or
Governor''s decision; judiciary based on Portuguese system
Government leader: Governor General Antonio Sebastiao','26f94b5ac68dba01bceafc52588b86c0f693f5fceef11c1217ee8290373f7be5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('420b773657c64d44c7a49f2260fc9c139516c7692d333682c63ee72f2eadd74a',1971,'BR','Brazil','government',13,'Ribeiro de Spinola
Political parties and leaders: National Popular Action of Portugal only legal
party; opposition parties (illegal) include Partido Africano da Independencia
da Guinee e Cabo Verde (PAIGC), led by Amilcar Cabral, a Communist-supported
nationalist party which is chief political force conducting current
rebellion against Portuguese rule and which operates mainly from Republic of
Guinea; Front de Lutte pour 1''Independence Nationale de la Guinee (FLING),
a loose coalition of Senegal-based nationalist elements opposed both to the
Portuguese and the PAIGC, leadership fragmented, headed by Benjamin Pinto-
Bull; other nationalist factions
Suffrage: limited to those satisfying fairly rigid economic and cultural
requirements
Legal name: Province of Timor
Type: overseas province of Portugal
Capital: Dili
Political subdivisions: 12 administrative districts
Legal system: based on Portuguese law
Branches: Governor General appointed by Portuguese Minister of Overseas; advised
by a 7-member council composed of 4 ex offico members and 3 members elected
from the Legislative Council of 14 members (3 ex officio and 11 elected);
usual executive departments such aS Treasury > Health, Justice, Education,
Transportation exist, each of which is headed by a director
Government leader: Governor Brig. Jose Noqoueira Valente Pires (appointed 1968)
Suffrage: high school education required
Elections: Timor elects one representative to the Portuguese National Assembly,
scarcely more than a gesture
aie parties and leaders: single party only, the National Popular Action
on Timor
Voting strength: limited to Portuguese on Timor and small group of Timorese
who fulfill requirement ‘
Communists: prior to | October 1965, infiltration by Indonesian Communist Party
from Indonesian Timor, especially in the Oe-Cusse enclave
Legal name: Commonwealth of Puerto Rico
Type: commonwealth voluntarily associated with U.S.
Capital: San Juan
Political subdivisions: 76 municipalities
Legal system: based on civil codes; constitution came into effect 1952, U.S.
Constitution also applies; local courts and U.S. federal court; legal
education at University of Puerto Rico Law School
Branches: elected Governor and bicameral legislature; 9-judge Supreme Court
appointed by Governor
Government leader: Governor Luis A. Ferre
Elections: every 4 years, last election November 1968; plebescite held July
1967 on question of opting for statehood, continued commonwealth status, or
full independence; 60.5% for commonwealth status, 38.9% for statehood, 0.6%
for independence
Suffrage: universal over age 21
Political parties and leaders: Popular Democratic Party (PPD), Luis Negron Lopez;
Republican Statehood Party (PER); New Progressive Party (PPN), Luis A. Ferre;
Christian Action Party (PAC), Catholic Church; Independence Party (PI);
People''s Party (formed August 1968), Roberto Sanchez
Voting strength (1968 election): 44.6% PPN, 42.2% PPD, 9.4% People''s Party;
distribution of house seats -- NPP 26, PPD 25; distribution of Senate seats
-- PPD 16, PPN 11
Legal name: State of Qatar
Type: traditional monarchy; independence declared in 1971
Capital: Ad Dawhah
Legal system: discretionary system of law controlled by the ruler, although new
civil codes are being implemented; Islamic law is significant in personal
matters; a constitution was promulgated in 1970
Government leader: Amir Ahmad ibn ''Ali Al-Thani
Political parties and pressure groups: none; a few small clandestine organizations
are active
Branches: Council of Ministers
Member of: Arab League, U.N.
Legal name: Overseas Department of Reunion
Type: overseas department of France; represented in French Parliament by three
Deputies and two Senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a Prefect appointed by the French Minister
of Interior, assisted by a Secretary-General and an elected 36-man General
Council
Government leader: Prefect Jean Vaudeville
Suffrage: universal adult
Elections: last municipal elections in 1971; parliamentary election June 1968
Political parties and leaders: Reunion Communist Party (RCP) led by Paul Verges,
only organized political movement on island; other political candidates
affiliated with metropolitan French parties, which do not maintain permanent
organizations on Reunion
Voting strength (parliamentary election 1968): Gaullist candidates swept all 3
districts
Communists: Communist Party small -- probably only 15-20 hard-line Communists --
but has support among peasant sugarcane cutters and in Le Port district
Legal name: Colony of Southern Rhodesia
Type: self-proclaimed independent state since 1965 (not recognized by U.S.);
settlement reached with U.K. in November 1971, legal independence expected
first half of 1972
Capital: Salisbury
Political subdivisions: 11 magisterial districts
Legal system: Smith government implemented a republican constitution on 2 March
1970 which institutionalized white rule
Branches: President Dupont is ceremonial head of state; executive council
(cabinet) lead by Prime Minister Smith; National Assembly gives highly
disproportionate representation to white minority -- 50 white constituency
seats and 16 black constituency seats
Government leaders: Prime Minister Ian Smith and President Clifford Dupont
Suffrage: franchise is based on income, property holdings, and education; there
are separate rolls for Africans and non-Africans
Elections: must be held every 5 years
Political parties and leaders: Rhodesian Front, Prime Minister Smith; Centre
Party, Pat Bashford
Voting strength (1970 elections): Rhodesian Front won all 50 white constituency
seats in Parliament
Communists: negligible
Other pressure groups and leaders: African nationalist organizations banned
from political activity -- Zimbabwe African People''s Union, Joshua Nkomo;
Zimbabwe African National Union, Ndabaningi Sithole; these leaders detained
by government; exiled leaders in Lusaka, Zambia, are James Chikerema (ZAPU)
and Herbert Chitepo (ZANU)
Member of: no international bodies
Legal name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 39 counties and 46 municipalities, including Bucharest
Legal system: mixture of civil law system and Communist legal theory which
increasingly reflects Romanian traditions; constitution adopted 1965; legal
education at University of Bucharest and two other law schools; has not
accepted compulsory ICJ jurisdiction
Branches: Council of Ministers; the Grand National Assembly, under which is
Office of Prosecutor General and Supreme Court; Council of State is a
collective head of state
Government leaders: Ion Gheorghe Maurer, President of the Council of Ministers,
head of government; Nicolae Ceausescu, President of Council of State,
titular head of state
Suffrage: universal over age 18, compulsory
Elections: elections in Romania held every 2 years for the local people''s
councils and every 4 years for Grand National Assembly deputies
Political parties and leaders: Communist Party of Romania only functioning party,
Nicolae Ceausescu, General Secretary
Voting strength (1969 election): overall participation reached 99.96%; of those
registered to vote (13,577,143), 99.75% voted for party candidates
Communists: 2,089,085 party members (December 1970)
Member of: CEMA, FAQ, IAEA, ICAO, ILO, ITU, Seabeds Committee, U.N., UNESCO,
UPU, Warsaw Pact, WHO, WMO, GATT
Legal name: Republic of Rwanda
Type: republic, formerly combined with Burundi in U.N. trusteeship under Belgium;
became separate independent country in July 1962
Capital: Kigali
Political subdivisions: 10 prefectures , subdivided into 141 communes
Legal system: based on German and Belgian civil law systems and customary law;
constitution adopted 1962; judicial review of legislative acts in the
Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: executive consists of President, popularly elected for 4-year tern,
and 14 cabinet ministers; single house 47-member National Assembly, popularly
elected for 4-year terms; 6-member Supreme Court appointed by President
Government leader: President Gregoire Kayibanda
Suffrage: universal and compulsory over age 18
Elections: last legislative election September 1969; president reelected September
1969; both elected for 4-year terms
Political parties and leaders: Party of the Hutu Emancipation Movement
(PARMEHUTU), led by President Gregoire Kayibanda, dominates at all levels
Member of EAMA, IBRD, ICAQ, ILO, IMF, ITU, OCAM, OAU, U.N. UNESCO, WHO, WMO
Legal name: Ryukyu, southern
Type: U.S.-administered territory; will revert to Japan in 1972
Capital: Naha
Political subdivisions: 3 main island groups (Okinawa, Yaeyama, Miyako); 60
cities, towns, and villages
Legal system: based on Japanese civil law with specific U.S. enactments dealing
with the islands; U.S. Executive Order of 1957 functions as constitution
Branches: executive, judicial, and legislative branches
Government leader: Chief Executive, Chobyo Yara
Suffrage: universal over age 20
Elections: Japanese Diet elections held every four years or upon dissolution of
Lower House, triennially for one half of Upper House; Legislative Assembly,
every 3 years
Political parties and leaders: Okinawa Liberal Democratic Party (OLDP), Seisaku
Ota, president; Okinawa Socialist Masses Party (OSMP), Tsumichiyo Asato,
chairman; Okinawa People''s Party (OPP) (pro-Communist), Kamejiro Senaga,
chairman; Okinawa Prefecture Headquarters Japan Socialist Party (OUSP) ,
Kosuke Vehara, chairman
Voting strength: seats in Legislative Assembly following 1968 election -- OLDP
18, OSMP 9, OPP 3, OJSP 2
Communists: 300-400; sympathizers 2,000
Legal name: State of St. Chris topher-Nevis
Type: dependent territory with full internal autonomy as a British "Associated
State"; Anguilla formally seceded in May 1967 but has not been recognized
as an independent state by any government; in July 1968 a legislative
council headed by Ronald Webster was elected to govern Anguilla; in March
1969 the U.K. sent troops to Anguilla, placing the island again under
colonial rule
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law; constitution of 1960; highest judicial
organ is Court of Appeal of Leeward and Windward Islands
Government leaders: Premier, Robert L. Bradshaw; U.K. Governor, M. P. Allen
Suffrage: universal adult suffrage
Elections: at least every 5 years; most recent 10 May 1971
Political parties and leaders: OSt. Chris topher-Nevis-Anguilla Labor Party, Robert
L. Bradshaw; People''s Action Movement (PAM), William Herbert; Nevis Reformation
Party (NFP), Ivor Stevens
Voting strength (1971 election): St. Christopher-Nevis-Anguilla Labor Party won
7 seats in the House of Assembly, PAM won 2, 1 seat remains open for Anguilla
which did not participate in the election as a protest to United Kingdom''s
resumption of control over St. Christopher and Nevis
Communists: none known
Member of: CARIFTA
Legal name: Surinam
Type: territory within Kingdom of the Netherlands, enjoying complete domestic
autonomy
Capital: Paramaribo
Political subdivisions: 9 districts, each headed by district commissioner
responsible to Minister of Internal Affairs
Legal system: Dutch civil law system; country statute of 1955 serves as
constitution
Branches: Council of Ministers headed by a Minister-President, which constitutes
the Cabinet; 39-member legislative council (Staten) popularly elected for
4-year term; court system administered by Attorney-General under Minister
of Justice and Police
Government leader: Minister-President, Jules Sedney
Suffrage: universal over age 23
Elections: every 4 years or earlier upon request of Minister-President
Political parties and leaders: National Party of Surinam (NPS), (temporary
leader M. Ch. Calor); Party of the People''s Welfare (VHP), J. Lachmon; Action
Group (AG), R. Janki; Progressive National Party (PNP), Frank E. Essed;
Surinam Democratic Party (SDP), B. F. Jd. Oostburg; United Indonesian People''s
Party (SRI), F. Karsowidijojo; Javanese Farmers’ Party (KTPI), H. I. Soemita;
Nationalist Republic Party (PNR), Edward Bruma (principal leftist party )
Voting strength (1969): 27.7% NPS, 35.1% VHP, .2% AG, 23.3% PNP, 1.1% SDP, 3.4%
SRI, 8.8% other
Communists: no overt Communist Party
Member of: EC (associate), WHO
319
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $214 million (1969 est.); $550 per capita; real growth rate 1969, 0%
Agriculture: main crops -- rice, sugarcane, bananas; self-sufficient in major
staple (rice); caloric intake 2,500 calories per day per capita (1962)
Major industries: bauxite mining, alumina and aluminum production, lumbering,
food processing
Electric power: 220,000 kw. capacity (1970); 1.2 billion kw.-hr. production
(1970), 3,190 kw.-hr. per capita
Exports: $150 million (f.o.b., 1970); bauxite, alumina, wood and wood products,
rice
Imports: $123 million (c.i.f., 1970); capital equipment, petroleum, iron and
steel, cotton, flour, meat, dairy products
Major trade partners: exports -- U.S. 74%, Canada 9%, Netherlands 7%; imports
-- U.S. 47%, Netherlands 20%, Europe 16% (1966)
Aid: economic -- extensions from U.S. (FY54-70), $5.0 million loans, $4.7 million
grants; from international organizations (FY49-70), $33.2 million
Monetary conversion rate: 1.75 Surinam guilders (S. f1.)=US$1 (1 October 1971)
Fiscal year: calendar year
Legal name: Kingdom of Swaziland
Type: constitutional monarchy, under King Sobhuza I1; independent member of
Commonwealth since September 1968
Capital: Mbabane (administrative) Lobamba (royal and legislative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-Dutch law in statutory courts,
Swazi traditional law and custom in traditional courts; constitution
adopted in 1968; legal education at University of Botswana, Lesotho, and
Swaziland (located in Lesotho); has not accepted compulsory ICJ jurisdiction
Branches: executive authority vested in King but exercised through Prime Min-
ister and cabinet; cabinet appointed by King from legislative majority;
House of Assembly (24 elected, 6 appointed by King plus Speaker and Attorney
General) and Senate (6 elected by House of Assembly, 6 appointed by King,
Speaker) -- 17 Swazi courts administer customary law for Africans, High
Court and Subordinate Courts have criminal jurisdiction over all residents,
Court of Appeal has appellate jurisdiction
Government leader: Head of State King Sobhuza II; Prime Minister Makhosini
Dalmini
Suffrage: universal for adults
Elections: first elections for Legislative Council held in June 1964; latest
in April 1967
Political parties and Jeaders: Imbokodvo, the traditionalist party, controlled
by King Sobhuza II; Ngwane National Liberatory Congress (NNLC), led by
Dr. Ambrose Zwane, is only active opposition
Voting strength: Imbokodvo won 80% of vote in 1967 elections and all seats in
parliament; NNLC won 20% of vote but no seats
Communists: no Swaziland Communist Party
Member of: OAU, U.N.
Legal name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 provinces. 624 communes, 224 towns
Legal system: civil law system influenced by customary law; Acts of 1809,
1886, 1910, and 1949 serve as constitution; judicial review of legislative
acts in Supreme Court; legal education at Universities of Lund, Stockholm,
and Uppsala; accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament (Riksdag);
executive power vested in Crown but exercised by cabinet responsible to
parliament; Supreme Court, 6 superior courts, 152 lower courts
Government leaders: King Gustav VI Adolf; Prime Minister Olof Palme
Suffrage: universal, but not compulsory, over age 20
Elections: every 3 years. (next in 1973
Political parties and leaders: Conservative, Gosta Bohman; Center, Gunnar
Hedlund; Liberal, Gunnar Helen; Social Democratic, Olof Palme; Communist,
cules Hermansson; Communist League of Marxists-Leninists (KFML), Gunnar
Bylin
Voting strength (1970 election): 11.5% Conservative, 19.9% Center, 16.2% Liberal,
45.3% Social Democratic, 4.8% Communist, 0.4% KFML, 1.8% other
Communists: 17,000; a number of sympathizers as indicated by the 236,700
Communist votes cast in 1970 elections; an additional 21,200 votes cast for
Maoist KFML
Member of: Council of Europe, EFTA, FAQ, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHB,
ILO, IMCO, IMF, ITU, Nordic Council, OECD, Seabeds Committee (observer), U.N.,
UNESCO, UPU, WHO, WMO ,
Legal name: Swiss Confederation
Type: federal republic
Capital: Bern
Political subdivisions: 22 cantons (3 divided into half cantons)
Legal system: civil law system influenced by customary law; constitution adopted
1874, amended since; judicial review of legislative acts, except with
respect to Federal decrees of general obligatory character; legal education
at Universities of Bern, Geneva and Lausanne, and four other university
schools of law; accepts compulsory ICJ jurisdiction, with reservations
Branches: bicameral parliament has legislative authority; federal council
(Bundesrat) has executive authority; justice left chiefly to cantons
Government leader: Rudolf Gnaegi, President
Suffrage: universal over age 20
Elections: held every 4 years; next elections 1975
Political parties and leaders: Social Democratic Party (SPS), Fritz Gruetter,
president; Radical Democratic Party (FDP), Henri Schmitt, president;
Christian Conservative People''s Party (CVP), Franz Josef Kurmann, president;
Farmer, Artisan, and Middle Class Party (BGB), Hans Conzett, president;
Communist Party (PdA), Jacob Lechleiter, Jean Vincent, Andre Muret, all
Secretariat members; Republican Movement (REP)-National Action (N.A.), James
Schwarzenbach
Voting strength (1971 election): 49 seats FDP, 44 seats GVP, 46 seats SPS, 23
seats BGB, 5 seats pdA, 4 seats N.A., 7 seats REP, 22 seats others
Communists: 3,500; 50,831 votes in 1971 election
Member of: Council of Europe, EFTA, FAO, IAEA, ICAO, OECD, U.N. (permanent
observer), WHO, WMO','0cd00311898a6143515b539524bb11b7123f386fae179c8546b58554aaea2d75','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2ba5f5402f2b84953bb2aea44afbb1014ec54420c466ed828772e874b8cc393',1971,'IE','Ireland','government',25,'Legal name: Colony of Gibraltar
Type: U.K. colony
Capital: none
Legal system: English law; constitutional talks in July 1968; new system
effected in 1969 after electoral enquiry
Branches: parliamentary system comprised of the Gibraltar House of the Assembly
(15 elected members and 2 ex officio members), the Council of Ministers
headed by the Chief Minister, and the Gibraltar Council; the Governor is
appointed by the Crown
Government leaders: Governor and Commander in Chief, Adm. of the Fleet Sir
Vary] Begg; Chief Minister, Maj. Robert Peliza; Deputy Chief Minister,
Peter Isola
Suffrage: all adult Gibraltarians, plus other U.K. subjects resident 6 months
or more
Elections: every 5 years; last held in July 1969
Political parties and leaders: Association for Advancement of Civil Rights
(AACR), Sir Joshua Hassan; Labor, Sir Joshua Hassan; Independents, Peter
Isola; Integrationists (IWBP), Maj. Robert Peliza
Voting strength: In 1969, the AACR won 7 seats in the Assembly, the IWBP won 5,
the Independents won 3; a coalition between the latter two parties was formed
Communists: none known
Other political or pressure groups: the Housewives Association; the Chamber
of Commerce
Legal name: Kingdom of Greece
Type: constitutional monarchy; power in hands of ex-military leaders since
April 1967
Capital: -Athens
Political subdivisions: 52 departments (nomoi) administered by the central
government (probably will be altered)
Legal system: based on Roman and Byzantine law, substantially altered by civil
codes of 1946-51; legal training at University of Athens; compulsory ICJ
jurisdiction not accepted
Branches: new constitution implemented in November 1968, except for certain
articles concerning individual rights, political activity, and powers of the
courts theoretically implemented through new legislation in 1969; however,
in practice repression of these rights still exists; Consultative Assembly
elected in 1970
Government leaders: King Constantine, head of state (in exile); Lt. Gen. George
Zoitakis, Regent; actual authority lies in hands of ex-military headed by
Georgis Papadopoulos, Prime Minister, Minister of Defense, and Foreign
Minister; Stylianos Pattakos, First Deputy Prime Minister; and Nikolaos
Makarezos, Second Deputy Prime Minister
Suffrage: universal age 21 and over
Elections: subject to scheduling of government
Political parties and leaders: political activities suppressed; party leadership
and organization in disarray
Communists: 12% of electorate in February 1964; hard-core elements imprisoned;
Communist Party (KKE) outlawed since 1947
Member of: EC (associate member), FAO, FUND, IAEA, IBRD, ICAO, IDA, IFC, IHB,
ILO, IMCO, ITU, NATO, OECD, U.N., UNESCO, UPU, WHO, WMO
Legal name: Greenland
Type: province of Kingdom of Denmark; 2 representatives in Danish parliament;
separate Minister for Greenland in the Danish cabinet
Capital: Godthaab (administrative center)
Political subdivisions: 3 counties, 19 communes
Legal system: Danish law; transformed from colony to province in 1953
Branches: legislative authority rests jointly with Crown and Danish parliament;
executive power vested in Crown, acting through provincial governor
responsible to Minister for Greenland; local affairs handled by provincial
council (Landsr@d) subject to approval of provincial governor; 19 lower courts
Government leader: King Frederick IX; Governor N.O. Christensen
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years (next 1975)
Political parties: Inuit (advocating close ties with Denmark); Sukaq (moderate
socialist, advocating more distinct Greenland identity)
Legal name: State of Grenada
Type: dependent territory with full internal autonomy as a British “Associated
State"
Capital: St. Georges
Political subdivisions: 6 parishes
Legal system: based on English common law
Government leaders: Premier Eric Matthew Gairy; U.K. Governor Dr. Hilda Bynoe
Suffrage: universal aduit suffrage
Elections: every 5 years; most recent election August 1967
Political parties and leaders: Grenada United Labor Party (GULP), Eric Matthew
Gairy; Grenada National Party (GNP), Herbert A. Blaize
Voting strength (1967 election): GULP 53.9%, GNP 46.12; Legislative Council
seats, GULP 7, GNP 3
Communists: negligible
Member of: CARIFTA
Legal name: Guadeloupe
Type: overseas department of France 3 represented by 3 deputies in the French
National Assembly and 2 deputies in the Senate
Capital: Basse-lerre
Political subdivisions: 3 arrondissements ; 34 communes ; each with a locally
elected municipal council
Legal system: French civil law system; highest court is a court of appeal based
in Martinique with jurisdiction over Guadeloupe, Guiana, and Martinique
Branches: executive, Prefecture appointed by Paris; legislative, popularly
elected council of 36 members 3 judicial, under jurisdiction of French legal
system
Government leader: Prefect Pierre Brunon
Suffrage: universal over age 21
Elections: General Council elections coincide with those for the French National
Assembly, normally every 5 years; last General Council election took place
in March 1970
Political parties and leaders: Union of Democrats for the Republic (UDR), Paul
Greese; Communist Party of Guadeloupe (PCG) Henri Bangou; Socialist Party,
leader unknown; Progressive Party of Guadeloupe (PPG), Henri Rodes ;
Independent Republicans ; leader unknown
Yoting strength: PCG, 1 seat in French National Assembly; UDR, 1 seat; Independent
Republicans, | seat. (1968 election)
Communists: 2,000, 11,000 sympathizers
ae alae or pressure groups + Group of National Organization of Guadeloupe
GONG
Legal name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions: 22 departments
Legal system: civil law system; constitution came into effect 1966; judicial
review of legislative acts; Jegal education at University of San Carlos of
Guatemala; has not accepted compulsory ICJ jurisdiction
Branches: traditionally dominant executive; elected unicameral legislature;
J-member (minimum) Supreme Court
Government leader: President Carlos Arana
Suffrage: universal over age 18, compulsory for literates, optional for illiterates
Elections: next elections {President and Congress) March 1974
Political parties and leaders: Democratic Institutional Party (PID), Donaldo
Alvarez Ruiz; Revolutionary Party (PR), Alberto Fuentes Mohr (Sec. Gen.);
National Liberation Movement (MLN), Mario Sandoval Alarcon; Guatemalan
Christian Democratic Party (DCG), Danilo Barillas Rodriguez
Voting strength: for President -- MLN-PID 251,135 (40%), PR 202,241 (32.5%), DCG
125,948 (20%) null, 7.5%; for congressional seats -- PR 16, MLN-PID 34, DCG 5
Other political or pressure groups : outlawed (Communist) Guatemalan Labor Party
(PGT), Bernardo Alvarado; Revolutionary Democratic Unity (URD), Francisco
Villagran Kramer
Member of: CACM, IADB, IAEA, ICAQ, IHB, OAS, ODECA, U.N.
Legal name: Republic of Guinea
Type: republic; under one-party presidential regime
Capital: Conakry
Political subdivisions: 30 administrative regions, 204 arrondissements, about
8,000 local entities of village or district level
Legal system: based on French civil law system and customary law; constitution
adopted 1958; no constitutional provision for judicial review of legislative
acts; has not accepted compulsory ICJ jurisdiction
Branches: executive branch dominant, with power concentrated in President''s
hands and a small group who are both ministers and members of the party''s
politburo; unicamera] National Assembly and judiciary have little independence
Government leader: President Ahmed Sekou Toure, who has been designated
"The Supreme Leader of the Revolution"
Suffrage: universal over age 18
Elections: approximate schedule -- 5 years parliamentary, latest in 1968;
7 years Presidential, latest in 1968
Political parties and leaders: only party 4s Democratic Party of Guinea (PDG),
headed by Sekou Toure
Communists: no Guinean Communists have been identified, although there are some
sympathizers
Member of: FAO, ICAO, ILO, ITU, OAU, U.N., UNESCO, UPU, WHO, WMO
~','7931229a19564e951da0ea8974e86275c0ad2b83be0e584a565ed2f1fb842c93','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09f181ffbe53f2f4d6aedbdbf4294c7501a237af1f7867aee59679691b15c8ac',1971,'ET','Ethiopia','government',30,'Legal name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital: ‘Amman
Political subdivisions: 8 districts (3 are under Israeli occupation) under
centrally appointed officials
Legal system: based on Islamic law and French codes; constitution adopted 1952;
judicial review of legislative acts ina specially provided High Tribunal;
has not accepted compulsory ICJ jurisdiction
Branches: executive branch holds balance of power; King is effective ruler with
Prime Minister exercising executive authority in name of King; Cabinet
appointed by King and responsible to parliament; bicameral parliament with
Chamber of Deputies chosen by national elections, Senate appointed by King;
each house contains equal representation from East and West Jordan; present
parliament subservient to executive as a result of rigged elections (April
1967); secular court system based on differing legal systems of the former
Transjordan and Palestine; law Western in concept and structure; Sharia
(religious) courts for Muslims, and religious community council courts for
non-Muslim communities; desert police carry out quasi-judicial functions
in desert areas
Government leader: King Husayn ibn Talal al-Hashimi
Suffrage: male citizens over age 20
Political parties and leaders: political party activity illegal since 1957;
Palestine Liberation Organization and Fatah, Yasir Arafat; various smaller
fedayeen groups; Ba''th Party of Jordan, Dr. Mun''if Razzaz; National
Socialist Party, Sulayman al-Nabulust; Communist Party actively repressed;
Muslim Brethren
169
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GOVERNMENT (cont''d):
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Republic of Kenya
Type: republic within Commonwealth since December 1963
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi Area
Legal system: based on English common law, tribal law and Islamic law;
constitution enacted 1963; judicial review in Supreme Court; legal education
at University Kenya School of Law in Nairobi; accepts compulsory ICJ
jurisdiction, with reservations
Branches: President and Cabinet responsible to unicameral legislature (National
Assembly) of 170 seats, 158 directly elected by constituencies and 12
specially elected by the Assembly; Assembly must be reelected at least every
5 years; High Court, with Chief Justice and at least 11 justices, has
unlimited original jurisdiction to hear and determine any civil or criminal
proceeding; provision for systems of courts of appeal with ultimate appeal
to East African Court of Appeals
Government leader: President Jomo Kenyatta
Suffrage: universal over age 2]
Elections: general election (December 1969) elected present National Assembly
Political party and leaders: Kenyan African National Union (KANU), president -
Jomo Kenyatta
Voting strength: KANU controls National Assembly; holds all seats
Communists: may be a few Communists and sympathizers
Member of: EAC, IAEA, ICAO, OAU, Seabeds Committee, U.N.
Legal name: Democratic People''s Republic of Korea
Type: Communist state; one-man rule
Capital: P''yongyang
Political subdivisions: 9 provinces, 3 special cities (P''yongyang, Hamhung,
Ch''ongjin), and 1 special district (Kaesong)
Legal system: based on German civil law system with Japanese influences and
Communist legal theory; constitution adopted 1948; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
Branches: constitution provides for a Supreme People''s Assembly (SPA), with
provincial government under complete control of central authorities
Government and party leaders: Kim Il-song, Premier and General Secretary
of the Korean Labor Party
Suffrage: universal at age 18
Elections: election to SPA every 4 years, but this constitutional provision not
necessarily followed -- last election (November 1967), with claimed 100% of
electorate voting for official slate
Political party: Korean Labor (Communist) Party; claimed membership of about
1.6 million, or about 12% of population
Member. of: no international bodies
Legal name: Republic of Korea
Type: republic; power centralized in a strong executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities; heads centrally appointed
Legal system: combines elements of continental European civil law systems,
Anglo-American law, and Chinese classical thought; constitution approved
1962; judicial review of legislative acts in Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: executive, legislative (unicameral), and judiciary
Government leaders: President Pak Chong-hui; Prime Minister Kim Chong-pil
Suffrage: universal over age 20
Elections: presidential and National Assembly elections must be held every 4
years; National Assembly elections due about 1 month after Presidential
elections; last elections held in April and May 1971 respectively
Principal political parties and leaders: Democratic Republican Party, Pak
Chong-hui; New Democratic Party, Kim Hong-i1
Voting strength: April 1971 presidential election -- Democratic Republican Party,
51.1%; New Democratic Party, 43.4%; minor parties, 1.5%; invalid, 4.0% June
1971 National Assembly elections -- Democratic Republican Party, 49%; New
Democratic Party, 44%; minor parties, 3.0%; invalid 2.0% composition of
legislature (25 May 1971) -- Democratic Republican Party, 113 seats; New
Democratic Party, 89 seats; Peoples'' Party, 1 seat; Nationalist Party, 1 seat
Other political or pressure groups: Federation of Korean Trade Unions; Korean
Veterans! Association; large volatile student population concentrated in Seoul
Member of: ADB, Asian Parliamentary Union, Asian People''s Anti-Communist League
(APACL), ASPAC, Colombo Plan, ECAFE, FAQ, GATT, Geneva Conventions of 1949
for the protection of war victims, IAEA, IBRD, ICAO, IDA, IFC, IHB, IMCO, IMF,
INTELSAT, Inter-Parliamentary Union, INTERPOL, ITU, UNESCO, U.N. Special Fund,
UPU, WHO, WMO, World Anti-Communist League (WACL); does not hold U.N.
membership
Approved For Release 2004/08/31 / CIA-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $8.1 billion (1970), $250 per capita; real growth 9% (1965-70)
Agriculture: 50% of the population live on the land, but agriculture constitutes
27% GNP; main crops -- rice, barley, wheat; not self-sufficient; food
shortages -- barley, wheat, dairy products, rice, corn
Fishing: Catch 852,000 tons, $172 million (1969)
Major industries: textiles and clothing, food processing, chemical fertilizers,
chemicals, plywood, coal
Shortages: base metals, fertilizer, petroleum, lumber and certain food grains
Electric power: 1,794,000 kw. capacity (1968); 8.1 billion kw.-hr. produced
(1969), 250 kw.-hr. per capita
Exports: $835 million (f.o.b., 1970); clothing and textiles, veneer and plywood,
silk, wigs
Imports: $1,984 million (c.i.f., 1970)
Major trade partners: 1970 exports -- U.S. 47%, Japan 28%; imports -- Japan
Al%, U.S. 29%
Aid:
economic -- U.S. (FY46-70), $5.1 billion committed; Japan (1965-70), $580
million extended;
military -- U.S. (FY46-70), $3.6 billion committed
Monetary conversion rate: 310 won=US$1 (floating-rate average value in 1970),
370 won=US$1 by end of June 197]
Fiscal year: calendar year
Legal name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Al Kuwayt
Political subdivisions: 3 governates, 10 voting constituencies
Legal system: based on Islamic law in personal matters, civil law system with
Islamic law significant in personal matters; constitution adopted 1962;
judicial review of legislative acts not yet determined; has not accepted
compulsory ICJ jurisdiction
Branches: Council of Ministers; National Assembly
Government leader: Amir Sabah Al Salim Al Sabah
Suffrage: native born and naturalized males over age 21
Elections: held every 4 years for National Assembly; last held January 197]
Communists: insignificant
Member of: Arab League, FAO, FUND, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO, ITU,
OPEC, OAPEC, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Laos
Type: constitutional monarchy
Capital: Vientiane (Louangphrabang royal capital)
Political subdivisions: 16 provinces subdivided into districts, cantons, and
villages
Legal system: based on civil law system; constitution of 1947 superseded by
international agreements of 1962 and subsequent events ; has not accepted
compulsory ICJd jurisdiction
Branches: King, 59-member National Assembly, 12-member King''s Council; provisional]
coalition government formally composed of 3 "tendencies" -- neutralists,
Communists, rightists -- but Communists not participating
Government leaders: King. Savang Vatthana; Premier Souvanna Phouma, neutralist;
Deputy Premier Prince Souphanouvong , Communist (absent); Deputy Premier
Leuam Insisiengmay, rightist
Suffrage: universal over age 18
Elections: National Assembly designated by King; general election last held
in 1967, assembly election scheduled for January 1972
Political parties and leaders: Neo Lao Hak Sat, Communist-front organization
which includes the Lao People''s Party (Communist) » only party active
Communists: Lao People''s Party (clandestine) membership unknown
Other political or pressure groups: Communists are resisting "neutralist"
government; insurgent Communist forces with North Vietnamese backing
pose serious threat to existing government; other political groups are
informal and associated with regional family and military leaders; Prince
Boun Oum is the acknowledged, though not formal leader of the Laotian
rightists; Royal Armed Forces (FAR) leaders, Commander in Chief Bounpone
Makthepharack, and Generals Kouprasith Abhay, Phasouk Somly, Vang Pao, Soutchay
Vongsavanh, and Ret. Gen. Ouan Rathi Koun
Member of: Colombo Plan, ECAFE, ICAO, IMF, Mekong Committee, SEAMES, U.N., UNCTAD
Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political. subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law, and civil law system; consti-
tution mandated in 1920; no judicial review of legislative acts; legal
education at University of Lebanon; has not accepted compulsory ICJ
jurisdiction
Branches: power lies with President elected by parliament (Chamber of Deputies);
Cabinet appointed by President, approved by parliament; independent secular
courts on French pattern; religious courts for matters of marriage, divorce,
inheritance, etc.; by custom, President is a Maronite Christian, Prime
Minister a Sunni Muslim, and president of parliament a Shia Muslim; each of
9 religious communities represented in parliament in proportion to national
numerical strength
Government leader: President Sulayman Franjiyyah
Suffrage: compulsory for all males over 21; authorized for women over 21] with
elementary education
Elections: for Chamber of Deputies, held every 4 years or within 3 months of
dissolution of Chamber; held March-April 1968
Political parties and leaders: political party activity is organized along.
sectarian lines; numerous political groupings exist, consisting of individual
political figures and followers motivated by religious, clan, and economic
i considerations; political stability dependent on maintenance of balance
between religious communities; Communist Party one of largest in Middle
East, was made a legal party on 15 August 1970
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Lesotho
Type: constitutional monarchy under King Moshoeshoe II
Capital: Maseru
Political subdivisions: 9 administrative districts
Legal system: based on English common law and Roman-Dutch law; constitution came
into effect 1966; judicial review of legislative acts in High Court and
Court of Appeal; legal education at University of Botswana, Lesotho, and
Swaziland (located in Lesotho); has not accepted compulsory ICJ jurisdiction
Branches: executive, divided between a largely ceremonial King and a Prime
Minister who leads cabinet of at least 7 members; a bicameral legislature
consisting of a National Assembly (60 seats) and a Senate (33 seats);
judicial -- 63 Lesotho courts administer customary law for Africans, High
Court and subordinate courts have criminal jurisdiction over all residents,
Court of Appeal at Maseru has appellate jurisdiction
Government leader: Prime Minister Chief Leabua Jonathan
Suffrage: universal for adults
Elections: elections held in January 1970; nullified allegedly because of election
irregularities; subsequent elections promised at unspecified date
Political parties and leaders: Basutoland Congress Party (BCP), Ntsu Mokhele;
Marema-tlou Freedom Party (MFP), Dr. Seth Makotoko; National Party. (BNP),
Chief Leabua Jonathan
Voting strength: National Assembly -- BNP 32 seats, BCP 22 seats, MFP 2 seats,
LDP 2 seats, 2 seats vacant; Senate -- BNP holds 24 of 33 seats (1965
elections)
Communists: Communist Party of Lesotho banned in early 1970, although in past
it received support from Chinese Communists
Member of: Commonwealth, FAQ, ILO, ITU, U.N., UNESCO, UPU, WHO
Legal name: Republic of Liberia
Type: republic; dominated by strong executive
Capital: Monrovia
Political subdivisions: country divided into 9 counties; President appoints all
officials of significance
Legal system: based on U.S. constitutional theory; recent codes drawn up by
Cornell University; constitution adopted 1847; amended 1907, 1926, 1934,
and 1955; no constitutional provision for judicial review of legislative
acts; legal education at Louis Arthur Grimes School of Law, University of
Liberia; accepts compulsory ICJ jurisdiction, with reservations
Branches: President, elected by popular vote initially for 8-year term and
eligible for successive 4-year terms, controls through appointive powers and
authority over national expenditures; 2-house legislature elected by popular
vote is rubber stamp; judiciary consisting of Supreme Court and variety of
lower courts theoretically independent but in fact subordinate to executive
Government leader: President William R. Tolbert
Suffrage: universal over age 21
Elections: members of House of Representatives elected for 4-year terms, most
recently in May 1971; Senate members elected for 6-year terms, one-half
elected in May 1971; President Tolbert, constitutional successor to President
Tubman who died in July 1971, is eligible to complete the four year term to
which Tubman was elected in May 19713; next scheduled presidential election May
1975
Political parties and leaders: True Whig Party, in power since 1878, only
political party; President Tolbert is leader
Voting strength: 1971 elections uncontested; True Whig Party won all but a
handful of votes
Communists: no Communist Party and only a few sympathizers
Member of: ECA, FAQ, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, OAU, Seabeds Committee,
U.N., UNESCO, UPU, WHO
185
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GDP: $417 million (1970), 3% real growth rate (approx. 6% 1969 real growth rate),
$360 per capita
Agriculture: rubber, oil palm, cassava, coffee, rice; imports of rice, wheat,
and meat are necessary for basic diet
Fishing: catch 18,500 tons, $6.1 million (1969)
Industry: rubber processing, food processing, construction materials, furniture,
palm oil processing, mining (iron ore, diamonds), 10,000 b/d oil refinery
Electric power: 152,000 kw. capacity (1970); 540 million kw.-hr. produced (1970),
470 kw.-hr. per capita
Exports: $214 million (f.o.b., 1970); iron ore, diamonds, rubber, palm kernels,
coffee, cocoa
Imports: $151 million (c.i.f., 1970); machinery, transportation equipment,
foodstuffs, manufactured goods
Major trade partners: U.S., West Germany, Japan, U.K.
Aid:
economic -- (FY62-70) U.S., $158.3 million;
military -- (FY62-70) U.S., $6.8 million; other aid sources include IBRD,
U.N., IMF, and West Germany
Monetary conversion rate: Liberia uses U.S. currency
Fiscal year: calendar year
Legal name: Libyan Arab Republic
Type: republic; under military control following ouster of king on 1 September
1969; provisional constitution promulgated December 1969
Capital: Tripoli (defacto)
Political subdivisions: 10 administrative provinces closely controlled by
central government; district commissioners appointed by Revolutionary
Command Council
Legal system: based on Italian civil law system and Islamic law; separate
religious courts; no constitutional provision for judicial review of legislative
acts; legal education at Law School, at University of Libya at Banghazi; has
not accepted compulsory ICJ jurisdiction
Branches: paramount political power and authority rests with the Revolutionary
Command Council; cabinet of 12 ministers; Parliament has been dissolved
salt leaders: Revolutionary Command Council Presidentt Colonel Mu''ammar
Qadhafi
Elections: last held in May 1965, Libyan Arab Socialist Union scheduled in October
1971
Political parties and leaders: Libyan Arab Socialist Union still being formed
Communists: no organized party, negligible membership
Other political or pressure groups: various Arab nationalist movements and the
Arab Socialist Resurrection (Ba''th) Party with small, almost negligible
memberships may be functioning clandestinely
Member of: Arab League, FAQ, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
OPEC, OAPEC, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','e87cef2eb993c2e90d6828182d3b1ae2a75d7bc6d2f63dd2c1c5f42980cac18c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bc8f728bbe30aafae56cd90bbdd4ddcc1b085682fb665ea210e2538ef06020a',1971,'NO','Norway','government',34,'Legal name: Principality of Liechtenstein
Type: hereditary constitutional monarchy
Capital: Vaduz
Political subdivisions: 11 districts
Legal system: based on Swiss law; constitution adopted 1921; judicial review of
legislative acts ina special Constitutional Court; accepts compulsory ICd
jurisdiction, with reservations
Branches: unicameral Parliament, hereditary Prince, independent judiciary
Government leaders: Head of State, Prince Franz Joseph II; Chief of Government,
Dr. Alfred Hilbe .
Suffrage: males age 20 and over
Elections: every 4 years; next elections 1974
Political parties and leaders: Fatherland Union Party (VU), Dr. Alfred Hilbe;
Progressive Citizens Party (PCP), Dr. Gerard Batliner
Voting strength (1970 election): 50.5% VU, 49.5% PCP
Communists: none
Member of: IAEA, IPU, ITU; seeking U.N. membership; under a 1923 treaty, Switzer-
land handles Liechtenstein''s post and telegraph systems, customs , and foreign
relations
Legal name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for administrative purposes has 3
districts (Luxembourg, Diekirch, Grevenmacher) and 12 cantons
Legal system: based on civil law system; constitution adopted 1868; judicial
review of legislative acts in the Cassation Court only; accepts compulsory
ICJ jurisdiction
Branches: parliamentary democracy; seven ministers comprise Council of Government
headed by President, which constitutes the executive; it is responsible to
the unicameral legislature, the Chamber of Deputies; the Council of State,
appointed for indefinite term, exercises some powers of an upper house; judicial
power exercised by independent courts
Government leader: Pierre Werner, Minister of State and President of the Govern-
ment as well as Minister of Treasury
Suffrage: universal and compulsory over age 21
Elections: every 5 years for entire Chamber of Deputies; latest elections Dec-
ember 1968; next election, December 1973
Political parties and leaders: Christian Social Union, Pierre Werner and Jean
Dupong (Party President); Socialist, Antone Wehenkel (Party President); Social
Democrat, Ernst Lay (Party President); Democratic, Gaston Thorn (Party
President and Foreign Minister); Communist, Dominique Urbany
Voting strength (1968 election, approx.): 32% Socialist, 35% Christian Socialist,
15% Communist, 17% Democratic, 1% other; it should be noted that these are
percentages of votes cast rather than voters, since Luxembourg has a weighted
proportional representation system in which voters in most populous areas
have largest multiple votes
Communists: 520 party members
Other political or pressure groups: group of steel industries representing iron
and steel industry, Centrale Paysanne representing agricultural producers;
Christian and Socialist labor unions, Federation of Industrialists; Artisans
and Shopkeepers Federation
Member of: Benelux, BLEU (Belgium-Luxembourg Economic Union), Council of Europe,
EC, FAQ, IAEA, IBRD, ICAO, IFC, ILO, IMF, NATO, OECD, U.N., UPU, WEU, WHO, WMO
191
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $995.7 million (1970), $2,910 per capita; 56.4% consumption, 29.8% investment,
11.0% government, 2.8% net exports of goods and services, 1970 growth rate
3.5% at 1963 constant prices
Agriculture: mixed farming; main crops -- grains, potatoes, fodder beets; food
shortages -- sugar, bread grains, fats; caloric intake, 3,090 calories per
day per capita (1967-68 est.)
Major industries: iron and steel, food processing, chemicals, metal products and
engineering, tires
Shortages: crude petroleum, coal, textile materials
Crude steel: 5.5 million metric tons produced (1970), about 16,080 kg. per capita
Electric power: 1,177,000 kw. capacity (1970); 2,520 million kw.-hr. produced
(1970), 6,290 kw.-hr. per capita
Exports: $869.0 million (f.o.b., 1970)
Imports: $686.4 million (c.i.f., 1970)
Major trade partners: Luxembourg and Belgium form an economic and customs union
and report their foreign trade jointly (see Belgium); Luxembourg''s principal
exports are iron and steel products; principal imports are coal and consumer
products; most foreign trade is with Germany, Belgium, and other EC countries;
about 7% of steel exports to the U.S. (1969)
Aid: foreign aid to Luxembourg is included in aid to Belgium
Monetary conversion rate: 50 Luxembourg francs=US$1 (official); under the BLEU
agreement, the Luxembourg franc is equal to the Belgian franc which circulates
freely in Luxembourg
Fiscal year: calendar year
Legal name: Province of Macao
Type: overseas province of Portugal
Capital: Lisbon (Portugal )
Political subdivisions: municipality of Macao, and 2 islands
Legal system: Portuguese civil law system
Branches: Governor, who dominates legislative and executive branches, assisted
by Legislative Council with unknown number of appointed and 8 elected
members ; the Urban Council with 3 governor-appointed and 4 elected members 3;
all high-ranking officials appointive under provisions of revised Organic
Overseas Law
Government leader: Brigadier Jose Manuel Nobre De Carvalho, Governor
Suffrage: restricted to Portuguese citizens
Elections: conducted every 4 years; last held November 1968 ;
Political parties and leaders: Portuguese National Union (Uniao Nacional) only
legal party, as in Portugal; Governor is leading political figure
Other political or pressure groups: wealthy Macanese and Chinese representing
local interests, wealthy pro-Communist merchants representing China''s
interests; in January 1967 Macao Government acceded to Chinese demands which
gave Chinese veto power over administration of the enclave
Legal name: Malagasy Republic
Type: republic; under one-party rule since independence in June 1960
Capital: Tananarive
Political subdivisions: 6 provinces
Legal system: based on French civil law system and Islamic law; constitution
adopted 1959, amended 1960, 1962, and 1970; judicial review of legislative
acts in High Council of Institutions; legal education at National School of
Law, University of Tananarive; has not accepted compulsory ICJ jurisdiction
Branches: executive -- President has wide powers, elected for 7-year term by
direct universal suffrage; legislative -- bicameral (National Assembly and
Senate); judicial -- patterned after French system
Government leader: President Philibert Tsiranana
Suffrage: universal for adults
Elections: held regularly but opposition parties are hampered by restrictions
on campaigning ©
Political parties and leaders: Parti Social Democrate (PSD), led by Tsiranana as
National President and a secretary General, appointed by National President,
for | year; leading opposition party is AKFM (Congress Party
for the Independence of Madagascar), led by Pastor Richard Andriamanjato
Voting strength: (1970 elections) President Tsiranana received 97% of votes cast;
PSD candidates for National Assembly won 94%; AKFM 3%
Communists: small Communist party under close surveillance by government
security forces; Communist party virtually of no importance; small and
vocal group of Communists has gained strong position in leadership
of AKFM, the rank and file of which is non-Communist
Member of: EAMA, FAO, IAEA, ICAO, ILO, IMCO, ITU, OAU, OCAM, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2004/08/31 9 TIA-RDP79-01051A000400010002-1
ECONOMY: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $794.2 million (1969), about $120 per capita; a real increase of 8.9% between
1968 and 1969, almost all due to price increases because of franc devaluation
Agriculture: cash crops -- coffee, vanilla, sugar, tobacco, sisal, rice, cloves,
raphia; food crops -- rice, Cassava, cereals, potatoes, corn, beans,
bananas, coconuts, and peanuts; animal husbandry widespread; self-
sufficient in foodstuffs, but some milk and cereals imported
Fishing: catch 69,900 tons
Major industries: agricultural processing (meat canneries, soap factories,
brewery, tanneries, sugar refining), light consumer goods industries
(textiles, glassware), cement plant, auto assembly plant, paper mill, oil
refinery :
Electric power: 14,600 kw. capacity (1970); 200 million kw.-hr. produced (1970),
30 kw.-hr. per capita
Exports: $104.9 million (f.o.b., 1969); coffee 28%, rice 8%, vanilla 10%, sugar
7%, petroleum products 4%, sisal 3%; mineral products, graphite and mica 3%;
agricultural and livestock products account for about 85% of export earnings
Imports: $145.0 million (f.0.b., 1969); consumer goods 46% -- food, beverages,
textiles, clothing; capital equipment 26% -- machinery, appliances, and
electrical; raw materials 28% -- cement, energy products, fertilizers
(percent figures for 1969)
Major trade partners: France (in 1969 accounted for 36% of exports and 52% of
imports); U.S., preferential tariffs to EC and franc zone countries; trade
with Communist countries remains a minute part of total trade
Monetary conversion rate: 278 Malagasy francs=US$1 (official); member of
French franc zone
Fiscal year: calendar year
Legal name: Republic of Malawi
Type: republic since July 1966; independent member of Commonweal th
Capital: Zomba
Political subdivisions: local government unit is the district
Legal system: based on English common law and customary law; constitution
adopted 1964; judicial review of legislative acts in the Supreme Court of
Appeal; has not accepted compulsory ICJ jurisdiction
Branches: strong presidential system with cabinet appointed by President; uni-
cameral National Assembly of 60 elected and 15 nominated members; High
Court with Chief Justice and at least 2 justices
Government leader: President Hastings Kamuzu Banda
Suffrage: universal adult
Elections: scheduled for April 1971 but not held since MCP candidates were unopposed
Political parties and leaders: Malawi Congress Party (MCP), Dr. Hastings Kamuzu
Banda
Communists: no Communist Party; may be a few Communist sympathizers
Member of: FAO, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU, U.N., UNESCO, WHO, WMO
Legal name: Malaysia
Type:
Malaysia: constitutional monarchy nominally headed by Paramount Ruler (King)
West Malaysian states: hereditary rulers in all but Penang and Malacca where
Governors appointed by Malaysian Government; powers of state governments
limited by federal constitution.
Sabah: self-governing state within Malaysia in which it holds 16 seats in
House of Representatives; foreign affairs, defense, internal security,
and other powers delegated to federal government
Sarawak: self-governing state within Malaysia in which it holds 24 seats in
House of Representatives; foreign affairs, defense, and internal security,
and other powers are delegated to federal government
Capital:
West Malaysia: Kuala Lumpur
Sabah: Kota Kinabalu (formerly Jesselton)
Sarawak: Kuching
Political subdivisions: 13 states (including Sabah and Sarawak)
Legal system: based on English common law; constitution came into force 1963;
judicial review of legislative acts in the Supreme Court at request of
Supreme Head of the Federation; has not accepted compulsory ICd jurisdiction
Branches: 9 state rulers alternate as Paramount Ruler for 5-year terms; locus of
executive power vested in Prime Minister and cabinet, who are responsible
to bicameral parliament; following communal rioting in May 1969, govern-
ment imposed state of emergency and suspended constitutional rights of ali
parliamentary bodies; parliamentary democracy resumed in February 1971
West Malaysia: executive branches of 11 states vary in detail but are similar
in design; a Chief Minister, appointed by hereditary ruler or Governor,
heads an executive council (cabinet) which is responsible to an elected,
unicameral legislature
Sarawak and Sabah: executive branch headed by Governor appointed by central
government , largely ceremonial role; executive power exercised by Chief
Minister who heads parliamentary cabinet responsible to unicameral
legislature; judiciary part of Malaysian judicial system
Government leader: Head of State, Tun Abdul Razak
Suffrage: universal over age 20
Elections: minimum of every 5 years
Political parties and leaders:
West Malaysia: Alliance Party consisting of United Malays National Organiza-
tion (UMNO), Tun Abdul Razak; Malaysian Chinese Association (MCA), Tan
Siew Sin; and Malaysian Indian Congress (MIC), V.T. Sambanthan; major
opposition parties -- Pan Malayan Islamic Party (PMIP), Dato Asri bin Haji
200
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GOVERNMENT Ajoprovert For Rele CIA.
Political parties and eae (08! iyi CIA RDP79-01051A000400010002-1
West Malaysia (cont''d):
Muda (acting); Labor Party of Malaya (LPM), Lim Kean Siew (acting);
Democratic Action Party (DAP); Gerakan Rakyat Malaysia (GRM); minor
opposition parties -- Party Rakyat (PR), People''s Progressive Party (PPP),
Partai Keadilan Masharakyat (KEMAS), United Malaysian Chinese Organization
(UMCO); Communist Party illegal
Sabah: United Sabah National Organization (USNO), Tun Mustapha bin Dato
Harun; Sabah Chinese Association (SCA), Khoo Siak Chiew; no organized
opposition
Sarawak: coalition composed of Sarawak Alliance and Sarawak United Peoples
Party (SUPP), Ong Kee Hui; Opposition Sarawak National Party, Stephen
Ningkan
Voting strength:
West Malaysia: (1969 election) Alliance Party controls 9 of 11 state
legislatures, won estimated 49% of total vote; Pan-Malaysian Islamic
Party polled 24%; Democratic Action Party polled 12%; Gerakan 7%
Sabah: (October 1971 Assembly Elections) Alliance unopposed, opposition
candidates disqualified
Sarawak: (1970 elections) Alliance 24 seats, SNAP 12 seats, SUPP 11 seats;
SUPP has joined the Alliance to form a coalition state government
Member of: ADB, ASEAN, ASPAC, ‘Commonwealth, FAO, GATT, IAEA, IBRD, ICAO, IFC,
ILO, IMF, ITU, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Maldives
Type: republic
Capital: Male
Political subdivisions: 19 administrative areas broken down by clusters of atolls
Legal system; based on Islamic law with admixtures of English common law primari-
ly in commercial matters; has not accepted compulsory ICJ jurisdiction
Branches: popularly elected unicameral national legislature (Majlis) (members
elected for 5-year terms); elected President, chief executive; appointed
Chief Justice responsible for administration of Islamic law
Government leaders: President Ibrahim Nasir
Suffrage: universal over age 21
Political parties and leaders: no organized political parties; country governed
by the Didi clan for the past eight centuries
Member of: Colombo Plan, U.N.
Legal name: Republic of Mali
Type: republic; under military regime since November 1968
Capital: Bamako
Political subdivisions: 6 administrative regions; 42 administrative districts
(cercles), arrondissements , villages; all subordinate to central government
Legal system: based on French civil law system and customary law; constitution
adopted 1960, amended 1961; judicial review of legislative acts in Constitu-
tional Section of Court of State; has not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by Military Committee of National
Liberation (MCNL ) composed of 11 army officers; under MCNL functional
cabinet composed of civilians and army officers; judiciary
Government leaders: Col. Moussa Traore, president of MCNL, Chief of State. and
head of government
Suffrage: universal over age 21
Political parties and leaders: former Union Soudanaise-RDA dissolved and political
activity proscribed by military government
Elections: MCNL promises elections at unspecified date
Communists: there are a few Communists and a somewhat larger number of sympathizers ;
some are under detention by MCNL
Member of: EAMA, FAO, IAEA, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UPU, WHO, WMO
ba ECONOMY :
GDP: about $245 million (FY69), per capita about $50
Agricul ture: main crops -- millet, sorghum, rice, corn, peanuts ; cash crops --
peanuts, cotton, livestock
Fishing: exports $1,399,000 (1969); imports $6,000 (1969)
: Major industries: small local consumer goods and processing
Electric power: 22,500 kw. capacity (1970); 38 million kw.-hr. produced (1970),
7 kw.-hr. per capita
ou $30.2 million (f.o.b., 1970); livestock, peanuts, dried fish, cotton,
skins
Imports: $35.8 million (c.1.f., 1970); textiles, vehicles, petroleum products,
machinery, and sugar
Maloy rece partners: mostly with france zone and Western Europe; also with U.S.S.R.;
ina
Approved For R ie
or Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : eo ae alo Teac
Monetary conversion rate: since August 1969, 555.4 Mali francs=
Fiscal year: calendar year
Legal name: Malta
Type: independent state since September 1964, recognizing Elizabeth II as chief
of state
Capital: Valletta
Political subdivisions: 2 main populated islands, Malta and Gozo, divided into
10 electoral districts (divisions )
Legal system: based on English common law; constitution adopted 1961, came into
force 1964; has accepted compulsory ICJ jurisdication, with reservations
Branches: executive, consisting of prime minister and cabinet; legislative,
comprising 55-member House of Representatives ; independent judiciary
Government leader: Prime Minister Dom Mintoff
Suffrage: universal over age 21; registration required
Elections: at the discretion of the Prime Minister, but must be held before the
expiration of a 5-year electoral mandate; last election June 197%
Political parties and leaders: Nationalist Party, George Borg Olivier; Malta Labor
Party, Dom Mintoff
Voting strength (1971 election): Labor, 28 seats; Nationalist, 27 seats
Member of: Commonwealth, Council of Europe, FAO, GATT, ICAO, ILO, IMF, Seabeds
Committee, TDB, U.N., UNESCO, WHO
Legal name: Martinique
Type: overseas department of France; represented by 3 deputies in the French
National Assembly and 2 deputies in the Senate
Capital: Fort-de-France
Political subdivisions: 2 arrondissements; 34 communes, each with a locally
elected municipal council
Legal system: French civil law system; highest court is a court of appeal based
in Martinique with jurisdiction over Guadeloupe, Guiana, and Martinique
Branches: executive, Prefect appointed by Paris; legislative, popularly elected
council of 36 members; judicial, under jurisdiction of French judicial system
Government leader: Prefect Jean Terrade
Suffrage: universal over age 21
Political parties and leaders: Union of Democrats for the Republic (UDR), Emi]
Maurice; Progressive Party of Martinique (PPM), Aime Cesaire; Communist
Party of Martinique (PCM), Armand Nicolas; Democratic Union of Martinique,
Leon-Laurent Valere; Socialist Party, leader unknown; Federation of the
Left, leader unknown
Voting strength: UDR, 2 seats in French National Assembly; PPM, 1 seat (1968
siactiony
Communists: 2,000, 10,000 sympathizers
Other political or pressure groups: Organization of the Anti-colonialist
Martinique Youth (QJAM), Proletarian Action Group (GAP)
Legal name: Islamic Republic of Mauritania
Type: republic; one-party presidential rule since 1960
Capital: Nouakchott
Political subdivisions: 7 regions and a capital administration
Legal system: based on French civil law system and Islamic law; constitution
adopted 1961; judicial review of legislative acts in the Supreme Court;
has not accepted compulsory ICJ jurisdiction
Branches: president; unicameral National Assembly of 50 elected members;
separate judiciary (appointed by president
Government leader: President Moktar Ould Daddah
Suffrage: universal for adults
Elections: presidential and parliamentary election every 5 years; most recent
August 1971
Political parties and leaders: Mauritanian People''s Party is only legal party,
Secretary General Moktar Ould Daddah
Communists: no Communist Party; sympathizers exist, particularly for Chinese
Communists
Member of: EAMA, FAO, ICAO, ILO, IMCO, ITU, OAU, Organization of Riparian States
of the Senegal River (OQERS), Seabeds Committee, U.N., UNESCO, WHO, WMO
Legal name: Mauritius
Type: independent state since 1968, recognizing Elizabeth II
as chief of state
Capital: Port Louis
Political subdivisions: 5 “organized municipalities" and various island
dependencies
Legal system: based on French civil law system with elements of English common
Taw in certain areas; constitution adopted 6 March 1968
Branches: executive power exercised by Prime Minister and 15-man Council of
Ministers; unicameral legislature (National Assembly) with 62 members elected
by direct suffrage and 8 specially elected
Government leader: Prime Minister Dr. S. Ramgoolam
Suffrage: universal over age 21
Elections: last held in August 1967; next scheduled in 1972 postponed at least
A years by constitutional amendment
Political parties and ledders: a loose government coalition consisting of Labor
Party (S. Ramgoolam), Muslim Committee of Action (A. R. Mohamed), and Parti
Mauricien Social Democrate (G. Duval); Independent Forward Bloc (S.
Bissoondoyal); Mauritius Democratic Union (M. Lesage); a few independents ;
Mouvement Militant Mauritian (P. Berenger)
Voting strength: Muslim Committee of Action, 6 seats; Independent Forward Bloc,
7 seats; Mauritius Labor Party, 32 seats; Mauritius Democratic Union, 12 seats;
Parti Mauricien Social Democrate, 10 seats; independent 2 seats; Mouvement
Militant Mauritian 1 seat
Communists: may be 2,000 sympathizers ; several Communist organizations; Mauritius
Lenin Youth Organization, Mauritius Women''s Committee, Mauritius Communist
Party, Mauritius People''s Progressive Party, Mauritius Young Communist League,
Mauritius Liberation Front, Chinese Middle School Friendly Association,
Mauritius/USSR Friendship Society
Other political or pressure groups: Tamil United Party, Mauritius Workers Party
Member of: Commonwealth, OAU, CAM, U.N.
215
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-0 -
GNP: est. $157 million (1969), approximately $200 per Oia ae .
Agriculture: sugar crop is major economic asset; about 40% of land area is planted
to sugar;. tea production rising slowly; most food imported -- rice is the
staple food -- and since cultivation is already intense and expansion of
cultivable areas is unlikely, heavy reliance on food imports except sugar
and tea will continue
Shortage: land
Industries: mainly confined to processing sugarcane, tea; some small-scale,
simple manufactures; tobacco fiber; some fishing; tourism, diamond cutting,
weaving and textiles
Electric power: 61,340 kw. capacity (1970); 134 million kw.-hr. produced (1970),
160 kw.-hr. per capita
Exports: $66.1 million (f.o.b., 1969); 33% foodstuffs (rice, wheat, flour,
meat, fruit); manufactured goods, machinery, chemicals, fuels
Imports: $59.2 million (1969); foodstuffs 40%, manufactured goods 18%
Major trade partners: U.K. has preferential treatment, buys over 50% of Mauritius’
sugar export at heavily subsidized prices; small amount of sugar exported to
Canada, U.S., and Italy; imports from U.K. and EC primarily, also from South
Africa, Australia, and Burma; some minor trade with China
Aid: U.K. financed 40% of 1960-66 development programs with loans and grants
totaling $33 million; U.K.''s sugar subsidies amount to approx. $30 million
annually; U.S. $4.1 million since 1967 (P.L. 480); Soviet Union made some
small-scale offers in 1969
Monetary conversion rate: 5.55 Mauritian rupees=US$1
Fiscal year: 1 July - 30 June
Legal name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Political subdivisions: 4 sections
Legal system: based on French law; new constitution adopted 1962; has not
accepted compulsory ICJ jurisdiction
Branches: National Council (18 members); Communal Council (15 members, headed
by a mayor)
Government leader: Prince Rainier III
Suffrage: universal
Elections: National Council every 5 years; most recent 1968
Political parties and leaders: Nati','77a02f030c7725521f2a38fac93ac2210d788507c65d810b248a94a8f82e56ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a12acfd7dcd89ae51458dffcff05a11b8f500f42ceaecaf586f0c33e061d0578',1971,'NO','Norway','government',35,'onal Union of Independents, National Democratic
Entente (1965)
Voting strength: figures for 1968 election not available; (1958) 61% National
Union of Independents, 39% National Democratic Entente
Communists: not available
Member of:. IAEA, IHB, ITU, U.N., UNESCO, UPU, WHO
Legal name: Mongolian People''s Republic
Type: Communist state
Capital: Ulaanbaatar
Political subdivisions: 18 provinces and 2 autonomous municipalities (Ulaanbaatar
and Darhan)
Legal system: blend of Russian, Chinese, and Turkish systems of law; constitution
adopted 1940; no constitutional provision for judicial review of legislative
acts; legal education at Ulaanbaatar State University; has not accepted
compulsory ICJ jurisdiction
Branches: constitution provides for a Great People''s Hural (national assembly)
and a highly centralized administration
Party and government leader: Y. Tsedenbal, First Secretary of the MPRP and
Chairman of the Council of Ministers
Suffrage: universal; age 18 and over
Elections: national assembly elections held in June 1969; next elections
scheduled for 1972
Political party: Mongolian People''s Revolutionary (Communist) Party (MPRP) ;
estimated membership, 48,500 (less than 5% of the population)
Member of: CEMA, ECAFE, U.N., WHO
Legal name: Kingdom of Morocco
Type: constitutional monarchy (constitution adopted 1970)
Capital: Rabat
Political subdivisions: 19 provinces and 2 prefectures
Legal system: based on Islamic law and French and Spanish civil law system;
judicial review of legislative acts in Constitutional Chamber of Supreme
Court; modern legal education at branches of Mohamed V University in Rabat
and Casablanca and Karaouine University in Fes; has not accepted compulsory
ICJ jurisdiction
Branches: constitution provides for Prime Minister and ministers named by and
responsible to King; King has paramount executive powers; unicameral
legislature; judiciary independent of other branches
Government leaders: King Hassan II; Prime Minister Mohamed Karim-Lamrani
Suffrage: universal over age 20
Elections: 150 members of parliament indirectly elected on 21 August 1970 and
remaining 90 directly elected on 28 August 1970
Political parties and leaders: Istiqlal Party, Allal el-Fassi; Popular Movement
(MP), Mahjoubi Aherdan; Constitutional and Democratic Popular Movement
(MPCD), Dr. Abdelkrim Khatib; National Union of Popular Forces (UNFP),
collegial leadership of Abderrahim Bouabid, Abdallah Ibrahim, and Mahjoub
Ben Seddik; Democratic Socialist Party (PSD), Ahmed Reda Guedira; Party for
Liberation and Socialism (PLS), established in June 1968 and banned September
1969, is front for Moroccan Communist Party (MCP), which was proscribed in
1959, Ali Yata; Istiqlal and the UNFP formed a National Front in July 1970
to oppose the new constitution, boycotted the parliamentary elections
Voting strength: (1970 election) not yet available; new parliament is composed
of 158 Independents, 60 Popular Movement, 9 Istiqial, 2 UNFP, 11 other
Communists: 300 est.
Member of: Arab League, EC (association until 1974), FAO, IAEA, IBRD, ICAO, IDA,
ILO, IMC, IMCO, IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO
223
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Agriculture: cereals farming and livestock raising predominate; main crops --
cereals, citrus fruit, wine, truck garden produce, olives
Major industries: mining and mineral processing, food processing, textiles
Electric power: 748,300 kw. capacity (1970); 1,850 million kw.-hr. produced
(1970), 115 kw.-hr. per capita
Monetary conversion rate: 5.06 dirhams=US$1 (IMF par value)
Fiscal year: calendar year
Legal name: Province of Mozambique
Type: overseas province of Portugal
Capital: Lourenco Marques
Political subdivisions: province divided into 10 districts administered by
district governors; municipalities governed by appointed official
Legal system: based on Portuguese civil law system and customary law .
Branches: Governor General appointed by Lisbon is chief executive officer for
internal administration; he also has certain legislative powers which he
exercises with a legislative council; all action in province may be vetoed
by Minister of Overseas in Lisbon; judiciary is constitutionally independent
Government leader: Governor General Manuel Pimentel dos Santos
Suffrage: all adults able to read and write Portuguese and in full possession of
political and civil rights
Political parties and leaders: National Popular Action (ANP), formerly the
National Union (UN), provincial president Manuel Montiero Ribeiro Jeloso; no
legal opposition political parties
Other political or pressure groups: the National Liberation Front (FRELIMO), led
by Moises Samora Machel, operates primarily from Tanzania; Revolutionary
: Committee (COREMO), led by Paulo Gumane, based in Zambia','6db313a820ca1d8111b4331bdb8438ea98828ec605700e39f38502593cb1c4d9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c80c1768d77de0c13bcd1af62842aa1660a87b9629c5f28c0337c1e3dccc590',1971,'AU','Australia','government',38,'Legal name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se; government offices in Uaboe District
Political subdivisions: 14 districts
Branches: President elected from and by Parliament for an unfixed term; popularly
elected unicameral legislature, the Parliament; Cabinet to assist the
President, four members, appointed by President from Parliament members
Government leader: President Hammer Ve Roburt
Suffrage: universal adult
Political parties and leaders: De Roburt is only significant political figure;
has almost universal support of Nauruans
Member of: no present plans to join U.N. or other international agencies; enjoys
"special membership" in Commonweal th
Legal name: Kingdom of Nepal
Type: constitutional monarchy; King Mahendra exercises autocratic control over
multitiered panchayat system of government
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and English common law; legal
education at Nepal Law College in Kathmandu; has not accepted compulsory
ICJ jurisdiction
Branches: Council of Ministers appointed by the King; indirectly elected
National Panchayat (Assembly)
Government leader: King Mahendra Bir Bikram Shah Deva; Prime Minister Kirti Nidhi
Bista
Suffrage: universal over age 2]
Elections: village and town councils (panchayats) elected by universal suffrage;
district, zonal, and National Panchayat members indirectly elected, most
for 6-year terms; 15 National Panchayat members elected from five class
organizations (women, workers, youth, and ex-servicemen), four directly
elected by all voters possessing a B.A. or its equivalent, and 16 are
appointed by the King
Political parties and leaders: all political parties outlawed
Member of: ADB, FAO, IBRD, ICAO, IDA, ILO, IMF, ITU, U.N., UNESCO, UPU, WHO
Legal name: Kingdom of the Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government resides at The Hague
Political subdivisions: 1]1-provinces governed by centrally appointed commissioners
of Queen
Legal system: civil law system incorporating French penal theory; constitution
of 1815 frequently amended, reissued 1947; judicial review in the Supreme
Court of legislation of lower order than Acts of Parliament; legal education
at six law schools; accepts compulsory ICJ jurisdiction, with reservations
Branches: executive, (Queen and Cabinet of Ministers), which is responsible to
bicameral states general (parliament); independent judiciary
Government leader: Barend Willem Biesheuvel, Prime Minister
Suffrage: universal over age 21
Elections: must be held at least every 4 years for lower house (most recent
April 1971), and every 3 years for upper house (most recent April 1971)
Political parties and leaders: Catholic People''s Party (KVP), A.P. van der Stee;
Antirevolutionary (ARP), A. Veerman; Labor (PydA), Andre van der Louw; Liberal
(VVD), Mrs. H. van Someren-Downer; Christian Historical Union (CHU),
Prof. J. W. van Hulst; Democrats ''66 (D-66), J. Beekmans ; Communist (CPN),
Henk Hoekstra; Pacifist Socialist (PSP), H. Wiebenga; Political Reformed
(SGP), H. G. Abma; Reformed Political Union (GVP), W. G. Beeftink; Radical
Party (PPR), J. Tonnaer; Democratic Socialist ''70 (DS-70), Dr. Wilhelm
Dress, Jr.
Voting strength (1971 election): 21.9% KVP, 10.3% VD, 8.6% ARP, 6.3% CHU, 24.6%
PvdA, 6.8% D-66, 5.3% DS-70, 3.9% CPN, 1.4% PSP, 1.8% PRP, 2.4% SGP, 1.6% GVP
Communists: 10,200 members; 246,328 votes in 1971 election
Member of: Benelux, Council of Europe, ECE, ECSC, EC, EMA, EURATOM, FAQ, IAEA,
IBRD, ICAO, IHB, NATO, OECD, Seabeds Committee (observer), U.N., UNESCO, WEU,
WHO
231
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $31.3 billion (1970), $2,410 per capita (based on 1970 population); 56%
consumption, 29% investment, 16% government, -1% net exports of goods and
services; 1970 growth rate 5.9%, in 1963 constant prices
Agriculture: animal husbandry predominates; main crops -- horticultural crops,
grains, potatoes, sugar beets; food shortages -- grains, fats, oils; caloric
intake, 3,030 calories per day per capita (1967-68)
Fishing: catch 323,100 metric tons, $66,938,000 (1969); exports $94,542,000
(1969), imports $82,531,000 (1969)
Major industries: food processing, metal and engineering products, electrical and
electronic machinery and equipment, chemicals, and petroleum products
Shortages: crude petroleum, raw cotton, base metals and ores, pulp, pulpwood,
lumber, feedgrains, and oilseeds
Crude steel: 5 million metric tons produced (1970), 383 kilograms per capita
Electric power: 10,682,000 kw. capacity (1970); 38.7 billion kw.-hr. produced
(1970), 2,869 kw.-hr. per capita
Exports: $11,772 million (f.o.b., 1970); foodstuffs, machinery, transportation
equipment, consumer manufactures, chemicals, petroleum products, textiles
Imports: $13,392 million (c.i.f., 1970); machinery, transportation equipment,
consumer manufactures, crude petroleum, foodstuffs, chemicals, raw cotton,
base metals and ores, pulp
Major trade partners: (1970) 58.7% EC, 29.7% W. Germany, 15.5% Belgium-
Luxembourg, 8.7% France, 12.9% EFTA, 6.3% U.K., 7.2% U.S., 1.7% Eastern
Europe
Aid:
economic -- (received) U.S., $1,279 million authorized (FY46-69); none
since FY58; IBRD, $236 million authorized (FY46-58), none since 1958;
military -- (received) U.S., $1,241 million authorized (FY46-68), none since
FY67; net official aid given to less developed areas and multilateral
agencies -- $1,005 million (FY60-70), $200 million (FY70)
Monetary conversion rate: 3.62 guilders=US$1 (official IMF rate); actual rate
3.36 guilders=US$1 (30 September 1971)
Fiscal year: calendar year
Legal name: Papua New Guinea
Type: dependent territory under Administrator appointed by Australia
Capital: Port Moresby
Political subdivisions: 18 administrative districts (12 in New Guinea, 6 in Papua) ;
New Guinea (including Bismarck archipelago and Bougainville) is a U.N. Trust
Territory
Legal system: based on English common law; highest judicial organ is High Court
of Australia
Branches: executive -- Administrator and Executive Council; legislature --
House of Assembly (94 members, including 10 appointed); judiciary -- court
system consists of Supreme Court of Papua New Guinea and various inferior
courts (District Courts, Local Courts, Children''s Courts, Wardens'' Courts);
Supreme Court decisions may be appealed to High Court of Australia
Government leader: Administrator, L. W. Johnson
Elections: preferential-type elections for 84 members of 94-member House of
Assembly every 4 years; 10 are appointed "official" members; last elections
in February-March 1968
Political parties: proindependence Pangu Pati is principal political group; 5 or
6 other small parties and numerous independents
Suffrage: universal adult suffrage
Voting strength (1968 election): 1.18 million registered voters, of which an
estimated 65% to 75% voted; Pangu Pati and pro-Pangu Pati sympathizers won
91-26 assembly seats, minor parties and independents won remainder
Communists: no significant strength
Legal name: Kingdom of Tonga
Type: constitutional monarchy
Capital: Nukualofa
Political subdivisions: 3 main island groups (Tongatapu, Haapi, Vavau )
Legal system: based on English law
Branches: Executive (King and Privy Council); Legislative (Legislative Assembly
composed of 7 nobles elected by their peers, 7 elected representatives of
the people, 7 Ministers of the Crown; the King appoints one of the 7 nobles
to ae speaker); Judiciary (Supreme Court, magistrate courts, Land
Court
Government leaders: King Taufa''ahau Tupou IV; Premier, Prince Tu''ipelehake
(younger brother of the King)
Suffrage: granted to all literate adults over 21 years of age who pay taxes
Elections: held triennially
Communists: none known
Member of: Commonwealth
Legal name: Trinidad and Tobago
Type: independent state since August 1962; recognizes Elizabeth II as chief
of state
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards, Tobago is 30th)
Legal system: based on English common law; constitution came into effect
1962; judicial review of legislative acts in the Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: legislative branch consists of 36-member elected House of
Representatives and 24-member Senate (13 nominated by Prime Minister,
4 by opposition leader, 7 at discretion of Governor General); executive is
cabinet led by the Prime Minister; judiciary is Supreme Court
Government leader: Prime Minister, Dr. Eric Williams
Suffrage: universal over age 21
Elections: last election 24 May 1971, PNIM won all seats (constitutionality of
situation is under review)
Political parties and leaders: People''s National Movement (PNM), Dr. Eric
Williams; Democratic Labor Party (DLP), Vernon Jamadar; Democratic Liberation
Party (DLIBP), Bhadase Sagan Maraj; United National Independence Party, James
Millette; Democratic Action Congress (DAG), Arthur Napoleon Raymond Robinson
Voting strength (1971 election): 32.9% of registered voters cast ballots, 83.7%
PNM, 16.3% other
Communists: not significant
Other political pressure groups: Tapia House Group (headed by Lloyd Best);
National Youth Congress (NYC); Oilfield Workers Trade Union (OWTU), pro-
Marxist leadership; National Joint Action Committee (NJAC), antigovernment,
extremist organization; United Revolutionary Organization (URO), Marxist-led
amalgam
Member of: CARIFTA, Commonwealth, GATT, IBRD, ICAO, IDB, IMF, OAS, Seabeds
Committee, U.N.
337
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GDP: $858.5 million (1970 est.), $820 per capita; real growth rate 1970, 1.9% est.
Agriculture: main crops -- sugarcane, cocoa, coffee, rice, citrus, bananas;
largely dependent upon imports of food
Fishing: catch 4,000 metric tons (1969); exports $1.5 million (1969),
imports $2.3 million (1969)
Major industries: petroleum, tourism, food processing, cement
Electric power: 285,000 kw. capacity (1969); 1.21 billion kw.-hr. produced (1969),
1,170 kw.-hr. per capita
Exports: $482 million (f.o.b., 1970 est.); petroleum and petroleum products,
sugar, cocoa
Imports: $544 million (c.i.f., 1970 est.); crude petroleum, machinery,
transportation equipment, manufactured goods, food
Major trade partners: exports -- U.S. 46%, U.K. 10%, CARIFTA 10%; imports --
Venezuela and Colombia 25%, U.S. 16%, U.K. 13%, CARIFTA 2% (1970)
Aid: economic -- extensions from U.S. (FY56-70) $22.7 million loans, $40.1
million grants; from international organizations (FY53-70), $60.2 million
Monetary conversion rate: TT$1.93=US$1 (6 October 1971)
Fiscal year: calendar year
Legal name: Trucial States (7 amirates )
Type: ruled by traditional leading families, each headed by a sheikh
Legal system: based on Islamic law with ultimate appeal to the Sheikh; some
secular and civil codes being introduced
States and rulers: Abu Dhabi, Zayid ibn Sultan; Ajman, Rashid ibn Humayd;
Dubai, Rashid ibn Sa''id; Fujairah, Muhammad ibn Hamad; Ras al Khaimah,
Saqr ibn Muhammad; Sharjah, Khalid ibn Muhammad; Umm al Qaiwain, Ahmad
ibn Rashid
Legal name: Republic of Tunisia
Type: republic
Capital: Tunis
Political subdivisions: 13 governorates (provinces )
Legal system: based on French civil law system and Islamic law; constitution
patterned on Turkish and U.S. constitutions adopted 1959; some judicial
review of legislative acts in the Supreme Court in joint session; legal
education at Institute of Higher Studies and Ecole Superieure de Droit in
Tunis; has not accepted compulsory [CJ jurisdiction
Branches: executive dominant; unicameral legislative largely advisory; judicial,
patterned on French system and Koranic law
Government leader: President Habib Bourguiba; Prime Minister Hedi Nouira
Suffrage: universal over age 21
Elections: national elections held every 5 years; last elections 2 November 1969
Political party and leader: Destourian Socialist Party, Habib Bourguiba
Voting strength (1969 election): 100% Destourian Socialist Party
Communists: 100 est.; a few sympathizers; Tunisian Communist Party proscribed in
1962
Member of: Arab League, EC (association until 1974), FAO, IAEA, IBRD, ICAO, IDA,
IFC, ILO, IMCO, IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO, UPU,
WHO, WMO
Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Cevdet Sunay, Prime Minister Nihat Erim
Suffrage: universal over age 21
Elections: National Assembly (1973); Presidential (1973)
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party (RPP), Ismet Inonu; Democrats Party (DP), Ferruh Bozbeyli;
Reliance Party (RP), Turhan Feyzioglu; New Turkey Party (NTP), Yusuf Azizoglu;
Nationalist Movement Party (NMP), Alparslan Turkes; Nation Party (NP), Osman
Bolukbasi; Unity Party (UP), Mustafa Timisi; Communist Party illegal
Voting strength: 1969 National Assembly elections -- 46.6% JP, 27.5% RPP, 3.3%
NP, 2.2% NTP, 2.6% TLP, 5.7% independent, 6.4% RP, 3.1% NMP, 2.5% UP; 1968
Senatorial elections (1/3 of Senate seats) -- 49.9% JP, 27.1% RPP, 6.0% NP,
8.5% RP, 4.7% TLP, 2.0% RPNP
Communists: strength and support negligible
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECD, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO
343
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $9,834 million (1970), about $280 per capita; 5.7% average annual real
growth 1970
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2,172,000 kw. capacity (1970); 7,897 million kw.-hr. produced
(1970), 218 kw.-hr. per capita
Exports: $588.5 million (f.o.b., 1970); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $447.7 million (c.i.f., 1970); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals |
Major trade partners: EC 37.3%, EFTA 18.1%, North America 16.9%, Communist
countries 13.8% (1969)
Monetary conversion rate: 9 Turkish liras=US$1 (export rate); 9.08 Turkish
ee (import rate); both controlled; 15 Turkish liras=US$1 (tourist
rate
Fiscal year: 1 March - 28 February
Legal name: Republic of Uganda
Type: republic independent since October 1962
Capital: Kampala
Political subdivisions: 20 districts
Legal system: based on English common law and customary law; constitution
adopted 1967; judicial review of legislative acts; legal education at
Makerere University, Kampala; accepts compulsory ICJ jurisdiction, with
reservations
Branches: Gen. Amin rules by decree; assisted by Council of Ministers and Defense
Council, a group of military officers
Government leader: Gen. Idi Amin, President
Suffrage: universal adult
Elections: none scheduled by military government
Political party and leader: Uganda People''s Congress (UPC), principal party
before 1971 coup, not banned but inactive
Communists: possibly a few sympathizers
Member of: Commonwealth, EAC, IAEA, ICAO, ILO, OAU, U.N., UNESCO, WHO
Legal name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow
Political subdivisions: 15 union republics, 20 autonomous republics, 6 krays,
114 oblasts, and 8 autonomous oblasts
Legal system: civil law system as modified by Communist legal theory; consitution
adopted 1936; no judicial review of legislative acts; legal education at 18
universities and 4 law institutes; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers (executive), Supreme Soviet (legislative), Supreme
Court of U.S.S.R. (judicial)
Government. leaders: Leonid I. Brezhnev, General Secretary of the Central Committee
of the Communist Party; Aleksey N. Kosygin, Chairman of the Council of
Ministers; Nikolay V. Podgornyy, Chairman of the Presidium of the U.S.S.R.
Supreme Soviet
Suffrage: universal over age 18; direct, equal
Elections: to Supreme Soviet every 4 years; 1,517 deputies elected in 1970;
72.3% party members
Political parties and leaders: Communist Party of the Soviet Union (CPSU) only
party permitted
Voting strength (1970 election): 153,237,112 persons over 18; claimed 99.96%
voted
Communists: nearly 14,500,000 party members
,Other political or pressure groups: Komsomol, trade unions, and other organizations
which facilitate Communist control
Member of: CEMA, IAEA, ICAO ILO, IMCO, ITU, Seabeds Committee (observer), U.N.,
UNESCO, UPU, Warsaw Pact, WHO, WMO
Legal name: Republic of Upper Volta
Type: republic; transitional military regime in power since January 1966, wil]
rule until 1974
Capital: Ouagadougou
Political subdivisions: 5 departments consisting of 44 cercles
Legal system: based on French civil law system and customary law; constitution
adopted 1970; judicial review of legislative acts in Supreme Court; has not
accepted compulsory ICd jurisdiction
Branches: President is an army officer; 57-man National Assembly was elected in
December 1970; 4 year transition period will follow during which President
will rule over 15-man cabinet, one-third of which will be military; separate
judiciary
Government leader: President Gen. Sangoule Lamizana
Suffrage: universal for adults
Elections: National Assembly elections were in late December 1970; RDA-UDY won
37 seats, PRA 12, MLN 6; Prime Minister Gerard Kango Ouedraogo; of voters
officially reported as approving unopposed candidates of former Yameogo
regime
Political parties and leaders: 7 legally recognized parties; Voltan Democratic
Union-African Democratic Rally (UDV-RDA), Gerard Kango Ouedraogo; African
Regroupment Party (PRA), Diongolo Traore; Movement for National Liberation
(MLN); People''s Action Group (GAP), Nohoun Sigue; Union for the New Voltaic
Republic (UNR), Blaise Bassoleth; Party of National Regroupment (PRN),
Francois Bassolet; Party of Voltan Workers (PTV), George Kabore
Communists: possibly some Communists and sympathizers
Other political or pressure groups: labor organizations are badly splintered
Member of: EAMA, ENTENTE, FAQ, ICAO, ILO, ‘ITU, OAU, OCAM, U.N., UNESCO, WHO, WMO
Legal name: Oriental Republic of Uruguay
Type: republic
Capital: Montevideo
Political subdivisions: 19 departments with limited autonomy
Legal system: based on Spanish civil law system; new constitution implemented
1967; judicial review of legislative acts in Supreme Court, legal education
at University of the Republic at Montevideo; accepts compulsory ICJ
jurisdiction
Branches: executive, headed by President; bicameral legislature (30 Senators
plus Vice President who presides and has voice and vote, and 99-member
Chamber of Deputies) elected by popular vote under a complicated system
using proportional representation; national judiciary headed by Supreme
Court
Government leader: President Jorge Pacheco Areco
Suffrage: universal over age 18
Elections: every 5 years; next in 197]
Political parties and leaders: National (Blanco) Party, President of Party
Directorate Alberto Heber Usher, main factions include Martin Echegoyen''s
"Alianza" faction, List 400 (Washington Beltran), Rocha Movement (Alberto
Gallinal), Orthodox Herreristas (Alberto Heber Usher), and Por La Patria
(Wilson Ferreira Aldunate); Colorado Party, main factions include Colorado
and Batllista Union (Jorge Pacheco Areco), List 15 (Jorge Batlle), List 315
(Amilcar Vasconcellos); Broad Front (Frente Amplio), leftwing coalition of
Leftist Liberation Front (FIDEL), Communist Front and dissident factions from
both the Blanco and Colorado parties, and including FIDEL, the Christian
Democrats, and other splinter groups
Voting strength (1966 elections): 49.3% Colorado, 40.3% Blanco, 5.7% FIDEL,
3% Christian Democrat, 0.9% Socialists, 0.8% other
Other political or pressure groups: Conmunist Party (PCU), Rodney Arismendi;
Christian Democratic Party (PDC); Socialist Party of Uruguay (PSU); Revolutionary
Movement of Uruguay (MRO) pro-Cuban Communist Party; National Liberation
Movement (MLN-Tupamaros) Marxist Revolutionary terrorist group
Member of: IADB, IAEA, IBRD, ICAO, ILO, IMF, LAFTA, OAS, U.N.
353
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $3.2 billion (purchasing power parity estimate, 1970); $1,110 per capita;
74% private consumption, 12% public consumption, 14% gross investment (1969);
real growth rate 1970, 4.4%
Agriculture: large areas devoted to extensive livestock grazing (22 million
sheep, 8 million cattle); main crops -- wheat, rice, corn; self-sufficient
in most basic foodstuffs; caloric intake, 3,000 calories per day per capita,
with high protein content
Major industries: meat processing, wool and hides, textiles, footwear, cement,
petroleum refining
Crude steel: 24,000 metric tons produced (1966), 10 kilograms per capita
Electric power: 575,000 kw. capacity (1970 est.); 2.1 billion kw.-hr. produced
(1970 est.), 724 kw.-hr. per capita
Exports: $233 million (f.o.b., 1970); beef, wool, hides
Imports: $231 million (c.i.f.; 1970); fuels, metals, machinery, transportation
equipment
Major trade partners: exports -- EC 27%, U.K. 25%, U.S. 12%, LAFTA 11%;
imports -- LAFTA 26%, U.S. 22%, U.K. 14%, EC 13% (1968)
Aid:
economic -- extensions from U.S. (FY46-70), loans $115.5 million, grants
$21.6 million; from international organizations, IBRD $108.5 million, IDB
$67.2 million, U.N. $9.4 million; $6 million credit from East Germany (1966),
$10 million credit from Hungary (1967), $20 million credit from U.S.S.R.
(1969), $5 million credit from Czechoslovakia (1970), $.4 million credit from
Bulgaria (1969); military -- U.S., grants $42.4 million (FY46-70), $.3 million
credits
Monetary conversion rate: 250 pesos=US$1 (official)
Fiscal year: calendar year
Legal name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes St. Peter''s, the Vatican Palace
and Museum and neighboring buildings covering more than 13 acres; 13
buildings in Rome, although outside the boundaries, enjoy extraterritorial
rights
Legal system: Canon law; constitutional laws of 1929 serve some of the functions
of a constitution
Branches: the Pope possesses full executive, legislative, and judicial powers;
he delegates these powers to the governor of Vatican City, who is subject
to pontifical appointment and recall; high Vatican offices include the
Secretariat of State, the College of Cardinals (chief papal advisers), the
Roman Curia (which','175a0f618581c27690c335b5ab7a03c8e8704ab9ace87d6212f7f3e8c95b2145','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('640fd9e54ad7c3e48079f19d842e355a1658054d9459550f50e076d7ad1f97af',1971,'AU','Australia','government',39,'carries on the central administration of the Roman
Catholic Church) the Presidence of the Prefecture for the Economy, and
the synod of bishops (created in 1965)
Government leader: Supreme Pontiff, Paul VI, (Giovanni Battista Montini, born
26 September 1897, elected Pope 21 June 1963)
Suffrage: limited to cardinals
Elections: Supreme Pontiff elected for life by College of Cardinals
Communists: none known
Other political parties and pressure groups: none (exclusive of influence
exercised by other church officers in universal Roman Catholic Church)
Member: IAEA
Legal name: Republic of Venezuela
Type: republic
Capital: Caracas
Political subdivisions: 20 states, ]1 federal district, 2 federal territories
Legal system: based on Spanish civil law system with influence of U.S. law;
constitution promulgated 1961; judicial review of legislative acts in
Cassation Court only; dual court system, state and federal; legal education
at Central University of Venezuela; has not accepted compulsory ICJ
jurisdiction
Branches: executive (President), bicameral legislature, judiciary
Government leader: President Rafael Caldera
Suffrage: universal and compulsory over age 18
Elections: every 5 years; most recent December 1968
Political parties and leaders: Accion Democratica (AD), Romulo Betancourt, Paul
* Leoni, Gonzalo Barrios; Comite por Organizacion Politica y Electoral
Independiente (COPEI), known as Social Christian party, Rafael Caldera; People''s
Electoral Movement (MEP), Luis Beltran Prieto; Cruzada Civica Nacionalista
(CCN), Marcos Perez Jimenez, leader, and Luis Damiani, president; Union
Republicana Democratica (URD), Jovito Villalba; Partido Comunista de Venezuela
(PCV), Secretary-General Jesus Faria; Movimiento de la Izquierd Revolucionaria
(MIR), political activities suspended by government, Moises Moliero; Fuerza
Democratica Popular (FDP), Jorge Dager; Frente Nacional Democratico (FND),
Pedro Segnini La Cruz; Partido Revolucionario Izquierdista Nacionalista
(PRIN), Domingo Alberto Rangel
Voting strength (1968 election): 25.6% AD, 24.1% COPEI, 10.9% CCN, 9.3% URD,
5.3% FDP, 2.8% Union for Advancement (Communist front), 2.6% FND, 2.3% PRIN
Member of: FAQ, IADB, IAEA, IBRD, ICAO, IDB, IFC, ILO, ITU, OAS, Seabeds Committee
(cbserver), U.N., UNESCO, UPU, WHO, WMO
357
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $11.4 billion (purchasing power parity estimate, 1970), $1,100 per capita;
64% private consumption, 14% public consumption, 22% gross investment (1969),
real growth rate 1970 est. 5 1/2%
Agriculture: main crops -- cotton, sugarcane, corn, coffee, rice; self-sufficient
in most basic foods; caloric intake 2,600 calories per day per capita (1964)
Fishing: catch 132,000 tons (1969), $25,228,000 (1969); exports $4,287,000 (1969),
imports $1.4 million (1969)
Major industries: petroleum, iron-ore mining, construction, food processing,
textiles
Crude steel: 923,000 metric tons produced (1970), 90 kilograms per capita
Electric power: 4.0 million kw. capacity (1970); 11.7 billion kw.-hr. produced
(1970), 1,130 kw.-hr. per capita
Exports: 2,600 million (f.o.b., 1970 est.); petroleum, iron ore, coffee, cocoa
Imports: $1,737 million (f.o.b., 1970 est.}; industrial machinery and equipment,
chemicals, manufactures, wheat
Major trade partners: U.S. 41%, Canada 9%, U.K. 5% (1969)
Aid:
economic -- extensions from U.S. (FY46-70), $345.9 million loans; $57.4
million grants; from international organizations (FY46-70), $517.0 million;
military -- assistance from U.S. (FY53-70), $105.8 million
Monetary conversion rate: 4.50 bolivares=US$1 (selling rate)
Fiscal year: calendar year
Legal name: Democratic People''s Republic of Viet-Nam
Type: Communist state
Capital: Hanoi
Political subdivisions: 9 autonomous regions (of 3 and 5 provinces, respectively)»
17 other provinces, 2 centrally governed municipalities, | special zone
Legal system: based on Communist legal theory and French civil law system;
constitution enacted 1960
Branches: constitution provides for a National Assembly and highly centralized
executive nominally subordinate to it ;
Party and government leaders: Le Duan, First Secretary; Ton Duc Thang, President
of DRV; Pham Van Dong, Premier; Truong Chinh, Chairman, Standing Committee
of National Assembly; Vo Nguyen Giap, Minister of National Defense
Suffrage: over age 18
Elections: pro forma elections held for national and local assemblies
Political parties: ruled by Lao Dong Party with no organized opposition;
membership approximately 900,000 (about 4% of population)
Member of: no international bodies
Legal name: Republic of Viet-Nam
Type: republic
Capital: Saigon
Political subdivisions: 4 regions (corresponding to 4 military regions), 1 special
region (corresponding to Capital Special Zone), divided into 44 provinces
and 11 autonomous municipalities
Legal system: based on French civil law system; legal education at Universities
of Saigon and Hue
Branches: constitution provides for modified presidential system with executive,
legislative, and judicial branches
Government leaders: President Nguyen Van Thieu; Vice President Tran Van Huong;
Prime Minister Tran Thien Khiem
Elections: senate elections scheduled for 1973; next presidential elections
scheduled for 1975
Political parties and leaders: numerous small parties reflecting an emphasis on
personal leadership rather than ideological content; parties supporting
government and opposition groups are fragmented and poorly organized; An
Quang Buddhists are the most important opposition group, while several
Catholic parties usually back the government; other significant parties
include two old-line political parties (Revolutionary Dai Viet and Vietnamese
Nationalist-VNQDD), the Progressive Nationalist Movement, and the labor
union-based Farmer-Worker Party; Hoa Hao and Cao Dai politico-religious sects
exert strong influence in local areas
Communists: The People''s Revolutionary Party operates through and within the
National Front for the Liberation of South Vietnam (NLF) and the Alliance of
National, Democratic, and Peace Forces (ANDPF), and the Provisional Revolu-
tionary Government (PRG) designed to rival the legal government
Member of: Colombo Plan, FAO, IAEA, ICAO, ILO, IMCO, ITU, U.N. (certain specialized
U.N. agencies and maintains observer team), UNESCO, UPU, WHO, WMO
361
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $2.0-2.5 billion (1970), $110-140 per capita; 1.4% average annual real growth
(1966-69)
Agriculture: main crops -- rice, rubber, peanuts, corn, sugarcane, sweet potatoes,
copra; major food imports -- rice, dairy products, sugar, wheat flour
Fishing: catch 577,450 metric tons (1970 est.); trade in fish and fish products
insignificant
Major industries: manufacturing on small scale, mainly light manufacturing and
processing of local agricultural and forest products; factories produce
textiles, beer, cigarettes, glass, tires, sugar, paper, cement, soft drinks;
there are also limited mining operations
Shortages: capital goods
Electric power: 560,000 kw. capacity (1970); 1.13 billion kw.-hr. produced (1970),
62 kw.-hr. per capita
Exports: $13 million (f.o.b., 1970); major commodities -- rubber, scrap metal,
duckfeathers
Imports: $850 million (c.i.f., 1970); major commodities -- machinery and trans-
portation equipment, rice, textile fabrics and yarn, petroleum products, base
metals and manufactures
Major trade partners: exports -- France, U.K., West Germany, Japan; imports --
U.S., Japan, Taiwan; no trade with Communist countries
Monetary conversion rate: official rate, 118 piasters=US$1 applies to most imports
of goods and government transfers; a second rate of 275 piasters=US$1 estab-
lished on October 5, 1970, applies to imports of luxury goods, exports of
goods, and invisible transactions such as purchases of piasters by American
personnel in South Vietnam, foreign investment, and profit remittances of
foreign firms; black-market rate of 396 piasters=US$1 during first quarter
197]
Fiscal year: calendar year
Legal name: The Independent State of Western Samoa
Type: constitutional monarchy under native chief; special treaty relationship
with New Zealand
Capital: Apia
Legal system: based on English common law and local customs; constitution came
into effect upon independence in 1962; judicial review of legislative acts
with respect to fundamental rights of the citizen; has not accepted
compulsory ICJ jurisdiction
Branches: Head of State and Executive Council; Legislative Assembly; Supreme
Court, Court of Appeal, Land and Titles Court, village courts
Government leaders: Head of State, Malietoa Tanumafili II; Prime Minister,
Tupua Tamasese Leaofi IV
Suffrage: 45 Samoan members of Legislative Assembly are elected by holders of
matai (heads of family) titles (about 5,000); 2 European members are elected
by universal adult suffrage
Elections: held triennially
Political parties and leaders: no clearly defined political party structure
Communists: unknown
Member of: ADB, Commonwealth, WHO
Legal name: People''s Democratic Republic of Yemen
Type: republic, but without constitution
Capital: Aden;.Madinat ash Sha''b, administrative capital
Political subdivisions: 6 provinces
Legal system: based on Islamic law (for personal matters) and English common
law (for commercial matters); highest judicial organ, Federal High Court,
interprets constitution and determines disputes between states
Branches: General Command of the National Front (NF) acts as legislature pending
adoption of a constitution; Presidential Council, cabinet
Government leaders: 5-man Presidential Council, Prime Minister Ali Nasir Muhammed
al-Hasani; NF Secretary General Abd Al-Fattah Ismail (the real government
strongman)
Political parties and leaders: National Front (NF), only legal party
Communists: few known
Member of: U.N.
Legal name: Yemen Arab Republic
Type: republic
Capital: San''a''
Political subdivisions: 8 provinces
Legal system: based on Turkish law, Islamic law, and local customary law; first
constitution promulgated December 1970; has not accepted compulsory ICJ
jurisdiction
Branches: President, Prime Minister, Republican Council, Consultative Council
Government leaders: President Abd al-Rahman 6iryani; Prime Minister Muhsin al-Ayni
Member of: Arab League, FAO, ICAQ, ITU, U.N., UNESCO, UPU, WHO','f71660429053f449e7df562d239c65049e01f7e9baee3d6a3cb94907047ebfd4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d69ef9e7b56d051944556a03ff03c252fce7faddd60cadc512116cffd22f0dfa',1971,'CO','Colombia','government',43,'Legal name: State of St. Lucia
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Castries
Political subdivisions: 14 parishes
Legal system: based on English common law; constitution of 1960; highest judicial
body is Court of Appeal of Leeward and Windward Islands
Government leaders: Premier John Compton; U.K. Governor Frederick Clarke
Suffrage: universal adult suffrage
Elections: every 5 years; most recent April 1969
Political parties and leaders: United Worker''s Party (UWP), John Compton; St..
Lucia Labor Party (SLP), Martin Jean Baptiste; St. Lucia Labor Party United
Front (LPUF) led by George Charles
Voting strength (1969 election): UWP won 6 of the 10 elected seats in Legislative
Council; SLP won 3 seats; LPUF won 1 seat
Communists: negligible
Member of: CARIFTA
Legal name: State of St. Vincent
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Kingstown
Political subdivisions: 10 local government authorities
Legal system: based on English common law; constitution of 1960; highest
judicial body is Court of Appeal of Leeward and Windward Islands
Government leader: Premier, R. Milton Cato; Administrator (U.K.) Rupert John
Suffrage: universal adult suffrage
Elections: every 5 years; most recent May 1967
Political parties and leaders: People''s Political Party (PPP), Ebenezer Joshua;
St. Vincent Labor Party (LP), R. Milton Cato
Voting strength (1967 election): LP won 6 seats to PPP''s 3 in the Legislative
Council
Communists: negligible
Member of: CARIFTA
Legal name: Republic of San Marino
Type: republic (dates from 4th century A.D.); in 1862 the Kingdom of Italy
concluded a treaty guaranteeing the independence of San Marino; although
legally sovereign, San Marino is vulnerable to pressure from the Italian
Capital: San Marino
Political subdivisions: San Marino is divided into 9 sections: Guaita, Fratta,
Serravalle, Domagnano, Acquaviva, Fiorentino, Montegiardino, Faetano,
Chiesanuova
Legal system: based on civil law system with Italian law influences; electoral
law of 1926 serves some of the functions of a constitution; has not accepted
compulsory ICJ jurisdiction
Branches: the Grand and General Council is the legislative body elected by popular
vote; its 60 members serve 5-year terms; Council in turn elects two Captains-
Regent who exercise executive power for term of 6 months, the Council of
State whose members head government administrative departments and the Council
of Twelve, the supreme judicial body; actual executive power is wielded by
the Secretary of State for Foreign Affairs and the Secretary of State for
Internal Affairs
Government leaders: Secretary of State for Foreign Affairs Federico Bigi
(Christian Democratic party); Secretary of State for Internal Affairs Gian
Luigi Berti (Christian Democratic party)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General Council required at least every
5 years; next elections 1974
Political parties and leaders: Christian Democratic party (DCS), Federico Bigi
Social Democratic Party (PSDIS), Alvaro Casali; Socialist Party (PSS), Gino
Giacomini, Domenico Forcellini; Communist Party (PCS), Umberto Barulli
Voting strength (1969 election): 45% DCS, 25% PCS, 18.3% PSDIS, 11.7% PSS
Communists: approx. 300 members (number of sympathizers cannot be determined);
PCS is technically autonomous but in fact closely tied to Italian Communist
Party (PCI); PCS-PSS coalition dominated San Marino Government until 1957;
PSS, unlike its Italian counterpart, remains securely allied with PCS
Other political parties and pressure groups: political parties influenced by
policies of their counterparts in Italy, but the two Socialist parties are
not united as in Italy
Member of: ICJ, International Institute for Unification of Private Law,
International Relief Union, IRC, UPU
Approved For Release 2004/08/31 *"Gia-RDP79-01051A000400010002-1
ooo,
Approved For Relea ‘
ECONOMY : se 2004/08/31 : CIR REPT o-oo teooosoneeoss
Principal economic activities of San Marino are farming, livestock raising, light
manufacturing, and tourism; the government''s total budget for FY71 is about
$12 million, with the largest share of revenue derived from the sale of
postage stamps throughout the world and from payments by the Italian
government in exchange for Italy''s monopoly in retailing tobacco, gasoline,
and a few other goods ; main problem is finding an additional $3 million to
finance badly needed water and electric power systems expansions
Agriculture: principal crops are wheat (average annual output about 4,400 metric:
tons/year) and grapes (average annual output about 700 metric tons/year) 3
other grains, fruits, vegetables, and animal feedstuffs are also grown;
livestock population numbers roughly 6,000 cows, oxen, and sheep; cheese
and hides are most important livestock products
Electric power: obtained from Italy
Manufacturing: consists mainly of cotton textile production at Serravalle, brick
and tile production at Dogane, cement production at Acquaviva, Dogane, and
Fiorentino, and pottery production at Borgo Maggiore; some tanned hides,
paper, Candy, baked goods, Moscato wine, and gold and silver souvenirs are
also produced
Foreign transactions: dominated by tourism; in summer months 20,000 to 30,000
foreigners visit San Marino every day; a number of hotels and restaurants
have been built in recent years to accommodate them; remittances from
Sanmarinese abroad also represent an important net foreign inflow; commodity
trade consists primarily of exchanging building stone, lime, wood, chestnuts,
wheat, wine, baked goods, hides, and ceramics for a wide variety of consumer
manufactures
Legal name: Kingdom of Saudi Arabia
Type: monarchy
Capital: Riyadh; foreign ministry and foreign diplomatic representatives located
in Juddah
Political subdivisions: 18 amirates
Legal system: largely based on Islamic law, several secular codes have been
introduced; commercial disputes handled by special committees; has not
accepted compulsory ICJ jurisdiction
Branches: King Faysal (Al Saud, Faysal ibn Abd al-Aziz) rules in consultation
with ruling family, Council of Ministers, and religious leaders
Government leader: King Faysal
Communists: negligible
Member of: Arab League, FAO, IAEA, IATA, IBRD, ICAO, IDA, IFC, IMF, ITU, OAPEC,
‘OPEC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Senegal
Type: republic; only one legal party since 1966
Capital: Dakar
Political subdivisions: 7 regions, each subdivided into 28 departments and 90
arrondissements
Legal system: based on French civil law system; laws dealing with marriage,
inheritance, succession, etc., based on Islamic law with elements of
traditional practices; constitution adopted 1960, revised 1963 and 1970;
judicial review of legislative acts in Supreme Court (which also audits
the government''s accounting office); legal education at University of Dakar;
has not accepted compulsory ICd jurisdiction
Branches: Government dominated by President who is assisted by Prime Minister,
appointed by President and subject to dismissal by President or censure by
National Assembly; 80-member National Assembly, elected for 5 years
(effective 1968); President elected for 5-year term (effective 1968) by
universal suffrage; judiciary headed by Supreme Court, with members appointed
© by President
Government leaders: Leopold Sedar Senghor, President; Abdou Diouf, Prime Minister
Suffrage: universal adult
Political parties and leaders: Union Progressiste Senegalaise (UPS), ruling
party led by President Leopold Senghor, has absorbed all major opposition
parties; illegal parties include Communist-backed Parti Africain
de 1''Independence (PAI), led by Majmout Diop, and Parti Communiste Senegalais
(PCS) a splinter group
Elections: single party (UPS) presidential and legislative elections held
February 1968
Communists: a few Communists and sympathizers; PAI is pro-Moscow; PCS is pro-Peking
Member of: EAMA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, OCAM, Organization
of Senegal River States (QERS), U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2004/08/31. &14-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Legal name: Colony of the Seychelles
Type: British crown colony
Capital: Victoria, Mahe Island
Legal system: based on English common law, French civil law system, and
customary law
Branches: Governor, Council of Ministers, Legislative Assembly
Government leader: Governor Sir Bruce Greatbatch
Suffrage: universal adult
Elections: November 1970
Political parties and leaders: Seychelles Democratic Party (SDP), James R.
Mancham, President; Seychelles Peoples United Party (SPUP), France
Albert Rene, President
Voting strength: SDP won 4 seats on Governing Council with 52.8% popular vote
in 1970 election; SPUP won 5 seats with 47.2% of votes
Communists: negligible
Other political or pressure groups: trade unions which are appendages of
political parties
Legal name: Republic of Sierra Leone
Type: republic under presidential regime since April 1971
Capital: Freetown ;
Political subdivisions: 3 provinces; divided into 12 districts with 146 chief-
doms, where paramount chief and council of elders constitute basic unit of
government; plus western area, which comprises Freetown and other coastal
areas of the former colony
Legal system: based on English law and customary laws indigenous to local
tribes; constitution adopted April 1970; highest court of appeal is the
Sierra Leone Court of Appeals; has not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by President; parliament consists of 78
members, 66 of whom are elected representatives and 12 paramount chiefs
representing tribal councils in provincial districts; independent judiciary
Government leader: Siaka Stevens, President, heads APC government composed
of members of his political party, and paramount chiefs
Elections: the maximum life of an elected parliament is 5 years, but it may be
dissolved earlier by the President; last election March 1967; President is
me elected by parliament for 5 year term; next presidential election 1976
Political parties and leaders: All People''s Congress (APC), headed by Stevens;
Sierra Leone People''s Party (SLPP) is the opposition party
Communists: no party, although there are a few Communists and a slightly larger
number of sympathizers
“ Member of: Commonwealth, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Singapore
Type: republic within Commonwealth since separation from Malaysia in August 1965
Capital: Singapore
Legal system: based on English common law; constitution based on preindependence
State of Singapore constitution; legal education at University of Singapore;
has not accepted compulsory ICJd jurisdiction
Branches: ceremonial President; executive power exercised by Prime Minister and
cabinet responsible to unitary legislature
Government leaders: President, Dr. Benjamin Sheares; Prime Minister, Lee Kuan Yew
Suffrage: universal over age 20; voting compulsory
Elections: normally every 5 years
Political parties and leaders: government -- People''s Action Party (PAP), Lee
Kuan Yew; opposition -- Barisan Sosialis Party (BSP), Dr. Lee Siew Choh;
Workers'' Party, J.B. Jeyaretnam, Communist Party illegal
Voting strength (1968 election): PAP returned unopposed in 51 of 58 constituencies ;
in remaining 7 constituencies PAP received 84% of vote, independents 9%;
worker''s Party 4%; BSP boycotted election
Member of: ASEAN, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, U.N., UNESCO, UPU, WHO,
WMO
Legal name: Somali Democratic Republic
Type: republic; under military rule since October 1969
Capital: Mogadiscio
Political subdivisions: 8 regions, 48 districts
Organization: the junta has assumed all authority, calling itself the Supreme
Revolutionary Council, membership of which consists of 18 army and 3 police
officers; the Council has abrogated the constitution, dissolved the parliament,
and banned political parties
Government leader: President of the Supreme Revolutionary Council, Gen. Mohamed
Siad Barre
Member of: EAMA, FAQ, IBRD, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UNICEF, UPU,
WHO
Legal name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative, Cape Town; judicial, Bloemfontein
Political subdivisions: 4 provinces, each headed by centrally appointed
administrator; provincial councils, elected by white electorate, retain
limited powers
Legal system: based: on Roman-Dutch law and English common law; constitution.
enacted 1961, changing the Union of South Africa into a Republic; possibility
of judicial review of Acts of Parliament concerning dual official ‘anguages;
accepts compulsory [CJ jurisdiction, with reservations
Branches: President as formal chief of state; Prime Minister as head of
government; Cabinet responsible to bicameral legislature, lower house
elected directly by white electorate; upper house indirectly elected and
appointed; judiciary maintains substantial independence of government
influence
Government leader: Prime Minister Balthazar J. Vorster
Suffrage: general suffrage limited to whites over 18 (17 in Natal Province)
Elections: must be held at least every 5 years; last elections April 1970
Political parties and leaders: National Party, B. J. Vorster, P. W. Botha,
B. J. Shoeman, M. C. Botha, Jan De Klerk; United Party, Sir De Villiers
Graaff; Progressive Party, Colin Eglin, Helen Suzman; Herstigte Nasionale
Party, Albert Hertzog, Jaap Marais
Voting strength (1970 general elections): of 166 legislative seats, National
Party 118, United Party 47, Progressive Party 1
Communists: small Communist Party illegal since 1950; party in exile maintains
headquarters in London; Dr. Yasuf Dadoo, Michael Harmel, Joe Slovo
Other political groups: (insurgent groups in exile) African National Congress (ANC)
Oliver Tambo; Pan-Africanist Congress (PAC), leadership in dispute
pee of: Ha IBRD, ICAO, IHB, IMF, ITU, Seabeds Committee (observer), U.N.,
PU, WHO, WMO
Approved For Release 2004/08/31 : CYA-RDP79-01051A000400010002-1
ECONOMY: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $16.7 billion (1970), $830 per capita; real growth rate 5.1% (1970)
Agriculture: main crops -- corn, wool, dairy products, wheat, sugarcane,
tobacco, citrus fruits; self-sufficient in foodstuffs
Fishing: catch 1,079,000 tons (1968); exports $45 million (1970), imports $10
million (1970)
Major industries: mining, automobile assembly, metal working, machinery,
textiles, iron and steel, chemical, fertilizer, fishing
Electric power: 11,635,000 kw. capacity (1970); 48.8 billion kw.-hr. produced
(1970), 2,279 kw.-hr. per capita
Exports: $2.2 billion (f.o.b., 1970 excluding gold); wool, diamonds, corn,
uranium, sugar, fruit, hides, skins, metals, metallic ores, asbestos,
fish products; gold output $1.1 billion (1970)
Imports: $3.6 billion (f.0.b., 1970); motor vehicles, machinery, metals,
petroleum products, textiles, chemicals
Major trade partners: U.K. and other Commonwealth nations, U.S., Germany, Japan
Aid: no substantial military or economic aid
Monetary conversion rate: 1 SA Rand=US$1.40 (official); 0.714 SA Rand=US$1
Fiscal year: 1] April - 31 March
Legal name: Territory of South-West Africa
Type: administered as part of Republic of South Africa, under a League of
Nations mandate; U.N. formally ended South Africa''s mandate, and status now
in dispute
Capital: Windhoek
Political subdivisions: police zone (police-protected area, consisting of 17
magisterial districts, in which all-white settlement and several Bantu
reserves are found), northern territories (exclusively Bantu magisterial
districts under control of officials of South African Department of Bantu
Administration and Development)
Legal system: based on Roman-Dutch law and customary law
Branches: administrator, appointee of South African Government, principal
local executive; structure similar to that of a province of the Republic;
South-West Africa elects 4 Senators and 6 lower house members to the
Republic''s legislature; judicial system patterned on that of Republic
Government leader: B.J. van der Walt, Administrator
Suffrage: limited to white adults
Elections: last general election, 1970
Political parties and leaders: white parties -- National Party (NP), led in
South-West Africa by A. H. du Plessis; United National South-West Party
(UNSWP), J. P. Niehaus; nonwhite parties -- South-West Africa People''s
Organization (SWAPO), almost exclusively based on Ovambo tribe led by Sam
Nujoma, in exile; South-West Africa National Union (SWANU), primarily based
on Herero tribe, leaders in exile; National Unity Democratic Organization
(NUDO), primarily based on Herero tribe led by Clements Kapuuo
Voting strength: NP (1970 election) won all 10 seats in Republic legislature
and all 18 seats in South-West Africa Legislative Assembly
Communists: no Communist Party, but some influence by South African Communists
and other Communists on South-West African Bantu outside territory
Approved For Release 2004/08/31 *Gia-RDP79-01051A000400010002-1
Approved F :
ECONOMY: pp or Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Agriculture: livestock raising (cattle and sheep) predominates, subsistence
crops (millet, sorghum, corn, and some wheat) are raised but most food
must be imported
Fishing: catch 979,000 tons (1968), $56 million (1970 -- after processing,
mostly in South African enclave of Walvis Bay)
Major industries: meatpacking, fish processing, copper, lead, and diamond
mining, dairy products
Electric power: 95,200 kw. capacity (1969); 295 million kw.-hr. produced (1970),
463 kw.-hr. per capita
Aid: South Africa is only major donor
Monetary conversion rate: | South African Rand=US$1 .40 (official); 0.714 SA
Rand=US$1
Fiscal year: 1 April - 31 March
Legal name: (The) Spanish State
Type: nominally a monarchy, but without a king; actually a dictatorship under
Generalissimo Franco with Prince Juan Carlos designated to succeed him as
chief of state and become king
Capital: Madrid
Political subdivisions: metropolitan Spain, including the Canaries and Balearics,
divided into 50 provinces with governors appointed by the central government,
also 1 province and 5 places of sovereignty (presidios) in Africa; Ifni
province ceded by Spain to Morocco in June 1969; 2 former provinces com-
prising Equatorial Guinea were granted independence in October 1968
Legal system: civil law system, with regional applications of customary law;
7 basic laws including Organic Law of the State of January 1967 serve as
a constitution; legal education at 14 schools of law; does not accept
compulsory ICJ jurisdiction
Branches: executive, with chief of government dominating all branches of
government through his appointive powers and authority to legislate by
decree; legislative with unicameral Cortes controlled by executive; judicial,
completely subservient and limited to interpretation of laws
Government leader: Generalissimo Francisco Franco -- who is also Chief of State,
Commander in Chief of the armed forces, and head of the National Movement
(formerly called the Falange)
Suffrage: universal in national referendums, over age 21
Elections: only two types of direct election other than referendum provided:
representatives to municipal councils for which only heads of households
vote (last election November 1970) and, under new constitutional law of 1967,
104 members of the Cortes elected by heads of households and married women
for a 4-year term (last election September 1971)
311
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GOVERNMENT (cont ''dyeProved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Political parties and leaders: National Movement (formerly called Falange) only
legally recognized party, headed by Franco; Torcuato Fernandez Miranda,
minister-secretary general of the movement; various semiclandestine opposition
groups include -- Christian Democratic factions under Jose Maria Gil Robles
and Joaquin Ruiz Gimenez; the Socialists, whose secretary general, Rodolfo
Llopis, is in exile; "Internal Socialists" under Enrique Tierno Galvan; the
Anarchists; Republicans; Monarchists; smaller regional and national splinter
groups; the Communist Party, whose secretary general, Santiago Carrillo
Solares, is in exile; and a pro-Chinese Communist faction Marxist-Leninist
Communist Party of Spain
Voting strength: 556 seats, but only 534 members as. some hold more than one
seat -- 19% representing the family elected directly; 45% representing
municipalities, syndicates, and professions. elected indirectly under close
regime control; and 36% are appointed by regime or are ex officio
Communists: (inside and outside Spain, est.) 5,000; sympathizers up to 20,000
Other political or pressure groups: the state-controlled organization of
syndicates, comprising representatives of management and labor, an illegal
labor group called the Workers'' Commissions, the Catholic Church, business
and land owning interests, Opus Dei, Catholic Action, university students
Member of: FAO, IAEA, IBRD, ICAO, ILO, IHB, IMF, ITU, OECD, Seabeds Committee
(observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Province of Sahara
Type: province of Spain, subordinate to Ministry of the Presidency
Capital: E1 Aaiun
Political. subdivisions: two regions -- Rio de Oro and Saguia el Hamra
Legal system: based on Spanish civil law system and customary law
Branches: Provincial Council; 80 members, of whom half are elected natives
Government leader: Governor General responsible to Directorate General of the
Promotion of the Sahara (a division of the Ministry of the Presidency),
Br. Gen. Fernando de Santiago y Diaz de Mendivil
Suffrage: heads of families only
Elections: 40 members of Provincial Council, August 1967; half of municipal
councillors May 1969
Political party: National Movement
Communists: party proscribed; Communist sympathizers, few (if any)
Other political or pressure groups: none
Legal name: Democratic Republic of the Sudan
Type: republic under military control since coup in May 1969
Capital: Khartoum
Political subdivisions: 9 provinces, provincial and local administrations
controlled by central government
Legal system: based on English common law and Islamic law; some separate
religious courts ; constitution adopted 1956, suspended 1958, restored on an
interim basis in 1964; suspended with military coup in May 1969; temporary
constitution established by Republican order in August 1971; Revolutionary
Command Council established in 1969 disolved in October 1971 with the
anstallation of Ja''far al-Numayrias president and chief executive; Numayri
has reorganized government through a series of Republican decrees; legal
education at University of Khartoum and Khartoum extension of Cairo University
at Khartoum; accepts compulsory ICJ jurisdiction, with reservations
Government leader: RCC President and Prime Minister Ja''far al-Numayri
Suffrage: universal adult but franchise has not been exercised under present regime
Elections: parliamentary elections, first after 6 years of military rule held
in April and May 1965 in 6 northern provinces; latest elections in April
1968; presidential plebescite held in September 1971
Political parties and leaders: all parties outlawed since May 1969; the ban was
RoE ennerens on the Sudan Communist Party until after abortive coup in July
9
Voting strength: not tabulated by party
Communists: party decimated following July 1971 coup and counter-coup, several
top leaders including Secretary-General Mahjub executed; actual hard-core
membership down to lowest point in years; party control over labor unions,
professional groups and university student groups ended; Communists purged
from government :
Member of: Arab League, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU, Seabeds
Committee, U.N., UPU, WMO
317
Approved For Release 2004/08/31 : CIA-RDP79','af1a46cfd43ff0e1c033ce3e97c2308a9b9d57761941306f2c05f675cb688da9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('342a69f4f836d472e9aaa17e0f2a8efacbd7c23790c36f5f011fa70a3dc26c40',1971,'CO','Colombia','government',44,'-01051A000400010002-1
ECONOMY ; Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GDP: $1.4 billion (1968 provisional), under $100 per capita; 7% growth at
current prices 1967-68
Agriculture: main crops -- sorghum, millet, wheat, sesame, peanuts, beans,
barley; not self-sufficient in food production; main cash crops -- cotton,
gum arabic
Major industries: cotton ginning, textiles, brewery, cement, edible oils, soap,
distilling, shoes, pharmaceuticals
Electric power: 132,000 kw. capacity (1970); 303 million kw.-hr. produced (1969),
19 kw.-hr. per capita
Exports: $287 million (f.o.b., FY70); cotton (64%), gum arabic, peanuts,
sesame; $64.7 million exports to bloc (FY70)
Imports: $268 million (c.i.f., FY70); textiles, petroleum products, vehicles,
tea, wheat; $22.2 million imports from bloc (1968)
Major trade partners: U.K., West Germany, Italy, India, U.S.S.R.
Monetary conversion rate: 1 Sudanese pound=US$2.87 (official); 0.348 Sudanese
pound=US$1
Fiscal year: 1 July - 30 June','2c0e73f967c3b1a03cd0cf92fdbe4695548896273460029647fa080b07cd479b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ece84f09459d5aca8a07300bfb175c96074e4ec12d164321441f103b1d35f070',1971,'SD','Sudan','government',48,'Legal name: Syrian Arab Republic
Type: republic; under left-wing military regime since March 1963
Capital: Damascus
Political subdivisions: 13 provinces and city of Damascus administered as
separate unit
Legal system: based on Islamic law and civil law system, special religious courts;
provisional constitution promulgated in 1964; legal education at Damascus
University and University of Aleppo; has not accepted compulsory ICJ
jurisdiction
Branches: legislative and executive powers vested in President and Council
of Ministers; seat of power is the Ba''th Party Regional (Syrian) Command
Government leaders: President Hafiz Al-Asad
Suffrage: universal over age 18
Elections: no electoral laws in force; last elections in December 1961; presidential
referendum in 197]
Political parties and leaders: Arab Socialist Resurrection (Ba''th) Party only
recognized party
Other political or pressure groups: all officially banned; conservative Populist
and Nationalist Parties have lost all effective political influence;
Communist Party ineffective; small pro-Nasir organizations (United Socialist
Movement, Arab National Front, Arab Nationalist Movement) constitute greatest
threat to Ba''thist regime aside from factionalism in Ba''th Party itself
Member of: Arab League, FAQ, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: United Republic of Tanzania
Type: republic; single parties dominate both on the mainland and on Zanzibar
Capital: Dar es Salaam
Political subdivisions: 22 regions -- 18 on mainland, 4 on Zanzibar islands
Legal system: based on English common law, Islamic law, customary law, and German
civil law system; interim constitution adopted 1965; judicial review of
legislative acts limited to matters of interpretation; legal education at
University College, Dar es Salaam; has not accepted compulsory ICJ jurisdiction
Branches: President Julius Nyerere has full executive authority; National Assembly
dominated by Nyerere and the Tanganyika African National Union (TANU), consists
of 120 elected members, 17 ex officio members, and up to 25 appointed members
from mainland, and 3 ex officio members and up to 52 appointed members from
Zanzibar; First Vice President Abeid Karume and the Revolutionary Council
still run Zanzibar despite the efforts of Nyerere to integrate the islands
into the political system of the mainland
Government leader: President Julius Nyerere
Suffrage: universal adult
Political party and leaders: Tanganyika African National Union (TANU), only main-
land political party, dominated by Nyerere with Second Vice President Rashidi
Kawawa as his top lieutenant; Karume''s Afro-Shirazi Party in Zanzibar is
supposed to merge with TANU eventual ly
Voting strength (October 1970 national elections): 5 million registered voters,
Nyerere received 95% of 3.6 million votes cast
Communists: a few Communists and sympathizers
Member of: Commonwealth, EAC, FAO, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions: 71 centrally controlled provinces
Legal system: based on civil law system, with influences of common law; new
constitution promulgated in 1968, suspended 17 November 1971; legal education
at Thammasat University; has not accepted compulsory ICJ jurisdiction
Branches: King is head of state with nominal powers; Chairman heads a 16-man
national executive council, a caretaker body, pending an appointment of a
new cabinet under a provisional constitution; judiciary relatively independent
except in important political subversive cases
Government leaders: King Phumiphon Adundet; Field Marshal Thanom Kittikachorn,
Chairman; General Praphat Charusathien, Deputy Chairman
Suffrage: universal
Elections: suspended
Political parties and leaders: dissolved under the revolutionary order 17
November 1971
Member of: ADB, ASA, ASEAN, ASPAC, Colombo Plan, ECAFE, FAO, IAEA, ICAQ, IDA,
IFC, IHB, ILO, ITU, Seabeds Committee, SEAMES, SEATO, U.N., UNESCO, UNICEF,
UPU, WHO, WMO
Legal name: Republic of Togo
Type: republic; under military rule since January 1967
Capital: Lome
Political subdivisions: 18 circumscriptions
Legal system: based on French civil law and customary practice; draft constitution
presented to President in 1968, no indication of when it will be submitted
to referendum; has not accepted compulsory ICJ jurisdiction
Branches: military government, with civilian participation in the cabinet, took
over on 14 April 1967, replacing provisional government created after
January coup; no legislature; separate judiciary including State Security
Court established 1970
Government leader: Brig. Gen. Etienne Eyadema, President
Suffrage: universal adult
Elections: no elections since 1963 and none scheduled
Political parties: single party formed by President Eyadema in September 1969;
Rassemblement de Peuple Togolais, structure and staffing of party closely
controlled by government
Communists: no Communist Party; there may be a few Communists and sympathizers
Member of: EAMA, ENTENTE, FAQ, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM, U.N.,
UNESCO, UPU, WHO, WMO','05b2de3e164adae4038684c2a0c329a895380bd30f742079c78899462bee7954','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7be0c07c78a2d5c8175d09e9c0d970b6070eda84e429f927f0a0dbdcbeecdcb9',1971,'JP','Japan','government',54,'Legal name: Socialist Federal Republic of Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
Political subdivisions: 6 republics with 2 autonomous provinces (within the
Republic of Serbia)
Legal system: mixture of civil law system and Communist legal theory; constitution
adopted 1963 and amended in 1967, 1968, and 1971; in early stage of development
is a system of judicial review of legislative acts in Constitutional Court
(a quasi-judicial body); legal education at several law schools; has not
accepted compulsory ICJ jurisdiction
Branches: parliament (Federal Assembly) constitutionally supreme; executive
includes cabinet (Federal Executive Council) and the Federal Administration;
independent judiciary; the State Pesidency is a collective policymaking body
based on proportional representation of all the republics and provinces, Tito
presides as President of the Republic
Government leader: Josip Broz Tito, President of Republic and President of
League of Communists of Yugoslavia
Suffrage: universal over age 18
Elections: Federal Assembly elected every 4 years
Political parties and leaders: League of Communists of Yugoslavia (LCY) only;
leaders are President Tito and influential presidium executive bureau
members Edvard Kardelj, Veljko Vlahovic, Mijalko Todorovic, Vladimir
Bakaric, and Krste Crvenkovski
Voting strength: Voter participation in national elections has declined, as
follows -- 1963, 95.5%; 1965, 93.6%; 1967, 89%; 1969, 88%
Communists: 1.2 million party members
Other political or pressure groups: Socialist Alliance of Working People of
Yugoslavia (SAWPY), the major mass front organization for the LCY;
Confederation of Trade Unions of Yugoslavia (CTUY), Union of Youth of
Yugoslavia (UYY), Federation of Yugoslav War Veterans (SUBNOR)
Approved For Release 2004/08/31" GIA-RDP79-01051A000400010002-1
GOVERNMENT (cont''d) Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Member of: CEMA (participates in certain commissions), EC (trade agreement with
EC initiated 3 Feb 1970), FAO, GATT, IAEA, IBRD, ICAO, IHB, ILO, IMCO,
IMF, ITU, OECD (participant in some activities), Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Republic of Zaire (until recently known as Democratic Republic
of the Congo)
Type: republic; constitution establishes strong presidential system
Capital: Kinshasa
Political subdivisions: 8 provinces and federal district of Kinshasa
Legal system: based on Belgian civil law system and tribal law; new constitution
promulgated 1967; legal education at Lovanium and Congo Official University;
has not accepted compulsory ICJ jurisdiction
Branches: president elected 1970 for seven-year term; National Assembly of 420
members elected for five-year term
Government leaders: Gen. Joseph Mobutu, President
Elections: presidential and legislative elections in October and November 1970
Political parties and leaders: Mouvement Populaire de la Revolution (MPR), only
legal party, organized from above with actual grassroots popularity not
clearly definable
Communists: no Communist Party, but some politicians are subject to Communist
influence
Member of: EAMA, FAQ, IAEA, ICAO, IHB, ILO, ITU, OAU, OCAM, UDEAC, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Republic of Zambia
Type: republic since October 1964
Capital: Lusaka
Political subdivisions: 8 provinces
Legal system: based on English common law and customary law; constitution adopted
1964; judicial review of legislative acts in an ad hoc constitutional
council; legal education at University of Zambia in Lusaka; has not accepted
compulsory ICJ jurisdiction
Branches: modified presidential system; unicameral legislature; judiciary
Government leader: President Kenneth Kaunda
Suffrage: universal adult
Elections: last general election December 1968
Political parties and leaders: United National Independence Party (UNIP),
Kenneth Kaunda; African National Congress (ANC), Harry Nkumbula; United
Progressive Party (UPP), Simon Kapwepwe
Voting strength (1968 election): UNIP had 73% of vote, but 30 of its candidates
were unopposed; strength probably would have been over 80% if these seats
had been contested; UPP was not in existence when the most recent general
or local elections were held
Communists: no Communist Party, but sympathizers of socialism in upper levels
of government, UNIP, and labor unions
Member of: Commonwealth, FAQ, IAEA, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: United States of America
Legal system: based on English common law; dual system of courts, state and
federal; constitution adopted 1789; judicial review of legislative acts;
accepts compulsory ICd jurisdiction, with reservations
Voting strength (1968 presidential election): Republican Party (Nixon),
31,770,237; Democratic Party (Humphrey), 31,270,533; Independent (Wallace),
9,897,141; minor parties, 239,910
Communists: Party membership, 10,000-11,000 (est.); General Secretary, Gus Hal]
Member of: ADB, ANZUS, CENTO, Colombo Plan, FAO, GATT, IAEA, IBRD, ICAO, IDA,
IDB, IFC, ILO, IMCO, IMF, ITU, NATO, OAS, OECD, SEATO, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO','c8432d1c8523cf0732254c5934a87e3ae30b561806344e4ead499df7d9c67921','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

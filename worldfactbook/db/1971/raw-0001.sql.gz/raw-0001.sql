SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3e83fbb5aff08c3973718f4d8b1f98a393103be7c7a9d2204ef8d5b98ad2d00',1971,'','','raw',1,'Approved for Release: 2018/04/27 C06726998
BASIC INTELLIGENCE FACTBOOK
JULY 1973
Supersedes the January 1973 issuance of this
Factbook, copies of which should be destroyed.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998 :
ae
teow
i
{
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data on political
entitics worldwide, is coordinated and published semiannually as part of the NIS
Program by the Office of Basic and Geographic Intelligence, Central Intelli-
_» gence Agency. The data are prepared by Office of the Geographer, Department
of State and by componcnts of the Defense Intelligence Agency and the Central
Intelligence Agency. Comments and canuestions should be addressed to the
Office of Basic ana Geographic Intelligence (Attn: NIS Factbook), Central
Intelligence Agency, Washington, D.C. 20505.
Additional copies of the Factbook are obtainable through established
~ channels for dissemination of the NIS.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
This edition is a compilation of the unclassified
information in the classified version of the Factbook.
It is issued for use by U. S. Government departments
and agencies.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
Table of Contents
Page
SAN MARINO. 2... 2 ee ee ee ee ee ee eS 293
SAUDI ARABIA... - ee ee eee tee et ee eee 295
SENEGAL. . 2-2 ee et et ee te ee eee te eee 297
SEYCHELLES . 2. ee ee eet te ee te ee 299
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE. 2. we ee ee ee ee ee et 301
SIKKIM... 2 ee ee ee ee tt eet te HE 303
SINGAPORE. . .- - 2 es © eng aoe: Re a Meas lee SARI a NES, TEES Ms 305
SOMALIA. . .. 2. - eee ponies ee Yornlg vies Ro eee dats tet Se wee We 2 . . 307
SOUTH AFRICA... ee ee ee te ee ee 309
Southern Rhodesia (see RHODESTAJ
Sil aaah AFRICA. .... > bees Je ghigs vate Go are em 6 ieee ise uy
SPANISH SAHARA... .- hc le wale “ae ae Gah tae ee ogi Cee SS 317
SRI LANKA. 2. ee ee te et ee ee 319
SUDAN. . .. 2 ss eo eel Wes eee ce tat gi rel cal get, Ser ton ah Say va Sg, ea nes 321
SURINAM. » 2 ee ee ee te ee 323
SWAZILAND be gy ose ental a: atctah eae pO) be bg Wik en WE TES Be ew TS 325
SWEDEN . 2. we ee te ee te ee ewe ee ee ee 327
SWITZERLAND. . 2... 2 ee ee ee te ee eee ee eS oe « 329
SYRIA. 2. ew ee et te tee we ee ES 331
-T-
Tanganyika (see TANZANIA)
TANZANIA. wc eee te ee ee et ee ee & 333
Tasmania (see AUSTRALIA)
THAILAND... 2... ee ee te ee te ees gf ehhiig ig fe eel eh % 3330
TOGO... . es cia, ais tae ong. And Keen oper ae Pah te NS a ject wy eS
TONGA, . 2 ee ee et tte ett we eet we ee ee . . 339
TRINIDAD AND TOBAGO. ....-+.-s Se clbt ee hg seh ke Tal yor et to? ow) Ca seas . 341
TUNISIA. 2 2. ew ee ee eee te ee ee Sag Se 2849
TURKEY . 2... ee ee ee ee Band May US Sain EPS Mee tay seh ain aie S. te es TORO GS 345
-U-
UGANDA. 2. we ee ee te ee te ee wee ee 347
Umm al Qaiwain (see UNITED ARAB EMIRATES)
| ee eee ee PP To a 349
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Unm al Qaiwain . . 2 2 6 eee ees 351
United Arab Republic (see EGYPT)
UNITED KINGDOM... . eee ee eee te ee ee eee 353
UNITED STATES. . 2. eee ee te eee eet ee he eH 379
UPPER VOLTA, . . 2. ee ee eee et ee ee ee ee eee 355
URUGUAY. . .. 2 «> Ly cgi gh tortie. Ue dies Nel vas Meneses Sept ere, ee? cote ree. 357
-y-
VATICAN CITY 2. 2 we ee ee ee ee 359
VENEZUELA. . 2. 1 ee ee ee et ee ee ee he eee 361
VIETNAM, NORTH. . 2... - ee ee we ee Sree nds. Ghceear barr") sat War 0 eso fe 363
VIETNAM, SOUTH . 2. 6 6 we ee te ee eee te eh ee ee 365
v
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
TURKEY
D:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive SPRY
Land boundaries: 1,600 mi. Seat
cover SAUDI
WATER: "Sy nama
Limits of territorial waters (claimed): 6 n. mi. Be
except in Black Sea where it is 12 n. mi. SUDAN ‘
(fishing, 12 n. mi.) £ RSS
Coastline: 4,475 mi. ETHIOPYA','a24946e0eda2487814d38bc598fdbba53715746ebaacc57387c8bc055ad24a8d','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f9897caa3bac9bcd05b1b78239bfbd456f6cf61afcf31f05e0921cbe8388238',1971,'','','raw',1,'Approved for Release: 2018/04/27 C06727040
. January 1979
Zz
0)
a4
0
3
z)
1)
9
¥,
0
5.
a
0
- eet: . | National Basic Intelligence
$1 FACTBOOK
ay
>
0
as |
‘@
n°
0
f
y
[ GC BIF _
January 1979
Approved for Release: 2018/04/27 C06727040
eee ee eer etahe tet,
Approved for Release: 2018/04/27 C06727040
FOREWORD
The National Basic Intelligence Factbook, a compilation of
basic data on political entities worldwide, is coordinated and
published semiannually by the Central Intelligence Agency. The
data are prepared by components of the Central Intelligence
Agency, the Defense Intelligence Agency, and the Department
of State. Comments and suggestions regarding the contents
should be addressed to the Office of Geographic and Carto-
graphic Research (Att: Factbook) Central Intelligence Agency,
Washington, D.C. 20505.
The publication is prepared for the use of U.S. Government
officials. The format, coverage and contents of the publication
are designed to meet the specific requirements of those users.
U.S. Government officials may obtain additional copies of this
document directly or through liaison channels from the Central
Intelligence Agency.
Non-U.S. Government users may obtain this along with
similar CIA publications on a subscription basis by addressing
inquiries to:
- Document Expediting (DOCEX) Project
Exchange and Gifts Division
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users not interested in the DOCEX
Project subscription service may purchase reproductions of
specific publications on an individual basis from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users may also purchase hard copies
of this publication from:
Superintendent of Documents
U.S, Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-00103-5
Approved for Release: 2018/04/27 C06727040
rr
: Approved for Release: 2018/04/27 C06727040
National Basic Intelligence
FACTBOOK
January 1979
Supersedes the July 1978 issuance of this
Factbook, copies of which should be destroyed.
For sale by the Superintendent of Documents, U.S. Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-001035.
Approved for Release: 2018/04/27 C06727040
’ viii
‘WESTERN SAMOA
Approved for Release: 2018/04/27 C06727040
—TI—
TONGA oo... picts cetera dd halk tas 42M acl lace Bage Rt ang a eeIR eg
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO ........c..cccssssssssssssssvsssssevesssctessssessesssssssisisteeeceessissnesseeee','229191d21c5e7113b8bc9c7834f6ee045e559d212a2c62569a00745b896f5e03','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ded3fce09682e1e34108f254ecfd4b9f850846c8976090894249ff24b8d65f8',1971,'TN','Tunisia','raw',2,'TURKEY
ye
UGANDA) ):ecce ie tctivinl Gaiid neil ti lnetin dain Minion iieas alae SAS AS
Umm al Qaiwain (see UNITED ARAB EMIRATES)
UNS SRE soos eciecdid Setaa ces Hideo ae ses enbevicah oe esn ave tuapiea vests eaetabaebeyainsvedavays ba dan dagas¥ deaddeceetbagnetyeee
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain
United Arab Republic (see EGYPT)
UNITED KINGDOM: 0).50$:68.00sisstcta neve ieee ie atch hier
UNITED STATES) «ies st ndecta isda iigetenensc ce ie deed rhe tcien aroatinnaedieuaties
UPPER VOLTA > f.)cs dees hei hedhccsidesess ese ad dete as ae Gaetan','87fea2c6025fe50108bbe7331561928567fe86fd954f857c29e9754a3d429d1f','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf9d6124f492d2e1266d76dd016b751402385b90905228d2252f479a6a3a5e70',1971,'UY','Uruguay','raw',3,'—v—
VATICAN CITY. o.cisciicckectests tisaetes cats at etch ee enesetn dens Uonhieintieaatinia cael
VENEZUELA s c3fcicccdeseseh estecccbesqntenaessncdans gti nates gts Se aadead bps bts Gedaderebenpaniebecsae Beuthanea
VIETNAM
—w—
WALLIS and FUTUNA oon. ce ceric crete cnererrscnsecescrseseeecieersesneeteeereecreges
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara)
y=
YEMEN (Aden)
YEMEN (Sana)
YUGOSLAVIA
=7=
ZAMBIA. < ciscceisivshetes Hass aoe sess el eens eens tae a Gai ane a eae dent
Zanzibar (see TANZANIA)
Approved for Release: 2018/04/27 C06727040
January 1979
213
Approved for Release: 2018/04/27 C06727040
January 1979
TUNISIA/TURKEY
key centers are Safaais, Susah, Bizerte, and Tunis; 100,000
telephones (1.7 per 100 popl.); 8 AM, 3 FM, and 7 TV
stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 1,273,000; 718,000 fit
for military service; about 75,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1978, $153 million; 6% of central government budget
Ankara
TURKEY
oa
\\: ae GA =~
Since ats
{Sas reference map V}
LAND
766,640 km*; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km','2718b31987e7b789819ff5bb67cdf4eab1f34054cdda210d0c8cee0a45e8c535','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e5d0eeff91182c45d9d4b92ff4446bbaf07117d15efff8c270b4d8507839ef8',1971,'','','raw',1,'Approved for Release: 2018/04/27 C06727039
>
“NATIONAL INTELLIGENCE SURVEY
BASIC INTELLIGENCE FACTBOOK
JULY 1973
Supersedes the January 1973 issuance of this “ ARCHIVAL RECOR!
Factbook, copies of which should be destroyed FLEAS? RETURN TO ;
AGENCY ARCHIVES, ELDG. 4+.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data
on political entities worldwide, is coordinated and published
semiannually as part of the NIS Program by the Office of Basic
and Geographic Intelligence, Central Intelligence Agency. The
data are prepared by Office of the Geographer, Department of
State and by components of the Defense Intelligence Agency
and the Central Intelligence Agency. Comments and suggestions
should be addressed to the Office of Basic and Geographic
Intelligence (Attn: NIS Factbook), Central Intelligence Agency,
Washington, D.C. 20505.
Additional copies of the Factbook, both classified and un-
classified issues, are obtainable through established channels for
dissemination of the NIS.
THIS MATERIAL CONTAINS INFORMATION AFFECTING
THE NATIONAL DEFENSE OF THE UNITED STATES
WITHIN THE MEANING OF THE ESPIONAGE LAWS,
TITLE 18, USC, SECS. 793 AND 794, THE TRANSMISSION
OR REVELATION OF WHICH IN ANY MANNER TO AN
UNAUTHORIZED PERSON IS PROHIBITED BY LAW.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
WARNING
The NIS is National Intelligence and may not be re-
leased or shown to representatives of any foreign govern-
ment or international body except by specific authorization
of the Director of Central Intelligence in accordance with
the provisions of National Security Council Intelligence Di-
rective No. 1.
For NIS containing unclassified material, however, the
portions so marked may be made available for official pur-
poses to foreign nationals and nongovernment personnel
provided no attribution is made to National Intelligence or
the National Intelligence Survey.
Unless otherwise indicated, individual items
are UNCLASSIFIED/FOR OFFICIAL USE ONLY.
Classification designations are:
(OC) testes Confidential
(S)ve. 32) Secret
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
“SECRET.
Table of Contents
Page
SAN: MARINO: ce 6 cee See ge Sere Se a lade Gee an A ee ie a ae 383
SAUDE ARABIA g:o5 3 sd. ceed & Reel Se) eS ee es 385
SENEGAL 2. fms oe So te a te Se at ee LE Si eh aes PE eee 387
SEYCHELLES cigar ee eas oe be este eS he Ge so es eee Sa ae So Be 389
Sharjah (see UNITED ARAB EMIRATES)
STERRA (LEONE: ~) 05. &. gee Sees ete A Sa ae te Re ey ne ye pe en ee 391
ST KKEM 3.2 caste see A es ce sl ee Gave Con Be eee, Ree ee We eS 393
STINGAPORE 6 ~ eieccoe otesecs desea We: obo eG" Annee Moh ee io oes nao es Wee eee 395
SOMALTA Sic: senor SBS ee Pa EE ne ae ie een ee eee “al GE ws Rees of? 397
SOUTH: AFRICA? oc. cei eo 8 See eer te ar ee Ss Tee 0 We ee Se 399
Southern Rhodesia (see RHODESIA)
SOUTH-WEST AFRICA. . . 2. 2 1 ee we ee te we te 403
SPAINGG se Se oe Se ee ls Ba Sera tS re wl hee os tay Janine 8s 405
SPANTSH ‘SAHARA 5. 232-0. ee kee ee ee see ee eee ww Ce 409
SRE LANKA Ses setae ib tie es re ote Sore a wren ie) eo ee tated See ae 411
SUDAN o. ie-.g. oe sehen Sek mol as he Bh “Seer se tgs Sha tah re win et ems NS Ge tee eh oe 415
SURINAME. 02 xsc260 ve sei Soro ce A SE ee eR he ee as ar tar Sh eee eee 419
SWAZILAND =. 2.62 ccs S) nO ee Fe Oo Se Blea Mek % Bee, Byway teu ke 421
SWEDEN cue ce nea caetot le conte on medic phase, Gti Gams Mean Se 423
SWITZERUAND sc od ce ''o: 1,006 os van ts Fen Saas Ag Be, eae! Tey Cage 427
SYR TRG oy ec secs etek be ee ek eng es areas 429
-T:
Tanganyika (see TANZANIA)
TANZANTAS ob cake. oie eh ce etn eh nin 8 Case a a te cle Ca aS wate Se 431
Tasmania (see AUSTRALIA)
THAILAND 3. wc -8 we ees eR ee be aoe & ie we ee 495
TOGO a: yee UR Ow aw ae ee wd Se ee A Se wee ee 439
TONGA © 6. edge ee Se Sc ae eS rae ; : ‘ 44]
oe AND TOBAGO. F Bae bode al eh awe hare ee ss . . =. 443
iia Bah GPL Baa aE ND ON Cie DER ea vs ect aay ce Fs 445
TURKEY gn eh weet Ai APS ae i sg ge eet, BMG ee eit te aa Sk: 447
-U-
UGANDA 555 io oe eo do reser ree ee nse ae a eles wes es ee 451
nes al Qaiwain (see UNITED ARAB EMIRATES)
Sk, ake Byles Be Sw Gon Ey fa els NDR ne Ot age, ee 453
ED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain. ........2... 457
United Arab Republic (see EGYPT)
UNITED KINGDOM. 2... 1 1 we ee ee ee we tt ee te et 459
UNETED “STATES. o°-2 oc. se? Gece oe an ce ere Vel Gh ewe Sal Bek ele ne a 497
UPPER: VOLTA so: o:ce) te tee es oe I ee Be BO be Oe bes 463
URUGUAY cei eo ie eho eae Ser ay Boal ww Boer SP Gee: Be, Sas 82 weer 8 465
-V-
VATICAN: CLI a: 22-2, ecg: sés fortes Se et Se ea SCR te. ae a Gales 469
VENEZUELA se 5- ower ver era RS, “eee eee te yee el HS Bey Sere Re 471
VIETNAM, ‘NORTH gees detec tee ca eel ceive ei Ba ee ee 475
VEETNAM,. “SQUTHD ec. ce ios wee ae Se ee ee ae ee EP 479
v
SEGRE.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
““SRCRET.
NIS 27 TURKEY
D:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mi.)
Coastline: 4,475 mi.','d81506181d04ffbecc364831122ff5a940f94bbc6ccef504917bcbbdae630814','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0556612a4bdc7b956ede39188e6d5b51d52d2054ad144c2d9f5c2b3b2506c224',1971,'','','raw',1,'if 4a. Approved for Release: 2018/04/27 C0672 704 2s
: Seer’ 1 @E%. National |
| a (a) ce. | os sig
Center
; National
| | Basic Intelligence |
| Factbook | :
July 1979
GLEEAIRE »-— Jo0g398,y soUESTTPOIUT aISeg PeUOHEN
a Sa
4
|
t
Secret :
GC BIF 79-002
July 1979
\\
Approved for Release: 2018/04/27 C06727042
i
F
\\
t
i
L
!
f
|
i
| Warning Notice .
|
:
re National Security Unauthorized Disclosure
| | Information * Subject to Criminal Sanctions
F
|
|
;
‘|
|
|
|
|:
| : Dissemination Control! ——
! Abbreviations :
! —
4 ;
il y .
;
i _
|
f oe
Pr
|
l
a |
Oe
—————VK— KEE
Approved for Release: 2018/04/27 C06727042
c—,
7
=f Nes
BRS
oe ee Doo — palate as ws y . tomer 4
: Ne Por ited
Approved for Release: 2018/04/27 C06727042 ;
4n x5
Ma National “Sercret-
tie Aaceceniel | : (b)(3)
SZ Contes :
National
Basic Intelligence
Factbook
July 1979
Supersedes the January 1979
edition, copies of which should
be destroyed.
The Factbook, a compilation of basic data on political
entities worldwide, is produced semiannually by the
Office of Geographic and Cartographic Research
with contributions provided by various components of .
the Central intelligence Agency, the Defense intelli-
gence Agency, and the Department of State. Com-
ments, suggestions, and requests for additional copies
may be addressed to:
Office of Geographic and Cartographic Research
(Attn: Factbook)
Central intelligence Agency
Washington, D.C. 20505
Unless otherwise indicated,
individual entries are Unclassified.
~Secret—
GC BIF 79-002
July 1979
Approved for Release: 2018/04/27 C06727042
viii
.TAIWAN
Approved for Release: 2018/04/27 C06727042
=f
Tanganyika (see TANZANIA)
TANZANIA 835528 i ato cheats Sing Selene AM scaled Abatement de cles tae Moc ietee eA Glae La,
Tasmania (see AUSTRALIA) :','17c76fc57964e9e265cdb7e01247ff344b48f8f5bed7f69f931d495d9a334a11','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('669731d6b2149a5c879b7ebae13f60ee05dd9d4b0d2f1c09fc8bc236d593bc1f',1971,'TH','Thailand','raw',2,'—U—
UGANDA °:cicc0c ine diaries fot hd eh codeine lt da
Umm al. Qaiwain (see UNITED ARAB EMIRATES)
USiS Re xP ei AS a oe AB de sel tah etna ic alban aaa dal ee
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain o.oo... cece teetteec eee
United Arab Republic (see EGYPT)
UNITED’ KINGDOM: ii.chetnde eee ease oi ineeulaten caunranniiieaieald
WINITED: STATES © esc tics pick ageh csesessertestolentiveaedguist ae gateactavtear ue mueaadonua soto
UPPER: VOLTA) i icsisescitend, dy acto aha ieee oe aN ha aR ae
URUGUAY 2.2025 sd on acs th ceebdeelth deaail bs it aa poidivoes be patsagus Reve ee iS Meera te
Vv
VATICAN CITY
VENEZUELA
VIETNAM
—w—
WALLIS. and: FUTUNA: | o5:) 022.5 Sic iecsa facets cove idk Mieiadan dls svtasadeaedelde Wgec es
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara)
WESTERN SAMOA
ys
YEMEN (Aden)
YEMEN (Sana)
YUGOSLAVIA
Zanzibar (see TANZANIA)
ZIMBABWE-RHODESIA
Approved for Release: 2018/04/27 C06727042
248
July 1979
Approved for Release: 2018/04/27 C06727042
July 1979
éSea reference map V)
LAND
766,640 km?*; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km','4a3473dce6e084136ed98a392f13f6d6cce4c4e03f22d2b86f9359158600c544','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6adf0a34c64366fa7b8b2540898bf463c01782baf410c03513a1dc1f8e3110d2',1971,'','','raw',1,'A pproved for Release: 2018/04/27 C06726997 =
NATIONAL INTELLIGENCE SURVEY
; BASIC INTELLIGENCE FACTBOOK
JANUARY 1973
$
Py
; CHIVAL RECORD
des t 1972 i f this Factbook, ''ARCHIV. ,
Supersedes the July 1972 issuance of this Factboo i PLEASE RETURN TO |
copies of which should be destroyed. AGEN i ARCHIVES,
a ORT
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
“SECRE—
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data
on political entitics worldwide, is coordinated and published
scmiamnually as part of the NIS Program by the Office of Basic
and Geographic Intelligence, Central Intelligence Agency. The
data are prepared by components of the Defensc Intelligence
Agency and the Central Intelligence Agency. Comments and
suggestions should be addressed to the Office of Basic and
Geographic Intelligence (Attn: NIS Factbook), Central Intel-
ligence Agency, Washington, D.C. 20505.
Additional copics of the Factbook, both classificd and un-
classificd issucs, are obtainable through established channels for
disscmination of the NIS.
THIS MATERIAL CONTAINS INFORMATION AFFECTING
THE NATIONAL DEFENSE OF TIIE UNITED STATES
WITHIN THE MEANING OF THE ESPIONAGE LAWS,
TITLE 18, USC, SECS. 793 AND 794, THE TRANSMISSION
OR REVELATION OF WHICH IN ANY MANNER TO AN
UNAUTIIORIZED PERSON IS PROHIBITED BY LAW.
CLASSIFIED BY 58-0001, EXEMPT FROM GENERAL DECLASSIFICATION SCHEDULE
OF €. O. 11652 EX zea CATEGORIES SB (2) AND (3). DECLASSIFIED ONLY
ON APPROVAL OF OCI
Approved for Release: 2018/04/27 C06726997
em det
ee ee
Approved for Release: 2018/04/27 C06726997
WARNING
The NIS is National Intelligence and may not be re-
leased or shown to representatives of any foreign govern-
ment or international body except by specific authorization
of the Director of Central Intelligence in accordance with
the provisions of National Security Council Intelligence Di-
rective No. 1.
For NIS containing unclassified material, however, the
portions so marked may be made available for official pur-
poses to foreign nationals and nongovernment personnel
provided no attribution is made to National Intelligence or
the National Intelligence Survey.
Unless otherwise indicated, individual items
are UNCLASSIFIED/FOR OFFICIAL USE ONLY.
Classification designations are:
(2) ee Confidential
(S)...... Secret
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
SECRET
Table of Contents (cont''d):
SENEGAL. oe be so ec bs Bate oor Ra we ee el ee SO ale le or SP es
SEYCHELLES =o) 5.95. et te ee A fe ee ee Sa es oa hte erie eae
Sharjah (see UNITED ARAB EMIRATES)
STERRA LEONE: 3. 3. 3,6: jose aoe koe: eee eo Aca 4 be ee RE are
SIKKIM esol aoe Wn ea ey eee ae ee SO We we Aaa ter eS ete
SOMALT As. for) ec se coh Oe ewe se ee Gc ce ites) Srl a as ae ew ele
SOUTHARRIGCA |e. oi: eh ee il el oe ere ww Bea ch Swe wwe als
Southern Rhodesia (see RHODESIA)
SOUTH=WEST |AFRIGAS: e555 55 Soke, Woe les ae ec OS es
SPAIWNs o.oo oe lertene ce mar Cove! Cee oh Wow LSS? o> He Rua coy See ee Ged Saas
SRT LANKA si i50c3. oe hate faa tes. a ER a ee EK ey
i i i i i i |
2Tz
|
Middl (see peace
THAILAND... .... B Meas i) Ate ha kak oA Gheeiued Ma, Mor iy ode te melee fo
TONGA. ee, ee rare
TRINTOAD AND TOBAGOs 2 3 Gav 0 Soba actbnoe and fo aces a
TUNISIA. 2... ww ee Sol Gat cat anh oy Weel oe aoe ol Ga Sakae fee be oh Oe
TURKEY, |, 5353-6 co: sic ae Ges Gos 0 as a te ec Bye Pol Gn eS Tecate faire a
-U-
S.R
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm "al Qaiwain. .. 1. ee ew eee
United Arab Republic (see EGYPT)
UNITED KINGDOM. 2... 1 2 we ee ee ee
UNITED: STATES > 5. eas ce. Ss ber evs ie el en a eee ee
UPPER ‘VOLTA S. a ten ves és ce ete oe Nel ie Sele a? ec ee ea Mee ea
URUGUAY 6 ese ccs aise Melee yee og oo ley ty ce: Sa i a ea ey tea eS La ee
-\\-
VATICAN CLIN io a oe dee ae ht a Rees ae es I ae ae cas
VENEZUELA cece seas ol a as $05 ar dk a ce ave dap Pe ay Sa a Se, lw Ae
VIETNAM, NORTH... ....., BS Ae Sia Bye ROSENT RS Jet te be a dh, ae eect, ye
VIETNAM, SOUTH . . 1 eee ee eee we ee eee tt tts
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
—~Sterer—
NIS 27 TURKEY
LAND:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER: Pare
Limits of territorial waters (claimed): 6 n. mi. .
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mt.)
Coastline: 4,475 mi.','3d010a63a9223686fb0d93a0591b381470714a42cab3b49d027269a6eff5c8a9','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f55c88a113eb8d14ddbcd2df337c2c4ddacbdb6313e4e1e478343366f063452',1971,'','','raw',1,'fidterpaoa™
BASIC INTELLIGENCE FACTBOO
JUNE 1971
DIA review(s) completed.
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
FOREWORD
The Factbook is an integral component of the NIS Program which
provides interim updating of the type of basic data appearing in the Area
Brief of each General Survey and serves as a general ready reference,
The Factbook is prepared by components of the Defense Intelligence
Agency and of the Central Intelligence Agency, and is coordinated and
published semiannually by the Office of Basic and Geographic Intelligence,
CIA,
Additional copies of the Factbook are obtained through established
channels for dissemination of the NIS,
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Next 6 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
AAPSO Afro-Asian People''s Solidarity Organization
ADB Asian Development Bank
ANZUS ANZUS Council; treaty signed by Australia, New Zealand,
and the United States
ASA Association of Southeast Asia
ASPAC Asian and Pacific Council
BENELUX Belgium, Netherlands, Luxembourg Economic Union
BLEU Belgium-Luxembourg Economic Union
CACM Central American Common Market
CARIFTA Caribbean Free Trade Association
CEMA Council for Mutual Economic Assistance
CENTO Central Treaty Organization
Colombo Plan
Council of Europe
DAC Development Assistance Committee (OECD)
EAMA African States associated with the EEC
ECSC European Coal and Steel Community
EEC European Economic Community (Common Market)
EFTA European Free Trade Association
EIB European Investment Bank
ELDO European Launcher Development Organization
EMA European Monetary Agreement
ENTENTE Political-Economic Association of Ivory Coast, Dahomey,
Niger, Upper Volta, and Togo
ESRO European Space Research Organization
EURATOM European Atomic Energy Community
IADB Inter-American Defense Board
ICFTU International Confederation of Free Trade Unions
IDB Inter-American Development Bank
IFCTU International Federation of Christian Trade Unions
vii
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (cont''d)
IHB
IRC
LAFTA
LICROSS
NATO
OAPEC
OAS
OAU
OCAM
ODECA
OECD
OPEC
SEATO
UAM
UEAC
UDEAC
WEU
WFTU
WPC
International Hydrographic Bureau
International Red Cross
Latin American Free Trade Association
League of Red Cross Societies
North Atlantic Treaty Organization
Organization of Arab Petroleum Exporting Countries
Organization of American States
Organization of African Unity
Afro-Malagasy Common Organization
Organization of Central American States
Organization for Economic Cooperation and Development
Organization of Petroleum Exporting Countries
South-East Asia Treaty Organization
Union Africaine et Malgache
Union of Central African States
Economic and Customs Union of Central Africa
Western European Union
World Federation of Trade Unions
Wortd Peace Council
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
SC
GA
ECOSOC
TC
ICJ
Security Council
General Assembly
Economic and Social Council
Trusteeship Council
International Court of Justice
Secretariat
Approved For Release 2004/88/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES (cont''d)
Operating Bodies:
UNCTAD U.N. Conference for Trade and Development
TDB Trade and Development Board
UNICEF U.N. Children''s Fund
Regional Economic Commissions:
ECA Economic Commission for Africa
ECAFE Economic Commission for Asia and the Far East
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development
(World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural Organization
UPU Universal Postal Union
WHO World Health Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
ix
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NOTE:
Political, sociological, and economic data generally reflect information
through mid-April 1971, except for population estimates, which have been projected .
to 1 July 1971. 25X1
25X1
\\*
Most of the land utilization estimates are rough approximations, and most of
the statistical data are rounded (thousands and millions). Figures for "arable" may
reflect only the area actually under crops rather than the potential cultivable.
For some countries GDP, rather than GNP, is shown. The difference between the
two is in the addition or subtraction of the value of return on foreign investment.
GDP equals GNP plus income earned in the country but sent abroad, minus income
earned abroad but sent into the country. GDP thus tends to exceed GNP in debtor
countries, and the reverse is true in creditor countries.
Major transport aircraft are those weighing over 20,000 pounds. Military
budgets are in U.S. dollar equivalents. The dollar sign refers to U.S. dollars
unless otherwise stated. The abbreviation FY stands for fiscal year; all years are
calendar years unless otherwise indicated.
x
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
w
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 34 AFGHANISTAN A ~ Y
ND: \\ CHINA
250,000 sq. mi.; 22% arable (including 6.5% cultivated), c
5% pasture, 71% desert, waste or urban, 2% forested Press Ring, BHUTAN
(1965) Bly','27530aeb33f794aa0e4eab439069579206ff286fd1619279a83615b592e15204','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a39cfdad6e456c4c901db62a7183497275ba4064a2e3450930bd77ae5bc7604',1971,'','','raw',1,'BASIC INTELLIGENCE FACTBOOK
DECEMBER 197]
DIA review(s) completed.
Supersedes the June 1971 issuance of this Factbook,
copies of which should be destroyed.
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
FOREWORD
The Basic Intelligence Factbook, a compilation of
basic data on political entities worldwide, is coordinated
and published semiannually as part of the NIS Program by
the Office of Basic and Geographic Intelligence. The data
are prepared by components of the Defense Intelligence
Agency and the Central Intelligence Agency. Comments
and suggestions should be addressed to the Office of Basic
and Geographic Intelligence (Attn: NIS Factbook), Central
Intelligence Agency, Washington, D.C, 20505,
Additional copies of the Factbook are obtainable
through established channels for dissemination of the NIS,
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Next 5 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
AAPSO
ADB
ANZUS
ASA
ASPAC
BENELUX
BLEU
CACM
CARIFTA
CEMA
CENTO
DAC
EAMA
EC
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
IADB
ICFTU
IDB
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
Afro-Asian People''s Solidarity Organization
Asian Development Bank
ANZUS Council; treaty signed by Australia, New Zealand,
and the United States
Association of Southeast Asia
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Free Trade Association
Council for Mutual Economic Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Launcher Development Organization
European Monetary Agreement
Political-Economic Association of Ivory Coast, Dahomey,
Niger, Upper Volta, and Togo
European Space Research Organization
European Atomic Energy Community
Inter-American Defense Board
International Confederation of Free Trade Unions
Inter-American Development Bank
Approved For Release 2004/08/31 : GiA-RDP79-01051A000400010002-1
Approved
IFCTU
IHB
IRC
LAFTA
LICROSS
NATO
OAPEC
OAS
QAU
OCAM
ODECA
OECD
OPEC
SEATO
UAM
UEAC
UDEAC
WEU
WFTU
WPC
For Release 2004/08/31 : CIA- - =
Foe Re se aoe TN OR AN Pa PTGS 40004000 1 0002-1
International Federation of Christian Trade Unions
International Hydrographic Bureau
International Red Cross
Latin American Free Trade Association
League of Red Cross Societies
North Atlantic Treaty Organization
Organization of Arab Petroleum Exporting Countries
Organization of American States
Organization of African Unity
Afro-Malagasy Common Organization
Organization of Central American States
Organization for Economic Cooperation and Development
Organization of Petroleum Exporting Countries
South-East Asia Treaty Organization
Union Africaine et Malgache
Union of Central African States
Economic and Customs Union of Central Africa
Western European Union
World Federation of Trade Unions
World Peace Council
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
sc
GA
ECOSOC
TC
ICdJ
Security Council
General Assembly
Economic and Social Council
Trusteeship Council
International Court of Justice
Secretariat
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
AREER Foe GREG ZOCOR aE NE RECA LAE 08M
Operating Bodies:
UNCTAD U.N. Conference for Trade and Development
TDB Trade and Development Board
UNICEF U.N. Children''s Fund
Regional Economic Commissions:
ECA Economic Commission for Africa
ECAFE Economic Commission for Asia and the Far East
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development
(World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural Organization
UPU Universal Postal Union
WHO World Health Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
Committees:
Seabeds Committee United Nations Committee on the Peaceful Uses of the
Sea~Bed and Ocean Floor beyond the Limits of National
Jurisdiction
ix
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
wore: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Political, sociological, and economic data, including monetary conversion
rates, generally reflect information through mid-October 1971, except for population
estimates, which have been projected to 1 January 1972. Military manpower estimates
are as of 1 January 1972 except for average number of males reaching military age,
which are projected averages for the 5-year period 1971-75. Military and communications
data are as of 1 October 1971 unless otherwise indicated.
Most of the land utilization estimates are rough approximations, and most of
the statistical data are rounded (thousands and millions). Figures for "arable" may
reflect only the area actually under crops rather than the potential cultivable.
Fishing limits are included only when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The difference between the
two is in the addition or subtraction of the value of return on foreign investment.
GDP equals GNP Sitis income earned in the country but sent abroad, minus income earned
abroad but sent into the country. GDP thus tends to exceed GNP in debtor countries,
and the reverse is true in creditor countries.
Major ports are the largest maritime ports of the country, relative to other
ports of the same country, on the basis of estimated port capacity, alongside berthing
accommodations, and commercial or naval importance. Minor ports are the remaining
ports of a country which have, relative to the major ports, significantly lower
estimated port capacity, fewer alongside berthing accommodations, are of less
commercial or naval importance. Major transport aircraft are those weighing over 20,000
pounds. Military budgets are in U.S. dollar equivalents. The dollar sign refers to
U.S. dollars unless otherwise stated. The abbreviation FY stands for fiscal year; all
years are calendar years unless otherwise indicated.
Approved For Release 3004/08/31 : CIA-RDP79-01051A000400010002-1
NIS gfPProved For Release 2004/08/34. GlA-RDP79-01 051A000400010002-1
D:
250,000 sq. mi.; 22% arable (including 6.5% cultivated),
5% pasture, 71% desert, waste or urban, 2% forested Pa
Land boundaries: 3,390 mi. ai a eed
*
PEOPLE: ie
Population: about 18 million, average annual growth rate
2.5% (FY65-70); males 15-49, about 4.7 million; 2.5
million fit for military service; about 165,000 reach
military age (22) annually
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9% Uzbeks,
9% Hazaras;, minor ethnic groups include Chahar,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11% Turkic languages (primarily
Uzbeki and Turkmeni), 10% 30 minor languages (primarily Baluchi and Pashai);
much bilingualism
Literacy: under 10%
Labor force: about 4.3 million (official est.); 75%-80% agriculture and animal
husbandry, 15%-25% commerce, small industry, services; massive shortage of
skilled labor
Organized labor: none
f
a
2','9edde16fa6723f7be07de9994c68cf51d4963147fe9b1898d07b7e8b5b0af5c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42097f3685f8f5cdd7a703d24095773874005d0d8484fe08416ad5cde53ef3be',1971,'','','raw',1,'%. % “ qt "e r= -~
EDWARD P. BOLAND, MASS., Approved For Release 2004/09/24 : CIA-RDF% LDS TSTRGU 9001 0QL8 +f-405, U.S. CAPITOL
CLEMENT J. ZABLOCK!, WIS. roa \\ (202) 225-4121
BILL D. BURLISON, MO.
MORGAN F. MURPHY, ILL.
LES ASPIN, WIS.
CHARLES ROSE, N.C. U.S. HOUSE OF REPRESENTATIVES LOPS CL
NORMAN Y. MINETA, CALIE- PERMANENT SELECT COMMITTEE
WYCHE FOWLER, JR., GA. ON INTELLIGENCE
BOB WILSON, CALIF.
JOHN M. ASHBROOK, OHIO WASHINGTON, D.C. 20515
ROBERT MCCLORY, ILL.
J. KENNETH ROBINSON, VA.
THOMAS K. LATIMER, STAFF DIRECTOR OLC a v4 ie ~/. QO
MICHAEL J. O''NEIL, CHIEF COUNSEL
February 22, 1978
Office of Legislative Counsel
7D45 Headquarters
Central Intelligence Agency
Washington, D.C. 20505
Dear Pete:
Enclosed is a letter from a Mr. Abraham
Velez-Miranda who requests four CIA publica-
tions. Please respond directly to
Mr. Velez—-Miranda.
Sincerely,
anGhle e Latimer
Staff Director
Enclosure
Approved For Release 2004/09/24 : CIA-RDP81M00980R003200010018-7
Approved For Release 2004/09/24 : CIA-RDP81M00980R003200010018-7
USA
Febuowy II, 1973
Jk toner be |
Edwerd ?. Belenk Charman
Perm enact Lebec Comritle om J Rbhigen ce
Ozer O. Charsran.,
— CTR. prbbediire qrofek
Aicraly
PQ
Approved For Release 2004/09/24 : CIA-RDP81M00980R003200010018-7
APS, ATA, SOSSI, SPA
RRR KR KEK KR KR KR KR KK KK
CIA PRODUCED ATLASES
Peoples Republic of China: Atlas 1971 82 Pages
Catalog No. PrEx 3.10/4: C44/3
Atlas: Issues in the Middle East 1973 40 Pages
Catalog No. PrEx 3.10/4: M58
USSR Agriculture Atlas 1974 60 Pages
Catalog No. PrEx 3.10/4: UN3/4
Peoples Republic of China Administrative Atlas 1975 68 Pages
Stock Number: ———0414=015=00076=4-—— --
Approved For Release 2004/09/24 : CIA-RDP81M00980R003200010018-7
October 1977
Maps of the World''s Nations Vol. I Western Hemisphere 1976 46 Pages
Stock No. 041-015-00078-1
sf
Maps of the World''s Nations Vol. II Africa 1977 53 Pages
Stock No. 041-015-00083-7
Indian Ocean Atlas 1976 80 Pages
—_—S Catalog No. PrEx 3.10/4
National Basic Intelligence Factbook July 1977
GC BIF-77-002 Stock Number: 041-015-00085-3
ZF
Approved For Release 2004/09/24 : CIA-RDP81
67NS NATIONAL BASIC INTELLI-
GENCE FACTBOOK. Yhis CIA ubtication
gives basic data on 188 countries of the
world. The data includes information on
each country’s People, type of government
Economy, transportation system, ;
eee and more. The information’ is
ed semiannually and this edition (he
igen it be ly and this edj on (uuaty, y
quent editions will be reviewed in this
magazine as they become available. 1977.
221 p. il., eight color mape.
NERRRORGRTE 1018-7','41850f54f3a33c4451b53521167fac234e8524c4721864e8cf8de384640b4f27','internet-archive','cia-readingroom-document-cia-rdp81m00980r003200010018-7','txt','4f707d87451911ecf6ed872c11ab5de56a08ee3b50fe4eb18a247352d4e2087a','https://archive.org/download/cia-readingroom-document-cia-rdp81m00980r003200010018-7/cia-rdp81m00980r003200010018-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

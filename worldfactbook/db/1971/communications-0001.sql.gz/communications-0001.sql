SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b18a8699d75a60309e210abf9258fa94620de32be913e922477274a4089afa7d',1971,'','','communications',5,'Railroads: 4,991 mi.; 4,940 mi. 4''8 1/2" gage, 51 mi. double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi1, 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 594,900 GRT, 826,600 DHT;
includes 12 passenger, 52 cargo, 11 tanker, 10 bulk, 2 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 123 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 22 with runways
4 ,000-7 ,999 ft.; 2 seaplane stations
Teleconmunications: excellent international radiocommunication and fair domestic
telecommunication services; 654,500 telephones; 3.94 million radio and 133,000
TV receivers; 39 AM, 2 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,707,000; 5,730,000 fit for military service;
about 402,000 reach military age (20) annually
Military budget: for fiscal year ending 28 February 1974, $792.8 million; about
16% of central government budget
346
Approved for Release: 2018/04/27 C06726998','3f12afb7679ed6d6fbd9995b63f1709fd9f751fa11e529d9e6974f040abec1d6','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e61c95cf38e5a10c36a550053de9b9c51849fe86d4d409ffb1ed17dfdc727cda',1971,'UY','Uruguay','communications',7,'Railroads: 8,253 km standard gage (1.485 m); 143 km
double track; 72 km electrified
Highways: 60,000 km total; 21,000 km bituminous;
28,000 km gravel or crushed stone; 2,500 km improved
earth; 8,500 km unimproved earth
Inland waterways: approx. 1,689 km
Pipelines: 1,288 km crude oil; 2,055 km refined products
Ports: 10 major, 35 minor
Civil air; 24 major transport aircraft
Airfields: 120 total, 101 usable; 58 with permanent-sur-
face runways; 3 with runways over 3,660 m, 23 with
runways 2,440-3,659 m, 22 with runways 1,220-2,439 m
Telecommunications; new trunk domestic radio-relay
net, good international service; 1.1 million: telephones (2.7
per 100 popl.); 40 AM, 4 FM, and 36 TV stations; 1 coaxial
submarine cable; COMSAT station near completion
DEFENSE FORCES
Military manpower: males 15-49, 9,786,000; 5,778,000 fit
for military service; about 430,000 reach military age (20)
annually
Military budget: for fiscal year ending 28 February 1979,
$2.3 billion; about 20.7% of proposed central government
budget','7e816193155ad479397a55a2b2a1a5d3043b02aefe57e7e22dc1c730b59a35e1','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0669aee26765f73eeec929ed8b8b8cd9a3c597b2e630a3071ab77f148a7486c2',1971,'TV','Tuvalu','communications',8,'(formerly Ellice Islands)
NOTE: On October 1, 1975, by Constitutional Order, the
Ellice Islands were formally separated from the British
colony of Gilbert and Ellice Islands, thus forming the new
Pacific Ocean.
5 OBERT =
{ISLANDS °.°7.’
(Sas referesce map Vis)
colony of Tuvalu. The remaining islands in the former
Gilbert and Ellice Islands Colony were renamed the Gilbert
Islands.
The new colony of Tuvalu includes the islands of
Nanumanga, Nanumea, Nui, Niutao, Vaitupu, and those
islands claimed by the United States: Funafuti, Nukufetau,
Nukulailai, and Nurakita.
LAND
26 km*
WATER
Limits of territorial waters: 3 nm
Coastline: about 24 km
Railroads: none
Highways: 8 km gravel
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
211
Approved for Release: 2018/04/27 C06727040
teeta ey pied ater ee age','c6e4b7d483ed178badad0a15adba5ca0f06843585a1f60549b57d2f2cf1e95b2','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fa0b0a8cbbf27d298bd590be5bea7e71583a7bd279c6ea11858724972de274c',1971,'','','communications',5,'Railroads: 4,991 mi.; 4,940 mi. 4''8 1/2" gage, 51 mi. double track: 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. grave? or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 594,900 GRT, 826,600 DWT;
includes 12 passenger, 52 cargo, 11 tanker, 10 bulk, 2 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 123 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 22 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international radiocommunication and fair domestic
telecommunication services; 654,500 telephones; 3.94 million radio and 133,000
TV receivers; 39 AM, 2 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,707,000; 5,730,000 fit for military service;
about 402,000 reach military age (20) annual ly
78,000) ee navy 39,500, air force 54,600 (1,082 pilots), gendarmerie
75 ,000
Major ground units: 3 armies, 10 corps with corps troops, 13 infantry divisions,
2 mechanized divisions, 1 mechanized brigade, 1 armored division, 4 separate
armored brigades, 2 armored cavalry brigades, 4 infantry brigades, ] border
regiment, 34 battalions (22 artillery, 11 border, 1 on Cyprus), and 7
airborne/commando brigade; army aviation companies with about 5 aircraft
each are assigned to each army, corps, and division
Ships: 13 destroyers, 12 submarines, 71 patrol » 28 mine warfare, 60
amphibious craft, 40 auxiliary, 47 service
Aircraft: 1,252 including 437 (nonjet) in arny aviation, 15 (nonjet) in naval
air, 800 (605 jet) in air force
Missiles: 8 SAM squadrons (Nike Ajax/Hercules)
Supply: mostly dependent on foreign sources, primarily U.S., Canada, and West
Germany; manufactures some small arms, trucks and adequate quantities of
ammunition; builds some of its naval ships
448
““SECRE
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
_ SEsRET,
DEFENSE FORCES (cont''d):
Military budget: for fiscal year ending 28 February 1974, $792.8 million; about
16% of central government budget
INTELLIGENCE AND SECURITY:
National Intelligence Organization (MIT), including Turkish National Security
Service Directorate (TNSS), domestic/foreign; Turkish General Staff, J-2
Section, Intelligence Branch, domestic/foreign; Turkish National Polf
domestic; Ministry of Foreign Affairs, foreign; Gendarmerie, domestic
449
Approved for Release: 2018/04/27 C06727039','9d4a2b2fc51ea58b3df2ca018de5da87ff79463fa05f18e4af69d388d6b68cd4','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fd3fdc37c15164255aa2792fa7b8431634cd2348963d9da6774b0c54a0f668c',1971,'TH','Thailand','communications',6,'Railroads: 8,253 km standard gage (1.435 m); 143 km
double track; 72 km electrified
Highways: 60,000 km total; 21,000 km_ bituminous;
28,000 km gravel or crushed stone; 2,500 km improved
- earth; 8,500 km unimproved earth
Inland waterways: approx. 1,689 km
Pipelines: 1,288 km crude oil; 2,055 km refined products
Ports: 10 major, 35 minor
Merchant marine: 163 ships (1,000 GRT or over) totaling
1,251,300 GRT, 1,931,400 DWT; includes 12 passenger, 96
cargo, 1 liquefied gas, 22 tanker, 22 bulk, 7 specialized
carrier, 2 roll-on/roll-off cargo
* Civil air: 23 major transport aircraft, including 5 leased in
Airfields: 121 total, 102 usable; 58 with permanent-sur-
face runways; 3 with runways over 3,660 m, 25 with’
runways 2,440-3,659 m, 21 with runways 1,220-2,439 m
Telecommunications: good international, fair domestic
service; maintenance a continuing problem; radio relay
being expanded and improved; 1.1 million telephones (2.7
per 100 popl.); 40 AM, 4 FM, arid 36 TV stations; 1 coaxial
infantry brigades, 1 airborne brigade, 1 commando brigade,
3 mobile gendarmerie brigades, 3 regiments (2 infantry, 1
armored), 38 battalions (22 artillery, 11 border); each field
army has ] aviation regiment assigned and each corps has 1
aviation battalion
Ships: 12 destroyers, 2 frigates, 13 submarines, 48 patrol
craft, 32 mine warfare, 5 amphibious ships, 68 amphibious
craft, 45 auxiliary, 57 service
Aircraft: 1,169 (473 jet); 657 (473 jet) in air force, 493 in
army aviation, 19 in naval air
Missiles: 8 SAM squadrons (Nike Hercules with 72
launchers)
Supply: mostly dependent. on foreign sources, primarily
U.S., Canada, and West Germany; manufactures some small
arms, trucks and adequate quantities of ammunition; builds
some of its naval ships including submarines with technical
and material assistance
Military budget: for fiscal year ending 28 February 1979,
$2.6 billion; about 16% of proposed central government
budget
INTELLIGENCE AND SECURITY
Turkish National Intelligence Organization (TNIO), in-
cluding Turkish National Security Service Directorate
(TNSS), domestic/foreign; and Intelligence Directorate,
Turkish General Staff (J-2), domestic/foreign; Turkish
National Police, domestic; Ministry of Foreign Affairs,
NR Record
foreign; Gendarmerie, Intelligence Section, domestic
(b)(3)
t
submarine cable; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 10,072,000, 5,951,000
fit for military service; about 444,000 reach military age (20)
annually
Personnel: 485,000 army, 45,400 navy, 52,300 air force
(970 pilots), 100,000 gendarmerie
Major ground units: 4 armies, 10 corps with corps troops,
15 infantry divisions, 2 mechanized divisions, 6 separate
armored brigades, 4 mechanized infantry brigades, 5
246
NR Record
Approved for Release: 2018/04/27 C06727042','7ec7527a54654d9c673d4643867b755c16d415fdb00fd76cef3c3958e5b0d8a7','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78d9c9f45021c5a1b43933211b6930ecfbbb03241cc810d3b2b2faf8c83adf7d',1971,'','','communications',5,'Ratlroads: 4,991 mi.; 4,940 mi. 4''8 1/2” gage, 5] mi, double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 402 mi.; refined products, 1,277 mi.
Ports: 10 major, 35 minor
Merchant marine: 88 ships (1,000 GRT or over) totaling 596,300 GRT, 829,500 DWT;
includes 12 passenger, 52 cargo, 11 tanker, 11 bulk, 2 specialized carrier
Civil air: 17 major transport aircraft
Airfields: 119 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 18 with runways 8,000-11,999 ft., 25 with runways
4,000-7 ,999 ft.; 2 seaplane stations
Teleconmunications: excellent international radioconmunication and fair domestic
telecommunication services; 577,000 telephones; 3.1 million radio and 50,000
TV receivers; 39 AM, 2 FM, and 7 TV stations; communications satellite ground
station to be operational in 1972 .
DEFENSE FORCES:
Military manpower: males 15-49, 9,585,000; 5,655,000 fit for military service;
about 402,000 reach military age (20) annually
Personnel: army 375,000 navy 39,500, air force 54,600 (1,082 pilots),
gendarmerie 75,000 (S)
Major ground units: 3 armfes, 10 corps with corps troops, 13 infantry divisions,
2 mechanized divisions, 1 mechanized brigade, 1 armored division, 4 separate
armored brigades, 2 armored cavalry brigades, 4 infantry brigades, 2 regiments
(1 border, 1 armored cavalry), 32 battalions (20 artillery, 11 border, 1 on
Cyprus), and 1 commando brigade; army aviation companies with about 5 aircraft
each are assigned to each army, corps, and divisfon
438
Seca
‘Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
SECRET
DEFENSE FORCES (cont''d):
Ships: 15 destroyers, 1 destroyer escort, 16 submarines, 71 patrol craft, 33
mine warfare, 62 amphibious craft, 38 auxiliary, 47 service
Aircraft: 1,223 including 428 (nonjet) in army aviation, 4 (nonjet) in naval
air, 791 (602 jet) in air force
Missiles: 8 SAM squadrons (Nike Ajax/Hercules)
Supply: mostly dependent on foreign sources, primarfly U.S., Canada, and West
Germany; manufactures some smatl arms, tru adequate quantities of
ammunition; builds some of its naval ships
Military budget: for fiscal year ending 28 February 1973, $599.7 million;
about 19% of central government budget
INTELLIGENCE AND SECURITY:
National Intelligence Organization (MIT), including Turkish National Security
Service Directorate (TNSS), domes tic/foreign; Turkish General Staff, J-2
Section, Intelligence Branch, domestic/foreign; Turkish National Police,
domestic; Ministry of Foreign Affairs, foreign; Gendarmerie, domestic
439
Approved for Release: 2018/04/27 C06726997','c7a3c13800a7f80209df199f4e15cd31ac06b3366a1526781ce16a01816910d3','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ba9cc6d6713b5b75ef1068147ad2816b87ff63d8834807c7d08692af02d6566',1971,'','','communications',5,'Railroads: 6 mi. (single track) 5''O"-gage, government-owned spur of Soviet line
Highways: 10,740 mi.; 420 mi. concrete, 980 mi. bituminous surfaced, 2,100 mi.
gravel, 3,630 mi. improved earth, and 3,610 mi. unimproved earth
Inland waterways: total navigability 760 mi.; steamers use Amu Darya
Ports: only minor river ports
Civil air: 5 major transport aircraft
Airfields: 61 total, 33 usable; 9 with permanent-surface runways; 7 with runways
8,000-11,999 ft., 1] with runways 4,000-7,999 ft.
Telecommunications: limited telephone, telegraph, and radiobroadcast services,
barely sufficient to meet civil and military requirements; 10,000 telephones;
76,000 radio receivers; no TV receivers; 1 AM, no FM, no TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 21 March 1970, $30.4 million; 18.2%
of total budget; latest figures not available, but current budget believed
to be about the same
2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
oe en
y
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 20 ALBANIA
LAND:
11,100 sq. mi.; 19% arable, 24% other agricultural, 43%
forested, 14% other (1967)
Limits of territorial waters: 12 n. mi. (fishing, 12 n.
mi.)
Railroads: 127 mi. standard gage, single track; government owned (1971)
Highways: 3,100 mi.; 300 mi. paved, 1,200 mi. crushed stone and/or gravel, 1,600
mi. improved or unimproved earth (1970)
Inland waterways: 27 mi. plus Albanian sections of Lake Scutari, Lake Ohrid,
and Lake Prespa (1971)
Merchant marine: 11 cargo ships (1,000 GRT or over) totaling 54,000 GRT, 53,000
DWT
Pipelines: crude oi], 110 mi.
Civil air: no major transport aircraft (1970)
4
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 47 ALGERIA ra USSR
¢
EY.
rev gl
LAND: : za
950,000 sq. mi.; 3% cultivated, 16% pasture and meadows, T uae, sausi
1% forested, 80% desert, waste, or urban \\
Limits " territorial waters: 12 n. mi. (fishing 12 n.
mi.
ir
Railroads: 2,414 mi.; 1,660 mi. standard gage, 663 mi. 3''5 9/16" gage, 91 mi.
meter gage; 188 mi. electrified; 120 mi. double track
Highways: 40,600 mi., of which 17,000 mi. are concrete or bituminous and the
remainder gravel or crushed stone
Ports: 9 major, 8 minor
Merchant marine: 8 ships (1,000 GRT or over) totaling 62,000 GRT, 87,000 DWT;
includes 4 cargo, 1 tanker, 1 bulk, 2 specialized carrier
Pipelines: crude oi], 2,568 mi.; refined products, 177 mi.; natural gas, 494 mi.
Civil air: 16 major transport aircraft
Airfields: 233 total, 191 usable; 55 with permanent-surface runways; 17 with
runways 8,000-11,999 ft., 112 with runways 4,000-7,999 ft.; 3 seaplane
stations
Telecommunications: adequate domestic and international facilities in the north,
primarily radio communications in the desert; 169,000 telephones; 1,100,000
radio receivers; 250,000 TV receivers; 14 AM and 9 TV stations; 3 submarine
cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, $98,000,000;
approximately 5.5% of national budget
Approved For Release 2004/08731 : CIA-RDP79-01051A000400010001-2
r
”
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 9 ANDORRA
LAND:
180 sq. mi.
Railroads: none
Highways: about 60 mi.
Inland waterways: none
Ports: none
Civil air: no major transport aircraft
Airfields: none
Telecommunications: 2 AM and 1 FM radiobroadcast facilities, 1 TV repeater
station; manual telephone system serving about 1,700 telephones; 8,000
radio receivers, 2,500 TV receivers
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
DEFENSE FORCES: ; : :
Andorra has no defense forces; Spain and France are responsible for protection
as needed
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 59 ANGOLA
LAND:
481,000 sq. mi.; 1% cultivated, 44% forested, 22% meadows
and pastures, 33% other (including fallow) (1965)
Limits of territorial waters: Portuguese Foreign Office has
no es Navy claims 6 n. miles (fishing
12 n. mi.
Railroads: 1,918 mi.; 1,724 mi. 3''6" gage, 194 mi. 1''11 5/8" gage
Highways: 29,000 mi.; 3,000 mi. bituminous-surface treatment, 1,000 mi. crushed
stone or gravel, 25,000 mi. earth
Inland waterways: 2,000 mi. navigable
Ports: 3 major
Pipelines: crude oi], 171 mi.
Civil air: 12 major transport aircraft
Airfields: 447 total, 389 usable; 18 with permanent-surface runways; 1 with
runway over 12,000 ft., 5 with runways 8,000-11,999 ft., 53 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: simple network of low-capacity open-wire and radio-relay
facilities; 25,300 telephones; 95,000 radio receivers; 21 AM, 7 FM, and no
TV stations
DEFENSE FORCES:
Defense is responsibility of Portugal
Supply: dependent on Portugal
Military budget: for fiscal year ending 31 December 1969 $45.7 million; about
16.7% of total budget
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 81A ANTI GUA
LAND:
108 sq. mi.; 54% arable, 5% pasture, 14% forested,
9% unused but potentially productive, 18% wasteland
and built on (1964)
Limits of territorial waters: 3 n. mi.
Railroads: none
Highways: 235 mi.; 150 mi. main, 85 mi. secondary
Ports: 1 minor
Civil air: 5 major transport aircraft
Airfields: 3 total, 1 usable; 1 with asphalt runway 9,000 ft.; 1 seaplane
station
Telecommunications: new automatic telephone system recently installed; 1,450
telephones; tropospheric scatter links with Tortola and St. Lucia; 5,000
radio receivers, 1 AM and 2 TV stations; 2 coaxial submarine cables
12
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 90 ARGENTINA
LAND:
1,070,000 sq. mi.; 57% agricultural (11% crops, improved BRAZIL
pasture and fallow, 46% natural grazing land), 25%
forested, 18% mountain, urban, or waste (1968 est.)
Limits of territorial waters: 200 n. mi.
Railroads: 25,034 mi.; 2,053 mi. standard gage (4''8 1/2"), 14,215 mi. broad
gage (5''6") 8,018 mi. meter gage (3''3 3/8"), 388 mi. 2''5 1/2" gage, and
36 mi. narrow gage industrial; about 1,035 mi. double track; 76 mi. electrified;
99.6% government-owned
Highways: 125,000 mi., of which 13,800 mi. paved, 16,000 mi. gravel, 49,300
mi. improved earth, and 46,000 mi. unimproved earth
Inland waterways: 6,800 navigable mi.
Ports: 7 major, 65 minor
Merchant marine: 177 ships (1,000 GRT or over) totaling 1,179,000 GRT,
1,614,000 DWT; includes 6 passenger, 98 cargo, 60 tanker, 9 bulk;
4 specialized carriers; 3 tankers and 4 combination cargo-transport ships
are naval vessels sometimes used commercially
Pipelines: crude oil, 1,163 mi.; refined products 1,374 mi.; natural
gas, 4,061 mi.
Civil air: 66 major transport aircraft
Airfields: 2,078 total, 1,542 usable; 64 with permanent-surface runways;
1 with runway over 12,000 ft., 12 with runways 8,000-11,999 ft., 232 with
runways 4,000-7,999 ft.; 10 seaplane stations
Telecommunications: foremost in telecom facilities in South America; improving
telephone network has slightly over 1.6 million sets, radio relay widely
used, communications satellite ground station; estimated 10 million radio
receivers and 3.3 million TV sets; 116 AM, 4 FM, and 3] TV stations;
8 telegraph submarine cables
DEFENSE FORCES:
Supply: produces some weapons, ammunition, and motor transport; past
dependence upon U.S., Canada, and Western Europe being shifted almost
exclusively to Europe
Military budget: proposed for fiscal year ending 31 December 1970,
$514,150,000 about 15% of total central government budget
14
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 16 AUSTRIA
LAND:
32,400 sq. mi.; 20% cultivated, 27% meadows and pastures,
14% ee or urban, 38% forested, 1% inland water
(1968','b47f03f7b1fcacf28a4cf48fd8da2c4eebc1bc646418184fd93f64ade9efcefc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d34a7f80b43e88e1b1fb18bfc81987b3903c6e69b091eee042cdd4141fa8112',1971,'DZ','Algeria','communications',19,'Railroads: 4,073 mi.; 3,612 mi. standard gage, 433 mi. 2''5 7/8" gage, and 28 mi.
3''3 3/8" narrow gage; 833 mi. double tracked; 1,612 mi. electrified
Highways: 20,356 mi. total; 6,056 mi. Federal (5,656 mi. bituminous, concrete,
stone block, 400 mi. crushed stone, gravel, improved earth); 14,300 mi.
Provincial (4,340 mi. bituminous, concrete, stone block, 9,950 mi. crushed
stone, gravel, improved earth); additionally about 38,000 mi. of communal
roads, mostly of gravel, crushed stone, and improved earth
Inland waterways: 267 mi.; carries 5% freight, 6% passengers
Ports: 3 major
Merchant marine: 4 ships (1000 GRT or over) totaling 12,900 GRT, 17,000 DWT;
includes 3 cargo, 1 specialized carrier
Pipelines: crude oi1, 450 mi.; natural gas, 535 mi.
Civil air: 10 major transport aircraft
Airfields: 58 total, 47 usable; 1] with permanent-surface runways; 2 with run-
ways 8,000-11,999 ft., 8 with runways 4,000-7,999 ft.
Telecommunications: highly developed and efficient; excellent national and
international services; extensive TV and radiobroadcast systems with 13 AM,
14 FM, and 19 TV stations; 1.33 million telephones; 2 million radio receivers;
1.38 million television receivers
DEFENSE FORCES:
Major ground units: 7 brigades (4 infantry, 3 armored infantry), 3 artillery
regiments (battalion-size), 3 armored battalions, 1 infantry battalion,
4 engineer battalions, 3 antiaircraft battalions, 1 reconnaissance battalion
Supply: produces some small arms and anmunition, trucks, and tank destroyers;
current sources of other items are the U.S., Western Europe, Sweden,
and the Communist countries
Military budget: for fiscal year ending 31 December 1971, $165.3 millions; about
3.9% of the federal budget and 1.2% of GNP
18
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 81B BAHAMAS
LAND:
4,400 sq. mi.; 1% cultivated, 29% forested, 70% built
on, wasteland, and other (1962)
Limits of territorial waters: 3 n. mi. (fishing, 12
n. mi.)
a
VENEZUELA
PEOPLE A COLOMBIA
Population: 176,000, average annual growth rate 3.4%
(November 63-April 70) :
Ethnic divisions: 80% Negro, 10% white, 10% mixed nasi
Religion: mainly Church of England; some Protestant,
Greek Orthodox, and Roman Catholic
Language: English
Labor force: 60,000 (1963)
Railroads: none
Highways: 555 mi.; 380 mi. paved, 100 mi. gravel, 20 mi. improved earth; 55 mi.
unimproved earth
Ports: 5 major, 9 minor
Civil air: no major transport aircraft
Airfields: 56 total, 51 usable; 8 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 21 with runways 4,000-7,999 ft.; 4 seaplane
stations .
19
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Telecommunications: telecom facilities highly developed, including 53,800 =
telephones in totally automatic system, tropospheric scatter link with .
Florida; 55,000 radio receivers and 16,000 TV sets, 1 AM station; 2 special =
coaxial submarine cables; plan TV station for color broadcasts and new cable
connection with the United States
20
LS eS ELOISE ET ND ET OTN ET TT TE AE A a oa EE LE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 32 BAHRAIN
LAND:
230 sq. mi. plus group of smaller islands; 5% cultivated,
negligible forested area, remainder desert, waste,
or urban
Limits of territorial waters: not available
Highways: 120 mi. surfaced; undetermined mileage of natural surface tracks
Ports: 1 major
Pipelines: crude oil, 68 mi.; refined products, 8] mi.; natural gas, 18 mi.
Civil air: 7 major transport aircraft (all registered in the U.K.)
Airfields: 5 total, 3 usable; 1 with permanent-surface runway; 2 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent international radiocommunications; limited
domestic services; 10,800 telephones; 56,500 radio receivers; 10,000 TV sets;
1 AM radiobroadcast station; satellite earth station; tropospheric scatter
Bahrain-Qatar
2]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 81E BARBADOS
LAND:
166 sq. mi.; 60% cropped, 10% permanent meadows, 30% built
on, waste, other (1960)
Limits of territorial waters: 3 n. mi.
PEOPLE: VENEZUELA
Population: 257,000, average annual growth rate 0.8% (FY68-
69); males 15-49, 63,000; 45,000 fit for military COLOMBIA
service; average number reaching military age annually,
3,000 : } BRAZIL
Ethnic divisions: 80% African, 15% mixed, 5% European Hoes,
Religion: Anglican, Roman Catholic, Methodist, and Moravian
Language: English
Literacy: over 90%
Labor force: 60,000 wage and salary earners
Organized labor: 19,300 (32%)
Railroads: 2,873 mi.; 2,645 mi. standard gage, 228 mi. (3''3 3/8") narrow gage;
1,615 mi. double track; 920 mi. electrified
Highways: 57,700 mi.; 26,550 mi. bituminous, stone block, or concrete; 31,150
mi. crushed stone, gravel, earth
Inland waterways: 1,270 mi., of which 950 are in regular use by commercial
transport
Ports: 5 major, 1 minor 5
Merchant marine: 76 ships (1,000 GRT or over) totaling 1,028,000 GRT, 1,546,000
DWT; includes 1 passenger, 49 cargo, 13 tanker, 13 bulk
Pipelines: refined products, 400 mi.; crude, 31 mi.; natural gas, 45 mi.
Civil air: 54 major transport aircraft, including 6 based in Libya
Airfields: 50 total, 36 usable; 19 with permanent-surface runways; 12 with _
- runways 8,000-11,999 ft., 6 with runways 4,000-7,999 ft.
Telecommunications: excellent domestic and international telephone and
telegraph facilities; 1,937,000 telephones; 3.2 million radio receivers; 2.1 ;
million TY receivers; countrywide broadcast coverage provided by 7 AM,
10 FM, and 18 TV stations; submarine cables to United Kingdom and to Portugal
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $675.2 million; about
8.3% of total budget
Pep
26 ~
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 81B BERMUDA
LAND:
21 sq. mi.; 8% arable, 60% forested, 21% built on, se
wasteland, and other, 11% leased for air and CANADA
naval bases (1964)
Limits of territorial waters: 3 n. mi.
ry
NITED STATES
Railroads: none
Highways: 130 mi., all paved
Ports: 4 major
Civil air: no major transport aircraft
Airfields: 1 with concrete runway 9,660 ft.; 1 seaplane station
Telecommunications: modern telecom system suited to island needs, includes
fully automatic telephone system with 28,100 instruments; 29,000 radio and
Lah TV receivers, 2 AM, 1 FM, and 2 TV stations; 2 submarine coaxial
cables
27
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 35 BHUTAN
19,000 sq. mi.; 15% agricultural; 15% desert, waste, AFGHAN
wilon/)
urban; 70% forested (1963)
Highways: 810 mi.3; 260 mi. surfaced, 320 mi. improved, 230 mi. unimproved
earth
Freight carried: not available, very light traffic
29
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Civil air: no major transport aircraft
Airfields: 1 composite runway under 6,000 feet
Telecommunications: facilities almost nonexistent; data not available on
telephones; 6,000 radio sets; no TV sets; data not available on AM; no
FM; and no TV stations
DEFENSE FORCES:
Supply: dependent on India
30
SL a IE aE EE TE Ta SC OE NT ML TT Pe a TSE ED
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 93 BOLIVIA
LAND:
424,000 sq. mi.; 2% cultivated and fallow, 11% pasture BRAZIL
and meadow, 45% urban, desert, waste, or other,
40% forest (1967)
Railroads: 2,310 mi., single track; 2,290 mi., meter gage, 20 mi., 2''6" gage;
all government owned except 60 mi. of meter-gage track; 5.6 mi. of meter-
gage track electrified
Highways: 15,000 mi.; 500 mi. paved, 3,500 mi. gravel, 5,000 mi. improved
earth, 6,000 mi. unimproved earth
Inland waterways: officially estimated to be 6,250 mi. of commercially
navigable waterways
Pipelines: crude oi], 1,044 mi.; refined products and crude 888 mi.; natural gas
20 mi.
Ports: none (Bolivian cargo moved through Arica and Antofagasta, Chile, and
Matarani, Peru)
Civil air: 31 major transport aircraft
Airfields: 456 total, 391 usable; 3 with permanent-surface runways; | with
runway over 12,000 ft., 3 with runways 8,000-11,999 ft., 81 with runways
4,000-7,999 ft.
Telecommunications: poorest telecom facilities on continent with local and
intercity networks needing rehabilitation; almost 38,000 telephones; est.
750,000 radio and 1,000 TY receivers; 1 TV, 72 AM, and 6 FM stations;
long-range improvement plans revised and partly implemented
DEFENSE FORCES:
Supply: totally dependent on foreign sources (primarily U.S.)
Military budget: proposed for fiscal year ending 31 December 1971, $15.9 million;
about 9% of proposed central government budget
32
eal
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
“&
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 61 BOTSWANA
LAND:
220,000 sq. mi.; about 6% arable, less than 1% under
cultivation, mostly desert (1970)
Railroads: 400 mi. 3''6" gage, single track; owned and operated by the Rhodesia
Railroads
Highways: 5,016 mi.; 16 mi. paved, 471 mi. crushed stone, gravel, or stabilized
soil; 4,529 mi. improved or unimproved earth
Inland waterways: native craft only; of local importance
Civil air: 12 major transport aircraft
Airfields: 69 total, 58 usable; 2 with permanent-surface runways; 16 with
runways 4,000-7,999 ft. “)
Telecommunications: the system is a minimal combination of a single main wire
line and a few radiocommunication stations; Gaberone is the center; 3,500
telephones; 20,000 radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Police only
34
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 94 BRAZIL
LAND:
3,290,000 sq. mi.; 4% cultivated, 14% pastures, 14%
waste, urban, or other, 13% fallow, idle, or
woodlot, 55% forested (1970)
Limits of territorial waters: 200 n. mi.
Railroads: 19,893 mi.; 17,552 mi. 3''3 3/8" gage, 2,082 mi. 5''3" gage, 121 mi.
4''8 1/2" gage, 139 mi. narrow gages; 1,522 mi. electrified
Highways: 583,800 mi.; 26,300 mi. paved, 36,700 mi. gravel, and 520,800 mi. of
improved and unimproved earth
Inland waterways: 31,000 mi. navigable
Ports: 6 major, 24 minor
Pipelines: crude oi], 633 mi.; refined products, 139 mi.; natural gas, 24 mi.
Merchant marine: 207 ships (1,000 GRT or over) totaling 1,402,000 GRT, 2,071,000
DWT; includes 2 passenger, 131 cargo, 45 tanker, 22 bulk, 7 specialized
carrier; includes 3 naval tankers sometimes used commercially
Civil air: 125 major transport aircraft
Airfields: 2,377 total, 2,082 usable; 111 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 308 with runways 4,000-7,999 ft.; 18 seaplane
stations
Telecommunications: extensive telecom facility expansion programs; radio relay
widely used; communications satellite ground station; almost 1.8 million
telephones; est. 10.5 million radio and 6 million TV receivers; 850 AM,
145 FM, and 50 TV stations (plus relays); 10 telegraph submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1969, $736,339,520; 19.5%
of federal budget
36
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
atl
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 72 BRITISH HONDURAS
LAND:
8,870 sq. mi.; 38% agricultural (5% cultivated), 46%
exploitable forest, 16% urban, waste, water,
offshore islands or other (1966)
Limits of territorial waters: 3 n. mi.
%
VENEZUELA
PEOPLE: covoMer
Population: 124,000, average annual growth rate 2.9%
(April 60-70); males 15-49, 27,000; 16,000 fit for
military service; 1,500 reach military age (18) eit
annually
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerindian,
8% other
Religion: 50% Roman Catholic; Anglican, Seventh-day Adventist, Methodist,
Baptist, Jehovah''s Witnesses, Mennonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 26,000; 41% agriculture, 19% manufacturing, 8% commerce,
12% construction and transportation, 20% services; shortage of skilled
labor and all types of technical personnel; over 15% are unemployed
Organized labor: 8% of labor force
Railroads: 6 mi. narrow gage (2'')
Highways: 750 mi.; 110 mi. paved (bituminous treated), 220 mi. gravel or stone,
420 mi. unimproved
Inland waterways: 130 mi.; navigable by shallow-draft craft
Ports: 2 minor (Bandar Ser Begawan, formerly Brunei, and Kuala Belait)
39
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Pipelines: crude oi], 84 mi.; refined products, 35 mi.; natural gas, 35 mi.;
crude oi] and natural gas, 150 mi. under construction
Civil air: no major transport aircraft
Airfields: 4 total, 3 usable; 1 with permanent-surface runway; 2 with runways
4,000-7,999 ft.
Telecommunications: service throughout country is adequate for present needs;
international service good to adjacent Sabah and Sarawak; radiobroadcast
coverage good; 3,819 telephones; 13,000 radio sets; Radio Brunei «
broadcasts from 3 stations and uses 4 mediunmwave and 1 shortwave
transmitter
DEFENSE FORCES:
Defense is responsibility of U.K.; Brunei has an indigenous military force of 7
about 1,150; about 1,100 police are maintained ;
Military budget: for fiscal year ending 31 December 1970, $9.8 million for the
military and $7.1 million for the police; about 15% of the total budget
40
PLE NT aL a a a IL LT a LE a RL Le PE LT WT eR aE EE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 23 BULGARIA
LAND:
42,800 sq. mi.; 41% arable, 11% other agricultural,
33% forested, 15% other (1966)
Limits of territorial waters: 12 n. mi.
Railroads: 2,592 mi.; about 2,432 mi. standard gage, 160 mi. narrow gage; 116 mi.
double track; 477 mi. electrified; government owned (1971)
Highways: 20,700 mi.; 7,900 mi. paved, 8,100 mi. crushed stone and gravel,
4,700 mi. earth (1971)
Inland waterways: 300 mi. (1971)
Freight carried: rai] -- 69 million short tons, 9 billion short ton/mi. (1969);
highway -- 464.2 million short tons, 4.5 billion short ton/mi. (1969);
waterway -- 4.1] million short tons, 1.2 billion short ton/mi. (1970)
Merchant marine: 107 ships (1,000 GRT and over) totaling 655,000 GRT, 950,000
DWT; includes 5 passenger, 84 cargo, 18 tanker
Pipelines: crude oi], 4] mi.; natural gas, 29 mi.; refined, 3 mi.
42
a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 38
LAND:
Railroads: 1,956 mi.; 195 mi. double track; government owned
Highways: 15,540 mi.; 4,210 mi. paved, 4,770 mi. gravel, 5,810 improved earth,
750 mi. unimproved earth
Inland waterways: 8,000 mi.; 2,000 mi. navigable by large commercial vessels
Ports: 4 major, 6 minor
Merchant marine: 9 cargo ships (1,000 GRT or over) totaling 56,000 GRT, 71,000
DWT
Airfields: 118 total, 83 usable; 20 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 35 with runways 4,000-7,999 ft.; 2 seaplane -
stations
Telecommunications: provide minimum requirements for local intercity service;
international service is fair; radiobroadcast coverage is limited to the
more populous areas; 24,654 telephones; 500,000 radio sets; 1 AM, 1 FM,
and no TV stations
DEFENSE FORCES:
Supply: very limited local production; various non-Communist countries suppliers;
naval vessels from U.K., U.S., Yugoslavia, and Japan
Military budget: for fiscal year ending 30 September 1971; $126 million, an
estimated 35% of total budget
44
LT LAE aL aE a ae a a LE EE ee ETT a a aa eee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 60B BURUNDI
LAND:
Railroads: none Be
Highways: 3,700 mi.; 45 mi. bituminous, 3,655 mi. crushed stone, gravel, laterite,
and improved or unimproved earth
Inland waterways: Lake Tanganyika navigable for lake steamers and barges
Ports: ] minor
Civil air: no major transport aircraft
Airfields: 32 total, 22 usable; 1 with permanent-surface runway; |] with runway
8,000-11 ,999 ft.
Telecommunications: telegraph is principal service, limited telephones; 3,400
telephones, 65,000 radio receivers; 2 AM, 1 FM, and no TV stations
\\¢
DEFENSE FORCES:
Military budget: for fiscal year ending December 1970, $3,428,000; about 14.4% of Q
ordinary budget
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 43A CAMBODIA
69,898 sq. mi.; 16% cultivated, 74% forested, 10% built-on
area, wasteland, and other (1958)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: 409 mi. meter gage; government owned
Highways: 3,340 mi.; 1,600 mi. bituminous, 1,000 mi. crushed stone, gravel, or
laterite; 275 mi. improved earth; and 6,465 mi. unimproved earth
Inland waterways: 1,220 mi. during high water, 1,010 mi. during low water;
90% of total navigability on Mekong system and Tonle Sap
Freight carried: (1968) rail -- 50 million ton-miles; waterway -- approximately
300,000 short tons annually; figures unavailable for highways
Ports: 2 major, 6 minor
Merchant marine: 4 ships (1,000 GRT or over) totaling 4,000 GRT, 6,400 DHT;
includes 3 cargo, | tanker
Airfields: 93 total, 46 usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 14 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: service to general public considered poor; barely adequate
for government requirements; international service fair to adjoining countries a
and a few other nations; radiobroadcasts and television coverage limited by
small number of stations and receivers; 8,024 (est.) telephones; 102,500
radio receivers; 25,000 (est.) TV receivers; 1 AM, 2 AM relay, no FM, 1 TV,
and 1 TV relay stations; no submarine cables
48
a I a a ea a OE cee hn See he a ak a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 52C CAMEROON
LAND:
183,400 sq. mi.; 4% cultivated, 18% grazing, 13% fallow,
50% forest, 15% other (1964)
Limits of territorial waters: 18 n. mi. (fishing, 18 n. mi.)
Railroads: 623 mi.; 533 mi. meter gage, 90 mi. 1''11 5/8" gage
Highways: approximately 8,545 mi.; 765 mi. BST, 7,780 mi. gravel, laterite, or
improved earth
Inland waterways: 1,300 mi.
Ports: 1 major, 3 minor
Civil air: 4 major transport aircraft
Airfields: 59 total, 55 usable; 5 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: good telephone service between Douala and Yaounde, fair in
southern part; fair to good telegraph service; 5,800 telephones; 211,500
radio receivers; 4 AM, no FM, and no TY stations; limited wired broadcast;
1 submarine cable
DEFENSE FORCES:
Supply: mostly from France
Military budget: for fiscal year ending 30 June 1971, $20.9 million; 18.0% of 7
total budget
50
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 52B CENTRAL AFRICAN REPUBLIC
LAND:
242,000 sq. mi.; est. 10%-15% cultivated, 5% dense forests,
80-85% grazing, fallow, vacant arable land, urban,
waste (1966)
Railroads: none +
Highways: 13,250 mi.; 50 mi. bituminous, 2,330 mi. gravel and/or crushed stone,
3,420 mi. improved earth, 7,450 mi. unimproved earth
Inland waterways: 4,400 mi.; traditional trade carried on by means of dugouts
on the extensive system of rivers and streams; only the Oubangui River
between Bangui and Brazzaville and short sections of the Sangha and the as
Lobaye Rivers are navigable throughout year; during high-water period :
(July - December) Oubangui navigable upstream from Bangui as far as Ouango
Port: Bangui (river port)
Civil air: 4 major transport aircraft
Airfields: 60 total, 47 usable; 3 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 17 with runways 4,000-7,999 ft.
Telecommunications: facilities are meager and provide only barely sufficient
services; principal network is 39 low-capacity, low-powered radiocommunica-
tion stations; no cables or radio relay links are used; single center of
Bangui has only international radio connections; 3,500 telephones; 46,000
radio receivers; 1 AM, 1 FM, and no TV stations 5
DEFENSE FORCES:
Supply: completely dependent on France
Military budget: for fiscal year ending 31 December 1970, $4,878,000; about
11.2% of ordinary budget
54
SE PTS EES gE SE EI Le A ST ae ae
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 37 CEYLON
LAND:
25,300 sq. mi.; 23% arable; 20% desert, waste, or urban;
54% forested; 3% inland water (1968)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: 938 mi.; 851 mi. 5''6" gage, 87 mi. 2''6" gage; 63 mi. double track;
no electrification; government owned z
Highways: 25,580 mi.; 11,700 mi. paved (mostly bituminous treated), 11,500 mi.
crushed stone or gravel, 530 mi. improved earth, 1,850 mi. unimproved earth;
in addition several thousand mi. of tracks, mostly unmotorable
Inland waterways: 270 mi.; navigable by shallow-draft craft
Ports: 3 major, 9 minor
Airfields: 17 total, 13 usable; 13 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: an inadequate telephone and a less extensive but more
efficient telegraph system serves most areas, with greatest concentration
around Colombo and Kandy; all areas are served by radio and/or wire
broadcast; excellent international service; 60,84] telephones; 500,000 radio
sets, no TV sets; 1 AM (plus 4 repeater stations), no FM, and no TV stations;
submarine cables extend to India, Malaysia, Seychelle Islands, and Aden
56
TL ae a ee Eee aT eT I a a ee ae a SAR a ET ee Se Oe
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 52A CHAD
LAND:
496,000 sq. mi.; 17% arable, 35% pastureland, 2% forest
and scrub, 46% other uses and waste (1967)
Railroads: none
Highways: 19,200 mi.; 160 mi. bituminous, 3,300 mi. gravel and laterite, and
15,740 mi. unimproved
Inland waterways: approximately 1,300 mi. of year-round navigability, increased
to 3,000 mi. during high-water period
Civil air: 2 major transport aircraft
Airfields: 64 total, 56 usable; 5 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 17 with runways 4,000-7,999 ft.
Telecommunications: fair system of radiocommunication stations only for intercity
links; principal center Fort-Lamy, secondary center Fort-Archambault; 4,200
telephones; 60,000 radio receivers; 1 AM, 1 FM, and no TV stations
ea
58
SLES LL ee TE a a a a a NEN a LE aI I EL ee ea a a:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major industries: copper, nitrates, foodstuffs, fish processing, textiles and
apparel, iron and steel, pulp and paper
Crude steel: 0.7 million metric tons capacity (1967); 0.6 million metric tons
produced (1967), 70 kg. per capita
Electric power: 2.55 million kw. capacity (1970 est.); 8.9 billion kw.-hr.
produced (1970 est.); 909 kw.-hr. per capita
Exports: $1,144 million','803ec3cdc8f0a337835729e8f8953a8de32e6ec0f514a81112fec8af0b21c3bd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2867f0e7757d1cc538e5b5083b3752c424115e8380d28ff913ab6ec1493dd175',1971,'DZ','Algeria','communications',20,'(f.o.b., 1970 prov.); copper, nitrates, iron
Imports: $1,020 million (c.i.f., 1970 est.); machinery and equipment, chemicals,
t
petroleum, foodstuffs
Major trade partners: exports -- EEC 32%, U.K. 15%, U.S. 22%, Japan 13%, LAFTA
10%; imports -- U.S. 38%, EEC 19%, U.K. 6%, LAFTA 26% (1968)
Aid:
economic -- extensions from U.S. (FY46-69) -- $1,569.2 million ($1,368.5
million loans, $200.7 million grants); from international organizations °
(FY46-68) -- $441.0 million (of which IBRD $201.8 million, IDB $176.4
million); from other Western countries (1960-66) -- $170.6 million; from
Communist countries (1967-69) -- $60.0 million;
military (FY46-69) -- from U.S., $14.1 million in loans, $128.2 million in
grants
Monetary conversion rate: 14.35 escudos=US$1 nontrade (broker) rate; 12.2
escudos=US$1 trade rate (31 July 1970)
Fiscal year: calendar year
Railroads: 5,090 mi.; 1,930 mi. 5''6" gage, 230 mi. 4''& 1/2" gage, 200 mi. 3''6"
gage, 2,590 mi. 3''3 3/8" gage, 80 mi. 2''6" gage, 60 mi. 1''11 5/8" gage,
133 mi. double track; 437 mi. electrified
Highways: 40,000 mi.; 4,600 mi. paved, 19,900 mi. gravel, 15,500 mi. improved
and unimproved earth
Inland waterways: 451 mi.
Pipelines: crude oi], 380 mi.; refined products, 510 mi., natural gas, 200 mi.
Ports: 10 major, 20 minor
Merchant marine: 48 ships (1,000 GRT or over) totaling 363,000 GRT, 524,000 DwWT;
includes 2 passenger, 30 cargo, 6 tanker, 9 bulk, 1 specialized carrier;
includes 2 naval tankers and 1 transport sometimes used commercially
Civil air: 56 major transport aircraft
Airfields: 413 total, 302 usable; 40 with permanent-surface runways; 3 with run-
ways 8,000-11,999 ft., 54 with runways 4,000-7,999 ft.; 7 seaplane stations
Telecommunications: extensive radio relay network under construction; telephone
network modern but with only 349,000 instruments; communications satellite
ground station; est. 2.5 trillion radio and 500,000 TV receivers, 137 AM,
30 FM, and 15 TV stations
—
60
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 89 CHILE
LAND:
286,000 sq. mi; 2% cultivated, 7% other arable, 152
permanent pasture, grazing, 29% forest, 47% barren
mountains, deserts, and cities (1965)
Limits of territorial waters: 27 n. mi. (50 km.)
t (fishing, 200 n. mi.)
Railroads: 2,823 mi., all narrow gage; 130 mi. double track; 623 mi. government
owned, 2,200 mi. industrial
Highways: 10,300 mi. plus 300 mi. on Penghu and offshore islands; 3,300 mi. paved,
5,000 mi. gravel and crushed stone, 2,000 mi. earth
Ports: 7 major, 9 minor
Merchant marine: 143 ships (1,000 GRT or over) totaling 193,000 GRT, 248,000
DWT; includes 2 passenger, 109 cargo, 11 tanker, 14 bulk, 7 specialized
carrier
64
a nn 7 TR CN a aS Ro Sa A a i ek ie Se i aaa
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 85 COLOMBIA
LAND:
Railroads: 2,160 mi., all 3''0" gage, single track, 22 mi. electrified
Highways: 28,600 mi.; 3,700 mi. paved, 19,900 mi. crushed stone or gravel,
3,100 mi. improved earth, 1,900 mi. unimproved earth
Inland waterways: 8,900 mi., navigable by river boats
Pipelines: crude oi], 2,000 mi.; refined products, 828 mi.; natural gas, 3/70 mi.3
natural gas liquids 83 mi.
Ports: 5 major, 5 minor
Merchant marine: 36 ships (1,000 GRT or over) totaling 193,000 GRT, 248,000 DWT;
33 cargo, 3 tanker (includes 2 naval tankers sometimes used comercially)
Civil air: 85 major transport aircraft
Airfields: 677 total, 570 usable; 27 with permanent-surface runways; 1 with
runway over 12,000 ft.; 6 with runways 8,000-11,999 ft., 73 with runways
4,000-7,999 ft.; 11 seaplane stations
Telecommunications: rapidly improving nationwide telecom system, with UHF relay
system being installed; communications satellite ground station; over 545 ,000
telephones; est. 6 million radio and 730,000 TV receivers, 253 AM, 132 FM,
and 16 TV stations
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1971, $89.4 million;
about 10.2% of central government budget
66
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 52E CONGO (BRAZZAVILLE)
LAND:
135,000 sq. mi.; 63% dense forest or woodland, 33%
cultivable or grazing (est. 2% cultivated), 4% urban
or waste (1970)
Limits of territorial waters: 3 n. mi. (fishing, 3 n. mi.)
Railroads: 490 mi., 3''6" gage, single track
Inland waterways: 4,030 mi. navigable
Ports: 1 major
Civil air: 6 major transport aircraft
Airfields: 63 total, 48 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 14 with runways 4,000-7 ,999 ft.; 1 seaplane station
Telecommunications: all services only fair; barely adequate for government and
public; principal network is comprised of 30 low-capacity, low-powered radio
communication stations; few wire lines connect key centers of Brazzaville,
Pointe-Noire, and Dolisie with maximum of 21 channels; 9,800 telephones;
65,000 radio receivers; 1,800 TV receivers; 3 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Supply: former dependence on France replaced by U.S.S.R. and Communist China
Military budget: for fiscal year ending 31 December 1969, $9,235,000; about
14.8% of total budget
see?
68
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
he -
2 Lan ting ioe Bee
ELT TTTT TAT AO BERLE LS LNT TE TE Ee EE EL SE ET CT ey ee Ee A ET
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 60A CONGO (KINSHASA)
LAND:
905,000 sq. mi.; 22% agricultural land (1% cultivated),
45% forested, 33% other (1971)
Limits of territorial waters: 3 n. mi.
Railroads: none
Highways: 5,050 mi.; 2,010 mi. bituminous surface treated; 3,040 mi. gravel,
crushed stone, and earth
Ports: 3 major, 6 minor
Merchant marine: 255 ships (1,000 GRT or over) totaling 1,497,000 GRT, 2,134,000
DWT; includes 9 passenger, 214 cargo, 9 tanker, 23 bulk; all but a few are
owned and operated by Greek nationals
Civil air: 8 major transport aircraft
Airfields: 19 total, 12 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft.; 3 with runways 4,000-7,999 ft.
Telecomnunications: modest but expanding telecommunication system; 42,500
telephones; 150,000 radio receivers; 45,800 TV receivers; 2 TV, 11 AM, and
4 FM stations; tropospheric scatter to Europe
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $7.5 million about
9.7% of central government budget
76
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
te
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 18 CZECHOSLOVAKIA
LAND:
49,400 sq. mi.; 42% arable, 14% other agricultural, 35%
forested, 9% other (1968)
Railroads: 8,269 mi.; 8,089 mi. standard gage, 70 mi. broad gage, 110 mi. narrow a
gage; 1,743 mi. double track; 1,483 mi. electrified; government owned (1969)
Highways: 45,500 mi.; 600 mi. concrete; 20,700 mi. bituminous; 2,400 mi.
cobblestone, brick sett, stone block: 21,800 mi. crushed stone, gravel,
improved earth (1971)
Inland waterways: 517 mi. (1971)
Pipelines: crude oil, 900 mi.; refined products, 535 mi.; natural gas, 1,450 mi.
Freight carried: rail -- 261.2 million short tons, 41.8 billion short ton/mi. ae
(1969); highway -- 711.7 million short tons, 6.2 billion short ton/mi. (1969);
waterway -- 4.9 million short tons, 1.7 billion short ton/mi. (1969) :
Ports: no maritime ports; outlets are Gdynia, Gdansk, Stettin in Poland; Rijeka, =
Yugoslavia; Hamburg, West Germany; Rostock, East Germany; principal river
ports are Prague, Melnik, Usti nad Labem, Decin, Komarno, Bratislava (1970)
Merchant marine: 12 cargo ships (1,000 GRT or over) totaling 98,000 GRT,
140,000 OWT
78
ere rn ae etn
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50M DAHOMEY
44,700 sq. mi.; southern third of country is most fertile;
arable land 80% (actually cultivated 11%), forests and
game preserves 19%, non-arable 1% (1968)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: 360 mi., all meter gage (3''3 3/8")
Highways: 4,300 mi.; 470 mi. paved, 1,670 mi. otherwise improved earth, 2,160
mi. unimproved
Inland waterways: 400 mi. navigable
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
Airfields: 1] total, 10 usable; 1 with permanent-surface runway; 3 with runways
4 ,000-7,999 ft.
Telecommunications: telephone service concentrated in south; telegraph limited,
but more extensive than telephone; 4,800 telephones; 54,000 radio receivers;
2 AM, no FM, and no TV stations; 3 submarine cables
DEFENSE FORCES:
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1969, $4,399,000; about
12.4% of total budget
80
LUT N PRAE SE NLR a a ET a ee a eT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 7 DENMARK
LAND:
16,600 sq. mi. (exclusive of Greenland and Faeroe Islands) ;
64% arable, 8% meadows and pastures, 11% forested, 17%
other (1966)
Limits of territorial waters: 3n. mi. (fishing, 12 n. mi.)
Railroads: 2,424 total route miles; Danish State Railways (DSB) own 1,497 route
miles of standard gage (4''8 1/2") and 25 route miles of meter gage (3''3 3/8"),
449 mi. double track, 41 mi. electrified; remaining 902 route miles of
standard gage lines are privately owned and operated
Highways: 38,275 mi.; 31,205 mi. concrete, bitumen, or stone block; 5,640 mi.
gravel and crushed stone; 1,430 mi. improved earth
Inland waterways: 259 mi.
Pipelines: refined products, 202 mi.
Ports: 16 major, 42 minor
Merchant marine: 292 ships (1,000 GRT or over) totaling 2,944,000 GRT, 4,625,000
DWT; includes 11 passenger, 193 cargo, 41 tanker, 19 bulk, 28 specialized
carrier
Civil air: 60 major transport aircraft (including 2 based in Greenland)
Airfields: 110 total, 97 usable; 15 with permanent-surface runways; 8 with run-
ways 8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent telephone, telegraph, and broadcast services; major
relay point for international telecom traffic; 1,600,000 telephones; 1,517,133
radiobroadcast receivers; 1,340,563 TV receivers; 7 AM, 10 FM, and 20 TV
stations; 20 submarine cables
DEFENSE FORCES:
Supply: dependent on U.S., Canada, U.K., and Western Europe; most naval craft
produced domestically
Military budget: for fiscal year ending 31 March 1972, $398 million; about 7.2%
of central government budget
82
a Sok aa he a eT uate Daal
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
fe ote
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 81A DOMINICA
LAND:
305 sq. mi.; 24% arable, 2% pasture, 67% forests, 7%
other (1966)
Limits of territorial waters: 3 n. mi.
PEOPLE: | VENEZUELA
ee 78,000, average annual growth rate 2.8%
(FY69 COLOMBIA
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist BRAZIL
Language: English; French patois
Literacy: about 80%
Labor force: est. at 23,000 in 1960; about 50% in
agriculture
Organized labor: 25% of the labor force
Railroads: none
Highways: 460 mi.; 175 mi. paved, 190 mi. gravel, crushed stone, or stabilized
earth surface, 95 mi. unimproved
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 1 with asphalt runway 4,830 ft.
Telecommunications: over 1,000-line fully automatic telephone system; VHF
interisland links to St. Lucia and Antigua; no data on radio or TV receivers;
1 AM station
83
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 80 DOMINICAN REPUBLIC
18,800 sq. mi.; 14% cultivated, 4% fallow, 17% meadows
and pastures, 45% forested, 20% built-on or waste
(1967)
Limits of territorial waters: 6 n. mi. (fishing, 12 n. mi.)
VENEZUELA
Railroads: 9,640 route mi.; 9,052 mi. standard gage, 588 mi. meter and narrow
gage, 1,243 mi. double track standard gage; 795 mi. electrified, including
109 mi. of Berlin S-Bahn (1969)
Highways: 54,055 mi.; 29,369 mi. paved, 24,685 mi. unpaved; 910 mi. classified
autobahn, 7,705 mi. national routes, 20,755 mi. district roads (1971)
Inland waterways: 1,562 mi. (1971)
Freight carried: rail -- 278.4 million short tons, 26.4 billion short ton/mi.
t1969) ; highway -~- 478.5 million short tons, 6.9 billion short ton/mi. (1969);
waterway -- 14.3 million short tons, 1.6 billion short ton/mi. (1969)
Pipelines: crude oi], 360 mi; refined products, 100 mi.
Merchant marine: 130 ships (1,000 GRT and over) totaling 967,000 GRT, 1,300,000
DWT; includes 2 passenger, 119 cargo, 9 tanker
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, 6.736 billion DME;
about 9.5% of total budget
116
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Te ne tern peg og
Sb siete a ea ee ee
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50A GHANA
LAND:
92,000 sq. mi.; 19% agricultural, 60% forest and brush,
21% other (1969)
Limits of territorial waters: 12 n. mi. (fishing, 12
n. mi.)
Railroads: 599 mi. -- all 3''6" gage; 20 mi. double track; diesel locomotives .
gradually replacing steam engines
Highways: 21,350 mi., 3,100 mi. concrete or bituminous surface, 3,750 mi. gravel
or laterite, 3,700 mi. improved earth, 10,800 mi. unimproved earth
Inland waterways: Volta, Ankobra, and Tana rivers provide 145 mi. of perennial
navigation for launches and lighters; additional routes navigable seasonally
by small craft; Lake Volta reservoir provides 700 mi. of arterial and
feeder waterways
Pipelines: refined products, 2 mi.
Ports: 2 major, 1 naval base (Sekondi), 4 minor oar
Merchant marine: 16 cargo ships (1,000 GRT or over) totaling 114,000 GRT,
151,000 DWT
Civil air: 6 major transport aircraft
Airfields: 22 total, 19 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 10 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone fair to good in urban areas; fairly good telegraph
services; 54,000 telephones; about 703,000 radio receivers; 16,000 TV 7
receivers; 2 AM, no FM, and 5 TV stations; 2 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1971, $45,500,000; 8.8% of
total budget
120
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 25A GIBRALTAR
LAND:
2.5 sq. mi.
Limits of territorial waters: 3 n. mi.
Railroads: none n
Highways: 19 miles, all paved
Inland waterways: none
Ports: 1 major
Civil air: 1 major transport aircraft (registered in U.K.)
Airfields: 1 permanent-surface runway, 4,000-7,999 ft.; 1 seaplane station
Telecommunications: international radiocommunication facilities; automatic =
telephone system serving 5,600 telephones; 6,000 radio receivers; 6,600
television receivers; 1 AM, 1 FM, and 2 TV stations; 14 submarine cables
122
SP a LR Ea a aE ee NE Te a Te a ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 24 GREECE
LAND:
51,200 sq. mi.; 28% arable and land under permanent crops,
35% meadows and pastures, 19% forested, 18% wasteland,
urban, other (1965)
Limits of territorial waters: 6-n. mi. (fishing, 6 n. mi.)
Railroads: 1,620 mi.; 980 mi. standard gage (4''8 1/2"), 610 mi. meter gage
(3''3 3/8"), 20 mi. 1''1) 5/8" narrow gage, 10 mi. 2''5 1/2" narrow gage
Highways: 24,200 mi.; 7,100 mi. paved, 9,100 mi. crushed stone and gravel
4,800 mi. improved earth, 3,200 mi. unimproved earth
Inland waterways: system consists of 3 coastal canals and 3 unconnected rivers
which provide navigable length of just less than 50 mi.
Pipelines: crude oi], 16 mi., refined products, 340 mi.
Ports: 17 major, 37 minor
Merchant marine: 1,328 ships (1,000 GRT or over) totaling 12,520,000 GRT,
19,700,000 DWT; includes 52 passenger, 838 cargo, 223 tanker, 190 bulk,
25 specialized carrier; ethnic Greeks also own an estimated 18,000,000
GRT under other flags: about 15,780,000 GRT under Liberia, 745,000 under
Panama, 1,400,000 under Cyprus, 55,000 under Lebanon, 5,000 under Malta,
and 15,000 under Somali Republic
Airfields: 52 total, 45 usable; 31 with permanent-surface runways; 15 with
runways 8,000-11,999 ft., 9 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 32 major transport aircraft
Telecommunications: fairly modern networks reach al] areas on mainland and
islands; however, services generally inadequate; 881,000 telephones; 1.4
million radio receivers; 255,000 TV receivers; 27 AM, 6 FM and 12 TV stations; @a-
9 submarine cables
DEFENSE FORCES: .
Military budget: for fiscal year ending 31 December 1970, $471 million; 26.3% .
of central government budget 7
124
Fg Ta TE ARE a tL aa aa aa
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
~~
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 67 GREENLAND
LAND:
840 000 sq. mi.; less than 1% arable (of which only a
fraction cultivated), 83% permanent ice and snow,
16% other (1964)
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Railroads: none
Highways: none
Ports: 7 major, 16 minor
Civil air: 2 major transport aircraft registered in Denmark
Airfields: 11 total, 8 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 7 seaplane stations
Telecommunications: adequate domestic and international service provided by
radio; 2,950 telephones; 7,100 radiobroadcast receivers; 5 AM, 1 FM, and
2 TV stations; 2 submarine cables
125
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 81A GRENADA
LAND:
133 sq. mi. (Grenada and southern Grenadines); 47%
cultivated, 3% pastures, 12% forests, 20% unused but
potentially productive, 18% built on, wasteland,
other (1964) : 4,
Limits of territorial waters: 3 n. mi. VENEZUELA
PEOPLE: COLOMBIA
Population: 107,000, average annual growth rate 1.7%
(FY67-69)
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects;
Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 25,170 (1960); 40% in agriculture; 30% unemployed or underemployed
Organized labor: 33% of labor force
Railroads: none
Highways: 600 mi.; 380 mi. paved, 100 mi. gravel, crushed stone, or earth
surface; 120 mi. unimproved
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 4 total, 3 usable; 1 with asphalt runway 5,000 ft.
Telecommunications: automatic, islandwide telephone system with 2,700 telephones ;
VHF island link to Trinidad; no data on radio or TV receivers; 1 AM station
127
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 71 GUATEMALA
LAND:
42,040 sq. mi.; 14% cultivated, 10% pasture, 57% forest,
19% other (1967)
Limits of territorial waters: 12 n. mi.
Railroads: 550 mi., all narrow gage (3''0"); 510 mi. government owned, 40 mi.
privately owned
Highways: 7,600 mi., 300 mi. bituminous, 4,200 mi. gravel, 2,100 mi. improved
or unimproved earth (1965)
Iniand waterways: 164 mi. navigable year-round; additional 458 mi. navigable
during high-water season
Pipelines: crude oi1, 28 mi.
Freight carried: rail (1960) -- 191.8 million ton/miles, 1.1 million tons
Ports: 4 major, 1 minor
Merchant marine: 2 cargo ships {1,000 GRT or over) totaling 3,600 GRT, 5,400 DwT
Airfields: 469 total, 316 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 11 major transport aircraft
Telecommunications: modern telecom facilities largely limited to Guatemala City;
intercity open wire network; 38,500 telephones; est. 350,000 radio and
72,000 TV receivers, 77 AM, 25 FM, and 3 TV stations; construction of
satellite earth station under consideration
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, $15,904,000; about
8.6% of central government budget
130
ae
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50E GUINEA
LAND:
95,000 sq. mi.; 3.3% cropland, 10% forest (1969)
Limits of territorial waters: 130 n. mi. (fishing 130
n. mi.)
ad PEOPLE:
~~ Population: 3,914,000, average annual growth rate 2.6%
; (FY67); males 15-49, 927,000; 445,000
fit for military service
Ethnic divisions: 99% African (3 major tribes - Fulani,
Malinke, Soussou; and 13 smaller tribes)
‘ Religion: 80% Muslim, 19% animist, 1% Christian
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written language
Labor force: 1.5 million, of which less than 10% are wage earners; most of
population engages in subsistence agriculture
Organized labor: virtually 100% of wage labor force loosely affiliated with the
National Confederation of Guinean Workers, which is closely tied to the PDG
Railroads: 500 mi. meter gage, 5 mi. standard gage
a 6,000 mi.; 300 mi. paved, 2,000 mi. all weather, 3,700 mi. seasonal
dry Ne é
Inland waterways: 1,115 mi.; 310 mi. navigable by small oceangoing vessels, “
805 mi. navigable by shallow-draft steamers and barges
Ports: 1 major, 2 minor
Merchant marine: 1 bulk carrier (1,000 GRT or over) totaling 10,800 GRT,
15,290 DWT
Civil air: 5 major transport aircraft
Airfields: 19 total, 15 usable; 1] with permanent-surface runway; 2 with runways +
8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: limited telephone service; fair telegraph facilities;
6,500 telephones; 91,000 radio receivers; 1 AM, no FM, and no TV stations;
3 submarine cables
DEFENSE FORCES:
Supply: totally dependent on Communist countries, mainly U.S.S.R.
Military budget: for fiscal year ending 30 September 1969, $14.2 million; 16.2%
of total budget
132
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
:
asf lead
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 95A GUY ANA
LAND:
83,000 sq. mi.; 1% cropland, 3% pasture, 9% savanna,
77% forested, 10% water, urban, and waste (est. 1968)
Limits of territorial waters: 3 n. mi.
PEOPLE: oe
Population: 786,000, average annual growth rate 3.0% (FY69- |
70); males 15-49, 182,000; 125,000 fit for military
service
Ethnic divisions: 50% East Indians, 44% Negro and Negro
mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1% other
Language: English
Literacy: 86%
Labor force: 175,000; about 75% agriculture; 10% mining, services, and
manufacturing; 15% other; 21% unemployed; shortage of technical and
managerial personnel
Organized labor: 25% of labor force
Railroads: 164 mi.; 146 mi. 4''8 1/2" gage, 18 mi. 3''6" gage, all single track, é
none electrified Et
Highways: 750 mi.; 300 mi. paved, 400 mi. gravel, crushed stone, and bauxite i.
ore, 50 mi. earth and sand
Inland waterways: 3,700 mi.; Demerara River navigable to Mackenzie by ocean :
steamers, others by ferryboats, small craft only ns
Freight carried: 75,593 tons 1961
Ports: 1 major, 3 minor i
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 2,959 GRT, 3,149 DWT :
Civil air: 6 major transport aircraft :
Airfields: 100 total, 87 usable; 4 with permanent-surface runways; 12 with runways .
4,000-7 ,999 ft.; 2 seaplane stations -
Telecommunications: highly developed telecom system with multistation radio :
relay network and over 13,500 telephones; tropospheric scatter link to :
Trinidad; 200,000 radio receivers, 2 AM stations
DEFENSE FORCES:
Supply: mostly U.K., some U.S. equipment
Military budget: for fiscal year ending 3] December 1969, $2.35 million; 2.8%
of central government budget
134
a PR a EN rel
Approved For Release 2004','61f74337f6dec9eb7302ecca142c44fb9448213f2b19b5f0ab550c56fb896641','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d18b1a6df9c15635fb4fd507d14a86d8598f4fce59ba760b1050623eb713167',1971,'DZ','Algeria','communications',21,'/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 79 HAITI
LAND:
10,700 sq. mi.; 31% cultivated, 18% rough pastures,
10% forested, 44% unproductive (1960)
Limits of territorial waters: 6 n. mi.
Railroads: 51 mi. 2'' 6" gage, single-track, privately owned industrial railway; .
70 mi. narrow-gage, single-track, privately owned industrial railway;
government line dismantled
Highways: 2,000 mi.; 325 mi. paved, 150 mi. otherwise improved, 1,525 mi.
unimproved
Inland waterways: negligible; about 60 mi. navigable é
Ports: 2 major, 12 minor
Civil air: 3 major transport aircraft owned by the air force
Airfields: 30 total, 15 usable; 3 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: all domestic facilities inadequate, international facilities
only slightly better; large-scale telephone expansion program; only 4,450
telephones, est. 282,000 radio and 10,800 TV receivers, 25 AM, 1 FM, and
1 TV stations.
DEFENSE FORCES:
Military budget: for fiscal year ending 30 September 1970, $5,800,000; about
20.7% of operational budget
fae
al
136
EEE ES GT IIR EN TL A ee eT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 73 HONDURAS
D:
43,300 sq. mi.; 27% forested, 30% pasture, 36% waste,
7% cropland (1966)
Limits of territorial waters: 12 n. mi.
Railroads: 22 mi. standard gage; government owned
Highways: 600 mi.; 410 mi. paved, 190 mi. gravel and crushed stone, or earth
Freight carried: rail -- 903,180 short tons (FY68)
Ports: 1 major @
Merchant marine: 65 ships (1,000 GRT or over) totaling 527,000 GRT, 787,000
DIT; includes 2 passenger, 45 cargo, 5 tanker, 11 bulk cargo, 2 specialized
carrier; ships registered in Hong Kong fly the British flag; over 400 Hong
Kong-owned ships are registered elsewhere
Civil air: 7 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.; 1 seaplane station
DEFENSE FORCES:
Defense is the responsibility of U.K.
140
a Rae de ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 19 HUNGARY
LAND:
35,900 sq. mi.; 60% arable; 14% other agricultural; 16%
forested; 10% other (January 1968)
Railroads: 5,948 route mi.; 5,102 mi. standard gage, 824 mi. narrow gage :
(mostly 2'' 5 7/8"), 22 mi. broad gage (5''0"), 685 mi. double track, 486 ji
mi. electrified; government owned (1970) :
Highways: 18,300 mi.; 7,700 mi. paved, 9,700 mi. crushed stone or gravel, 900 :
mi. earth (1971) :
Pipelines: crude oi], 330 mi.; natural gas, over 1,500 mi. i
Freight carried: rail -- 124 million short tons (1969), 12.8 billion short ton/mi. ;
71970) ; highway -- 277 million short tons, 2.4 million short ton/mi. (1969);
waterway -- 3.5 million short tons, 1.9 billion short ton/mi. (January 1971)
River ports: 2 principal (Budapest, Dunaujvaros); no maritime ports; outlets are
Rostock, East Germany and ports in Poland (1977)
Merchant marine: 18 cargo ships (1,000 GRT or over) totaling 33,000 GRT,
45,000 DWT
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, 9.44 billion forints;
about 4.8% of total budget
yal
*
142
SLES TIT SSN aL a cS SL ET I a a a ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 68 ICELAND
GREENLAND Se
, 39,750 sq. mi.; arable negligible, 22% meadows and
pastures, forested negligible, 78% other (1967)
Limits of territorial waters: 4 n. mi. (fishing, 12 n. mi.)
Railroads: none .
Ports: 5 major, 55 minor
Merchant marine: 22 ships (1,000 GRT or over) totaling 55,000 GRT, 74,000 DWT;
includes 1 passenger, 18 cargo, 2 tanker, 1 specialized carrier
Civil air: 12 major transport aircraft
Airfields: 107 total, 93 usable; 4 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 15 with runways 4,000-7,999 ft.; 5 seaplane stations
Telecommunications: adequate domestic service provided by wire telephone and
telegraph system which circles island; good international radiocommunica-
tion service; 67,973 telephones; 62,000 radiobroadcast receivers; 38,000 TV
receivers; main AM and FM station in Reykjavik is relayed by 5 AM, 15 FM,
and 32 TV stations; 2 submarine cables
or
144
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 36 INDIA
LAND:
1,211,000 sq. mi. (includes Indian part of Jammu-
Kashmir, Sikkim, Goa, Damao and Diu); 50% arable,
5% permanent meadows and pastures, 20% desert,
waste, or urban, 22% forested, 3% inland water (1968)
Limits of territorial waters: 12 n. mi. (fishing, 12. n.
mi.) (100 mi. is fisheries conservation zone,
December 1968)
Railroads: 36,188 mi.; 15,628 mi. meter (3''3 3/8") gage, 17,462 mi. broad gage,
2,687 mi. (2''6” and 2''0") narrow gage government owned; 411 mi. 2''6" and
2''0" gage privately owned; 5,555 mi. double track; 1,305 mi. electrified
Highways: 589,650 mi.; 96,550 mi. paved, 95,000 gravel or crushed stone, 167,550
improved earth, 235,550 mi. unimproved earth
Inland waterways: 8,410 mi.; 1,600 mi. navigable by river steamers
Ports: 7 major 53 minor
Merchant marine: 245 ships (1,000 GRT or over) totaling 2,538,000 GRT,
3,889,000 DWT; includes 3 passenger, 187 cargo, 12 tanker, 35 bulk, and
8 specialized carrier
Airfields: 603 total, 371 usable; 192 with permanent-surface runways; 2 with
runway over 12,000 ft., 49 with runways 8,000-11,999 ft., 141 with runways
4,000-7,999 ft.; 4 seaplane stations
Telecommunications: fair domestic telephone service where available in and
between major cities; facilities and services diminish in quantity and
quality as size of communities decreases and distance between increases;
telephone distribution is less than 2 per 1,000 population; telegraph
facilities widespread; AM broadcast adequate; TV limited to Delhi -- New
Delhi; international telephones and telegraph adequate; 1,159,279 telephones;
9.3 million radio and 9,000 TV sets; AM stations at 70 locations, 1 TV
station; submarine cables extend to Malaysia, Ceylon, and Aden
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1972, $1.66 billion; 22% of -
total budget -_
146
SEAL LIA TE LIS La EE LAL TT ST TE DN GN DR NS ES EEN
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 100 INDONESTA
LAND:
736,000 sq. mi.; 11% small holdings and estates, 64% for-
ests, 25% inland water, waste, urban, and other (1970)
Limits of territorial waters: 12 n. mi.
Railroads: 4,364 mi.; 3,990 mi. 3''6" gage, 317 mi. 2''5 1/2" gage, 57 mi.
1''11 5/8" gage; 132 mi. double track; 74 mi. electrified; government owned
Highways: 57,460 mi.; 12,600 mi. paved, 25,200 mi. gravel or crushed stone,
19,660 mi. improved or unimproved earth
Inland waterways: 14,010 mi.; Sumatra 4,000 mi., Java and Madura 510 mi., Borneo
6,500 mi., Celebes 150 mi., and West New Guinea 2,850 mi.
Ports: 10 major, 62 minor
Merchant marine: 156 ships (1,000 GRT or over) totaling 502,000 GRT, 608,000
DWT; includes 9 passenger, 117 cargo, 15 tanker, 1] bulk, 3 specialized
carrier; a small proportion of the fleet is in overseas trade; in the
interisland fleet over two-thirds are commercially inoperable
Airfields: 314 total, 200 usable; 33 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 56 with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: extensive police net for interisland service; international
and domestic service is limited; radiobroadcast coverage adequate but TV
available on Java only; 182,319 telephones; 3.2 million radio sets; 90,000
TV sets; AM stations at 53 locations ; 1 FM and 5 TV stations; 2 submarine
cables to Singapore
DEFENSE FORCES:
Military budget: for fiscal year ene 31 March 1971, $330 million; about
24% of total budget
148
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Hi eS a Be : 2
en ee ea et eee
Pa
shoves
nena rea wets poe
san
areas
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 33 IRAN
" TURKEY
LAND:
636,000 sq. mi.; 14% agricultural, 11% forested, 16%
cultivable with adequate irrigation, 51% desert,
waste, or urban, 8% migratory grazing and other (1968)
Limits of territorial waters: 12 n. mi. trishing, 12 n. mi.)
Railroads: 2,212 mi.; 2,167 mi. 4°8 1/2" gage
Highways: 24,309 mi.; 6,524 mi. paved, 10,637 mi. gravel and crushed stone,
7,148 mi. improved
Inland waterways: 565 mi., not including Caspian Sea and Shatt al Arab
Pipelines: crude o11, 2,35] mi.; refined products, 2,24] mi.; natural gas,
1,552 mi.
Ports: 7 major, 6 minor
Merchant marine: 13 ships (1,000 GRT or over) totaling 124,000 GRT, 178,000 DWT;
includes 10 cargo, 3 tanker
Civil air: 17 major transport aircraft
Airfields: 220 total, 142 usable; 49 with permanent-surface runways; 7 with or
runways over 12,000 ft., 14 with runways 8,000-11,999 ft., 51 with runways sone
4,000-7,999 ft. ae
Telecommunications: excellent international radiocommunications; good domestic Meee
telecommunication facilities; 286,200 telephones; 1.8 million radio and
200,000 TV receivers; 17 AM, 2 FM, and 11 TV stations; satellite earth station
DEFENSE FORCES:
Military budget: for fiscal year ending 20 March 1971, $912.2 million; about :
17.0% of total budget a
150
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2 | |
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 30 IRAQ
LAND:
172,000 sq. mi.; 18% cultivated, 68% desert, waste, or
urban, 10% seasonal and other grazing land, 4% forest
and woodland
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: 1,377 mi.; 667 mi. 4''8 1/2" gage, 710 mi. meter (3''3 3/8") gage;
10 mi. meter gage double track
Highways: 12,900 mi.; 4,000 mi. paved; 2,900 mi. crushed stone, gravel, or
improved earth; 6,000 mi. earth and sand tracks
Inland waterways: 1,950 mi.; Shatt al Arab navigable by maritime traffic for
about 80 mi.; Tigris and Euphrates navigable by shallow-draft steamers
Ports: 3 major
Pipelines: crude oi], 2,162 mi.; 100 mi. refined products; 548 mi. natural gas
Merchant marine: 2 cargo ships (1,000 GRT or ee totaling 7,700 GRT, 12,000 a
DWT
Civil air: 6 major transport aircraft
Airfields: 162 total, 65 usable; 19 with permanent-surface runways; 33 with
runways 8,000-11,999 ft., 13 with runways 4,000-7 ,999 ft.
Telecommunications: excellent international radiocommunication service; poor
domestic telephone and telegraph service; 119,600 telephones; 185,000 radio
receivers; 177,000 TV receivers; 2 TV and 3 AM stations
DEFENSE FORCES:
Military budget: for fiscal year ending 3] March 1969, $270 million; about
27.0% of total budget
152
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2 7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 2 TRELAND
LAND:
26,600 sq. mi.; 17% arable, 51% meadows and pastures,
a ao 2% inland water, 27% waste and urban
1967
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Railroads: 1,370 mi., 5''3" gage; government-owned
Highways: 53,300 mi.; 41,300 mi. paved, 12,000 mi. otherwise improved
Inland waterways: approx. 650 mi.
Ports: 6 major, 38 minor
Merchant marine: 16 ships (1,000 GRT or over) totaling 136,000 GRT, 190,000
DWT; includes 8 cargo, 5 bulk, 2 specialized carrier
Civil air: 23 major transport aircraft
Airfields: 26 total, 21 usable; 6 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; ] seaplane station
Telecommunications: small, modern system; all cities interconnected for telephone
and telegraph service and broadcast netting; 287,100 telephones; 700,000
radiobroadcast receivers; 432,000 TV receivers; 3 AM, 9 FM, and 20 TV stations; ae
12 submarine cables rik
DEFENSE FORCES:
Supply: formerly from the U.K. primarily, but since 196] from other European
countries
Military budget: for fiscal year ending 31 March 1970, $38.3 million; about
4.5% of total budget
\\
154
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Next 4 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50K IVORY COAST
LAND:
125,000 sq. mi.; 40% forest and woodland, 7% cultivated,
53% grazing, fallow, and waste, 200 mi. of lagoons
and connecting canals along eastern coast (1965)
Limits of territorial waters: 6 n. mi. (fishing, 12 n. mi.)
Railroads: 408 mi. of the 728 mi. Abidjan to Ouagadougou, Upper Volta line, all
single track mater gage; only diesel locomotives in use
Highways: 22,570 mi.; 720 mi. bituminous and bituminous-surface treatment;
11,200 mi. gravel, crushed stone, laterite, and improved earth; 12,600
mi. unimproved earth roads
Inland waterways: 429 mi. navigable rivers and numerous coastal lagoons
Ports: 2 major, 3 minor
Merchant marine: 8 cargo ships (1,000 GRT or over) totaling 53,000 GRT, 74,000
DWT
Civil air: 16 major transport aircraft
Airfields: 48 total, 43 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: system only slightly above African average; consists of
open-wire lines and radio relay links, which provide incomplete coverage of
country; Abidjan is only center; 24,800 telephones; 75,000 radio and
10,500 TV receivers; 3 AM, no FM, and 4 TV stations; 2 submarine cables
DEFENSE FORCES:
Supply: dependent on French
Military budget: for fiscal year ending 31 December 1970, $16,506,000; about
7.9% of total budget
162
LETT a LT a a ae EP ERE a LS NL TI LE EE ee eae
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 81C JAMAICA
LAND:
4,410 sq. mi.; 21% arable, 23% meadows and pastures, 19%
forested, 37% waste, urban, or other (1964)
Limits of territorial waters: 12 n. mi.
Railroads: 204 mi. government-owned, 43 mi. privately owned, al] standard gage,
single track
Highways: 7,100 mi.; 1,200 mi. paved, 4,400 mi. gravel, 1,500 mi. unimproved
earth surfaces
Pipelines: refined products, 6 mi.
Ports: 1 major, 10 minor
Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 11,900 GRT, 10,500 DWT
Civil air: 5 major transport aircraft
Airfields: 47 total, 37 usable; 10 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 1 with runway 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fully automatic domestic telephone network with 66,700
telephones; intraisland VHF network; planned satellite ground station to be
operational in 1971; 500,000 radio and 70,000 TV receivers; 8 AM, 5 FM, and
8 TV stations; 5 submarine cables, including 2 coaxial
DEFENSE FORCES:
Supply: dependent on materiel from U.K. and U.S.
Military budget: for fiscal year ending 31 March 1970, $5 million; about 2.0%
of central government budget
164
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
LTT Re pig
Ie
a pita
be fog bhp Oe DR ae Ba
a ae eee
fees
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 29 JORDAN °
NOTE: The war between Israel and the Arab states in June 1967
ended with Israel in control of West Jordan. Although
approx. 930,000 persons resided in this area prior to the
start of the war, fewer than 750,000 of them remain there
under the Israeli occupation, the remainder having fled
to East Jordan. Over 14,000 of those who fled were
repatriated in August 1967, but their return has been
more than offset by other Arabs who have crossed and are ;
continuing to cross from West to East Jordan. These and ate oy
ARABIA
certain other effects of the Arab-Israeli war are not
included in the data below.
LAND:
37,100 sq. mi. (including about 2,100 sq. mi. occupied by Israel); 11%
agricultural, 88% desert, waste, or urban, 1% forested (1964)
Limits of territorial waters: 3 n. mi. (fishing 3 n. mi.)
Railroads: 230 mi. 3''5 3/8" gage, single track
Highways: 3,971 mi.; 3,210 mi. bituminous, 224 mi. improved, 537 unimproved earth
(these mileages include the Jordanian territory held by Israel)
Pipelines: crude of1, 168 mi.
Ports: 1 major
Civil air: 3 major transport aircraft
Airfields: 51 total, 15 usable; 9 with permanent-surface runways; 1 with
runway over 12,000 ft., 9 with runways 8,000-11,999 ft., 2 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate telecommunication system for the needs of the
country; 34,500 telephones; 170,000 radio and 55,000 TV receivers; 1 AM
and 2 TV stations; planned earth satellite station
DEFENSE FORCES:
Supply: dependent on outside sources; U.S., U.K., France, and West Germany
principal suppliers of military equipment
168
TS a Ta a rc as A GAS Ss eR AR et ae ie i ea Ee aa
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Sree em MERE SSAA ERE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 56D KENYA
D:
225,000 sq. mi.; about 21% forest and woodland, 13%
suitable for agriculture, 66% mainly grassland
adequate for grazing (1970)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: 1,275 mi.; meter gage
Highways: 26,970 mi.; 1,532 mi. paved, 8,849 mi. gravel or improved earth, about
16,589 mi. unimproved or tracks
Inland waterways: part of Lake Victoria and Lake Rudolph are within boundaries
of Kenya
Ports: 1 major, 3 minor
Merchant marine: 5 ships (1,000 GRT or over) totaling 13,800 GRT, 21,600 DWT;
includes 2 cargo, | tanker, 1] specialized carrier
Civil air: 10 major transport aircraft
Airfields: 257 total, 202 usable; 5 with permanent-surface runways; 1] with
runway over 12,000 ft., 1 with runways 8,000-11,999 ft., 44 with runways
4,000-7,999 ft.; 3 seaplane stations
Teleconmunications: in top group of African systems; consists of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Nairobi, secondary centers Mombasa and Nakuru; 72,300 telephones; 774,000
radio and 16,400 TV receivers; 5 AM, 2 FM, and 3 TV stations; 2 submarine
cables
DEFENSE FORCES:
Supply: dependent on U.K.
Military budget: for fiscal year ending 30 June 1969, $14 million; about 5.6% of
ordinary budget
170
ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
" ® ;
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 41A KOREA, NORTH
LAND:
47,000 sq. mi.; 17% arable and cultivated, 74% in forest,
scrub, and brush; remainder wasteland and urban (1970)
Limits of territorial waters: 12 n. mi.
Railroads: 2,818 route mi. operating in 1968; 2,137 mi. standard gage, 681 mi.
2''6" narrow gage; 99 mi. double tracked; about 524 mi. electrified; government
owned
171
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Highways: about 12,600 mi., 95% gravel or earth surface
Inland waterways: 1,400 mi.; mostly navigable by small craft only
Freight carried (1969): rail -- 13 billion metric ton/km., 62 million metric
tons; highway -- 765 million metric ton/km., 116 million metric tons;
waterway -- 540 million metric ton/km., 7.7 million metric tons; coastal --
170 million metric ton/km., 0.4 million metric tons
Ports: 6 major, 26 minor
Merchant marine: 5 cargo ships (1,000 GRT and over) totaling 17,000 GRT, 25,000
od
DWT
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, announced at $746
million; 31% of total budget (converted at 2.57 won=US$1 ) ‘
won
172
Sr PAE PP PES ENR
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 418 KOREA, SOUTH
Railroads: 1,964 mi.; 1,887 mi. standard gage, 77 mi. (2''6") narrow gage; 280
mi. double track; government owned
Highways: 25,340 mi.; 1,600 mi. paved, 16,140 mi. gravel, 4,000 mi. improved
earth, 3,600 mi. unimproved earth
Inland waterways: 1,000 mi.; use restricted to small native craft
Freight carried: rail (1963) 2,708.2 million short ton/mi., 19.8 million short
tons; highway (1963) 21.9 million short tons; air (1959) 796,260 lbs. carried
Pipelines: 255 mi., refined products, under construction
Ports: 10 major, 10 minor
Merchant marine: 111 ships (1,000 GRT or over) totaling 849,000 GRT, 1,390,000
DWT; includes 79 cargo, 17 tanker, 11 bulk, 4 specialized carriers
Airfields: 254 total, 122 usable; 44 with permanent-surface runways; 7 with
runways 8,000-11,999 ft., 16 with runways 4,000-7,999 ft.; 2 seaplane stations
vo
174
rere EEE:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 32C KUWAIT
LAND:
6,200 sq. mi. (excluding neutral zone but including islands);
insignificant amount forested; nearly all desert,
waste, or urban (1969)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: none
Pipelines: crude oil, 195 mi.; refined products, 27 mi.; natural gas, 30 mi.;
Neutral Zone of Kuwait: crude oi], 93 mi.; natural gas, 32 mi.
Ports: 2 major, 1] minor
Merchant marine: 29 ships (1,000 GRT or over), totaling 584,000 GRT, 1,002,000
DWT; includes 20 cargo, 6 tankers, 2 specialized carrier
Civil air: 8 major transport aircraft
Airfields: 12 total, 5 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.
Telecommunications: excellent international radiocommunications; adequate a
domestic telecommunication facilities; 58,000 telephones; 105,000 radio
and 100,000 TV sets; 3 AM and 3 TV stations
DEFENSE FORCES: e
Supply: dependent on U.K.
Military budget: for fiscal year ending 31 March 1971, $72,800,000; about 8.6%
of total budget
a
Ai,
176
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 43B LAOS
LAND:
91,430 sq. mi.; 7% agricultural, 60% forests; except in
very limited areas, soil is very poor; most of
forested area is not exploitable (May 1969, est.)
Highways: about 9,200 mi. (including Communist-held areas); 500 mi. bituminous
or bituminous treated, 1,900 mi. gravel, crushed stone, or improved earth;
6,800 mi. unimproved earth and often impassable during rainy season
mid-May to mid-September
Inland waterways: about 2,850 mi., primarily Mekong and tributaries; 1,800
additional miles are sectionally navigable by craft drawing less than 1.5 ft.
Ports (river): 5 major, 4 minor
Airfields: 377 total, 22] usable; 3 with permanent-surface runways; 17 with
runways 4,000-7,999 ft., 1 with runway 8,000-11,999 ft.
Telecommunications: service to general public considered poor; radio network
provides generally erratic service to government users; poor international
service recently improved by radio relay link to Thailand; radiobroadcast
transmitters operate in a few towns; 1,148 (est.) telephones; 70,000 (est.)
radio receivers
DEFENSE FORCES:
Supply: Royal Armed Forces and Neutralist forces dependent on U.S. and France;
Pathet Lao dependent on North Vietnam, U.S.S.R., Communist China
Military budget: for fiscal year ending 30 June 1971, $37,600,000; about 49%
of total budget
178
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Td
SAT LL TE a a A RP eT I EE Sa EN IES TE ES TEE I I NE I a IS Te TE A EEG RE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 288 LEBANON
LAND:
4,000 sq. mi.; 27% agricultural land, 64% desert, waste,
or urban, 9% forested TURKEY
Limits of territorial waters: fishing, 6 n. mi.
Highways: 5,133 mi.; 3,821 mi. paved, 342 mi. gravel and crushed stone, 373 mi.
improved earth, 597 mi. unimproved earth
Inland waterways: none
Pipelines: crude oi],','aca85c67996429aeb98fdc82af7d54563e810b509068b5fb111807e457e60a95','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('500754fba5d65af8699f83359cd5cfa1c8225a782efcee87664023669903a8fc',1971,'DZ','Algeria','communications',22,'85 mi.
Ports: 3 major, 5 minor
Merchant marine: 46 ships (1,000 GRT or over) totaling 136,000 GRT, 208,200 DWT;
includes 42 cargo, 4 bulk; at least 20 ships are foreign owned or operated
Civil air: 14 major transport aircraft
Airfields: 11 total, 4 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft.; 1 seaplane station
Telecommunications: excellent international telecommunication facilities include
satellite ground station; good domestic telephone and telegraph service;
150,500 telephones; 600,000 radio and 300,000 TV receivers; 7 TV, 1 FM, and
1 AM radiobroadcast stations; 1 submarine cable
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, $63.2 million; about
23.5% of proposed total budget
180
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
So Deak sant nai el
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 61 LESOTHO
LAND:
11,700 sq. mi. (1969); 12% cultivable; largely mountainous
Railroads: 1 mi.; owned, operated, and included in the statistics of the Republic
of South Africa
Highways: approx. 1,136 mi.; 76 mi. paved; 269 mi. crushed stone, gravel, or
stablized soil; 791 mi. improved or unimproved earth
Civil air: no major transport aircraft , i)
Airfields: 36 total, 21 usable; 3 with runways 4,000-7,000 ft.
Telecommunications: system a modest one consisting of a few landlines, a small
radio-relay system, and minor radiocommunication stations; Maseru is the
center; 2,000 telephones; 5,000 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
None, police only
aw
182
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 51 , LIBERIA.
LAND:
43,000 sq. mi.; 20% agricultural, 30% jungle and swamps ,
40% forested, 10% unclassified (1969)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: 310 mi.; 220 mi. standard gage, 90 mi. narrow gage (3''6"); all lines
single track; rail systems owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
Highways: 4,150 mi.; 325 mi. bituminous treated, 875 mi. laterite, 2,950 mi.
unimproved
Inland waterways: 230 mi. navigable
Ports: 3 major, 4 minor
Merchant marine: 1,876 ships (1,000 GRT or over) totaling 35,302,000 GRT,
62,671,000 DWT; includes 12 passenger, 472 cargo, 696 tanker, 484 bulk, 119
specialized carrier; though this registry ranks first in tonnage in the
world, all but 3 ships are foreign owned and operated
Civil air: 2 major transport aircraft
Airfields: 59 total, 41 usable; 3 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone and telegraph limited; main center is Monrovia;
6,000 telephones; 155,000 radio and 6,500 TV receivers; 3 AM, no FM,
2 TV stations; 2 submarine cables
DEFENSE FORCES:
Military budget: for year ending 3] December 1970, $3,383,000; 5.6% of total
budget
184
nee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 49 LIBYA
LAND:
679,000 sq. mi.; 6% agricultural, 1% forested, 93%
desert, waste, or urban (1962)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: none :
Highways: 5,300 mi.; 3,450 mi. bituminous or bituminous surface treated, 1,250 2
mi. improved earth and gravel, 600 mi. unimproved earth
Pipelines: crude oi] 1,890 mi.; natural gas 311 mi.; refined products 143 mi.
Ports: 4 major, 12 minor
Civil air: 7 major transport aircraft; an additional 27 major transports are
operated by external carriers engaged in charter work for several oi] companies
Airfields: 102 total, 81 usable; 13 with permanent-surface runways; 4 with runways
8,000-11,999 ft., 36 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: system is just within top one-third of African systems; con-
sists of radio-relay and tropospheric-scatter links, open-wire lines, and
radiocommunication stations; principal centers are Tripoli and Benghazi;
34,790 telephones; 225,000 radio and 12,500 TV receivers; 7 AM, 5 FM, and
3 TV stations; 3 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1970, $254,500,000; 21.3% of
total budget
186
LTS TRL EAST MOT CE Pe EAE RE ET DI LT ERE ET TT a EE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 15 LIECHTENSTEIN
LAND:
65 sq. mi. o
Bg MER BERMANY
Railroads: 210 mi. standard gage; 100 mi. double track; 90 mi. electrified
Highways: 2,700 mi.; al] paved
Pipelines: refined products, 30 mi.
Inland waterways: 23 mi.; Moselle River
Port: Mertert
Civil air: 5 major transport aircraft
Airfields: 2 total, 1 usable with permanent-surface runway 8,000-11,999 ft.
Telecommunications: adequate and efficient modern system; serves as transfer
point for international European communications; 105,500 telephones; 152,000
radiobroadcast receivers; 66,600 TV receivers; AM megawatt service of Radio
Luxembourg reaches most of Europe; 3 FM stations; 1 TV station with 6 relays
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $8.5 million; 3.0% of :
central government budget :
190 r
ies =
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 39€ MACAO
LAND: ‘
6 sq. mi.; 10% agricultural, 90% urban (1968)
Limits of territorial waters: no claim; Portuguese Navy
asserts territorial sea claim for Portugal and
possessions of 6 n. mi.; Portuguese Foreign Office says
there is no Taw on books concerning claims to terri-
torial sea; fishing, 12 n. mi.
Highways: 26 mi. paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
DEFENSE FORCES:
Defense is responsibility of Portugal
192
SS a a a ST a CTI LT a ET EEE I a Pa aE TE Oe
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 62
LAND:
Railroads: 540 mi. of meter gage
Highways: 5,300 mi.; 1,550 mi. paved 2,550 mi. crushed stone, gravel, or stabi-
lized soil; 1,200 mi. improved and unimproved earth; remainder are tracks
Inland waterways: 1,200 mi. navigable; Lac Alaotra (200 sq. mi.)
Ports: 4 major, 13 minor
Merchant marine: 8 ships (1,000 GRT or over) totaling 38,000 GRT, 54,000 DNT;
includes 6 cargo, } tanker, 1 specialized carrier
Civil air: 13 major transport aircraft
Airfields: 352 total, 179 usable; 2] with permanent-surface runways; 3 with run-
ways 8,000-11,999 ft., 44 with runways 4,000-7,999 ft.; 6 seaplane stations
Telecommunications: telephone and telegraph generally adequate in urban areas;
25,300 telephones; 500,000 radio and 300 TV receivers; 4 AM, no FM, and
1 TV stations
DEFENSE FORCES:
Supply: largely dependent on France; has received some ground force materiel :
from Israel and West Germany ;
Military budget: for fiscal year ending 31 December 1970, $12.2 million; about a
7.8% of total budget
194
SSL LS aE A a a ea EA ET EI EC TD a a ae a a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 57¢ MALAWI
LAND:
36,700 sq. mi.; about 31% of land area arable (of which
less than half is cultivated), nearly 25% forested,
6% meadow and pasture, 38% other (1966)
Railroads:
West Malaysia: 1,014 mi. 3''3 3/8" gage; 8 mi. double track; government-owned awe
East Malaysia: 96 mi. meter gage in Sabah
Highways:
West Malaysia: 10,500 mi.; 8,925 mi. hard surfaced (mostly bituminous surface
treatment), 1,150 mi. crushed stone/gravel, 425 mi. improved or unimproved
earth ae
East Malaysia: about 3,140 mi. (1,608 in Sarawak, 1,532 in Sabah); 520 mi.
hard surfaced (mostly bituminous surface treatment), 1,853 mi. gravel or
crushed stone, 767 mi. earth
Inland waterways:
West Malaysia: 1,985 mi.
East Malaysia: 2,540 mi. (975 mi. in Sabah, 1,565 mi. in Sarawak)
Ports:
West Malaysia: 3 major, 10 minor
East Malaysia: 4 major, 7 minor (3 major, 3 minor in Sabah; 1 major, 4 minor
in Sarawak)
Merchant marine: 11 ships (1,000 GRT or over) totaling 44,000 GRT, 57,000 DWT;
includes 9 cargo, 2 tanker
Civil air: 10 major transport aircraft
Pipelines: crude oi], 90 mi.; refined products, 35 mi.
Airfields:
West Malaysia: 105 total, 71 usable; 15 with permanent-surface runways;
2 with runways 8,000-11,999 ft., 1] with runways 4,000-7,999 ft.; 3
seaplane stations
Sabah: 37 total, 32 usable; 5 with permanent-surface runways; 5 with runways
4,000-7,999 ft.; 3 seaplane stations
Sarawak: 48 total, 43 usable; 5 with permanent-surface runways; 4 with
runways 4,000-7,999 ft.
Telecommunications:
West Malaysia: good intercity service provided mainly by microwave relay;
international service good; good coverage by radio and television broad-
casts; 146,212 telephones; 430,000 radio and 130,000 TV receivers; 9 towns “a
have AM stations; no FM, 8 TV stations; submarine cables extend to India, £
Ceylon, and Singapore; connected to SEACOM submarine cable terminal at
Singapore by microwave relay
Sabah: adequate intercity radio-relay network extends to Sarawak via Brunei;
10,246 telephones; 48,800 radio receivers; 2 AM, 1 FM, no TV stations;
SEACOM submarine cable links to Hong Kong and Singapore ~~
Sarawak: adequate intercity radio-relay network extends to Sabah via Brunei;
12,188 telephones; 65,000 radio and no TV receivers; 1 AM, no FM, no TV
stations
DEFENSE FORCES:
External defense dependent on U.K. forces furnished under terms of Anglo-Malayan
defense agreement of 1957 as amended in 1963; to be replaced by loose 5-power
defense arrangement by end of 1971
Military budget: for fiscal year ending 31 December 1970, $262.3 million; 24%
of total budget
200
See ane nenaennle
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 63 MALDIVE ISLANDS
LAND:
115 sq. mi.; 2,000 islands grouped into 12 atolls, 214
islands inhabited
Limits of territorial waters: 2.75-55 n. mi. (fishing,
100-150 n. mi.)
Railroads: none
Highways: none
Inland waterways: none
Ports: 2 minor ports (Male and Gan)
Merchant marine: 18 ships (1,000 GRT or over) totaling 49,000 GRT, 64,000 DWT;
includes 16 cargo, 2 bulk
Civil air: no major transport aircraft
Airfields: 3 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: no domestic and international telecommunication facilities;
200 telephones; 1,250 radio sets; 1 AM station
201
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50H MALT
465,000 sq. mi.; only about a fourth of area arable, skeen
(3967) negligible, rest sparse pasture or desert : “araaia
1967 .
Railroads: 400 mi. meter gage
Highways: approximately 7,500 mi.; 870 mi. bituminous, 3,215 mi. gravel, 580 mi.
improved earth, 2,835 mi. unimproved earth
Inland waterways: 1,141 mi. navigable a
Civil air: 7 major transport aircraft
Airfields: 55 total, 39 usable; 6 with permanent-surface runways; 2 with runway
8,000-11,999 ft., 11 with runways 4,000-7,999 ft.
Telecommunications: system poor and provides only minimum service to government,
business, and public; open-wire and radiocommunication used for long distance ;
telecommunications; radio sometimes only link to outlying points; 6,670 , aaa
telephones; 60,000 radio receivers; 2 AM, no FM, and no TV stations
DEFENSE FORCES:
Supply: dependent primarily on foreign countries, mainly France and the U.S.S.R.
Military budget: for fiscal year ending 31 December 1969, $3,904,000; about 9%
of total budget
204
LENT TE LTE SLE LTE a LT aE TE a Se a aL Sa EEE CS
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 25B . MALTA
YUGOSLAVIA
LAND:
121 sq. mi.; 50% arable, negligible amount forested,
remainder urban, waste, or other (1965)
Limits of territorial waters: 3 n. mi. (fishing, 3 n. mi.)
Highways: 743 mi., 625 mi. paved (asphalt), 85 mi. crushed stone, 15 mi. improved
earth, 18 mi. unimproved
Ports: 2 minor
Merchant marine: 6 ships (1,000 GRT or over) totaling 45,000 GRT, 52,000 DWT;
includes 1 passenger, 3 cargo, 2 bulk; 2 ships are foreign owned and operated
Civil air: no major transport aircraft
Airfields: 4 total, all usable; 4 with permanent-surface runways; 3 with runways
4,000-7 ,999 ft.; 1 seaplane station
Telecommunications : modern automatic telephone system centered in Valletta;
33,100 telephones; 67,000 radio receivers (including 46,700 subscribers to
the wired broadcast service of Rediffusion Malta, Ltd.); 50,000 television
receivers; 3 AM, 2 FM, and 1 TV stations; extensive wired broadcast service;
10 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1971, $739,200; about 1.6% of
central government bugdet
206
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50F MAURITANIA
LAND:
419,000 sq. mi.; less than 1% suitable for crops, 10%
pasture, 90% desert (1967)
Limits of territorial waters: 12 n. mi. (fishing, 12
n. mi.)
Railroads: 400 mi. standard gage, single track, privately owned
Highways: 3,785 mi.; 220 mi. paved; 500 mi. gravel, crushed stone, or otherwise
improved; 3,065 mi. unimproved
Inland waterways: 500 mi.
Ports: 3 major
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,520 GRT, 1,695 DWT
Civil air: 5 major transport aircraft :
Airfields: 40 total, 29 usable; 9 with permanent-surface runways; 16 with run- ae
ways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone poor, telegraph fair; 1,200 telephones; 55,000
radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES: 2
Supply: dependent on France ae
Military budget: for fiscal year ending 31 December 1969, $5,002,000; 19.2% ''
of ordinary budget
208
SE a CEI PPS SO RC PTT ESSE TS EE SE STROSS
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
a
Pd
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 63 MAURITIUS i ae
LAND:
720 sq. mi., excluding dependencies ; 55% agricultural, in-
tensely cultivated; 35% forests, woodlands, mountains,
river, and natural reserves; 5% built-up areas; 5%
water bodies (1970)
Limits of territorial waters: 12 n. mi. (fishing, 12 n.
mi.) (1967)
Highways: 1,100 mi.; 990 mi. paved, 110 mi. earth
Civil air: no major transport aircraft
Ports: 1 major, 2 minor
Airfields: 5 total, 4 usable; 1 with permanent-surface runway 8,000-11,999 ft.
Telecommunications: 16,800 telephones; radio telegraph service with Reunion,
Malagasy Republic, Seychelles, Zanzibar, and other places in Africa; 1 AM,
no FM, and 4 TV stations; 103,500 radio and 18,800 TV sets; submarine cables
extend to Republic of South Africa, Seychelles Islands, and Rodrigues
Island
210
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
y
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 3 MONACO
LAND: : ae aS
0 . 6 sq . mi e Pee EAST cane
Limits of territorial waters: 12 n. mi. . oe
Railroads: 3 mi.
Highways: none; city streets
Ports: 1 minor
Merchant marine: 5 ships (1,000 GRT or over) totaling 40,600 GRT, 60,600 DWT;
includes 2 cargo, 3 tankers
Civil air: no major aircraft
Airfields: none :
Telecommunications: served by the French wire communications system; automatic
telephone system with about 14,800 telephones; international AM broadcast;
FM and TV facilities; 6,700 radio and 15,100 TV receivers
DEFENSE FORCES:
France responsible for defense
213
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Railroads: 1,130 route mi.; 800 mi. broad gage (5''0"), 330 mi. meter gage
(3''3 3/8") (1971)
Highways: 52,000 mi.; 125 mi. paved, 5,275 mi. improved natural surface and
gravel, 46,600 mi. unimproved earth (1971)
Inland waterways: 585 mi. navigable; used primarily for local transport (1971)
Freight carried: rail -- unknown; highway -- about 10 million short tons (1966),
391 million short ton/mi. (1966); waterway -- 2.5 million short ton/mi. {1970)
DEFENSE FORCES: *
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 31 December 1969, 131.7 million tugriks,
7% of total budget; value in dollars $33 million (est.)
216
eee ell
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 48
LAND:
Railroads: 2,260 mi.; 480 mi. 3''3 3/8" meter gage, 1,780 mi. broad gage (5''5 1/2");
280 mi. double track; 350 mi. electrified
Highways: 18,250 mi.; 10,700 mi. bituminous, bituminous treatment, concrete and
stoneblock; 7,170 mi. gravel and crushed stone; 380 mi. improved earth; plus
an additional 10,500 mi. of unimproved earth roads and motorable tracks
Inland waterways: 508 mi. navigable; relatively unimportant to national economy,
used by shallow-draft craft limited to 330-ton cargo capacity
Ports: 8 major, 32 minor
Merchant marine: 102 ships (1,000 GRT or over) totaling 744,000 GRT, 950,000 DWT;
includes 15 passenger, 63 cargo, 18 tanker, 4 bulk, 2 specialized carrier
Civil air: 20 major transport aircraft
Airfields (including Azores, Cape Verde Islands, and Madeira Islands): 60 total,
52 usable; 25 with permanent-surface runways; 2 with runways over 12,000 ft.,
9 with runways 8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 7 seaplane ze)
stations
Telecommunications: facilities are generally adequate; 720,000 telephones; 1.6
million radio receivers; 352,000 television receivers; 35 AM, 35 FM, and 30
TV stations; 18 submarine cables
258
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
DEFENSE FORCES (cont''d):
Supply: produces vehicles, small arms, ammunition, and incendiary, smoke, and
tear agent munitions; also produces naval ships up to modified destroyer
escort class; other military equipment imported from other NATO countries;
navy ships, weapons, and equipment from U.S., West Germany, U.K., Canada,
France, Brazil, Austria, South Africa, Spain
Military budget: for fiscal year ending 31 December 1970, $409.4 million; about
37% of central government budget
259
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50R PORTUGUESE GUINEA
LAND:
14,000 sq. mi. (includes Bijagos archipelago)
Limits of territorial waters: Portuguese Foreign Office
has no claim; Portuguese Navy claims 6 n. mi.
(fishing 12 n. mi.)
Railroads: none
Highways: 2,000 mi. (80 mi. bituminous, remainder earth)
Inland waterways: 994 mi.
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 61 total, 58 usable; 3 with permanent-surface runways; 9 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: limited telephone and telegraph service; 1,800 telephones;
3,600 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Defense is responsibility of Portugal
262
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 100 PORTUGUESE TIMOR
LAND:
7,000 sq. mi.; 34% forest, 33% grassland, and 33%
cultivated (1968)
Limits of territorial waters: Portuguese Foreign Office
has no claim; Portuguese Navy claims 6 n. mi.
(fishing, 12 n. te
Railroads: 10,763 mi.; 8,493 mi.; (5''6" gage), 2,270 mi. other gages
(4''8 1/2" to 1''11 5/8"), 1,309 mi., double track; 2,348 mi. electrified
Highways: 83,080 mi.; national -- 24,800 mi., bituminous, 22,940 mi. crushed +
stone; provincial -- 32,860 mi., 80% crushed stone, 20% paved; 2,480 mi. other
Inland waterways: about 650 mi.; of minor importance as transport arteries and
contribute little to economy
Pipelines: crude oi], 229 mi.; refined products, 515 mi.; natural gas, 3 mi.
Ports: 23 major, 20 minor
Merchant marine: 419 ships (1,000 GRT or over) totaling 2,946,000 GRT, 4,454,000
DWT; includes 38 passenger, 231 cargo, 84 tanker, 31 bulk, 35 specialized
carrier
304
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Civil air: 150 major transport aircraft
Airfields (including Balearic and Canary Islands): 117 total, 80 usable; 42
with permanent-surface runways; 4 with runways over 12,000 ft., 18 with
runways 8,000-11,999 ft., 33 with runways 4,000-7 ,999 ft.; 5 seaplane
stations
Telecommunications: fairly modern, well engineered, well maintained; 4.0 million
telephones; 5.5 million radio and 3.84 million television receivers; 180
AM, 40 FM, and 27 TV stations with numerous FM/TY repeaters; 15 submarine
cables; communication satellite ground station
DEFENSE FORCES:
Military budget: for biennium ending 31 December 1970, $1,094 million; about
25% of total budget
305
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50P SPANISH SAHARA
103,000 sq. mi., nearly all desert
Limits of territorial waters: 6 n. mi. (fishing, 12 n. mi.)
Railroads: none
Highways: 3,790 mi.; 305 bituminous treated, 3,485 mi. unimproved earth roads
and tracks
Ports: 2 major, 2 minor
Civil air: no major transport aircraft
Airfields: 23 total, 15 usable; 3 with permanent-surface runways; 5 with
runways 4,000-7,999 ft.
Telecommunications: telephone poor, telegraph poor to fair; 540 telephones;
1,500 radio receivers; 1 AM, no FM or TV stations
307
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
DEFENSE FORCES:
Defense is responsibility of Spain; Spanish Sahara is a province of Spain;
defense forces operationally under Canary Islands Command
308
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 54 SUDAN
LAND:
967,000 sq. mi.; 37% arable (3% cultivated), 15% grazing,
33% desert, waste, or urban, 15% forest (1970)
Limits of territorial waters: 12 n. mi. (fishing 12 n. mi.)
Railroads: 2,950 mi.; 2,730 mi. 3''6" gage, 440 mi. 2'' gage plantation line
Highways: 6,550 mi.; 680 mi. crushed stone or gravel, 190 mi. bituminous-treated,
and 5,680 mi. improved and unimproved earth roads; in addition, there are an
undetermined number of tracks =
Inland waterways: 3,300 mi. navigable
Ports: 1 major, 7 minor
Merchant marine: 6 cargo ships (1,000 GRT or over) totaling 21,000 GRT, 25,000
DWT
Civil air: 9 major transport aircraft
Airfields: 86 total, 66 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 29 with runways 4,000-7,999 ft.
Telecommunications: large system by African standards, but still barely adequate
for size of country; consists of open-wire lines, radio-relay links, multi-
conductor cables, radio communication stations and a tropospheric scatter
link; principal center of Khartoum, secondary centers at Al Fashir and
Port Sudan; 45,600 telephones; 650,000 radio and 35,000 TV receivers; 2 AM,
no FM, and 1 TV stations; 5 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1971, $106.0 million; 24.0% of
total budget
310
an
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 95B SURINAM
55,100 sq. mi.; negligible amount of arable land, meadows
and pastures, 76% forest, 8% unused but potentially
productive, 16% built-on area, wasteland, and other
(1964)
Limits of territorial waters: 3 n. mi.
Railroads: 104 mi.; 54 mi. 3''3 3/8" gage (government owned) and about 50 mi.
narrow gage (indu','fba22f6cd3cc0aa71ffbf744d75a043f30a09300939e13f133eda2a89bcd2c78','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4113a03d28b60a9e6e34659aa38c694f407c43334e5738df47c115c63fec362e',1971,'DZ','Algeria','communications',23,'strial line); all single track, no electrification
Highways: 1,550 mi.; 300 mi. paved, 130 mi. gravel, 370 mi. improved earth,
750 mi. unimproved earth
Inland waterways: 2,850 mi.; most important means of transport; oceangoing
vessels with drafts ranging from 14 to 23 ft. can navigate many of the
principal waterways while native canoes navigate upper reaches
Ports: 1 major, 6 minor
Civil air: 3 major transport aircraft
Airfields: 31 total, 30 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: international facilities good and domestic network under
improvement; 10,000 telephones; 60,000 radio and 25,000 TV receivers, 5 AM,
1 FM, and 3 TV stations
DEFENSE FORCES:
Defense is responsibility of the Netherlands; the Netherlands maintains an army
force in Surinam; also available are naval, marine corps, and naval air
personnel located in the Netherlands Antilles
Ships: none
312
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 61 SWAZILAND
LAND:
6,700 sq. mi. (1970); most of area suitable for crops or
pastureland
Railroads: 135 mi., 3''6" gage, single track
Highways: 1,660 mi.; 135 mi, paved; 840 mi. crushed stone, gravel, or stabilized
soil; 685 mi. improved or unimproved earth
Civil air: 4 major transport aircraft
Airfields: 29 total, 26 usable; ] with permanent-surface runway; 2 with runways
4,000-7 ,999 ft.
Telecommunications: the system consists of a few open-wire lines and low-powered
radiocommunication stations; Mbabane is the center; 4,800 telephones; 30,000
radio receivers; 7 AM, no FM or TY stations
DEFENSE FORCES:
None, police only
314
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 11 SWEDEN
LAND:
173,000 sq. mi.; 8% arable, 1% meadows and pastures, 55%
forested, 36% other (1968)
Limits of territorial waters: 4 n. mi. (fishing, 12 n. mi.)
Railroads: 8,015 mi.; Swedish State Railways (SJ) account for 7,245 mi. standard
gage (4''8 1/2"), 48 mi. narrow gage (3''6"), 255 mi. narrow gage (2''11"),
4,358 mi. electrified; remaining lines are privately owned and operated
(90 route mi. of narrow gage (2''11"), 30 mi. narrow gage
(2''7 1/2"), and 347 mi. standard gage (4''8 1/2"), lines)
Highways: 60,100 mi.; 45,800 mi. are crushed stone, gravel, or improved
earth; and 14,300 mi. are bitumen, stone biock, or cobblestone
Inland waterways: 1,268 mi. navigable for smal? steamers and barges
Ports: 17 major, and 23 minor
Merchant marine: 378 ships (1,000 GRT or over) totaling 4,475,000 GRT, 6,747,000
DWT; includes 10 passenger, 185 cargo, 50 tanker, 56 bulk, 77 specialized
carrier
Civil air: 61 major transports registered
Airfields: 174 total, 145 usable; 79 with permanent-surface runways; 5 with
runways 8,000-11,999 ft., 55 with runways 4,000-7,999 ft.; 9 seaplane
stations
Telecommunications: telephone the primary service, but extensive telegraph and
broadcast services are available; excellent domestic and international
facilities; 4,307,000 telephones; 42 AM, 70 FM, and 168 TV stations available
to over 90% of population; 4.8 million radio and 2.8 million TV receivers;
12 submarine cables
DEFENSE FORCES:
Supply: produces vehicles, artillery, tanks, aircraft, chemical and biological
warfare defensive materiel, some missiles, and ammunition; imports
considerable quantities from NATO countries; most naval ships produced
domestically
Military budget: for fiscal year ending 30 June 1972, $1.2 billion; about
11% of proposed central government budget
316
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
D)
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 15 SWITZERLAND
LAND:
16,000 sq. mi.; 10% arable, 42% meadows and pastures, 21%
waste or urban, 24% forested, 3% inland water (1968)
Railroads: 3,040 mi.; 2,195 mi. 4°8 1/2" gage, 845 mi. narrow gage (810 mi. at
3''3 3/8", 35 mi. at 2''7 1/2"); 780 mi. double track; 3,040 mi. electrified
Highways: 31,300 mi.; 12,300 mi. paved, 19,000 mi. otherwise improved
Pipelines: crude oi], 195 mi.
Inland waterways: 41 mi.; Rhine River-Basel to Rheinfelden, Schaffhausen to
Constanz; in addition, there are 12 navigable lakes ranging in size from
Lake Geneva to Hallwilersee
oa ae rail -- 34.8 million metric tons (1963); 4.59 billion ton/km.
1963
Ports: 3 minor
Merchant marine: 27 ships (1,000 GRT or over) totaling 205,000 GRT, 293,000
DWT; includes 23 cargo, 4 bulk; fleet is registered in Basel, operates
mainly out of Genoa, Hamburg, and Rotterdam
Civil air: 70 major transport aircraft
Airfields: 88 total, 72 usable; 34 with permanent-surface runways; 2 with
runways over 12,000 ft., 4 with runways 8,000-11,999 ft., 13 with runways
4,000-7 ,999 ft.
Telecommunications: excellent services; 2.8 million telephones; 1.8 million
radio and 1.3 million TV receivers; 8 AM, 70 FM, and 205 TV stations
including repeaters
DEFENSE FORCES:
Supply: produces moderate amounts of all types of materiel; some medium and
heavy equipment is imported from U.S. and Western Europe; formerly produced
jet aircraft (under license); produces surface-to-air missiles in limited
quantities
Military budget: for fiscal year ending 31 December 1970, $457 ,907,010; 26%
of central government budget
318
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
aft
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 28A SYRIA
LAND:
72,000 sq. mi.; (including about 500 sq. mi. occupied by
Israel); mainly semiarid and desert plains; 38% arable,
41% grazing, 3% forest, 18% other ae
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.) uniteo
PEOPLE: | ARABIA
Population: 6,452,000, average annual aroath rate 3.3%
(FY61- 70); males 15-49, 1,563,000; 840,000 fit for
military service; about 78,000 reach military age (19)
annually
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians, and
other
Religion: 70.5% Sunni Muslim, 16.3% other Muslim sects, 13.2% Christians of
various sects
Language: Arabic, Kurdish, Armenian; French and English widely understood
Literacy: about 40%
Labor force: 1.2 million; 53% agriculture, 17% industry, 30% miscellaneous
services; majority unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Railroads: 476 mi.; 334 mi. standard gage, 142 mi. narrow gage (3''5 3/8")
‘Highways: 6,030 mi.; 4,306 mi. paved, 808 mi. gravel or crushed stone, 1,535 mi.
improved earth, 497 mi. unimproved earth
Inland waterways: 420 mi.; of little importance
Pipelines: crude oi], 1,173 mi.; refined products, 320 mi.
Ports: 3 major, 4 minor
Civil air: 5 major transport aircraft
Airfields: 86 total, 26 usable; 20 with permanent-surface runways; 1 with runway
over 12,000 ft., 15 with runways 8,000-11,999 ft., 5 with runways 4,000- if
7,999 ft.
Telecommunications: excellent international radiocommunication service; excellent
domestic telecommunication service; 104,000 telephones; 280,000 radio and
75,000 TV receivers; 5 TV and 5 AM stations
DEFENSE FORCES:
Supply: capable of producing limited quantities of small-arms ammunition; other-
wise dependent on outside sources, principally U.S.S.R.
320
TET IE aL SIE TA SI TT a I a Se AT IT a ee a LL eT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 56E TANZANIA
LAND:
Railroads: 1,620 mi., meter gage, 4 mi. double track
Highways: total 21,200 mi., 390 mi. on Zanzibar Island, 277 mi. on Pemba and
Mafia Islands; about 1,400 mi. bituminous treated, 370 mi. on Zanzibar and
Pemba; Tanzania, 19,800 mi. gravel, crushed stone, or unimproved earth
Pipelines: refined products 610 mi.
Inland waterways: 730 mi. of navigable streams; several thousand mi. navigable
on Lakes Tanganyika, Victoria, and Nyasa
Ports: 4 major, 8 minor
Merchant marine: 4 cargo ships (1,000 GRT or over} totaling 21,500 GRT, 31,200
DWT
Civil air: 9 major transport aircraft
Airfields: 95 total, 83 usable; 7 with permanent-surface runways; 1 with runway
8,000 to 11,999 ft., 36 with runways 4,000-7,999 ft.; 4 seaplane stations
Telecommunications: telephone and telegraph good in main centers, only fair
outside main towns; 31,600 telephones; 150,000 radio receivers; 4 AM, no FM
or TV stations; 4 submarine cables
DEFENSE FORCES:
Supply: dependent on external sources, primarily Communist China, but also
U.K., U.S.S.R., Australia; Marine Police ships supplied by East Germany,
West Germany, U.S.S.R., and Communist China
Military budget: for fiscal year ending 30 June 1971, $17,000,000; 4.7% of
total budget
322
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 42 ~ THATLAND
LAND:
bai ay mi.; 24% in farms, 56% forested, 20% other
1969
Limits of territorial waters: 12 n. mi.
Railroads: 310 mi. meter gage, single track
Highways: approx. 4,475 mi.; 235 mi. paved, 120 mi. gravel, 910 mi.
improved earth, 3,210 mi. unimproved
Inland waterways: section of Mono River and about 30 mi. of coastal lagoons
and tidal creeks
Ports: 1 major, 1 minor
Civil air: ] major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-surface runway 4,000-7,999 ft.
Telecommunications: Togo has poor system based on skeletal network of open-wire
lines, supplemented by a few radiocommunication stations; only center is
Lome; 4,600 telephones; 45,000 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Supply: most military materiel obtained from France
Military budget: for fiscal year ending 31 December 1970, $2,800,000; 9.8% of
total budget
326
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 102 TONGA
LAND:
385 sq. mi.; 150 islands; 77% arable, 3% pasture, 13%
forest, 3% inland water, 4% other (1963)
Limits of territorial waters: 3 n. mi.
Railroads: none
Highways: 365 mi.; 132 mi. metalled all-weather, 233 mi. earth
Ports: 5 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,800 GRT, 2,700
DWT
Civil air: (see Western Samoa)
Airfields: 3 total; 1 usable, with grass runway 7,000 ft.; 3 seaplane stations
Telecommunications: 895 telephones; 6,050 radio sets; no TV sets; 1 AM station
327
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 81D TRINIDAD AND TOBAGO
LAND:
1,980 sq. mi.; 41.9% in farms (of which 25.7% cropped or
fallow, 1.5% pasture, 10.6% forests, 4.1% unused or
built-on); 58.1% outside of farms, including
grassland, forest, built-up area, and wasteland ; &
Limits of territorial waters: 12 n. mi. VENEZUELA
Railroads: none -
Highways: 4,200 mi.; 2,500 mi. paved, 1,700 mi. gravel or otherwise improved
Pipelines: crude ofl, 243 mi.; refined products, 12 mi.; natural gas, 130 mi.
Ports: 3 major, 6 minor
Civil air: 10 major transport aircraft
Airfields: 12 total, 9 usable; 4 with permanent-surface runways; } with runway
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international service via tropospheric scatter
link to Barbados and Guyana; good local service; planned satellite ground
station; 51,700 telephones; est. 250,000 radio and 54,000 TV receivers;
2 AM, 2 FM, and 2 TV stations
DEFENSE FORCES:
Supply: mostly from U.K.
Military budget: proposed for fiscal year ending 31 December 1969, $2,500,000;
about 1.5% of central government budget
330
ALLL Le aS Ta TIN A ES a a a ac Re eR TL NE TT ee ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 32C TRUCIAL STATES
LAND:
32,000 sq. mi. (1965); almost all desert, waste or urban
(1963)
Limits of territorial waters: Abu Dhabi 3 n. mi., Sharjah
12 n. mi., others not available
Railroads: none
Highways: no surfaced roads
Pipelines: crude oil, 170 mi.
Ports: 2 major, 4 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 4,300 GRT, 7,900 DWT
Civil air: no major transport aircraft
Airfields: 83 total, 38 usable; 3 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 16 with runways 4,000-7,999 ft.
331
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Telecommunications: telephone system in Dabai and Al Sharjah, also links
these towns; Abu Dhabi Petroleum operates a telecom system throughout
the sheikhdom; key centers are Tarif, Habshaan, and Jebel Dhana; 6,800
telephones; 250,000 radio and 10,000 TV receivers; 3 AM, 1 FM, and 1 TV
stations
DEFENSE FORCES:
Defense is responsibility of U.K.
1¢
332
Se a I a ae a NT TL ee I LTT TET EE a a ae ea EE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 46 TUNISTA
LAND:
63,400 sq. mi.; 28% arable land and tree crops, 23% range
and esparto grass, 6% forest, 43% desert, waste or
urban
Limits of territorial waters: 6 n. mi. (fishing, 12 n. mi
follows meter isobath in south; maximum extent 80 n.
mi.)
Railroads: 1,210 mi.; 310 mi. standard gage (4''8 1/2"), 900 mi. meter gage
(3''3 3/8"); 20 mi. double track; 10 mi. electrified
Highways: 10,000 mi.; 4,560 mi. bituminous, 465 mi. gravel, 2,050 mi. improved
earth, 2,925 mi. unimproved earth
Pipelines: crude oi], 391 mi.; refined products, 6 mi.; natural gas, 43 mi.
Ports: 4 major, 14 minor
Merchant marine: 10 ships {1,000 GRT or over) totaling 30,000 GRT, 42,000 DWT;
includes 8 cargo, 2 specialized carrier
Civil air: 6 major transport aircraft :
Airfields: 60 total, 36 usable; 9 with permanent-surface runways; 7 with runway
8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 1 seaplane station
Teleconmunications: the system is above the African average in amount and
capacity of facilities which consist of open-wire lines with multiconductor
cable or radio relay on trunk routes; key centers are Safagis, Susah, and
Tunis; 70,000 telephones; 400,000 radio and 50,000 TV receivers; 3 AM, 3 FM,
and 7 TV stations; 3 submarine cables
@
DEFENSE FORCES:
Supply: dependent on foreign sources of supply; mostly U.S., with lesser amounts
from France, Italy, and West Germany
334
ane eneEnnnernre nell
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 27 TURKEY
296,000 sq. mi.; 34%, cropland; 33%, meadows and pastures;
16% forested, 17% unproductive
Limits of territorial waters: 6 n. mi. except in Black Sea
where it is 12 n. mi. (fishing, 12 n. mi.)
aras
*
REPUBLIC.
Railroads: 4,996 mi.; 4,976 mi. 4''8 1/2" gage, 20 mi. 2''5 1/2" gage; 40 mi.
double track; 20 mi. electrified
Highways: 35,729 mi.; 11,806 mi. paved, 18,641 mi. gravel or crushed stone,
5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oil, 40 mi.; refined products, 1,277 mi.
Ports: 10 major, 35 minor
Merchant marine: 85 ships (1,000 GRT or over) totaling 554,000 GRT, 759,000 DWT;
includes 12 passenger, 55 cargo, 6 tanker, 6 bulk, 2 specialized carrier
Civil air: 19 major transport aircraft
Airfields: 115 total, 88 usable; 46 with permanent-surface runways; 3 with
runways over 12,000 ft., 18 with runways 8,000-11,999 ft., 24 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international radiocommunication and domestic
telecommunication services; 513,600 telephones; 3.1 million radio and 50,000
TV receivers; 35 AM, 3 FM, and 2 TV stations; 1 submarine cable
DEFENSE FORCES:
Supply: mostly dependent on foreign sources, primarily U.S., Canada, and West
Germany; manufactures some small arms, trucks and adequate quantities of
ammunition; builds some of its naval ships
Military budget: for fiscal year ending 28 February 1971, $439.7 million; about
18% of central government budget
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 56B UGANDA
91,000 sq. mi.; 21% inland water and swamp, including
territorial waters of Lake Victoria, about 21%
cultivated, 13% national parks, forest, and game
reserves, 45% forest, woodland, and grassland (1970)
Railroads: 760 mi.; all meter gage, single track
Highways: 31,330 mi. total; 940 mi. bituminous surface treatment; 10,390 mi.
crushed stone, gravel, laterite, and improved earth; 20,000 mi. unimproved
earth roads and tracks
Inland waterways: Lake Victoria, Lake Albert, Lake Kyoga, Lake George, and
Lake Edward (6,010 mi.); Kagera River and Victoria Nile (380 mi.)
Ports: 1 major (Port Bell on Lake Victoria)
Civil air: 6 major transport aircraft
Airfields: 48 total, 41 usable; 3 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 11 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: telephone and telegraph services fair to good, intercity
connections based on 3 or 12 channel carrier systems; 27,700 telephones ;
256,000 radio and 11,000 TV receivers; 2 AM, no FM, and 6 TV stations
DEFENSE FORCES:
Supply: dependent on external sources -- U.K., Israel, U.S.S.R., and
Czechos lovakia
Military budget: for fiscal year ending 30 June 1970, $21.7 million; 11% of
total budget
ry
338
TL TT LT ae nT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 26 U.S.S.R.
LAND:
8,600,000 sq. mi.; 9.3% cultivated, 37.1% forest and
brush, 2.6% urban, industrial, and transportation,
16.8% pasture and natural hay land, 34.2% desert,
swamp, or waste (1969)
Limits of territorial waters: 12 n. mi.
(fishing, 12 n. mi.)
Railroads: 83,263 mi.; 80,622 mi. broad gage, 2,641 mi. narrow gage; 58,118 mi.
broad gage single track; 19,138 mi. electrified; government owned (1970)
Highways: 934,000 mi.; 99,000 mi. paved, 266,000 mi. gravel, crushed stone,
569,000 mi. improved or unimproved earth (1969)
Inland waterways: 89,000 mi. navigable, exclusive of Caspian Sea; 27,350 mi.
principal routes (1971)
Pipelines: crude oi], 19,000 mi.; refined products, 4,500 mi.; natural gas,
40 500 mi.
Freight carried: rail -- 3,185.6 million short tons, 1,696.3 billion short
ton/mi. (January 1971); highways -- 15,620.0 billion short tons, 148.0
billion short ton/mi. (January 1971); waterway -- 393.4 million short tons,
118.3 billion short ton/mi. (January 1971)
Merchant marine: 1,400 ships (1,000 GRT or over) totaling 9,200,000 GRT,
11,900,000 DWT; includes 60 passenger, 1,085 cargo, 255 tanker
DEFENSE FORCES:
Nuclear weapons: satisfies major requirements of Soviet forces
Supply: fully supplies own needs
340
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
THT ta
sit: isn''sre Th
os tame
tare arene ra are na
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 53 ~ UNITED ARAB REPUBLIC
LAND:
386 ,000 sq. mi. (including 22,200 sq. mi. occupied by
Israel); 2.8% cultivated (of which about 70% multiple
cropped); 96.5% desert, waste, or urban; 0.7% inland
water
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: 3,320 mi.; 2,940 mi. 4''8 1/2" gage, 160 mi. 3''3 3/8" gage, 220 mi.
2''5 1/2" gage, 570 mi. double track; 15 mi. electrified
Highways: 30,273 mi.; 5,900 mi. paved, 280 mi. gravel and crushed stone, 7,490
mi. improved earth, 16,680 mi. unimproved earth
Inland waterways: 2,100 mi.; Suez Canal, 100 mi. long, temporarily closed to
navigation because of sunken vessels; normally used by ocean-going vessels
drawing up to 38 ft. of water; Alexandria-Cairo waterway navigable by barges
of 500-ton capacity; Nile and large canals by barges of 420-ton capacity;
Ismailia Canal by barges of 200- to 300-ton capacity; secondary canals by
sailing craft of 10- to 70-ton capacity
Freight carried: Suez Canal (1966) -- 242 million tons of which 175.6 million
tons were POL
Pipelines: crude oil, 128 mi.; refined products, 335 mi.; natural gas, 31 mi.
Ports: 5 major, 12 minor
Merchant marine: 41 ships (1,000 GRT or over) totaling 194,200 GRT, 246 ,100
DWT; includes 5 passenger, 27 cargo, 9 tanker
Civil air: 18 major transport aircraft
Airfields: 144 total, 81 usable; 59 with permanent-surface runways; 42 with
runways 8,000-11,999 ft., 23 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: second best system of coaxial and multiconductor cables,
open-wire lines, and radio communication stations in Africa; principal centers
Alexandria and Cairo, secondary centers Al Mansinah, Ismailia, and Tanta;
365,000 telephones; 4.4 million radio and 560,000 TV receivers; 12 AM, 1 FM,
and 26 TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1971, $1.3 billion (armed forces
and security); 44.0% of total budget
342
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50d UPPER VOLTA
LAND:
106,000 sq. mi.; 50% pastureland, 21% fallow, 10%
cultivated, 9% forest and scrub, 10% waste and other
uses (1967)
Railroads: 1,870 mi., all standard gage and government owned (1970)
Highways: 23,480 mi.; 970 mi. paved, 4,160 mi. otherwise surfaced, 350 mi.
improved earth, 18,000 mi. earth tracks
Inland waterways: 1,068 mi.; used by coastal and shallow-draft river craft
Freight carried: highways 80% of total cargo traffic, rail 15%, waterways 5%
Ports: 4 major, 6 minor
Merchant marine: 18 ships (1,000 GRT or over) totaling 168,000 GRT, 258,000
DWT; includes 11 cargo, 7 tanker; includes 2 naval tanker sometimes used
commercially
Airfields: 86 total, 63 usable; 6 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: ten-year plan developed to improve telecom facilities
underway; most modern facilities concentrated in Montevideo; 206,600
telephones; 1 million radio and 250,000 TV receivers; 70 AM, 3 FM, and 12
TV stations; 9 submarine cables
DEFENSE FORCES:
Supply: dependent on U.S. for current supplies, with few exceptions
Military budget: for fiscal year ending 31 December 1970, $31.6 million; 8.7%
of central government budget
#
348
EAE LE PS I a EP ET NS a Le I a a ea ee ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 17 VATICAN CITY
LAND:
0.169 sq. mi.
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Telecommunications: AM and FM radiobroadcasting stations
DEFENSE FORCES:
Defense is responsibility of Italy
Sf
350
SE LN A AE NSE FER TEL NE HE a Se a Nee ALL a a a EE ee Te Rs EO EE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 86 VENEZUELA
LAND:
352,000 sq. mi.; 3% cropland, 18% pasture, 21% forest, eee
58% urban, waste, and other (1961)
Limits of territorial waters: 12 n. mi.
Railroads: 233 mi. 4''8 1/2" gage; all single track; no electrification
Highways: 34,600 mi.; 11,000 mi. paved, 9,300 mi. gravel, 4,000 mi. improved
earth, 10,000 unimproved
Inland waterways: 4,450 mi.; Orinoco River and Lake Maracaibo accept oceangoing
vessels
Pipelines: crude 011, 3,795 mi.; refined products, 245 mi.; natural gas, 1,412 mi.
Ports: 6 major, 17 minor
Merchant marine: 39 ships (1,000 GRT or over) totaling 350,000 GRT, 518,000 DWT;
includes 19 cargo, 13 tanker, 4 bulk, 3 specialized carrier
Civil air: 62 major transport aircraft
Airfields: 442 total, 336 usable; 90 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 77 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: extensive radio relay; local telephone systems greatly expanded;
plan satellite ground station and troposcatter link','a8a0266b903bc74c8687c50b6a3fe74d91c38e9d8dff50578262b5c2ca49f031','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('619cb267a8d933571f0b6ae13e08a73ddc530ee3ceb92a57b4aa8ae92592ad9c',1971,'DZ','Algeria','communications',24,'to Curacao; over 377,000
telephones; est. 2.73 million radio and 720,000 TV receivers; 136 AM, 50 FM,
and 33 TV stations; 3 submarine cables, including 1 coaxial
DEFENSE FORCES:
Supply: produces portion of smail arms ammunition requirement; dependent upon
U.S. and Western Europe for all other materie}
Military budget: for fiscal year ending 31 December 1969, $205,377,780; about
9.2% of central government budget
352
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 43C VIETNAM, NORTH
LAND:
61,300 sq. mi.; 14% cultivated, 50% forested, 36% urban
inland water, and other (1969)
Limits of territorial waters: 12 n. mi.
Railroads: 602 usable route mi., consists of about 25 mi. of standard gage
(4''8 1/2"), 438 mi. of meter gage (3''3 3/8"), and 139 mi. of dual gage
(4''8 1/2" and 3''3 3/8"); all single track, none electrified; all government
owned and operated; new rail line under construction between Kep and port
of Hon Gai
Highways: 8,400 mi., plus about 2,100 mi. of seasonally motorable tracks; 800 to
900 mi. bituminous surface-treated, remainder gravel, crushed stone, or earth
Inland waterways: 4,200 mi.; 1,800 mi. navigable perennially by craft drawing 6 ft.
Ports: 3 major, 12 minor
Merchant marine: 6 ships (1,000 GRT or over) totaling 14,000 GRT, 15,000 DWT;
3 cargo, 3 tanker
~
353
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 43D VIETNAM, SOUTH
LAND:
66 ,000 sq. mi.; 35% arable (16% cultivated), 32% fforested,
33% other (1969)
Limits of ‘a waters: 3.n. mi. (fishing, 10.8
n. mi.
Railroads: 770 mi.
Highways: 12,500 mi.; 3,250 mi. bituminous, 2,250 mi. gravel and crushed stone,
1,500 mi. improved earth, 5,500 mi. unimproved earth
Inland waterways: about 3,600 mi. navigable; 1,550 mi. navigable by vessels of
more than 2-meter draft
Ports: 6 major, 20 minor
Merchant marine: 20 ships totaling 24,000 GRT, 33,000 DWT; includes 19 cargo,
1 bulk; only 5 ships over 1,000 GRT
Airfields: 340 total, 218 usable; 6] with permanent-surface runways, 8 with
runways 8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 4 seaplane stations
DEFENSE FORCES:
Supply: dependent on U.S. for military supplies
356
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
fr teeny pce ph tae
sag oe coma tmp
a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 103 WESTERN SAMOA
LAND:
1,100 sq. mi.; comprised of 2 large islands of Savai''i and
Upolu and several smaller islands, including Manono
and Apolima (1969)
Limits of territorial waters: 3 n. mi.','961927166f1ae608b84057fb65ffabe62a3f5d788ce7a5626c557ec14a01e6a0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81b248eb8f9b43377f49d5c5107d5582bf3a8f4b04fb299c79ac1325eea7bc48',1971,'BR','Brazil','communications',30,'Railroads: 662 mi.; 615 mi. 3''6" gage, 47 mi. 2''5 1/2" gage; all single track
Highways: 12,800 mi.; 1,800 mi. paved, 4,000 mi. gravel, 3,800 mi. improved
earth, 3,200 mi. unimproved earth
Inland waterways: 960 mi.
Pipelines: crude oil, 27 mi.; refined products, 50 mi.
Ports: 2 major, 11 minor
Merchant marine: 8 ships (1,000 GRT or over) totaling 40,000 GRT, 48,000 DWT;
includes 6 cargo, 2 tanker
Civil air: 16 major transport aircraft
Airfields: 183 total, 161 usable; 12 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: radio relay system, facilities adequate only in Quito and
Guayaquil; 94,300 telephones; 650,000 radio and 70,000 TV receivers, 254 AM,
30 FM, and 8 TY stations; 4 old telegraph submarine cables
DEFENSE FORCES:
Supply: dependent primarily on U.S.; some major purchases from Western Europe
Military budget: for fiscal year ending 31 December 1971, $22.9 million; about
11.3% of central government budget
88
—— seen
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 74 EL SALVADOR
LAND:
8,260 sq. mi.; 32% cropland (9% corn, 5% cotton, 7%
coffee, 11% other), 26% meadows and pastures, 31%
nonagricultural, 11% forested (1965)
Limits of territorial waters: 200 n. mi.
2 PEOPLE:
a” Population: 3,652,000, average annual growth rate 3.8%
(FY69); males 15-49, 840,000; 515,000 fit for mili-
tary service; 42,000 reach military age (18) annually
Ethnic divisions: 84%-88% mestizo; Indian and white
~
minorities, 6%-8% each
Religion: predominantly Roman Catholic, probably 97%-98%
Language: Spanish
Literacy: 50% of population 10 years of age and over (1966 est.)
Labor force: 1 million (est. January 1968); 57% agriculture, 14% services,
14% manufacturing, 6% commerce, 9% other; shortage of skilled labor, but
manpower training programs improving large pool of unskilled labor
Organized labor: 4.5% of total labor force; 8% of nonagricultural labor force
Railroads: 375 mi., all narrow gage; 285 mi. privately owned, 90 mi. government
owned
Highways: 5,400 mi.; 750 mi. bituminous, 950 mi. gravel or crushed stone, 3,700 mi.
earth
Inland waterways: Lempa River partially navigable
Ports: 3 major, | minor
Merchant marine: 1 ship (1,000 GRT or over) totaling 1,600 GRT, 1,800 DWT; includes
1 cargo
Civil air: 8 major transport aircraft
Airfields: 139 total, 110 usable; 1 with permanent-surface runway 4,000-7 ,999 ft.;
1 seaplane station
Telecommunications: nationwide trunk radio relay system completed; extensive
local telephone exchange improvements completed; 35,000 telephones ; 460 ,000
radio and 92,000 TV receivers, 58 AM, 6 FM, and 2 TV stations (3 additional
TV stations planned)
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $7.2 million; about
6% of central government budget (excludes public security forces)
90
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 52F EQUATORIAL GUINEA
LAND: ¥
10,800 sq. mi.; Rio Muni, about 10,000 sq. mi., largely ALGERIA? LIBYA lu ar suai
forested; Fernando Po, about 800 sq. mi. naires) oS
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi. / 5
Railroads: none
Highways: Rio Muni ''-- 1,553 mi.; Fernando Po -- 186 mi.
Inland waterways: Rio Muni has approximately 104 mi. of year-round navigable
waterway, used mostly by pirogues
Ports: 2 major, 3 minor
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft. 4
Telecommunications: fairly adequate for the size and stage of development of the
country; international communications by radio from Bata and Santa Isabel
to Cameroon, Nigeria, and Spain; 1,500 telephones; 71,000 radio receivers;
2 AM, no FM, and 1 TV stations
92
PE AGA RSE EOS EE NN ST TI I OO ES
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 55A ETHIOPIA
LAND:
Railroads: 630 mi.; 420 mi. 3''3 3/8" gage, 20 mi. 3''6" gage, 190 mi. 3'']
3/8" gage; all single track
Highways: 14,300 mi.; 1,125 mi. bituminous, 2,850 mi. crushed stone, gravel, or
stabilized earth, 10,325 mi. earth
Inland waterways: navigation possible on approx. 140 mi. of unconnected and
basically unimproved waterways, of which only 71 mi. are navigable year round
Ports: 2 major, 1 minor
Merchant marine: 7 ships (1,000 GRT or over) totaling 43,000 GRT, 64,000 DWT;
includes 4 cargo, 2 tanker, 1 bulk
Civil air: 17 major transport aircraft »
Airfields: 195 total, 117 usable; 7 with permanent-surface runways; 5 with run-
ways 8,000-11,999 ft., 52 with runways 4,000-7,999 ft.
Telecommunications: system better than in most African countries; composed of
open-wire lines, radiocommunication stations, and smal] number of multi-
conductor cable and radio-relay links; principal center Addis Ababa, secondary
center Asmara; 41,100 telephones; 160,000 radio receivers; 8,000 TV receivers;
5 AM, no FM, and 2 TV stations
94
eer ene i in tht becca ea
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 7 FAEROE ISLANDS
LAND:
540 sq. mi.; less than 5% arable, of which only a fraction
cultivated; archipelago consisting of 18 inhabited
islands and a few uninhabited islets (1964)
Limits of territorial waters: 3 n. mi.; fishing, 12 n. mi.
(from extended base lines)
Railroads: none
Highways: none
Ports: 1 minor
Airfields: 1 with permanent-surface runway, less than 4,000 ft.
95
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Civil air: no major transport aircraft
Telecommunications: good international radiocommunications; fair domestic
wire facilities; 6,300 telephones, 11,000 radio receivers, 1 AM, and 3 FM
stations; 1 submarine cable connection
96
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 64 FALKLAND ISLANDS (MALVINAS )*
LAND:
Colony -- 4,700 sq. mi.; area consists of some 200 small : eRe
islands, chief of which are East Falkland (2,580 sq. ''
mi.) and West Falkland (2,038 sq. mi.); dependencies -- |
consists of the South Sandwich Islands, South Georgia,
and the Shag and Clerke Rocks (1966)
Limits of territorial waters: 3 n. mi.
Railroads: none
Highways: 512 mi.; 9 mi. paved, 23 mi. gravel, 480 mi. earth
Inland waterways: none
Ports: 1 major, 4 minor
Civil air: no major transport aircraft
*The possession of the Falkland Islands has been disputed by the U.K. and Argentina
(which refers to them as the Malvinas) since 1833.
97
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Airfields: 1 seaplane station
Telecommunications: government-operated open-wire and radiotelephone networks
providing effective service to almost all points on both islands; approx-
imately 500 telephones; 1 AM station and approximately 1,100 radiobroadcast
receivers
98
LENSES LE IE TS TEL a pT ig De aE Ta NL LE TS TS LE a ST PS TE TEI SEES SS Sa ee Se Fe
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 102 FIJI
LAND:
7,055 sq. mi.; landownership -- 83.6% Fijians, 1.7% Indians,
6.4% government, 7.2% European, 1.1% other; about 30% :
of land area is suitable for farming AUSTRALIA ae
Limits of territorial waters: 3 n. mi. (fishing 3 n. mi.) : ce
Railroads: none
Highways: 1,555 mi.; 150 mi. paved, 1,325 mi. grave) or crushed stone, 80 mi.
unimproved earth
Inland waterways: 126 mi.; 76 mi. navigable by motorized craft and 200-ton barges
Ports: 6 major, numerous minor landings
Civil air: 5 major transport aircraft (incl. 2 leased)
Telecomnunications: modern local, interisland, and international (wire/radio
integrated) public and special-purpose telephone, telegraph, and teleprinter
facilities; regional radio center; important COMPAC cable link between a
U.S./Canada and New Zealand/Australia, et al; 16,789 telephones; 50,000 Pr
radio receivers; 5 AM, no FM or TV stations -
DEFENSE FORCES:
Military budget: the defense of the Fiji Islands was the responsibility of the a
U.K. until 10 October 1970; the military budget for 1971 is $314,000
el ee
100
ea tec nr eenceeaanaana aia iar
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 12 FINLAND
LAND:
130,000 sq. mi.; 9% arable, 71% forested, 20% other (1966)
Limits of territorial waters: 4 n. mi. (fishing, 4 n. mi.);
Aland Islands, 3 n. mi.
Railroads: 3,505 total route miles; Finnish State Railways (VR) operate a total
of 3,459 route miles of broad gage (5''0"), of which 278 mi. are double track;
privately owned lines total 46 route miles of which 40 mi. are narrow gage
(2'' 5 1/2") and 6 miles are broad gage; electrification is in progress but
none operable as yet
Highways: 44,200 mi., 11,600 mi. bituminous, 31,900 mi. stablized gravel, 700
mi. gravel and earth, and 12,400 mi. of private roads (surface type na)
Inland waterways: 4,100 mi. total (including Saimaa Canal); 2,300 mi. suitable
for steamers; canal locks (275 ft. by 42 ft. with a 16.7 ft. depth over sill)
can accommodate vessels of up to 225 ft. in length, 36 ft. beam, and 14.5
ft. draft
Ports: 1] major, 14 minor
Merchant marine: 213 ships (1,000 GRT or over) totaling 1,311,000 GRT, 1,976,000
DWT; includes 9 passenger, 135 cargo, 45 tanker, 13 bulk, 11 specialized
carrier
Civil air: 30 major transport aircraft
Airfields: 92 total, 72 usable; 28 with permanent-surface runways; 15 with
runways 8,000-11,999 ft., 23 with runways 4,000-7,999 ft.
Telecommunications: facilities provide essential services for government and
industry; 1,090,000 telephones; 1,774,569 radiobroadcast receivers; 1,042,700
TV receivers; 1] AM, 39 FM, and 55 TV stations; 6 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, $137,595,000; about
5.6% of central government budget
102
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 3 FRANCE
213,000 sq. mi.; 31% cultivated, 25% meadows and pastures, reo’ E ‘pot,
Rep ‘GER.
19% waste, urban, or other, 25% forested (1968)
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)','f33b98ecd40b405f24541c59e32f13202aa72cf47495c7565440d8b15bf592ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8d6ff226853b04ade86c24418b02079416eb0ade322046123eceeeee9958ebd',1971,'LY','Libya','communications',34,'Railroads: 24,679 mi.; 23,829 mi. standard gage, 740 mi. meter gage, 110 mi.
other gages (4'' 8 7/8" to meter); 5,970 mi. electrified, 9,892 mi. double
or multiple track
Highways: National, Departmental, and Communal roads total 487,600 mi. comprising
292 ,600 mi. paved, 190,000 mi. crushed stone and gravel, and 14,600 mi.
improved earth; in addition, there are approximately 434,000 mi. of local
farm and forest roads
Inland waterways: 9,320 mi.; 4,820 mi. heavily traveled
Pipelines: total, 10,000 mi.; crude oi], 1,400 mi.; refined products, 2,700 mi.;
natural gas, 5,900 mi.
Ports: 22 major, 165 minor ’
Merchant marine: 435 ships (1,000 GRT or over) totaling 6,070,000 GRT, 9,290,000
DWT; includes 13 passenger, 222 cargo, 109 tanker, 56 bulk, 35 specialized
carrier
Civil air: 270 major transport aircraft
Airfields: 505 total, 413 usable; 141 with permanent-surface runways; 2 with
runways over 12,000 ft., 21 with runways 8,000-11,999 ft., 123 with runways Renee
4,000-7,999 ft.; 10 seaplane stations
Telecommunications: highly developed system provides satisfactory telephone,
telegraph, telex, facsimile, and radio and TV broadcast services; 8,400,000
telephones; 19 million radiobroadcast receivers; 10.1 million TV receivers;
countrywide AM, FM, and TV service including 38 AM, 55 FM, and 40 primary
TV stations; 25 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $5.1 billion; about
17.2% of central government budget
104
STL EI ELL eT a a I TN TT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 95C FRENCH GUIANA
35,100 sq. mi.; 95% forested, 2% water, 1% meadows and BRAZIL
pastures, 2% waste, urban, or other (negligible
amount cultivated) (1963)
Limits of territorial waters: 3 n. mi.
Railroads: 20 mi. private plantation line, 1''11 5/8" gage; 8 mi. abandoned
narrow-gage line
Highways: 450 mi.; 250 mi. paved, 200 mi. earth
105
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Inland waterways: 290 mi.; navigable by small oceangoing vessels and river
and coastal steamers; 2,110 mi. possibly navigable by native craft
Ports: 1 major, 6 minor
Civil air: no major transport aircraft
Airfields: 15 total, 13 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft.; 1 seaplane station
Telecommunications: very limited open-wire telecom system with only 3,000
telephones in mostly manual systems; est. 7,000 radio receivers and 1,290
TV receivers, 1 AM and 2 TV stations
DEFENSE FORCES: :
Defense is responsibility of France; France maintains an army force in French
Guiana; also available army and naval forces located in Martinique and','13090d0a01c273fdf8bb951d6887f49d3013b1b7900645b202b284a274e134fb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d468d3ea574f355c99df5e332fabdda021d2b9aad24d8aba333976586cd57a71',1971,'GP','Guadeloupe','communications',36,'106
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 55C FRENCH TERRITORY OF THE AFARS AND ISSAS
LAND:
9,000 sq. mi.; 89% desert wasteland, 10% permanent pasture,
and less than 1% cultivated (1970)
Limits of territorial waters: 3 n. mi.','543fbc2bad537bbc140f1716bc2977db60aa25e1ff428688fef0f49c5f958cc1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7e20733b32992fedec16601436a1927ba1e6b2561bac1c330da566e734c418c',1971,'CO','Colombia','communications',43,'Railroads: none * b
Highways: 3,820 mi.; 125 mi. paved, 1,960 mi. gravel or crushed stone, 1,425 mi. eg
improved earth, 310 mi. unimproved earth
Inland waterways: approximately 1,000 mi. perennially navigable
Pipelines: crude oil, 39 mi.
Ports: 3 major, 2 minor z
Civil air: 10 major transport aircraft
Airfields: 168 total, 101 usable; 2 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 16 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: fair telephone and telegraph services; good broadcast
coverage in vicinity of Libreville; 2 AM and 2 TV stations; 6,700 telephones;
62,000 radio receivers; 1,200 TV receivers
DEFENSE FORCES:
Supply: dependent on France
112
ae SSE ey I a a a a Se a eh en RS AE Ta St oad
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50S GAMBIA
LAND:
4,000 sq. mi.; 25% uncultivated savanna, 16% swamps, 4%
forest parks, 55% upland cultivable areas, built-up
areas, etc.
Limits of territorial waters: 12 n. mi. (fishing, 18 n. mi.)
Railroads: none
Highways: 820 mi.; 130 mi. bituminous surface treated, 260 mi. gravel, 430 mi.
unimproved earth
Inland waterways: 377 mi.
Ports: 1 major
Civil air: no major transport aircraft
Airfields: 4 total, 2 usable; 1 with permanent-surface runway; 1 with runway
4,000-7,999 ft.; 1 seaplane station
Telecommunications: good telephone and telegraph services; 1,600 telephones;
35,000 radio receivers; 2 AM, no FM or TY stations; 1 submarine cable
DEFENSE FORCES:
Defense is responsibility of U.K.; no British troops present; police strength
is about 600, including 6 expatriate officers
114
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 13A GERMANY , EAST
41,800 sq. mi.; 45% arable, 13% meadows and pasture, 27%
forested, 15% other (1968)
Limits of territorial waters: 3 n. mi.','6e4de7bb69f121feda07923cd85f83fb887801cfc94167e24277bffed8a8e0c1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('405b0ceb1025a4cd6aca4b51f8bab63f96a3fb79528cfc002e443420c06a9a7d',1971,'MA','Morocco','communications',46,'Railroads: 1,105 mi. standard gage, 100 mi. double track; 454 mi. electrified
Pipelines: crude oil, 86 mi.; refined products, 307 mi.; natural gas, 18 mi.
Ports: 8 major, 12 minor
Merchant marine: 11 ships (1,000 GRT or over) totaling 34,000 GRT, 45,000 DWT;
includes 10 cargo, 1 specialized carrier
Civil air: 10 major transport aircraft
Airfields: 139 total, 85 usable; 23 with permanent-surface runways; 2 with
runways over 12,000 ft., 8 with runways 8,000-11,999 ft., 4] with runways
4,000-7,999 ft.; 4 seaplane stations
Telecommunications: superior system by African standards composed of open wave
lines, coaxial multi-conductor and submarine cables and radio relay links;
principal centers Casablanca and Rabat, secondary centers Fez, Manakeck,
Qujda, Sebaa, Aroun, Tangiers and Fetouan; 160,300 telephones; 934,689 radio
and 173,904 TV receivers; 17 Moroccan AM, 1 Voice of America AM, 3 FM, 19 TV
stations; 21 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, $140.8 million; 17.5%
of total budget
218
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
me,
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 58 MOZAMBIQUE
LAND:
292,000 sq. mi.; 30% arable, of which 1% cultivated, 56%
tose and forest, 14% wasteland and inland water
1966)
Limits of territorial waters: Portuguese Foreign Office
has no claim; Portuguese Navy claims 6 n. mi. (fishing,
12 n. mi.)
Railroads: 1,842 mi.; 1,750 mi. 3''6" gage, 92 mi. 2''5 1/2" gage, 6 mi. 3''6" gage
double track
Highways: 20,000 mi.; 1,000 mi. paved; 19,000 other (mostly earth)
Inland waterways: approx. 2,330 mi. of navigable routes
Pipelines: crude oi], 186 mi.
Ports: 3 major, 13 minor
Civil air: 17 major transport aircraft
Airfields: 313 total, 272 usable; 14 with permanent-surface runways; 5 with run-
ways 8,000-11,999 ft., 22 with runways 4,000-7,999 ft.; 5 seaplane stations
Telecommunications: system ranks at the bottom of top two-fifths of African
systems and employs a basic low-capacity open-wire network supplemented
by numerous smal] radiocommunication stations and a single tropospheric
scatter system; important centers are Lourenco Marques, Beira, Nampula,
and Tete; 25,400 telephones; 110,000 radio receivers; 9 AM, 1 FM, and no
TV stations
DEFENSE FORCES:
Defense is responsibility of Portugal
Military budget: for fiscal year ending 31 December 1971, $34.6 million; about
12.6% of national budget
220
enn
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 102 NAURU
LAND:
8.2 sq. mi.s insignificant arable land, no urban areas,
extensive phosphate mines (1970)
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
PEOPLE: AUSTRALIA
Population: 7,000 (official estimate for 30 June 1969); _
males 15-49, about 1,800; fit for military service,
about 950; average number reaching military age (18)
annually, 1971-75, less than 100
Ethnic divisions: 2,921 Nauruans, 1,167 Chinese, 428
Europeans, 1,532 other Pacific Islanders
Religion: Christian (2/3 Protestant, 1/3 Catholic)
Language: Nauruan, a distinct Pacific Island tongue; English, the language of
school instruction, spoken and understood by nearly all
Literacy: nearly universal
Railroads: none
Highways: about 17 mi.; 13 mi. paved, 4 mi. improved earth
Inland waterways: none
Ports: 1 minor
Merchant marine: 3 ships (1,000 GRT or over) totaling 23,800 GRT; 25,500 DWT;
includes 2 cargo, 1 bulk
Civil air: no major transport aircraft
Airfields: 1, coral-surfaced, 5,270 ft.
Telecommunications: adequate interisland and international radiocommunications
provided via Australian facilities; 381 telephones; 1 AM, but no TV or FM
radiobroadcasting facilities; number of radios unknown
221
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
DEFENSE FORCES:
No formal defense structure and no regular armed forces
222
TASES TT LL LL IS NN TS EP TT EE ES OT a A ER LGD PER DE OE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 35A NEPAL
LAND:
54,600 sq. mi.; 13% agricultural area, 35% desert, waste,
or urban; 31% forested and inland water, 21% unused
but potentially productive (1964)
Railroads: 63 mi., all narrow gage (2''6"); 50% government owned
Highways: 1,050 mi.; 290 mi. paved, 250 mi. gravel or crushed stone, 240 mi.
improved earth; 270 mi. unimproved earth, 200 mi. of seasonally motorable
tracks
Airfields: 45 total, 43 usable; 4 with permanent-surface runways; 5 with runways
4,000-7 ,999 ft.
Teleconmunications: poor telephone and telegraph service; good radiocommunication
and broadcast service; most radiocommunication stations are military; inter-
national radiocommunication service is poor; 5,400 telephones, 55,000 radio
and no TV sets, 2 AM, no FM, and no TV stations
DEFENSE FORCES:
Supply: all military supplies imported; India, U.K., U.S. principal suppliers
224
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 4 NETHERLANDS
LAND:
13,100 sq. mi.; 25% arable, 31% meadows and pastures, aoe
31% waste or urban, 8% forested; inland water areas ren CER.
excluded (1968) ;
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Railroads: 2,004 mi., standard gage; 970 mi. double track; 1,020 mi. electrified
Highways: 46,000 mi.; 26,000 mi. paved, 4,000 mi. crushed stone and gravel,
16,000 mi. earth
Inland waterways: 3,940 mi.; less than 962 mi. is natural river; more than 1,400
mi. navigable by craft of 1,000-ton capacity; 1,011 mi. will take 1,500-ton
vessels
Pipelines: crude oi], 208 mi.; refined products, 602 mi.; natural gas, 4,203 mi.
Ports: 8 major, 5 minor
Merchant marine: 475 ships (1,000 GRT or over) totaling 4,797,000 GRT, 7,080,000
DWT; includes 8 passenger, 346 cargo, 83 tanker, 29 bulk, 9 specialized
carrier
Civil air: 80 major transport aircraft
Airfields: 27 total, 25 usable; 16 with permanent-surface runways; 12 with
runways 8,000-11,999 ft., 3 with runways 4,000-7,999 ft.
Telecommunications: highly developed, excellently maintained, and well integrated;
extensive system of multiconductor cables, supplemented by radio relay links,
submarine cables, and radiocommunication stations; 3.12 million telephones;
2.84 million radiobroadcast and 3.04 million TV receivers; 5 AM, 12 FM, and
8 TV stations which provide countrywide service; 6 submarine cables £&
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $1,113 million;
about 12% of central government budget
226
a SAN a Ce
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 82 NETHERLANDS ANTILLES
LAND:
394 sq. mi.; 5% arable, 95% waste, urban, or other (1951)
Limits of territorial waters: 3 n. mi.
Railroads: none
Highways: 760 mi.; 350 mi. paved, 100 mi. gravel, 200 mi. improved earth, 110
mi. unimproved earth
Ports: 3 major, 6 minor
Civil air: 5 major transport aircraft
Airfields: 7 total, all usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: generally adequate telecom facilities; extensive inter-
island VHF links; plan troposcatter link to Venezuela; 26,000 telephones,
105,000 radio and 30,000 TV receivers, 10 AM and 2 TV stations, 4 telegraph
submarine cables
DEFENSE FORCES:
Defense is responsibility of the Netherlands; Dutch forces stationed in
Netherlands Antilles
Supply: dependent on Netherlands -- which itself is dependent for heavier
equipment on other non-Communist countries
228
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ee ee ee
persed
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
“NIS 102 NEW CALEDONIA
LAND:
8,500 sq. mi.; 6% cultivable, 22% pasture land, 7% forests,
65% waste or other (1968)
Limits of territorial waters: 3 n. mi. (fishing, 3 n. mi.)
PEOPLE: rer 8
Population: 107,000, average annual growth rate 2.6% (May
63-March 69)
Ethnic divisions: Melanesian - Polynesian admixture; over
28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian - Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese laborers were imported for
plantations and mines in pre-World War II period; immigrant labor now
coming from Wallis Islands, New Hebrides, and French Polynesia
Organized labor: unorganized
Railroads: none
Highways: 2,900 mi.; 180 mi. paved; 1,170 mi. gravel, crushed stone, or stabilized
surface; 1,550 mi. unimproved earth
Inland waterways: none a
Ports: 1] major, 21 minor
Civil air: no major transport aircraft
Airfields: 33 total, 28 usable; 2 with permanent-surface runways; 2 with
runways 4,000-7,999 ft.; 1 airfield over 8,000 ft.; 1 seaplane station
Telecommunications: 8,023 telephones; 25,000 radio and 8,000 TV sets; 7 AM, _—
no FM, and 1 TV stations
’
4
ia;
230
ae MN LTS A aa a a a a ee a US ae i tear Sk Be ane Sa
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 75 NICARAGUA
LAND:
57,100 sq. mi.; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other (1963)
Limits of territorial waters: 3 n. mi. (fishing, 200 n. mi.)
{VENEZUELA
\\
Railroads: none
Highways: approx. 4,300 mi.; 300 mi. bituminous, 1,850 mi. gravel, 2,150 mi.
unimproved earth
Inland waterways: Niger River navigable 185 miles from Niamey to Gaya on the
Dahomey frontier from mid-December through March
Ports: Niger landlocked; outlet to sea is Cotonou, Dahomey
Civil air: 4 major transport aircraft
Airfields: 74 total, 59 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 15 with runways 4,000-7,999 ft.
Telecommunications: principal telecommunication center Niamey; telephone poor,
telegraph fair, 3,300 telephones; 85,000 radio receivers; unknown number of
TV receivers; 4 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Supply: dependent on France exclusively until 1964; since then has obtained
ground force materiel from other non-Communist countries including Belgium,
Israel, and West Germany
Military budget: for fiscal year ending 30 September 1971, $3,665,000; 8.0%
of total budget
236
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
or
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50B NIGERIA
LAND:
357,000 sq. mi.; 24% arable (13% of total land area
under cultivation), 35% forested, 41% desert, waste,
urban, or other (1969)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
ee PEOPLE:
Population: about 58,000,000*, average annual growth rate
2.8% (current); males 15-49, 13,740,000; 6,520,000 fit
for military service
Ethnic divisions: 250 tribal groups, of which most
al important are Hausa-Fulani (north), Ibo and Yoruba
o“ (south); these 3 tribes total over 60% of population;
about 27,000 non-Africans
Religion: 47% Muslim, 34.5% Christian, 18.3% other
Literacy: est. 25%
Language: English official; Hausa, Yoruba, and Ibo also widely used
Labor force: approx. 26.6 million; about 48% of total population, 80% of those 11
to 55 years of age of both sexes, are accounted "economically active"; only
about 700,000 are wage earners, of whom 8% are in agriculture, forestry,
hunting, and fishing; 7% mining and quarrying; 8% manufacturing; 22%
construction; 2% electricity; 8% commerce; 8% transportation and communication;
37% services
Organized labor: about 530,000 wage earners, approx. 2% of total labor force,
belong to some 666 unions
Railroads: 2,180 route mi.; 3''6" gage
Highways: 55,400 mi.; 9,475 mi. paved (mostly bituminous surface treatment);
45,925 mi. laterite, gravel, crushed stone, improved earth
Inland waterways: 5,330 mi. consisting of Niger and Benue rivers and smaller
rivers and creeks .
Pipelines: crude oj], 58] mi.; natural gas, 56 mi.; refined products, 3 mi. Z
Ports: 4 major, 5 minor
Merchant marine: 13 cargo ships (1,000 GRT or over) totaling 84,000 GRT,
122,000 DWT
Civil air: 8 major transport aircraft
Airfields: 86 total, 75 usable; 12 with permanent-surface runways; 4 with runways
8,000-11,999 ft., 25 with runways 4,000-7,999 ft.; 4 seaplane stations
Telecommunications: one of the best systems in Africa composed of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Lagos, secondary centers Ibadan and Kaduna; 81,400 telephones; 1,275,000
radio receivers, 75,000 TV receivers; 25 AM, 6 FM, and 8 TV stations; 2
submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1970, $364 million; 36.4% of
total budget
238
RST ESET ST TSS A I ELE TLS LN TE IEE IO MTT ET ETE aE EN EE LT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 10 NORWAY
LAND:
Norway: 125,000 sq. mi.; Svalbard, 24,000 sq. mi.;
Jan Mayen, 144 sq. mi.; 3% arable, 2% meadows
and pastures, 21% forested, 73% other (1968)
Limits of territorial waters: 4 n. mi. (fishing, 12 n. mi.)
ae PEOPLE:
Population: 3,918,000, average annual growth rate 0.9%
(current); males 15-49, 907,000; 730,000 fit for
Ri
military service; average number reaching military “sf ey
~ age (20) annually, 31,000 MBA [UAW se SRABIA Sv
7 Ethnic divisions: homogeneous white population; smal]
Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant and Roman Catholic, 1%
other
Language: Norwegian, small Lapp and Finnish-speaking minorities
Literacy: 99%
Labor force: 1.6 million; 19.5% agriculture, forestry, fishing; 27.0% mining and
manufacturing; 9.5% construction; 13.3% commerce; 11.9% transportation and
communication; 17.7% services; 1.1% unemployed
Organized labor: 60% of labor force
Railroads: 2,630 mi.; 2,583 mi. single track standard gage; 1,513 mi. electrified,
including 47 mi. double track
Highways: 44,180 mi.; 7,135 mi. paved, 37,045 mi. crushed stone and gravel
Inland waterways: 980 mi.; 5'' draft vessels maximum
Pipelines: refined products, 33 mi.
Ports: 9 major, 69 minor
Merchant marine: 1,164 ships (1,000 GRT or over) totaling 19,476,000 GRT,
32,311,000 DWT; includes 24 passenger, 444 cargo, 291 tanker, .258 bulk,
147 specialized carrier
Civil air: 57 major transport aircraft
Airfields: 64 total, 58 usable; 32 with permanent-surface runways; 11] with
runways 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.; 24 seaplane
stations
Teleconmunications: high-quality domestic and international telephone, telegraph,
and telex service; 1,091,000 telephones; 1.9 million radiobroadcast receivers;
816,941 TV receivers; 34 AM, 43 FM, and 41 TV stations (including many high
powered transmitters); 6 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, $369 million; about
13% of central government budget
240
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 32B OMAN
LAND: pudker
About 82,000 sq. mi.; negligible amount forested,
remainder desert, waste, or urban
Limits of territorial waters: 3 n. mi.
Pipelines: crude oi1 223 mi.
Ports: 7 minor
Civil air: no major transport aircraft
Airfields: 152 total, 86 usable; 2 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 27 with runways 4,000-7,999 ft.
Telecommunications: poor international radiocommunications (service to Bahrain
only); very poor domestic wire service; 800 telephones; 1 AM station;
tropospheric scatter-link to Bahrain
ll DEFENSE FORCES:
é Supply: from U.K.
241
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 36 PAKISTAN
LAND:
405,000 sq. mi. (includes Pakistani part of Jammu-Kashmir)
(West Pakistan 86%; East Pakistan 14% in two non-
contiguous provinces); 38% arable, including 24%
ae i 58% desert, waste, or urban, 4% forested
1967
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: 7,049 mi. (5,334 mi. West, 1,715 mi. East); 1,468 mi. meter gage
(318 mi. West, 1,150 mi. East) 5,181 mi. broad gage (4,636 mi. West, 545 mi.
East); 400 mi. narrow gage (380 mi. West, 20 mi, East); 722 mi. double track
(635 mi. West, 87 mi. East); government owned
Highways: 71,850 mi. (43,500 mi. West, 28,350 mi. East); 12,730 mi. paved (10,460
mi. West, 2,270 mi. East); 13,850 mi. gravel (12,250 mi. West, 1,600 mi. East);
45,250 mi. earth (20,790 mi. West, 24,480 mi. East)
Inland waterways: 4,600 mi., East Pakistan; 1,150 mi., West Pakistan; river
steamers navigate main waterways in East Pakistan
Pipelines: crude oi], 143 mi.; natural gas, 1,200 mi.
Ports: 2 major, 10 minor
Merchant marine: 75 ships (1,000 GRT or over) totaling 593,000 GRT, 802,000 DWT;
includes 5 passenger, 67 cargo, 1 tanker, 2 bulk
Civil air: 23 major transport aircraft
Airfields: 250 total, 132 usable; 79 with permanent-surface runways; 1 with runway
over 12,000 ft., 22 with runways 8,000-11,999 ft., 67 with runways 4,000-
7,999 ft.; 3 seaplane stations
Telecommunications: excellent international radiocommunication service over
CENTO links; domestic wire and radiocommunication and broadcast service very
good; 193,493 telephones; 1,626,146 radio and 80,000 TV sets; 12 AM, no FM,
and 7 TV stations; submarine cables extend to Muscat
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1971 $630,000,000; about 23%
of total budget
244
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 77 PANAMA
LAND:
29,208 sq. mi. (excluding Canal Zone); 24% agricultural
land (9% fallow, 4% cropland, 11.0% pasture), 20%
exploitable forest, 56% other forests, urban, and
waste (1960); Canal Zone, 553 sq. mi.
Limits of territorial waters: 200 n. mi.
VENEZUELA
Railroads: 345 mi.; 48 mi. 5''0" gage, 107 mi. 3''0" gage; 190 mi. plantation
feeder lines
Highways: 4,200 mi.; 950 mi. paved, 700 mi. gravel or crushed stone, 300 mi.
improved earth, 2,250 mi. unimproved earth; Panama Canal Zone 145 mi.;
140 mi. paved; 5 mi. gravel
Inland waterways: 500 mi. navigable by shallow draft vessels; 50-mile
Panama Cana}
Pipelines: refined products, 56 mi.
Ports: 2 major, 10 minor
Merchant marine: 670 ships (1,000 GRT or over) totaling 5,953,000 GRT, 9,497,000
DWT; includes 12 passenger, 398 cargo, 170 tanker, 66 bulk, 24 specialized
carrier; all foreign owned and operated
Civil air: 22 major transport aircraft
Airfields: 237 total, 124 usable; 16 with permanent-surface runways; 3 with
runways 8,000-11,999 ft.; 11 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: domestic and international telecom facilities well developed,
including nearly nationwide radio-relay system; communications satellite
ground station; 72,900 telephones; 550,000 radio and 108,000 TV receivers,
77 AM, 25 FM, and 13 TV stations; 1 coaxial submarine cable
DEFENSE FORCES:
Supply: principally dependent on U.S. but acquired modern smal] arms and ammuni-
tion from Belgium (1969)
246
ene ny
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 102 PAPUA AND NEW GUINEA
LAND:
183,540 sq. mi. (Papua 90,540 sq. mi., New Guinea
93,000 sq. mi.)
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Papua:
Railroads: none
Highways: approx. 2,480 mi.; about 1,360 mi. suitable for heavy and medium
traffic, and about 1,120 mi. suitable for light traffic “~
Injand waterways: 800 mi., not including minor rivers
Ports: 1 principal (Port Moresby), 1 secondary
Civil air: see New Guinea (below)
Airfields: 180 total, 128 usable; 7 with permanent-surface runways; 14 with
runways 4,000-7,999 ft.; 10 seaplane stations, inactive
Telecommunications: see New Guinea (below)
New Guinea:
Railroads: none
Highways: approx. 6,430 mi.; approx. 3,865 mi. suitable for heavy and medium
traffic, and 2,565 mi. suitable for light traffic only
Inland waterways: 1,350 mi., northeast New Guinea; minor rivers not included
Pipelines: crude oi], 87 mi.
Ports: 4 principal (Rabaul, Lae, Madang, Kavieng), 4 minor
Civil air: 28 major transport aircraft (plus 26 registered in Australia)
Airfields: 429 total, 296 usable; 5 with permanent-surface runways; 34 with
runways 4,000-7,999 ft.; 4 seaplane stations, inactive
Telecommunications: Papua/New Guinea telecom services are adequate and are
being improved; principal telecom centers include Goroka, Lae, Madang,
Mount Hagen, and Wewak in new Guinea; and Daru, Port Moresby and Samarai in
Papua; facilities provide radiobroadcast, radiotelephone and telegraph,
coastal radio, aeronautical radio and international radiocommunication
services; numerous privately-owned radio facilities exist; submarine
cables extend from Madang to Australia and Guam; 18,998 telephones, 75,000
radios, but no TV sets; 11 AM, no FM and no TV facilities
DEFENSE FORCES:
Defense is responsibility of Australia
248
eaten eater ieee nein denen i eterna re ea are a i eae
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 92 PARAGUAY
LAND: :
157,000 sq. mi.; 2% under crops; 24% meadow and pasture; : saagic
52% forested; 22% urban, waste, and other (1963)
Railroads: 652 mi.; 273 mi. standard gage, 32 mi. 3''3 3/8'''' gage, 347 mi. various
narrow gage (privately owned)
Highways: 9,900 mi.; 400 mi. bituminous treated, 310 mi. gravel, 2,390 mi. earth
Inland waterways: 1,970 mi.
Freight carried: 70% carried by inland waterway in 1960
Ports: 1 major, 7 minor (all river)
Merchant marine: 14 ships (71,000 GRT or over) totaling 16,000 GRT, 12,000 DWT;
includes 2 passenger, 9 cargo, 2 tanker, 1 specialized carrier; domestic
ships operate mostly in river traffic; most international waterborne trade
is carried by foreign flag ships
Civil air: 5 major transport aircraft
Airfields: 762 total, 666 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 23 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: local telecom facilities in Asuncion good, but intercity net
still poor; only 21,225 telephones; est. 720,000 radio and 25,000 TV receivers;
18 AM, 5 FM, and 1 TY stations
DEFENSE FORCES:
Supply: dependent on foreign sources (U.S., Brazil, Argentina, and Belgium) for
all materials
Military budget: for fiscal year ending 31 December 1971, $16.5 million; about
19% of proposed central government budget
250
LETT NL LT Le a PE eae RE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 88 PERU
LAND:
496,000 sq. mi. (other estimates range as low as 482,000 Braz
sq. mi.); 2% cropland, 14% meadows and pastures, 55%
forested, 29% urban, waste, other (1962)
Limits of territorial waters: 200 n. mi.
Railroads: approx. 2,144 mi.; 1,800 mi. 4'' 8 1/2" gage; 130 mi. gage less than
3''0"; 214 mi. 3'' O" gage; 9 mi. double track -
Highways: 31,100 mi.; 3,000 mi. paved, 5,400 mi. gravel or crushed stone, 8,500
mi. improved earth, 14,200 mi. unimproved earth
Inland waterways: 5,400 mi. of navigable tributaries of Amazon River system and
130 mi. Lake Titicaca
Pipelines: crude oi], 206 mi.; natural gas, 16 mi.
Ports: 7 major, 20 minor
Merchant marine: 37 ships (1,000 GRT or over) totaling 291,000 GRT, 407,000 DuT;
includes 25 cargo, 9 tanker (includes 4 naval tankers sometimes used
commercially), 1 specialized carrier
Civil air: 46 major transport aircraft
Airfields: 317 total, 271 usable; 15 with permanent-surface runways; 1 with
runway over 12,000 ft., 18 with runways 8,000-11,999 ft., 50 with runways
4,000-7,999 ft.; 3 seaplane st','a970f227b1f7b1adcbad985a930c809d2593e70d0935824e22f16f1b16c01472','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86c3062ca2df604926f50ac1560e55b4113ffc5014647780e3b54a689d12620f',1971,'MA','Morocco','communications',47,'ations
Telecommunications: fairly adequate for most public requirements; communications
satellite ground station; 192,600 telephones; est. 2 million radio and 395,000
TV receivers; 217 AM, 7 FM, and 28 TV stations; 1 telegraph submarine cable
DEFENSE FORCES:
Military budget: a biennial budget for 1 January 1971 through 31 December 1972,
$485.2 million; about 16.2% of central government biennial budget
4
@
252
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 99 PHILIPPINES
D:
116,000 sq. mi.; 37% cropland, 41% forested, 22% other
(1968)
Limits of territorial waters: 0-300 n. mi. (treaty limits
of the Philippines)
Railroads: 2,160 mi.; 2 common-carrier systems (3''6" gage) totaling about 710
mi.; 19 industrial systems with 4 different gages totaling 1,450 mi.; 34%
government owned
Highways: 39,371 mi.; 7,507 mi. paved; 22,838 mi. gravel, crushed stone, or
stabilized soil surface; 9,026 mi. improved earth
Inland waterways: 2,000 mi.; limited to shallow-draft (less than 5 ft.) vessels
Pipelines: refined products, 157 mi.
Ports: 13 major, 89 minor
Merchant marine: 172 ships (1,000 GRT or over) totaling 896,000 GRT, 1,281,000
DWT; includes 9 passenger, 123 cargo, 24 tanker, 1] bulk, 5 specialized
carrier
Civil air: 87 major transport aircraft
Airfields: 278 total, 165 usable; 32 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 8 seaplane stations
DEFENSE FORCES:
Supply: almost exclusively from U.S.; naval ships and equipment also from
Australia, Japan, and Italy
Military budget: for fiscal year ending 30 June 1971, $115.4 million; about 13%
of total budget
Cd
254
a a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 14 POLAND
LAND:
120,600 sq. mi.; 49% arable, 14% other agricultural, 27%
forested, 10% other (1969)
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Railroads: 16,493 route mi.; 14,427 mi. standard gage, 2,066 mi. narrow gage;
4,644 mi. double track; 2,143 mi. electrified; government owned (1968)
Highways: 190,095 mi.; 40,389 mi. paved; 39,479 mi. crushed stone, gravel;
110,227 mi. earth (improved and unimproved) (1971)
Inland waterways: 3,158 mi. navigable streams and canals (1971)
Pipelines: 1,600 mi. for natural gas; 469 mi. for crude oi1; 117 mi. for refined
products
Freight carried: rail -- 411.8 billion short ton, 64.6 million short ton/mi.
(1969) ; highway 878.5 million short tons, 9.4 billion short ton/mi. (1970);
waterway -- 7 million short tons, 1.6 billion short ton/mi. (1970)
Merchant marine: 234 ships (1,000 GRT and over) totaling 1,500,000 GRT and
2,000,000 DWT; includes 2 passenger, 226 cargo, 4 tanker
a
gus
256
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 8 PORTUGAL
LAND:
Metropolitan Portugal: 36,400 sq. mi., including the Azores
and Madeira Islands; 49% arable, 6% meadow and pasture,
28% forested, 17% waste and urban, inland water, and
other (1963)
Cape Verde Islands: 1,560 sq. mi., divided among 10 islands
and several islets (not a part of Metropolitan Portugal )
Limits of territorial waters: Portuguese Foreign Office has
no ae Portuguese Navy claims 6 n. mi. (fishing, 12
n. mi.','ea85c7a908e3a8cb87f5e0f429887a950b3f9f10eb9aa7de28a4f506f45ef07f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b747deff0399ef1847a5e549dc38f139d78af299c5c0d26a1ea3611117e9e9cb',1971,'AU','Australia','communications',54,'Railroads: none
Highways: 200 mi.; 75 mi. all season, 125 mi. improved and unimproved earth
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 14 total, 10 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: domestic and international radio stations used primarily 1
for administrative and military purposes; 1 low-power radiobroadcast station;
unreliable open-wire lines and 12 small manual switchboards serve about 679
telephones; 3,075 radio sets
264
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 84 PUERTO RICO
LAND:
3,440 sq. mi.; 33% arable, 35% meadow and pasture, 13%
forested, 19% waste, urban, or other (1964)
Limits of territorial waters: 3.n. mi. (fishing, 12 n. mi.)
Railroads: more than 450 mi. plantation lines; 6 gages from 1''8" to 3''3 3/8"
with latter predominating
Highways: 4,800 mi.; 3,900 mi. paved, 260 mi. gravel, 640 mi. otherwise
improved and unimproved earth
Inland waterways: negligible
Pipelines: refined products, 90 mi.
Ports: 3 major, 7 minor
Civil air: major transport aircraft are included in U.S. registered total
Airfields: 31 total, 27 usable; 17 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 8 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: highly developed telecom system of open-wire and radio relay
links; communications satellite ground station, 302,300 telephones; over
1 million radio and 410,000 TV receivers; 48 AM, 18 FM, and 11 TV stations;
5 submarine cables, including 4 coaxial
DEFENSE FORCES:
Defense is responsibility of U.S.
266
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 32 QATAR
LAND:
About 4,000 sq. mi.; negligible amount forested; mostly
desert, waste, or urban (1963)
Limits of territorial waters: 3 n. mi. (fishing, 3 n. mi.)
Railroads: none
Highways: 275 mi. surfaced; undetermined mileage of natural surfaced tracks
Pipelines: crude oi], 137 mi.; natural gas, 60 mi.
Ports: 2 minor
Airfields: 10 total, 1 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft.
Civil air: no major transport aircraft
Telecommunications: all international telecom traffic is by radio thru Bahrain;
fair domestic wire facilities; 9,400 telephones; 25,000 radio and 20,000 TV.
receivers; 1 AM and 1 TV stations
267
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 62 REUNION
LAND:
970 sq. mi.; two-thirds of island extremely rugged,
consisting of volcanic mountains; 120,000 acres (less
than one-fifth of the land) under cultivation
Limits of territorial waters: 3 n. mi.
Railroads: none
Highways: 1,092 mi.; 814 mi. paved, 278 mi. gravel, crushed stone, or stabilized
earth
Ports: 1 major
Civil air: no major transport aircraft
Airfields: 6 total, 6 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.
Telecommunications: adequate for size of island and fairly modern; international
communications by radio to France, Malagasy, and Mauritius; 11,300
telephones; 71,000 radio and 17,700 TV receivers; 1 AM, no FM, and 8 TV
stations
270
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 57B RHODESIA
D:
151,000 sq. mi.; 40% arable (of which 6% cultivated); 60%
available for extensive cattle grazing; European
alienated lands (farmed by modern methods) 37%,
African 46%, national land 7%, 6% not alienated (1970)
Railroads: 9,700 mi.; 6,430 mi. standard gage, 3,252 mi. narrow gage, 18 mi.
Se 187 mi. electrified, 42] mi. double track; government owned
1970
Highways: 48,000 mi.; 7,600 mi. paved; 16,300 mi. other improved surfaces,
24,100 mi. earth (1969)
Inland waterways: 1,445 mi. (1971)
Pipelines: crude 011, 1,600 mi.; refined products, 888 mi.; natural gas, 3,100
mi.
Freight carried: rail -- 179 million short tons, 30 billion short ton/mi.(1969);
highway -- 430.0 million short tons, 4.3 billion short ton/mi. (1969);
waterway -- 3.5 million short tons, .70 billion short ton/mi. (1969)
Merchant marine: 50 ships (1,000 GRT or over) totaling 350,000 GRT, 510,000
DHT; includes 1 passenger, 45 cargo, 4 tanker
274
eal
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 60C RWANDA
10,000 sq. mi. almost all the arable land, about 1/3
of total area, is under cultivation; about 1/3 is
pastureland (1967)
Railroads: none
Highways: 3,728 mi.; 1,243 mi. primary roads (only 6 mi. paved), 2,485 mi.
secondary roads; most roads improved or unimproved earth
Inland waterways: Lake Kivu navigable by steamers and barges
Civil air: no major transport aircraft
Airfields: 20 total, 15 usable; 2 with permanent-surface runways; 2 with
runways 4,000-7,999 ft., 1 with runway 8,000-11,999 ft.
Telecommunications: telephone and telegraph limited; main center is Kigali;
1,400 telephones; 30,000 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Supply: dependent primarily on Belgium; has received quantities of arms from
West Germany, and armored cars from France
Military budget: for fiscal year ending 31 December 1971, $3,900,000; about
20.4% of total budget
276
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
oye:
pe Pl St R eee wes
Tose te aR Aa
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 45 RYUKYUS
LAND:
848 sq. mi.; 44% forested, 25% cropland, 10% grassland,
21% other, including building sites, roads, wasteland,
etc. (1968)
Limits of territorial waters: 3 n. mi.
Railroads: none
Highways: 2,060 mi.; 286 paved, 596 gravel, remainder earth
Pipelines: refined products, 33 mi.
Ports: 2 major, 3 minor
Civil air: 8 major transport aircraft (registered in Japan)
Airfields: 22 total, 16 usable; 12 with permanent-surface runways; 1 with runway
over 12,000 ft., 2 with runways 8,000-11,999 ft., 8 with runways 4,000-7,999
ft.; 2 seaplane stations
DEFENSE FORCES:
Defense is responsibility of U.S.
278
SS SLE SE RT TS a SE mE SE AT a a EB RE ET
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 81A ST. KITTS, NEVIS, ANGUILLA
LAND:
150 sq. mi.; 40% arable, 10% pasture, 17% forest, 33%
wasteland and built-on (1962)
Limits of territorial waters: 3 n. mi.
Railroads: none
Highways: 180 mi.; 60 mi. paved, 90 mi. gravel, crushed stone, or improved
earth, 30 mi. unimproved earth
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 1 with asphalt runway 5,700 ft.
Telecommunications: good interisland VHF radio connections and international
link via Antigua; about 1,600 telephones; no data on radio, 6,000 TV
receivers; 2 AM and 1 TV stations
279
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 81A ST. LUCIA
LAND:
238 sq. mi.; 34% arable, 5% pasture, 21% forest, 22%
unused but potentially productive, 18% wasteland
and built-on (1964)
Limits of territorial waters: 3 n. mi.
Railroads: none
Highways: 440 mi.; 150 mi. paved; 190 mi. gravel, crushed stone, or improved
earth; 100 mi. unimproved earth
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 1 with asphalt runway 5,700 ft., 1 with concrete
runway 5,000 ft.; 2 seaplane stations
Telecommunications: partly automatic telephone system with 2,700 telephones;
interisland tropospheric links to Barbados and Antigua; no data on radio or
TV receivers, 1 AM station
281
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 81A ST. VINCENT
LAND:
150 sq. mi. (including northern Grenadines); 50% arable, 3%
pasture, 44% forest, 3% wasteland and built-on (1964)
Limits of territorial waters: 3 n. mi.
Railroads: none
Highways: 600 mi.; 150 mi. paved; 450 mi. gravel, crushed stone, or improved
earth
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 2 total; 1 usable, with asphalt runway 4,800 ft.
Telecommunications: islandwide automatic telephone system with 900
instruments; VHF interisland links to Barbados and St. Lucia; no data on
radio or TV receivers; 2 AM stations
283
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 17 SAN MARINO
LAND:
24 sq. mi.; 74% cultivated, 22% meadows and pastures, 2%
built-on (1964)
Railroads: none
Highways: about 65 mi.
Inland waterways: none 2
Ports: none
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system serving 2,400 telephones; no
radiobroadcasting or television facilities, 3,000 radio and 600 TV receivers
(Italian broadcasts)
DEFENSE FORCES:
San Marino has no defense forces; treaty of 1862 extended protective friendship
of Italy and is believed to be still in effect
286
a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 32D SAUDI ARABIA
LAND:
618,000 sq. mi. (boundaries are poorly defined); 1%
agricultural, 1% forested, 98% desert, waste, or
urban (1963)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: 350 mi., 4''8 1/2" gage
Highways: 7,022 mi.; 4,971 mi. bituminous, 520 mi. gravel and crushed stone,
2,051 mi. improved earth, undetermined mileage of earth and desert track
Pipelines: crude oi], 1,792 mi.; refined products, 96 mi.; natural gas, 275 mi.
Ports: 3 major, 4 minor
Merchant marine: 10 ships {1,000 GRT or over) totaling 46,000 GRT, 61,000 DWNT;
includes 2 passenger, 6 cargo, 1] bulk, | tanker
Civil air: 23 major transport aircraft
Airfields: 220 total, 64 usable; 16 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 37 with runways 4,000-7,999 ft.
Telecommunications: excellent international radio communications; poor domestic
wire service; 44,250 telephones; 78,000 radio and 60,000 TV receivers; 11
TV, 1 FM, and 4 AM stations; 2 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 August 1971, $594 million; about
41.2% of total budget
288
Neem aimee ae peat enema
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50G SENEGAL
LAND: We
76,000 sq. mi.; 13% forested, 40% agricultural (10% nate Re
cultivated), 47% built-up areas, waste, etc. on
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.) |
Railroads: 640 mi. meter gage; 40 mi. double track
Highways: 8,725 mi.; 1,335 mi. bituminous, 990 mi. gravel, 400~mi. improved
earth, 6,000 mi. unimproved earth
Inland waterways: 935 mi.
Merchant marine: 3 ships (1,000 GRT and over) totaling 5,300 GRT, 6,500
DWT; includes 2 cargo, 1 tanker
Ports: 1 major, 4 minor
Civil air: 5 major transport aircraft, including 1 leased to Air Mauritanie
Airfields: 40 total, 25 usable; 8 with permanent-surface runways; |] with runway
8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: relatively advanced for Africa; 29,300 telephones; 268,000
radio receivers; 1,400 TV receivers; 3 AM, no FM, and 1 TV stations;
3 submarine cables
DEFENSE FORCES:
Supply: primarily dependent on France
Military budget: for fiscal year ending 30 June 1970, $16.2 million; about 10.0%
of total budget
290
pe TRS STE SS HS TNT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 63 SEYCHELLES
LAND:
156 sq. mi.; 54% arable land, nearly all of it is under
cultivation, 17% wood and forest land, 29% other
(mainly reefs and other surfaces unsuited for
agriculture); 40 granitic and 43 coral islands
Limits of territorial waters: 3 n. mi.
Railroads: none
Highways: 147 mi.; 62 mi. bituminous, 79 mi. earth
Ports: ] minor port (Victoria)
Civil air: no major transport aircraft Ki
Airfields: 2 total, 1 usable on Astove Isiand, ] under construction on Mahe :
Island; former RAF seaplane station at Port Victoria, Mahe Island, although \\
not in present use, could be used in emergency :
Telecommunications: direct radiotelegraph communications with other adjacent
islands and African coastal countries; 600 telephones; 11,000 radio sets; *
no TV sets; 2 AM, no FM, and no TV stations; submarine cables extend to
Aden, Tanzania, Ceylon, and Mauritius
DEFENSE FORCES:
Defense is responsibility of U.K.; no U.K. troops present 4
292
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50Q SIERRA LEONE
D:
27,900 sq. mi.; 65% arable (6% of total land area under
cultivation), 27% pasture, 4% swampland, 4% forested
(1967) ;
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: 370 route miles; 310 mi. narrow gage (2''6") Sierra Leone Government
Railroad (SLR), 60 mi. narrow gage (3''6") privately owned mineral line
operated by the Sierra Leone Development Company
Highways: 4,950 mi.; 450 mi. bituminous (including some bituminous treatment), :
1,750 mi. laterite (some gravel), and 2,750 mi. earth es
Inland waterways: 500 mi.; 372 mi. navigable year-round
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 15 total, 15 usable; 5 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone and telegraph are adequate; 6,500 telephones;
35,000 radio and 3,050 TV receivers; 1 AM, no FM, and 1 TV stations;
3 submarine cables
DEFENSE FORCES:
Supply: dependent on U.K. :
294
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 44¢ SINGAPORE
LAND:
225 sq. mi.; 31% built up area, roads, railroads, and
airfields, 22% agricultural, 47% other (1970)
Limits of territorial waters: 3 n. mi.
Railroads: 24 mi. of meter gage
Highways: 1,080 mi.; 650 mi. paved, 260 mi. crushed stone, 170 mi. improved
earth
Ports: 3 major
Merchant marine: 93 ships (1,000 GRT or over) totaling 504,600 GRT, 646,000
DWT; includes 4 passenger, 73 cargo, 10 tanker, 4 bulk, 2 specialized carrier
Civil air: 8 major transport aircraft
Airfields: 5 total, 5 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate domestic facilities; good international service;
good radio and television broadcast coverage; about 136,267 telephones;
est. 227,410 radio and 145,258 TV sets; 2 AM, 4 FM, and 2 TV stations; new
SEACOM submarine cable extends to Hong Kong via Sabah, Malaysia
DEFENSE FORCES:
Supply: produces some small arms ammunition, rifles, and quartermaster-type
individual equipment; some small patrol craft built; all other materiel
imported, mainly from U.K. and U.S.
Military budget: for fiscal year ending 31 March 1971, $125 million; 26% of
total budget
296
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 55B SOMALIA
LAND:
246,000 sq. mi.; 13% arable (0.3% cultivated), 32%
grazing, 14% scrub and forest, 41% mainly desert,
urban, or other (1964)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Railroads: none
Highways: 8,324 mi.; 492 mi. paved; 1,478 mi. crushed stone, gravel, or
stablized soil; 7,354 mi. improved or unimproved earth
Inland waterways: Fiume Giuba navigable 345 mi. from May to mid-June and
August to late November
Ports: 4 major, 17 minor
Civil air: 6 major transport aircraft
297
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Merchant marine: 88 ships (1,000 GRT or over) totaling 519,000 GRT, 758,000
DWT; 1 passenger, 9 tanker, 77 cargo, 1 bulk; al] foreign owned and operated
Airfields: 106 total, 55 usable; 2 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 11 with runways 4,000-7,999 ft.; 5 seaplane
stations
Telecommunications: telephone poor, telegraph fair; 4,800 telephones; 45,000
radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, $16,600,000; 36.3% of
total budget
298
PAH ES SESE ST CH TOE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 61 SOUTH AFRICA
Railroads: 12,277 mi.; 11,837 mi. 3''6" gage of which 1,323 mi. are multiple
track; 2,634 mi. electrified; 440 mi. 2''0" gage single track
Highways: 211,000 mi.; 27,300 mi. paved, 47,050 mi. crushed stone or gravel,
145,650 mi. improved and unimproved earth
Pipelines: crude oi], 520 mi.; refined products, 450 mi.; natural gas, 200 mi.
Inland waterways: none
Ports: 5 major, 6 minor
Merchant marine: 60 ships (1,000 GRT or over) totaling 413,000 GRT, 509,000
DWT; includes 2 passenger, 53 cargo, 3 bulk, 2 specialized carrier
Civil air: 55 major transport aircraft
Airfields: 710 total, 565 usable; 39 with permanent-surface runways; 1 with runway
over 12,000 ft., 6 with runways 8,000-11,999 ft., 131 with runways 4,000-7,999
ft.; 4 seaplane stations
Telecommunications: the system, except for the lack of television, is the best
developed, most modern, and highest capacity in Africa and consists of
carrier-equipped open-wire lines, coaxial cables, radio-relay links, and
radioconmunication stations; key centers are Bloemfontein, Cape Town,
Durban, Johannesburg, Port Elizabeth, and Pretoria; 1.5 million telephones;
2 million radio receivers; 13 AM, 60 FM, and no TY stations; 4 submarine
cables
DEFENSE FORCES:
Military budget: for year ending 31 March 1971, $360,000,000; about 9.9%
of total budget
300
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 61 SOUTH-WEST AFRICA
LAND:
318,000 sq. mi. (1970); mostly desert except for interior e" vaaitisauor 9
TQRABIA
plateau and area along northern border
Limits y territorial waters: 6 n. mi. (fishing, 12 n.
mi.
Railroads: none
Highways: 477 mi.; 80 mi. bituminous, remainder mostly gravel, crushed stone,
or earth
Inland waterways: none
357
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Ports: 1 principal (Apia), 1 minor
Civil air: 4 major transport aircraft (includes 2 leased)
Airfields: 4 total, al] usable; 4 with runways 4,000-7,999 ft.; 3 seaplane
stations
Telecommunications: 1,838 telephones; 22,000 radio receivers; 1 AM station
358
SLL TP LTTE IE Oe LE i aE SE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 32B YEMEN (ADEN)*
LAND:
Railroads: none
Highways: 3,350 mi.; 120 mi. bituminous treated, 30 mi. crushed stone and gravel,
3,200 motorable track
Ports: 1 major
Pipelines: refined products, 57 mi.
Civil air: 9 major transport aircraft
Airfields: 134 total, 89 usable; 2 with permanent-surface runways; 2 witn
runways 8,000-11,999 ft., 43 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent international radiocommunications; excellent 8
domestic wire facilities; 9,400 telephones; 250,000 radio receivers; 21,000
TV receivers; 5 TV and 1 AM stations; 4 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1969, $21,152,000; about 55.2% aa
of total budget
360
ne ed
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 32A YEMEN (SANA)
LAND:
about 75,000 sq. mi. (parts of border with Saudi Arabia
and Southern Yemen undefined); 20% agricultural,
1% forested, 79% desert, waste, or urban
Limits of territorial waters: 12 n. mi. (fishing,
12 n. mi.)','57c60f76f1e7b06228658ef45c8fee3530961ee9eefdf5d4cecf3e2da63e1580','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9670faa478124c1d53fe66ac13f0f94b2d11af42d010ab7828b7865aca3ae22b',1971,'JP','Japan','communications',56,'Railroads: none
Ports: 3 major, 2 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,253 GRT, 1,810 DWT
Civil air: 8 major transport aircraft
Airfields: 33 total, 24 usable; 6 with permanent-surface runways ; 1 with
runway over 12,000 ft., 5 with runways 8,000-11,999 ft., 13 with runways
4,000-7,999 ft.
361
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Telecommunications: fair international service by radio; poor domestic wire
service; 1,900 telephones; 10,000 radio receivers (approx.); 2 AM radio-
broadcast stations
DEFENSE FORCES:
Supply: dependent on outside sources, primarily U.S.S.R.
362
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 21 YUGOSLAVIA
LAND:
98,700 sq. mi.; 32% arable; 25% meadows and pastures;
34% forested; 9% urban, waste, and other (1967)
Limits of territorial waters: 10 n. mi. (fishing,
12 n. mi.)
Railroads: 6,640 route mi.; 5,702 mi. standard gage, 938 mi. narrow gage;
463 mi. double track (1969)
Highways: 49,000 mi.; 8,900 mi. paved, 26,980 mi. gravel, crushed stone, 12,675
mi. improved earth, 445 mi. unimproved earth (1970)
Inland waterways: 1,231 mi. (1970)
Freight carried: rail -- 76.7 million short tons, 12.1 billion short ton/mi.
(1969); highway -- 48.3 million short tons, 3.2 billion short ton/mi. (1968);
waterway -- 24.5 million short tons, est. 5.4 billion short ton/mi. (1969)
Pipelines: crude oi], 90 mi.; natural gas, 280 mi.
Merchant marine: 196 ships (1,000 GRT or over) totaling 1,500,000 GRT, 2,200,000
DWT; includes 5 passenger, 175 cargo, 16 tanker
DEFENSE FORCES:
Military budget: for fiscal year ending 3] December 1971, 8,838 billion new
dinars; about 60% of the central government budget
364
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
a J
iv
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 57A ZAMBIA
LAND:
288,000 sq. mi.; 5% under cultivation, 5% arable, 10%
grazing, 13% dense forest, 6% marsh, 61% scattered
trees and grassland, 5% other (1970)
Railroads: 764 mi., all narrow gage (3''6"); 8 mi. double track; 664 mi. are
government owned; 100 mi. privately owned
Highways: 21,220 mi.; 1,500 mi. paved, 3,120 mi. crushed stone, gravel, or
stabilized soil; 16,600 mi. improved and unimproved earth
Inland waterways: 1,409 mi. including Zambezi River, Luapula River, Lake Kariba,
Lake Bangweulu, Lake Tanganyika; principal port on Lake Tanganyika is Mpulungu
Pipelines: 450 mi. refined
Civil air: 12 major transport aircraft
Airfields: 186 total, 155 usable; 6 with permanent-surface runways; 1 with
runway over 12,000 ft., 20 with runways 4,000-7,999 ft.
Telecommunications: al] services being modernized and increased; presently
adequate but must be expanded to permit growth; high-capacity wire and
radio relay connect centers of Kitwe in northern mining region and Lusaka
along axial north-south route; 52,000 telephones; 100,000 radio and
17,000 TV receivers; 4 AM, 1 FM, and 2 TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, $26,400,000; about
4.8% of total budget
366
A
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2','6c6623401acd005159098ca0686bb37551c7c8f9646fca80645686d265bea5f6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc282b46c69d1fe29b45b087424319ba773b2d84709206acdd49a679a0cbd29a',1971,'US','United States','communications',59,'This "Factsheet" on the U.S. is provided solely as a service to those
wishing to make rough comparisons of foreign country data with a U.S.
"yardstick." Information is from U.S. open sources and publications
and in no sense represents estimates by the U.S. intelligence community.
LAND:
3,615,211 sq. mi. (contiguous U.S. plus Alaska and Hawaii); 20% cultivated;
27% grazing and pasture; 32% forested; 21% waste, urban, and other
(est. 1965)
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Railroads: 224,083 mi. (1967)
Highways: 3,697,950 mi. (1967); 2,800,481 mi. surfaced
Inland waterways: 25,260 mi. of navigable inland channels, exclusive of the
Great Lakes; carried 511 million short tons of cargo (1967); Great Lakes,
154 million short tons (1967)
Pipelines: petroleum, 70,000 mi.; major crude, 53,000 mi. products; gas,
200,000 mi. major transmission
367
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNICATIONS (cont''d):
Ports: 25 major
Merchant marine: 2,278 ships (1,000 GRT or over)
Civil air: 3,380 major transport aircraft
Airfields: 10,470 (1968)
Telecommunications: 4,138 AM, 1,737 FM, 619 TV operating stations (1968);
109,124,000 telephones (1968), 53.95 telephones per 100 population (1968)
DEFENSE FORCES:
Personnel: army 1,570,186, navy 765,232, air force 904,759, marines 307,252 (1968) =
Military budget: $80.5 billion (1968)
x
|
?
368
FOR OFFICIAL USE ONLY
LL EE I a a eT LS a eT aT TON Le a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
30 A
Approved For Release 2004/08/31 :
CIA-RDP79-01051A000400010001-2
3 150 ey "st
: i
! 1
AF BE
SVERDRUP TSLANDS., ey
vg) : ee Se
= Gh,
Ss Se? at Se
on St ee Le .
a Rograss Ee SM 4 GREENLAND . :
a i on et = ‘ as 75
gk anaes NEW SIBERTANS. EAST SH BERIAN SEA
—_ an “f ?
SOS ce eee xP | |
Be pelo - =: 7 mi Novara ZEMLYA ~ SS =3I weandet- L
ow FEA UE OR Victoriat. a NS Po “ | ee corp
* aa we et ee
oo ee q Ae satin Zoo A yep
J —~e, : ‘ atin :
eee y A ee moh '' “s i °
A. é f - 4 t oy,
. ; '' _
, | Ye
ost UNITED STATES | ho Se
: (ALASKA) |
T+ | “ox
loa i 4 St Lowence he
é “TFacROE 1s, we
copa A paritin = $ aia ey
, ORKNEY IS. 5”
: ¥
ENT OF SOVIET SOCIALIST REPUBLICS
er : ade
‘ Sf
1 ap OO is
fo ‘
aan QUEEN CHARLOTT] : oe ftw te
| H 4 pa
: NEWFOUNDLAND ! a ALEUTIAN ISLANDS
H . ore CHANNEL 18... SLT
i paen)
opal é
cai i
I
| i
46, E
|
|
NORTH ones
, UNITED STATES By 2
y L + a x
| | . hy ae OiR T H
i
‘. 3 N O
| APGHANI No -
i Pp A C | F | iC BERMUDA IS. MADEIRA IS. 4 anisra ares bp
i ! teed ‘
co ; past YY IP A Cl F IE .
— A T L A ; C CANARY 1S. PAKISTAN chive 8 i \\
+ / ; ’ / aes Séa oot BONIN IS } i
O C E A Ni “7 gaHAMA IS . Okinawar & a FAWAHAN IS.
\\ an SPANISH —— ‘ | :
| Loy SAHARA, Fo gat | VOLCANO IS. | Marcus 1.
| F H j :
i i { “ i MACA\\ _ cawwan O C E A N
wa +, UNITED STATES '' : = Oc — 1 =
\\WAIIAN 1S. : ; DOMINICAN 7
caalran) i wo’ ad JAMAICA REPUBLIC MAURITANIA ‘ wate |
i f | : | 7 HONDURAS “oe "Puerto Rico’, Antigua o y }; NIGER MARIANA 1S |
: i : '' Ts et SS —HORBURAS CAHSEE AN seteemupe CAPE wen j MAL a CHAD !
vs | 7 ag on ma ; Sp rurens a |
Hl “ : * | ''Barbad : 4 elt ra moUN A “Guam
| : : i - Meanacus seo 4 OP Grenada NIDAD PORT. CURE TN oo VOUTA =) * ! LACCADIVE. IS ‘ , i
t 1 1 ap - . pe 7 oe oD
l Clipperton 1. : COSTA RICK ONE a pee AND GUINEA ‘ 7, DAVOMEY - CAROLINE +8 ''
: : : : (santas $ WENEZUEL AL : 4 by SP CeYLOr : 1
i t : H RANAMIy SIERRA, LEONE IvoRY taf \\ x TRUK IS. MARSHALL
: ‘ ia f COAST " a ! -
Palmyra t. : : : y naa UBERIA GO Gone REPUBLI | — |
¥ ! i : t FRENCH GUIANA weet oo | . MALDIVE IS | H
| . : : | i + COLOMBIA f* pane 8 '' : GILBERT IS
H ‘Christmas |. | ! :
: - GuLs A i :
se} 7 " + i : :
rr '' ae : | GaunPagos SE ECUADOR ; : : . : rr T °
. : : : . . ; | Nee - | . \\
: ! § OU TH | i ST) OF THE ay Siiseor i
i RY CONGO chaos CAND SR
'' | : | : ‘ SEYCHELLES ARCHIPELAGO " NEW GUINEA SRA, | | ELUICE ts.
: i i L Ascension {. oy aA ee foe : Rn, SOtOMON Stans od
i H : : I ., te ° ‘
: Pe | : : : H ! : NA NR + BAS \\
: enchryn MARQUESAS I5. > PA CH FEC | “PERU | |; Christmas SE we
! i ! ! : COMORO IS | .C000S IS. | ! ae 8 ~ ° ,
| | i o a | : : \\ . }
t : ‘ | 4 4 iS t | COREL ia ! : a
- i i i i aan i aad SAMOA IS? - ;
* t TOAROTU - =~ 7 j oo t a = i t te cae 18
one''s | ARCHIPELAGO! OC E A WN i . : y i { : | NEW HEBRIDES ro PUTS
COOK IS. Satan i ‘ : | MALAGASY Loy 1 Ly : SEA : QS
| : | H H '' : | REPUBLIC = mauatws | N D i A N H : s | a
i | { : | '' : | ! Ne
TUBUAL IS. i | : i : : '' REUNION '' : ! : New Caledoniaty “©
| : Po ~ 5 OU | | | |
: i a : . ‘
| Pica. bucie | ’ | i oe | e AUSTRALIA
. : | Easter t.: : i | I : CF | | ! N i
; : : i | | | REPUBLIC ! '' ! '' :
| | pad gene e) C E A ON or
Q on woot ot — — : ae i ——— — , an 30]
: : A T I A WN Tf Cc [SOUTH AFRI | ! n ; Lord Mowe t! | KERMADEC 75
JUAN FERNANDEZ IS ’ - '' 1 ¢ i | L a 4
i : ! fo Ree ; i | Nooo Ss : |
| i . oo” i M Sey i iN
! j Tastan da Cunha : i : : Amsterdam 1. ~~} } i Se
'' | : : | "Saint Pout I Ste i PAS MAN | wew J 2
Gough i : : i '' ¢ i ZEALANDS,
O CEA N: ae | fea MON
| . | ; | | TASMAN, cop
H | : : Loe “od CHATHAM IS
sh — . a | -- + te enn _ . ana ja
j . : i PRINCE EDWARD IS. CROZET IS. | (hoy !
| H | | ’ : / 8B BOUNTY IS |
! : i KERGUELEN IS. '' . ''
; i | the : : ANTIPODES 1S
: Ss AUCKLAND tS.
: i | \\ |
H | | | i : | MACQUARIE 1... !
‘ : |
| NoWIGn r BOUNDARY permesewration ''s |
i : _ SANDWICH JS. NOT NECESSARILY AUTHORITATIVE i | i
H : i i i L
Tes an 13s To 30 30 Te 30 35 er 75 3D 705 120 Te
Approved For Re
lease 2004/08/31 : CIA-RDP79-01051A000400010001-2
Ter
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
FOR OFFICIAL USE ONLY
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2','bb9678b8771a188dafd51f3fe256a3951adcef3120107efd263d2019ca223add','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2463ca6c06a121109b167261539812a4182c92f086afd01cfe969ca0b36393d6',1971,'','','communications',4,'Railroads: 6 mi. (single track) 5''O"-gage, government-owned spur of Soviet line
Highways: 10,740 mi.; 420 mi. concrete, 980 mi. bituminous surfaced, 2,100 mi.
gravel, 3,630 mi. improved earth, and 3,610 mi. unimproved earth
Inland waterways: total navigability 760 mi.; steamers use Amu Darya
Ports: only minor river ports
Civil air: 5 major transport aircraft
Airfields: 64 total, 35 usable; 9 with permanent-surface runways ; 6 with runways
8,000-11,999 ft., 12 with runways 4,000-7,999 ft.
Telecommunications: limited telephone, telegraph, and radiobroadcast services,
barely sufficient to meet civil and military requirements; 13,967 telephones ;
200,000 radio receivers; no IV receivers; 1 AM, no FM, no TY stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1971, $28.8 million; 16.3%
of total budget
2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 20 ALBANTA
"11,100 sq. mi.; 19% arable, 24% other agricultural, 43%
forested, 14% other (1967)
Land boundaries: 445 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 225 mi. (including Sazan Island)
Railroads: 127 mi. standard gage, single track; government owned (1971)
Highways: 3,100 mi.; 300 mi. paved, 1,200 mi. crushed stone and/or gravel, 1,600
mi. improved or unimproved earth (1971)
Inland waterways: 27 mi. plus Albanian sections of Lake Scutari, Lake Ohrid,
and Lake Prespa (1971)
Freight carried: rail -- 2.8 million short tons, 109.6 million short ton/mi. (1970);
highways -- 31 million short tons, 519.9 million short ton/mi. (1970)
Merchant marine: 11 cargo ships (1,000 GRT or over) totaling 53,000 GRT, 72,700
DWT, includes 8 cargo, 3 bulk
Pipelines: crude oil, 110 mi.
Civil air: no major transport aircraft (1971)
4
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Nrs 4Approved For Release 2004/08/31 4; GHAsRDP79-01051A000400010002-1
LAND:
950,000 sq. mi.; 3% cultivated, 16% pasture and meadows,
1% forested, 80% desert, waste, or urban (1967)
Land boundaries: 3,890 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 735 mi.
Railroads: 2,414 mi.; 1,660 mi. standard gage, 663 mi. 3''5 9/16" gage, 91 mi.
meter gage; 188 mi. electrified; 120 mi. double track
Highways: 40,600 mi., of which 17,000 mi. are concrete or bituminous and the
remainder gravel or crushed stone
Ports: 9 major, 8 minor
Merchant marine: 10 ships (1,000 GRT or over) totaling 80,100 GRT, 116,300 DWT;
includes 6 cargo, 2 tanker, 1 bulk, 1 specialized carrier
Pipelines: crude oil, 2,251 mi.; refined products, 177 mi.; natural gas, 494 m.
Civil air: 21 major transport aircraft
Airfields: 233 total, 186 usable; 55 with permanent-surface runways; 17 with
runways 8,000-11,999 ft., 109 with runways 4,000-7,999 ft.; 3 seaplane
stations
Telecommunications: adequate domestic and international facilities in the north,
primarily radio communications in the desert; 182,000 telephones; 1,100,000
radio receivers; 250,000 TV receivers; 16 AM and 9 TV stations; 3 submarine
cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, $99,250,000;
approximately 4.1% of national budget
6
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS gApproved For Release 2004/08/31); GIA RDP79-01051A000400010002-1
LAND:
180 sq. mi. (1968)
Land boundaries: 65 mi.
PEOPLE : cae
Population: 24,000, average annual growth rate 9.6% (FY65-69)
Ethnic divisions: Catalan stock; 44% Andorrans, 50% be
Spanish, 3% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French and
Castilian
Labor force: unorganized; largely shepherds and farmers
Railroads: none
Highways: about 60 mi.
Civil air: no major transport aircraft
Airfields: none
Teleconmunications: 2 AM and 1 FM radiobroadcast facilities, I TV repeater
station; manual telephone system serving about 1,700 telephones; 8,000
radio receivers, 2,500 TV receivers
7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
DEFENSE FORCES:
Andorra has no defense forces; Sp
as needed
ain and France are responsible for protection
8
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
sgPProved For Rele ANCOR
NIS
LAND:
481,000 sq. mi.; 1% cultivated, 44% forested, 22% meadows
and pastures, 33% other (including fallow) (1965)
Land boundaries: 3,150 mi.
WATER: ae
Limits of territorial waters: claims 6 n. mi. (fishing
12 n. mi.)
Coastline: 1,000 mi.
PEQPLE:
Population: 5,745,000, average annual growth rate 1.6%
(December 60-70); males 15-49, 1,422,000, fit for military
service, 710,000; average number reaching military age (20) annually about
60,000
Ethnic divisions: 93.6% Negro, 5% Europeans, 1.4% mulatto (1960)
Religion: about 84% animist, 12% Roman Catholic, 4% Protestant
Language: Portuguese (official), many native dialects
Literacy: 10%-15%
Labor force: 2.6 million economically active (1964); 531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)
Railroads: 1,918 mi.; 1,724 mi. 3''6" gage, 194 mi. T''1l 5/8" gage
Highways: 29,000 mi.; 3,000 mi. bituminous-surface treatment, 1,000 mi. crushed
stone or gravel, 25,000 mi. earth
Inland waterways: 2,000 mi. navigable
Ports: 3 major
Pipelines: crude oi], 111 mi.
Civil air: 12 major transport aircraft
Airfields: 448 total, 392 usable; 19 with permanent-surface runways; | with
runway over 12,000 ft., 5 with runways 8,000-11,999 ft., 55 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: simple network of low-capacity open-wire and radio-relay
facilities; 25,300 telephones; 95,000 radio receivers; 21 AM, 7 FM, and no
TV stations
DEFENSE FORCES:
Defense is responsibility of Portugal
Supply: dependent on Portugal
Military budget: for fiscal year ending 31 December 1969 $45.7 million; about
16.7% of total budget
10
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS g{ppProved For Release 2004/08/34. ClA -RDP79-01051A000400010002-1
LAND:
~ 108 sq. mi.; 54% arable, 5% pasture, 14% forested,
9% unused but potential ly productive, 18% wasteland
and built on (1964)
WATER: ‘ a
Limits of territorial waters: 3 n. mi. ei ae
Coastline: 95 mi. Guvanay
Railroads: 25,000 mi.; 2,000 mi. standard gage (4''8 1/2"), 13,750 mi. broad
gage (5''6") 8,750 mi. meter gage (3''3 3/8"), 500 mi. 2''5 1/2" gage;
about 1,035 mi. double track; 76 mi. electrified; 99.6% government-owned
Highways: 125,000 mi., of which 13,800 mi. paved, 16,000 mi. gravel, 49,300
mi. improved earth, and 45,900 mi. unimproved earth
Inland waterways: 6,800 navigable mi.
Ports: 7 major, 2]
Merchant marine: 178 ships (1,000 GRT or over) totaling 1,187,000 GRT,
1,619,000 DWT; includes 6 passenger, 98 cargo, 59 tanker, 10 bulk,
5 specialized carriers; 3 tankers and 4 combination cargo-transport ships
are naval vessels sometimes used commercially
Pipelines: crude oi], 1,163 mi.; refined products 1,374 mi.; natural
gas, 4,061 mi.
Civil air: 58 major transport aircraft
Airfields: 2,110 total, 1,517 usable; 64 with permanent-surface runways ;
1 with runway over 12,000 ft., 14 with runways 8,000-11,999 ft., 235 with
runways 4,000-7,999 ft.; 10 seaplane stations
Teleconmmunications: foremost in telecom facilities in South America; improving
telephone network has slightly over 1.6 million sets, radio relay widely
used, communications satellite ground station; estimated 6.5 million radio
receivers and 3.3 million TV sets; 100 AM, 3 of which are FM, and 30 TV stations;
8 telegraph submarine cables
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1970,
$514,150,000 about 15% of total central government budget
14
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 1Approved For Release 2004/08/31 ¢ @}A7RDP79-01051A000400010002-1
LAND:
32,400 sq. mi.; 20% cultivated, 27% meadows and pastures,
14% waste or urban, 38% forested, 1% inland water (1968) eae
Land boundaries: 1,605 mi. eee (nee "oes
Railroads: 4,073 mi.; 3,612 mi. standard gage, 833 mi. double tracked; 433 mi.
2''5 7/8" gage, and 28 mi. electrified 3''3 3/8" narrow gage; 1,584 mi.
electrified
Highways: 20,356 mi. total; 6,056 mi. Federal (5,656 mi. bituminous, concrete,
stone block, 400 mi. crushed stone, gravel, improved earth); 14,290 mi.
Provincial (4,340 mi. bituminous, concrete, stone block, 9,950 mi. crushed
stone, gravel, improved earth); additionally about 38,000 mi. of communa 1
roads, mostly of gravel, crushed stone, and improved earth
Inland waterways: 267 mi.; carries 5% freight, 6% passengers
Ports: 3 major
Merchant marine: 4 ships (1000 GRT or over) totaling 12,900 GRT, 17,000 DWT;
includes 3 cargo, 1 specialized carrier
Pipelines: crude oil, 450 mi.; natural gas, 535 mi.
Civil air: 9 major transport aircraft
Airfields: 58 total, 47 usable; 1] with permanent-surface runways; 2 with run-
ways 8,000-11,999 ft., 8 with runways 4,000-7,999 ft.
Telecommunications: highly developed and efficient; excellent national and
international services; extensive TV and radiobroadcast systems with 13 AM,
14 FM, and 19 TV stations; 1.33 million telephones; 2 million radio receivers;
1.38 million television receivers
DEFENSE FORCES:
Supply: produces some small arms and ammunition, trucks, and tank destroyers;
current sources of other items are the U.S., Western Europe, Sweden,
and the Communist countries
Military budget: for fiscal year ending 31 December 1971, $165.3 million; about
3.9% of the federal budget and 1.2% of GNP
18
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS approved For Release Sunine
LAND:
4,400 sq. mi.; 1% cultivated, 29% forested, 70% built
on, wasteland, and other (1962)
WATER:
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.) =
Coastline: 2,200 mi. (New Providence Is. 47 mi.) {VENEZUELA
1 coLomBia
Railroads: none
Highways: 555 mi.; 380 mi. paved, 100 mi. gravel, 20 mi. improved earth; 55 mi.
unimproved earth
Ports: 5 major, 9 minor
19
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATION RESNER: For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Civil air: no major transport aircraft
Airfields: 56 total, 53 usable; 13 with permanent-surface runways ; 3 with
runways 8,000-11,999 ft., 22 with runways 4,000-7,999 ft.; 4 seaplane
stations
Telecommunications: telecom facilities highly developed, including 53,800
telephones in totally automatic system; tropospheric scatter link with
Florida; 55,000 radio receivers and 16,000 TV sets, 1 AM station; 2 special
coaxial submarine cables; plan TV station for color broadcasts and new cable
connection with the United States
i 20
pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Nts #PProved For Release 2004/08/31 pd AaRDP 79-01051A000400010002-1
LAND:
230 sq. mi. plus group of smaller islands; 5% cultivated,
negligible forested area, remainder desert, waste,
or urban
WATER:
Limits of territorial waters: claim is 3 n. mi.
Coastline: 100 mi.
Highways: 120 mi. bituminous surfaced; undetermined mileage of natural surface
tracks
Ports: 1 major
Pipelines: crude oi], 34 mi.; refined products, 9 mi.; natural gas, 19 mi.
Civil air: 8 major transport aircraft (all registered in the U.K.)
Airfields: 5 total, 3 usable; 1 with permanent-surface runway; 1 with runway over
12,000 ft; 1 with runway 4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent international radiocommunications; limited
domestic services; 10,800 telephones; 56,500 radio receivers; 10,000 TV sets;
1 AM radiobroadcast station; satellite earth station; tropospheric scatter
Bahrain-Qatar
2]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS Approved For Release 2004/08/31 BG ApROP79-01051A000400010002-1
LAND:
166 sq. mi.; 60% cropped, 10% permanent meadows, 30% built
on, waste, other (1960)
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 60 mi. VENEZUELA
PEOPLE: COLOMBIA
Population: 257,000, average annual growth rate 0.2%
(April 60-70); males 15-49, 53,000; 38,000 fit for @RAZIL
military service; average number reaching military age,
(18) annually, 3,000; no conscription
Ethnic divisions: 80% African, 15% mixed, 5% European
Religion: Anglican, Roman Catholic, Methodist, and Moravian
Language: English
Literacy: over 90%
Labor force: 60,000 wage and salary earners
Organized labor: 19,300 (32%)
Railroads: none
Highways: 950 mi.; 800 mi. paved, 100 mi. gravel, 50 mi. improved earth
Ports: 1 major, 2 minor
Civil air: 1 major transport aircraft
Airfields: 1 with permanent-surface runway 8,000-11,999 ft.; 1 seaplane station
Telecommunications: islandwide automatic telephone system with 26,100
telephones; key international traffic transit center for Caribbean area;
tropospheric scatter links to Trinidad and St. Lucia; 86,000 radio and
16,000 TV sets, 2 AM and 1 TV stations; 2 telegraph submarine cables; planned
construction of satellite earth station to be operational in 1972
DEFENSE FORCES:
Supply: obtained primarily from the U.K.; some ammunition from Belgium
24
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 93 Approved For Release 2004/08/$1 v IGIA-RDP79-01051A000400010002-1
424,000 sq. mi.; 2% cultivated and fallow, 11% pasture
and meadow, 45% urban, desert, waste, or other,
40% forest, 2% inland water (1967)
Land boundaries: 3,780 mi.','422831ae7fec42733a50fa976cdaa2c1fdfbd140d084fd40203693974412b908','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1100a5f61cdf97ca6d56cba02b0179255e31fd820d0d332bf9ff31591db2303b',1971,'BR','Brazil','communications',19,'Railroads: 2,873 mi.; 2,645 mi. standard gage, 1,615 mi. double track, 920 mi.
electrified; 228 mi. (3''3 3/8") narrow gage
Highways: 57,700 mi.; 26,550 mi. bituminous, stone block, or concrete; 31,150
mi. crushed stone, gravel, earth
Inland waterways: 1,270 mi., of which 950 are in regular use by commercial
transport
Ports: 5 major, 1 minor
Merchant marine: 78 ships (1,000 GRT or over) totaling 1,801,900 GRT, 1,616,000
DWT; includes 1 passenger, 50 cargo, 13 tanker, 12 bulk, 2 specialized carrier
Pipelines: refined products, 400 mi.; crude, 50 mi.; natural gas, 45 mi.
Civil air: 57 major transport aircraft, including 6 based’in Libya
Airfields: 51 total, 37 usable; 20 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 10 with runways 4,000-7,999 ft.
Telecommunications: excellent domestic and international telephone and
telegraph facilities; 1,937,000 telephones; 3.6 million radio receivers; 2.1]
million TV receivers; countrywide broadcast coverage provided by 7 AM,
10 FM, and 18 TV stations; submarine cables to U.K. and to Portugal
EFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $675.2 million; about
8.3% of central government budget
26
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
: - -01051A000400010002-1
NIS Approved For Release 2004/08/31 BeHARPP 79
LAND:
21 sq. mi.; 8% arable, 60% forested, 21% built on,
wasteland, and other, 11% leased for air and
naval bases (1964)
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 64 mi.
INITED STATES
Railroads: none
Highways: 130 mi., all paved
Ports: 4 major
Civil air: no major transport aircraft
Airfields: 1 with concrete runway 9,660 ft.; 1 seaplane station
Telecommunications: modern telecom system suited to island needs, includes fully
automatic telephone system with 28,100 instruments; 29,000 radio and
17,000 TV receivers, 2 AM, 1 FM, and 2 TV stations; 3 submarine coaxial cables
27
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 35 BHUTAN
LAND:
19,000 sq. mi.; 15% agricultural, 15% desert, waste,
urban, 70% forested (1963)
Land boundaries: about 540 mi.
aes 810 mi.; 260 mi. surfaced, 320 mi. improved, 230 mi. unimproved
eart
Freight carried: not available, very light traffic
Civil air: no major transport aircraft
29
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIRRY WySS Foy Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Airfields: 1 composite runway under 6,000 feet
Telecommunications: facilities almost nonexistent; data not available on
telephones; 6,000 radio sets; no TV sets; data not available on AM; no
FM; and no TV stations
DEFENSE FORCES:
Supply: dependent on India
30
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS gfPProved For Release 2004/08/31, -ClARDP79-01051A000400010002-1
LAN
Railroads: 400 mi. 3''6" gage, single track; owned and operated by the Rhodesia
Railroads
Highways: 5,016 mi.; 16 mi. paved, 471 mi. crushed stone, gravel, or stabilized
soil; 4,529 mi. improved or unimproved earth
Inland waterways: native craft only; of local importance
Civil air: 12 major transport aircraft
Airfields: 81 total, 70 usable; 2 with permanent-surface runways; 19 with
runways 4,000-7,999 ft.
Telecommunications: the system is a minimal combination of a single main wire
line and a few radiocommunication stations; Gaberone is the center; 3,500
telephones; 20,000 radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Police only
34
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
: - 9-01051A000400010002-1
NIS gfPProved For Release 2004/08/31 val RDP?
LAND:
3,290,000 sq. mi.; 4% cultivated, 14% pastures, 14%
waste, urban, or other, 13% fallow, idle, or
woodlot, 55% forested (1970)
Land boundaries: 8,125 mi.
WATER:
Limits of territorial waters: 200 n. mi.
Coastline: 4,655 mi.
Railroads: 20,160 mi.; 17,886 mi. 3''3 3/8" gage, 1,982 mi. 5''3" gage, 121 mi.
4''8 1/2" gage, 171 mi. narrow gages; 1,692 mi. electrified
Highways: 583,800 mi.; 26,300 mi. paved, 36,700 mi. gravel, and 520,800 mi. of
improved and unimproved earth
Inland waterways: 31,000 mi. navigable
Ports: 6 major, 24 minor
Pipelines: crude oi], 633 mi.; refined products, 139 mi.; natural gas, 24 mi.
Merchant marine: 210 ships (1,000 GRT or over) totaling 1,492,800 GRT, 2,171,500
DWT; includes 2 passenger, 132 cargo, 47 tanker, 22 bulk, 7 specialized
carrier; includes 3 naval tankers sometimes used commercially
Civil air: 112 major transport aircraft
Airfields: 2,416 total, 2,077 usable; 113 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 306 with runways 4,000-7,999 ft.; 18 seaplane
stations
Telecomnunications: extensive telecom facility expansion programs; radio relay
widely used; communications satellite ground station; almost 1.8 million
telephones; est. 10.5 million radio and 6 million TV receivers; 850 AM,
145 FM, and 50 TV stations (plus relays); 10 telegraph submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1969, $736,339,520; 19.5%
of federal budget
36
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
WieGe Approved For Release 2004/08/34, Gua RE 79-01051A000400010002-1
LAND:
8,870 sq. mi.; 38% agricultural (5% cultivated), 46%
exploitable forest, 16% urban, waste, water,
offshore islands or other (1966)
Land boundaries: 320 mi.
WATER: : VENEZUELA
Limits of territorial waters: 3 n. mi.
Coastline: 240 mi.
PEOPLE: BEAr
Population: 126,000, average annual growth rate 2.9%
(April 60-70); males 15-49, 28,000; 16,000 fit for
military service; 1,500 reach military age (18) annually
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican, Seventh-day Adventist, Methodist,
Baptist, Jehovah''s Witnesses, Mennonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 26,000; 41% agriculture, 19% manufacturing, 8% commerce, _
12% construction and transportation, 20% services; shortage of skilled
labor and all types of technical personnel; over 15% are unemp1oyed
Organized labor: 8% of labor force
Railroads: none
Highways: 1,350 mi.; 150 mi. paved, 600 mi. improved (gravel, earth), 600 mi.
unimproved
Inland waterways: 514 mi. river network used by shallow-draft craft
Ports: 1 major, 4 minor
Civil air: no major transport aircraft
Airfields: 49 total, 29 usable; 2 with permanent-surface runways; 1 with
runway 4,000-7,999 ft.; 1 seaplane station
Telecommunications: meager but adequate facilities; Belize City center of
2,405 telephone network; over 48,000 radio receivers; 2 AM stations; no
submarine cables
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 44 BRUNEI
LAND:
2,230 sq. mi.; 3% cultivated; 3% industry, waste, or
urban; 94% forested
Land boundaries: 237 mi.
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 136 mi.
Railroads: 6 mi. narrow gage (2'')
Highways: 750 mi.; 110 mi. paved (bituminous treated), 220 mi. gravel or stone,
420 mi. unimproved
39
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICAT FORE" ONGE Foc Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Inland waterways: 130 mi.; navigable by shallow-draft craft
Ports: 2 minor (Bandar Seri Begawan, formerly Brunei, and Kuala Belait)
Pipelines: crude oil, 84 mi.; refined products, 35 mi.; natural gas, 35 mi.;
crude oi] and natural gas, 150 mi. under construction
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface runway; 1 with runway
over 12,000 ft., 2 with runways 4,000-7,999 ft.
Telecommunications: service throughout country is adequate for present needs ;
international service good to adjacent Sabah and Sarawak; radiobroadcast
coverage good; 3,819 telephones; 13,000 radio sets; Radio Brunei
broadcasts from 3 stations and uses 4 mediumwave and 1 shortwave
transmitter
DEFENSE FORCES:
Defense is responsibility of U.K.; Brunei has an indigenous military force of
about 1,150; about 1,100 police are maintained
Military budget: for fiscal year ending 31 December 1970, $9.8 million for the
military and $7.1 million for the police; about 15% of the total budget
40
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 23 BULGARIA
LAND:
42,800 sq. mi.; 41% arable, 11% other agricultural,
33% forested, 15% other (1966)
Land boundaries: 1,170 mi.
WATER: :
Limits of territorial waters: 12 n. m.
Coastline: 220 mi.
Railroads: 2,650 mi.; about 2,470 mi. standard gage, 180 mi. narrow gage; 127 mi.
double track; 477 mi. electrified; government owned (1971
Highways: 20,700 mi.; 7,900 mi. paved, 8,100 mi. crushed stone and gravel,
4,700 mi. earth (1971)
Inland waterways: 300 mi. (1971)
Freight carried: rail -- 75.2 million short tons, 8.9 billion short ton/mi.
(1970); highway -- 511.5 million short tons, 4.7 billion short ton/mi. (1970);
waterway -- 3.5 million short tons, 1.2 billion short ton/mi. (1970)
Merchant marine: 108 ships (1,000 GRT and over) totaling 675,200 GRT, 974,200
DWT; includes 5 passenger, 56 cargo, 18 tanker, 29 bulk
Pipelines: crude oil, 41 mi.; natural gas, 29 mi.; refined, 3 mi.
42
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 38 BURMA
LAND:
262,000 sq. mi.; 23% arable, of which 12% is cultivated,
67% forest, 10% urban and other area (1965)
Land boundaries: 3,630 mi.
WATER:
Limits of territorial waters: 12 n. mi. (extended base
lines 15 November 1968)
Coastline: 1,200 mi.
Railroads: 2,022 mi.; 1,952 mi. meter gage, 70 mi. narrow-gage industrial lines;
204 mi. double track; government owned
Highways: 15,540 mi.; 4,210 m. paved, 4,770 mi. gravel, 5,810 improved earth,
750 mi. unimproved earth
Inland waterways: 8,000 mi.; 2,000 mi. navigable by large commercial vessels
Ports: 4 major, 6 minor
Merchant marine: 9 cargo ships (1,000 GRT or over) totaling 55,500 GRT, 73,800
DWT
Airfields: 118 total, 83 usable; 20 with permanent-surface runways ; 2 with
runways 8,000-11,999 ft., 37 with runways 4,000-7,999 ft.; 2 seaplane
stations
Telecommunications: provide minimum requirements for local intercity service;
international service is fair; radiobroadcast coverage is limited to the
more populous areas; 24,654 telephones; 500,000 radio sets; 1 AM, 1 FM,
and no TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 September 1971; $126 million, an
estimated 35% of total budget
Approved For Release 2004/08/34*: CIA-RDP79-01051A000400010002-1
f
Nis 6gyPProved For Release 2004/08/31 2 (lA FR }DP79-01051A000400010002-1
LAND:
Railroads: 409 mi. meter gage; government owned
Highways: 9,340 mi.; 1,600 mi. bituminous, 1,000 mi. crushed stone, gravel, or
laterite; 275 mi. improved earth; and 6,465 mi. unimproved earth
Inland waterways: 1,220 mi. during high water, 1,010 mi. during low water;
90% of total navigability on Mekong system and Tonle Sap
Freight carried: (1968) rail -- 50 million ton-miles; waterway -- approximately
300,000 short tons annually; figures unavailable for highways
Ports: 2 major, 6 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,398 GRT, 2,600 DWT;
Airfields: 94 total, 42 usable; 8 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 10 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: service to general public considered poor; barely adequate
for government requirements; international service fair to adjoining countries
and a few other nations; radiobroadcasts and television coverage limited by
small number of stations and receivers; 8,024 (est.) telephones; 102,500
radio receivers; 25,000 (est.) TV receivers; 1 AM, 2 AM relay, no FM, and 1 TV
station; no submarine cables
Approved For Release 2004/08/51 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 52 CAMEROON
LAND:
183,400 sq. mi.; 4% cultivated, 18% grazing, 13% fallow,
50% forest, 15% other (1964)
Land boundaries: 2,830 mi.
WATER:
Limits of territorial waters: 18 n. mi.
Coastline: 250 mi.
Railroads: 623 mi.; 533 mi. meter gage, 90 mi. 1''11 5/8" gage
Highways: approximately 8,545 mi.; 765 mi. BST, 7,780 mi. gravel, laterite, or
improved earth
Inland waterways: 1,300 mi.
Ports: 1 major, 3 minor
Civil air: 4 major transport aircraft
Airfields: 59 total, 55 usable; 5 with permanent-surface runways ; 1 with runway
8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: good telephone service between Douala and Yaounde, fair in
southern part; fair to good telegraph service; 5,800 telephones; 211,500
radio receivers; 4 AM, no FM, and no TV stations, limited wired broadcast;
1 submarine cable
DEFENSE FORCES:
Supply: mostly from France
Military budget: for fiscal year ending 30 June 1972, $24,174,500; 14.0% of
total budget
50
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Nrs Approved For Release 2094(08/3 1 -ClAsRDP7 90 4051A000400010002-1
LAND:
242,000 sq. mi.; 10%-15% cultivated, 5% dense forests,
80-85% grazing, fallow, vacant arable land, urban,
waste (1966 est.)
Land boundaries: 3,095 mi.
Railroads: none
Highways: 13,250 mi.; 50 mi. bituminous, 2,330 mi. gravel and/or crushed stone,
3,420 mi. improved earth, 7,450 mi. unimproved earth
Inland waterways: 4,400 mi.; traditional trade carried on by means of dugouts
on the extensive system of rivers and streams; only the Oubangui River
between Bangui and Brazzaville and short sections of the Sangha and the
Lobaye Rivers are navigable throughout year; during high-water period
(July - December) Oubangui navigable upstream from Bangui as far as Quango
Port: Bangui, Ouango (river ports )
Civil air: 4 major transport aircraft
Airfields: 65 total, 49 usable; 3 with permanent-surface runways ; 1 with runway
8,000-11,999 ft., 15 with runways 4,000-7,999 ft.
Telecommunications: facilities are meager and provide only barely sufficient
services; principal network is 39 low-capacity, low-powered radiocommunica-
tion stations; no cables or radio relay links are used; single center of
Bangui has only international radio connections ; 3,500 telephones; 46,000
radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Supply: completely dependent on France
Military budget: for fiscal year ending 31 December 1970, $4,878,000; about
11.2% of ordinary budget
Approved For Release 2004/08/34 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 37 CEYLON
LAND:
25,300 sq. mi.; 23% arable; 20% desert, waste, or urban;
54% forested; 3% inland water (1968)
WATER: {
Limits of territorial waters: 12 n. mi. (fishing, 12 n.
Coastline: 835 mi.
Railroads: 938 mi.; 851 mi. 5''6" gage, 87 mi. 2''6" gage; 63 mi. double track;
no electrification; government owned
Highways: 25,580 mi.; 11,700 mi. paved (mostly bituminous treated), 11,500 mi.
crushed stone or gravel, 530 mi. improved earth, 1,850 mi. unimproved earth;
in addition several thousand mi. of tracks, mostly unmotorable
Inland waterways: 270 mi.; navigable by shallow-draft craft
Ports: 3 major, 9 minor
Airfields: 17 total, 13 usable; 13 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: an inadequate telephone and a less extensive but more
efficient telegraph system serves most areas, with greatest concentration
around Colombo and Kandy; all areas are served by radio and/or wire
broadcast; excellent international service; 60,841 telephones; 500,000 radio
sets, no TV sets; 1 AM (plus 4 repeater stations), no FM, and no TV stations;
submarine cables extend to India, Malaysia, Seychelle Islands, and Aden
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ge
Approved For Release 2004/08/31 ;, CIA-RDP79-01051 :
NIS 52A one A000400010002-1
ND:
496,000 sq. mi.; 17% arable, 35% pastureland, 2% forest
and scrub, 46% other uses and waste (1967)
Land boundaries: 3,720 mi.
Railroads: none
Highways: 19,200 mi.; 160 mi. bituminous, 3,300 m. gravel and laterite, and
15,740 mi. unimproved
Inland waterways: approximately 1,300 mi.
to 3,000 mi. during high-water period
Civil air: 3 major transport aircraft
Airfields: 74 total, 60 usable; 4 with permanent-surface runways ; 1] with runway
8,000-11,999 ft., 18 with runways 4,000-7,999 ft.
Telecommunications: fair system of radiocommunication stations only for intercity
links; principal center Fort-Lamy, secondary center Fort-Archambault; 4,200
telephones; 60,000 radio receivers; 1 AM, 1 FM, and no TV stations
of year-round navigability, increased
58
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 89 CHILE
WATER:
Railroads: 5,090 mi.; 1,930 mi. 5''6" gage, 230 mi. 4''8 1/2" gage, 200 mi. 3''6"
gage, 2,590 mi. 3''3 3/8" gage, 80 mi. 2''6" gage, 60 mi. 1''1l1 5/8" gage,
133 mi. double track; 437 mi. electrified
Highways: 40,000 mi.; 4,600 mi. paved, 19,900 mi. gravel, 15,500 mi. improved
and unimproved earth
Inland waterways: 451 mi.
Pipelines: crude oil, 380 mi.; refined products, 510 mi., natural gas, 200 mi.
Ports: 10 major, 20 minor
Merchant marine: 49 ships (1,000 GRT or over) totaling 400,100 GRIT, 595,100 DWT;
includes 2 passenger, 30 cargo, 6 tanker, 9 bulk, 2 specialized carrier;
includes 2 naval tankers and 1 transport sometimes used commercially
Civil air: 48 major transport aircraft
Airfields: 431 total, 302 usable; 40 with permanent-surface runways; 2 with run-
ways 8,000-11,999 ft., 53 with runways 4,000-7,999 ft.; 7 seaplane stations
Telecommunications: extensive radio relay network under construction; telephone
network modern but with only 349,000 instruments; communications satellite
ground station; est. 2.5 million radio and 500,000 TV receivers, 137 AM,
30 FM, and 15 TV stations
Approved For Release 2004/08/31°9 CIA-RDP79-01051A000400010002-1
NIS {gpProved For Release 2094(08/34,, ClA-RIBY 40 195 1A000400010002-1
LAND:
WATER:
3.7 million sq. mi.; 11% cultivated, sown area extended by
multicropping, 78% desert, waste, or urban (32% of
this area consists largely of denuded wasteland,
plains, rolling hills, and basins from which about 3%
ero reclaimed), 8% forested; 2%-3% inland water
1971
Land boundaries: 15,000 mi.
Limits of territorial waters: 12 n. mi.
Coastline: 9,000 mi. Geinauin
Railroads: about 25,000 mi., of which 370 mi. 3''3 3/8" gage, 30 mi. 3''6" gage,
24,600 mi. 4''8 1/2" gage; mostly single track, less than 1% electrified;
government owned
Highways: 325,000 mi.; 1,000 mi. paved, 74,000 mi. gravel and crushed stone,
80,000 mi. improved earth, and 170,000 mi. unimproved earth, including tracks
Inland waterways: 105,000 mi.; 25,000 mi. navigable by modern motorized craft
Ports: 9 major, 157 minor
Airfields: 303 total; 209 with permanent-surface runways; 4 with runways over
12,000 ft., 60 with runways 8,000-11,999 ft., 207 with runways 4,000-7,999
ft.; 1 seaplane station
*In terms of DWI, 65% of the fleet is employed in domestic operations and the remainder
in international operations to Southeast Asia, Africa, Europe, and Japan.
62
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
-01051A000400010002-1
NIS {Approved For Release 2004/0815
7)
oP
A
0
ov
=~
Ooo
PEOPLE''S REP.
OF CHINA
LAND:
14,000 sq. mi. (Taiwan and Pescadores); 24% cultivated,
6% pasture, 55% forested, 15% other (urban, industrial,
denuded, water area) (1969)
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 615 mi. Taiwan, 285 mi. offshore islands
Railroads: 2,823 mi., all narrow gage; 130 mi. double track; 623 mi. government
owned, 2,200 mi. industrial
Highways: 10,300 mi. plus 300 mi. on Penghu and offshore islands; 3,300 mi. paved,
5,000 mi. gravel and crushed stone, 2,000 mi. earth
Ports: 7 major, 9 minor
Merchant marine: 154 ships (1,000 GRT or over) totaling 1,284,000 GRT, 1,906 ,400
DWT; includes 2 passenger, 110 cargo, 12 tanker, 17 bulk, 7 specialized
carrier
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 85 COLOMBIA
LAND:
440,000 sq. mi.; 6% cultivated, 18% meadows and pastures,
53% forested, 5% inland water, 18% built-up area
Land boundaries: 3,750 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 1,500 mi.
Railroads: 2,160 mi., all 3''0" gage, single track, 22 mi. electrified
Highways: 28,600 mi.; 3,700 mi. paved, 19,900 mi. crushed stone or gravel,
3,100 mi. improved earth, 1,900 mi. unimproved earth
Inland waterways: 8,900 mi., navigable by river boats
Pipelines: crude oil, 2,000 mi.; refined products, 828 mi.; natural gas, 370 m.;
natural gas liquids 83 mi.
Ports: 5 major, 5 minor
Merchant marine: 36 ships (1,000 GRT or over) totaling 193,200 GRT, 246,600 DWT;
33 cargo, 3 tanker (includes 2 naval tankers sometimes used comercially)
Civil air: 91 major transport aircraft
Airfields: 727 total, 617 usable; 29 with permanent-surface runways ; 1 with
runway over 12,000 ft.; 6 with runways 8,000-11,999 ft., 76 with runways
4,000-7,999 ft.; 11 seaplane stations
Telecommunications: rapidly improving nationwide telecom system, with UHF relay
system being installed; communications satellite ground station; over 575,000
telephones; est. 6 million radio and 730,000 TV receivers, 253 AM, 132 FM,
and 16 TV stations
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1971, $89.4 million;
about 10.2% of central government budget
6
Approved For Release 2004/08/34 : CIA-RDP79-01051A000400010002-1
Approved For Release 20 0G tg : CIA-RDP79-01051A000400010002-1
NIS 52E CONGO (BRAZZAVILLE)
LAND:
135,000 sq. mi.; 63% dense forest or woodland, 33%
cultivable or grazing (2% cultivated est.), 4% urban
or waste (1970)
Land boundaries: 2,805 mi.
WATER:
Limits of territorial waters: claim 15 n. mi.
Coastline: 105 mi.
Railroads: 490 mi., 3''6" gage, single track
Inland waterways: 4,030 mi. navigable
Ports: 1 major
Civil air: 8 major transport aircraft
Airfields: 69 total, 49 usable; 2 with permanent-surface runways; | with runway
8,000-11,999 ft., 16 with runways 4,000-7,999 ft. ; ] seaplane station
Telecommunications: all services only fair; barely adequate for government and
public; principal network is comprised of 30 low-capacity, low-powered radio
communication stations ; few wire lines connect key centers of Brazzaville,
Pointe-Noire, and Dolisie with maximum of 21 channels; 9,800 telephones ;
65,000 radio receivers ; 1,800 TV receivers; 3 AM, no FM, and 1 TV stations
68
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Rele 2 : = -
r pp ase 004/08/34.. CIA-RDP79 01051A000400010002-1
NIS
19,700 sq. mi.; 30% agricultural land (8% cultivated, 22%
meadows and pasture), 60% forested, 10% waste, urban,
and other (1964)
Land boundaries: 415 mi.
WATER: f ‘ VENEZUELA
Limits of territorial waters: 3.n. mi. (fishing 200 n. mi-. )
Coastline: 800 mi.
Railroads: 407 mi.; 395 mi. 3''6" gage, 12 mi. 3''0" gage, all single track, 72 mi.
electrified
Highways: 11,700 mi.; 850 mi. paved, 3,200 mi. gravel, 7,650 mi. earth
Inland waterways: about 455 mi. perennially navigable
Pipelines: refined products, 75 mi.
Ports: 3 major, 4 minor
Civil air: 10 major transport aircraft
Airfields: 197 total, 120 usable; 10 with permanent-surface runways; 9 with
runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: domestic telephone service greatly improved with new
automatic exchanges; nearly 56,300 telephones; VHF radio system being
installed; 330,000 radio and 100,000 television receivers in use, 45 AM,
9 FM, and 12 TV stations
DEFENSE FORCES:
Supply: dep','d423fc5599d2bbe9d2256bad8046064077ef22978dd7a690233049575fc7404f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7e4fb16c2cf9922b978ebe30617f59335c88509508e40320304ffe7de96ec5e',1971,'BR','Brazil','communications',20,'endent on imports from U.S.
Military budget: for fiscal year ending 31 December 1971, $3.3 million for
Ministry of Public Security, including the Civil Guard; about 2.3% of total
central government budget
70
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
seprover For Release 2004/08/31 : 7 Waa etal acta ha
NIS
LAND:
44,200 sq. mi.; 35% cultivated, 30% meadow and pasture,
20% waste, urban, or other, 15% forested (1968)
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 2,320 mi.
Railroads: 9,150 mi. government owned; 3,150 mi. common carrier lines (8 mi.
double track and 95 mi. electrified) and about 6,000 mi. plantation-
industrial lines; common carrier lines comprise 3,100 mi. 4''8 1/2" standard
gage, and about 50 mi. 3''0" and 2''6" narrow gage; plantation-industrial
lines comprise about 4,000 mi. standard gage and 2,000 mi. narrow gage
Highways: 11,600 mi.; 4,000 mi. (est.) paved, 2,500 mi. (est.) gravel or
otherwise improved hard surfaces, 5,100 mi. (est.) improved or unimproved
earth surface
Inland waterways: 50 mi.
Pipelines: natural gas, 47 m.
Ports: 8 major, 44 minor; Guantanamo under U.S. control
Merchant marine: 51 ships (1,000 GRT and over) totaling 315,500 GRT, 428,300
DWT; includes 43 cargo, 6 tanker, 2 specialized carrier
Airfields: 372 total, 211 usable; 36 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 32 with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: modern facilities adequately serve military and most civil
needs; excellent international facilities, planned satellite ground station;
est. 270,000 telephones in use; 1.5 million radio and 260,000 TV receivers,
90 AM, 30 FM, and 19 TV stations with nationwide coverage; 6 submarine cables,
including 1 coaxial
DEFENSE FORCES:
Military budget: for fiscal year ending 3] December 1966, $213 million; about
7.8% of total budget
Approved For Release 2004/08/3'' : CIA-RDP79-01051A000400010002-1
2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS of\\pproved For Release Sarit
LAND:
3,570 sq. mi.; 47% arable and land under permanent crops,
18% forested, 10% meadows and pasture, 25% waste,
urban areas, and other (1968)
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 400 mi. (approx. )
PEOPLE: Bap!
Population: 653,000, average annual growth rate 1.7% nee
(January 70-71); males 15-49, 156,000; 109,000 fit for
military service, about 7,000 reach military age (18)
annually
Ethnic divisions: 78% Greek; 18% Turkish; 4% British, Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Armenian Orthodox and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Labor force: 254,000 (1967 est.), 38% agriculture, 23% industry, 9% commerce,
2% mining, 28% other; 3,130 registered unemployed (December 1968)
Organized labor: 24% of labor force
Railroads: none
Highways: 5,050 mi.; 2,010 mi. bituminous surface treated; 3,040 mi. gravel,
crushed stone, and earth
Ports: 3 major, 6 minor
Merchant marine: 289 ships (1,000 GRT or over) totaling 1,636,700 GRT, 2,337,000
DWT; includes 9 passenger, 241 cargo, 13 tanker, 26 bulk; all but a few are
owned and operated by Greek nationals
Civil air: 8 major transport aircraft
Airfields: 19 total, 11 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft.; 3 with runways 4,000-7,999 ft.
Telecommunications: modest but expanding telecommunication system; 42,500
telephones; 150,000 radio receivers; 45,800 TV receivers; 2 TV, 11 AM, and
4 FM stations; tropospheric scatter to Europe
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $7.5 million about
9.7% of central government budget
74
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
04/08/34: CIA-RDP79-01051A000400010002-1
nis {approved For Release 2004/08/31. Cl RDF,
LAND:
49,400 sq. mi.; 42% arable, 14% other agricultural, 35%
forested, 9% other (1968)
Land boundaries: 2,205 mi.
Railroads: 8,269 mi.; 8,089 mi. standard gage, 70 mi. broad gage, 110 mi. narrow
gage; 1,743 mi. double track; 1,483 mi. electrified; government owned (1969)
Highways: 45,500 mi.; 600 mi. concrete; 20,700 mi. bituminous ; 2,400 mi.
cobblestone, brick sett, stone block; 21,800 mi. crushed stone, gravel,
improved earth (1971)
Inland waterways: 517 mi. (1971)
Pipelines: crude oil, 900 mi.; refined products, 535 mi.; natural gas, 1,450 mi.
Freight carried: rail -- 256.3 million short tons, 40.3 billion short ton/mi.
(1970); highway -- 715 million short tons, 6.2 billion short ton/mi. (1970);
waterway -- 4.9 million short tons, 1.7 billion short ton/mi. (1970)
Ports: no maritime ports; outlets are Gdynia, Gdansk, Stettin in Poland; Rijeka,
Yugoslavia; Hamburg, West Germany; Rostock, East Germany; principal river
ports are Prague, Melnik, Usti nad Labem, Decin, Komarno, Bratislava (1970)
Merchant marine: 12 ships (1,000 GRT or over) totaling 97,700 GRIT, 138,800 DWT;
includes 8 cargo, 4 bulk
7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS Approved For Release 2004/08/31 5 Gif ARDP79-01051A000400010002-1
AND:
44,700 sq. mi.; southern third of country is most fertile;
arable land 80% (actually cultivated 11%), forests and
game preserves 19%, non-arable 1% (1968)
Land boundaries: 1,220 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 75 mi.
Railroads: 360 mi., all meter gage (3''3 3/8")
Highways: 4,300 mi.; 470 mi. paved, 1,670 mi. otherwise improved earth, 2,160
mi. unimproved
Inland waterways: 400 mi. navigable
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
Airfields: 11 total, 10 usable; 1 with permanent-surface runway; 3 with runways
A ,000-7 ,999 ft.
Telecommunications: telephone service concentrated in south; telegraph limited,
but more extensive than telephone; 4,800 telephones ; 54,000 radio receivers;
2 AM, no FM, and no TV stations; 3 submarine cables
DEFENSE FORCES:
Supply: dependent on France
Military budget: for fiscal year ending 3] December 1970, $4,420,000; about
12.4% of total budget
78
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A : -
NIS 7 pproved For Release 2004/08/31,;-falAsRDP79-01051A000400010002-1
LAND:
16,600 sq. mi. (exclusive of Greenland and Faeroe Islands);
64% arable, 8% meadows and pastures, 11% forested, 17% Pere ny
other (1966) an Ree EE. 3
Land boundaries: 42 mi. :
Limits o
WATER:
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi-. )
Coastline: 2,100 mi.
PEOPLE : ’ ALGERIA
Population: 4,971,000, average annual growth rate 0.7% z
(FY66-70); males 15-49, 1,187,000; 1,040,000 fit for
military service; 38,000 reach military age (20) annually
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant and Roman Catholic, 1%
other
Language: Danish; small German-speaking minority
Literacy: 99%
Labor force: 2.4 million; 14.5% agriculture, forestry, fishing, 29.4% mining and
manufacturing, 8.1% construction, 15.0% commerce, 6.6% transportation and
communications, 23.6% services, 0.2% other; 2.6% unemployed
Organized labor: 65% of labor force
Railroads: 2,399 mi. Danish State Railways (DSB) 1,472 mi. standard gage (4''8 1/2"),
52 mi. electrified and 438 mi. double tracked; and 25 route miles of meter
gage (3''3 3/8"), remaining 902 mi. of standard gage lines are privately owned
and operated
Highways: 38,275 mi.; 31,205 mi. concrete, bitumen, or stone block; 5,640 mi.
gravel and crushed stone; 1,430 mi. improved earth
Inland waterways: 259 mi.
Pipelines: refined products, 202 mi.
Ports: 16 major, 42 minor
Merchant marine: 240 ships (1,000 GRT or over) totaling 3,074,500 GRT, 4,885,100
DWT; includes 11 passenger, 189 cargo, 42 tanker, 18 bulk, 30 specialized
carrier
Civil air: 58 major transport aircraft (including 2 based in Greenland)
Airfields: 120 total, 107 usable; 16 with permanent-surface runways; 8 with run-
ways 8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent telephone, telegraph, and broadcast services; major
relay point for international telecom traffic; 1,600,000 telephones; 1,517,133
radiobroadcast receivers; 1,340,563 TV receivers; 7 AM, 10 FM, and 20 TV
stations; 20 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1972, $398 million; about 7.2%
of central government budget
80
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
aippreved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS DOMINICA
LAND:
305 sq. mi.; 24% arable, 2% pasture, 67% forests, 7%
other (1966)
WATER:
Limits of territorial waters: 3 n. mi. »
Coastline: 92 mi. VENEZUELA
PEOPLE: COLOMBIA
Population: 72,000, average annual growth rate 1.6%
(April 60-70) BaAg
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist
Language: English; French patois
Literacy: about 80%
Labor force: est. at 23,000 in 1960; about 50% in agriculture
Organized labor: 25% of the labor force
Railroads: none
Highways: 460 mi.; 175 mi. paved, 190 mi. gravel, crushed stone, or stabilized
earth surface, 95 mi. unimproved
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 1 with asphalt runway 4,830 ft.
81
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICAT LORE PMEE Fe Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Telecommunications: over 1,000-line fully automatic telephone system; VHF
interisland links to St. Lucia and Antigua; no data on radio or TV receivers;
1] AM station
82
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
\\
A d F : - - 4
re pproved For Release 2004/0 BS dea RA bat 01051A000400010002-1
LAND:
18,800 sq. mi.; 14% cultivated, 4% fallow, 17% meadows
and pastures, 45% forested, 20% built-on or waste
(1967)
Land boundaries: 224 mi.
WATER 7 7 . ‘ . eNeiuEL
Limits of territorial waters: 6 n. mi. (fishing, 12 n. mi.)
Coastline: 800 mi.
Railroads: 1,000 route mi. of which 65 mi. government-owned common carrier
(3''6" gage) and 935 mi. privately owned plantation network (approximately 4
different gages ranging from 1''10 1/2" to 4''8 1/2", with 2''6" predominating)
Highways: 6,000 mi.; 3,000 mi. paved, 800 mi. gravel, 1,400 mi. improved earth,
800 mi. unimproved earth
Pipelines: product lines (1.5 mi. and 43 mi.) under construction, to be completed
in 197]
Ports: 5 major, 17 minor
Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 3,100 GRT, 3,800 DwT
Civil air: 15 major transport aircraft
Airfields: 47 total, 25 usable; 7 with permanent-surface runways; | with runway
8,000-11,999 ft., 8 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: relatively efficient domestic system based on islandwide
radio relay network; automatic telex exchange inaugurated in 1971 provides
international connections via New York; 40,200 telephones; 400,400 radio and
1,250,000 TV viewers, 92 AM, 24 FM, and 6 TV stations; 2 submarine cables, |
of which is coaxial
DEFENSE FORCES:
Supply: dependent upon U.S. and Western Europe
Military budget: for fiscal year ending 31 December 1971, $32.3 million; about
12.3% of central government budget
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 87 ECUADOR
LAND:
106,000 sq. mi. (including Galapagos Islands); 11%
cultivated, 8% meadows and pastures, 55% forested,
26% waste, urban, or other (1961)
Land boundaries: 1,200 mi.
WATER:
Limits of territorial waters: 200 n. mi.
Coastline: 750 mi. (includes Galapagos Is.)
Railroads: 710 mi.; 615 mi. 3''6" gage, 95 mi. 2''5 1/2" gage; all single track
Highways: 12,800 mi.; 1,800 mi. paved, 4,000 mi. gravel, 3,800 mi. improved
earth, 3,200 mi. unimproved earth
Inland waterways: 960 m.
Pipelines: crude oil, 27 mi.; refined products, 50 mi.
Ports: 2 major, 11 minor
Merchant marine: 8 ships (1,000 GRT or over) totaling 40,100 GRT, 48,600 DWT;
includes 6 cargo, 2 tanker
Civil air: 14 major transport aircraft
Airfields: 187 total, 161 usable; 14 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 16 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: radio relay system, facilities adequate only in Quito and
Guayaquil; 95,000 telephones; 650,000 radio and 70,000 TV receivers, 200 AM,
15 FM, and 11 TV stations
DEFENSE FORCES:
Supply: dependent primarily on U.S.; some major purchases from Western Europe
Military budget: for fiscal year ending 31 December 1971, $22.9 million; about
11.3% of central government budget
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 5gpproved For Release 2004/08/31 -@JA-RDP79-01051A000400010002-1
LAND:
386,000 sq. mi. (including 22,200 sq. mi. occupied by
Israel); 2.8% cultivated (of which about 70% multiple
cropped); 96.5% desert, waste, or urban; 0.7% inland
water
Land boundaries: 1,635 mi. (1967), excludes occupied area
1,534 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 2,140 mi. (1967), excludes occupied area 1,340 m
Railroads: 2,976 mi.; 570 mi. double track; 15 mi. electrified; 2,594 mi. 4''8 1/2"
gage, 156 mi. 3''3 3/8" gage, 226 mi. 2''5 1/2" gage
Highways: 29,000 mi.; 5,190 mi. paved, 7,130 mi. gravel, crushed stone, and
improved earth, 16,680 mi. unimproved earth, additional 1,500 mi. (mostly
paved) in territory (Sinai) occupied by Israel
Inland waterways: 2,100 mi.; Suez Canal, 100 mi. long, temporarily closed to
navigation because of sunken vessels; normally used by ocean-going vessels
drawing up to 38 ft. of water; Alexandria-Cairo waterway navigable by barges
of 500-ton capacity; Nile and large canals by barges of 420-ton capacity;
Ismailia Canal by barges of 200- to 300-ton capacity; secondary canals by
sailing craft of 10- to 70-ton capacity
Freight carried: Suez Canal (1966) -- 242 million tons of which 175.6 million
tons were POL
Pipelines: crude oil, 226 mi.; refined products, 294 mi.; natural gas, 31 mi.
Ports: 5 major, 12 minor
Merchant marine: 40 ships (1,000 GRT or over) totaling 185,700 GRIT, 238,300
DWT; includes 5 passenger, 27 cargo, 9 tanker
Civil air: 17 major transport aircraft
Airfields: 147 total, 78 usable; 62 with permanent-surface runways ; 42 with
runways 8,000-11,999 ft., 23 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: second best system of coaxial and multiconductor cables,
open-wire lines, and radio communication stations in Africa; principal centers
Alexandria and Cairo, secondary centers Al Mansinah, Ismailia, and Tanta;
365,000 telephones; 4.4 million radio and 560,000 TV receivers; 12 AM, 1 FM,
and 26 TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972, $1.5 billion; 25.1% of
total budget
88
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31, GIASRPP79-01051A000400010002-1
NIS 74 ALVAD
LAND:
8,260 sq. mi.; 32% cropland (9% corn, 5% cotton, 7%
coffee, 11% other), 26% meadows and pastures, 31%
nonagricultural, 11% forested (1965)
Land boundaries: 320 mi. —
WATER:
Limits of territorial waters: 200 n. mi.
Coastline: 190 mi.
Railroads: 375 mi., 3''0" gage; 285 mi. privately owned, 90 mi. government
owned
Highways: 5,400 mi.; 750 mi. bituminous, 950 mi. gravel or crushed stone, 3,700 mi.
earth
Inland waterways: Lempa River partially navigable
Ports: 3 major, | minor
Merchant marine: 1 ship (1,000 GRT or over) totaling 1,580 GRT, 1,800 DWT
Civil air: 10 major transport aircraft
Airfields: 141 total, 111 usable; 1 with permanent-surface runway 4,000-7,999 Tt.3
] seaplane station
Telecommunications: nationwide trunk radio relay system completed; extensive
local telephone exchange improvements completed, 35,500° telephones; 460,000
radio and 92,000 TV receivers, 58 AM, 6 FM, and 2 TV stations (3 additional
TV stations planned)
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $7.2 million; about
6% of central government budget (excludes public security forces)
Approved For Release 2004/08/31: CIA-RDP79-01051A000400010002-1
Epprowes For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 5 EQUATORIAL GUINEA
LAND:
10,800 sq. mi.; Rio Muni, about 10,000 sq. mi., largely
forested; Fernando Po, about 800 sq. mi. gy | Raustnia ) Lava FeVAR cuore 4
Land boundaries: 335 mi. -
WATER:
Limits of territorial waters: 6 n. mi. (fishing, 12 n. mi.)
Coastline: 184 mi.
Railroads: none
Highways: Rio Muni -- 1,553 mi.; Fernando Po -- 186 mi.
Inland waterways: Rio Muni has approximately 104 mi. of year-round navigable
waterway, used mostly by pirogues
Ports: 2 major, 3 minor
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: fairly adequate for the size and stage of development of the
country; international communications by radio from Bata and Santa Isabel
to Cameroon, Nigeria, and Spain; 1,500 telephones ; 71,000 radio receivers;
2 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Military budget: for FY70, $3,475,000, 14.3% of total budget
Approved For Release 2004/08/34": CIA-RDP79-01051A000400010002-1
Approved For Rel 2004/08/31: - a o
NIS 5PP Vv elease 1. GASRDP79 01051A000400010002-1
LAND:
455,000 sq. mi.; 9.5% cropland and orchards, 54.6% meadows
and natural pastures, 6.5% forests and woodlands,
29.4% wasteland, built-on areas, and other
Land boundaries: 3,230 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 680 mi. (includes offshore islands)
Railroads: 630 mi.; 420 mi. 3''3 3/8" gage, 20 mi. 3''6" gage, 190 mi. 3''1
3/8" gage; all single track
Highways: 14,300 mi.; 1,125 mi. bituminous, 2,850 mi. crushed stone, gravel, or
stabilized earth, 10,325 mi. earth
Inland waterways: navigation possible on approx. 140 mi. of unconnected and
basically unimproved waterways, of which only 71 mi. are navigable year round
Ports: 2 major, 1 minor
Merchant marine: 6 ships (1,000 GRT or over) totaling 40,200 GRT, 59,700 DWT;
includes 3 cargo, 2 tanker, | bulk
Civil air: 17 major transport aircraft
Airfields: 195 total, 117 usable; 7 with permanent-surface runways; 5 with run-
ways 8,000-11,999 ft., 53 with runways 4,000-7,999 ft.
Telecommunications: system better than in most African countries; composed of
open-wire lines, radiocommunication stations, and small number of multi-
conductor cable and radio-relay links; principal center Addis Ababa, secondary
center Asmara; 41,100 telephones; 160,000 radio receivers; 8,000 TV receivers;
5 AM, no FM, and 2 TV stations
Approved For Release 2004/08/#4 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 7
LAND:
WATER:
Railroads: none
Highways: 512 mi.; 9 mi. paved, 23 mi. gravel, 480 mi. earth
Ports: 1 major, 4 minor
Civil air: no major transport aircraft
*The possession of the Falkland Islands has been disputed by the U.K. and Argentina
(which refers to them as the Malvinas) since 1833.
97
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS (cont''d):
Airfields: 1 seaplane station
Telecommunications: government-operated open-wire and radiotelephone networks
providing effective service to almost all points on both islands; approx-
imately 500 telephones; 1 AM station and approximately 1,100 radiobroadcast
receivers
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 102 FIJI
LAND:
7,055 sq. mi.; landownership -- 83.6% Fijians, 1.7% Indians,
6.4% government, 7.2% European, 1.1% other; about 30%
of land area is suitable for farming
WATER:
Limits of territorial waters: 3 n. mi. (fishing 3 n. mi.)
Coastline: 700 mi. (est.)
Railroads: 3,720 mi.; Finnish State Railways (VR) operate a total
3,693 mi. broad gage (5''0"), 290 mi. double track, and 41 mi. electrified;
14 mi. narrow gage (2'' 5 1/2") and 13 mi. broad gage are privately owned
Highways: 44,200 mi., 11,600 mi. bituminous, 31,900 mi. stablized gravel, 700
mi. gravel and earth; 12,400 mi. of private roads (surface type na)
Inland waterways: 4,100 mi. total (including Saimaa Canal); 2,300 mi. suitable
for steamers; canal locks (275 ft. by 42 ft. with a 16.7 ft. depth over sill)
can accommodate vessels of up to 225 ft. in length, 36 ft. beam, and 14.5
ft. draft
Ports: 11 major, 14 minor
Merchant marine: 215 ships (1,000 GRT or over) totaling 1,350,700 GRT, 2,011,900
DWT; includes 9 passenger, 136 cargo, 45 tanker, 13 bulk, 12 specialized
carrier
Civil air: 33 major transport aircraft
Airfields: 92 total, 73 usable; 28 with permanent-surface runways ; 15 with
runways 8,000-11,999 ft., 22 with runways 4,000-7,999 ft.
Telecommunications: facilities provide essential services for government and
industry; 1,090,000 telephones ; 1,774,569 radiobroadcast receivers ; 1,042,700
TV receivers; 11 AM, 39 FM, and 55 TV stations; 6 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $177.3 million; about
6.7% of central government budget
102
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
i ee el AO NE SOU 853 Lash
acscommnsemmncee ete RCM A ANNA Re rn
nis Approved For Release 2004/08/31 : CJA-RDP79-01051A000400010002-1
LAND:
213,000 sq. mi.; 31% cultivated, 25% meadows and pastures,
19% waste, urban, or other, 25% forested (1968)
Land boundaries: 1,795 mi.
WATER:
Limits of territorial waters: 3.n. mi. (fishing, 12 n. mi.)
Coastline: 2,130 mi. (includes Corsica, 400 mi.)
Railroads: 24,679 mi.; 23,829 mi. standard gage, 740 mi. meter gage, 110 m.
other gages (4'' 8 7/8" to meter); 5,970 mi. electrified, 9,892 mi. double
or multiple track
Highways: National, Departmental, and Communal roads total 487,600 mi. comprising
292,600 mi. paved, 190,000 mi. crushed stone and gravel, and 14,600 mi.
improved earth; in addition, there are approximately 434,000 mi. of local
farm and forest roads
Inland waterways: 9,320 mi.; 4,820 mi. heavily traveled
Pipelines: total, 10,000 mi.; crude oil, 1,400 mi.; refined products, 2,/00 mi.3
natural gas, 5,900 m.
Ports: 22 major, 165 minor
Merchant marine: 442 ships (1,000 GRT or over) totaling 6,591,400 GRT, 10,302,000
DWT; includes 13 passenger, 225 cargo, 109 tanker, 58 bulk, 37 specialized
carrier
Civil air: 277 major transport aircraft
Airfields: 509 total, 419 usable; 155 with permanent-surface runways ; 2 with
runways over 12,000 ft., 20 with runways 8,000-11,999 ft., 128 with runways
4,000-7,999 ft.; 10 seaplane stations
104
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS (cont''d):
Telecommunications: highly developed system provides satisfactory telephone,
telegraph, telex, facsimile, and radio and TV broadcast services; 9.5 million
telephones; 16 million radiobroadcast receivers; 11 million TV receivers ;
countrywide AM, FM, and TV service including 38 AM, 55 FM, and 40 primary
TV stations; 25 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $5.1 billion; about
17.2% of central government budget
105
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Nis g5(PProved For Release 2004/08/34.; GlfAaRPP79-01051A000400010002-1
LAND:
35,100 sq. mi.; 90% forested, 10% wasteland, built-on,
inland water, and other of which .05% is cultivated
and pasture (1970)
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 235 mi.
Railroads: 20 mi. private plantation line, 1''11 5/8" gage; 8 mi. abandoned
narrow-gage line
Highways: 450 mi.; 250 mi. paved, 150 mi. improved earth, 50 mi. gravel
Iniand waterways: 290 mi.; navigable by small oceangoing vessels and river
and coastal steamers; 2,110 mi. possibly navigable by native craft
Ports: 1 major, 7 minor
Civil air: no major transport aircraft
Airfields: 15 total, 13 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft.; 1 seaplane station
Telecommunications: very limited op','14df99b3a30d958a88eb45deb1924532e5f3f8107b57aaf9d3d35c4fe7c2a478','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38fe8ed57227457af62adfe1ee35aab2a15337906df7593710a5ecff907c4259',1971,'BR','Brazil','communications',21,'en-wire telecom system with more than 4,000
telephones; 25% connected to automatic exchanges; est. 7,000 radio receivers
and nearly 2,000 TV receivers, 1 AM, 2 FM and 2 TV stations; 1 satellite
tracking and control station
108
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 55C FRENCH TERRITORY OF THE AFARS AND ISSAS
LAND:
9,000 sq. mi.; 89% desert wasteland, 10% permanent pasture,
and less than 1% cultivated (1970)
Land boundaries: 321 mi.
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 195 mi. (includes offshore islands)
Railroads: 60 mi. meter gage
Highways: 620 mi.; 50 mi. paved, 570 mi. earth
Ports: 1 major, 1 minor
Airfields: 27 total, 10 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
109
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
roved ror Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNTCATIARR 2X (cont''d):
Civil air: 5 major transport aircraft (registered in France)
Telecommunications: fair telephone services; poor telegraph facilities;
telephones; 7,000 radio receivers; 1,100 TV receivers; | AM, no FM,
1 TV stations
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
2,000
and
NTS gfapproved For Release 2004/08/31 : GIARRDP79-01051A000400010002-1
102,000 sq. mi.; 75% forested, 15% savanna, 9% urban and
wasteland, less than 1% cultivated (1967)
Land boundaries: 1,505 mi.
WATER:
Limits of territorial waters: 25 n. mi.
Coastline: 550 mi.
Railroads: none
Highways: 3,820 mi.; 125 mi. paved, 1,960 mi. gravel or crushed stone, 1,425 m.
improved earth, 310 mi. unimproved earth
Inland waterways: approximately 1,000 mi. perennially navigable
Pipelines: crude oil, 39 mi.
Ports: 3 major, 2 minor
Civil air: 9 major transport aircraft
Airfields: 179 total, 98 usable; 2 with permanent-surface runways ; 1 with run-
way 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: fair telephone and telegraph services; good broadcast
coverage in vicinity of Libreville; 2 AM and 2 TV stations; 6,700 telephones ;
62,000 radio receivers; 1,200 TV receivers
DEFENSE FORCES:
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1971, 5,545,000; about 6.3%
of total budget
112
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
te saerproves For Release 2004/08/31: fA;RDP79-01051A00040001 0002-1
LAND:
4,000 sq. mi.; 25% uncultivated savanna, 16% swamps, 4%
forest parks, 55% upland cultivable areas, built-up
areas, etc.
Land boundaries: 460 mi.
WATER:
Limits of territorial waters: 12 n. mi. (fishing, 18 n. mi.
Coastline: 50 mi.
proved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: 820 mi.; 130 mi. bituminous surface treated, 260 mi. gravel, 430 mi.
unimproved earth
Inland waterways: 377 mi.
Ports: 1 major
Civil air: no major transport aircraft
Airfields: 4 total, 1 usable; 1 with permanent-surface runway; 1 with runway
4,000-7,999 ft.; 1 seaplane station .
Telecommunications: good telephone and telegraph services; 1,600 telephones ;
35,000 radio receivers; 2 AM, no FM or TV stations; 1 submarine cable
DEFENSE FORCES:
Defense is responsibility of U.K.; no British troops present; police strength
is about 600, including 6 expatriate officers
114
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 13A GERMANY , EAST
41,800 sq. mi.; 45% arable, 13% meadows and pasture, 27%
forested, 15% other (1968)
Land boundaries: 1,435 mi.
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 560 mi. (including islands)
Railroads: 9,109 route mi.; 8,/62 mi. standard gage, 347 mi. meter and narrow
gage, 1,731 mi. double track standard gage; 843 mi. overhead electrified (1970)
Highways: 54,055 mi.; 29,369 mi. paved, 24,685 mi. unpaved; 910 mi. classified
autobahn, 7,705 mi. national routes, 20,755 mi. district roads (1971)
Inland waterways: 1,562 mi. (1971)
Freight carried: rail -- 289.2 million short tons, 28.4 billion short ton/mi.
(1969); highway -- 510.4 million short tons, 8.4 billion short ton/mi. (1970);
waterway -- 14.3 to 15.1] million short tons, 1.6 billion short ton/mi. (1970)
Pipelines: crude oil, 360 mi; refined products, 100 mi.
Merchant marine: 130 ships (1,000 GRT and over) totaling 966,300 GRT, 1,299,800
DWT; includes 2 passenger, 99 cargo, 9 tanker, 11 bulk, 9 specialized carrier
Telecommunications: domestic and jnternational facilities modern and adequate;
good coverage provided by 21 AM and 18 FM broadcast stations, 6,000,000
receivers; 15 major TV stations supplemented by 300 rebroadcast stations;
4.4 million TV receivers; 1,986,190 telephones (100% automatic)
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, 7.2 billion DME;
about 9.5% of total budget
Approved For Release 2004/08/31 CIA-RDP79-01051A000400010002-1
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 5o¢\\pproved For Release 2004/08/31 ¢:GlA-RDP79-010514000400010002-1
AND:
92,000 sq. mi.; 19% agricultural, 60% forest and brush,
21% other (1969)
Limits of territorial waters: 12 n. mi. (fishing, 12
n. mi.
Railroads: 599 mi. -- all 3''6" gage; 20 mi. double track; diesel locomotives
gradually replacing steam engines
Highways: 21,350 mi., 3,100 mi. concrete or bituminous surface, 3,750 mi. gravel
or laterite, 3,700 mi. improved earth, 10,800 mi. unimproved earth
Inland waterways: Volta, Ankobra, and Tano rivers provide 145 mi. of perennial
navigation for launches and lighters; additional routes navigable seasonally
by small craft; Lake Volta reservoir provides 700 mi. of arterial and
feeder waterways
Pipelines: refined products, 2 mi.
Ports: 2 major, 1 naval base (Sekondi), 4 minor
Merchant marine: 16 cargo ships (1,000 GRT or over) totaling 113,900 GRT,
150,900 DWT
Civil air: 7 major transport aircraft
Airfields: 22 total, 19 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 9 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone fair to good in urban areas; fairly good telegraph
services; 54,000 telephones; about 703,000 radio receivers; 16,000 TV
receivers; 2 AM, no FM, and 5 TV stations; 2 submarine cables
DEFENSE FORCES:
Major ground units: 2 brigades (6 infantry battalions, 1 reinforced airborne company,
1] mortar battery, 1 field engineer battalion, 1 reconnaissance battalion)
Military budget: for fiscal year ending 30 June 1971, $45,500,000; 8.8% of
total budget
120
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 25A
WATER:
WATER:
Limits of territorial waters: 3 on. mi.
Coastline: 285 mi. Ses
*
PEQPLE: —
Population: 745,000, average annual growth rate 2.5% (Apri]
60-70); males 15-49, 173,000; 119,000 fit for military
service
x Ethnic divisions: 50% East Indians, 44% Negro and Negro mixed, 4% Amerindian, 2%
white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1% other
Language: English
Literacy: 86%
Labor force: 175,000; about 75% agriculture, 10% mining, services, and
manufacturing, 15% other; 21% unemployed; shortage of technical and
Managerial personnel
Organized labor: 25% of labor force
Railroads: 164 mi., all single track; 146 mi. 4''8 1/2" gage, 18 mi. 3''6" gage
Highways: 750 mi.; 300 mi. paved, 400 mi. gravel, crushed stone, and bauxite °
ore, 50 mi. earth and sand
Inland waterways: 3,700 mi.; Demerara River navigable to Mackenzie by ocean
steamers, others by ferryboats, small craft only
Ports: 1 major, 3 minor
Merchant marine: 1 bulk carrier (1,000 GRT or over) totaling 2,959 GRT, 3,149 DWT
Civil air: 6 major transport aircraft
Airfields: 102 total, 89 usable; 4 with permanent-surface runways ; 12 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: highly developed telecom system with multistation radio
relay network and over 13,500 telephones ; tropospheric scatter link to
Trinidad; 200,000 radio receivers, 2 AM stations
DEFENSE FORCES:
Supply: mostly U.K., some U.S. equipment
Military budget: for fiscal year ending 31 December 1969, $2.35 million; 2.8%
of central government budget
136
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NTS 79 Approved For Release 2004/08/31, >. FIA-RDP79-01051A000400010002-1
LAND:
10,700 sq. mi.; 31% cultivated, 18% rough pastures,
10% forested, 44% unproductive (1960)
Land boundary: 224 mi.
WATER: co
Limits of territorial waters: 6 n. mi. reed bed VENEZUELA
Coastline: 1,100 mi. a
PEOPLE: Y
Population: 5,020,000, average annual growth rate 2.1% ere en
(FY70); males 15-49, 1,256,000; 645,000 fit for
inilitary service; about 47,000 reach military age
(18) annually
Ethnic divisions: over 90% Negro, nearly 10% mulatto, few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of which an overwhelming
majority also practice Voodoo)
Language: French (official) spoken by only 10% of population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.6 million (est. January 1968); 86% agriculture, 12% industry,
2% unemployed; shortage of skilled labor; unskilled labor abundant
Organized labor: less than 1% of labor force
Railroads: 120 mi. 2'' 6" gage, single-track, privately owned industrial line;
government line dismantled
Highways: 2,000 mi.; 325 mi. paved, 150 mi. otherwise improved, 1,525 mi.
unimproved
Inland waterways: negligible; about 60 mi. Navigable
Ports: 2 major, 12 minor
Civil air: 4 major transport aircraft; 3 owned by the air force, ] privately owned
Airfields: 30 total, 15 usable; 3 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: al] domestic facilities inadequate, international facilities
only slightly better; large-scale telephone expansion Program; only 4,450
telephones, est. 282,000 radio and 8,000 TY receivers, 25 AM, 3 FM, and
1 TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 September 1970, $5,800,000; about
20.7% of operational budget
138 ''
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 73 Approved For Release 2004/08/8’)5)QhA-RDP79-01051A000400010002-1
PEQPLE:
43,300 sq. mi.; 27% forested, 30% pasture, 36% waste,
7% cropland (1966)
Land boundaries: 950 mi.
Limits of territorial waters: 12 n. mi. ee Sioa? LEENERUELA
Coastline: 510 mi. SENS
Population: 2,719,000, average annual growth rate 3.5%
(FY70); males 15-49, 669,000; 395,000 fit for military
service; about 28,000 reach military age (18) annually
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and 1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 47% of persons 10 years of age and over
Labor force: approx. 800,000 (est. mid-1970); 66% agriculture, 12% services, 8%
manufacturing, 5% commerce, 6% unemployed, 3% unspecified
Organized labor: 7-10% of labor force (mid-1970)
Railroads: 743 mi.; 443 mi. of 3''6" gage, 300 mi. of 3''0" gage
Highways: 3,000 mi.; 520 mi. paved, 1,240 mi. gravel, 520 mi. improved earth,
720 mi. unimproved earth
Inland waterways: 750 mi. navigable by small craft
Ports: 3 major, 9 minor
Merchant marine: 13 cargo ships (1,000 GRT or over) totaling 60,200 GRT, 57,200
DWT; all foreign owned and operated
Civil air: 23 major transport aircraft
Airfields: 212 total, 122 usable; 4 with permanent-surface runways; 8 with run-
ways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: improved, but still inadequate for all requirements; instal-
lation of radio relay system completed; over 12,500 telephones ; 300 ,000
radio and 21,000 TV receivers; 59 AM, 5 FM, and 6 TV stations
DEFENSE FORCES:
Supply: traditional dependence on U.S. has for the time being shifted to
Western Europe
Military budget: for fiscal year ending 31 December 1971, $11,400,000; about
9% of central government budget (includes the armed forces and the Special
Security Corps)
140
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 20 : zi :
NIS 39C Pp se 04/0813 ol RDP79-01051A000400010002-1
LAND:
400 sq. mi.; 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country) (1970)
Land boundaries: 15 mi.
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 455 mi.
Railroads: 22 mi. standard gage; government owned
Highways: 600 mi.; 410 mi. paved, 190 mi. gravel and crushed stone, or earth
Freight carried: rail -- 903,180 short tons (FY68)
Ports: 1 major
Merchant marine: 59 ships (1,000 GRT or over) totaling 489,500 GRT, 728,300
DWT; includes 2 passenger, 38 cargo, 5 tanker, 11 bulk cargo, 2 specialized
carrier; ships registered in Hong Kong fly the British flag; over 400 Hong
Kong-owned ships are registered elsewhere
Civil air: 7 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.; 1 seaplane station
DEFENSE FORCES:
Defense is the responsibility of U.K.
14
Approved For Release 2064/08/31 : CIA-RDP79-01051A000400010002-1
: CIA-RDP79-01051A000400010002-1
NIS jgAPproved For Release 200408131 | Cae
LAND:
35,900 sq. mi.; 60% arable, 14% other agricultural, 16%
forested, 10% other (1968)
Land boundaries: 1,395 mi.
Railroads: 5,948 route mi.; 5,102 mi. standard gage, 824 mi. narrow gage
(mostly 2'' 5 7/8"), 22 mi. broad gage (5''0"), 685 mi. double track, 486
mi. electrified; government owned (1970)
Highways: 18,300 mi.; 7,700 mi. paved, 9,700 mi. crushed stone or gravel, 900
mi. earth (1971)
Pipelines: crude oi], 330 mi.; natural gas, over 1,500 mi.
Inland waterways: 1,320 mi. (1971)
Freight carried: rail -- 125.4 million short tons (1970), 13.2 billion short ton/mi.
(1970); highway -- 440 million short tons, 3.7 million short ton/mi. (1970);
waterway -- 3.5 million short tons, 1.9 billion short ton/mi. (1970)
River ports: 2 principal (Budapest, Dunaujvaros); no maritime ports; outlets are
Rostock, East Germany and ports in Poland (1971)
Merchant marine: 18 cargo ships (1,000 GRT or over) totaling 33,200 GRIT,
44,500 DWT
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, 9.44 billion forints;
about 4.8% of total budget
Approved For Release 2604/08/31 : CIA-RDP79-01051A000400010002-1
ieee Approved For Release 2004/08/34. - GLA-RDP79-01051A000400010002-1
GREENLAND {65
-
CANADA SS Pecenet
LAND:
39,750 sq. mi.; arable negligible, 22% meadows and
pastures, forested negligible, 78% other (1967)
WATER:
Limits of territorial waters: 4 n. mi. (fishing, 12 n. mi.)
Coastline: 3,100 mi.
PEQPLE:
Population: 207,000, average annual growth rate 1.1%
(December 65-70); males 15-49, 49,000; 41,000 fit for
military service (Iceland has no conscription or
compulsory military service)
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant and Roman Catholic, 2%
no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 80,000; 22.6% agriculture, forestry, fishing; 25.6% mining and
manufacturing; 10.7% construction; 12.8% commerce; 7.8% transportation and
communications; 15.2% services; and 4.0% other; unemployment is insignificant
Organized labor: 60% of labor force
Ai BRAZIL
PERUD Sy
Railroads: none
Ports: 5 major, 55 minor
Merchant marine: 23 ships (1,000 GRT or over) totaling 57,700 GRT, 78,900 DWT;
includes 1 passenger, 19 cargo, 2 tanker, |] specialized carrier
Civil air: 13 major transport aircraft
Airfields: 108 total, 93 usable; 4 with permanent-surface runways ; 1] with
runway 8,000-11,999 ft., 15 with runways 4,000-7,999 ft.; 5 seaplane stations
Telecommunications: adequate domestic service provided by wire telephone and
telegraph system which circles island; good international radiocommunica-
tion service; 67,973 telephones; 62,000 radiobroadcast receivers; 38,000 TV
receivers; main AM and FM station in Reykjavik is relayed by 5 AM, 15 FM,
and 32 TV stations; 2 submarine cables
146
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ee Approved For Release 2004/08/34; CIA-RDP79-01051A000400010002-1
LAND:
1,211,000 sq. mi. (includes Indian part of Jammu-
Kashmir, Sikkim, Goa, Damao and Diu); 50% arable,
5% permanent meadows and pastures, 20% desert,
waste, or urban, 22% forested, 3% inland water (1968)
Land boundaries: 8,430 mi.
WATER:
® Limits of territorial waters: 12 n. mi. (fishing, 12. n.
mi.) (100 mi. is fisheries conservation zone,
December 1968)
Coastline: 3,300 mi.
» PEQPLE:
Population: 556,193,000 (including Sikkim and the Indian-held part of disputed
Jammu-Kashmir, and excluding the several million refugees who entered India
from East Pakistan during 1971), average annual growth rate 2.2% (March
61-April 71); males 15-49, 133,049,000; 75,640,000 fit for military service;
about 6,014,000 reach military age (17) annually
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.5% Christian, .7% Buddhist,
.8% other
Language: 24 languages spoken by a million or more persons each; numerous
other languages and dialects, for the most part mutually unintelligible;
Hindi is the national language and primary tongue of 30% of the people;
English enjoys “associate” status but is the most important language for
national, political, and commercial communication; Hindustani, a popular
variant of Hindi/Urdu, is spoken widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29% (1971 census )
Labor force: about 220 million; 72% agriculture, more than 10% unemployed and
underemployed; shortage of skilled labor is significant and unemployment is
rising
Organized labor: 2.5% to 3% of total labor force
Railroads: 36,188 mi.; 15,628 mi. meter (3''3 3/8") gage» 17,462 mi. broad gage,
2,687 mi. (2''6" and 2''O") narrow gage government owned; 411 mi. 2''6" and
2''Q" gage privately owned; 5,555 mi. double track; 1,305 mi. electrified
Highways: 604,176 mi.; 101,117 mi. paved, 97,351 gravel or crushed stone, 169,480
improved earth, 936,228 mi. unimproved earth
Inland waterways: 8,410 mi.; 1,600 mi. navigable by river steamers
Ports: 7 major 53 minor
Merchant marine: 244 ships (1,000 GRT or over) totaling 2,532,300 GRT,
3,892,000 DWT; includes 3 passenger, 186 cargo, 12 tanker, 35 bulk, and
8 specialized carrier
Airfields: 609 total, 373 usable; 190 with permanent-surface runways; 2 with
runway over 12,000 ft., 49 with runways 8,000-11,999 ft-, 140 with runways
4,000-7 ,999 ft.; 4 seaplane stations
Telecommunications: fair domestic telephone service where available in and
between major cities; facilities and services diminish in quantity and
quality as size of communities decreases and distance between increases ;
telephone distribution is less than 2 per 1,000 population; telegraph
facilities widespread; AM broadcast adequate; TY limited to Delhi -- New
Delhi; international telephones and telegraph adequate; 1,159,279 telephones ;
11.7 million radio and 24,833 TV sets; AM stations at 70 locations, 1 TV
station; submarine cables extend to Malaysia, Ceylon, and Aden
DEFENSE FORCES:
Military budget: for fiscal year ending 31] March 1972, $1.66 billion; 21% of
total budget
148
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 100\\pproved For Release 2004/08/3)5\\644,RDP79-01051A000400010002-1
LAND:
736,000 sq. mi.; 11% small holdings and estates, 64% for-
ests, 25% inland water, waste, urban, and other (1970)
Land boundaries: 1,700 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 34,000 mi.
Railroads: 4,364 mi.; 3,990 mi. 3''6" gage, 317 mi. 2''5 1/2" gage, 57 mi.
1''11 5/8" gage; 132 mi. double track; 74 mi. electrified; government owned
Highways: 57,460 mi.; 12,600 mi. paved, 25,200 mi. gravel or crushed stone,
19,660 mi. improved or unimproved earth
Inland waterways: 14,010 mi.; Sumatra 4,000 mi., Java and Madura 510 mi., Borneo
6,500 mi., Celebes 150 mi., and West New Guinea 2,850 mi.
Ports: 10 major, 62 minor
Merchant marine: 156 ships (1,000 GRT or over) totaling 513,700 GRT, 620,100 ;
DWT; includes 8 passenger, 118 cargo, 16 tanker, 11 bulk, 3 specialized
carrier -- includes 1 naval tanker and 5 transports sometimes used commercially;
a small proportion of the fleet is in overseas trade; in the interisland fleet
over two-thirds are commercially inoperable because of a chronic lack of spare
parts and trained personnel
Airfields: 330 total, 216 usable; 33 with permanent-surface runways ; 8 with
runways 8,000-11,999 ft., 56 with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: extensive police net for interisland service; international
and domestic service is limited; radiobroadcast coverage adequate but TV
available on Java only; 182,319 telephones; 3.2 million radio sets; 90,000
TV sets; AM stations at 53 locations; 1 FM and 5 TV stations; 2 submarine
cables to Singapore
150
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/34 + CIA-RDP79-01051A000400010002-1
NIS 33 RAN
LAND:
636,000 sq. mi.3; 14% agricultural, 11% forested, 16%
cultivable with adequate irrigation, 51% desert, 4
waste, or urban, 8% migratory grazing and other (1968) EGYPT, sauerl
Land boundaries: 3,305 mi. “lt ARABIA
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 1,580 mi.
PEQPLE:
Population: 29,912,000, average annual growth rate 2.9%
(FY70); males 15-49, 7,052,000; 4,170,000 fit for
military service; about 310,000 reach military
age (21) annually
Ethnic divisions: 63% Ethnic Persians, 3% Kurds, 13% other Iranian, 18% Turkic,
3% Arab and other Semitic, 1% other
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2% Zoroastrians, Jews, and Christians
Language: Farsi (Persian), Turki, Kurdish, Arabic
Literacy: about 30% of those 10 years of age and older
Labor force: 7.5 million; 47% agriculture, 53% industry, commerce and services;
shortage of skilled labor substantial
Organized labor: 1.1% of labor force
Railroads: 2,257 mi. mi. 4''8 1/2" gage
Highways: 24,309 mi.; 6,524 mi. paved, 10,637 mi. gravel and crushed stone,
7,148 mi. improved earth
Inland waterways: 565 mi., not including Caspian Sea and Shatt al Arab
Pipelines: crude oil, 2,351 mi.; refined products, 2,241 mi.; natural gas,
1,552 mi.
Ports: 7 major, 6 minor
Merchant marine: 13 ships (1,000 GRT or over) totaling 129,700 GRT, 187,100 DWT;
includes 10 cargo, 3 tanker
Civil air: 17 major transport aircraft
Airfields: 225 total, 149 usable; 50 with permanent-surface runways ; 6 with
runways over 12,000 ft., 15 with runways 8,000-11,999 ft., 50 with runways
4,000-7,999 ft.
Telecommunications: excellent international radiocommunications ; good domestic
telecommunication facilities; 286,200 telephones; 1.8 million radio and
200,000 TV receivers; 17 AM, 2 FM, and 11 TV stations; satellite earth station
DEFENSE FORCES:
Military budget: for fiscal year ending 20 March 1972, $1,023.0 million; about
22.0% of total budget
i
Approved For Release 2064/08/31 : CIA-RDP79-01051A000400010002-1
ee
Approved For Re
I
oer ease 2004/08): CIA-RDP79-01051A0004000
LAND:
172,000 sq. mi.; 18% cultivated, 68% desert, waste, or
urban, 10% seasonal and other grazing land, 4% forest
and woodland
Land boundaries : 2,280 mi.
WATER:
Limits of territorial waters: 12 n. mi.
¥ Coastline: 36 mi.
Railroads: 1,408 mi.; 698 mi. 4''8 1/2" gage, 710 mi. meter (3''3 3/8") gage;
10 mi. meter gage double track
Highways: 12,900 mi.; 4,000 mi. paved; 2,900 mi. crushed stone, gravel, or
improved earth; 6,000 mi. earth and sand tracks
Inland waterways: 1,950 mi.; Shatt al Arab navigable by maritime traffic for
about 80 mi.; Tigris and Euphrates navigable by shallow-draft steamers
Ports: 3 major
Pipelines: crude oil, 2,860 mi.; 81 mi. refined products; 548 mi. natural gas
Merchant marine: 3 cargo ships (1,000 GRT or over) totaling 17,500 GRT, 24,500
DWT
Civil air: 6 major transport aircraft
Airfields: 162 total, 63 usable; 22 with perman','dbc80aa2a48a8e923f82de4a35451cdb74de16ea13b10d13a9b2561dd475fd79','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a2bf89e2e4206a9a68064e250ae42276263b3e754c4b64b72f10188599e259f',1971,'BR','Brazil','communications',22,'ent-surface runways; 31 with
runways 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.
Telecommunications: fair international radiocommunication service; poor
domestic telephone and telegraph service; 119,600 telephones; 200,000 radio
receivers; 177,000 TV receivers; 4 TV and 4 AM stations
154
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 2 Approved For Release 2004/0843 1, §1A-RDP79-01051A000400010002-1
LAND:
26,600 sq. mi.; 17% arable, 51% meadows and pastures,
3% forested, 2% inland water, 27% waste and urban S ees
(1967 ) : tas Fee er
Land boundaries: 224 mi. S ‘
WATER:
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi. )
Coastline: 900 mi. .
Railroads: 1,332 mi., 5''3" gage; government-owned
Highways: 53,700 mi.; 46,950 mi. surfaced, 6,750 mi. earth
Inland waterways: approx. 650 mi.
Ports: 6 major, 38 minor
Merchant marine: 17 ships (1,000 GRT or over) totaling 139,000 GRT, 193,000
DWT; includes 4 cargo, 5 bulk, 3 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 28 total, 23 usable; 7 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: small, modern system; all cities interconnected for telephone
and telegraph service and broadcast netting; 287,100 telephones; 700,000
radiobroadcast receivers; 438,000 TV receivers; 3 AM, 9 FM, and 20 TV stations;
12 submarine cables
DEFENSE FORCES:
Supply: formerly from the U.K. primarily, but since 1961 from other European
countries
Military budget: for fiscal year ending 31 March 1970, $38.3 million; about
3.7% of the central government budget
156
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 17 Approved For Release 2004/08/31, : CIA-RDP79-01051A000400010002-1
LAND:
116,300 sq. mi.; 51% arable, 17% meadow and pasture, 20%
forest, 3% unused but potentially productive, 9%
inland water, waste, urban (1968)
Land boundaries: 1,058 mi.
WATER:
Limits of territorial waters: 6 n. mi. (fishing, 12 n. mi.)
Coastline: 3,105 mi.
PEOPLE: : ALGERIA
Population: 4,174,000 average annual growth rate 0.8%
(FY61-67); males 15-49, 13,448,000; 11,310,000 fit for
military service; 407,000 reach military age (18) annually
Ethnic divisions: a composite of the Mediterranean, Alpine, Adriatic, and Nordic
racial types; Mediterranean type predominates in southern and insular Italy
Religion: almost 100% nominally Roman Catholic (de facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region (e.g., Bolzano) are
predominantly German speaking; significant French-speaking minority in Valle
d''Aosta Region; Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5-7% of population illiterate (1967); illiteracy varies widely by region
Labor force: 19,752,000 (October 1970); 18.9% agriculture, 42.0% industry,
37.2% other, 3.1% unemployed; underemployment, particularly in southern
Italy, remains widespread; 1.5 million Italians employed in other Western
European countries
Organized labor: 20% (est.) of labor force
Railroads: 12,890 mi.; 11,390 mi. 4''8 1/2" gage, 1,490 mi. 3''1 3/8" gage, 2,860
mi. double track 4'' 8 1/2" gage, 120 mi. double track 3'' 1 3/8" gage, 5,712
mi. electrified 4'' 8 1/2" gage, 320 mi. electrified 3'' 1 3/8" gage
Highways: 126,500 mi.; state highways 25,985 mi., provincial highways 45,850 mi.,
communal highways 54,665 mi.; 60,200 mi. concrete, bituminous, or stone block,
66,300 mi. gravel and crushed stone
Inland waterways: 2,547 mi. navigable routes; 1,180 mi. are rivers and
canals, 1,367 mi. are lake routes
Pipelines: crude oil, 1,100 mi.; refined products, 655 mi.; natural gas, 3,600 mi.
Ports: 16 major, 148 minor
160
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
nN ee
Approved Far Rel
COMMUNICATIONS feontaye 2004/08/31 : CIA-RDP79-010514090400010992
Merchant marine: 646 ships (1,000 GRT or over) totaling 7, $008, 2992-45 ,303 200
DWT; includes 64 passenger s 243 cargo, 164 tanker, 122 bulk, 53 specialized
carrier
Civil air: 130 major transport aircraft
1 with permanent-surface runways; 2 with
Airfields: 227 total, 151 usable; 8
runways over 12,000 ft., 24 with runways 8 ,000-11 ,999 ft., 49 with runways
4,000-7 ,999 ft.; 11 seaplane stations
Telecommunications: well engineered, well constructed, and efficiently operated;
almost 8.53 million telephones ; : ili dio and 9.6 million television
receivers; 68 AM, 160 FM, and 65 TV stations, each with numerous repeater
stations; 9 submarine cables; communication satellite ground station
DEFENSE FORCES:
Military budget: for fi $2.65 billions about
12% of central governme
scal year ending 31 December 1971,
nt budget
he 161
pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
D:
125,000 sq. mi.; 40% forest and woodland, 8% cultivated,
52% grazing, fallow, and waste, 200 mi. of lagoons
and connecting canals along eastern coast (1970)
Land boundaries: 2,005 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 320 mi.
Railroads: 408 mi. of the 728 mi. Abidjan to Ouagadougou, Upper Volta line, all
single track meter gage; only diesel locomotives in use
Highways: 24,600 mi.; 800 mi. bituminous and bituminous-surface treatment;
11,200 mi. gravel, crushed stone, laterite, and improved earth; 12,600
mi. unimproved earth roads
Inland waterways: 460 mi. navigable rivers and numerous coastal lagoons
Ports: 2 major, 3 minor
Merchant marine: 11 cargo ships (1,000 GRT or over) totaling 79,100 GRT, 122,800
DWT
Civil air: 15 major transport aircraft
Airfields: 49 total, 43 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 6 with runways 4,000-7 ,999 ft.; 1 seaplane station
Telecommunications: system only slightly above African average; consists of
open-wire lines and radio relay links, which provide incomplete coverage of
country; Abidjan is only center; 24,800 telephones; 75,000 radio and
10,500 TV receivers; 3 AM, no FM, and 4 TV stations; 2 submarine cables
DEFENSE FORCES:
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1971, $18,550,000; about
4.9% of total budget
164
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 8]
LAND:
WATER:
Railroads: 204 mi. government-owned , 50 mi.
single track
privately owned, all standard gage,
Highways: 7,100 mi.; 1,200 mi. paved, 4,400 mi. gravel, 1,900 mi. unimproved
earth surfaces
Pipelines: refined products, 6 mi.
Ports: 1 major, 11 minor
Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 11,900 GRT, 10,500 DWT
Civil air: 3 major transport aircraft
Airfields: 47 total, 35 usable; 11 with permanent-surface runways ; 1 with run-
way 8,000-11,999 ft., 2 with runway 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fully automatic domesti
c¢ telephone network with 66,700
telephones ; intraisland VHF network; satellite ground station under construction
to be operational in 1971; 500,000 radi
and 8 TV stations; 5 submarine cables,
o and 70,000 TV receivers; 8 AM, 5 FM,
including 2 coaxial, with third coaxial
being laid and expected to be completed about the end of 1971
DEFENSE FORCES:
Supply: dependent on U.K. and U.S.
Military budget: for fiscal year ending 31
of central government budget
166
Approved For Release 2004/08/31 :
March 1970, $5 million; about 2.0%
CIA-RDP79-01051A000400010002-1
~
=
= comme sO
=_—_ oom
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 29
NOTE:
LAND:
WATER:
Approved For Release 2004/0834 4,CIA-RDP79-01051A000400010002-1
The war between Israel and the Arab states in June 1967
ended with Israel in control of West Jordan. Although
approx. 930,000 persons resided in this area prior to the
start of the war, fewer than 750,000 of them remain there
under the Israeli occupation, the remainder having fled
to East Jordan. Over 14,000 of those who fled were
repatriated in August 1967, but their return has been
more than offset by other Arabs who have crossed and are
continuing to cross from West to East Jordan. These and
certain other effects of the Arab-Israeli war are not
included in the data below.
ARABIA
ao
SUDAN be
Ss
Railroads: none
Highways: 760 mi.; 350 mi. pavéd, 100 mi. gravel, 200 mi. improved earth, 110
mi. unimproved earth
Ports: 3 major, 6 minor
Civil air: 6 major transport aircraft
Airfields: 7 total, all usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: generally adequate telecom facilities; extensive inter-
island VHF links; plan troposcatter link to Curacao, Venezuela; 26,000
telephones, 105,000 radio and 30,000 TV receivers, 10 AM and 2 TV stations,
4 telegraph submarine cables
DEFENSE FORCES:
Defense is responsibility of the Netherlands
Supply: dependent on Netherlands -- which itself is dependent for heavier
equipment on other non-Communist countries
234
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
—-
NIS 102 APProved For Release 2094/08/34 5 l4-RDP79-01051A000400010002-1
LAND:
8,500 sq. mi.; 6% cultivable, 22% pasture land, 7% forests,
65% waste or other (1968)
WATER:
Limits of territorial waters: 3 n. mi. (fishing, 3 n. mi.)
Coastline: 1,000 mi. dieacin
Railroads: 220 mi.; 200 mi. of 3''6" gage, government owned; 20 mi. narrow gage,
privately owned
Highways: 6,400 mi.; 750 mi. paved, 600 mi. gravel or crushed stone, 1,850 mi.
improved earth, 3,200 mi. unimproved earth
Inland waterways: 1,380 mi., including 2 large lakes
Pipelines: crude oil, 36 mi.
Freight carried: rail 1960 -- 25 million ton/km.
Ports: 4 major, 6 minor
Merchant marine: 4 cargo ships (1,000 GRT or over) totaling 9,800 GRT,
14,800 DWT
Civil air: 10 major transport aircraft
Airfields: 459 total, 414 usable; 5 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 8 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: extensive but low-capacity wire network; single radio relay
link; 23,500 telephones; est. 700,000 radio and 55,000 TV receivers, 70 AM,
26 FM, and 5 TV stations; satellite ground service station scheduled to
enter service in 1973
DEFENSE FORCES:
Supply: dependent primarily upon U.S.
Military budget: for fiscal year ending 31 December 1970, $11.6 million for the
Ministry of Defense, including civil functions (e.g., police and civil air);
11.8% of central government budget
Approved For Release“4004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 50L Approved For Release 2004/08)345"ciA-RDP79-01051A000400010002-1
489,000 sq. mi.; about 3% cultivated, perhaps 20% somewhat
arable, remainder desert (1970)
Land boundaries: 3,570 mi.
Railroads: none
Highways: approx. 4,300 mi.; 300 mi. bituminous, 1,850 mi. gravel, 2,150 mi.
unimproved earth :
Inland waterways: Niger River navigable 185 miles from Niamey to Gaya on the
Dahomey frontier from mid-December through March
Ports: Niger landlocked; outlet to sea is Cotonou, Dahomey
Civil air: 5 major transport aircraft
Airfields: 74 total, 59 usable; 4 with permanent-surface runways; | with runway
8,000-11,999 ft., 15 with runways 4,000-7,999 ft.
Telecommunications: principal telecommunication center Niamey; telephone poor,
telegraph fair, 3,300 telephones; 85,000 radio receivers; unknown number of
TV receivers; 4 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Supply: dependent on France exclusively until 1964; since then has obtained
ground force materiel from other non-Communist countries including Belgium,
Israel, and West Germany
Military budget: for fiscal year ending 30 September 1971, $3,665,000; 8.0%
of total budget
242
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
a
Approved For R
NIS 50B elease 2004/08/34 ,CIA-RDP79-01051A00040001000
LAND:
357,000 sq. mi.; 24% arable (13% of total land area
under cultivation)» 35% forested, 41% desert, waste,
urban, or other (1969)
Land boundaries: 2,501 mi.
WATER:
Limits of territorial waters: 30 n. mi.
” Coastline: 530 mi.
Railroads: 2,180 route mi.; 3''6" gage
Highways: 55,400 mi.; 9,475 mi. paved (mostly bituminous surface treatment) ;
45,925 mi. laterite, gravel, crushed stone, improved earth
Inland waterways: 5,330 mi. consisting of Niger and Benue rivers and smaller
rivers and creeks; additionally, the newly formed Kainji Lake has several
hundred miles of navigable lake routes
Pipelines: crude oil, 581 mi.; natural gas, 56 mi.; refined products, 3 mi.
Ports: 4 major, 5 minor
Merchant marine: 14 cargo ships (1,000 GRT or over) totaling 84,800 GRT,
123,800 DWT
Civil air: 9 major transport aircraft
Airfields: 86 total, 73 usable; 12 with permanent-surface runways ; 4 with runways
8,000-11,999 ft., 26 with runways 4,000-7,999 ft.; 4 seaplane stations
Telecommunications: one of the best systems in Africa composed of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Lagos, secondary centers Ibadan and Kaduna; 81,400 telephones; 1,275,000
radio receivers, 75,000 TV yeceivers; 25 AM, 6 FM, and 8 TV stations; 2
submarine cables
4
Approved For Release 2004108/31 : CIA-RDP79-01051A000400010002-1
ell
eae Approved For Release 2004/08(6ayA CIA-RDP79-01051A000400010002-1
LAND:
Norway: 125,000 sq. mi.; Svalbard, 24,000 sq. mi.;
Jan Mayen, 144 sq. mi.; 3% arable, 2% meadows
and pastures, 21% forested, 74% other (1968)
Land boundaries: 1,603 mi.
WATER:
Limits of territorial waters: An. mi. (fishing, 12 n. mi.)
Coastline: mainland 2,125 mi.; islands 1,500 mi. (excludes
long fjords and numerous small islands and minor
indentations which total as much as 10,000 mi. overall)
Railroads: 2,711 mi.; 2,669 mi. single track standard gage; 1,420 mi. electrified,
including 47 mi. double track
Highways: 44,180 mi.; 7,135 mi. paved, 37,045 mi. crushed stone and gravel
Iniand waterways: 980 mi.; 5'' draft vessels maximum By
Pipelines: refined products, 33 mi.
Ports: 9 major, 69 minor
Merchant marine: 1,168 ships (1,000 GRT or over) totaling 20,492,000 GRT,
34,344,400 DWT; includes 25 passenger, 425 cargo, 291 tanker, 264 bulk,
163 specialized carrier
Civil air: 47 major transport aircraft
Airfields: 64 total, 60 usable; 35 with permanent-surface runways ; 11 with
runways 8,000-11 ,999 ft., 14 with runways 4,000-7,999 ft.; 24 seaplane
and telex service; 1,091,000 telephones ; 1.9 million radiobroadcast receivers 3
816,941 TV receivers; 34 AM, 43 FM, and 41 TV stations (including many high
powered transmitters); 6 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $410 million; about
13% of central government budget
|
stations F, 1
Telecommunications: high-quality domestic and international telephone, telegraph, |
46
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 32B
Pipelines: crude oi] 223 mi.
Ports: 7 minor
Civil air: no major transport aircraft
Airfields: 188 total, 111 usable; 2 with permanent-surface runways; 3 with runways
8,000-11 ,999 ft., 36 with runways 4,000-7,999 ft.
Telecommunications: poor international radiocommunications (service to Bahrain
only); very poor domestic wire service; 800 telephones; 1 AM station;
tropospheric scatter-link to Bahrain
247
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 36 Approved For Release 2004/08/81 GIA-RDP79-01051A000400010002-1
405,000 sq. mi. (includes Pakistani part of Jammu- Kashmir)
(West Pakistan 86%; East Pakistan 14% in two non-
contiguous provinces); 38% arable, including 24%
Gen 58% desert, waste, or urban, 4% forested
1967
Land boundaries: 6,925 mi. (West Pakistan 5,350 mi., East
Pakistan 1,575 mi.)
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 1,010 mi. (West Pakistan 650 mi., East Pakistan
360 mi.)
Railroads: 7,049 mi. (5,322 mi. West, 1,752 mi. East); 1,455 mi. meter gage
(277 mi. West, 1,178 mi. East) 5,219 mi. broad gage (4,665 mi. West, 554 mi.
East); 400 mi. narrow gage (380 mi. West, 20 mi. East); 722 mi. double track
(635 mi. West, 87 mi. East); government owned
Highways: 71,850 mi. (43,500 mi. West, 28,350 mi. East); 15,159 mi. paved (12,700
mi. West, 2,450 mi. East); 14,200 mi. gravel (12,450 mi. West, 1,750 mi. East);
42,500 mi. earth (18,350 mi. West, 24,150 mi. East)
Inland waterways: 4,600 mi., East Pakistan; 1,150 mi., West Pakistan; river
steamers navigate main waterways in East Pakistan
Pipelines: crude oil, 143 mi.; natural gas, 1,200 mi.
Ports: 2 major, 10 minor
Merchant marine: 76 ships (1,000 GRT or over) totaling 604,800 GRT, 816,700 DWT;
includes 5 passenger, 68 cargo, 1 tanker, 2 bulk
Civil air: 23 major transport aircraft (includes 2 leased)
Airfields: 25] total, 133 usable; 80 with permanent-surface runways; 1 with runway
over 12,000 ft., 22 with runways 8,000-11,999 ft., 68 with runways 4,000-
7,999 ft.; 3 seaplane stations
250
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNI CAPRRECYEShE Sf Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Telecommunications: excellent international radiocommunication service over
CENTO links; domestic wire and radiocommunication and broadcast service very
good; 193,493 telephones; 1,626,146 radio and 80,000 TV sets; 12 AM, no FM,
and 7 stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1971 $630,000,000; about 27%
of total budget
251
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 77 Approved For Release 2004/08/3/h)y,CIA-RDP79-01051A000400010002-1
LAND:
29,208 sq. mi. (excluding Canal Zone, 553 sq. mi.); 24% ee
agricultural land (9% fallow, 4% cropland, 11% pasture),|.
20% exploitable forest, 56% other forests, urban, and
waste (1967 crop year)
Land boundaries: 390 mi.
WATER:
Limits of territorial waters: 200 n. mi.
Coastline: 1,545 mi.
PS, COLOMBIA
Railroads: 345 mi.; 48 mi. 5''O" gage, 107 mi. 3''0" gage; 190 mi. plantation
feeder lines
Highways: 4,200 mi.; 950 mi. paved, 700 mi. gravel or crushed stone, 300 mi.
improved earth, 2,250 mi. unimproved earth; Panama Canal Zone 145 mi.;
140 mi. paved; 5 mi. gravel
Inland waterways: 500 mi. navigable by shallow draft vessels; 50-mile
Panama Canal
Pipelines: refined products, 56 mi.
Ports: 2 major, 10 minor
Merchant marine: 742 ships (1,000 GRT or over) totaling 6,131,000 GRT, 9,670,700
DWT; includes 13 passenger, 458 cargo, 168 tanker, 70 bulk, 33 specialized
carrier; all foreign owned and operated
Civil air: 28 major transport aircraft
Airfields: 237 total, 120 usable; 15 with permanent-surface runways; 3 with
runways 8,000-11,999 ft.; 10 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: domestic and international telecom facilities well developed,
including nearly nationwide radio-relay system; communications satellite
ground station; 72,900 telephones; 550,000 radio and 108,000 TV receivers,
77 AM, 25 FM, and 13 TV stations; 1 coaxial submarine cable
Approved For Releaseé 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 102 Approved For Release 2006(A8(34) :GlAERDP79-01051A000400010002-1
D:
183,540 sq. mi. (Papua 90,540 sq. mi., New Guinea
93,000 sq. mi.)
Land boundaries: 600 mi.
WATER: |
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.) |
Coastline: about 2,000 mi.
Railroads: 652 mi.; 273 mi. standard gage, 85 mi. 3''3 3/8'''' gage, 294 mi. various
narrow gage (privately owned) ;
Highways: 9,900 mi.; 400 mi. bituminous treated, 3,100 mi. otherwise improved,
6,400 mi unimproved earth
Inland waterways: 1,970 mi.
Freight carried: 70% carried by inland waterway in 1960
Ports: 1 major, 7 minor (all river)
Merchant marine: 14 ships (1,000 GRT or over) totaling 15,700 GRT, 12,300 DWT;
includes 2 passenger, 9 cargo, 2 tanker, 1 specialized carrier; domestic
ships are operated mostly in river traffic; most international waterborne trade
is carried by foreign flag ships
Civil air: 5 major transport aircraft
Airfields: 774 total, 659 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 23 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: local telecom facilities in Asuncion good, but intercity net
still poor; only 21,225 telephones; est. 720,000 radio and 25,000 TV receivers;
18 AM, 5 FM, and 1 TV stations
DEFENSE FORCES:
Supply: dependent on foreign sources (U.S., Brazil, Argentina, and Belgium) for
all materials
Military budget: for fiscal year ending 31 December 1971, $16.5 million; about
19% of proposed central government. budget :
Approved For Release 3004/08/31 : CIA-RDP79-01051A000400010002-1
.
nitsies Approved For Release 2004/08£}ij) CIA-RDP79-01051A000400010002-1
496,000 sq. mi. (other estimates range as low as 482,000
sq. mi.); 2% cropland, 14% meadows and pastures, 55%
forested, 29% urban, waste, other (1962)
Land boundaries: 3,810 mi.
WATER:
Limits of territorial waters: 200 n. mi.
Coastline: 1,500 mi.
Railroads: approx. 2,144 mi.; 1,800 mi. 4'' 8 1/2" gage; 130 mi. gage less than
3''0"; 214 mi. 3'' 0" gage; 9 mi. double track
Highways: 31,100 mi.; 3,000 mi. paved, 5,400 mi. gravel or crushed stone, 8,500
mi. improved earth, 14,200 mi. unimproved earth
Inland waterways: 5,400 mi. of navigable tributaries of Amazon River system and
130 mi. Lake Titicaca
Pipelines: crude oil, 200 mi.; natural gas and natural gas liquids, 1,411 mi.
Ports: 7 major, 20 minor
Merchant marine: 37 ships (1,000 GRT or over) totaling 276,800 GRT, 390,400 DWT;
includes 26 cargo, 9 tanker (includes 5 naval tankers sometimes used
commercially), 1 specialized carrier, 1 bulk
Civil air: 34 major transport aircraft
Airfields: 318 total, 273 usable; 16 with permanent-surface runways; 2 with
runway over 12,000 ft., 19 with runways 8,000-11,999 ft., 47 with runways
4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fairly adequate for most public requirements; communications
satellite ground station; est. 200,000 telephones; est. 1.8 million radio and
450,000 TV receivers; 200 AM, 7 FM, and 29 TV stations
DEFENSE FORCES:
Military budget: a biennial budget for 1 January 1971 through 31 December 1972,
$485.2 million; about 16.2% of central government biennial budget
260
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A .
ieee pproved For Release 2004/8153 bp LA-RDP79-01051A000400010002-1
PEOPLE''S REP.
OF CHINA
D:
116,000 sq. mi.; 37% cropland, 41% forested, 22% other
(1968)
WATER:
Limits of territorial waters: 0-300 n. mi. (treaty limits
of the Philippines )
Coastline: about 14,000 mi.
Railroads: 2,160 mi.; 2 common-carrier systems (3''6" gage) totaling about 710
mi.; 19 industrial systems with 4 different gages totaling 1,450 mi.; 34%
government owned
Highways: 39,516 mi.; 7,647 mi. paved; 22,791 mi. gravel, crushed stone, or
stabilized soil surface; 9,078 mi. improved earth
Inland waterways: 2,000 mi.; limited to shallow-draft (less than 5 ft.) vessels
Pipelines: refined products, 157 mi.
Ports: 13 major, 89 minor
Merchant marine: 176 ships (1,000 GRT or over) totaling 925,800 GRT, 1,321,500
DWT; includes 9 passenger, 122 cargo, 28 tanker, 11 bulk, 6 specialized
carrier
Civil air: 92 major transport aircraft
Airfields: 297 total, 188 usable; 35 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 20 with runways 4,000-7,999 ft.; 8 seaplane stations
DEFENSE FORCES:
Supply: almost exclusively from U.S.; naval ships and equipment also from
Australia, Japan, and Italy
Military budget: for fiscal year ending 30 June 1972, $117.0 million; about 10%
of total budget
262
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
.
¥
Ts Ni Nee A ane MUN ~~ gene -
NIS 14 Approved For Release 2004/08/3AND CIA-RDP79-01051A000400010002-1
D:
120,600 sq. mi.; 49% arable, 14% other agricultural, 27%
forested, 10% other (1969)
Land boundaries: 1,920 mi.
WATER:
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Coastline: 305 mi.
Railroads: 16,469 route mi.; 14,381 mi. standard gage, 2,088 mi. narrow gage;
4,644 m','18a495b7f8ae98bc5a27c232709411847f5b888ec228714aa74cbf63a53da2f7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edb38c5c526f398cef92026595581fa62673a6eeeda1f3277640ac74f11fd39e',1971,'BR','Brazil','communications',23,'i. double track; 2,400 mi. electrified; government owned (1970)
Highways: 190,095 mi.; 40,389 mi. paved; 39,479 mi. crushed stone, gravel;
110,227 mi. earth (improved and unimproved) (1971)
Inland waterways: 3,158 mi. navigable streams and canals (1971)
Pipelines: 1,700 mi. for natural gas; 500 mi. for crude oi]; 117 mi. for refined
products
Freight carried: rail -- 421.4 billion short ton, 67.9 million short ton/mi.
(1970); highway 920.7 million short tons, 9.8 billion short ton/mi. (1970);
waterway -- 7 million short tons, 1.6 billion short ton/mi. (1970)
Merchant marine: 239 ships (1,000 GRT and over) totaling 1,562,600 GRT and
2,166,700 DWT; includes 1 passenger, 169 cargo, 5 tanker, 64 bulk
264
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ye
NIS 8 Approved For Release 2004/98/{34gnCIA-RDP79-01051A000400010002-1
Co
LAND: }
Metropolitan Portugal: 36,400 sq. mi., including the Azores
and Madeira Islands; 48% arable, 6% meadow and pasture,
31% forested, 15% waste and urban, inland water, and
other (1966)
Cape Verde Islands: 1,560 sq. mi., divided among 10 islands
and several islets (not a part of Metropolitan Portugal
Land boundaries: 750 mi.
~~
WATER: ;
Limits of territorial waters: territorial sea claim 6n. mi.f
(fishing, 12 n. mi .) Sg MOROCCO 5) ALGERIA
Coastline: 1,945 mi. (excludes Azores, Maderia, and Cape
Verde Islands, 1,180 mi.)
Railroads: 2,230 mi.; 472 mi. 3''3 3/8" meter gage, 1,758 mi. broad gage (5''5 9/16");
265 mi. double track; 274 mi. electrified
Highways: 18,500 mi.; 11,000 mi. bituminous, bituminous treatment, concrete and
stoneblock; 7,200 mi. gravel and crushed stone; 300 mi. improved earth; plus
an additional 10,500 mi. of unimproved earth roads (motorable tracks)
Inland waterways: 508 mi. navigable; relatively unimportant to national economy,
used by shallow-draft craft limited to 330-ton cargo capacity
Ports: 7 major, 33 minor
Merchant marine: 111 ships (1,000 GRT or over) totaling 824,900 GRT, 1,065,500 DWT;
includes 15 passenger, 70 cargo, 19 tanker, 4 bulk, 3 specialized carrier
Civil air: 21 major transport aircraft
266
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICA Te oved Figr Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Airfields (including Azores, Cape Verde Islands, and Madeira Islands): 62 total,
54 usable; 26 with permanent-surface runways ; 2 with runways over 12,000 ft.,
9 with runways 8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 7 seaplane
stations
Telecommunications: facilities are generally adequate; 720,000 telephones; 1.6
million radio receivers; 400,000 television receivers; 35 AM, 35 FM, and 30
TV stations; 18 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $409.4 million; about
37% of central government budget
2
Approved For Release 2004/08/31 “Eia-RDP79-01051A000400010002-1
h eeaan Approved For Release 2004/08/34; GIAsRDP79-01051A000400010002-1
AND:
14,000 sq. mi. (includes Bijagos archipelago)
Land boundaries: 460 mi.
WATER: ae
Limits of territorial waters: claims 6 n. m. (fishing 12
n. mi.
Coastline: 170 mi.
Railroads: none
Highways: 463 mi.; 293 mi. gravel or crushed stone, 170 mi. improved and
unimproved earth
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 14 total, 10 usable; 2 with permanent-surface runways; ] with runway
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: domestic and international radio stations used primarily
for administrative and military purposes; 1 low-power radiobroadcast station;
unreliable open-wire lines and 12 small manual switchboards serve about 679
telephones; 3,075 radio sets
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ier an Approved For Release 2004/08/34 GIA;RDP79-01051A000400010002-1
LAND:
3,440 sq. mi.; 33% arable, 35% meadow and pasture, 13%
forested, 19% waste, urban, or other (1964)
WATER:
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Coastline: 300 mi.
Railroads: none
Highways: 275 mi. bituminous; 225 mi. gravel; surfaced; undetermined mileage of
earth tracks
Pipelines: crude oil, 73 mi.; natural gas, 60 mi.
Ports: 2 minor
Airfields: 10 total, 1 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft.
275
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS (conARAOved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Civil air: no major transport aircraft
Telecommunications: all international telecom traffic is by radio thru Bahrain;
fair domestic wire facilities; 9,400 telephones; 25,000 radio and 20,000 TV
receivers; 1 AM and 1 TV stations
DEFENSE FORCES:
Supply: from U.K.
276
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
WES 62 Approved For Release 2004/08/34 ofr A-RDP79-01051A000400010002-1
LAND:
970 sq. mi.; two-thirds of island extremely rugged,
consisting of volcanic mountains; 120,000 acres (less
than one-fifth of the land) under cultivation
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 125 mi.
PEQPLE:
Population: 461,000, average annual growth rate 2.3% (FY69)
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy,
Chinese, and Indian origin
Religion: predominantly Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal unemployment
Railroads: none
Highways: 1,092 mi.; 814 mi. paved, 278 mi. gravel, crushed stone, or stabilized
earth
Ports: 1] major
Civil air: no major transport aircraft
Airfields: 6 total, 6 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 2 with runways 4,000~7,999 ft.
Telecommunications: adequate for size of island and fairly modern; international
communications by radio to France, Malagasy, and Mauritius; 11,300
telephones; 71,000 radio and 17,700 TV receivers; 1 AM, no FM, and 8 TV
stations
278
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
me ee ee
Ce ee
NIS 578 Approved For Release 2004/0834. fIA-RDP79-01051A000400010002-1
LAND:
151,000 sq. mi.; 40% arable (of which 6% cultivated); 60%
available for extensive cattle grazing; European
alienated lands (farmed by modern methods) 39%,
African 48%, national land 7%, 6% not alienated (1970)
Land boundaries: 1,875 mi.
Railroads: 1,610 mi. narrow gage (3''6"); 26 mi. double track
Highways: 49,385 mi.; 4,965 mi. paved, 18,350 mi. crushed stone, gravel,
stabilized soil, or improved earth; 26,070 mi. unimproved earth
Inland waterways: 175 mi. on Lake Kariba
Airfields: 289 total, 200 usable; 7 with permanent-surface runways; 1 with run-
way over 12,000 ft., 23 with runways 4,000-7,999 ft.
Civil air: 12 major transport aircraft
Telecommunications: system is one of the best in Africa; consists of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Salisbury, secondary center Bulawayo; 122,100 telephones; 145,300 radio
and 50,000 TV receivers; 8 AM, no FM and 2 TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972, $51,260,000; 15.5% of
total budget
280
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 22 Approved For Release 2004/08/31 j1&!A-RDP79-01051A000400010002-1
LAND:
91,700 sq. mi.; 44% arable, 19% other agriculture, 27%
forested, 10% other (1969)
Land boundary: 1,845 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 140 mi.
Railroads: 9,700 mi.; 6,430 mi. standard gage, 3,252 mi. narrow gage, 18 mi.
Ga 187 mi. electrified, 421 mi. double track; government owned
1970
Highways: 48,000 mi.; 7,600 mi. paved; 16,300 mi. other improved surfaces,
24,100 mi. earth (1969)
Inland waterways: 1,445 mi. (1971)
Pipelines: crude 011, 1,600 mi.; refined products, 888 mi.; natural gas, 3,100
mi.
Freight carried: rail -- 178.6 million short tons, 32.3 billion short ton/mi.
(1970); highway -- 435 million short tons, 4.8 billion short ton/mi. (1970);
waterway -- 3.4 million short tons, .77 billion short ton/mi. (1970)
Merchant marine: 49 ships (1,000 GRT or over) totaling 349,600 GRT, 509,100
DWT; includes 1 passenger, 33 cargo, 4 tanker, 11 bulk
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 60C Approved For Release 2004/0@(2NDACIA-RDP79-01051A000400010
* 40,000 sq. mi.; almost all the arable land, about_1/3
under cultivation, about 1/3 pastureland (1967)
Land boundaries: 545 mi.
PEQPLE:
Population: 3,791,000 (African population only), average
annual growth rate 3.1% (FY65-67); males 15-49,
a 880,000; 425,000 fit for military service; no
conscription; 36,000 reach military age (18) annual ly
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa (Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist ‘
a Language: Kinyarwanda and French official; Kiswahili language of African commerce,
Kinyarwanda language of interior and used in National Assembly
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 240 mi.
Railroads: 104 mi.; 54 mi. 3''3 3/8" gage (government owned) and 50 mi.
narrow gage (industrial line); all single track
Highways: 1,550 mi.; 300 mi. paved, 130 mi. gravel, 370 mi. improved earth,
750 mi. unimproved earth
Inland waterways: 2,850 mi.; most important means of transport; oceangoing
vessels with drafts ranging from 14 to 23 ft. can navigate many of the
principal waterways while native canoes navigate upper reaches
Ports: 1 major, 6 minor
Civil air: 2 major transport aircraft
Airfields: 31 total, 30 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: international facilities good and domestic network under
improvement; 10,000 telephones; 60,000 radio and 25,000 TV receivers, 5 AM,
1 FM, and 3 TV stations
DEFENSE FORCES:
Defense is responsibility of the Netherlands; the Netherlands maintains an army
force in Surinam; also available are naval, marine corps, and naval air
personnel located in the Netherlands Antilles
Ships: none
320
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Appr
vee pproved For Release 2004/08/21jyIA-RDP79-01051A000400010002-1
LAND: Sa
6,700 sq. mi.; most of area suitable for crops or
pastureland (1970)
Land boundaries: 270 mi.
Railroads: 139 mi., 3''6" gage, single track
Highways: 1,660 mi.; 135 mi. paved; 840 mi. crushed stone, gravel, or stabilized
soil; 685 mi. improved or unimproved earth
Civil air: 5 major transport aircraft
Airfields: 29 total, 26 usable; 1 with permanent-surface runway; 2 with runways
4,000-7,999 ft. :
Telecommunications: the system consists of a few open-wire lines and low-powered
radiocommunication stations; Mbabane is the center; 4,800 telephones; 30,000
radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
None, police only
322
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/0 : al -
aaa pp Bb ECA RDP79-01051A000400010002-1
LAND:
173,000 sq. mi.; 8% arable, 1% meadows and pastures, 55%
forested, 36% other (1968)
Land boundaries: 1,365 mi.
WATER:
Limits of territorial waters: 4 n. mi. (fishing, 12 n. mi.. )
Coastline: 2,000 mi.
Railroads: 7,767 mi.; Swedish State Railways (SJ) 7,096 mi. standard
gage (4''8 1/2"), 4,324 mi. electrified; 48 mi. narrow gage (3''6"), 241 mi.
narrow gage (2''11"), 29 mi. of narrow gage (2''11"), 2 mi. narrow gage (2''),
and 351 mi. standard gage (4'' 8 1/2") are privately owned and operated
Highways: 60,925 mi.; 44,530 mi. are crushed stone, gravel, or improved
earth; and 16,395 mi. are bitumen, stone block, or cobblestone
Inland waterways: 1,268 mi. navigable for small steamers and barges
Ports: 17 major, and 23 minor
Merchant marine: 373 ships (1,000 GRT or over) totaling 4,576,100 GRT, 7,073,500
DWT; includes 10 passenger, 178 cargo, 49 tanker, 53 bulk, 83 specialized
carrier
Civil air: 68 major transports registered
Airfields: 187 total, 159 usable; 85 with permanent-surface runways; 5 with
runways 8,000-11,999 ft., 58 with runways 4,000-7,999 ft.; 9 seaplane
stations
Telecommunications: telephone the primary service, but extensive telegraph and
broadcast services are available; excellent domestic and international
facilities; 4,307,000 telephones; 42 AM, 70 FM, and 168 TV stations available
to over 90% of population; 4.8 million radio and 2.8 million TV receivers;
12 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972, $1.2 billion; about
11% of proposed central government budget
Approved For Release 2664/08/31 : CIA-RDP79-01051A000400010002-1
NIS 15 Approved For Release 2004/08/34 --GIARDP79-01051A000400010002-1
LAND:
16,000 sq. mi.; 10% arable, 42% meadows and pastures, 21%
waste or urban, 24% forested, 3% inland water (1970)
Land boundaries: 1,171 mi.
Railroads: 3,040 mi.; 2,195 mi. 4''8 1/2" gage, 780 mi. double track; 845 mi.
narrow gage (810 mi. at 3''3 3/8", 35 mi. at 2''7 1/2"); 3,040 mi. electrified
Highways: 31,300 mi.; 12,300 mi. paved, 19,000 mi. otherwise improved
Pipelines: crude oi], 195 mi.
Inland waterways: 41 mi.; Rhine River-Basel to Rheinfelden, Schaffhausen to
Constanz; in addition, there are 12 navigable lakes ranging in size from
Lake Geneva to Hallwilersee
ae oo rail -- 34.8 million metric tons (1963); 4.59 billion ton/km.
1963
Ports: 1 major, 2 minor
Merchant marine: 27 ships (1,000 GRT or over) totaling 204,300 GRT, 294,500
DWT; includes 24 cargo, 3 bulk; fleet is registered in Basel, operates
mainly out of Genoa, Hamburg, and Rotterdam
Civil air: 59 major transport aircraft
Airfields: 89 total, 73 usable; 34 with permanent-surface runways; 2 with
runways over 12,000 ft., 5 with runways 8,000-11,999 ft., 12 with runways
4,000-7 ,999 ft.
Telecommunications: excellent services; 2.8 million telephones; 1.8 million
radio and 1.3 million TV receivers; 8 AM, 70 FM, and 205 TV stations
including repeaters
DEFENSE FORCES:
Supply: produces moderate amounts of all types of materiel; some medium and
heavy equipment is imported from U.S. and Western Europe; formerly produced
jet aircraft (under license); produces surface-to-air missiles in limited
quantities
Military budget: for fiscal year ending 31 December 1970, $457,907,010; 26%
of central government budget
326
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIs 284 Approved For Release 2004/087391ACIA-RDP79-01051A000400010002-1
LAND
72,000 sq. mi.; (including about 500 sq. mi. occupied by
Israel); mainly semiarid and desert plains; 38% arable,
41% grazing, 3% forest, 18% other
Land boundaries: 1,365 (1967) (excluding occupied area
1,340 mi.)
TURKEY
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 120 mi.','875a38a0dd409da9faf2670b6a48eb17c7e939982d4981f0fdb552bdd89a36e0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1b464af5fc6fa55d9691a8e7dd188dd54d339f45c4491e482c2492f785de344',1971,'IE','Ireland','communications',27,'Railroads: none
Highways: 19 miles, all paved
Inland waterways: none
Ports: 1 major
Civil air: 1 major transport aircraft (registered in U.K.)
Airfields: 1 permanent-surface runway, 4,000-7 ,999 ft.; 1 seaplane station
Telecommunications: international radiocommunication facilities; automatic
telephone system serving 5,600 telephones; 6,000 radio receivers; 6,600
television receivers; 1 AM, 1 FM, and 2 TV stations; 14 submarine cables
Approved For Release 2664/08/31 : CIA-RDP79-01051A000400010002-1
at
NIS 24 Approved For Release 2004/08 ¢ ClIA-RDP79-01051A000400010002-1
51,200 sq. mi.; 29% arable and land under permanent crops,
40% meadows and pastures, 20% forested, 11% wasteland,
urban, other (1966)
Land boundaries: 740 mi.
WATER:
Limits of territorial waters: 6 n. mi.
Coastline: 8,500 mi.
Railroads: 1,620 mi.; 980 mi. standard gage (4''8 1/2"), 610 mi. meter gage
(3''3 3/8"), 20 mi. 1''11 5/8" narrow gage, 10 mi. 2''5 1/2" narrow gage
Highways: 24,200 mi.; 7,100 mi. paved, 9,100 mi. crushed stone and gravel
4,800 mi. improved earth, 3,200 mi. unimproved earth
Inland waterways: system consists of 3 coastal canals and 3 unconnected rivers
which provide navigable length of just less than 50 mi.
Pipelines: crude oi], 16 mi., refined products, 340 mi.
Ports: 17 major, 37 minor
Merchant marine: 1,419 ships (1,000 GRT or over) totaling 13,296,900 GRT,
20,994,000 DWT; includes 52 passenger, 890 cargo, 234 tanker, 218 bulk,
25 specialized carrier; ethnic Greeks also own an estimated 18,421,000
GRT under other flags: about 16,192,000 GRT under Liberia, 732,000 under
Panama, 1,437,000 under Cyprus, 46,000 under Lebanon, 5,300 under Malta,
and 8,700 under Somali Republic
Airfields: 54 total, 47 usable; 32 with permanent-surface runways; 15 with
runways 8,000-11,999 ft., 10 with runways 4,000-7,999 ft.; | seaplane station
Civil air: 32 major transport aircraft
Telecommunications: fairly modern networks reach all areas on mainland and =
islands; however, services generally inadequate; 881,000 telephones; 1.4
million radio receivers; 255,000 TV receivers; 27 AM, 6 FM and 12 TV stations;
9 submarine cables; communications satellite ground station
DEFENSE FORCES: a
Military budget: for fiscal year ending 31 December 1970, $471 million; 26.3%
of central government budget
124
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved : -
ete pproved For Release 2004/08/31 anf!A: RDP79-01051A000400010002-1
840,000 sq. mi.; less than 1% arable (of which only a
fraction cultivated), 83% permanent ice and snow,
16% other (1964)
WATER:
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Coastline: 27,400 mi. (approx., includes minor islands)
PEOPLE: Be
Population: 49,000, average annual growth rate 2.2% (FY70); v3
males 15-49, included with Denmark
Ethnic divisions: 86% Greenlander (Eskimos and Greenland-
born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep breeding
Railroads: none
Highways: none
Ports: 7 major, 16 minor
Civil air: 2 major transport aircraft registered in Denmark
Airfields: 11 total, 8 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 7 seaplane stations
125
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ome 18]
ee
Approved For Release 20
04/08/31 : CIA-R 7 .
COMMUNICATIONS (cont'' d): DP79-01051A000400010002-1
Telecommuni cations: adequate domestic and international service provided by
radio; 2,950 telephones ; 7,100 radiobroadcast receivers; 95 AM, 1 FM, and
2 TV stations; 2 submarine cables
Appr
pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-
gre cRiA ( 8/31 GIA RDP79-01051A000400010002-1
LAND:
133 sq. mi. (Grenada and southern Grenadines); 47%
cultivated, 3% pastures, 12% forests, 20% unused but
potentially productive, 18% built on, wasteland,
other (1964)
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 75 mi.
PEOPLE: BRAZIL
CEEOL 96,000, average annual growth rate 0.6% (April
60-70
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects; Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 25,170 (1960); 40% agriculture, 30% unemployed or underemployed
Organized labor: 33% of Jabor force
Railroads: none
Highways: 600 mi.; 380 mi. paved, 100 mi. gravel, crushed stone, or earth
surface; 120 mi. unimproved
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 4 total, 3 usable; | with asphalt runway 5,000 ft.
Telecommunications: automatic, islandwide telephone system with 2,700 telephones;
VHF island link to Trinidad; no data on radio or TV receivers; 1 AM station
Approved For Release 2004/08/31 : ¢fA-RDP79-01051A000400010002-1
a
Approved For Release 2004/08/31
GU
NIS 83 REECE ene One
LAND:
687 sq. mi.3 25% cropland, 8% pasture, 19% forest, 48%
wasteland, built on; area consists of two islands (1970
WATER:
Limits of territorial waters: 3n, mi.
Coastline: 190 mi. VENEZUELA
PEOPLE: COLOMBIA
Population: 337,000, average annual growth rate 1.8%
(FY67-69) 5 males 15-49; included with France BRAZIL
Ethnic divisions: 90% Negro or Mulatto, 5% East Indian,
5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu, and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force
Railroads: privately owned, narrow-gage plantation lines
Highways: 1,200 mi.; 780 mi. paved, 420 mi. gravel and earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
Civil air: 1 major transport
Telecommunications: domestic facilities inadequate; international, approaching
saturation point; 11,400 telephones, 83% automatic; telegrams re-transmitted
by telephone; international radio-telegraph carries 5 telex circuits;
inter-island VHF radio links; 2 AM radio and 2 TV transmitters, with about
22,500 radio and 5,200 TV receivers
DEFENSE FORCES:
Defense is responsibility of France; data included with-France
Airfields: 6 total, 5 usable, 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft.; 1 seaplane station
130
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 200 : -
a AIG BISA AGIA RDP79-01051A000400010002-1
us
D:
42,040 sq. mi.; 14% cultivated, 10% pasture, 57% forest,
19% other (1967)
Land boundaries: 1,010 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 250 mi.
Railroads: 550 mi., 3''0" gage; 510 mi. government owned, 40 mi.
privately owned
Highways: 7,600 mi., 1,300 mi. bituminous, 4,200 mi. gravel, 2,100 mi. improved
or unimproved earth (1965)
Inland waterways: 164 mi. navigable year-round; additional 458 mi. navigable
during high-water season
Pipelines: crude oil, 28 mi.
Freight carried: rail (1960) -- 191.8 million ton/miles, 1.1 million tons
Ports: 4 major, 1 minor
Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 3,600 GRT, 5,400 DWT
Airfields: 476 total, 314 usable; 4 with permanent-surface runways; | with runway
8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 12 major transport aircraft
Teleconmunications: modern telecom facilities largely limited to Guatemala;
intercity open wire network; 38,500 telephones; est. 350,000 radio and
72,000 TV receivers, 77 AM, 25 FM, and 3 TV stations; construction plan for
satellite earth station canceled
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, $15,904,000; about
8.6% of central government budget
132
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 50E Approved For Release 2004/08/34 y-GIA-RDP79-01051A000400010002-1
URRANCE
D: & Moonie :
95,000 sq. mi.; 3.3% cropland, 10% forest (1969) ay :
Land boundaries: 2,160 mi. OS ciayn
WATER: ”
Limits of territorial waters: 130 n. mi.
Coastline: 215 mi.
Railroads: 500 mi. meter gage, 5 mi. standard gage
Highways: 6,000 mi.; 300 mi. paved, 2,000 mi. all weather, 3,700 mi. seasonal
(dry)
Inland waterways: 1,115 mi.; 310 mi. navigable by small oceangoing vessels,
805 mi. navigable by shallow-draft steamers and barges
Ports: 1 major, 2 minor
Merchant marine: 1 bulk carrier (1,000 GRT or over) totaling 10,764 GRT,
15,290 DWT
Civil air: 5 major transport aircraft
Airfields: 20 total, 15 usable; 1 with permanent-surface runway; 3 with runways
8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: limited telephone service; fair telegraph facilities;
6,500 telephones; 91,000 radio receivers; 1 AM, no FM, and no TV stations;
3 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 30 September 1970, $6,073,000; 8.0%
of total budget
134
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
eo.
NIS 95Approved For Release 2004/08/31 GU@AMARDP79-01051A000400010002-1
LAND:
83,000 sq. mi.; 1% cropland, 3% pasture, 9% Savanna,
77% forested, 10% water, urban, and waste (1968 est.)
Land boundaries: 1,600 mi.','3f516f7e5162a0c3c6890d545344f7aa4a41d77903707808a0063ab836ad8d2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e56233669c33f39fd8dca9b06ea4624c274aef1921ab9442576c18c86d15b46',1971,'ET','Ethiopia','communications',28,'37,100 sq. mi. (including about 2,100 sq. mi. occupied by Israel); 11%
agricultural, 88% desert, waste, or urban, 1% forested (1964)
Land boundaries: 1,141 mi. (1967, 1,037 mi. excluding occupied areas )
Limits of territorial waters: 3 n. mi.
Coastline: 16 mi.
Railroads: 230 mi. 3''5 3/8" gage, single track
Highways: 3,971 mi.; 3,210 mi. bituminous, 224 mi. improved, 537 unimproved earth
(these mileages include approximately 670 mi. -- mostly bituminous -- of
Jordanian territory held by Israel)
Pipelines: crude oi], 168 mi.
Ports: 1 major
Civil air: 5 major transport aircraft
Airfields: 51 total, 16 usable; 9 with permanent-surface runways; 1 with
runway over 12,000 ft., 9 with runways 8,000-11,999 ft., 3 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate telecommunication system for the needs of the
country; 34,500 telephones; 170,000 radio and 55,000 TV receivers; ] AM
and 2 TV stations; earth satellite station under construction
DEFENSE FORCES:
Supply: dependent on outside sources; U.S., U.K., France, and West Germany
principal suppliers of military equipment
Approved For Release''3004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 56D Approved For Release 2004/08/34); <CIA-RDP79-01051A000400010002-1
LAND:
225,000 sq. mi.; about 21% forest and woodland, 13%
suitable for agriculture, 66% mainly grassland
adequate for grazing (1970)
Land boundaries: 2,093 mi.
WATER: Z
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Coastline: 333 mi.
Railroads: 1,275 mi.; meter gage
Highways: 26,970 mi.; 1,532 mi. paved, 8,849 mi. gravel or improved earth, about
16,589 mi. unimproved or tracks
Inland waterways: part of Lake Victoria and Lake Rudolph are within boundaries
of Kenya
Ports: 1 major, 3 minor
Merchant marine: 6 ships (1,000 GRT or over) totaling 16,200 GRT, 25,300 DWT;
includes 3 cargo, 2 tanker, | specialized carrier
Civil air: 10 major transport aircraft
Airfields: 258 total, 202 usable; 5 with permanent-surface runways ; 1} with
runway over 12,000 ft., 1 with runways 8,000-11 ,999 ft., 43 with runways
4,000-7,999 ft.; 3 seaplane stations
Telecommunications: in top group of African systems ; consists of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Nairobi, secondary centers Mombasa and Nakuru; 72,300 telephones; 774,000
radio and 16,400 TV receivers; 5 AM, 2 FM, and 3 TV stations; 2 submarine
cables
DEFENSE FORCES:
Supply: dependent on U.K.
Military budget: for fiscal year ending 30 June 1971, $6,392,000; about 5.0% of
ordinary budget
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 41A Approved For Release 2004(98/31 ncqRIA-RDP79-01051A000400010002-1
PEOPLE''S REP
OF CHINA
LAND:
47,000 sq. mi.; 17% arable and cultivated, 74% in forest,
scrub, and brush; remainder wasteland and urban (1971)
Land boundaries: 1,040 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 1,550 mi.
Railroads: 2,818 route mi. operating in 1968; 2,137 mi. standard gage, 681 mi.
2''6" narrow gage; 99 mi. double tracked; about 588 mi. electrified; government
owned
Highways: about 12,600 mi., 95% gravel or earth surface
Inland waterways: 1,400 mi.; mostly navigable by small craft only
Freight carried (1969): rail -- 13 billion metric ton/km., 62 million metric
tons; highway -- 765 million metric ton/km., 116 million metric tons;
waterway -- 540 million metric ton/km., 7.7 million metric tons; coastal --
170 million metric ton/km., 0.4 million metric tons
Ports: 6 major, 26 minor
Merchant marine: 7 cargo ships (1,000 GRT and over) totaling 23,200 GRT, 28,600
DWT; additionally 6 refrigerated ships (1,000 GRT or over) totaling 34,600
GRT, 28,700 DWT are subordinate to the fishing fleet
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, announced at
2,051,040,000 won; 28% of total budget (converted at 2.57 won=US$1)
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
uIs 413 APProved For Release 2004/98/31 :.GiAgRDP79-01051A000400010002-1
PEOPLE''S REP.
OF CHINA
LAND:
38,000 sq. mi.; 23% arable (22% cultivated), 10% urban
and other, 67% forested (1968)
Land boundaries: 150 mi.
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 1,550 mi.
Railroads: 1,964 mi.; 1,887 mi. standard gage, 77 mi. (2''6") narrow gage; 280
mi. double track; government owned
Highways: 25,340 mi.; 1,600 mi. paved, 16,140 mi. gravel, 4,000 mi. improved
earth, 3,600 mi. unimproved earth
Inland waterways: 1,000 mi.; use restricted to small native craft
Freight carried: rail (1963) 2,708.2 million short ton/mi., 19.8 million short
tons; highway (1963) 21.9 million short tons; air (1959) 796,260 lbs. carried
Pipelines: 255 mi., refined products, under construction
Ports: 10 major, 10 minor
Merchant marine: 116 ships (1,000 GRT or over) totaling 886,000 GRT, 1,455,800
DWT; includes 81 cargo, 19 tanker, 12 bulk, 4 specialized carriers
Airfields: 257 total, 125 usable; 47 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 2 seaplane stations
176
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA- f
NIS 32C 31 ¢ RDP79-01051A000400010002-1
LAND:
6,200 sq. mi. (excluding neutral zone but including islands)
insignificant amount forested; nearly all desert,
waste, or urban (1969)
Land boundaries: 285 mi.
WATER:
Limits of territorial waters: 12 on. mi.
Coastline: 310 mi.
Highways: about 9,200 mi. (including Communist-held areas); 500 mi. bituminous
or bituminous treated, 1,900 mi. gravel, crushed stone, or improved earth;
6,800 mi. unimproved earth and often impassable during rainy season
mid-May to mid-September
Inland waterways: about 2,850 mi., primarily Mekong and tributaries; 1,800
additional miles are sectionally navigable by craft drawing less than 1.5 ft.
Ports (river): 5 major, 4 minor
Airfields: 378 total, 222 usable; 5 with permanent-surface runways; 18 with
runways. 4,000-7,999 ft., 1 with runway 8,000-11,999 ft.
Telecommunications: service to general public considered poor; radio network
provides generally erratic service to government users; poor international
service recently improved by radio relay link to Thailand; radiobroadcast
transmitters operate in a few towns; 1,148 (est.) telephones; 70,000 {est.)
radio receivers
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1971, $37,000,000; about 49%
of total budget
180
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Nis 288 Approved For Release 2004/08/36anChA-RDP79-01051A000400010002-1
LAND:
4,000 sq. mi.; 27% agricultural land, 64% desert, waste,
or urban, 9% forested
Land boundaries: 285 mi.
TURKEY
WATER:
Limits of territorial waters: no claims (fishing, 6 n. mi.)
Coastline: 140 mi.
Highways: 5,133 mi.; 3,821 mi. paved, 342 mi. gravel and crushed stone, 373 mi.
improved earth, 597 mi. unimproved earth
Pipelines: crude oil, 85 mi.
Ports: 3 major, 5 minor
Merchant marine: 43 ships (1,000 GRT or over) totaling 121,100 GRT, 183,500 DWT;
includes 39 cargo, 4 bulk; 17 ships are foreign owned or operated
Civil air: 14 major transport aircraft
Airfields: 11 total, 4 usable; 4 with permanent-surface runways; 3 with runways
8,000-11,999 ft.; 1 seaplane station
Telecommunications: excellent international telecommunication facilities include
satellite ground station; good domestic telephone and telegraph service;
150,500 telephones; 600,000 radio and 300,000 TV receivers; 7 TV, 2 FM, and
1 AM radiobroadcast stations; 1 submarine cable
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $55.8 million; about
20.7% of proposed total budget
182
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 61 Approved For Release 2004/08/31 5, GIA-RDP79-01051A000400010002-1
LAND:
11,700 sq. mi. (1969); 12% cultivable; largely mountainous
Land boundaries: 500 mi.
Railroads: 1 mi.; owned, operated, and included in the statistics of the Republic
of South Africa
Highways: approx. 1,136 mi.; 76 mi. paved; 269 mi. crushed stone, gravel, or
stablized soil; 791 mi. improved or unimproved earth
Civil air: no major transport aircraft
Airfields: 36 total, 21 usable; 3 with runways 4,000-7,000 ft.
Telecommunications: system a modest one consisting of a few landlines, a small
radio-relay system, and minor radiocommunication stations; Maseru is the
center; 2,000 telephones; 5,000 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
None, police only
184
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Appro
oe pproved For Release 2004/08/#23 CIA-RDP79-01051A000400010002-1
SF HANCE
D:
43,000 sq. mi.; 20% agricultural, 30% jungle and swamps;
40% forested, 10% unclassified (1969)
Land boundaries: 830 mi.
WATER: :
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.) |
Coastline: 360 mi.
Railroads: 310 mi.; 220 mi. standard gage, 90 mi. narrow gage (3''6"); al] lines
single track; rail systems owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
Highways: 4,150 mi.; 325 mi. bituminous treated, 875 mi. laterite, 2,950 mi.
unimproved
Inland waterways: 230 mi. navigable
Ports: 3 major, 4 minor
Merchant marine: 1,966 ships (1,000 GRT or over) totaling 37,945,400 GRT,
67,814,400 DWT; includes 12 passenger, 529 cargo, 741 tanker, 535 bulk, 149
specialized carriér; though this registry ranks first in tonnage in the
world, all but 3 ships are foreign owned and operated
Civil air: 2 major transport aircraft
Airfields: 59 total, 40 usable; 3 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone and telegraph limited; main center is Monrovia;
6,000 telephones; 155,000 radio and 6,500 TV receivers; 3 AM, no FM,
2 TV stations; 2 submarine cables
DEFENSE FORCES:
Supply: dependent mainly on U.S., has received small arms and ammunition from
Israel, 6 armored cars from Switzerland and 16 trucks from Japan
Military budget: for year ending 31 December 1970, $3,383,000; 5.6% of total budget
186
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 200 : - a
tn pp e 4108/34 -,CIA RDP79-01051A000400010002-1
LAND:
679,000 sq. mi.; 6% agricultural, 1% forested, 93%
desert, waste, or urban (1962)
Land boundaries: 2,700 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 1,100 mi.
Railroads: none
Highways: 5,300 mi.; 3,450 mi. bituminous or bituminous surface treated, 1,250
mi. improved earth and gravel, 600 mi. unimproved earth
Pipelines: crude oi] 1,890 mi.; natural gas 311 mi.; refined products 143 mi.
Ports: 4 major, 12 minor
Civil air: 7 major transport aircraft; an additional 27 major transports are
operated by external carriers engaged in charter work for several oil companies
Airfields: 102 total, 81 usable; 14 with permanent-surface runways; 4 with runways
8,000-11,999 ft., 36 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: system is just within top one-third of African systems; con-
sists of radio-relay and tropospheric-scatter links, open-wire lines, and
radiocommunication stations; principal centers are Tripoli and Benghazi;
34,790 telephones; 225,000 radio and 12,500 TV receivers; 7 AM, 5 FM, and
3 TV stations; 3 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1970, $254,500,000; 21.3% of
total budget
188
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 15 Approved For Release 2004/06/3 ANSTIANRDP79-01051A000400010002-1','2d295c42b56e38f18ebe8085c4230cc63ddd6de75009cb49e955fb32131bd059','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b4c9f8610c5e308a836d88df849c2137d852844b3cafb7f0e338786a2a01365',1971,'NO','Norway','communications',32,'LAND:
65 sq. mi.
Land boundaries: 47 mi. zo. 1
East { LAND
Rep. _J
“GERMANY 5
FON
Railroads: 9.94 mi. 4''8 1/2" gage, electrified; owned, operated, and included in
statistics of Austrian Federal Railways
Highways: no information on total mileage
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system serving about 9,500 telephones;
no broadcast facilities; 4,000 radio and 3,400 TV receivers (programed from
Switzerland)
189
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 6 Approved For Release 2004/0B/%#pGilAGRDP79-01051A000400010002-1
LAND:
1,000 sq. mi.; 26% arable, 26% meadows and pasture, 16%
waste or urban, 32% forested, negligible amount of
inland water (1969)
Land boundaries: 221 mi. i
LUXE
Railroads: 203 mi. standard gage; 100 mi. double track; 85 mi. electrified
Highways: 3,070 mi.; all paved
Pipelines: refined products, 30 mi.
Inland waterways: 23 mi.; Moselle River
Port: Mertert
Civil air: 7 major transport aircraft
Airfields: 2 total, 1 usable with permanent-surface runway 8,000-11,999 ft.
Telecommunications: adequate and efficient modern system; serves as transfer
point for international European communications; 105,500 telephones; 152,000
radiobroadcast receivers; 66,600 TV receivers; AM megawatt service of Radio
Luxembourg reaches most of Europe; 3 FM stations; 1 TV station with 6 relays
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $8.5 million; 3.0% of
central government budget
192
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Nrs 39¢c Approved For Release 2004/08/@4caCIA-RDP79-01051A000400010002-1
LAND:
6 sq. mi.; 10% agricultural, 90% urban (1968)
Land boundaries: 220 yds.
WATER:
Limits of territorial waters: territorial sea claim 6 n. mi
fishing, 12 n. mi.
Coastline: 25 mi.
Railroads: 540 mi. of meter gage
Highways: 5,300 mi.; 1,550 mi. paved 2,550 mi. crushed stone, gravel, or stabi-
lized soil; 1,200 mi. improved and unimproved earth; remainder are tracks
Inland waterways: 1,200 mi. navigable; Lac Alaotra (200 sq. mi.)
Ports: 4 major, 13 minor
Merchant marine: 8 ships (1,000 GRT or over) totaling 37,500 GRT, 54,100 DWT;
includes 6 cargo, | tanker, 1 specialized carrier
Civil air: 11 major transport aircraft
Airfields: 359 total, 178 usable; 24 with permanent-surface runways ; 3 with run-
ways 8,000-11,999 ft,, 49 with runways 4,000-7,999 ft.; 6 seaplane stations
Telecommunications: telephone and telegraph generally adequate in urban areas;
25,300 telephones; 500,000 radio and 300 TV receivers; 4 AM, no FM, and
1 TV stations
DEFENSE FORCES:
Supply: largely dependent on France; has received some ground force materiel
from Israel and West Germany
Military budget: for fiscal year ending 31 December 1970, $12.2 million; about
7:8% of total budget
196
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 57c Approved For Release 2004/08/34,¢ GfA-RDP79-01051A000400010002-1
LAND:
36,700 sq. mi.; about 31% of land area arable (of which : is
less than half is cultivated), nearly 25% forested, algeria) paste VAT
SAUDI
6% meadow and pasture, 38% other (1966)
Land boundaries: 1,790 mi.
Railroads: 352 mi. (3''6" gage)
Highways: 6,610 mi.; 430 mi. paved; 555 mi. crushed stone, gravel, or stabilized
soil; 5,625 mi. earth
Inland waterways: Lake Nyasa, 800 route mi. and Shire River, 90 mi.
Ports: 2 minor
Civil air: 4 major transport aircraft
Airfields: 37 total, 35 usable; 1 with permanent-surface runway; 7 with
runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: the system is barely above average for African countries
and consists of thinly spread open-wire lines, radio-relay links, and
radiocommunication stations; principal centers are Blantyre and Zomba;
11,500 telephones; 106,000 radio receivers; 5 AM, 4 FM and no TY stations
198
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
he em — UR Latin: mea TO:
wy ets es eons —
NIS 44 Approved For Release 2004/98/34 (GIA-RDP79-01051A000400010002-1
NOTE:
Malaysia, which came into being on 16 September 1963,
consists of West Malaysia, which includes 11 states
of the former Federation of Malaya, plus East
Malaysia, which includes the 2 former colonies of
North Borneo (renamed Sabah) and Sarawak
LAND:
West Malaysia: 50,700 sq. mi.; 20% cultivated, 26%
forest reserves, 54% other (1965)
Sabah: 29,400 sq. mi.; 13% cultivated, 34% forest
reserves, 53% other (1966) BONS
Sarawak: 48,300 sq. mi.; 21% cultivated, 24% forest reserves, ~ other a5
Land boundaries: West Malaysia 315 mi., East Malaysia 873 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: West Malaysia, 1,045 mi., East Malaysia 1,439 mi.
Railroads:
West Malaysia: 1,014 mi. 3''3 3/8" gage; 8 mi. double track; government-owned
East Malaysia: 96 mi. meter gage in Sabah
Highways :
West Malaysia: 10,500 mi.; 8,925 mi. hard surfaced (mostly bituminous surface
treatment), 1,150 mi. crushed stone/gravel, 425 mi. improved or unimproved
earth
East Malaysia: about 3,140 mi. (1,608 in Sarawak, 1,532 in Sabah); 520 mi.
hard surfaced (mostly bituminous surface treatment), 1,853 mi. gravel or
crushed stone, 767 mi. earth
Inland waterways :
West Malaysia: 1,985 mi.
East Malaysia: 2,540 mi. (975 mi. in Sabah, 1,565 mi. in Sarawak)
Ports:
West Malaysia: 3 major, 10 minor
East Malaysia: 4 major, 7 minor (3 major, 3 minor in Sabah; 1 major, 4 minor
in Sarawak)
Merchant marine: 11 ships (1,000 GRT or over) totaling 57,300 GRT, 67,600 DWT;
ancludes 9 cargo, 2 tanker
Civil air: 10 major transport aircraft
Pipelines: crude oil, 90 mi.; refined products, 35 mi.
Airfields:
West Malaysia: 105 total, 70 usable; 15 with permanent-surface runways ;
2 with runways 8,000-11,999 ft., 11 with runways 4,000-7,999 ft.; 3
seaplane stations
Sabah: 37 total, 32 usable; 5 with permanent-surface runways; 5 with runways
4,000-7,999 ft.; 3 seaplane stations
Sarawak: 48 total, 43 usable; 5 with permanent-surface runways ; 4 with
runways 4,000-7,999 ft.
Telecommunications:
West Malaysia: good intercity service provided mainly by microwave relay;
international service good; good coverage by radio and television broad-
casts; 146,212 telephones ; 430,000 radio and 130,000 TV receivers ; 9 towns
have AM stations; no FM, 8 TV stations; submarine cables extend to India,
Ceylon, and Singapore; connected to SEACOM submarine cable terminal at
Singapore by microwave relay
Sabah: adequate intercity radio-relay network extends to Sarawak via Brunei ;
10,246 telephones; 48,800 radio receivers; 3 AM, 1 FM, no TV stations;
SEACOM submarine cable links to Hong Kong and Singapore
Sarawak: adequate intercity radio-relay network extends to Sabah via Brunei;
12,188 telephones; 49,055 radio and no TV receivers; 2 AM, no FM, no TY
stations
202
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
DEFENSE FopmRroved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
External defense dependent on loose Five Power Defense Agreement (FPDA) which
replaced Anglo-Malayan defense agreement of 1957 as amended in 1963; FPDA,
effective as of 1 November 1971, also provides for small ANZUK Joint Force
composed of Australia, New Zealand, and U.K. ground, naval, and air elements,
headquarters in Singapore
Military budget: for fiscal year ending 31 December 1971, $262 million; 25%
of total budget
203
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
» wa
NIS 63 Approved For Release 2004/08/80 I:VESA-RDP79-01051A000400
LAND:
115 sq. mi.; 2,000 islands grouped into 12 atolls, 214
islands inhabited
WATER:
Limits of territorial waters: 2,75-55 n. mi. (fishing,
100-150 n. mi.)
Coastline: 400 mi. (approx. )
Railroads: none
Highways: none
Ports: 2 minor ports (Male and Gan)
Merchant marine: 20 ships (1,000 GRT or over) totaling 53,400 GRT, 70,100 DWT;
includes 18 cargo, 2 bulk
Civil air: no major transport aircraft
Airfields: 3 total, 2 usable; 2 with permanent-surface runways ; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: no domestic and international teleconmmunication facilities;
200 telephones; 1,250 radio sets; 1 AM station
205
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
a
Approved Fo .
NIS 50H p r Release 2004/0843/;: CIA-RDP79-01051A000400010002-1
LAND: ,
465,000 sq. mi.; only about a fourth of area arable,
forests negligible, rest sparse pasture or desert
(1967)
Land boundaries: 4,635 mi.
Railroads: 400 mi. meter gage
Highways: approximately 7,500 mi.; 870 mi. bituminous, 3,215 mi. gravel, 580 mi.
improved earth, 2,835 mi. unimproved earth
Inland waterways: 1,141 mi. navigable
Civil air: 7 major transport aircraft
Airfields: 55 total, 39 usable; 6 with permanent-surface runways; 2 with runway
8,000-11,999 ft., 11 with runways 4,000-7 ,999 ft.
Teleconmunications: system poor and provides only minimum service to government,
business, and public; open-wire and radiocommunication used for long distance
telecommunications; radio sometimes only link to outlying points; 6,670
telephones; 60,000 radio receivers; 2 AM, no FM, and no TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $6,100,000; about 14.5%
of total budget
208
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 25B Approved For Release 2004/0@/3/,: CIA-RDP79-01051A000400010002-1
LAND:
121 sq. mi.; 50% arable, negligible amount forested,
remainder urban, waste, or other (1965)
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 87 mi.
Highways: 743 mi., 625 mi. paved (asphalt), 85 mi. crushed stone, 15 mi. improved
earth, 18 mi. unimproved
Ports: 2 minor
Merchant marine: 5 ships (1,000 GRT or over) totaling 29,500 GRT, 45,900 DWT;
includes 3 cargo, 2 bulk; 2 ships are foreign owned and operated
Civil air: no major transport aircraft
Airfields: 4 total, all usable; 4 with permanent-surface runways; 3 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: modern automatic telephone system centered in Valletta;
33,100 telephones; 67,000 radio receivers (including 46,700 subscribers to
the wired broadcast service of Rediffusion Malta, Ltd.); 50,000 television
receivers; 3 AM, 2 FM, and 1 TV stations; extensive wired broadcast service;
10 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1971, $739,200; about 1.6% of
central government bugdet
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 83 Approved For Release 2004/08 211 Gi4uRDP79-01051A000400010002-1
LAND:
425 sq. mi.; 31% cropland, 16% pasture, 29% forest, 24%
wasteland, built on (1970)
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 180 mi.
PEOPLE: c
Population: 347,000, average annual growth rate 1.8% (FY70);}
males 15-49, included in France Spagic
Ethnic divisions: 90% African and African-Caucasian-Indian bee
mixture, 5% East Indian, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 25% agriculture, 25% unemployed
Organized labor: 17% of labor force
Railroads: none
Highways: 1,100 mi.; 600 mi. paved, 500 mi. gravel and earth
Ports: 1 major (Fort-de-France), 5 minor
Civil air: no major transport
Airfields: 2 usable; 1 with permanent-surface runway; 1 with runway 4 ,000-7,999
ft; 1 seaplane station
Telecommunications: domestic facilities inadequate; international facilities
approaching saturation point; 15,900 telephones, 72% automatic; international
radiotelegraph carriers, 25 telex circuits; inter-island VHF radio links;
satellite earth station under construction and scheduled for completion at
end of 1971; 1 AM radio station and 1 TV station with 3 rebroadcast
transmitters; about 33,000 radio and 9,200 TV receivers
DEFENSE FORCES:
Defense is responsibility of France
212
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 50F Approved For Release 2004/08/31 TAGIA-RDP79-01051A000400010002-1
D:
419,000 sq. mi.; less than 1% suitable for crops, 10%
pasture, 90% desert (1970)
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 490 mi.
Railroads: 400 mi. standard gage, single track, privately owned
Highways: 3,785 mi.; 220 mi. paved; 500 mi. gravel, crushed stone, or otherwise
improved; 3,065 mi. unimproved
Inland waterways: 500 mi.
Ports: 3 major
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,520 GRT, 1,695 DWT
Civil air: 5 major transport aircraft
Airfields: 40 total, 29 usable; 9 with permanent-surface runways; 16 with run-
ways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone poor, telegraph fair; 1,200 telephones; 55,000
radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1971, $5,400,000; 16.0%
of total budget
214
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
(
NIS 63
LAND:
720 sq. mi. (excluding dependencies); 50% agricultural, in-
tensely cultivated; 39% forests, woodlands, mountains,
river, and natural reserves; 3% built-up areas; 9%
water bodies, 2% roads and tracks, 1% permanent
wastelands (1970)
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 110 mi.
Highways: 1,100 mi.; 990 mi. paved, 110 mi. earth
Civil air: no major transport aircraft
Ports: 1 major, 2 minor
Airfields: 6 total, 5 usable; 1 with permanent-surface runway 8,000-11,999 ft.
Telecommunications: 16,800 telephones; radio telegraph service with Reunion,
Malagasy Republic, Seychelles, Zanzibar, and other places in Africa; 1 AM,
no FM, and 4 TV stations; 103,500 radio and 18,800 TV sets; submarine cables
extend to Republic of South Africa and Seychelles Islands
‘DEFENSE FORCES:
Military budget: for fiscal year 1971-72, $2,864,000 (combined military and internal
ses 6.1% of total budget
216
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 3 Approved For Release 2004/08434.coCIA-RDP79-01051A000400010002-1
Tee NORWAY
LAND:
0.6 sq. mi.
Land boundaries: 2.3 mi.
EO. C, \\
EAST POLAND
\\
"GERMANY 5
FN
WATER: eae ea)
Limits of oe waters: claims 3 n. mi. (fishing 12 iS ees
n. mi.
Coastline 2.6 mi. BANGS
Railroads: 1 mi. (see France)
Highways: none; city streets
Ports: 1 minor
Merchant marine: 4 ships (1,000 GRT or over) totaling 27,400 GRT, 40,300 DWT;
includes 2 cargo, 2 tankers
Civil air: no major aircraft
Airfields: none
219
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS (conPi@pir lease 20Q4/ GhAwRDPX
Tel TIONS (configproved For Re ¢ QAhds 9°61 esarenooavinntado2 1
telephone system with about 14,800 telephones ; international roadcas ts"
FM and TV facilities; 10,500 radio and 15,100 TV receivers
DEFENSE FORCES:
France responsible for defense
220
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 40 Approved For Release 2004/98(%6):;@IA-RDP79-01051A000400010002-1
LAND:
604,100 sq. mi.; almost 90% of land area is pasture or
desert wasteland, varying in usefulness, less than
1% arable, 10% forested (1971)
Land boundaries: 4,975 mi.
Railroads: 1,105 mi. standard gage, 100 mi. double track; 454 mi. electrified
Pipelines: crude oi1, 86 mi.; refined products, 307 mi.; natural gas, 18 mi.
Ports: 8 major, 12 minor
Merchant marine: 12 ships (1,000 GRT or over) totaling 35,100 GRT, 46,000 DWT;
includes 10 cargo, 2 specialized carrier
Civil air: 10 major transport aircraft
Airfields: 139 total, 84 usable; 23 with permanent-surface runways; 2 witn
runways over 12,000 ft., 8 with runways 8,000-11,999 ft., 40 with runways
4,000-7,999 ft.; 4 seaplane stations
Telecommunications: superior system by African standards composed of open wave
lines, coaxial multi-conductor and submarine cables and radio relay links;
principal centers Casablanca and Rabat, secondary centers Fes, Marrakech,
Qujda, Sebaa Aioun, Tangier and Ftetouan; 170,000 telephones; 934,689 radio
and 173,904 TV receivers; 25 Moroccan AM, 1 Voice of America AM, 3 FM, 17 TV
stations; 11 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31: December 1970, $140.8 million; 17.5%
of total budget
224
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 58 Approved For Release 2004/Q8/@® i@IA-RDP79-01051A0004000100
D:
292,000 sq. mi.; 30% arable, of which 1% cultivated, 56%
woodland and forest, 14% wasteland and inland water
(1966)
Land boundaries: 2,885 mi.
WATER: ; ;
Limits of territorial waters: 6 n. mi. (fishing, 12 n. mi: )
» Coastline: 1,800 mi.
Railroads: 2,437 mi.; 2,345 mi. 3''6" gage (6 mi. double track), 92 mi. 2''5 1/2"
gage
Highways: 20,000 mi.; 1,000 mi. paved; 19,000 other (mostly earth)
Inland waterways: approx. 2,330 mi. of navigable routes
Pipelines: crude oil, 186 mi.
Ports: 3 major, 13 minor
Civil air: 16 major transport aircraft
Airfields: 319 total, 277 usable; 14 with permanent-surface runways, 5 with run-
ways 8,000-11,999 ft., 24 with runways 4,000-7,999 ft.; 5 seaplane stations
Telecommunications: system ranks at the bottom of top two-fifths of African
systems and employs a basic low-capacity open-wire network supplemented
by numerous smal] radiocommunication stations and a single tropospheric
scatter system; important centers are Lourenco Marques, Beira, Nampula,
and. Tete; 25,400 telephones ; 110,000 radio receivers; 9 AM, 1 FM, and no
TV stations ,
DEFENSE FORCES:
Defense is responsibility of Portugal
Military budget: for fiscal year ending 31 December 1971, $34.6 million; about
12.6% of national budget
Approved For Release 2664/08/31 : CIA-RDP79-01051A000400010002-1
NIS 102 Approved For Release 2004/08/44 rGIA-RDP79-01051A000400010002-1
LAND:
WATER:','40edb36302cdcff0ddd7cba98fe4dd88365b20f638fe203fd0784765355252da','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8da31a16fa284e83bc35e39e346bd8c137e6eec5c52858b3b25e3cfcd862f79',1971,'AU','Australia','communications',41,'Railroads: none
Highways: about 17 mi.; 13 mi. paved, 4 mi. improved earth
Inland waterways: none
Ports: 1 minor
Merchant. marine: 3 ships (1,000 GRT or over) totaling 23,800 GRT; 25,500 DWT;
includes 2 cargo, | bulk
Civil air: no major transport aircraft
Airfields: 1, coral-surfaced, 5,270 ft.
227
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS (cont''d):
Telecommunications: adequate qnterisland and international radiocommunications
provided via Australian facilities; 381 telephones; 1 AM, but no TV or FM
radiobroadcasting facilities; number of radios unknown
DEFENSE FORCES:
No formal defense structure and no regular armed forces
Approved For Release 2604/08/31 : CIA-RDP79-01051A000400010002-1
NIS 35A Approved For Release 2004/08/34-, GIA-RDP79-01051A000400010002-1
54,600 sq. mi.; 16% agricultural area, 14% permanent meadows
and pastures, 38% alpine land (unarable), waste, or
urban; 32% forested (1966)
Land boundaries: 1,720 mi.
Railroads: 63 mi., all narrow gage (2''6"); 50% government owned; all in Teraiarea
close to Indian border and little used
Highways: 1,660 mi.; 410 mi. paved, 255 mi. gravel or crushed stone, 475 mi.
improved earth; 525 mi. unimproved earth, 200 mi. of seasonally motorable
tracks
Airfields: 47 total, 45 usable; 4 with permanent-surface runways; 5 with runways
4,000-7,999 ft.
Telecommunications: poor telephone and telegraph service;:good radiocommunication
and broadcast service; international radiocomnunication service is poor;
5,400 telephones, 55,000 radio and no TV sets, 2 AM, no FM, and no TV stations
DEFENSE FORCES:
Supply: all military supplies imported; India, U.K., U.S. principal suppliers
230
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
——wae ee —_——~ Ape Be * TAR hg, EET et ee ~ aon,” — wan
= tgs “Bane
he!
Wea Approved For Release aC NE RERLANDS tts oon HOOOsCOCICCO2
LAND:
13,100 sq. mi.; 25% arable, 31% meadows and pastures,
31% waste or urban, 8% forested; inland water areas
excluded (1968)
Land boundaries: 635 mi.
WATER:
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Coastline: 280 mi.
Railroads: 1,956 mi., standard gage; 970 mi. double track; 1,022 mi. electrified
Highways: 46,000 mi.; 26,000 mi. paved, 4,000 mi. crushed stone and gravel,
16,000 mi. earth
Inland waterways: 3,940 mi.; less than 962 mi. is natural river; more than 1,400
mi. navigable by craft of 1,000-ton capacity; 1,011 mi. will take 1,500-ton
vessels
Pipelines: crude oil, 254 mi.; refined products, 602 mi.; natural gas, 4,203 mi.
Ports: 8 major, 5 minor
Merchant marine: 469 ships (1,000 GRT or over) totaling 4,663,800 GRT, 6,877,500
DWT; includes 8 passenger, 339 cargo, 81 tanker, 29 bulk, 12 specialized
carrier
Civil air: 91 major transport aircraft
Airfields: 27 total, 25 usable; 16 with permanent-surface runways; 12 with
runways 8,000-11,999 ft., 3 with runways 4,000-7,999 ft.
Telecommunications: highly developed, excellently maintained, and well integrated;
extensive system of multiconductor cables, supplemented by radio relay links,
submarine cables, and radiocommunication stations; 3.12 million telephones;
4.81 million radiobroadcast and 3.04 million TV receivers; 5 AM, 12 FM, and
7 TV stations which provide countrywide service; 10 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $1,113 million;
about 12% of central government budget
232
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
re Approved For Release, 2004/08(3.4 “AFACRERP 79-01051A000400010002-1
LAND:
394 sq. mi.; 5% arable, 95% waste, urban, or other (1951)
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 226 mi.
2 BARBADOS
Papua:
New
Railroads: none
Highways: approx. 2,480 mi.; about 1,360 mi. suitable for heavy and medium
traffic, and about 1,120 mi. suitable for light traffic
Inland waterways: 800 mi., not including minor rivers
Ports: 1 principal (Port Moresby), 1 secondary
Civil air: see New Guinea (below)
Airfields: 180 total, 128 usable; 7 with permanent-surface runways; 14 with
runways 4,000-7,999 ft.; 10 seaplane stations, inactive
Telecommunications: see New Guinea (below)
Guinea:
Railroads: none
Highways: approx. 6,430 mi.; approx. 3,865 mi. suitable for heavy and medium
traffic, and 2,565 mi. suitable for light traffic only
Inland waterways: 1,350 mi., northeast New Guinea; minor rivers not included
Pipelines: crude oil, 87 mi.
Ports: 4 principal (Rabaul, Lae, Madang, Kavieng), 4 minor
Civil air: 16 major transport aircraft (plus 26 registered in Australia)
Airfields: 631 total, 422 usable; 13 with permanent-surface runways; 48 with
runways 4,000-7,999 ft.; 14 seaplane stations, inactive
Teleconmunications: Papua New Guinea telecom services are adequate and are
being improved; principal telecom centers include Goroka, Lae, Madang,
Mount Hagen, and Wewak in New Guinea; and Daru, Port Moresby and Samarai in
Papua; facilities provide radiobroadcast, radiotelephone and telegraph,
coastal radio, aeronautical radio and international radiocommunication
services; numerous privately owned radio facilities exist; submarine
cables extend from Madang to Australia and Guam; 18,998 telephones, 75,000
radios, but no TV sets; 11 AM, no FM and no TV facilities
DEFENSE FORCES:
Defense is responsibility of Australia
256
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A .
Mrs pproved For Release 2004/98/35 GIA-RDP79-01051A000400010002-1
LAND:
157,000 sq. mi.; 2% under crops, 24% meadow and pasture,
52% forested, 22% urban, waste, and other
Land boundaries: 2,140 mi.
Railroads: none
Highways: 365 mi.; 132 mi. metalled all-weather, 233 mi. earth
Ports: 5 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,820 GRT, 2,700
DWT
Civil air: (see Western Samoa)
Airfields: 3 total; 1 usable, with grass runway 7,000 ft.; 1 seaplane station
Telecommunications: 936 telephones; 7,600 radio sets; no TV sets; ] AM station
Approved For Release 2004/08/31 “@iA-RDP79-01051A000400010002-1
NIS 81D Approved For Release 2004/08/34) GUAASHP79-01051A000400010002-1
LAND:
1,980 sq. mi.; 41.9% in farms (of which 25.7% cropped or
fallow, 1.5% pasture, 10.6% forests, 4.1% unused or
built-on), 58.1% outside of farms, including
grassland, forest, built-up area, and wasteland
WATER: i . VENEZUELA
Limits of territorial waters: 12 n. mi.
Coastline: 225 mi. COLOMBIA
PEQPLE: BRAZIL
Population: 967,000, average annual growth rate 1.3%
(April 60-70); males 15-49, 213,000; 150,000 fit for
military service
Ethnic divisions: 43% Negro, 36% East Indian, 16% mixed, 2% white, 3% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23% Hindu, 6% Muslim, 13% unknown
Language: English
Literacy: 80%
Labor force: about 368,400 (June 1969), at least 15% unemployed; about 20.4%
agriculture, 18.3% mining, quarrying, and manufacturing, 15.8% commerce;
14.6% construction and utilities; 6.9% transportation and communications;
20.8% services (1965); shortage of technical and managerial personnel
Organized labor: 24% of labor force
Railroads: none
Highways: 4,200 mi.; 2,500 mi. paved, 1,700 mi. gravel or otherwise improved
Pipelines: crude oi1, 243 mi.; refined products, 12 mi.; natural gas, 130 mi.
Ports: 3 major, 6 minor
Civil air: 8 major transport aircraft
Airfields: 12 total, 9 usable; 3 with permanent-surface runways ; 1 with runway
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international service via tropospheric scatter
link to Barbados and Guyana; good local service; satellite ground
station to be operational in 1971; 51,700 telephones; est. 250,000 radio
and 54,000 TV receivers; 2 AM, 2 FM, and 2 TV stations
DEFENSE FORCES:
Supply: mostly from U.K.
Military budget: proposed for fiscal year ending 31 December 1969, $2,500,000;
about 1.5% of central government budget
!
Approved For Release 3664/08/31 : CIA-RDP79-01051A000400010002-1
Approved F 3
ire mae pp or Release 2004/0831 §1@AsRDP79-01051A000400010002-1
LAND:
gaia ae mi. (1965); almost all desert, waste or urban
1963
Land boundaries: 680 mi. (does not include boundaries
between adjacent Trucial Sheikhdoms )
WATER:
Limits of territorial waters: Abu Dhabi 3 n. mi.; Sharjah
12 n. mi., others not available
Coastline: 900 mi.
Railroads: none
Highways: 175 mi. bituminous, undetermined mileage of earth tracks
Pipelines: crude oil, 170 mi.
Ports: 2 major, 4 minor
Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 6,500 GRT, 11,500 DWT
339
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS (cont aproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Civil air: no major transport aircraft
Airfields: 86 total, 37 usable; 3 with permanent-surface runways ; 1 with runway
8,000-11,999 ft., 15 with runways 4,000-7,999 ft.
Telecommunications: telephone system jn Dabai and Al Sharjah, also links
these towns; Abu Dhabi Petroleum operates a telecom system throughout
the sheikhdom; key centers are Tarif, Habshaan, and Jebel Dhana; 6,800
telephones; 250,000 radio and 10,000 TV receivers; 3 AM, 1 FM, and 1 TY
stations
DEFENSE FORCES:
Defense is responsibility of U.K.
340
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
D:
63,400 sq. mi.; 28% arable land and tree crops, 23% range
and esparto grass, 6% forest, 43% desert, waste or
urban
Land boundaries: 875 mi.
WATER:
Limits of territorial waters: 6 n. mi. (fishing, 12 n. mi
follows meter isobath in south; maximum extent 80 n.
mi.)
Coastline: 710 mi. (includes offshore islands)
Railroads: 5,286 mi.; 5,266 mi. 4''8 1/2" gage, 51 mi. double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 35,729 mi.; 11,806 mi. paved, 18,641 mi. gravel or crushed stone,
5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oil, 40 mi.; refined products, 1,277 mi.
Ports: 10 major, 35 minor
Merchant marine: 88 ships (1,000 GRT or over) totaling 576,000 GRT, 791,000 DWT;
includes 12 passenger, 56 cargo, 11 tanker, 7 bulk, 2 specialized carrier
Civil air: 21 major transport aircraft, plus 3 on leae from U.S.
Airfields: 117 total, 94 usable; 47 with permanent-surface runways ; 3 with
runways over 12,000 ft., 18 with runways 8,000-11,999 ft., 25 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international radiocommunication and domestic
telecommunication services; 513,600 telephones; 3.1 million radio and 50,000
TV receivers; 35 AM, 3 FM, and 2 TV stations; 1 submarine cable
DEFENSE FORCES:
Supply: mostly dependent on foreign sources, primarily U.S., Canada, and West
Germany; manufactures some small arms, trucks and adequate quantities of
ammunition; builds some of its naval ships
Military budget: for fiscal year ending 28 February 1972, $474.5 million; about
19% of central government budget
344
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 568 Approved For Release 2004/08/@AnD@IA-RDP79-01051A000400010002-1
LAND:
91,000 sq. mi.; 21% inland water and swamp, including
territorial waters of Lake Victoria, about 21%
cultivated, 13% national parks, forest, and game
reserves, 45% forest, woodland, and grassland (1970)
Land boundaries: 1,665 mi.
Railroads: 760 mi.; all meter gage, single track
Highways: 31,330 mi. total; 940 mi. bituminous surface treatment; 10,390 mi.
crushed stone, gravel, laterite, and improved earth; 20,000 mi. unimproved
earth roads and tracks
Lake Victoria, Lake Albert, Lake Kyoga, Lake ae and
Inland waterways:
Lake Edward (6,010 mi.); Kagera River and Victoria Nile (380 mi.
Ports: 1 major (Port Bell on Lake Victoria)
Civil air: 6 major transport aircraft
Airfields: 49 total, 42 usable; 3 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 11 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: telephone and telegraph services fair to good, intercity
connections based on 3 or 12 channel carrier systems; 27,700 telephones ;
256,000 radio and 11,000 TV receivers; 2 AM, no FM, and 6 TV stations
DEFENSE FORCES:
Supply: dependent on external sources -- U.K., Israel, U.S.S.R., and
Czechoslovakia
Military budget: for fiscal year ending 30 June 1972, $42.7 million; 16.6% of
total budget
Approved For Releasé 4004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 26 Approved For Release 2004/08/3% : ClIA-RDP79-01051A000400010002-1
LAND:
8,600,000 sq. mi.; 9.3% cultivated, 37.1% forest and
brush, 2.6% urban, industrial, and transportation,
16.8% pasture and natural hay land, 34.2% desert,
swamp, or waste (1969)
Land boundaries: 12,595 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 29,000 mi. (incl. Sakhalin)
Railroads: 83,263 mi.; 80,622 mi. broad gage, 2,641 mi. narrow gage; 58,118 mi.
broad gage single track; 19,138 mi. electrified; government owned (1970)
Highways: 934,000 mi.; 99,000 mi. paved, 266,000 mi. gravel, crushed stone,
569,000 mi. improved or unimproved earth (1969)
Inland waterways: 89,000 mi. navigable, exclusive of Caspian Sea; 27,350 mi.
principal routes (1971)
Pipelines: crude oil, 20,000 mi.; refined products, 5,000 mi.; natural gas,
42,500 mi.
Freight carried: rail -- 3,185.6 million short tons, 1,696.3 billion short
ton/mi. (January 1971); highways -- 15,620.0 million short tons, 148.0
billion short ton/mi. (January 1971); waterway -- 393.4 million short tons,
118.3 billion short ton/mi. (January 1971)
Merchant marine: 1,400 ships (1,000 GRT or over) totaling 9,369,000 GRT,
12,091,000 DWT; includes 63 passenger, 691 cargo (includes dry cargo,
refrigerated cargo, combination cargo-passenger combination cargo-training),
259 tanker, 105 bulk, 309 timber carrier, 12 specialized carrier; 145 dry
cargo ships have long hatches ranging from 53 ft. to 79 ft. in length; 594
merchant ships based in Black Sea, 322 in Baltic Sea, 405 in Soviet Far East
and 188 in Barents/White Seas
DEFENSE FORCES:
Nuclear weapons: satisfies major requirements of Soviet forces
Supply: fully supplies own needs
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 50d Approved For Release 2004/0831 oC tA-RDP79-01051A000400010002-1
D:
106,000 sq. mi.; 50% pastureland, 21% fallow, 10%
cultivated, 9% forest and scrub, 10% waste and other
uses (1967)
Land boundaries: 2,055 mi.
Railroads: 728 mi., 320 mi. meter gage, single track; Ouagadougou to Abidjan,
Ivory Coast line
Highways: 10,380 mi.; 40 mi. paved, 3,710 mi. improved, 6,630 mi. unimproved
Civil air: no major transport aircraft
Airfields: 58 total, 51 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: all services generally poor; 2,600 telephones ; 87,000 radio
receivers; 5,500 TV receivers; 2 AM, no FM, and 1 TV stations (broadcasts
temporarily suspended)
DEFENSE FORCES:
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1971, $4.6 million; 12.0% of
total budget
352
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 91 Approved For Release 2004/08/14) 4\\CIA-RDP79-01051A000400010002-1
72,200 sq. mi.; 90% agricultural land, 75% pasture, 15%
cropland, 10% urban and waste Seazil
Land boundaries: 840 mi.
WATER:
Limits of territorial waters: 200 n. mi.
Coastline: 410 mi.
PEQPLE:
Population: 2,938,000, average annual growth rate 1.2%
(FY70); males 15-49, 726,000; 565,000 fit for
military service; no conscription
Ethnic divisions: 85%-90% white, 5% Negro, 5%-10% mestizo
Religion: 66% Roman Catholic (less than half adult population attends church
regularly) 7
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed in important sectors --
25% government; 53% trade and service; 28% manufacturing and construction;
19% agriculture, forestry, fishing and mining; no shortage of skilled labor
Organized labor: about 25% of labor force (largely Communist influenced)
Railroads: 1,870 mi., all standard gage and government owned (1970)
Highways: 23,480 mi.; 970 mi. paved, 4,160 mi. otherwise surfaced, 350 mi.
improved earth, 18,000 mi. earth tracks
Inland waterways: 1,068 mi.; used by coastal and shallow-draft river craft
Freight carried: highways 80% of total cargo traffic, rail 15%, waterways 5%
Ports: 4 major, 6 minor
Merchant marine: 18 ships (1,000 GRT or over) totaling 167,500 GRT, 258,200
DWT; includes 11 cargo, 7 tanker; includes 2 naval tanker sometimes used
commercially
Airfields: 86 total, 63 usable; 6 with permanent-surface runways ; 1] with runway
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: ten-year plan developed to improve telecom facilities
underway; most modern facilities concentrated in Montevideo; 206,600
telephones; 1 million radio and 240,000 TV receivers; 70 AM, 2 FM, and 16
TV stations; 9 submarine cables
DEFENSE FORCES:
Supply: dependent on U.S. for current supplies, with few exceptions
Military budget: for fiscal year ending 3] December 1970, $31.6 million; 8.7%
of central government budget
354
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A : - - 2
NIS 17 pproved For Release 2004/08/34. : GIA-RDP79 01051A000400010002-1
YUGOSLAVIA
LAND:
0.169 sq. mi.
Land boundaries: 2 mi.
Railroads: 233 mi. 4''8 1/2" gage; all single track
Highways: 34,300 mi.; 11,000 mi. paved, 9,300 mi. gravel, 4,000 mi. improved
earth, 10,000 unimproved (including trails)
Inland waterways: 4,450 mi.; Orinoco River and Lake Maracaibo accept oceangoing
vessels
Pipelines: crude oil, 3,795 mi.; refined products, 245 mi.; natural gas, about
1,550 mi.
Ports: 6 major, 17 minor
Merchant marine: 39 ships (1,000 GRT or over) totaling 355,000 GRT, 526,300 DWT;
includes 19 cargo, 13 tanker, 4 bulk, 3 specialized carrier
Civil air: 62 major transport aircraft
Airfields: 446 total, 320 usable; 91 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 79 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: extensive radio relay; local telephone systems greatly expanded;
plan satellite ground station; planned troposcatter link to Curacao; over
377,000 telephones; est. 2.73 million radio and 700,000 TV receivers; 130
AM, 50 FM, and 30 TV stations; 6 submarine cables, including 1 coaxial
DEFENSE FORCES:
Supply: produces portion of small arms ammunition requirement; dependent upon
U.S. and Western Europe for all other materiel
Military budget: for fiscal year ending 31 December 1971, $227.5 million; about
9.4% of central government budget
358
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
i tn ling
A dF ;
eas pproved For Release 2004/09/31 cet RDP79-01051A000400010002-1
LAND:
61,300 sq. mi.3 14% cultivated, 50% forested, 36% urban
4nland water, and other (1969)
Land boundaries: 1,850 mi.
WATER:
Limits of territorial waters: 12 n. mi.
; Coastline: 490 mi.
Railroads: 770 mi.
Highways: 12,600 mi.; 3,000 mi. bituminous, 2,200 mi. gravel and crushed stone,
1,900 mi. improved earth, 5,900 mi. unimproved earth
Inland waterways: about 3,600 mi. navigable; 1,550 mi. navigable by vessels of
more than 2-meter draft
Ports: 6 major, 20 minor
Merchant marine: 20 ships totaling 23,700 GRT, 33,200 DWT; includes 19 cargo,
1 bulk; only 5 ships over 1,000 GRT
Airfields: 341 total, 211 usable; 66 with permanent-surface runways, 8 with
runways 8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 4 seaplane stations
362
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
vis 103 APProved For Release 20Q4/0A/3 f|4,RDP79-01051A000400010002-1
LAND:
1,100 sq. mi.; comprised of 2 large islands of Savai''i and
Upolu and several smaller islands, including Manono
and Apolima (1969)
WATER: :
Limits of territorial waters: 3 n. mi. cosreatin
Coastline: 250 mi.','c743636cb5f3bc98b32781a07b06bed52f521774a7c8bd292880807b1243e2fa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4244c214341ec6a3a752f06a16352ff42dcd15f8bcff253265a082e99a280720',1971,'CO','Colombia','communications',46,'Railroads: none
Highways: 440 mi.; 150 mi. paved; 190 mi. gravel, crushed stone, or improved
earth; 100 mi. unimproved earth
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 1 with asphalt runway 5,700 ft., 1 with concrete
runway 5,000 ft.; 2 seaplane stations
289
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS (coApReved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Telecommunications: partly automatic telephone system with 2,700 telephones to
be improved as result of initiation of operation of microwave radio link
between two main towns; interisland tropospheric links to Barbados and Antigua;
no data on radio or TV receivers, 1 AM station
290
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
lease 2004/08/31 : CIA-RDP79-01051A000400010002-1
Niiscaia Pe proved ber Release St. VINCENT
LAND:
150 sq. mi. (including northern Grenadines); 50% arable, 3% |’
pasture, 44% forest, 3% wasteland and built-on (1964)
WATER: Se
Limits of territorial waters: 3 n. mi. i 5
Coastline: 52 mi.
Railroads: none
Highways: 600 mi.; 150 mi. paved; 450 mi. gravel, crushed stone, or improved
earth
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 3 total; 2 usable, with asphalt runway 4,800 ft.
Approved For Release 2004/08/34: CIA-RDP79-01051A000400010002-1
roved For Release 2004.
spumuitcar ions: { (cont PR se /08/31 : CIA-RDP79-01051A000400010002-1
Telecommunications: islandwide automatic telephone system with 900
instruments; VHF interisland links to Barbados and St. Lucia; no data on
radio or TV receivers; 2 AM stations
Approved For Release $04/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Rel 200 : - - z
wea pp elease AIQ8I3 1A GI RDP79-01051A000400010002-1
LAND:
24 sq. mi.; 74% cultivated, 22% meadows and pastures, 4%
built-on (1964)
Land boundaries: 21 mi.
Railroads: none
Highways: about 65 mi.
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system serving 2,400 telephones; no
radiobroadcasting or television facilities, 3,000 radio and 600 TV receivers
(Italian broadcasts )
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
= ny
uaeogo0 Approved For Release 2004/08/34 .;,GlA-RDP79-01051A000400010002-1
618,000 sq. mi. (boundaries are poorly defined); 1%
agricultural, 1% forested, 98% desert, waste, or
urban (1963)
Land boundaries: 2,820 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 1,560 mi.
PEQPLE:
Population: about 4.7 million, average annual growth rate
2.5% (current); males 15-49, 1,350,000; 720,000 fit
for military service; about 69,000 reach military age (18) annually
Ethnic divisions: 90% Arab, 10% Afro-Asian (est. )
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 25% of population; 40% agriculture and herding, 12%
construction, 12% service, 12% government, 11% commerce
Railroads: 640 mi. meter gage; 40 mi. double track
Highways: 8,725 mi.; 1,335 mi. bituminous, 990 mi. gravel, 400 mi. improved
earth, 6,000 mi. unimproved earth
Inland waterways: 935 mi.
Merchant marine: 3 ships (1,000 GRT and over) totaling 5,300 GRT, 6,500
DWT; includes 2 cargo, 1 tanker
Ports: 1 major, 4 minor
Civil air: 5 major transport aircraft, including 1 leased to Air Mauritanie
Airfields: 40 total, 25 usable; 8 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: relatively advanced for Africa; 29,300 telephones; 268,000
radio receivers; 1,400 TV receivers; 3 AM, no FM, and 1 TV stations;
3 submarine cables
DEFENSE FORCES:
Supply: primarily dependent on France
Military budget: for fiscal year ending 30 June 1972, $17,874,100; about 10.5%
of total budget
Approved For Release 2684/08/31 : CIA-RDP79-01051A000400010002-1
NIS 63
LAND
WATER:
Railroads: none
Highways: 141 mi.; 62 mi, bituminous, 79 mi. crushed stone or earth
Ports: 1 minor port (Victoria)
Civil air: no major transport aircraft
Airfields: 2 total, 1 usable on Astove Island, 1 permanent surface 8 ,000-11,999
ft.; former RAF seaplane station at Port Victoria, Mahe Island, although
not in present use, could be used in emergency
Telecommunications: direct radiotelegraph communications with other adjacent
islands and African coastal countries; 600 telephones; 11,000 radio sets;
no TV sets; 2 AM, no FM, and no TV stations; submarine cables extend to
Aden, Tanzania, Ceylon, and Mauritius
DEFENSE FORCES:
Defense is responsibility of U.K.; no U.K. troops present
300
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A :
NIS 500 pproved For Release 2004/08/31 |:-G4A-RDP79-01051A000400010002-1
27,900 sq. mi.; 65% arable (6% of total land area under
cultivation), 27% pasture, 4% swampland, 4% forested
(1967)
Land boundaries: 580 mi.
WATER:
Limits of territorial waters: territorial sea claim 200 n.
* mi. (no fishing claim)
Coastline: 250 mi.
Railroads: 370 route miles; 310 mi. narrow gage (2''6") Sierra Leone Government
Railroad (SLR), 60 mi. narrow gage (3''6") privately owned mineral line
operated by the Sierra Leone Development. Company
Highways: 4,950 mi.; 450 mi. bituminous (including some bituminous treatment),
1,750 mi. laterite (some gravel), and 2,750 mi. earth
Inland waterways: 500 mi.; 372 mi. navigable year-round
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 15 total, 15 usable; 5 with permanent-surface runways; 1 with runway
8,000-11,999 ft. 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone and telegraph are adequate; 6,500 telephones ;
35,000 radio and 3,050 TV receivers; 1 AM, no FM, and 1 TV stations;
3 submarine cables
DEFENSE FORCES:
Supply: dependent on U.K.
Military budget: for year ending 30 June 1972, 6,122,000; 8.4% of total
budget
302
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A :
fie ase pproved For Release 2004/08/31, ClIA-RDP79-01051A000400010002-1
LAND:
225 sq. mi.; 31% built up area, roads, railroads, and
airfields, 22% agricultural, 47% other (1970)
WATER:
Limits of territorial waters: 3n. mi.
Coastline: 120 mi.
Railroads: 24 mi. of meter gage
Highways: 1,080 mi.; 650 mi. paved, 260 mi. crushed stone, 170 mi. improved
earth
Ports: 3 major
Merchant marine: 115 ships (1,000 GRT or over) totaling 633,200 GRT, 837,900
DWT; includes 4 passenger, 90 cargo, 12 tanker, 6 bulk, 3 specialized carrier
Civil air: 10 major transport aircraft
Airfields: 5 total, 5 usable; 4 with permanent-surface runways ; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate domestic facilities; good international service;
good radio and television broadcast coverage; about 136,267 telephones;
est. 227,410 radio and 145,258 TV sets; 2 AM, 4 FM, and 2 TV stations; new
SEACOM submarine cable extends to Hong Kong via Sabah, Malaysia
DEFENSE FORCES:
Supply: produces some small arms ammunition, rifles, and quartermaster- type
individual equipment; some small patrol craft built; all other materiel
jmported, mainly from U.K. and U.S.
Military budget: for fiscal year ending 31 March 1972, $191 million; 32% of
total budget
304
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 55B Approved For Release 2004/08(ih: (@IA-RDP79-01051A00040001000
ND:
246,000 sq. mi.; 13% arable (0.3% cultivated), 32%
grazing, 14% scrub and forest, 41% mainly desert,
urban, or other (1970)
Land boundaries: 1,406 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 1,880 mi.
Railroads: 12,277 mi.; 11,837 mi. 3''6" gage of which 1,323 mi. are multiple
track; 2,634 mi. electrified; 440 mi. 2''0" gage single track
Highways: 220,000 mi.; 27,300 mi. paved, 47,050 mi. crushed stone or gravel,
145,650 mi. improved and unimproved earth
Pipelines: crude oi1, 520 mi.; refined products, 450 mi.; natural gas, 200 mi.
Ports: 5 major, 6 minor
Merchant marine: 58 ships (1,000 GRT or over) totaling 405,300 GRT, 496 ,200
DWT; includes 2 passenger, 51 cargo, 3 bulk, 2 specialized carrier
Civil air: 53 major transport aircraft
Airfields: 735 total, 588 usable; 40 with permanent-surface runways; | with runway
over 12,000 ft., 6 with runways 8,000-11,999 ft., 131 with runways 4 ,000-7 ,999
ft.; 4 seaplane stations
Telecommunications: the system, except for the lack of television, is the best
developed, most modern, and highest capacity in Africa and consists of
carrier-equipped open-wire lines, coaxial cables, radio-relay links, and
radiocommunication stations; key centers are Bloemfontein, Cape Town,
Durban, Johannesburg, Port Elizabeth, and Pretoria; 1.5 million telephones ;
2 ae radio receivers; 13 AM, 60 FM, and no TV stations; 4 submarine
cables
DEFENSE FORCES:
Military budget: for year ending 31 March 1971, $360,000,000; about 9.9%
of total budget
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ee Approved For Release 2004/08/34 : ClAcRDP79-01051A000400010002-1
0S Rance
Rs al
eo Sfprains
, 318,000 sq. mi.; mostly desert except for interior
plateau and area along northern border (1970)
Land boundaries: 2,360 mi.
WATER:
Limits of territorial waters: 6 n. mi. (fishing, 12 n.
mi.)
Coastline: 925 mi.
Railroads: 1,454 mi., all 3''6" gage, single track
Highways: 21,000 mi.; 2,344 mi. bituminous treated, 220 mi. gravel and 18,436 mi.
earth road and tracks
Ports: 1 major, 1 minor
Civil air: 3 major transport aircraft (registered in South Africa)
Airfields: 118 total, 93 usable; 10 with permanent-surface runways ; 4 with
runways 8,000-11,999 ft., 39 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: system is a meager combination of open-wire lines, a single
short radio-relay link, and scattered radiocommunication stations; Windhoek
is the center; 32,100 telephones; unknown number of radio receivers; no
AM, 1 FM, and no TV stations
DEFENSE:
Defense is responsibility of Republic of South Africa
Approved For Release 2064%08/31 : CIA-RDP79-01051A000400010002-1
NIS 9 Approved For Release 2004/08/34), CIA-RDP79-01051A000400010002-1
D:
195,000 sq. mi., including Canary (2,900 sq. mi.) and
Balearic Islands (1,940 sq. mi.); 41% arable and
land under permanent crops, 27% meadow and pasture,
22% forest, 10% urban or other (1969)
Land boundaries: 1,180 mi.
WATER:
Limits of territorial waters: 6 n. mi. (fishing, 12 n.
mi.
Coastline: 3,085 mi. (includes Balearic Islands, 420 mi.,
and Canary Islands, 720 mi.)
Railroads: 10,763 mi.; 8,493 mi.; (5''6" gage), 2,270 mi. other gages
(4''8 1/2" to 1''11 5/8"), 1,309 mi., double track; 2,348 mi. electrified
Approved For Release 3664/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS (cont''d):
Highways: 83,080 mi.; national -- 24,800 mi., bituminous, 22,940 mi. crushed
stone; provincial -- 32,860 mi., 80% crushed stone, 20% paved; 2,480 mi. other
Inland waterways: about 650 mi.; of minor importance as transport arteries and
contribute little to economy
Pipelines: crude oi1, 229 mi.; refined products, 515 mi.; natural gas, 3 mi.
Ports: 23 major, 20 minor
Merchant marine: 432 ships (1,000 GRT or over) totaling 3,149,100 GRT, 4,817,300
DWT; includes 38 passenger, 237 cargo, 85 tanker, 35 bulk, 37 specialized
carrier
Civil air: 162 major transport aircraft
Airfields (including Balearic and Canary Islands): 118 total, 78 usable; 42
with permanent-surface runways; 4 with runways over 12,000 ft., 17 with
runways 8,000-11,999 ft., 36 with runways 4,000-7,999 ft.; 5 seaplane
stations
Telecommunications: modern, well engineered, well maintained; 4.5 million
telephones; 5.5 million radio and 4.5 million television receivers; 190
AM, 40 FM, and 27 TV stations with numerous FM/TV repeaters; 15 submarine
cables; 3 communication satellite ground stations
DEFENSE FORCES:
Military budget: for biennium ending 31 December 1971, $1,226 million; about
28% of total budget
Approved For Release 2004/08/34 ''2CIA-RDP79-01051A000400010002-1
NIS 50Approved For Release 2004/0863) r<GlAnRROR79-01051A000400010002-1
LAND:
103,000 sq. mi., nearly all desert
Land boundaries: 1,296 mi.
WATER:
Limits of territorial waters: 6 n. mi. (fishing, 12 n. mi.)
Coastline: 690 mi.
Railroads: none
Highways: 3,790 mi.; 305 bituminous treated, 3,485 mi. unimproved earth roads
and tracks
Ports: 2 major, 2 minor
315
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS (cARPagved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Civil air: no major transport aircraft
Airfields: 23 total, 15 usable; 3 with permanent-surface runways; 5 with
runways 4,000-7,999 ft.
Telecommunications: telephone poor, telegraph poor to fair; 540 telephones;
1,500 radio receivers; 1 AM, no FM or TV stations
316
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ete Approved For Release 2004/08/3t,: CIA-RDP79-01051A000400010002-1
LAND:
967,000 sq. mi.; 37% arable (3% cultivated), 15% grazing,
33% desert, waste, or urban, 15% forest (1970)
Land boundaries: 4,850 mi.
WATER:
Limits of territorial waters: 12 nn. mi.
Coastline: 530 mi.
Railroads: 2,950 mi.; 2,730 mi. 3''6" gage, 440 mi. 2'' gage plantation line
Highways: 6,550 mi.; 680 mi. crushed stone or gravel, 190 mi. bituminous-treated,
and 5,680 mi. improved and unimproved earth roads; in addition, there are an
undetermined number of tracks
Inland waterways: 3,300 mi. navigable
Ports: 1 major, 7 minor
Merchant marine: 5 cargo ships (1,000 GRT or over) totaling 16,400 GRT, 19,800
DWT
Civil air: 9 major transport aircraft
Airfields: 86 total, 66 usable; 4 with permanent-surface runways; 2 with runways
‘8,000-11,999 ft., 29 with runways 4,000-7,999 ft.
Telecommunications: large system by African standards, but still barely adequate
for size of country; consists of open-wire lines, radio-relay links, multi-
conductor cables, radio communication stations and a tropospheric scatter
link; principal center of Khartoum, secondary centers at Al Fashir and
Port Sudan; 45,600 telephones; 650,000 radio and 35,000 TV receivers; 2 AM,
no FM, and 1 TV stations; 5 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1971, $106.0 million; 24.0% of
total budget
Approved For Release 2664/08/31 : CIA-RDP79-01051A000400010002-1
NIS 95B Approved For Release 2004/08/34 ynftIA-RDP79-01051A000400010002-1
55,100 sq. mi.; negligible amount of arable land, meadows
and pastures, 76% forest, 8% unused but potentially
productive, 16% built-on area, wasteland, and other
(1964)
Land boundaries: 970 mi.','bbd2feb528739d4cd4be0b6e8c35ba3f8fa39b25a073a540b62a15b5534fc738','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cd192981002d94f5db972b1783a25053eccaf6a8d0c57d1303983a167c0663d',1971,'SD','Sudan','communications',47,'PEOPLE : ES ETHIOPIA
Population: 6,557,000, average annual growth rate 3.3%
(September 60-70); males 15-49, 1,490,000; 810,000 fit for military service;
about 73,000 reach military age (19) annually
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians, and other
Religion: 70.5% Sunni Muslim, 16.3% other Muslim sects, 13.2% Christians of
various sects
Language: Arabic, Kurdish, Armenian; French and English widely understood
Literacy: about 40%
Labor force: 1.2 million; 53% agriculture, 17% industry, 30% miscellaneous
services; majority unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Railroads: 649 mi.; 459 mi. standard gage, 190 mi. narrow gage (3''5 3/8")
Highways: 7,150 mi.; 4,300 mi. paved, 810 mi. gravel or crushed stone, 1,540 mi.
improved earth, 497 mi. unimproved earth
Inland waterways: 420 mi.; of little importance
Pipelines: crude oi], 1,577 mi.; refined products, 320 mi.
Ports: 3 major, 4 minor
Civil air: 5 major transport aircraft
Airfields: 86 total, 26 usable; 20 with permanent-surface runways ; 1 with runway
over 12,000 ft., 15 with runways 8,000-11,999 ft., 5 with runways 4,000-
7,999 ft.
Telecommunications: fair international radiocommunication service; poor domestic
telecommunication service; 104,000 telephones; 300,000 radio and 111,000 TV
receivers; 5 TV and 5 AM stations
328
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 56E Approved For Release 2004/08/34, G{A-RDP79-01051A000400010002-1
362,800 sq. mi. (including islands of Zanzibar and Pemba,
1,020 sq. mi.); 6% inland water, 8% cultivated, 9%
used for grazing, 77% forest, woodland, or grassland
on mainland; 50% arable, of which 40% cultivated
on islands of Zanzibar and Pemba (1965)
Land boundaries: 2,413 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 575 mi.
Railroads: 1,638 mi., meter gage, 4 mi. double track
Highways: total 21,200 mi., including 390 mi. on Zanzibar Island and 277 mi. on
Pemba and Mafia Islands; about 1,400 mi. bituminous treated, (370 mi. on
Zanzibar and Pemba); 19,800 mi. gravel, crushed stone, or unimproved earth
Pipelines: refined products 610 mi.
Inland waterways: 730 mi. of navigable streams; several thousand mi. navigable
on Lakes Tanganyika, Victoria, and Nyasa
Ports: 4 major, 8 minor -
Merchant marine: 4 cargo ships (1,000 GRT or over) totaling 21,500 GRT, 31,200
DWT
Civil air: 9 major transport aircraft
Airfields: 101 total, 89 usable; 7 with permanent-surface runways; 1 with runway
8,000 to 11,999 ft., 37 with runways 4,000-7,999 ft.; 4 seaplane stations
Telecomnunications: telephone and telegraph good in main centers, only fair
outside main towns; 31,600 telephones; 150,000 radio receivers; 4 AM, no FM
or TY stations; 4 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 30 June 1972, $41.4 million; 11% of
total budget
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Rel . - - -
ew pprov or Release 2004/08/31 AnglA RDP79-01051A000400010002-1
D:
198,000. sq. mi.; 24% in farms, 56% forested, 20% other
(1969)
Land boundaries: 3,025 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 2,200 mi.
PEQPLE:
Population: 35,774,000, average annual growth rate 2.7%
(April 60-70); males 15-49, 8,562,000; 5,220,000 fit
for military service; about 385,000 reach military age
(18) annually
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70%
Labor force: 88% agriculture, 9% commerce, 3% industry
Railroads: 2,382 mi. meter gage; 60 mi. double track
Highways: 12,590 mi.; 5,440 mi. paved, 4,820 mi. crushed stone or gravel, 2,330
earth and laterite
Inland waterways: 2,485 mi. principal waterways; 2,300 mi. with navigable depths
of 3 ft. or more throughout the year; numerous minor waterways navigable by
shallow-draft native craft
Ports: 2 major, 16 minor
Merchant marine: 22 ships (1,000 GRT or over) totaling 68,600 GRT, 101,600 DWT;
includes 15 cargo, 6 tanker, 1 specialized carrier
Airfields: 219 total, 187 usable; 40 with permanent-surface runways ; 10 with
runways 8,000-11,999 ft., 21 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: service to general public being improved, but still inadequate;
bulk of service to government activities provided by numerous radiocommunica-
tion stations and radio-relay network; satellite ground station connects to
Intelsat II and will connect to Indian Ocean satellite; 134,663 telephones ;
2,775,000 radios; 222,000 televisions; estimated 50 AM, 5 FM, and 6 TV
stations in two government-controlled networks ; U.S. military submarine
cable to South Vietnam
DEFENSE FORCES:
Military budget: for fiscal year ending 30 September 1972, $256,000,000; 18.2% of
total budget
Approved For Release 3064/08/31 : CIA-RDP79-01051A000400010002-1
NIS SON Approved For Release 2004/08/34 CIA-RDP79-01051A000400010002-1
LAND:
22,000 sq. mi.; nearly half total is arable, under 15%
cultivated (1970)
Land boundaries: 940 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 35 mi.
Railroads: 310 mi. meter gage, single track
Highways: approx. 4,475 mi.3; 235 mi. paved, 120 mi. gravel, 910 mi.
improved earth, 3,210 mi. unimproved
Inland waterways: section of Mono River and about 30 mi. of coastal lagoons
and tidal creeks
Ports: 1 major, 1 minor
Civil air: 1 major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-surface runway 4,000-7,999 ft.
Telecommunications: Togo has poor system based on skeletal network of open-wire
lines, supplemented by a few radiocommunication stations; only center is
Lome; 4,600 telephones; 45,000 radio receivers ; 1 AM, no FM or TV stations
DEFENSE FORCES:
Supply: most military materiel obtained from France
Military budget: for fiscal year ending 31 December 1971, $3,262,000; 9.0% of
total budget
Approved For Release 2604/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004 : 4 x
NIS. 102 Pp se 108/31. GIA RDP79-01051A000400010002-1
LAND:
385 sq. mi. (150 islands); 77% arable, 3% pasture, 13%
forest, 3% inland water, 4% other
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 350 mi. (est.)','50d7eb4bc2d593f018d01fed61b2df22c7f4977c72296dca39071aeda6755ab4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50745ec06db5ab7f001d6d4a320dc57e2a7186240162f7c691b3b07e87c85270',1971,'JP','Japan','communications',52,'Railroads: none
Ports: 3 major, 2 minor
Civil air: 4 major transport aircraft
367
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS (comtpproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Airfields: 35 total, 26 usable; 6 with permanent- -surface runways; 1 with
runway over 12, 600 ft., 5 with runways 8,000-11,999 ft., 14 with runways
4,000-7 ,999 ft.
Telecommunications: fair international service by radio; poor domestic wire
service; 1,900 telephones; 10,000 radio receivers (approx.); 2 AM radio-
broadcast stations
368
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 21 Approved For Release 2004/08/31: GlA-RDP79-01051A000400010002-1
LAND:
98,700 sq. mi.; 32% arable, 25% meadows and pastures,
34% forested, 9% urban, waste, and other (1967)
Land boundaries: 1,865 mi.
WATER:
Limits of territorial waters: 10 n. mi. (fishing, 12 n. mi.)
Coastline: 945 mi. (mainland), plus 1,500 mi. (offshore
islands )
Railroads: 6,640 route mi.; 5,702 mi. standard gage, 938 mi. narrow gage;
463 mi. double track (1969)
Highways: 56,565 mi.; 14,850 mi. paved, 25,715 mi. gravel, crushed stone, 15,600
mi. improved earth, 400 mi. unimproved earth (1970)
Inland waterways: 1,231 mi. (1970)
Freight carried: rail -- 79.5 million short tons, 12.7 billion short ton/mi. (1970);
highway -- 64.7 million short tons, 4.5 billion short ton/mi. (1971);
waterway -- 24.5 million short tons, est. 5.4 billion short ton/mi. (1970)
Pipelines: crude oi], 200 mi.; natural gas, 580 mi.
Merchant marine: 197 ships (1,000 GRT or over) totaling 1,505,300 GRT, 2,188,300
DWT; includes 5 passenger, 150 cargo, 17 tanker, 25 bulk
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, 8,838 million new
dinars; about 60% of the central government budget
370
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 60A Approved For Release 2004/08/34; pEIA-RDP79-01051A000400010002-1
LAND:
905,000 sq. mi.3; 22% agricultural land (1% cultivated),
45% forested, 33% other (1971)
Land boundaries: 6,220 mi.
WATER: 7
Limits of territorial waters: territorial sea claim 12 n. mi.
Coastline: 23 mi.
Railroads: 3,103 mi.; 2,419 mi. 3''6" gage, 78 mi. 3'' 3 3/8" gage, 85 mi.
2'' 0 1/4" gage, 521 mi. 1'' 11 5/8" gage; 421 mi. of 3''6" gage electrified
Highways: 91,500 mi.; 1,400 mi. bituminous, 2,200 mi. gravel or crushed stone,
87,900 mi. earth
Inland waterways: comprising the Congo, its tributaries, and unconnected lakes,
the waterway system affords over 9,329 mi. of navigable routes
Ports: 2 major, 1 minor
Merchant marine: 4 ships (1,000 GRT or over) totaling 35,900 GRT, 45,900 DWT ;
includes 1 passenger, 3 cargo
Pipelines: refined products, 461] mi.
Civil air: 26 major transport aircraft
Airfields: 482 total, 316 usable; 18 with permanent-surface runways; 1 with
runway over 12,000 ft., 2 with runways 8,000-11,999 ft., 54 with runways
4,000-7,999 ft.; 5 seaplane stations
Teleconmunications: limited, barely adequate telephone service, telegraph service
good; 22,000 telephones; 63,000 radio receivers; 7,100 TV receivers ;
12 AM, 1 FM, and 2 TV stations
372
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 57A
LAND
Railroads: 764 mi.; all narrow gage (3''6"); 8 mi. double track; 664 mi. are
government owned; 100 mi. privately owned
Highways : 21,220 mi.; 1,500 mi. paved, 3,120 mi. crushed stone, gravel, or
stabilized soil; 16,600 mi. improved and unimproved earth
Iniand waterways: 1,409 mi. including Zambezi River; Luapula River, Lake Kariba,
Lake Bangweulu, Lake Tanganyika; principal port on Lake Tanganyika is Mpulungu
Pipelines: 450 mi. refined
Civil air: 11 major transport aircraft
Airfields: 188 total, 156 usable; 6 with permanent-surface runways; 1 with
runway over 12,000 ft., 21 with runways 4,000-7 ,999 ft.
Telecommunications : all services being modernized and increased; presently
adequate but must be exparided to permit growth; high-capacity wire and
radio relay connect centers of Kitwe in northern mining region and Lusaka
along axial north-south route; 52,000 telephones ; 100,000 radio and
17,000 TV receivers; 4 AM, 1 FM, and 2 Tv stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1970, $26,400,000; about
4.8% of total budget
A
pproved For Release 2004108/31 : CIA-RDP79-01051A000400010002-1
reed
Approved For Release 2004/0878 1ST CIASRDP79-01051A000400010002-1
This "Factsheet" on the U.S. is provided solely as a service to those
wishing to make rough comparisons of foreign country data with a U.S.
"yardstick." Information is from U.S. open sources and publications
and in no sense represents estimates by the U.S. intelligence community.
LAND:
3,615,211 sq. mi. (contiguous U.S. plus Alaska and Hawaii); 19% cultivated,
( 27% grazing and pasture, 32% forested, 22% waste, urban, and other
re Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Railroads: 208,111 mi. (1968)
Highways: 3,684,000 mi. (1968); 2,894,000 mi. surfaced
Inland waterways: 25,260 mi. of navigable inland channels, exclusive of the
Great Lakes; carried 737 million short tons of cargo (1968); Great Lakes,
151 million short tons (1968)
Pipelines: petroleum, 70,000 mi.; major crude, 53,000 mi. products; gas,
200,000 mi. major transmission
375
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS (cARPAQVed For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Ports: 25 major
Merchant marine: 2,278 ships (1,000 GRT or over)
Civil air: 3,380 major transport aircraft
Airfields: 10,470 (1968)
Telecommunications: 4,138 AM, 1,737 FM, 619 TV operating stations (1968);
109,124,000 telephones (1968), 53.95 telephones per 100 population (1968)
DEFENSE FORCES:
Personnel: army 1,570,186, navy 765,232, air force 904,759, marines 307,252 (1968)
Military. budget: $80.5 billion (1968)
376
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
tie
| : |
i f !
i i i
I |
3 a —
| : ! :
| | |
i : bunt Wales pe ‘
| ~ ; ae : ! tb
i ae . :
aiiee 1
Se che
ae Sé uniTED STATES
eee? (ALASKA)
FAEROE 1s, vy 5 1,
OE. ; . NORWAY,
of es é ay aw SHETLAND IS. yj e.
Ling fea =
ales ary i ae
Lee |
NEWFOUNDLAND.
~ | :
5 | os 1 2
nee, i s
; % NDORE.| Corsica * TAL
NO bua RAR A a
i i ae + “Sardinia
: ! ee ~ ; ee
| : i : *, ee Ee
| | | NOR T HI
: Pp A Ci / / : C BERMUDALIS i H MADEIRAIIS.
| “ | ; |
| 1 oi a. i CANARY IS. -
7 | - AP PAN Pe ee
Or “Ce E> A N > JeaHana IS | : srt —
tg] 1 H SAHARA
’ : ;
STATES i aoe .
Alea | a oe OC E AN i
| | i pee ote |
| ie pt he, RAS: Shen [CAPE VERDE
CURTENA TE a? Ta shat Lak
: +” NICARAGUA Barbados
Clipperton 1, costa se ae # : me ee : See,
i x ENEZUELA — ; i SHER vette’ me ol :
Palenyca | : ! ! i : Ne, gs wren l : 1 uBeria \\ COST Sends TOGO
| { ah ¢ ¢ FRENCH GUIANA! | St x “2
'' : i A eS | ! | .
“Christmas |. : i | : Nees :
il ; ! GALAPAGOS 1S = 7 ! se : "GABON,
H | > : i b : Psy
: O | 7 i ;
: i : se ''
, i | IT LOL | Ascension 1.
Paarl MARQUESAS 16. : ip CulsoF C i | !
: i r i ;
: | | i | t
i . ! | ; . | !
: TORMOTU : t + — 7 # é
aoe Benes a ea ei E A | | | : St. Helena 1,|
: : i |
TUBUAY IS. | i ! ! | :
| i Pitcairn |: Ducie | £ f S O ; U if H en 8S Map
Easter. \\
; i : i :
} J ie tS 4 3 “= - 7 —— 4
: ae
JUAN FERNANDEZ !S a &j URUGUAY? : r L A N ! / a
\\ | ime Be uae
‘ : ; | ee = i |, Tristan da Cunha
| : '' fe x g | Sough
| be oe Oo C E™A N
| : = ee 4+ G1ASRDP79-01054A000400010002- |
Approved For Release 2004/03/31 z +9: 1 An i
a Fal Kh ann 15
|
a ats ; {
i TAN 2 soser Te | i
i : i ''
: ! ! : :
| CIA-RDP79-01051A000400010002-1 |
| s | a ~ ° |
: : i _ 4 Cope sel Et
ig i : i oe NEW SIBERTAN''|Is, 3: 44
" i oe i |
WRANGEL: I.
i | per
| j
=
!
i
i / ;
i
| i
OF SOVIET SO''ICIALIST REPUBLICS
} H |
i | i ;
! i ; i
fe
at a Atul {
Sw ha = 4 [seyesets
Sakhalin ALEUTIAN |ISLANDS
ae 4 I
i ra 7
3 i
ee ROMAN]
''
UGOSLA VY t 7 ——-—- t ~~ ee eee REN
yl ! jf :
gs . = e
a ofl | N O|R T 4
pe) hin ; * |
4 4 f , re 7 5
oa 1 pete PEOPLE’S REPUBLIC OF CHINA |
IRAN SARSGHANISTAN gf 07 4 i
f va FI
Y f “4 f we
= ib oem oe : = PA Cil Poe
Le PAKISTAN dep. ’ j ve =
’ oe pee ”s eh OWAN BONIN 15. |
Batibo i ya ic . ey 4 HAWAIIAN. is,
nf AR - ‘Ny 4 ¢
Seer a ie PAKISTAN VOLCANO 18. | Marcus |. _ =
ahem. - PO en ok st PAE GA Ne
ai : BERMAN Ta tnAeone fe : |
x | 8 Lady! oe : HEPU J i :
ate, : ek phe ede REPUBLIC OF CHINA | oo |
a beet, IETS
| - : ae ayy THAILANT, x MARIANA IS !
{ii + aoa, | : : - eae : | s
Secoira | ANDAMAN 1S, eo Sor Hogs ainn av\\GYee PHILIPPINES ua ah |
i LACCADIVE IS. i Poh i i
: : ; : : Yap : i
; CAROLINE «5
fT f sa CEYLON ‘és
va SOMALIA | | . eB 1S PALAU IS ; TRUK IS. MARSHALL
'' MEADIVES® GILBERT IS
i i
i
i : NguTT Ocean es =
; NEW GUINEA
‘ | chacos ~ i Ss } ,
SEYCHELLE ARCHIPELAGO ™S New GUINEAS, j ELUICE IS
i : Chri
| | cocos isp
: = | é |__SAMOA IS> |
; NEW HEBRIDES FULTS. aoe” :
MALAGASY : : f gia :
resco wend | N Df AN | |
ret: i I te
RéuNION | i : | New Caledonian.»
CA 4 ‘ |
re i . { | :
ee (Sitaztano i i ! a one ee i
\\ REPUBLIC Se ‘ : e : {
oF Tesoro : : Oat EA i! V : Norfolk L :
SOUTH AFRICK / 7 ; Tera Howe if RERMEDEC TSF"
_ Amsterdam 1. Me
Saint Paul 1, . _ . au
i
TASMANIA ane
ae
- PRINCE EOWARO IS. | cRORET Approved For Release 731; CIA-RBP79-610514A000400010002-1 I
KERGUELEN 15, Re :
ANTIPODES 1S','6770a208ae150dcff741a353c79500f32ff4652df1aa10226a7f3b4d413af09f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

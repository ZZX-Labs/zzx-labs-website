SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84e0d0f040dbf13fab6c7395f1246cb7add2fac1172431393bbcf4c261c0f9c0',1971,'','','economy',4,'GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971 :
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2.8 million kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $616.5 million (f.o.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
Mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Monetary conversion rate: 14 Turkish liras=US$] (official rate)
Fiscal year: 1 March - 28 February','a893c8676599b7e8f9599afa88721528d836b28df6ec5629e7a51b3407d7a703','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('392bbb1f63911a79baff619448776e3b89240cbd7c12032b7eeaa5c2a1f3eef0',1971,'UY','Uruguay','economy',6,'GNP: $45.0 billion (1977), $1,070 per capita; 3.8% real
growth 1977, 7%-8% average annual real growth 1970-76
Agriculture: main products—cotton, tobacco, cereals,
sugar beets, fruits, nuts, and livestock products; self-suffi-
cient in food in average years
Approved for Release: 2018/04/27 C06727040
Approved for Release: 2018/04/27 C06727040
January 1979
TURKEY/TUVALU
Major industries: textiles, food processing, mining (coal,
chromite, copper, boron minerals), steel, petroleum
Crude steel: 1.9 million tons produced (1976), 45 kg per
capita
Electric power: 5,000,000 kW capacity (1977); 22.0
billion kWh produced (1977), 510 kWh per capita
Exports: $2,671 million (f.0.b., 1977); cotton, tobacco,
fruits, nuts, metals, livestock products, textiles and clothing
Imports: $6,999 million (f.0.b., 1977); crude oil, machin-
ery, transport equipment, metals, mineral fuels, fertilizers,
chemicals
Major trade partners: 22% West Germany, 9% U.S., 9%
Iraq, 7% U.K., 7% Italy (1976)
Budget: (FY77) revenues $11.2 billion, expenditures $12.2
billion, deficit $1.01 billion
Monetary conversion rate: 25.25 Turkish liras=US$1
(July 1978)
Fiscal year; 1 March-28 February','6d481c40eef294111bb6be0fe2d7c7299f0393ba2d3ccfb9026500459e9c72ad','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da462ac90485430ea784cac8c8be1a436535dd4810abb3e7dec1015b1a26c251',1971,'','','economy',4,'GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2.8 million kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $616.5 million (f.0.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Aid: $390.5 million extended by Communist countries 1955-December 1971; none
extended in 1971; total U.S. economic, $2,727.9 million (1946-71); total
U.S. military $3,250.2 million (July 1946-June 1971); $603 million in aid
commitments from international tes (1946-71); $657 million in bilateral
aid from other sources 1960-70
Monetary conversion rate: 14 Turkish liras=US$1 (official rate)
Fiscal year: 1 March - 28 February','4c5921c18d539de60f8b6e157cd7b171fa7672f2c9502dc3d789c30404de55ea','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e93db3694c6bfaee8ea17ef79dc7e93e57fa679d755cd06c6a0444d3c410a35',1971,'TH','Thailand','economy',5,'GNP: $48.7 billion (1978), $1,181 per capita; 2.7% real
growth 1978, 7%-8% average annual real growth 1970-76
Agriculture: main products—cotton,. tobacco, cereals,
sugar beets, fruits, nuts, and livestock products; self-suffi-
cient in food in average. years
Major industries: textiles, food processing, mining (coal,
chromite, copper, boron minerals), steel, petroleum
245
Approved for Release: 2018/04/27 C06727042
NR Record
Approved for Release: 2018/04/27 C06727042
“SEEREL.
July 1979
TURKEY
Crude steel: 1.9 million tons produced (1976), 45 kg per
capita
Electric power: 5,000,000 kW capacity (1978); 22 billion
kWh produced (1978), 505 kWh per capita
Exports: $2,288 million (f.0.b., 1978); cotton, tobacco,
fruits, nuts, metals, livestock products, textiles and clothing
Imports: $4,599 million (c.i.f., 1978); crude oil, machin-
ery, transport equipment, metals, mineral fuels, fertilizers,
chemicals
Major trade partners: 22.1% West Germany, 9.3% Italy,
6.9% U.S., 6.2% Switzerland, 5.4% France (1977)
Aid: economic authorizations: U.S., $535 million (FY70-
71), other Western (ODA and OOF), $1,130 million (1970-
77); Communist, $1,094 million (1970-77); OPEC, ODA,
$362 million (1974-77); military authorizations: U.S., $1,414
million (FY70-77)
Budget: (FY78) revenues $13.1 billion, expenditures $14.7
billion, deficit $1.6 billion
Monetary conversion rate: 25.25 Turkish liras=US$1 -
(July 1978)
Fiscal year: 1 March-28 February','0706127ee1bc228b95463f7c80bfb44fe749b490522311d4a84d801c4b70c202','internet-archive','cia-readingroom-document-06727042','txt','3d4865ad913d7fe18d90d451e85d71a2d4a29a6ece6ee987139031bece799d60','https://archive.org/download/cia-readingroom-document-06727042/06727042_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eeabdb5be19d25e57607dc143e4c45b1557957567bde355da912801102d8d28d',1971,'','','economy',4,'GNP: $12,016 million (1971), about $330 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electrtc power: 2.6 million kw, capacity (1971); 9,724 million kw.-hr. produced
(1971), 267 kw.-hr. per capita
Exports: $616.5 million (f.0.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 192, U.S. 102, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Aid: $1,602 million assistance disbursed 1963-69 by the Aid of Turkey Consortium
consisting of the U.S., 13 additiona) OECD member countries, the IMF, IBRD,
and European Fund of the EMA; $390.5 million extended by Communist countries
1955-December 1971; none extended in 1971; total U.S. economic, $2,727.9
million (July 1946-Ju : total U.S. military $3,250.2 million
(July 1946-June 1971)
Monetary conversion rate: urkish liras=US$] (official rate)
Fiscal year: 1 March - 28 February','1de57ea31cf866407b6e812547f4485a4e5342ee730fa5f2945b98c2595fcb1c','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f0130cf7405ca1accfcb21a1a36e1404078fd0d99c87429790820394541d2de',1971,'','','economy',4,'oe ides billion (1967-70), less than $100 per capita; real growth rate 3%
1969-70)
Agriculture: agriculture and animal husbandry account for over 50% of GNP and
occupy over 80% of the labor force; main crops -- wheat, cotton, fruits,
nuts; largely self-sufficient; food shortages -- sugar, tea, wheat
Major industries: cottage industries, food processing, textiles, cement, coal
mining
Electric power: 254,000 kw. capacity (1969); 410 million kw.-hr. produced
(1969); 26 kw.-hr. per capita
Exports: $80.0 million (f.o.b., 1969-70); fruits and nuts, karakul, cotton, wool,
natural gas
Imports: $135.0 million (c.i.f., 1969-70); textiles, sugar, tea, petroleum,
transportation equipment
Major trade partners: exports -- U.S., U.K., U.S.S.R., and India; imports --
about half from U.S.S.R.
Monetary conversion rate: 45 Afghanis per US$] (official); 81 Afghanis per US$]
(June 1970)
Fiscal year: 21 March - 20 March
GNP: $0.8 billion in 1969 (at 1968 prices), $400 per capita
Agriculture: food deficit area; main crops -- corn, wheat, tobacco, sugar beets,
cotton; food shortages -- wheat; caloric intake, 2,100 calories per day per
capita (1961/62)
Major industries: agricultural processing, textiles and clothing, lumber, and
extractive industries
Shortages: spare parts, machinery and equipment, wheat
Exports: $80 million (1969 est.); 1964 trade -- 55% minerals, metals, fuels;
17% agricultural materials (except foods); 23% foodstuffs (including
cigarattes); 5% consumer goods
3
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Imports: $143 million (1969 est.); 1964 trade -- 50% machinery, equipment, and
spare parts; 16% minerals, metals, fuels, construction materials; 7%
fertilizers, other chemicals, rubber; 4% agricultural materials (except
foodstuffs); 16% foodstuffs; 7% consumer goods
Monetary conversion rate: 5 leks=US$1 (commercial); 12.5 leks=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year
1 July - 30 June
Agriculture: main crops -- bread grains, wine, citrus fruits
Major industries: petroleum (1970 crude production 47 million tons), Tight
industries, natural gas, mining, petrochemical and steel plants under
construction
Electric power: 1,462,000 kw. capacity (1970); 1,536 million kw.-hr. produced
(1970 est.); 110 kw.-hr. per capita
Monetary conversion rate: 4.937 dinars=US$1 (controlled rate)
Fiscal year: calendar year
Approved For Release 2004/08/31 : GIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Agriculture: sheep raising; small quantities of tobacco, rye, wheat, barley,
oats, and some vegetables (only 25% of land can be used for agricul ture)
Major industries: tourism (800,000 in 1965), one cigarette factory (annual
output $800,000), handicrafts, smuggling (tobacco to France; manufactured
items, including automobiles and cameras, to Spain)
Shortages: food
Electric power: 25,000 kw. capacity (1970); 100 million kw.-hr. produced (1970);
400 kw.-hr. per capita; power is mainly exported to Spain and France
Major trade partners: Spain, France
GNP: $1,100 million (1969 est.), about $200 per capita
Agriculture: cash crops -- coffee, sisal, corn, cotton, sugar, manioc, and
tobacco; food crops -- cassava, corn, vegetables, plantains, bananas, and
other local foodstuffs; largely self-sufficient in food
Major industries: mining (iron, diamonds), fish processing, brewing, tobacco,
sugar processing, cement, food processing plants, building construction
Electric power: 344,700 kw. capacity (1969); 552 million kw.-hr. produced
(1969) ; 100 kw.-hr. per capita
Exports: $276.8 million (f.0.b., 1968); coffee (50%), diamonds, sisal, fish and
fish products, iron ore, oil, timber, and corn
Imports: $309.6 million (c.i.f., 1968); capital equipment (machinery and electrical
equipment), wines, bulk iron and ironwork, steel and metals, vehicles and
Spare parts, textiles and clothing, medicines
Approved For Release 2004/08/31 : C}KA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major trade partners: main partner Portugal, followed by West Germany, U.S.,
U.K., EEC countries (primarily coffee to last three)
Aid: Portugal only donor
Monetary conversion rate: 28.75 escudos=USS1 (official)
Fiscal year: calendar year
GDP: $27.2 million (at factor cost, 1967 est.), $470 per capita
Agriculture: main crops -- sugar, cotton
Major industries: sugar processing, tourism
Shortages: electric power
Electric power: 14,040 kw. nameplate capacity (1970); less than 4,000 kw. operating;
12 million kw.-hr. produced (1969 est.); 189 kw.-hr. per capita
Exports: $2.9 million (f.o.b., 1967); sugar, molasses, cotton
Imports: $22.2 million (c.i.f., 1967); food, clothing, oi], wood
Major trade partners: U.K. 30%, U.S. 25%, Commonwealth Caribbean countries
18% (1966)
Monetary conversion rate: 2 East Caribbean Dollars=US$1
11
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $31.3 billion (purchasing power parity estimate, 1970), $1,340 per capita;
real growth rate 1970, 4.9%; 68% private consumption, 12% public consumption,
18% gross domestic investment, 2% net foreign balance (1968)
Agriculture: main products -- cereals, oilseeds, livestock products; Argentina
is a major world exporter of temperate zone foodstuffs
Major industries: food processing (especially meatpacking), motor vehicles,
consumer durables, textiles, chemicals, printing, and metallurgy
Crude steel: 1.69 million metric tons produced (1969); 70 kilograms per capita
Electric power: 6,318,000 kw. capacity (1970); 20.9 billion kw.-hr.
produced (1970); 853 kw.-hr. per capita
Exports: $1,750 million (f.o.b., 1970) -- meat, wheat, corn, wool, hides, oil-
seeds
Imports: $1,550 million (c.i.f., 1970) -- machinery and vehicles, fuel and
lubricating oils, iron and steel, textiles, intermediate industrial products
Major trade partners: exports -- EEC 37%, LAFTA 25%, U.S. 11%, U.K. 8%;
imports -- EEC 24%, LAFTA 24%, U.S. 23%, U.K. 7%
Aid: economic -- extensions from U.S. (FY46-69), $743.2 million in loans;
$16.7 million in grants; from international organizations (FY46-68), $497.2
million; from other Western countries (1960-66). $315.5 million; from
Communist countries (1954-69) $86.0 million (drawn, $41.0 million);
military -- assistance from U.S. (FY46-69), $134.8 million
Monetary conversion rate: 4.04 pesos=US$] ("heavy" peso=100 old pesos,
introduced 1 January 1970) -- “crawling pig" exchange rate system established
April 1971
Fiscal year: calendar year','dc9f17c22f6185f38d556a208e3fcfd17fe753d287b4883fcc1cec5f20a7f6be','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6f2ac4f2abdf2788257dd1e935cdb903d1a360fdc2a1b6a2763addbb13f8210',1971,'DZ','Algeria','economy',13,'GNP: $12.5 billion (1969), $1,690 per capita; 57% consumption, 27% investment,
16% government; 1969 growth rate 6.4% 1954 constant prices
Agriculture: livestock, cereals, potatoes, sugar beets; 84% self-sufficient;
caloric intake 2,920 calories per day per capita (1967-68)
Major industries: foods, iron and steel, machinery, textiles, chemicals,
electrical, paper and pulp
a ar 4.080 million metric tons produced (1970), 551 kilograms per capita
1970
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Electric power: 7,530,000 kw. capacity (1970); 25,793 million kw.-hr produced
(1970) ; 3,460 kw.-hr. per capita
Exports: $2.86 billion (f.o.b., 1970); iron and steel products, machinery and
equipment, Tumber, textiles and clothing, paper products, chemicals
Imports: $3.55 billion (c.i.f., 1970); machinery and equipment, chemicals,
textiles, coal, petroleum, foodstuffs
Major trade partners: (1969) West Germany 33%, Italy 8%, Switzerland 8%,
U.K. 6%, U.S. 4%; EEC 50%; EFTA 22%; Communist countries 14%
Aid:
economic -- received - U.S. $1,166.6 million authorized through FY69, none
since FY64; IBRD $104.9 million authorized, none since FY62;
military -- U.S., $98 million authorized (FY50-64); $0.6 million in FY64;
net official economic aid to less developed areas and multilateral agencies
-- $165 million (FY60-69), $21.3 million in FY69
Monetary conversion rate: 26 shillings=US$1 (official)
Fiscal year: calendar year
GNP: not available
Agriculture: main crops -- fruits, vegetables
Major industries: tourism, cement, lumber, salt production
Electric power: 59,750 kw. capacity (1970); 247.5 million kw.-hr. produced
(1969 est.); 1,095 kw.-hr. per capita
Exports: $46 million (f.o.b., 1969); cement, rum, pulpwood, fruits, and
vegetables
Imports: $251 million (c.i.f., 1969); foodstuffs, manufactured goods, petroleum
Major trade partners: U.S. 67%, U.K. 11%, Canada 7% (1968)
Aid: economic -- authorizations from U.S. (FY56-69) -- $34.8 million in loans
Monetary conversion rate: 1.00 Bahamian dollars (B$)=US$1 (official)
Fiscal year: calendar year
Agriculture: produces dates, alfalfa, vegetables; dairy and poultry farming;
fishing; not self-sufficient in food
Major industries: petroleum refining, boatbuilding, shrimp fishing, and
sailmaking on a small scale; major development projects include aluminum
smelter, flourmill, and ISA town
Electric power: 108,000 kw. capacity (1970); 270 million kw.-hr. produced (1970);
1,250 kw.-hr. per capita
Imports: $109 million (1968)
Major trade partners: U.K., Japan, U.S., EEC
Monetary conversion rate: 1 Bahrain dinar=US$2.10 (official)
Fiscal year: 1 April - 31 March
GDP: $117 million (1969 est.), $460 per capita; real growth rate 1969, 3.3%
Agriculture: main products -- sugar, subsistence foods
Major industries: tourism, sugar milling, manufacturing, edible oils and fats
Electric power: 39,950 kw. capacity (1969, est.); 143.7 million kw.-hr. produced
(1969 est.); 595 kw.-hr. per capita
Exports: $34 million (f.o.b., 1969); sugar, molasses, rum
—. $97 million (c.i.f., 1969); foodstuffs, lumber, machinery, manufactured
goods
Major trade partners: U.K. 33%, U.S. 21%, Commonwealth Caribbean countries 13%,
Canada 11% (1968)
Aid: economic -- extensions from U.S. (FY67-69), $0.1 million in grants; from
international organizations (FY63-69), $0.6 million
Monetary conversion rate: 2.00 East Caribbean Dollars=US$1
Fiscal year: 1 April - 31 March
23
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNI CATIONS:
Railroads: none
Highways: 950 mi.; 800 mi. paved, 100 mi. gravel, 50 mi. improved earth
Inland waterways: none
Ports: 1] major, 2 minor
Civil air: no major transport aircraft
Airfields: 1 with permanent-surface runway 8,000-11,999 ft.; 1 seaplane station
Telecommunications: islandwide automatic telephone system with 26,100
telephones; key international traffic transit center for Caribbean area; .
tropospheric scatter links to Trinidad and St. Lucia; 86,000 radio and
16,000 TV sets, 2 AM and 1 TV stations; 2 telegraph submarine cables; plan
construction of satellite earth station to be operational in two years
DEFENSE FORCES:
Supply: obtained primarily from the U.K.; some ammunition from Belgium
24
IPE SSN RIG EN I TP LE GIES PT ED SE OE WCE A TP EE RC eS
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 5 BELGIUM
LAND:
11,800 sq. mi.3; 53% agricultural land, of which about Feo
.| ‘
Rep GER.
half is in crops, the rest meadows and pastures, 27%
waste, urban, or other; 20% forested (1968) ;
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
GNP: not available
Agriculture: main products -- bananas, vegetables, Easter lilies, dairy products,
citrus fruits
Major industries: tourism, ship repair, small boat building
Electric power: 51,740 kw. capacity (1969); 181.6 million kw.-hr. produced (1969);
3,425 kw.-hr. per capita
Exports: $70.0 million (f.0.b., 1969); mostly reexports of drugs and bunker fuel
Imports: $85.5 million (c.i.f., 1969); fuel, foodstuffs, machinery
Major trade partners: U.S. 46%, U.K. 22%, Canada 9% (1968)
Monetary conversion rate: 1 Bermuda dollar=US$1 (official)
Fiscal year: calendar year
GNP: under $100 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles )
Electric power: 400 kw. capacity
Exports: about $1 million annually; rice, dolomite, and handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic -- India (FY61-68) $35.2 million
Monetary conversion rate: 7.5 Indian rupees=US$1
Fiscal year: 1 April - 31 March
GNP: $1.3 billion (purchasing power parity estimate, 1970), $270 per capita;
79% private consumption, 11% public consumption, 17% gross domestic
investment, -2% net foreign balance (1970); real growth rate 1970, 3%
31
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Agriculture: main crops -- potatoes, corn, rice, sugarcane, yucca, bananas;
imports significant quantities of foodstuffs including lard, vegetable oils,
and wheat; caloric intake, 2,100 calories per day per capita (1966)
Major industries: mining, smelting, petroleum refining, food processing, textiles,
and clothing
Electric power: 281,000 kw. capacity (1970 est.); 710 million kw.-hr. produced
(1970 est.); 154 kw.-hr. per capita
Exports: $182 million (f.0.b., 1969); tin, petroleum, lead, zinc, silver,
tungsten, antimony, bismuth, gold, coffee, and sugar
Imports: $167 million (f.o.b., 1969); foodstuffs, chemicals, capital goods,
pharmaceuticals
Major trade partners: exports -- U.K. 42%, U.S. 37%, Argentina 5%;
imports -- U.S. 43%, West Germany 13%, Japan 11%, Argentina 7% (1968)
Aid: s
economic -- extensions from U.S. (FY46-69) $235.4 million in loans, $293.3 anil
million in grants; from international organizations (FY46-68), $107.2
million; from other Western countries (1960-66), $12.6 million;
military -- assistance from U.S. (FY58-69), $22.4 million
Monetary conversion rate: 11.88 pesos=US$1 (selling rate)
Fiscal year: calendar year
Agriculture: principal crops are corn and sorghum; livestock raised and exported
Major industries: livestock processing, mining of asbestos, manganese
Electric power: 5,000 kw. capacity (1970); 0.3 million kw.-hr. produced (1970);
-5 kw.-hr. per capita
Exports: $10.5 million (f.0.b., 1968); cattle, animal products, minerals
Imports: $29.0 million (f.0.b., 1968); foodstuffs, vehicles, textiles
Major trade partner: South Africa
Monetary conversion rate: 1 SA Rand=US$1.40 (Botswana uses the South African
Rand) (official); 0.714 SA Rand=US$1
Fiscal year: 1 April - 31 March
33
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $42.7 billion (purchasing power parity estimate, 1970), $450 per capita;
17% gross investment, 83% consumption (est. 1970); real growth rate 1970, 9.5%
Agriculture: main products -- coffee, rice, beef, corn, milk, sugarcane, beans;
(ige2) self-sufficient; caloric intake, 2,900 calories per day per capita
1962
Major industries: textiles and other consumer goods, cement, lumber, steel,
motor vehicles, other metalworking industries
Crude steel: 5.5 million metric tons capacity (1970 est.); 5.4 million metric
tons produced (1970); 58 kilograms per capita (1970)
Electric power: 10.3 million kw. capacity (1969); 45.7 billion kw.-hr. produced
(1969 est.); 480 kw.-hr. per capita
Exports: $2,700 million (f.o.b., 1970); coffee, manufactures, iron ore, cotton,
sugar, wood, cocoa f
35
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Imports: $2,300 million (f.o.b., 1970); machinery, chemicals, pharmaceuticals,
petroleum, wheat
Major trade partners: exports -- U.S. 26%, West Germany 102%, Italy 7%, Argentina
7%, Netherlands 6%, Japan 5%, U.K. 4%; imports -- U.S. 30%, West Germany 13%,
Argentina 7%, U.K. 4%, Italy 3% (1969)
Aid: economic -- extensions from U.S. (FY46-69) -- loans $2,915.6 million,
grants $552.7 million; from international organizations (FY46-68) $1,093.6
million; from other Western countries (1960-66) -- $343.6 million; from
Communist countries (1954-69) $335.6 million; drawings $34.0 million
Monetary conversion rate: 5.0 cruzeiros=US$1 (free rate March 71, changes
frequently)
Fiscal year: calendar year
GNP: $46 million (est. 1968), $380 per capita; 78% private consumption, 17%
public consumption, 36% domestic investment, -31% net foreign balance
(1958); real growth rate 1968 4.5% (est.)
Agriculture: main products -- citrus fruits, sugar, corn, rice, beans, livestock
products; net importer of food; caloric intake, 2,500 calories per day
per capita
Major industries: timber and forest products, food processing, furniture, rum,
soap
Electric power: 8,030 kw. capacity (1969 est.); 16 million kw.-hr. produced
(1969 est.); 132 kw.-hr. per capita
Exports: $15.1 million (f.o.b., 1968); sugar, lumber, citrus fruits, fish
Imports: $26.5 million (c.i.f., 1968); vehicles, petroleum, food, textiles,
machinery
37
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major trade partners: exports -- U.K. 32%, U.S. 29%, Mexico 16%, Canada 15%;
imports -- U.S. 33%, U.K. 29% (1967)
Aid: economic -- extensions from U.S. (FY46-70), $5.8 million, grants; from
international organizations (1946-69), $1.1 million
Monetary conversion rate: $BH1.67=US$1 (official)
Fiscal year: calendar year
COMMUNICATIONS: e
Railroads: none
Highways: 1,350 mi.; 150 mi. paved, 600 mi. improved (gravel, earth), 600 mi.
unimproved
Inland waterways: 514 mi. river network used by shallow-draft craft
Ports: 1] major, 4 minor
Civil air: no major transport aircraft
Airfields: 49 total, 34 usable; 2 with permanent-surface runways; 1 with
runway 4,000-7,999 ft.; 1 seaplane station
Telecomnunications: meager but adequate facilities; Belize City center of
2,405 telephone network; over 48,000 radio receivers; 2 AM stations; no
submarine cables
38
i
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 44 BRUNEI
LAND:
2,230 sq. mi.; 3% cultivated; 3% industry, waste, or
urban; 94% forested (1960)
Limits of territorial waters: 3 n. mi.
GNP: $132 million (estimated 1968), $1,200 per capita
Agriculture: main crops -- rubber, rice, sago
Major industry: crude petroleum
Electric power: 54,000 kw. capacity (1969); 130 million kw.-hr. produced (1969);
1,120 kw.-hr. per capita
Exports: $85 million (1969); almost all crude petroleum
Imports: $72 million (1969)
Major trade partners: exports of crude petroleum go to Sarawak for refining
and reexport; 30% imports from U.K., Singapore 16%, Japan 13%
Monetary conversion rate: 3.06 Brunei dollars=US$1
Fiscal year: calendar year
GNP: $11.1 billion, 1970 (at 1970 prices), $1,300 per capita; 1970 growth rate 7.3%
Agriculture: mainly self-sufficient; main crops--grain, vegetables; no food
shortages; caloric intake, 3,000 calories per day per capita (1965/66)
Major industries: agricultural processing, machinery, textiles and clothing, -
mining, ore processing, timber
Shortages: petroleum, some raw materials, metal products
Crude steel: 1.80 million metric tons produced (1970), 210 kg. per capita
4]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Exports: $2,009 million (f.o.b., 1970); in 1970, 29% machinery, equipment, and
transportation equipment; 13% fuels, minerals, raw materials, metals, and
other industrial material; 8% agricultural raw materials; 35% foodstuffs
and animals; 15% industrial consumer goods
Imports: $1,816 million (f.o.b., 1969); in 1969, 41% machinery, equipment, and
transportation equipment; 38% fuels, minerals, raw materials, metals, other
materials; 10% agricultural raw materials; 6% foodstuffs and animals; 5%
industrial consumer goods
Major trade partners: $3,825 million in 1970; 22% with non-Communist countries; =
78% with Communist countries
Monetary conversion rate: (commercial) 1.17 leva, (noncommercial) 1.99 leva=US$1
Fiscal year: calendar year; economic data reported for calendar years except for
caloric intake, which is reported for consumption year 1 July - 30 June
GDP: $2.2 billion (FY69), less than $100 per capita
Agriculture: main crops -- paddy, sugarcane, peanuts; almost 100% self-sufficient;
most rice grown in deltaic land
Major industries: agricultural processing; textiles and footwear, wood and
wood products
Electric power: 253,000 kw. capacity (1969); 580 million kw.-hr. produced (1969);
21 kw.-hr. per capita
Exports: $112 million (f.o.b., 1969); rice, teak
Imports: $180 million (c.i.f., 1969)
Major trade partners: exports -- India, Ceylon, Communist China; imports --
Japan, U.K., U.S. .
Monetary conversion rate: 4.76 kyat=US$1
Fiscal year: 1 October - 30 September
43
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GDP: about $177.8 million (1969), $50 per capita
Agriculture: major cash crops -- coffee, cotton; main food crops -- manioc,
yams, corn, sorghums, bananas, haricot beans; not self-sufficient
Industries: light consumer goods such as beverages, shoes, soap
Electric power: 11,000 kw. capacity (1969); 101,000 kw.-hr. produced (1969);
5 kw.-hr. per capita
Exports: $15.9 million (f.0.b., 1970); coffee, cotton, hides, skins
Imports: official transactions, $15.1 million (c.i.f., 1970); textiles,
foodstuffs, transport equipment, petroleum products
Major trade partners: U.S., Belgium, Congo; much trade unrecorded
Aid: mostly free world; U.S., $100,000 (FY70); other free world (Belgium, EEC,
West Germany) $8.5 million (1969); France $1.7 million (1967); U.N. $2.2
million (1968); EDF $4.1 million (1969)
Monetary conversion rate: 87.5 Burundi francs=US$1 (official)
Fiscal year: calendar year
45
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $634 million (1969), $90 per capita (constant 1966 prices, converted at
55.5 riels=US$1); 1960-69 average growth rate 3.6% (constant 1966 prices)
Agriculture: Mainly subsistence except for rubber plantations; main crops --
rice, rubber, corn; largely self-sufficient;: food shortages -- dairy products,
sugar, flour
Major industries: rice milling, fishing, wood and wood products, textiles
Shortages: fossil fuels
Electric power: 101,000 kw. capacity (1969); 175 million kw.-hr. produced (1969);
26 kw.-hr. per capita
Exports: $37.8 million (1970); rice, rubber, corn
Imports: $37.2 million (1970); metals and metal products, transportation equipment,
food, textiles, petroleum products, minerals
Major trade partners: (1970) exports -- France, Hong Kong, Senegal, 24% with
Communist countries; imports -- Japan, France, U.S., 2% with Communist countries
Monetary conversion rate: 55.5 riels=US$1 (effective 18 August 1969)
Fiscal year: calendar year
47
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GDP: $946 million (1969), per capita about $160
Agriculture: good agricultural potential; commercial and food crops -- cocoa,
livestock, bananas, peanuts, millet, sorghum, yams, palm kernels, rubber,
and timber
Major industries: small aluminum plant; food processing and light consumer goods
industries, sawmills
49
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Electric power: 190,000 kw. capacity (1969); 1,246 million kw.-hr. produced
(1969) ; 220 kw.-hr. per capita
Exports: $219 million (f.o.b., 1969) excluding trade with other members of the
Economic and Customs Union of Central Africa (UDEAC); cocoa and coffee about
53%, other exports include bananas, timber, aluminum, rubber, and cotton;
$3.5 million to Communist countries (1968)
Imports: $191 million (c.i.f., 1969), excluding UDEAC trade; consumer goods,
machinery, transport equipment, alumina (for refining), petroleum products; *
food and beverages; $5.9 million from Communist countries (1965)
Major trade partners: France (about 50%) and other EEC countries; preferential
tariff applied to EEC and franc zone countries; U.S.
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$]
(official) since August 1969 2
Fiscal year: 1 July - 3 June
GDP: $168 million (1967), about $127 per capita
Agriculture: commercial -- cotton, coffee, peanuts, sesame, wood; main food
crops -- manioc, corn, peanuts, rice, potatoes, beef; requires wheat, flour,
#2 rice, beef, and sugar imports
Major industries: sawmills, cotton textile mills, brewery, diamond mining and
splitting
Electric power: 15,100 kw. capacity (1970); 32 million kw.-hr. produced (1970);
20 kw.-hr. per capita
Exports: $38 million (f.o.b., 1969); diamonds (43%), coffee, cotton, lumber
Imports: $44 million (c.i.f., 1969); textiles, petroleum products, machinery
and electrical equipment, motor vehicles and equipment, chemicals and
pharmaceuticals
53
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major trade partner: France; preferential tariff applied to EEC countries and
franc zone; U.S. =
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$1 .
(official)
Fiscal year: calendar year
GNP: $1.8 billion (1969), $140 per capita; real growth rate 4.3% (1970)
Agriculture: agriculture accounts for about 35% of GNP; main crops -- rice, t
rubber, tea, coconuts; 55% self-sufficient in food; food shortages -- rice,
wheat, sugar, fish
Major industries: processing of rubber, tea, and other agricultural commodities;
consumer goods manufacture :
Electric power: 298,000 kw. capacity (1969); 750 million kw.-hr. produced »
(1969) ; 60 kw.-hr. per capita
Exports: $338 million (f.0.b., 1970); tea, rubber, coconut products
Imports: $403 million (c.i.f., 1970)
Major trade partners: (1969) exports -- U.K. 20.2%, China 12.8%, U.S. 8.0%,
Australia 4.2%, South Africa 4.5%, U.S.S.R. 4.8%, West Germany 4.1%, Canada
2.6%; imports -- U.K. 17.4%, China 11.1%, India 8.3%, Australia 4.5%,
U.S.S.R. 2.0%, U.S. 8.4%, Japan 7.4%, Burma 1.2%
Monetary conversion rate: 5.95 rupees=US$1
Fiscal year: 1 October - 30 September
GDP: about $209 million (1967), about $60 per capita; annual growth rate 5.7%
Agriculture: commercial -- cotton, gum arabic, livestock, fish; food crops --
peanuts, millet, sorghum, rice, dates, manioc, wheat; imports food
Major industries: agricultural and livestock processing plants (cotton textile
miil, slaughterhouses, brewery), natron
57
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Electric power: 13,800 kw. capacity (1970); 21 million kw.-hr. produced (1970);
6 kw.-hr. per capita a
Exports: $33.8 million (c.i.f., 1968) including trade with members of the
Economic and Customs Union of Central Africa (UDEAC); cotton 80%, meat, hides
Imports: $50.0 million (c.i.f., 1968) including UDEAC trade; petroleum, textiles,
machinery and motor vehicles; $1.3 million from Communist countries (1967)
Major trade partners: France (about 36%) and UDEAC countries; preferential
tariffs to EEC and franc zone countries
Aid: major source France, FY61-67 $49.1 million; EEC (FY60-67) $28.6 million; +
U.S. (FY62-69) $9.1 million; military aid (1954-68) -- $5.4 million, from *
France $4.1 million, remainder from West Germany and Israel
aa ae St aa rate: 277 Communaute Financiere Africaine francs=US$1
official
Fiscal year: calendar year =
GNP: $8.0 billion (purchasing power parity estimate, 1970), $800 per capita;
73% private consumption, 14% government consumption, 13% gross investment
(1970 est.); real growth rate 1969, 1.0% (est.)
Agriculture: main crops -- wheat, other cereals, potatoes; about 75% self-
sufficient; 2,600 calories per day per capita (1970 est.)
59
a TE aE LE LS EE TT Ee a ES Te A a a I a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
sce it
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 39A CHINA, COMMUNIST
LAND:
3.7 million sq. mi.; 11% cultivated, sown area extended by
multicropping, 78% desert, waste, or urban (32% of
this area consists largely of denuded wasteland,
plains, rolling hills, and basins from which about 3%
Gaol reclaimed), 8% forested; 2%-3% inland water
1970
Limits of territorial waters: 12 n. mi.
GNP: about $120 billion (1970), $145 per capita
Agriculture: main crops -- rice, wheat, miscellaneous grains, cotton; caloric
intake, 2,000 calories per day per capita (1970); agriculture mainly
subsistence; grain imports 4-5 million tons annually (1961-70)
Major industries: iron and steel, coal, machine building, armaments, textiles
Shortages: complex machinery and equipment, highly skilled scientists and
technicians
Crude steel: 17 million tons produced (1970), 20 kilograms per capita (1970)
Exports: $2.15 billion (f.o.b., 1970), agricultural products, minerals and metals,
manufactured goods
Imports: $2.10 billion (c.i.f., 1970), grain, chemical fertilizer, industrial
raw materials, machinery and equipment
Major trade partners: Japan, Hong Kong, West Germany, U.K., Singapore, Malaysia,
Canada, Australia (1970)
Monetary conversion rate: 2.46 yuan=US$1 (arbitrarily established)
Fiscal year: calendar year
COMMUNI CATIONS:
Railroads: about 25,000 mi., of which 370 mi. 3''3 3/8" gage, 30 mi. 3''6" gage,
24,600 mi. 4''8 1/2" gage; mostly single track, less than 1% electrified;
government owned
Highways: 325,000 mi.; 1,000 mi. paved, 74,000 mi. gravel and crushed stone,
80,000 mi. improved earth, and 170,000 mi. unimproved earth, including
tracks
Inland waterways: 105,000 mi.; 25,000 mi. navigable by modern motorized craft
Ports: 2] major, 46 minor
Merchant marine: 290 ships {1,000 GRT or over) totaling 1,600,000 GRT, 2,100,000
DWT, includes 15 passenger, 235 cargo, 40 tanker
Airfields: 303 total; 209 with permanent-surface runways; 4 with runways over
12,000 ft., 60 with runways 8,000-11,999 ft., 207 with runways 4,000-7,999
ft.; 1 seaplane station
62
rane
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
eed peat eae
ie
ot
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 39B CHINA, NATIONALIST
LAND:
14,000 sq. mi. (Taiwan and Pescadores); 24% cultivated,
6% pasture, 55% forested, 15% other (urban, industrial,
denuded','669d133496e57409a6d582ae422f50a8e17a82f5ebecac104f35577399d80865','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be9d0b40fd2f11d32715881d2e92d3bda27b2999d1b385df9c750e934700d760',1971,'DZ','Algeria','economy',14,', water area) (1969)
Limits of territorial waters: 3 n. mi.
GNP: $4.8 billion (1969), $330 per capita; real growth, 9%
Agriculture: most arable land intensely farmed -- 60% cultivated land under
irrigation; main crops -- rice, sweet potatoes, sugarcane, bananas,
pineapples, citrus fruits; 90% self-sufficient; food shortages -- wheat
Major industries: textile manufacturing, chemicals, plywood, electronics, sugar
milling, food processing, cement
63
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Electric power: 2,345,000 kw. capacity (1969); 11.3 billion kw.-hr. produced
(1969); 819 kw.-hr. per capita
Exports: $1,050 million (f.0.b., 1969); textiles 22%, metals and manufactures
25%, canned foods 5%, lumber and plywood 4%, bananas 5%, sugar 4%
Imports: $1,213 million (c.i.f., 1969)
Major trade partners: exports -- 38% U.S., 15% Japan; imports -- 44% Japan,
24% U.S.
Aid: Ps
economic -- U.S. (FY53-69) $1.3 billion committed; IBRD (1964-68) $104
million committed;
military -- U.S. (FY49-70) $3.4 billion committed
Monetary conversion rate: NT$40 (New Taiwan)=US$1
Fiscal year: 1 July - 30 June
GNP: $10.4 billion (purchasing power parity estimate, 1970), $470 per capita;
72% private consumption, 7% public consumption, 21% gross investment (1969);
real growth rate 1970, 7.0%
Agriculture: main crops -- coffee, rice, corn, Sugarcane, plantains, bananas,
cotton, potatoes, yucca; caloric intake, 2,220 calories per day per capita
(1965)
Major industries: textiles, food processing, clothing and footwear, beverages,
chemicals, and metal products ¢
Crude steel: 0.4 million metric tons capacity (1965); 0.21 million metric tons
production (1969), 10 kilograms per capita
Electric power: 1.9 million kw. capacity (1969); 7.3 billion kw.-hr. produced
(1969), 328 kw.-hr. per capita
Exports: $638 million (f.o.b., 1969); coffee, petroleum, bananas, tobacco, »
cotton, sugar, textiles, cattle and hides
Imports: $724 million (c.i.f., 1969); industrial metals and raw materials,
transportation equipment, machinery, fuels, fertilizers, paper and paper
products, wheat
Major trade partners: U.S. 44%, West Germany 11%, other EEC 9%, Latin America
6.4%, Communist countries 4% (1968)
Monetary conversion rate: 19.1 pesos=US$1 (31 December 1970, changes frequently)
Fiscal year: calendar year
GDP: about $228 million (1967 est.), about $260 per capita, real growth rate
about 4% per year
Agriculture: cash crops -- sugarcane, wood, coffee, cocoa, palm kernels, peanuts,
tobacco; food crops -- root crops, rice, corn, bananas, manioc, fish
Major industries: sawmills, brewery, cigarettes, sugar mill, soap
Electric power: 39,000 kw. capacity (1969); 54 million kw.-hr. produced (1969);
60 kw.-hr. per capita
Exports: $60 million (f.o.b., 1968); lumber, sugar, tobacco, veneer, and plywood;
diamonds smuggled from Congo (Kinshasa)
67
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Imports: $86 million (c.i.f., 1968); machinery, transport equipment, manufactured
consumer goods, iron and steel, foodstuffs, petroleum products
Major trade partners: France and other EEC countries on preferential basis
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$]
(official)
Fiscal year: calendar year
GDP: about $1.8 billion (1969 est.), under $100 per capita; real growth rate
7% p.a. 1968-69
Agriculture: main cash crops -- coffee, palm oi1, rubber; main food crops --
manioc, bananas, root crops, corn; some provinces self-sufficient
Major industries: mining, mineral processing, light industries
Electric power: 715,600 kw. capacity (1969); 2,840 million kw.-hr. produced
(1969) ; 174 kw.-hr. per capita
eae $684 million (f.0.b., 1969); copper, diamonds, other minerals, coffee,
palm oil
Imports: $340 million (c.i.f., 1969 prelim.); consumer goods, foodstuffs, mining
and other machinery, transport equipment, fuels
Major trade partners: Belgium, U.S., and West Germany
Aid: economic -- (1969 estimated disbursements) Belgium, $22.5 million; U.S.,
$13.8 million; France, $5.2 million; West Germany, $0.6 million; other
bilateral aid $3 million; U.N., $7.4 million; EEC, $9 million
Monetary conversion rate: 1 zaire=US$2
Fiscal year: calendar year
69
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNI CATIONS :
Railroads: 3,103 mi.; 2,419 mi. 3''6" gage, 78 mi. 3'' 3 3/8" gage, 85 mi.
2'' 0 1/4" gage, 52) mi. 1'' 11 5/8" gage; 421] mi. of 3''6" gage electrified
Highways: 91,500 mi.; 1,400 mi. bituminous, 2,200 mi. gravel or crushed stone,
87,900 mi. earth
Inland waterways: comprising the Congo, its tributaries, and unconnected lakes,
the waterway system affords over 9,329 mi. of navigable routes
Ports: 2 major, 1 minor
Merchant marine: 3 ships (1,000 GRT or over) totaling 28,400 GRT, 34,300 DWT; =
includes 1 passenger, 2 cargo
Pipelines: refined products, 461 mi.
Civil air: 24 major transport aircraft
Airfields: 470 total, 314 usable; 18 with permanent-surface runways; 1 with
runway over 12,000 ft., 2 with runways 8,000-11,999 ft., 53 with runways »
4,000-7,999 ft.; 5 seaplane stations
Teleconmunications: limited, barely adequate telephone service, telegraph service
good; 22,000 telephones; 63,000 radio receivers; 7,100 TV receivers;
12 AM, 1 FM, and 2 TV stations
DEFENSE FORCES:
Supply: dependent on Western sources, principally Belgium and U.S., and to a
lesser extent France, Israel, and Italy
70
SS a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 76 COSTA RICA
19,700 sq. mi.; 30% agricultural land (8% cultivated, 22%
meadows and pasture), 60% forested, 10% waste, urban,
and other (1964)
Limits of territorial waters: 3 n. mi. (fishing 200 n. mi.)
GNP: $870 million (purchasing power parity estimate, 1969), $510 per capita;
14% government consumption, 69% private consumption, 24% domestic investment,
-7% net foreign balance (1969); real growth rate 1970, 8.0%
Agriculture: main products -- bananas, coffee, sugarcane, rice, corn, cocoa,
livestock products; caloric intake, 2,500 calories per day per capita
Major industries: food processing, textiles and clothing, construction
materials, fertilizer
Electric power: 237,000 kw. capacity (1969); 757 million kw.-hr. produced
(1969 est.); 443 kw.-hr. per capita
Exports: $220 million (f.o.b., 1970); coffee, bananas, sugar, beef, fertilizers,
cacao
Imports: $310 million (c.i.f., 1970 est.); manufactured products, machinery,
transportation equipment, chemicals, fuels, foodstuffs
7]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major trade partners: exports -- 48% U.S., 19% CACM, 7% West Germany, 30%
Netherlands; imports -- 37% U.S., 20% CACM, 8% West Germany, 8% Japan (1969)
Aid:
economic -- extensions from U.S. (FY46-69), $101.3 million loans, $88.4
million grants; from international organizations (FY46-69), $94.7 million;
from other Western countries (1960-68), $1.8 million;
military -- assistance from U.S. (FY60-69) $2.5 million
Monetary conversion rate: 6.62 colones=US$1 (official buying rate); 6.65 7
colones=US$1 (official selling rate)
Fiscal year: calendar year
COMMUNI CATIONS:
Railroads: 407 mi.; 395 mi. 3''6" gage, 12 mi. 3''0" gage, all single track, 72 mi. *
electri fied
Highways: 11,700 mi.; 850 mi. paved, 3,200 mi. gravel, 7,650 mi. earth
Inland waterways: about 455 mi. perennially navigable
Pipelines: refined products, 75 mi.
Ports: 3 major, 4 minor
Civil air: 10 major transport aircraft
Airfields: 184 total, 107 usable; 10 with permanent-surface runways; 10 with
runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: domestic telephone service greatly improved with new
automatic exchanges; nearly 56,300 telephones; VHF radio system being
installed; 330,000 radio and 100,000 television receivers in use, 45 AM,
9 FM, and 12 TV stations
DEFENSE FORCES:
Supply: dependent on imports from U.S.
Military budget: for fiscal year ending 31 December 1971, $3.3 million for
Ministry of Public Security, including the Civil Guard; about 2.3% of total
central government budget
72
ae eae teed eR il
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 78 CUBA
D:
44,200 sq. mi.; 26% cultivated, 39% meadow and pasture,
21% waste, urban, or other (1968)
Limits of territorial waters: 3 n. mi.
GDP: $4.5 billion (est. 1970 at 1970 prices), $525 per capita; 60% private
consumption, 19% public consumption, 21% gross investment; real growth
rate 1970, 6%
Agriculture: main crops -- sugar, tobacco, coffee, rice, potatoes, tubers,
citrus fruits
Major industries: sugar milling, petroleum refining, food and tobacco processing,
textiles, chemicals, paper and wood products, metals
Shortages: spare parts for transportation and industrial machinery, consumer goods
Crude steel: 0.35 million metric tons capacity (planned 1969); 165,000 metric
tons produced (1970); 19 kg. per capita
Electric power: 909,000 kw. capacity (1970); 3,787 million kw.-hr. produced
(1970); 475 kw.-hr. per capita ‘
Exports: $970 million (f.o.b., 1970 est.); sugar, nickel, tobacco
Imports: $1,325 million (c.i.f., 1970 est.); petroleum, industrial raw
materials, capital goods, food
Major trade partners: exports -- U.S.S.R. 49%, Communist China 7%, other
Communist countries 15%, Japan 10%, Spain 3%; imports -- U.S.S.R. 54%,
73
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major trade partners (cont''d):
Communist China 6%, other Communist countries 10%, France 5%, Italy 5%
(1970 est.)
Monetary conversion rate: 1 peso=US$1 (nominal)
Fiscal year: calendar year
COMMUNI CATIONS:
Railroads: 9,150 mi. government owned; 3,150 mi. common carrier lines (8 mi.
double track and 95 mi. electrified) and about 6,000 mi. plantation- 4
industrial lines; common carrier lines comprise 3,100 mi. 4''8 1/2" standard
gage, and about 50 mi. 3''0" and 2''6" narrow gage; plantation-industrial
lines comprise about 4,000 mi. standard gage and 2,000 mi. narrow gage
Highways: 11,600 mi.; 4,000 mi. (est.) paved, 2,500 mi. (est.) gravel or
otherwise improved hard surfaces, 5,100 mi. (est.) improved or unimproved *.
earth surface
Inland waterways: 50 mi.
Pipelines: natural gas, 47 mi.
Ports: 8 major, 44 minor; Guantanamo under U.S. control
Merchant marine: 52 ships (1,000 GRT and over) totaling 315,000 GRT, 425,000
DWT; includes 47 cargo, 5 tanker
Airfields: 372 total, 213 usable; 34 with permanent-surface runways; 9 with
runways 8,000-11,999 ft., 33 with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: modern facilities adequately serve military and most civil
needs; excellent international facilities, planned satellite ground station;
est. 263,300 telephones in use; 1.5 million radio and 260,000 TV receivers,
90 AM, 30 FM, and 19 TV stations with nationwide coverage; 6 submarine cables,
including 1 coaxial
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1966, $213 million; about
7.8% of total budget
Qa
+
74
ce TT A I AE a a Ca cate mre oe Ma oS Rh ee oe oa
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 25C CYPRUS
LAND:
3,570 sq. mi.; 47% arable and land under permanent crops,
18% forested, 10% meadows and pasture, 25% waste,
urban areas, and other (1965)
Limits of territorial waters: 12 n. mi. (fishing 12 n. mi.)
TURKEY
s PEOPLE:
Population: 650,000, average annual growth rate 1.6% UNITED
(FY70); males 15-49, 153,000; 108,000 fit for military ARAB
service, about 7,000 reach military age (18) annually =] rerusiic
Ethnic divisions: 78% Greek; 18% Turkish; 4% British,
. Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Armenian Orthodox and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Labor force: 254,000 (1967 est.), 38% agriculture, 23% industry, 9% commerce,
2% mining, 28% other; 3,130 registered unemployed (December 1968)
Organized labor: 24% of labor force
ARABIA
GNP: $504 million (1969), $800 per capita; 1969 growth 11%, 1958 constant prices
Agriculture: main crops -- vine products, citrus, potatoes, other vegetables,
food shortages -- grain, dairy products, meat, fish; caloric intake, 2,590
calories per day per capita (1961)
Major industries: mining (cupreous and iron pyrites, asbestos), manufactures
principally for local consumption -- food, beverages, footwear
Shortages: water, petroleum
Electric power: 190,000 kw. capacity (1970); 553 million kw.-hr. produced (1970);
750 kw.-hr. per capita
Exports: $94.8 million (f.o.b., 1969); principal items -- copper, pyrites, citrus,
raisins, and other agricultural products
Imports: $180.7 million (f.o.b., 1969); principal items -- manufactured goods,
machinery and transport equipment, petroleum products, foods
Major trade partners: (1969) U.K. 34%, West Germany 10%, Italy 9%, EEC 29.4%,
Communist countries 8.3%
Aid: economic -- U.S., $20.3 million authorized (1961-69), none authorized in
1969; IBRD, $18.3 million (1946-68); U.N. Technical Assistance, $1.2 million
(1946-68); U.N. Special Fund, $5.8 million (1946-68); Poland, $1.3 million
authorized (1962)
Monetary conversion rate: 1 Cyprus pound=US$2.40
Fiscal year: calendar year
GNP: $30.9 prion in 1970 (at 1969 prices), $2,130 per capita; 1970 real growth
rate 4.2%
Agriculture: diversified agriculture; main crops -- wheat, rye, potatoes, sugar
beets; net food importer -- meat, wheat, vegetable oils, fresh fruits and
vegetables; caloric intake, 3,100 calories per day per capita (1967)
Major industries: machinery, food processing, metallurgy, textiles, chemicals
Shortages: ores, crude oil, grain
Crude steel: 11.5 million metric tons produced (1970), 750 kg. per capita
77
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
av
ECONOMY (cont''d):
Exports: $3,812 million (f.0.b., 1970 est.); 50% machinery, equipment; 28% fuels,
raw materials; 5% foods, food products, and live animals; 18% consumer goods,
excluding foods (1969) =
Imports: $3,290 million (f.0.b., 1970); 32% machinery, equipment; 44% fuels, raw :
materials; 15% foods, food products, and live animals; 8% consumer goods, 5
excluding foods (1969) x
Major trade partners: $7,522 million (1970); 70% Communist countries, 30% other :
Monetary conversion rate: commercial 7.20 crowns=US$1, noncommercial 14,36 oro
crowns=US$1, tourist rate 16.20 crowns=US$1] i
Fiscal year: calendar year
GDP: $219 million (1970 est.); real growth rate, less than 5% per annum
Agriculture: major cash crop is oil palms; peanuts, cotton, coffee, sheanuts ,
tobacco also produced commercially; main food crops -- corn, cassava, yams,
sorghum and millet; livestock, fish
Major industries: palm oi] and palm kernel oi] processing
Electric power: 7,500 kw. capacity (1970); 22.4 million kw.-hr. produced (1970);
9 kw.-hr. per capita
Exports: about $46 million (f.0.b., 1970); palm products (41%); other
agricultural products
Imports: about $68 million (f.o.b., 1970); clothing and other consumer goods,
cement, lumber, fuels, foodstuffs, machinery, and transport equipment
79
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major trade partners: France, EEC, franc zone; preferential tariffs to EEC and
franc zone countries
Aid:
economic (1970) -- France, $8 million; EEC, $4.2 million; U.N., $2 million;
West Germany, $1 million; Taiwan, $1 million; U.S., $0.9 million
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$1
Fiscal year: calendar year
pica GNP: $14.0 billion (1969), $2,850 per capita; 61.9% consumption, 21.4% invest-
ment, 17.8% government, -1.1% net foreign balance; 1969 growth 7.5%, 1968
constant prices
Agriculture: highly intensive, specializes in dairying and animal husbandry ;
main crops -- cereals, root crops; food shortages -- oi], seeds; caloric
intake, 3,180 calories per day per capita (1968-69)
Major industries: food and food processing, textiles, clothing, footwear, en-
gineering and electrical equipment, transportation equipment, chemicals
Shortages: fuels, basic metals, fertilizers, grains
81
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Crude steel: 482,000 metric tons produced (1969), 100 kg. per capita
Electric power: 4,370,000 kw. capacity (1970); 18,620 million kw.-hr. produced
(1970); 2,500 kw.-hr. per capita
Exports: $3,019 million (f.o.b., 1969); principal items -- meat, dairy products,
fish, machinery and transport equipment, chemicals
Imports: $3,813 million (c.i.f., 1969); principal items -- machinery and trans-
port equipment, petroleum and coal, textile fibers and yarns, iron and steel
products
Major trade partners: U.K. 15.8%, West Germany 16.3%, Sweden 3.6%, U.S. 8.0%,
ia Norway 5.4%; EEC 28.9%; EFTA 44.5%; Communist countries 3.6%
id:
economic -- (received) U.S., $301.8 million authorized 1946-69, none since
1958; IBRD -- $85.0 million through June 1969, none since 1964; net official
economic aid given to less developed areas and multilateral agencies,
$128 million 71960-68) , $54.3 million (1969)
Monetary conversion rate: 7.5 Kroner=US$1
Fiscal year: 1 Apri? - 31 March
GDP: $15.8 million (1968 est.}), $230 per capita; economy is virtually stagnant
in real terms
Agricultural products: bananas, citrus, coconuts, cocoa
Major industries: agricultural processing
Electric power: 3,000 kw. capacity (1969 est.); 9 million kw.-hr. produced
(1969 est.); 120 kw.-hr. per capita
Exports: $7.1 million (f.o.b., 1969); bananas, lime juice and oil, cocoa
Imports: $12.4 million (c.i.f., 1969); foodstuffs, manufactured articles
Major trade partners: U.K. 53%, Commonwealth Caribbean countries 15%, Canada
10%, U.S. 7% (1963)
Monetary conversion rate: 2.00 East Caribbean dollars=US$1
GNP: $1.5 billion (purchasing power parity estimate, 1970), $360 per capita; real
growth rate 1970, 6.5%
Agriculture: main crops -- sugarcane, coffee, cocoa, tobacco, rice, corn; self-
sufficient in rice; caloric intake, 2,200 calories per day per capita (1966)
Major industries: sugar processing, bauxite mining, peanut processing, textiles,
cement
Electric power: 254,000 kw. capacity (1970 est.); 710 million kw.-hr. produced
(1970 est.); 175 kw.-hr. per capita
Exports: $213.5 million (f.o.b., 1970); sugar, coffee, cocoa, tobacco, bauxite
Imports: $306 million (c.i.f., 1970); foodstuffs, petroleum, industrial raw
materials, capital equipment
Major trade partners: exports -- U.S. 89%, Europe 8%; imports -- U.S. 56%,
Europe 25% (1968)
85
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Aid:
economic -- extensions from U.S. (FY46-69), $192.8 million in grants,
$255.0 million in loans; from international organizations (FY46-69),
$56.7 million;
military -- assistance from U.S. (FY53-69), $24.9 million
Monetary conversion rate: 1 peso=US$1 (official)
Fiscal year: calendar year
COMMUNI CATIONS:
Railroads: 1,000 route mi. (3''6" gage) of which 65 mi. government-owned common
carrier and 935 mi. privately owned plantation network (approximately 10
different gages ranging from 1''10 1/2" to 4''8 1/2", with 2''6" predominating)
Highways: 6,000 mi.; 3,000 mi. paved, 800 mi. gravel, 1,400 mi. improved earth,
800 mi. unimproved earth
Ports: 5 major, 17 minor
Merchant marine: 3 cargo ships {1,000 GRT or over) totaling 6,100 GRT, 8,000 DWT
Civil air: 13 major transport aircraft (9 operational)
Airfields: 47 total, 25 usable; 9 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 8 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: relatively efficient domestic system based on islandwide
radio relay network; 40,200 telephones; 400,400 radio and 1,250,000 TV viewers,
92 AM, 24 FM, and 6 TY stations; 2 submarine cables, 1 of which is coaxial
DEFENSE FORCES:
Supply: dependent upon U.S. and Western Europe
Military budget: for fiscal year ending 31 December 1970, $30.4 million; about
14.2% of central government budget
86
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
hy,
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 87 ECUADOR
LAND:
106,000 sq. mi., including Galapagos Islands; 11%
cultivated, 8% meadows and pastures, 55% forested,
26% waste, urban, or other (1961)
Limits of territorial waters: 200 n. mi.
Agriculture: food deficit area; main crops -- potatoes, rye, wheat, barley, oats,
industrial crops; shortages in grain, vegetables, vegetable oil, beef;
caloric intake, 3,000 calories per day per capita (1967-68)
Major industries: metal fabrication, chemicals, light industry, brown coal,
uranium, and shipbuilding
Shortages: coking coal, coke, crude oi], rolled steel products, nonferrous metals
Crude steel: 5.45 million metric tons produced (1970 est.), approx. 320 kg. per
capita
Exports: $4,570 million est. (f.o.b. delivering country, 1970)
Imports: $4,730 million est. (f.o.b. delivering country, 1970)
Major trade partners: $9,300 million (1970); 40% Soviet Union, 32% other
Communist countries, 28% non-Communist countries (est.)
Monetary conversion rate: 4.2 DME=US$1 (unofficial rate actually used in East
German accounting of foreign trade transactions
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for the consumption year
1 duly - 30 June
GDP: $2.3 million (1969) at current prices, about $260 per capita
Agriculture: main crop -- cocoa; other crops include root crops, corn, sorghum
and millet, peanuts; not self-sufficient, but can become so
Major industries: mining, lumbering, light manufacturing, fishing, aluminum
Electric power: 700,000 kw. capacity (1969); 903 million kw.-hr. produced
(1969) ; 105 kw.-hr. per capita
Exports: $348 million (f.0.b., 1969); cocoa (about 70%), wood, gold, diamonds,
manganese, bauxite, and aluminum (aluminum regularly excluded from balance
of payments data)
119
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d): a
Imports: $331 million (c.i.f., 1969); textiles and other manufactured goods, st
food, mineral fuels, machinery, chemicals, transport equipment :
Major trade partners: U.K., EEC, and U.S. a
Monetary conversion rate: 1 new Cedi=US$0.98 (official); 1.02 new Cedi=US$1 a
Fiscal year: 1 July - 30 June
Economic activity in Gibraltar centers on commerce and large British naval and
air bases. Nearly all trade in the well-developed port is transit trade and
port serves also as important supply depot for fuel, water, and ships'' wares.
Recently built dockyards and machine shops provide maintenance and repair
services to 3,500-4,000 vessels that call at Gibraltar each year.
U.K. military establishments and civil government employ nearly half the insured
labor force. Local industry is confined to manufacture of tobacco, roasted
coffee, ice, mineral waters, candy, and canned fish. Some factories for
manufacture of clothing are being developed. A small segment of local
population makes its livelihood by fishing. In recent years tourism has-
increased in importance.
Electric power: 29,170 kw. capacity (1970); 47 million kw.-hr. produced (1970);
1,500 kw.-hr. per capita
121
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A00','85bdd3ce45b70ab351260f5b00ab3cf4a50ef74a8aa8e6529a300db2c1511ace','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1fc72ef6f50cba46d42e7f3b51ebbed9a38c638e545390b45c9429f8578b5af',1971,'DZ','Algeria','economy',15,'0400010001-2
ECONOMY (cont''d):
Exports: $4.0 million (f.o.b., 1968); principally reexports of tobacco,
petroleum, and wine
Imports: $19.8 million (1967)
Major trade partners: U.K., France, Spain, Netherlands, Italy, West Germany
Monetary conversion rate: 1 Gibraltar pound=US$2.40
GNP: $8.4 billion (1969), $940 per capita; 78% consumption, 22% investment;
1969 growth rate 8.5%, 1958 constant prices
Agriculture: subject to droughts; main crops -- wheat, olives, tobacco, cotton;
nearly self-sufficient; food shortages -- livestock products; caloric intake,
2,960 calories per day per capita (1963)
123
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
‘ECONOMY (cont''d):
Major industries: food processing, tobacco, chemicals, textiles, petroleum
refining, aluminum processing
Shortages: petroleum, minerals, feed grains
Crude steel: 210,000 metric tons produced (1965), 20 kg. per capita
Electric power: 2,614,000 kw. capacity (1970); 8,900 million kw.-hr. produced
(1970) ; 780 kw.-hr. per capita
Exports: $612 million (f.0.b., 1970); principal items -- tobacco, cotton, fruits,
metals
Imports: $1,696 million (c.i.f., 1970); principal items -- machinery and
automotive equipment, manufactured consumer goods, petroleum and
petroleum products, chemicals
Major trade partners: (1969) imports -- 42.2% EEC, 14% sterling area, 12% U.S.,
7.3% CEMA countries; exports -- 38.2% EEC, 9.4% sterling area, 18.1% U.S., re
15.8% CEMA countries
Aid:
economic (authorized) -- U.S., $1,883 million (1946-69); International
Finance Corporation, $6.3 million through 1968; U.N. technical assistance,
$3.5 million through 1968; U.N. Special Fund, $6.0 million through 1968;
World Bank, $12.5 million in 1968; Consortium, $40 million in 1966; EEC
(1964-68) $69.2 million;
military -- U.S., $2,018 million (1946-69)
Monetary conversion rate: 30 drachmae=US$1 (official)
Fiscal year: calendar year
GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep grazing; garden produce
Major industries: mining, slaughtering, fishing, sealing
Electric power: 25,000 kw. capacity (1970); 49 million kw.-hr. produced (1970);
580 kw.-hr. per capita
Exports: $13.2 million (f.o.b., 1968); fish and fish products, nonmetallic minerals
Imports: $45.7 million (f.o.b., 1968); machinery and transport equipment,
petroleum and petroleum products, food products
Major trade partners: (1968) Denmark 83.5%, U.S. 7.6%, Venezuela 3.2%
Monetary conversion rate: 7.5 Danish Kroner=US$1
Fiscal year: 1 April - 31 March
GDP: $22.0 million (1967), $220 per capita
Agriculture: main crops -- cocoa, spices, bananas
Electric power: 2,500 kw. capacity (1969); 8.75 million kw.-hr. produced (1969
est.); 82 kw.-hr. per capita
Exports: $5.1 million (f.o.b., 1968); cocoa beans, bananas, nutmeg, mace
Imports: $13.2 million (c.i.f., 1968); textiles, flour, clothing, miscellaneous
manufactured goods
Major trade partners: U.K. 37%, U.S. 9%, Canada 9% (1966)
Monetary conversion rate: 2 West Indies dollars=US$1 (official)
GNP: $2.0 billion (purchasing power parity estimate, 1969), $380 per capita; 80%
private consumption, 8% government consumption, 14% domestic investment, -2%
net foreign balance; real growth rate 1969, 5.5%
Agriculture: main products -- coffee, cotton, corn, beans, sugarcane, bananas,
livestock; caloric intake, 2,200 calories per day per capita (1967)
Major industries: food processing, textiles and clothing, furniture, chemicals,
nonmetallic minerals, metals
Electric power: 230,000 kw. capacity (1970 est.); 730 million kw.-hr. produced
(1970 est.); 137 kw.-hr. per capita
129
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Exports: $304 million (f.0.b., 1969); coffee, cotton, meat, bananas, sugar,
textiles, tires
Imports: $305 million (c.i.f., 1969); manufactured products, machinery, trans-
portation equipment, chemicals, fuels
Major trade partners: exports -- U.S. 28%, CACM 29%, West Germany 10%, Japan
11%; imports -- U.S. 412, CACM 20%, West Germany 10%, U.K. 17% (1968)
Aid:
economic -- extensions from U.S. (FY46-69), $150.3 million loans, $164.1 #
million grants; from international organizations (FY46-69), $108.8 million;
from other western countries (1960-685 $7.6 million;
military -- assistance from U.S. (FY46-69), $16.6 million
Monetary conversion rate: 1 quetzal=US$1 (official)
Fiscal year: calendar year
we GDP: about $275 million (1965), $75 per capita
ail Agriculture: cash crops -- coffee, bananas, palm products, peanuts, and pine-
apples; staple food crops -- cassava, rice, millet, corn, sweet potatoes;
livestock raised in some areas; not self-sufficient, but can become so
Major industries: alumina, light manufacturing and processing industries,
a bauxite
Electric power: 99,700 kw. capacity (1969); 200 million kw.-hr. produced (1969);
50 kw.-hr. per capita
Exports: export receipts, $56 million (FY69-70); alumina, pineapples, bananas,
palm nuts, coffee
Imports: $66 million (FY69-70); petroleum products, metals, machinery and
transport equipment, foodstuffs, textiles
Major trade partners: Western Europe (including France), Communist countries,
U.S.
13]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Monetary conversion rate: 247 Guinea francs=US$1 (provisional)
Fiscal year: 1 October - 30 September
GDP: $269 million (1970), $350 per capita; real growth rate 1970 (est.) 3%
Agriculture: main crops -- sugarcane, rice, other food crops; food shortages --
wheat flour, potatoes, processed meat, dairy products; caloric intake, 2,110
calories per day per capita (1965)
Major industries: bauxite mining, alumina production, sugar and rice milling
Electric power: 112,000 kw. capacity (1970 est.); 448 million kw.-hr. produced
(1970 est.), 578 kw.-hr. per capita
Exports: $133 million (f.o.b., 1970); bauxite, sugar, alumina, rice, shrimp,
timber, diamonds
Imports: $118 million (c.i.f., 1969); machinery, manufactures, food, petroleum
133
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major trade partners: U.K. 28%, U.S. 23%, Canada 14%, Commonwealth Caribbean
countries 13% (1969)
Aid: economic -- extensions from U.S. (1953-69), $41.2 million loans, $19.8
million grants; from international organizations (FY46-69), $18.8 million
Monetary conversion rate: 2 Guyana dollars=US$1
Fiscal year: calendar year
GDP: about one-half billion U.S. dollars (purchasing power parity estimate,
1969), $100 per capita; economy has been stagnant in recent years, but some
growth probably occurred in 1969-70
Agriculture: main crops -- coffee, sugarcane, rice, corn, sorghum, pulses;
caloric intake, 1,850 calories per day per capita
Major industries: sugar refining, textiles, flour milling, cement manufacturing,
copper and bauxite mining, tourism
Electric power: 30,000 kw. capacity (1970 est.); 78 million kw.-hr. produced
(1969 est.); 16 kw.-hr. per capita
Exports: $36.6 million (f.o.b., 1969); coffee, bauxite, light industrial
products, sisal, sugar, copper
135
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Imports: $42.0 million (f.o.b., 1969); wheat, fish, vegetable oils, textiles,
petroleum products, industrial equipment, medical supplies, construction
materials
Major trade partners: U.S. 59%, EEC 15%, Japan 6% (1967 est.)
Aid:
economic -- extensions from U.S., $34.0 million loans, $80.4 million grants
(FY46-69); international organizations, $20.6 million (FY46-69); ,
military -- U.S., $4.3 million (FY53-63) :
Monetary conversion rate: 5 gourdes=US$1 (official)
Fiscal year: 1 October - 30 September
GNP: $800 million (purchasing power parity estimate, 1969), $310 per capita; 77%
private consumption, 9% government consumption, 19% domestic investment, -5%
net foreign balance; real growth rate 1969, 4.2%
Agriculture: main crops -- bananas, coffee, corn, beans, cotton, sugarcane,
tobacco; caloric intake, 2,300 calories per day per capita (1964-65)
Major industries: agricultural processing, textiles, clothing, wood products
Electric power: 113,000 kw. capacity (1969 est.); 380 million kw.-hr. produced
(1969 est.); 150 kw.-hr. per capita
Exports: $177 million (f.o.b., est. 1970); bananas, coffee, corn, cotton, lumber,
minerals, beef
137
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Imports: $222 million (c.i.f., est. 1970); manufactured products, machinery,
transportation equipment, chemicals, fuels
Major trade partners: exports -- U.S. 43%, West Germany 18%, CACM 16%; imports
-- U.S. 45%, CACM 26%, West Germany 4% (1968 est.)
Aid:
economic -- extensions from U.S. (FY46-69), $60.8 million loans, $50.5
million grants; from international organizations (FY46-68), $118.5 million;
from other Western countries (1960-68), $5.3 million; oe a ee
military -- assistance from U.S. (FY46-69), $7.7 million
Monetary conversion rate: 2 lempiras=US$1 (official)
Fiscal year: calendar year
COMMUNICATIONS: ts
Railroads: 743 mi.; 443 mi. of 3''6" gage, 300 mi. of 3‘0" gage -
Highways: 3,000 mi.; 520 mi. paved, 1,240 mi. gravel, 520 mi. improved earth,
720 mi. unimproved earth
Inland waterways: 750 mi. navigable by smal]? craft
Ports: 3 major, 9 minor
Merchant marine: 14 ships (1,000 GRT or over) totaling 62,000 GRT, 61,000 DWT;
includes 14 cargo; all foreign owned and operated
Civil air: 23 major transport aircraft
Airfields: 212 total, 136 usable; 4 with permanent-surface runways; 9 with run-
ways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: improved, but stil] inadequate for all requirements; instal-
Yation of radio relay system completed; over 12,500 telephones; 300,000
radio and 21,000 TV receivers; 58 AM, 5 FM, and 6 TV stations
DEFENSE FORCES:
Supply: traditional dependence on U.S. has for the time being shifted to
Western Europe
Military budget: for fiscal year ending 31 December 1971, $11,400,000; about
9% of central government budget (includes the armed forces and the Special
Security Carnes
138
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 39€ HONG KONG
LAND:
400 sq. mi.; 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country) (1970)
Limits of territorial waters: 3 n. mi.
GNP: $3 billion 1969, $750 per capita
Agriculture: agriculture occupies a minor position in the economy; main crops --
rice, vegetables, dairy products; less than 20% self-sufficient; food
shortages -- rice, wheat
Major industries: textiles and clothing, tourism, plastics, electronics, light
metal products, food processing
Shortages: industrial raw materials, water, food
Electric power: 1,367,500 kw. capacity (1969); 4 billion kw.-hr. produced
(1969); 1,095 kw.-hr. per capita
139
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Exports: $2.2 billion (f.o.b., 1969); including 442 million reexports; principal
products clothing, plastic articles, textiles, electrical goods, wigs,
footwear, light metal manufactures
Imports: $2.5 billion (c.i.f., 1969)
Major trade partners: 1969 exports -- U.S. 35%, U.K. 12%, Japan 6%, West
Germany 6%; imports -- Japan 23%, China 18%, U.S. 13%, U.K. 8%
Monetary conversion rate: HK$6.06=US$1
Fiscal year: 1 April - 33 March ’
GNP: $15.0 billion in 1970 (at 1969 prices), $1,450 per capita; 1970 growth
rate 2.4%
Agriculture: normally self-sufficient; main crops -- corn, wheat, potatoes,
sugar beets, wine grapes; caloric intake 3,100 calories per day
per capita (1966/67)
Major industries: mining, metallurgy, engineering industries, processed foods,
textiles, chemicals (especially pharmaceuticals)
Shortages: metallic ores (except bauxite), copper, high grade coal, forest
products
Crude steel: 3.11 million metric tons produced (1970), about 300 kg. per capita
141
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Exports: $2,317 million (f.o.b., 1970); 25% machinery, 28% industrial consumer
goods, 25% raw materials and semimanufactures, 22% food and raw materials
for the food industry (distribution for 1967)
Imports: $2,505 million (1970); 24% machinery, 8% industrial consumer goods,
57% raw materials and semimanufactures, 11% food and raw materials for the
food industry (distribution for 1967)
Trade: $4,822 million (1970); 65% with Communist countries, 35% with non-
Communist countries ~
Monetary conversion rate: 11.74 forints=US$1 (arbitrary commercial); 30
forints=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data reported for calendar years
GNP: $383. million (1969), $1,859 per capita; 65.4% consumption, 33.8%
investment, 10.8% government, -10% net foreign balance (1968); 1968 growth
rate -5.0%, 1960 constant prices
Agriculture: potatoes, turnips, animals, dairy products, hay; food shortages
-- grains, sugar, vegetable and other fibers; caloric intake, 2,900 calories
per day per capita (1964-66)
Major industries: fish processing
Shortages: grain, fuel, wood, minerals, vegetable fibers .
Electric power: 320,000 kw. capacity (1970); 1,351 million kw.-hr. produced
(1970); 3,800 kw.-hr. per capita
143
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Exports: $107.6 million (f.o.b., 1969); fish and fish products, animal oils and
fats, aluminum a
Imports: $123.4 million (c.i.f., 1969); machinery and transportation equipment,
petroleum, foodstuffs, textiles
Major trade partners: (1969) EFTA 36.7%, EEC 21.9%, U.K. 13.3%, U.S. 17.5%, West
Germany 13.0%, U.S.S.R. 8.4%, Communist countries 11.9%
Aid: economic -- U.S. authorized (1946-68) $87.2 million, $2.0 million 3
(1968); IBRD $25.9 million through June 1968, none in 1968, $1.6 million in =~
1969, authorized $4.1 million loan in 1970
Monetary conversion rate: 88 kronur=US$1 (official)
Fiscal year: calendar year
GNP: $44 billion est. (year ending 31 March 1970), less than $100 per capita; real
average annual growth (1 April 1966 - 31 March 1970), 3.5%
Agriculture: main crops -- rice, other cereals, pulses, oilseeds,
cotton, jute, sugarcane, tobacco, tea, and coffee; 95% self-sufficient in
food grains; shortages -- rice, wheat; caloric intake, roughly 2,000 calories
per capita per day, of which some 1,500 calories or 15 oz. is from cereals
and pulses :
Major industries: textiles, food processing yo’
Crude steel: 6.2 million metric tons produced (1969)
Electric power: 15,135,000 kw. capacity (1969); 54 billion kw.-hr. produced
(1969); 100 kw.-hr. per capita
Exports: $1.9 billion (f.o.b., FY69); tea, jute manufactures, iron ore, cotton
textiles, leather and leather products, iron and steel
Imports: $2.1 billion (c.i.f., FY69); machinery and transport equipment, grains
and flour
Major trade partners: U.S., U.K., U.S.S.R. and Eastern Europe, Japan
Monetary conversion rate: 7.5 rupees=US$1
Fiscal year: 1 April, stated year - 3] March
I
GNP: $9 billion (1969), less than $100 per capita; real average annual growth
(1960-68), 2.5%
Agriculture: subsistence food production, and smallholder and plantation
production for export; main crops -- rice, rubber, copra, other tropical
products; substantially self-sufficient; food shortage -- rice
Major industries: processing agricultural products and petroleum, textiles,
cement, mining
Electric power: 960,000 kw. capacity (1969); 2.35 billion kw.-hr. produced (1969);
20 kw.-hr. per capita
Exports: $975 million (f.o.b., 1969); petroleum, rubber, tin, copra, tea, coffee,
tobacco, palm oil
Imports: $961 million (f.o.b., 1969); rice, other foodstuffs, textiles, chemicals,
iron and steel products, machinery , transport equipment, consumer durables
Major trade partners: exports (1967) -- 27% U.S., 15% Japan, 10% U.K., 4%
Communist countries; imports -- 18% U.S., 17% Japan, 10% West Germany , 7%
Communist countries
Monetary conversion rate: multiple exchange rate system; major import rate
378 rupiah=US$1, major export rate 340 rupiah=US$1
Fiscal year: 1 April - 31 March
GNP: $9,770 million (1970 est.), $335 per capita; real GNP growth, FY69-70, 9% est.
Agriculture: dates, fruit, nuts, vegetables, grains, sugar beets, cotton, gum,
rice, sheep, and goats
Electric power: 2,842,000 kw. capacity (1970); 12 billion kw.-hr. produced
(1970) ; 410 kw.-hr. per capita
Exports: $2,099 million (f.0.b., 1969); 88% petroleum; also carpets, raw cotton,
fresh and dried fruits, hide and leather items, ores; Communist countries
(primarily U.S.S.R.) took about 4.4% of total exports
Imports: $1,384 million {(c.4.f., 1969); machinery, iron and steel products,
chemicals, pharmaceuticals, electrical equipment; Communist countries
supplied 8.3% of commodity imports
Major trade partners: exports -- U.K., Japan, U.S., South Africa, U.S.S.R. and ee
other Communist countries; imports -- West Germany, U.S., U.S.S.R., U.K., Pee
Japan, Italy, France, Netherlands * Hie:
Monetary conversion rate: 75.75 rials=US$1
Fiscal year: 21 March - 20 March
a“ GNP: $2,693 million in 1969, $286 per capita
“ Agriculture: dates, wheat, barley, rice, livestock; largely self-sufficient
in food
Major industry: crude petroleum (fourth largest producer in Middle East)
‘ Electric power: 740,000 kw. capacity (1970); 2 billion kw.-hr. produced (1970);
210 kw.-hr. per capita
Exports: $1,045 million (f.0.b., 1969); $973 million oi] exports
Imports: $410 million (c.i.f., 1969); 21% from Communist countries (1968)
Major trade partners: exports (non oil) -- U.S. 4%, Western European countries 3%,
Communist countries 21%, Arab countries 52%, other 20%; imports -- U.S. 4%,
Western European countries 43%, Japan 8%, Communist countries 23%, Arab
countries 8%, other 14%
151
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d): ii
Monetary conversion rate: 1 Iraqi dinar=US$2.80 (freely convertible); 0.357 if
Iraqi dinar=US$1
Fiscal year: 1 April - 31 March
GNP: $3,473 million (1969), $1,180 per capita; 67.3% consumption, 24.2%
investment, 13.2% government; -4.8% net export of goods and services;
1970 real growth rate 1.4% est., 1958 constant prices
e Agriculture: about 2/3 of agricultural area used for permanent hay and pasture;
main products -- livestock and dairy products, barley, potatoes, sugar beets,
wheat; 85% self-sufficient; food shortages -- grains, fruits, vegetables;
caloric intake 3,450 calories per day per capita (1968)
Major industries: food products, brewing, textiles and clothing, machinery and
transportation equipment
Shortages: coal, petroleum, timber and woodpulp, steel and nonferrous metals,
fertilizers, cereals and animal feeds, textile fibers and textiles
Crude steel: 67,000 metric tons produced in 1968, 20 kilograms per capita
153
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Electric poner 1,500,000 kw. capacity (1970); 5,652 million kw.-hr. produced
(1970); 1,555 kw.-hr. per capita
_ Exports: $1,090 million (f.o.b., 1970); live animals, meat, textile products,
clothing, machinery, dairy products, chemicals
Imports: $1,480 million (f.o.b., 1970 est.); machinery, chemicals, textiles,
transportation equipment, petroleum, metal manufactures, cereals
Major trade partners: 14% EEC, 6% West Germany, 62% EFTA, 58% U.K., 10% U.S.,
1% Communist countries (1969)
Aid: economic -- U.S., $193 million authorized (FY46-69), no activity (FY55-66),
$46.5 million authorized (FY67-69), $14.7 million
authorized in FY69; IBRD $14.5 million authorized (FY69) Le
Monetary conversion rate: 1 Irish pound=US$2.40 (official)
Fiscal year: 1 April - 31 March «3
GDP: $1.3 billion (1968), $300 per capita (1968); average annual growth
rate 1960-68, about 7% a year
Agriculture: commercial -- coffee, cocoa, timber, bananas, pineapples, fish,
palm oi1; food crops -- cassava, plaintain, yams, rice, peanuts, sorghum,
corn; largely self-sufficient, but some rice and meat imported
Major industries: diamond and manganese mining, wood and food processing, light
consumer goods industries; 12,000 b/d oil refinery, auto assembly plant
Electric power: 144,000 kw. capacity (1969); 540 million kw.-hr. produced (1969);
128 kw.-hr. per capita
Exports: $427 million (f.0.b., 1969; converted at exchange rate prevailing since
August 1969) tropical woods, coffee, cocoa 78% of total; bananas,
pineapples, palm kernels
161
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Imports: $312 million (c.i.f., 1969); textiles and other consumer goods,
machinery, transport equipment, petroleum products, rice, wheat, dairy
products
Major trade partners: U.S.; France and other EEC countries (about 65%); $6.5
million to Communist countries, $3.0 million from Communist countries (1968);
preferential tariffs and quotas favor EEC
Aid:
economic -- France (1960-69) $218 million; EEC (1962-69) $82.8 million;
U.S. (1962-69) about $71.2 million; *
military -- non-Communist countries, $7.3 million (1954-67)
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$1
(official) since August 1969
Fiscal year: calendar year
GNP: $1,063.8 million (1969), $550 per capita; real growth rate 1969, 3%
Agriculture: main crops -- sugarcane, citrus fruits, bananas, pimento, coconuts,
coffee, cocoa
Major industries: bauxite, textiles, food processing, light manufactures, tourism
163
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Electric power: 550,000 kw. capacity (1970 est.); 1,270 million kw.-hr. produced
(1969); 650 kw.-hr. per capita
Exports: $336 million (f.o.b., 1970); bauxite, alumina, sugar, rum, bananas,
citrus fruits and fruit products, cocoa
Imports: $480 million (c.i.f., 1970); food, machinery, fuels, transportation
and electrical equipment, fertilizer
Major trade partners: exports -- U.S. 38%, U.K. 19%, Canada 17%, Norway 9%;
imports -- U.S. 42%, U.K. 21%, Canada 9% (1969)
Aid:
economic -- extensions from U.S. (FY56-69), $37.4 million in loans; (AID
$10.7 million, Import-Export Bank $26.7 million), $36.3 million grants (AID
technical assistance $12.5 million, Food for Freedom $23.8 million); from
international organizations (FY46-69), $52.3 million; from other Western
countries (1960-68), $35.4 million;
military -- assistance from U.S. (FY63-69), $1.1 million
Monetary conversion rate: 1 Jamaican dollar=US$1.20
Fiscal year: 1 April - 31 March
GNP: $567 million (1968), $270 per capita
Agriculture: main crops -- cereals, fruits, vegetables, olive oi]; not self-
sufficient in many foodstuffs
Major industries: phosphate mining, petroleum refining, and cement
Electric power: 61,800 kw. capacity (1970); 140 million kw.-hr. produced (1970);
60 kw.-hr. per capita
Exports: $35 million (f.o.b., 1970); major items -- fruits and vegetables,
phosphate rock; Communist share less than 3% of total (1969)
Imports: $180 million (c.i.f., 1969); major items -- petroleum products, textiles,
capital goods, motor vehicles, foodstuffs; Communist share 13% of total (1969)
Aid:
economic -- U.S., $590 million economic assistance (FY51-69), of which $23
million loans, $567 million grants;
military -- $150 million total from U.S. (July 1949-September 1970) including -
$53 million in MAP grants
Monetary conversion rate: 1 Jordanian d','ba3afcf0f1b0de5e058aeb1dfc682e142846fd963ff78a4f40ae2c4f7e437c8b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b330b44148cccd29b6ba58c91bb4b75f22b0ae615b41095d22abfef96322054',1971,'DZ','Algeria','economy',16,'inar=US$2.80, freely convertible; 0.357
Jordanian dinar=US$1
Fiscal year: 1 January - 31 December
GNP: $1.33 billion (1969), $120 per capita; 6.3% real growth per year between
1964 and 1969
Agriculture: main cash crops -- coffee, sisal, tea, pyrethrum, cotton, livestock;
food crops -- corn, wheat, rice, cassava; largely self-sufficient in food
Major industries: small-scale consumer goods (plastic, furniture, batteries,
ela soap, agricultural processing, cigarettes, flour), oi] refining,
cemen
Electric power: 153,000 kw. capacity (1969); 402 million kw.-hr. produced (1969);
38 kw.-hr. per capita
Exports: $250.2 million (f.0.b., 1969); coffee, tea, livestock products, pyrethrum,
soda ash, wattle-bark tanning extract
Imports: $338.6 million (c.i.f., 1969); machinery, transport equipment, crude oil,
paper and paper products, iron and steel products, and textiles
169
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major trade partners: U.K. and Common Market countries, also Uganda and
Tanzania, which are part of East African Economic Community
Monetary conversion rate: ] Kenya shilling=US$0.14 (official); 7.143 Kenya
shillings=US$1
Fiscal year: 1 July - 30 June
Agriculture: main crops -- rice, corn, vegetables; food shortages -- meat,
cooking oils; production of foodstuffs adequate for domestic needs at low
levels of consumption
Major industries: machine building, electric power, chemicals, mining, metallurgy,
textiles
matte heavy machinery and equipment, bituminous and coking coal, petroleum,
rubber
Crude steel: 2.2 million metric tons produced (1970), about 150 kilograms
per capita
Exports: minerals, chemical and metallurgical products
Imports: machinery and equipment, petroleum, foodstuffs, coking coal
Major trade partners: total trade turnover about $640 million 71970); 19% with
non-Communist countries, 81% with Communist countries (50% with the U.S.S.R.)
Monetary conversion rate: 2.57 won=US$1 (noncommercial), 1.20 won=US$1 (commercial)
Fiscal year: calendar year
GNP: $7.0 billion (1969), $220 per capita; real growth 15%
Agriculture: 50% of the population live on the land, but agriculture constitutes
27% GNP; main crops -- rice, barley, wheat; not self-sufficient; food
shortages -- barley, wheat, dairy products, rice, corn
Major industries: textiles and clothing, food processing, chemical fertilizers,
chemicals, plywood, coal
Shortages: base metals, fertilizer, petroleum, lumber and certain food grains
Electric power: 1,794,000 kw. capacity (1968); 8.1 billion kw.-hr. produced
(1969); 260 kw.-hr. per capita °
Exports: $.6 billion (f.o.b., 1969); cotton and synthetic clothing and textiles,
veneer and plywood, silk, wigs, fish
Imports: $1.8 billion (c.i.f., 1969)
Major trade partners: 1969 exports -- U.S. 50.1%, Japan 21.4%; imports -- Japan
41.3%, U.S. 29.1% 4
Aid:
economic -- U.S. (FY46-70), $5.1 billion committed; Japan (1965-70), $580
million extended,
military -- U.S. (FY46-70), $3.6 billion committed
Monetary conversion rate: 290 won=US$1 (floating-rate average value in 1969),
312 won=US$1 by end of July 1970
Fiscal year: calendar year
Agriculture: virtually none, dependent on imports for food; approx. 75% of
potable water must be distilled or imported
Major industries: crude petroleum production averaging 2.99 million b.p.d.
(includes Kuwait''s share of neutral zone) (1970); government revenues from
taxes and royalties on production, refining, and consumption was $850 million
in FY69; refinery capacity est. at 504,000 bbls. per day (1970); other major
industries include fishing, processing of building materials, fertilizers,
chemicals, and flour
Electric power: 838,000 kw. capacity (1970); 1,670 million kw.-hr. produced
(1970); 2,140 kw.-hr. per capita
Exports: $1.6 billion (1968), of which petroleum accounted for 98%; nonpetroleum
exports are mostly reexports and totaled $58 million (1969)
Imports: $646 million (1969); major suppliers -- U.S., Japan, U.K., West Germany
Aid: $50 million loan from Export-Import Bank, 1967; extended about $50 million
in credits to other Arab nations from 196] to January 1969
Monetary conversion rate: 1 Kuwaiti dinar=US$2.80 (freely convertible)
Fiscal year: 1 April - 31 March
175
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $202’ million (1968 est.), $70 per capita
Agriculture: main crops -- rice (overwhelmingly dominant), corn, coffee, cotton
and tobacco; largely self-sufficient; food shortages (due in part to
distribution deficiencies) including rice
Major industries: tin mining, timber
177
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Shortages: capital equipment, petroleum, transportation system
Electric power: 25,000 kw. capacity (1969); 29 million kw.-hr. produced (1969);
11 kw.-hr. per capita
Exports: $2.0 million (f.o.b., 1969); forest products, coffee, tin concentrates,
and timber; undeclared exports of opium significant but value unknown
Imports: $51.4 million (c.i.f., 1969); rice, petroleum products, textiles,
transportation equipment, machinery
Major trade partners: imports from Thailand, U.S., Japan, France, Hong Kong,
U.K., Indonesia, and West Germany; exports to Malaysia and Thailand; trade
with Communist countries insignificant; Laos a major transit point in world
gold trade; gold imports and approx. offsetting gold exports excluded from
official trade data; value of 1969 gold imports $36.7 million
Monetary conversion rate: 240 kip=US$1; open market rate approx. 505 kip=US$1
(1969); all but restricted list of developmental commodities now imported
at open market rate
Fiscal year: 1 July - 30 June
Agriculture: fruits, wheat, corn, barley, potatoes, tobacco, olives, onions; not
self-sufficient in food
Major industries: service industries, food processing, textiles, cement, oil
refining, chemicals, some metal fabricating, tourism
Electric power: 664,100 kw. capacity (1970); 1,394 million kw.-hr. produced
(1970); 500 kw.-hr. per capita
179
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major trade partners: exports $179 million (f.o.b., 1969 est.); 67% to Arab
countries and only 4.5% to Communist countries; imports $643 million (c.i.f.,
1969 est.); chiefly from EEC, U.K., and Arab countries; 8.4% from Communist
countries; trade deficit covered by large net receipts from invisibles
(particularly tourism and transportation) and private capital inflow
Monetary conversion rate: 3.08 Lebanese pounds=US$1 (provisional parity); free
market (January 1971) 3.24 Lebanese pounds=US$1
Fiscal year: calendar year
GNP: $90 million (1968), about $100 per capita
Agriculture: exceedingly primitive, mostly subsistence farming and livestock;
principal crops are corn, wheat, pulses, sorghum, barley
Major industries: none
Electric power: 2,820 kw. capacity (1969); 2.5 million kw.-hr. produced (1969);
3 kw.-hr. per capita
Exports: labor to South Africa (remittances $15 million in 1969); $5 million
(f.o.b., 1968), wool, mohair, wheat, cattle, diamonds, peas, beans, corn,
hides, skins
18]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Imports: $29 million (f.o.b., 1968); mainly corn, building materials, clothing,
vehicles, machinery, POL
Major trade partner: South Africa
Aid: economic aid $17 million (1968) -- U.K. $10 million (1969-70); others $9
million (1968); no military aid
Monetary conversion rate: 1 SA Rand=US$1 =
Fiscal year: 1 April - 31 March es
GDP: $387 million (1969), 6% growth rate approx., $330 per capita
Agriculture: rubber, oi] palm, cassava, coffee, rice; imports of rice, wheat,
and meat are necessary for basic diet :
183
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont ‘d):
Industry: rubber processing, food processing, construction materials, furniture,
palm oil processing, mining {iron ore, diamonds), 10,000 b/d oil refinery
Electric power: 152,000 kw. capacity (1970); 540 million kw.-hr. produced (1970);
470 kw.-hr. per capita
Exports: $196 million (f.0.b., 1969); iron ore, diamonds, rubber, palm kernels,
coffee, cocoa
Imports: $115 million (c.i.f., 1969); machinery, transportation equipment,
foodstuffs, manufactured goods _—
Major trade partners: U.S., Netherlands, U.K,, West Germany —_
Aid:
economic -- (1962-69) U.S., $152.1 million;
military -- (1962-68) U.S., $5.7 million (other aid sources include IBRD,
U.N., IMF, and West Germany) >
Monetary conversion rate: Liberia uses U.S. currency
Fiscal year: calendar year
GNP: $2.96 billion (1969 prelim.), $1,530 per capita
GDP: $3.6 billion (1969 prelim.), $1,900 per capita
Agriculture: main crops -- wheat, barley, olives, dates, citrus fruits, peanuts;
not self-sufficient in food
Major industries: petroleum production averaged 3.3 million b.p.d. (1970);
estimated oi] revenues for FY71 about $1.5 billion; food processing,
textiles, handicrafts
Electric power: 146,600 kw. capacity (1969); 430 million kw.-hr. produced (1969);
230 kw.-hr. per capita
Exports: $2,160 million (1969); 99% petroleum
Imports: $676 million (1969)
Major trade partners: imports -- Italy 23%, U.S. 19%; exports -- Italy 23%,
West Germany 22% (1969)
185
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Aid: no Communist country assistance; U.S. aid extended $201.7 million economic
aid (1946-69), $34.5 million military aid (1958-69)
Monetary conversion rate: 1 Libyan pound=US$2.80
Fiscal year: 1] April - 3) March
Despite its small size and sparse natural resources, Liechtenstein has a
prosperous economy based primarily on small-scale light industry and farming.
Textiles, ceramics, precision instruments, pharmaceuticals, and canned foods
are the principal manufactures produced, almost entirely for export. Live-
stock raising and dairying are the main sources of farm income; cereals and
potatoes are the most important farm crops. The Liechtenstein economy is
tied closely to that of Switzerland in a virtual customs union. No national
accounts data are available.
pk BaRtiierss exports (1967) -- $45.5 million; 41% Switzerland, 28% EEC,
~1% EFT
Electric power: 22,600 kw. capacity (1970); 55 million kw.-hr. produced (1970);
1,800 kw.-hr. per capita; power is exchanged with Switzerland, but net
exports average 35 million kw. yearly
COMMUNI CATIONS:
Railroads: 9.94 mi. 4''8 1/2" gage; owned, operated, and included in statistics
of Austrian Federal Railways
Highways: no information on total mileage
Inland waterways: none
Ports: none
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system serving about 9,500 telephones;
no broadcast facilities; 4,000 radio and 3,400 TV receivers (programed from
Switzerland)
DEFENSE FORCES:
Defense is responsibility of Switzerland
187
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 6 LUXEMBOURG
LAND:
1,000 sq. mi.; 26% arable, 26% meadows and pasture, 16% = ee
waste or urban, 32% forested, negligible amount of ; age re
inland water (1969)
GNP: $995.7 million (1970), $2,930 per capita; 56.4% consumption, 29.8% investment,
11.0% government, 2.8% net exports of goods and services, 1970 growth rate
3.5% at 1963 constant prices
Agriculture: mixed farming; main crops -- grains, potatoes, fodder beets; food
shortages -- sugar, bread grains, fats; caloric intake, 3,090 calories per
day per capita (1967-68 est.)
Major industries: iron and steel, food processing, chemicals, metal products and
engineering, tires i
Shortages: crude petroleum, coal, textile materials
Crude steel: 5.5 million metric tons produced (1969), about 16,320 kg. per capita
Electric power: 1,177,000 kw. capacity (1970); 2,520 million kw.-hr. produced
(1970); 6,450 kw.-hr. per capita
Exports: $869.0 million (f.o.b., 1970)
Imports: $686.4 million (c.i.f., 1970)
Major trade partners: Luxembourg and Belgium form an economic and customs union L
and report their foreign trade jointly (see Belgium); Luxembourg''s principal
exports are iron and steel products; principal imports are coal and consumer
products; most foreign trade is with Germany, Belgium, and other Common
Market countries; about 7% of steel exports to the U.S. (1969)
Aid: foreign aid to Luxembourg is included in aid to Belgium
Monetary conversion rate: 50 Luxembourg francs=US$1 (official); under the BLEU
agreement, the Luxembourg franc is equal to the Belgian franc which circulates
freely in Luxembourg
Fiscal year: calendar year
Agriculture: main crops -- rice, vegetables; food shortages -- rice, vegetables,
meat; depends mostly on imports for food requirements
Major industries: textiles, fireworks
Electric power: 14,000 kw. capacity (1969); 30.6 million kw.-hr. produced (1969);
110 kw.-hr. per capita
Exports: $28 million (f.0.b., 1968); textiles and clothing, foodstuffs, fireworks
Imports: $50 million (f.o.b., 1968)
Major trade partners: exports -- Hong Kong 24%, West Germany 21%; imports --
Hong Kong 67%, Communist China 30% (1968)
Monetary conversion rate: 6.06 patacas=US$1
Fiscal year: calendar year
19]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $794.2 million (1969), about $120 per capita; a real increase of 8.9% between
1968 and 1969, almost all due to price increases because of franc devaluation
Agriculture: cash crops -- coffee, vanilla, sugar, tobacco, sisal, rice, cloves,
raphia; food crops -- rice, cassava, cereals, potatoes, corn, beans,
bananas, coconuts, and peanuts; animal husbandry widespread; self-
sufficient in foodstuffs, but some milk and cereals imported
Major industries: agricultural processing (meat canneries, soap factories,
brewery, tanneries, sugar refining), light consumer goods industries
(textiles, glassware), cement plant, auto assembly plant, paper mill, oi1 r
refinery
Electric power: 14,600 kw. capacity (1970); 200 million kw.-hr. produced (1970);
30 kw.-hr. per capita
Exports: $104.9 million (f.o.b., 1969); coffee 28%, rice 8%, vanilla 10%, sugar
7%, petroleum products 4%, sisal 3%; mineral products, graphite and mica 3%; ra
agricultural and livestock products account for about 85% of export earnings a
Imports: $145.0 million (f.o0.b., 1969); consumer goods 46% -- food, beverages,
textiles, clothing; capital equipment 26% -- machinery, appliances, and
electrical; raw materials 28% -- cement, energy. products, fertilizers
(percent figures for 1969)
Major trade partners: France (in 1969 accounted for 36% of exports and 52% of
imports); U.S., preferential tariffs to EEC and franc zone countries; trade
with Communist countries remains a minute part of total trade
Monetary conversion rate: 278 Malagasy francs=US$1 (official); member of
French franc zone
Fiscal year: calendar year
GDP: $282 million (1969), $60 per capita; average annual growth rate in constant
prices 6.1% (1969)
Agriculture: cash crops -- tea, tobacco, peanuts, cotton, tung; subsistence
vA crops -- corn, sorghum, millet, pulses, root crops, fruit, vegetables, rice
we Electric power: 38,200 kw. capacity (1970); 133 million kw.-hr. produced (1970);
30 kw.-hr. per capita
Major industries: agricultural processing (tea, tobacco, sugar), sawmilling,
-# cement, consumer goods
Exports: $52.8 million (f.o.b., 1969); tea, tobacco, cotton, tung, peanuts
Imports: $73.7 million (f.o.b., 1969); manufactured goods, machinery and transport
equipment, food, fuels
Major trade partners: exports -- U.K., Zambia, Rhodesia, U.S.; imports -- U.K.,
Rhodesia, South Africa
Aid:
economic -- U.K. provides both budgetary and development support, about
$20 million cumulative through (1970); U.S. aid commitments, $18 million
through FY70;
195
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
military -- U.K., $0.9 million (1954-68)
Monetary conversion rate: 1 Malawi pound=US$2.40 (official)
Fiscal year: 1 April - 31 March
COMMUNI CATIONS:
Railroads: 355 mi. (3''6" gage)
Highways: 6,610 mi.; 430 mi. paved; 555 mi. crushed stone, gravel, or stabilized
soil; 5,625 mi. earth Ps
Inland waterways: Lake Malawi, 800 route mi. and Shire River, 90 mi. aot
Ports: 2 minor
Civil air: 4 major transport aircraft
Airfields: 34 total, 32 usable; 1 with permanent-surface runway; 7 with
runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: the system is barely above average for African countries rd
and consists of thinly spread open-wire lines, radio-relay links, and
radiocommunication stations; principal centers are Blantyre and Zomba;
11,500 telephones; 106,000 radio receivers; 5 AM, 4 FM and no TV stations
DEFENSE FORCES: =
Supply: dependent on U.K. c
Military budget: for fiscal year ending 31 December 1969, $1,426,000; 1.7% of
total budget
196
mii a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 44 MALAYSIA
NOTE:
Malaysia, which came into being on 16 September 1963,
consists of West Malaysia, which includes 11 states
of the former Federation of Malaya, plus East
Malaysia, which includes the 2 former colonies of
North Borneo (renamed Sabah) and Sarawak
Limits of territorial waters: 12 n. mi.
LAND:
West Malaysia: 50,700 sq. mi.; 20% cultivated, 26%
forest reserves, 54% other (1965)
Sabah: 29,400 sq. mi.; 13% cultivated, 34% forest
reserves, 53% other (1966)
Sarawak: 48,300 sq. mi.; 21% cultivated, 24% forest reserves, 55% other (1966)
GNP:
Malaysia: $3.7 billion (1969), $346 per capita; average annual real growth
(1966-69) 6%
Agriculture:
West Malaysia: mixed plantation and subsistence; main crops -- rubber, rice,
oi] palm; 25% of rice requirements imported
Sabah: mainly subsistence; main crops -- rubber, coconut, rice; food deficit
-- rice
Sarawak: main crops -- rubber, pepper; food deficit -- rice
Major industries:
West Malaysia: rubber and oi] palm processing and manufacturing, tin mining
and smelting, logging and processing timber, light consumer goods
Sabah: logging
Sarawak: agriculture processing, petroleum refining, logging
Electric power:
West Malaysia: 938,000 kw. capacity (1969); 3.1 billion kw.-hr. produced
(1969); 338 kw.-hr. per capita
Sabah: 30,000 kw. capacity (1969); 85 million kw.-hr. produced (1969); 133
kw.-hr. per capita
Sarawak: 44,000 kw. capacity (1969); 98 million kw.-hr. produced (1969);
99 kw.-hr. per capita
Exports: $1,653 million (f.o.b., 1969); 40% rubber, 18.4% tin, 15.3% timber
Imports: $1,134 million (f.o.b., 1969)
Major trade partners: exports -- Singapore, Japan, U.S.; imports -- Japan, U.S.,
Singapore, Communist China
199
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Monetary conversion rate:
Malaysia: 3.06 Malaysian dollars=US$1
Fiscal year: calendar year
GNP: under $100 per capita
Agriculture: crops -- coconut and millet; shortages -- rice, wheat
Major industries: fishing; some coconut processing
Electric power: 2,500 kw. capacity (1969); 7 million kw.-hr. produced (1969);
65 kw.-hr. per capita
Exports: $2.5 million (f.o.b., 1967); fish
Imports: $2.5 million (c.i.f., 1967)
Major trade partner: Ceylon
Aid: U.K. (1960-65), $1.4 million drawn; Ceylon (1967), $1 million committed
Monetary conversion rate: 4.76 rupees=US$1
Fiscal year: calendar year
GNP: about $245 million (FY69), per capita about $50
Agriculture: main crops -- millet, sorghum, rice, corn, peanuts; cash crops --
peanuts, cotton, livestock
Major industries: small local consumer goods and processing
Electric power: 22,500 kw. capacity (1970); 38 million kw.-hr. produced (1970);
7 kw.-hr. per capita
Epon $23.3 million (f.0.b., 1969); livestock, peanuts, dried fish, cotton,
skins
Imports: $38.3 million (c.i.f., 1969); textiles, vehicles, petroleum products,
machinery, and sugar
Major trade partners: mostly with franc zone, Communist China, and U.S.S.R.
203
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Monetary conversion rate: since August 1969, 555.4 Mali francs=US$1
Fiscal year: 1 July - 30 June
GNP: $139.4 million (1968 constant prices), $580 per capita; 68.9% private
al consumption, 16.7% public consumption, 29.5% gross investment; 1968 growth
Z. rate 10% in constant prices
a : Agriculture: overall, 20% self-sufficient; adequate supplies of vegetables, poultry,
milk and pork products; shortages in beef, grain, animal fodder, and fruits
at various seasons; main products -- potatoes, cauliflowers, grapes, wheat,
2 barley, tomatoes, citrus, cut flowers, green peppers, hogs, poultry, eggs
a Major industries: ship repair yard, building industry, food manufacturing,
textiles, tourism
Shortages: most consumer and industrial needs (fuels and raw materials) must be
imported
Electric power: 85,000 kw. capacity (1970); 276 million kw.-hr. produced (1970);
570 kw.-hr. per capita
Exports: $38.2 million (1969); textiles, scrap metal, wine, agricultural
products, and footwear
205
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Imports: $147.6 million (1969)
Major trade partners: U.K. 44%, Italy 15.7%; EFTA 48%; EEC 28.2%; Communist
countries 2.5%; North and Central America 3.8%
Aid: economic -- U.S., $8.2 million (1949-69), of which $1.2 million authorized
in 1966, $0.3 million authorized in 1968, $1.7 million authorized 1969;
U.K. Financial Agreement (loans and grants) 1964-74, $140 million; IBRD $8.2
million through 1968, none since 1965; U.N. Special Fund $2.1 million through
1968, none in 1968; U.N. Technical Assistance $0.9 million through 1968, of
which $0.2 million in 1968
Monetary conversion rate: 1 Maltese Pound=US$2.40 (official)
Fiscal year: 1 April - 31 March
GDP: about $170 million (1968), about $150 per capita; average annual rate of
growth (real terms, 1962-66) 9%
Agriculture: most Mauritanians are nomads or subsistence farmers; main crops
~- livestock, small grains, dates; cash crops -- livestock, gum arabic
Major industries: mining of iron ore, salt fishing, exploitation of copper
resources planned
Electric power: 20,200 kw. capacity (1970); 38 million kw.-hr. produced (1970);
32 kw.-hr. per capita
Exports: $71 million (f.o.b., 1967); iron ore, fish, gum arabic
Imports: $25 million (c.i.f., 1967); sugar, cloth, tea, and fuels
Major trade partners: (trade figures not complete because Mauritania has a form
of customs union with Senegal and much local trade unreported) France and
other EEC members, U.K., and U.S. are main overseas partners
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year
207
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: est. $158 million (1969), approximately $200 per capita
Agriculture: sugar crop is major economic asset; about 40% of land area is planted
to sugar; tea production rising Slowly; most food imported -- rice is the
staple food -- and since cultivation is already intense and expansion of
cultivable areas is unlikely, heavy reliance on food imports except sugar
and tea will continue
Shortage: land
Industries: mainly confined to processing sugarcane, tea; some small-scale,
simple manufactures; tobacco fiber; some fishing; tourism
Electric','d4158ca8049052c9ebd35d0986d09b85529eed5001207e8898895d01f37eef4c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77a3bc9cc897d7fea2e30bcbee4752313cd4d05cfdeed079b43c5076cd84f055',1971,'DZ','Algeria','economy',17,'power: 61,340 kw. capacity (1970); 134 million kw.-hr. produced (1970);
160 kw.-hr. per capita
Exports: $66.1 million (f.o.b., 1969); 33% foodstuffs (rice, wheat, flour,
meat, fruit); manufactured goods, machinery, chemicals, fuels
Imports: $59.2 million (1969); foodstuffs 40%, manufactured goods 18%
Major trade partners: U.K. has preferential treatment, buys over 50% of Mauritius!
sugar export at heavily subsidized prices; smal] amount of Sugar exported to
Canada, U.S., and Italy; imports from U.K. and EEC primarily, also from South
Africa, Australia, and Burma; some minor trade with Communist China
Aid: U.K. financed 40% of 1960-66 development programs with loans and grants
totaling $33 million; U.K.''s Sugar subsidies amount to approx. $30 million
annually; U.S. $6 million since 1967 (P.L. 480); Soviet Union made some
small-scale offers in 1969
Monetary conversion rate: 5.55 Mauritian rupees=US$]
Fiscal year: 1 July - 30 June
GNP: 55% tourism; 25%-30% industry (small and primarily tourist oriented); 10%-15%
registration fees and sales of postage stamps; about 4% traceable to the Monte
Carlo casino
Major industries: chemicals, food processing, precision instruments, glassmaking,
printing
Electric power: 8,000 kw. capacity (1970); 60 million kw.-hr. supplied by France
(1970) ; 2,250 kw.-hr. per capita
Trade: full customs integration with France, which collects and rebates Monacan
trade duties
Monetary conversion rate: 5.55419 francs=US$1
Agriculture: self-sufficient in animal products; main crops -- wheat, oats,
barley
Industries: processing of animal products and building materials; mining
Exports: animal and dairy products, fluorspar, woolen textiles, leather shoes ,
glass, and paper
Imports: machinery and equipment, petroleum, cloth, coal, and building materials,
sugar, and tea
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 4 tugriks=US$1 (arbitrarily established)
Fiscal year: calendar year
215
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $6,350 million, $655 per capita (1970 est.); 72.9% consumption, 17.7%
investment, 14.1% government, -4.7% net exports of goods and services (1970),
growth rate 6.6% (1970) in 1963 constant prices
Agriculture: generally underdeveloped; main crops -- grains, potatoes, olives,
grapes for wine; food shortages -- sugar, wheat; caloric intake, 2,930
calories per day per capita 11968)
Major industries: cotton textiles, cork processing, fish canning, petroleum *
refining, pulp and paper, chemical fertilizer
Shortages: coal, petroleum, cotton, steel
Crude steel: 386,000 metric tons produced (1969), 40 kg. per capita (1969)
Electric power: 2,700,000 kw. capacity (1970); 7,183 million kw.-hr. produced
(1970); 650 kw.-hr. per capita
Exports: $822.6 million (1969); principal items -- cotton textiles, cork and cork
products, canned fish, wine, timber and timber products, resin
Imports: $1,231 million (c.i.f., 1969); principal items -- petroleum, cotton,
industrial machinery, iron and steel, chemicals
Major trade partners: (1969) 16.7% U.K., 12.1% West Germany, 6.4% France, 6.7%
U.S., 12.3% Angola, 6.4% Mozambique; 27.9% EEC; 28.8% EFTA; 1.3% Communist
countries
Aid:
economic -- U.S., $207.1 million (1946-69), $7.0 million authorized 1968,
$4.8 million authorized 1969; IBRD, $57.5 million authorized (1964-66), none
since 1966; net official aid to less developed areas and multilateral agencies
$34.8 million (1968), $97.7 million (1969);
military -- U.S., $325 million authorized (1946-69), $7.5 million authorized
in 1965, $2.7 million authorized in 1968
Monetary conversion rate: 28.75 escudos=US$1 (official)
Fiscal year: calendar year
Agriculture: main crops -- palm oil, root crops, rice, coconuts, peanuts
Electric power: 1,200 kw. capacity (1970); 2 million kw.-hr. produced (1970);
4 kw.-hr. per capita
Exports: $3.2 million (f.0.b., 1967); principally peanuts, coconuts
Imports: $16.4 million (c.i.f., 1967); manufactured goods, fuels, transport
equipment, rice
Major trade partners: mostly Portugal, also immediate neighbors
Aid: Portugal, smal] amounts
Monetary conversion rate: 28.75 escudos=US$1 (official)
Fiscal year: probably is the calendar year
261
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $28.7 billion; $870 per capita (1969); 68.5% consumption, 24.3% investment,
10.4% government; -3.2% net export of goods and services (1969); 1970 (est.)
real growth rate 6.1%, in 1964 constant prices
Agriculture: main crops -- cereals, oranges, grapes for wine, potatoes, olives,
sugar beets; virtually self-sufficient in good crop years; caloric intake,
2,680 (1968-69) calories per day per capita
Major industries: food processing, textiles and apparel (including footwear),
metal manufacturing, chemicals, shipbuilding
Shortages: crude petroleum
Crude steel: 7.3 million metric tons produced, 218 kilograms per capita (1970 est.)
17,906 ,000 kw. capacity (1970); 56,397 million kw.-hr. produced (1970),
1,400 kw.-hr. per capita
Exports: $2,473 million (f.o.b., 1970 est.); principal items -- oranges and other
fruits, iron and steel products, textiles, wines, mercury, ships, canned
fruits, vegetables
Imports: $4,367 million (f.o.b., 1970 est.); principal items -- machinery and
transportation equipment, petroleum and petroleum products, grains, cotton,
iron and steel
Major trade partners: (1969) 16.6% U.S., 12.6% West Germany, 9.6% France,
8.0% U.K., 5.7% Italy, 3.2% Netherlands; 33.4% EEC; 16.0% EFTA; 11.4% Latin
America; 2.2% Communist countries
Aid:
economic -- U.S., $1,602.8 million authorized (FY46-49), $8.6 million
authorized (FY68), $54.8 million authorized (FY69); IBRD, $225 million
authorized (FY64-70), $37 million authorized (FY70);
military -- U.S., $625.3 million authorized (FY46-69), $15.0 million
authorized in FY69
Monetary conversion rate: 70 pesetas=US$1 (official)
Fiscal year: calendar year
Agriculture: practically none; some barley is grown in nondrought years; fruit
and vegetables in the few oases; food imports are essential; camels, sheep,
and goats are kept by the nomadic natives; cash economy exists largely for
the garrison forces
Major industries: confined to fishing and handicrafts; exploitation of huge
phosphate deposit is planned
Shortages: water
Electric power: 300 kw. capacity (1970); 0.2 million kw.-hr. produced (1970);
3 kw.-hr. per capita
Exports: $445,600 (1968); dried fish, goatskins
Imports: $1,443,000 (1968); fuel for fishing fleet, foodstuffs
Major trade partners: monetary trade largely with Spain and Spanish possessions
Aid: small amounts from Spain
Monetary conversion rate: 70 pesetas=US$1 (official)
GDP: $1.4 billion (1968 provisional), under $100 per capita; 7% growth at
current prices 1967-68
Agriculture: main crops -- sorghum, millet, wheat, sesame, peanuts, beans,
barley; not self-sufficient in food production; main cash crops -- cotton,
gum arabic
Major industries: cotton ginning, textiles, brewery, cement, edible oils, soap,
distilling, shoes, pharmaceuticals
Electric power: 132,000 kw. capacity (1970); 303 million kw.-hr. produced (1969);
19 kw.-hr. per capita
309
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Exports: $287 million (f.o.b., FY70); cotton (64%), gum arabic, peanuts,
sesame; $64.7 million exports to bloc (FY70)
Imports: $268 million (c.i.f., FY70); textiles, petroleum products, vehicles,
tea, wheat; $22.2 million imports from bloc (1968)
Major trade partners: U.K., West Germany, Italy, India, U.S.S.R.
Monetary conversion rate: 1 Sudanese pound=US $2.87 (official); 0.348 Sudanese
pound=US$1
Fiscal year: 1 July - 30 June -
GNP: $218 million (1968 est.); $580 per capita; real growth rate 1968, about 6%
Agriculture: main crops -- rice, sugarcane, bananas; self-sufficient in major
_ staple (rice); caloric intake 2,500 calories per day per capita (1962)
Major industries: bauxite mining, alumina and aluminum production, lumbering,
food processing
311
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Electric power: 220,000 kw. capacity (1969); 660 million kw.-hr. production
(1969) ; 1,650 kw.-hr. per capita
Exports: $113 million (f.o.b., 1968); bauxite, alumina, wood and wood products,
rice
Imports: $99 million (c.i.f., 1968); capital equipment, petroleum, iron and
steel, cotton, flour, meat, dairy products
Major trade partners: exports -- U.S. 74%, Canada 9%, Netherlands 7%; imports
~~ U.S. 47%, Netherlands 20%, Europe 16% (1966)
Aid: economic -- extensions from U.S. (FY54-69), $6.0 million loans, $4.7 million
grants; from international organizations (FY49-69), $32.3 million
Monetary conversion rate: 1.89 Surinam guilders (S. f1.)=US$1 (official)
Fiscal year: calendar year
GDP: approx million (1968), about $190 per capita; real growth rate about
8% (1967
Agriculture: main crops -- sugar, rice, and citrus fruits
Major industry: mining
Electric power: 59,000 kw. capacity (1970); 204 million kw.-hr. produced (1970);
500 kw.-hr. per capita
Exports: $62 million (f.0.b., 1969); iron ore, asbestos, sugar, wood and forest
products, citrus, meat products, cotton
313
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Imports: $53 million (f.o.b., 1969); food products, manufactured goods, machinery,
fertilizer, fuel
Major trade partners: Japan, U.K., South Africa
Aid: economic aid -- U.K. $4.2 million (1969-70), others approximately $2 million;
no military aid
Monetary conversion rate: 1 South African Rand=US$1.40 (Swaziland uses the South
African Rand) (official); 0.714 SA Rand=US$1
Fiscal year: 1 April - 31 March
GNP: $28.5 billion, $3,532 per capita (1969); 51.6% consumption, 32.1% investment,
17.0% government; -0.7% net exports of goods and services (1968); 1969 growth
rate 5.0%, in 1959 constant prices
Agriculture: animal husbandry predominates with milk and dairy products
accounting for 40% of farm income; main crops -- grains, sugar beets,
potatoes; 90% self-sufficient; food shortages -- oils and fats, tropical
products; caloric intake, 2,880 calories per day per capita (1967-68)
Major industries: iron and Steel, precision equipment (bearings, radio and
telephone parts, armaments), shipbuilding, wood pulp and paper products,
processed foods, textiles, chemicals
315
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Shortages: coal, petroleum, textile fibers, potash, salt
Crude steel: 5.3 million metric tons produced (1969), 670 kilograms per capita
Electric power: 15 million kw. capacity (1970); 60,612 million kw.-hr. produced
(1970); 7,000 kw.-hr. per capita
Exports: $5,688 million (f.o.b., 1969); nonelectric machinery, motor vehicles
and ships, wood pulp, paper products, jron and steel] products, metal ores
and scrap
Imports: $5,899 million (c.i.f., 1969); machinery, motor vehicles, petroleum and
petroleum products, textile yarn and fabrics, iron and steel
Major trade partners: (1969) West Germany 15.4%, U.K. 13.4%, U.S. 7.4%, Norway
9.8%, Denmark 8.8%; EFTA 40%; EEC 31.0%; Communist countries 5.4%
Rid: economic -- U.S., $189.6 million authorized through June 1968; net official
aid to less developed countries and multilateral agencies, $315.6 million
(1960-68), $71.4 million in 1968, $120.8 million in 1969
Monetary conversion rate: 5.173 kronor=US$1 (official)
Fiscal year: 1 July - 30 June
GNP: $20.1 billion (1970), $3,190 per capita; 57% consumption, 29% investment,
12% government, net foreign balance 2% (1970); 1970 growth rate 4.4%, 1958
constant prices
Agriculture: dairy farming predominates; less than 50% self-sufficient; food
shortages -- fish, refined sugar, fats and oils (other than butter), grains,
eggs, fruits, vegetables, meat; caloric intake, 2,990 calories per day per
capita (1967-68 est.)
317
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major industries: machinery, chemicals, watches, textiles, precision instruments
Shortages: practically all important raw materials except hydroelectric energy
Crude steel: 453,000 metric tons produced (1969), 73 kg. per capita
Electric power: 9,965,000 kw. capacity (1970); 35,245 million kw.-hr. produced
(1970); 4,220 kw.-hr. per capita
Exports: $5.1 billion (f.o.b., 1970); principal items -- machinery and equip-
ment, chemicals, precision instruments, textiles, foodstuffs
Imports: $6.5 billion (c.i.f., 1970); principal items -- machinery and trans-
portation equipment, metals and metal products, foodstuffs, chemicals,
textile fibers and yarns
Major trade partners: West Germany 23%, France 10%, U.S. 9%, Austria 5%, Italy
9%, U.K. 8%; EEC 49%; EFTA 20%; Communist countries 3% (1970)
Aid: some disbursed; none received
Monetary conversion rate: 4.328 Swiss francs=US$1
Fiscal year: calendar year
Agriculture: main crops -- cotton, wheat, and barley; sheep and goat raising;
self-sufficient in food in years of average weather
Major industries: textiles, cement, glass, petroleum (80,000 bpd. production,
refining capacity 54,000 bbIs. per day, 1970) food processing, soap
Electric power: 350,000 kw. capacity (1970); 900 million kw.-hr. produced
(1970 70) 3 210 kw.-hr. per capita
Exports : $206. 8 million (1969); 50% cotton, grain and wool in good years,
lives tock
Imports: $369.6 million (c.i.f., 1969); metal products, textiles, machinery, sugar
319
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Monetary conversion rate: 3.82 Syrian pounds=US$1 (controlled rate); 4.20 Syrian
pounds=US$1 (free rate) (1970, October)
Fiscal year: calendar year
Mainiand:
GDP: $1,058 million at 1966 prices (1969), about $80 per capita; growth rate in
constant 1966 prices for 1969 3.1%
Agriculture: main crops -- cotton, coffee, sisal on mainland; largely self-
sufficient in food
321
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major industries: primarily agricultural processing (sugar, beer, cigarettes,
sisal twine), diamond mine, oi] refinery, shoes, cement
Electric power: 93,500 kw. capacity (1970); 360 million kw.-hr. produced (1970);
24 kw.-hr. per capita
Exports: $256 million (f.o.b., 1969); coffee, cotton, sisal, cashew nuts, meat,
diamonds, cloves, coconut products
Imports: $244 million (c.i.f., 1969); manufactured goods, machinery and transport
equipment, cotton piece goods, crude oi1, foodstuffs ney for Zanzibar);
Zanzibar accounted for $6.8 million of total imports (1968)
Major trade partners: exports -- Communist countries $11.7 million, Zanzibar
$14 million (cloves and coconut products); imports -- Communist countries
$25.3 million (1968)
Monetary conversion rate: 1 Tanzanian shilling=US$0.14; 7.143 Tanzanian
shillings=US$1
Fiscal year: 1 July - 30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops -- cloves, coconuts
Industries: agricultural processing
Electric power: see Tanganyika (above)
Exports: $12.6 million (1968); cloves and clove products, coconut products
Imports: $5.6 million (1968); mainly foodstuffs and consumer goods
Major trade partners: imports -- Communist China, Japan, and mainland Tanzania;
exports -- Singapore, Communist China, Hong Kong, U.K.
Aid: U.K. principal source of aid until 1964; Communist China and East Germany
extended through June 1968 -- $25 million
Exchange rate: 1 Tanzanian shilling=US$0.14; 7.143 Tanzanian shillings=US$1
Fiscal year: 1] July - 30 June
GDP: $6.3 billion (1969 est. in current prices), $175 per capita; estimated 11%
real growth in 1969
Agriculture: world''s second largest rice exporter; main crops -- rice, rubber,
corn; almost 100% self-sufficient in food
Major industries: agricultural processing, textiles, wood and wood products,
cement, tin mining; non-Communist world''s third largest tin producer
Shortages: fuel sources, including coal and petroleum
Electric power: 1,287,000 kw. capacity (1970) : 3.9 billion kw.-hr. produced
(1970); 109 kw.-hr. per capita
Exports: $711 million (f.o.b., 1970); rice, rubber, corn, tin, cassava, kenaf
* Imports: $1,275 million (c.i.f., 1970); excluding U.S. military imports;
machinery and transport equipment, textiles, fuels and lubricants, base
metals, chemicals
Major trade partners: exports -- Japan, U.S., Singapore, Hong Kong, Netherlands,
Malaysia; imports -- Japan, U.S., West Germany, U.K.; about 1% or less trade
with Communist countries
Monetary conversion rate: 20.8 baht=US$1
Fiscal year: 1 October - 30 September
323
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
COMMUNI CATIONS:
Railroads: 2,379 mi. meter gage; 60 mi. double track
Highways: 12,590 mi.; 5,440 mi. paved, 4,820 mi. crushed stone or gravel, 2,330
earth and laterite
Inland waterways: 2,485 mi. principal waterways; 2,300 mi. with navigable depths
of 3 ft. or more throughout the year; numerous minor waterways navigable by
Shallow-draft native craft
Ports: 2 major, 16 minor
Merchant marine: 17 ships (1,000 GRT or over) totaling 63,300 GRT, 94,800 DWT;
includes 10 cargo, 7 tanker a
Airfields: 195 total, 162 usable; 39 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 2] with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: service to general public being improved, but still inadequate;
bulk of service to government activities provided by numerous radiocommunica- a
tion stations and radio-relay network; satellite ground station connects to i
Intelsat II and will connect to Indian Ocean satellite; 134,663 telephones; ‘A
2,775,000 radios; 222,000 televisions; estimated 50 AM, 5 FM, and 6 TV
stations in two government-controlled networks; U.S. military submarine
cable to South Vietnam
DEFENSE FORCES:
Military budget: for fiscal year ending 30 September 1971, $335,400,000; 26% of
total budget
seems mee
324
a a TN Tacs a TSC ns Crane er ee a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50N TOGO
LAND:
22,000 sq. mi.; nearly half total is arable, under 15%
cultivated (1970)
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
GDP: $233 million (1969), about $130 per capita
Agriculture: main cash crops -- coffee, cocoa; major food crops -- yams, cassava,
corn, beans, rice, fish; must import some foodstuffs
Major industries: phosphate mining, agricultural processing, handicrafts,
textiles, beverages
Electric power: 11,900 kw. capacity (1970); 38 million kw.-hr. produced (1970);
20 kw.-hr. per capita
Exports: $41.4 million (f.0.b., 1969); phosphates, cocoa, coffee, palm
kernels, and cassava
Imports: $52.6 million (c.i.f., 1969); textiles and other consumer goods,
fuels, machinery, tobacco, foodstuffs
Major trade partners: mostly with France and other EEC countries
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year
325
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Agriculture: largely dominated by coconut production with subsistence crops of
taro, yams, sweet potatoes, manioc, and bread fruit
Electric power: 900 kw. capacity (1970); 2.6 million kw.-hr. produced (1970);
18 kw.-hr. per capita
Exports: $3.8 million (f.0.b., 1969); copra and bananas
Imports: $5.7 million (c.i.f., 1969)
Major trade partners: Australia, New Zealand, Netherlands, Japan, U.K.
Monetary conversion rate: 0.893 Tonga dollar=US$1
GDP: $837.5 million (1969 est.), $790 per capita; real growth rate 1968, 3.7% est.
Agriculture: main crops -- sugarcane, cocoa, coffee, rice, citrus, bananas;
largely dependent upon imports of food
Major industries: petroleum, tourism, food processing, cement
329
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Electric power: 285,000 kw. capacity (1969); 1.21 billion kw.-hr. produced (1969);
1,170 kw.-hr. per capita
Exports: $475 million (f.o.b., 1969 est.); petroleum and petroleum products,
sugar, cocoa
Imports: $482 million (c.i.f., 1969 est.); crude petroleum, machinery,
transportation equipment, manufactured goods, food
Major trade partners: exports -- U.S. 47%, U.K. 10%, CARIFTA 9%; imports --
LAFTA 39%, U.S. 15%, U.K. 14% (1969)
Aid: economic -- extensions from U.S. (FY56-69) $22.7 million loans, $40.4 -
million grants; from international organizations (FY53-69), $56.5 million
Monetary conversion rate: TT$2=US$1
Fiscal year: calendar year
Agriculture: food imported, but some dates, alfalfa, vegetables, fruit, tobacco
raised
Major industries: fishing, trading, oi] production; oi] production began in Abu
Dhabi in 1962, and in 1970: reached 694,000 bbis. per day; oil revenues
accruing to Abu Dhabi estimated $200 million in 1970; Dubai has best port
and is commercial center -- oi] was discovered in commercial quantities in
1966; production began in 1969, 1970 production 86,000 b.p.d.; oi] revenues
for 1970 estimated at $33 million; small fishing, some boat building,
handicrafts, animal husbandry, pearling throughout area
Electric power: 18,000 kw. capacity (1970); 50 million kw.-hr. produced (1970);
380 kw.-hr. per capita
Exports: crude petroleum, pearls, fish; Abu Dhabi crude exports $244 million (est.
1968) and Dubai $20 million total, of which $18.8 million reexports (1968)
Imports: food, consumer and capital goods; Abu Dhabi $120 million estimated
(1969) and Dubai $200 million total (est. 1969)
Major trade partners: Japan, U.K., India
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.21; Abu Dhabi, 1 Bahrain
dinar=US$2.10
Agriculture: cereal farming and livestock herding predominate; main crops --
wheat, barley, olives, fruits (especially citrus), viticulture, vegetables,
dates
Major industries: mining, food processing, textiles and leather, light
manufacturing, construction materials, chemical fertilizers
Electric power: 270,000 kw. capacity (1970); 710 million kw.-hr. produced (1970);
137 kw.-hr. per capita
Monetary conversion rate: 0.52 dinar=US$1 (IMF par value)
Fiscal year: calendar year
333
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $12,820 million (1969), about $370 per capita; 7.5% average annual real
growth 1965-69
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: 1.2 million tons produced (1969), 30 kilograms per capita
Electric power: 2,172,000 kw. capacity (1970); 8,510 million kw.-hr. produced
(1970); 195 kw.-hr. per capita
Exports: $536.7 million (f.0.b., 1969); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $801.1 million (c.i.f., 1969); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: EEC 37.3%, EFTA 18.1%, North America 16.9%, Communist
countries 13.8% (1969)
Monetary conversion rate: 9 Turkish liras=US$1 (export rate); 9.08 Turkish
ey (import rate); both controlled; 12-Turkish liras=US$1 (tourist
rate
Fiscal year: 1 March - 28 February
GDP: $1,026 million (1969), $100 per capita; 6.3% real growth between 1966 and
1969
Agriculture: main cash crops -- coffee, cotton;','b4676837707856528f2b434915252333a47062e5e5b906974087349edb17187b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8341b4c5f4b357f8ad90591a7b4c90e0d91215db61637c1b8a6530d9e4990251',1971,'DZ','Algeria','economy',18,'other cash crops -- sugar,
tobacco, fish, tea, livestock; self-sufficient in food
Major industries: agricultural processing (textiles, sugar, coffee, plywood,
beer), cement, copper smelter, corrugated iron sheet, shoes, fertilizer
Electric power: 150,000 kw. capacity (1969); 737 million kw.-hr. produced
(1969); 90 kw.-hr. per capita
Exports: $211.7 million (f.o.b., 1969); coffee, cotton, copper, tea; $7.6 million
to Communist countries (c.i.f., 1968)
Imports: $194.2 million (c.i.f., 1968); petroleum products, machinery, cotton
Te ieee transport equipment; $7 million from Communist countries
c.i.f.,
Major trade partners: U.K., U.S., Kenya (Uganda, Kenya, and Tanzania form
East African Economic Community)
Monetary conversion rate: 7.143 Uganda shillings=US$1; 1 Uganda shilling=US$0.14
Fiscal year: 1 July - 30 June
337
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Agriculture: principal food crops -- grain (especially wheat), potatoes; main
industrial crops -- sugar beets, cotton, sunflowers, and flax; degree of
self-sufficiency depends on fluctuations in crop yields; given normal yields,
U.S.S.R. is self-sufficient; caloric intake, 3,000-3,200 calories per day
per capita in recent years
Major industries: diversified, highly developed capital goods industries; consumer
goods industries comparatively less developed
339
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Shortages: natural rubber, bauxite and alumina, tantalum, tin, and tungsten
Crude steel: 124.6 million metric ton capacity as of 1 January 1971; 115.8
million metric tons produced in 1970, 475 kilograms per capita
Exports: fuels (particularly petroleum and derivatives), metals, agricultural
products (timber, grain) and a wide variety of manufactured goods (primarily
capital goods); $11,655.3 million (f.0.b., 1969)
Imports: specialized and complex machinery and equipment, textile fibers, consumer
manufactures, and any significant shortages in domestic production (for
example, wheat imported following poor domestic harvests): $10,326.7 million
(f.o.b., 1969)
Monetary conversion rate: .90 rubles=US$1; 1 ruble=US$1.1111
Fiscal year: calendar year
$
i@
Agriculture: main cash crop -- cotton; other crops -- rice, onions, beans, wheat,
corn, barley; not self-sufficient in food, but agriculture a net earner of
foreign exchange
Major industries: textiles, food processing, chemicals, petroleum, construction,
cement
Electric power: 4,875,000 kw. capacity (1970); 10,628 million kw.-hr. produced
(1970 est.); 310 kw.-hr. per capita
Monetary conversion rate: 1 Egyptian pound=US$2.30 (selling rate); 0.435 Egyptian
pound=US$1 (selling rate)
Fiscal year: 1 July - 30 June
34]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GDP: $270 million (1967), about $50 per capita
Agriculture: cash crops -- peanuts, shea nuts, sesame, cotton; food crops --
sorghum, millet, corn, rice; livestock; largely self-sufficient
Major industries: agricultural processing plants, brewery, bottling, and ice
plants; a few other light industries
345
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d): 3
Electric power: 12,100 kw. capacity (1970); 38 million kw.-hr. produced (1970); =
7 kw.-hr. per capita -
Exports: $19 million (f.o.b., 1968); livestock (on the hoof), peanuts, shea
nut products, cotton, sesame
Imports: $34 million (c.i.f., 1968); textiles and other consumer goods, transport ae
equipment, machinery, fuels, food :
Major trade partners: volume understated because much regional trade is unrecorded;
Ivory Coast and Ghana; overseas trade mainly with France and other EEC
countries; preferential tariff to EEC and franc zone countries 2 :
Aid: =
economic -- France (1964-67) $34.4 million;-EEC (1960-68) $49.3 million; ;
U.S.5.R., Ghana, West Germany, and Israel have also extended aid; U.S.
(1962-69) $12.6 million; international organizations $9.5 million;
military -- France, $3.6 million (1964-689, U.S., $0.1 million (1962-69) -
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$]
(official)
Fiscal year: calendar year
COMMUNICATIONS: Fd
Railroads: 728 mi., 320 mi. meter gage, single track; Ouagadougou to Abidjan,
Ivory Coast line
Highways: 10,380 mi.; 40 mi. paved, 3,710 mi. improved, 6,630 mi. unimproved
Civil air: no major transport aircraft
Airfields: 58 total, 51 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: all services generally poor; 2,600 telephones; 87,000 radio
receivers; 5,500 TV receivers; 2 AM, no FM, and 1 TV stations (broadcasts
temporarily suspended)
DEFENSE FORCES:
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1970, $4.3 million; 12.2% of
total budget
346
ie a te Te na
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 91 URUGUAY
LAND:
72,200 sq. mi.; 90% agricultural land, 75% pasture, 15% phat
cropland, 10% urban and waste
Limits of territorial waters: 200 n. mi.
GNP: $2.94 billion (purchasing power parity estimate, 1969); $1,005 per capita;
74% private consumption, 12% public consumption, 14% gross investment; real
growth rate 1970, 5% =
Agriculture: large areas devoted to extensive livestock grazing (22 million
sheep, 8 million cattle); main crops -- wheat, rice, corn; self-sufficient
in most basic foodstuffs; caloric intake, 3,000 calories per day per capita,
with high protein content
Major industries: meat processing, wool and hides, textiles, footwear, cement,
petroleum refining ig
Crude steel: 24,000 metric tons produced (1966), 10 kilograms per capita
Electric power: 575,000 kw. capacity (1970 est.); 2.1 billion kw.-hr. produced
(1970 est.); 724 kw.-hr. per capita
Exports: $220 million (f.o.b., 1970); beef, wool, hides
Imports: $233 million (c.i.f., 1970); fuels, metals, machinery, transportation -
equipment
Major trade partners: exports -- EEC 27%, U.K. 25%, U.S. 12%, LAFTA 11%;
imports -- LAFTA 26%, U.S. 22%, U.K. 14%, EEC 13% (1968)
Monetary conversion rate: 250 pesos=US$1
Fiscal year: calendar year
The Vatican City, seat of the Holy See, is supported financially by contributions
(known as Peter''s pence) from Roman Catholics throughout the world; some
income derived from sale of Vatican postage stamps and tourist mementos,
fees for admission to Vatican museums, and sale of publications; industrial
activity consists solely of printing and production of a small amount of
mosaics and staff uniforms
The banking and financial activities of the Vatican are worldwide; the Institute
for Religious Agencies carries out fiscal operations and invests and. transfers
funds of Roman Catholic religious communities throughout the world; the
Cardinal''s Commission controls the administration of ordinary assets of the
Holy See and a Special Administration manages the Holy See''s capital assets
Electric power: obtained from Rome city grid; standby diesel powerplant with
2,100 kw. capacity
349
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $10.2 billion (purchasing power parity estimate, 1969), $1,020 per capita;
64% private consumption, 14% public consumption, 22% gross investment (1969),
real growth rate 1970 est. 5.4%
Agriculture: main crops -- cotton, sugarcane, corn, coffee, rice; self-sufficient
in most basic foods; caloric intake 2,600 calories per day per capita (1964)
35]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major industries: petroleum, iron-ore mining, construction, food processing,
textiles
Crude steel: 821,000 metric tons produced (1969), 80 kilograms per capita
Electric power: 3.9 million kw. capacity (1970); 11.7 billion kw.-hr. produced
(1970); 1,112 kw.-hr. per capita
Exports: $2,560 million (f.0.b., 1970 est.); petroleum, iron ore, coffee, cocoa
Imports: $1,660 million (f.o.b., 1970 est.); industrial machinery and equipment,
chemicals, manufactures, wheat
Major trade partners: U.S. 41%, Canada 9%, U.K. 5% (1969)
Aid:
economic -- extensions from U.S. (FY46-69), $330.7 million loans; $54.8
million grants; from international organizations (FY46-69), $440.1 million;
military -- assistance from U.S. (FY53-69), $105.1 million
Monetary conversion rate: 4.50 bolivares=US$1 (selling rate)
Fiscal year: calendar year
GNP: $1.6 billion (1964 in 1964 prices), less than $100 per capita; pre-1965
growth rate 6%; GNP 1970, $1.4 billion (S)
Agriculture: mainly subsistence; main crops -- rice, corn, sweet potatoes,
manioc, sugarcane; food shortages -- rice, meat, sugar; caloric intake,
1,700-2,200 calories per day per capita
Major industries: food processing, textiles, machine building, mining, cement
Shortages: petroleum, complex machinery and equipment, fertilizer, foodstuffs
Monetary conversion rate (nominal): 3.7 dong=US$1
Fiscal year: calendar year
Oe aes oye (1969), $240 per capita; 3.3% average annual real growth
1966-69
Agriculture: main crops -- rice, rubber, peanuts, corn, sugarcane, sweet potatoes,
copra; major food imports -- rice, dairy products, sugar, wheat flour
Major industries: manufacturing on small scale, mainly light manufacturing and
processing of local agricultural and forest products; factories produce
textiles, beer, cigarettes, glass, tires, sugar, paper, cement, soft drinks;
there are also limited mining operations
Shortages: capital goods
Electric power: 560,000 kw. capacity (1970); 1.15 billion kw.-hr. produced (1970);
63 kw.-hr. per capita
Exports: $33 million (f.o.b., 1969); major commodities -- rubber, reexported oil
drums, tea, duckfeathers
Imports: $818 million (c.i.f., 1969); major commodities -- machinery and trans -
portation equipment, rice, textile fabrics and yarn, petroleum products, base
metals and manufactures
Major trade partners: exports -- France, U.K., West Germany, Japan; imports --
U.S., Japan, Taiwan; no trade with Communist countries
Monetary conversion rate: official rate, 118 piasters=US$1 applies to most imports
of goods and government transfers; a second rate of 275 piasters=US$1 estab-
lished on October 5, 1970, applies to imports of luxury goods, exports of
goods, and invisible transactions such as purchases of piasters by American
personnel in South Vietnam, foreign investment, and profit remittances of
foreign firms; black-market rate of 396 piasters=US$1 during first quarter
1971
Fiscal year: calendar year','aa96b19ca8fc4812338b7221f8261b62bcfa44c5833eedae2c50192028e88349','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9971bd87a305026000d179d8da9bd2f84cc81adacd3e8b7ef2595326c2323f8',1971,'BR','Brazil','economy',28,'rae PEOPLE:
Population: 6,300,000 (excluding nomadic Indian tribes),
average annual rate of growth 3.4% (FY69); males 15-49
1,461,000; 930,000 fit for military service; average
~ number reaching military age (20) annually 60,000
Ethnic divisions: 41% mestizo, 39% Indian, 10% white,
5% Negro, 5% Oriental and other
Religion: 95% Roman Catholic (majority nonpracticing), trace of Evangelical
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 55% agriculture, 16% manufacturing, 4%
construction, 7% trade, 9% services, 9% other; shortage of skilled labor
Organized labor: 12% of labor force
GNP: $2.3 billion (purchasing power parity estimate, 1969), $400 per capita;
74% private consumption, 13% public consumption, 12% gross investment (1969
ect: real growth rate 1970 est., 5%-6%
$ Agriculture: main crops -- sugarcane, beans, coffee, cotton, corn, bananas,
cocoa, rice; nearly self-sufficient; caloric intake, 2,100 calories per day
per capita (1964)
Major industries: food processing, textiles, cement, leather and rubber products ,
drugs, fishing
Electric power: 226,275 kw. capacity (1970 est.); 1.1 billion kw.-hr. produced
(1970); 183 kw.-hr. per capita
Exports: $183 million (f.o.b., 1969); bananas, coffee, cocoa
87
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Imports: $262 million (c.i.f., 1969 est.); agricultural and industrial machinery,
petroleum products, chemical products, transportation and communication
equipment
Major trade partners: U.S. 36%, EEC 25%, Japan 9% (1969)
Aid:
economic -- extensions from U.S. (FY46-69), $169.9 million loans, $89.8
million grants; from international organizations (FY46-69), $143.7 million; ;
from Communist countries (1954-69), $10 million loans; a
military -- assistance from U.S. (FY49-70), $52.0 million
Monetary conversion rate: 25.25 sucres=US$1 (selling rate)
Fiscal year: calendar year
GNP: $1.45 billion (purchasing power parity estimate, 1969), $430 per capita;
80% private consumption, 9% government consumption, 11% domestic investment
(1970 est.); real growth rate 1970 est., 5.5%
Agriculture: main crops -- coffee, cotton, corn, sugar, rice, beans; caloric
intake, 2,000 calories per day per capita (1963-64)
Major industries: food processing, textiles, clothing, petroleum products
Electric power: 166,600 kw. capacity (1969 est.); 680 million kw.-hr. produced
(1970 est.); 190 kw.-hr. per capita
Exports: $202 million (f.o.b., 1969); coffee, cotton, sugar, chemicals,
other manufactures
Imports: $214 million (c.i.f., 1969); machinery, automotive vehicles, petroleum,
foodstuffs
Major trade partners: exports -- U.S. 21%, CACM 37%, Western Europe 29%, Japan
10%; imports -- U.S. 29%, CACM 29%, Western Europe 22%, Japan 9% (1969)
Aid:
economic -- extensions from U.S. (FY46-69), $78.7 million loans, $50.3
million grants; from international organizations (FY46-69), $98.5 million;
from other Western countries (1960-68) $3.7 million;
military -- assistance from U.S. (FY46-69), $6.2 million
Monetary conversion rate: 2.5 colones=US$1 (official)
Fiscal year: calendar year
, GDP: $40 million (1965 est.); Rio Muni nearly $100 per capita, Fernando Po
if about $250 per capita
& Agriculture: major cash crops -- Rio Muni, timber, coffee; Fernando Po, cocoa;
main food crops -- rice, yams, cassava, bananas, oi] palm nuts, manioc, and
lives tock
f Major industries: fishing, sawmilling
Electric power: 2,800 kw. capacity (1970); 9 million kw.-hr. produced (1970);
about 30 kw.-hr. per capita
Exports: $32.5 million (1964); cocoa, coffee, fruits, and wood
Imports: $15.3 million (1964); automobiles, cement, petroleum products
Major trade partner: Spain
Aid: Spain, $14.0 million (1967); Libya, $1 million (1971)
Monetary conversion rate: 70 Guinean pesetas=US$1 (official)
91
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GDP: $1.5 billion (est. 1969 in current prices); 1966-68 average annual growth
rate 4.3%
Agriculture: main crops -- coffee, teff, durra, barley, wheat, corn, sugarcane,
cotton, pulses, oilseeds, livestock; usually self-sufficient in food
Major industries: cement, sugar refining, cotton textiles, food processing,
oil refinery
Electric power: 200,000 kw. capacity (1969); 390 million kw.-hr. produced
(1969); 16 kw.-hr. per capita
Exports: $109 million (f.o.b., 1969); coffee 58%, hides and skins 10%, oilseeds
9%, pulses 8%; $4.5 million to Communist countries (1967)
Imports: $155 million (c.i.f., 1969); machinery and transport equipment 41%,
fuels 7%, intermediate goods 18%, consumer goods 27%, misc. 7%; $7.8 million
from Communist countries (1967)
Major trade partners: imports -- Italy, West Germany, Japan, and U.S.3
exports -- U.S., Italy, Saudi Arabia, West Germany, Japan
93
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d): 7
Monetary conversion rate: 2.50 Ethiopian dollars=US$1 (official)
Fiscal year: 8 July - 7 July
Agriculture: sheep and cattle grazing
Major industry: fishing and whaling
Electric power: 27,500 kw. capacity (1970); 59 million kw.-hr. produced (1970);
1,590 kw.-hr. per capita
Exports: $20.5 million (f.o.b., 1968); fish and fish products
Imports: $28.2 million (c.i.f., 1968); machinery and transport equipment, pet-
roleum and petroleum products, food products
Major trade partners: (1968) Denmark 42.8%, U.K. 9.9%, Sweden 5.0%, U.S. 2.1%,
Norway 11.2%; EEC 9.6%; EFTA 71.8%; Communist countries 1.4%
Monetary conversion rate: 7.5 Danish kroner=US$1
Fiscal year: 17 April - 31 March
Government budget: Colony -- revenues, $1.0 million (FY68); expenditures,
$1.1 million (FY68)
Agriculture: Colony -- predominantly sheep farming; dependencies -- whaling
and sealing
Major industries: Colony -- wool processing; dependencies -- whale and seal
processing
Electric power: 1,327 kw. capacity (1970); 4 million kw.-hr. produced (1970);
200 kw.-hr. per capita
Exports: Colony -- $2.52 million (1966); wool (97%), hides and skins (2%) ,
and other (1%); dependencies -- $3.8 million (1965); whale and seal oi]
(62%) and other whale products (38%)
Imports: Colony -- $1.7 million (1966); food, clothing, fuels, and machinery;
dependencies -- $.2 million (1965); mineral fuels and lubricants, food,
and machinery
Major trade partners: nearly all exports to the U.K., 77% of imports from the
U.K.3 dependencies -- exports to the Netherlands (63%) and Japan (37%),
imports from Curacao, Japan, and the U.K.
Monetary conversion rate: 1 Falkland Island pound=US$2.40
9 suerte as (1969 est.), $340 per capita; 6% average annual growth rate
967-69
Agriculture: main crops -- sugar, coconut products, bananas, rice; major
deficiency, grains
‘Major industries: tourism, sugar processing
. Electric power: 15,700 kw. capacity (1969); 23.5 million kw.-hr. produced (1969);
“~~ 43 kw.-hr. per capita
Exports: $59.2 million (f.o.b., 1969 excluding reexports); sugar, copra, copper
Imports: $89.6 million (c.i.f., 1969)
Major trade partners: U.K., Australia, U.S., Japan, New Zealand
Aid: disbursed 1968 -- Australia $1.5 million, U.S. $600,000, U.K. $4.2 million
Monetary conversion rate: 0.87 Fijian dollar=US$1
Fiscal year: calendar year
99
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $9.1 billion (1968), $1,928 per capita; 59.1% consumption, 27.5%
investment, 15.1% government, 1.7% net exports of goods and services; 1969
growth rate 8.7%, 1964 constant prices
Agriculture: animal husbandry, especially dairying, predominates; forestry
important secondary occupation for rural population; main crops -- cereals,
101
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Agriculture (cont''d);
sugar beets, potatoes; 85% self-sufficient; shortages -- food and fodder
grains; caloric intake 2,890 calories per day per capita (1968-69)
Major industries: include metal manufacturing and shipbuilding, forestry and
wood processing (pulp, paper), copper refining
Shortages: fossil fuels; industrial raw materials, except wood, and iron ore
Crude steel: 907,000 metric tons produced (1969), 190 kilograms per capita
Electric power: 4,800,000 kw. capacity (1970); 22,313 million kw.-hr. produced
(1970); 4,000 kw.-hr. per capita
Exports: $1,987 million (f.o.b., 1969); timber, paper and pulp, ships, machinery
Imports: $2,023 million (c.i.f., 1969); foodstuffs, industrial raw materials,
manufactured producer and consumer goods, petroleum and petroleum products,
chemicals
Major trade partners (1969): 25.6% EEC, 39.5% EFTA, 13.1% West Germany,
15.8% U.K., 14.2% Sweden, 5.6% U.S., 13.3% U.S.S.R., 17.2% Communist countries
Aid: U.S. $151.5 million authorized 1946-68, $0.5 million (1966), $17.8 million
(1967), none in 1968; IBRD -- $221.5 million authorized through 1946-68,
none since 1966; Finnish foreign aid programs have amounted to $23 million
1961-69
Monetary conversion rate: new markka (Fmk) 4.20=US$1 (official)
Fiscal year: calendar year','9c3124429e298a4c4b9eabf628a1f267c1b5d2c597e9bc847e332e8aab444dd6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65a9c53b1778b04b9eab400dcedc173a8793368bc970b1376419898e8a67415c',1971,'LY','Libya','economy',33,'GNP: $145.9 billion (1970), $2,870 per capita; 60% consumption, 28% investment
(including government), 11% government consumption; 1% net exports; 1970
growth rate 5.9%, 1963 constant prices
Agriculture: Western Europe''s foremost producer; main crops -- cereals, sugar
beets, potatoes, wine grapes; self-sufficient for most temperate zone food-
stuffs; food shortages -- fats and oils, tropical produce; caloric intake,
3,180 calories per day per capita (1967 est.)
Major industries: steel, machinery and equipment, textiles and clothing, fee
chemicals, food processing, metallurgy —_
Shortages: crude oj], textile fibers, most nonferrous ores, coking coal, fats
and oils
Crude steel: 23.8 million metric tons produced (1970 prelim.), 469 kilograms per
capita (1970 prelim.) “
Electric power: 36,500,000 kw. capacity (1970); 140.7 billion kw.-hr. produced
(1970); 2,600 kw.-hr. per capita
Exports: $18.1 billion (f.0.b., 1970); principal items -- textiles and clothing,
iron and steel products, machinery and transportation equipment, foodstuffs
and agricultural preducts, alcoholic beverages
Imports: $18.6 billion (c.i.f., 1970); principal items -- machinery and
equipment, crude petroleum, iron and steel products, textile fibers, coal
and coke, foodstuffs, alcoholic beverages
Major trade partners: (1970) EEC 49%; West Germany 21%; Belgium-Luxembourg 112%;
Italy 10%; Netherlands 6%; EFTA 13%; U.S. .8%; Eastern Europe 2%; U.S.S.R. 1%;
franc zone 10%
Aid:
economic (received) -- U.S., $5,157.0 million authorized (FY46-68), none
since FY67;
military -- U.S., $4,259 million authorized (FY46-68); net official economic
aid to less developed areas and multilateral agencies -- $7,624 million
(FY60-68), $855.2 million (FY69)
Monetary conversion rate: 5.55419 francs=US$1 (official)
Fiscal year: calendar year
GNP: $32 million (1966), $840 per capita
Agriculture: main crops -- rice, corn, manioc, cocoa, bananas, sugarcane
Major industries: rum, shrimping, timber, gold mining, and production of
rosewood essence
Electric power: 18,300 kw. capacity (1970); 54.9 million kw.-hr.
produced (1970); 106 kw.-hr. per capita
Exports: $3.1 million (f.o.b. 1968); rum, gold, timber, shrimp, rosewood essence
Imports: $46.7 million (c.i.f., 1968); food (grains, processed meat), miscella-
neous manufactured goods
Monetary conversion rate: 5.554 Guianese francs=US$1 (official)
Fiscal year: calendar year','c89e0d2f9b58159f7171c6953420b8d2f3bc6b7da33bd61439433dbe56ae8918','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10b0b1ba26fd8f63449bfff31dc3bea30ba4e8f1030aa3c0584ec396326558a1',1971,'GP','Guadeloupe','economy',39,'Agriculture: livestock; desert conditions limit commercial crops to about 15
acres
Industry: ship repairs
Electric power: 18,300 kw. capacity (1970); 18 million kw.-hr. produced (1970);
222 kw.-hr. per capita
Imports: almost all domestically needed goods
Exports: hides and skins
Aid: $2.4 million in 1967 from France
Monetary conversion rate: 214 Djibouti francs=US$1 (official)
Fiscal year: probably same as that for France (calendar year)
COMMUNI CATIONS:
Railroads: 60 mi. meter gage
Highways: 620 mi.; 50 mi. paved, 570 mi. earth
Ports: 1 major, 1 minor
Airfields: 27 total, 10 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 4 major transport aircraft (registered in France)
Telecommunications: fair telephone services; poor telegraph facilities; 2,000
telephones; 7,000 radio receivers; 1,100 TV receivers; 1 AM, no FM, and
1 TV stations
107
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 83 FRENCH WEST INDIES
LAND:
1,120 sq. mi.; 29% arable, 13% meadows and pastures, 29%
forested, 9% unused but potentially productive, 20%
built on, waste, other, area consists of eight islands,
principal of which are Martinique and the two islands
of Guadeloupe (1965) ; VENEZUELA
Limits of territorial waters: 3 n. mi.','ccc3c9cd64cfc41484f0804280e28c46b7aebbb202770d1e4ee6e7d03f48886c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2692de333c67a77f8f6a4f03a242e828714440d53de00d5ea6314098d82297e1',1971,'CO','Colombia','economy',42,'GNP: Martinique -- $196 million (1967), $590 per capita; real growth rate (1967)
ie at ne -- $169 million (1967), $510 per capita; real growth rate
1966} 1%
Major industry: manufacture of rum and liqueurs
Electric power: 54,220 kw. capacity (1969); 145.4 million kw.-hr. produced
(1969) ; 220 kw.-hr. per capita
Exports: Martinique -- $36 million (f.0.b., 1969); Guadeloupe -- $34 million
(f.o.b., 1969); rum, liqueurs, sugar, bananas, pineapples
Imports: Martinique -- $128 million (c.i.f., 1969); Guadeloupe -- $106 million
(c.i.f., 1968); petroleum products, rice, flour, other foodstuffs (mostly
processed), textiles, manufactured consumer goods, transportation equipment
Major trade partners: Martinique -- France 74%, EEC 10%, U.S. 4% (1968);
Guadeloupe -- France 72%, U.S. 8% (1964)
Monetary conversion rate: 5.554 West Indian francs=US$1 (official)
Fiscal year: calendar year
*
COMMUNI CATIONS:
Railroads: only privately-owned, narrow-gage lines on sugar plantations
Highways: 2,010 mi.; 1,030 mi. paved, 900 mi. gravel, 80 mi. earth
Ports: 2 major, 9 minor
Civil air: no major transport aircraft
Airfields: 7 total, 5 usable; 3 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: major islands linked by VHF system; plan interconnection -
with nearby British islands soon; planned satellite ground station on
Martinique; 27,300 telephones; 89,000 radio and 14,500 TV receivers; 3 AM
and 6 TV stations
DEFENSE FORCES:
Defense is responsibility of France; data are for French military forces
stationed in FWI
Supply: responsibility of France
110
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 52D GABON
LAND:
102,000 sq. mi.; 75% forested, 15% savanna, 9% urban and
wasteland, less than 1% cultivated (1967) 5
Limits of territorial waters: 25 n. mi. (fishing, 25 n. mi.) |
GDP: $163 million (1968), about $340 per capita; 1965-66 growth rate 8.8% at
current prices
Agriculture: commercial -- cocoa, coffee, wood, palm oil, rice; main food crops
-- bananas, manioc, peanuts, root crops; imports food
Major industries: sawmills, petroleum refinery, natural gas, agricultural
processing; mining of increasing importance; major minerals -- manganese,
uranium, gold, and iron
Electric power: 16,750 kw. installed capacity (1970); 46 million kw.-hr. produced
(1970) ; 97 kw.-hr. per capita
Exports: $133 million (f.o.b., 1969) excluding trade with other members of the
Economic and Customs Union of Central Africa (UDEAC); wood and wood products
about 40%; minerals (manganese, uranium concentrates, gold, crude oi1)
Imports: $73 million (c.i.f., 1969) excluding UDEAC trade; mining, roadbuilding
machinery, electrical equipment, transport vehicles, foodstuffs, textiles
W1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d): 2
Major trade partners: France, U.S., West Germany, and Curacao; preferential
tariffs to EEC and franc zone 2
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year £
GDP: $32 million (1968 est.), about $90 per capita
Agriculture: main crops -- peanuts, rice, palm kernels
Major industry: peanut processing
Electric power: 3,000 kw. capacity (1969); 6.6 million kw.-hr. produced (1969);
18 kw.-hr. per capita
Exports: $12.9 million (1968); peanuts and peanut products 90% to 95%, palm
kernels
Imports: $19.4 million (1968); textiles, foodstuffs, tobacco, machinery ,
petroleum products
Major trade partners: exports -- U.K.; imports -- U.K. and Japan
Aid: economic -- U.K. (1968-71) about $8 million commitment
Monetary conversion rate: 1 Gambian pound=US$2.40 (official)
Fiscal year: 1 July - 30 dune
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2','6c0939e05ebef1c413a7dcc59874aefd207c1eafc26152f5767d773eaadba0ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7729fbb8e2b8112b5f0c7da4ea9a6eda460c5245e0ae3b3a82503d97c71faed',1971,'MA','Morocco','economy',45,'Agriculture: cereals farming and livestock raising predominate; main crops --
cereals, citrus fruit, wine, truck garden produce, olives
Major industries: mining and mineral processing, food processing, textiles
Electric power: 748,300 kw. capacity (1970 est.); 2,529 million kw.-hr. produced’
(1970 est.); 160 kw.-hr. per capita
Monetary conversion rate: 5.06 dirhams=US$1 (IMF par value)
Fiscal year: calendar year
GNP: $700 million (est. 1966), about $100 per capita
Agriculture: cash crops -- raw cotton, cashew nuts, sugar, tea, copra, sisal;
other crops -- corn, wheat, peanuts, potatoes, beans, sorghum, and cassava;
self-sufficient in food except for wheat which must be imported
Major industries: food processing (chiefly sugar, tea, wheat, flour, cashew
kernels); chemicals (vegetable oi1, oilcakes, soap, paints); petroleum
products; beverages; textiles; nonmetallic mineral products (cement, glass,
asbestos, cement products); tobacco
Electric power: 232,000 kw. capacity (1970); 464 million kw.-hr. produced (1970);
64 kw.-hr. per capita
219
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Exports: $149 million (f.o.b., 1970); cotton, sugar, cashew nuts, mineral products,
timber products, tea, copra, petroleum products
Imports: $288 million (c.i.f., 1970); machinery and electrical equipment, cotton
textiles, vehicles, petroleum products, wine, iron and steel
Major trade partners: over one-third of foreign trade with Portugal; South Africa,
U.S., U.K., West Germany
Aid: from Portugal only
Monetary conversion rate: 28.75 escudos=US$1 (official) ‘
Fiscal year: calendar year
GNP: $18 million (1968), over $2,500 per capita
Agriculture: negligible; almost completely dependent on imports for food
Major industries: mining of phosphates, about 2 million tons per year (1966)
Electric power: 7,600 kw. capacity (1969); 17 million kw.-hr. produced (1969);
2,833 kw.-hr. per capita
Exports: $17 million (f.o.b., 1968), consisting entirely of phosphates
Imports: $5 million (c.i.f., 1968)
Major trade partners: Australia, New Zealand, and United Kingdom
Monetary conversion rate: 1 Australian dollar=US$1.12 (official)
Fiscal year: 1 July - 30 June
GDP: $1 billion (1969), less than $100 per capita
Agriculture: over 90% of population engaged in agriculture; main crops -- rice,
corn, wheat, sugarcane, oilseeds; largely self-sufficient
Major industries: small rice, jute, sugar, and oilseed mills; match and cigarette
factories
Electric power: 44,000 kw. capacity (1970); 61 million kw.-hr. produced (1970);
kw.-hr. per capita
Exports: $55 million (FY69 est.); rice and other food products, jute, timber
Imports: $62 million (FY69 est.); manufactured consumer goods, food grains and
food products
Major trade partner: over 90% India
Monetary conversion rate: 10.1 Nepalese rupees=US$1
Fiscal year: 15 July - 14 July
223
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $31.3 billion (1970), $2,410 per capita (based on 1970 population); 56%
consumption, 29% investment, 16% government, -1% net exports of goods and
services; 1970 growth rate 5.2%, in 1963 constant prices
Agriculture: animal husbandry predominates; main crops -- horticultural crops,
grains, potatoes, sugar beets; food shortages -- grains, fats, oils; caloric
intake, 3,030 calories per day per capita (1967-68)
225
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major industries: food processing, metal and engineering products, electrical and
electronic machinery and equipment, chemicals, and petroleum products
Shortages: crude petroleum, raw cotton, base metals and ores, pulp, pulpwood,
lumber, feedgrains, and oilseeds
Crude steel: 4.7 million metric tons produced (1969), 360 kilograms per capita
Electric power: 10,682,000 kw. capacity (1970); 38.7 billion kw.-hr. produced
(1970) ; 2,869 kw.-hr. per capita
Exports: $11,772 million (f.o.b., 1970); foodstuffs, machinery, transportation Py
equipment, consumer manufactures, chemicals, petroleum products, textiles
Imports: $13,392 million (c.i.f., 1970); machinery, transportation equipment,
consumer manufactures, crude petroleum, foodstuffs, chemicals, raw cotton,
base metals and ores, pulp
Major trade partners: (1969) 58.3% EEC, 28.1% W. Germany, 15.9% Belgium-
Luxembourg, 9.6% France, 13.7% EFTA, 6.6% U.K., 7.2% U.S., 2.0% Eastern .
Europe
Aid:
economic -- (received) U.S., $1,230 million authorized (FY46-69); none
since FY58; IBRD, $236 million authorized (FY46-58), none since 1958;
military -- (received) U.S., $1,241 million authorized (FY46-68), none since
FY67; net official aid given to less developed areas and multilateral
agencies -- $805 million (FY60-69), $150 million (FY69)
Monetary conversion rate: 3.62 guilders=US$1 (official)
Fiscal year: calendar year
GNP: $254 million (1967), $1,190 per capita; real growth rate 1967, 3.6%
Agriculture: little production
Major industries: petroleum refining on Curacao and Aruba; also tourism and
phosphate mining on Curacao
Electric power: 288,500 kw. capacity (1969); 1.3 billion kw.-hr. produced (1969
est.); 5,909 kw.-hr. per capita
Exports: $625 million (f.o0.b., 1969); petroleum products, phosphate
Imports: $830 million (c.i.f., 1969); crude petroleum, food manufactures :
Major trade partners: exports -- U.S. 43%, EEC 16%, Latin America 13%, U.K. 10%,
Canada 7%; imports -- Venezuela 72%, U.S. 10%, Netherlands 4% (1968)
Monetary conversion rate: 1.88 Netherlands_Antillean florins (NAF)=US$1 (official)
Fiscal year: calendar year
GNP: $190 million, $1,900 per capita
Agriculture: main crops -- coffee, copra, fruits, and vegetables
Industry: mining of nickel
Electric power: 105,000 kw. capacity (1970); 725 million kw.-hr. produced (1970);
7,500 kw.-hr. per capita
Exports: $131 million (f.0.b., 1969) 98% nickel
Imports: $124 million (c.i.f., 1969)
Major trade partners: (1968) exports -- France (47%), Japan (40%); imports --
France (49%), Australia (19%)
Monetary conversion rate: 95 CFP francs=US$1
229
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $750 million (purchasing power parity estimate, 1968), $410 per capita; 77%
private consumption, 11% government consumption, 16% domestic investment, -4%
net foreign balance; real growth rate 1968, 3%
Agriculture: main crops -- cotton, coffee, sugarcane, rice, corn, beans; caloric
intake, 2,300 calories per day per capita (1966)
Major industries: food processing, textiles and clothing, chemicals, petroleum
products
Electric power: 173,000 kw. capacity (1969 est.); 550 million kw.-hr. produced
(1969 est.); 290 kw.-hr. per capita
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Exports: $155 million (1969); cotton, coffee, cottonseed, meat, sugar
Imports: $176 million (1969); machinery, equipment, vehicles, manufactures,
chemicals, foods, fuels
Major trade partners: exports -- U.S. 33%, Japan 19%, CACM 21%; imports -- U.S.
38%, CACM 24%, West Germany 7% (1969)
Aid:
economic -- extensions from U.S. (FY46-69), $105.8 million loans, $58.4
million grants; international organizations, $124.2 million (1946-69); —_
military -- from U.S. (FY53-69), $11.8 million (1946-69)
Monetary conversion rate: 7 cordobas=US$1 (official)
Fiscal year: calendar year
COMMUNICATIONS : on F
Railroads: 220 mi.; 200 mi. of 3''6" gage, government owned; 20 mi. narrow gage, ree
privately owned
Highways: 6,400 mi.; 750 mi. paved, 600 mi. gravel or crushed stone, 1,850 mi.
improved earth, 3,200 mi. unimproved earth
Inland waterways: 1,380 mi., including 2 large lakes
Pipelines: crude oi], 36 mi.
Freight carried: rail 1960 -- 25 million ton/km.
Ports: 4 major, 6 minor
Merchant marine: 4 cargo ships (1,000 GRT or over) totaling 9,800 GRT,
14,800 DWT
Civil air: 10 major transport aircraft
Airfields: 456 total, 411 usable; 4 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: extensive but low-capacity wire network; single radio relay
link; 23,500 telephones; est. 700,000 radio and 55,000 TV receivers, 70 AM,
26 FM, and 5 TV stations
DEFENSE FORCES:
Supply: dependent primarily upon U.S.
Military budget: for fiscal year ending 31 December 1970, $11.6 million for the
Ministry of Defense, including civil functions (e.g., police and civil air);
11.8% of central government budget
234
3
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 50L NIGER
LAND:
489,000 sq. mi.; about 3% cultivated; perhaps 20% somewhat
arable; remainder desert (1970)
an GDP: $319 million (1966 est.), less than $100 per capita
Agriculture: commercial -- peanuts, cotton, livestock; main food crops --
millet, sorghum, niebe beans, vegetables
Major industries: cement plant, brick factory, rice mill, small cotton gins, oi]
presses, slaughterhouse, and a few other small light industries
. Electric power: 40,000 kw. capacity (1970); 28 million kw.-hr. produced (1970);
7 kw.-hr. per capita
Exports: $31.4 million (f.0.b., 1968-69 est.); about 74% peanuts and related
products, rest largely livestock, hides, skins; exports badly understated
because much regional trade not recorded
Imports: $31.2 million (c.i.f., 1968-69 est.); fuels, machinery, transport equip-
ment, foodstuffs, consumer goods (largely for European residents); sizable
imports unrecorded
Major trade partners: France (about 50%), other EEC countries, Nigeria, UDEAC
countries, U.S.; preferential tariff to EEC and franc zone countries
235
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Aid:
economic -- France (1960 to mid-1967) $68 million; EEC (1966-67) $51.3 million;
U.S. (FY62-69) $14 million; West Germany, Israel, Republic of China, and U.N.
have also extended aid;
military -- $2.8 million (1954-68)
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: 1 October - 30 September
GDP: $4.6 billion (1970 est.), probably about $80 per capita; 2.6% growth rate
assumed FY69-70
Agriculture: main crops -- peanuts, cotton, cocoa, rubber, yams, cassava,
sorghum, palm kernels, millet, corn, rice; livestock; almost self-sufficient
*This estimate is consistent with the series of estimates adopted by the U.S. Agency
for International Development. Its accuracy cannot be precisely evaluated but
it represents a reasonable approximation.
237
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major industries: processing industries -- oi] palm, peanut, cotton, rubber,
petroleum, wood, hides, skins; manufacturing industries -- textiles, cement,
building materials, food products, footwear, chemical, printing, ceramics;
mining -- crude oi], natural gas, coal, tin, columbite
Electric power: 1,111,000 kw. capacity (1970 est.); 1,667 million kw.-hr. produced
{1970 est.); 30 kw.-hr. per capita
Exports: $906.1 million (f.o.b., 1969); of], peanuts, palm products, cocoa, rubber,
cotton, timber, tin =_
Imports: $696.6 million (c.i.f., 1969); machinery and transport equipment, manu-
factured goods, textiles, chemicals
Major trade partners: U.K., EEC, U.S.
Monetary conversion rate: 1 Nigerian pound=US$2.80 (official)
Fiscal year: 1 April - 31 March Poll
GNP: 9.7 billion (1969), $2,488 per capita; 53.8% consumption; 31.4% investment,
including government; 14.3% government, including defense (current); net
foreign balance 0.5%; 1969 growth rate 3.9%, in 1961 constant prices
Agriculture: animal husbandry predominates; main crops -- feed grains, potatoes,
fruits, vegetables; 40% self-sufficient; food shortages -- food grains, sugar;
caloric intake, 2,910 calories per day per capita (1968-69)
Major industries: food processing, wood pulp, paper products, metals, machinery,
chemicals, shipbuilding
239
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Shortages: feed and bread grains, coal, petroleum and petroleum products, cotton,
woo]
Crude steel: 824,000 metric tons produced (1969), 210 kilograms per capita
Electric power: 12,580,000 kw. capacity (1970); 56,475 million kw.-hr. produced
(1970); 14,000 kw.-hr. per capita
Exports: $2,203 million (f.o.b., 1969); principal items -- fish and fish
products, metal and metal products, pulp and paper, chemicals, ships
Imports: $2,943 million (c.i.f., 1969); principal items -- ships, machinery,
fuels, foodstuffs
Major trade partners: 18.2% Sweden, 19.5% U.K., 15.7% West Germany, 7.9% U.S.,
i 7.2% Denmark; 27.6% EEC; 50.2% EFTA; 2.6% Communist countries
id:
economic -- U.S., $353.0 million authorized (1946-69); none since 1958,
except $1.2 million in 1967; IBRD, $145 million authorized through 1968,
none since 1964; net official economic aid given to less developed areas and
multilateral agencies, $134.2 million (1960-69), $26.6 million (1968), $37.8
million (1969);
military -- U.S., $900.3 million authorized (1946-69), $32.6 million (1967),
$24.2 million (1968), $11.0 million (1969)
Monetary conversion rate: 7.14 kroner=US$1 (official)
Fiscal year: calendar year
Agriculture: based on subsistence farming (fruits, dates, cereals, cattle, camels,
fish) and trade
Electric power: 24,000 kw. capacity (1970); 70 million kw.-hr. produced (1970);
120 kw.-hr. per capita
Exports: petroleum exports worth $140 million (1968); dates, fish, limes, hides,
wool; to U.K. $6.5 million (1967)
Major trade partners: India, Burma, Pakistan, the other Persian Gulf States, U.K.
Monetary conversion rate: new currency introduced Riyal Said; RO.42=US$1
Fiscal year: no budget year
GNP: $15.7 billion (1969-70), $120 per capita; real growth (1969-70) 5.8%
Agriculture: largely subsistence farming, heavily dependent on monsoon rainfall
in East Pakistan and extensive irrigation in West Pakistan; main crops --
jute and rice in the East, and wheat and cotton in the West; West largely
self-sufficient; East -- shortages in rice and wheat
Major industries: cotton textiles, jute manufactures, food processing, natural gas
Electric power: 2,616,000 kw. capacity (1970); 7.85 billion kw.-hr. produced
(1970); 69 kw.-hr. per capita
Exports: $701 million (f.o.b., 1969-70); jute and cotton (raw and manufactured)
Imports: $1,071 million (c.i.f., 1969-70) machinery, transport equipment, chemicals
Major trade partners: U.S., U.K., Japan, West Germany
Monetary conversion rate: 4.762 rupees=US$1
Fiscal year: 1 July - 30 June
GNP: $550 million (FY70 estimate), $225 per capita; real average annual growth
rate (1960-69) 7.5%
Agriculture: main crops -- coconuts, coffee, cocoa, rubber, rice
Major industries: sawmilling and timber processing, copper mining (Bougainville)
Electric power: 70,500 kw. capacity (1970); 196 million kw.-hr. produced (1970);
80 kw.-hr. per capita
247
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Exports: $84.3 million (f.o.b., FY69); principal products -- coconut products,
coffee beans, cocoa beans, timber
Imports: $168.5 million (f.0.b., FY69)
Major trade partners: Australia, U.K., Japan
Aid: economic -- Australia (FY46-69) $909 million extended; World Bank group
(1968-September 1969) -- $7.5 million committed
Monetary conversion rate: 0.893 Australian dollar=US$1
Fiscal year: 1 July - 30 June
GNP: $755 million (purchasing power parity estimate, 1970), $320 per capita; 77%
private consumption; 11% public consumption; 15% gross domestic investment;
-3% net foreign balance (1968); real growth rate 1970, 7%
Agriculture: main crops -- oilseeds, cotton, wheat, manioc, sweet potatoes,
tobacco, corn, rice, sugarcane; self-sufficient in most foods; caloric
intake, 2,580 calories per day per capita (1963-64); protein intake,
70 grams per day per capita (20 grams of animal origin)
Major industries: meat packing, oilseed crushing, milling, brewing, textiles,
Tight consumer goods, cement
249
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Electric power: 150,000 kw. capacity (1970 est.); 201 million kw.-hr. produced
(1970 est.); 83 kw.-hr. per capita
Exports: $64 million (f.o.b., 1970) ; meat, timber, oilseeds, tobacco, cotton,
quebracho extract, hides, yerba mate
Imports: $76 million (c.i.f., 1970); foodstuffs, machinery, transport equipment,
engines, consumer durables, fuels and lubricants, textiles
Major trade partners: U.S. 25%, Argentina 20%, West Germany 8%, U.K. 8%
Aid: ae
economic -- extensions from U.S. (FY46-69), $74.8 million loans, $50.5 million
grants; from international organizations (FY46-68), $88.4 million; from other
Western countries (1960-66), $7.4 million;
military -- assistance from U.S. (FY58-69), $10.2 million
Monetary conversion rate: 126 guaranies=US$1 (selling rate)
Fiscal year: calendar year a
GNP: $7.3 billion (purchasing power parity estimate, 1969), $520 per capita; 72%
private consumption, 10% public consumption, 13% gross investment (1970); 5%
net foreign balance; real growth rate 1970, 7%
Agriculture: main crops -- wheat, corn, potatoes, beans, barley, cotton, sugarcane;
imports wheat, meat, lard and oils, rice, corn; caloric intake, 2,300 calories
per day per capita (1964)
Major industries: mining of metals, petroleum, fishing, textiles and clothing,
food processing, cement
Electric power: 2 million kw. capacity (1969 est.); 4.7 billion kw.-hr. produced
(1969); 442 kw.-hr. per capita
Exports: $1,048 million (f.o.b., 1970); fish and fish products, copper, sitver,
iron, cotton, sugar, lead, zinc, petroleum, coffee
25]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Imports: $618 million (f.0.b., 1970); foodstuffs, machinery, transport equipment,
iron and steel semimanufactures, chemicals, pharmaceuticals
Major trade partners: exports -- U.S. 33%, Western Europe 42%, Japan 14%, Latin
America 6%; imports -- U.S. 32%, Western Europe 33%, Latin America 17%,
Japan 6% (1970)
Aid:
economic -- extensions from U.S. (FY46-69), $456.6 million loans, $164.0
million grants; from international oA aaa (FY46-67), $325.2 million;
from other Western countries (1960-66), $43.4 million; Communist countries a
(1968-70) $59.3 million;
military -- assistance from U.S. (FY49-69), $143.7 million
Monetary conversion rate: 38.70 soles=US$1 (trade); 435 soles=US$1 (non-trade)
Fiscal year: calendar year
7
GNP: $8 billion (1969), $210 per capita
Agriculture: about self-sufficient in rice; main crops -- rice, corn, coconut,
sugarcane, abaca, tobacco
Major industries: agricultural processing, textiles, chemicals and chemical products
253
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Electric power: 2,201,000 kw. capacity (1970); 8.3 billion kw.-hr. produced
(1970) ; 216 kw.-hr. per capita
Exports: $855 million (f.o.b., 1969); copra, sugar, logs and lumber, coconut
oil, copper concentrates, abaca
Imports: $1,254 million (c.i.f., 1969)
Major trade partners: (1968) exports -- 45% U.S., 34% Japan; imports -- 32%
; U.S., 28% Japan
Aid:
economic -- U.S. (FY46-69), $1.5 billion committed; Japan (reparations), -
$550 million extended in 1956, $337 million drawn through July 1969; IBRD
(1953-68), $158 million committed;
military -- U.S. (FY46-68), $552.3 million committed
Monetary conversion rate: 6.43 pesos=US$1 (December, 1970) (floating rate)
Fiscal year: 1 July - 30 June *
GNP: $43.8 billion in 1970 at 1969 prices, $1,330 per capita; 1969 growth rate
4.6%
—~P Agriculture: self-sufficient for minimum requirements; main crops -- grain,
sugar beets, oilseeds, potatoes, exporter of livestock products and sugar;
importer of grains; 3,300 calories per day per capita (1968-69)
Major industries: chemistry, food processing, transportation equipment, machine
building, iron and steel, textiles, and shipbuildin
Crude steel: 11.8 million metric tons produced (1970), about 360 kg. per capita
*Excludes armed forces and other classified categories of employment.
255
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Exports: $3,548 million (f.o.b., 1970); 39% machinery and equipment, 33% fuels,
raw materials, and semimanufactures, 13% agricultural and food products,
16% industrial consumer goods
Imports: $3,608 million (f.0.b., 1969); 36% machinery and equipment; 48% fuels,
raw materials, and semimanufactures; 10% agricultural and food products;
6% industrial consumer goods
Major trade partners: $7,156 million (1970); 66% with Communist countries, 34%
with West (1969) %
Monetary conversion rate: 4 zlotys=US$1 (commercial); 40 zlotys=US$1 (noncommercial )
Fiscal year: same as calendar year; economic data are reported for calendar
years except for caloric intake which is reported for the consumption year,
1 July - 30 June','c682729ee88bfcabac569efbb73df96f05fabd551adf733c62263e64e522be43','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e387fdf5de3d3b49e902d6f73cc63e89f1f5f1094cfca0c4ad747a2494c8dfe',1971,'AU','Australia','economy',53,'GNP: less than $100 per capita
Agriculture: principal crops -- corn, rice, rubber, coffee, copra
Electric power: 2,000 kw. capacity (1970); 8 million kw.-hr. produced (1970);
13 kw.-hr. per capita
Exports: $2.6 million (f.o.b., 1967); coffee, copra
Imports: $5.2 million (c.i.f., 1967
Major trade partners: Portugal and its possessions, Singapore, and Hong Kong
Monetary conversion rate: Portuguese escudo known in Timor as pataca; 28.75
patacas=US$1
Fiscal year: calendar year
263
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $4.1 billion (FY69), $1,490 per capita
Agriculture: main crops -- sugar, coffee, tobacco, bananas
Major industries: textiles, clothing manufacture, food processing, petroleum
refining, petro-chemicals
Electric power: 1.2 million kw. capacity (1969); 5.9 billion kw.-hr. produced
(1969 est.); 2,010 kw.-hr. per capita
Exports: $1,535 million (f.0.b., 1969); sugar, pineapple, citrus fruits, coffee,
rum, textiles
Imports: $2,338 million (f.0.b., 1969); food, machinery, transportation equip-
ment, fuels, minerals
Major trade partner: U.S. 84% (1969)
Monetary conversion rate: uses U.S. currency
Fiscal year: 1 July - 30 June
265
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $65 million (1969 est.)
Agriculture: farming and grazing on small scale; commercial fishing increasing
in importance; most food imported; rice and dates staple diet
Major industries: oi] production and refining; crude oil production from onshore
and offshore averaged 362,000 bbls. per day in 1970; oi] revenues estimated
$122 million at the beginning of 1970, representing 99% of government/royal
family income; major development projects include $7 million harbor at Doha,
fertilizer plant, 2 desalting plants, refrigerated storage for fishing, and
a cement plant
Electric power: capacity 70,000 kw. (1970); 180 million kw.-hr. produced (1970);
2,190 kw.-hr. per capita
Exports: crude oi] dominates; reexports $56 million (1968)
Imports: approx. $53 million in 1969
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.21
Fiscal year: 1 April - 31 March
Agriculture: cash crops -- almost entirely sugarcane, small amounts of vanilla
and perfume plants; food crops -- tropical fruit and vegetables, manioc,
bananas, corn, market garden produce, also some tea, tobacco, and coffee;
food crop inadequate, most food needs imported
Major industries: 12 sugar processing mills, rum distilling plants, cigarette
factory, 2 tea plants, fruit juice plant, canning factory, a slaughterhouse,
and a number of smal] shops producing handicraft items
Electric power: 54,400 kw. capacity (1970); 108 million kw.-hr. produced (1970);
246 kw.-hr. per capita
Exports: $46.2 million (f.o.b., 1968); 84% Sugar, 10% perfume essences, 5% rum,
1% vanilla
Imports: $126 million (c.i.f., 1968); 45% manufactured goods, 30% food, beverages,
and tobacco, 20% machinery and transportation equipment, 5% raw materials
and petroleum products
Major trade partners: France (supplies 75% of Reunion''s imports, purchases 90%
of its exports); Madagascar (supplies 6% of its imports )
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: probably calendar year
269
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GDP: $1,223 million (1969 est.), $240 per capita; real growth rate 2.2%
Agriculture: main crops -- tobacco, corn, sugar, cotton, citrus fruits; live-
stock; self-sufficient in foodstuffs except wheat
Major industries: mining and steel, textiles
Electric power: 1,187,000 kw. capacity (1969); 5,580 million kw.-hr. produced
(1969); 1,160 kw.-hr. per capita
271
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Exports: $318 million (f.o.b., 1969), including net gold sales and reexports,
tobacco, asbestos, copper, clothing, meat, chrome, sugar
Imports: $279 million (f.o.b., 1969); textiles, machinery, petroleum products,
wheat, transport equipment
Major trade partners: South Africa, Portugal, and Portuguese territories
Aid: no substantial military or economic aid
Monetary conversion rate: 1 Rhodesian dollar=US$1.40 (official); 0.714 Rhodesian
dollar=US$1
Fiscal year: 1 July - 30 June ~
COMMUNI CATIONS :
Railroads: 1,610 mi. narrow gage (3''6"); 26 mi. double track
Highways: 49,385 mi.; 4,965 mi. paved, 18,350 mi. crushed stone, gravel,
stabilized soil, or improved earth; 26,070 mi. unimproved earth
Inland waterways: 175 mi. on Lake Kariba
Airfields: 281 total, 191 usable; 7 with permanent-surface runways; 1 with run-
Way over 12,000 ft., 22 with runways 4,000-7,999 ft.
Civil air: 11 major transport aircraft
Telecommunications: system is one of the best in Africa; consists of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Salisbury, secondary center Bulawayo; 122,100 telephones; 145,300 radio
and 50,000 TV receivers; 8 AM, no FM and 2 TY stations
272
ee EEE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 22 ROMANIA
LAND:
91,700 sq. mi.; 44% arable, 19% other agriculture, 27%
forested, 10% other (1969)
Limits of territorial waters: 12 n. mi.
GNP: $23.2 billion in 1970 (at 1969 prices), $1,140 per capita; 1970 growth rate
4.9%
Agriculture: net exporter; main crops -- corn, wheat, oilseed; livestock --
cattle, hogs, sheep; caloric intake, 3,000 calories per day per capita (1967-68)
Major industries: machinery, metals, fuels, chemicals, textiles, food processing,
timber processing
sie co iron ore, coking coal, metallurgical coke, cotton fibers, natural
rubber
Crude steel: 6.5 million metric tons produced (1970), 320 kg. per capita
273
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Exports: $1,633 million (f.o.b., 1969); 22% machinery and equipment; 40% fuels,
Gs oe semifinished products; 22% foodstuffs; and 16% consumer goods
1969
Imports: $1,741 million (mixture f.o.b. and c.i.f., 1969); 44% machinery and
equipment; 46% fuels, raw materials, semifinished products; 4% foodstuffs;
and 6% consumer goods (1969)
Major trade partners: $3,374 million in 1969; 45% non-Communist countries, 55%
Communist countries
Monetary conversion rate: 6 lei=US$1 (commercial); 12 lei=US$1 (noncommercial);
18 lei=US$1 (tourist)
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year, 1 July -
30 June
~
GLP: $150 million (1968), less than $40 per capita
Agriculture: cash crops -- mainly coffee, tea, cotton, some pyrethrum; main
food crops -- bananas, cassava; stock raising; self-sufficiency increasing
but country still imports some foodstuffs
Major industries: mining of cassiterite (tin ore), agricultural processing, and
light consumer goods
Electric power: 21,460 kw. capacity (1970); 100 million kw.-hr. produced (1970);
28 kw.-hr. per capita
Exports: $14.7 million (f.o.b., 1969); mainly coffee, tea, pyrethrum, cassiterite
Imports: $16.8 million (c.i.f., 1969); textiles, foodstuffs, machines, equipment
Major trade partners: U.S., Belgium, Congo (Kinshasa)
Aid: U.S., FY64-69, $6.6 million; Belgium, France, Germany, and Canada, FY64-67,
$33.4 million obligated
Monetary conversion rate: 100 Rwanda francs=US$1 (official)
Fiscal year: calendar year
275
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $727 million (FY69), $740 per capita
Agriculture: sugarcane, pineapple, rice; 65% self-sufficient
Major industries: sugarcane and pineapple processing; various light industries
Electric power: 419,000 kw. capacity (1970); 1.42 billion kw.-hr. produced
(1970); 1,439 kw.-hr. per capita
Exports: $90 million (f.o.b., FY69); sugar, pineapples
Imports: $378 million (c.i.f., FY69)
Major trade partners: Japan, U.S.
Aid: economic -- U.S. (FY46-69), $397 million committed
Monetary conversion rate: U.S. currency used
Fiscal year: 1 July - 30 June
277
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GDP: $14.0 million (1967), $230 per capita
Agriculture: main crops -- sugar on St. Kitts, cotton on Nevis
Major industries: sugar processing, salt extraction
Electric power: 147,500 kw. capacity (1969 est.); 260 million kw.-hr. produced
(1969 est.); 437 kw.-hr. per capita
Exports: $5.2 million (f.o.b., 1967); sugar, molasses, cotton, salt, copra
Imports: $9.4 million (c.i.f., 1967); foodstuffs, fuel, manufactures
Major trade partners: U.K. 45%, Canada 14%, U.S. 12% (1966)
Monetary conversion rate: 2.00 East Caribbean dollars=US$1
GDP: $28.2 million (1969), $230 per capita
Agriculture: main crops -- bananas, copra, sugar, cocoa, spices
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 4,565 kw. capacity (1969); 9.3 million kw.-hr. produced (1969
est.); 82 kw.-hr. per capita
Exports: $6.2 million (f.0.b., 1968); sugar, bananas, cocoa
Imports: $14.7 million (c.i.f., 1968); foodstuffs, machinery and equipment,
fertilizers, petroleum products
Major trade partners: U.K. 49%, Canada 9%, U.S. 8% (1964)
Monetary conversion rate: 2.00 East Caribbean dollars=US$1
GDP: $16.9 million (1969), $180 per capita
Agriculture: main crops -- bananas, arrowroot, coconut
Major industries: food processing
Electric power: 1,700 kw. capacity (1969); 5.1 million kw.-hr. produced (1969
est.); 53 kw.-hr. per capita
Exports: $3.7 million (f.o.b., 1968); bananas, arrowroot, copra, cotton
Imports: $1.0 million (c.i.f., 1968); fertilizer, flour, transportation
equipment, lumber, textiles
Major trade partners: U.K. 39%, U.S. 10%, Canada 10% (1967)
Monetary conversion rate: 2.00 East Caribbean dollars=US$1
Principal economic activities of San Marino are farming, livestock raising, light
manufacturing, and tourism; the government''s total budget for FY71 is about
$12 million, with the largest share of revenue derived from the sale of
postage stamps throughout the world and from payments by the Italian
government in exchange for Italy''s monopoly in retailing tobacco, gasoline,
and a few other goods; main problem is finding an additional $3 million to
finance badly needed water and electric power systems expansions
Agriculture: principal crops are wheat (average annual output about 4,400 metric
tons/year) and grapes (average annual output about 700 metric tons/year);
other grains, fruits, vegetables, and animal feedstuffs are also grown;
livestock population numbers roughly 6,000 cows, oxen, and sheep; cheese
and hides are most important livestock products
Electric power: obtained from Italy ;
Manufacturing: consists mainly of cotton textile production at Serravalle, brick mm °
and tile production at Dogane, cement production at Acquaviva, Dogane, and
Fiorentino, and pottery production at Borgo Maggiore; some tanned hides,
paper, candy, baked goods, Moscato wine, and gold and silver souvenirs are
also produced
Foreign transactions: dominated by tourism; in sunmer months 20,000 to 30,000
foreigners visit San Marino every day; a number of hotels and restaurants
have been built in recent years to accommodate them; remittances from
Sanmarinese abroad also represent an important net foreign inflow; commodity
trade consists primarily of exchanging building stone, lime, wood, chestnuts,
wheat, wine, baked goods, hides, and ceramics for a wide variety of consumer
manufactures -
Agriculture: dates, grains, livestock; not self-sufficient in food
Major industries: petroleum production 3.8 million barrels per day (1970); est.
payments to Saudi Arabian Government, $1,223 million in 1970; cement
production and small steel-rolling mill and oil refinery; several other
light industries, including factories producing detergents, plastic products,
furniture, etc.; PETROMIN, a semipublic agency associated with the Ministry
of Petroleum, has recently undertaken construction of a major fertilizer plant
Electric power: 290,000 kw. capacity (1970); 400 million kw.-hr. produced (1970);
100 kw.-hr. per capita
Exports: $2,185 million (f.o.b., 1970); 99% petroleum and petroleum products
Imports: $750 million (provisional) (c.i.f., 1970); manufactured goods, trans-
portation equipment, construction materials, and processed food products
Major trade partners: exports -- U.S., Western Europe, Japan; imports -- U.S.,
Japan, West Germany
Monetary conversion rate: 4.5 Saudi riyals=US$1 (IMF par value, freely convertible)
Fiscal year: follows Islamic year; the 1970-71 Saudi fiscal year covers the
period 2 September 1970 through 20 August 1971
287
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GDP: $824 million (1969, calculated at exchange rate prevailing after August
1969); real growth rate, 2% (per annum)
289
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Agriculture: main crops -- peanuts, millet, sorghum, manioc, rice; peanuts
primary cash crop; production of food crops increasing but still
insufficient for domestic requirements
Major industries: fishing, agricultural processing plants, light manufacturing,
mining
Electric power: 147,500 kw. capacity (1970); 284 million kw.-hr. produced (1970);
70 kw.-hr. per capita
Exports: $115 million (f.0.b., 1969); approx. 50% peanuts and peanut products;
phosphate rock; canned fish *
Imports: $185 million (c.i.f., 1969); food, consumer goods, machinery, transport
equipment
Major trade partners: France, EEC (other than France), and franc zone
Aid: France major donor, economic (1964-67) $93.1 million; U.S. military and :
economic (1962-69) $34.5 million; U.S.S.R. $6.7 million Joan negotiated; ie
EEC economic (1962-69) $98.5 million ae
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$]1
Fiscal year: 1 July - 30 June
Agriculture: islands depend largely on coconut production and export of copra;
cinnamon, vanilla, and patchouli (used for perfumes) are other cash crops;
food crops -- small quantities of sweet potatoes, cassava, Sugarcane, and
bananas; islands not self-sufficient in foodstuffs and the bulk of the
supply must be imported
Major industries: processing of coconut and vanilla, fishing, small-scale
manufacture of consumer goods, coir rope factory, tea factory
Electric power: 1,700 kw. capacity (1970); 4.5 million kw.-hr. produced (1970);
86 kw.-hr. per capita
Exports: $3 million (f.0.b., 1968); cinnamon (bark and oil) and vanilla account
for almost 50% of the total, copra accounts for about 40%, the remainder
consisting of vanilla, patchouli, fish, and guano
Imports: $6.3 million (c.i.f., 1968); food, tobacco, and beverages account for
about 40% of imports, manufactured goods about 25%, machinery and transport
equipment, petroleum products, textiles
Major trade partners: exports -- India, U.S.; imports -- U.K., Burma, India,
South Africa, Kenya, Australia
Aid: $1.2 million in aid in both 1965 and 1966 from U.K.
Monetary conversion rate: 5.4 Seychelles rupees=US$1
Fiscal year: calendar year
291
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
GNP: $390 million (1969), approx. $150 per capita
Agriculture: main crops -- palm kernels, rice, yams, millet, cassava; much of
cultivated land devoted to subsistence farming; food crops insufficient for
domestic consumption
Major industries: mining -- diamonds, iron ore, bauxite, rutile; manufacturing
-- beverages, textiles, cigarettes, construction goods
Electric power: 45,000 kw. capacity (1970); 125 million kw.-hr. produced (1970);
50 kw.-hr. per capita
293
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d): .
Exports: $107 million (f.o.b., 1969); 69% diamonds; iron ore, palm kernels, cocoa,
coffee “
Imports: $11] million (c.i.f., 1969); machinery and transportation equipment,
manufactured goods, foodstuffs, petroleum products
Major trade partners: U.K., EEC, Japan, U.S., Communist countries
Monetary conversion rate: 1 leone=US$1.20 (official); 0.833 leone=US$1
Fiscal year: 1 July - 30 June (since 1 July 1966)
GNP: $1.7 million (1969), $840 per capita; 11% average annual real growth
Agriculture: occupies a position of minor importance in the economy, main crops
-- poultry, hogs, small truck farming; food shortages -- grains, sugar,
dairy products
Major industries: rubber processing and rubber products, processed food and
beverages, electronics, ship repair, entrepot trade
Electric power: 595,000 kw. capacity (1970); 3.2 billion kw.-hr. produced (1970);
1,059 kw.-hr. per capita
Exports: $1.6 billion f.o.b., oro}: almost 90% reexports; rubber, fuels, food
Imports: $2.5 billion c.i.f., 1970); over 40% goods reexported
Major trade partners: exports -- Malaysia, Indonesia, U.S., Japan, U.K.;
imports -- Malaysia, Japan, Indonesia, Communist China, U.K., U.S.
295
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Aid: U.K. -- (1960-September 1969) $254 million disbursed; (1969-73) $120
million extended; IBRD -- (1963-June 1970) $111 million committed, $61
million disbursed
Monetary conversion rate: 3.06 Singapore dollars=US$1
Fiscal year: converted to | April - 31 March fiscal year on 1 April 1970;
formerly -on calendar year basis
GDP: $137 million (1968 est.), about $50 per capita
Agriculture: mainly a pastoral country; main crops -- bananas, livestock,
sugarcane, cotton, cereals
Major industries: a few small industries, including a sugar refinery, tuna
and beef canneries, iron rod plant
Electric power: 13,000 kw. capacity (1970); 31 million kw.-hr. produced (1970);
10 kw.-hr. per capita
Exports: $34.5 million (f.o.b., 1969, est.); bananas, livestock, hides, skins
Imports: $46.9 million (c.i.f., 1969, est.); textiles, cereals, transport
equipment
Major trade partners: Italy and U.K.; Arab countries; $6.9 million imports from
Communist countries (1965)
Monetary conversion rate: 7.143 Somali shillings=US$1 (official)
Fiscal year: 1 January - 3] December
GNP: $15.8 billion (1969), $800 per capita; real growth rate 10% (1969)
Agriculture: main crops -- corn, wool, dairy products, wheat, sugarcane,
tobacco, citrus fruits; self-sufficient in foodstuffs
299
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Major industries: mining, automobile assembly, metal working, machinery,
textiles, iron and steel, chemical, fertilizer, fishing
Electric power: 11,635,000 kw. capacity (1970); 55 billion kw.-hr. produced
(1969) ; 2,700 kw.-hr. per capita
Exports: $2.1 billion (f.o.b., 1969 excluding gold); wool, diamonds, corn,
uranium, sugar, fruit, hides, skins, metals, metallic ores, asbestos,
fish products; gold output $1.7 billion (1970)
Imports: $3.6 billion (f.0.b., 1970); motor vehicles, machinery, metals,
petroleum products, textiles, chemicals
Major trade partners: U.K. and other Commonwealth nations, U.S., Germany, Japan
Aid: no substantial military or economic aid
Monetary conversion rate: 1 SA Rand=US$1.40 (official); 0.714 SA Rand=US$1
Fiscal year: 1 April - 31 March
Agriculture: livestock raising (cattle and sheep) predominates, subsistence
crops (millet, sorghum, corn, and some wheat) are raised but most food
must be imported
Major industries: meatpacking, fish processing, copper, lead, and diamond
mining, dairy products
Electric power: 95,200 kw. capacity (1969); 285 million kw.-hr. produced (1969);
463 kw.-hr. per capita
Aid: South Africa is only major donor
Monetary conversion rate: 1 South African Rand=US$1.40 (official); 0.714 SA 7
Rand=US$1
Fiscal year: 1 April - 31 March
COMMUNICATIONS: a
Railroads: 1,454 mi., all 3''6" gage, single track
Highways: 21,000 mi.; 2,344 mi. bituminous treated, 220 mi. gravel and 18,436 mi.
earth road and tracks
Ports: 1 major, 1 minor
Civil air: 3 major transport aircraft (registered in South Africa)
Airfields: 116 total, 91 usable; 10 with permanent-surface runways; 4 with
runways 8,000-11,999 ft., 38 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: system is a meager combination of open-wire lines, a single
short radio-relay link, and scattered radiocommunication stations; Windhoek
is the center; 32,100 telephones; unknown number of radio receivers; no
AM, 1 FM, and no TV stations
DEFENSE:
Defense is responsibility of Republic of South Africa
302
aoe anne nna ermal
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
NIS 9 SPAIN
LAND:
195,000 sq. mi., including Canary (2,900 sq. mi.) and 1. eo! © pos.
Rep ‘GER.
Balearic Islands (1,940 sq. mi.); 41% arable and
land under permanent crops, 27% meadow and pasture,
22% forest, 10% urban or other (1969)
Limits y territorial waters: 6 n. mi. (fishing, 12 n.
mi.
GNP: $10 million (1966 est.), less than $100 per capita
Agriculture: cocoa, bananas, copra; staple foods include taro and coconuts,
supplemented by bananas and bread fruit
Electric power: 6,900 kw. capacity (1970); 16.7 million kw.-hr. produced (1970);
113 kw.-hr. per capita
Exports: $6 million (1969); copra, cocoa, bananas
Imports: $10 million (1969)
Major trade partners: exports -- New Zealand, the Netherlands, U.K.; imports
-- New Zealand, Australia, U.K., U.S.
Aid: New Zealand, $2.5 million committed; U.S., $1.5 million extended (FY67-69)
Monetary conversion rate: .719 tala=US$1
Agriculture (all outside Aden): cotton is main cash crop; cereals, dates, Kat
(qat), coffee, and livestock are raised and there is a small fishing
industry; large amount of food must be imported (particularly for Aden) ;
cotton, hides, skins, dried and salted fish are exported
Major industries: petroleum refinery (178,000 bbIs. per day capacity, 1969) at
Little Aden operates on imported crude; oi] exploration activity
Electric power: 108,000 kw. capacity (1970); 190 kw.-hr. produced (1970); 166
kw.-hr. per capita
Major trade partners: Yemen, East Africa, but some cement and sugar imported from
Communist countries; crude oi] imported from Persian Guif, exported mainly
to U.K. and Japan
Monetary conversion rate: 1 S. Yemeni dinar=US$2.40
Fiscal year: 1 April - 31 March
*Includes Aden and 16 members of the former Protectorate of South Arabia.
**Excluding the islands of Perim and Kamaran for which no data are available.
359
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Agriculture: sorghum and millet, gat (a mild narcotic), cotton, coffee, fruits
and vegetables; largely self-sufficient in food
Major industries: cotton textiles and leather goods produced on a small scale;
handicraft and some fishing; small aluminum products factory
Electric power: 4,000 kw. capacity (1970); 8 million kw.-hr. produced (1970);
2 kw.-hr. per capita
Exports: about $6 million (1966), qat, cotton, coffee, hides, vegetables
Imports: about $17 million (1966), textiles and other manufactured consumer goods,
petroleum products, sugar, grain, flour, other foodstuffs, and cement
Major trade partners: exports -- over half to or through Aden, one-third to
Communist countries; imports -- Aden, Communist countries (20%), U.A.R.,','734235f7bf7e49b261dd37d0d911824c823540d3d2309f7668a69e426f7952e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ea341f286ba6ad62c39d5627f082b22c318ce5e04cbdf2ce17b4060515569a9',1971,'JP','Japan','economy',55,'Monetary conversion rate: approx. 1.25 Yemeni rials=US$1 January 1967 (official);
about 2.92 Yemeni rials=US$1 January 1967 (free market)
Fiscal year: 1 July - 30 June
GNP: $17.7 billion (est.) in 1970 (at 1968 prices), $860 per capita; 1970 growth
rate approx. 5.5%
Agriculture: diversified agriculture with many small private holdings and large
agricultural combines; main crops -- corn, wheat, tobacco, sugar beets, and
sunflowers; generally a net exporter of foodstuffs and live animals; self-
sufficient in food except for tropical products, cotton, wool, and vegetable
meal feeds; caloric intake, 3,210 calories per day per capita (1967)
Major industries: metallurgy, machinery and equipment, textiles, wood
processing, food processing
Shortages: fuels, steel, textile fibers
Crude steel: 2,228 million metric tons produced (1970), 109 kg. per capita
Exports: $1,679 million (f.0.b., 1970); 19% foodstuffs and tobacco; 16% raw
materials, fuels, and chemicals; 23% machinery and equipment; 42% other
manufactures
Imports: $2,874 million (c.i.f., 1970); 7% foodstuffs and tobacco; 26% raw
materials, fuels, chemicals; 33% machinery and equipment; 34% other
manufactures
Major trade partners: $4,553 million (1970); 75% non-Communist countries (37%
Common Market, 5% U.S., 31% other non-Communist countries), 25% Communist
countries
Aid: postwar credits extended mainly by the U.S. ($2.9 billion, including grants
and $700 million in military aid); Western Europe (over $750 million); IBRD
($377 million); IMF ($262 million); Communist countries extended credits
totaling $464 million in 1956 ($125 million drawing balance suspended in 1958)
and $140 million during 1962-66; Yugoslavia has extended credits
totaling about $600 million to 27 less developed countries of Africa, Asia,
and Latin America
Monetary conversion rate: 15 dinars=US$1, effective 24 January 1971 in
conjunction with currency reform (1 new dinar=100 old dinars)
Fiscal year: same as calendar year (all data refer to calendar year or to middle
or end of calendar year as indicated)
GNP: $1.6 million (1969 est.), $390 per capita; real growth rate 13% between 1965
and 1969
Agriculture: main crops -- corn, tobacco, cotton; net importer of all major
agricultural products
Major industries: copper mining and processing
Electric power: 788,200 kw. capacity (1970); 3,527 million kw.-hr. produced
(1970) ; 840 kw.-hr. per capita
Exports: $1,073 million (f.o.b., 1969); copper, zinc, cobalt, lead, tobacco
Imports: $436 million (f.o.b., 1969); consumer goods, machinery, transport
equipment, foodstuffs, fuels
Major trade partners: U.K., South Africa, Japan, Western Europe
365
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010001-2
ECONOMY (cont''d):
Aid:
economic -- Communist China $200 million credit for Tanzam railroad (1970);
(1964-67) U.K. $63 million (1966); IBRD $99 million (1970); U.S. $12 million;
U.S.S.R. $6 million; Communist China extended $19 million;
military -- $9 million (1964-69), mainly U.K. and Canada
Monetary conversion rate: 1 Zambia kwache=US$1.40 (official), 0.714 Zambia
kwacha=US$1
Fiscal year: calendar year','2727367b0bf7a378ec2989330262d01a7ebd99716fffaf761278b5846d478ac2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f4d1796bee2e2d199c79da0e3eec4e98214c04c40f9e6e0f4857fd42550ecd4',1971,'US','United States','economy',62,'GNP: $976.5 billion (1970); 63.1% consumption, 13.9% investment, 22.6% government,
$4,725 per capita; 1970 growth rate
Crude steel: 128 million metric tons produced (1969)
Electric power: 331,905,000 kw. capacity (1969); 1,552,299 million kw.-hr.
produced (1969); 7,620 kw.-hr. per capita
Exports: $38,005 million (f.o.b., 1969); machinery and transport equipment,
chemicals, cereals, mineral fuels
Imports: $36,043 million (c.i.f., 1969); transport equipment, machinery, mineral
fuels, steel, nonferrous metals, metal ores
Major trade partners: (1968) Canada 26%, EEC 17%, Japan 11%, U.K. 6%
Official development assistance: total $3,328 million (1969)
Fiscal year: 1 July - 30 June','17eb622985ebd81d1211203e982d58dbc81a0f9fafdb7d8526a88a20608470f8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010001-2','txt','0dc8dc8a5e789b70ba4a147ae08feb4411f7aec7acd6938688c0c07588d59b13','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010001-2/cia-rdp79-01051a000400010001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cf5b0047ae0fc86e53bc7c4e0c28679dfd9c041c1fe39110f12aa7e20f6e090',1971,'','','economy',3,'GNP: $1.0 billion (1969-70), less than $100 per capita; real growth rate 3%
(1969-70)
Agriculture: agriculture and animal husbandry account for over 50% of GNP and
occupy nearly 90% of the labor force; main crops -- wheat, cotton, fruits,
nuts; largely self-sufficient; food shortages -- sugar, tea, wheat
Major industries: cottage qndustries, food processing, textiles, cement, coal
mining
Electric power: 254,000 kw. capacity (1969); 410 million kw.-hr. produced
(1969), 26 kw.-hr. per capita
Exports: $81 million (f.0.b., 1969-70); fruits and nuts, karakul, cotton, wool,
natural gas
Imports: $135.0 million (c.i.f., 1969-70); textiles, sugar, tea, petroleum,
transportation equipment
Major trade partners: exports -- Ue Ss5 Uskss
about half from U.S.5S.R.
Monetary conversion rate: 45 Afghanis per US$1 (official); 89.69 Afghanis per
US$1 (July 1971)
Fiscal year: 21 March - 20 March
U.S.S.R., and India; imports -~
GNP: $0.8 billion in 1970 (at 1969 prices), $400 per capita
Agriculture: food deficit area; main crops -- corn, wheat, tobacco, sugar beets,
cotton; food shortages -- wheat; caloric intake, 2,100 calories per day per
capita (1961/62)
Major industries: agricultural processing, textiles and clothing, lumber, and
extractive industries
Shortages: spare parts, machinery and equipment, wheat
Exports: $80 million (1969 est.); 1964 trade -- 55% minerals, metals, fuels;
17% agricultural materials (except foods); 23% foodstuffs (including
cigarettes); 5% consumer goods
3
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (coffPayeves For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Imports: $143 million (1969 est.); 1964 trade -- 50% machinery, equipment, and
spare parts; 16% minerals, metals, fuels, construction materials; 7%
fertilizers, other chemicals, rubber; 4% agricultural materials (except
foodstuffs); 16% foodstuffs; 7% consumer goods
Monetary conversion rate: 5 leks=US$1 (commercial); 12.5 leks=US$1 (noncommercial )
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year
1] July - 30 June
Agriculture: main crops -- bread grains, wine, citrus fruits
Major industries: petroleum (1970 crude production 47 million tons), light
industries, natural gas, mining, petrochemical and steel plants under
construction
Electric power: 1,462,000 kw. capacity (1970); 1,536 million kw.-hr. produced
(1970), 110 kw.-hr. per capita
5
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cofPRsoved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Monetary conversion rate: 4.937 dinars=US$1 (prior to 15 August 1971); currently
1 dinar=1.12 French francs, dollars converted at free market rate
Fiscal year: calendar year
Agriculture: sheep raising; small quantities of tobacco, rye, wheat, barley,
oats, and some vegetables (only 25% of land can be used for agricul ture)
Major industries: tourism (800,000 in 1965), one cigarette factory (annual
output $800,000), handicrafts, smuggling (tobacco to France; manufactured
jtems, including automobiles and cameras, to Spain)
Shortages: food .
Electric power: 25,000 kw. capacity (1970); 100 million kw.-hr. produced (1970),
400 kw.-hr. per capita; power is mainly exported to Spain and France
Major trade partners: Spain, France
GNP: $1,100 million (1969 est.), about $200 per capita
Agriculture: cash crops -- coffee, sisal, corn, cotton, sugar, manioc, and
tobacco; food crops -- Cassava, Corn, vegetables, plantains, bananas, and
other local foodstuffs; largely self-sufficient in food
Fishing: catch 293,000 tons (1968); exports 73,000 tons, $11 million (1968)
Major industries: mining (iron, oil, diamonds), fish processing, brewing, tobacco,
Sugar processing, cement, food Processing plants, building construction
Electric power: 433,000 kw. capacity (1970); 694 million kw.-hr. produced
(1970), 125 kw.-hr. per capita
Approved For Release 2004/08/31 : SIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A00 :
ECONOMY (Cont''d): “PP A000400010002-1
Exports: $422.6 million (f.o.b., 1970); coffee (50%), diamonds, sisal, fish and
fish products, iron ore, oi], timber, and corn
Imports: $326.6 million (c.i.f., 1970); capital equipment (machinery and electrical
equipment), wines, bulk iron and ironwork, steel and metals, vehicles and
spare parts, textiles and clothing, medicines
Major trade partners: main partner Portugal, followed by West Germany, U.S.,
U.K., EC countries (primarily coffee to last three)
Aid: Portugal only donor
Monetary conversion rate: 28.75 escudos=US$1 (official)
Fiscal year: calendar year
GDP: $27.2 million (at factor cost, 1967 est.), $470 per capita
Agriculture: main crops -- sugar, cotton
Major industries: sugar processing, tourism
Shortages: electric power
Electric power: 14,040 kw. nameplate capacity (1970); less than 4,000 kw. operating;
12 million kw.-hr. produced (1969 est.}), 189 kw.-hr. per capita
Exports: $2.9 million (f.o.b., 1967); sugar, molasses, cotton
Imports: $22.2 million (c.i.f., 1967); food, clothing, oil, wood
Major trade partners: U.K. 30%, U.S. 25%, Commonwealth Caribbean countries
18% (1966)
Monetary conversion rate: 1.93 East Caribbean dollars=US$1 (6 October 1971)
11
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A
COMMUNICATIONS pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: 235 mi. 150 mi. main, 85 mi. secondary
Ports: 1 minor
Civil air: 8 major transport aircraft
Airfields: 3 total, | usable; 1 with asphalt runway 9,000 ft.; 1 seaplane
station
Telecommunications: new automatic telephone system recently installed; 1,450
telephones ; tropospheric scatter 1inks with Tortola and St. Lucia; 5,000
radio receivers, 1 AM and 2 TV stations; 2 coaxial submarine cables
12
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
*
NIS approved For Release 2004/08/34. GlAFRDP79-01051A000400010002-1
LAND:
1,070,000 sq. mi.; 57% agricultural (11% crops, improved \\
pasture and fallow, 46% natural grazing land), 25% BRAZIL
forested, 18% mountain, urban, or waste (1968 est.)
Land boundaries: 5,850 mi.
WATER:
Limits of territorial waters: 200 n. mi.
Coastline: 3,100 mi.
GNP: $31.3 billion (purchasing power parity estimate, 1970), $1,290 per capita;
real growth rate 1970, 4.9%; 68% private consumption, 12% public consumption,
18% gross domestic investment, 2% net foreign balance (1968)
Agriculture: main products -- cereals, oilseeds, livestock products; Argentina
is a major world exporter of temperate zone foodstuffs
Fishing: catch 202,800 metric tons, $15,486,000; exports $1,158,000, imports
$3,659 ,000
Major industries: food processing (especially meatpacking), motor vehicles,
consumer durables, textiles, chemicals, printing, and metallurgy
Crude steel: 1.82 million metric tons produced (1970); 70 kilograms per capita
Electric power: 6,318,000 kw. capacity (1970); 20.9 billion kw.-hr.
produced (1970), 853 kw.-hr. per capita
Exports: $1,750 million (f.o.b., 1970) -- meat, wheat, corn, wool, hides, oil-
seeds
Imports: $1,550 million (c.i.f., 1970) -- machinery and vehicles, fuel and
lubricating oils, iron and steel, textiles, intermediate industrial products
Major trade partners: exports -- EC 37%, LAFTA 25%, U.S. 11%, U.K. 8%;
imports -- EC 24%, LAFTA 24%, U.S. 23%, U.K. 7%
Aid: economic -- extensions from U.S. (FY46-70), $764.4 million in loans;
$17.6 million in grants; from international organizations (FY46-70), $860.3
million; from other Western countries (1960-66), $315.5 million; from
Communist countries (1954-70) $86.0 million (drawn, $41.0 million);
military -- assistance from U.S. (FY46-70), $129.6 million
Monetary conversion rates: commercial -- 5.00 pesos = US$1; financial -- floating
(6.35 pesos = US$1 on 29 September 1971)
Fiscal year: calendar year
GNP: $15.0 billion (1970), $2,035 per capita; 56.1% consumption, 29.3% investment,
14.4% government, 2% net exports of goods and services; 1970 growth rate 7.1%
1964 constant prices
Agriculture: livestock, cereals, potatoes, sugar beets; 84% self-sufficient;
caloric intake 2,920 calories per day per capita (1967-68)
Fishing: catch 4,000 metric tons, $3,846,000 (1968); exports $494,000 (1968),
imports $23,514,000 (1968)
Major industries: foods, fron and steel, machinery, textiles, chemicals,
electrical, paper and pulp
17
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cdabRypved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ae steel: 4.1 million metric tons produced (1970), 550 kilograms per capita
1970) -
Electric power: 7,530,000 kw. capacity (1970); 30,036 million kw.-hr produced
(1970), 3,460 kw.-hr. per capita
Exports: $2.86 billion (f.o.b., 1970); iron and steel products, machinery and
equipment, lumber, textiles and clothing, paper products, chemicals
Imports: $3.55 billion (c.i.f., 1970); machinery and equipment, chemicals,
textiles, coal, petroleum, foodstuffs
Major trade partners: (1970) West Germany 33%, Italy 8%, Switzerland 9%,
U.K. 6.5%, U.S. 4%; EC 49%; EFTA 23%; Communist countries 11%
Aid:
economic -- received - U.S. $1,166.9 million authorized through FY70; IBRD
$104.9 million authorized, none since FY62;
military -- U.S., $113.2 million authorized (FY52-70); net official economic
aid to less developed areas and multilateral agencies -- $189 million
(FY60-70), $24.2 million in FY70
Monetary conversion rate: 24.75 shillings=US$1 (official)
Fiscal year: calendar year
GNP: not available
Agriculture: main crops -- fruits, vegetables
Major industries: tourism, cement, oi] refining, lumber, salt production
Electric power: 59,750 kw. Capacity (1970); 247.5 million kw.-hr. produced
(1969 est.), 1,095 kw.-hr. per capita
Exports: $89.6 million (f.0.b., 1970); fuel oi1, cement, rum, pulpwood, fruits,
and vegetables
Imports: $337.5 million (c.i.f., 1970); foodstuffs, manufactured goods, crude oi]
Major trade partners: exports -- U.S. 61%, U.K. 22%, other 17%; imports -- U.S.
68%, U.K. 9%, Italy 6%, Canada 4%, other 13%
Aid: economic -- authorizations from U.S. (FY56-70) -- $38.6 million in loans,
$0.3 million in grants
Monetary conversion rate: 1.00 Bahamian dollars (B$)=US$1 (20 August 1970)
Fiscal year: calendar year
Agriculture: produces dates, alfalfa, vegetables; dairy and poultry farming;
fishing; not self-sufficient in food
Major industries: petroleum refining, boatbuilding, shrimp fishing, and
sailmaking on a smal] scale; major development projects include aluminum
smelter, flourmil], and ISA town
Electric power: 108,000 kw. capacity (1970); 270 million kw.-hr. produced (1970),
1,250 kw.-hr. per capita
Imports: $168 million (1970)
Major trade partners: U.K., Japan, U.S., EC
Aid: economic -- multilateral western $360,000 (annual average 1967-69)
Monetary conversion rate: 1 Bahrain dinar=US$2.10 (official)
Fiscal year: 1 April - 31 March
GDP: $117 million (1969), $460 per capita; real growth rate 1969, 3.3%
Agriculture: main products -- sugar, subsistence foods
Major industries: tourism, sugar milling, manufacturing, edible oils and fats
Electric power: 39,950 kw. capacity (1969, est.); 143.7 million kw.-hr. produced
(1969 est.), 595 kw.-hr. per capita
Exports: $39.8 million (f.0.b., 1970); sugar, molasses, rum
Imports: $116.3 million (c.i.f., 1970); foodstuffs, lumber, machinery, manufactured
goods
Major trade partners: exports -- U.K. 38%, U.S. 21%, CARIFTA 19%, other 22%;
imports -- U.K. 29%, U.S. 22%, Canada 11%, CARIFTA 11%, other 27%
23
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (Cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Aid: economic -- extensions from U.S. (FY67-70), $0.1 million in grants; from
international organizations (FY63-70), $0.7 million
Monetary conversion rate: 1.93 East Caribbean dollars=US$1
Fiscal year: 1 April - 31 March','a408b537f35ea9e83a1081fcb7d1e1d6bb98972ab451b7a097713f02bd37f5e1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88b2a02977a6fb071566a25d5d503c26781b11d93d3a9a98ac133ff429cc6eae',1971,'BR','Brazil','economy',14,'GNP: $1.3 billion (purchasing power parity estimate, 1970), $270 per capita;
78% private consumption 11% public consumption » 13% gross domestic
investment, ~ ¥ net foreign balance (1970) 5 real growth rate 1970; 3%
Agriculture: main crops ~~ potatoes » corn, rice, sugarcane » yucca, bananas 3
imports significant quantities of foodstuffs including lard, vegetable oils;
and wheat; caloric intake, 2,100 calories per day per capita (1966)
Major industries: minings smelting, petroleum refining, food processing,» textiles,
and clothing
Electric power: 981,000 kw. capacity (1970); 730 million kw.-hr. produced
Exports: $192.0 million (f.0.b-.> 1970); tin, petroleum, (eads Zincser ers
tungsten » antimony » bismuth, gold, coffee, and sugar
Imports : $157.7 milion (f.0.b.> 1970); foodstuffs » chemicals» capital goods 5
pharmaceuticals
Major trade partners: exports -~ U.K. 42%, U.S. 37%, Argentina 5% 3
imports -- U.S. 31%, West Germany 12%, Japan 16%, Argentina 10% (1969)
Aid:
economic —~ extensions from U.S. (FY46-70) $1 226.7 million in loans; $298.5
million in grants 3 from international organizations (FY46-68) » $107.2
million; from other Western countries (1960-66) » $12.6 millions
military -~ assistance from U.S. (FY58-70) » $23.9 million
Monetary conversion rate: 11.88 pesos=US$1 (selling rate)
Fiscal year: calendar year
COMMUNICAT LONS :
Railroads : 2,310 mi.» single track; 25290 mi., meter gage > 20 mi.» 2''6'' 9age>
all government owned except 60 mi. of meter- gage track; 9.6 mi. of meter-
gage track electrifie
Highways : 15,000 mi. 500 mi. paved, 3,500 mi. gravel»
earth, 6,000 mi. unimproved earth
Inland waterways : officially estimated to be 6,250 mi. of commercial ly
navigable waterways
Pipelines: crude oil, 1,044 mi. refined products and crude 888 mi. natural gas
20 m.
Ports: none (Bolivian cargo moved through Arica and Antofagasta » Chile, and
5,000 mi. improved
Civil air: 28 major transport aircraft
Airfields: 464 total, 399 usable; 3 with permanent-surface runways; | with
runway over 12,000 ft., 3 with runways 8 000-11 .999 €t., 81 with runways
4000-7 ,999 ft.
Telecommuni cations: poorest telecom facilities on continent with local and
intercity networks needing rehabilitation; almost 38 ,000 telephones 3 est.
750 ,000 radio and 10 ,000-15 ,000 Ty receivers; 1 Tv, 72 AM, and 6 FM stations;
long-range improvement plans revised and partly implemented
DEFENSE FORCES:
Military budget: proposed for fiscal year ending 31 December 1971, $15.9 millions
about 9% of proposed central government budget
Approved F
or Release 2004/08/34 : CIA-RDP79-01051A000
- 400010002-1
NIS 4pproved For Release 2004/08/31 ‘pear RPP 79-01051A000400010002-1
LAND:
11,800 sq. mi.; 53% agricultural land, of which about
half is in crops, the rest meadows and pastures, 27%
waste, urban, or other; 20% forested (1968)
Land boundaries: 860 mi.
WATER:
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Coastline:. 40 mi.
PEOPLE: is ALGERIA
Population: 9,736,000, average annual growth rate 0.5% =
(January 65-71); males 15-49, 2,247,000; 1,795,000 fit
for military service; average number reaching military
age (19) annually 71,000
Ethnic divisions: 55% Flemings , 33% Walloons, 12% mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch); divided along ethnic lines
Literacy: 97%
Labor force: 3.9 million; 5.5% agriculture, forestry, hunting, and fishing, 43%
mining, manufacturing and construction, 39% commerce and services, 8%
transportation, 1.8% insured unemployed; no shortage of unskilled labor
Organized labor: 48% of labor force (1969)
GNP: $25.7 billion (1970), $2,640 per capita (1970), 62% consumption,
23% investment, 14% government, 1% net exports of goods and services;
1970 growth rate 5.5%, 1963 constant prices
25
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A d : 7 a is
ECONOMY (cont''d): pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Agriculture: livestock production predominates; main crops -- grains, beets,
potatoes; 80% self-sufficient in food; food shortages -- edible and coarse
grains, fats and oils; caloric intake, 3,150 calories per day per capita
(1967-68 est.)
Fishing: catch 58,700 metric tons, $16,766,000 (1969); exports $14,973,000
(including Luxembourg, 1969), imports $76,200,000 (including Luxembourg, 1969)
Major industries: engineering and metal products, processed food and beverages,
chemicals, basic metals, textiles, and petroleum
Shortages: iron ore, nonferrous minerals, petroleum, cotton, wool, wood
Crude steel: capacity 14.3 million metric tons (1969); 12.6 million metric tons
produced (1970); 1,310 kilograms per capita
Electric power: 6,855,000 kw. capacity (1970); 29,306 million kw.-hr. produced
(1970), 2,910 kw.-hr. per capita
Exports: $11,600 million (f.0.b., 1970) motor vehicles, refined copper, iron and
steel products, finished or semifinished precious stones, textile products
Imports: $11,350 million (c.i.f., 1970) crude materials, food, fuels, automotive
parts, nonelectrical machinery and appliances, clothing
Major trade partners: (Belgium-Luxembourg Economic Union, 1970) West Germany
24.0%, Netherlands 17.1%, France 18.5%, U.S. 7.4%, U.K. 4.7%, Italy 4.2%;
EC 63.8%, EFTA 10.9%, Communist countries 1.7%.
Aid:
economic -- received - U.S., $767.4 million authorized (FY46-70); none
since FY/0;
military -- received - $1,253.6 million authorized (FY46-69), $1.9 million
in FY68, none since FY68; net official economic aid to less developed areas
and multilateral agencies -- $1,003.6 million (FY60-70), $119.6 million in 1970
Monetary conversion rate: 50 francs=US$1 (official IMF rate), as of 30 September
1971 the actual rate was 47.01 francs=US$1
Fiscal year: calendar year
GNP: not available
Agriculture: main products -- bananas, vegetables, Easter lilies, dairy products,
citrus fruits
Major industries: tourism, ship repair, small boat building
Electric power: 51,740 kw. capacity (1969); 181.6 million kw.-hr. produced (1969),
3,425 kw.-hr. per capita
Exports: $70.0 million (f.o.b., 1969); mostly reexports of drugs and bunker fuel
Imports: $85.5 million (c.i.f., 1969); fuel, foodstuffs, machinery
Major trade partners: U.S. 46%, U.K. 22%, Canada 9% (1968)
Monetary conversion rate: 1 Bermuda dollar=US$1 (14 August 1971)
Fiscal year: 1 April-317 March
GNP: under $100 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Electric power: 400 kw. capacity
Exports: about $1 million annually; rice, dolomite, and handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic -- India (FY61-68) $35.2 million
Monetary conversion rate: 7.5°Indian rupees =US$1
Fiscal year: 1 April - 31 March
Agriculture: principal crops are corn and sorghum; livestock raised and exported
Major industries: livestock processing, mining of asbestos, manganese
Electric power: 8,000 kw. capacity (1970); 0.3 million kw.-hr. produced (1970),
.5 kw.-hr. per capita
Exports: $18.3 million (f.o.b., 1969); cattle, animal products, minerals
Imports: $43.1 million (f.o.b., 1969); foodstuffs, vehicles, textiles
Major trade partner: South Africa
33
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (céhppspved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Monetary conversion rate: 1 SA Rand=US$1.40 (Botswana uses the South African
Rand) (official); 0.714 SA Rand=US$1
Fiscal year: 1 April - 31 March
GNP: $42.7 billion (purchasing power parity estimate, 1970), $460 per capita;
17% gross investment, 83% consumption (est. 1970); real growth rate 1970, 9.5%
Agriculture: main products -- coffee, rice, beef, corn, milk, Sugarcane, beans;
aeey self-sufficient; caloric intake, 2,900 calories per day per capita
1962
Fishing: catch 500,000 metric tons (1968); exports $10.2 million, imports $28.6
million
Major industries: textiles and other consumer goods, cement, lumber, steel,
motor vehicles, other metalworking industries
Crude steel: 5.5 million metric tons capacity (1970 est.); 5.4 million metric
tons produced (1970); 60 kilograms per capita (1970)
35
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (c ths : ‘j by 3
1, Scombptdved For eae i anaes 1A 04? 9.405 {A000 200010002 A edueed
(1970), 503 kw.-hr. per capita
Exports: $2,740 million (f.o.b., 1970); coffee, manufactures, iron ore, cotton,
sugar, wood, cocoa
Imports: $2,526 million (f.o.b., 1970); machinery, chemicals, pharmaceuticals,
petroleum, wheat
Major trade partners: exports -- U.S. 23%, West Germany 10%, Italy 7%, Argentina
7%, Netherlands 6%, Japan 5%, U.K. 5%; imports -- U.S. 31%, West Germany 13%,
Argentina 6%, U.K. 5%, Italy 3% (1970)
Aid: economic -- extensions from U.S. (FY46-70) -- loans $3,023.4 million,
grants $599.8 million; from international organizations (FY46-68) $1,093.6
million; from other Western countries (1960-66) -- $343.6 million; from
Communist countries (1954-70) $330.6 million; drawings $66 million
Monetary conversion rate: 5.5 cruzeiros=US$1 (free rate September 1971, changes
frequently)
Fiscal year: calendar year
GNP: $46 million (est. 1968), $380 per capita; 78% private consumption, 17%
public consumption, 36% domestic investment, -31% net foreign balance
(1968); real growth rate 1968 4.5% (est.)
Agriculture: main products -- citrus fruits, sugar, corn, rice, beans, livestock
products; net importer of food; caloric intake, 2,500 calories per day
per capita
Major industries: timber and forest products, food processing, furniture, rum,
soap
Electric power: 8,030 kw. capacity (1969 est.); 16 million kw.-hr. produced
(1969 est.), 132 kw.-hr. per capita
37
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d):
Exports: $17 million (f.o.b., 1969); sugar, lumber, citrus fruits, fish
Imports: $30 million (c.i.f., 1969); vehicles, petroleum, food, textiles,
machinery
Major trade partners: exports -- U.K. 31%, U.S. 29%, Mexico 16%, Canada 15%;
imports -- U.S. 33%, U.K. 29%, Jamaica 7% (1968)
Aid: economic -- extensions from U.S. (FY46-70), $5.8 million, grants; from
international organizations (1946-69), $1.1 million
Monetary conversion rate: $BH1.67=US$1 (official)
Fiscal year: calendar year
GNP: $132 million (estimated 1968), $1,200 per capita
Agriculture: main crops -~- rubber, rice, sago
Major industry: crude petroleum
Electric power: 58,000 kw. capacity (1970); 130 million kw.-hr. produced (1970),
1,120 kw.-hr. per capita
Exports: $85 million (f.o.b. AG almost all crude petroleum
Imports: $77 million (c.i.f. 1970
Major trade partners: exports of crude petroleum go to Sarawak for refining
and reexport; 30% imports from U.K., Singapore 16%, Japan 13%
Monetary conversion rate: 3.06 Brunei dol lars=US$1
Fiscal year: calendar year
GNP: $11.1 billion, 1970 (at 1969 prices), $1,300 per capita; 1970 growth rate
7.8% (current)
Agriculture: mainly self-sufficient; main crops--grain, vegetables; no food
shortages; caloric intake, 3,000 calories per day per capita (1965/66)
Major industries: agricultural processing, machinery, textiles and clothing,
mining, ore processing, timber
4]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved Fo .
Sarre ‘PP r Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Shortages: petroleum, some raw materials, metal products
Crude steel: 1.86 million metric tons produced (1970), 220 kg. per capita
Electric power: 4,035,000 kw. capacity (1970); 19.5 billion kw.-hr. produced
(1970), 2,285 kw.-hr. per capita
Exports: $2,009 mitlion (f.0.b., 1970); in 1970, 29% machinery, equipment, and
transportation equipment; 13% fuels, minerals, raw materials, metals, and
other industrial material; 8% agricultural: raw materials; 35% foodstuffs
and animals; 15% industrial consumer goods
Imports: $1,816 million (f.0.b., 1970); in 1970, A1% machinery, equipment, and
transportation equipment; 38% fuels, minerals, raw materials, metals, other
materials; 10% agricultural raw materials; 6% foodstuffs and animals; 5%
industrial consumer goods
Major trade partners: $3,825 million in 1970; 22% with non-Communist countries;
738% with Communist countries
Monetary conversion rate: (commercial) 1.17 leva, (noncommercial) 1.99 Jeva=US$1
Fiscal year: calendar year; economic data reported for calendar years except for
caloric intake, which is reported for consumption year | July - 30 June
GDP: $2.08 billion (FY70), less than $100 per capita; real growth rate 4% (FY70)
Agriculture: main crops -- paddy, sugarcane, peanuts; almost 100% self-sufficient;
most rice grown in deltaic land
Major industries: agricultural processing; textiles and footwear, wood and
wood products
Electric power: 253,000 kw. capacity (1969); 580 million kw.-hr. produced (1969),
21 kw.-hr. per capita
Exports: $112 million (f.o.b., 1970); rice, teak
Imports: $163 million (c.i.f., 1970)
43
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d):
Major trade partners: exports -- India, Western Europe, U.K., Japan; imports --
Japan, Western Europe, U.K., India
Monetary conversion rate: 4.76 kyat=US$1
Fiscal year: 1 October - 30 September
GNP: about $207.4 million (1970), $60 per capita
Agriculture: major cash crops -- coffee, cotton; main”food crops -- manioc,
yams, corn, sorghums, bananas, haricot beans; not self-sufficient
Industries: light consumer goods such as beverages, shoes, soap
Electric power: 13,100 kw. capacity (1970); 26 million kw.-hr. produced (1970),
7 kw.-hr. per capita
Exports: $21.7 million (f.0.b., 1970); coffee, cotton, hides, skins
Imports: $20.9 million (c.i.f., 1970); textiles, foodstuffs, transport equipment,
petroleum products
Major trade partners: U.S., Belgium, Congo; much trade unrecorded
Aid: $14.9 million (1969) includes U.S. 3
$7.6 million, U.N. $2.2 million, EDF $2.2 million
Monetary conversion rate: 87.5 Burundi francs=US$1 (official)
Fiscal year: calendar year
45
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
340,000 (U.S. $7.5 million FY61-70), Belgium
COMMUNTCcATARPFoved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: 3,700 mi.; 45 mi. bituminous, 3,655 mi. crushed stone, gravel, laterite,
and improved or unimproved earth
Inland waterways: Lake Tanganyika navigable for lake steamers and barges
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 32 total, 22 usable; 1] with permanent-surface runway; 1 with runway
8,000-11,999 ft.
Telecommunications: telegraph is principal service, limited telephones; 3,400
telephones, 65,000 radio receivers; 2 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending December 1971, $1,100,000; about 4.5% of
ordinary budget
46
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS Approved For Release 2004/08/31 ¢,GhAryRDP79-01051A000400010002-1
D:
69,898 sq. mi.; 16% cultivated, 74% forested, 10% built-on
area, wasteland, and other (1958)
Land boundaries: 1,515 mi.
WATER:
Limits of territorial waters: 12 n. mi. (fishing, 12 n. mi.)
Coastline: about 400 mi.
GNP: $634 million (1969), $90 per capita (constant 1966 prices, converted at
55.5 riels=US$1); 1960-69 average growth rate 3.6% (constant 1966 prices)
Agriculture: Mainly subsistence except for rubber plantations; main crops --
rice, rubber, corn; largely self-sufficient; food shortages -- dairy products,
sugar, flour
Major industries: rice milling, fishing, wood and wood products, textiles
Shortages: fossil fuels
Electric power: 101,000 kw. capacity (1969); 175 million kw.-hr. produced (1969),
26 kw.-hr. per capita
Exports: $37.8 million (1970); rice, rubber, corn
Imports: $37.2 million (1970); metals and metal products, transportation equipment,
food, textiles, petroleum products, minerals
Major trade partners: (1970) exports -- France, Hong Kong, Senegal, 24% with
Communist countries; imports -- Japan, France, U.S., 2% with Communist countries
47
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cdnpRrpved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Monetary conversion rate: 55.5 riels=US$1 (effective 18 August 1969)
Fiscal year: calendar year
GDP: $872 million (1970 est.), per capita about $150; real growth rate about 7%
per annum
Agriculture: commercial and food crops -- cocoa, coffee, timber, cotton, rubber,
bananas, peanuts, palm oi] and palm kernels; root starches, livestock, millet,
sorghum, and rice
49
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY leone For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Fishing: catch about 73,000 tons (1970), value not available; exports -- none
(1970), imports $1.6 million (1970)
Major industries: small aluminum plant; food processing and light consumer goods
industries, sawmills
Electric power: 200,000 kw. capacity (1970); 1,150 million kw.-hr. produced
(1970), 194 kw.-hr. per capita
Exports: $226 million (f.0.b., 1970) cocoa and coffee about 55%; other exports
include timber, aluminum, cotton, natural rubber, bananas, peanuts, tobacco,
and tea
Imports: $242 million (c.i.f., 1970) consumer goods, machinery, transport equipment,
alumina for refining, petroleum products, food and beverages; about 2% from
Communist countries
Major trade partners: about 70% of total trade with France and other EC countries;
less than 10% of total trade with U.S.
Monetary conversion rate: | Communaute Financiere Africaine franc=0.02 French
francs; prior to 13 August 1971, 277 CFA francs = uUS$1 (official )
Fiscal year: 1 July - 30 June
GDP: $168 million (1967), about $120 per capita
Agriculture: commercial -- cotton, coffee, peanuts, sesame, wood; main food
crops -- manioc, corn, peanuts, rice, potatoes, beef; requires wheat, flour,
rice, beef, and sugar imports
Major industries: sawmills, cotton textile mills, brewery, diamond mining and
splitting
Electric power: 15,100 kw. capacity (1970); 32 million kw.-hr. produced (1970),
20 kw.-hr. per capita
Exports: $38 million (f.o.b., 1969); diamonds (43%), coffee, cotton, lumber
Imports: $44 million (c.i.f., 1969); textiles, petroleum products, machinery
and electrical equipment, motor vehicles and equipment, chemicals and
pharmaceuticals
53
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d):
Major trade partner:
franc zone; U.S.
Monetary conversion rate:
(official)
Fiscal year: calendar year
France; preferential tariff applied to EC countries and
277 Communaute Financiere Africaine francs=US$1
GNP: $1.95 billion (1970), $150 per capita; real growth rate 4.1% (1970)
Agriculture: agriculture accounts for about 35% of GNP; main crops -- rice,
rubber, tea, coconuts; 55% self-sufficient in food; food shortages -- rice,
wheat, sugar, fish
Fishing: catch 140,000 tons (1970), $64 million; exports $0.4 million, imports
$11.7 million
Major industries: processing of rubber, tea, and other agricultural commodities;
consumer goods manufacture
Electric power: 298,000 kw. capacity (1969); 750 million kw.-hr. produced
(1969), 60 kw.-hr. per capita
Exports: $342 million (f.o0.b., 1970); tea, rubber, coconut products
Imports: $398 million (c.i.f., 1970)
Major trade partners: (1969) exports -- U.K. 20.2%, China 12.8%, U.S. 8.0%,
Australia 4.2%, South Africa 4.5%, U.S.S.R. 4.8%, West Germany 4.1%, Canada
2.6%; imports -- U.K. 17.4%, China 11.1%, India 8.3%, Australia 4.5%,
U.S.S.R. 2.0%, U.S. 8.4%, Japan 7.4%, Burma 1.2%
Monetary conversion rate: 5.95 rupees=US$1
Fiscal year: 1 October - 30 September
GDP: about $209 million (1967), about $60 per capita; annual growth rate 5.7%
Agriculture: commercial -- cotton, gum arabic, livestock, fish; food crops --
peanuts, millet, sorghum, rice, dates, manioc, wheat; imports food
Fishing: catch 100,000-110,000 tons annually; exports $300,000 (1969)
Major industries: agricultural and livestock processing plants (cotton textile
mill, slaughterhouses, brewery), natron
57
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (conAaproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002
Yr. pr 1999 tl070),
Electric power: 16,300 kw. capacity (1970); 45 million kw.-hr. pro
12 kw.-hr. per capita
Exports: $33.8 million (c.i.f., 1968) including trade with members of the
Economic and Customs Union of Central Africa (UDEAC); cotton 80%, meat, hides
Imports: $50.0 million (c.i.f., 1968) including UDEAC trade; petroleum, textiles,
machinery and motor vehicles; $1.3 million from Communist countries (1967)
Major trade partners: France (about 36%) and UDEAC countries; preferential
tariffs to EC and franc zone countries
Aid: major source France, FY61-67 $49.1 million; EC (FY60-67) $28.6 million;
U.S. (FY62-70) $9.2 million; U.S.S.R. $2.2 million (1968); military aid
(1954-68) -- $5.4 million, from France $4.1 million, remainder from West
Germany and Israel
Monetary conversion rate:
(official )
Fiscal year: calendar year
277 Communaute Financiere Africaine francs=US$1
GNP: about $120 billion (1970), $145 per capita
Agriculture: main crops -- rice, wheat, miscellaneous grains, cotton; caloric
intake, 2,000 calories per day per capita (1970); agriculture mainly
subsistence; grain imports 4-5 million tons annually (1961-70)
Major industries: iron and steel, coal, machine building, armaments, textiles
Shortages: complex machinery and equipment, highly skilled scientists and
technicians
Crude steel: 17 million tons produced (1970), 20 kilograms per capita (1970)
Exports: $2.1 billion (f.0.b., 1970), agricultural products, minerals and metals,
manufactured goods
Imports: $2.2 billion (c.i.f., 1970), grain, chemical fertilizer, industrial
raw materials, machinery and equipment
Major trade partners: Japan, Hong Kong, West Germany, U.K., Singapore, Malaysia,
Canada, Australia (1970)
Monetary conversion rate: 2.46 yuan=US$1 (arbitrarily established)
Fiscal year: calendar year
GDP: about $228 million (1967 est.), about $260 per capita, real growth rate
about 4% per year
Agriculture: cash crops -- sugarcane, wood, coffee, cocoa, palm kernels, peanuts,
tobacco; food crops -- root crops, rice, corn, bananas, manioc, fish
Fishing: catch 30,000 tons (1970 est.)
67
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Rel :
cena deanna) elease 2004/08/31 : CIA-RDP79-01051A000400010002-1
Major industries: sawmills, brewery, cigarettes, sugar mill, soap
Electric power: 42,000 kw. capacity (1970); 68 million kw.-hr. produced (1970),
70 kw.-hr. per capita
Exports: $60 million (f.0.b., 1968); lumber, sugar, tobacco, veneer, and plywood;
diamonds smuggled from Zaire
Imports: $86 million (c.i.f-; 1968); machinery, transport equipment, manufactured
consumer goods, iron and steel, foodstuffs, petroleum products
Major trade partners: France and other EC countries on preferential basis
Monetary conversion rate: 277 Conmunaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year
GNP: $896 million (purchasing power parity estimate, 1970), $510 per capita;
14% government consumption, 67% private consumption, 23% domestic investment,
6% inventory, -10% net foreign balance (1969); real growth rate 1970, 8.0%
Agriculture: main products -- bananas, coffee, sugarcane, rice, corn, cocoa,
livestock products; caloric intake, 2,500 calories per day per capita
Fishing: catch 4,100 tons (1970); exports, $1.4 million (1969), imports $0.4
million (1969)
Major industries: food processing, textiles and clothing, construction
materials, fertilizer
69
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cofpRpved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Electric power: 237,000 kw. capacity (1969); 757 million kw.-hr. produced
(1969 est.), 443 kw.-hr. per capita
Exports: $229 million (f.o.b., 1970); coffee, bananas, sugar, beef,','238709b282c65210235138f70484b5d71c7c381248d4fe0e0b5b5105965ea121','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('937dc2777325daf58afe7b9d2e8ecdc0545822ca888a2edfaa04e494b5826890',1971,'BR','Brazil','economy',15,'fertilizers,
cacao
Imports: $317 million (c.i.f., 1970 est.); manufactured products, machinery,
transportation equipment, chemicals, fuels, foodstuffs
Major trade partners: exports -- 41% U.S., 20% CACM, 8% West Germany, 5%
Netherlands; imports -- 35% U.S., 22% CACM, 8% West Germany, 9% Japan (1970)
Aid:
economic -- extensions from U.S. (FY46-70), $116.7 million loans, $91.5
million grants; from international organizations (FY46-69), $94.7 million;
from other Western countries (1960-68), $1.8 million;
military -- assistance from U.S. (FY60-70) $1.8 million
Monetary conversion rate: 6.62 colones=US$1 (official buying rate); 6.65
colones=US$1 (official selling rate)
Fiscal year: calendar year
GDP: $4.9 billion (est. 1970 at 1970 prices), $570 per capita; 60% private
consumption, 20% public consumption, 20% gross investment; real growth
rate 1970, 6%
Agriculture: main crops -- sugar, tobacco, coffee, rice, potatoes, tubers,
citrus fruits
Fishing: catch 106,000 tons (1970); exports about $19 million (1970), imports
$13 million (1970)
Major industries: sugar milling, petroleum refining, food and tobacco processing,
textiles, chemicals, paper and wood products, metals
Shortages: spare parts for transportation and industrial machinery, consumer goods
Crude steel: 0.35 million metric tons capacity (planned 1969); 165,000 metric
tons produced (1970); 19 kg. per capita
Electric power: 1.3 million kw. capacity (1970); 5.1 billion kw.-hr. produced
(1970), 600
Exports: $970 million (f.o.b., 1970 est.); sugar, nickel, tobacco
7)
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY eouene For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Imports: $1,325 million (c.i.f., 1970 est.); petroleum, industrial raw
materials, capital goods, food
Major trade partners: exports -- U.S.S.R. 49%, China 7%, other Communist
countries 15%, Japan 10%, Spain 3%; imports -- U.S.S.R. 54%,
China 6%, other Communist countries 10%, France 5%, Italy 5% (1970 est.)
Monetary conversion rate: | peso=US$1 (nominal)
Fiscal year: calendar year
GNP: $504 million (1969), $800 per capita; 1969 growth 11%, 1958 constant prices
Agriculture: main crops -- vine products, citrus, potatoes, other vegetables;
food shortages -- grain, dairy products, meat, fish; caloric intake, 2,590
calories per day per capita (1961)
Major industries: mining (cupreous and iron pyrites, asbestos), manufactures
principally for local consumption -- food, beverages, footwear
Shortages: water, petroleum
Electric power: 190,000 kw. capacity (1970); 553 million kw.-hr. produced (1970),
850 kw.-hr. per capita ‘
Exports: $108.5 million (f.0.b., 1970); principal items -- copper, pyrites, citrus,
raisins, and other agricultural products
Imports: $239 million (c.i.f., 1970); principal items -- manufactured goods,
machinery and transport equipment, petroleum products, foods
Major trade partners: (1969) U.K. 34%, West Germany 10%, Italy 9%, EC 29.4%,
Communist countries 8.3%
Aid: economic -- U.S., $22.2 million authorized (1961-70), none authorized in
1970; IBRD, $34.2 million (1963-70); U.N. Technical Assistance, $1.5 million
(1946-68); U.N. Special Fund, $8 million (1953-70); Poland, $1.3 million
authorized (1962)
Monetary conversion rate: 1 Cyprus pound=US$2.40
Fiscal year: calendar year
GNP: $30.9 ee in 1970 (at 1969 prices), $2,130 per capita; 1970 real growth
rate 4.1%
Agriculture: diversified agriculture; main Crops -- wheat, rye, potatoes, sugar
beets; net food importer -- meat, wheat, vegetable oils, fresh fruits and
vegetables; caloric intake, 3,100 calories per day per capita (1967)
Major industries: machinery, food processing, metallurgy, textiles, chemicals
Shortages: ores, crude oil, grain
75
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A ;
Snag eae pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Crude steel: 11.5 million metric tons produced (1970), 750 kg. per capita
Electric power: 10,612,000 kw. capacity (1970); 44.8 billion kw.-hr. produced
(1970), 3,020 kw.-hr. per capita
Exports: $3,792 million (f.0.b., 1970); 50% machinery, equipment; 28% fuels,
raw materials; 5% foods, food products, and live animals; 17% consumer goods,
excluding foods (1969)
Imports: $3,695 million (f.0.b., 1970); 32% machinery, equipment; 44% fuels, raw
materials; 15% foods, food products, and live animals; 9% consumer goods,
excluding foods (1969)
Major trade partners: $7,487 million (1970); 70% Communist countries, 30% other
Monetary conversion rate: commercial 7.20 crowns=US$1, noncommercial 14.36
crowns=US$1, tourist rate 16.20 crowns=US$1
Fiscal year: calendar year
GDP: $219 million (1970 est.) $80 per capita; real growth rate, less than 5%
per annum
Agriculture: major cash crop is oi1 palms; peanuts, cotton, coffee, sheanuts,
tobacco also produced commercially; main food crops -- corn, cassava, yams,
sorghum and millet; livestock, fish
Fishing: catch 35,000 tons (1970); exports none, imports 4,000 tons
Major industries: palm oi] and palm kernel oi1 processing
Electric power: 7,500 kw. capacity (1970); 34 million kw.-hr. produced (1970),
12 kw.-hr. per capita
77
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cofPRKeved For Release 2004/08/31 : CIA-RDP79-01051A0900400010002-1
Exports: about $46 million (f.0.b., 1970); palm products (41%); other
agricultural products
Imports: about $68 million (f.0.b., 1970); clothing and other consumer goods,
cement, lumber, fuels, foodstuffs, machinery, and transport equipment
Major trade partners: France, EC, franc zone; preferential tariffs to EC and
franc zone countries
Aid:
economic (1970) -- France, $8 million; EC, $4.2 million; U.N., $2 million;
West Germany, $1 million; Taiwan, $1 million; U.S., (FY1960-70) $12.5 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; prior to 13 August 1971, 277 CFA francs=US$1
Fiscal year: calendar year
GNP: $16.9 billion (1969), $3,420 per capita; 57.0% consumption, 28.2% invest-
ment, 17.3% government, -2.5% net foreign balance; 1970 growth 10.9%, 1968
current prices
Agriculture: highly intensive, specializes in dairying and animal husbandry;
main crops -- cereals, root crops; food shortages -- oil, seeds; caloric
intake, 3,180 calories per day per capita (1968-69)
79
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (Arneroyed For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Fishing: catch 1,259,314 metric tons (1969), $100 million; exports $14.3 million,
imports $22 million
Major industries: food and food processing, textiles, clothing, footwear, en-
gineering and electrical equipment, transportation equipment, chemicals
Shortages: fuels, basic metals, fertilizers, grains
Crude steel: 549,800 metric tons produced (1970), 116 kg. per capita
Electric power: 4,370,000 kw. capacity (1970); 18,620 million kw.-hr. produced
(1970), 2,500 kw.-hr. per capita
Exports: $3,300 million (f.o.b., 1970); principal items -- meat, dairy products,
fish, machinery and transport equipment, chemicals
Imports: $4,510 million (c.i.f., 1970); principal items -- machinery and trans-
port equipment, petroleum and coal, textile fibers and yarns, iron and steel
products, chemicals, food, and live animals
Major trade partners: U.K. 16%, West Germany 16.9%, Sweden 15.8%, U.S. 8.2%,
Norway 5.5%; EC 28.3%; EFTA 45.05%; Communist countries 3.6%
Aid:
economic -- (received) U.S., $301.8 million authorized 1946-70, none since
1958; IBRD -- $85.0 million through June 1970, none since 1964; net official
economic aid given to less developed areas and multilateral agencies,
$241.4 million (1960-70), $54.3 million (1969), $59.1 million (1970)
Monetary conversion rate: 7.5 Kroner=US$1
Fiscal year: 1 April - 31 March
GDP: $15.8 million (1968 est.), $230 per capita; economy is virtually stagnant
in real terms
Agricultural products: bananas, citrus, coconuts, cocoa
Major industries: agricultural processing, tourism
Electric power: 3,000 kw. capacity (1969 est.); 9 million kw.-hr. produced
(1969 est.), 120 kw.-hr. per capita
Exports: $6.2 million (f.o.b., 1970); bananas, lime juice and oi], cocoa and
reexports
Imports: $15.9 million (c.i.f., 1970); foodstuffs, manufactured articles
Major trade partners: U.K. 53%, Commonwealth Caribbean countries 15%, Canada
10%, U.S. 7% (1963)
Monetary conversion rate: 1.93 East Caribbean dollars=US$1 (6 October 1971)
GNP: $1.5 billion (purchasing power parity estimate, 1970), $350 per capita; real
growth rate 1970, 6.5%
Agriculture: main crops -- sugarcane, coffee, cocoa, tobacco, rice, corn; self-
sufficient in rice; caloric intake, 2,200 calories per day per capita (1966)
Major ss sugar processing, bauxite mining, peanut processing, textiles,
cemen
Electric power: 254,000 kw. capacity (1970 est.); 710 million kw.-hr. produced
(1970 est.), 175 kw.-hr. per capita
83
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
F : - - =
ECONOMY (con pepreved or Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Exports: $213.5 million (f.o.b., 1970); sugar, coffee, cocoa, tobacco, bauxite
Imports: $306 million (c.i.f., 1970); foodstuffs, petroleum, industrial raw
materials, capital equipment
Major trade partners: exports -- U.S. 89%, Europe 8%; imports -- U.S. 56%,
Europe 25% (1968)
Aid:
economic -- extensions from U.S. (FY46-70), $198.8 million in grants,
$257.4 million in loans; from international organizations (FY46-69),
$82.2 million;
military -- assistance from U.S. (FY53-70), $26.9 million
Monetary conversion rate: 1 peso=US$1 (31 August 1971)
Fiscal year: calendar year
GNP: $2.8 billion (purchasing power parity estimate, 1970), $460 per capita;
72% private consumption, 14% public consumption, 14% gross investment (1970
est.)3; real growth rate 1970 est., 9%
Agriculture: main crops -- sugarcane, beans, coffee, cotton, corn, bananas ,
cocoa, rice; nearly self-sufficient; caloric intake, 2,100 calories per day
per capita (1964)
Fishing: catch 91,500 tons (1970), $12.1 million (1970); exports $10.2 million
(1970), imports negligible
85
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d):
Major industries: food processing, textiles, cement, leather and rubber products,
drugs, fishing, petroleum
Electric power: 226,275 kw. capacity (1970 est.); 1.1 billion kw.-hr. produced
(1970), 183 kw.-hr. per capita
Exports: $237 million (f.o.b., 1970); bananas, coffee, cocoa
Imports: $275 million (f.0.b., 1970 est.); agricultural and industrial machinery,
petroleum products, chemical products, transportation and communication
equipment
Major trade partners: U.S. 37%, EC 22%, Japan 14% (1970)
Aid:
economic -- extensions from U.S. (FY46-70), $192.0 million loans, $95.2
million grants; from international organizations (FY46-70), $152.4 million;
from Communist countries (1954-70), $10 million loans;
military -- assistance from U.S. (FY49-70), $53.6 million
Monetary conversion rate: 25.25 sucres=US$1 (selling rate)
Fiscal year: calendar year
Agriculture: main cash crop -- cotton; other crops -- rice, onions, beans, wheat,
corn, barley; not self-sufficient in food, but agriculture a net earner of
foreign exchange
Major industries: textiles, food processing, chemicals, petroleum, construction,
cement
Electric power: 4,350,000 kw. capacity (1971); 10,000 million kw.-hr. produced
(1971), 265 kw.-hr. per capita
87
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (conpRrpved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Aid
economic -- Communist countries, $1,681 million in credits through December
1970; U.S., $912.2 million in credits and grants through June 1967
(diplomatic relations and aid terminated June 1967); sizable credits from
international agencies, West Germany, Italy, Kuwait; large grant from Libya
since 1969; $250 million annual subsidy from Arab states while canal is closed;
military -- Communist countries, about $2,700 million through December 1970
Monetary conversion rate: |] Egyptian pound=US$2.30 (selling rate); 0.435 Egyptian
pound=US$1 (selling rate)
Fiscal year: 1 July - 30 June
GNP: $1.49 billion (purchasing power parity estimate, 1970), $420 per capita;
80% private consumption, 9% government consumption, 11% domestic investment
(1970 est.); real growth rate 1970 est., 5.5%
Agriculture: main crops -- coffee, cotton, corn, sugar, rice, beans; caloric
intake, 2,000 calories per day per capita (1963-64)
Fishing: catch 16,100 tons; exports $4.2 million (1969), imports $0.2 million (1969)
Major industries: food processing, textiles, clothing, petroleum products
Electric power: 166,600 kw. capacity (1969 est.); 680 million kw.-hr. produced
(1970 est.), 190 kw.-hr. per capita
Exports: $229 million (f.o.b., 1970); coffee, cotton, sugar, chemicals,
other manufactures
Imports: $214 million (c.i.f., 1970); machinery, automotive vehicles, petroleum,
foodstuffs
Major trade partners: exports -- U.S. 19%, CACM 30%, West Germany 27%, Japan
12%; imports -- U.S. 29%, CACM 29%, West Germany 8%, Japan 10% (1970)
Aid:
economic -- extensions from U.S. (FY46-70), $86.5 million loans, $55.1
million grants; from international organizations (FY46-70), $99.0 million;
from other Western countries (1960-68) $3.7 million;
military -- assistance from U.S. (FY46-70), $6.6 million
Monetary conversion rate: 2.5 colones=US$1 (official)
Fiscal year: calendar year
GDP: $40 million (1968 est.); Rio Muni nearly $100 per capita, Fernando Po
about $250 per capita
Agriculture: major cash crops -- Rio Muni, timber, coffee; Fernando Po, cocoa;
main food crops -- rice, yams, cassava, bananas, 011 palm nuts, manioc, and
livestock
Fishing: exports $86,000 (1970)
Major industries: fishing, sawmilling
Electric power: 2,800 kw. capacity (1970); 9 million kw.-hr. produced (1970),
about 30 kw.-hr. per capita
Exports: $24.9 million (1970); cocoa, coffee, and wood
Imports: $21.0 million (1970); foodstuffs, chemicals and chemical products,
textiles
91
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79- -
ECONOMY (cont''d): 79-01051A000400010002-1
Major trade partner: Spain
Aid: Spain, $14.0 million (1969); Libya, $1 million (1971)
Monetary conversion rate: 70 Guinean pesetas=US$1 (official)
GDP: $1.794 billion (1970 in current prices), $70 per capita; 1970 average annual
growth rate 5%
Agriculture: main crops -- coffee, teff, durra, barley, wheat, corn, sugarcane,
cotton, pulses, oilseeds, livestock; almost self-sufficient in food
Sa 6,927 metric tons (1970), $1.4 million (1970); exports $348,000
Major industries: cement, sugar refining, cotton textiles, food processing,
oil refinery
Electric power: 206,000 kw. capacity (1970); 453 million kw.-hr. produced
(1970), 18 kw.-hr. per capita
Exports: $122 million (f.o.b., 1969); coffee 59.8%, hides and skins 8.2%, oilseeds
9%, cereals 5.7%; $2.0 million to Communist countries (1970)
93
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d):
Imports: $172 million (c.i.f., 1970); machinery and transport equipment 34.3%,
fuels 7.6%, chemicals 11.6%, manufactured goods 34.3%; $10 million
from Communist countries (1970)
Major trade partners: imports -- Italy, Japan, West Germany, and U.S.;
exports -- U.S., West Germany, Italy, Saudi Arabia, Japan
Monetary conversion rate: 2.50 Ethiopian dollars=US$1 (official)
Fiscal year: 8 July - 7 July
Legal name: The Faeroe Islands
Type: self-governing province within the Kingdom of Denmark; 2 representatives
in Danish parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, 1] town
Legal system: based on Danish law; Home Rule Act enacted 1948
Branches: legislative authority rests jointly with Crown, acting through appointed
High Commissioner, and provincial parliament (Lagting) in matters of strictly
Faeroese concern; executive power vested in Crown, acting through High
Commissioner, but exercised by provincial cabinet responsible to provincial
parliament
Government leaders: King Frederick IX; Prime Minister, Atli Dam
Suffrage: universal, but not compulsory, over age 2]
Elections: held every 4 years; next election 1974
Political parties and leaders: Peoples, Hakun Djurhuus; Republican, Erlendur
Patursson; Home Rule, Samuel Petersen; Progressive, Kjartan Mohr; Social
Democratic, Atli Dam; Union, Kristian Djurhuus
Voting strength (1970 election): Peoples 20.0%, Republican 20.0%, Home Rule
5.6%, Progressive 3.5%, Social Democratic 27.2%, Union 21.7%
Member of: Nordic Council
GDP: $57.1 million (1969), about $1,460 per capita
Agriculture: sheep and cattle grazing
Fishing: catch 173,780 tons (1969); exports $23.6 milljon
Major industry: fishing
Electric power: 27,500 kw. capacity (1970); 59 million kw.-hr. produced (1970),
1,590 kw.-hr. per capita
Exports: $24.3 million (f.o.b.,/1969); fish and fish products
Imports: $31.3 million (c.i.f.,| 1969); machinery and transport equipment, pet-
roleum and petroleum products, food products
Major trade partners: (1968) Denmark 42%, U.K. 9.9%, Sweden 5.0%, U.S. 2.1%,
Norway 11.2%; EC 10.2%; EFTA 71.4%; Communist countries 1.4%
Monetary conversion rate: 7.5 Danish kroner=US$1
Fiscal year: 1 April - 31 March:
95
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNTCAT ARRLOved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: none
Ports: 1 minor
Airfields: 1 with permanent-surface runway, less than 4,000 ft.
Civil air: no major transport aircraft
Telecommunications: good international radiocommunications; fair domestic
wire facilities; 6,300 telephones, 11,000 radio receivers, 1 AM, and 3 FM
stations; 1 submarine cable connection
96
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS gpPProved For Release P04/DB/3 1 SLAMS RAIA PkG 3140004000 10002-4
LAND:
Colony -- 4,700 sq. mi.; area consists of some 200 small
islands, chief of which are East Falkland (2,580 sq.
mi.) and West Falkland (2,038 sq. mi.); dependencies --
consists of the South Sandwich Islands, South Georgia.
and the Shag and Clerke Rocks (1966)
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 800 mi.
Government budget: Colony -- revenues, $1.0 million (FY68); expenditures,
$1.1 million (FY68)
Agriculture: Colony -- predominantly sheep farming; dependencies -- whaling
and sealing
Major industries: Colony -- wool processing; dependencies -- whale and seal
processing
Electric power: 1,327 kw. capacity (1970); 4 million kw.-hr. produced (1970),
2,000 kw.-hr. per capita
Exports: Colony -- $2.52 million (1966); wool (97%), hides and skins (2%),
and other (1%); dependencies -- $3.8 million (1965); whale and seal oi]
(62%) and other whale products (38%)
Imports: Colony -- $1.7 million (1966); food, clothing, fuels, and machinery;
dependencies -- $.2 million (1965); mineral fuels and lubricants, food,
and machinery
Major trade partners: nearly all exports to the U.K., 77% of imports from the
U.K.; dependencies -- exports to the Netherlands (63%) and Japan (37%),
imports from Curacao, Japan, and the U.K.
Monetary conversion rate: 1 Falkland Island pound=US$2.40
oe ace ee (1970), $370 per capita; 5% (est.) average annual growth rate
1965-70
Agriculture: main crops -- sugar, coconut products, bananas, rice; major
deficiency, grains
Major industries: tourism, sugar processing
Electric power: 15,700 kw. capacity (1969); 23.5 million kw.-hr. produced (1969),
43 kw.-hr. per capita
Exports: $59.2 million (f.o.b., 1969 excluding reexports); sugar, copra, copper
Imports: $89.6 million (c.i.f., 1969)
Major trade partners: U.K., Australia, U.S., Japan, New Zealand
Aid: disbursed 1968 -- Australia $1.5 million, U.S. $600,000, U.K. $4.2 million
Monetary conversion rate: 0.87 Fijian dollar=US$1
Fiscal year: calendar year
99
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONEPrOved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: 1,555 mi.; 150 mi. paved, 1,325 mi. gravel or crushed stone, 80 mi.
unimproved earth
Inland waterways: 126 mi.; 76 mi. navigable by motorized craft and 200-ton barges
Ports: 6 major, numerous minor landings
Civil air: 5 major transport aircraft (incl. 2 leased)
Airfields: 16, 11 usable; 1 with runway 8,000-11,999 ft., 1 with runway 4 ,000-7 ,999
ft., 2 seaplane stations
Telecommunications: modern local, interisland, and international (wire/radio
integrated) public and special-purpose telephone, telegraph, and teleprinter
facilities; regional radio center; important COMPAC cable link between
U.S./Canada and New Zealand/Australia, et al; 16,789 telephones; 50,000
radio receivers; 5 AM, no FM or TY stations
DEFENSE FORCES:
Military budget: the defense of the Fiji Islands was the responsibility of the
U.K. until 10 October 1970; the military budget for 1971 is $314 ,000
100
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For R : - - -
are- 94 pprov or Release 2004/08/31 + ClA-RDP79 01051A000400010002-1
LAND:
130,000 sq. mi.; 8% arable, 65% forested, 27% other (1966)
Land boundaries: 1,575 mi.
WATER:
Limits of territorial waters: 4.n. mi. (fishing, 4 n. mi.);
Aland Islands, 3 n. mi.
Coastline: 700 mi. (approx.) includes islands
GNP: $145.9 billion (1970), $2,870 per capita; 60% consumption, 28% investment
(including government), 11% government consumption; 1% net exports; 1970
growth rate 5.9%, 1963 constant prices
Agriculture: Western Europe''s foremost producer; main crops -- cereals, sugar
beets, potatoes, wine grapes; self-sufficient for most temperate zone food-
stuffs; food shortages -- fats and oils, tropical produce; caloric intake,
3,180 calories per day per capita (1967 est.)
Fishing: catch 746,300 metric tons, $227,449 ,000 (1969); exports $27,158,000
(1969), imports $165,963,000 (1969)
Major industries: steel, machinery and equipment, textiles and clothing,
chemicals, food processing, metallurgy
Shortages: crude oil, textile fibers, most nonferrous ores, coking coal, fats
and oi]s
par ae 23.8 million metric tons produced (1970), 469 kilograms per capita
1970
Electric power: 36,500,000 kw. capacity (1970); 140.7 billion kw.-hr. produced
(1970), 2,600 kw.-hr. per capita
Exports: $17.9 billion (f.o.b., 1970); principal items -- textiles and clothing,
dron and steel products, machinery and transportation equipment, foodstuffs
and agricultural products, alcoholic beverages
Imports: $19.1 billion (c.i.f., 1970); principal items -- machinery and
equipment, crude petroleum, iron and steel products, textile fibers, coal
and coke, foodstuffs, alcoholic beverages
Major trade partners: (1970) EC 49%; West Germany 21%; Belgium-Luxembourg 1143
Italy 10%; Netherlands 6%; EFTA 13%; U.S. 8%; Eastern Europe 2%; U.S.S.R. 1%3
franc zone 10%
Aid:
economic (received) -- U.S., $5,215.4 million authorized (FY46-68), none
since FY67;
military -- U.S., $4,259 million authorized (FY46-70); net official economic
aid to less developed areas and multilateral agencies -- $7,431 million
(FY60-70), $951.7 million (FY70)
Monetary conversion rate: 5.55419 francs=US$1 (official)
Fiscal year: calendar year
GNP: $32 million (1966), $840 per capita
Agriculture: main crops -- rice, corn, manioc, cocoa, bananas, Sugarcane
Fishing: catch 800 metric tons (1968); exports $2.4 million (1968), imports $2.2
million (1967)
Major industries: timber, rum, gold mining, production of rosewood essence and
space center
Electric power: 18,300 kw. capacity (1970); 54.9 million kw.-hr.
produced (1970), 1,058 kw.-hr. per capita
Exports: $3.4 million (f.o.b. 1968); shrimp, timber, rum, rosewood essence
Imports: $52.0 million (c.i.f., 1968); food (grains, processed meat), other
consumer goods, producer goods and petroleum
Major trade partners: exports -- U.S. 78%, France 11%, Martinique 5%; imports --
France 72%, U.S. 13% and Trinidad and Tobago 3','1c9270da60b7e7eccdd5f3901890d8dbcc969365a1797e94735c222d68f921f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1d5fbeb1d58408dcf5dfbfe790b9eb607090f60bc3bcb83a78e77406704097f',1971,'BR','Brazil','economy',16,'% (1967)
107
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (Appreved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Monetary conversion rate: commercial rate, 5.5187 francs=US$1; financial rate,
5.3333 francs=US$1 (1 October 1971)
Fiscal year: calendar year
Agriculture: livestock; desert conditions limit commercial crops to about 15
acres
Industry: ship repairs
Electric power: 18,300 kw. capacity (1970); 18 million kw.-hr. produced (1970),
222 kw.-hr. per capita
Imports: almost all domestically needed goods
Exports: hides and skins
Aid: $2.4 million in 1967 from France
Monetary conversion rate: 214 Djibouti francs=US$1 (official )
Fiscal year: probably same as that for France (calendar year)
GDP: $326 million (1970), about $660 per capita; 1965-70 real growth 8% average
annual rate
Agriculture: commercial -- cocoa, coffee, wood, palm oil, rice; main food crops
-- bananas, manioc, peanuts, root crops; imports food
Fishing: catch 4,000 tons (1969); exports $600,000 (1970), imports -- not available
Major industries: sawmills, petroleum refinery, natural gas, agricultural
processing; mining of increasing importance; major minerals -- manganese,
uranium, gold, and iron
Electric power: 16,750 kw. installed capacity (1970); 46 million kw.-hr. produced
(1970), 97 kw.-hr. per capita
111
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont. roved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Exports: $174 million (f.o.b., 1970) excluding trade with other members of the
Economic and Customs Union of Central Africa (UDEAC); wood and wood products
about 40%; minerals (manganese, uranium concentrates, gold, crude oil)
Imports: $113 million (c.i.f., 1970) excluding UDEAC trade; mining, roadbuilding
machinery, electrical equipment, transport vehicles, foodstuffs, textiles
Major trade partners: France, U.S., West Germany, and Curacao; preferential
tariffs to EC and franc zone
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; prior to 13 August 1971, 277 CFA francs=US$1
Fiscal year: calendar year
GDP: $46 million (FY71 est.), about $120 per capita
Agriculture: main crops -- peanuts, rice, palm kernels
Fishing: catch 4,500 tons (1970); exports $94,000 (1970)
Major industry: peanut processing
Electric power: 5,000 kw. capacity (1970); 12 million kw.-hr. produced (1970),
32 kw.-hr. per capita
Exports: $15.7 million (1970); peanuts and peanut products 90% to 95%, palm
kernels
Imports: $17 million (1970); textiles, foodstuffs, tobacco, machinery,
petroleum products
Major trade partners: exports -- U.K.3 imports -- U.K. and Japan
Aid: economic -- U.K. (1968-71) about $8 million commi tment
Monetary conversion rate: 1 Gambian pound=US$2.40 (official )
Fiscal year: 1 July - 30 June
113
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Agriculture: food deficit area; main crops -- potatoes, rye, wheat, barley, oats,
industrial crops; shortages in grain, vegetables, vegetable oil, beef;
caloric intake, 3,000 calories per day per capita (1967-68)
Major industries: metal fabrication, chemicals, light industry, brown coal,
uranium, and shipbuilding
Shortages: coking coal, coke, crude oil, rolled steel products, nonferrous metals
Crude steel: 5.37 million metric tons produced (1970 est.), approx. 310 kg. per
capita
Electric power: 12,669,100 kw. capacity (1970); 67.7 billion kw.-hr. produced
(1970), 3,020 kw.-hr. per capita
Exports: $4,581 million est. (f.0.b. delivering country, 1970)
Imports: $4,847 million est. (f.0.b. delivering country, 1970)
Major trade partners: $9,428 million (1970); 39% Soviet Union, 32% other
Communist countries, 29% non-Communist countries
Monetary conversion rate: 4.2 DME=US$1 (unofficial rate actually used in East
German accounting of foreign trade transactions )
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for the consumption year
] July - 30 June
GDP: $2.3 billion (1969) at current prices, about $260 per capita; real growth
rate about 3.6%
Agriculture: main crop -- cocoa; other crops include root crops, corn, sorghum
and millet, peanuts; not self-sufficient, but can become so
Fishing: catch 163,000 tons (1969), $35 million
Major industries: mining, lumbering, light manufacturing, fishing, aluminum
Electric power: 675,000 kw. capacity (1970); 2.8 billion kw.-hr. produced
(1970), 320 kw.-hr. per capita
Exports: $348 million (f.o.b., 1969); cocoa (about 70%), wood, gold, diamonds,
manganese, bauxite, and aluminum (aluminum regularly excluded from balance
of payments data)
119
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d/xpproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Imports: $300 million (f.o.b., 1969}; textiles and other manufactured goods,
food, fuels, transport equipment
Major trade partners: U.K., EC, and U.S.
Monetary conversion rate: 1 new Cedi=US$0.98 (official); 1.02 new Cedi=US$1
Fiscal year: 1 July - 30 June
GNP: $252 million (1970), $330 per capita; real growth rate 1970 (est.) 3%
Agriculture: main crops -- sugarcane, rice, other food crops; food shortages --
wheat flour, potatoes, processed meat, dairy products; caloric intake, 2,110
calories per day per Capita (1965)
Fishing: catch 16,600 tons, $12 million (1970); exports $4.8 million (1970),
imports $1.5 million (1970)
135
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A
ECONOMY (cont''d): pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Major industries: bauxite mining, alumina production, sugar and rice milling
Electric power: 112,000 kw. capacity (1970 est.); 448 million kw.-hr. produced
(1970 est.), 578 kw.-hr. per capita
Exports: $131 million (f.0.b., 1970); bauxite, sugar, alumina, rice, shrimp,
molasses, timber, diamonds, rum
Imports: $134 million (c.i.f., 1970); manufactures , machinery, food, petroleum
Major trade partners: U.K. 28%, U.S. 23%, Canada 14%, Commonwealth Caribbean
countries 13% (1969)
Aid: economic -- extensions from U.S. (1953-70), $41.1 million loans, $21.3
million grants; from international organizations (FY46-70), $19.0 million
Monetary conversion rate: 2 Guyana dollars=US$1 4
Fiscal year: calendar year
GDP: about one-half billion U.S. dollars (purchasing power parity estimate,
1969), $100 per capita; economy has been stagnant in recent years, but some
growth probably occurred in 1969-70
Agriculture: main crops -- coffee, sugarcane, rice, corn, sorghum, pulses;
caloric intake, 1,850 calories per day per capita
Major industries: sugar refining, textiles, flour milling, cement manufacturing,
copper and bauxite mining, tourism
Electric power: 30,000 kw. capacity (1970 est.); 78 million kw.-hr. produced
(1969 est.), 16 kw.-hr. per capita
137
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d )kpproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Exports: $40 million (f.0.b., 1970 est.); coffee, bauxite, light industrial
products, sisal, sugar, copper
Imports: $42.0 million (f.o.b., 1970 est.); wheat, fish, vegetable oils, textiles,
petroleum products, industrial equipment, medical supplies, construction
materials
Major trade partners: U.S. 59%, EC 15%, Japan 6% (1967 est.)
Aid:
economic -- extensions from U.S., $34.1 million loans, $84.2 million grants
(FY46-70); international organizations, $26.0 million (FY46-70);
military -- U.S., $4.3 million (FY53-63)
Monetary conversion rate: 5 gourdes=US$1 (17 August 1971)
Fiscal year: 1 October - 30 September
GNP: $784 million (purchasing power parity estimate, 1970), $300 per capita; 76%
private consumption, 9% government consumption, 19% domestic investment; 2%
inventory, -7% net foreign balance; real growth rate 1970, 2.6%
Agriculture: main crops -- bananas, coffee, corn, beans, cotton, sugarcane,
tobacco; caloric intake, 2,300 calories per day per capita (1964-65)
Fishing: exports $1.4 million (1970); imports $0.5 million (1970)
Major industries: agricultural processing, textiles, clothing, wood products
139
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Electric power: 113,000 kw. capacity (1969 est.); 380 million kw.-hr. produced
(1969 est.), 150 kw.-hr. per capita
Exports: $170 million (f.o.b., est. 1970); bananas, coffee, corn, cotton, lumber,
minerals, beef
Imports: $220 million (c.i.f., est. 1970); manufactured products, machinery,
transportation equipment, chemicals, fuels
Major trade partners: exports -- U.S. 53%, West Germany 11%, CACM 11%; imports
-- U.S. 41%, CACM 25%, West Germany 5% Japan 8% (1970)
Aid:
economic -- extensions from U.S. (FY46-70), $65.6 million loans, $54.8
million grants; from international organizations (FY46-68), $118.5 million;
from other Western countries (1960-68), $5.3 million;
military -- assistance from U.S. (FY46-70), $8.1 million
Monetary conversion rate: 2 lempiras=US$1 (official)
Fiscal year: calendar year
GNP: $3.6 billion 1970, $860 per capita
Agriculture: agriculture occupies a minor position in the economy; main crops --
rice, vegetables, dairy products; less than 20% self-sufficient; food
shortages -- rice, wheat
Major industries: textiles and clothing, tourism, plastics, electronics, light
metal products, food processing
14]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79- -
ECONOMY (cont''d): 9-01051A000400010002-1
Shortages: industrial raw materials, water, food
Electric power: 1,367,500 kw. capacity (1969); 4 billion kw.-hr. produced
(1969), 1,095 kw.-hr. per capita
Exports: $2.5 billion (f.o.b., 1970); including $477 million reexports; principal
products clothing, plastic articles, textiles, electrical goods, wigs,
footwear, light metal manufactures
Imports: $2.9 billion (c.i.f., 1970)
Major trade partners: 1970 exports -- U.S. 35%, U.K. 10%, Japan 7%, West
Germany 7%; imports -- Japan 24%, China 16%, U.S. 13%, U.K. 9%
Monetary conversion rate: HK$6.06=US$1
Fiscal year: 1 April - 31 March
GNP: $15.0 billion in 1970 (at 1969 prices), $1,450 per capita; 1970 growth
rate 2.4%
Agriculture: normally self-sufficient; main crops -- corn, wheat, potatoes,
Sugar beets, wine grapes; caloric intake 3,100 calories per day
per capita (1966/67)
Major industries: mining, metallurgy, engineering industries, Processed foods,
textiles, chemicals (especially pharmaceuticals )
Shortages: metallic ores (except bauxite), copper, high grade coal, forest
products
Crude steel: 3.11 million metric tons produced (1970), about 300 kg. per capita
Electric power: 2,930,000 kw. Capacity (1970); 14.5 billion kw.-hr. produced
(1970), 1,405 kw.-hr. per capita
Approved For Release 2004/08/31'': SIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79- e
ECONOMY (cont''d): 01051A000400010002-1
Exports: $2,317 million (f.0.b., 1970); 26% machinery, 21% industrial consumer
goods, 30% raw materials and semimanufactures, 23% food and raw materials
for the food industry (distribution for 1970)
Imports: $2,505 million (1970); 22% machinery, 10% industrial consumer goods,
57% raw materials and semimanufactures, 11% food and raw materials for the
food industry (distribution for 1970)
Major trade partners: $4,822 million (1970); 65% with Communist countries, 35%
with non-Communist countries
Monetary conversion rate: 11.74 forints=US$1 (arbitrary commercial); 30
forints=US$1 (noncommercial )
Fiscal year: same as calendar year; economic data reported for calendar years
GNP: $383 million (1969), $1,860 per capita; 63.2% consumption, 26.8%
investment, 10.8% government, -0.8% net foreign balance (1969); 1968 growth
rate -5.0%, 1960 constant prices
Agriculture: potatoes, turnips, animals, dairy products, hay; food shortages --
grains, sugar, vegetable and other fibers; caloric intake, 2,900 calories
per day per capita (1964-66)
145
Approved For Release 2004/08/31 G1a-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Fishing: catch 689,400 metric tons; exports $69.7 million, imports $0.4 million
Major industries: fish processing, aluminum smelting, diatomite production
Shortages: grain, fuel, wood, minerals, vegetable fibers
Electric power: 320,000 kw. capacity (1970); 1,351 million kw.-hr. produced
(1970), 3,800 kw.-hr. per capita
Exports: $107.6 million (f.o.b., 1969); fish and fish products, animal oils and
fats, aluminum
Imports: $123.4 million (c.i.f., 1969); machinery and transportation equipment,
petroleum, foodstuffs, textiles
Major trade partners: (1969) EFTA 39%, EC 21.5%, U.K. 13.3%, U.S. 18.1%, West
Germany 18.6%, U.S.S.R. 8.4%, Communist countries 11.9%
Aid: economic -- U.S. authorized (1946-70) $89.3 million, $2.0 million
(1968) $2.3 million (1969), none in 1970; IBRD $25.9 million through June
1970, none in 1968, authorized $4.1 million loan in 1970
Monetary conversion rate: 88 kronur=US$1 (official)
Fiscal year: calendar year
GNP: $44 billion est. (year ending 31 March 1970), less than $100 per capita; real
average annual growth (1 April 1966 - 31 March 1970), 3.5%
Agricul ture: main crops -- rice; other cereals, pulses, oilseeds,
cotton, jute, sugarcane, tobacco, tea, and coffee; largely self-sufficient
in foodgrains, but caloric intake is still low and diet is deficient in
protein
Fishing: catch 1.6 million tons (1970), $275 million (1969); exports 26.9 million
(1969), imports $61 thousand (1969)
Major industries: textiles, food processing
Crude steel: 6.1 million metric tons produced (1970)
Electric power: 16,099,000 kw. capacity (1970); 59.2 billion kw.-hr. produced
(1970), 108 kw.-hr. per capita
Exports: $2 billion (f.o.b., FY70); tea, jute manufactures , iron ore, cotton
textiles, leather and leather products, iron and steel
Imports: $2.2 billion (Cotte FY/0)3 machinery and transport equipment, grains
and flour
Major trade partners: U.S., U.K., U.S.S.R. and Eastern Europe, Japan
Monetary conversion rate: 7.5 rupees=US$1
Fiscal year: 1 April, stated year - 31 March
GNP: $10.2 billion (1971 est.), $350 per capita; real GNP growth, FY70-71, 9.4% est.
Agriculture: dates, fruit, nuts, vegetables, grains, sugar beets, cotton, gum,
rice, sheep, and goats
Electric power: 2,842,000 kw. capacity (1970); 12 billion kw.-hr. produced
(1970), 410 kw.-hr. per capita
Exports: $2,360 million (f.0.b., 1970); 89% petroleum; also carpets, raw cotton,
fresh and dried fruits, hide and leather items, ores; Communist countries
(primarily U.S.S.R.) took about 4.5% of total exports
Imports: $1,632 million (c.i.f.; 1970); machinery, iron and steel products,
chemicals, pharmaceuticals, electrical equipment; Communist countries
supplied 12% of commodity imports
Major trade partners: exports -- U.K., Japan, U.S., South Africa, U.S.S.R. and
other Communist countries; imports -- West Germany, U.S., U.S.S.R., U-K.,
Japan, Italy, France, Netherlands
Monetary conversion rate: 75.75 rials=US$1
Fiscal year: 21 March - 20 March
GNP: $2,693 million in 1969, $300 per capita
Agricul ture: dates, wheat, barley, rice> livestock; largely self-sufficient
in food
Major industry: crude petroleum (fourth largest producer in Middle East)
Electric power: 740,000 kw. capacity (1970); 2 billion kw.-hr. produced (1970) 5
220 kw.-hr. per capita
Exports: $63 million (f.0.b-> 1970), not including oi] revenue of $513.3 million
Imports : $509 million (c.i.f.> 1970); 26% from Communist countries (1969)
Major trade partners : exports (non oil) -- U.S: 7%, Western European countries 4%;
Communist countries 15%, Arab countries 54%, other 20%; imports -- U.S. 4%,
Western European countries 44%, Japan 3%, Communist countries 26%, Arab
countries 7% other 16%
Approved F -
or Release 2004/08/31 : CIA-RDP79-01051A000400
010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ZCONOMY (cont''d):
Monetary conversion rate: 1 Iraqi dinar=US$2.80 (freely convertible); 0.357
Iraqi dinar=US$1
Fiscal year: 1 April - 31 March
GNP: $3,950 million (1970 est.), $1,350 per capita; 67.3% consumption, 22.5%
investment, 13.9% government; -3.7% net export of goods and services;
1970 real growth rate 1.4% est., 1958 constant prices
Agriculture: about 2/3 of agricultural area used for permanent hay and pasture;
main products -- livestock and dairy products, barley, potatoes, sugar beets,
wheat; 85% self-sufficient; food shortages -- grains, fruits, vegetables;
caloric intake 3,450 calories per day per capita (1968)
Fishing: catch 66,200 tons, $13.7 million (1969); exports of fish and fish products
$6.7 million (1968), imports of fish and fish products $6.2 million (1968)
155
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RI - -
ECONOMY (cont''d): pp I DP79-01051A000400010002-1
Major industries: food products, brewing, textiles and clothing, machinery and
transportation equipment
Shortages: coal, petroleum, timber and woodpulp, steel and nonferrous metals,
fertilizers, cereals and animal feeds, textile fibers and textiles
Crude steel: 67,000 metric tons produced in 1968, 20 kilograms per capita
Electric power: 1,500,000 kw. capacity (1970); 5,652 million kw.-hr. produced
(1970), 1,555 kw.-hr. per capita
Exports: $1,034 million (f.o.b., 1970); live animals, meat, textile products,
clothing, machinery, dairy products, chemicals
Imports: $1,570 million (c.i.f., 1970); machinery, chemicals, textiles,
transportation equipment, petroleum, metal manufactures, cereals
Major trade partners: 14.5% EC, 5.4% West Germany, 62.7% EFTA, 58.4% U.K., 8.2% U.S.,
1.5% Communist countries (1970)
Aid: economic -- U.S., $193 million authorized (FY49-70), no activity (FY55-66),
$46.5 million authorized (FY67-70), $14.7 million authorized in FY69, none
authorized in FY70; IBRD $14.5 million authorized (FY69), none authorized in
FY70
Monetary conversion rate: 1 Irish pound=US$2.40 (official)
Fiscal year: 1 April - 31 March
GNP: $93.2 billion (1970), $1,740 per capita; 63.9% consumption, 22.7% investment,
12.7% government, net foreign balance 0.7% (1970); 1970 provisional growth
rate 5.1%, 1963 constant prices
Agriculture: important producer of fruits and vegetables ; main crops -- cereals,
potatoes, olives; 95% self-sufficient; food shortages -- fats, meat, fish,
and eggs; caloric intake, 3,100 calories per capita (1970)
Fishing: catch 353,100 metric tons (1969), $196 ,558 ,000 (1969); exports $8,142,000
(1969), imports $131,715,000 (1969)
Major industries: machinery and transportation “equipment, iron and steel,
chemicals, food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 17.3 million metric tons produced (1970), 320 kilograms per capita
Electric power: 33 million kw. capacity (1970); 115,600 million kw.-hr.
produced (1970), 2,200 kw.-hr. per capita
Exports: $13.2 billion (f.0.b., 1970); principal items -- machinery and
transport equipment, textiles, foodstuffs, chemicals
Imports: $14.8 billion (c.i.f., 1970); principal items -- machinery and
transport equipment, foodstuffs, ferrous and nonferrous metals, wool, cotton
Major trade partners: (1970) 21% West Germany , 10% U.S., 13% France, 4% U.K.,
4% Belgium-Luxembourg , 4% Netherlands, 3% Switzerland; 42% EC; 12% EFTA; 6%
Communist countries
Aid:
economic -- U.S., $3,893 million (FY46-70), $121.8 million authorized FY70;
IBRD, $398 million authorized through FY68, none since FY65; International
Finance Corporation, $1 million authorized through FY67, none since FY60;
military -- U.S., $2,466 million (FY46-69), $62.4 million authorized in
FY68 (Export-Import Bank credits), none in FY69
Monetary conversion rate: 625 lira=US$1 (official); as of 30 September 1971 the
actual rate was 612 lira=US$1
Fiscal year: calendar year
GDP: $1.5 billion (1970), $350 per capita (1970); average annual growth
rate 1960-670, 8%
Agriculture: commercial -- coffee, wood, cocoa, bananas, pineapples, palm oil;
food crops -- corn, millet, yams, rice; other commodities -- cotton, rubber,
tobacco, fish; self-sufficient in most foodstuffs, but rice, sugar, and meat
imported
Fishing: catch 70,000 tons (1970), $12.7 million (1969); exports. $1.6 million
(1969), imports $1.9 million (1969)
163
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Major industries: food and lumber processing, oil refinery, automobile assembly
plant, texiltes, soap, flour mill, matches, three small shipyards
Electric power: 180,000 kw. capacity (1970); 540 million kw.-hr. produced (1970),
128 kw.-hr. per capita
Exports: $470 million (f.o.b., 1970); coffee, tropical woods, cocoa, 76% of total;
bananas, pineapples, palm oil
Imports: $389 million (c.i.f., 1970); consumer goods 44%, raw materials and fuels
8%, manufactured goods and semi-finished products, 48%
Major trade partners: France and other EC countries about 65%, U.S. 13%, Communist
countries about 1%
Aid:
economic -- France (1960-69) $312 million; EC $123 million, including 1971
commitments; U.S. (FY61-70), $85.6 million; others (1960-71), $76 million,
including $18.5 million comitted; no Communist aid programs
military -- non-Communist countries, $7.3 million (1954-67)
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs (prior to 13 August 1971, 277 CFA francs=US$1)
Fiscal year: calendar year
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
GNP: $1,177.6 million (1970), $590 per capita; real growth rate 1969, 5%
Agriculture: main crops -- sugarcane, citrus fruits, bananas, pimento, coconuts ,
coffee, cocoa
Major industries: bauxite, textiles, food processing, light manufactures , tourism
Electric power: 550,000 kw. capacity (1970
(1969). 650 kw.-hr. per capita
est.); 1,270 million kw.-hr. produced
Exports: $340 million (f.o.b., 1970); alumina, bauxite, sugar, bananas, citrus
fruits and fruit products, rum, cocoa
Imports: $522 million (c.i.f., 1970); machinery, transportation and electrical
equipment, food, fuels, fertilizer
Major trade partners: exports -- U.S. 52%»
U.K. 16%, Canada 8%, Norway 8%3
imports -- U.S. 43%, U.K. 19%, Canada 9% (1970)
Aid:
economic -- extensions from U.S. (FY56-70), $43.2 million in loans; (AID
$10.7 million, Import-Export Bank $32.5 million), $38.4 million grants (AID
technical assistance $14.2 million, Food for Freedom $24.2 million); from
international organizations (FY46-70) »
countries (FY46-69), $54.0 million;
$55.6 million; from other Western
military -- assistance from U.S. (FY63-70), $1.1 million
Monetary conversion rate: 1 Jamaican dollar=US$1 .20
Fiscal year: 1 April - 31 March
GNP: $190 million, $1,780 per capita (1969 est.)
Agriculture: main crops -- coffee, copra, fruits, and vegetables
Industry: mining of nickel
Electric power: 105,000 kw. capacity (1970); 725 million kw.-hr. produced (1970),
6,780 kw.-hr. per capita :
Exports: $131 million (f.0.b., 1969) 98% nickel
Imports: $124 million (c.i.f., 1969)
Major trade partners: (1968) exports -- France (47%), Japan (40%); imports --
France (49%), Australia (19%)
Monetary conversion rate: 95 CFP francs=US$1
Approved For Release 2004/08/34 = CIA-RDP79-01051A000400010002-1
COMMUNICATIONS : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: 2,900 mi.; 180 mi. paved; 1,170 mi. gravel, crushed stone, or stabilized
surface; 1,550 mi. unimproved earth
Inland waterways: none
Ports: 1 major, 21 minor
Civil air: no major transport aircraft
Airfields: 34 total, 29 usable; 2 with permanent-surface runways ; 2 with
runways 4,000-7,999 ft.; 1 airfield over 8,000 ft.; 1 seaplane station
Telecommunications: 8,073 telephones; 25,000 radio and 8,000 TV sets; 1 AM,
no FM, and 1 TY stations
236
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Next 1 Page(s) In Doc','5cc606212b34b8a167aaa2096f7d17e1ce16e75ed70e8fa9ad91ced498dbcaf8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33c14b618176a34085dbafe50a0940dfefd6f3873c8a007cd9828d9c397020dd',1971,'BR','Brazil','economy',17,'ument Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A .
ined pproved For Release 2004/08/3ApnGJA-RDP79-01051A000400010002-1
LAND:
57,100 sq. mi.; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other (1963)
Land boundaries: 760 mi.
WATER: Be OEE
Limits of territorial waters: 3n. mi. (fishing, 200 n. mi.) Gases” Ped
Coastline: 565 mi. EES SESS oo omaua
PEOPLE: fo See
Population: 1,926,000, average annual growth rate 2.6% i ee,
(April 63-September 71); males 15-49, 505,000; 300,000 |... 2
fit for military service; 24,000 reach military age
(18) annually
Ethnic divisions: 75% mestizo, 15% white, 10% Negro, Indian or mulatto
Religion: 96% Roman Catholic
Language: Spanish (official); small English-speaking minority on Atlantic coast
Literacy: 50% of population 10 years of age and over
Labor force: 475,000 (est. mid-1970); 57% agriculture, 12% manufacturing, 14%
services, 17% other; shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: about 6% of labor force
GNP: $933 million (purchasing power parity estimate, 1970), $470 per capita; 73%
private consumption, 10% government consumption, 19% domestic investment, -2%
net foreign balance; real growth rate 1970, 4.5%
Agriculture: main crops -- cotton, coffee, sugarcane, rice, corn, beans; caloric
intake, 2,300 calories per day per capita (1966)
Fishing: catch 7,200 tons (1970)
Major industries: food processing, textiles and clothing, chemicals, petroleum
products
239
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d):
Electric power: 173,000 kw. capacity (1969 est.); 550 million kw.-hr. produced
(1969 est.), 290 kw.-hr. per capita
Exports: $179 million ey: cotton, coffee, cottonseed, meat, sugar
Imports: $178 million (1970); machinery, equipment, vehicles, manufactures,
chemicals, foods, fuels
Major trade partners: exports -- U.S. 33%, Japan 19%, CACM 21%; imports -- U.S.
38%, CACM 24%, West Germany 7% (1969)
Aid:
economic -- extensions from U.S. (FY46-70), $105.8 million loans, $61.4
million grants; international organizations, $124.2 million (1946-69);
military -- from U.S. (FY53-70), $12.8 million (1946-70)
Monetary conversion rate: 7 cordobas=US$1 (official)
Fiscal year: calendar year
GDP: $319 million (1966 est.), less than $100 per capita
Agriculture: commercial -- peanuts, cotton, livestock; main food crops --
millet, sorghum, niebe beans, vegetables
Major industries: cement plant, brick factory, rice mill, small cotton gins, oi]
presses, slaughterhouse, and a few other small light industries; uranium
production began, in 197]
Electric power: 40,000 kw. capacity (1970); 40 million kw.-hr. produced (1970),
10 kw.-hr. per capita
Exports: $31.4 million (f.o.b., 1968-69 est.); about 74% peanuts and related
products, rest largely livestock, hides, skins; exports badly understated
because much regional trade not recorded
Imports: $31.2 million (c.i.f., 1968-69 est.); fuels, machinery, transport equip-
ment, foodstuffs, consumer goods (largely for European residents); sizable
imports unrecorded
241
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Major trade partners: France (about 50%), other EC countries, Nigeria, UDEAC
countries, U.S.; preferential tariff to EC and franc zone countries
Aid:
economic -- France (1960 to mid-1967) $68 million; EC (1966-67) $51.3 million;
U.S. (FY62-70) $15.8 million; West Germany, Israel, Republic of China, and U.N.
have also extended aid;
military -- $2.8 million (1954-68)
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: 1 October - 30 September
GDP: $4.9 billion (1970 est.), probably about $80 per capita; 6.3% growth rate
assumed FY69-70
Agriculture: main crops -- peanuts, cotton, cocoa, rubber, yams. cassava,
sorghum, palm kernels, millet, corn, rice; livestock; almost self-sufficient
Fishing: catch 114,000 tons (1970 est.); imports $4 million (1970)
243
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Rel .
ECONOMY (cont''d): ease 2004/08/31 : CIA-RDP79-01051A000400010002-1
Major industries: processing industries -- oil palm, peanut, cotton, rubber,
petroleum, wood, hides, skins; manufacturing industries -~- textiles, cement,
building materials, food products, footwear, chemical, printing, ceramics;
mining -- crude oil, natural gas, coal, tin, columbite
Electric power: 1,111,000 kw. capacity (1970 est.); 1,667 million kw.-hr. produced
(1970 est.), 30 kw.-hr. per capita
Exports: $1,240 million (f.0.b., 1970); oil, peanuts, palm products, cocoa, rubber,
cotton, timber, tin
Imports: $1,059 million (c.i.f., 1970); machinery and transport equipment, manu-
factured goods, textiles, chemicals
Major trade partners: U.K., EC, U.S.
Monetary conversion rate: 1 Nigerian pound=US$2.80 (official )
Fiscal year: 1 April - 31 March
Agriculture: based on subsistence farming (fruits, dates, cereals, cattle, camels,
fish) and trade
Major industries: petroleum discovery in 1964; production began in 1967; production
1970 equaled 333,000 b.p.d.; pipeline capacity 400,000 b.p.d.; revenue for
1970 about 108 million
Electric power: 24,000 kw. capacity (1970); 70 million kw.-hr. produced (1970),
120 kw.-hr. per capita
Exports: petroleum exports worth $140 million (1968); dates, fish, limes, hides,
wool $930,000 (1970)
Imports: ‘anche goods, automobiles, electrical goods, machinery $18 million
1970
Major trade partners: U.K., Gulf states, India, Australia, China, Japan
Aid: multilateral annual average 1967-69 $350,000
Monetary conversion rate: new currency introduced Riyal Said; RO.42=US$1
Fiscal year: no budget year
GNP: $16.2 billion (FY71), $120 per capita; real growth (FY71) 5.8%
Agriculture: largely subsistence farming, heavily dependent on monsoon rainfall
in East Pakistan and extensive irrigation in West Pakistan; main crops --
Jute and rice in the East, and wheat and cotton in the West; West largely
self-sufficient; East -- shortages in rice and wheat
Fishing: catch 455.9 thousand tons, $191.8 million (1969)
Major industries: cotton textiles, jute manufacturers, food processing, natural gas
Electric power: 2,616,000 kw. capacity (1970); 7.85 billion kw.-hr. produced
(1970), 69 kw.-hr. per capita
Exports: $706 million (f.o.b., FY71); jute and cotton (raw and manufactured)
Imports: $1,071 million (c.i.f., FY71) machinery, transport equipment, chemicals
Major trade partners: U.S., U.K., Japan, West Germany
Monetary conversion rate: 4.762 rupees=US $1
Fiscal year: 1 July - 30 June
GNP: $755 million (purchasing power parity estimate, 1970), $320 per capita; 77%
private consumption; 11% public consumption; 15% gross domestic investment;
-3% net foreign balance (1968); real growth rate 1970, 7%
Agriculture: main crops -- oilseeds, cotton, wheat, manioc, sweet potatoes,
tobacco, corn, rice, sugarcane; self-sufficient in most foods; caloric
intake, 2,580 calories per day per capita (1963-64); protein intake,
70 grams per day per capita (20 grams of animal origin)
Major industries: meat packing, oilseed crushing, milling, brewing, textiles,
light consumer goods, cement
257
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Electric power: 150,000 kw. capacity (1970 est.); 201 million kw.-hr. produced
(1970 est.), 80 kw.-hr. per capita
Exports: $64 million (f.o.b., 1970); meat, timber, oilseeds, tobacco, cotton,
quebracho extract, hides, yerba mate
Imports: $76 million (c.i.f., 1970); foodstuffs, machinery, transport equipment,
engines, consumer durables, fuels and lubricants, textiles
Aa trade partners: U.S. 25%, Argentina 20%, West Germany 8%, U.K. 8%
Aid:
economic -- extensions from U.S. (FY46-70), $79.3 million loans, $53.9 million
grants; from international organizations (FY46-68), $88.4 million; from. other
Western countries (1960-66), $7.4 million;
military -~ assistance from U.S. (FY58-70), $11.0 million
Monetary conversion rate: 126 guaranies=US$1 (selling rate)
Fiscal year: calendar year
GNP: $8.3 billion (purchasing power parity estimate, 1970), $610 per capita; 72%
private consumption, 10% public consumption, 13% gross investment (1970); 5%
net foreign balance; real growth rate 1970, 7%
Agriculture: main crops -~- wheat, corn, potatoes, beans, barley, coffee, cotton,
sugarcane; imports wheat, meat, lard and oils, rice, corn; caloric intake,
2,300 calories per day per capita (1964)
Fishing: catch 12.6 million tons (1970); exports $300.3 million (1970), imports
$0.3 million (1969)
259
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Major industries: mining of metals, petroleum, fishing, textiles and clothing,
food processing, cement
Electric power: 2 million kw. capacity (1970); 5.3 billion kw.-hr. produced
(1970), 390 kw.-hr. per capita
Exports: $1,048 million (f.o.b., 1970); fish and fish products, copper, silver,
iron, cotton, sugar, lead, zinc, petroleum, coffee
Imports: $618 million (f.o.b., 1970); foodstuffs , machinery, transport equipment,
dron and steel semimanufactures, chemicals, pharmaceuticals
Major trade partners: exports -- U.S. 33%, Western Europe 42%, Japan 14%, Latin
America 6%; imports -- U.S. 32%, Western Europe 33%, Latin America 17%,
Japan 6% (1970)
Aid:
economic -- extensions from U.S. (FY46-70), $453 million loans, $178
million grants; from international organizations (FY46-70), $372 million;
from other Western countries (1960-66), $43.4 million; Communist countries
(1968-70) $59.3 million;
military -- assistance from U.S. (FY49-70), $141 million
Monetary conversion rate: 38.70 soles=US$1 (trade); 43.38 soles=US$1 (non- trade)
August 1971
Fiscal year: calendar year
GNP: $8.5 billion (1970), $210 per capita
Agriculture: main crops -- rice, corn, coconut, sugarcane, abaca, tobacco
Fishing: catch 978,000 tons, $332 million (1969)
261
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d):
Major 7 ndustPROVSd 5 ef FREISASE,ZOQ4L9 RLS telATRPP @ rep OS 1A900 40004 M a se
products
Electric power: 2,201,000 kw. capacity (1970); 8.3 billion kw.-hr. produced
(1970), 216 kw.-hr. per capita
Exports: $1,062 million (f.0.b., 1970); copra, sugar, logs and lumber, coconut
oil, copper concentrates, abaca
Imports: $1,210 million (c.i.f., 1970)
Major trade partners: (1968) exports -- 43% U.S., 39% Japan; imports -- 29%
U.S., 35% Japan
Aid:
economic -- U.S. (FY46-69), $1.5 billion committed; Japan (reparations),
$550 million extended in 1956, $337 million drawn through July 1969; IBRD
(1953-68), $158 million committed;
military -- U.S. (FY46-68), $552.3 million committed
Monetary conversion rate: 6.43 pesos=US$1 (July, 1970) (floating rate)
Fiscal year: 1 July - 30 June
GNP: $43.8 billion in 1970 at 1969 prices, $1,330 per capita; 1970 growth rate
4.5%
Agriculture: self-sufficient for minimum requirements; main crops -- grain,
sugar beets, oilseeds, potatoes, exporter of livestock products and sugar;
importer of grains; 3,300 calories per day per capita (1968-69)
*Excludes armed forces and other classified categories of employment.
263
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Major industries: chemistry, food processing, transportation equipment, machine
building, iron and steel, textiles, and shipbuilding
Crude steel: 11.8 million metric tons produced (1970), about 360 kg. per capita
Electric power: 13,875,000 kw. capacity (1970); 64.5 billion kw.-hr. produced
(1970), 1,965 kw.-hr. per capita
Exports: $3,548 million (f.o.b., 1970); 39% machinery and equipment, 33% fuels,
raw materials, and semimanufactures, 13% agricultural and food products,
16% industrial consumer goods
Imports: $3,608 million (f.o.b., 1970); 36% machinery and equipment; 48% fuels,
raw materials, and semimanufactures; 10% agricultural: and food products ;
6% industrial consumer goods
Major trade partners: $7,155 million (1970); 66% with Communist countries, 34%
with West (1970)
Monetary conversion rate: 4 zlotys=US$1 (commercial); 24 zlotys=US$1 (noncommercial )
Fiscal year: same as calendar year; economic data are reported for calendar
years except for caloric intake which is reported for the consumption year,
1] July - 30 June
GNP: $6,350 million, $660 per capita (1970 est.); 72.9% consumption, 17.7%
investment, 14.1% government, -4.7% net exports of goods and services (1970),
growth rate 6.6% (1970) in 1963 constant prices
Agriculture: generally underdeveloped; main crops -- grains, potatoes, olives,
grapes for wine; food shortages -- sugar, wheat; caloric intake, 2,930
calories per day per capita (1968)
Fishing: catch 334,000 tons, $74.1 million; exports $47.3 million, imports $24.6
million, trade includes fish and fish products
Major industries: cotton textiles, cork processing, fish canning, petroleum
refining, pulp and paper, chemical fertilizer
Shortages: coal, petroleum, cotton, steel
Crude steel: .38 million metric tons produced (1970), 40 kg. per capita (1970)
Electric power: 2,700,000 kw. capacity (1970); 7,400 million kw.-hr. produced
(1970), 1,000 kw.-hr. per capita
Exports: $946 million (f.o.b. 1970); principal items -- cotton textiles, cork
and cork products, canned fish, wine, timber and timber products, resin
Imports: $1,556 million (c.i.f., 1970); principal items -- petroleum, cotton,
industrial machinery, iron and steel, chemicals
Major trade partners: (1969) 16.5% U.K., 12% West Germany, 6.1% France, 7.6%
U.S., 10.7% Angola, 6% Mozambique; 27.5% EC; 28.8% EFTA; .7% Communist
countries
Aid:
economic -- U.S., $180.7 million (1949-70), $4.7 million authorized 1969,
$4.3 million authorized 1970; IBRD, $57.5 million authorized (1964-66), none
since 1966; net official aid to less developed areas and multilateral agencies
$462 million (1961-70), $79.5 million (1969), $57.1 million (1970);
military -- U.S., $328.1 million authorized (1949-70), $2.7 million authorized
in 1969, $1.3 million authorized in 1970
Monetary conversion rate: 28.75 escudos=US$1 (official)
Fiscal year: calendar year
Agriculture: main crops -- palm oil, root crops, rice, coconuts, peanuts.
Electric power: 1,200 kw. capacity (1970); 2 million kw.-hr, produced (1970),
4 kw.-hr. per capita
Exports: $3.2 million (f.o.b., 1967); principally peanuts, coconuts
Imports: $16.4 million (c.i.f., 1967); manufactured goods, fuels, transport
equipment, rice
Major trade partners: mostly Portugal, also immediate neighbors
Aid: Portugal, small amounts
Monetary conversion rate: 28.75 escudos=US$1 (official)
Fiscal year: probably is the calendar year
269
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: approx. 2,000 mi. (205 mi. bituminous, remainder earth)
Inland waterways: 994 mi.
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 63 total, 60 usable; 3 with permanent-surface runways; 9 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: limited telephone and telegraph service; 1,800 telephones ;
3,600 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Defense is responsibility of Portugal
270
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Appro
iia gy HPPRONGG or Helene 200 Orel se Clo 72-0105 1800400010002.
LAND:
7,000 sq. mi.3 34% forest, 33% grass land, and 33%
cultivated (1968)
Land boundaries: 90 mi.
WATER: xf
Limits of territorial waters: territorial sea claim 6n. mi. MOR
(fishing, 12 n. mi.) ngernaLe
Coastline: 1,600 mi. :
GNP: less than $100 per capita
Agriculture: principal crops -- corn, rice, rubber, coffee, copra
Electric power: 2,000 kw. capacity (1970); 8 million kw.-hr. produced (1970),
13 kw.-hr. per capita
Exports: $2.6 million (f.0.b., 1967); coffee, copra
Imports: $5.2 million (ert cbig 196h)
Major trade partners: Portugal and its possessions , Singapore, and Hong Kong
271
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA- m .!
ECONOMY (cont''d): PP IA-RDP79-01051A000400010002-1
Monetary conversion rate: Portuguese escudo known in Timor as pataca; 28.75
patacas=US$1
Fiscal year: calendar year
GNP: $4.6 billion (FY70), $1,650 per capita
Agriculture: main crops -- sugar, coffee, tobacco, bananas
Major industries: textiles, clothing manufacture, food processing, petroleum
refining, petro-chemicals
Electric power: 1.2 million kw. capacity (1969); 5.9 billion kw.-hr. produced
(1969 est.), 2,010 kw.-hr. per capita
Exports: $1,680 million (f.o.b., 1970); sugar, pineapple, citrus fruits, coffee,
rum, textiles
Imports: $2,680 million (f.o.b., 1970); food, machinery, transportation equip-
ment, fuels, minerals
Major trade partner: exports -- U.S. 93%; imports -- U.S. 77%
Monetary conversion rate: uses U.S. currency
Fiscal year: 1 July - 30 June
Approved For Release 2004/08/31“ GIA-RDP79-01051A000400010002-1
COMMUNICATIONS: Approved For Release 2004/08/31 : CIA-RDP79- dn tartan 002-1
Railroads: more than 450 mi. plantation lines; 6 gages from 1''8" to 3''3 3/8"
with latter predominating
Highways: 4,800 mi.; 3,900 mi. paved, 260 mi. gravel, 640 mi. otherwise
improved and unimproved earth
Inland waterways: negligible
Pipelines: refined products , 90 mi.
Ports: 3 major, 7 minor
Civil air: major transport aircraft are included in U.S. registered total
Airfields: 31 total, 27 usable; 16 with permanent-surface runways 3 3 with
runways 8,000-11, 999 ft., 9 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: highly developed telecom system of open-wire and radio relay
links; communications satellite ground station; 302,300 telephones; over
1] million radio and 410,000 TV receivers; 48 AM , 18 FM, and 11 TV stations;
5 submarine cables, including 4 coaxial
DEFENSE FORCES:
Defense is responsibility of U.S.
274
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 32 Approved For Release 2004/08/$t Ar(CIA-RDP79-01051A000400010002-1
LAND:
About 4,000 sq. mi.; negligible amount forested; mostly
desert, waste, or urban (1963)
Land boundaries: 35 mi.
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: 350 mi.
GNP: $65 million (1969 est.)
Agriculture: farming and grazing on small scale; commercial fishing increasing
in importance; most food imported; rice and dates staple diet
Major industries: oil production and refining; crude oil] production from onshore
and offshore averaged 362,000 bbls. per day in 1970; oi] revenues estimated
$122 million at the beginning of 1970, representing 99% of government/royal
family income; major development projects include $7 million harbor at Ad Dawhah,
fertilizer plant, 2 desalting plants, refrigerated storage for fishing, and
a cement plant
Electric power: capacity 80,000 kw. (1970); 200 million kw.-hr. produced (1970),
1,709 kw.-hr. per capita
Exports: crude oi] dominates; reexports $56 million (1968)
Imports: approx. $53 million in 1969
Aid: multilateral annual average $170,000 (1967-69)
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.21
Fiscal year: 1 April - 31 March
Agriculture: cash crops -- almost entirely sugarcane, small amounts of vanilla
and perfume plants; food crops -- tropical fruit and vegetables, manioc,
bananas, corn, market garden produce, also some tea, tobacco, and coffee;
food crop inadequate, most food needs imported
Major industries: 12 sugar processing mills, rum distilling plants, cigarette
factory, 2 tea plants, fruit juice plant, canning factory, a slaughterhouse,
and a number of small shops producing handicraft items
Electric power: 54,400 kw. capacity (1970); 108 million kw.-hr. produced (1970),
246 kw.-hr. per capita
Exports: ne million (f.o.b., 1968); 84% sugar, 10% perfume essences, 5% rum,
1% vanilla
Imports: $126 million (c.i.f., 1968); 45% manufactured goods, 30% food, beverages,
and tobacco, 20% machinery and transportation equipment, 5% raw materials
and petroleum products
Major trade partners: France (supplies 75% of Reunion''s imports, purchases 90%
of its exports); Madagascar (supplies 6% of its imports) :
277
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: probably calendar year
GDP: $1,359 million (1970 est.), $260 per capita; real growth rate 4.5% (1970)
Agriculture: main crops -- tobacco, corn, sugar, cotton, citrus fruits; live-
stock; self-sufficient in foodstuffs except wheat
279
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved F : Z| z
ECONOMY (cont''d): pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Major industries: mining and steel, textiles
Electric power: 1,187,000 kw. capacity (1970); 5,580 million kw.-hr. produced
(1970), 1,160 kw.-hr. per capita
Exports: $384 million (f.o.b., 1970), including net gold sales and reexports ;
tobacco, asbestos, copper, clothing, meat, chrome, sugar
Imports: $329 million (f.o.b., 1970); textiles, machinery, petroleum products,
wheat, transport equipment
Major trade partners: South Africa, Portugal, and Portuguese territories
Aid: no substantial military or economic aid
Monetary conversion rate: 1 Rhodesian dollar=US$1.40 (official); 0.714 Rhodesian
dollar=US$1
Fiscal year: 1 July - 30 June
GNP: $23.2 billion in 1970 (at 1969 prices), $1,140 per capita; 1970 growth rate
5.0%
Agriculture: net exporter; main crops -- corn, wheat, oilseed; livestock --
cattle, hogs, sheep; caloric intake, 3,000 calories per day per capita (1967-68)
Major industries: machinery, metals, fuels, chemicals, textiles, food processing,
timber processing
ura tee iron ore, coking coal, metallurgical coke, cotton fibers, natural
rubber
281
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A dForR : - - -
ECONOMY (cont''d): pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Crude steel: 6.5 million metric tons produced (1970), 320 kg. per capita
Electric power: 7.5 million kw. capacity (1970); 34.9 billion kw.-hr. produced
(1970), 1,710 kw.-hr. per capita
Exports: $1,850 million (f.o.b., 1970); 22% machinery and equipment; 40% fuels,
as oe semifinished products; 22% foodstuffs; and 16% consumer goods
1969
Imports: $1,949 million (mixture f.o.b. and c.i.f., 1970); 44% machinery and
equipment; 46% fuels, raw materials, semifinished products; 4% foodstuffs;
and 6% consumer goods (1969) ;
Major trade partners: $3,799 million in 1970; 45% non-Communist countries, 55%
Communist countries
Monetary conversion rate: 6 lei=US$1 (commercial); 12 lei=US$1 (noncommercial);
18 lei=US$1 (tourist)
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year, 1 July -
30 June
GDP: $195 million (1970), $50 per capita
Agricul ture: cash crops -- mainly coffee, tea, cotton, some pyrethrum; main
food crops -- bananas, Cassava; stock raising; self-sufficiency increasing
but country still imports some foodstuffs
Major industries: mining of cassiterite (tin ore), agricultural processing, and
light consumer goods
Electric power: 21,460 kw. capacity (1970); 100 million kw.-hr. produced (1970),
28 kw.-hr. per capita
Exports: $24.6 million (f.0.b., 1970); mainly coffee, tea, pyrethrum, cassiterite
Imports: $26.4 million (c.i.f., 1970); textiles, foodstuffs, machines, equipment
* Major trade partners: U.S., Belgium, Congo (Kinshasa)
Aid: U.S., FY64-70, $7.5 million; Belgium, France, Germany, and Canada, FY64-67,
$33.4 million obligated
Monetary conversion rate: 100 Rwanda franc','68b7571d8e4c578e79f52b26d68675206969a2241bac81d7def3ade54f826851','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4efda425355e29a33cf15427a16a1e3cc98d86ab2d753cc47ddf43e300c53c63',1971,'BR','Brazil','economy',18,'s=US$1 (official )
Fiscal year: calendar year
283
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: 3,728 mi.; 1,243 mi. primary roads (only 6 mi. paved), 2,485 mi.
secondary roads; most roads improved or unimproved earth
Inland waterways: Lake Kivu navigable by steamers and barges
Civil air: no major transport aircraft
Airfields: 20 total, 15 usable; 2 with permanent-surface runways; 2 with
runways 4,000-7,999 ft., 1 with runway 8,000-11,999 ft.
Telecommunications: telephone and telegraph limited; main center is Kigali;
1,400 telephones; 30,000 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, $3,900,000; about
20.4% of total budget
284
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 45 Approved For Release 2004/08/34.7 @A-RDP79-01051A000400010002-1
PEOPLE’S REP.
OF CHINA
LAND:
848 sq. mi.; 44% forested, 25% cropland, 10% grassland,
21% other, including building sites, roads, wasteland,
etc. (1968)
Land boundaries: 1,000 mi.
WATER:
Limits of territorial waters: 3 n. mi.
PEQPLE:
Population: about 999,000, average annual growth rate
1.1% (FY65-69); males 15-49, 240,000; 169,000 fit for
military service
Ethnic divisions: homogeneous; no significant minorities
Religion: basically animist; no significant minorities
Language: Japanese (strong local dialect)
Literacy: 95%
Labor force: 423,000; about 33.6% agriculture, forestry, fishing; 28.4% trade
and services; 16.9% industry; 11.6% government and utilities; 9% employed
by U.S. forces; .5% unemployed (1970)
Organized labor: 8% of labor force
GNP: $860 million (FY70), $870 per capita
Agriculture: sugarcane, pineapple, rice; 65% self-sufficient
Major industries: sugarcane and pineapple processing; various light industries
Electric power: 485,600 kw. capacity (1970); 1.42 billion kw.-hr. produced
(1970), 1,430 kw.-hr. per capita :
Exports: $108 million (f.o.b., FY70); sugar’, pineapples
Imports: $481 million (c.i.f., FY70)
Major trade partners: Japan, U.S.
Aid: economic -- U.S. (FY46-69), $397 million committed
Monetary conversion rate: U.S. currency used
Fiscal year: 1 July - 30 June
285
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS : Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: 2,060 mi.; 286 paved, 596 gravel, remainder earth
Pipelines: refined products, 33 mi.
Ports: 2 major, 3 minor
Civil air: 8 major transport aircraft (registered in Japan)
Airfields: 22 total, 16 usable; 12 with permanent-surface runways ; 1 with runway
over 12,000 ft., 2 with runways 8,000-11 ,999 ft., 8 with runways 4 ,000-7 ,999
ft.; 2 seaplane stations
DEFENSE FORCES:
Defense is responsibility of U.S.
286
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Nrs gia APProved For Release; 2004/08/3Jpi ATREP 7 9-01051A000400010002-1
LAND:
150 sq. mi.; 40% arable, 10% pasture, 17% forest, 33%
wasteland and built-on (1962)
WATER 7 bbe
Limits of territorial waters: 3 n. mi.
Coastline: 120 mi. VENEZUELA
PEQPLE: COLOMBIA
Population: 65,000 (official estimate for 31 December 1967),
average annual growth rate 1.2% (April 60-70) BRAZIL
Ethnic divisions: mainly of African Negro descent
Religion: Church of England, other Protestant sects, Roman
Catholic
Language: English
Literacy: about 80%
Labor force: not available
Organized labor: 6,700
GDP: $15.2 million (1969), $270 per capita
Agriculture: main crops -- sugar on St. Christopher, cotton on Nevis
Major industries: sugar processing, salt extraction
Electric power: 147,500 kw. capacity (1969 est.); 260 million kw.-hr. produced
(1969 est.), 437 kw.-hr. per capita
Exports: $4.3 million (f.o.b., 1969); sugar, molasses, cotton, salt, copra
Imports: $9.6 million (c.i.f., 1969); foodstuffs, fuel, manufactures
Major trade partners: U.K. 45%, Canada 14%, U.S. 12% (1966)
Monetary conversion rate: 1.93 East Caribbean dollars=US$1 (6 October 1971)
287
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: 180 mi.; 60 mi. paved, 90 mi. gravel, crushed stone, or improved
earth, 30 mi. unimproved earth
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 1 with asphalt runway 5,700 ft.
Telecommunications: good interisland VHF radio connections and international
link via Antigua; about 1,600 telephones; no data on radio, 6,000 TV
receivers; 2 AM and 1 TV stations
288
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 81A Approved For Release 2004/08{31) 1 )G/A-RDP79-01051A000400010002-1
LAND:
238 sq. mi.; 34% arable, 5% pasture, 21% forest, 22%
unused but potentially productive, 18% wasteland
and built-on (1964)
WATER: f \\,
Limits of territorial waters: 3 n. mi. * -wenesUELA
Coastline: 98 mi.
GDP: ay million (1968), about $190 per capita; real growth rate about
8% (1967
Agriculture: main crops -- sugar, rice, and citrus fruits
Major industry: mining
Electric power: 63,300 kw. capacity (1970); 204 million kw.-hr. produced (1970),
500 kw.-hr. per capita
321
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Exports: $68 million (f.o.b., 1970); iron ore, asbestos, sugar, wood and forest
products, citrus, meat products, cotton
Imports: $59 million (f.0.b., 1970); food products, manufactured goods, machinery,
fertilizer, fuel
Major trade partners: Japan, U.K., South Africa
Aid: economic aid -- U.K. $8.4 million (budgeted, 1971-72), others approximately
$2.9 million; no military aid
Monetary conversion rate: 1 South African Rand=US$1.40 (Swaziland uses the South
African Rand) (official); 0.714 SA Rand=US$1
Fiscal year: 1 April - 31 March
GNP: $31.2 billion, $3,850 per capita (1970); 52.3% consumption, 23.9% investment,
23.1% government; -0.7% net exports of goods and services (1970); 1970 growth
rate 9.4% in current prices
Approved For Release 2004/08/31 3741a-RDP79-01 051A000400010002-1
A dForR : - - S
ECONOMY (cont''d): pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Agriculture: animal husbandry predominates with milk and dairy products
accounting for 40% of farm income; main crops -- grains, sugar beets,
potatoes; 90% self-sufficient; food shortages -- oils and fats, tropical
products; caloric intake, 2,880 calories per day per capita (1967-68)
Major industries: iron and steel, precision equipment (bearings, radio and
telephone parts, armaments), shipbuilding, wood pulp and paper products,
processed foods, textiles, chemicals
Shortages: coal, petroleum, textile fibers, potash, salt
Crude steel: 5.5 million metric tons produced (1970), 680 kilograms per capita
Electric power: 15 million kw. capacity (1970); 60,612 million kw.-hr. produced
(1970), 7,000 kw.-hr. per capita
Exports: $6,743 million (f.o.b., 1970); machinery, motor vehicles
and ships, wood pulp, paper products, iron and steel products, metal ores
and scrap, chemicals
Imports: $6,937 million (c.i.f., 1970); machinery, motor vehicles, petroleum and
petroleum products, textile yarn and fabrics, iron and steel, chemicals, food,
and live animals
Major trade partners: (1970) West Germany 15.4%, U.K. 13.4%, U.S. 7.4%, Norway
7.9%, Denmark 8.8%; EFTA 40%; EC 31.0%; Communist countries 5.4%
Aid: economic -- U.S., $188.1 million authorized (FY46-70); none since 1968;
net official aid to less developed countries and multilateral agencies, $662.4
million (1960-70), $71.4 million in 1968, $120.8 million in 1969, $154.6
million in 1970
Monetary conversion rate: 5.173 kronor=US$1 (official )
Fiscal year: 1 July - 30 June
GNP: $20.1 billion (1970), $3,190 per capita; 57% consumption, 29% investment,
12% government, net foreign balance 2% (1970); 1970 growth rate 4.4%, 1958
constant prices
Approved For Release 2004/08/31 :-ClA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Agriculture: dairy farming predominates; less than 50% self-sufficient; food
shortages -- fish, refined sugar, fats and oils (other than butter), grains,
eggs, fruits, vegetables, meat; caloric intake, 2,990 calories per day per
capita (1967-68 est.)
Major industries: machinery, chemicals, watches, textiles, precision instruments
Shortages: practically all important raw materials except hydroelectric energy
Crude steel: 453,000 metric tons produced (1969), 70 kg. per capita
Electric power: 10.3 million kw. capacity (1971); 35,245 million kw.-hr. produced
(1970), 4,220 kw.-hr. per capita
Exports: $5.1 billion (f.o.b., 1970); principal items -- machinery and equip-
ment, chemicals, precision instruments, textiles, foodstuffs
Imports: $6.5 billion (c.i.f., 1970); principal items -- machinery and trans-
portation equipment, metals and metal products, foodstuffs, chemicals,
textile fibers and yarns
Major trade partners: West Germany 23%, France 10%, U.S. 9%, Austria 5%, Italy
9%, U.K. 8%; EC 49%; EFTA 20%; Communist countries 3% (1970)
Aid: some disbursed; none received
Monetary conversion rate: 4.0841 Swiss francs=US$1
Fiscal year: calendar year','ee330b193e3ff96f43d34fe2a9340acd47bb97625c516e051851082f598a985f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e824d0ab5cb71e37843b919b0bfffc34a6f77e0a31358abdf78de022de6eea0',1971,'IE','Ireland','economy',26,'Economic activity in Gibraltar centers on commerce and large British naval and
air bases. Nearly all trade in the well-developed port is transit trade and
port serves also as important supply depot for fuel, water, and ships'' wares.
Recently built dockyards and machine shops provide maintenance and repair
services to 3,500-4,000 vessels that call at Gibraltar each year.
U.K. military establishments and civil government employ nearly half the insured
labor force. Local industry is confined to manufacture of tobacco, roasted
coffee, ice, mineral waters, candy, and canned fish. Some factories for
manufacture of clothing are being developed. A small segment of local
population makes its livelihood by fishing. In recent years tourism has
increased in importance.
Approved For Release 2004/08/31 ! CIA-RDP79-01051A000400010002-1
eee,
Le |
ee en
1
TAY PRT
we
Approved For Release 2004/ : eI z p
ECONOMY (cont''d): PP 08/31 : CIA-RDP79-01051A000400010002-1
Electric power: 29,170 kw. capacity (1970); 47 million kw.-hr. produced (1970),
1,500 kw.-hr. per capita
Exports: $4.0 million (f.o.b., 1968); principally reexports of tobacco,
petroleum, and wine
Imports: $19.8 million (1967)
Major trade partners: U.K., France, Spain, Netherlands, Italy, West Germany
Monetary conversion rate: 1] Gibraltar pound=US$2 .40
GNP: $8.4 billion (1969), $950 per capita; 78% consumption, 22% investment;
1969 growth rate 8.5%, 1958 constant prices
123
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Agriculture: subject to droughts; main crops -- wheat, olives, tobacco, cotton,
nearly self-sufficient; food shortages -- livestock products; caloric intake,
2,960 calories per day per capita (1963)
Major industries: food processing, tobacco, chemicals, textiles, petroleum
refining, aluminum processing
Shortages: petroleum, minerals, feed grains
Crude steel: 210,000 metric tons produced (1969), 20 kg. per capita
Electric power: 2,614,000 kw. capacity (1970); 8,900 million kw.-hr. produced
(1970), 780 kw.-hr. per capita
Exports: $612 million (f.o.b., 1970); principal items -- tobacco, cotton, fruits,
metals ies
Imports: $1,696 million (c.i.f., 1970); principal items -- machinery and
automotive equipment, manufactured consumer goods, petroleum and
petroleum products, chemicals
Major trade partners: (1970) imports -- 43% EC, 14.5% sterling area, 15% U.S.,
6.4% CEMA countries; exports -- 40.4% EC, 10.7% sterling area, 15.6% U.S., z
16.5% CEMA countries
Aid:
economic (authorized) -- U.S., $1,887 million (1946-70), $14 million in 1970;
International Finance Corporation, $14.9 million through 1970; U.N. technical
assistance, $3.9 million through 1970; U.N. Special Fund, $8.2 million through
1970; IBRD, $32.5 million (1968-70), $20 million in 1970; Consortium, $40
million in 1966; EC (1964-70) $69.2 million;
military -- U.S., $2,020 million (1946-70)
Monetary conversion rate: 30 drachmae=US$1 (official)
Fiscal year: calendar year
GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep grazing; garden produce
Fishing: catch 39,200 tons, $4.5 million (1969)
Major industries: mining, slaughtering, fishing, sealing
Electric power: 25,000 kw. capacity (1970); 49 million kw.-hr. produced (1970),
580 kw.-hr. per capita
Exports: $13.2 million (f.o.b., 1968); fish and fish products, nonmetallic minerals
Imports: $45.7 million (f.o.b., 1968); machinery and transport equipment,
petroleum and petroleum products , food products
Major trade partners: (1968) Denmark 83.5%, U.S. 7.6%, Venezuela 3.2%
Monetary conversion rate: 7.5 Danish Kroner=US$1
Fiscal year: 1 April - 31 March
GDP: $22.0 million (1967), $220 per capita
Agriculture: main crops -- cocoa, spices, bananas
Electric power: 2,500 kw. capacity (1969); 8.75 million kw.-hr. produced (1969
est.), 82 kw.-hr. per capita
Exports: $5.1 million (f.0.b., 1968); cocoa beans, bananas, nutmeg, mace
Imports: $13.2 million (c.i.f., 1968); textiles, flour, clothing, miscellaneous
manufactured goods
Major trade partners: U.K. 37%, U.S. 9%, Canada 9% (1966)
Monetary conversion rate: 1.93 West Indies dollars=US$1 (6 October 1971)
GDP: $206 million (1968), $650 per capita; real growth rate (1968 est.) 1%
Agriculture: main crops, sugarcane and bananas
Major industry: agricultural processing, sugar milling and rum distillation
Electric power: 27,800 kw. capacity (1970); 72 million kw.-hr. produced (1970);
913 kw.-hr. per capita
Exports: $38 million (f.o.b., 1970), sugars bananas, rum
Imports: $128 million (c.i.f.> 1970), foodstuffs » clothing and other consumer
goods, raw materials and supplies; and petroleum
Major trade partners: exports -- France 71%, U.S. 17%, Germany 7%, other
5%; imports -- France 70%, U.S. 9%, Germany 3%, Netherlands Antilles 3%,
Netherlands 3%, other 12% (1968)
a 129
pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
anne com ce EPL PEE
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Monetary conversion rate: US$1=5.5187 francs (commercial), US$1=5.333 francs,
] October 1971
Fiscal year: calendar year
GNP: $2.0 billion (purchasing power parity estimate, 1969), $380 per capita; 79%
private consumption, 8% government consumption, 14% domestic investment, -1%
net foreign balance; real growth rate 1970, 5.6%
Agriculture: main products -- coffee, cotton, corn, beans, sugarcane, bananas ,
livestock; caloric intake, 2,200 calories per day per capita (1967)
Fishing: catch 3,700 tons (1970)
Major industries: food processing, textiles and clothing, furniture, chemicals,
nonmetallic minerals, metals
131
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Electric power: 230,000 kw. capacity (1970 est.); 730 million kw.-hr. produced
(1970 est.), 137 kw.-hr. per capita
Exports: $298 million (f.0.b., 1970); coffee, cotton, meat, bananas, sugar,
textiles, tires
Imports: $284 million (c.i.f., 1970); manufactured products, machinery, trans-
portation equipment, chemicals, fuels
Major trade partners: exports -~- U.S. 28%, CACM 29%, West Germany 10%, Japan
; 11%; imports -- U.S. 41%, CACM 20%, West Germany 10%, U.K. 17% (1968)
Aid:
economic -- extensions from U.S. (FY46-70), $171.3 million loans, $170.8
million grants; from international organizations (FY46-69), $108.8 million;
from other western countries (1960-68) $7.6 million;
military -- assistance from U.S. (FY46-70), $17.6 million
Monetary conversion rate: 1] quetzal=US$1 (official)
Fiscal year: calendar year
GDP: about $275 million (1965), $80 per capita
Agriculture: cash crops -- coffee, bananas, palm products, peanuts, and pine-
apples; staple food crops -- cassava, rice, millet, corn, sweet potatoes;
livestock raised in some areas
Major industries: alumina, light manufacturing and processing industries,
bauxite
Electric power: 99,700 kw. capacity (1970); 239 million kw.-hr. produced (1970),
60 kw.-hr. per capita
Exports: export receipts, $56 million (FY69-70); alumina, coffee, pineapples,
bananas, palm nuts
Imports: $66 million (FY69-70); petroleum products, metals, machinery and
transport equipment, foodstuffs, textiles
; 133
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Major trade partners: Communist countries, Western Europe (including France),
U.S.
Monetary conversion rate: 247 Guinea francs=US$1 (provisional)
Fiscal year: 1 October - 30 September','5a338889a68de93afe9683a19d009755a631746338f4a2241f956cd0ee547fda','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62fd9fb76e1cee18ad09f1520e6ae18b9b3604f29895c49f3b8992eb80eb22f5',1971,'ET','Ethiopia','economy',31,'GNP: $648 million (1969), $270 per capita
Agriculture: main crops -- cereals, fruits, vegetables, olive oil; not self-
sufficient in many foodstuffs
Major industries: phosphate mining, petroleum refining, and cement
Electric power: 61,800 kw. capacity (1970); 140 million kw.-hr. produced (1970),
60 kw.-hr. per capita
Exports: $34 million (f.0.b., 1970); major items -- fruits and vegetables,
phosphate rock; Communist share 9% of total (1970)
Imports: $183 million (c.i.f., 1970); major items -- petroleum products, textiles,
capital goods, motor vehicles, foodstuffs; Communist share 16% of total (1970)
Aid:
economic -- U.S., $601 million economic assistance (FY51-70), of which $31
million loans, $570 million grants;
military -- $184 million total from U.S. (July 1949-March 1971) including
$72 million in MAP grants
Monetary conversion rate: 1 Jordanian dinar=US$2.80, freely convertible; 0.357
Jordanian dinar=US$1
Fiscal year: 1 January - 31 December
GNP: $1.33 billion (1969), $120 per capita; 6.3% real growth per year between
1964 and 1969
Agriculture: main cash crops -- coffee, sisal, tea, pyrethrum, cotton, livestock;
food crops -- corn, wheat, rice, cassava; largely self-sufficient in food
Fishing: catch 31,900 tons, $3,424,000; exports $230,000, imports $1,097,000
Major industries: small-scale consumer goods (plastic, furniture, batteries,
textiles, soap, agricultural processing, cigarettes, flour), oil refining,
cement
Electric power: 153,000 kw. capacity (1970); 402 million kw.-hr. produced (1970),
38 kw.-hr. per capita
171
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d):
Exports: $250.2 million (f.0.b., 1969); coffee, tea, livestock products, pyrethrum,
soda ash, wattle-bark tanning extract
Imports: $338.6 million (c.i.f., 1969); machinery, transport equipment, crude oil,
paper and paper products, iron and steel products, and textiles
Major trade partners: U.K. and EC, also Uganda and
Tanzania, which are part of East African Economic Community
Monetary conversion rate: 1 Kenya shilling=US$0.14 (official); 7.143 Kenya
shill ings=US$1
Fiscal year: 1 July - 30 June
GNP: roughly $300 per capita (1970)
Agriculture: main crops -- rice, corn, vegetables; food shortages -- meat,
cooking oils; production of foodstuffs adequate for domestic needs at low
levels of consumption
Major industries: machine building, electric power, chemicals, mining, metallurgy,
textiles
Shortages: heavy machinery and equipment, bituminous and coking coal, petroleum,
rubber
Crude steel: 2.2 million metric tons produced (1970), about 160 kilograms
per capita
Exports: minerals, chemical and metallurgical products
Imports: machinery and equipment, petroleum, foodstuffs, coking coal
Major trade partners: total trade turnover about $680 million (1970); 17% with
non-Communist countries, 83% with Communist countries (55% with the U.S.S.R.)
173
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d):
Monetary conversion rate: 2.57 won=US$1 (noncommercial), 1.20 won=US$1 (commercial)
Fiscal year: calendar year
Agriculture: virtually none, dependent on imports for food; approx. 75% of
potable water must be distilled or imported
Major industries: crude petroleum production averaging 2.99 million b.p.d.
(includes Kuwait''s share of neutral zone) (1970); government revenues from
taxes and royalties on production, refining, and consumption was $850 million
in FY69; refinery capacity est. at 504,000 bbis. per day (1970); other major
industries include fishing, processing of building materials, fertilizers,
chemicals, and flour
Electric power: 838,000 kw. capacity (1970); 1,670 million kw.-hr. produced
(1970), 2,140 kw.-hr. per capita
Exports: $1.6 billion (1968), of which petroleum accounted for 98%; nonpetroleum
exports are mostly reexports and totaled $58 million (1969)
Imports: $646 million (1969); major suppliers -- U.S., Japan, U.K., West Germany
Aid: $50 million loan from Export-Import Bank, 1967; $2.6 million from international
organizations (FY63-70); extended about $50 million
in credits to other Arab nations from 1961 to January 1969
Monetary conversion rate: 1 Kuwaiti dinar=US$2.80 (freely convertible)
Fiscal year: 1 April - 31 March
Approved For Release 2004/08/31 :''€fn-RDP79-01051A000400010002-1
COMMUNICATIONS: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Pipelines: crude oi1, 254 mi.; refined products, 27 mi.; natural gas, 74 mi.
Ports: 2 major, 1 minor
Merchant marine: 30 ships (1,000 GRT or over), totaling 593,900 GRT, 1,013,100
DWT; includes 22 cargo, 6 tankers, 2 specialized carrier
Civil air: 5 major transport aircraft
Airfields: 13 total, 4 usable; 2 with permanent-surface runways; | with runway
8,000-11,999 ft., 1 with runways 4,000-7,999 ft.
Telecommunications: excellent international radiocommunications; adequate
domestic telecommunication facilities; 58,000 telephones; 105,000 radio
and 100,000 TV sets; 3 AM and 3 TV stations
DEFENSE FORCES:
Supply: dependent on U.K.
Military budget: for fiscal year ending 31 March 1972, $86,800,000; about 11.7%
of total budget
178
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Appr
NIS 438 pproved For Release 2004/08/89; CIA-RDP79-01051A000400010002-1
D:
91,430 sq. mi.; 7% agricultural , 60% forests, 33% urban,
waste, and other; except in very limited areas, soil
is very poor; most of forested area is not exploitable
(May 1969, est.)
Land boundaries: 2,700 mi.
GNP: $211 million, $73 per capita (1969 est.)
Agriculture: main crops -~ rice (overwhelmingly dominant), corn, coffee, cotton
and tobacco; largely self-sufficient; food shortages (due in part to
distribution deficiencies) including rice
179
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Fishing: catch data unavailable; imports fish and fish products 278 tons,
$119,000 (1969)
Major industries: tin mining, timber
Shortages: capital equipment, petroleum, transportation system
Electric power: 23,200 kw. capacity (1969); 29 million kw.-hr. produced (1970),
11 kw.-hr. per capita
Exports: $3.0 million (f.o.b., 1970 est.); forest products, coffee, tin concentrates,
and timber; undeclared exports of opium significant but value unknown
Imports: $51.4 million (c.i.f., 1969); rice, petroleum products, textiles,
transportation equipment, machinery
Major trade partners: imports from Thailand, U.S., Japan, France, Hong Kong,
U.K., Indonesia, and West Germany; exports to Malaysia and Thailand; trade
with Communist countries insignificant; Laos a major transit point in world
gold trade; gold imports and approx. offsetting old exports excluded from
official trade data; value of 1969 gold imports $36.7 million
Monetary conversion rate: 240 kip=US$1; open market rate approx. 505 kip=US$1
(1969); all but restricted list of developmental commodities now imported
at open market rate
Fiscal year: 1 July - 30 June
Agriculture: fruits, wheat, corn, barley, potatoes, tobacco, olives, onions; not
self-sufficient in food
181
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000490010002-1
Major industries: service industries, food processing, textiles, cement, 01
refining, chemicals, some metal fabricating, tourism
Electric power: 552,000 kw. capacity (1970); 1,394 million kw.-hr. produced
(1970), 500 kw.-hr. per capita
Major trade partners: exports $179 million (f.0.b., 1969 est.); 67% to Arab
countries; imports $643 million (c.i.f., 1969 est.); chiefly from EC, U.K.,
and Arab countries; 8.4% from Communist countries; trade deficit covered by
large net receipts from invisibles (particularly tourism and transportation)
and private capital inflow
Monetary conversion rate: 3.08 Lebanese pounds=US$1 (provisional parity); free
market (January 1971) 3.24 Lebanese pounds=US$1
Fiscal year: calendar year
GNP: $90 million (1968), about $100 per capita
Agriculture: exceedingly primitive, mostly subsistence farming and livestock;
principal crops are corn, wheat, pulses, sorghum, barley
Major industries: none
Electric power: 2,820 kw. capacity (1970); 2.5 million kw.-hr. produced (1970),
3 kw.-hy. per capita
Exports: labor to South Africa (remittances $15 million in 1969); $5 million
(f.o.b., 1968), wool, mohair, wheat, cattle, diamonds, peas, beans, corn,
hides, skins
Approved For Release 2004/08/34° CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Imports: $29 million (f.o.b., 1968); mainly corn, building materials, clothing,
vehicles, machinery, POL
Major trade partner: South Africa
Aid: economic aid $6.9 million (budget FY71-72); U.K. $6.4 million (budget
FY71-72); no military aid
Monetary conversion rate: Lesotho uses the South African rand; 1 SA rand=US$1.40
(official); 0.714 SA rand=US$1
Fiscal year: 1 April - 31 March
GNP: $2.91 billion (1970 est.), $1,500 per capita, approximately constant over
1967-70
GDP: $3.5 billion (1970 est.), $1,800 per capita
Agriculture: main crops -- wheat, barley, olives, dates, citrus fruits, peanuts;
not self-sufficient in food
Major industries: petroleum production averaged 3.3 million b.p.d. (1970);
estimated oil revenues for FY71 about $1.5 billion; food processing,
textiles, handicrafts
187
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Electric power: 146,600 kw. capacity (1969); 430 million kw.-hr. produced (1969),
230 kw.-hr. per capita
Exports: $2,366 million (1970 est.); over 99% petroleum
Imports: $544 million (1970 est.)
Major trade partners: imports -~ Italy, West Germany, U.S.
Aid: economic -- $17.4 (FY52-70); no Communist country assistance; U.S. aid
extended $212.6 million (1949-70)
military -- arms obtained by cash purchase; chief suppliers France, U.S.S.R.5
Czechoslovakia; U.S. suspended since September 1969
Monetary conversion rate: 1 Libyan pound=US$2.80
Fiscal year: 1 April - 31 March','9c73f40e91c3c738bd699cfc502ea4437151e3fd8953d255c79f794d27e6665e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8615181ab7ba5ba6bcf10cd00e5553f171a5684b0c3cd6b5ad29cc3995f34224',1971,'NO','Norway','economy',36,'Despite its small size and sparse natural resources , Liechtenstein has a
prosperous economy based primarily on small-scale light industry and farming.
Textiles, ceramics, precision instruments, pharmaceuticals, and canned foods
are the principal manufactures produced, almost entirely for export. Live-
stock raising and dairying are the main sources of farm income; cereals and
potatoes are the most important farm crops. The Liechtenstein economy is
tied closely to that of Switzerland in a virtual customs union. No national
accounts data are available.
Major trade partners: exports (1967) -- $45.5 million; 41% Switzerland, 28% EC,
56.1% EFTA
Electric power: 22,600 kw. capacity (1970); 55 million kw.-hr. produced (1970),
1,800 kw.-hr. per capita; power is exchanged with Switzerland, but net
exports average 35 million kw. yearly
Agriculture: main crops -- rice, vegetables; food shortages -- rice, vegetables,
meat; depends mostly on imports for food requirements
Major industries: textiles, fireworks
Electric power: 14,000 kw. capacity (1969); 30.6 million kw.-hr. produced (1969),
120 kw.-hr. per capita
Exports: $37 million (f.o.b., 1969); textiles and clothing, foodstuffs, fireworks
Imports: $50 million (f.o.b., 1968)
Major trade partners: exports -- Hong Kong 24%, West Germany 21%; imports --
Hong Kong 67%, China 30% (1968)
Monetary conversion rate: 6.06 patacas=US$]1
Fiscal year: calendar year
193
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Highways: 26 mi. paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
DEFENSE FORCES:
Defense is responsibility of Portugal
]
Approved For Release 04/08/31 : CIA-RDP79-01051A000400010002-1
NIS 62 APproved For Release 2004/0812) </CIASRDE £9-01051A000400010002-1
LAND:
230,000 sq. mi.; 5% cultivated, 58% pastureland, 21%
forested, 8% wasteland, 2% rivers and lakes, 6% other
(1965)
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 3,000 mi.
GDP: $319 million (1970), $70 per capita; average annual growth rate in constant
prices 5.3% (1964-70)
Agriculture: cash crops -- tea, tobacco, peanuts, cotton, tung; subsistence
crops -- corn, sorghum, millet, pulses, root crops, fruit, vegetables, rice
Electric power: 38,200 kw. capacity (1970); 133 million kw.-hr. produced (1970);
30 kw.-hr. per capita
Major industries: agricultural processing (tea, tobacco, sugar), sawmilling,
cement, consumer goods
Exports: $57 million (f.0.b., 1970); tea, tobacco, cotton, tung, peanuts
Imports: $82.1 million (f.0.b., 1970); manufactured goods, machinery and transport
equipment, food, fuels
Major trade partners: exports -- U.K., Zambia, Rhodesia, U.S.; imports -- U.K.,
Rhodesia, South Africa
9
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Aid:
economic -- U.K. provides both budgetary and development support, about
$35 million through FY1971; U.S. aid commitments , $26 million (1962-70);
military -- U.K., $0.9 million (1954-68)
Monetary conversion rate: 1 Malawi kwacha=US$1.20 (official)
Fiscal year: 1 April - 31 March
GNP:
“Malaysia: $3.9 billion (1970), $360 per capita; average annual real growth
(1966-70) 6%
Agriculture:
West Malaysia: mixed plantation and subsistence; main crops -- rubber, rice,
oil palm; 25% of rice requirements imported
Sabah: mainly subsistence; main crops -- rubber, coconut, rice; food deficit
-- rice
Sarawak: main crops -- rubber, pepper; food deficit -- rice
Fishing: catch 406,000 tons, $93.2 million (1968)
Major industries:
West Malaysia: rubber and oil palm processing and manufacturing, tin mining
and smelting, logging and processing timber, light consumer goods
Sabah: logging
Sarawak: agriculture processing, petroleum refining, logging
Electric power:
West Malaysia: 908,000 kw. capacity (1970); 3.47 billion kw.-hr. produced
(1970), 373 kw.-hr. per capita
Sabah: 41,400 kw. capacity (1970); 85 million kw.-hr. produced (1969); 133
kw.-hr. per capita
Sarawak: 47,300 kw. capacity (1970); 98 million kw.-hr. produced (1969),
95 kw.-hr. per capita
Exports: $1,680 million (f.0.b., 1970); 40% rubber, 18% tin, 15% timber
Imports: $1,393 million (c.i.f. 1970)
Major trade partners: exports -- Singapore, Japan, U.S.; imports -- Japan, U.S.,
Singapore, China
201
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A :
ECONOMY (cont''d): pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Monetary conversion rate:
Malaysia: 3.06 Malaysian dollars=US$1
Fiscal year: calendar year
GNP: under $100 per capita
Agriculture: crops -- coconut and millet; shortages -- rice, wheat
Fishing: catch 32,000 tons (1970)
Major industries: fishing; some coconut processing
Electric power: 2,500 kw. capacity (1970); 7 million kw.-hr. produced (1970),
65 kw.-hr. per capita
Exports: $2.5 million (f.o.b., 1967); fish
Imports: $2.5 million (c.i.f., 1967)
Major trade partner: Ceylon
Aid: U.K. (1960-65), $1.4 million drawn, Ceylon (1967), $1 million committed
Monetary conversion rate: 4.76 rupees=US$1
Fiscal year: calendar year
GNP: $212 million (1969 current prices), $660 per capita; 71% private
consumption, 29% gross investment, 1969 growth rate 15% in current prices
Agriculture: overall, 20% self-sufficient; adequate supplies of vegetables, poultry,
milk and pork products; shortages in beef, grain, animal fodder, and fruits
at various seasons; main products -- potatoes, cauliflowers, grapes, wheat,
barley, tomatoes, citrus, cut flowers, green peppers, hogs, poultry, eggs
Major industries: ship repair yard, building industry, food manufacturing,
textiles, tourism
Shortages: most consumer and industria? needs (fuels and raw materials) must be
imported
Electric power: 85,000 kw. capacity (1970); 276 million kw.-hr. produced (1970),
570 kw.-hr. per capita
Exports: $38.2 million (1969); textiles, scrap metal, wine, agricultural
products, and footwear
209
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d):
Imports: $147.6 million (1969)
Major trade partners: U.K. 44%, Italy 15.7%; EFTA 48%; EC 28.2%; Communist
countries 2.5%; North and Central America 3.8%
Aid: economic -- U.S., $8.3 million (1949-70), of which $0.3 million authorized
in 1968, $1.7 million authorized 1969 and $0.1 million authorized in 1970;
U.K. Financial Agreement (loans and grants) 1964-74, $140 million; IBRD $6
million through 1970, none since 1964; U.N. Special Fund $2.1 million through
1970, none in 1970; U.N. Technical Assistance $1.1 million through 1970, of
which $0.1 million in 1970
Monetary conversion rate: 1 Maltese Pound=US$2.40 (official )
Fiscal year: 1 April - 31 March
GDP: $245 million (1968), $750 per capita; real growth rate 8% (1968, est.)
Agriculture: bananas, sugarcane, and pineapples
Major industries: agricultural processing, particularly sugar milling and rum
distillation; cement, oil refining and tourism
Electric power: 26,400 kw. capacity (1970); 74 million kw.-hrs. produced (1970),
219 kw.-hrs. per capita
Exports: $30 million (f.o.b., 1970), bananas, sugar, rum, pineapples
Imports: $146 million (c.i.f., 1970), foodstuffs, clothing and other consumer
goods, raw materials and supplies, and petroleum
Major trading partners: exports -- France 82%, Italy 9%, other 9%; imports --
ae i spy United States 6%, Netherlands Antilles 3%, Netherlands 3%, other
18% (1968
Monetary conversion rate: US$1=5.5187 francs (commercial), US$1=5.3333 francs
(financial), 1 October 1971
211
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A : zi
ECONOMY (cont''d): pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Fiscal year: calendar year
GDP: about $170 million (1968), about $150 per capita; average annual rate of
growth (real terms, 1962-66) 9%
Agriculture: most Mauritanians are nomads or subsistence farmers; main crops
-- livestock, small grains, dates; cash crops -- livestock, gum arabic —
Fishing: catch, traditional river fishing, 15,000 tons (1969), traditional sea
fishing, 2,750 tons (valued at $437,000); fish supplied to processing plants
by foreign fishing fleets from France, Spain, Canary Islands using Mauritanian
waters; exports 21,090 tons, $7.3 million (1970)
Major industries: mining of iron ore, salt fishing, exploitation of copper
resources planned
Electric power: 20,200 kw. capacity (1970); 38 million kw.-hr. produced (1970),
32 kw.-hr. per capita
Exports: $71 million (f.o.b., 1967); iron ore, fish, gum arabic
Imports: $25 million (c.i.f., 1967); sugar, cloth, tea, and fuels
213
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Major trade partners: (trade figures not complete because Mauritania has a form
of customs union with Senegal and much local trade unreported) France and
other EC members, U.K., and U.S. are main overseas partners
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year
GNP: 55% tourism; 25%-30% industry (small and primarily tourist oriented); 10%-15%
registration fees and sales of postage stamps; about 4% traceable to the Monte
Carlo casino
Major industries: chemicals, food processing, precision instruments, glassmaking,
printing
Electric power: 8,000 kw. capacity (1970); 60 million kw.-hr. supplied by France
(1970), 2,250 kw.-hr. per capita
Trade: full customs integration with France, which collects and rebates Monacan
trade duties
Monetary conversion rate: 5.55419 francs=US$1
Agriculture: self-sufficient in animal products ; main crops -- wheat, oats,
barley
Industries: processing of animal products and building materials; mining
Exports: animal and dairy products, fluorspar, woolen textiles, leather shoes ,
glass, and paper
Imports: machinery and equipment, petroleum, cloth, coal, and. building materials,
sugar, and tea
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 4 tugriks=US$1 (arbitrarily es tablished)
Fiscal year: calendar year
221
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
A
COMMUNICATIONS : pproved For Release 2004/08/31 : CIA- 7
Railroads: 1,130 route mi.; g00 mi. broad gage LARP P 2350105 1a POP ARG 1 0002-1
(3''3 3/8") (1971)
Highways: 52,000 mi.; 125 mi. paved, 5,275 mi. improved natural surface and
gravel, 46,600 mi. unimproved earth (1971)
DEFENSE FORCES:
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 31 December 1969, 131.7 million tugriks,
7% of total budget; value in dollars $33 million (est.)
222
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
NIS 48 Approved For Release 2004/08/34,.,€44-RDP79-01051A000400010002-1
LAND:
158,000 sq. mi.; 19% farmland and orchard, 19% pasture,
20% forest and esparto, 42% desert, waste, or urban
(1965)
Land boundaries: 1,240 mi.
WATER:
Limits of territorial waters: 3 n. mi. (fishing, 12 n. mi.)
Coastline: 1,140 mi.
GNP: $700 million (est. 1966), about $100 per capita
Agriculture: cash crops -- raw cotton, cashew nuts, sugar, tea, copra, sisal;
é other crops -- corn, wheat, peanuts, potatoes, beans, sorghum, and cassava;
self-sufficient in food except for wheat which must be imported
Major industries: food processing (chiefly sugar, tea, wheat, flour, cashew
kernels); chemicals (vegetable oil, oilcakes, soap, paints); petroleum
products; beverages; textiles; nonmetallic mineral products (cement, glass,
asbestos, cement products); tobacco
225
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : C
: CIA- ‘
Electric power: 232,000 kw. capacity (1969); 464 million kw.-hr. produced (1969),
64 kw.-hr. per capita
Exports: $149 million (f.0.b., 1970); cotton, sugar, cashew nuts, mineral products,
timber products, tea, copra, petroleum products
Imports: $288 million (c.i.f., 1970); machinery and electrical equipment, cotton
textiles, vehicles, petroleum products, wine, iron and steel
Major trade partners: over one-third of foreign trade with Portugal; South Africa,
U.S., U.K., West Germany
Aid: from Portugal only
Monetary conversion rate: 28.75 escudos=US$1 (official )
Fiscal year: calendar year','9405c9ca3666e9bfecc52aa2f5408369a5d18f14d0758afb205e3691ab2991ac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc12fe032b3d0989d0ff18f2b4e7dc72441e9602b822411719c3f44880711465',1971,'AU','Australia','economy',40,'GNP: $25 million (1970), $3,570 per capita
Agriculture: negligible; almost completely dependent on imports for food, water
Major industries: mining of phosphates, about 2 million tons per year (1966)
Electric power: 7,600 kw. capacity (1969); 17 million kw.-hr. produced (1969),
2,429 kw.-hr. per capita
Exports: $17 million (f.o.b., 1968), consisting entirely of phosphates
Imports: $5 million (c.i.f., 1968)
Major trade partners: Australia, New Zealand, and United Kingdom
Monetary conversion rate: 1 Australian dol lar=US$1.12 (official)
Fiscal year: 1 July - 30 June
GDP: $1 billion (1969), less than $100 per capita
Agriculture: over 90% of population engaged in agriculture; main crops -- rice,
corn, wheat, sugarcane, oilseeds; largely self-sufficient
Major industries: small rice, jute, sugar, and oilseed mills; match, cigarette,
and brick factories
Electric power: 44,000 kw. capacity (1970); 61 million kw.-hr. produced (1970),
6 kw.-hr. per capita
Exports: $55 million (FY69 est.); rice and other food products, jute, timber
Imports: $62 million (FY69 est.); manufactured consumer goods, food grains and
food products
229
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
HE He Anpraved Far-Ralease 2004/08/31 : CIA-RDP79-01051A000400010002-1
Monetary conversion rate: 10.1 Nepalese rupees=US$]1
Fiscal year: 15 July - 14 July
GNP: $550 million (FY70 estimate), $225 per capita; real average annual growth
rate (1960-69) 7.5%
Agriculture: main crops -~- coconuts, coffee, cocoa, tea
Major industries: sawmilling and timber processing, copper mining (Bougainville)
Electric power: 70,500 kw. capacity (1970); 196 million kw.-hr. produced (1970),
80 kw.-hr. per capita
5
Approved For Release 2004/08/31 ?@iA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Exports: $84.3 million (f.o.b., FY69); principal products -- coconut products,
coffee beans, cocoa beans, timber
Imports: $168.5 million (f.o.b., FY69)
Major trade partners: Australia, U.K., Japan
Aid:
economic -- Australia (FY46-69) $909 million extended; World Bank group
(1968-September 1969) -- $7.5 million committed
Monetary conversion rate: 0.893 Australian dol lar=US$1
Fiscal year: 1 July - 30 June
Agriculture: largely dominated by coconut production with subsistence crops of
taro, yams, sweet potatoes, manioc, and bread fruit
Electric power: 900 kw. capacity (1970); 2.6 million kw.-hr. produced (1970),
30 kw.-hr. per capita
Exports: $3.8 million (f.0.b., 1969); copra and bananas
Imports: $5.7 million (c.i.f., 1969)
Major trade partners: Australia, New Zealand, Netherlands, Norway
Monetary conversion rate: 0.893 Tonga dollar=US$1
Agriculture: food imported, but some dates, alfalfa, vegetables, fruit, tobacco
raised
Major industries: fishing, trading, oi] production; oi] production began in Abu
Dhabi in 1962, and in 1970 reached 694,000 bbis. per day; oi] revenues
accruing to Abu Dhabi estimated $200 million in 1970; Dubai has best port
and is commercial center -- oil was discovered in commercial quantities in
1966; production began in 1969, 1970 production 86,000 b.p.d.; oi] revenues
for 1970 estimated at $33 million; small fishing, some boat building,
handicrafts, animal husbandry, pearling throughout area
Electric power: 36,000 kw. capacity (1970); 90 million kw.-hr. produced (1970),
676 kw.-hr. per capita
Exports: crude petroleum, pearls, fish; Abu Dhabi crude exports $244 million (est.
1968) and Dubai $20 million total, of which $18.8 million reexports (1968)
Imports: food, consumer and capital goods; Abu Dhabi $120 million estimated
(1969) and Dubai $197 million total (1970)
Major trade partners: Japan, U.K., India
Aid: multilateral annual average (1967-69) $1.17 million
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.21; Abu Dhabi, 1 Bahrain
dinar=US$2.10
Agriculture: cereal farming and livestock herding predominate; main crops --
wheat, barley, olives, fruits (especially citrus), viticulture, vegetables,
dates
Major industries: mining, food processing, textiles and leather, light
manufacturing, construction materials, chemical fertilizers
Electric power: 270,000 kw. capacity (1970); 710 million kw.-hr. produced (1970),
137 kw.-hr. per capita
Monetary conversion rate: 0.52 dinar=US$1 (IMF par value)
Fiscal year:-calendar year
341
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS: Approved For Release 2004/08/31 ; CIA-RDP79-01051A000400010002-1
mi
Railroads: 1,273 mi.; . Standard gage (4''8 1/2"), mi. double track; 975
mi. meter gage (3''3 3/8")
Highways: 10,000 mi.; 4,560 mi. bituminous, 465 mi. gravel, 2,050 mi. improved
earth, 2,925 mi. unimproved earth
Pipelines: crude oi1, 496 mi.; refined products, 6 mi.; natural gas, 43 mi.
Ports: 4 major, 14 minor
Merchant marine: 8 ships (1,000 GRT or over) totaling 15,400 GRT, 19,300 DWT;
includes 6 cargo, 2 specialized carrier
Civil air: 5 major transport aircraft
Airfields: 60 total, 36 usable; 10 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: the system is above the African average in amount and
capacity of facilities which consist of open-wire lines with multiconductor
cable or radio relay on trunk routes; key centers are Safagis, Susah, Bizerte,
and Tunis; 70,000 telephones; 400,000 radio and 50,000 TV receivers; 2 AM,
3 FM, and 7 TV stations; 2 submarine cables
DEFENSE FORCES:
Supply: dependent on foreign sources of supply; mostly U.S., with lesser amounts
from France, Italy, and West Germany
342
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
am naar gy
= te:
A Tp neem tment anes
NIS 27 Approved For Release 2004/0831; CIA-RDP79-01051A000400010002-1
LAND:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive (1968)
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters: 6 n. mi. except in Black Sea
where it is 12 n. mi. (fishing, 12 n. mi.)
Coastline: 4,475 mi.
GDP: $1,026 million (1969), $100 per capita; 6.3% real growth between 1966 and
1969
Agriculture: main cash crops -- coffee, cotton; other cash crops -- sugar,
tobacco, fish, tea, livestock; self-sufficient in food
Fishing: catch 124,500 tons
Major industries: agricultural processing (textiles, sugar, coffee, plywood,
beer), cement, copper smelter, corrugated iron sheet, shoes, fertilizer
Electric power: 150,000 kw. capacity (1969); 737 million kw.-hr. produced
(1969), 90 kw.-hr. per capita
Exports: $211.7 million (f.o.b., 1969); coffee, cotton, copper, tea; $7.6 million
to Communist countries (c.i.f., 1968)
Imports: $190.7 million (c.i.f., 1969); petroleum products, machinery, cotton
ae goods, ree transport equipment; $7 million from Communist countries
c.i.f., 1968
Major trade partners: U.K., U.S., Kenya (Uganda, Kenya, and Tanzania form
East African Economic Community )
345
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
_Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d)
1 Uganda shilling=US$0.14
Monetary conversion rate: 7.143 Uganda shillings=US$1;
Fiscal year: 1 July - 30 June
Agriculture: principal food crops --. grain (especially wheat), potatoes; main
industrial crops -- sugar beets, cotton, sunflowers, and flax; degree of
self-sufficiency depends on fluctuations in crop yields; given normal yields,
U.S.S.R. is self-sufficient; caloric intake, 3,000-3,200 calories per day
per capita in recent years
347
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-
Fishing: catch 7,090,000 tons (1969); exports $84,910,000 (1969), imports
$14,710,000 (1969)
Major industries: diversified, highly developed capital goods industries; consumer
goods industries comparatively less developed
Shortages: natural rubber, bauxite and alumina, tantalum, tin, and tungsten
Crude steel: 124.6 million metric ton capacity as of | January 1971; 115.8
million metric tons produced in 1970, 475 kilograms per capita
Electric power: 165.6 million kw. capacity (1970); 740 billion kw.-hr. produced
(1970), 3,033 kw.-hr. per capita
Exports: fuels (particularly petroleum and derivatives), metals, agricultural
products (timber, grain) and a wide variety of manufactured goods (primarily
capital goods); $12,800 million (f.0.b., 1970)
Imports: specialized and complex machinery and equipment, textile fibers, consumer
manufactures, and any significant shortages in domestic production (for
eats is imported following poor domestic harvests); $11,738.9 million
f.o.b., 1970
Major trade partners: $24.5 billion (1970); trade 65% with Communist countries ,
21% with industrialized West, and 14% with less developed countries
Official monetary conversion rate: .90 rubles=US$1; 1 ruble=US$1.1111
Fiscal year: calendar year
GDP: $220 million (1967), under $50 per capita
Agriculture: cash crops -- peanuts, shea nuts, sesame, cotton; food crops --
sorghum, millet, corn, rice; livestock; largely self-sufficient
Fishing: catch 5,000 tons (1969), $2.7 million
351
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
1,,, Approved For Rel :
ECONOMY (cont''d): Pp elease 2004/08/31 : CIA-RDP79-
Major industries: agricultural processing plants, a eee OO Re AA AQQ02-1
plants; a few other light industries
Electric power: 12,100 kw. capacity (1970); 38 million kw.-hr. produced (1970);
7 kw.-hr. per capita
Exports: $19 million (f.o.b., 1968); livestock (on the hoof), peanuts, shea
nut products, cotton, sesame
Imports: $34 million (c.i.f., 1968); textiles, food, and other consumer goods,
transport equipment, machinery, fuels
Major trade partners: volume understated because much regional trade is unrecorded;
Ivory Coast and Ghana; overseas trade mainly with France and other EC
countries; preferential tariff to EC and franc zone countries
Aid:
economic -- France (1964-September 1970) $46 million; EC (1960-70) $56.7
million; U.S.S.R., Ghana, West Germany, and Israel have also extended aid;
U.S. (FY61-70) $14.5 million; international organizations $12.1 million;
military -- France, $3.7 million (1964-70); U.S.> $0.1 million (1962-70)
Monetary conversion rate: 277 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year
The Vatican City, seat of the Holy See, is supported financially by contributions
(known as Peter''s pence) from Roman Catholics throughout the world; some
income derived from sale of Vatican postage stamps and tourist mementos,
fees for admission to Vatican museums, and sale of publications; industrial
activity consists solely of printing and production of a small amount of
mosaics and staff uniforms
The banking and financial activities of the Vatican are worldwide; the Institute
for Religious Agencies carries out fiscal operations and invests and transfers
funds of Roman Catholic religious communities throughout the world; the
Cardinal''s Commission controls the administration of ordinary assets of the
Holy See and a Special Administration manages the Holy See''s capital assets
Electric power: obtained from Rome city grid; standby diesel powerplant with
2,100 kw. capacity
Approved For Release 2004/08/31 7 CIA-RDP79-01051A000400010002-1
COMMUNICATIONS: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Telecommunications: AM and FM radiobroadcasting stations
DEFENSE FORCES:
Defense is responsibility of Italy
Approved For Release 3304/08/31 : CIA-RDP79-01051A000400010002-1
NIS 86 Approved For Release 2004/08(34); GIA-RDP79-01051A000400010002-1
LAND:
352,000 sq. mi.; 4% cropland, 18% pasture, 21% forest, F
57% urban, waste, and other (1961) : ere
Land boundaries: 2,598 mi. —
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 1,740 mi.
Agriculture: mainly subsistence; main crops -- rice, corn, sweet potatoes,
manioc, sugarcane; food shortages -- rice, meat, sugar; caloric intake,
1,700-2,200 calories per day per capita
. Major industries: food processing, textiles, machine building, mining, cement
Shortages: petroleum, complex machinery and equipment, fertilizer, foodstuffs
Monetary conversion rate (nominal): 3.7 dong=US$1
Fiscal year: calendar year
r COMMUNICATIONS:
Railroads: 602 usable route mi., consists of about 25 mi. of standard gage
(4''8 1/2"), 438 mi. of meter gage (3''3 3/8"), and 139 mi. of dual gage
(4''8 1/2" and 3''3 3/8"); all single track, none electrified; all government
owned and operated; new rail line under construction between Kep and port
of Hon Gai
Highways: 8,850 mi., plus about 1,800 mi. of seasonally motorable tracks; 900 to
1,000 mi. bituminous surface-treated, remainder gravel, crushed stone, or earth
Inland waterways: 4,200 mi.; 1,800 mi. navigable perennially by craft drawing 6 ft.
359
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS (cAPPEQVed For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Ports: 3 major, 12 minor
Merchant marine: 6 ships (1,000 GRT or over) totaling 14,100 GRT, 14,400 DWT;
includes 3 cargo, 3 bulk, supplemented by 3 coastal cargo ships and 2 coastal
tankers totaling 2,400 GRT, 3,200 DWT
360
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
vig a3p APProved For Release 2094/08/31 <6 fA;RDP79-010514000400010002-1
LAND:
67,000 sq. mi.; 35% arable (17% cultivated), 32% forested,
33% other (1970)
Land boundaries: 1,025 mi.
WATER:
Limits of aa waters: 3.n. mi. (fishing, 10.8
n. mi.
Coastline: 1,650 mi.
PEQPLE:
Population: 19,054,000, average annual growth rate 2.6%
(FY69); males 15-49, 4,460,000; 2,570,000 fit for
military service; 143,000 reach military age (18) annually
Ethnic divisions: 85% Vietnamese, 6% Chinese, 5% mountain tribesmen, 3% Cambodian,
1% other
Religion: 50%-60% nominal Buddhist (10% Hoa Hao), 10%-20% active Buddhist, 5%
Cao Dai, 8%-12% Catholic, 15%-30% no affiliation or animist; most Buddhists
are of Mahayana school or practice combination of Buddhism, Taoism, and
Confucianism
Language: Vietnamese, French, Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian), Cham (Malayo-Polynesian dialect)
Labor force: employed work force 6.5 million (not including armed forces );
80.2% agriculture, 3.2% transport and communications, 2.4% fishing, 2.4%
construction, 2.3% commerce and finance, 2.1% domestic and personal services,
4.3% government, 2.4% manufacturing, 0.7% plantation and public utilities
Organized labor: 6% of labor force
GNP: $25 million (1967 est.), $170 per capita
Agriculture: cocoa, bananas, copra; staple foods include taro and coconuts,
supplemented by bananas and bread fruit
Electric power: 6,900 kw. capacity (1970); 16.7 million kw.-hr. produced (1970),
110 kw.-hr. per capita
Exports: $4.6 million (1970); copra, cocoa, bananas
Imports: $13.7 million (1970)
Major trade partners: exports -- New Zealand, the Netherlands, U.K.; imports
-- New Zealand, Australia, U.K., U.S.
Aid: New Zealand, $2.5 million committed; U.S., $1.5 million extended (FY67-69)
Monetary conversion rate: .719 tala=US$1
Approved For Release 2004/08/34 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: 477 mi.; 80 mi. bituminous, remainder mostly gravel, crushed stone,
or earth
Inland waterways: none
Ports: 1 principal (Apia), 1 minor
Civil air: 4 major transport aircraft (includes 2 leased)
Airfields: 4 total, all usable; 4 with runways 4,000-7,999 ft.; 3 seaplane
stations
Telecomnunications: 1,838 telephones; 22,000 radio receivers; 1 AM station
Approved For Release 2064108/31 : CIA-RDP79-01051A000400010002-1
NIS 32B Approved For Release 2004/08/31 Aseh4*RDP79-01051A000400010002-1
112,000 sq. mi. (border with Saudi Arabia undefined); only
about 1% arable (of which less than 25% cultivated)
Land boundaries: 1,060 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 860 mi.
Agriculture (all outside Aden): cotton is main cash crop; cereals, dates, kat
(qat), coffee, and livestock are raised and there is a small fishing
industry; large amount of food must be imported (particularly for Aden);
cotton, hides, skins, dried and salted fish are exported
Major industries: petroleum refinery (production 150,000 bbis. per day) mid 1971;
” capacity 178,000 bbls. per day at Little Aden operates on imported crude; oil
exploration activity
Electric power: 108,000 kw. capacity (1970); 378 million kw.-hr. produced (1970),
290 kw.-hr. per capita
Major trade partners: Yemen, East Africa, but some cement and sugar imported from
Communist countries; crude oil imported from Persian Gulf, exported mainly
to U.K. and Japan
Monetary conversion rate: 1 S. Yemeni dinar=US$2.40
Fiscal year: 1 April - 31 March
*kExcluding the islands of Perim and Kamaran for which no data are available.
365
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS : Approved For Release 2004/08/31 : CIA-RDP79-010514000400010002-1
no
Railroads:
Highways: 3,350 mi.; 120 mi. bituminous treated, 30 mi. crushed stone and gravel,
3,200 motorable track
Ports: 1 major
Pipelines: refined products, 57 mi.
Civil air: 8 major transport aircraft
Airfields: 136 total, 87 usable; 2 with permanent-surface runways; 2 with
runways 8,000-11,999 ft., 44 with runways 4,000-7,999 ft.; 1] seaplane station
Telecommunications: excellent international radiocommunications; excellent
domestic wire facilities; 9,400 telephones; 250,000 radio receivers; 21,000
TV receivers; 5 TV and 1 AM stations; 4 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 31 March 1971, $13,400,000; about 25.1%
of total budget
366
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
vis 32a APProved For Release 2004/08/31 < fij-RDP78-01051A000400010002-1
LANQ:
about 75,000 sq. mi. (parts of border with Saudi Arabia
and Southern Yemen undefined); 20% agricultural,
1% forested, 79% desert, waste, or urban
Land boundaries: 950 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 325 mi.
Agriculture: sorghum and millet, gat (a mild narcotic), cotton, coffee, fruits
and vegetables; largely self-sufficient in food
Major industries: cotton textiles and leather goods produced on a small scale;
handicraft and some fishing; small aluminum products factory
Electric power: 4,000 kw. capacity (1970); 14 million kw.-hr. produced (1970),
2 kw.-hr. per capita
Exports: about $6 million (1970), qat, cotton, coffee, hides, vegetables
Imports: about $88 million (1970), textiles and other manufactured consumer goods,
petroleum products, sugar, grain, flour, other foodstuffs, and cement
Major trade partners: exports -- over half to or through Aden, one-third to
Communist countries; imports -- Aden, Communist countries (20%), Egypt,','15d143717c76eddf276dac64fa01b0931b840d63ee8a4ec6f718335af4b32dbc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdabf750cc34fdeeb3df9d7c94f9b6a1db11a49672bb3033cb483a969208cd43',1971,'CO','Colombia','economy',45,'GDP: $28.2 million (1969), $230 per capita
Agriculture: main crops -- bananas, copra, sugar, cocoa, spices
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 4,565 kw. capacity (1969); 9.3 million kw.-hr. produced (1969
est.); 82 kw.-hr. per capita
Exports: $6.2 million (f.o.b., 1968); sugar, bananas, cocoa
Imports: $14.7 million (c.i.f., 1968); foodstuffs, machinery and equipment,
fertilizers, petroleum products
Major trade partners: U.K. 49%, Canada 9%, U.S. 8% (1964)
Monetary conversion rate: 1.93 East Caribbean dollars=US$1 (6 October 1971)
GDP: $16.9 million (1969), $180 per capita
Agriculture: main crops -- bananas, arrowroot, coconut
Major industries: food processing
Electric power: 1,700 kw. capacity (1969); 5.1 million kw.-hr. produced (1969
est.), 53 kw.-hr. per capita
Exports: $3.7 million (f.o.b., 1968); bananas, arrowroot, copra, cotton
Imports: $1.0 million (c.i.f., 1968); fertilizer, flour, transportation
equipment, lumber, textiles
Major: trade partners: U.K. 39%, U.S. 10%, Canada 10% (1967)
Monetary conversion rate: 1.93 East Caribbean dollars=US$1 (6 October 1971)
Agriculture: dates, grains, livestock; not self-sufficient in food
Major industries: petroleum production 3.8 million barrels per day (1970); est.
payments to Saudi Arabian Government, $1,223 million in 1970; cement
production and small steel-rolling mill and oil refinery; several other
light industries, including factories producing detergents, plastic products,
furniture, etc.; PETROMIN, a semipublic agency associated with the Ministry
of Petroleum, has recently completed a major fertilizer plant
Electric power: 290,000 kw. capacity (1970); 1 billion kw.-hr. produced (1970),
180 kw.-hr. per capita
Exports: $2,185 million (f.o.b., 1970); 99% petroleum and petroleum products
Imports: $842 million (c.i.f., 1970); manufactured goods, transportation equipment,
construction materials, and processed food products
Major trade partners: exports -- U.S., Western Europe, Japan; imports -- Us Sissy
Japan, West Germany
Monetary conversion rate: 4.5 Saudi riyals=US$1 (IMF par value, freely convertible)
Fiscal year: follows Islamic year; the 1970-71 Saudi fiscal year covers the
period 2 September 1970 through 20 August 1971
A 295
pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-0 -
Cie eRONS: pp 79-01051A000400010002-1
Railroads: 350 mi., 4''8 1/2" gage
Highways: 7,542 mi.; 4,971 mi. bituminous, 520 mi. gravel and crushed stone,
2,051 mi. improved earth, undetermined mileage of earth and desert track
Pipelines: crude oil, 1,792 mi.; refined products, 96 mi.; natural gas, 275 mi.
Ports: 3 major, 6 minor
Merchant marine: 10 ships (1,000 GRT or over) totaling 46,200 GRT, 61,500 DWT;
includes 2 passenger, 6 cargo, 1 bulk, 1 tanker
Civil air: 23 major transport aircraft
Airfields: 228 total, 71 usable; 16 with permanent-surface runways; 9 with
runways 8,000-11,999 ft., 40 with runways 4,000-7,999 ft.
Telecommunications: excellent international radio communications; poor domestic
wire service; 44,250 telephones; 85,000 radio and 75,000 TV receivers; 11
TV, 1 FM, and 4 AM stations; 2 submarine cables
DEFENSE FORCES:
Military budget: for fiscal year ending 10 August 1972, $712.8 million; about
29.7% of total budget
9
Approved For Release 5664/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/71 : CIA-RDP79-01051A000400010002-1
NIS 50G GAL
76,000 sq. mi.; 13% forested, 40% agricultural (10%
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 1,665 mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: 330 mi.
GDP: $824 million (1969, calculated at exchange rate prevailing after August
1969); $210 per capita; real growth rate 2% (per annum)
Agriculture: main crops -- peanuts, millet, sorghum, manioc, rice; peanuts
primary cash crop; production of food crops increasing but still
insufficient for domestic requirements
Fishing: catch 182,000 tons, $23 million (1969); exports $151,000 (1969),
imports (not available)
Major industries: fishing, agricultural processing plants, light manufacturing,
mining
Electric power: 110,400 kw. capacity (1970); 337 million kw.-hr. produced (1970),
84 kw.-hr. per capita
Exports: $115 million (f.o.b., 1969); approx. 50% peanuts and peanut products;
phosphate rock; canned fish
Imports: $185 million (c.i.f., 1969); food, consumer goods, machinery, transport
equipment
Major trade partners: France, EC (other than France), and franc zone
Aid: economic -- France (1964-67) $93.1 million; U.S. (1961-70) $37.3 million;
U.S.S.R. $6.7 million loan negotiated; EC (1962-70) $100.5 million;
military -- U.S. (FY61-70) $2.8 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; prior to 13 August 1971, 277 CFA francs=US$1
Fiscal year: 1 July - 30 June
Agriculture: islands depend largely on coconut production and export of copra;
cinnamon, vanilla, and patchouli (used for perfumes) are other cash crops;
food crops -- small quantities of sweet potatoes, cassava, sugarcane, and
bananas; islands not self-sufficient in foodstuffs and the bulk of the
supply must be imported
Major industries: processing of coconut and vanilla, fishing, small-scale
manufacture of consumer goods, coir rope factory, tea factory
Electric power: 3,400 kw. capacity (1970); 8.5 million kw.-hr. produced (1970),
162 kw.-hr. per capita
Exports: $3 million (f.0.b., 1968); cinnamon (bark and oil) and vanilla account
for almost 50% of the total, copra accounts for about 40%, the remainder
consisting of vanilla, patchouli, fish, and guano
Imports: $6.3 million (c.i.f., 1968); food, tobacco, and beverages account for
about 40% of imports, manufactured goods about 25%, machinery and transport
equipment, petroleum products, textiles
Major trade partners: exports -- India, U.S.3 imports -- U.K., Burma, India,
South Africa, Kenya, Australia
299
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Aid: $1.2 million in aid in both 1965 and 1966 from U.K.
Monetary conversion rate: 5.4 Seychelles rupees=US$1
Fiscal year: calendar year
GDP: $425 million (FY70), approx. $170 per capita; real growth rate 1970, 2%- 3%
Agriculture: main crops ~~ palm kernels, coffee, Cocoa, rice, yams, millet,
cassava; much of cultivated land devoted to subsistence farming; food crops
insufficient for domestic consumption
Fishing: catch 25.5 thousand tons (1969), $3.8 million (1969)
301
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
in i A TTT
Approved For Re ‘
Major industries: mining -- diamonds, iron ore, bauxite, rutile; manufacturing
-- beverages, textiles, cigarettes , construction goods; 1 oil refinery
Electric power: 45,000 kw. capacity (1970); 125 million kw.-hr. produced (1970),
50 kw.-hr. per Capita
Exports: $107 million (f.0.b., 1969); 69% diamonds; iron ore, palm kernels, cocoa,
coffee
Imports: $111 million (c.i.f.; 1969); machinery and transportation equipment,
manufactured goods , foodstuffs, petroleum products
Major trade partners: U.K., EC, Japan, U.S. Communist countries
Monetary conversion rate: 1 leone=US$1 .20 (official); 0.833 leone=US$1
Fiscal year: 1 duly - 30 June (since 1 July 1966)
GNP: $1.9 billion (1970), $910 per capita; 11% average annual real growth
Agriculture: occupies a position of minor importance in the economy, main crops
-- poultry, hogs, small truck farming; food shortages -- grains, sugar,
dairy products
Fishing: catch 170,000 tons (1970), $5.8 million (1969)
Major industries: rubber processing and rubber products, processed food and
beverages, electronics, ship repair, entrepot trade
Electric power: 584,000 kw. capacity (1970); 2.2 billion kw.-hr. produced (1970),
728 kw.-hr. per capita
Exports: $1.6 billion (f.o.b., 1970); almost 90% reexports; rubber, fuels, food
se 303
pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Imports: $2.5 billion (c.i.f., 1970); over 40% goods reexported
Major trade partners: exports -- Malaysia, Indonesia, U.S., Japan, U.K.3
imports -- Malaysia, Japan, Indonesia, China, U.K., U.S.
Aid: U.K. -- (1960-September 1969) $254 million disbursed; (1969-73) $120
million extended; IBRD -- (1963-June 1970) $111 million committed, $61
million disbursed
Monetary conversion rate: 3.06 Singapore dollars=US$1
Fiscal year: converted to 1 April - 31 March fiscal year on 1 April 19703
formerly on calendar year basis
GDP: $137 million (1968 est.), about $50 per capita
Agriculture: mainly a pastoral country; main crops -- bananas, livestock,
sugarcane, cotton, cereals
Major industries: a few small industries, including a sugar refinery, tuna
and beef canneries, iron rod plant
Electric power: 13,000 kw. capacity (1970); 31 million kw.-hr. produced (1970),
10 kw.-hr. per capita
Exports: $34.5 million (f.o.b., 1969, est.); bananas, livestock, hides, skins
Imports: $46.9 million (c.i.f., 1969, est.); textiles, cereals, transport
equipment
Major trade partners: Italy and U.K.; Arab countries; $6.9 million imports from
Communist countries (1965)
Monetary conversion rate: 7.143 Somali shillings=US$1 (official)
Fiscal year: 1 January - 31 December
305
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
COMMUNICATIONS: Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Railroads: none
Highways: 8,324 mi.; 492 mi. paved; 478 mi. crushed stone, gravel, or
stablized soil; 7,354 mi. improved or unimproved earth
Inland waterways: Fiume Giuba navigable 345 mi. from May to mid-June and
August to late November
Ports: 4 major, 17 minor
Civil air: 6 major transport aircraft
Merchant marine: 107 ships (1,000 GRT or over) totaling 644,600 GRT, 957,100
DWT; 1 passenger, 10 tanker, 95 cargo, 1 bulk; all foreign owned and operated
Airfields: 107 total, 57 usable; 2 with permanent-surface. runways; 3 with
runways 8,000-11,999 ft., 11 with runways 4,000-7,999 ft.; 5 seaplane
stations
Telecommunications: telephone poor, telegraph fair; 4,800 telephones; 45,000
radio receivers; 2 AM, no FM or TY stations
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1971, 17,662,800; 40.9% of
total budget
306
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : CIA-RDP79-01051A0004
: - 0 -
NIS 61 SOUTH AFRICA sacar ts
472,000 sq. mi. (includes enclave of Walvis Bay,
434 sq. mi.); 12% cultivable, 2% forested, 86% desert,
waste, or urban (1970)
Land boundaries: 1,270 mi.
WATER: mes
Limits of territorial waters: 6 n. mi. (fishing, 12 n. mi.)
Coastline: 1,790 mi.
GNP: $30.5 billion; $920 per capita (1970); 68.5% consumption, 24.3% investment,
10.4% government; -3.2% net export of goods and services (1969); 1970 (est.)
real growth rate 6.4%, in 1964 constant prices
Agriculture: main crops -- cereals, oranges, grapes for wine, potatoes, olives,
sugar beets; virtually self-sufficient in good crop years; caloric intake,
2,680 (1968-69) calories per day per capita
Fishing: catch 1.2 million tons, $326.8 million (1969); exports $67.2 million
(1969 fish and fish products); imports $41.1 million (1969 fish and fish
products )
Major industries: food processing, textiles and apparel (including footwear),
metal manufacturing, chemicals, shipbuilding
Shortages: crude petroleum
Crude steel: 7.4 million metric tons produced, 220 kilograms per capita (1970
Electric power: 17,906,000 kw. capacity (1970); 56,397 million kw.-hr. produced
(1970), 1,400 kw.-hr. per capita
Exports: $2,387 million (f.o.b., 1970); principal items -- oranges and other
fruits, iron and steel products, textiles, wines, mercury, ships, canned
fruits, vegetables
Imports: $4,747 million (f.0.b., 1970); principal items -- machinery and
transportation equipment, petroleum and petroleum products, grains, cotton,
iron and steel
Major trade partners: (1970) 32.7% U.S., 23.3% West Germany, 18.7% France,
14.5% U.K., 10.7% Italy, 6.8% Netherlands; 64.2% EC; 29.2% EFTA; 20.4% Latin
America; 4.5% Eastern European countries
Aid:
economic -- U.S., $1,647.2 million authorized (FY49-70), $50.5 million
authorized (FY69), $64 million authorized (FY70); IBRD, $224 million
authorized (FY64-70), $37 million authorized (FY70);
military -- U.S., $771.4 million authorized (FY53-70), $130.9 million
authorized in FY70
Monetary conversion rate: 70 pesetas=US$1 (official)
Fiscal year: calendar year
Agriculture: practically none; some barley is grown in nondrought years; fruit
and vegetables in the few oases; food imports are essential; camels, sheep,
and goats are kept by the nomadic natives; cash economy exists largely for
the garrison forces :
Major industries: confined to fishing and handicrafts; exploitation of huge
phosphate deposit is planned
Shortages: water
Electric power: 300 kw. capacity (1970); 0.2 million kw.-hr. produced (1970),
3 kw.-hr. per capita
Exports: $445,600 (1968); dried fish, goatskins
Imports: $1,443,000 (1968); fuel for fishing fleet, foodstuffs
Major trade partners: monetary trade largely with Spain and Spanish possessions
Aid: small amounts from Spain
Monetary conversion rate: 70 pesetas=US$1 (official)','3df4bc8d43da13892f945cfeaa027472c982b9f450de2a98a378b80fdf567365','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('969024720e3eb49aaa455d092a6b801fa27139f2946a0b4a6da4007522343883',1971,'SD','Sudan','economy',49,'Agriculture: main crops -- cotton, wheat, sugar beets and barley; sheep and goat
raising; self-sufficient in food in years of average weather
Major industries: textiles, cement, glass, petroleum (83,000 bpd. production,
refining capacity 59,000 bbls. per day, 1970) food processing, soap
Electric power: 350,000 kw. capacity (1970); 900 million kw.-hr. produced
(1970), 210 kw.-hr. per capita
327
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Exports: $203 million (1970); 40% cotton, grain and wool in good years,
livestock (Eastern Europe and U.S.S.R. received 19%)
Imports: $359.8 million (c.i.f., 1970); metal products, textiles, machinery, Sugar
Monetary conversion rate: 3.82 Syrian pounds=US$1 (controlled rate); 4.20 Syrian
pounds=US$1 (free rate) (1970, October)
Fiscal year: calendar year
Mainland:
GDP: $1,058 million at 1966 prices (1969), about $80 per capita; growth rate in
constant 1966 prices for 1969 3.1%
Approved For Release 2004/08/31 : ¢1A-RDP79-01051A000400010002-1
A d : zi - 3
ECONOMY (cont''d): pproved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Agriculture: main crops -- cotton, coffee, sisal on mainland; largely self-
sufficient in food
Fishing: catch 140,200 tons, $1,329,200; exports $734,000, imports $655,000
Major industries: primarily agricultural processing (sugar, beer, cigarettes,
sisal twine), diamond mine, oi] refinery, shoes, cement
Electric power: 93,500 kw. capacity (1970); 360 million kw.-hr. produced (1970),
24 kw.-hy. per capita
Exports: $256 million (f.o.b., 1969); coffee, cotton, sisal, cashew nuts, meat,
diamonds, cloves, coconut products
Imports: $244 million (c.i.f., 1969); manufactured goods, machinery and transport
equipment, cotton piece goods, crude oil, foodstuffs (mainly for Zanzibar);
Zanzibar accounted for $6.8 million of total imports (1968)
Major trade partners: exports -- Communist countries $11.7 million, Zanzibar
$14 million (cloves and coconut products); imports -- Communist countries
$25.3 million (1968)
Monetary conversion rate: 1 Tanzanian shilling=US$0.14; 7.143 Tanzanian
shi] lings=US$1
Fiscal year: 1 July - 30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops -- cloves, coconuts
Industries: agricultural processing
Electric power: see Tanganyika (above)
Exports: $12.6 million (1968); cloves and clove products, coconut products
Imports: $5.6 million (1968); mainly foodstuffs and consumer goods
Major trade partners: imports -- China, Japan, and mainland Tanzania;
exports -- Singapore, China, Hong Kong, U.K.
Aid: U.K. principal source of aid until 1964; China and East Germany
extended through June 1968 -- $25 million
Exchange rate: 1 Tanzanian shilling=US$0.14; 7.143 Tanzanian shillings=US$1
Fiscal year: 1 July - 30 June
GDP: $6.5 billion (1970 est. in current prices), $175 per capita; estimated 6%
real growth in 1970
Agriculture: world''s second largest rice exporter; main crops -- rice, rubber,
corn; almost 100% self-sufficient in food
Fishing: catch 1.27 million tons, $220 million (1969); exports -- none, imports~-
none (1969)
Major industries: agricultural processing, textiles, wood and wood products,
cement, tin mining; non-Communist world''s third largest tin producer
Shortages: fuel sources, including coal and petroleum
Electric power: 1,287,000 kw. capacity (1970); 5 billion kw.-hr. produced
(1970), 140 kw.-hr. per capita
Exports: $711 million (f.o.b., 1970); rice, rubber, corn, tin, cassava, kenaf
Imports: $1,262 million (c.i.f., 1970); excluding U.S. military imports ;
machinery and transport equipment, textiles, fuels and lubricants, base
metals, chemicals
Approved For Release 2004/08/37 CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Major trade partners: exports -- Japan, U.S., Singapore, Hong Kong, Netherlands,
Malaysia; imports -- Japan, U.S., West Germany, U.K.; about 1% or less trade
with Communist countries
Monetary conversion rate: 20.8 baht=US$1
Fiscal year: 1 October - 30 September
GDP: $267 million, about $140 per capita; estimated real growth 1966-70, 5.3%
average annual rate
Agriculture: main cash crops -- coffee, cocoa; major food crops -- yams, cassava,
corn, beans, rice, fish; must import some foodstuffs
Major industries: phosphate mining, agricultural processing, handicrafts,
textiles, beverages
Electric power: 11,900 kw. capacity (1970); 38 million kw.-hr. produced (1970),
20 kw.-hr. per capita
Exports: $54.8 million (f.0.b., 1970); phosphates, cocoa, coffee, palm
kernels, and cassava
Imports: $64.7 million (c.i.f., 1970); consumer goods,
fuels, machinery, tobacco, foodstuffs
Approved For Release 2004/08/31 * CIA-RDP79-01051A000400010002-1
Approved For Release 2004/08/31 : - =
ECONOMY (cont''d): CIA-RDP79-01051A000400010002-1
Major trade partners: mostly with France and other EC countries
Aid: (1970 disbursements) France $2.3 million, West Germany $2.0 million, U.S.
$0.7 million (FY60-70 total commitments $1.6 million), EC $5.5 million,
U.N. $1.8 million, others $1.1 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs (prior to 13 August 1971, 277 CFA francs=US$1 )
Fiscal year: calendar year','783a74e92d36f850138d3d245b74489ae5d537c6b853f527e0c71acfa348ffda','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bb9508365bff5f1ae658c73009270ca2494e98fcce4a2d27f3db0bda4a04d63',1971,'JP','Japan','economy',51,'Monetary conversion rate: approx. 1.25 Yemeni rials=US$1 January 1967 (official);
about 2.92 Yemeni rials=US$1 January 1967 (free market)
Fiscal year: 1 July - 30 June
GNP: $18.5 billion (est.) in 1970 (at 1969 prices), $900 per capita; 1970 growth
rate approx. 4.5%
Agriculture: diversified agriculture with many small private holdings and large
agricultural combines; main crops -- corn, wheat, tobacco, sugar beets, and
sunflowers; generally a net exporter of foodstuffs and live animals; self-
sufficient in food except for tropical products, cotton, wool, and vegetable
meal feeds; caloric intake, 3,210 calories per day per capita (1967)
Major industries: metallurgy, machinery and equipment, textiles, wood
processing, food processing
Shortages: fuels, steel, textile fibers
Crude steel: 2.2 billion metric tons produced (1970), 110 kg. per capita
Electric power: 6,881,000 kw. capacity (1970); 26 billion kw.-hr. produced
(1970), 1,260 kw.-hr. per capita
Exports: $1,679 million (f.o.b., 1970); 19% foodstuffs and tobacco; 16% raw
materials, fuels, and chemicals; 23% machinery and equipment; 42% other
manufactures
Imports: $2,874 million (c.i.f., 1970); 7% foodstuffs and tobacco; 26% raw
materials, fuels, chemicals; 33% machinery and equipment; 34% other
manufactures
Major trade partners: $4,553 million (1970); 75% non-Communist countries (37%
EC, 5% U.S., 33% other non-Communist countries), 25% Communist countries
Aid: postwar credits extended mainly by the U.S. ($2.9 billion, including grants
and $700 million in military aid); Western Europe (over $750 million); IBRD
($377 million); IMF ($262 million); Communist countries extended credits
totaling $464 million in 1956 ($125 million drawing balance suspended in 1958)
and $140 million during 1962-66; Yugoslavia has extended credits
totaling about $600 million to 27 less developed countries of Africa, Asia,
and Latin America
Monetary conversion rate: 15 dinars=US$1, effective 24 January 1971 in
conjunction with currency reform (1 new dinar=100 old dinars )
Fiscal year: same as calendar year (all data refer to calendar year or to middle
or end of calendar year as indicated)
GDP: $2 billion (1970), about $100 per capita; real growth rate
7% p.a. 1968-70
Agriculture: main cash crops -- coffee, palm oil, rubber; main food crops --
manioc, bananas, root crops, corn; some provinces self-sufficient
Major industries: mining, mineral processing, light industries
Electric power: 715,600 kw. capacity (1970); 2,840 million kw.-hr. produced
(1970), 174 kw.-hr. per capita
Exports: $793 million (f.o.b., 1970); copper, diamonds, other minerals, coffee,
palm oi]
Imports: $620 million (c.i.f., 1970); consumer goods, foodstuffs, mining
and other machinery, transport equipment, fuels
Major trade partners: Belgium, U.S., and West Germany
371
Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
ECONOMY (cont''d): Approved For Release 2004/08/31 : CIA-RDP79-01051A000400010002-1
Aid: economic -- U.S. (FY62-70) $344 million; (1969 estimated disbursements )
Belgium, $22.5 million; France, $5.2 million; West Germany, $0.6 million;
other bilateral aid $3 million; U.N., $7.4 million; EC, $9 million
military -- U.S., $25.8 million (FY62-70)
Monetary conversion rate: 1 zaire=US$2
Fiscal year: calendar year
GNP: 1 OE ton (1969 est.), $380 per capita; real growth rate 13% between 1965
an 69
Agriculture: main crops -- corn, tobacco, cotton; net importer of all major
agricultural products
Fishing: catch 44,000 tons, $3.4 million (1969)
Major industries: copper mining and processing
Electric power: 788,200 kw. capacity (1970); 3,527 million kw.-hr. produced
(1970), 850 kw.-hr. per capita
Exports: $1.0 billion (f.o.b., 1970); copper, zinc, cobalt, lead, tobacco
37
Approved For Release 2004/08/31 : &IA-RDP79-01051A000400010002-1
ete a
Approved For Release 200
4/08/31 : CIA-R -
ECONOMY (cont''d): DP79-01051A000400010002-1
Imports: $502 million (f.0.b., 1970); consumer goods, machinery; transport
equipment, foodstuffs, fuels
Major trade partners: U.K., South Africa, Japan, Western Europe
Aid:
economic -- China $200 million credit for Tanzam railroad (1970);
(1964-67 ) U.K. $63 million (1966); IBRD $99 million (1970); U.S. $12 million;
U.S.S.R. $6 million; China extended $19 million;
military -- $9 million (1964-69); mainly U.K. and Canada
Monetary conversion rate: 1 Zambia kwache=US$1 .40 (official), 0.714 Zambia
kwacha=US$1
Fiscal year: calendar year
GNP: $974.1 billion (1970); 63.2% consumption, 13.9% investment, 22.5% government,
0.4% foreign; $4,760 per capita; 1970 growth rate -0.6%
Fishing: catch 2,495,400 tons (1969)
Crude steel: 119 million metric tons produced (1970)
Electric power: 331,905,000 kw. capacity (1969); 1,638,010 million kw.-hr.
produced (1970), 7,980 kw.-hr. per capita
Exports: $43,226 million (f.o.b., 1970); machinery and transport equipment,
* chemicals, cereals, mineral fuels
Imports: $39,963 million (c.i.f., 1970); transport equipment, machinery, mineral
fuels, steel, nonferrous metals, metal ores
Major trade partners: (1970) Canada 24%, EC 18%, Japan 13%, U.K. 6%
Official development assistance (aid): net disbursements $3,119 million (1970)
oo Fiscal year: 1 July - 30 June','676e0334790eb996b2c97144fb025f4606b31e26101e9d6199ac56ef38ef3512','internet-archive','cia-readingroom-document-cia-rdp79-01051a000400010002-1','txt','e623ccd630c0624d9327977bd46c403c5a83284441b04e32ac741ee5813e46b9','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000400010002-1/cia-rdp79-01051a000400010002-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

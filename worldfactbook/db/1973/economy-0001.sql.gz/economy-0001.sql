SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e78d9eea7e6b421b76e819c1419d878926275e435e451914151680c6737859f6',1973,'','','economy',4,'GNP: $12,016 million (1971), about $330 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electrtc power: 2.6 million kw, capacity (1971); 9,724 million kw.-hr. produced
(1971), 267 kw.-hr. per capita
Exports: $616.5 million (f.0.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 192, U.S. 102, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Aid: $1,602 million assistance disbursed 1963-69 by the Aid of Turkey Consortium
consisting of the U.S., 13 additiona) OECD member countries, the IMF, IBRD,
and European Fund of the EMA; $390.5 million extended by Communist countries
1955-December 1971; none extended in 1971; total U.S. economic, $2,727.9
million (July 1946-Ju : total U.S. military $3,250.2 million
(July 1946-June 1971)
Monetary conversion rate: urkish liras=US$] (official rate)
Fiscal year: 1 March - 28 February','1de57ea31cf866407b6e812547f4485a4e5342ee730fa5f2945b98c2595fcb1c','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f76c698358f1381d18498f4eb58e289c63a84019bd5e4eb640ea7da238206d87',1973,'','','economy',4,'GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2.8 million kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $616.5 million (f.0.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Aid: $390.5 million extended by Communist countries 1955-December 1971; none
extended in 1971; total U.S. economic, $2,727.9 million (1946-71); total
U.S. military $3,250.2 million (July 1946-June 1971); $603 million in aid
commitments from international tes (1946-71); $657 million in bilateral
aid from other sources 1960-70
Monetary conversion rate: 14 Turkish liras=US$1 (official rate)
Fiscal year: 1 March - 28 February','4c5921c18d539de60f8b6e157cd7b171fa7672f2c9502dc3d789c30404de55ea','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3288b795cc2e9c1f612499ba160a749bfcb45baa6ba0abacb6234c805c6a9000',1973,'','','economy',4,'GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971 :
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2.8 million kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $616.5 million (f.o.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
Mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Monetary conversion rate: 14 Turkish liras=US$] (official rate)
Fiscal year: 1 March - 28 February','a893c8676599b7e8f9599afa88721528d836b28df6ec5629e7a51b3407d7a703','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8682915d40a7541aa97037fa8568328a0d0a72b0bfe187fc1b6da8f381750c70',1973,'','','economy',4,'GNP: $1.0 billion (FY71), well below $100 per capita; real growth rate probably
near zero in 1970-71
Agriculture: agriculture and animal husbandry account for over 50% of GNP and
occupy nearly 80% of the labor force; main crops -- wheat and other grains,
cotton, fruits, nuts; largely self-sufficient; food shortages -- wheat,
sugar, tea
Major industries: cottage industries, food processing, textiles, cement, coal
mining
Electric power: 275,000 kw. capacity (1972); 470 million kw.-hr. produced
(1972) , 26 kw.-hr. per capita
Exports: $83.7 million (f.0.b., 1970-71); fruits and nuts, karakul, natural gas,
carpets and rugs, wool, cotton
Imports: $117.4 million (c.i.f., 1970-71); wheat, textiles, sugar, tea, petroleum,
transportation equipment
Major trade partners: exports -- U.S., U.K., U.S.S.R., and India; imports --
about 40% from U.S.S.R.
Monetary conversion rate: 45 Afghanis per US$1 (official); 81.79 Afghanis per
US$1 (August 1972)
Fiscal year: 21 March - 20 March','90541b241a1dda0f646dcb2a2eb9a54749d3ff5f3fbddedf4a7a03fedd776de3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c39780fc1bd199f685638e5f9664cc5ef2eb241a99c091e41ba5345fe9b98713',1973,'AL','Albania','economy',9,'GNP: $0.84 billion in 1970 (at 1970 prices), $390 per capita
Agriculture: food deficit area; main crops -- corn, wheat, tobacco, sugar beets,
cotton; food shortages -- wheat; caloric intake, 2,100 calories per day per
capita (1961/62)
Major industries: agricultural processing, textiles and clothing, lumber, and
extractive industries
Shortages: spare parts, machinery and equipment, wheat
Exports: $80 million (1969 est.); 1964 trade -- 55% minerals, metals, fuels;
17% agricultural materials (except foods); 23% foodstuffs (including
cigarettes); 5% consumer goods
Approved For Release 2004/09/15 : CJA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Imports: $143 million (1969 est.); 1964 trade -- 50% machinery, equipment, and
spare parts; 16% minerals, metals, fuels, construction materials; 7%
fertilizers, other chemicals, rubber; 4% agricultural materials (except
foodstuffs); 16% foodstuffs; 7% consumer goods
Monetary conversion rate: 5 leks=US$1 (commercial); 12.5 leks=US$1 (noncommercial )
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year
1 July - 30 June
GNP: $5.0 billion (est. 1971), $350 per capita; real average annual increase
since 1968, 8%
Agriculture: main crops -- wheat, barley, wine, citrus fruits
Major industries: petroleum, light industries, natural gas, mining, petrochemical
and steel plants under construction
Electric power: 1,230,000 kw. capacity (1971); 1.9 billion kw.-hr. produced
(1971), 125 kw.-hr. per capita
Exports: $996 million (f.o.b., 1970); crude petroleum 66%, other items -- wine,
citrus fruit, iron ore, vegetables; 54% of exports to France (1970)
Approved For Release 2004/09/15 : ChA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Imports: $1,241 million (c.i.f., 1970); major items -- capital goods, foodstuffs,
textiles; 42% from France (1970)
Monetary conversion rate: 4.547 dinars=US$1
Fiscal year: calendar year
Agriculture: sheep raising; small quantities of tobacco, rye, wheat, barley,
oats, and some vegetables (only 25% of land can be used for agriculture)
Major industries: tourism ($1 million annually), one cigarette factory (annual
output $1 million), handicrafts, smuggling (tobacco to France; manufactured
items, including automobiles and cameras, to Spain)
Shortages: food
Electric power: 25,000 kw. capacity (1971); 95 million kw.-hr. produced (1971),
380 kw.-hr. per capita; power is mainly exported to Spain and France
Major trade partners: Spain, France
GNP: $1.2 billion (1970 est.), about $220 per capita
Agriculture: cash crops -- coffee, sisal, corn, cotton, sugar, manioc, and
tobacco; food crops -- cassava, corm, vegetables, plantains, bananas, and
other local foodstuffs; largely self-sufficient in food
Fishing: catch 368,000 metric tons, $8.4 million (1970); exports $19 million;
imports $4.1 million (1970)
Major industries: mining (oi], iron, diamonds), fish processing, brewing, tobacco,
sugar processing, cement, food processing plants, building construction
Electric power: 433,000 kw. capacity (1971); 694 million kw.-hr. produced
(1971), 125 kw.-hr. per capita
Approved For Release 2004/09/15 : C(IA-RDP79-01051A000500010001-1
ECONOMY (cont Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Exports: $441 million (f.0.b., 1971); coffee (50%), 011, diamonds, sisal, fish
and fish products, iron ore, oil, timber, and corn
Imports: $447 million (c.i.f., 1971); capital equipment (machinery and electrical
equipment), wines, bulk iron and ironwork, steel and metals, vehicles and
spare parts, textiles and clothing, medicines
Major trade partners: main partner Portugal, followed by West Germany, U.S.,
U.K. , Japan
Aid: Portugal only donor
Monetary conversion rate: 27.25 escudos=US$1 (approximate realigned rate)
Fiscal year: calendar year
GDP: $27.2 million (at factor cost, 1967 est.), $470 per capita
Agriculture: main crops -- sugar, cotton
Major industries: sugar processing, tourism
Shortages: electric power
Electric power: 22,440 kw. capacity (1971); 45 million kw.-hr. produced (1971
est.), 540 kw.-hr. (est.) per capita
Exports: $2.9 million (f.o.b., 1967); sugar, molasses, cotton
Imports: $22.2 million (c.i.f., 1967); food, clothing, oi], wood
Major trade partners: U.K. 30%, U.S. 25%, Commonwealth Caribbean countries
18% (1966)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1 (6 October 1971)
in
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Railroads: 49 mi. narrow gage (2''6"), employed almost exclusively for handling cane
Highways: 235 mi.; 150 mi. main, 85 mi. secondary
Ports: 1 major, 1 minor
Civil air: 1 major transport aircraft
Airfields: 3 total, 1 usable; 1 with asphalt runway 9,000 ft.; 1 seaplane
station
Telecommunications: automatic telephone system; 2,800 telephones; tropospheric
scatter links with Tortola and St. Lucia; 20,000 radio receivers, 8,500 TV
sets; 2 AM and 1 TV stations; 2 coaxial submarine cables
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : Reo n00500010001=1
15
ARGENTI
LAND:
1,070,000 sq. mi.; 57% agricultural (11% crops, improved ;
pasture and fallow, 46% natural grazing land), 25% BRAZIL
forested, 18% mountain, urban, or waste
Land boundaries: 5,850 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 3,100 mi.
GNP: $32.4 billion (purchasing power parity estimate, 1971), $1,370 per capita;
68% private consumption, 12% public consumption, 18% gross domestic investment,
2% net foreign balance (1968); real growth rate 1971, 3.8%
Agriculture: main products -- cereals, oilseeds, livestock products; Argentina
is a major world exporter of temperate zone foodstuffs
Fishing: catch 214,800 metric tons, $20.2 million; exports $1,158,000, imports
$3,659,000 (1970)
Major industries: food processing (especially meatpacking), motor vehicles,
consumer durables, textiles, chemicals, printing, and metallurgy
Crude steel: 1.91 million metric tons produced (1971); 80 kilograms per capita
Electric power: 6,650,000 kw. capacity (1971); 22.8 billion kw.-hr.
produced (1971), 940 kw.-hr. per capita
Exports: $1,740.4 million (f.o.b., 1971) -- meat, wheat, corn, wool, hides, oil-
seeds
Imports: $1,887.6 million (c.i.f., 1971) -- machinery, fuel and lubricating oils,
iron and steel, intermediate industrial products
Major trade partners: exports -- EC 37%, LAFTA 25%, U.S. 11%, U.K. 8%;
imports -- EC 24%, LAFTA 24%, U.S. 23%, U.K. 7%
Aid: economic -- extensions from U.S. (FY46-71), $803.0 million in loans; $18.0
million in grants; from international organizations (FY46-70), $1,109.8
million; from other Western countries (1960-66), $315.5 million; from
Communist countries (1954-71) $56 million (drawn, $41.0 million);
military -- assistance from U.S. (FY46-71), $152.2 million
Monetary conversion rate: commercial -- 5.00 pesos = US$1; financial -- floating
(9.95 pesos = US$] July 1972)
Fiscal year: calendar year','6586801e399535f30807c7bef65ea2570950a2d19e4a502edf97e5a37c41db91','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c76bf88e828f8bae090aa6ed2d935f599bb245abe17e6983987b169ecafadce0',1973,'AT','Austria','economy',12,'GNP: $17.8 billion (1971), $2,400 per capita; 56.1% consumption, 29.3% investment,
14.4% government, 0.2% net foreign balance (1970); 1971 growth rate 5.2% 1964
constant prices
Agriculture: livestock, cereals, potatoes, sugar beets; 84% self-sufficient;
caloric intake 2,920 calories per day per capita (1967-68)
Fishing: catch 4,000 metric tons, $3,846,000 (1968); exports $847,000 (1970),
imports $28,711,000 (1970)
Major industries: foods, iron and steel, machinery, textiles, chemicals,
electrical, paper and pulp
eb 4.1 million metric tons produced (1970), 550 kilograms per capita
0
Approved For Release 2004/09/15 | €IA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY iconeiay:
Electric power: 8,177,000 kw. capacity (1971); 28,755 million kw.-hr produced
(1971), 3,847 kw.-hr. per capita
Exports: $3.39 billion (f.o.b., 1971); iron and steel products, machinery and
equipment, lumber, textiles and clothing, paper products, chemicals
Imports: $4.48 billion (c.i.f., 1971); machinery and equipment, chemicals,
textiles, coal, petroleum, foodstuffs
Major trade partners: (1971) West Germany 33%, Italy 8%, Switzerland 9%,
: U.K. 7%, U.S. 4%; EC 48%; EFTA 22%; Communist countries 10%
Aid:
economic -- received - U.S. $1,188.2 million through FY71; IBRD $104.9
million, none since FY62;
military -- U.S., $144.6 million (FY52-71); net official economic aid to
less developed areas and multilateral agencies -- $189 million (FY60-70),
$24.2 million in FY70
Monetary conversion rate: 23.30 shillings=US$1 (central rate)
Fiscal year: calendar year
COMMUNTCATIONS:
Railroads: 4,073 mi.; 3,673 mi. government owned; 3,373 mi. standard gage of which
1,408 mi. electrified and 833 mi. double tracked; 300 mi. narrow gage (2''6")
of which 57 mi. electrified; 400 mi. privately owned; 229 mi. standard gage
of which 109 mi. electrified; 171 narrow gage (2''6" and 3''3 3/8") of which
55 mi. electrified
Highways: 20,356 mi. total; 6,056 mi. Federal (5,656 mi. bituminous, concrete,
stone block, 400 mi. crushed stone, gravel, improved earth); 14,290 mi.
Provincial (4,340 mi. bituminous, concrete, stone block, 9,950 mi. crus hed
stone, gravel, improved earth); additionally about 38,600 mi. of communal
roads, mostly of gravel, crushed stone, and improved earth
Inland waterways: 267 mi.; carries 5% freight, 6% passengers
Ports: 3 major
Merchant marine: 16 ships (1000 GRT or over) totaling 75,700 GRT, 110,500 DWT;
includes 14 cargo, 1 bulk, 1 specialized carrier
Pipelines: crude oi], 430 mi.; natural gas, 775 mi.
Civil air: 9 major transport aircraft
Airfields: 64 total, 12 usable; 53 with permanent-surface runways; 2 with run-
ways 8,000-11,999 ft., 9 with runways 4,000-7,999 ft.
Telecommunications: highly developed and efficient; excellent national and
international services; extensive TV and radiobroadcast systems with 100 AM,
68 FM, and 195 TV stations; 1.59 million telephones; 2.48 million radio
receivers; 1.65 million television receivers
DEFENSE FORCES:
Military manpower: males 15-49, 1,679,000; 1,350,000 fit for military service;
average number reaching military age (19) annually about 52,000
Supply: produces some small arms and ammunition, trucks, and tank destroyers;
current sources of other items are the U.S$., Western Europe, Sweden,
and the Communist countries
Military budget: for fiscal year ending 31 December 1972, $198.4 million; about
3.9% of the federal budget and 1.2% of GNP
Approved For Release 2004/89/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/1 BarfalAsRDP79-01051A000500010001-1
LAND:
4,400 sq. mi.; 1% cultivated, 29% forested, 70% built
on, wasteland, and other
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 2,200 mi. (New Providence Is. 47 mi.)
GNP: not available
Agriculture: main crops -- fruits, vegetables
Major industries: tourism, cement, oil refining, lumber, salt production
Electric power: 177,200 kw. capacity (1971); 537.0 million kw.-hr. produced
(1971), 3,055 kw.-hr. per capita
Exports: $246 million (f.o.b., 1971); fuel oi], cement, rum, pulpwood, fruits,
and vegetables
Imports: $515.6 million (c.i.f., 1971); foodstuffs, manufactured goods, crude oil
Major trade partners: exports -- U.S. 68%, U.K. 7%, Canada 6%; imports -- U.S.
54%, U.K. 14%, Italy 7%, Canada 4%, other 21% (1970)
Aid: economic -- authorizations from U.S. (FY56-70) -- $21.7 million in Toans,
$0.3 million in grants
Monetary conversion rate: 0.97 Bahamian dollars (B$)=US$1
Fiscal year: calendar year
Agriculture: produces dates, alfalfa, vegetables; dairy and poultry farming;
fishing; not self-sufficient in food
Major industries: petroleum refining, boatbuilding, shrimp fishing, and
sailmaking on a small scale; major development projects include aluminum
smelter, flourmil], and ISA town
Electric power: 108,000 kw. capacity (1970); 270 million kw.-hr. produced (1970),
1,250 kw.-hr. per capita
Imports: $241 million (1972)
Major trade partners: U.K., Japan, U.S., EC
Aid: economic -- multilateral Western $360,000 (annual average 1967-69)
Monetary conversion rate: 1 Bahrain dinar=US$2.27 (as of March 1972)
Fiscal year: 1 April - 31 March
GNP: $5.8 billion (FY70), less than $100 per capita; real growth (FY70) 5.8%
Agriculture: largely subsistence farming, heavily dependent on monsoon rainfall;
main crops are jute and rice; shortages -- rice, wheat, and cotton
Fishing: catch 273 thousand tons, $115 million (estimate, 1969)
Major industries: jute manufactures, food processing and cotton textiles
Electric power: 680,000 kw. capacity (1972); 1.2 billion kw.-hr. produced (1972),
19 kw.-hr. per capita
Exports: $359 million (f.o.b., FY71)3 raw and manufactured jute, tea, paper and
paperboard, hides and skins
Imports: $505 million (c.i.f. FY71); chemicals, machinery and other manufactured
products, transport equipment, foodgrains, fuels, oils and fats
*Does not take account of refugees who entered India from Bangladesh during 1971, most
of whom presumably have returned.
Approved For Release 2004/09/15 : (A-RDP79-01051A000500010001-1
ECONOMY (coneproved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Major trade partners: West Pakistan (until December 1971), U.S., U.K., Japan,
India (since December 1971)
Aid: Bangladesh received roughly one-third of the estimated $8 billion in total
economic aid received by Pakistan between 1950 and 1971; the U.S, was by
far the largest contributor
Monetary conversion rate: 7.5 takas=US$1 (effective September 1972)
Fiscal year: 1 July - 30 June','0abff234ea5afe25e73ca26a28e0ffde2a7652554eeda33dea39a993e25e3f3a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c48f77bf07898909a5505aa8b77a07c7b41a80f037d971b10b61de01993167d',1973,'BR','Brazil','economy',15,'GDP: $160.7 million (1971), $620 per capita; real growth rate 1970, 0.0% (est.)
Agriculture: main products -- sugar, subsistence foods
Major industries: tourism, sugar milling, manufacturing, edible oils and fats
Electric power: 48,000 kw. capacity (1971); 150 million kw.-hr. produced
(1971), 580 kw.-hr. per capita
Exports: $39.6 million (f.o.b., 1971); sugar, molasses, rum
myers $134.7 million (c.i.f., 1971); foodstuffs, lumber, machinery, manufactured
goods
Major trade partners: exports -- U.K. 32%, U.S. 13%, CARIFTA 27%, other 22%;
imports -- U.K. 30%, U.S. 18%, Canada 10%, CARIFTA 12%, other 27%
Aid: economic -- U.S. (FY67-70), $0.7 million in grants; from international
organizations (FY63-70), $0.8 million
Monetary conversion rate: 1.92 East Caribbean dollars=US$1
Fiscal year: 1 April - 31 March
Approved For Release 2004/09/15 : GIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GNP: $49.5 billion (purchasing power parity estimate, 1971), $520 per capita;
18.8% gross investment, 83.3% consumption, -2.1% foreign balance (est. 1971);
real growth rate 1971, 11.3%
Agriculture: main products -- coffee, rice, beef, corn, milk, sugarcane, beans;
igeet self-sufficient; caloric intake, 2,900 calories per day per capita
1962
Fishing: catch 493,000 metric tons (1969); exports $18.7 million, imports $34.7
million (1970)
Major industries: textiles and other consumer goods, cement, lumber, steel,
motor vehicles, other metalworking industries
Crude steel: 6.5 million metric tons capacity (1971 est.); 6 million metric
tons produced (1971); 60 kilograms per capita (1971)
Approved For Release 2004/09/15 : SJA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Electric power: 12.8 million kw. capacity (1971); 52 billion kw.-hr. produced
(1971), 500 kw.-hr. per capita
Exports: $2,900 million (f.o.b., 1971); coffee, manufactures, iron ore, cotton,
sugar, wood, cocoa
Imports: $3,250 million (f.o.b., 1971); machinery, chemicals, pharmaceuticals,
petroleum, wheat
Major trade partners: exports -- U.S. 23%, West Germany 10%, Italy 7%, Argentina
7%, Netherlands 6%, Japan 5%, U.K. 5%; imports -- U.S. 31%, West Germany 13%,
Argentina 6%, U.K. 5%, Italy 3% (1970)
Aid: economic -- extensions from U.S. (FY46-71) -- loans $3,168.5 million,
grants $623.9 million; from international organizations (FY46-72) $1,651.2
million; from other Western countries (1960-66) -- $343.6 million; from
Communist countries (1954-71) $330.6 million; drawings $124.4 million
Monetary conversion rate: 6.0 cruzeiros=US$1 (September 1972, changes frequently)
Fiscal year: calendar year
GNP: $65.6 million (est. 1970), $540 per capita; 78% private consumption, 17%
public consumption, 36% domestic investment, -31% net foreign balance
(1968); real growth rate 1970 7% (est.)
Agriculture: main products -- citrus fruits, sugar, corm, rice, beans, livestock
products; net importer of food; caloric intake, 2,500 calories per day
per capita
Major industries: timber and forest products, food processing, furniture, rum,
soap
Electric power: 6,350 kw. capacity (1970 est.); 19 million kw.-hr. produced
(1970), 160 kw.-hr. per capita
Exports: $19 million (f.o.b., 1970 est.); sugar, lumber, citrus fruits, fish
Approved For Release 2004/09/15 : C4A-RDP79-01051A000500010001-1
proved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
A
ECONOMY (cont “df:
Imports: $35 million (c.i.f., 1970 est.); vehicles, petroleum, food, textiles,
machinery
Major trade partners: exports -- U.S. 30%, U.K. 24%, Mexico 22%, Canada 13%;
imports -- U.S. 34%, U.K. 25%, Jamaica 7% (1970)
Aid: economic -- U.S. (FY46-71), $5.5 million, grants; from international
organizations (1946-71), $1.4 million
Monetary conversion rate: $BH1.54=US$1 (official)
Fiscal year: calendar year
GNP: $132 million (1968 est.), $1,180 per capita
Agriculture: main crops -- rubber, rice, pepper, must import most food
Major industry: crude petroleum
Electric power: 85,000 kw. capacity (1972); 145 million kw.-hr. produced (1972),
1,028 kw.-hr. per capita
Exports: $92 million (f.0.b. 1970); 95% crude petroleum, natural gas, rubber
Imports: $84 million (c.i.f. 1970); 37% machinery and transport equipment,
29% manufactured goods, 15% food
Major trade partners: exports of crude petroleum go to Sarawak for refining
and reexport; 30% imports from U.K., Singapore 16%, Japan 13%
Monetary conversion rate: 2.82 Brunei dollars=US$1
Fiscal year: calendar year
GNP: $10.6 billion (purchasing power parity estimate, 1971), $1,170 per capita;
75% private consumption, 15% government consumption, 10% gross investment
(1971 est.); real growth rate 1971 (est.), GNP 8.0%
Agriculture: main crops -- wheat, other cereals, potatoes; about 65% self-
sufficient; 2,650 calories per day per capita (1971 est.)
Fishing: catch 1.04 million metric tons; exports $25.4 million, imports $0.2
million (1970)
Major industries: copper, nitrates, foodstuffs, fish processing, textiles and
apparel, iron and steel, pulp and paper
Crude steel: 0.7 million metric tons capacity (1967); 0.6 million metric tons
produced (1969), 60 kg. per capita
Electric power: 2.6 million kw. capacity (1971); 8.98 billion kw.-hr. produced
(1971), 850 kw.-hr. per capita
Exports: $1,040 million (f.o.b., 1971 est.); copper, iron ore, fishmeal, nitrates,
and iodine
Imports: $1,124 million (c.i.f., 1971 est.}; foodstuffs, machinery and equipment,
chemicals
Major trade partners: exports -- EC 42%, U.K. 12%, U.S. 14%, Japan 12%, LAFTA
10%; imports -- U.S. 37%, EC 21%, U.K. 6%, Japan 3%, LAFTA 21% (1970)
Aid:
economic -- extensions from U.S. (FY46-71) -- $1,502.7 million ($1,289.6
million loans, $213.1 million grants); from international organizations
(FY46-70) -- $566.3 million (of which IBRD $232.7 million, IDB $253.9
million); from other Western countries (1960-66) -- $170.6 million; from
Communist countries (1967-71) -- $193.3 million;
military (FY53-71) -- from U.S., $25.1 million in loans, $124.4 million in
grants
Monetary conversion rate: multiple exchange rate system; range from 15.80 to
30.0 escudos=US$1 trade rate; 28.03 escudos=US$1 nontrade (broker) rate;
varying taxes double effective rate for some purposes; black market rate is
upwards of 200 escudos=US$1 (October 1972)
Fiscal year: calendar year
3
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 800 mi.
Government budget: Colony -- revenues, $1.0 million (FY68); expenditures,
$1.1 million (FY68)
Agriculture: Colony -- predominantly sheep farming; dependencies -- whaling
and sealing
Major industries: Colony -- wool processing; dependencies -- whale and seal
processing
Electric power: 1,440 kw. capacity (1971); 4 million kw.-hr. produced (1971),
1,740 kw.-hr. per capita
Exports: Colony -- $2.28 million (1969); wool, hides and skins, and other;
dependencies -- no exports in 1968 or 1969
Imports: Colony -- $1.22 million (1969); food, clothing, fuels, and machinery;
dependencies -- $8,368 (1969); mineral fuels and lubricants, food,
and machinery
Major trade partners: nearly all exports to the U.K., 77% of imports from the
U.K.; dependencies -- exports to the Netherlands (63%) and Japan (37%),
imports from Curacao, Japan, and the U.K,
Monetary conversion rate: 1 Falkland Island pound=US$2.60
GDP: $22.0 million (1967), $220 per capita
Agriculture: main crops -- cocoa, spices, bananas
Fishing: 1,500 metric tons, $618,000 (1970)
Electric power: 7,000 kw. capacity (1970 est.); 15.2 million kw.-hr. produced
(1970), 138 kw.-hr. per capita
Exports: $5.1 million (f.o.b., 1968); cocoa beans, bananas, nutmeg, mace
Imports: $13.2 million (c.i.f., 1968); textiles, flour, clothing, miscellaneous
manufactured goods
Major trade partners: U.K. 37%, U.S. 9%, Canada 9% (1966)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1
GDP: $231 million (1970 est.), $685 per capita; real growth rate (1970 est.) 1%
Agriculture: main crops, Sugarcane and bananas
Major industries: agricultural processing, sugar milling and rum distillation
Electric power: 27,800 kw. Capacity (1970); 72 million kw-hr. produced (1970),
213 kw.-hr. per capita
Exports: $38 million (f.o.b., 1970), sugar, bananas, rum
Imports: $128 million (c.i.f., 1970), foodstuffs, clothing and other consumer
goods, raw materials and supplies, and petroleum
Approved For Release 2004/09/15 :!@{A-RDP79-01051A000500010001-1
roved F : 2! z
ECONOMY (cont dyer ved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Major trade partners: exports -- France 71%, U.S. 17%, Germany 7%, other
5%; imports -- France 70%, U.S. 9%, Germany 3%, Netherlands Antilles 3%,
Netherlands 3%, other 12% (1968)
Monetary conversion rate: 5.002 francs=US$1
Fiscal year: calendar year
GDP: $1.8 billion (1971, in 1958 prices), $340 per capita; 79%
private consumption, 8% government consumption, 14% domestic investment, -1%
net foreign balance; real growth rate 1971, 5.1%
Agriculture: main products -- coffee, cotton, corn, beans, sugarcane, bananas,
livestock; caloric intake, 2,200 calories per day per capita (1967)
Fishing: catch 5,000 metric tons (1970); exports $1,700,000 (1970), imports
$500,000 (1970)
Approved For Release 2004/09/15 : CIASRDP79-01051A000500010001-1
ECONOMY (eonecqynppreved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Major industries: food processing, textiles and clothing, furniture, chemicals,
nonmetallic minerals, metals
Electric power: 178,600 kw. capacity (1971); 1,050 million kw.-hr. produced
(1971), 180 kw.-hr. per capita
Exports: $296 million (f.o.b., 1971); coffee, cotton, meat, bananas, sugar,
textiles, tires
Imports: $281 million (f.0.b., 1971); manufactured products, machinery, trans-
portation equipment, chemicals, fuels
Major trade partners: exports -- U.S. 28%, CACM 29%, West Germany 10%, Japan
, 11%; imports -- U.S. 41%, CACM 20%, West Germany 10%, U.K. 17% (1968)
id:
economic -- from U.S. (FY46-71), $182.7 million loans, $177.5 million grants;
from international organizations (FY46-71), $127.4 million; from other
western countries (1960-68) $7.6 million; military -- assistance from
U.S. (FY53-71), $24.4 million
Monetary conversion rate: 1 quetzal=US$1 (official)
Fiscal year: calendar year
GDP: about $275 million (1965), $80 per capita
Agriculture: cash crops -- coffee, bananas, palm products, peanuts, and pine-
apples; staple food crops -- cassava, rice, millet, corn, sweet potatoes;
livestock raised in some areas
Major industries: alumina, light manufacturing and processing industries,
bauxite
Electric power: 99,700 kw. capacity (1971); 239 million kw.-hr. produced (1971),
60 kw.-hr. per capita
Exports: export receipts, $51 million (FY71); alumina, bauxite, coffee,
pineapples, bananas, palm kernels
Imports: $80 million (FY71); petroleum products, metals, machinery and
transport equipment, foodstuffs, textiles
Approved For Release 2004/09/15 : CIXtRDP79-01051A000500010001-1
ECONOMY (cont''d) Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Major trade partners: Communist countries, Western Europe (including France),
U.S.
Monetary conversion rate: 22.7 syli=US$1 (October 1972)
Fiscal year: 1 October - 30 September
GNP: $1.49 billion (purchasing power parity estimate, 1971), $1,010 per capita;
72% private consumption, 11% government consumption, 26% gross fixed
investment, -9% net foreign balance (1970); real growth rate 1971, 8.0% (est.)
Approved For Release 2004/09/15 : Cl4g¢RDP79-01051A000500010001-1
ECONOMY (coneiaprrrore? For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Agriculture: main crops -- bananas, rice, corn, coffee, sugarcane; self-sufficient
in most basic foods; 2,450 calories per day per capita (1969)
Fishing: catch 42,400 metric tons, $8 million (1970); exports $11.1 million (1970);
imports $1.6 million (1970)
Major industries: food processing, metal products, construction materials,
petroleum products, clothing
Electric power: 329,000 kw. capacity (1971); 987 million kw.-hr. produced
(1971), 642 kw.-hr. per capita
Exports: $140 million (f.0.b., 1971 est.); bananas, petroleum products, shrimp,
sugar, coffee
Imports: $396 million (c.i.f., 1971 est.); manufactures, transportation equipment,
crude petroleum, foodstuffs, chemicals
Major trade partners: U.S. 43%, Venezuela 15%, Canal Zone 9%, Colon Free Zone
6% (1969)
Aid:
economic -- from U.S. (FY46-71), $161.6 million loans, $106.3
million grants; from international organizations (FY46-70), $129.6 million;
from other Western countries (1960-69), $14.5 million;
military -- assistance from U.S. (FY61-71), $4.5 million
Monetary conversion rate: 1 balboa=US$1 (official)
Fiscal year: calendar year','f8ed24a75532e64d7e3600a17a93c0df62dea57e4b54273bb41646f7388d414f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30e4c74730f2a14bce7b943a923a95f018fca24c109fb46641fa43e3b8777e41',1973,'BE','Belgium','economy',19,'GNP: $31.5 billion (1971}, $3,230 per capita (1971), 60% consumption,
24% investment, 14% government, 2% net foreign balance; 1971 growth rate
3.7%, 1970 constant prices
Approved For Release 2004/09/15 : @PBA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (coated:
Agriculture: livestock production predominates; main crops -- grains, beets,
potatoes; 80% self-sufficient in food; food shortages -- edible and coarse
grains, fats and oils; caloric intake, 3,150 calories per day per capita
(1968-69)
Fishing: catch 53,400 metric tons, $18,637,000 (1970); exports $18,118,000
(including Luxembourg, 1970), imports $85,139,000 (including Luxembourg, 1970)
Major industries: engineering and metal products, processed food and beverages,
chemicals, basic metals, textiles, and petroleum
Shortages: iron ore, nonferrous minerals, petroleum, cotton, wool, wood
Crude steel: capacity 16.6 million metric tons (1971); 12.4 million metric tons
produced (1971); 1,270 kilograms per capita
Electric power: 7,511,000 capacity (1971); 31,596 million kw.-hr. produced (1971),
3,239 kw.-hr. per capita
Exports: $13,475 million (f.o.b., 1971) motor vehicles, refined copper, iron and
steel products, finished or semifinished precious stones, textile products
Imports: $13,986 million (c.i.f., 1971) crude materials, food, fuels, automotive
parts, nonelectrical machinery and appliances, clothing
Major trade partners: (Belgium-Luxembourg Economic Union, 1971) West Germany
25%, Netherlands 18%, France 19%, U.S. 7%, U.K. 5%, Italy 4%; EC 66%, EFTA
Abe 10%, Communist countries 2%
id:
economic -- received - U.S., $767.4 million authorized (FY46-71); $15.8 million
in FY70:
military -- received - $1,253.6 million authorized (FY46-71); net official
economic aid to less developed areas and multilateral agencies -- $1,003.6
million (FY60-70), $119.6 million in 1970
Monetary conversion rate: 44.8159 francs=US$1 (official central)
Fiscal year: calendar year','429bcb5c0a0ff9d38443231217660c69536a5351cb99dda7bb9dc38ece360691','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7eaf458fd95b0a9d8f80084d6828aba79da8e309da27478e5e50f2448a3878a6',1973,'CA','Canada','economy',23,'GNP: not available
Agriculture: main products -- bananas, vegetables, Easter lilies, dairy products,
citrus fruits
Major industries: tourism, ship repair, small boat building
Electric power: 66,340 kw. capacity (1970); 226 million kw.-hr. produced (1970),
4,245 kw.-hr. per capita
Exports: $70.0 million (f.o.b., 1969); mostly reexports of drugs and bunker fuel
Imports: $85.5 million (f.o.b., 1969); fuel, foodstuffs, machinery
Major trade partners: U.S. 46%, U.K. 22%, Canada 9% (1968)
Monetary conversion rate: 1 Bermuda dollar=US$1
Fiscal year: 1 April-31 March
GNP: under $100 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Electric power: 400 kw. capacity
Exports: about $1 million annually; rice, dolomite, and handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic -- India (FY61-71) $180 million
Monetary conversion rate: 7.5 Indian rupees=US$1 (official rate); now floating
with U.K. pound
Fiscal year: 1 April - 31 March
: GDP: $59 million (1968), about $100 per capita; GDP est. after Shashi devel opment
approx. $85 million (1973) (C)
Agriculture: principal crops are corn and sorghum; livestock raised and exported
Major industries: livestock processing, mining of asbestos, manganese, diamonds
Electric power: 8,000 kw. capacity (1971); 0.3 million kw.-hr. produced (1971),
.5 kw.-hr. per capita
Exports: $18.3 million (f.0.b., 1969); cattle, animal products, minerals
Imports: $43.2 million (f.0.b., 1969); foodstuffs, vehicles, textiles
Major trade partner: South Africa
Approved For Release 2004/09/15 : GIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Monetary conversion rate: 1 SA Rand=US$1.25 (Botswana uses the South African
Rand which is linked to the floating U.K. pound; the Rand exchange rate
fluctuated in the range of $1.24-$1.26 during July-September 1972) (official);
0.80 SA Rand=US$1
Fiscal year: 1 April - 317 March','5965d854c1015a4d030b2f4522c70756785031e64892266d58c1e51b64d90ce3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('881a47062c0ecedadef607d9a3667a9274af9932d4888ef94cb1a691777393c3',1973,'BG','Bulgaria','economy',29,'GNP: $12.7 billion, 1971 (at 1970 prices), $1,480 per capita; 1971 growth rate
7.3% (current)
Agriculture: mainly self-sufficient; main crops--grain, vegetables; no food
shortages; caloric intake, 3,000 calories per day per capita (1969/70)
Fishing: catch 97,000 metric tons (1971)
Major industries: agricultural processing, machinery, textiles and clothing,
mining, ore processing, timber
Approved For Release 2004/09/15 : @GKA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Shortages: some raw materials, metal products
Crude steel: 2 million metric tons produced (1971), 230 kg. per capita
Exports: $2,180 million (f.0.b., 1971}; in 1970, 29% machinery, equipment, and
transportation equipment; 13% fuels, minerals, raw materials, metals, and
other industrial material; 8% agricultural raw materials; 35% foodstuffs
and animals; 15% industrial consumer goods
Imports: $2,169 million (f.0.b., 1971); in 1970, 41% machinery, equipment, and
transportation equipment; 38% fuels, minerals, raw materials, metals, other
materials; 10% agricultural raw materials; 6% foodstuffs and animals; 5%
industrial consumer goods
Major trade partners: $4,349 million in 1971; 21% with non-Conmunist countries;
79% with Communist countries
Monetary conversion rate: (commercial) 1.08 leva, (noncommercial) 1.85 Teva=US$1
Fiscal year: calendar year; economic data reported for calendar years except for
caloric intake, which is reported for consumption year 1 July - 30 June
GDP: $2.2 billion (FY71), approx. $80 per capita; real growth rate 6% (FY70)
Agriculture: main crops -- paddy, sugarcane, peanuts; almost 100% self-sufficient;
most rice grown in deltaic land
Fishing: catch 432,400 metric tons, $87.5 million (1970)
Major industries: agricultural processing; textiles and footwear, wood and
wood products; petroleum refining
Electric power: 313,400 kw. capacity (1972); 660 million kw.-hr. produced (1972),
23 kw.-hr. per capita
Exports: $118 million (f.o.b., 1971); rice, teak
Imports: $150 million (c.i.f., 1971 est.) machinery and transportation equipment,
textiles, other manufactured goods
Approved For Release 2004/09/15 : GM-RDP79-01051A000500010001-1
ECONOMY (cont! ARProved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Major trade partners: exports -- India, Western Europe, U.K., Japan; imports --
Japan, Western Europe, India, U.K.
Monetary conversion rate: 5.35 kyat=US$1
Fiscal year: J] October - 30 September
GNP: about $204.7 million (1971 est.), $60 per capita; estimated real GDP
growth 1%
Agriculture: major cash crops -- coffee, cotton; main food crops -- manioc,
yams, corn, sorghums, bananas, haricot beans; not self-sufficient
Industries: light consumer goods such as beverages, shoes, soap
Electric power: 13,100 kw. capacity (1971); 26 million kw.-hr. produced (1971),
7 kw.-hr. per capita
Exports: $20.7 million (f.0.b., 1970); coffee, cotton, hides, skins
Imports: $25.6 million (c.i.f., 1970); textiles, foodstuffs, transport equipment,
petroleum products
Major trade partners: U.S., Belgium, Congo; much trade unrecorded
Aid: $17.7 million (1970) includes Belgium $7.4 million, U.N. $3.1 million, EDF
$2.9 million; France $2.0 million (1970); U.S. $7.9 million FY62-71
Monetary conversion rate: 87.5 Burundi francs=US$1 (official)
Fiscal year: calendar year
Approved For Release 2004/09/15 : @4A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A00 -
COMMUNICATIONS: poogacelrs
Railroads: none
Highways: 3,700 mi.; 45 mi. bituminous, 3,655 mi. crushed stone, gravel, laterite,
and improved or unimproved earth
Inland waterways: Lake Tanganyika navigable for lake steamers and barges
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 32 total, 22 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft.
Telecommunications: telegraph is principal service, limited telephones; 5,400
telephones, 65,000 radio receivers; 2 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 873,000; 420,000 fit for military service; 42,000
reach military age (16) annually
Military budget: for fiscal year ending December 1971, $1,100,000; about 4.5% of
ordinary budget
Approved For Release 2004969/15 : CIA-RDP79-01051A000500010001-1
Approved For Release SS ee ee ee
LAND:
70,000 sq. mi.; 16% cultivated, 74% forested, 10% built-on
area, wasteland, and other
Land boundaries: 1,515 mi.
Ri
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: about 275 mi.
GNP: $634 million (1969), $90 per capita (constant 1966 prices, converted at
55.5 riels=US$1); 1960-69 average growth rate 3.6% (constant 1966 prices)
Agriculture: Mainly subsistence except for rubber plantations; main crops --
rice, rubber, corn; largely self-sufficient prior to the war; food shortages
-- rice, dairy products, sugar, flour
Major industries: rice milling, fishing, wood and wood products, textiles
‘ Shortages: fossil fuels
Electric power: 104,000 kw. capacity (1972); 180 million kw.-hr. produced (1972),
25 kw.-hr. per capita
Exports: $12.7 million (f.o.b., 1971); rice, corn, kapok
Imports: $75.2 million (f.0.b., 1971); machinery and equipment, chemical products,
* metals and metal products, petroleum products, foods, transport equipment
Major trade partners: (1971) exports -- Senegal, Singapore, Hong Kong; 8% with
Communist countries; imports -- Singapore, Australia, France; 3% with
Communist countries
Approved For Release 2004/09/15 : SIA-RDP79-01051A000500010001-1
ECONOMY (cont ‘Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Monetary conversion rate: adjustable; average about 150 riels=US$1 (effective
31 March 1972)
Fiscal year: calendar year
GDP: $1,196 million (1971 est.), per capita about $190; real growth rate about 7%
per annum
Agriculture: commercial and food crops -- cocoa, coffee, timber, cotton, rubber,
bananas, peanuts, palm cil and palm kernels; root starches, livestock, millet,
sorghum, and rice
Fishing: catch about 70,800 metric tons (1970)
» value not availab’e; exports $1.1
million (1970), imports $2.1 million (1970)
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (eoneiaerre ee For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Major industries: small aluminum plant; food processing and light consumer goods
industries, sawmills
Electric power: 262,400 kw. capacity (1971); 1.2 billion kw.-hr. produced
(1971), 206 kw.-hr. per capita
Exports: $224 million (f.o.b., 1971) cocoa and coffee about 55%; other exports
include timber, aluminum, cotton, natural rubber, bananas, peanuts, tobacco,
and tea
Imports: $271 million (c.i.f., 1977) consumer goods, machinery, transport equipment,
alumina for refining, petroleum products, food and beverages; about 2% from
Communist countries
Major trade partners: about 70% of total trade with France and other EC countries;
Tess than 10% of total trade with U.S.
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: 1 July - 30 June','688641ad978c6a4d6856c5b87eed3f3bc4d588f5d0616197641f80cca0f9441e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82c86aee3dcea8b305376741817fa3b043aad41c336e4ea8afcb892bbdce76bd',1973,'CF','Central African Republic','economy',33,'GDP: $213 million (est. 1971), about $140 per capita
Agriculture: commercial ~-- cotton, coffee, peariuts, sesame, wood; main food
crops -- manioc, corn, peanuts, rice, potatoes, beef; requires wheat, flour,
rice, beef, and sugar imports
Major aca sawmills, cotton textile mills, brewery, diamond mining and
splitting
Electric power: 16,850 kw. capacity (1971); 47 million kw.-hr. produced (1971),
29 kw.-hr. per capita
Exports: $33 million (f.o.b., 1970); diamonds (43%), coffee, cotton, ‘umber
Imports: $41 million (c.i.f., 1970); textiles, petroleum products, machinery
and electrica! equipment, motor vehicies and equipment, chemicals and
pharmaceuticals
Approved For Release 2004/09/15 : CHA-RDP79-01051A000500010001-1
: CIA-RDP79-01051A000500010001-1
ECONOMY (cane apProve? For Release 2004/09/15
Major trade partner: France; preferential tariff applied to EC countries and
franc zone; U.S.
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year
WHO, WMO
GDP: about $241 million (1967), about $70 per capita; estimated real annual growth
rate 2.5%
Agriculture: commercial -- cotton, gum arabic, livestock, fish; food crops --
peanuts, millet, sorghum, rice, dates, manioc, wheat; imports food
Fishing: catch 120,000 metric tons (1970) $13 million; exports $300,000 (1969)
Major industries: agricultural and livestock processing plants (cotton textile
mil], slaughterhouses, brewery), natron
Approved For Release 2004/09/15 : CAA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Electric power: 16,660 kw. capacity (1971); 54 million kw.-hr. produced (1971),
14 kw.-hr. per capita
Exports: $28.0 million (f.o.b., 1971); cotton 67.5%
Imports: $62.0 million (c.i.f., 1970); cement, petroleum, foodstuffs , machinery ,
textiles, and motor vehicles; $1.3 million from Communist countries (1967)
Major trade partners: France (about 40% in 1969) and UDEAC countries; preferential
tariffs to EC and franc zone countries
Aid: major source France, $469 million, 1961-69, EDF $393 million (1965-70);
U.S. (FY62-71) $9.6 million; U.S.S.R. $2.2 million (1968); military aid
(1954-68) -- $5.4 million, from France $4.1 million, remainder from West
Germany and Israel, more than $10 million annually {est.) in French military
aid (1969-71)
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year','80afc33964028bfd10e955b0b89c57a04f73e518c84246801fb9a229a4abb826','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dffb128d8b4a6ea2ef56b090281bfca49b7a9d3c31d26514d2958e24f35db5f0',1973,'AU','Australia','economy',37,'GNP: about $130 billion (1971), $150 per capita
Agriculture: main crops -- rice, wheat, miscellaneous grains, cotton; caloric
intake, 2,000 calories per day per capita (1971); agriculture mainly
subsistence; grain imports 4-5 million tons annually (1961-70) and 3.2 million
tons in 197]
Major industries: iron and steel, coal, machine building, armaments, textiles
Shortages: complex machinery and equipment, highly skilled scientists and
technicians
Crude steel: 21 million tons produced (1971), 20 kilograms per capita (1971)
Exports: $2.4 billion (f.0.b., 1971), agricultural products, minerals and metals,
manufactured goods
Imports: $2.2 billion (c.i.f., 1971), grain, chemical fertilizer, industrial
raw materials, machinery and equipment
Major trade partners: Japan, Hong Kong, West Germany, U.K., Singapore, Malaysia,
Canada (1971)
Monetary conversion rate: 2.27 yuan=US$1 (arbitrarily established)
Fiscal year: calendar year
GNP: $6.2 billion (1971), $420 per capita; real growth, 11%
Agriculture: most arable land intensely farmed -- 60% cultivated land under
irrigation; main crops -- rice, sweet potatoes, sugarcane, bananas,
pineapples, citrus fruits; 90% self-sufficient; food shortages -- wheat
Fishing: catch 613,000 tons, $179 million (1970)
Major industries: textiles, clothing, chemicals, plywood, electronics, sugar
milling, food processing, cement
Electric power: 3,587,000 kw. capacity (1972); 17.3 billion kw.-hr. produced
(1972); 1,138 kw.-hr. per capita
Exports: $2,136 million (f.0.b., 1971); textiles 18%, clothing and footwear 15%,
T.V. and radios 8%, other machinery and equipment 10%, metals and manufactures
14%, canned foods 7%, lumber and plywood 6%, sugar 4%, seafood 4%
Imports: $1,950 million (c.i.f., 1971) machinery and equipment 33%, basic metals
10%, grains and soybeans 8%
Major trade partners: exports -- 37% U.S., 15% Japan; imports -- 38% Japan,
30% U.S.
Aid:
economic -- U.S. (FY53-71) $1.4 billion committed; IBRD (1964-71) $313
million committed; Japan (1965-70) $137 million committed; ADB (1968-71)
$100 million committed;
military -- U.S. (FY49-71) $3.0 billion committed
Monetary conversion rate: NT$40 (New Taiwan)=US$1
Fiscal year: 1 July - 30 June
GNP: $10.4 billion (purchasing power parity est., 1970), $480 per capita; 72%
private consumption, 7% public consumption, 21% gross investment (1969);
real growth rate 1971, 5.5% (est.)
Agriculture: main crops -- coffee, rice, corn, Sugarcane, plantains, bananas,
(hogs) potatoes, yucca; caloric intake, 2,220 calories per day per capita
9
Fishing: catch 70,600 metric tons 1969; exports $2.9 million (1969), imports $1.0
million (1969), $0.56 million (1970)
Major industries: textiles, food processing, clothing and footwear, beverages,
chemicals, and metal products
Crude steel: 0.4 million metric tons capacity (1965); 0.26 million metric tons
production (1969), 10 kilograms per capita
Electric power: 2.4 million kw. capacity (1971); 9.208 billion kw.-hr. produced
(1971), 450 kw.-hr. per capita
Exports: $727 million (f.0.b., 1970); coffee, petroleum, bananas, tobacco,
cotton, sugar, textiles, cattle and hides, wood and wood products
Imports: $755 million (c.i.f., 1970); industrial metals and raw materials, chemicals
and pharmaceuticals, transportation equipment, machinery, fuels, fertilizers,
paper and paper products, foodstuffs and beverages, rubber and rubber products
Major trade partners: U.S. 44%, West Germany 11%, other EC 9%, EFTA 9% Latin
America 6%, Communist countries 4% (1968)
Monetary conversion rate: 22.2 pesos=US$1 (August 1972, changes frequently),
selling rate
Fiscal year: calendar year
Agriculture: food crops -- rice, manioc, potatoes, fruits, vegetables; export
crops -- essential oils for perfumes (mainly ylang-ylang), vanilla, copra,
sisal
Exports: $3.8 million (1967) perfume oils, vanilla, copra, sisal
Imports: $7.5 million (1967) foodstuffs, cement, fuels, chemicals, textiles
Major trade partners: France, Malagasy Republic, Italy, Kenya, Tanzania and U.S.
Electric power: est. 1,000 kw. capacity (1971); est. 2 million kw.-hr. produced
(1971); 7 kw.-hr. per capita
Aid: French aid in 1971 was about $2.7 million, or about 50% of the island''s
entire budget
Monetary conversion rate: 255.85 Communaute Financiere Africdine (CFA) francs=US$1
GNP: $193 million, $1,800 per capita (1971 est.)
Agriculture: large areas devoted to cattle grazing; major products -- coffee and
vegetables; 60% self sufficient in beef; must import grains and vegetables
Industry: mining of nickel
Electric power: 105,000 kw. capacity (1972); 780 million kw.-hr. produced (1972),
7,090 kw.-hr. per capita
Exports: $212 million (f.o.b., 1971) 98% nickel
Imports: $248 million (c.i.f., 1971) machinery, transport equipment, food
243
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''dpproved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Major trade partners: (1971) exports -- France (42%), Japan (47%), U.S. (9%);
imports -- France (48%), Australia (14%)
Monetary conversion rate: 95 CFP francs=US$]
GNP: $933 million (purchasing power parity estimate, 1970), $470 per capita; 73%
private consumption, 10% government consumption, 19% domestic investment, -2%
net foreign balance; real growth rate 1970, 4.5%
Approved For Release 2004/09/15 : E1A-RDP79-01051A000500010001-1
5 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont ''¢}PProved For Release 2004/09/1
Agriculture: main crops -- cotton, coffee, sugarcane, rice, corn, beans, cattle;
caloric intake, 2,300 calories per day per capita (1966)
Fishing: catch 7,200 metric tons (1970)
Major industries: food processing, textiles and clothing, chemicals, petroleum
products
Electric power: 175,000 kw. capacity (1972 est.); 560 million kw.-hr. produced
(1972 est.), 260 kw.-hr. per capita
Exports: $179 million (1970); cotton, coffee, cottonseed, meat, sugar
Imports: $199 million (1970); machinery, equipment, vehicles, manufactures,
Chemicals, foods, fuels
Major trade partners: exports -- U.S. 33%, Japan 19%, CACM 21%; imports -- U.S.
Fi 38%, CACM 24%, West Germany 7% (1969)
id:
economic -- extensions from U.S. (FY46-70), $105.8 million loans, $61.4
million grants; international organizations (1946-70), $124.2 million;
military -- from U.S. (FY53-70), $12.8 million (1946-70)
Monetary conversion rate: 7 cordobas=US$1 (official)
Fiscal year: calendar year
GNP: less than $100 per capita
Agriculture: principal crops -- corn, rice, rubber, coffee, copra
Electric power: 2,000 kw. capacity (1972); 8.7 million kw.-hr. produced (1972),
14 kw.-hr. per capita
Exports: $3.3 million (f.o.b., 1970); 89% coffee, 6% copra
Imports: $7.2 million (c.i.f., 1970); textiles, beer and wine, petroleum
Major trade partners: Portugal and its possessions, Far Eastern countries
Approved For Release 2004/09/1877CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Monetary conversion rate: Portuguese escudo known in Timor as pataca; 28.75
patacas=US$1
Fiscal year: calendar year
GNP: $4.6 billion (FY70), $1,650 per capita
Agriculture: main crops -- sugar, coffee, tobacco, bananas
Fishing: catch 46,000 metric tons, $17.4 million (1970)
Major industries: textiles, clothing manufacture, food processing, petroleum
refining, petro-chemicals
Electric power: 1.3 million kw. capacity (1971); 9.156 billion kw.-hr. produced
(1971), 3,365 kw.-hr. per capita
Exports: $1,680 million (f.o.b., 1970); sugar, pineapple, citrus fruits, coffee,
rum, textiles
Imports: $2,680 million (f.o.b., 1970); food, machinery, transportation equip-
ment, fuels, minerals
Major trade partner: exports -- U.S. 93%; imports -- U.S. 77%
Approved For Release 2004/09/15 2/31a-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-0 -
econ (cont "ayeP 1051A000500010001-1
Monetary conversion rate: uses U.S. currency
Fiscal year: 1 July - 30 June
GNP: $36 million (1970), $240 per capita
Agriculture: cocoa, bananas, copra; staple foods include coconut, bananas, taro,
and yams
Electric power: 6,800 kw. capacity (1972); 17 million kw.-hr. produced (1972),
114 kw.-hr. per capita
Exports: $6.3 million (1971); copra, cocoa, bananas
cd Imports: $12.8 million (1971); machinery and equipment, manufactured goods, food
; Major trade partners: exports -- New Zealand, West Germany, the Netherlands; imports
-- New Zealand, Australia, US .
Aid: New Zealand, $2.5 million committed; U.S., $2 million extended (FY67-70)
Monetary conversion rate: WS$1=US$1.48
Major industries: timber, tourism
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS -APProved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Railroads: none
Highways: 477 mi.; 80 mi. bituminous, remainder mostly gravel, crushed stone,
or earth
Inland waterways: none
Ports: 1 principal (Apia), 1 minor
Civil air: 4 major transport aircraft (includes 1 leased)
Airfields: 4 total, all usable; 1 with runway 4,000-7,999 ft.; 1 seaplane
station
Telecommunications: 1,960 telephones; 32,000 radio receivers; 1 AM station
Approved For Release 2064/09/15 : CIA-RDP79-01051A000500010001-1
Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Re VEMEN. CASEN)*
LAND:
112,000 sq. mi. (border with Saudi Arabia undefined); only
about 1% arable (of which less than 25% cul tivated)
Land boundaries: 1,060 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 860 mi.
GNP: $100 per capita
Agriculture (a11 outside Aden): cotton is main cash crop; cereals, dates, kat
(qat), coffee, and livestock are raised and there is a growing fishing
industry; large amount of food must be imported (particularly for Aden);
cotton, hides, skins, dried and salted fish are exported
Major industries: petroleum refinery (production 150,000 bbls. per day) mid 1971;
capacity 178,000 bbls. per day at Little Aden operates on imported crude; oi]
exploration activity
Exports: $13 million (f.o.b., 1971)
Imports: $169 million (c.i.f., 1971)
Electric power: 108,000 kw. capacity (1971); 378 million kw.-hr. produced (1971),
290 kw.-hr. per capita
Major trade partners: Yemen, East Africa, but some cement and sugar imported from
Communist countries; crude oi] imported from Persian Gulf, exported mainly
to U.K. and Japan
Monetary conversion rate: 1 S. Yemeni dinar=US$2.61
Fiscal year: 1 April - 31 March
Agriculture: sorghum and millet, gat (a mild narcotic), cotton, coffee, fruits
and vegetables; largely self-sufficient in food
Major industries: cotton textiles and leather goods produced on a small scale;
handicraft and some fishing; small aluminum products factory
Electric power: 4,000 kw. capactiy (1971); 14 million kw.-hr. produced (1971),
2 kw.-hr. per capita
Exports: about $6 million (1970), qat, cotton, coffee, hides, vegetables
Imports: about $88 million (1970), textiles and other manufactured consumer goods,
petroleum products, sugar, grain, flour, other foodstuffs, and cement
Major trade partners: trade with Aden 25% of total, others include U.S.S.R.,
Japan, Saudi Arabia, Australia, France
Aid:
economic -- $340 million credits extended through August 1972, $170 million
drawn through 1970; major donors include U.S.S.R., China, U.S., West
Germany, Saudi Arabia;
military -- $77 million from U.S.S.R.; $36 million from Eastern Europe;
$7 million through 1971, western military aid
Monetary conversion rate: 1 Yemeni rial=US$0.20 as of March 1972
Fiscal year: 1 July - 30 June
375
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS : Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Railroads: none
Highways: 2,160 mi.; 290 mi. bituminous; 270 mi. crushed stone and gravel;
1,600 mi. earth, sand, and light gravel
Ports: 3 major, 2 minor
Civil air: 9 major transport aircraft
Airfields: 35 total, 25 usable; 5 with permanent-surface runways; 1 with
runway over 12,000 ft., 6 with runways 8,000-11,999 ft., lé2 with runways
4,000-7 ,999 ft.
Telecommunications: systems among mideast''s worst; consists of meager open-wire
lines and low-power radio communication stations; principal center Sana,
secondary centers Al Hudaydah and Taizz; 3,550 telephones; 25,000 radio
receivers (approx.); 1 AM radio-broadcast station
DEFENSE FORCES:
Military manpower: males 15-49, 1,488,000; 790,000 fit for military service;
about 65,000 reach military age (18) annually; univeral military conscription
law (10 January 1963) makes military service obligatory for all Yemeni
males 18-30
Approved For Release 2004/69/15 : CIA-RDP79-01051A000500010001-1
WATER:
GNP: $21.2 billion (est.) in 1971 (at 1970 prices), $1,020 per capita; 1971 growth
rate approx. 9%
Agriculture: diversified agriculture with many small private holdings and large
agricultural combines; main crops -- corn, wheat, tobacco, sugar beets, and
sunflowers; generally a net exporter of foodstuffs and live animals; self-
sufficient in food except for tropical products, cotton, wool, and vegetable
meal feeds; caloric intake, 3,210 calories per day per capita (1967)
Major industries: metallurgy, machinery and equipment, textiles, wood
processing, food processing
Shortages: fuels, steel, textile fibers, chemicals
Crude steel: 2.7 million metric tons produced (1971), 130 kg. per capica
Exports: $1,816 million (f.o.b., 1971) 18% foodstuffs and tobacco; 17% raw
materials, fuels, and chemicals; 24% machinery and equipment; 41% other
manufactures
Imports: $3,253 million (c.i.f., 1971); 9% foodstuffs and tobacco; 26% raw
materials, fuels, chemicals; 31% machinery and equipment; 34% other
manufactures
Major trade partners: $5,069 million (1971); 71% non-Communist countries (35%
EC, 6% U.S., 30% other non-Communist countries), 29% Communist countries
Aid: postwar credits extended mainly by the U.S. (about $3 billion, including grants
and $700 million in military aid); Western Europe (over $950 million); IBRD
($585 million); IMF {over $400 million); Communist countries extended credits
totaling $464 million in 1956 ($125 million drawing balance suspended in 1958)
and $576 million during 1962-70 and $130 million in 1971; Yugoslavia has
extended credits totaling about $600 million to 27 less developed countries
of Africa, Asia, and Latin America
Monetary conversion rate: 16.65 ND=US$1
Fiscal year: same as calendar year (all data refer to calendar year or to middie
or end of calendar year as indicated)
GDP: $2.1 billion (1971), about $90 per capita; real growth rate
6.5% p.a. 1968-71
Agriculture: main cash crops -- coffee, palm oil, rubber; main food crops --
manioc, bananas, root crops, corn; some provinces self-sufficient
Fishing: catch 122,000 metric tons (1970); imports $15.4 million (1969)
Major industries: mining, mineral processing, light industries
aj Electric power: 751,380 kw. capacity (1971); 3.23 billion kw.-hr. produced
(1971), 143 kw.-hr. per capita
Exports: $669 million (f.o.b., 1971); copper, cobalt, diamonds, other minerals,
ca coffee, palm oi] —
} Imports: $698 million (c.i.f., 1971); consumer goods, foodstuffs, mining
a and other machinery, transport equipment, fuels
Major trade partners: Belgium, U.S., and West Germany
Approved For Release 2004/09/15 : etA-RDP79-01051A4000500010001-1
ECONOMY (conesayeereye? For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Aid: economic -- U.S. (FY61-70) $449 million; (1970 estimated disbursements)
Belgium, $27.4 million; France, $6.9 million; other bilateral aid $3 million;
U.N., $7.1 million; EC, $14.1 million military -- U.S., $39.2 million (FY62-71)
Monetary conversion rate: 1 zaire=US$2
Fiscal year: calendar year','4807baac4b2c5536f1e78dd03043aa63d27ff56fe6ddf00a64e76363e66c47a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('645f688a5c1e1aa4c39b09acfb3dff7625a924a5297119c4f1c9257d1b7e39a6',1973,'CG','Congo','economy',42,'GDP: about $228 million (1967 est.), about $260 per capita, real growth rate
about 4% per year
Agriculture: cash crops -- sugarcane, wood, coffee, cocoa, palm kernels, peanuts,
tobacco; food crops -- root crops, rice, corn, bananas, manioc, fish
Fishing: catch 12,200 metric tons (1970); imports $3.3 million (1969)
Major industries: sawmills, brewery, cigarettes, sugar mill, soap
Approved For Release 2004/09/15 : GiA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONGMY (cont''d):
Electric power: 43,600 kw. capacity (1971); 71 million kw.-hr. produced (1971),
73 kw.-hr. per capita
Exports: $60 million (f.0.b., 1968); lumber, sugar, tobacco, veneer, and plywood;
diamonds smuggled from Zaire
Imports: $86 million (c.i.f., 1968); machinery, transport equipment, manufactured
consumer goods, iron and steel, foodstuffs, petroleum products
Major trade partners: France and other EC countries on preferential basis
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year','4d9f8880f9f85d75e495bccaf09830063b9e89886f53e40ae32d62097c707fb0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ba4f05dee40bca1f9a563d87f27e263336f14abb6ed1bc75e6218f927ef21c8',1973,'CR','Costa Rica','economy',46,'GNP: $982 million (purchasing power parity estimate, 1971), $550 per capita;
14% government consumption, 67% private consumption, 23% domestic investment,
ic enemy -10% net foreign balance (1970); real growth rate 1971, 5.5%
est.
Agriculture: main products -- bananas, coffee, sugarcane, rice, corn, cocoa,
livestock products; caloric intake, 2,610 calories per day per capita (1966)
Fishing: catch 8,100 metric tons, $2.2 million (1970); exports, $1.8 million
(1970), imports $0.5 million (1970)
Approved For Release 2004/09/15 : GA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Major industries: food processing, textiles and clothing, construction
materials, fertilizer
Electric power: 220,000 kw. capacity (1971); 1,014 million kw.-hr. produced
(1971), 540 kw.-hr. per capita
Exports: $231.1 million (f.o.b., 1971); coffee, bananas, sugar, beef, fertilizers,
cacao
Imports: $347.9 million (c.i.f., 1971 est.); manufactured products, machinery,
transportation equipment, chemicals, fuels, foodstuffs
Major trade partners: exports -- 41% U.S., 20% CACM, 8% West Germany, 5%
Netherlands; imports -- 35% U.S., 22% CACM, 8% West Germany, 9% Japan (1970)
Aid:
economic -- extensions from U.S. (FY46-71), $121.4 million loans, $95.2
million grants; from international organizations (FY46-71), $147.8 million;
from other Western countries (1960-68), $1.8 million;
military -- assistance from U.S. (FY60-71) $1.9 million
Monetary conversion rate: 6.62 colones=US$1 (official buying rate); 6.65
colones=US$1 (official selling rate)
Fiscal year: calendar year','2f1dd4c1c6eb8afeb9275356f83506bd313383f5379ae39201a5e516ae23f29d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('875406aeeddd6f1e897215e2e090f10873f96cd28c660bc62ced0edf97fefd8d',1973,'CU','Cuba','economy',50,'GDP: $4.8 billion (est. 1971 at 1971 prices), $560 per capita; 60% private
consumption, 20% public consumption, 20% gross investment; real growth
rate 1971, -5%
Agriculture: main crops -- sugar, tobacco, coffee, rice, potatoes, tubers,
citrus fruits
Fishing: catch 125,900 metric tons (1971); exports $21.7 million (1971), imports
$11.9 million (1971)
Major industries: sugar milling, petroleum refining, food and tobacco processing,
textiles, chemicals, paper and wood products, metals
Shortages: spare parts for transportation and industrial machinery, consumer goods
Crude steel: 0.35 million metric tons capacity (planned 1969); 165,000 metric
tons produced (1970); 20 kg. per capita
Electric power: 1.35 million kw. capacity (1971); 5.1 billion kw.-hr. produced
(1971), 600 kw.-hr. per capita
Exports: $815 million (f.o.b., 1971 est.); sugar, nickel, tobacco
Imports: $1,255 million (c.i.f., 1971 est.); capital goods, industrial raw
materials, food, petroleum
Approved For Release 2004/09/15 : GAA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Major trade partners: exports -- U.S.S.R. 35%, China 8%, other Communist
countries 21%, Japan 10%, Spain 3%; imports -- U.S.S.R. 53%,
China 5%, other Communist countries 12%, U.K. 5%, Japan 5% (1971 est.)
Monetary conversion rate: 1 peso=US$1.09 (nominal)
Fiscal year: calendar year','38f440613ccaf4a6a7c46c9e86fec5310cdf84e206dfb5859c3a57cb52031280','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df45cbf224c36fd08597e0da6b33ab573142d8a3a144f4752633d90d16850eb4',1973,'CY','Cyprus','economy',53,'GNP: $540 million (1970), $850 per capita; 1970 growth 3%, 1958 constant prices
Agriculture: main crops -- vine products, citrus, potatoes, other vegetables;
food shortages -- grain, dairy products, meat, fish; caloric intake, 2,590
calories per day per capita (1961)
Major industries: mining (cupreous and iron pyrites, asbestos), manufactures
principally for local consumption -- food, beverages, footwear
Shortages: water, petroleum
Electric power: 179,000 kw. capacity (1971); 618.2 million kw.-hr. produced (1971),
958 kw.-hr. per capita
Exports: $114 million (f.0.b., 1971); principal items -- copper, pyrites, citrus,
raisins, and other agricultural products
Imports: $260 million (c.i.f., 1971); principal items -- manufactured goods,
machinery and transport equipment, petroleum products, foods
Major trade partners: (1970) U.K. 32%, West Germany 11%, Italy 9%, EC 28.1%,
Communist countries 7.7%
Aid: economic -- U.S., $22.2 million authorized (1961-70), none authorized in
1970; IBRD, $34.2 million (1963-70); U.N. Technical Assistance, $1.5 million
(1953-70); U.N. Special Fund, $8 million (1953-70)
Monetary conversion rate: 1 Cyprus pound=US$2.61 (as of March 1972)
Fiscal year: calendar year
COMMUNICATIONS: F
Railroads: none
Highways: 5,000 mi.; 2,100 mi. bituminous surface treated; 2,900 mi. gravel,
crushed stone, and earth
Ports: 3 major, 6 minor
Merchant marine: 410 ships (1,000 GRT or over) totaling 2,289,100 GRT, 3,282,200 4
DWT; includes 9 passenger, 328 cargo, 23 tanker, 47 bulk, 3 specialized ;
carriers; all but a few are owned and operated by Greek nationals
Civil air: 7 major transport aircraft
Airfields: 20 total, 13 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft.; 3 with runways 4,000-7,999 ft.
Telecommunications: modest but expanding telecommunication system; 44,000
telephones; 174,000 radio receivers; 62,500 TV receivers; 2 TV, 12 AM, and
4 FM stations; tropospheric scatter circuit to Greece
DEFENSE FORCES:
Military manpower: males 15-49, 156,000; 110,000 fit for military service,
about 7,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1971, $7.5 million about
9.7% of central government budget
Approved For Release 20049/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
CZECHOSLOVAKIA
LAND:
49,400 sq. mi.; 42% arable, 14% other agricultural, 35%
forested, 9% other
Land boundaries: 2,205 mi.
GNP: $34.0 pee in 1971 (at 1970 prices), $2,340 per capita; 1971 real growth
rate 4.1%
Agriculture: diversified agriculture; main crops -- wheat, rye, potatoes, sugar
beets; net food importer -- meat, wheat, vegetable oils, fresh fruits and
vegetables; caloric intake, 3, 100 calories per day per capita (1967)
Major industries: machinery, food processing, metallurgy, textiles, chemicals
Shortages: ores, crude oi], grain
Crude steel: 12 million metric tons produced (1971), 830 kg. per capita
Approved For Release 2004/09/15 : ({a-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Exports: $4,174 million (f.o.b., 1971); 50% machinery, equipment; 29% fuels,
raw materials; 4% foods, food products, and live animals; 17% consumer goods,
excluding foods (1970)
Imports: $3,810 million (f.o.b., 1971); 33% machinery, equipment; 44% fuels, raw
materials; 15% foods, food products, and live animals; 8% consumer goods,
excluding foods (1970)
Major trade partners: $7,984 million (1971); 69% Communist countries, 31% other
Monetary conversion rate: commercial 6.63 crowns=US$1, noncommercial 13.05
crowns=US$1, tourist rate 15.0 crowns=US$1
Fiscal year: calendar year
a fe Le (1971 est.) $80 per capita; real growth rate, 6.5% per annum
1967-71
Agriculture: major cash crop is 011 palms; peanuts, cotton, coffee, sheanuts,
tobacco also produced commercially; main food crops -- corn, cassava, yams,
sorghum and millet; livestock, fish
Fishing: catch 33,000 tons (1971); exports none, imports 4,000 metric tons
Major industries: palm oil and palm kernel oil processing
Electric power: 9,330 kw. capacity (1971); 50 million kw.-hr. produced (1971),
18 kw.-hr. per capita
Exports: about $42 million (f.o.b., 1971); palm products (34%); other
agricultural products
Imports: about $76 million (f.o.b., 1971); clothing and other consumer goods,
cement, lumber, fuels, foodstuffs, machinery, and transport equipment
Approved For Release 2004/09/15 : GiA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Major trade partners: France, EC, franc zone; preferential tariffs to EC and
franc zone countries
Aid:
economic (1970) -- France, $8 million; EC, $4.2 million; U.N., $2 million;
West Germany, $1 million; Taiwan, $1 million; U.S., (FY60-70) $12.8 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; 255.785 CFA francs=US$1
Fiscal year: calendar year','199c22691076e76ca1887b673a3a4a320f4052542fd16eb11420d6c82ff11777','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37f2e9da2af3d8bd84091d16a7a46a9b15ec1d9ad220ce96d517806460a19565',1973,'DZ','Algeria','economy',60,'GNP: $18.4 billion (1971), $3,700 per capita; 61% private consumption, 21%
investment, 20% government, -1.6% net foreign balance; 1971 growth 3.6%,
constant prices
Agriculture: highly intensive, specializes in dairying and animal husbandry;
main crops -- cereals, root crops; food shortages -- oilseeds, grain,
feedstuffs; caloric intake, 3,180 calories per day per capita (1968-69)
Approved For Release 2004/09/15 g CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Fishing: catch 1,379,235 metric tons (1971), $128 million; exports $144.3 million,
imports $33.7 million
Major industries: food processing, machinery and equipment, textiles and clothing,
chemical products, electronics, transport equipment, metal products, brick
and mortar, furniture and other wood products
Shortages: most industrial raw materials and fuels
Crude steel: 470,000 metric tons produced (1971), 90 kg. per capita
Electric power: 4,780,000 kw. capacity (1971); 17.186 billion kw.-hr. produced
(1971), 3,453 kw.-hr. per capita
Exports: $3,833 million (f.0.b., 1971); principal items -- meat, dairy products,
industrial machinery and equipment, textiles and clothing, chemical products,
transport equipment, fish, furs, and furniture
Imports: $4,865 million (c.i.f., 1971); principal items -- industrial machinery,
transport equipment, petroleum, textile fibers and yarns, iron and steel
products, chemicals, grain and feedstuffs, wood and paper
Major trade partners: U.K. 16%, West Germany 16%, Sweden 16%, U.S. 8%, Norway 6%;
EC 28%; EFTA 46%; Communist countries 4%
Aid:
economic -- (received) U.S., $301.8 million authorized 1946-72, none since
1958; IBRD -- $85.0 million through June 1970, none since 1964; net official
economic aid given to less developed areas and multilateral agencies,
$250.5 million (1960-70), $58.3 million (1969), $63.2 million (1970) $80
million (1971 provisional )
Monetary conversion rate: 6.98 Kroner=US$1 (central rate)
Fiscal year: 1 April - 31 March
GDP: $15.8 million (1968 est.), $230 per capita; economy is virtually stagnant
in real terms
Agricultural products: bananas, citrus, coconuts, cocoa
Major industries: agricultural processing, tourism
Electric power: 5,420 kw. capacity (1971). 15 million kw.-hr. produced
(1971 est.), 220 kw.-hr. per capita
Exports: $6.2 million (f.0.b., 1970); bananas, lime juice and oil, cocoa and
reexports
Imports: $15.9 million (c.i.f., 1970); foodstuffs, manufactured articles
Major trade partners: U.K. 53%, Commonwealth Caribbean countries 15%, Canada
10%, U.S. 7% (1963)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1
GNP: $34.0 billion; $1,010 per capita (1971); 68.5% consumption, 24.3% investment,
10.4% government; -3.2% net export of goods and services (1969); 1971 (est.)
real growth rate 5.5%, in 1964 constant prices
Agriculture: main crops -- cereals, oranges, grapes for wine, potatoes, olives,
sugar beets; virtually self-sufficient in good crop years; caloric intake,
2,680 (1968-69) calories per day per capita
Fishing: catch 1.2 million tons, $326.8 million (1969); exports $67.2 million
(1969 fish and fish products); imports $41.1 million (1969 fish and fish
products)
Major industries: food processing, textiles and apparel (including footwear),
metal manufacturing, chemicals, shipbuilding
Shortages: crude petroleum
Crude steel: 7.4 million metric tons produced, 220 kilograms per capita (1970
Electric power: 18.8 million kw. capacity (1971); 59.9 billion kw.-hr. produced
(1971), 1,734 kw.-hr. per capita
Exports: $3,050 million (f.o.b., 1971); principal items -- oranges and other
fruits, iron and steel products, textiles, wines, mercury, ships, canned
fruits, vegetables
Imports: $4,600 million (f.0.b., 1971); principal items -- machinery and
transportation equipment, petroleum and petroleum products, grains, cotton,
iron and steel
Major trade partners: (1971) 16.0% U.S., 12.0% West Germany, 10.4% France,
8.4% U.K., 6.0% Italy, 3.5% Netherlands; 34.0% EC; 15.8% EFTA; 8.7% Latin
‘ America; 1.5% Eastern European countries and U.S.S.R.
id:
economic -- U.S., $1,647.2 million authorized (FY49-70), $50.5 million
authorized (FY69), $64 million authorized (FY70); IBRD, $224 million
authorized (FY64-70), $37 million authorized (FY70);
military -- U.S., $771.4 million authorized (FY53-70), $130.9 million
authorized in FY70
Monetary conversion rate: 64.47 pesetas=US$1 (1971)
Fiscal year: calendar year
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01 -
COMMUNTEATIONS : 051A000500010001-1
Railroads: 10,667 mi.; 8,427 mi.; (5''6" gage), 2,240 mi. other gages
(4''8 1/2" to 1''11 5/8"), 1,318 mi., double track; 2,359 mi. electrified
Highways: 83,080 mi.; national -- 24,800 mi., bituminous, 22,940 mi. crushed
stone; provincial -- 32,860 mi., 80% crushed stone, 20% paved; 2,480 mi. other
Inland waterways: about 650 mi.; of minor importance as transport arteries and
* contribute little to economy
Pipelines: crude oil, 230 mi.; refined products, 515 mi.; natural gas, 3 mi.
Ports: 23 major, 20 minor
Civil air: 173 major transport aircraft
Airfields (including Balearic and Canary Islands): 120 total, 81 usable; 45
with permanent-surface runways; 4 with runways over 12,000 ft., 18 with
runways 8,000-11,999 ft., 36 with runways 4,000-7 ,999 ft.; 5 seaplane
stations
Telecommunications: modern, well engineered, well maintained; 5.38 million
telephones; 7.7 million radio and 4.75 million television receivers; 190
AM, 221 FM, and 645 TV stations with numerous FM/TV repeaters; 4 coaxial
submarine cables; 3 communication satellite ground stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,460,000; 6,500,000 fit for military service;
275,000 reach military age (20) annually
Military budget: for biennium ending 31 December 1971, $1,255 million; 23% of
central government budget
Approved For Release 2004/09/15 : CfA2RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000 2
SPANISH SAHARA A000500010001-1
, 103,000 sq. mi., nearly all desert
Land boundaries: 1,296 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 690 mi.
Agriculture: practically none; some barley is grown in nondrought years; fruit
and vegetables in the few oases; food imports are essential; camels, sheep ,
and goats are kept by the nomadic natives; cash economy exists largely for
the garrison forces
Major industries: confined to fishing and handicrafts; exploitation of huge
phosphate deposit is planned
Shortages: water
Electric power: 300 kw. capacity (1971); 0.2 million kw.-hr. produced (1971),
3 kw.-hr. per capita
Exports: $445,600 (1968); dried fish, goatskins
Imports: $1,443,000 (1968}; fuel for fishing fleet, foodstuffs
Major trade partners: monetary trade largely with Spain and Spanish possessions
can . ‘
Aid: small amounts frem Spain
Monetary conversion rate: 64.47 pesetas=US$1 (official)
COMMUNTCATICNS:
Railroads: none
; Highways: 3,790 mi.; 305 bituminous treated, 3,485 mi. unimproved earth roads
and tracks
Ports: 2 major, 2 minor
Approved For Release 2004/09/15 : CBRIRDP79-01051A000500010001-1
d For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS APPROVES
Civil air: no major transport aircraft
Airfields: 25 total, 17 usable; 3 with permanent-surface runways; 5 with
runways 4,900-7 ,999 f¢,
Telecommunications: telephone poor, telegraph poor to fair; 540 telephones;
1,500 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 15,000; 7,000-8,000 fit for military service
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release CRRA ak A Toh 9 0 105 14000500010001-1
LAND:
25,300 sq. mi.; 23% arable; 20% desert, waste, or urban; PEOPLE''S REPUBLIC
OF CHINA
54% forested; 3% inland water
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi. plus pearling in the Gulf of
Mannar)
Coastline: 835 mi.
ae billion (1971 current prices), $170 per capita; real growth rate 0.9%
1971
Agriculture: agriculture accounts for about 35% of GNP; main crops -- rice,
rubber, tea, coconuts; 60% self-sufficient in food; food shortages -- rice,
wheat, sugar, fish
Fishing: catch 190,000 metric tons, $64 million (1970); exports $0.6 million,
imports $11.7 million (1969)
Major industries: processing of rubber, tea, and other agricultural commodities;
consumer goods manufacture
Electric power: 323,000 kw. capacity (1972); 950 million kw.-hr. produced
(1972), 73 kw.-hr. per capita
Exports: $327.2 million (f.o.b., 1971); tea, rubber, coconut products
Imports: $333.6 million (c.i.f., 1971), machinery and equipment, sugar, flour,
rice, textiles, and clothing
Major trade partners: (1971) exports -- U.K. 19.8%, China 12.9%, U.S. 8.6%,
Australia 3.5%, Canada 1.9%, Japan 2.8%, U.S.5.R. 5.0%; imports -- U.K. 22%,
China 9.6%, India 7.9
Australia 3.4%, U.S. 5.3%, Japan 7.2%, USSR 3.2%
Monetary conversion rate: 5.95 rupees=US$1
Fiscal year: 1 October - 30 September
GDP: $1.6 billion (1969 provisional), under $100 per capita; 8% growth at
current prices 1968-69
Agriculture: main crops -- sorghum, millet, wheat, sesame, peanuts, beans,
barley; not self-sufficient in food production; main cash crops -- cotton,
gum arabic
Major industries: cotton ginning, textiles, brewery, cement, edible oils, soap,
distilling, shoes, pharmaceuticals
Electric power: 197,000 kw. capacity (1971); 453 million kw.-hr. produced (1971),
28 kw.-hr. per capita
Exports: $313 million (f.o.b., FY71); cotton (63%), gum arabic, peanuts,
sesame; $102 million exports to Communist countries (FY71)
Imports: $316 million (c.i.f., FY71); textiles, petroleum products, vehicles,
tea, wheat; $75 million imports from Communist countries (FY71)
Major trade partners: U.K., West Germany, Italy, India, U.S.S.R., China
Monetary conversion rate: 1 Sudanese pound=US$2.87 (official); 0.348 Sudanese
pound=US$1
Fiscal year: 1 July - 30 June
GDP: aN million (1968), about $190 per capita; real growth rate about
8% (1967
Agriculture: main crops -- maize, cotton, rice, sugar, and citrus fruits
Major industry: mining
Electric power: 63,300 kw. capacity (1971); 204 million kw.-hr. produced (1971),
490 kw.-hr. per capita
Approved For Release 2004/09/15 : CfA-RDP79-01051A000500010001-1
ECONOMY (cont ighPProved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Exports: $70 million (f.0.b., 1970); iron ore, asbestos, sugar, wood and forest
products, citrus, meat products, cotton
Imports: $60 million (f.0.b., 1970); food products, manufactured goods, machinery,
fertilizer, fuel
Major trade partners: Japan, U.K., South Africa
Aid: economic aid -- U.K. $14.7 million (budgeted, 1971-73), others approximately
$1.3 million; no military aid
Monetary conversion rate: 1 South African Rand=US$1.25 (Swaziland uses the South
African Rand, which is linked to the U.K. pound; the Rand exchange rate
fluctuated in the range of $1.24-$1.26 during July-September 1972); 0.800
SA Rand=US$1
Fiscal year: 1 April - 31 March
GNP: $37.8 billion, $4,650 per capita (1971); 53.5% consumption, 22.1% investment,
23.3% government; 1.1% net exports of goods and services; 1971 growth rate
0.3% in constant prices
Approved For Release 2004/09/15 : GA\\-RDP79-01051A000500010001-1
ECONOMY (cont approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Agriculture: animal husbandry predominates with milk and dairy products
accounting for 40% of farm income; main crops -- grains, sugar beets,
potatoes; 90% self-sufficient; food shortages -- oils and fats, tropical
Products; caloric intake, 2,880 calories per day per capita (1967-68)
Major industries: fron and steel, precision equipment (bearings, radio and
telephone parts, armaments), shipbuilding, wood pulp and paper products,
processed foods, textiles, chemicals
Shortages: coal, petroleum, textile fibers, potash, salt
Crude steel: 5.3 million metric tons produced (1971), 650 kilograms per capita
Electric power: 16.5 million kw. capacity (1971); 66.5 billion kw.-hr. produced
(1971), 8,164 kw.-hr. per capita
Exports: $7,932 million (f.0.b., 1971); machinery, motor vehicles
and ships, wood pulp, paper products, iron and steel products, metal ores
and scrap, chemicals
Imports: $7,524 million (c.i.f., 1971); machinery, motor vehicles, petroleum and
petroleum products, textile yarn and fabrics, iron and steel, chemicals, food,
and live animals
Major trade partners: (1971) West Germany 15.0%, U.K. 13.8%, U.S. 7.2%, Norway
8.3%, Denmark 9.0%; EFTA 42.4%; EC 29.7%; Communist countries 4.8%
Aid: economic -- U.S., $206.4 million authorized (FY46-71); $18.5 million in 1971;
net official aid to less developed countries and multilateral agencies, $662.4
million (1960-70), $71.4 million in 1968, $120.8 million in 1969, $154.6
million in 1970, $180 million in 1971
Monetary conversion rate: 4.81 kronor=US$1 (central rate, 1971)
Fiscal year: 1 July - 30 June
GNP: $26.2 billion (1971), $4,110 per capita; 57% consumption, 29% investment,
12% government, net foreign balance 2% (1971); 1971 growth rate 4%, 1958
constant prices
Approved For Release 2004/09/15 : G#4-RDP79-01051A000500010001-1
ECONOMY fesnerayseereved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Agriculture: dairy farming predominates; less than 50% self-sufficient; food
shortages -- fish, refined sugar, fats and oils (other than butter), grains,
eggs, fruits, vegetables, meat; caloric intake, 2,990 calories per day per
capita (1967-68 est.)
Major industries: machinery, chemicals, watches, textiles, precision instruments
Shortages: practically all important raw materials except hydroelectric energy
Crude steel: 453,000 metric tons produced (1969), 70 kg. per capita
Electric power: 10,6 million kw. capacity (1971); 32.8 billion kw.-hr. produced
(1971), 5,145 kw.-hr. per capita
Exports: $6.2 billion (f.o.b., 1971); principal items -- machinery and equip-
ment, chemicals, precision instruments, textiles, foodstuffs
Imports: $7.7 billion (c.4.f., 1971); principal items -- machinery and trans-
portation equipment, metals and metal products, foodstuffs, chemicals,
textile fibers and yarns
Major trade partners: West Germany 23%, France 11%, U.S. 8%, Austria 5%, Italy
9%, U.K. 8%; EC 50%; EFTA 20%; Communist countries 4% (1971)
Aid: some disbursed; none received
Monetary conversion rate: 3.84 Swiss francs=US$1 (central rate)
Fiscal year: calendar year
NDP: $2.279 billion (1972), $340 per capita; real GNP growth rate 10-13% est.
Agriculture: main crops -- cotton, wheat, sugar beets and barley; sheep and goat
raising; self-sufficient in food in years of average weather
Major industries: textiles, cement, glass, petroleum (118,000 bpd. production,
refining capacity 54,000 bbls. per day, 1971) food processing, soap
Electric power: 360,000 kw. capacity (1971); 1.2 billion kw.-hr. produced
(1971), 193 kw.-hr. per capita
Approved For Release 2004/09/15 : GIAARDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Exports: $180 million (1971); cotton, fruits and vegetables, grain, wool, and
livestock
Imports: $375 million (1971); machinery and metal products, textiles, fuels,
foodstuffs
Monetary conversion rate: 3.82 Syrian pounds=US$1 (controlled rate); 4.32 Syrian
pounds=US$1 (free rate) (January 1972)
Fiscal year: calendar year
GDP: $6.9 billion (1971 est. in current prices), $190 per capita; estimated 7%
real growth in 1970
Agriculture: world''s second largest rice exporter; main crops -- rice, rubber,
corn; almost 100% self-sufficient in food
Fishing: catch 1.63 million tons, (1971)
Major industries: agricultural processing, textiles, wood and wood products,
cement, tin mining; non-Communist world''s third largest tin producer
Shortages: fuel sources, including coal and petroleum
Electric power: 1,566,000 kw. capacity (1972); 6.2 billion kw.-hr. produced
(1971), 171 kw.-hr. per capita
Exports: $833 million (f.0.b., 1971); rice, corn, rubber, tin, cassava, kenaf
Imports: $1,288 million (c.i.f., 1971); excluding U.S. military imports;
machinery and transport equipment, textiles, fuels and lubricants, base
metals, chemicals
Major trade partners: exports -- Japan, U.S., Singapore, Hong Kong, Netherlands,
Malaysia; imports -- Japan, U.S., West Germany, U.K.; about 1% or less trade
with Communist countries
Approved For Release 2004/09/15 31A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-010 u
ECONOMY (cont''d): ''51A000500010001-1
Monetary conversion rate: 20.8 baht=US$1
Fiscal year: 1 October - 30 September
GDP: $290 million (1971), about $140 per capita; estimated real growth 1966-70, 5.3%
average annual rate
Agriculture: main cash crops -- coffee, cocoa; major food crops -- yams, cassava,
corn, beans, rice, fish; must import some foodstuffs
Major industries: phosphate mining, agricultural processing, handicrafts,
textiles, beverages
Electric power: 18,750 kw. capacity (1971); 63 million kw.-hr. produced (1971),
30 kw.-hr. per capita
. Exports: $49.2 million (f.o.b., 1971); phosphates, cocoa, coffee, palm
kernels, and cassava
Imports: $70.2 million (c.i.f., 1971); consumer goods,
fuels, machinery, tobacco, foodstuffs
Approved For Release 2004/09/15 : GfA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Major trade partners: mostly with France and other EC countries
Aid: (1970 disbursements) France $2.3 million, West Germany $2.0 million, U.S.
$1.0 million (FY60-70 total commitments $18.3 million), EC $5.5 million,
U.N. $1.0 million, others $1.1 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; 255.78 CFA francs=US$1
Fiscal year: calendar year
Agriculture: largely dominated by coconut production with subsistence crops of
taro, yams, sweet potatoes, and bread fruit
Electric power: 3,500 kw. capacity (1972); 10.4 billion kw.-hr. produced (1972),
114 kw.-hr. per capita
Exports: $3.8 million (f.o.b., 1969); copra, coconut products 71%, bananas 20%
Imports: $5.7 million (c.i.f., 1969)
Major trade partners: (1969) exports -- 30% New Zealand, 30% Norway, 15%
Netherlands; imports -- 32% New Zealand, 25% Australia, 13% U.K.
Monetary conversion rate: 0.893 Tonga dollar=US$1
GDP: $1.2 billion (1971 provisional, 1966 constant prices), $230 per capita;
3.1% average annual growth rate 1965-71
Agriculture: cereal farming and livestock herding predominate; main crops --
weet barley, olives, fruits (especially citrus), viticulture, vegetables,
ates
Major industries: mining, food processing, textiles and leather, light
manufacturing, construction materials, chemical fertilizers
" Electric power: 270,000 kw. capacity (1971); 680 million kw.-hr. produced (1971),
127 kw.-hr. per capita
Approved For Release 2004/09/15 : CPAZRDP79-01051A000500010001-1
ECONOMY (cont*drrrores For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Exports: $181 million (f.o.b., 1971); 26% petroleum, 21% phosphates, 9% olive
oil, 16% other agricultural products, 28% other
Imports: $346 million (c.i.f., 1971}; 36% raw materials, 23% machinery and
equipment, 14% consumer goods, 19% food and beverages, 3% energy, 5% other
Major trade partners: exports -- France 24%, other EC 33%; imports -- France
35%, U.S. 17%, other EC 20% (1970)
Monetary conversion rate: 0.48 dinar=US$1
Fiscal year: calendar year
GNP: $12,016 million (1971), about $330 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2,6 million kw. capacity (1971); 9,724 million kw.-hr. produced
(1971), 267 kw.-hr. per capita
Exports: $616.5 million (f.o.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 102,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Monetary conversion rate: 14 Turkish liras=US$1 (official rate)
Fiscal year: 1 March - 28 February
arr Oly million (1970), $100 per capita; 7.3% real growth between 1965 and
970
Agriculture: main cash crops -- coffee, cotton; other cash crops --~ sugar,
tobacco, fish, tea, livestock; self-sufficient in food
Fishing: catch 129,000 metric tons (1970), $19.5 million (1970)
Major industries: agricultural Processing (textiles, sugar, coffee, plywood,
beer), cement, copper smelter, corrugated iron sheet, shoes, fertilizer
Electric power: 156,000 kw. Capacity (1971); 768 million kw.-hr. produced
(1971), 142 kw.-hr. per capita
Exports: $261.4 million (f.0.b., 1970); coffee, Cotton, copper, tea; $7.6 million
to Communist countries (c.i.f., 1968)
Imports: $204.8 million (c.i.f., 1970); petroleum products, machinery, cotton
tera oe transport equipment; $7 million from Communist countries
c.i.f., 1968
Major trade partners: U.K., U.S., Kenya (Uganda, Kenya, and Tanzania form
East African Economic Communi ty)
Approved For Release 2004/09/15 *CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A0
ECONOMY (cont''d): A000500010001-1
Monetary conversion rate: 7.143 Uganda shill ings=US$1; 1 Uganda shill ing=US$0.14
Fiscal year: 1 July - 30 June
Agriculture: principal food crops -- grain (especially wheat), potatoes; main
industrial crops -- sugar beets, cotton, sunflowers, and flax; degree of
self-sufficiency depends on fluctuations in crop yields; given normal yields,
U.S.S.R. is self-sufficient; caloric intake, 3,000-3,200 calories per day
per capita in recent years
Approved For Release 2004/09/15 3&#A-RDP79-01051A000500010001-1
Approved For Release 2004, : - -
ECONOMY (cont! ae 109/15 : CIA-RDP79-01051A000500010001-1
Fishing: catch 7,811,100 tons (1971); exports 277,200 tons (1971), imports
22,200 tons (1971)
Major industries: diversified, highly developed capital goods industries; consumer
goods industries comparatively less developed
Shortages: natural rubber, bauxite and alumina, tantalum, tin, and tungsten
Crude steel: 130 million metric ton capacity as of 1 January 1972; 120.7
million metric tons produced in 1971, 490 kilograms per capita
Exports: fuels (particularly petroleum and derivatives), metals, agricultural
products (timber, grain) and a wide variety of manufactured goods (primarily
capital goods); $13,806 million (f.0.b. 1971)
Imports: specialized and complex machinery and equipment, textile fibers, consumer
manufactures, and any significant shortages in domestic roduction (for
example, wheat imported following poor domestic aaevestc |: $12,479 million
(f.0.b., 1971)
Major trade partners: $26.3 billion (1971); trade 65% with Communist countries,
21% with industrialized West, and 14% with less developed countries
Official monetary conversion rate: 0.82 rubles=US$1; 1 ruble=US$1.2195
Fiscal year: calendar year
Agriculture: food imported, but some dates, alfalfa, vegetables, fruit, tobacco
raised
Major industries: fishing, trading, oi] production; oi1 production began in Abu
Dhabi in 1962, and in 1972 reached 1,100,000 bbls. per day; oi] revenues
accruing to Abu Dhabi estimated $600 million in 1972; Dubai has best port
and is commercial center -- oi] was discovered in commercial quantities in
1966; production began in 1969, 1971 production 125,000 b.p.d.; oil revenues
for 1971 estimated at $50 million; small fishing, some boat building,
handicrafts, animal husbandry, pearling throughout area
Electric power: 36,000 kw. capacity (1970); 90 million kw.-hr. produced (1970),
676 kw.-hr. per capita
Exports: crude petroleum, pearls, fish; Abu Dhabi crude exports $624 million (','86ae88ad9a1e4608cd06744dc4d860e72883c40413741eb5eddd8ee02c29c3ed','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02f430b255b7b87c073061dbe94b704fc60ee681b4f06bc477f3aca6493d50f2',1973,'DZ','Algeria','economy',61,'est.
1971) and Dubai $32 million total, of which $30 million reexports (1972)
Imports: food, consumer and capital goods; Abu Dhabi $108 million (est.
1972) and Dubai $249 million total (1972)
Major trade partners: Japan, U.K., India
Aid: multilateral annual average (1967-69) $1.17 million
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.23; Abu Dhabi, 1 Bahrain
dinar=US$2.27 (as of March 1972)
Approved For Release 2004/09/15 : @A-RDP79-01051A000500010001-1
COMMUNICATIONSAPProved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Railroads: none
Highways: 175 mi. bituminous, undetermined mileage of earth tracks
Pipelines: crude oi], 160 mi.
Ports: 2 major, 4 minor
Merchant marine: 3 cargo ships (1,000 GRT or over) totaling 7,700 GRT, 11,900 DWT
Civil air: no major transport aircraft
Airfields: 89 total, 38 usable; 3 with permanent-surface runways; | with runway
over 12,000 ft., 1 with runway 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.
Telecommunications: telephone system in Dubayy and Ash Shariqah, also links
these towns; Abu Dhabi Petroleum operates a telecom system throughout
the sheikhdom; key centers are at At Tarif, Habshan, and Az Zannah; 6,800
telephones; 22,000 radio and 10,000 TV receivers; 3 AM, 1 FM, and 2 TV
stations
DEFENSE FORCES:
Military manpower: males 15-49, about 43,000; about 22,000 fit for military service
Aircraft: Abu Dhabi, 28 (11 jet, 7 prop, 10 helicopters)
Supply: mostly from U.K.
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GDP: $325 million (1971 est.), $60 per capita
Agriculture: cash crops -- peanuts, shea nuts, sesame, cotton; food crops --
sorghum, millet, corn, rice; livestock; largely self-sufficient
Fishing: catch 5,000 metric tons (1969), $2.7 million
Major industries: agricultural processing plants, brewery, bottling, and brick
plants; a few other light industries
Approved For Release 2004/09/15 : @?A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Electric power: 13,530 kw. capacity (1971); 33 million kw.-hr. produced (1971),
6 kw.-hr. per capita
Exports: $17 million (f.0.b., 1971); livestock (on the hoof), peanuts, shea
nut products, cotton, sesame
Imports: $55 million (c.i.f., 1971); textiles, food, and other consumer goods,
transport equipment, machinery, fuels
Major trade partners: volume understated because much regional trade is unrecorded;
Ivory Coast and Ghana; overseas trade mainly with France and other EC
countries; preferential tariff to EC and franc zone countries
Aid:
economic -- France (1964-September 1970) $46 million; EC (1960-70) $56.7
million; U.S.S.R., Ghana, West Germany, and Israel have also extended aid;
U.S. (FY¥62-71) $268 million; international organizations (1960-70) $12.1 million;
military -- France, $3.7 million (1964-70); U.S., $0.2 million (1962-70)
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
(official )
Fiscal year: calendar year
The Vatican City, seat of the Holy See, is supported financially by contributions
(known as Peter''s pence) from Roman Catholics throughout the world; some
income derived from sale of Vatican postage stamps and tourist mementos,
fees for admission to Vatican museums, and sale of publications; industrial
activity consists solely of printing and production of a small amount of
mosaics and staff uniforms
The banking and financial activities of the Vatican are worldwide; the Institute
for Religious Agencies carries out fiscal operations and invests and transfers
funds of Roman Catholic religious communities throughout the world; the
Cardinal''s Commission controls the administration of ordinary assets of the
Holy See and a Special Administration manages the Holy See''s capital assets
Electric power: obtained from Rome city grid; standby diesel powerplant with
2,100 kw. capacity
Approved For Release 2004/09/15 : ciA°RDP79-010514000500010001-1
2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS; “PProved For Release
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Telecommunications: 1 AM and 1 FM radiobroadcasting stations; 2,000-line
automatic telephone exchange
DEFENSE FORCES:
Defense is responsibility of Italy
Approved For Release 2664/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release e0om Oo : CIA-RDP79-01051A000500010001-1
LAND:
352,000 sq. mi.; 4% cropland, 18% pasture, 21% forest, \\
57% urban, waste, and other BRAZIL
Land boundaries: 2,598 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,740 mi.
GNP: $12.3 billion (purchasing power parity estimate, 1971), $1,140 per capita;
64% private consumption, 14% public consumption, 22% gross investment (1970) ;
real growth rate 1971 est. 5%
Agriculture: main crops -- cotton, Sugarcane, corn, coffee, rice; self-sufficient
in rice and chicken, imports wheat (U.S.) and meat (Colombia); caloric
intake 2,600 calories per day per capita (1964)
Approved For Release 2004/09/15 : GI#2RDP79-01051A000500010001-1
ECONOMY (cont ''d\\pProved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Fishing: catch 126,300 tons metric, $33.8 million (1970); exports $5.7 million
(1969 est.), imports $4.6 million (1969)
Major industries: petroleum, jron-ore mining, construction, food processing,
textiles
Crude steel: 923,000 metric tons produced (1970), 90 kilograms per capita
Electric power: 3.2 million kw. capacity (1971); 13.4 billion kw.-hr. produced
(1971), 1,300 kw.-hr. per capita
Exports: $3,129 million (f.o.b., 1971); petroleum $2,783 million (1971), iron
ore, coffee, cocoa
Imports: $1,891 million (c.i.f., 1971); industrial machinery and equipment,
chemicals, manufactures, wheat
hla trade partners: U.S. 41%, Canada 9%, U.K. 5% (1969)
id:
economic -- extensions from U.S. (FY46-70), $360.1 million loans; $59.7
million grants; from international organizations (FY46-70), $574.5 million;
from Communist countries (1954-71), $10 million;
military -- assistance from U.S. (FY53-71), $115.6 million
Monetary conversion rate: 4.40 bolivares=US$1 (selling rate)
Fiscal year: calendar year
Agriculture: mainly subsistence; main crops -- rice, corn, sweet potatoes,
manioc, sugarcane; food shortages -- rice, meat, sugar; caloric intake,
1,700-2,200 calories per day per capita
Major industries: food processing, textiles, machine building, mining, cement
Shortages: petroleum, complex machinery and equipment, fertilizer, foodstuffs
Monetary conversion rate (nominal): 3.7 dong=US$1
Fiscal year: calendar year','9309e0f19d20b70cc463362e762180519ee43e4a8c93dbdd73943cfa85b08b23','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c2a512bb135dce14b481d7a5c101abf1eb2bc5f2840742dd4821dbe93cc0363',1973,'DO','Dominican Republic','economy',67,'GDP: $1.5 billion (1971), $360 per capita; real growth rate 1970, 6.1%
Agriculture: main crops -- sugarcane, coffee, cocoa, tobacco, rice, corn; self-
sufficient in rice; caloric intake, 2,200 calories per day per capita (1966)
Major industries: sugar processing, bauxite mining, peanut processing, textiles,
cement
Approved For Release 2004/09/15 : @IA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Electric power: 256,500 kw. capacity (1971); 1,052 million kw.-hr. produced
(1971), 250 kw.-hr. per capita
Exports: $213.5 million (f.0.b., 1970); sugar, coffee, cocoa, tobacco, bauxite
Imports: $306 million (c.i.f., 1970); foodstuffs, petroleum, industrial raw
materials, capital equipment
Major trade partners: exports -- U.S. 78%, EC 6% (1970); imports -- U.S. 56%,
Europe 25% (1968)
Aid:
economic -- from U.S. (FY46-71), $208.1 million in grants, $262.9 million
in loans; from international organizations (FYA6-715, $100.7 million;
military -- assistance from U.S. (FY53-70), $28.3 million
Monetary conversion rate: 1 peso=US$]
Fiscal year: calendar year
GNP: $3 billion (purchasing power parity estimate, 1971), $480 per capita;
72% private consumption, 14% public consumption, 14% gross investment (1970
est.); real growth rate 1971 est., 8%
Agriculture: main crops -- sugarcane, beans, coffee, cotton, corn, bananas,
potatoes, cocoa, rice; nearly self-sufficient; caloric intake, 2,100 calories
per day per capita (1964)
Fishing: catch 91,500 tons (1970), $12.1 million (1970); exports $10.2 million
(1970), imports negligible
Major industries: food processing, textiles, cement, leather and rubber products ,
drugs, fishing, petroleum, fertilizer
Approved For Release 2004/09/15 : @la-RDP79-01051A000500010001-1
ECONOMY CecnecapPreved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Electric power: 294,000 kw. capacity (1971); 937 million kw.-hr. produced
(1971), 160 kw.-hr. per capita
Exports: $235 million (f.o.b., 1971 est.); bananas, coffee, cocoa, sugar, fish
products
Imports: $275 million (c.i.f., 1971 est.); agricultural and industrial machinery,
wheat, petroleun products, chemical products, transportation and conmunication
equi pment
pooper trade partners: U.S. 37%, EC 22%, Japan 14% (1970)
id:
economic -- extensions from U.S. (FY46-71), $208.7 million loans, $102.0
million grants; from international organizations (FY46-70), $152.4 million;
from Communist countries (1954-71), $15.4 million loans;
military -- assistance from U.S. (FY49-71), $60.6 million
Monetary conversion rate: 25.25 sucres=US$1 (official selling rate)
Fiscal year: calendar year
Agriculture: main cash crop -- cotton; other crops -- rice, onions, beans, wheat,
corn, barley; not self-sufficient in food, but agriculture a net earner of
foreign exchange
Major industries: textiles, food processing, chemicals, petroleum, construction,
cement
Electric power: 4,350,000 kw. capacity (1971); 10,000 million kw.-hr. produced
(1971), 265 kw.-hr. per capita
Approved For Release 2004/09/15 : Gla-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : - -
Sceuour tenn PP 15 : CIA-RDP79-01051A000500010001-1
Aid:
economic -- Communist countries, $1,950 million in credits through December
1971; U.S., $910.6 million in credits and grants through June 1967
(diplomatic relations and aid suspended June 1967, aid resumed January 1972);
sizable credits from international agencies, West Germany, Italy; large grants
from Libya since 1969; $250 million annual subsidy from Arab states while
canal is closed;
military -- Communist countries, about $2,800 million through December 1971
Monetary conversion rate: 1 Egyptian pound=US$2. 30 (selling rate); 0.435 Egyptian
pound=US$1 (selling rate)
Fiscal year: calendar year','67e320acf328c48aa2c6437050a54e80e087a197493cd163a0245160fa77aa35','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28462e91d1f5f0a6e631a5cb9398d5541e56c262327a23d00a8ad7d61ee6c30a',1973,'SV','El Salvador','economy',71,'GNP: $1.49 billion (purchasing power parity estimate, 1971), $410 per capita;
80% private consumption, 9% government consumption, 11% domestic investment
(1970 est.); real growth rate 1970 est., 4.5%
Agriculture: main crops -- coffee, cotton, corn, sugar, rice, beans; caloric
intake, 2,000 calories per day per capita (1963-64)
Fishing: catch 16,600 metric tons (1970); exports $5.3 million (1970), imports
$0.2 million (1970)
Major industries: food processing, textiles, clothing, petroleum products
Electric power: 188,000 kw. capacity (1971); 736 million kw.-hr. produced
(1971), 209 kw.-hr. per capita
Exports: 228.4 million (f.0.b., 1971); coffee, cotton, sugar, chemicals,
other manufactures
Imports: $249.2 million (f.0.b., 1971); machinery, automotive vehicles, petroleum,
foodstuffs
Major trade partners: exports -- U.S. 19%, CACM 30%, West Germany 27%, Japan
12%; imports -- U.S. 29%, CACM 29%, West Germany 8%, Japan 10% (1970)
Aid:
economic -- from U.S. (FY46-71), $87.2 million loans, $59.3 million grants;
from international organizations (FY49-71), $104.7 million; from other Western
countries (1960-68) $3.7 million;
military -- assistance from U.S. (FY53-71), $6.9 million
Monetary conversion rate: 2.5 colones=US$1 (official)
Fiscal year: calendar year','a433eb87b1d8055fd430ee48686fe7eb31190ec4c5b37de0c466df862cb60d1a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8e4dccc6dd2b0d0b08a29c090926589ae608b0fdd7f0be1f643db350bbcc82d',1973,'GQ','Equatorial Guinea','economy',75,'GDP: $40 million (1968 est.); Rio Muni nearly $100 per capita, Fernando Po
about $250 per capita
Agriculture: major cash crops -- Rio Muni, timber, coffee; Fernando Po, cocoa;
main food crops -- rice, yams, cassava, bananas, oi] palm nuts, manioc, and
livestock
Fishing: catch 4,000 metric tons (1970); exports $86,000 (1970)
Major industries: fishing, sawmilling
Electric power: 2,800 kw. capacity (1971); 9 million kw.-hr. produced (1971),
about 30 kw.-hr. per capita
Exports: $24.9 million (1970); cocoa, coffee, and wood
Imports: $21.0 million (1970); foodstuffs, chemicals and chemical products,
textiles
Major trade partner: Spain
Aid: Spain, $14.0 million (1969); Libya, $1 million (1971)
Monetary conversion rate: 64.47 Guinean pesetas=US$1 (official)
Railroads: none
Highways: Rio Muni -- 1,553 mi.; Fernando Po -- 186 mi.
Approved For Release 2004/09/15 : @Pa-RDP79-01051A000500010001-1
rove For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
comunt cations ARB
Inland waterways: Rio Muni has approximately 104 mi. of year-round navigable
waterway, used mostly by pirogues
Ports: 2 major, 3 minor
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: fairly adequate for the size and stage of development of the
country; international conmunications by radio from Bata and Santa Isabel
to Cameroon, Nigeria, and Spain; 1,500 telephones; 71,000 radio receivers;
2 AM, no FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 74,000; 35,000 fit for military service
Military budget: for FY70, $3,475,000, 14.3% of total budget
Approved For Release 2002709/15 : CIA-RDP79-01051A000500010001-1
Approved For Release Be Ce ee
D:
455,000 sq. mi.; 9.5% cropland and orchards, 54.6% meadows
and natural pastures, 6.5% forests and woodlands,
29.4% wasteland, built-on areas, and other
Land boundaries: 3,230 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 680 mi. (includes offshore islands)
GDP: $1,629 million (1970 in current prices), $60 per capita; 1970 average annual
growth rate 6.1% (current prices)
Agriculture: main crops -- coffee, teff, durra, barley, wheat, corn, sugarcane,
cotton, pulses, oilseeds, livestock; almost self-sufficient in food
ee ead 6,927 metric tons (1970), $1.4 million (1970); exports $348,000
Major industries: cement, sugar refining, cotton textiles, food processing,
oil refinery
Electric power: 206,000 kw. capacity (1971); 453 million kw.-hr. produced
(1971), 18 kw.-hr. per capita
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Exports: $125.6 million (f.0.b., 1971); coffee 55.8%, hides and skins 8.2%,
oilseeds, oilcakes, and nuts 10.2%, cereals 7.4%; $4.6 million to Communist
countries (1971)
Imports: $188.9 million (c.i.f., 1971); metals, machinery and vehicles 47.1%,
petroleum and chemicals 17%, foodstuffs, live animals, and beverages 7.3%;
$9.7 million from Communist countries (1970)
Major trade partners: imports -- Italy, Japan, West Germany, and U.S.;
exports -- U.S., West Germany, Italy, Saudi Arabia, Japan
Monetary conversion rate: 2.3026 Ethiopian dollars=US$1 (official)
Fiscal year: 8 July - 7 July','4bf3832f2ae9fb52f7781a6d5a9e61da616c77bfe7c7454f338fb5659a9ae935','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('093df7c06c413f160b16ef19635f70bd5d5ea99a3c25ad01cea26828948b3dd9',1973,'FR','France','economy',78,'GDP: $75.3 million (1969), about $1,930 per capita
Agriculture: sheep and cattle grazing
Fishing: catch 210,100 tons (1971); exports $38.7 million
Major industry: fishing
Electric power: 27,545 kw. Capacity (1970); 66.86 billion kw.-hr. Produced (1970),
1,713 kw.-hr. per capita
Exports: $35.9 million (f.0.b., 1970); fish and fish products
Imports: $32.7 million (c.i.f., 1970); machinery and transport equipment, pet-
roleum and petroleum products, food products
Major trade partners: (1969) Denmark 48%, U.K. 8%, Sweden 4%, U.S. 6%, Norway
4%; EC 15%; EFTA 68%
Monetary conversion rate: 6.98 Danish kroner=US $1
Fiscal year: 1 April - 31 March
99
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Releas : zi a
COMMUNICATIONS: pp e 2004/09/15 : CIA-RDP79-01051A000500010001-1
Railroads: none
Highways: none
Ports: 1 minor
Airfields: 1 with permanent-surface runway, less than 4,000 ft.
Civil air: no major transport aircraft
Telecommunications: good international radiocommunications; fair domestic
wire facilities; 9,400 telephones, 11,000 radio receivers, 1 AM, and 3 FM
stations; 3 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49 included with Denmark
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release. 200 4109/45 atte RRP Rae 140005000 10001-1
LAND:
Colony -- 4,700 sq. mi.; area consists of some 200 small
islands, chief of which are East Falkland (2,580 sq.
mi.) and West Falkland (2,038 sq. mi.); dependencies--~
consists of the South Sandwich Islands, South Georgia,
and the Shag and Clerke Rocks
LAND:
213,000 sq. mi.; 35% cultivated, 26% meadows and pastures,
14% waste, urban, or other, 25% forested
Land boundaries: 1,795 mi.
WATER: }
Limits of oe waters (claimed): 12 n. mi. (fishing
12 n. mi.
Coastline: 2,130 mi. (includes Corsica, 400 mi.)
PEOPLE: 4 ALGERIA
Population: 51,922,000, average annual growth rate 0.8%
(January 66-72)
Ethnic divisions: 45% Celtic; remainder Latin, Germanic, Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1% Muslim (North African
workers), 11% unaffiliated
Language: French (100% of population); rapidly declining regional patois --
Provencal, Breton, Germanic, Corsican, Catalan, Basque, Flemish
Literacy: 97%
Labor force: 20,002,240; 15.4% agriculture, 39.5% industry, 44.9% services,
2% unemployed
Organized labor: 17% of labor force, 23.4% of salaried labor force
GNP: $176.8 billion (1971 est.), $3,450 per capita; 59% consumption, 28% investment
(including government), 12% government consumption; 1% net foreign balance;
1971 growth rate 5.0%, 1963 constant prices
Agriculture: Western Europe''s foremost producer; main crops -- beef, cereals, sugar
beets, potatoes, wine grapes; self-sufficient for most temperate zone food-
stuffs; food shortages -- fats and oils, tropical produce; caloric intake, A
3,270 calories per day per capita (1969-70)
Fishing: catch 775,200 metric tons, $287 million (1970); exports $37 million
(1970), imports $204 million (1970)
Major industries: steel, machinery and equipment, textiles and clothing,
chemicals, food processing, metallurgy
Shortages: crude oi], textile fibers, most nonferrous ores, coking coal, fats
and oils
Crude steel: 22.9 million metric tons produced (1971), 450 kilograms per capita
(1971 est.)
Electric power: 38,900,000 kw. capacity (1971); 149 billion kw.-hr. produced
(1971), 2,879 kw.-hr. per capita
Exports: $22.5 billion (f.o.b., 1971); principal items -- textiles and clothing,
iron and steel products, machinery and transportation equipment, foodstuffs
and agricultural products, alcoholic beverages
Imports: $23.1 billion (c.i.f., 1971); principal items -- machinery and
equipment, crude petroleum, iron and steel products, textile fibers, coal
and coke, foodstuffs, alcoholic beverages
Major trade partners: (1971) EC 54%; West Germany 242; Belgium-Luxembourg 12%;
Italy 11%; Netherlands 6%; EFTA 14%; U.S. 8%; Eastern Europe 3%; U.S.S.R. 1%3
franc zone 9%
Aid:
economic (received) -- U.S., $5,343 million authorized (FY46-71), $128
million in FY71;
military -- U.5., $4,259 million authorized (FY46-71); net official economic «
aid to less developed areas and multilateral agencies -- $7,431 million
(FY60-70) , $951.7 million (FY70)
Monetary conversion rate: 5.1157 francs=US$1 (central rate)
Fiscal year: calendar year
GNP: $32 million (1966), $840 per capita
Agriculture: main crops -- rice, corn, manioc, cocoa, bananas, sugarcane
Fishing: catch 900 metric tons (1969) $378,000; exports $3.9 million (1969),
imports $2.3 million (1969)
Major industries: timber, rum, gold mining, production of rosewood essence and
space center
Electric power: 18,560 kw. capacity (1971); 55 million kw.-hr. produced (1971),
1,068 kw.-hr, per capita
Exports: $3.4 million (f.o.b. 1968); shrimp, timber, rum, rosewood essence
Imports: $52.0 million (c.i.f., 1968); food (grains, processed meat), other
consumer goods, producer goods and petroleum
Major trade partners: exports -- U.S. 78%, France 11%, Martinique 5%; imports --
France 72%, U.S. 13%, Trinidad and Tobago 3% (1967)
Approved For Release 2004/09/15 : Cia-RDP79-01051A000500010001-1
ECONOMY (cont approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Monetary conversion rate: 5.002 francs=US$]
Fiscal year: calendar year
Agriculture: livestock; desert conditions limit commercial crops to about 15
acres
Industry: ship repairs
Electric power: 18,300 kw. capacity (1971); 18 million kw.-hr. produced (1971),
222 kw.-hr, per capita
Imports: almost all domestically needed goods
Exports: hides and skins
Aid: $2.4 million in 1967 from France
s Monetary conversion rate: 197.11 Djibouti francs=US$1 (official)
Fiscal year: probably same as that for France (calendar year)
GDP: $378 million (1971, current prices), about $760 per capita; real GDP
growth 8.5%
Agriculture: commercial -- cocoa, coffee, wood, palm oil, rice; main food crops
-- bananas, manioc, peanuts, root crops; imports food
Fishing: catch 4,000 metric tons (1970); exports $600,000 (1970), imports -- not
available
Major industries: sawmills, petroleum refinery, natural gas, agricultural
processing; mining of increasing importance; major minerals -- manganese,
uranium, gold, and iron
Electric power: 34,000 kw. capacity (1971); 114 million kw.-hr. produced (1971),
222 kw.-hr. per capita
Exports: $212.5 million (f.0.b., 1971); wood and wood products 40%; minerals
(manganese, uranium concentrates, gold, crude oil) 60% (1970)
Approved For Release 2004/09/15 | Ga-RDP79-01051A000500010001-1
ECONOMY (cont''d proved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Imports: $102.8 million (c.i.f., 1970) excluding UDEAC trade; mining, roadbuilding
machinery, electrical equipment, transport vehicles, foodstuffs, textiles
Major trade partners: France, U.S., West Germany, and Curacao; preferential
tariffs to EC and franc zone
Monetary conversion rate: 1 Conmunaute Financiere Africaine franc=0.02 French
francs; 255.785 CFA francs=US$]
Fiscal year: calendar year
GDP: $46 million (FY71 est.), about $120 per capita
Agriculture: main crops -- peanuts, rice, palm kernels
Fishing: catch 5,000 tons (1970); exports $106,000 (1970)
Major industry: peanut processing
Electric power: 5,000 kw. capacity (1971); 12 million kw.-hr. produced (1971),
32 kw.-hr. per capita
ate ee million (1970); peanuts and peanut products 90% to 95%, palm
ernels
Imports: $17 million (1970); textiles, foodstuffs, tobacco, machinery ,
petroleum products
Major trade partners: exports -- U.K.; imports -- U.K. and Japan
Aid: economic -- U.K. (1968-71) about $8 million commitment
Approved For Release 2004/09/15 } U1A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Monetary conversion rate: 1.92 Gambian dalasi=US$1 (official)
Fiscal year: 1 July - 30 June
Agriculture: food deficit area; main crops -- potatoes, rye, wheat, barley, oats,
industrial crops; shortages in grain, vegetables, vegetable oil, beef;
caloric intake, 3,000 calories per day per capita (1970-71)
Fish catch: 332,000 metric tons (1971)
Major industries: metal fabrication, chemicals, light industry, brown coal,
uranium, and shipbuilding
Shortages: coking coal, coke, crude oil, rolled steel products, nonferrous metals
Crude steel: 5.67 million metric tons produced (1971), approx. 330 kg. per capita
Electric power: 13,338,000 kw. capacity (1971); 69.4 billion kw.-hr. produced
(1971), 4,075 kw.-hr. per capita
Exports: $5,074 million (f.o.b. delivering country, 1971)
Imports: $4,847 million (f.o.b. delivering country, 1971)
Major trade partners: $10,032 million (1971); 38% Soviet Union, 34% other
Communist countries, 29% non-Communist countries
Monetary conversion rate: 3.15 DME=US$1 (new rate introduced in 1972 and presumably
to be used for foreign trade calculations; foreign trade prior to 1972
calculated at old rate of 4.2 DME=US$1)
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for the consumption year
1 July - 30 June','71d16baa6835e4dca161bc1571262725b3ca7cee38f04ebecc296d5f53666c17','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac59dd274a1cc3fd7d148f4c7ae74c560d013a87eff7dbd6585667af6ca52370',1973,'FJ','Fiji','economy',82,'GNP: $244 million (1971), $450 per capita; 5% average annual growth rate (1968-71)
Agriculture: main crops -- sugar, coconut products, bananas, rice; major
deficiency, grains
Major industries: tourism, sugar processing
Electric power: 61,300 kw. capacity (1972); 160 million kw.-hr. produced (1972),
296 kw.-hr. per capita
Exports: $67.7 million (f.o.b., 1970 excluding reexports); sugar, copra, copper
Imports: $101.8 million (c.i.f., 1970); machinery, manufactured goods, food
Major trade partners: U.K., Australia, U.S., Japan, New Zealand
Aid: disbursed 1968 -- Australia $1.5 million, U.S. $600,000, U.K. $4.2 million
Monetary conversion rate: 0.87 Fijian dollar=US$1
Fiscal year: calendar year
GNP: $11.5 billion (1971), $2,450 per capita; 51.8% consumption, 29.0%
investment, 21.2% government, -2.0% net exports of goods and services; 197]
growth rate 1.3%, constant prices
Agriculture: animal husbandry, especially dairying, predominates; forestry
important secondary occupation for rural population; main crops -- cereals,
sugar beets, potatoes; 85% self-sufficient; shortages -- food and fodder
grains; caloric intake 2,890 calories per day per capita (1968-69)
Major industries: include metal manufacturing and shipbuilding, forestry and
wood processing (pulp, paper), copper refining
Shortages: fossil fuels; industrial raw materials, except wood, and iron ore
Crude steel: 1,168,837 metric tons produced (1970), 250 kilograms per capita
Electric power: 5,179,000 kw. capacity (1971); 23.5 billion kw.-hr. produced
(1971), 5,000 kw.-hr. per capita
Exports: $2,410 million (f.0.b., 1971); timber, paper and pulp, ships, machinery,
iron and steel, clothing and footwear
Imports: $2,860 million (c.i.f., 1971); foodstuffs, petroleum and petroleum
products, chemicals, transport equipment, iron and steel, machinery, textile
yarn and fabrics
Major trade partners (1971): 25% EC, 44% EFTA, 14% West Germany, 17% U.K.,
17% Sweden, 5% U.S., 12% U.S.S.R., 17% Communist countries
Aid: U.S. $184.1 million authorized FY46-71, $7.6 million in FY70; IBRD -- $276.5
million authorized through 1946-71, $33 million in 1971; Finnish foreign aid
programs have amounted to $23 million 1961-69, $15,000 in 1970
Monetary conversion rate: new markka (Fmk) 4.1=US$1 (central rate)
Fiscal year: calendar year
COMMUNT CATIONS:
Railroads: 3,676 mi.; Finnish State Railways (VR) operate a total
3,656 mi. broad gage (5''0"), 288 mi. multiple track, and 68 mi. electrified;
. 44 mi. narrow gage (2'' 5 1/2") and 13 mi. broad gage are privately owned
Highways: 44,200 mi., 11,600 mi. bituminous, 31,900 mi. stablized gravel, 700
mi. gravel and earth; 12,400 mi. of private roads (surface type na)
Inland waterways: 4,100 mi. total (including Saimaa Canal); 2,300 mi. suitable
for steamers; canal locks (275 ft. by 42 ft. with a 16.7 ft. depth over sill)
can accommodate vessels of up to 225 ft. in length, 36 ft. beam, and 14.5
ft. draft
Ports: 11 major, 14 minor
Merchant marine: 226 ships (1,000 GRT or over) totaling 1,501,800 GRT, 2,193,900
DWT; includes 1] passenger, 127 cargo, 49 tanker, 16 bulk, 23 specialized
carrier
Civil air: 32 major transport aircraft
Airfields: 96 total, 79 usable; 28 with permanent-surface runways; 15 with
runways 8,000-11,999 ft., 23 with runways 4,000-7,999 ft.
Telecommunications: facilities provide essential services for government, public,
and industry; 1,301,000 telephones; 1,817,000 radiobroadcast receivers;
Lee TV receivers; 17 AM, 40 FM, and 58 TV stations; 4 submarine cables,
coaxia
DEFENSE FORCES:
Military manpower: males 15-49, 1,197,000; 890,000 fit for military service;
38,000 reach military age (17) annually
Military budget: proposed for fiscal year ending 31 December 1972, $213.9 million;
about 6% of central government budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','03b8450839376427c7fb1bd03438a7a766f62e41ea41ae45c79d00b4560ac958','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44fef2d24eb458375b67f350f5cb670e82329c7455af1a1d7af40951b782147e',1973,'GH','Ghana','economy',87,'GDP: $2.5 billion (1970) at current prices, about $280 per capita; real growth
rate about 3.6%
Agriculture: main crop -- cocoa; other crops include root crops, corn, sorghum
and millet, peanuts; not self-sufficient, but can become so
Fishing: catch 187,000 metric tons (1970), $35 million
Major industries: mining, lumbering, light manufacturing, fishing, aluminum
Electric power: 765,000 kw. capacity (1971); 2.94 billion kw.-hr. produced
(1971), 325 kw.-hr. per capita
Exports: $424 million (f.0.b., 1970); cocoa (about 76%), wood, gold, diamonds,
manganese, bauxite, and aluminum (aluminum regularly excluded from balance
of payments data)
Imports: $384 million (c.i.f., 1970); textiles and other manufactured goods,
food, fuels, transport equipment
Major trade partners: U.K., EC, and U.S.
Approved For Release 2004/09/15 : GFA-RDP79-01051A000500010001-1
proved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (conser
Monetary conversion rate: 1 Cedi=US$0.78 (official); 1.28 Cedi=US$1
Fiscal year: 1 July - 30 June','799c93e0816dd6c3a58747050edc7bfe24cff4fd2adaa90a9c96887170cfb666','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49c78abde51ff30fbf7ec3af5471df6507f73088a76090c3805fa20b7f5b737b',1973,'GI','Gibraltar','economy',90,'Economic activity in Gibraltar centers on commerce and large British naval and
air bases. Nearly all trade in the well-developed port is transit trade and
port serves also as important supply depot for fuel, water, and ships'' wares.
Recently built dockyards and machine shops provide maintenance and repair
services to 3,500-4,000 vessels that call at Gibraltar each year.
U.K. military establishments and civil government employ nearly half the insured
labor force. Local industry is confined to manufacture of tobacco, roasted
coffee, ice, mineral waters, candy, and canned fish. Some factories for
manufacture of clothing are being developed. A small segment of local
population makes its livelihood by fishing. In recent years tourism has
increased in importance.
Approved For Release 2004/09/15 : CIALRDP79-01051A000500010001-1
ppproved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Electric power: 29,170 kw. capacity (1970); 47 million kw.-hr. produced (1970),
1,500 kw.-hr. per capita
Exports: $7.5 million (f.0.b., 1970}; principally reexports of tobacco,
petroleum, and wine
Imports: $25.2 million (1970)
Major trade partners: U.K., Morocco, Portugal, Netherlands
Monetary conversion rate: 1 Gibraltar pound=US$2.42 (floating U.K. pound, value
for October 1972)
GNP: $10.6 billion (1971), $1,205 per capita; 78% consumption, 22% investment;
1971 growth rate 10.3%, current market prices
Agriculture: subject to droughts; main crops -- wheat, olives, tobacco, cotton;
nearly self-sufficient; food shortages -- livestock products; caloric intake,
2,960 calories per day per capita (1963)
Major industries: food processing, tobacco, chemicals, textiles, petroleum
refining, aluminum processing
Shortages: petroleum, minerals, feed grains
Crude steel: 210,000 metric tons produced (1969), 20 kg. per capita
Electric power: 2,680,000 kw. capacity (1971); 10.816 billion kw.-hr. produced
(1971), 1,219 kw.-hr. per capita
Exports: $625 million (f.o.b., 1971); principal items -- tobacco, cotton, fruits,
metals
Imports: $1,840 million (c.i.f., 1971); principal items -- machinery and
automotive equipment, manufactured consumer goods, petroleum and
petroleum products, chemicals
Major trade partners: (1971) -- 44% EC, 14% sterling area, 13% U.S.,
8.4% CEMA countries
Aid:
economic (authorized) -- U.S., $1,916.4 million (1946-71); International
Finance Corporation, $14.9 million through 1971; U.N. Technical Assistance,
$4.1 million through 1970; U.N. Special Fund, $8.9 million through 1971;
IBRD, $71.3 million (1968-71), $20 million in 1971; Consortium, $40
million in 1966; EC (1964-71) $69.2 million;
military -- U.S., $2,066 million (1946-70)
Monetary conversion rate: 30 drachmae=US$1 (official)
Fiscal year: calendar year','12e16ab05628520501714cd42e865b2043584403ccaa66679d830acd816759e0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9db9a76a285c9e9d041bfc282fdfd3e1ea8668aa349889b2e6ee468aef90db9',1973,'GL','Greenland','economy',95,'GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep grazing; garden produce
Fishing: catch 38,159 tons, $6.3 million (1971)
Major industries: mining, slaughtering, fishing, sealing
Electric power: 27,338 kw. capacity (1971); 45.8 million kw.-hr. produced (1971),
934 kw.-hr. per capita
Exports: $15.0 million (f.o.b., 1969); fish and fish products, nonmetallic minerals
Imports: $56.7 million (f.o.b., 1969); machinery and transport equipment,
petroleum and petroleum products, food products
Major trade partners: (1970) Denmark 91%, U.S. 3%, Venezuela 5%
Monetary conversion rate: 6.98 Danish Kroner=US$1
Fiscal year: 1 April - 31 March','7081c04734a548013efb06bbde29482b106fb2cdc1b389449ce2c05e3f311f5c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b6904cc9210f41bd30999eb3533af60ed56e8dc408be25f508bd617ff69b05a',1973,'GY','Guyana','economy',99,'GNP: $283 million (1971 est.), $360 per capita; real growth rate 1971 (est.) 4%
Agriculture: main crops -- sugarcane, rice, other food crops; food shortages --
wheat flour, potatoes, processed meat, dairy products; caloric intake, 2,180
calories per day per capita (1967)
Fishing: catch 16,600 metric tons, $12 million (1970); exports $4.4 million (1970),
imports $1.5 million (1970)
Major industries: bauxite mining, alumina production, sugar and rice milling
Approved For Release 2004/09/15 : Clh4-<RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Electric power: 112,000 kw. capacity (1971); 350 million kw.-hr. produced
(1971), 412 kw.-hr. per capita
Exports: $137 million (f.o.b., 1971); bauxite, sugar, alumina, rice, shrimp,
molasses, timber, diamonds, rum
Imports: $131 million (c.i.f., 1971); manufactures, machinery, food, petroleum
Major trade partners: U.K. 28%, U.S. 23%, Canada 14%, Commonwealth Caribbean
countries 13% (1969)
Aid: economic -- from U.S. (FY53-71), $40.7 million loans, $22.9 million grants;
from international organizations (FY46-71), $26.8 million
Monetary conversion rate: 2 Guyana dollars=US$1
Fiscal year: calendar year','609855f4d1c675ba2eef2c76cc28bc84b3c4533ed70e08ac162e162f4142a74e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb98163aacacc0ff9befb65e7dc5572b3258b4361127df6b53aba460c582ecbe',1973,'HT','Haiti','economy',103,'GDP: about $420 million (1971), $80 per capita; real growth rate 1971 5.7%
Agriculture: main crops -- coffee, sugarcane, rice, corn, sorghum, pulses;
caloric intake, 1,850 calories per day per capita
Major industries: sugar refining, textiles, flour milling, cement manufacturing,
copper and bauxite mining, tourism, light assembly industries
Electric power: 62,000 kw. capacity (1971 est.); 120 million kw.-hr produced
(1971 est.), 24 kw.-hr. per capita
Exports: $47 million (f.o.b., 1971 est.); coffee, bauxite, light industrial
products, sugar, copper, sisal
Approved For Release 2004/09/15 : CIA4RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Imports: $63.5 million (f.0.b., 1970 est.); consumer durables, foodstuffs,
industrial equipment, petroleum products, construction materials
Major trade partners: U.S. 50% (1970 est.)
Aid:
economic -- from U.S., $34.1 million loans, $88.1 million grants (FY46-70);
international organizations, $28.2 million (FY49-71);
military -- U.S., $4.3 million (FY53-71), from other Western countries
(1960-70) $3.7 million
Monetary conversion rate: 5 gourdes=US$1
Fiscal year: 1 October - 30 September
GNP: $838 million (purchasing power parity estimate, 1971), $310 per capita; 77%
private consumption, 9% government consumption, 19% domestic investment; 2%
inventory, -7% net foreign balance (1970); real growth rate 1971, 2.5%
Agriculture: main crops -- bananas, coffee, corn, beans, cotton, sugarcane,
tobacco; caloric intake, 2,300 calories per day per capita (1964-65)
Fishing: exports $1.4 million (1970); imports $0.5 million (1970)
Approved For Release 2004/09/15! 4 CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA- - -
sean eanbiay: IA-RDP79-01051A000500010001-1
Major industries: agricultural processing, textiles, clothing, wood products
Electric power: 156,000 kw. capacity (1971); 350 million kw.-hr. produced
(1971), 116 kw.-hr. per capita
Exports: $182 million (f.o.b., est. 1971); bananas, coffee, corn, cotton, lumber,
minerals, beef
Imports: $194 million (c.i.f., est. 1971); manufactured products, machinery,
transportation equipment, chemicals, fuels
Major trade partners: exports -- U.S. 53%, West Germany 11%, CACM 11%; imports
-- U.S. 41%, CACM 25%, West Germany 5% Japan 8% (1970)
Aid: .
economic -- extensions from U.S. (FY46-70), $65.6 million loans, $54.8
million grants; from international or anizations (FY46-70), $132.6 million;
from other Western countries (1960-68), $5.3 million;
military -- assistance from U.S. (FY46-70), $8.1 million
Monetary conversion rate: 2 lempiras=US$1 (official)
Fiscal year: calendar year
GNP: $4 billion 1971 (est.), $960 per capita (est.)
Agriculture: agriculture occupies a minor position in the economy; main crops --
rice, vegetables, dairy products; less than 20% self-sufficient; food
Shortages -- rice, wheat
Major industries: textiles and clothing, tourism, plastics, electronics, light
metal products, food processing
Shortages: industrial raw materials, water, food
Approved For Release 2004/09/15 : UVA-RDP79-01051A000500010001-1
d For Rel 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY iconeiayerrey’ or Release /
Electric power: 1,810,000 kw. capacity (1972); 5.5 billion kw.-hr. produced
(1972), 1,341 kw.-hr. per capita
Exports: $2.9 billion (f.o.b., 1971), including $630 million reexports; principal
products clothing, plastic articles, textiles, electrical goods, wigs,
footwear, light metal manufactures
Imports: $3.4 billion (c.i.f., 1971)
Major trade partners: 1971 exports -- U.S. 37%, U.K. 15%, West Germany 7%; imports
-- Japan 24%, China 16%, U.S. 13%
Monetary conversion rate: HK$5.9=US$1
Fiscal year: 1 April - 317 March','e6f4f8de1ad8f36e0eed044ea08ea2af161b73f94398b2cb3bc41879613727d6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd0a57d49d571d0c02c59987157fe467a162ee2d034e140bd4e7596c3b92256e',1973,'HU','Hungary','economy',107,'GNP: $16.7 billion in 1971 (at 1970 prices), $1,610 per capita; 197] growth
rate 4.6%
Agriculture: normally self-sufficient; main crops -- corn, wheat, potatoes,
Sugar beets, wine grapes; caloric intake 3,140 calories per day
per capita (1970)
Major industries: mining, metallurgy, engineering industries, processed foods,
textiles, chemicals (especially pharmaceuticals)
Shortages: metallic ores (except bauxite), copper, high grade coal, forest
products
Crude steel: 3.11 million metric tons produced (1971), 300 kg. per capita
Approved For Release 2004/09/157 CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Exports: $2,500 million (f.0.b., 1971); 26% machinery, 23% industrial consumer
goods, 27% raw materials and semimanufactures, 24% food and raw materials
for the food industry (distribution for 1971)
Imports: $2,990 million (1971); 26% machinery, 9% industrial consumer goods,
54% raw materials and semimanufactures, 11% food and raw materials for the
food industry (distribution for 1971)
Major trade partners: $5,490 million (1971); 67% with Communist countries, 35%
with non-Communist countries
Monetary conversion rate: 10.81 forints=US$1 (arbitrary commercial); 27.63
forints=US$] {noncommercial )
Fiscal year: same as calendar year; economic data reported for calendar years','d0de38eaf380ce71e5fab84fe95c0a027e777a0a1134958b5baeeb1ee2c9bdb2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3967c228ea4e9c51c0f06937ad2b022f622b3ec2e72fb36d1c3a1a8b1f85d4e4',1973,'IS','Iceland','economy',111,'GNP: $591 million (1971), $2,830 per capita; 65.3% consumption, 32.5%
investment, 9.8% government, -7.6% net foreign balance (1971); 1971 growth
rate 9.20%, constant prices
Agriculture: cattle, sheep, dairying, hay, potatoes, turnips; food shortages --
grains, sugar, vegetable and other fibers; caloric intake, 2,900 calories
per day per capita (1964-66)
Fishing: catch 680,742 metric tons; exports $125.6 million (1971)
Approved For Release 2004/09/15 : CIASRDP79-01051A000500010001-1
09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont Approved For Release 2004/
Major industries: fish processing, aluminum smelting, diatomite production
Shortages: grain, fuel, wood, minerals, vegetable fibers
Electric power: 356,000 kw. capacity (i971); 1.6 billion kw.-hr. produced
(1971), 7,700 kw.-hr. per capita
Exports: $149.7 million (f.0.b., 1971)
aluminum, diatomite
Imports: $220.0 million (c.i.f., 1971)
petroleum, foodstuffs, textiles
Major trade partners: (1971) Exports: EFTA 33%, EC 11%, U.S. 39%, Communist
countries 8%; Imports: EFTA 43%, EC 26%, U.S. 9%, Communist countries 11%
Aid: economic -- U.S. authorized (1949-70) $89.3 million, $2.0 million
(1968) $2.3 million (1969), none in 1970, $1.2 million (1972); IBRD $30.0
million through December 1971
Monetary conversion rate: 88 kronur=US$1 (official)
Fiscal year: calendar year
> fish and fish products, animal products,
; Machinery and transportation equipment,
GNP: $54 billion in current prices (year ending 31 March 1972), less than $100
per capita; real growth (FY71), 3% est.
Agriculture: main crops -- rice, other cereals, pulses, oilseeds,
cotton, jute, sugarcane, tobacco, tea, and coffee; largely self-sufficient
in foodgrains, but caloric intake is still low and diet is deficient in
protein
est auc 1.9 million tons (FY71-72); exports $52 million (FY71-72), imports
0,000
Major industries: textiles, food processing
Crude steel: 6.3 million metric tons produced (FY71)
Electric power: 18,070,000 kw. capacity (1971); 68 billion kw.-hr. produced
(1971), 120 kw.-hr. per capita
Exports: $2 billion (f.o.b., FY71); tea, jute manufactures, iron ore, cotton
textiles, leather and leather products, iron and steel
Imports: $2.5 billion (c.i.f., FY71); machinery and transport equipment, chemicals,
iron and steel, grains and flour
Major trade partners: U.S., U.K., U.S.S.R. and Eastern Europe, Japan
Monetary conversion rate: 7.5 rupees=US$1 (official rate), now floating with
U.K. pound
Fiscal year: 1 April, stated year - 37 March','5c9e927ccf83def29681a4be7d4f1dced10b6c87d4827e7d335b17aa86a85c72','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be41480ec72534b834b737b5133c427b4c0b829d5bd791424713fc44d8a4eb48',1973,'ID','Indonesia','economy',114,'GNP: $9.4 billion (1970), less than $100 per capita; real average annual growth
(1965-70) 3.5% (est.)
Agriculture: subsistence food production, and smallholder and plantation
production for export; main crops -- rice, rubber, copra, other tropical
products; substantially self-sufficient; food shortage -- rice
Fishing: catch 1.2 million tons (1970); exports $4.5 million (1970), imports $0.3
million (1970)
Major industries: processing agricultural products and petroleum, textiles,
mining
Electric power: 1,225,000 kw. capacity (1971); 2.97 billion kw.-hr. produced (1971),
24 kw.-hr. per capita
Exports: $1,181 million (f.o.b., 1970); petroleum, rubber, tin, copra, tea, coffee,
tobacco, palm oi]
Imports: $1,145 million (f.0.b., 1970); rice, other foodstuffs, textiles, chemicals,
iron and steel products, machinery, transport equipment, consumer durables
Major trade partners: exports (1970) -- 16% U.S., 55% Japan, 4% Singapore, 9%
West Germany; imports -- 22% U.S., 55% Japan, 9% West Germany, 13% Singapore
Monetary conversion rate: 415 rupiah=US$1
Fiscal year: 1 April - 31 March
GNP: $12 billion (Iranian FY71-72 est.), $400 per capita; real GNP growth,
Iranian FY71-72, 14. % est.
Agriculture: wheat, barley, rice, sugar beets, cotton, dates, raisins, tea,
tobacco, sheep, and goats ‘~
Electric power: 2,400,000 kw. capacity (1971); 8.5 billion kw.-hr. produced
(1971), 280 kw.-hr. per capita
Exports: $356 million (non-oil, Iranian FY71-72); 89% petroleum; also carpets,
raw cotton, fruits, and nuts, hide and leather items, ores; Communist
countries (primarily U.S.S.R.) took about 31% of non-oil exports
Imports: $1,632 million (c.i.f., 1970); machinery, iron and steel products,
chemicals, pharmaceuticals, electrical equipment, Communist countries
supplied about 13% of commodity imports
Major trade partners: exports -- U.S., Japan, West Germany, U.S.S.R. and
other Communist countries; imports -- U.S., West Germany, U.K., Japan, U.S.S.R.
Monetary conversion rate: 75.75 rials=US$1
Fiscal year: 21 March - 20 March
GNP: $2,693 million in 1969, $300 per capita
Agriculture: dates, wheat, barley, rice, livestock; largely self-sufficient
in food
Major industry: crude petroleum (fourth largest producer in Middle East)
Electric power: 824,000 kw. capacity (1971); 3.5 billion kw.-hr. produced (1971),
350 kw.-hr. per capita
Exports: $71 million (f.o.b., 1971), not including oi1 revenue of $840 million
Imports: $756 million (c.i.f., 1971); 26% from Communist countries (1969)
Major trade partners: exports (non oi1) -- U.S. 7%, Western European countries 4%,
Communist countries 15%, Arab countries 54%, other 20%; imports -- U.S. 4%,
Western European countries 44%, Japan 3%, Communist countries 26%, Arab
countries 7%, other 16%
Approved For Release 2004/09/15 :''61A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-
ECONOMY (cont''d): 79-01051A000500010001-1
Monetary conversion rate: 1 Iraqi dinar=US$3.04 (freely convertible); 0.329
Iraqi dinar=US$1
Fiscal year: 1 April - 31 March
GNP: $4,552 million (1971), $1,540 per capita; 67% consumption, 22%
investment, 14% government; 3% net export of goods and services;
1971 real growth rate 3%
Agriculture: about 2/3 of agricultural area used for permanent hay and pasture;
main products -- livestock and dairy products, barley, potatoes, sugar beets,
wheat; 85% self-sufficient; food shortages -- grains, fruits, vegetables;
caloric intake 3,450 calories per day per capita (1968)
Fishing: catch 81,000 tons, $13.7 million (1970); exports of fish and fish products
$13.8 million (1971), imports of fish and fish products $4.6 million (1971)
Major industries: food products, brewing, textiles and clothing, machinery and
transportation equipment
Approved For Release 2004/09/15 661A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79- -
ane Reanaan P79-01051A000500010001-1
Shortages: coal, petroleum, timber and woodpulp, steel and nonferrous metals,
fertilizers, cereals and animal feeds, textile fibers and textiles
Crude steel: 67,000 metric tons produced in 1968, 20 kilograms per capita
Electric power: 1,600,000 kw. capacity (1971); 6,108 million kw.-hr. produced
(1971), 2,040 kw.-hr. per capita
Exports: $1,408 million (f.o.b., 1971); live animals, meat, textile products, v
clothing, machinery, dairy products, chemicals
Imports: $1,962 million (c.i.f., 1971); machinery, chemicals, textiles,
transportation equipment, petroleum, metal manufactures, cereals
Major trade partners: 14.5% EC, 5.4% West Germany, 62.7% EFTA, 58.4% U.K.,
8.2% U.S., 1.5% Communist countries (1970)
Aid: economic -- U.S., $191 million authorized (FY49-71), no activity (FY55-66) , ~
$44 million authorized (FY67-71), $12.6 million authorized in FY69, none
authorized in FY70-71; IBRD $30.0 million authorized (FY71)
Monetary conversion rate: 1 Irish pound=US$2.45 (average floating pound third
quarter 1972) (official)
Fiscal year: 1 April - 31 March
GNP: $108 billion (1971), $2,000 per capita; 63.6% consumption, 20.9% investment,
13.7% government, net foreign balance 1.8% (1971 provisional); 1971 provisional
growth rate 1.4%, 1963 constant prices
Agriculture: important producer of fruits and vegetables; main crops -- cereals,
potatoes, olives; 95% self-sufficient; food shortages -- fats, meat, fish,
and eggs; caloric intake, 3,100 calories per capita (1970)
Fishing: catch 353,100 metric tons (1969), $196,558,000 (1969); exports $8,142,000
(1969), imports $131,715 ,000 (1969)
Major industries: machinery and transportation equipment, iron and steel,
chemicals, food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 17.4 million metric tons produced (1971), 320 kilograms per capita
Electric power: 35.53 million kw. capacity (1971); 124.6 billion kw.-hr.
produced (1971), 2,297 kw.-hr. per capita
Exports: $16.1 billion (f.0.b., 1971); principal items -- machinery and
transport equipment, textiles, foodstuffs, chemicals
Imports: $17.0 billion (c.i.f., 1971); principal items -- machinery and
transport equipment, foodstuffs, ferrous and nonferrous metals, wool, cotton
Major trade partners: (1971) 21% blest Germany, 9% U.S., 14% France, 4% U.K.,
4% Belgium-Luxembourg, 5% Netherlands, 3% Switzerland; 44% EC; 12% EFTA; 6%
Communist countries
Aid:
economic -- U.S., $3,893 million (FY46-70), $121.8 million authorized FY70;
IBRD, $398 million authorized through FY70, none since FY65; International
Finance Corporation, $1 million authorized through FY70, none since FY60;
military -- U.S., $2,290 million (FY46-70), $38 million authorized in
FY68 (Export-Import Bank credits), none in FY69
Monetary conversion rate: 581.5 lira=US$1 (central rate)
Fiscal year: calendar year
GDP: $1.6 billion (1971), $360 per capita (1971); average annual growth
rate 1960-70, 8.3%
Agriculture: commercial -- coffee, wood, cocoa, bananas, pineapples, palm oi];
food crops -- corn, millet, yams, rice; other commodities -- cotton, rubber,
tobacco, fish; self-sufficient in most foodstuffs, but rice, sugar, and meat
imported
Fishing: catch 74,000 metric tons (1971); exports $2.6 million (1970), imports
$3.3 million (1970)
Approved For Release 2004/09/15 : clA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Major industries: food and lumber processing, oil refinery, automobile assembly
plant, textiles, soap, flour mill, matches, three small shipyards, fertilizer
plant, and battery factory
Electric power: 180,000 kw. capacity (1971); 540 million kw.-hr. produced (1971),
128 kw.-hr. per capita
Exports: $490 million (f.0.b., 1971); coffee, tropical woods, cocoa, 80% of total;
bananas, pineapples, palm oil
Imports: $443 million (c.i.f., 1971); consumer goods 44%, raw materials and fuels
8%, manufactured goods and semi-finished products, 48%
Major trade partners: France and other EC countries about 65%, U.S. 13%, Communist
countries about 1%
Aid:
economic -- France (1960-69) $312 million; EC $123 million, including 1971
commitments; U.S. (FY61-71), $96 million; others (1960-71), $76 million,
including $18.5 million comitted; no Communist aid programs
military -- non-Communist countries, $7.3 million (1954-67)
Monetary conversion rate: ] Communaute Financiere Africaine franc=0.02 French
francs; 255.78 CFA francs=US$1
Fiscal year: calendar year','46389f5abf6d78d1f364700d84bb75420e3e27e8ca8e4b12c9cb02eca6354455','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8701a49956b86218885ab1826149a25e7e8a181f205f75e15bbdf75accf6433',1973,'JM','Jamaica','economy',120,'GNP: $1,440 million est. (1971), $760 per capita; real growth rate 1970, 4%
Agriculture: main crops -- sugarcane, citrus fruits, bananas, pimento, coconuts,
coffee, cocoa
Major industries: bauxite, textiles, food processing, light manufactures, tourism
Electric power: 556,000 kw. capacity (1971); 1,680 million kw.-hr. produced
(1971), 840 kw.-hr. per capita
Approved For Release 2004/09/15 : QIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Exports: $370 million (f.o.b., 1971); alumina, bauxite, sugar, bananas, citrus
fruits and fruit products, rum, cocoa
Imports: $595 million (c.i.f., 1971); machinery, transportation and electrical
equipment, food, fuels, fertilizer
Major trade partners: exports -- U.S, 52%, U.K. 16%, Canada 8%, Norway 8%;
imports -- U.S. 43%, U.K. 19%, Canada 9% (1970)
Aid:
economic -- from U.S. (FY56-71), $67.2 million in loans; (AID $30.5 million,
Import-Export Bank $36.7 million), $41.0 million grants (AID technical
assistance $16.0 million, Food for Freedom $25.0 million); from international
organizations (FY46-71), $90.1 million; from other Western countries (1946-70),
$78.2 million;
military -- assistance from U.S. (FY63-70), $1.1 million
Monetary conversion rate: 1 Jamaican dollar=US$1.30
Fiscal year: 1 April - 31 March','4dd06da1a1274a2b36a340bb2e883ed743ae5f9257f5d44a5b564e1afb9ee3d5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2235ca28aea8243bce04ab5e6433305de4fde35070ec56a8426ffa33c954838',1973,'ET','Ethiopia','economy',124,'GNP: $570 million (1971 est.), $240 per capita
Agriculture: main crops -- cereals, fruits, vegetables, olive oi]; not self-
sufficient in many foodstuffs
Major industries: phosphate mining, petroleum refining, and cement
Electric power: 46,260 kw. capacity (1971); 131 million kw.-hr. produced (1971),
60 kw.-hr. per capita
Exports: $32 million (f.o.b., 1971); major items -- fruits and vegetables,
phosphate rock; Communist share 5% of total (1971)
Imports: $213 million (c.i.f., 1971); major items -- petroleum products, textiles,
‘ capital goods, motor vehicles, foodstuffs; Communist share 17% of total (1971)
economic -- U.S., $617 million economic assistance (FY51-70), of which $31
million loans, $585 million grants; technical assistance
military -- $191 million total from U.S. (July 1949-March 1971) including
$72 million in MAP grants
Monetary conversion rate: 1 Jordanian dinar=US$2.80, freely convertible; 0.357
Jordanian dinar=US$1
Fiscal year: 1 January - 31 December
GDP: $1,438 million at 1964 prices (1971), $120 per capita; 5.7% real growth
per year between 1970 and 1971
Agriculture: main cash crops -- coffee, sisal, tea, pyrethrum, cotton, livestock;
food crops -- corn, wheat, rice, cassava; largely self-sufficient in food
Fishing: $4.2 million (1970)
Major industries: small-scale consumer goods (plastic, furniture, batteries,
dat soap, agricultural processing, cigarettes, flour), oil refining,
cemen
Electric power: 198,000 kw. capacity (1971); 760 million kw.-hr. produced (1971),
62 kw.-hr. per capita
Approved For Release 2004/09/15 : GYR-RDP79-01051A000500010001-1
ECONOMY (cont Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Exports: $292.9 million (f.o.b., 1971); coffee, tea, livestock products, pyrethrum,
soda ash, wattle-bark tanning extract
Imports: $539.8 million (c.i.f., 1971); machinery, transport equipment, crude oil,
paper and paper products, iron and steel products, and textiles
Major trade partners: U.K. and EC, also Uganda and
Tanzania, which are part of East African Economic Conmunity
Monetary conversion rate: 1 Kenya shilling=US$0.14 (official); 7.143 Kenya
shillings=US$1
Fiscal year: 1 July - 30 June
COMMUNT CATIONS:
Railroads: 1,275 mi.; meter gage
Highways: 25,787 mi.; 1,824 mi. paved, 3,728 mi. gravel, 7,745 mi. improved earth,
about 12,490 mi. unimproved earth
Inland waterways: part of Lake Victoria and Lake Rudolph are within boundaries
of Kenya
Ports: 1 major, 3 minor
Merchant marine: 6 ships (1,000 GRT or over) totaling 16,200 GRT, 25,300 DWT;
includes 3 cargo, 1] tanker, 2 specialized carrier
Civil air: 10 major transport aircraft
Airfields: 266 total, 210 usable; 6 with permanent-surface runways; 1] with
runway over 12,000 ft., 1 with runways 8,000-11,999 ft., 4] with runways
4,000-7,999 ft.; 3 seaplane stations
Telecommunications: in top group of African systems; consists of radio-relay
links, open-wire lines, and radioconmunication stations; principal center
Nairobi, secondary centers Mombasa and Nakuru; 77,500 telephones; 774,000
ee and 28,850 TV receivers; 5 AM, 2 FM, and 3 TV stations; 2 submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 2,745,000; 1,335,000 fit for military service;
no conscription
Military budget: for fiscal year ending 30 June 1971, $16,392,000; about 5.0% of
ordinary budget
Approved For Release 2004789/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09) ) Ape PIATRA 79-01051A000500010001-1
PEOPLE''S REP.
OF CHINA
LAND:
47,000 sq. mi.; 17% arable and cultivated, 74% in forest,
scrub, and brush; remainder wasteland and urban
Land boundaries: 1,440 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,550 mi.
GNP: roughly $300 per capita (1971)
Agriculture: main crops -- rice, corn, vegetables; food shortages -- meat,
cooking oils; production of foodstuffs adequate for domestic needs at low
levels of consumption
Major industries: machine building, electric power, chemicals, mining, metallurgy,
textiles
Shortages: heavy machinery and equipment, bituminous and coking coal, petroleum,
rubber
Crude steel: about 2.6 million metric tons produced (1971), about 180 kilograms
per capita (C)
Electric power: 3.1 million kw. capacity (1972); 17.5 billion kw.-hr. produced
(1972), 1,164 kw.-hr. per capita (C
Exports: minerals, chemical and metallurgical products
Imports: machinery and equipment, petroleum, foodstuffs, coking coal
Major trade partners: total trade turnover about $850 million (1971); 14% with
non-Communist countries, 84% with Communist countries (53% with the U.S.S.R.)
Approved For Release 2004/09/15 ''1A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Monetary conversion rate: 2.37 won=US$1 (arbitrarily established)
Fiscal year: calendar year
GNP: $8.7 billion (1971), $270 per capita; real growth 11% (1965-71)
Agriculture: 50% of the population live on the land, but agriculture constitutes
27% of GNP; main crops -- rice, barley, wheat; not self-sufficient; food
shortages -- barley, wheat, dairy products, rice, corm
Fishing: catch 934,000 tons, $21] million (1970)
Major industries: textiles and clothing, food processing, chemical fertilizers,
chemicals, plywood, coal
Shortages: base metals, fertilizer, petroleum, lumber and certain food grains
Electric power: 3,060,000 kw. capacity (1972); 12.1 billion kw.-hr. produced
(1972), 372 kw.-hr. per capita
Exports: $1.1 billion (f.o.b., 1971); clothing and textiles, veneer and plywood,
silk, wigs
Imports: $2.4 billion (c.i.f., 1971)
Major trade partners: 1971 exports -- U.S. 50%, Japan 24%; imports -- Japan
40%, U.S. 28%
Aid:
economic -- U.S. (FY46-70), $5.3 billion extended; Japan (1965-70), $620
million committed;
military -- U.S. (FY46-70), $3.4 billion extended
Monetary conversion rate: 358.75 won=US$1 (floating-rate average value in 1971),
400 won=US$1 by end of June 1972
Fiscal year: calendar year
Agriculture: virtually none, dependent on imports for food; approx. 75% of
potable water must be distilled or imported
Major industries: crude petroleum production averaging 3.3 million b.p.d.
(includes Kuwait''s share of neutral zone) (1972); government revenues from
taxes and royalties on production, refining, and consumption $1,700 million
in 1972; refinery capacity est. at 504,000 bbls. per day (1970); other major
industries include fishing, processing of building materials, fertilizers,
chemicals, and flour
Electric power: 1,070,800 kw. capacity (1970); 2.64 billion kw.-hr. produced
(1972), 2,890 kw.-hr. per capita
Exports: $1,580 million (1970), of which petroleum accounted for about 98%;
nonpetroleum exports are mostly reexports, $74 million 1971 est.
Imports: $706 million (1971) exclusive of oi] company imports; major suppliers --
U.S., Japan, U.K., West Germany
Aid: $50 million loan from Export-Import Bank, 1967; $2.6 million from international
organizations (FY63-70); extended about $50 million
in credits to other Arab nations from 1961 to January 1969
Approved For Release 2004/09/15! 8€1A-RDP79-01051A000500010001-1
Approved For Rel 200 : - -
ECONOMY (cont''d)PP Vv elease 4/09/15 : CIA-RDP79-01051A000500010001-1
Monetary conversion rate: 1 Kuwaiti dinar=US$2.80 (freely convertible)
Fiscal year: 1 April - 31 March
GNP: $211 million, $70 per capita (1969 est.)
Agriculture: main crops -- rice (overwhelmingly dominant), corn, coffee, cotton
and tobacco; largely self-sufficient; food shortages (due in part to
distribution deficiencies) including rice
Fishing: catch data unavailable; imports fish and fish products 200 tons,
$128,000 (1970)
Major industries: tin mining, timber
Approved For Release 2004/09/15 : ¢BX-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Shortages: capital equipment, petroleum, transportation system
Electric power: 54,500 kw. capacity (1972); 211 million kw.-hr. produced (1972),
68 kw.-hr. per capita
Exports: $2.8 million (f.o.b., 1971); tin concentrates; forest products, coffee,
undeclared exports of opium significant but value unknown
Imports: $55.7 million (c.i.f., 1970); rice and other foodstuffs, petroleum
products, machinery, transportation equipment, textiles
Major trade partners: imports from Thailand, Japan, U.S., France, U.K., Indonesia,
Hong Kong; exports to Malaysia and Thailand; trade with Communist countries
insignificant; Laos a major transit point in world gold trade; gold imports
and approx. offsetting gold exports excluded from official trade data; value
of 1970 gold imports $46.6 million
Monetary conversion rate: 600 kip=US$1 (1971)
Fiscal year: 1 July - 30 June','8545ed9af41bfb72e4982ed44c839ae6cd431bfb8b4966c27193c6991c605812','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a79ae1efebfef8aba7f31171d0f8a561cfb12bf3a2d99f69cf88be5a44fbcdf3',1973,'LB','Lebanon','economy',128,'GNP: $90 million (1968), about $100 per capita
Agriculture: exceedingly primitive, mostly subsistence farming and livestock;
principal crops are corn, wheat, pulses, sorghum, barley
Major industries: none
Electric power: 2,820 kw. capacity (1971); 3 million kw.-hr. produced (1971),
3 kw.-hr. per capita
Exports: labor to South Africa (remittances $15 million in 1969); $5 million
(f.0.b., 1970), wool, mohair, wheat, cattle, diamonds, peas, beans, corn,
hides, skins
Imports: $32 million (f.o.b., 1970); mainly corn, building materials, clothing,
vehicles, machinery, POL
Approved For Release 2004/09/15 : GiN-RDP79-01051A000500010001-1
: ui = 01-1
ECONOMY (cont ''dppProved For Release 2004/09/15 : CIA-RDP79-01051A0005000100
Major trade partner: South Africa
Aid: economic aid; U.K. $9.4 million (plan FY71-75); other $17.5 million (plan
FY71-75); no military aid
Monetary conversion rate: Lesotho uses the South African rand; 1 SA rand=US$1.25;
0.80 SA rand=US$1 (Lesotho uses the South African Rand, which is linked to
the floating U.K. pound; the rand exchange rate fluctuated in the range of
$1.24-$1.26 during July-September 1972)
Fiscal year: 1 April - 31 March
eee billion (1970 est.), $1,500 per capita, approximately constant over
967-70
GDP: $3.5 billion (1970 est.), $1,800 per capita
Agriculture: main crops -- wheat, barley, olives, dates, citrus fruits, peanuts;
not self-sufficient in food
Major industries: petroleum production averaged 2.8 million b.p.d. (1971);
oil revenues for 1971 about $1.9 billion; food processing, textiles, handicrafts
Approved For Release 2004/09/15 :IGhA-RDP79-01051A000500010001-1
ECONOMY (confapproved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Electric power: 300,000 kw. capacity (1971); 800 million kw.-hr. produced (1971),
390 kw.-hr. per capita
Exports: $2,535 million (1970 at present conversion rate); over 99% petroleum
Imports: $594 million (1970)
Major trade partners: imports -- Italy, West Germany, U.S.; exports -- Italy,
West Germany, U.K., France
Aid: economic -- no Communist country assistance; U.S. aid extended $212.5
million (1949-71)
military -- arms obtained by cash purchase; chief suppliers France, U.S.S.R.,
Czechoslovakia; U.S. suspended since September 1969
Monetary conversion rate: 1 Libyan pound=US$3.04 (January 1972)
Fiscal year: 7 April - 31 March
Despite its small size and sparse natural resources, Liechtenstein has a
prosperous economy based primarily on small-scale light industry and farming.
Textiles, ceramics, precision instruments, pharmaceuticals, and canned foods
are the principal manufactures produced, almost entirely for export. Live-
stock raising and dairying are the main sources of farm income; cereals and
potatoes are the most important farm crops. The Liechtenstein economy is
tied closely to that of Switzerland in a virtual customs union. No national
accounts data are available.
Major trade partners: exports (1971) -- $96.8 million; 34% Switzerland, 34% EC,
49% EFTA
Electric power: 22,600 kw. capacity (1970); 55 million kw.-hr. produced (1970),
1,800 kw.-hr. per capita; power is exchanged with Switzerland, but net
exports average 35 million kw.-hr. yearly
GNP: $1,135 million (1971), $3,340 per capita; 60% consumption, 12% investment,
30% government, -2% net exports of goods and services; 1970 growth rate
0.7% at constant prices
Agriculture: mixed farming; main crops -- grains, potatoes, fodder beets; food
shortages -- sugar, bread grains, fats; caloric intake, 3,150 calories per
day per capita (1968-69)
Major industries: iron and steel, food processing, chemicals, metal products and
engineering, tires
Crude steel: 5.2 million metric tons produced (1971), about 15,160 kg. per capita
Electric power: 1,180,000 kw. capacity (1970); 2,364 million kw.-hr. produced
(1970), 6,912 kw.-hr. per capita
Exports: $794 million (f.o.b., 1971)
Imports: $737 million (c.i.f., 1971)
Major trade partners: Luxembourg and Belgium form an economic and customs union
and report their foreign trade jointly (see Belgium); Luxembourg''s principal
exports are iran and steel products; principal imports are coal and consumer
products; most foreign trade is with Germany, Belgium, and other EC countries
Aid: foreign aid to Luxembourg is included in aid to Belgium
Monetary conversion rate: 44.8159 Luxembourg francs=US$1 (central rate); under the
BLEU agreement, the Luxembourg franc is equal to the Belgian franc which
circulates freely in Luxembourg
Fiscal year: calendar year
Agriculture: main crops -- rice, vegetables; food shortages -- rice, vegetables,
meat; depends mostly on imports for food requirements
Major industries: textiles, fireworks
Electric power: 28,500 kw. capacity (1972); 75 million kw.-hr. produced (1972),
310 kw.-hr. per capita
Exports: $43 million (f.o.b., 1970); textiles and clothing, foodstuffs, fireworks
Imports: $67 million (f.o.b., 1970)
Major trade partners: exports -- Portuguese colonies 19%, Hong Kong 18%, West
Germany 15%; imports -- Hong Kong 65%, China 27%
Monetary conversion rate: 5.9 patacas=US$1 (December 1971)
Fiscal year: calendar year
Approved For Release 2004/09/15 : CRA}RDP79-01051A000500010001-1
COMMUNICATIONAPProved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Highways: 26 mi. paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
DEFENSE FORCES:
Military manpower: males 15-49, 69,000; 43,000 fit for military service
Defense is responsibility of Portugal
Approved For Release 2004/08/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01 :
ii 9/15, <, G-RPP79-01051000500010001-1
LAND:
WATER:
GNP: $888.5 million (1970), about $130 per capita; a real increase of 6% between
1969 and 1970
Agriculture: cash crops -- coffee, vanilla, sugar, tobacco, sisal, rice, cloves,
raphia; food crops -- rice, cassava, cereals, potatoes, corn, beans,
bananas, coconuts, and peanuts; animal husbandry widespread; self-
sufficient in foodstuffs, but some milk and cereals imported
eae aaa 69,000 metric tons (1970); exports $3.1 million, imports $700,000
Major industries: agricultural processing (meat canneries, soap factories,
brewery, tanneries, sugar refining), light consumer goods industries
(textiles, glassware), cement plant, auto assembly plant, paper mill, oil
refinery
Electric power: 58,000 kw. capacity (1971); 175 million kw.-hr. produced (1971),
25 kw.-hr. per capita
Exports: $145 million (f.0.b., 1970); coffee 27%, rice 8%, vanilla 9%, sugar
4%, petroleum products 4%, cloves 12%, mineral products (graphite, mica, and
chromite) 4%; agricultural and livestock products account for about 85% of
export earnings
Imports: $170 million (f.o.b., 1970); consumer goods 30%, foodstuffs 11%, primary
products (crude oil, fertilizers, metal products) 34%, capital goods 25% (1970)
Major trade partners: France (in 1970 accounted for 34% of exports and 55% of
imports); U.S., preferential tariffs to EC and franc zone countries; trade
with Communist countries remains a minute part of total trade
Monetary conversion rate: 255.78 Malagasy francs=US$1 (official); member of
French franc zone
Fiscal year: calendar year','5bf194eb3e1cf4345ae54a5853fdef2294fcf234ee0667d3573d9d6bd7e13d8d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2578d321dd97ad6c8d7cb1faefee8ff7901536ec19c21bbad8cf6509ac1f61f7',1973,'MW','Malawi','economy',132,'GDP: $362 million (1971), $80 per capita; average annual real growth rate
5.9% (1964-71)
Agriculture: cash crops -- tea, tobacco, peanuts, cotton, tung; subsistence
crops -- corn, sorghum, millet, pulses, root crops, fruit, vegetables, rice
Electric power: 39,000 kw. capacity (1971); 144 million kw.-hr. produced (1971);
30 kw.-hr. per capita
Major industries: agricultural processing (tea, tobacco, sugar), sawmilling,
cement, consumer goods
Exports: $76.1 million (f.o.b., 1971); tobacco, tea, groundnuts, cotton
Imports: $94.3 million (c.i.f., 1971); manufactured goods, machinery and transport
equipment, food, fuels
Major trade partners: exports -- U.K., Zambia, Rhodesia, U.S.; imports -- U.K.,
Rhodesia, South Africa
Aid:
economic -- U.K. provides both budgetary and development support, about
$96 million (1966-71); U.S. aid commitments, $26 million (1956-71);
military -- U.K., $0.9 million (1954-68)
Monetary conversion rate: 1 Malawi kwacha=US$1.30286 (middle rate)
Fiscal year: 1 April - 31 March
Approved For Release 2004/09/15 : C@PA-RDP79-01051A000500010001-1
r Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS PProved Fo
Railroads: 352 mi. (3''6" gage)
Highways: 6,610 mi.; 580 mi. paved; 500 mi. crushed stone, gravel, or stabilized
soil; 5,530 mi. earth
Inland waterways: Lake Nyasa (Lake Malawi), 800 route mi. and Shire River, 90 mi.
Ports: 2 minor
Civil air: 5 major transport aircraft
Airfields: 41 total, 39 usable; 1 with permanent-surface runway; 8 with
runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: the system is barely above average for African countries
and consists of thinly spread open-wire lines, radio-relay links, and
radiocommunication stations; principal centers are Blantyre and Zomba;
13,000 telephones; 107,000 radio receivers; 5 AM, 4 FM and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 981,000; about 495,000 fit for military service
Approved For Release 2004369/15 : CIA-RDP79-01051A000500010001-1
Approved For Release aaa a aa a
NOTE:
Malaysia, which came into being on 16 September 1963,
consists of West Malaysia, which includes 11 states
of the former Federation of Malaya, pilus East
Malaysia, which includes the 2 former colonies of
North Borneo (renamed Sabah) and Sarawak
LAND:
West Malaysia: 50,700 sq. mi.; 20% cultivated, 26%
forest reserves, 54% other
Sabah: 29,400 sq. mi.; 13% cultivated, 34% forest
reserves, 53% other
Sarawak: 48,300 sq. mi.; 21% cultivated, 24% forest
reserves, 55% other
Land boundaries: West Malaysia 315 mi., East Malaysia 1,110 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: West Malaysia, 1,285 mi., East Malaysia 1,620 mi.
GNP:
Malaysia: $3.9 billion (1970), $360 per capita; average annual real growth
(1966-70) 6%
Agriculture:
West Malaysia: mixed plantation and subsistence; main crops -- rubber, rice,
oil palm; 25% of rice requirements imported
Sabah: mainly subsistence; main crops -- rubber, coconut, rice; food deficit
-- rice
Sarawak: main crops -- rubber, pepper; food deficit -- rice
Fishing: catch 365,000 tons, $93.9 million (1970)
Major industries:
West Malaysia: rubber and oi1 palm processing and manufacturing, tin mining
and smelting, logging and processing timber, light consumer goods
Sabah: logging
Sarawak: agriculture processing, petroleum refining, logging
Electric power:
West Malaysia: 1,094,000 kw. capacity (1972); 3.85 billion kw.-hr. produced
(1972), 418 kw.-hr. per capita
Sabah: 64,600 kw. capacity (1972); 155 million kw.-hr. produced (1972); 221
kw.-hr. per capita
Sarawak: 59,300 kw. capacity (1972); 134 million kw.-hr. produced (1972),
132 kw.-hr. per capita
209
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Exports: $1,680 million (f.o.b., 1970); 40% rubber, 18% tin, 15% timber
Imports: $1,393 million (c.i.f. 1970)
Major trade partners: exports -- Singapore, Japan, U.S.; imports -- Japan, U.S.,
Singapore, China
Aid:
economic -- U.K. (1946-69) $260 million disbursed; Japan (1966-68) $50
million extended; IBRD (1959 - July 1970) $289 million (committed); U.S.
(1954-71) $87 million;
military -- U.S. (FY65-71) $19 million committed
Monetary conversion rate:
Malaysia: 2.82 Malaysian dollars=US$1
Fiscal year: calendar year
GNP: under $100 per capita
Agriculture: crops -- coconut and millet; shortages -- rice, wheat
Fishing: catch 32,000 tons (1970)
Major industries: fishing; some coconut processing
Electric power: 2,500 kw. capacity (1972); 8.7 million kw.-hr. produced (1972),
77 kw.-hr. per capita
Exports: $2.4 million (f.o.b., 1968); fish
Imports: $2 million (c.i.f., 1968)
Major trade partner: Ceylon
Aid: U.K. (1960-65), $1.4 million drawn; Ceylon (1967), $1 million committed
Monetary conversion rate: 6.39 rupees=US$1
Fiscal year: calendar year
GDP: about $280 million (FY71), per capita about $50
Agriculture: main crops -- millet, sorghum, rice, corn, peanuts; cash crops --
peanuts, cotton, livestock
Fishing: exports $1.4 million (1971)
Major industries: small local consumer goods and processing
Electric power: 18,400 kw. capacity (1971); 43 million kw.-hr. produced (1971),
8 kw.-hr. per capita
Exports: $37.6 million (f.o.b., 1971); livestock, peanuts, dried fish, cotton,
skins
Imports: $48.6 million (f.o.b., 1971); textiles, vehicles, petroleum products,
machinery, and sugar
Major trade partners: mostly with franc zone and Western Europe; also with U.S.S.R.,','eb90fd71e37343d4a0235f149bd45b4d53286deba09d1750bcf27992ec661a57','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87c3d89472e8b0f1ef0273229839c04d4db625a354d9cfd686f22a2223826373',1973,'CN','China','economy',133,'Approved For Release 2004/09/15 : GiR-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Monetary conversion rate: since December 1971, 511.57 Mali francs=US$1
Fiscal year: calendar year','2d61ee4b805ee8d889b25344e3afc4dd6432000f80042d5ef419051e44581bb8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b502cdcbe5ed4734ea8267999f16148c8353faf41bec986321332e04db69c84a',1973,'MT','Malta','economy',138,'GNP: $255 million (1970 current prices), $780 per capita; 71% private
consumption, 29% gross investment; 1970 growth rate 8% in current prices
Agriculture: overall, 20% self-sufficient; adequate supplies of vegetables, poultry,
milk and pork products; shortages in beef, grain, animal fodder, and fruits
at various seasons; main products -- potatoes, cauliflowers, grapes, wheat,
barley, tomatoes, citrus, cut flowers, green peppers, hogs, poultry, eggs
Major industries: ship repair yard, building industry, food manufacturing,
textiles, tourism
Shortages: most consumer and industrial needs (fuels and raw materials) must be
imported
Electric power: 115,000 kw. capacity (1971); 305 million kw.-hr. produced (1971),
907 kw.-hr. per capita
Exports: $38.2 million (1969); textiles, scrap metal, wine, agricultural
products, and footwear
Approved For Release 2004/09/15 :4tHA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Imports: $147.6 million (1969)
Major trade partners: U.K. 44%, Italy 15.7%; EFTA 48%; EC 28.2%; Communist
countries 2.5%; North and Central America 3.8%
Aid: economic -- U.S., $8.3 million (1949-70), of which $0.3 million authorized
in 1968, $1.7 million authorized 1969 and $0.1 million authorized in 1970;
U.K. Financial Agreement (loans and grants) 1964-74, $140 million; IBRD $6
million through 1970, none since 1964; U.N. Special Fund $2.1 million through
1970, none since 1966; U.N. Technical Assistance $1.1 million through 1970, of
which $0.1 million in 1970
Monetary conversion rate: 1 Maltese Pound=US$2.67 (official)
Fiscal year: 1 April - 31 March','51024c2f1354d4f7bcee3d074f490a0661ccf0d1bb6927b0635566215964acdf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fe09b6c561a87d0b7314073e1e30bddf69d477800f155c394390f87e2b79d46',1973,'MQ','Martinique','economy',142,'GDP: $287 million (1970 est.), $840 per capita; real growth rate 8% (1968, est.)
Agriculture: bananas, sugarcane, and pineapples
Major industries: agricultural processing, particularly sugar milling and rum
distillation; cement, oi] refining and tourism
Electric power: 26,400 kw. capacity (1970); 74 million kw.-hrs. produced (1970),
219 kw.-hrs. per capita
Exports: $30 million (f.0.b., 1970), bananas, sugar, rum, pineapples
Imports: $146 million (c.i.f., 1970), foodstuffs, clothing and other consumer
goods, raw materials and supplies, and petroleum
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Major trading partners: exports -- France 82%, Italy 9%, other 9%; imports --
France 70%, United States 6%, Netherlands Antilles 3%, Netherlands 3%, other
18% (1968)
Monetary conversion rate: 5.1157 francs=US$1
Fiscal year: calendar year','1db9889398fc82146c80ba3fe4ab260fc24206378555f09b1a7ca382bfb270ac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('385965ee0c4594891db277259e5d94751e64281b70c14d9c42ba0ecd8b4f4dab',1973,'MR','Mauritania','economy',146,'GDP: about $170 million (1968), about $150 per capita
Agriculture: most Mauritanians are nomads or subsistence farmers; main crops
-- livestock, small grains, dates; cash crops -- livestock, gum arabic
Fishing: catch, traditional river fishing, 15,000 metric tons (1969), traditional
sea fishing, 2,750 metric tons (valued at $437,000); fish supplied to processing
plants by foreign fishing fleets from France, Spain, Canary Islands using
Mauritanian waters; exports 21,090 metric tons, $7.3 million (1970)
Major industries: mining of iron ore, salt fishing, exploitation of copper
resources planned
Electric power: 36,000 kw. capacity (1971); 70 million kw.-hr. produced (1971),
57 kw.-hr. per capita
Exports: $74 million (f.o.b., ecu iron ore, fish, gum arabic
Imports: $42 million (c.i.f., 1969); sugar, cloth, tea, and fuels
Approved For Release 2004/09/15 : 4JA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Major trade partners: (trade figures not complete because Mauritania has a form
of customs union with Senegal and much local trade unreported) France and
other EC members, U.K., and U.S. are main overseas partners
Monetary conversion rate: 255.78 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: calendar year','2291e45722be15cccdd314d260ead4e59f2e226d4f59e3ad3224efed22a169ca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea3c47bdfffe2a4c8273324c626a2f51c879e4c9b1bddd92972db7527ba0605b',1973,'MC','Monaco','economy',153,'GNP: 55% tourism; 25%-30% industry (small and primarily tourist oriented); 10%-15%
registration fees and sales of postage stamps; about 4% traceable to the Monte
Carlo casino
Major industries: chemicals, food processing, precision instruments, glassmaking,
printing
Electric power: 8,000 kw. capacity (1971); 70 million kw.-hr. supplied by France
(1971), 2,900 kw.-hr. per capita
Trade: full customs integration with France, which collects and rebates Monacan
trade duties
Monetary conversion rate: 5.1157 francs=US$1 (central rate)','8d43cb86845af57d4251c6c63c0bfb25d40a5db7279ac024505dd9eb9654e88d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffe490d3b9c3c903b4af8bc21c8c8a4a00341f2cbde60c34bf82009415091656',1973,'MN','Mongolia','economy',157,'Agriculture: self-sufficient in animal products; main crops -- wheat, oats,
barley
Industries: processing of animal products and building materials; mining
Exports: animal and dairy products, fluorspar, woolen textiles, leather shoes,
glass, and paper
Imports: machinery and equipment, petroleum, cloth, coal, and building materials,
sugar, and tea
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 4 tugriks=US$1 (arbitrarily established)
Fiscal year: calendar year
GNP: $2.7 billion (1970, constant 1966 prices), about $170 per capita;
average annual growth 5.5% during 1970-7]
Agriculture: cereal farming and livestock raising predominate; main crops --
wheat, barley, citrus fruit, wine, vegetables, olives; some fishing
Major industries: mining and mineral processing (phosphates, smaller quantities
of iron, manganese, lead, zinc, and other minerals), food processing, textiles
Electric power: 858,000 kw. capacity (1971); 1.96 billion kw.-hr. produced
(1971), 127 kw.-hr. per capita
age $488 million (f.o.b., 1970); food products 51%, phosphates 23%, other
6%
Imports: $686 million (c.i.f., 1970); food 17%, raw material and semi-finished
goods 43%, equipment 24%, consumer goods 16%
Major trade partners: exports -- France 36%, West Germany 9%, Italy 5%, U.K. 5%,
U.S. 2%; imports -- France 31%, U.S. 14%, West Germany 8%, Italy 6% (1971)
Monetary conversion rate: 4.57 dirhams=US$1 (selling rate June 1972)
Fiscal year: calendar year
GNP: $1.3 billion (est. 1970), about $170 per capita
Agriculture: cash crops -- raw cotton, cashew nuts, sugar, tea, copra, sisal;
other crops -- corn, wheat, peanuts, potatoes, beans, sorghum, and cassava;
self-sufficient in food except for wheat which must be imported
Major industries: food processing (chiefly sugar, tea, wheat, flour, cashew
kernels); chemicals (vegetable 011, oilcakes, soap, paints); petroleum
products; beverages; textiles; nonmetallic mineral products (cement, glass,
asbestos, cement products); tobacco
Electric power: 232,000 kw. capacity (1971); 464 million kw.-hr. produced (1971),
64 kw.-hr. per capita
233
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont ‘Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Exports: $162 million (f.0.b., 1971); cotton, sugar, cashew nuts, mineral products,
timber products, tea, copra, petroleum products
Imports: $338 million (c.i.f., 1971); machinery and electrical equipment, cotton
textiles, vehicles, petroleum products, wine, iron and steel
Major trade partners: over one-third of foreign trade with Portugal; South Africa,
U.S., U.K., West Germany
Aid: from Portugal only
Monetary conversion rate: 27.25 escudos=US$1 (approximate realigned rate)
Fiscal year: calendar year
GNP: $28 million (1970), $4,000 per capita (est.)
Agriculture: negligible; almost completely dependent on imports for food, water
Major industries: mining of phosphates, about 2 million tons per year (1966)
Electric power: 8,300 kw. capacity (1972); 23 million kw.-hr. produced (1972),
3,286 kw.-hr. per capita
Exports: $17 million (f.0.b., 1968), consisting entirely of phosphates
Imports: $5 million (c.i.f., 1968)
Major trade partners: Australia, New Zealand, and United Kingdom
Monetary conversion rate: 1 Australian dollar=US$1.19 (official )
Fiscal year: 1 July - 30 June
GDP: $1 billion (1970), less than $100 per capita
Agriculture: over 90% of population engaged in agriculture; main crops -- rice,
corn, wheat, sugarcane, oilseeds; largely self-sufficient
Major industries: small rice, jute, sugar, and oilseed mills; match, cigarette,
and brick factories
Electric power: 57,000 kw. capacity (1972); 71 million kw.-hr. produced (1972),
6 kw.-hr. per capita
Approved For Release 2004/09/15 : &tA-RDP79-01051A000500010001-1
: CIA-RDP79-01051A000500010001-1
ECONOMY (cont 4NProved For Release 2004/09/15 :C
Exports: $55 million (FY69 est.); rice and other food products, jute, timber
Imports: $62 million (FY69 est.); manufactured consumer goods, food grains and
food products
Major trade partner: over 90% India
Aid: economic -- China (1956-70), $68 million extended, $55
million disbursed; U.S.S.R. (1959-70), $21 million extended, $19
million disbursed; U.S. (FY49-71), $164.6 million authorized; India
(through July 1966), $94 million authorized, $56 million disbursed (S)
Monetary conversion rate: 10.1] Nepalese rupees=US$1
Fiscal year: 15 July - 14 July','8209915c4fe512226e706680dfc0b709814d94bd9734a5b21bc09ce38c142470','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4fae5e2d992061eac8e6508bc2d61aed9f154feb9e5e6ce1a54fd1724745c4b',1973,'NE','Niger','economy',161,'GDP: $372 million (1969 est.), less than $100 per capita
Agriculture: commercial -- peanuts, cotton, livestock; main food crops --
millet, sorghum, niebe beans, vegetables
Major industries: cement plant, brick factory, rice mill, small cotton gins, oi]
presses, slaughterhouse, and a few other small light industries; uranium
production began in 1971
Electric power: 55,000 kw. capacity (1971); 47 million kw.-hr. produced (1971),
11 kw.-hr. per capita
Exports: $22.4 million (f.o.b., 1969); about 60% peanuts and related
products, rest largely livestock, hides, skins; exports badly understated
because much regional trade not recorded
Imports: $45.2 million (c.i.f., 1969); fuels, machinery, transport equip-
ment, foodstuffs, consumer goods (largely for European residents); sizable
imports unrecorded
Approved For Release 2004/09/15 : GI4A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Major trade partners: France (over 50%), other EC countries, Nigeria, UDEAC
ro countries, U.S.; preferential tariff to EC and franc zone countries
id:
economic -- France (1960 to mid-1967) $68 million; EC (1966-67) $51.3 million;
U.S. (FY62-71) $17.1 million; West Germany, Israel, Republic of China, and U.N.
have also extended aid;
military -- $2.8 million (1954-68)
Monetary conversion rate: 255.78 Communaute Financiere Africaine francs=US$1
(official )
Fiscal year: 1 October - 30 September
GDP: $6.8 billion (FY71-72 est.), about $100 per capita; 12% growth rate
FY71-72
Agriculture: main crops -- peanuts, cotton, cocoa, rubber, yams, cassava,
sorghum, palm kernels, millet, corn, rice; livestock; almost self-sufficient
Fishing: catch 156,000 metric tons (1970); imports $4.1 million (1970)
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Major industries: processing industries -- oi] palm, peanut, cotton, rubber,
petroleum, wood, hides, skins; manufacturing industries -- textiles, cement,
building materials, food products, footwear, chemical, printing, ceramics;
mining -- crude oil, natural gas, coal, tin, columbite
Electric power: 1,111,000 kw. capacity (1971); 1.7 billion kw.-hr. produced
(1971), 30 kw.-hr. per capita
Exports: $1,659 million (f.o.b., 1971); oi], peanuts, palm products, cocoa, rubber,
cotton, timber, tin
Imports: $1,507 million (c.i.f., 1971); machinery and transport equipment, manu-
factured goods, chemicals
Major trade partners: U.K., EC, U.S.
Monetary conversion rate: 1 Nigerian pound=US$3.04 (official)
Fiscal year: 1 April - 37 March
GNP: $15.2 billion (1971), $3,870 per capita; 51.2% consumption; 37.0% investment;
13.6% government; net foreign balance -1.8%; 1971 growth rate 5.0%, in
constant prices
Agriculture: animal husbandry predominates; main crops -- feed grains, potatoes,
fruits, vegetables; 40% self-sufficient; food shortages -- food grains, sugar;
caloric intake, 2,910 calories per day per capita (1968-69)
Approved For Release 2004/09/15 : @{8-RDP79-01051A000500010001-1
ECONOMY (cont Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Fishing: catch 2.8 million metric tons (1971), $243 million; exports $205 million
Major industries: food processing, wood pulp, paper products, metals, machinery,
chemicals, shipbuilding
Meader feed and bread grains, coal, petroleum and petroleum products, cotton,
woo
Crude steel: 863,000 metric tons produced (1971), 220 kilograms per capita
Electric power: 13,850,000 kw. capacity (1971); 64 billion kw.-hr. produced
(1971), 15,000 kw.-hr. per capita
Exports: $2,710 million (f.o.b., 1971); principal items -- fish and fish
products, metal and metal products, pulp and paper, chemicals, ships
Imports: $4,320 million (c.i.f., 1971); principal items -- ships, machinery,
fuels, foodstuffs
Major trade partners: 18.2% Sweden, 14.6% U.K., 14.7% West Germany, 6.4% U.S.,
P 6.8% Denmark; 25.6% EC; 45.8% EFTA; 3.7% Communist countries (1971)
id:
economic -- U.S., $403.9 million authorized (1946-71), $2.2 million in 1970,
$48.7 million in 1971; IBRD, $145 million authorized through 1970,
none since 1964; net official economic aid given to less developed areas and
multilateral agencies, $134.2 million (1960-69), $26.6 million (1968), $37.7
million (1969); $36.8 million (1970)
military -- U.S., $900 million authorized (1946-71), none since 1967
Monetary conversion rate: 6.645 kroner=US$1 (central rate)
Fiscal year: calendar year
GNP: at market prices in 1971 est. $266 million
Agriculture: based on subsistence farming (fruits, dates, cereals, cattle, camels,
fish) and trade
Major industries: petroleum discovery in 1964; production began in 1967; production
1971 equaled 289,000 b.p.d.; pipeline capacity 400,000 b.p.d.; revenue for
1972 about $134 million est.
Electric power: 25,890 kw. capacity (1971); 70 million kw.-hr. produced (1971),
100 kw.-hr. per capita
Exports: exports $239 million (1971); most of which is petroleum
Imports: $92 million (1971 est.)
Major trade partners: U.K., Gulf states, India, Australia, China, Japan
Aid: multilateral annual average 1967-69 $350,000
Monetary conversion rate: 1 Riyal Said=US$2.60 (as of March 1972)
Fiscal year: no budget year
GNP: $4.7 billion (FY72), less than $100 per capita; real growth (FY72) 1.7%
Agriculture: extensive irrigation; main crops -- wheat and cotton; largely
self-sufficient; foodgrain shortage due to drought
Fishing: catch 183,000 tons, $77 million (1969 ey
Approved For Release 2004/09/15 : AAZRDP79-01051A000500010001-1
ECONOMY (éontsdprereres For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Major industries: cotton textiles, food processing, engineering, chemicals,
natural gas
Electric power: 2,090,000 kw. capacity (1972); 8 billion kw.-hr. produced
(1972), 143 kw.-hr. per capita
Exports: $564 million (f.0.b., FY71); cotton (raw and manufactured)
Imports: $841 million (c.i.f., FY71) machinery, transport equipment, chemicals
Major trade partners: U.S., U.K., Japan, West Germany
Monetary conversion rate: 1] rupees=US$1
Fiscal year: 1 July - 30 June','ed28819244b93aaa4751c22eed12bca81b00d259d13e6bf2107ae51d47a92a6d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17d41241f47ca33311f531d93577a66d20100769abcaad326044deac0712cf68',1973,'PG','Papua New Guinea','economy',166,'GNP: $550 million (FY70 estimate), $230 per capita; real average annual growth
rate (1960-69) 7.5%
Agriculture: main crops -- coconuts, coffee, cocoa, tea
Major industries: sawmilling and timber processing, copper mining (Bougainville)
Electric power: 78,000 kw. capacity (1972); 242 million kw.-hr. produced (1972),
93 kw.-hr. per capita
Exports: $105.0 million (f.o.b., FY70); principal products -- coconut products,
coffee beans, cocoa beans, timber
Imports: $239.9 million (f.o.b., FY70)
Approved For Release 2004/09/15 : @6A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Major trade partners: Australia, U.K., Japan
Aid: economic -- Australia (FY46-69) $909 million extended; World Bank group
(1968-September 1969) -- $7.5 million committed
Monetary conversion rate: 0.84 Australian dollar=US$1
Fiscal year: 1 July - 30 June
GNP: $790 million (purchasing power parity estimate, 1971), $320 per capita;
88% consumption; 16% gross domestic investment; -4% net foreign balance (1971);
real growth rate 1971, 4.8%
Agriculture: main crops -- oilseeds, cotton, wheat, manioc, sweet potatoes,
tobacco, corn, rice, sugarcane; self-sufficient in most foods; caloric
intake, 2,580 calories per day per capita (1963-64); protein intake,
70 grams per day per capita (20 grams of animal origin)
Major industries: meat packing, oilseed crushing, milling, brewing, textiles,
light consumer goods, cement
Approved For Release 2004/09/15 283 A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Electric power: 150,000 kw. capacity (1971); 220 million kw.-hr. produced
(i971), 92 kw.-hr. per capita
Exports: $65 million (f.o.b., 1971); meat, timber, oilseeds, tobacco, cotton,
quebracho extract, hides, yerba mate
Imports: $70 million (f.o.b., 1971); foodstuffs, machinery, transport equipment,
engines, consumer durables, fuels and lubricants, textiles
Nevis trade partners: U.S. 21%, Argentina 21%, West Germany 9%, U.K. 8%
id:
economic -- extensions from U.S. (FY46-70), $79.3 million loans, $53.9 million
grants; from international organizations (FY46-70), $147.4 million; from other
Western countries (1960-70), $21.9 million
military -- assistance from U.S. (FY46-71), $13.7 million
Monetary conversion rate: 126 guaranies=US$1 (official rate)
Fiscal year: calendar year
GNP: $9.1 billion (purchasing power parity estimate, 1971), $640 per capita; 72%
private consumption, 10% public consumption, 13% gross investment (1970); 5%
net foreign balance; real growth rate 1971, 5.2%
Agriculture: main crops -- wheat, corn, potatoes, beans, barley, coffee, cotton,
Sugarcane; imports wheat, meat, lard and oils, rice, corn; caloric intake,
2,300 calories per day per capita (1964)
Fishing: catch 10.2 million metric tons (1971); exports $339.5 million (1970), of
which $303.9 million fishmeal, $32.6 million fish oi1, and $3.1 million
canned and frozen fish; imports $0.3 million (1969)
Approved For Release 2004/09/15 : @6A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : = iH
ECONOMY (cont''d): PP 15 : CIA-RDP79-01051A000500010001-1
Major industries: mining of metals, petroleum, fishing, textiles and clothing,
food processing, cement, auto assembly, steel, ship-building, metal
fabrication
Electric power: 1.8 million kw. capacity (1971); 220 million kw.-hr. produced
See 220 kw.-hr. per capita
Exports: $883 million (c.i.f., 1971); fish and fish products, copper, silver,
iron, cotton, sugar, lead, zinc, petroleum, coffee
Imports: $743 million (f.0.b., 1971); foodstuffs, machinery, transport equipment,
iron and steel semimanufactures, chemicals, pharmaceuticals
Major trade partners: exports -- U.S. 33%, Western Europe 42%, Japan 14%, Latin
America 6%; imports -- U.S. 32%, Western Europe 33%, Latin America 17%,
Japan 6% (1970)
Aid:
economic -- extensions from U.S. (FY46-71), $455.6 million loans, $189.9
million grants; from international organizations (FY46-70), $371.9 million;
from other Western countries (1960-66), $43.4 million; Communist countries
(1954-71) $126.5 million;
military -- assistance from U.S. (FY49-71), $141.3 million
Monetary conversion rate: 38.70 soles=US$1 (trade); 43.38 soles=US$1 (non-trade)
Fiscal year: calendar year','4eca447e7ea9a90f0187980ca22e3cf85f4aa5e332d2c3132cd571c32325d5a9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2cf4012faaf37f87ce2696f3f4d2435256182916a98bf586eae8341fb05dbc6',1973,'PH','Philippines','economy',170,'GNP: ae billion in 1971 at 1970 prices, $1,480 per capita; 1971 growth rate
5.1%
Agriculture: self-sufficient for minimum requirements; main crops -- grain,
sugar beets, oilseeds, potatoes, exporter of livestock products and sugar;
importer of grains; 3,200 calories per day per capita (1970)
Fishing: catch 498,000 metric tons (1971)
*Excludes armed forces and other classified categories of employment.
Approved For Release 2004/09/15 : @#8-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Major industries: chemistry, food processing, transportation equipment, machine
building, iron and steel, textiles, and shipbuilding
Crude steel: 12.7 million metric tons produced (1971), about 390 kg. per capita
Electric power: 14,814,000 kw. capacity (1971); 69.9 billion kw.-hr. produced
(1971), 2,125 kw.-hr. per capita :
Exports: $3,872 million (f.0.b., 1971}; 42% machinery and equipment, 36% fuels,
raw materials, and semimanufactures, 13% agricultural and food products,
9% light industrial products
Imports: $4,038 million (f.o.b., 1971); 38% machinery and equipment; 41% fuels,
raw materials, and semimanufactures; 14% agricultural and food products;
7% light industrial products
Major trade partners: $8,598 million; 65% with Communist countries, 35%
with West
Monetary conversion rate: 3.68 zlotys=US$1 (commercial); 22.08 zlotys=US$1
(noncommercial); old commercial rate 4.00 zlotys=US$1
Fiscal year: same as calendar year; economic data are reported for calendar
years except for caloric intake which is reported for the consumption year,
1} duly - 30 June','a8c6be65d423f012f5c1a069c9cfa29120d71304364359ba5f770b114a7a2e0e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4241ae82c459bcc3e287a3c61f308f6ad1c706c902b3d195fec8fffc941996d4',1973,'PT','Portugal','economy',174,'GNP: continental Portugal -- $6,956 million, $825 per capita; 75.6%
consumption, 16.9% investment, 14.7% government, -7.2 net exports of goods
and services (1971), growth rate 4.9% (1971) in 1963 constant prices
Agriculture: generally underdeveloped; main crops -- grains, potatoes, olives,
grapes for wine; food shortages -- sugar, wheat; caloric intake, 2,930
calories per day per capita (1968)
Fishing: catch 365,000 tons, $77.4 million; exports $46.6 million, imports $32.6
million, trade includes fish and fish products (1970)
Major industries: cotton textiles, cork processing, fish canning, petroleum
refining, pulp and paper, chemical fertilizer
Shortages: coal, petroleum, cotton, steel
Crude steel: .38 million metric tons produced (1970), 40 kg. per capita (1970)
Electric power: 2,820,000 kw. capacity (1971); 7,790 million kw.-hr. produced
(1971), 898 kw.-hr. per capita
Exports: $1,033 million (f.0.b. 1971); principal items -- cotton textiles, cork
and cork products, canned fish, wine, timber and timber products, resin
Imports: $1,772 million (c.i.f., 1971); principal items -- petroleum, cotton,
industrial machinery, iron and steel, chemicals
Major trade partners: (1970) 16.5% U.K., 12% West Germany, 6.1% France, 7.9%
U.S., 10.7% Angola, 6% Mozambique; 27.5% EC; 28.2% EFTA; .7% Communist
countries
Aid:
economic -- U.S., $197.4 million (1949-71), $17.1 million authorized FY71;
IBRD, $57.5 million authorized (1964-66), none since 1966; net official
aid to less developed areas and multilateral agencies $462 million (1961-70),
$79.5 million (1969), $57.1 million (1970);
military -- U.S., $328.1 million authorized (1949-71), $1.0 million
authorized in 1971
Monetary conversion rate: 27.25 escudos=US$1 (official)
Fiscal year: calendar year
GNP: $107 million (1969, in 1963 constant prices), $200 per capita
Agriculture: main crops -- palm oil, root crops, rice, coconuts, peanuts
Electric power: 1,200 kw. capacity (1971); 2 million kw.-hr. produced (1971),
4 kw.-hr. per capita
Exports: $3.6 million (f.o.b., 1969); principally peanuts, coconuts
Imports: $23.3 million (c.i.f., 1969); manufactured goods, fuels, transport
equipment, rice
Major trade partners: mostly Portugal, also immediate neighbors
Approved For Release 2004/09/15 : CIA4RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Aid: Portugal, small amounts
Monetary conversion rate: 27.25 escudos=US$1 (approximate realigned rate)
Fiscal year: probably is the calendar year
COMMUNICATIONS : s
Railroads: none
Highways: approx. 2,000 mi. (205 mi. bituminous, remainder earth)
Inland waterways: 994 mi.
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 63 total, 60 usable; 4 with permanent-surface runways; 9 with runways bd
4 ,000-7,999 ft.; 1 seaplane station
Telecommunications: limited telephone and telegraph service; 2,000 telephones;
8,300 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 115,000; 65,000 fit for military service
Defense is responsibility of Portugal
Rebel forces: 6,000-7,000 (est.) guerrillas all belong to the African Party for
the Independence of Guinea and Cape Verde (PAIGC)
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
276
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
PORTUGUESE TIMOR
LAND:
7,000 sq. mi.; 34% forest, 33% grassland, and 33%
cultivated
Land boundaries: 90 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 400 mi.','0656d83923c1f219657df1ae4d240a332f7d84095562a5814d617da450e5f56a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8322ae04dee94329af6fb23bf58ce9009b80cf51e3b14d8bd32a1579f699e393',1973,'QA','Qatar','economy',178,'GNP: $65 million (1969 est.)
Agriculture: farming and grazing on small scale; commercial fishing increasing
in importance; most food imported; rice and dates staple diet
Major industries: oi] production and refining; crude oi] production from onshore
and offshore averaged 440,000 bbls. per day in 1972; oi] revenues $200
million (est.) in 1972, representing 99% of government/royal
family income; major development projects include $7 million harbor at Ad
Dawhah, fertilizer plant, 2 desalting plants, refrigerated storage for
fishing, and a cement plant
Electric power: capacity 82,000 kw. (1971); 205 million kw.-hr. produced (1971),
1,500 kw.-hr. per capita
Exports: crude 011 dominates; reexports $4 million (1972)
Imports: approx. $124 million in 1972
Aid: multilateral annual average $170,000 (1967-69)
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.23 (as of March 1972)
Fiscal year: 1 April - 31 March','9113e7b8d9a7fc5eecbccef20ae2c6f8d6acf06855cea91956044baeb5848a8e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60b8ff7534ee016fad227273faca8c38f55e667149983263af56a9aa7e0bc5fd',1973,'IN','India','economy',182,'Agriculture: cash crops -- almost entirely sugarcane, small amounts of vanilla
and perfume plants; food crops -- tropical fruit and vegetables, manioc,
bananas, corn, market garden produce, also some tea, tobacco, and coffee;
food crop inadequate, most food needs imported
Major industries: 12 sugar processing mills, rum distilling plants, cigarette
factory, 2 tea plants, fruit juice plant, canning factory, a slaughterhouse,
and a number of small shops producing handicraft items
Electric power: 54,400 kw. capacity (1971); 108 million kw.-hr. produced (1971),
246 kw.-hr. per capita
Exports: $50 million (f.0.b., 1970); 90% sugar, 4% perfume essences, 5% rum and
molasses, 1% vanilla and tea
Imports: $162.6 million (c.i.f., 1970); manufactured goods, food, beverages,
and tobacco, machinery and transportation equipment, raw materials and
petroleum products
Major trade partners: France (in 1970 supplied 62% of Reunion''s imports, purchased
76% of its exports); Mauritius (supplied 12% of imports)
Approved For Release 2004/09/15 2&1A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Monetary conversion rate: 255.78 Communaute Financiere Africaine francs=US$1
(official)
Fiscal year: probably calendar year
id GDP: $1,628 million (1971), $290 per capita; real growth rate 6% (1965-71)
Approved For Release 2004/09/15 : CI#B@RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79- -
ECONOMY (cont''d): pp 01051A000500010001-1
Agriculture: main crops -- tobacco, corn, sugar, cotton; livestock; self-
sufficient in foodstuffs except wheat
Major industries: mining and steel, textiles
Electric power: 1,300,000 kw. capacity (1971); 6,804 million kw.-hr. produced
(1971}, 1,195 kw.-hr. per capita
Exports: $420 million (f.0.b., 1971), including net gold sales and reexports;
tobacco, asbestos, copper, meat, chrome, gold, nickel, clothing, sugar
Imports: $418 million (f.o.b., 1971); machinery, petroleum products,
wheat, transport equipment
Major trade partners: South Africa, Portugal, and Portuguese territories
Aid: no substantial military or economic aid
Monetary conversion rate: 1 Rhodesian dollar=US$1.40 (official); 0.714 Rhodesian
dollar=US$1
Fiscal year: 1 July - 30 June
GNP: ras billion in 1971 (at 1970 prices), $1,300 per capita; 1970 growth rate
9.9%
Agricuiture: net exporter; main crops -- corn, wheat, oilseed; livestock --
cattle, hogs, sheep; caloric intake, 3,000 calories per day per capita (1967-68)
Fish catch: 75,000 metric tons (1971)
Major industries: machinery, metals, fuels, chemicals, textiles, food processing,
timber processing
sak iron ore, coking coal, metallurgical coke, cotton fibers, natural
rubber
Crude steel: 6.7 million metric tons produced (1971), 330 kg. per capita
Approved For Release 2004/09/15 : CIA4RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Electric power: 8,324,000 kw. capacity (1971); 39.4 billion kw.-hr. produced
(1971), 1,910 kw.-hr. per capita
Exports: $2,325 million (f.0.b., 1971); 23% machinery and equipment; 43% fuels,
cs fe semifinished products; 16% foodstuffs; and 18% consumer goods
1970
Imports: $2,252 million (mixture f.o.b. and c.i.f., 1971); 40% machinery and
equipment; 50% fuels, raw materials, semifinished products; 5% foodstuffs ;
and 5% consumer goods (1970)
Major trade partners: $4,557 million in 1970; 45% non-Communist countries, 55%
Communist countries (1970)
Monetary conversion rate: 5.53 lei=US$1 (commercial); old rate 12 lei=US$1
(noncommercial); 16 lei=US$1 (tourist)
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year, 1 July -
30 June
GDP: $195 million (1970), $50 per capita
Agriculture: cash crops -- mainly coffee, tea, cotton, some pyrethrum; main
food crops -- bananas, cassava; stock raising; self-sufficiency increasing
but country still imports some foodstuffs
Major industries: mining of cassiterite (tin ore), agricultural processing, and
light consumer goods
Electric power: 21,460 kw. capacity (1971); 100 million kw.-hr. produced (1971),
28 kw.-hr. per capita
Exports: $24.1 million (f.o.b., 1971); mainly coffee, tea, pyrethrum, cassiterite
Imports: $35.8 million (c.i.f., 1971); textiles, foodstuffs, machines, equipment
Major trade partners: U.S., Belgium, Zaire
Aid: U.S., FY62-70, $8.1 million; Belgium, France, Germany, and Canada, FY64-67,
$33.4 million obligated
Monetary conversion rate: 92.105 Rwanda francs=US$1 (official)
Fiscal year: calendar year
Approved For Release 2004/09/15 -289/-RDP79-01051A000500010001-1
COMMUNICATIONGPPrOved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Railroads: none
Highways: 3,728 mi.; 1,243 mi. primary roads (only 6 mi. paved), 2,485 mi.
secondary roads; most roads improved or unimproved earth
Inland waterways: Lake Kivu navigable by steamers and barges
Civil air: no major transport aircraft
Airfields: 20 total, 15 usable; 2 with permanent-surface runways; 2 with
runways 4,000-7,999 ft., 1 with runway 8,000-117,999 ft.
Teleconmunications: telephone and telegraph limited; main center is Kigali;
1,800 telephones; 31,000 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 925,000; 445,000 fit for military service;
no conscription; 36,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1972, $4,753,000; about
20.5% of total budget
Approved For Release 2004299/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ST. CHRISTOPHER-NEVIS
LAND:
150 sq. mi.; 40% arable, 10% pasture, 17% forest, 33%
wasteland and built-on (1962)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi.
PEOPLE: COLOMBIA
Population: 66,000, average annual growth rate 1.2%
(April 60-70) BRAZIL
Ethnic divisions: mainly of African Negro descent
Religion: Church of England, other Protestant sects,
Roman Catholic
Language: English
Literacy: about 80%
Labor force: not available
Organized labor: 6,700
GDP: $15.2 million (1969), $230 per capita
Agriculture: main crops -- sugar on St. Christopher, cotton on Nevis
Major industries: sugar processing, salt extraction
Electric power: 110,000 kw. capacity (1971 est.); 230 million kw.-hr. produced
(1971 est.), 526 kw.-hr. per capita
Exports: $4.3 million (f.o.b., 1969); sugar, molasses, cotton, salt, copra
Imports: $9.6 million (c.1.f., 1969); foodstuffs, fuel, manufactures
Major trade partners: U.K. 45%, Canada 14%, U.S. 12% (1966)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1
Approved For Release 2004/09/15 261A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GDP: $28.2 million (1969), $230 per capita
Agriculture: main crops -- bananas, copra, sugar, cocoa, spices
Major industries: tourism, Time processing
Shortages: food, machinery, capital goods
Electric power: 4,600 kw, capacity (1971); 10 million kw.-hr. produced (1971
est.); 86 kw.-hr. per capita
Exports: $6.2 million (f.0.b., 1968); sugar, bananas, cocoa
Imports: $14.7 million (c.i.f., 1968); foodstuffs, machinery and equipment,
fertilizers, petroleum products
Major trade partners: U.K. 49%, Canada 9%, U.S. 8% (1964)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1 (6 October 1971)
GDP: $16.9 million (1969), $180 per capita
Agriculture: main crops -- bananas, arrowroot, coconut
Major industries: food processing
Electric power: 6,300 kw. capacity (1971); 18.9 million kw.-hr. produced (1971
est.), 235 kw.-hr. per capita
Exports: $3.7 million (f.0.b., 1968); bananas, arrowroot, copra, cotton
Imports: $1.0 million (c.i.f., 1968); fertilizer, flour, transportation
equipment, Tumber, textiles
Major trade partners: U.K. 39%, U.S. 10%, Canada 10% (1967)
Monetary conversion rate: 1.92 East Caribbean dollars=US$]
COMMUNTCATIONS:
Railroads: none
pie 550 mi.; 170 mi. paved; 180 mi. otherwise improved; 200 mi. unimproved
eart
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 3 total; 2 usable, with asphalt runway 4,800 ft.
Telecomnunications: islandwide fully automatic telephone system with 16,000
instruments; VHF interisland links to Barbados and the Grenadines; no data
on radio and 400 TV receivers; 2 AM stations
Approved For Release 2004/09/15 : 4\\-RDP79-01051A000500010001-1
Approved For Release 2004/09/19), GalATRRP 79-0105 1A000500010001-1
IGOSLAVIA
LAND:
24 sq. mi.; 74% cultivated, 22% meadows and pastures,
4% built-on
Land boundaries: 21 mi.
GNP: $3.6 billion (FY71 prelim.), $650 per capita
Agriculture: dates, grains, livestock; not self-sufficient in food
Major industries: petroleum production 5.8 million barrels per day (1972); est.
payments to Saudi Arabian Government, $2,100 million (est.), in
1971; cement production and small steel-rolling mill and oil refinery; several
other light industries, including factories producing detergents, plastic
products, furniture, etc.; PETROMIN, a semipublic agency associated with the
Ministry of Petroleum, has recently completed a major fertilizer plant
Electric power: 405,750 kw. capacity (1971); 1.38 billion kw.-hr. produced (1971),
250 kw.-hr. per capita
Exports: $3,209 million (f.0.b., 1971); 99% petroleum and petroleum products
Imports: $909 million (c.i.f., 1971); manufactured goods, transportation equipment,
construction materials, and processed food products
Major trade partners: exports -- U.S., Western Europe, Japan; imports -- U.S.,
Japan, West Germany
Monetary conversion rate: 1 Saudi riyal=US$0.25 as of March 1972 (IMF par value,
freely convertible)
Fiscal year: follows Islamic year; the 1970-71 Saudi fiscal year covers the
period 2 September 1970 through 20 August 1971
Approved For Release 2004/09/15 : Ef8-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500 :
COMMUNICATIONS: | PP 00010001-1
Railroads: 350 mi., 4''8 1/2" gage :
Highways: 7,767 mi.; 5,282 mi. bituminous, 2,485 mi. gravel and improved earth,
undetermined mileage of earth roads and tracks ;
Pipelines: crude oi], 1,435 mi.; refined products, 95 mi.; natural gas, 95 mi.
Ports: 3 major, 6 minor
Civil air: 24 major transport aircraft : ®
Airfields: 229 total, 69 usable; 19 with permanent-surface runways; 11] with
runways 8,000-11,999 ft., 4] with runways 4,000-7,999 ft.
Telecommunications: excellent international radio communications; poor domestic
wire service; 44,250 telephones; 87,000 radio and 120,000 TV receivers; 11
TV, 1 FM, and 4 AM stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 1,347,000; 935,000 fit for military service,
about 69,000 reach military age (18) annually
Military budget: for fiscal year ending 10 August 1973, $952.2 million; about
29.9% of total budget
Approved For Release 2064/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 SGA DP79-01051A000500010001-1
ND:
76,000 sq. mi.; 13% forested, 40% agricultural (12%
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 1,665 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing
122 n. mi.)
Coastline: 330 m.
GNP: about $100 per capita
Agriculture: animal husbandry, cardamon, foodgrains, tea, and oranges
Industry: food processing and handweaving
Foreign trade: conducted and regulated by India
Electric power: 2,700 kw. capacity (1972); 8 million kw.-hr. produced (1972),
40 kw.-hr. per capita
Exports: cardamon and preserved fruits
Imports: consumer goods
Major trade partner: India
Aid: India (1955-66) $19.8 million committed and drawn; India (1967-71) $13.3
million committed (excludes $17.3 million spent on the development of
military roads)
Monetary conversion rate: 7.5 Indian rupees = US$1 (official rate); now floating
with U.K. pound
Fiscal year: 1 April stated year - 31 March','33aa80ef6178824253caa3bda4184b0c6e51d2594325c79eba5a0a3d56cd427b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dbb1c5d03ddb4185c2250385816d59cd68688e42a5fe65e817f871eccbae9b3',1973,'SC','Seychelles','economy',186,'Agriculture: islands depend largely on coconut production and export of copra;
cinnamon, vanilla, and patchouli (used for perfumes) are other cash crops;
food crops -- small quantities of sweet potatoes, cassava, sugarcane, and
bananas; islands not self-sufficient in foodstuffs and the bulk of the
supply must be imported
Major industries: processing of coconut and vanilla, fishing, small-scale
manufacture of consumer goods, coir rope factory, tea factory
Electric power: 3,500 kw. capacity (1971); 9.2 million kw.-hr. produced (1971),
171 kw.-hr. per capita
Exports: $2.1 million (f.0.b., 1970); cinnamon (bark and oi1) and vanilla account
for almost 50% of the total, copra accounts for about 40%, the remainder
consisting of patchouli, fish, and guano
Imports: $10.1 million (c.i.f., 1970); food, tobacco, and beverages account for
about 40% of imports, manufactured goods about 25%, machinery and transport
equipment, petroleum products, textiles
Major trade partners: exports -- India, U.S.; imports -- U.K., Burma, India,
South Africa, Kenya, Australia
Approved For Release 2004/09/15 : JA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Aid: $1.2 million in aid in both 1965 and 1966 from U.K,
Monetary conversion rate: 5.4 Seychelles rupees=US$1
Fiscal year: calendar year','e6f8d6a4cb0c4bd597350859042556df5ba7388c034b6347d217b156462543b0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f401bd3714f680b62d9aac544932703587e9a8edb0049ed561e8a968915f14fa',1973,'SL','Sierra Leone','economy',190,'GDP: $425 million (FY70), approx. $170 per capita; real growth rate 1970, 2%-3%
Agriculture: main crops -- palm kernels, coffee, cocoa, rice, yams, millet,
cassava; much of cultivated land devoted to subsistence farming; food crops
insufficient for domestic consumption
Fishing: catch 23,000 metric tons (1971)
Major industries: mining -- diamonds, iron ore, bauxite, rutile; manufacturing
-- beverages, textiles, cigarettes, construction goods; 1 oil refinery
Approved For Release 2004/09/15 : CBR9RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Electric power: 57,000 kw. capacity (1971); 154 million kw.-hr. produced (1971),
58 kw.-hr. per capita
Exports: $107 million (f.0.b., 1971); 61% diamonds; iron ore, palm kernels, cocoa,
coffee
Imports: $122 million (c.i.f., 1971); machinery and transportation equipment,
manufactured goods, foodstuffs, petroleum products
Major trade partners: U.K., EC, Japan, U.S., Communist countries
Monetary conversion rate: 1 Jeone=US$1.30 (official); 0.768 leone=US$1
Fiscal year: 1 July - 30 June (since 1 July 1966)','fdc3ae0758c9003a3670a9085a665e58540641ac5271504ed6292a4d1bcaecdd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa788a6cb8c43a114a5b136c9d31145e39f0a3e87b7efdbb0c1a6407f1faa407',1973,'SG','Singapore','economy',194,'or ieee aa (1971), $1,100 per capita; 13% average annual real growth
1965-71
Agriculture: occupies a position of minor importance in the economy, self-sufficient
in pork, poultry, and eggs, must import much of its other food requirements;
“ major crops -- rubber, copra, fruit and vegetables
Fishing: catch 18,300 tons (1970), $6.5 million (1970)
Major industries: rubber processing and rubber products, processed food and
beverages, electronics, ship repair, entrepot trade
Electric power: 826,000 kw. capacity (1971); 3 billion kw.-hr. produced (1971),
1,395 kw.-hr. per capita
Exports: $1.8 billion (f.o.b., 1971); 60% reexports; petroleum products, rubber,
manufactured goods
Approved For Release 2004/09/15 : @9A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Imports: $2.8 billion (c.1.f., 1971}; 25% goods reexported; major retained imports
-- capital equipment, manufactured goods, petroleum
Major trade partners: exports -- Malaysia, Indonesia, U.S., Japan, U.K.3
imports -- Japan, Malaysia, U.S., U.K.
Aid: U.K. -- (1960-September 1969) $254 million disbursed; (1969-73) $120
million extended; IBRD -- (1963-June 1970) $114 million committed, $61 r
million disbursed
Monetary conversion rate: 2,82 Singapore dollars=US$1
Fiscal year: converted to 1 April - 31 March fiscal year on 7 April 1970;
formerly on calendar year basis
GDP: $137 million (1968 est.), about $50 per capita
Agriculture: mainly a pastoral country; main crops -- bananas, livestock,
sugarcane, cotton, cereals
Major industries: a few small industries, including a sugar refinery, tuna
and beef canneries, iron rod plant
Electric power: 9,000 kw. capacity (1971); 18 million kw.-hr. produced (1971),
6 kw.-hr. per capita
Exports: $39.3 million (f.o.b., 1971, est.); bananas, livestock, hides, skins
Imports: $57.6 million (c.i.f., 1971, est.); textiles, cereals, transport
equipment
Major trade partners: Italy and U.K.; Arab countries; $6.9 million imports from
Communist countries (1970 est.)
Approved For Release 2004/09/15 : Gi4-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (cont''d):
Monetary conversion rate: 6.9252 Somali shillings=US$1 (official)
Fiscal year: 1 January - 31 December','23191ab36ed363ef6b55f0e08bff4ca2c5253031af0f1c14514fe2688803048d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5a6a92e672ef653a754b8f8d980e03362ccc653881fc08141583d87e4859d59',1973,'ZM','Zambia','economy',201,'GNP: $1.7 billion (1970 est.), $410 per capita; real growth rate 11% between 1965
and 1970
Agriculture: main crops -- corn, tobacco, cotton; net importer of all major
agricultural products
Fishing: catch 48,400 metric tons, $4.2 million (1970); imports $5.2 million (1969) .
Major industries: copper mining and processing
Electric power: 788,200 kw. capacity (1971); 4,430 million kw.-hr. consumed
(1971), 1,030 kw.-hr. per capita
Exports: $679 million (f.o.b. 1971 provisional); copper, zinc, cobalt, lead,
tobacco
Imports: $553 million (f.o.b., 1971 provisional); consumer goods, machinery,
transport equipment, foodstuffs, fuels
Approved For Release 2004/09/15 : C¥43RDP79-01051A000500010001-1
pproved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY (eonteaye
Heras trade partners: U.K., South Africa, Japan, Western Europe
id:
economic -- China $200 million credit for Tanzam railroad (1970);
(1964-67) U.K. $63 million; IBRD $99 million (1970); U.S. $17 million (FY62-71);
U.S.S.R. $6 million;
military -- $9 million (1964-69), mainly U.K. and Canada
Monetary conversion rate: 1 Zambia kwacha=US$1.40 (official), 0.714 Zambia
kwacha=US$1
Fiscal year: calendar year','35cab3931a4ea7715c1c730dc62e20eaf8a172cf8ec20c65e165302095637d6c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b96d5c40a38f5bbf58e30f834135879653d54d87ec6ce398f90077953a2bc22',1973,'US','United States','economy',205,'GNP: $1,050 billion (1971); 63% consumption, 15% private investment, 22% government;
$5,070 per capita; 1971 growth rate 2.7% (constant 1958 dollars
Fishing: catch 2.7 million metric tons (1970); imports $832 million (1970); exports
$112: million (1970)
Crude steel: 119 million metric tons produced (1970), 530 kg. per capita
Electric power: 367.4 billion kw. capacity (1971); 1.7 billion kw.-hr.
produced (1971), 8,255 kw.-hr. per capita
Exports: $44,130 million (f.o.b., 1971); machinery and transport equipment,
chemicals, cereals, mineral fuels
Imports: $45,563 million (c.i.f., 1971); transport equipment, machinery, mineral
fuels, steel, nonferrous metals, metal ores
Major trade partners: (1970) Canada 24%, EC 18%, Japan 13%, U.K. 6%
Official development assistance (aid): obligations and loan authorizations (1971),
economic $4,811 million, military $4,436 million
Fiscal year: 1 July - 30 June','baff87f283a8602d9b440cc947ed297807e35e9d3b5a15f5d7f2be6e59a3d263','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08d0deba73c9287bf112ab66671fc1707a5368d917d09828b6bcb98bfd0158b5',1973,'','','economy',4,'GNP: $1.1 billion (FY72), well below $100 per capita; real growth rate probably
about 3% in FY72
Agriculture: agriculture and animal husbandry account for over 50% of GNP and
Occupy nearly 80% of the labor force; main crops -- wheat and other grains,
cotton, fruits, nuts; largely self-sufficient; food shortages -- wheat,
Sugar, tea
Major industries: cottage industries, food processing, textiles, cement, coal
mining
Electric power: 275,000 kw. capacity (1972); 470 million kw.-hr. produced
(1972), 26 kw.-hr. per capita
Exports: $85.7 million (f.0.b., FY70); fruits and nuts, karakul, natural gas,
carpets and rugs, wool, cotton
Imports: $117.4 million (c.i.f., FY70); wheat, textiles, sugar, tea, petrol eum,
transportation equipment
Major trade partners: exports -- U.S., U.K., U.S.S.R., and India; imports --
about 40% from U.S.S.R.
Monetary conversion rate: 45 Afghanis per US$1 (official); 77.94 Afghanis per
US$1 (December 1972)
Fiscal year: 21 March ~ 20 March','d14b206e1ecbb0c957dde76b4506bdac6d3ea2865a29f7036d4399b0dc0a53bb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e1a17feb854f377049d310012e91acc072536318ebfb0b54f840217c0b7d1eb',1973,'AL','Albania','economy',8,'GNP: $0.84 billion in 1970 (at 1970 prices), $390 per capita
Agriculture: food deficit area; main crops -- corn, wheat, tobacco, sugar beets,
cotton; food shortages -- wheat; caloric intake, 2,100 calories per day per
capita (1961/62)
Major industries: agricultural processing, textiles and clothing, lumber, and
extractive industries
Shortages: spare parts, machinery and equipment, wheat
Exports: $91 million (1970 est.); 1964 trade -- 55% minerals, metals, fuels;
17% agricultural materials (except foods); 23% foodstuffs (including
cigarettes); 5% consumer goods
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Imports: $159 million (1970 est.); 1964 trade -- 50% machinery, equipment, and
Spare parts; 16% minerals, metals, fuels, construction materials; 7%
fertilizers, other chemicals, rubber; 4% agricultural materials (except
foodstuffs); 16% foodstuffs; 7% consumer goods
Monetary conversion rate: 5 leks=US$1 (commercial); 12.5 leks=US$1 (noncommercial )
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year
1 July - 30 June','31538852d62a711d9b78d0aae23bed1ce8423f35b0709b578d58a2bee0604643','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78b8567d1fdfb7813b67a7debea5a3141ce6e14b16c1d36f13d33d54789ee673',1973,'DZ','Algeria','economy',13,'GNP: $4.0 billion (est. 1972), $260 per capita; real average annual increase
since 1968, 8%
Agriculture: main crops ~~ wheat, barley, wine, citrus fruits
Major industries: petroleum, Tight industries, natural gas, mining, petrochemical
and steel plants under construction
Electric power: 1,770,000 kw. capacity (1972); 2.7 billion kw.-hr. produced
(1972), 178 kw.-hr. per capita
Exports: $924 million (f.0.b., 1971); crude petroleum 75%, other items -- wine,
citrus fruit, iron ore, vegetables; to France 24%, West Germany 24%, Italy 8%,
U.S.S.R. 7%
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Imports: $1,326 million (c.i.f., 1971); major items -- capital goods 37%,
semi-finished goods 27%, foodstuffs 13%; from France 38%, West Germany 9%,
Italy 9%, U.S. 8%
Monetary conversion rate: 4.1] dinars=US$1 1973 par value
Fiscal year: calendar year
Agriculture: sheep raising; small quantities of tobacco, rye, wheat, barley,
oats, and some vegetables (only 25% of land can be used for agricul ture)
Major industries: tourism ($1 million annually), one cigarette factory (annual
output $1 million), handicrafts, smuggling (tobacco to France; manufactured
items, including automobiles and cameras, to Spain)
Shortages: food
Electric power: 25,000 kw. capacity (1972); 100 million kw.-hr. produced (1972),
370 kw.-hr. per capita; power is mainly exported to Spain and France
Major trade partners: Spain, France
r COMMUNICATIONS:
Railroads: none
Highways: about 60 mi.
Civil air: no major transport aircraft
Airfields: none
~ Telecommunications: 4nternational circuits to Spain and France; 2 AM, 1 FM, 1 TV
station; about 1,700 telephones; 8,000 radio receivers, 2,800 TV receivers
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
DEFENSE FORCES:
Andorra has no defe i
s nse forces; Spai +
BS neaded 55 Pain and France are responsible for protection
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
4/2
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GNP: $35.6 billion (1972), $3,650 per capita (1972), 60% consumption,
24% investment, 14% government, 2% net foreign balance; 1972 real GNP
growth rate 4.1%
Agriculture: livestock production predominates; main crops -- grains, beets,
potatoes; 80% self-sufficient in food; caloric intake, 3,230 calories per
day per capita (1969-70)
Fishing: catch 53,400 metric tons, $18,637,000 (1970); exports $18,118,000
(including Luxembourg, 1970), imports $85,139,000 (including Luxembourg, 1970)
Major industries: engineering and metal products, processed food and beverages,
chemicals, basic metals, textiles, and petroleum
Shortages: iron ore, nonferrous minerals, petroleum
Crude steel: capacity 16.6 million metric tons (1971); 14.5 million metric tons
produced (1972); 1,490 (1972 est.) kilograms per capita
Electric power: 8,029,000 capacity (1972); 35.6 billion kw.-hr. produced (1972),
3,500 kw.-hr. per capita
Exports: $15,576 million (f.o.b., 1972) motor vehicles, finished or senifinished
precious stones, textile products
Imports: $14,880 million (c.i.f., 1972), nonelectrical machinery, motor vehicles,
textiles, chemicals
Major trade partners: (Belgium-Luxembourg Economic Union, 1971) West Germany
25%, France 19%, Netherlands 17%, U.S. 7%, U.K. 5%, Italy 4%; EC 66%, EFTA
10%, Communist countries 2%
Aid:
economic -- received - U.S., $767.4 million authorized (FY46-71); $15.8 million
in FY70:
military -- received - $1,253.6 million authorized (FY46-71); net official
econonic aid to less developed areas and multilateral agencies -- $1,003.6
million (FY60-70), $119.6 million in 1970
Monetary conversion rate: 40 francs=US$1 (average for week beginning 26 March 1973,
floating)
Fiscal year: calendar year
GNP: $68.2 million (1970 est.), $560 per capita; 78% private consumption, 17%
public consumption, 36% domestic investment, -31% net foreign balance
(1968); real growth rate 1970 7.8%
Agriculture: main products -- citrus fruits, sugar, corn, rice, beans, livestock
products; net importer of food; caloric intake, 2,500 calories per day
per capita
Major industries: timber and forest products, food processing, furniture, rum,
soap
Electric power: 6,250 kw. capacity (1971); 19 million kw.-hr. produced
(1971), 160 kw.-hr. per capita
Exports: $20.8 million (f.o.b., 1970 est.); sugar, lumber, citrus fruits, fish
3]
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Imports: $34.7 million (c.i.f., 1970); vehicles, petroleum, food, textiles,
machinery
Major trade partners: exports -- U.S. 30%, U.K. 24%, Mexico 22%, Canada 13%;
imports -- U.S. 34%, U.K. 25%, Jamaica 7% (1970)
Aid: economic -~ U.S. (FY46-71), $5.8 million, grants; from international
organizations (1946-71), $1.4 million
Monetary conversion rate: $BH1.54=US$1 (official)
Fiscal year: calendar year
Agriculture: food deficit area; main crops -- potatoes, rye, wheat, barley, oats,
industrial crops; shortages in grain, vegetables, vegetable oil, beef;
caloric intake, 3,000 calories per day per capita (1970-71)
Fish catch: 332,000 metric tons (1971)
Major industries: metal fabrication, chemicals, light industry, brown coal,
uranium, and shipbuilding
Shortages: coking coal, coke, crude of1, rolled steel products, nonferrous metals
Crude steel: 5.67 million metric tons produced (1972), approx, 330 kg. per capita
Exports: $7,635 million (f.0.b. delivering country, 1972)
Imports: $7,248 million (f.0.b. delivering country, 1972)
Major trade partners: $14,883 million (1972); 38% Soviet Union, 34% other
Communist countries, 29% non-Communist countries
Monetary conversion rate: 2.8 DME=US$1 (new rate introduced in 1973; for 1972,
3.15 DME=US$1; prior to 1972, 4.2 DME=US$1)
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for the consumption year
1 July - 30 June
NOTE: foreign trade data converted at 1972 rate
GNP: $5.2 billion (1972), $1,740 per capita (converted at 1 Irish pound=US$2.50);
67% consumption, 22% investment, 14% government; -3% net export of goods
and services; 1972 real growth rate 3%
Agriculture: about 2/3 of agricultural area used for permanent hay and pasture;
main products -- livestock and dairy products, barley, potatoes, sugar beets,
wheat; 85% self-sufficient; food shortages -- grains, fruits, vegetables;
caloric intake 3,510 calories per day per capita (1970)
Fishing: catch 81,000 tons, $13.7 million (1970); exports of fish and fish products
$13.8 million (1971), imports of fish and fish products $4.6 million (1971)
Major industries: food products, brewing, textiles and clothing, machinery and
transportation equipment
159
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Shortages: coal, petroleum, timber and woodpulp, steel and nonferrous metals,
fertilizers, cereals and animal feeds, textile fibers and textiles
Crude steel: 67,000 metric tons produced in 1968, 20 kilograms per capita
Electric power: 1,480,000 kw. capacity (1972); 6.370 billion kw.-hr. produced
(1972), 2,100 kw.-hr. per capita
Exports: $1,317 million (f.o.b., 1971); live animals, meat, textile products,
clothing, machinery, dairy products, chemicals
Imports: $1,888 million (c.i.f., 1971); machinery, chemicals, textiles,
transportation equipment, petroleum, metal manufactures, cereals
Major trade partners: 13.9% EC, 5.4% West Germany, 60.9% EFTA, 56.2% U.K.,
9.7% U.S., 1.3% Communist countries (1971)
Aid: economic -- U.S., $191 million authorized (FY49-71), no activity (FY55-66),
$44 million authorized (FY67-71), $12.6 million authorized in FY69, none
authorized in FY70-71; IBRD $30.0 million authorized (FY71)
Monetary conversion rate: 1 Irish pound=US$2.48 (value floating pound 30 March 1973)
Fiscal year: 1 April - 31 March
Note: foreign trade data converted at 1 Irish pound=US$2.50
GNP: $118.6 billion (1972), $2,180 per capita; 63.6% consumption, 20.9% investment,
13.7% government, net foreign balance 1.8% (1971 provisional); 1972 growth
rate 3.2%, 1963 constant prices (converted 581.5 lire=US$1)
Agriculture: important producer of fruits and vegetables; main crops -- cereals,
potatoes, olives; 95% self-sufficient; food Shortages -- fats, meat, fish,
and eggs; caloric intake, 3,100 calories per capita (1970)
Fishing: catch 243,100 metric tons (1971), $196,558,000 (1969); exports $16 million
(1971), imports $120 million (1971) (converted at 618.25 lire=US$1)
Major industries: machinery and transportation equipment, iron and steel,
chemicals, food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 17.4 million metric tons produced (1971), 320 kilograms per capita
Electric power: 37,000,000 kw. capacity (1972); 128 billion kw.-hr. produced
(1972), 2,300 kw.-hr. per capita
Exports: $18.6 billion (f.0.b., 1972); principal items -- machinery and
transport equipment, textiles, foodstuffs, chemicals
Imports: $19.3 billion (c.i.f., 1972); principal items -- machinery and
transport equipment, foodstuffs, ferrous and nonferrous metals, wool, cotton
Major trade partners: (1971) 21% West Germany, 9% U.S., 14% France, 4% U.K.,
4% Belgium-Luxembourg, 5% Netherlands, 3% Switzerland; 44% EC of six;
hear EFTA; 6% Communist countries
id:
economic -- U.S., $3,974 million (FY46-71), $82.9 million authorized FY71;
IBRD, $398 million authorized through FY71, none since FY65; International
Finance Corporation, $1 million authorized through FY71, none since FY60;
military -- U.S., $2,452 million (FY46-71), $38 million authorized in
FY70 (Export-Import Bank credits), none in FY71
Monetary conversion rate: commercial and financial lire floating; value on
30 March 1973 -- .1696 cents=1 commercial lire and .1720 cents=1 financial lira
Fiscal year: calendar year
Nate: foreign trade data converted at 581.5 lire=US$]
GDP: $1.6 billion (1971), $360 per capita (1971); average annual growth
rate 1960-70, 8.3%
Agriculture: commercial -- coffee, wood, cocoa, bananas, pineapples, palm oil;
food crops -- corn, millet, yams, rice; other commodities -- cotton, rubber,
tobacco, fish; self-sufficient in most foodstuffs, but rice, sugar, and meat
imported
Fishing: catch 74,000 metric tons (1971); exports $2.6 million (1970), imports
$3.3 million (1970)
Major industries: food and lumber processing, oi] refinery, automobile assembly
plant, textiles, soap, flour mill, matches, three small shipyards, fertilizer
plant, and battery factory
167
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Electric power: 238,900 kw. capacity (1972); 788 million kw.-hr. produced (1972),
157 kw.-hr. per capita
Exports: $490 million (f.0.b., 1971); coffee, tropical woods, cocoa, 80% of total;
bananas, pineapples, palm oi1 :
Imports: $443 million (c.i.f., 1971); consumer goods 44%, raw materials and fuels
8%, manufactured goods and semi-finished products, 48%
Major trade partners: France and other EC countries about 65%, U.S. 13%, Communist
countries about 1%
Aid:
economic -- France (1960-69) $312 million; EC $123 million, including 1971
commitments; U.S. (FY61-71), $96 million; others (1960-71), $76 million,
including $18.5 million comitted; no Communist aid programs
military -- non-Communist countries, $7.3 million (1954-67}
Budget: 1972 est. -- revenues $369.1 million, current expenditures $280.3 million,
investment expenditures $136.4 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; 255.785 CFA francs=US$1 as of February 1973 (currency floating since
February 1973)
Fiscal year: calendar year
GNP: $45.6 billion (1972), $3,420 per capita; 57% consumption, 20%
investment, 21% government; 2% foreign balance; 1971 growth rate 4%, in
constant prices
Agriculture: animal husbandry predominates; main crops -- horticultural crops, »
grains, potatoes, sugar beets; food shortages -- grains, fats, oi1s
Fishing: catch 297,012 metric tons, $93 million (1971); exports 270,901 metric
tons, imports 208,839 metric tons (1971)
Major industries: food processing, metal and engineering products, electrical and
electronic machinery and equipment, chemicals, and petroleum products
Shortages: crude petroleum, raw cotton, base metals and ores, pulp, pulpwood,
lumber, feedgrains, and oilseeds
Crude steel: 5 million metric tons produced (1971), 380 kilograms per capita
Electric power: 10,900,000 kw. capacity (1972); 48 billion kw.-hr. produced
(1972), 3,400 kw.-hr. per capita
Exports: $15,065 million (f.0.b., 1971); foodstuffs, machinery, transportation
equipment, consumer manufactures, chemicals, petroleum products, textiles
Imports: $16,729 million (c.i.f., 1971); machinery, transportation equipment,
consumer manufactures, crude petroleum, foodstuffs, chemicals, raw cotton,
base metals and ores, pulp
Major trade partners: (1971) 52% EC, 36% W. Germany, 16% Belgium-Luxembourg,
15% EFTA, 8% U.S.
Aid:
economic -- (received) U.S., $1,307 million authorized (FY46-71); none
since FY58; IBRD, $236 million authorized (FY46-70), none since 1958; *
military -- (received) U.S., $1,240 million authorized (FY49-71), none since
FY65; net official aid given to less developed areas and multilateral
agencies -- $1,005 million (FY60-70), $200 million (FY70)
Monetary conversion rate: 2.920 guilders=US$1 (March 1973, floating)
Fiscal year: calendar year
ie
GNP: $34.0 billion; $1,010 per capita (1971); 68.5% consumption, 24.3% investment,
10.4% government; -3.2% net export of goods and services (1969); 1971 (est.)
real growth rate 4.7%, in 1964 constant prices
Agriculture: main crops -- cereals, oranges, grapes for wine, potatoes, olives,
sugar beets; virtually self-sufficient in good crop years; caloric intake,
2,750 (1969-70) calories per day per capita
Fishing: catch 1.5 million tons, $378 million (converted at 70 pesetas=US$1)
(1970); exports $78.7 million (1971 fish and fish products); imports $36.4
million (1971 fish and fish products}; imports and exports converted at 68.76
pesetas=US$1
Major industries: food processing, textiles and apparel (including footwear),
metal manufacturing, chemicals, shipbuilding
Shortages: crude petroleum
Crude steel: 9.5 million metric tons produced, 275 kilograms per capita (1972)
Electric power: 21.8 million kw. capacity (1972); 64.0 billion kw.-hr. produced
(1972), 1,800 kw.-hr. per capita
Exports: $3,813 million (f.o.b., 1972); principal items -- oranges and other
fruits, iron and steel products, textiles, wines, mercury, ships, canned
fruits, vegetables
Imports: $6,805 million (c.i.f., 1972); principal items -- machinery and
transportation equipment, petroleum and petroleum products, grains, cotton,
iron and steel
Major trade partners: (1971) 16.0% U.S., 11.9% West Germany, 10.3% France,
7.9% U.K., 5.7% Italy, 3.4% Netherlands; 33.7% EC; 15.8% EFTA; 8.7% Latin
America; 1.5% Eastern European countries and U.S.S.R.
Aid:
economic -- U.S., $1,657.5 million authorized (FY49-71), $14.6 million
authorized (FY71), IBRD, $326.9 million authorized (FY64-71), $102.7 million
authorized (FY71); military -- U.S., $758.7 million authorized (FY53-71),
$25.0 million authorized in FY71
Monetary conversion rate: 58.0294 pesetas=US$1 (1973); 1 peseta=US$0.0172
Fiscal year: calendar year
Note: foreign trade figures converted at 64.30 pesetas=US$1
314
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Agriculture: practically none; some barley is grown in nondrought years; fruit
and vegetables in the few oases; food imports are essential; camels, sheep,
and goats are kept by the nomadic natives; cash economy exists largely for
the garrison forces
Major industries: confined to fishing and handicrafts; exploitation of huge
phosphate deposit is planned
Shortages: water
Electric power: 522 kw. capacity (1972); 0.8 million kw.-hr. produced (1972),
10 kw.-hr. per capita
Exports: $445,600 (1968); dried fish, goatskins
Imports: $1,443,000 (1968); fuel for fishing fleet, foodstuffs
Major trade partners: monetary trade largely with Spain and Spanish possessions
Aid: small amounts from Spain
Monetary conversion rate: 58.03 pesetas=US$1 (official), set February 1973
aN a billion (1972 current prices), $170 per capita; real growth rate 2.5%
1972
Agriculture: agriculture accounts for about 35% of GNP; main crops -- rice,
rubber, tea, coconuts; 60% self-sufficient in food; food shortages -- rice,
wheat, sugar, fish
Fishing: catch 190,000 metric tons, $64 million (1970); exports $0.6 million,
imports $11.7 million (1969)
Major industries: processing of rubber, tea, and other agricultural commodities;
consumer goods manufacture
Electric power: 287,000 kw. capacity (1972); 950 million kw.-hr. produced
(1972), 73 kw.-hr. per capita
Exports: $327.2 million (f.o.b., 1971); tea, rubber, coconut products
Imports: $333.6 million (c.i.f., 1971), machinery and equipment, sugar, flour,
rice, textiles, and clothing
Major trade partners: (1971) exports -- U.K. 19.8%, China 12.9%, U.S. 8.6%,
Australia 3.5%, Canada 1.9%, Japan 2.8%, U.S.S.R. 5.0%; imports -- U.K. 22%,
China 9.6%, India 7.9%, Australia 3.4%, U.S. 5.3%, Japan 7.2%, USSR 3.2%
Monetary conversion rate: 6.68 rupees=US$1 (effective December 1972)
Fiscal year: 1 January - 30 December (starting 1973)
GNP: $30.0 billion (1972), $4,710 per capita (1972); 57% consumption, 29%
investment, 12% government, net foreign balance 2% (1971); 1972 growth rate
4.7%, constant prices
329
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Agriculture: dairy farming predominates; less than 50% self-sufficient; food
shortages -- fish, refined sugar, fats and oils (other than butter), grains,
eggs, fruits, vegetables, meat; caloric intake, 2,990 calories per day per
capita (1967-68 est.)
Major industries: machinery, chemicals, watches, textiles, precision instruments
Shortages: practically al] important raw materials except hydroelectric energy
Crude steel: 453,000 metric tons produced (1969), 70 kg. per capita
Electric power: 11,216,000 kw. capacity (1972); 39.3 billion kw.-hr. produced
(1972), 5,200 kw.-hr. per capita
Exports: $6.8 billion (f.o.b., 1972); principal items -- machinery and equip-
ment, chemicals, precision instruments, textiles, foodstuffs
Imports: $8.4 billion (c.i.f., 1972); principal items -- machinery and trans-
portation equipment, metals and metal products, foodstuffs, chemicals,
textile fibers and yarns
Major trade partners: West Germany 23%, France 11%, U.S. 8%, Austria 52%, Italy
9%, U.K. 8%; EC 50%; EFTA 20%; Communist countries 4% (1972)
Aid: some disbursed; none received .
Monetary conversion rate: 3.24 Swiss francs=US$1 (March 1973, floating)
Fiscal year: calendar year
GDP: $2.1 billion (1972), $310 per capita; real GDP growth rate 14% 1972 est.
Agriculture: main crops -- cotton, wheat, barley and tobacco; sheep and goat
raising; self-sufficient in most foods in years of good weather
Major industries: textiles, petroleum (119,000 BPD. production, refining
capacity 54,000 bbls. per day, 1971) food processing, everages, tobacco
331
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d)
Electric power: 360,000 kw. capacity (1972); 722 million kw.-hr. produced
(1972), 110 kw.-hr. per capita
Exports: $247 million (f.o.b., 1972); cotton, fruits and vegetables, grain,
wool, and livestock
Imports: $550 million (c.i.f., 1972 est.); machinery and metal products,
textiles, fuels, foodstuffs
Major trade partners: exports -- Italy and U.S.S.R.; imports -- Lebanon,
Italy, U.S.S.R., China, U.S.
Budget: 1972 est. -- revenues $415 million, expenditures $565 million
Monetary conversion rate: 3.82 Syrian pounds=US$1 (controlled rate); 4.32 Syrian
pounds=US$1 (free rate) (February 1973)
Fiscal year: calendar year
Mainland:
GDP: $1,138 million at 1966 prices (1971), about $80 per capita; growth rate in
constant 1966 prices for 1970-71 4.5%
Agriculture: main crops -- cotton, coffee, sisal on mainland; largely self-
sufficient in food
Fishing: catch 195,000 metric tons, $15.7 million; exports $2.2 million, imports
$554,000 (1970)
Major industries: primarily agricultural processing (sugar, beer, cigarettes,
sisal twine), diamond mine, oil refinery, shoes, cement, textiles, wood
products
Electric power: 122,840 kw. capacity (1972); 460 million kw.-hr. produced (1972),
34 kw.-hr. per capita
Exports: $279 million (f.0.b., 1971); coffee, cotton, sisal, cashew nuts, meat,
diamonds, cloves, tobacco, tea
Imports: $382 million (c.i.f., 1971); manufactured goods, machinery and transport
equipment, cotton piece goods, crude oi], foodstuffs (mainly for Zanzibar)
Major trade partners: exports -- China, U.K., Hong Kong, India, Kenya, U.S.;
imports -- U.K., China, Kenya, West Germany, U.S.,° Japan
Monetary conversion rate: 1 Tanzanian shilling=US$0.14; 7.143 Tanzanian
shillings=US$1
Fiscal year: 1 July - 30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops -- cloves, coconuts
Industries: agricultural processing
Electric power: see Tanganyika (above)
Exports: $12.6 million (1968); cloves and clove products, coconut products
Imports: $5.6 million (1968); mainly foodstuffs and consumer goods
Major trade partners: imports -- China, Japan, and mainland Tanzania;
exports -- Singapore, China, Hong Kong, Indonesia, India, Pakistan
Aid: U.K. principal source of aid until 1964; China is currently major source
Exchange rate: 1 Tanzanian shilling=US$0.14; 7.143 Tanzanian shillings=US$1
Fiscal year: 1 July - 30 June
GDP: $7.4 billion (1972 est. in current prices), $200 per capita; estimated 4%
real growth in 1970
Agriculture: world''s largest rice exporter; main crops -- rice, rubber,
corn; almost 100% self-sufficient in food
Fishing: catch-1.63 million tons, (1971)
Major industries: agricultural processing, textiles, wood and wood products,
cement, tin mining; non-Communist world''s third largest tin producer
Shortages: fuel sources, including coal and petroleum
Electric power: 1,615,000 kw. capacity (1972); 6.2 billion kw.-hr. produced
(1972), 171 kw.-hr. per capita
Exports: $1,089 million (f.0.b., 1972); rice, corn, rubber, tin, cassava, kenaf
Imports: $1,455 million (c.i.f., 1972); excluding U.S. military imports;
machinery and transport equipment, textiles, fuels and lubricants, base
metals, chemicals
335
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partners: exports -- Japan, U.S., Singapore, Hong Kong, Netherlands,
Malaysia; imports -- Japan, U.S., West Germany, U.K.; about 1% or less trade
with Communist countries
Monetary conversion rate: 20.8 baht=US$1 Pe
Fiscal year: 1 October - 30 September','9692761e219ae808182c787a9a81277ed48560293110c4a23527bd5f9445c3c1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b94ca74291d0a0d7c6fd812e626c0807be82376e666042089a12696881b3ec7',1973,'AO','Angola','economy',14,'D:
481,000 sq. mi.; 1% cultivated, 44% forested, 22% meadows
and pastures, 33% other (including fallow)
Land boundaries: 3,150 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. (navy)
(fishing 12 n. mi.)
Coastline: 1,000 mi.
GNP: $1.2 billion (1970 est.), about $220 per capita
Agriculture: cash crops -- coffee, sisal, corn, cotton, Sugar, manioc, and
tobacco; food crops -- cassava, corn, vegetables, plantains, bananas, and
other local foodstuffs; largely self-sufficient in food
Fishing: catch 368,000 metric tons, $8.4 million (1970); exports $19 million;
imports $4.1 million (1970)
Major industries: mining (oil, iron, diamonds), fish processing, brewing, tobacco,
sugar processing, cement, food processing plants, building construction
Electric power: 443,000 kw. capacity (1971); 694 million kw.-hr. produced
(1971), 125 kw.-hr. per capita
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Exports: $433 million (f.o.b., 1971); coffee (34%), oil, diamonds, sisal, fish
and fish products, iron ore, oil, timber, and corn
Imports: $445 million (c.i.f., 1971); capital equipment (machinery and electrical
equipment), wines, bulk iron and ironwork, steel and metals, vehicles and ‘
spare parts, textiles and clothing, medicines
Major trade partners: main partner Portugal, followed by West Germany, U.S.,
U.K., Japan
Aid: Portugal only donor
Monetary conversion rate: 27.25 escudos=US$1, until February 1973; 25.5 escudos= é
US$] thereafter
Fiscal year: calendar year','b781874ab3b2045710ee02edb7f2d5b2914bc8461c596097bb194f4349d90257','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b500677525c64a5f8395b9443dc155397d53db5211a691e44eafeba4e805499',1973,'BR','Brazil','economy',21,'GNP: $20.0 million (at market prices, 1970), $310 per capita
Agricul ture: main crops -- sugar, cotton
Major industries: oil refining, tourism
Shortages: electric power
Electric power: 92,440 kw. capacity (1971); 45 million kw.-hr. produced (1971
> est.), 540 kw.-hr. (est.) per capita
Exports: $2.9 million (f.0.b.; 1968); sugar, molasses, cotton
Imports: $20.0 million (c.i.f-, 1968); food, clothing, oil, wood
Major trade partners: U.K. 30%, U.S. 5%, Commonweal th Caribbean countries
18% (1966)
Monetary conversion rate: 1.92 East Caribbean dol lars=US$1 (6 October 1971),
now floating with pound sterling
|
A
pproved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
00010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A0006
D:
424,000 sq. mi.; 2% cultivated and fallow, 11% pasture
and meadow, 45% urban, desert, waste, or other,
40% forest, 2% inland water
Land boundaries: 3,780 mi.
GNP: $1.1 billion (at average exchange rate, 1972) $220 per capita;
78% private consumption, 11% public consumption, 13% gross domestic
investment, -2% net foreign balance (1970); real growth rate 1972, 5.9%
Agriculture: main crops -- potatoes, corn, rice, sugarcane, yucca, bananas;
imports significant quantities of foodstuffs including lard, vegetable oils,
and wheat; caloric intake, 1,800 calories per day per capita (1971)
Major industries: mining, smelting, petroleum refining, food processing, textiles,
and clothing
Electric power: 270,000 kw. capacity (1971); 832 million kw.-hr. produced
(1971), 175 kw.-hr. per capita
Exports: $192.2 million (f.0.b., 1972 est.); tin, petroleum, lead, zinc, silver,
tungsten, antimony, bismuth, gold, coffee, and sugar
Imports: $192.0 million (f.o.b., 1972 est.); foodstuffs, chemicals, capital goods,
pharmaceuticals
Major trade partners: exports -- U.K. 46%, U.S. 39%, West Germany 5%, Argentina 2%;
imports -- U.S. 41%, West Germany 12%, Japan 11%, Argentina 6% (1970)
Aid:
economic -- extensions from U.S. (FY46-71) $230.5 million in loans, $304.4
million in grants; from international organizations (FY46-70), $180.7
million; from other Western countries (1960-70), $43.7 million; Communist
countries (1954-71), $55.5 million; military -- assistance from U.S. (FY58-70),
$25.3 million
Monetary conversion rate: 20 pesos=US$1
Fiscal year: calendar year
GNP: $42.0 billion (at average official exchange rate, 1971), $440 per capita;
18.5% gross investment, 83.4% consumption, -1.9% foreign balance (est. 1971);
real growth rate 1971, 11.3%
4]
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d)
Agriculture: main products -- coffee, rice, beef, corn, milk, sugarcane, soybeans;
(seo self-sufficient; caloric intake, 2,900 calories per day per capita
1962
Fishing: catch 650,000 metric tons (1971); exports $26.0 million, imports $28.3
million (1970)
Major industries: textiles and other consumer goods, cement, lumber, steel,
motor vehicles, other metalworking industries
Crude steel: 6.5 million metric tons capacity (1971 est.); 6 million metric
tons produced (1971); 60 kilograms per capita (1971)
Electric power: 14.1 million kw. capacity (1972); 53.7 billion kw.-hr. produced
(1972), 600 kw.-hr. per capita
Exports: $3,990 million (f.o.b., 1972); coffee, manufactures, iron ore, cotton,
soybeans, sugar, wood, cocoa
Imports: $4,225 million (f.o.b.,
petroleum, wheat
Major trade partners: exports -- U.S. 26%, West Germany 9%, Italy 6%,
Netherlands 7%, Japan 5%, U.K. 4%; imports -- U.S. 29%, West Germany 13%,
U.K. 6%, Italy 4% (1971)
Aid: economic -- extensions from U.S. (FY46-71) -- loans $3,168.5 million,
grants $623.9 million; from international organizations (FY46-72) $1,651.2
million; from other Western countries (1960-66) ~- $343.6 million; from
Communist countries (1954-71) $330.6 million; drawings $124.4 million
Monetary conversion rate: 6.0 cruzeiros=US$1 (March 1973, changes frequently)
Fiscal year: calendar year
1972); machinery, chemicals, pharmaceuticals,
GNP: $177 million (1971 est.), $1,430 per capita, average annual growth rate
(1969-71) 6%
Agriculture: main crops -- rubber, rice, pepper, must import most food
Major industry: crude petroleum
Electric power: 85,000 kw. capacity (1972); 145 million kw.-hr. produced (1972),
1,028 kw.-hr. per capita
Exports: $115 million (f.0.b. 1971); 96% crude petroleum
Imports: $163 million (c.i.f. 1971); 47% machinery and transport equipment,
30% manufactured goods, 8% food
Major trade partners: exports of crude petroleum go to Sarawak for refining
and reexport; imports from Japan 30%, U.S. 24%, U.K. 15%, Singapore 9%
Monetary conversion rate: 2.54 Brunei dollars=US$1
Fiscal year: calendar year
43
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GNP: $8.25 billion (at average official exchange rate 1972), $890 per capita;
79% private consumption, 12% government consumption, 13% gross investment,
-4% net imports and factor payments abroad (1971 est.); real growth rate
1972 (est.), GNP 2.0%
Agriculture: main crops -- wheat, other cereals, potatoes; about 65% self-
sufficient; 2,650 calories per day per capita (1971 est.)
Fishing: catch 0.82 million metric tons; exports $16.3 million, imports $2.1]
million (1972)
Major industries: copper, nitrates, foodstuffs, fish processing, textiles and
apparel, iron and steel, pulp and paper »
Crude steel: 0.7 million metric tons capacity (1967); 0.6 million metric tons
produced (1971), 65 kg. per capita
Electric power: 2.13 million kw. capacity (1971); 8.5 billion kw.-hr. produced
(1971), 855 kw.-hr. per capita
Exports: $0.9 billion (f.0.b., 1972 est.); copper, iron ore, nitrates,
and iodine
Imports: $1.4 billion (c.i.f., 1972 est.); foodstuffs, machinery and equipment,
chemicals
Major trade partners: exports -- EC 42%, U.K. 12%, U.S. 14%, Japan 12%, LAFTA
10%; imports -- U.S. 36%, EC 23%, U.K. 6%, Japan 3%, LAFTA 20% (1970)
Aid:
Economic -- extensions from U.S. (FY46-71) -- $1,502.7 million ($1,289.6
million loans, $213.1 million grants); from international organizations
(FY46-70) -- $566.3 million (of which IBRD $232.7 million, IDB $253.9
million); from other Western countries (1960-66) -- $170.6 million; from
Communist countries (1967-71) -- $193.3 million;
military (FY53-71) -- from U.S., $25.1 million in loans, $124.4 million in
grants
Monetary conversion rate: multiple exchange rate system; range from 20.00 to
80.0 escudos=US$1 trade rate; 36.00 to 187 escudos=US$1 nontrade (broker)
rate; varying taxes double effective rate for some purposes; black market
rate is upwards of 550 escudos=US$1 (March 1973)
Fiscal year: calendar year
GNP: about $135 billion-$150 billion (1972), $150-$170 per capita
Agriculture: main crops -- rice, wheat, miscellaneous grains, cotton; caloric
intake, 2,000 calories per day per capita (1972); agriculture mainly
subsistence; grain imports 4 million~5 million tons annually
Major industries: iron and steel, coal, machine building, armaments, textiles
Shortages: complex machinery and equipment, highly skilled scientists and
technicians
Crude steel: 23 million tons produced (1972), 25 kilograms per capita (1972)
Exports: $2.9 billion (f.0.b., 1972), agricultural products, minerals and metals,
manufactured goods
Imports: $2.6 billion (c.i.f., 1972), grain, chemical fertilizer, industrial
raw materials, machinery and equipment
Major trade partners: Japan, Hong Kong, West Germany, U.K., Singapore, Malaysia,
Canada (1972)
Monetary conversion rate: about 2 yuan=US$1 (arbitrarily established)
Fiscal year: calendar year
GNP: $7.2 billion (1972), $470 per capita; real growth, 11%
Agriculture: most arable land intensely farmed -- 60% cultivated land under
irrigation; main crops -- rice, sweet potatoes, sugarcane, bananas, pineapples,
citrus fruits; 90% self-sufficient; food shortages -- wheat 7
Fishing: catch 694,000 tons, $252 million (1972)
Major industries: textiles, clothing, chemicals, plywood, electronics, sugar
milling, food processing, cement, ship building
Electric power: 3,610,000 kw. capacity (1972); 17.9 billion kw.-hr. produced
(1972); 1,175 kw.-hr. per capita
Exports: $3,114 million (f.0.b., 1972); textiles and clothing 28%, footwear 5%,
T.V. and radios 11%, other machinery and equipment 10%, metals and other
manufactures 15%, canned foods 6%, lumber and plywood 5%, seafood 4%
Imports: $2,843 million (c.i.f., 1972) machinery and equipment 33%, basic metals
10%, grains and soybeans 9%, oi] and natural gas 4%, textile raw materials
and intermediates 7%, chemicals and pharmaceuticals 14%
ha partners: exports -- 41% U.S., 13% Japan; imports -- 38% Japan,
h U.S.
Aid:
economic -~ U.S. (FY53-72) $1.7 billion committed; IBRD (1964-71) $312
million committed; Japan (1965-70) $137 million committed; ADB (1968-71)
$100 million committed;
military -- U.S. (FY49-71) $3.1 billion committed
Monetary conversion rate: NT$38 (New Taiwan)=US$1
Fiscal year: 1 July - 30 June
GDP: $21.0 million (1971 est.); $270 per capita; 8.8% increase in 1971 -- including
price changes
Agricultural products: bananas» citrus, coconuts, cocoa
Major industries: agricultural processing, tourism
Electric power: 5,420 kw. capacity (1971); 15 million kw.-hr. produced
(1971 est.), 220 kw.-hr. per capita
Exports: $6.1 million (f.0.b., 1970); bananas lime juice and oil, cocoa and
reexports
Imports: $16.3 million (c.i.f., 1970); foodstuffs, manufactured articles
Major trade partners: U.K. 53%, Commonwealth Caribbean countries 15%, Canada
10%, U.S. 7% (1963)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1, now floating with
r) pound sterling
GDP: $465 million (1971), $90 per capita; real growth rate 1971 5.7%
Agriculture: main crops -- coffee, sugarcane, rice, corn, sorghum, pulses;
caloric intake, 1,850 calories per day per capita
Major industries: sugar refining, textiles, flour milling, cement manufacturing,
bauxite mining, tourism, light assembly industries
Electric power: 62,000 kw. capacity (1971 est.); 120 million kw.-hr produced
(1971 est.), 24 kw.-hr. per capita
Exports: $47 million (f.0.b., FY71); coffee, bauxite, light industrial products,
essential oils, sugar, sisal, copper
141
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Imports: $63.5 million (f.o.b., FY71); consumer durables, foodstuffs,
industrial equipment, petroleum products, construction materials
Major trade partners: U.S. 51% (FY70)
Aid:
economic -~ from U.S., $34.1 million loans, $88.1 million grants (FY46-71);
international organizations, $28.2 million (FY49-71);
military -~ U.S., $4.3 million (FY53-71), from other Western countries
(1960-70) $3.7 million
Monetary conversion rate: 5 gourdes=US#1
Fiscal year: 1 October - 30 September
GNP: $779 million (1972 est.), $280 per capita; 77% private consumption, 9%
government consumption. 19% domestic investment; 2% inventory, -7% net
foreign balance (1970); real growth rate 1972 est., 5.0%
143
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d)
Agriculture: main crops -- bananas, coffee, corn, beans, cotton, sugarcane,
tobacco; caloric intake, 2,300 calories per day per capita (1964-65)
Fishing: exports $1.4 million (1970); imports $0.5 million (1970)
Major industries: agricultural processing, textiles, clothing, wood products
Electric power: 165,500 kw. capacity (1972); 350 million kw.-hr. produced
(1971), 116 kw.-hr. per capita
Exports: $179.8 million (f.0.b., 1972 est.); bananas, coffee, corn, cotton, lumber,
minerals, beef
Imports: $176.7 million (c.i.f., 1972 est.); manufactured products, machinery,
transportation equipment, chemicals, fuels
Major trade partners: exports -- U.S. 53%, West Germany 11%, CACM 11%; imports
c+ U.S. 41%, CACM 25%, West Germany 5% Japan 8% (1970)
Aid:
economic -- extensions from U.S. (FY46-71), $64.9 million loans, $59.6
mitlion grants; from international organizations (FY46-71), $153.6 million;
from other Western countries (1960-68), $5.3 million;
military -- assistance from U.S. (FY46-71), $8.6 million
Monetary conversion rate: 2 lempiras=US$1 (official)
Fiscal year: calendar year .
GNP: $250 million (1967), $1,170 per capita; real growth rate 1967, 3.6%
Agriculture: little production
Major industries: petroleum refining on Curacao and Aruba; tourism on Curacao,
Aruba, and St. Martin; phosphate mining on Curacao
Electric power: 295,000 kw. capacity (1971); 1.4 billion kw.-hr. produced (1971
est.), 5,550 kw.-hr. per capita
Exports: $654 million (f.0.b., 1970 est.); petroleum products, phosphate
Imports: $767 million (c.i.f., 1970 est.); crude petroleum, food manufactures
Major trade partners: exports -- U.S. 43%, EC 16%, Latin America 13%, U.K. 10%,
Canada 7%; imports -- Venezuela 72%, U.S. 10%, Netherlands 4% (1968)
Monetary conversion rate: 1.886 Netherlands Antillean florins (NAF )=US$1 (official)
Fiscal year: calendar year
GDP: $1.169 million (1971), $790 per capita; 72% private consumption, 11%
government consumption, 26% gross fixed investment, -9% net foreign
balance (1970); real growth rate 1971, 7.6%
255
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Agriculture: main crops -- bananas, rice, corn, coffee, sugarcane; self-sufficient
in most basic foods; 2,450 calories per day per capita (1969)
Fishing: catch 42,400 metric tons, $8 million (1970); exports $11.1 million (1970);
imports $1.6 million (1970)
Major industries: food processing, metal products, construction materials,
petroleum products, clothing
Electric power: 378,000 kw. capacity (1972); 1.2 billion kw.-hr. produced
(1972), 650 kw.-hr. per capita
Exports: $136 million (f.o.b., 1971); bananas, petroleum products, shrimp,
sugar, coffee
Imports: $359 million (f.o.b., 1971); manufactures, transportation equipment,
crude petroleum, foodstuffs, chemicals
Major trade partners: U.S. 43%, Venezuela 15%, Canal Zone 9%, Colon Free Zone
6% (1969)
Aid:
economic -- from U.S. (FY46-71), $161.6 million loans, $106.3
miltion grants; from international organizations (FY46-71), $129.6 million;
from other Western countries (1960-69), $14.5 million;
military -- assistance from U.S. (FY61-71), $4.5 million
Monetary conversion rate: 1 balboa=US$1 (official)
Fiscal year: calendar year
GNP: $609 million (1972), $260 per capita; 88% consumption; 16% gross domestic
investment; -4% net foreign balance (1971); real growth rate 1971, 3.3%
Agriculture: main crops -- oilseeds, cotton, wheat, manioc, sweet potatoes,
tobacco, corn, rice, sugarcane; self-sufficient in most foods; caloric
intake, 2,580 calories per day per capita (1963-64); protein intake,
70 grams per day per capita (20 grams of animal origin
Major industries: meat packing, oilseed crushing, milling, brewing, textiles,
light consumer goods, cement
Electric power: 159,000 kw. capacity (1971); 257 million kw.-hr. produced
(1971), 104 kw.-hr. per capita
259
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Exports: $66.5 million (f.o.b., 1971); meat, timber, oilseeds, tobacco, cotton,
quebracho extract, hides, yerba mate
Imports: $83 million (f.o.b., 1971); foodstuffs, machinery, transport equipment,
engines, consumer durables, fuels and lubricants, textiles
Major trade partners: U.S. 15%, Argentina 14%, West Germany 13%, U.K. 9%
Aid:
economic -- extensions from U.S. (FY46-71), $87.6 million loans, $71.6 million
grants; from international organizations (FY46-71), $163.0 million; from other
Western countries (1960-70), $21.9 million
military -- assistance from U.S. (FY46-71), $13.7 million
Monetary conversion rate: 126 guaranies=US$1 (official rate)
Fiscal year: calendar year
GNP: $6.7 billion (at official exchange rate, 1971), $480 per capita; 72%
private consumption, 10% public consumption, 13% gross investment (1970); 5%
net foreign balance; real growth rate 1972 est. 5.9%
Agriculture: main crops -- wheat, corn, potatoes, beans, barley, coffee, cotton,
sugarcane; imports wheat, meat, lard and oils, rice, corn; caloric intake,
2,300 calories per day per capita (1964)
261
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d)
Fishing: catch 10.2 million metric tons (1971); exports $339.5 million (1970), of
which $303.9 million fishmeal, $32.6 million fish oi?, and $3.1 million
canned and frozen fish; imports $0.3 million (1969)
Major industries: mining of metals, petroleum, fishing, textiles and clothing,
food processing, cement, auto assembly, steel, ship-building, metal
fabrication
Electric power: 1.9 million kw. capacity (1972); 6.2 billion kw.-hr. produced
(1972), 423 kw.-hr. per capita
Exports: $889 million (f.o.b., 1971); fish and fish products, copper, silver,
iron, cotton, sugar, lead, zinc, petroleum, coffee
Imports: $764 million (f.0.b., 1971); foodstuffs, machinery, transport equipment,
iron and steel semimanufactures, chemicals, pharmaceuticals
Major trade partners: exports -- U.S. 33%, Western Europe 42%, Japan 14%, Latin
America 6%; imports -- U.S. 32%, Western Europe 33%, Latin America 17%,
Japan 6% (1970)
id:
Ai
economic -- extensions from U.S. (FY46-71), $455.6 million loans, $189.9
million grants; from international organizations (FY46-70), $371.9 million;
from other Western countries (1960-66), $43.4 million; Communist countries
(1954-71) $126.5 million;
military ~- assistance from U.S. (FY49-71), $141.3 million
Monetary conversion rate: 38.70 soles=US$1 (trade); 43.38 soles=US$1 (non-trade)
Fiscal year: calendar year
GNP: $7.5 billion (1971), $190 per capita
Agriculture: main crops -- rice, corn, coconut, sugarcane, abaca, tobacco
Fishing: catch 990,000 tons, $434 million (1970)
Major industries: agricultural processing, textiles, chemicals and chemical
products
Electric power: 2,880,000 kw. capacity (1972); 9.9 billion kw.-hr. produced
(1972), 251 kw.-hr. per capita
Exports: $1,067 million (f.o.b., 1972); copra, sugar, logs and lumber, coconut
oil, copper concentrates, abaca
Imports: $1,230 million (f.0.b., 1972)
Major trade partners: (1972) exports -- 41% U.S., 33% Japan; imports -- 25%
U.S., 30% Japan
Aid:
economic -- U.S. (FY46-71), $1.6 billion committed; Japan (reparations),
$550 million extended in 1956, $337 million drawn through July 1969; IBRD
(1953-71), $239 million committed;
military -- U.S. (FY46-71), $632 million committed
Monetary conversion rate: 6.78 pesos=US$1 (December 1972) (floating rate)
Fiscal year: 1 July - 30 June
GNP: $5.2 billion (FY71), $1,890 per capita
Agriculture: main crops -- sugar, coffee, tobacco, bananas
Fishing: catch 46,000 metric tons, $17.4 million (1970)
Major industries: textiles, clothing manufacture, food processing, petroleum
refining, petro-chemicals
Electric power: 1.3 million kw. capacity (1972); 9.2 billion kw.-hr. produced
(1972), 3,365 kw.-hr. per capita
Exports: $1,736 million (f.0.b., 1971); sugar, pineapple, citrus fruits, coffee,
rum, textiles
Imports: $2,884 million (f.0.b., 1971); food, machinery, transportation equip-
+ ment, fuels, minerals
Major trade partner: exports -- U.S. 93%; imports -- U.S. 77%
275
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Monetary conversion rate: uses U.S. currency
Fiscal year: 1 July - 30 June
GDP: $15.2 million (1969), $230 per capita
Agriculture: main crops -- sugar on St. Christopher, cotton on Nevis
Major industries: sugar processing, salt extraction
Electric power: 11,000 kw. capacity (1971); 38 million kw.-hr. produced
(1971), 526 kw.-hr. per capita
Exports: $4.3 million (f.o.b., 1969); sugar, molasses, cotton, salt, copra
Imports: $9.6 million (c.i.f., 1969); foodstuffs, fuel, manufactures
Major trade partners: U.K. 45%, Canada 14%, U.S. 12% (1966)
Monetary conversion rate: 1.92 East Caribbean dol lars=US$1
287
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GNP: $40 million (1970 est.), $350 per capita
Agriculture: main crops -- bananas, copra, sugar, cocoa, spices
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 4,600 kw. capacity (1971); 10 million kw.-hr. produced (1971
est.); 86 kw.-hr. per capita
Exports: $6.0 million (f.o.b., 1969); sugar, bananas, cocoa
Imports: $21.6 million (c.i.f., 1969); foodstuffs, machinery and equipment,
fertilizers, petroleum products
Major trade partners: U.K. 49%, Canada 9%, U.S. 8% (1964)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1 (6 October 1971),
now floating with pound sterling
289
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GNP: $20 million (1970 est.), $200 per capita
Agriculture: main crops -- bananas, arrowroot, coconut
Major industries: food processing
Electric power: 6,300 kw. capacity (1971); 18.9 million kw.-hr. produced (1971
est.), 235 kw.-hr. per capita
Exports: $3.7 million (f.o.b., 1968); bananas, arrowroot, copra, cotton
Imports: $1.0 million (c.i.f., 1968); fertilizer, flour, transportation
equipment, lumber, textiles
Major trade partners: U.K. 39%, U.S. 10%, Canada 10% (1967)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1, now floating with
pound sterling
GDP: $960 million (1971), $1,000 per capita; real growth rate 1971, 4.9% est.
Agriculture: main crops -- sugarcane, cocoa, coffee, rice, citrus, bananas:
Targely dependent upon imports of food
Fishing: catch 4,000 metric tons (1970); exports $2.4 million (1970),
imports $2.5 million (1970)
Major industries: petroleum, tourism, food processing, cement
Electric power: 290,000 kw. capacity (1971); 1.2 billion kw.-hr. produced (1971),
1,190 kw.-hr. per capita
Exports: $520 million (f.o.b., 1971); petroleum and petroleum products ($287
million, sugar, cocoa)
Imports: $657 million (c.i.f., 1971); crude petroleum ($312 million), machinery,
transportation equipment, manufactured goods, food
Major trade partners: (excludes trade under petroleum agreement) exports -- U.S.
33%, U.K. 14%, CARIFTA 23%; imports -- U.S. 33%, U.K. 25%, CARIFTA 10% (1971)
Aid: economic -- from U.S. (FY56-71) $24.7 million loans, $40.2
million grants; from international organizations (FY53-71), $64.1 million
Monetary conversion rate: floating with pound sterling; on 15 February 1973
TT$1.96=U.S.$1
Fiscal year: calendar year','543a9c42438e77cbc950668234cea2b80a8d7539c7cd211d4eb4a4a69f0ba9dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b98fd3a12139c3806ffd3ad0771bedcef1450ecc449b51dfc6171fa0be99afb8',1973,'AR','Argentina','economy',26,'GNP: $27.2 billion (at average export exchange rate, 1972) $1,130 per capita;
72% consumption, 27% gross domestic investment, 14% net foreign balance
(1972); real growth rate 1972, 4.0%
Agriculture: main products -- cereals, oilseeds, livestock products; Argentina
is a major world exporter of temperate zone foodstuffs
Fishing: catch 214,800 metric tons, $20.2 million; exports $1,158,000, imports
$3,659,000 (1970)
Major industries: food processing (especially meatpacking), motor vehicles,
consumer durables, textiles, chemicals, printing, and metallurgy
Crude steel: 2.1 million metric tons produced (1972)
Electric power: 7,262,000 kw. capacity (1972); 25.4 billion kw.-hr.
produced (1972), 1,000 kw.-hr. per capita
Exports: $1,740.4 million (f.0.b., 1971) -- meat, wheat, corn, wool, hides, oil-
seeds
Imports: $1,887.6 million (c.i.f., 1971) -- machinery, fuel and lubricating oils,
iron and steel, intermediate industrial products
Major trade partners: exports -- EC 37%, LAFTA 25%, U.S. 11%, U.K. 8%;
imports -- EC 24%, LAFTA 24%, U.S. 23%, U.K. 7%
Aid: economic -- extensions from U.S. (FY46-71), $803.0 million in loans; $18.0
million in grants; from international organizations (FY46-70), $1,109.8
million; from other Western countries (1960-66), $315.5 million; from
Communist countries (1954-71) $56 million (drawn, $41.0 million);
military -- assistance from U.S. (FY46-71), $152.2 million
Monetary conversion rate: commercial -- 5.00 pesos = US$1; financial -- floating
(9.98 pesos=US$1, December 1972)
Fiscal year: calendar year','b8cbfe8869c73a9eea0473442097a60a8fa79956904b07b2a5b889f2d0aa64ff','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('589f5b8ba2c02b86686316e1fa959ac392971b98fc6772f48ad4ef4265e465e2',1973,'AT','Austria','economy',30,'GNP: $20.1 billion (1972), $2,690 per capita (1972); 58.5% consumption, 28 .9%
investment, 11.5% government, 0.6% net foreign balance, net errors and
omissions (1971); 1972 growth rate 5.5% constant prices
Agriculture: livestock, cereals, potatoes, sugar beets; 84% self-sufficient;
caloric intake 2,920 calories per day per capita (1967-68)
19
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Fishing: catch 4,000 metric tons, $3,846,000 (1968); exports $847,000 (1970),
imports $28,711,000 (1970)
Major industries: foods, iron and steel, machinery, textiles, chemicals,
electrical, paper and pulp
me ae 4.1 million metric tons produced (1970), 550 kilograms per capita
970
Electric power: 8,228,700 kw. capacity (1971); 28.8 billion kw.-hr produced
(1971), 3,856 kw.-hr. per capita
Exports: $3.85 billion (f.0.b., 1972); iron and steel products, machinery and
equipment, lumber, textiles and clothing, paper products, chemicals
Imports: $5.18 billion (c.i.f., 1972); machinery and equipment, chemicals,
textiles, coal, petroleum, foodstuffs
Major trade partners: (1972) West Germany 34%, Italy 8%, Switzerland 9%,
eae 7%, U.S. 4%; EC 50%; EFTA 22%; Communist countries 10%
id:
economic -- received - U.S. $1,188.2 million through FY71; IBRD $104.9
million, none since FY62;
military -- U.S., $144.6 million (FY52-71); net official economic aid to
less developed areas and multilateral agencies -- $189 million (FY60-70),
$24.2 million in FY70
Monetary conversion rate: 20.6 shillings=US$1, March 1973 (floating rate)
Fiscal year: calendar year','d1c918762fe79ace548c02c86cf4ffae16c12497ad182d65ab6bbe875b2842ac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1ff7d190728aef1ba63b64b8234d8dded09dc3276a8d7a54d41a265d884ead4',1973,'BS','Bahamas','economy',34,'GNP: $390 million (at market prices, 1970), $1,920 per capita
Agriculture: main crops -- fruits, vegetables
Major industries: tourism, cement, oil refining, lumber, salt production
Electric power: 177,000 kw. capacity (1971); 537.0 million kw.-hr. produced
(1971), 3,055 kw.-hr. per capita
Exports: $246 million (f.0.b., 1971); fuel oil, cement, rum, pulpwood, fruits,
and vegetables
Imports: $515.6 million (c.i.f., 1971); foodstuffs, manufactured goods, crude oi]
Major trade partners: exports -- U.S. 68%, U.K. 7%, Canada 6%; imports -~- U.S.
54%, U.K. 14%, Italy 7%, Canada 4%, other 21% (1970)
Aid: economic -- authorizations from U.S. (FY56-71) -- $21.7 million in loans,
$0.3 million in grants
Monetary conversion rate: 0.97 Bahamian dollars (B$)=US$1
Fiscal year: calendar year','0bd6b15b602679fcc4f06855da75d551df8409fa9938faaf337712030ea8ae1e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87fff800d11e2fea393fc20a3999ea1a65503446804795725725c8dced42a86e',1973,'BH','Bahrain','economy',38,'Agriculture: produces dates, alfalfa, vegetables; dairy and poultry farming;
fishing; not self-sufficient in food
Major industries: petroleum refining, boatbuilding, shrimp fishing, and
sailmaking on a small scale; major development projects include aluminum
smelter, flourmil1, and ISA town
Electric power: 108,000 kw. capacity (1972); 270 million kw.-hr. produced (1972),
1,180 kw.-hr. per capita
Exports: Reexports were $66 million in 1972; total exports $230 million in
1972 (prelim. )
Imports: $241 million (1972)
Major trade partners: U.K., dapan, U.S., EC
Aid: economic -- multilateral Western $360,000 (annual average 1967-69)
Monetary conversion rate: 1 Bahrain dinar=US$2.52 (as of March 1973)
Fiscal year: calendar year
4 COMMUNICATIONS :
Highways: 120 mi. bituminous surfaced; undetermined mileage of natural surface
tracks
Ports: 1 major
Merchant marine: 1 cargo ship (1,000 GRT or over) of 1,600 GRT, 2,600 DWT
Pipelines: crude oil, 35 mi.; refined products, 10 mi.; natural gas, 20 mi.
4 Civil air: 5 major transport aircraft (all registered in the U.K.)
Airfields: 5 total, 2 usable; 1 with permanent-surface runway; 1 with runway over
12,000 ft; 1 seaplane station
23
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','35a807f71edb08b35b65d9a3460e1e9facb67302364528d322b74a36305be54a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab7361fd6e9615dc19992522011dd620283456184056762225723ae08749f7c6',1973,'BD','Bangladesh','economy',42,'‘ GNP: $5.0 billion FY72 est. (1970 prices), less than $100 per capita; real
growth (FY72 est.) -7%
Agriculture: largely subsistence farming, heavily dependent on monsoon rainfall;
main crops are jute and rice; shortages -- rice; wheat, and cotton
‘ *Does not take account of refugees who entered India from Bangladesh during 1971,
most of whom presumably have returned.
25
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Fishing: catch 273 thousand tons, $115 million (1969 est.)
Major industries: jute manufactures, food processing and cotton textiles
Electric power: 535,000 kw. capacity (1972); 1 billion kw.-hr, produced (1972),
16 kw.-hr. per capita
Exports: $297 million (f.o0.b., 1972); raw and manufactured jute, tea, paper and
paperboard, hides and skins
Imports: $694 million (c.i.f. 1972); chemicals, machinery and other manufactured
Products, transport equipment, foodgrains, fuels, oils and fats
Major trade partners: West Pakistan (until December 1971), U.S., ULK., Japan,
India (since December 1971)
Aid: Bangladesh received roughly one-third of the estimated $8 billion in total
economic aid received by Pakistan between 1950 and 1971; since independence
(17 December 1971-1 January 1973), economic aid: total $1.3 billion extended,
$634 million drawn; US$347 million extended; U.S.S.R. $136 million extended;
Eastern Europe $36 million extended
Monetary conversion rate: 7.5 takas=US$1 (effective April 1973)
Fiscal year: 1 July ~ 30 June
COMMUNTCATIONS :
Railroads: 1,752 mi.; 1,178 mi. meter gage, 554 mi. broad gage, 20 mi. narrow
gage; 87 mi. double track; government owned
Highways: 28,350 mi.; 2,450 mi. paved; 1,750 mi. gravel, 24,150 mi. earth
Inland waterways: 4,600 mi.; river steamers navigate main waterways
Ports: 1 major; 5 minor
Merchant marine: 5 cargo ships (1000 GRT or over) totaling 14,100 GRT, 17,800 DWT
Civil air: 6 major transport aircraft
Airfields: 6] total, 20 usable; 19 with permanent surface runways; 3 with runways
8,000-11,999 ft., 9 with runways 4,000-7,999 ft.; 17 seaplane station
Telecommuni cations : inadequate international radiocommunications and landline
service; fair domestic wire and radiocommuni cation service; fair broadcast
service; 52,000 (est.) telephones; 630,000 (est.) radio sets; 30,000
(est.) TV sets; 5 AM, no FM, and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 15,484,000; 8,320,000 fit for military service
Supply: military supplies consist of those captured from West Pakistani forces
and materiel provided by India
Military budget: for fiscal year ending 30 June 1973, $52,980,130; about 5.4% of
the central government budget
26
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','5bffa123ccf82d44cc8e71e27dc3bccacb60ca86b9064780f58eebb39e4e0473','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f43633004d270b3c291ec65a5e89743816baa1820c550335f6a5e3d8eecda035',1973,'BB','Barbados','economy',43,'LAND:
166 sq. mi.; 60% cropped, 10% permanent meadows, 30% built
on, waste, other
WATER: ; VENEZUELA
Limits of territorial waters (claimed): 3.n. mi.
Coastline: 60 mi. COLOMBIA
PEOPLE: ARAzIL
Population: 236,000 (official estimate for 1 July 1971)
Ethnic divisions: 80% African, 15% mixed, 5% European
Religion: Anglican, Roman Catholic, Methodist, and Moravian
Language: English
Literacy: over 90%
Labor force: 60,000 wage and salary earners
Organized labor: 19,300 (32%)
GDP: $155.4 million (1971), $600 per capita; real growth rate 1971, -1.0% (est.)
Agriculture: main products -- sugar, subsistence foods
Major industries: tourism, sugar milling, manufacturing, edible oils and fats
Electric power: 48,000 kw. capacity (1971); 150 million kw.-hr. produced
(1971), 580 kw.-hr. per capita
Exports: $40.0 million (f.o.b., 1971); sugar, molasses, rum
Imports: $135.6 million (c.i.f., 1971); foodstuffs, lumber, machinery,
manufactured goods
Major trade partners: exports -- U.K. 32%, U.S. 13%, CARIFTA 27%, other 22%;
imports -- U.K. 30%, U.S. 18%, Canada 10%, CARIFTA 12%, other 27% (1971)
Aid: economic -- U.S. (FY67-70), $0.7 million in grants; from international
organizations (FY63-70), $0.8 million
Monetary conversion rate: 1.92 East Caribbean dol lars=US $1
Fiscal year: 1 April - 31 March
27
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUN TCAT IONS :
Railroads: none
Highways: 950 mi.; 800 mi. paved, 100 mi. gravel, 50 mi. improved earth
Ports: 1 major, 3 minor
Civil air: 4 major transport aircraft
Airfields: 1 with permanent-surface runway 8,000-11,999 ft.; 1 seaplane station
Telecommunications: islandwide automatic telephone system with 33,000
telephones; tropospheric scatter link to Trinidad; VHF links to St. Vincent
and St. Lucia; 96,000 radio and 22,000 TV sets, 2 AM, 1 FM, and 1 TV stations;
1 telegraph submarine cable; communications satellite earth station
DEFENSE FORCES:
Military manpower: males 15-49, 48,000; 35,000 fit for military service; average
number reaching military age, (18) annually, 3,000; no conscription
28
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','50dd73c973aab48bb37633274d82d2493472c68c99fedc35fc16bbd78e0620b0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('499033689f1945f435e87428863998c00cb22172b6046754277deb67e4b0649e',1973,'BE','Belgium','economy',45,'LAND:
11,800 sq. mi.; 28% cultivated, 24% meadow and pasture,
28% waste, urban, or other; 20% forested
Land boundaries: 856 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 40 mi.','d0ca25191eb32c5dacb6fcc7b206ef04bc11d9b8476df911b2e4d1e25f374d4f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a5471b1fa746e16a0b4f7b9fb2308d66f5e7402bbc0907be1e0648ebb9456e4',1973,'BM','Bermuda','economy',49,'GNP: $190 million (at market prices, 1970), $3,580 per capita
Agriculture: main products -- bananas, vegetables, Easter lilies, dairy products,
citrus fruits
Major industries: tourism, finance, ship repair, small boat building
Electric power: 66,340 kw. capacity (1971); 226 million kw.-hr. produced (1971),
4,245 kw.-hr. per capita
Exports: $93.0 million (f.o.b., 1971); mostly reexports of drugs and bunker fuel
Imports: $111 million (f.0.b., 1971); fuel, foodstuffs, machinery
Major trade partners: U.S. 45%, U.K. 22%, Canada 9% (1971)
Monetary conversion rate: 1 Bermuda dol lar=US$1
Fiscal year: 1 April-31 March','603e7c62f58cfff79aaa81fa91d9895a981797d40552ba58b81ff0941d5dfb8c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('997dff78c9407ff34f6b01ecbb7e218afd28e454d1f0df85147d99a7e1d1ff1d',1973,'BT','Bhutan','economy',53,'GNP: under $100 per capita
Agricul ture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Electric power: 400 kw. capacity (1972)
Exports: about $1 million annually; rice, dolomite, and handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic -- India (FY61-72) $180 million
Monetary conversion rate: 7.5 Indian rupees=US$1 (official rate); now floating
with U.K. pound
* Fiscal year: | April - 31 March
COMMUNI CAT IONS: ;
Highways: 810 mi.; 260 mi. surfaced, 320 mi. improved, 230 mi. unimproved
earth
Pt Freight carried: not available, very light traffic
Civil air: no major transport aircraft
35
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
2-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A00060001000
COMMUNICATIONS (cont''d):
Airfields:
T asphalt runway 4,500 ft.
Telecommunications: facilities
S almost nonexistent; data not available on
telephones; 6,000 radio sets; no TV sets; data not available on AM; no
FM; and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 233,000; 121
about 8,000 reach milita
Pte me ERR TEER one
2000 fit for military service;
ry age (18) annually
36
02-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A0006000100
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
BOLIVIA','067e0dc132eee0201bdd631a835235940ebb7e9f9bd2b702f6a67e84ffa2090c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f29c07fe95b67ed35924849c96da0bece7672a2ec131672b71f62fbe3b2d923f',1973,'BW','Botswana','economy',57,''' GDP: $123.5 million (July 1971-June 1972), about $200 per capita
Agriculture: principal crops are corn and sorghum; livestock raised and ex
Major industries: livestock processing, mining of diamonds, copper, nickel, coal,
asbestos, and manganese
Electric power: 8,000 kw. capacity (1972); 16 million kw.-hr. produced (1972),
23 kw.-hr. per capita
* Exports: $47 million (FY71/72) 5 cattle, animal products, minerals
Imports: $88 million (FY71/72)5 foodstuffs, vehicles, textiles
39
A
pproved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
0002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A00060001
ECONOMY (cont''d)
Major trade partners: South Africa and U.K.
Monetary conversion rate: 1 SA Rand=US$1.42 (Botswana uses the South African
Rand), 0.70 SA Rand=US$1
Fiscal year: ] April - 31 March','1ec0e406a6ed9c306b73c0812ae95c914a990132f1a58160ddc7f32218db526c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f01e6501b33ddeef1074b2e366d700d90dbdf21995fd3c576aa72d87a052816',1973,'BG','Bulgaria','economy',60,'GNP: $13.9 billion, 1972 (at 1971 prices), $1,620 per capita; 1972 growth rate
6.3%
Agriculture: mainly self-sufficient; main crops--grain, vegetables; no food
shortages; caloric intake, 3,000 calories per day per capita (1969/70)
Fishing: catch 97,000 metric tons (1971)
Major industries: agricultural processing, machinery, textiles and clothing,
mining, ore processing, timber
Shortages: some raw materials, metal products
45
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Crude steel: 2.1 million metric tons produced (1972), 240 kg. per capita
Exports: $2,603 million (f.o.b., 1972); in 1971, 35% machinery, equipment, and
transportation equipment; 12% fuels, minerals, raw materials, metals, and
other industrial material; 4% agricultural raw materials; 37% foodstuffs
and animals; 12% industrial consumer goods
Imports: $2,548 million (f.0.b., 1972); in 1971, 46% machinery, equipment, and
transportation equipment; 35% fuels, minerals, raw materials, metals, other
materials; 9% agricultural raw materials; 3% foodstuffs and animals; 6%
industrial consumer goods
Major trade partners: $5,151 million in 1972; 19% with non-Communist countries;
81% with Communist countries
Monetary conversion rate: (commercial) 0.96 leva, (noncommercial) 1.65 leva=US$1;
old commercial rates: 1.08 leva=US$1 in 1972; 1.17 leva=US$1 prior to 1972
Fiscal year: calendar year; economic data reported for calendar years except for
caloric intake, which is reported for consumption year 1 July - 30 June
Note: foreign trade figures were converted at the 1972 rate
GDP: $2 billion (FY72), $70 per capita; real growth rate 3% (FY72)
Agriculture: main crops -- paddy, sugarcane, peanuts; almost 100% self-sufficient;
most rice grown in deltaic land
, Fishing: catch 432,400 metric tons, $87.5 million (1970)
Major industries: agricultural processing; textiles and footwear, wood and
wood products; petroleum refining
Electric power: 313,400 kw. capacity (1972); 725 million kw.-hr. produced (1972),
25 kw.-hr. per capita
Exports: $113 million (f.o.b., 1971); rice, teak
47
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Imports: $175 million (c.i.f., 1971) machinery and transportation equipment,
textiles, other manufactured goods
Major trade partners: exports -- India, Western Europe, U.K., Japan; imports --
Japan, Western Europe, India, U.K.
Monetary conversion rate: 4.79 kyat=US$1 (official)
Fiscal year: 1 October - 30 September','df3867b80015912a3d8df6b5b205f2118c9c22ab747aac998fc6d81e6e326cd2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6244fadc1b33daf9098794115adbbddd7dbffb5d7e1635fd3f3b0a1fcf78ab3d',1973,'BI','Burundi','economy',65,'GNP: about $204.7 million (1971 est.), $60 per capita; estimated real GDP
growth 1%
Agriculture: major cash crops -- coffee, cotton; main food crops -- manioc,
yams, corn, sorghums, bananas, haricot beans; not self-sufficient
Industries: light consumer goods such as beverages; shoes, soap
Electric power: 13,100 kw. capacity (1972); 26 million kw.-hr. produced (1972),
7 kw.-hr. per capita
Exports: $20.7 million (f.0.b., 1970); coffee, cotton, hides, skins
Imports: $25.6 million (c.i.f., 1970); textiles, foodstuffs, transport equipment,
petroleum products —
Major trade partners: U.S., Belgium, Congo; much trade unrecorded
Aid: $17.7 million (1970) includes Belgium $7.4 million, U.N. $3.1 million, EDF
$2.9 million; France $2.0 million (1970); U.S. $7.9 million FY62-71
Monetary conversion rate: 87.5 Burundi francs=US$1 (official )
Fiscal year: calendar year
49
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','77583a68ca04e5bda91d530c9f338dbd37a277419426fbc6f7dedb950b4fe48b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b71b37b7d1d7ecc5497d124a18247c1174cc156d8aafc4337293eedc2aa810e4',1973,'KH','Cambodia','economy',69,'GNP: $950 million (1971), $140 per capita (1971 prices; no growth rate available)
Agriculture: Mainly subsistence except for rubber plantations; main crops ~~
rice, rubber, corn; largely self-sufficient prior to the war; food shortages
-- rice, dairy products, sugar; flour :
? Major industries: rice milling, fishing, wood and wood products, textiles
Shortages: fossil fuels
Electric power: 104,000 kw. capacity (1972); 180 million kw.-hr. produced (1972),
25 kw.-hr. per capita
Exports: $8.3 million (f.0.b., 1972); rubber, corn, kapok
Imports: $84.2 million (f.0.b., 1972); machinery and equipment, chemical products,
* metals and metal products, petroleum products, foods, transport equipment
51
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d)
Major trade partners: (1971) exports -~ South Vietnam, Hong Kong, Singapore;
2% with Communist countries; imports -- U.S., Japan, France; negligible with
Communist countries
Monetary conversion rate: adjustable; about 230 riels=US$1 (March 1973)
Fiscal year: calendar year','48b27d47e7bd416b2643537e7a21af9e178ead67e5cde5e3edefe0977a570785','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01bf16465230135fbf67137baef9aa469ad897060074b5d59a46f490090e4c39',1973,'CM','Cameroon','economy',73,'GDP: $1,196 million (1971 est.), per capita about $190; real growth rate about 7%
per annum
Agriculture: commercial and food crops -- cocoa, coffee, timber, cotton, rubber,
bananas, peanuts, palm oil and palm kernels; root starches, livestock, millet,
sorghum, and rice
Fishing: catch about 70,800 metric tons (1970), value not available; exports $1.1
million (1970), imports $2.1 million (1970)
Major industries: smal] aluminum plant; food processing and light consumer goods
industries, sawmills
53
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Electric power: 262,400 kw. capacity (1972); 1.7 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $224 million (f.o.b., 1971) cocoa and coffee about 55%; other exports
include timber, aluminum, cotton, natural rubber, bananas, peanuts, tobacco,
and tea
Imports: $271 million (c.i.f., 1971) consumer goods, machinery, transport equipment,
alumina for refining, petroleum products, food and beverages; about 2% from
Communist countries
Major trade partners: about 70% of total trade with France and other EC countries;
less than 10% of total trade with U.S.
Budget: FY 72 current budget (est.) -- receipts $227 million, expenditures $190
million
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
as of February 1973, floating since February 1973
Fiscal year: 1 July - 30 June','64cddf0e361d083ee423b54911ce9a11a7c855fa103249a49bb2066a2ea4a31b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fce8320afc312180ff658421c2746ac9d2458375ab65787ecfe9c7edb0ab0bd',1973,'CF','Central African Republic','economy',77,'GDP: $213 million (est. 1971), about $140 per capita
Agriculture: commercial -- cotton, coffee, peanuts, sesame, wood; main food
crops -- manioc, corn, peanuts, rice, potatoes, beef; requires wheat, flour,
rice, beef, and sugar imports
Major industries: sawnills, cotton textile mills, brewery, diamond mining and
4 splitting
Electric power: 16,850 kw. capacity (1972); 50 million kw.-hr. produced (1972),
30 kw.-hr. per capita
Exports: $33 million (f.0.b., 1970); diamonds (43%), coffee, cotton, lumber
Imports: $41 million (c.i.f., 1970); textiles, petroleum products, machinery
> and electrical equipment, motor vehicles and equipment, chemicals and
pharmaceuticals
57
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partner: France; preferential tariff applied to EC countries and
franc zone; U.S.
Budget: 197] ordinary budget -- receipts $45.2 million, expenditure $45.1 million
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1 ,
as of February 1973, floating since February 1973 (official)
Fiscal year: calendar year','02769dd8088b45031af335a2a2ea1db0dd04df0769fc76f24fcb5eb507a14015','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86248ca5c0095ac77d6bff6e10affec8b3a33aa217dc9145fabf4600ea5efe25',1973,'TD','Chad','economy',81,'GDP: about $241 million (1967), about $70 per capita; estimated real annual growth
rate 2.5%
Agriculture: commercial -- cotton, gum arabic, livestock, fish; food crops --
peanuts, millet, sorghum, rice, dates, manioc, wheat; imports food
Fishing: catch 120,000 metric tons (1970) $13 million; exports $300,000 (1969)
Major industries: agricultural and livestock processing plants (cotton textile
mill, slaughterhouses, brewery), natron
59
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Electric power: 21,960 kw. capacity (1972); 54 million kw.-hr. produced (1972),
14 kw.-hr. per capita
Exports: $28.0 million (f.0.b., 1971); cotton 67.5%
Imports: $62.0 million (c.i.f., 1970); cement, petroleum, foodstuffs, machinery,
textiles, and motor vehicles; $1.3 million from Communist countries (1967)
Major trade partners: France (about 40% in 1969) and UDEAC countries; preferential
tariffs to EC and franc zone countries
Aid: major source France, $469 million, 1961-69; EDF $393 million (1965-70) ;
U.S. (FY62-71) $9.6 million; U.S.S.R. $2.2 million (1968); military aid
(1954-68) -- $5.4 million, from France $4.1 million, remainder from West
Germany and Israel, more than $10 million annually (est.) in French military
aid (1969-71)
Budget: 1972 ordinary budget (est.) -- $52 million
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
as of February 1973, floating since February 1973 (official)
Fiscal year: calendar year','46ba9dc8d0231332cf7bb855df2a6666a7994e54ef73263eddff360fb6a0759a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('955e3e01b68d44ac1d44b1fabf94fede85fc8c35c923aff682bf6c0c14bed012',1973,'CO','Colombia','economy',85,'GNP: $7.25 billion (at average exchange rate, 1971), $320 per capita; 72%
private consumption, 7% public consumption, 21% gross investment (1969);
real growth rate 1972, 7.% (est.)
Agriculture: main crops -- coffee, rice, corn, sugarcane, plantains, bananas,
(ies) potatoes, yucca; caloric intake, 2,220 calories per day per capita
1965
Fishing: catch 70,600 metric tons 1969; exports $2.9 million (1969), imports $1.0
million (1969), $0.56 million (1970)
Major industries: textiles, food processing, clothing and footwear, beverages,
chemicals, and metal products
Crude steel: 0.4 million metric tons capacity (1965); 0.26 million metric tons
production (1969), 10 kilograms per capita
Electric power: 2.57 million kw. capacity (1971); 9.5 billion kw.-hr. produced
(1971), 424 kw.-hr. per capita
Exports: $782 million (f.0.b., 1970); coffee, petroleum, bananas, tobacco,
cotton, sugar, textiles, cattle and hides, wood and wood products
Imports: $844 million (c.i.f., 1970); industrial metals and raw materials, chemicals
and pharmaceuticals, transportation equipment, nachinery, fuels, fertilizers,
paper and paper products, foodstuffs and beverages, rubber and rubber products
Major trade partners: U.S. 44%, West Germany 11%, other EC 9%, EFTA 9% Latin
America 6%, Communist countries 4% (1968)
Monetary conversion rate: 23.15 pesos=US$1 (February 1973, changes frequently),
selling rate
Fiscal year: calendar year
Agriculture: food crops -- rice, manioc, potatoes, fruits, vegetables; export
eons -- essential oils for perfumes (mainly ylang-ylang), vanilla, copra,
sisa
Exports: $6.1 million (1971) perfume oils, vanilla, copra, sisal
Imports: $11.1 million (1971) foodstuffs, cement, fuels, chemicals, textiles
Major trade partners: France, Malagasy Republic, Italy, Kenya, Tanzania and U.S.
Electric power: est. 1,000 kw. capacity (1972); est. 2 million kw.-hr. produced
(1972); 7 kw.-hr. per capita
Aid: French aid in 1971 was about $2.7 million, or about 50% of the island''s
entire budget
Monetary conversion rate: 255.785 Communaute Financiere Africaine (CFA) francs=US$1
as of February 1973 (floating since February 1973)
COMMUNTCATIONS :
Railroads: none
Highways: 600 mi.; approximately 100 mi. bituminous, 450 mi. crushed stone or
gravel, remainder tracks
Ports: 1 minor (Moroni on Grande Comore)
Civil air: 2 major transports (registered in France)
69
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Airfields: 4 total, 4 usable; 4 with permanent surface runways; 4 with runways
4,000-7,999 ft.; 1 seaplane alighting area
Telecommunications: minimal system of HF radiocommunication stations for inter-
island and external communications to Malagasy and Reunion; Dzaoudzi center
but of slight significance; 500 telephones; 35,000 radio receivers; 1] AM,
1 FM, and no TV stations
DEFENSE FORCES:
Defense is the responsibility of France
70
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','13e1dd885363d3390ed9b2671027f3c52dda345459bafbe9aca21b261f3aea34','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33148a768f7d929a59bf75b6b0f527a10c470f2b2d8383ccd44b983bf63210ae',1973,'CG','Congo','economy',86,'ALGERIA) LIBYA [E
ND:
135,000 sq. mi.; 63% dense forest or woodland, 33%
cultivable or grazing (2% cultivated est.), 4% urban
or waste
Land boundaries: 2,805 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(fishing 3-15 n. mi.)
Coastline: 105 mi.
GDP: about $277 million (1970 est.), $310 per capita, real growth rate
about 4% per year
Agriculture: cash crops -- sugarcane, wood, coffee, cocoa, palm kernels, peanuts,
tobacco; food crops -- root crops, rice, corn, bananas, manioc, fish
Fishing: catch 12,200 metric tons (1970); imports $3.3 million (1969)
Major industries: sawmills, brewery, cigarettes, sugar mill, soap
Electric power: 43,600 kw. capacity (1972); 88 million kw.-hr. produced (1972),
91 kw.-hr. per capita
71
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Exports: $41 million (f.0.b., 1970); Tumber, sugar, tobacco, veneer, and plywood;
diamonds smuggled from Zaire
Imports: $58 million (c.i.f., 1970); machinery, transport equipment, manufactured
consumer goods, iron and steel, foodstuffs, petroleum products ei
Major trade partners: France and other EC countries on preferential basis
Budget: 1970 -- revenue $60 million, expenditure $69 million
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
as of February 1973, floating since February 1973 (official)
Fiscal year: calendar year ,','8b71e177ac54735a36f43233d5784857134fe3de1bdbab811c42e7f20c4428a0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d326d2f30bad338ddc30b19403cdf5f230b69bd8eac73e0074c75a9c28bb7f8',1973,'CR','Costa Rica','economy',93,'GNP: $1,130 million (1972 ast.), $620 per capita; real growth rate 1972, 4.7% (est.)
Agriculture: main products ~~ bananas, coffee, sugarcane, rice, corn, cocoa,
livestock products; caloric intake, 2,610 calories per day per capita (1966)
y Fishing: catch 8,100 metric tons, $2.2 million (1970); exports, $1.8 million
(1970), imports $0.5 million (1970)
73
A
pproved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ee
10002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A0006000
ECONOMY (cont''d):
Major industries: food Processing, textiles and clothing, construction
materials, fertilizer
Electric power: 220,000 kw. Capacity (1971); ] billion kw.-hr. Produced
(1971), 540 kw.-hr. per capita
Exports: $240 million (f.0.b., 1972 est.); coffee, bananas, sugar, beef,
fertilizers, cacao
Imports: $337 million (Onin fin: 1972 est.); manufactured products, machinery ,
transportation equipment, chemicals, fuels, foodstuffs
Major trade Partners: exports -- 41% U.S. 21% CACM, 9% West Germany, 3% Japan;
imports -- 32% U.S., 22% CACM, 8% West Germany, 11% Japan (1971)
economic -- extensions from U.S, (FY46-71), $121.4 million loans, $95.2
million grants; from international organizations (FY46-71) , $147.8 million;
from other Western countries (1960-68), $1.8 million;
military -- assistance from U.S. (FY60-71) $1.9 million
Monetary conversion rate: 6.62 colones=US$] (official buying rate); 6.65
Colones=US$1 (official selling rate)
Fiscal year: calendar year
f VENEZUELA
“RANA
WATER: A Fc. ae = A i a COLOMBIA
Limits of territorial waters (claimed): 12 n. mi. ete eee
Coastline: 1,100 mi.','40472b762f6aad3b76f6caf2c9685872c1a95fe071fffd91c22f2f983937c44e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71a2e98d72a4834ab91c421968001b055178fca8898d978b8561497a9b4c148e',1973,'CU','Cuba','economy',97,'GDP: $4.7 billion (1972 est. at 1972 prices), $540 per capita; 60% private
consumption, 20% public consumption, 20% gross investment; real growth
rate 1972, -2%
Agriculture: main crops -- sugar, tobacco, coffee, rice, potatoes, tubers,
citrus fruits
Fishing: catch 139,600 metric tons (1972); exports $26.3 million (1972), imports
$11.9 million (1971)
Major industries: sugar milling, petroleum refining, food and tobacco processing,
textiles, chemicals, paper and wood products, metals
, Shortages: spare parts for transportation and industrial machinery, consumer goods
Crude steel: 0.35 million metric tons capacity (planned 1969); 154,000 metric
tons produced (1972); 20 kg. per capita
Electric power: 1.25 million kw. capacity (1972); 5.1 billion kw.-hr. produced
(1972), 600 kw.-hr. per capita
Exports: $745 million (f.0.b., 1972 est.); sugar, nickel, tobacco
‘ Imports: $1,360 million (c.i.f., 1972 est.); capital goods, industrial raw
materials, food, petroleum
75
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partners: exports -- U.S.S.R. 30%, China 5%, other Communist
countries 17%, Japan 17%; imports -- U.S.5.R, 55%, China 5%, other
Communist countries 12% (1972 est.)
Monetary conversion vate: 1 peso=US$1.21 (nominal)
Fiscal year: calendar year','85c48ebee19f99c0b745b6f2441dd3ea4558836e099adb75da68bf8bc44ad215','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6860ae5c5ff4772d32b5a8fa359ca380b560a0f38b79883f2ca3e38432b1ae13',1973,'CY','Cyprus','economy',101,'GNP: $676 million (1971), $1,040 per capita; 1971 growth rate 14%, 1958 current
market prices
Agriculture: main crops -- vine products, citrus, potatoes, other vegetables;
food shortages -- grain, dairy products, meat, fish; caloric intake, 2,590
calories per day per capita (1961)
Major industries: mining (cupreous and iron pyrites, asbestos), manufactures
principally for local consumption -- food, beverages, footwear
Shortages: water, petroleum
Electric power: 204,000 kw. Capacity (1972); 691 million kw.-hr. produced (1972),
980 kw.-hr. per capita
Exports: $123 million (f.o.b., 1971); Principal items -- copper, pyrites, citrus,
raisins, and other agricultural products
Imports: $253 million (c.t.f.5: 1971): principal items -- manufactured goods ,
machinery and transport equipment, petroleum products, foods
Major trade partners: (1970) U.K. 32%, West Germany 11%, Italy 9%, EC 28.1%,
Communist countries 7.7%
Aid: economic -- U.S., $21.9 million authorized through FY71; IBRD, $39.5 million
(1963-71); U.N. Technical Assistance, $1.5 million (1953-71); U.N. Special
Fund, $9.4 million (1953-70)
Monetary conversion rate: ] Cyprus pound=US$2.61 (as of December 1971)
Fiscal year: calendar year
GNP: oe ten in 1972 (at 1971 prices), $2,540 per capita; 1972 real growth
rate 3.6%
Agriculture: diversified agriculture; main crops -~ wheat, rye, potatoes, sugar
beets; net food importer -- meat, wheat, vegetable oils, fresh fruits and
vegetables; caloric intake, 3,100 calories per day per capita (1967)
Major industries: machinery, food processing, metallurgy, textiles, chemicals
Shortages: ores, crude oil, grain
79
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Crude steel: 12.7 million metric tons produced (1972), 880 kg. per capita
Exports: $5,123 million (f.o.b., 1972); 50% machinery, equipment; 28% fuels,
raw materials; 4% foods, food products, and live animals; 18% consumer goods,
excluding foods (1971)
Imports: $4,662 million (f.o.b., 1972); 33% machinery, equipment; 44% fuels, raw
materials; 15% foods, food products, and live animals; 8% consumer goods,
excluding foods (1971)
Major trade partners: $9,785 million (1972); 70% Communist countries, 30% with West
Monetary conversion rate: commercial 5.80 crowns=US$1, noncommercial 11,5
crowns=US$1, tourist rate 13.3 crowns=US$1; old commercial rates: 6.63
crowns=US$1 in 1972; prior to 1972, 7.2 crowns=US$1
Fiscal year: calendar year
Note: foreign trade figures were converted at the 1972 rate
COMMUNTCATIONS:
Railroads: 8,262 mi.; 8,080 mi. standard gage, 70 mi. broad gage, 110 mi. narrow
gage; 1,745 mi. double track; 1,610 mi. electrified; government owned (1971)
Highways: 45,500 mi.; 600 mi. concrete; 24,100 mi. bituminous; 2,400 mi.
cobblestone, brick sett, stone block; 18,200 mi. crushed stone, gravel,
improved earth (1972)
Inland waterways: 517 mi. (1973)
Pipelines: crude oi1, 900 mi.; refined products, 535 mi.; natural gas, 2,500 mi.
Freight carried: rail -- 275.1 million short tons, 40.2 billion short ton/mi.
(1970); highway -- 852.5 million short tons, 7.5 billion short ton/mi. (1971);
waterway ~- 9.5 million short tons, 2.5 billion short ton/mi. (1972)
Ports: no maritime ports; outlets are Gdynia, Gdansk, Stettin in Poland; Rijeka,
Yugoslavia; Hamburg, West Germany; Rostock, East Germany; principal river
ports are Prague, Melnik, Usti nad Labem, Decin, Komarno, Bratislava (1973)
Merchant marine: 13 ships (1,000 GRT or over) totaling 117,300 GRT, 171,000 DWT;
includes 8 cargo, 5 bulk
Civil air: 45 major transport aircraft (1973)
Airfields: 134 total; 33 with permanent-surface runways; 19 with runways
8,000-11,999 ft., 49 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 3,658,000; 2,830,000 fit for military service;
about 124,000 reach military age (18) annually
Supply: produces aircraft, copies of Soviet air-to-air and antitank missiles,
armored vehicles, river patrol boats and gunboats, some light artillery,
substantial quantities of infantry weapons, ammunition, explosives, tactical
signal equipment, trucks, and small amounts of chemical warfare agents;
chemical and biological warfare defensive materiel; dependent on the U.S.S.R.
for more complex electronic equipment; amphibious armored reconnaissance
cars obtained from Hungary
80
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
DAHOMEY
LAND:
44,700 sq. mi.3 southern third of country is most fertile;
* arable land 80% (actually cultivated 11%), forests and
game preserves 19%, non-arable 1%
Land boundaries: 1,220 mi.
WATER:
7 Limits of territori
Coastline: 75 mi.
al waters (claimed): 12 n. mi.
Ue eer ee (1971 est.) $80 per capita; real growth rate, 6.5% per annum
967-71
Agriculture: major cash crop is oi] palms; peanuts, cotton, coffee, sheanuts,
tobacco also produced commercially; main food crops -- corns cassava, yams,
sorghum and millet; livestock, fish
Fishing: catch 33,000 tons (1971); exports none, imports 4,000 metric tons
Major industries: palm oil and palm kernel oil processing
Electric power: 11,810 kw. capacity (1972); 50 million kw.-hr. produced (1972),
; 18 kw.-hr. per capita
Exports: about $42 million (f.0.b., 1971); palm products (34%); other
agricultural products
Imports: about $76 million (f.o.b., 1971); clothing and other consumer goods,
cement, lumber, fuels, foodstuffs, machinery, and transport equipment
81
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partners: France, EC, franc zone; preferential tariffs to EC and
franc zone countries
Aid:
economic (1970) -- France, $8 million; EC, $4.2 million; U.N., $2 million;
West Germany, $1 million; Taiwan, $1 million; uU.S., (FY60-70) $12.8 million
Budget: 1972 est, -- receipts $50.2 million, current expenditures $42.3,
investment expenditures $9.4 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
frances; 255.785 CFA francs=US$1 as of February 1973 (currency floating
since February 1973)
Fiscal year: calendar year','b9c6884cd7d99e006c0a611dd0fc13c1ee0c86eb9f086e96213cc1503afb0666','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26bf12ba30d96047899430e450b8bbb126aa2a04444457415070ab6cbcd43b19',1973,'DK','Denmark','economy',105,'GNP: $20.3 billion (1972); $4,090 per capita; 61% private consumption, 21%
investment, 20% government, -2.0% net foreign balance (1971); 1972 growth 4,0%,
constant prices
Agriculture: highly intensive, specializes in dairying and animal husbandry ;
main crops -- cereals, root Crops; food shortages -- oilseeds, grain,
feedstuffs; caloric intake, 3,180 calories per day per capita (1968-69)
83
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Fishing: catch 1,379,235 metric tons (1971), $128 million; exports $144.3 million,
imports $33.7 million
Major industries: food Processing, machinery and equipment, textiles and clothing,
chemical products, electronics, transport equipment, metal products, brick d
and mortar, furniture and other wood products
Shortages: most industrial raw materials and fuels
Crude steel: 470,000 metric tons Produced (1971), 90 kg. per capita
Electric power: 4,900,000 kw. capacity (1972); 19 billion kw.-hr. produced
(1972), 2,800 kw.-hr, per capita
Exports: $3,833 million (f.0.b., 1971); Principal items -- meat, dairy products,
industrial machinery and equipment, textiles and clothing, chemical products,
transport equipment, fish, furs, and furniture
Imports: $4,865 million (c.i.f., 1971); Principal items -- industrial machinery,
transport equipment, petroleum, textile fibers and yarns, iron and steel
products, chemicals, grain and feedstuffs, wood and paper
Major trade partners: U.K. 16%, West Germany 16%, Sweden 16%, U.S. 8%, Norway 6%;
EC 28%; EFTA 46%; Communist countries 4% (1971)
Aid:
economic -~ (received) U.S., $301.8 million authorized 1946-72, none since
1958; IBRD --~ $85.9 million through 1971, none since 1964; net official
economic aid given to less developed areas and multilateral agencies,
$250.5 million (1960-70), $58.3 million (1969), $63.2 million (1970) $80
million (1971 provisional)
Monetary conversion rate: 6.282 Kroner=US$1 (March 1973, floating)
Fiscal year: 1 April - 31 March','3c5888c919399b2e853a9190095c48f706e089a720f89021cbda40bac6d3c780','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f12493f00e9f9800163ca413640cc13cbda17286a4d16e506823f2addc91c60',1973,'DO','Dominican Republic','economy',111,'GNP: $1.9 billion (1972), $440 per capita; real growth rate 1972, 9.0%
Agriculture: main crops -- sugarcane, coffee, cocoa, tobacco, rice, corn; self-
sufficient in rice; caloric intake, 2,200 calories per day per capita (1966)
Major industries: sugar processing, nickel mining, bauxite mining, peanut
r processing, textiles, cement
87
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Electric power: 256,500 kw. capacity (1971); 1 billion kw.-hr. produced
(1971), 250 kw.-hr. per capita
Exports: $347.0 million (f.0.b., 1972); sugar, nickel, tobacco, coffee, cocoa,
bauxite
Imports: $350.0 million (c.i.f., 1972); foodstuffs, petroleum, industrial raw
mterials, capital equipment
bess ins Partners: exports -- U.S. 65%, EC 144 (1970); imports -- U.S. 50%
1972
Aid:
economic -- from U.S. (FY46-71), $208.1 million in grants, $262.9 million
in loans; from international organizations (FY46-71), $100.7 million;
military -- assistance from U.S. (FY53-71), $28.3 million
Monetary conversion rate: 1 peso=US$1
Fiscal year: calendar year','16df0c414f265f7e5ecd32d00537142df59a2892a097bdba86f9050cd8f9d1af','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ede16d8791059a789ac5ebb38c4cec1b832ff652edde0bdf64a4c8ea89de01ed',1973,'EC','Ecuador','economy',115,'; GDP: $1.7 billion (at official exchange rate, 1971), $260 per capita;
72% private consumption, 14% public consumption, 14% gross investment (1970
est.); real growth rate 1971 est., 8%
Agriculture: main crops -- sugarcane, beans, coffee, cotton, corn, bananas,
potatoes, cocoa, rice; nearly self-sufficient; caloric intake, 2,100 calories
per day per capita (1964)
4 Fishing: catch 91,500 tons (1970), $12.1 million (1970); exports $10.2 million
(1970), imports negligible
89
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major industries: food processing, textiles, cement, leather and rubber products,
drugs, fishing, petroleum, fertilizer
Electric power: 328,000 kw. capacity (1971); 1 billion kw.-hr. produced
(1971), 164 kw.-hr. per capita
Exports: $241 million (f.0.b., 1971 est.); bananas, coffee, cocoa, sugar, fish
products
Imports: $366 million (c.i.f., 1971); agricultural and industrial machinery,
wheat, petroleum products, chemical products, transportation and communication
equipment
Major trade partners: U.S. 37%, EC 22%, Japan 14% (1970)
Aid:
economic -- extensions from U.S. (FY46-71), $208.7 million loans, $102.0
million grants; from international organizations (FY46-70), $152.4 million;
from Communist countries (1954-71), $15.4 million loans;
military -- assistance from U.S. (FY49-71), $60.6 million
Monetary conversion rate: 24.95 sucres=US$1 (official selling rate, excluding
petroleum}
Fiscal year: calendar year','7bed02ed4bc94013b200644f9a1d693c830ef09c768177522d65f6a5bb2afe1f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa22da2de1617638fd2302a7421884dcbe66f8f6380368015b01c22571987de4',1973,'EG','Egypt','economy',119,'Agriculture: main cash crop -- cotton; other crops -- rice, onions, beans, wheat,
corn, barley; not self-sufficient in food, but agriculture a net earner of
foreign exchange
Major industries: textiles, food processing, chemicals, petroleum, construction,
cement
Electric power: 4,555,000 kw. capacity (1972); 11.3 billion kw.-hr. produced
(1972), 322 kw.-hr. per capita
91
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Aid:
economic -- Communist countries, $1,976 million in credits through December
1972; U.S., $910.6 million in credits and grants through June 1967
(diplomatic relations and aid suspended June 1967, aid resumed January 1972); ’
sizable credits from international agencies, West Germany, Italy; large grants
from Libya since 1969; $250 million annual subsidy from Arab states while
canal is closed;
military -- Communist countries, about $3 billion through December 1972
Monetary conversion rate: 1 Egyptian pound=US$2.54 (selling rate); 0.394 Egyptian .
pound=US$1 (selling rate)
Fiscal year: calendar year, beginning in 1973','b9baaa303bd72cd5cc34aa155e6fc916b04a4b872bfd97a606ca58e37a2981a4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('754b09e712e0d5c92fc9613605c3ff3be5efb323f43a44f5a6b29c4ac45ce14d',1973,'SV','El Salvador','economy',123,'GNP: $1.06 billion (current prices, 1971), $290 per capita; 80% private
consumption, 9% government consumption, 11% domestic investment
(1971); real growth rate 1972 est., 4.0%
Agriculture: main crops -- coffee, cotton, corn, sugar, rice, beans; caloric
intake, 2,000 calories per day per capita (1963-64)
Fishing: catch 16,600 metric tons (1970); exports $5.4 million (1971), imports
$0.5 million (1971)
Major industries: food processing, textiles, clothing, petroleum products
Electric power: 220,000 kw. capacity (1972); 736 million kw.-hr. produced
(1972), 210 kw.-hr. per capita
Exports: 277.5 million (f.0.b., 1972); coffee, cotton, sugar, chemicals,
other manufactures
Imports: $276.6 million (c.i.f., 1972); machinery, automotive vehicles, petroleum,
foods tuffs
Major trade partners: exports -- U.S. 23%, CACM 35%, EC 23%, Japan
13%; imports -- U.S. 28%, CACM 25%, EC 16%, Japan 12% (1971)
Aid:
economic -~ from U.S. (FY46-71), $87.2 million loans, $59.3 million grants;
from international organizations (FY49-71), $104.7 million; from other Western
countries (1960-68) $3.7 million;
military -- assistance from U.S. (FY53-71), $6.9 million
Monetary conversion rate: 2.5 colones=US$1 (official)
Fiscal year: calendar year','dbf8fe344c6e2e12f61c0cf467a36b01893a519d80be9f1cced1e7f33bc48027','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3661ee3c797d5458994e4fd1acda7cede9812b2f3bba64551b590fc7c1c719e3',1973,'GQ','Equatorial Guinea','economy',127,'GDP: $63.7 million (1970 est.); $220 per capita
Agriculture: major cash crops -- Rio Muni, timber, coffee; Fernando Po, cocoa;
ies Ma crops -- rice, yams, cassava, bananas, oi] palm nuts, manioc, and
ivestoc
Fishing: catch 4,000 metric tons (1970); exports $86,000 (1970)
Major industries: fishing, sawmilling
Electric power: 2,800 kw. capacity (1972); 9 million kw.-hr. produced {1972},
about 30 kw.-hr. per capita
Exports: $24.9 million (1970); cocoa, coffee, and wood
Imports: $21.0 million (1970); foodstuffs, chemicals and chemical products,
textiles
Major trade partner: Spain
Aid: Spain, $14.0 million (1969); Libya, $1 million (1971)
95
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d)
Budget: 1970 current budget receipts $14.7 million, current expendi ture
$10 million, capital expenditure $10 million
Monetary conversion rate: 64.47 Guinean pesetas=US$1 (official)','4bb59eda88b9f7b72e345632842cd4aadfab46108c53fd90b99abd69dd674cff','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab33f1d6662e804f67815636de50f316cc576f02ac48d91aa479cf024a9eea5f',1973,'ET','Ethiopia','economy',131,'GDP: $1,629 million (1970 in current prices). $60 per capita; 1970 averaae annual
growth rate 6.1% (current prices)
Agriculture: main crops -- coffee, teff, durra, barley, wheat, corn, sugarcane,
cotton, pulses, oilseeds, livestock; almost self-sufficient in food
ee 6,927 metric tons (1970), $1.4 million (1970); exports $348,000
Major industries: cement, sugar refining, cotton textiles, food processing,
oil refinery
97
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Electric power: 306,000 kw. capacity (1972); 673 million kw.-hr. produced
(1972), 25 kw.-hr. per capita
Exports: $125.6 million (f.o.b., 1971); coffee 55.8%, hides and skins 8.2%,
oilseeds, oilcakes, and nuts 10.2%, cereals 7.4%; $4.6 million to Communist :
countries (1971)
Imports: $188.9 million (c.i.f., 1971); metals, machinery and vehicles 47.1%,
petroleum and chemicals 17%, foodstuffs, live animals, and beverages 7.3%;
$9.7 million from Communist countries (1970)
Major trade partners: imports -- Italy, Japan, West Germany, and U.S.;
exports -- U.S., West Germany, Italy, Saudi Arabia, Japan id
Monetary conversion rate: 2.07 Ethiopian dollars=US$1 (official as of February 1973)
Fiscal year: 8 July - 7 July
GDP: $70.1 million (1969), about $1,800 per capita
Agriculture: sheep and cattle grazing
Fishing: catch 210,100 tons (1971); exports $38.7 million
Major industry: fishing
Electric power: 27,545 kw, capacity (1971); 66.9 million kw.-hr. produced (1971),
1,713 kw.-hr. per capita
Exports: $33.5 million (f.0.b., 1970); fish and fish products
q Imports: $30.5 million (c.i.f.; 1970); machinery and transport equipment, pet-
roleum and petroleum products, food products
Major trade partners: (1970) Denmark 48%, U.K. 9%, Sweden 4%, U.S. 6%, Norway
4%; EC 15%; EFTA 68%
Monetary conversion rate: 6.282 Danish kroner=US$1 (March 1973, floating)
a Fiscal year: 1 April - 31 March
99
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNT CATIONS:
Railroads: none
Highways: none
Ports: 1 minor
Airfields: 1 with permanent-surface runway, less than 4,000 ft.
Civil air: no major transport aircraft
Telecommunications: good internationational radiocommunications; fair domes tic
Wire facilities; 9,400 telephones, 11,000 radio receivers, 1 AM, and 3 FM
stations; 3 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49 included with Denmark
100
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
esas
FALKLAND ISLANDS (MALVINAS )*
LAND:
Colony -- 4,700 sq. mi.; area consists of some 200 small
islands, chief of which are East Falkland (2,580 sq.
mi.) and West Falkland (2,038 sq. mi.); dependencies--
consists of the South Sandwich Islands, South Georgia,
and the Shag and Clerke Rocks
WATER: .
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 800 mi.
Government budget: Colony -- revenues, $1.0 million (FY68); expenditures,
$1.1 million (FY68)
Agriculture: Colony -- predominantly sheep farming; dependencies -- whaling
and sealing
Major industries: Colony -- wool processing; dependencies -- whale and seal
processing
Electric power: 1,440 kw. capacity (1971); 4 million kw.-hr. produced (1971),
1,740 kw.-hr. per capita
Exports: Colony -- $2.28 million (1969); wool, hides and skins, and other;
dependencies -- no exports in 1968 or 1969
Imports: Colony -- $1.22 million (1969); food, clothing, fuels, and machinery;
dependencies -- $8,368 (1969); mineral fuels and lubricants, food,
and machinery
Major trade partners: nearly all exports to the U.K., 77% of imports from the
U.K.3; dependencies -- exports to the Netherlands (63%) and Japan (37%),
imports from Curacao, Japan, and the U.K.
Monetary conversion rate: 1 Falkland Island pound=US$2.60','8a228de341b64f0e9f2f8e60592fd7fffa5e4dedb905966a280480a6b51823bf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e89d30458ca60958ad1f3a9cf2c730d5e79271b6475216939bb11970780ebeee',1973,'FJ','Fiji','economy',135,'ENP: $244 million (1971), $450 per capita; 5% average annual growth rate (1968-71)
Agriculture: main crops -- sugar, coconut products, bananas, rice; major
deficiency, grains
Major industries: tourism, sugar processing
Electric power: 61,300 kw. capacity (1972); 160 million kw.-hr. produced (1972),
296 kw.-hr. per capita
Exports: $56.2 million (f.0.b., 1971] excluding reexports); sugar, Copras copper
Imports: $128.3 million (c.i.f.; 1971); machinery » manufactured goods ; food
Major trade partners: U.K., Australia, U.S., Japan, New Zealand
Aid: disbursed 1968 -- Australia $1.5 million, U.S, $600,000, U.K. $4.2 million
Monetary conversion rate: 0.80 Fijian dollar=US$1 (December 1971)
Fiscal year: calendar year','51e82b00d7f2545507f3409ba86a6134cb70984e79eefbb4c6d356ae85403e1e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a4c3cc2ddb5683ed8da268b4a7c77814ff11891be43979c0271804e0215a986',1973,'FI','Finland','economy',138,'GNP: $12.9 billion (1972), $2,750 per capita; 53% consumption, 26.2%
investment, 21.9% government, -1.1% net exports of goods and services; 1972
growth rate 4.8%, constant prices
Agriculture: animal husbandry, especially dairying, predominates; forestry
important secondary occupation for rural population; main crops -- cereals,
sugar beets, potatoes; 85% self-sufficient; shortages -- food and fodder
grains; caloric intake 2,940 calories per day per capita (1970-71)
Major industries: include metal manufacturing and shipbuilding, forestry and
wood processing (pulp, paper), copper refining
Shortages: fossil fuels; industrial raw materials, except wood, and iron ore
Crude steel: 1.4 million metric tons produced (1972), 300 kilograms per capita
Electric power: 5,800,000 kw. capacity (1972); 22.3 billion kw.-hr. produced
(1972), 4,700 kw.-hr. per capita
Exports: $2,950 million (f.0.b., 1972); timber, paper and pulp, ships, machinery,
iron and steel, clothing and footwear
Imports: $3,200 million (c.i.f., 1972); foodstuffs, petroleum and petroleum
products, chemicals, transport equipment, iron and steel, machinery, textile
yarn and fabrics
Major trade partners (1972): 24% EC, 43% EFTA, 13% West Germany, 15% U.K.,
17% Sweden, 5% U.S., 12% U.S.S.R., 16% Communist countries
Aid: U.S. $184.1 million authorized FY46-71, $7.6 million in FY70; IBRD -- $276.5
million authorized through 1946-71, $33 million in 1971; Finnish foreign aid
programs have amounted to $23 million 1961-69, $15,000 in 1970
Monetary conversion rate: new markka (Fmk) 3.9=US$1 (February 1973, floating)
Fiscal year: calendar year','d82bdc608c1cd6621d9ef836fc8eea5ad262cfc86f40a0acc6f07a58c3e67656','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54a570bb005fbf6af5d784a23d6cc621b7ba9df13e255be4e39403ed6ae64035',1973,'FR','France','economy',141,'GNP: $197.0 billion (1972 est.), $3,810 per capita; 60% consumption, 27% investment
(including government), 12% government consumption; 1% net foreign balance;
1972 real growth rate 5.6%
Agriculture: Western Europe''s foremost producer; main crops -- beef, cereals, sugar
beets, potatoes, wine grapes; self-sufficient for most temperate zone food-
stuffs; food shortages -- fats and oils, tropical produce; caloric intake,
3,270 calories per day per capita (1969-70)
Fishing: catch 775,200 metric tons, $287 million (1970); exports $37 million
(1970), imports $204 million (1970); (converted at 5.55 fr.=US$1)
Major industries: steel, machinery and equipment, textiles and clothing,
chemicals, food processing, metallurgy
Shortages: crude oil, textile fibers, most nonferrous ores, coking coal, fats
and oils
Crude steel: 24.1 million metric tons produced (1972), 465 kilograms per capita
Electric power: 39,800,000 kw. capacity (1972); 163.4 billion kw.-hr. produced
(1972), 2,900 kw.-hr. per capita
Exports: $26.0 billion (f.o.b., 1972); principal items -- textiles and clothing,
iron and steel products, machinery and transportation equipment, foodstuffs
and agricultural products, alcoholic beverages; (converted at 5.1157 fr.=US$1)
Imports: $24.7 billion (f.0.b., 1972); principal items -- machinery and
equipment, crude petroleum, iron and steel products, textile fibers, coal
and coke, foodstuffs, alcoholic beverages; (converted at 5.1157 fr.=US$1)
Major trade partners: (1971) EC-Six 55%; West Germany 24%; Belgium-Luxembourg 12%;
Italy 13%; Netherlands 6%; U.K. 6%; U.S. 7%; Eastern Europe 3%; U.S.S.R. 1%; x
franc zone 7%
Aid:
economic (received) -- U.S., $5,343 million authorized (FY46-71), $128
million in FY71;
military -- U.S., $4,259 million authorized (FY46-71); net official economic
aid to less developed areas and multilateral agencies -- $7,431 million
(FY60-70), $1,220 million (1972 est.)
Monetary conversion rate: 4.6041 francs=US$1 (central rate)
Fiscal year: calendar year','de139670c1b562f738b29b3fb6be3f52936624c31ec0fb41d8d67cfb9b753d43','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f716f3b87d96209bfe33d3ef6ff1ce241a3f56b4c8ed71c3e00d6d37ae74e70f',1973,'GF','French Guiana','economy',145,'GNP: $40 million (at market prices, 1970), $800 per capita
Agriculture: main crops -- rice, corn, manioc, cocoa, bananas, sugarcane
Fishing: catch 900 metric tons (1969) $378,000; shrimp exports $3.9 million
(1969); imports $2.3 million (1969)
Major industries: timber, rum, gold mining, production of rosewood essence, and
space center
Electric power: 18,560 kw. capacity (1971); 55 million kw.-hr. produced (1971),
1,060 kw.-hr. per capita
Exports: $5.6 million (f.o.b. 1969); shrimp, timber, rum, rosewood essence
Imports: $51.7 million (c.i.f., 1969); food (grains, processed meat), other
consumer goods, producer goods and petroleum
Major trade partners: exports -- U.S. 78%, France 11%, Martinique 5%; imports --
France 49%, U.S. 10%, Trinidad and Tobago 3% (1969)
111
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Monetary conversion rate: 5.002 francs=US$1
Fiscal year: calendar year
Agriculture: livestock; desert conditions limit commercial crops to about 15
acres
Industry: ship repairs
Electric power: 18,000 kw. capacity (1972); 18 million kw.-hr. produced (1972),
292 kw.-hr. per capita
Imports: almost all domestically needed goods
Exports: hides and skins
Aid: $2.4 million in 1967 from France
Monetary conversion rate: 197.11 Djibouti francs=US $1 (official)
4 Fiscal year: probably same as that for France (calendar year)
COMMUNTCATIONS :
Railroads: 60 mi. meter gage
Highways? 620 mi.; 50 mi. paved, 570 mi. earth
z Ports: 1 major, 1 minor
113
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Airfields: 27 total, 10 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 7 seaplane station
Civil air: 5 major transport aircraft (registered in France)
Telecommunications: fair telephone services; poor telegraph facilities; 2,590
telephones; 10,000 radio receivers; 2,500 Ty receivers; 1 AM, no FM, and
1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 30,000; about 17,000 fit for military
service
Defense is responsibility of France
114
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','1da5e6332b8533d907f5e5dc16f8d02ab0a3142b572a0f39a5df9775d828ba58','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65f39b07627a73a25caa2a1b69e3a9a72c95be3b73bfab059793c9ed36d62521',1973,'GA','Gabon','economy',146,'D:
102,000 sq. mi.; 75% forested, 15% savanna, 9% urban and
wasteland, less than 1% cultivated
Land boundaries: 1,505 mi.
WATER:
Limits of territorial waters (claimed): 100 n. mi.
(fishing 30 n. mi.)
Coastline: 550 mi.
GDP: $378 million (1971, current prices), about $760 per capita; real GDP
growth 8.5%
Agriculture: commercial -- cocoa, coffee, wood, palm oil, rice; main food crops
-- bananas, manioc, peanuts, root crops; imports food
Fishing: catch 4,000 metric tons (1970); exports $600,000 (1970), imports -- not
available
Major industries: sawmills, petroleum refinery, natural gas, agricultural
processing; mining of increasing importance; major minerals -- manganese,
uranium, gold, and iron
Electric power: 34,200 kw. capacity (1972); 114 million kw.-hr. produced (1972),
222 kw.-hr. per capita
115
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d);
Exports: $202.5 million (f.0.b., 1971); wood and wood products 40%; minerals
(manganese, uranium concentrates, gold, crude oi1) 60% (1970)
Imports: $104.8 million (c.i.f., 1971) excluding UDEAC trade; mining, roadbuilding
machinery, electrical equipment, transport vehicles, foodstuffs, textiles
Major trade partners: France, U.S., West Germany, and Curacao; preferential
tariffs to EC and franc zone
Budget: 1971 -- receipts $93.9 million, current expenditures $72.8 million,
investment expenditures $20.9 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; 255.785 CFA francs=US$1 as of February 1973 (currency floating
since February 1973)
Fiscal year: calendar year','dfec73975167a457c320b363861d9df44605183bbeb12c76b3cdff6062b3aa20','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27f4f574b289ce46223b48117ce345d7a5baacd7066ad2710d72ddfea5ea063d',1973,'GM','Gambia','economy',153,'GDP: $46 million (FY71 est.), about $120 per capita
Agriculture: main crops -- peanuts, rice, palm kernels
Fishing: catch 5,000 tons (1970); exports $106,000 (1970)
Major industry: peanut processing
Electric power: 7,100 kw. capacity (1972); 17 million kw.-hr. produced (1972),
44 kw.-hr. per capita
Emportss, vlPe million (1970); peanuts and peanut products 90% to 95%, palm
ernels
Imports: $17 million (1970); textiles, foodstuffs, tobacco, machinery,
petroleum products
Major trade partners: exports -- U.K. and France; imports -- U.K. and Japan
Aid: economic -- U.K. (1968-71) about $8 million commitment
117
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Monetary conversion rate: floating with sterling since June 1972; new fixed
relationship as of March 1973 was 1 pound sterling=5 gambian delas
Fiscal year: 1 July ~ 30 June','cb136af252b2e048f7a5f6c14ffa265e67e12644880a9fff840a20ab7463d3b6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b861b4488f6c61d6b3a680fe4805a0acf07e62d35b593beb915b0a097350f7b0',1973,'GH','Ghana','economy',157,'GDP: $2.5 billion (1970) at current prices, about $280 per capita; real growth
rate about 3.6%
Agriculture: main crop -- cocoa; other crops include root crops, corn, sorghum
and millet, peanuts; not self-sufficient, but can become so
Fishing: catch 187,000 metric tons (1970), $35 million
Major industries: mining, lumbering, light manufacturing, fishing, aluminum
Electric power: 893,000 kw. capacity (1972); 3.49 billion kw.-hr. produced
(1972), 380 kw.-hr. per capita
Exports: $424 million (f.0.b.; 1970); cocoa (about 76%), wood, gold, diamonds ,
manganese, bauxite, and aluminum (aluminum regularly excluded from balance
of payments data)
Imports: $384 million (c.i.f., 1970); textiles and other manufactured goods,
food, fuels, transport equipment
Major trade partners: U.K., EC, and U.S.
123
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Monetary conversion rate: 1 Cedi=US$0.78 (official, February 1972); now floating
Fiscal year: 1 July - 30 June
COMMUN T CATIONS:
Railroads: 592 mi. -- all 3''6" gage; 20 mi. double track; diesel locomotives
gradually replacing steam engines
Highways: 21,350 mi., 3,100 mi. concrete or bituminous surface, 3,750 mi. gravel
or laterite, 3,700 mi. improved earth, 10,800 mi. unimproved earth
Inland waterways: Volta, Ankobra, and Tano rivers provide 145 mi. of perennial
Navigation for launches and lighters; additional routes navigable seasonally
by small craft; Lake Volta reservoir provides 700 mi. of arterial and
feeder waterways
Pipelines: refined products, 2 mi.
Ports: 2 major, 1 naval base (Sekondi), 4 minor
Merchant marine: 16 cargo ships (1,000 GRT or over) totaling 117,900 GRT,
157,600 DWT
Civil air: 5 major transport aircraft
Airfields: 22 total, 19 usable; 4 with permanent~surface runways; 2 with runways
8,000-11,999 ft., 8 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone fair to good in urban areas; fairly good telegraph
services; 49,100 telephones; about 755,000 radio receivers; 21,000 Ty
receivers; 2 AM, no FM, and 5 TY stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 2,221,000; 1,185,000 fit for military service;
120,000 reach military age (18) annually
Military budget: for fiscal year ending 30 June 1973, $29,650,000; 6.7% of
total budget
124
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
IRELAND: UNITED”
GIBRALTAR : 2 nanaoow »
LAND:
2.5 sq. mi.
Land boundaries: 1 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 7.5 mi.
.# GIBRALTAR
PEOPLE: } wonoceos ee
Population: 27,000 (official estimate for 1 July 1971) :
Ethnic divisions: mostly Italian, English, Maltese, and
Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages; Italian, Portuguese, and
Russian also spoken; English used in the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian laborers
Organized labor: 3,369, in 27 registered trade unions
Economic activity in Gibraltar centers on commerce and large British naval and
air bases. Nearly all trade in the well-developed port is transit trade and
port serves also as important supply depot for fuel, water, and ships’ wares.
Recently built dockyards and machine shops provide maintenance and repair
services to 3,500-4,000 vessels that call at Gibraltar each year.
U.K. military establishments and civil government employ nearly half the insured
labor force. Local industry is confined to manufacture of tobacco, roasted
coffee, ice, mineral waters, candy, and canned fish. Some factories for
manufacture of clothing are being developed. A small segment of local
population makes its livelihood by fishing. In recent years tourism has
increased in importance.
125
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Electric power: 29,000 kw. capacity (1972); 45 million kw.-hr. produced (1972),
1,500 kw.-hr. per capita
Exports: $2.9 million (f.o.b., 1971); principally reexports of tobacco,
petroleum, and wine; principally to the EC (31%) and the U.K. (16%)
Imports: $23.1 million; principally from the EC (21%) and the UK (49%)
Major trade partners: U.K., Morocco, Portugal, Netherlands
Monetary conversion rate: 1 Gibraltar pound=US$2.48 (value floating pound for
March 30, 1973)
NOTE: foreign trade data converted at 1 pound=US$2. 44','81bba6ccb90e02d4c42dc7243d8b1e7ff5f26620b10317eae869db43360799d3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8afc026a97dc4df237601e0f94df5f88c943a1bb5b17e93183de665226d4cca',1973,'GR','Greece','economy',161,'GNP: $12.6 billion (1972), $1,425 per capita; 78% consumption, 22% investment;
1971 growth rate 12.4%, current market prices
Agriculture: subject to droughts; main crops -- wheat, olives, tobacco, cotton;
nearly self-sufficient; food shortages -- livestock products; caloric intake,
2,960 calories per day per capita (1963)
Major industries: food processing, tobacco, chemicals, textiles, petroleum
refining, aluminum processing
Shortages: petroleum, minerals, feed grains
Crude steel: 210,000 metric tons produced (1969)
Electric power: 2,800,000 kw. capacity (1972); 1
(1972), 1,220 kw.-hr. per capita
Exports: $871 million (f.o.b., 1972}; principal items -- tobacco, cotton, fruits,
metals
Imports: $2,145 million (c.i.f., 1972); principal items -- machinery and
automotive equipment, manufactured consumer goods, petroleum and
petroleum products, chemicals
Major trade partners: (1972) -- 50% EC, 13% sterling area, 14% U.S.,
9% CEMA countries
Aid:
economic (authorized) --~ U.S., $1,886.8 million (1946-71); International
Finance Corporation, $14.9 million through 1971; U.N. Technical Assistance,
$4.1 million through 1971; U.N. Special Fund, $8.9 million through 1971;
IBRD, $71.3 million (1968-71), $20 million in 1971; Consortium, $40
miltion in 1966; EC (1964-71) $69.2 million;
military ~- U.S., $2,066 million (1946-71)
Monetary conversion rate: 30 drachmae=US$1 (official)
Fiscal year: calendar year
» 20 kg. per capita
2.050 billion kw.-hr. produced','cceb31e0bf70a71b4bc10e5ef3a0a47fe3d609420ef08342741e98b13ca45181','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('950213fe06eec6caedbd961aa174a4b2f8151c5333416efcbafa53665810196a',1973,'PE','Peru','economy',164,'GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep grazing; garden produce
Fishing: catch 38,159 tons, $6.3 million (1971)
Major industries: mining, slaughtering, fishing, sealing
Electric power: 27,338 kw. capacity (1972); 45.8 million kw.-hr. produced (1972),
935 kw.-hr. per capita
Exports: $14.0 million (f.o.b., 1970); fish and fish products, nonmetallic minerals
Imports: $52.9 million (f.0.b., 1970); machinery and transport equipment,
petroleum and petroleum products, food products
Major trade partners: (1970) Denmark 91%, U.S. 3%, Venezuela 3%
Monetary conversion rate: 6.282 Danish Kroner=US$1, (March 1973, floating)
Fiscal year: 1 April - 31 March','65fa3a8a72a0c12a505c4b35245d622fac2d860d36bf25bfb2f12d071467d519','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fc34a1b850850e7d4de4eb431830e490a9305fb4cb8467afc083ce65f7445bd',1973,'GD','Grenada','economy',168,'GDP: $30 million (at marketprices, 1970) $280 per capita
Agriculture: main crops -- cocoa, spices, bananas
Fishing: 1,500 metric tons, $618,000 (1970)
Electric power: 7,000 kw. capacity (1971 est.); 12.2 million kw.-hr. produced
(1971), 140 kw.-hr. per capita
Exports: $5.1 million (f.o.b., 1968); cocoa beans, bananas, nutmeg, mace
Imports: $13.2 million (c.i.f., 1968); textiles, flour, clothing, miscellaneous
manufactured goods
Major trade partners: U.K. 37%, U.S. 9%, Canada 9% (1966)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1, now floating with
pound sterling','d77610630fd382992f9e4d119be9a9d672fb1dd006094dd19db4be98eb3cff97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82df237b978a53a2c08ed5d4f3504aeb9e6b77fc6d533c340d9f742ee8a639f2',1973,'GP','Guadeloupe','economy',170,'GDP: $231 million (1970 est.), $680 per capita; real growth rate (1970 est.) 1%
Agriculture: main crops, sugarcane and bananas
Major industries: agricultural processing, sugar milling and rum distillation
Electric power: 38,000 (est.) kw. capacity (1971); 115 million kw-hr. produced
(1971), 341 kw.-hr. per capita
Exports: $38 million (f.0.b., 1970), sugar, bananas, rum
Imports: $128 million (c4sf.5 1970)s foodstuffs, clothing and other consumer
goods, raw materials and supplies, and petroleum
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partners: exports -- France 71%, U.S. 17%, Germany 7%, other
5%; imports -- France 70%, U.S. 9%, Germany 3%, Netherlands Antilles 3%,
Netherlands 3%, other 12% (1968)
Monetary conversion rate: 5.002 francs=US$1
Fiscal year: calendar year','3a1d96a4c7070e2449385346e295a8c3d4cc24a7f157f3930d3a9939a5b7f7fa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b55a040e4376642b95b19e4777ccf1146e38abeb148837dae6c89aea889e6d9',1973,'GT','Guatemala','economy',173,'GDP: $2.0 billion (1971), $370 per capita; 79% private consumption, 8% government
consumption, 14% domestic investment, -1% net foreign balance; real growth
rate 1972, 6.2%
Agriculture: main products -- coffee, cotton, corn, beans, sugarcane, bananas,
livestock; caloric intake, 2,200 calories per day per capita (1967)
Fishing: catch 5,000 metric tons (1970); exports $1,700,000 (1970), imports
$500,000 (1970)
135
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major industries: food processing, textiles and clothing, furniture, chemicals,
nonmetallic minerals, metals
Electric power: 178,600 kw. capacity (1971); 1 billion kw.-hr. produced
(1971), 1,050 kw.-hr. per capita
Exports: $335 million (f.o.b., 1972); coffee, cotton, meat, bananas, sugar,
textiles, tires
Imports: $300 million (c.i.f., 1972); manufactured products, machinery, trans-
portation equipment, chemicals, fuels
Major trade partners: exports (1972) -- U.S. 28%, CACM 28%, West Germany 11%,
Japan 10%; imports (1972) -- U.S. 34%, CACM 22%, West Germany 9%, U.K. 5%
Aid:
economic -- from U.S. (FY46-71), $182.7 million loans, $177.5 million grants;
from international organizations (FY46-71), $127.4 million; from other
western countries (1960-58) $7.6 million; military -- assistance from
U.S. (FY53-71), $24.4 million
Monetary conversion rate: 1 quetzal=US$1 (official)
Fiscal year: calendar year
GDP: about $275 million (1965), $80 per capita
Agriculture: cash crops -- coffee, bananas, palm products, peanuts, and pine-
apples; staple food crops -- cassava, rice, millet, corn, sweet potatoes;
livestock raised in some areas
Major industries: alumina, Tight manufacturing and processing industries,
7 bauxite
Electric power: 99,700 kw. capacity (1972); 310 million kw.-hr. produced (1972),
77 kw.-hr. per capita
Exports: export receipts, $51 million (FY71); alumina, bauxite, coffee,
pineapples, bananas, palm kernels
« Imports: $80 million (FY71); petroleum products, metals, machinery and
transport equipment, foodstuffs, textiles
137
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partners: Communist countries, Western Europe (including France),
U.S.
Budget: FY72 ordinary budget (est.) -- $113 million
Monetary conversion rate: 22.7 sy1i=US$1 (October 1972) a
Fiscal year: 1 October - 30 September','c77dee1b7f91e83b95156d31173288917fdeff16e1ac854aa78b08dcac5627c6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b97e25a8601c6816783ceff82e4fb539d7d08d0f025e9394d2eea059de42dab',1973,'GY','Guyana','economy',178,'GNP: $283 million (1971 est.), $360 per capita; real growth rate (1971 est.) 4%
Agriculture: main crops -- sugarcane, rice, other food crops; food shortages --
wheat flour, potatoes, processed meat, dairy products; caloric intake, 2,180
calories per day per capita (1967)
Fishing: catch 16,600 metric tons, $12 million (1970); exports $4.4 million (1970),
imports $1.5 million (1970)
Major industries: bauxite mining, alumina production, sugar and rice milling
139
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Electric power: 112,000 kw. capacity (1971); 340 million kw.-hr. produced
(1971), 460 kw.-hr. per capita
Exports: $137 million (f.0.b., 1971); bauxite, sugar, alumina, rice, shrimp,
molasses, timber, diamonds, rum
Imports: $131 million (c.i.f., 1971); manufactures, machinery, food, petroleum
Major trade partners: U.K. 26%, U.S. 25%, Canada 14%, Commonwealth Caribbean
countries 13% (1970)
Aid: economic -- from U.S. (FY53-71), $40.7 million loans, $22.9 million grants ;
from PRC (1972), $26.0 million extended; from international organizations
(FY46-71), $26.8 million
Monetary conversion rate: floating with pound, 1 pound=G$5.21
Fiscal year: calendar year
COMMUNT CATIONS:
Railroads: 103 mi., all single track; 85 mi. 3''0" gage, 18 mi. 3''6" gage
Highways: 1,450 mi.; 290 mi. paved, 620 mi. otherwise improved, 540 mi. unimproved
Inland waterways: 3,700 mi.; Demerara River navigable to Mackenzie by ocean
steamers, others by ferryboats, small craft only
Ports: 1 major, 3 minor
Merchant marine: 1 bulk carrier (1,000 GRT or over) totaling 3,000 GRT, 3,100
DWT
Civil air: 6 major transport aircraft
Airfields: 102 total, 89 usable; 4 with permanent-surface runways; 12 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: highly developed telecom system with radio relay network and
over 16,000 telephones; tropospheric scatter link to Trinidad; 257,000 radio
receivers, 2 AM and 1 FM stations
DEFENSE FORCES:
Military manpower: males 15-49, 180,000; 123,000 fit for military service
Supply: mostly U.K., some U.S. equipment
Military budget: for fiscal year ending 31 December 1971, $2.65 million; 2.7%
of central government budget
140
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','ac5c915466847f3316f0b79d975e6ffdfc9907dc1d67a7841bbc3410430fb909','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('873d8eaaf992f55d5ba8a1cdc389069f0a3629a9db0cec1e54d455fcdf7903ed',1973,'HT','Haiti','economy',179,'D:
10,700 sq. mi.; 31% cultivated, 18% rough pastures,
7% forested, 44% unproductive, 1965
Land boundary: 224 mi.
= ves : a,','55067222448c319df790c808cb1cac2f98d72ca3c8128788190cbbfaa149e06b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23614bb120b19060ab66b38149b1428091c5c45849ba487ba96b126c82169093',1973,'HK','Hong Kong','economy',184,'GNP: $4 billion 1971 (est.), $960 per capita (est.)
Agriculture: agriculture occupies a minor position in the economy; main crops --
rice, vegetables, dairy products; less than 20% self-sufficient; food
shortages -- rice, wheat
Major industries: textiles and clothing, tourism, plastics, electronics, light
metal products, food processing
Shortages: industrial raw materials, water, food
145
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Electric power: 1,820,000 kw. capacity (1972); 5.6 billion kw.-hr. produced
(1972), 1,369 kw.-hr. per capita
Exports: $3.4 billion (f.0.b., 1972), including $735 million reexports; principal
products clothing, plastic articles, textiles, electrical goods, wigs,
footwear, light metal manufactures |
Imports: $3.9 billion (c.i.f., 1972)
Major trade partners: 1972 exports -- U.S. 40%, U.K. 14%, West Germany 10%; imports
~- Japan 23%, China 18%, U.S. 12%
Monetary conversion rate: HK$5.085=US$1
Fiscal year: 1 April - 31 March','7012b205d2fa2817950f5a76d1f3b9f34d46ff764674d82c968df500b72c3526','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b47ae5edcbe23593140bde1adbaac1655816e3ddf972559e7507716edeeed99',1973,'HU','Hungary','economy',188,'GNP: $17.7 billion in 1972 (at 1971 prices), $1,700 per capita; 1972 growth
rate 2.9%
Agriculture: normally self-sufficient; main crops -- corn, wheat, potatoes,
sugar beets, wine grapes; caloric intake 3,140 calories per day
per capita (1970)
Major industries: mining, metallurgy, engineering industries, processed foods,
textiles, chemicals (especially pharmaceuticals)
Shortages: metallic ores (except bauxite), copper, high grade coal, forest
products
Crude steel: 3.27 million metric tons produced (1972), 310 kg. per capita
147
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Exports: $3,290 million (f.o.b., 1972); 27% machinery, 22% industrial consumer
goods, 27% raw materials and semimanufactures, 23% food and raw materials
for the food industry, energy sources 1% (distribution for 1972)
Imports: $3,150 million (1972); 24% machinery, 9% industrial consumer goods,
50% raw materials and semimanufactures, 10% food and raw materials for the
food industry, energy sorces 8% (distribution for 1972)
Major trade partners: $6,440 million (1972); 68% with Communist countries, 32%
with non-Communist countries
Monetary conversion rate: 9.72 forints=US$1 (commercial); 24.9
forints=US$1 (noncommercial); old commercial rates: 10.81 forints=US$1 in
1972; 11.74 forints=US$1 prior to 1972
Fiscal year: same as calendar year; economic data reported for calendar years
NOTE: Foreign trade figures were converted at the 1972 rate
GNP: $715 million (1972), $3,440 per capita; 65.3% consumption, 32.5%
investment, 9.8% government, -7.6% net foreign balance (1971); 1972 growth
rate 6.0%, constant prices
Agriculture: cattle, sheep, dairying, hay, potatoes, turnips; food shortages --
grains, sugar, vegetable and other fibers; caloric intake, 2,900 calories
per day per capita (1964-66)
149
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Fishing: catch 680,742 metric tons; exports $125.6 million (1971)
Major industries: fish processing, aluminum smelting, diatomite production
Shortages: grain, fuel, wood, minerals, vegetable fibers
Electric power: 358,000 kw. capacity (1972); 1.50 billion kw.-hr. produced
(1972), 7,700 kw.-hr. per capita
Exports: $185 million (f.o.b., 1972); fish and fish products, animal products,
aluminum, diatomite
Imports: $247 million (c.i.f., 1972); machinery and transportation equipment,
petroleum, foodstuffs, textiles
Major trade partners: (1972) Exports: EFTA 36%, EC 14%, U.S. 30%, U.S.S.R. 7%
Imports: EFTA 43%, EC 29%, U.S. 8%, U.S.S.R. 6%
Aid: economic -- U.S. authorized (1949-70) $89.3 million, $2.0 million
(1968) $2.3 million (1969), none in 1970, $1.2 million (1972); IBRD $30.0
million through December 1972
Monetary conversion rate: 98.56 kronur=US$1 (official) (March 1973-floating)
Fiscal year: calendar year','56b882ad9ecead97a793e9e490a18afc4f9984531a03f0bd8573998abbbd9eea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d9658edadd915de7dbde2a8ae49b74dad64b6ae52c50b3ae3f46404e2068d29',1973,'IN','India','economy',192,'GNP: $56 billion in current prices est. (year ending 31 March 1973), less than $100
per capita; real growth (FY72), -3% est.
Agriculture: main crops -- rice, other cereals, pulses, oilseeds, cotton, jute,
sugarcane, tobacco, tea, and coffee; must import foodgrains; caloric intake
is low and diet is deficient in protein
ei catch 1.9 million tons (FY71-72); exports $52 million (FY71-72), imports
100,000
Major industries: textiles, food processing
Crude steel: 6.1 million metric tons produced (FY72)
Electric power: 17,500,000 kw. capacity (1972); 68 billion kw.~hr. produced
(1972), 120 kw.-hr. per capita
Exports: $2.4 billion est. (f.o.b., FY72); tea, jute manufactures, iron ore, cotton
textiles, leather and leather products, iron and steel
Imports: $2.8 est. billion (c.i.f., FY72); machinery and transport equipment,
petraleom, iron and steel, grains and flour
Major trade partners: U.S., U.K., U.S.S.R. and Eastern Europe, Japan
Monetary conversion rate: 7.5 rupees=US$1 (effective April 1973)
Fiscal year: 1 April, stated year - 31 March','a3ce08d92c72ae0380af53ed3493170fc6878ec2eb0d88a65ce5eb0d453dddd1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('155fc7faacaed6d63784666843ae5ff0a6473e92b491aba70617a6eac999c946',1973,'AU','Australia','economy',196,'GNP: $9.4 billion (1970), less than $100 per capita; real average annual growth
(1965-70) 3.5% (est.)
Agriculture: subsistence food production, and smallholder and plantation
production for export; main crops -- rice, rubber, copra, other tropical
products; substantially self-sufficient; food shortage -- rice
Fishing: catch 1.2 million tons (1970); exports $4.5 million (1970), imports $0.3
million (1970)
Major industries: processing agricultural products and petroleum, textiles,
mining
Electric power: 1,225,000 kw. capacity (1972); 2.97 billion kw.-hr. produced (1972),
24 kw.-hr. per capita
Exports: $1,247 million (f.o.b., 1971); petroleum, rubber, tin, copra, tea, coffee,
tobacco, palm oi]
Imports: $1,082 million (f.0.b., 1971); rice, other foodstuffs, textiles, chemicals,
iron and steel products, machinery, transport equipment, consumer durables
Major trade partners: exports (1970) -- 16% U.S., 55% Japan, 4% Singapore, 9%
West Germany; imports -- 22% U.S., 55% Japan, 9% West Germany, 13% Singapore
Monetary conversion rate: 415 rupiah=US$1
Fiscal year: 1 April - 31 March
GNP: $14.2 billion (Iranian FY71-72), $460 per capita; real GNP growth,
Iranian FY71-72, 14.3%
Agriculture: wheat, barley, rice, sugar beets, cotton, dates, raisins, tea,
tobacco, sheep, and goats
Electric power: 2,851,000 kw. capacity (1972); 10.170 billion kw.-hr. produced
(1972), 330 kw.-hr. per capita
Exports: $344.5 million (non-oil, f.o.b. Iranian FY71/72); 89% petroleum; also
carpets, raw cotton, fruits, and nuts, hide and leather items, ores; Communist
countries (primarily U.S.S.R.) took about 31% of non-oil exports
Imports: $2,061 million (c.i.f., FY71/72); machinery, iron and steel products,
chemicals, pharmaceuticals, electrical equipment; Communist countries
supplied about 11% of commodity imports
Major trade partners: exports -- U.S., Japan, West Germany, U.S.S.R. and other
Communist countries; imports -- U.S., West Germany, U.K., Japan, U.S.S.R.
Budget: FY73-74 ~- revenues $6.9 billion, expenditures $7.0 billion
Monetary conversion rate: 75.75 rials=US$1 used throughout; effective February
1973 rate changed to 68.17 rials=US$1
Fiscal year: 21 March - 20 March
GNP: $28 million (1970), $4,000 per capita (est.)
Agriculture: negligible; almost completely dependent on imports for food, water
Major industries: mining of phosphates, about 2 million tons per year (1966)
Electric power: 8,300 kw. capacity (1972); 23 million kw.-hr. produced (1972),
3,286 kw.-hr. per capita
Exports: $17 million (f.0.b., 1968), consisting entirely of phosphates
Imports: $5 million (c.i.f., 1968)
Major trade partners: Australia, New Zealand, and United Kingdom
Monetary conversion rate: 1 Australian dollar=US$1.4167 (official )
Fiscal year: 1 July - 30 June
GNP: $193 million, $1,800 per capita (1971 est.)
€ Agriculture: large areas devoted to cattle grazing; major products -- coffee and
vegetables; 60% self sufficient in beef; must import grains and vegetables
Industry: mining of nickel
Electric power: 105,000 kw. capacity (1972); 780 million kw.-hr. produced (1972),
7,090 kw.-hr. per capita
4 Exports: $212 million (f.o.b., 1971) 98% nickel
Imports: $248 million (c.i.f., 1971) machinery, transport equipment, food
239
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partners: (1971) exports -- France (42%), Japan (47%), U.S. (9%);
imports -~ France (48%), Australia (14%)
Monetary conversion rate: 95 CFP francs=US$1
GNP: less than $100 per capita
Agriculture: principal crops -- corn, rice, rubber, coffee, copra
Electric power: 3,500 kw. capacity (1972); 10 million kw.-hr. produced (1972),
16 kw.-hr. per capita
Exports: $3.3 million (f.o.b., 1970); 89% coffee, 6% copra
Imports: $7.2 million (c.i.f., 1970); textiles, beer and wine, petroleum
Major trade partners: Portugal and its possessions, Far Eastern countries
273
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Monetary conversion rate: Portuguese escudo known in Timor as pataca; 28.75
pa tacas=US$1
Fiscal year: calendar year','6780706b7a7928e716ac2db151b96761c0113c28f0ab49e4ac146f6b3913300e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a28ac9aae0412eff8717ff653377e0a865f558f1f90828735b24991fc279e5ed',1973,'IQ','Iraq','economy',201,'GNP: $3.8 billion (1972 est.), $380 per capita
Agriculture: dates, wheat, barley, rice, livestock; largely self-sufficient
in food
Major industry: crude petroleum (fourth largest producer in Middle East)
Electric power: 908,000 kw. capacity (1972); 3.904 billion kw.-hr. produced (1972),
385 kw.-hr. per capita
Exports: $71 million (f.o.b., 1971), not including oi] revenue of $840 million
Imports: $756 million (c.i.f., 1971); 26% from Communist countries (1969)
Major trade partners: exports (non 011) -- U.S. 7%, Western European countries 4%,
Communist countries 15%, Arab countries 54%, other 20%; imports -- U.S. 4%,
Western European countries 44%, Japan 3%, Communist countries 26%, Arab
countries 7%, other 16%
157
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Monetary conversion rate: 1 Iraqi dinar=US$3.38 (end of March 1973)
Fiscal year: 1 April - 31 March','c2560fe53d680f796864b48a771368f797759ed60f18c6dc414fab26edb9750a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d457ed75276f57c14f86eaf5cccee34437a3dbaa0f603923d3e1223ec75210a',1973,'NL','Netherlands','economy',206,'GNP: $1,520 million est. (1972), $790 per capita; real growth rate 1972, 3%
Agriculture: main crops -- sugarcane, citrus fruits, bananas, pimento, coconuts,
coffee, cocoa
Major industries: bauxite, textiles, food processing, light manufactures, tourism
Electric power: 556,000 kw. capacity (1971); 1.6 billion kw.-hr. produced
(1971), 860 kw.-hr. per capita
169
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Exports: $380 million (f.o.b., 1972 est.); alumina, bauxite, sugar, bananas, citrus
fruits and fruit products, rum, cocoa
Imports: $560 million (f.0.b., 1972 est.); machinery, transportation and electrical
equipment, food, fuels, fertilizer
Major trade partners: exports -- U.S. 52%, U.K. 16%, Canada 8%, Norway 8%;
imports -- U.S. 43%, U.K. 19%, Canada 9% (1970)
Aid:
economic -- from U.S. (FY56-71), $67.2 million in loans; (AID $30.5 million,
Import-Export Bank $36.7 million), $41.0 million grants (AID technical
assistance $16.0 million, Food for Freedom $25.0 million); from international
organizations (FY46-71), $90.1 million; from other Western countries (1946-70),
$78.2 million;
military -- assistance from U.S. (FY63-71), $1.1 million
Monetary conversion rate: 1 Jamaican dol lar=US$1.10
Fiscal year: 1 April - 31 March','0dfea5007af9a60803a381b4c74e101ac72bde6745a03a8840138e71513e85b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('114a1c4120bf2f5c70f6fc19806028712a9449f687d95ebd8f41855887db140e',1973,'JO','Jordan','economy',210,'GNP: $600 million (1972 est.), $250 per capita
Agriculture: main crops -- wheat, fruits, vegetables, olive oi1; not self-
sufficient in many foodstuffs
Major industries: phosphate mining, petroleum refining, and cement production
Electric power: 46,260 kw. capacity (1972); 131 million kw.-hr. produced (1972),
54 kw.-hr. per capita
Exports: $47 million (f.o.b., 1972); major items -- fruits and vegetables,
phosphate rock; Communist share 5% of total (1971)
Imports: $271 million (c.i.f., 1972); major items -- petroleum products, textiles,
capital goods, motor vehicles, foodstuffs; Communist share 17% of total (1971)
Aid:
economic -~ U.S., $618 million economic assistance (FY49-71), of which $32
million loans, $585 million grants; technical assistance
military -- $191 million total from U.S. (July 1949-March 19717) including
$72 million in MAP grants
Monetary conversion rate: 1 Jordanian dinar=US$3.08, freely convertible; 0.325
Jordanian dinar=US$1
Fiscal year: calendar year','89257d6f16262e97d13d1416e1d76d84ad446f3be2af3fbbe76f0c05ea44b5df','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5142dab15601cf5e2a14df8fec594e91ee3fb422c4643e09ffe1bf597afbcf76',1973,'KE','Kenya','economy',214,'GDP: $1,438 million at 1964 prices (1971), $120 per capita; 5.7% real growth
per year between 1970 and 1971
Agriculture: main cash crops -- coffee, sisal, tea, pyrethrum, cotton, livestock;
food crops -- corn, wheat, rice, cassava; largely self-sufficient in food
Fishing: $4.2 million (1970)
Major industries: small-scale consumer goods (plastic, furniture, batteries,
textiles, soap, agricultural processing, cigarettes, flour), oil refining,
cement
Electric power: 217,000 kw. capacity (1972); 875 million kw.-hr. produced (1972),
70 kw.-hr. per capita
175
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Exports: $292.9 million (f.o.b., 1971); coffee, tea, livestock products, pyrethrum,
soda ash, wattle-bark tanning extract
Imports: $539.8 million (c.i.f., 1971); machinery, transport equipment, crude oil,
Paper and paper products, iron and steel products, and textiles
Major trade partners: U.K. and EC, also Uganda and
Tanzania, which are part of East African Economic Community
Monetary conversion rate: 1 Kenya shilling=US$0.14 (official); 7.143 Kenya
shillings=US$1
Fiscal year: 1 July - 30 June
GNP: roughly $300 per capita (1971)
Agriculture: main crops -- rice, corn, vegetables; food shortages -- meat,
cooking oi1s; production of foodstuffs adequate for domestic needs at low
levels of consumption
Major industries: machine building, electric power, chemicals, mining, metallurgy,
textiles, food processing
Shortages: heavy machinery and equipment, bituminous and coking coal, petroleum,
rubber
Exports: minerals, chemical and metallurgical products
Imports: machinery and equipment, petroleum, foodstuffs, coking coal
Major trade partners: total trade turnover about $1 billion (1972); about one-fifth
* with non-Communist countries, four-fifths with Communist countries (over
one-half with the U.S.S.R.)
rs
177
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Aid:
economic and military aid from the U.S.S.R. and China
Monetary conversion rate: 2.37 won=US$1 (arbitrarily established)
Fiscal year: calendar year
GNP: $9.8 billion (1972), $300 per capita; real growth 7.1% (1972)
Agriculture: 46% of the population live on the land, but agriculture, forestry
and fishery constitute 26% of GNP; main crops -- rice, barley, wheat; not
self-sufficient; food shortages -- barley, wheat, dairy products, rice, corn
Fishing: catch 1,074,000 tons, $245 million (1971 est.)
Major industries: textiles and clothing, food processing, chemical fertilizers,
chemicals, plywood, coal
Shortages: base metals, fertilizer, petroleum, lumber and certain food grains
Electric power: 3,060,000 kw. capacity (1972); 11.6 billion kw.-hr. produced
(1972), 356 kw.-hr. per capita
Exports: $1.6 billion (f.o.b., 1972); clothing and textiles, veneer and plywood,
wigs, fish products, electrical products, iron and steel scrap
Imports: $2.5 billion (c.i.f., 1972)
Major trade partners: 1972 exports -- U.S. 47%, Japan 22%; imports ~- Japan
39%, U.S. 28%
Aid:
economic -- U.S. (FY46-71), $5.3 billion committed; Japan (1965-70), $620
million committed;
military -- U.S. (FY46-71), $5.0 billion committed
Monetary conversion rate: 393 won=US$1 (floating-rate average value in 1972),
rate fixed at 400 won=US$1 by end of 1972
Fiscal year: calendar year','61095f8f0bd3ce10de7388564d13b788322ecef87d6960a777f76b28471dab2b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('564b3ab1ba0838fc4d33cef27df4b664ab062c0c97e2fcb71dbe3d43efeffd35',1973,'KW','Kuwait','economy',218,'Agriculture: virtually none, dependent on imports for food; approx. 75% of
potable water must be distilled or imported
Major industries: crude petroleum production averaging 3.3 million b.p.d.
(includes Kuwait''s share of neutral zone) (1972); government revenues from
taxes and royalties on production, refining, and consumption $1,700 million
in 1972; refinery capacity est. at 504,000 bbls. per day (1970); other major
industries include fishing, processing of building materials, fertilizers,
chemicals, and flour
Electric power: 1,070,800 kw. capacity (1972); 2.635 billion kw.-hr. produced
* (1972), 2,890 kw.-hr. per capita
Exports: $1,580 million (1970), of which petroleum accounted for about 98%;
nonpetroleum exports are mostly reexports, $96 million (f.0.b., 1971 est.)
Imports: $650 million (c.i.f., revised 1971) exclusive of oi] company imports;
major suppliers -- U.S., Japan, U.K., West Germany
181
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Monetary conversion rate: 1 Kuwaiti dinar=US$3.33 (end of February 1973)
Fiscal year: 1 April - 31 March
GNP: $205 million, $70 per capita (1971 est.)
Agriculture: main crops -- rice (overwhelmingly dominant), corn, coffee, cotton
and tobacco; largely self-sufficient; food shortages (due in part to
distribution deficiencies) including rice
Fishing: catch data unavailable; imports fish and fish products 200 tons,
$128,000 (1970)
Major industries: tin mining, timber
Shortages: capital equipment, petroleum, transportation system
Electric power: 54,500 kw. capacity (1972); 211 million kw.-hr. produced (1972),
68 kw.-hr. per capita
Exports: $2.8 million (f.o.b., 1971); tin concentrates; forest products, coffee,
undeclared exports of opium significant but value unknown
183
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Imports: $27.3 million (c.i.f., 1970); rice and other foodstuffs, petroleum
products, machinery, transportation equipment, textiles
Major trade partners: imports from Thailand, Japan, U.S., France, U.K., Indonesia,
Hong Kong; exports to Malaysia and Thailand; trade with Communist countries
insignificant; Laos a major transit point in world gold trade; value
of 1970 gold imports $26.4 million
Monetary conversion rate: 600 kip=US$1 for most transactions
Fiscal year: 1 July - 30 June','fd85c5812d58102b486b168135102fadcf8762cfbdbc0025cfb20991c1d4030e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1fd82553b66221718e9fb37a588eb4374eac719e26192532a28eabc28b12172',1973,'LB','Lebanon','economy',222,'Agriculture: fruits, wheat, corn, barley, potatoes, tobacco, olives, onions; not
self-sufficient in food
Major industries: service industries, food processing, textiles, cement, oi]
refining, chemicals, some metal fabricating, tourism
Electric power: 560,900 kw. capacity (1972); 1.4 billion kw.-hr. produced
(1972), 466 kw.-hr. per capita
Major trade partners: exports $270 million (f.o.b., 1971); most to Arab
countries; imports $818 million (c.i.f., 1971); chiefly from EC, U.K.,
and Arab countries; trade deficit covered by large net receipts from
invisibles (particularly tourism and transportation) and private capital inflow
Monetary conversion rate: 1 Lebanese pound=US$0.37 as of March 1973
Fiscal year: calendar year','883b1c0efa7a6608517105eff763c48c4dd2f54cd6a5401e6690e150c78c2616','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76884526edf47109bba80e88bbb64eec3933e513d877445414297f5103179be3',1973,'LS','Lesotho','economy',226,'GNP: $90 million (1968), about $100 per capita
Agriculture: exceedingly primitive, mostly subsistence farming and livestock;
principal crops are corn, wheat, pulses, sorghum, barley
Major industries: none
Electric power: 2,820 kw. capacity (1972); 6 million kw.-hr. produced (1972),
6 kw.-hr. per capita
Exports: labor to South Africa (remittances $15 million in 1969); $5 million
(f.0.b., 1970), wool, mohair, wheat, cattle, diamonds, peas, beans, corn,
hides, skins
Imports: $32 million (f.0.b., 1970); mainly corn, building materials, clothing,
vehicles, machinery, POL
187
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partner: South Africa
Aid: economic aid; U.K. $9.4 million (plan FY71-75); other $17.5 million (plan
FY71-75); no military aid
Monetary conversion rate: Lesotho uses the South African rand; 1 SA rand=US$1 .42;
.7046 SA rand=US$1
Fiscal year: 1 April - 31 March
GDP: $459.6 million (1972 est.), 5.0% current growth rate, $280 per capita
Agriculture: rubber, oi] palm, cassava, coffee, rice; imports of rice, wheat,
and meat are necessary for basic diet
Fishing: catch 18,500 metric tons, $6.1 million (1969)
Industry: rubber processing, food processing, construction materials, furniture,
palm o71 processing, mining (iron ore, diamonds), 10,000 b/d oi] refinery
Electric power: 225,200 kw. capacity (1972); 788 million kw.-hr. produced (1972),
483 kw.-hr. per capita
Exports: $237 million (f.o.b., 1972 est.); iron ore, diamonds, rubber, palm
kernels, coffee, cocoa
Imports: $176 million (c.i.f., 1972 est.); machinery, transportation equipment,
foodstuffs, manufactured goods
Major trade partners: U.S., West Germany, Japan, U.K.
Aid:
economic -- (FY46-71) U.S., $279.1 million;
military -- (FY53-71) U.S., $8.8 million; other aid sources include IBRD,
U.N., IMF, and West Germany
Monetary conversion rate: Liberia uses U.S. currency
Fiscal year: calendar year','4f09efa3a677b732ead0b2f0dfa0dffd6aaabd014f17845814ea41d4d28831bd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ecb1fc1be0f30a6fb3e511b7fec765b7ad308ca03bb71176a6308831c0e820e',1973,'LY','Libya','economy',230,'GDP: $4.8 billion (1972 est.), $2,300 per capita, little real per capita change
since 1969
Agriculture: main crops -- wheat, barley, olives, dates, citrus fruits, peanuts;
not self-sufficient in food
’ Major industries: petroleum production averaged 2.2 million b.p.d. (1972);
oil revenues for 1972 about $1.6 billion; food processing, textiles, handicrafts
194
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Electric power: 146,600 kw. capacity (1972); 640 million kw.-hr. produced (1972),
310 kw.-hr. per capita
Exports: $3,113 million (1971 at present conversion rate); over 99% petroleum
Imports: $2,225 million (1971)
Major trade partners: imports -- Italy, West Germany, U.S.; exports -- Italy,
West Germany, U.K., France
Aid: economic -- no Communist country assistance; U.S. aid extended $212.5
million (1949-72)
military -- arms obtained by cash purchase; chief suppliers France, U.S.S.R.,
Czechoslovakia; U.S. Suspended since September 1969
Monetary conversion rate: 1] Libyan pound=US$3.40 (April 1973)
Fiscal year: 1 April - 31 March
GNP: $30.5 billion in 1972 (at 1971 prices), $1,470 per capita; 1972 growth rate
8.4%
Agriculture: net exporter; main crops -- corn, wheat, oilseed; livestock --
cattle, hogs, sheep; caloric intake, 3,000 calories per day per capita (1967-68)
Fish catch: 75,000 metric tons (1971)
Major industries: machinery, metals, fuels, chemicals, textiles, food processing,
timber processing
Shortages: iron ore, coking coal, metallurgical coke, cotton fibers, natural
rubber
Crude steel: 7.4 million metric tons produced (1972), 360 kg. per capita
283
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Electric power: 9,100,000 kw. capacity (1972); 43.4 billion kw.-hr. produced
(1972), 2,085 kw.-hr. per capita
Exports: $2,585 million (f.o.b., 1972); 24% machinery and equipment; 40% fuels,
ie io semifinished products; 18% foodstuffs; and 18% consumer goods
1971
Imports: $2,613 million (mixture f.o.b. and c.i.f., 1972); 42% machinery and
equipment; 46% fuels, raw materials, semifinished products; 7% foodstuffs;
and 5% consumer goods (1971)
Major trade partners: 5,198 million in 1972; 45% non-Communist countries, 55%
Communist countries (1971)
Monetary conversion rate: 4.97 lei=US$1 (commercial) 14.4 lei=US$1 (tourist);
old commercial rates: in 1972, 5.53 lei=US$1, prior to 1972 6.00 lei=US$1
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year, 1 July -
30 June
Note: foreign trade data converted at 1972 rate','95233d301c3a90f642ecc1cb394f3c351bd34364f1f116276ac2c5814fc95db7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5611999a009d16c0f8c1f6af321e0344d7d4f6f7e8f60ccfa53668aae7049817',1973,'LI','Liechtenstein','economy',234,'Despite its small size and sparse natural resources, Liechtenstein has a
prosperous economy based primarily on small-scale light industry and farming.
Textiles, ceramics, precision instruments, pharmaceuticals, and canned foods
are the principal manufactures produced, almost entirely for export. Live-
stock raising and dairying are the main sources of farm income; cereals and
potatoes are the most important farm crops. The Liechtenstein economy is
tied closely to that of Switzerland in a virtual customs union. No national
accounts data are available.
Mag) ieee partners: exports (1971) -- $96.8 million; 34% Switzerland, 34% EC,
9% EFTA
Electric power: 22,600 kw. capacity (1972); 55 million kw.-hr. produced (1972),
1,800 kw.-hr. per capita; power is exchanged with Switzerland, but net
exports average 35 million kw.-hr. yearly','0e95d81e31f941524ee5a407a12556674c16bbf30d60d9c36017d3c0cf81f669','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26ed0dde9dcd76ae16f9ea9f898384344ad10f024f16d3915a091a86e9e1fd3f',1973,'LU','Luxembourg','economy',238,'GNP: $1,135 million (1971), $3,340 per capita; 60% consumption, 12% investment,
30% government, -2% net exports of goods and services; 1971 growth rate
0.7% at constant prices
Agriculture: mixed farming; main crops -- grains, potatoes, fodder beets; food
Shortages -- sugar, bread grains, fats; caloric intake, 3,150 calories per
day per capita (1968-69)
Major industries: iron and steel, food processing, chemicals, metal products and
engineering, tires
Crude steel: 5.5 million metric tons produced (1972), about 16,100 kg. per capita
Electric power: 1,204,000 kw. capacity (1972); 2.3 billion kw.-hr. produced
(1972), 6,920 kw.-hr. per capita
Exports: $794 million (f.o.b., 1971)
Imports: $737 million (c.i.f., 1971)
Major trade partners: Luxembourg and Belgium form an economic and customs union
and report their foreign trade Jointly (see Belgium); Luxembourg''s principal
exports are iron and steel products; principal imports are coal and consumer
products; most foreign trade is with Germany, Belgium, and other EC countries
Aid: foreign atd to Luxembourg is included in aid to Belgium
Monetary conversion rate: 40 Luxembourg francs=US$1 (average for weeks beginning
26 March 1973, floating); under the BLEU agreement, the Luxembourg franc is
equal to the Belgian franc which circulates freely in Luxembourg
Fiscal year: calendar year','e44cd2589e4b0a604317ffaa5aa7e1dd353ece33e8a913124ef8dc6d1038a2fd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdbbe494aa187eb2c403e1dfa802f4f8956db1db3b6052bb8aacd214f1247f69',1973,'MO','Macao','economy',242,'Agriculture: main crops -- rice, vegetables; food shortages -- rice, vegetables,
meat; depends mostly on imports for food requirements
Major industries: textiles, fireworks
Electric power: 28,500 kw. capacity (1972); 75 million kw.-hr. produced (1972),
310 kw.-hr. per capita
Exports: $50 million (f.o.b., 1971); textiles and clothing, foodstuffs, fireworks
Imports: $77 million (f.0.b.; 1971)
“ Major trade partners: exports -- Portuguese colonies 21%, Hong Kong 16%, West
Germany 17%; imports -- Hong Kong 65%, China 27% (1971)
Monetary conversion rate: 5.486 patacas=US$1 (June 1972)
Fiscal year: calendar year
197
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','e5ee2a6ee05d223e07a77f5757e79a2d81cd42b91b43501b3c3e9d744fcee342','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d61189d19021a0784feda3ad74683ef5d6e41626db20490100c6d2c9f523eff6',1973,'MG','Madagascar','economy',246,'GDP: $970 million (1971), about $140 per capita; a real increase of 4.5% between
1967 and 1971
Agriculture: cash crops -- coffee, vanilla, Sugar, tobacco, sisal, rice, cloves,
raphia; food crops -- rice, cassava, cereals, potatoes, corn, beans,
bananas, coconuts, and peanuts; animal husbandry widespread; self-
sufficient in foodstuffs, but some milk and cereals imported
Fishing: catch 50,000 metric tons (1970); exports $4.4 million (1971),
imports $700,000 (1970)
Major industries: agricultural processing (meat canneries, soap factories,
brewery, tanneries, sugar refining), light consumer goods industries
(textiles, glassware), cement plant, auto assembly plant, paper mill, oi]
refinery
Electric power: 58,000 kw. capacity (1972); 210 million kw.-hr. produced (1972),
30 kw.-hr. per capita
Exports: $147.3 million (f.0.b., 1971); coffee 26%, rice 5%, vanilla 9%, sugar
3%, petroleum products 4%, cloves 14%, mineral products (graphite, mica, and
chromite) 4%; agricultural and livestock products account for about 85% of
export earnings
Imports: $213.9 million (f.0.b., 1971); consumer goods 30%, foodstuffs 14%, primary
products (crude oil, fertilizers, metal products) 28%, capital goods 28% (1971)
Major trade partners: France (in 1971 accounted for 34% of exports and 56% of
imports); U.S., preferential tariffs to EC and franc zone countries; trade
with Communist countries remains a minute part of total trade
Monetary conversion rate: 255.78 Malagasy francs=US$1 (as of February 1973,
floating since then); member of French franc zone
Fiscal year: calendar year','bedd1668a393eca3dd90c046a1014a9da2dfddfeabf2c83989ee9da4a64c78e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6805c0ea4e72ff1bdbaa0d049480967e27a8b4b1b49e73617d144a088725bbc3',1973,'MW','Malawi','economy',250,'GDP: $362 million (1971), $80 per capita; average annual real growth rate
5.9% (1964-71)
Agriculture: cash crops -- tea, tobacco, peanuts, cotton, tung; subsistence
crops -- corn, sorghum, millet, pulses, root crops, fruit, vegetables, rice
Electric power: 42,000 kw. capacity (1972); 158 million kw.-hr. produced (1972);
34 kw.-hr. per capita
Major industries: agricultural processing (tea, tobacco, sugar), sawmilling,
cement, consumer goods
Exports: $78.7 million (f.o.b., 1972); tobacco, tea, groundnuts, cotton
Imports: $127.5 million (c.i.f., 1972); manufactured goods, machinery and
transport equipment, food, fuels
Major trade partners: exports -- U.K., Zambia, Rhodesia, U.S.; imports -- U.K.,
Rhodesia, South Africa
Aid:
economic -- U.K. provides both budgetary and development support, about
$96 million (1966-71); U.S. aid commitments, $26 million (1956-71);
military -- U.K., $0.9 million (1954-68)
201
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Monetary conversion rate: 1 Malawi kwacha=US$1 .30286 (as of 12 February 1973,
Floating with pound ster] ing)
Fiscal year: 1 April - 317 March','b3438dd5633b1b3659493cd48adc7487aaf7539742c2abf2573de0ac666dd245','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fa47c4b03685bdcca3e17e2d01f991c28da29482136cee045cfce2168ab51f5',1973,'MY','Malaysia','economy',253,'GNP:
Malaysia: $4.1 billion (1971), $380 per capita; average annual real growth
(1966-71) 4%
Agricul ture:
West Malaysia: mixed plantation and subsistence; main crops -- rubber, rice,
oil palm; 25% of rice requirements imported
Sabah: mainly subsistence; main crops -- rubber, coconut, rice; food deficit
-- rice
Sarawak: main crops -- rubber, pepper; food deficit -- rice
Fishing: catch 322,000 tons, $93.9 million (1971)
Major industries:
West Malaysia: rubber and oi] palm processing and manufacturing, tin mining
and smelting, logging and processing timber, light consumer goods
Sabah: logging
Sarawak: agriculture processing, petroleum refining, logging
Electric power:
West Malaysia: 1,100,000 kw. capacity (1972); 4 billion kw.-hr. produced
(1972), 434 kw.-hr. per capita
Sabah: 59,600 kw. capacity (1972); 143 million kw.-hr. produced (1972); 204
kw.-hr. per capita
Sarawak: 60,300 kw. capacity (1972); 134 million kw.-hr. produced (1972),
132 kw.-hr. per capita
205
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Exports: $1,672 million (f.o.b., 1971); 29% rubber, 18% tin, 17% timber
Imports: $1,473 million (c.i.f. 1971)
Major trade partners: exports -- 22% Singapore, 18% Japan, 13% U.S.;
imports -- 20% Japan, 15% U.K., 8% Singapore
Aid:
economic -- U.K. (1946-69) $260 million disbursed; Japan (1966-68) $50
million extended; IBRD (1959 - July 1971) $289 million (committed); U.S.
(1954-71) $87 million;
military -- U.S. (FY65-71) $19 million committed
Monetary conversion rate:
Malaysia: 2.54 Malaysian dollars=US$1
Fiscal year: calendar year','da9283eec84dd7d7aa7cbcf6d01a509c8654667614fce5b478e4017ddac8b106','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('035c308e912b4dd52a946818fe2f266b4c2d9ee8f031b4f8f9c2c69337d72a05',1973,'MV','Maldives','economy',257,'GNP: under $100 per capita
Agriculture: crops -- coconut and millet; shortages -- rice, wheat
Fishing: catch 32,000 tons (1970)
Major industries: fishing; some coconut processing
Electric power: 2,500 kw. capacity (1972); 9 million kw.-hr. produced (1972),
76 kw.-hr. per capita
Exports: $2.4 million (f.o.b., 1968); fish
Imports: $2 million (c.i.f., 1968)
Major trade partner: Sri Lanka
Aid: U.K. (1960-65), $1.4 million drawn; Sri Lanka (1967), $1 million committed
Monetary conversion rate: 6.39 rupees=US$1
Fiscal year: calendar year
GDP: about $280 million (FY71), per capita about $50
Agriculture: main crops -- millet, sorghum, rice, corn, peanuts; cash crops --
peanuts, cotton, livestock
Fishing: exports $1.4 million (1971)
Major industries: smal1 local consumer goods and processing
Electric power: 22,480 kw. capacity (1972); 52 million kw.-hr. produced (1972),
10 kw.-hr. per capita
Exports: $37.6 million (f.o.b., 1971); livestock, peanuts, dried fish, cotton,
skins
Imports: $48.6 million (f.o.b., 1971); textiles, vehicles, petroleum products,
machinery, and sugar
Major trade partners: mostly with franc zone and Western Europe; also with U.S.S.R.,','e79ee94fd15f8bd2d308dc0cce076b4ec1772a190324ffabb265f366cb51d14a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edef068495d9f4d9e782e42b6bbb02ae5f0a2489aba35cb50520839eec5f8f1f',1973,'CN','China','economy',258,'211
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Budget: 1971 est. -- receipts $44.9 million, current expenditures $43.6
million, investment expenditures $5.2 million
Monetary conversion rate: since December 1971, 511.57 Mali francs=US$1
Fiscal year: calendar year
GNP: $281 million (1971 current prices), $860 per capita; 71% private
consumption, 29% gross investment; 1971 growth rate 3% in current prices
Agriculture: overall, 20% self-sufficient; adequate supplies of vegetables, poultry,
milk and pork products; shortages in beef, grain, animal fodder, and fruits
at various seasons; main products -- potatoes, cauliflowers, grapes, wheat,
barley, tomatoes, citrus, cut flowers, green peppers, hogs, poultry, eggs
Major industries: ship repair yard, building industry, food manufacturing,
* textiles, tourism
Shortages: most consumer and industrial needs (fuels and raw materials) must be
imported
Electric power: 115,000 kw. capacity (1972); 312 million kw.~hr. produced (1972),
910 kw.-hr. per capita
» Exports: $50.2 million (1971); textiles, scrap metal, wine, agricul tural
products, and footwear
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Imports: $174.6 million (1971)
Major trade partners: U.K. 44%, Italy 15.7%; EFTA 48%; EC 28.2%; Communist
countries 2.5%; North and Central America 3.8%
Aid: economic -- U.S., $8.5 million (1949-71), of which $0.3 million authorized
in 1968, $1.7 million authorized 1969; $0.1 million authorized in 1970; and
$0.2 million authorized in 1970; U.K. Financial Agreement (loans and
grants) 1964-74, $140 million; IBRD $6 million through 1971, none since
1964; U.N. Special Fund $2.1 million through 1971, none since 1966; U.N.
Technical Assistance $1.3 million through 1970, of which $0.1 million in 1970
Monetary conversion rate: 1 Maltese Pound=US$2.67 (Smithsonian Agreement),
December 1971; the Maltese pound began floating in June 1972, with the rate
being determined between that of sterling and that of the currencies of
Malta''s major trading partners; average market rate, February 1973: 1 Maltese
pound=US$2.63
Fiscal year: 1 April - 31 March
GNP: $310 million (at market prices, 1970), $910 per capita
Agriculture: bananas, sugarcane, and pineapples
® Major industries: agricultural processing, particularly sugar milling and rum
distillation; cement, oi] refining and tourism
Electric power: 31,900 kw. capacity (1972); 128 million kw.-hrs. produced (1972),
400 kw.-hrs. per capita
Exports: $30 million (f.o.b., 1970), bananas, sugar, rum, pineapples
» Imports: $146 million (c.i.f., 1970), foodstuffs, clothing and other consumer
goods, raw materials and supplies, and petroleum
215
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trading partners: exports -- France 82%, Italy 9%, other 9%; imports --
France 70%, United States 6%, Netherlands Antilles 3%, Netherlands 3%, other
18% (1968)
Monetary conversion rate: 5.1157 francs=US$1
Fiscal year: calendar year','1b20d1a151166547fefcbe3780d5302fb69105cd7f75695a2cb3bc45f7e4ae4d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('143b013c5c619764b74b1c1a78a7523f2bd15407ba405531a36ddd85478c4ae3',1973,'MR','Mauritania','economy',265,'GDP: about $190 million (1970), about $160 per capita
Agriculture: most Mauritanians are nomads or subsistence farmers; main crops
-- livestock, small grains, dates; cash crops -- livestock, gum arabic
Fishing: catch, traditional river fishing, 15,000 metric tons (1969), traditional
sea fishing, 2,750 metric tons (valued at $437,000); fish supplied to processing
plants by foreign fishing fleets from France, Spain, Canary Islands using
Mauritanian waters; exports 21,090 metric tons, $7.3 million (1970)
Major industries: mining of iron ore, salt fishing, exploitation of copper
resources planned
Electric power: 38,000 kw. capacity (1972); 78 million kw.-hr. produced (1972),
64 kw.-hr. per capita
Exports: $102 million (f.o.b., 1971); iron ore, fish, gum arabic
Imports: $68 million (c.i.f., 1971); sugar, cloth, tea, and fuels
217
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partners: (trade figures not complete because Mauritania has a form
of customs union with Senegal and much local trade unreported) France and
other EC members, U.K., and U.S. are main overseas partners
Budget: 1971 est. -- receipts $33.4 million, current expenditures $33.4 million,
investment expenditures $3.5 million
Monetary conversion rate: 255.785 CFA francs=US$1 as of February 1973
(currency floating since February 1973) (official)
Fiscal year: calendar year','6428ca8b93d2689c01c70fcfcb76e4ac33c20db4469687c4fa881f24cf4936cb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4682461a718419724b10ffdf3316a2aef14b78327aa12309bb63c6c9dbb1cc1a',1973,'MU','Mauritius','economy',269,'GNP: $222 million (1972 est.), $260 per capita
Agriculture: sugar crop is major economic asset; about 40% of land area is planted
to sugar; tea production rising slowly; most food imported -- rice is the
staple food -- and since cultivation is already intense and expansion of
cultivable areas is unlikely, heavy reliance on food imports except sugar
and tea will continue
Shortage: land
Industries: mainly confined to processing sugarcane, tea; some small-scale,
simple manufactures; tobacco fiber; some fishing; tourism, diamond cutting,
weaving and textiles
Electric power: 61,340 kw. capacity (1972); 148 million kw.-hr. produced (1972),
171 kw.-hr. per capita
Exports: $65 million (f.0.b., 1971); mainly sugar, tea, molasses
Imports: $83.2 million (1971); foodstuffs 30%, manufactured goods 23%
Major trade partners: U.K. has preferential treatment, buys over 50% of Mauritius''
sugar export at heavily subsidized prices; small amount of sugar exported to
Canada, U.S., and Italy; imports from U.K. and EC primarily, also from South
Africa, Australia, and Burma; some minor trade with China
Monetary conversion rate: 5.12 Mauritian rupees=US$1 (floating with pound
sterling as of 12 February 1973)
Fiscal year: 1 July - 30 June
GNP: 55% tourism; 25%-30% industry (small and primarily tourist oriented); 10%-15%
registration fees and sales of postage stamps; about 4% traceable to the Monte
Carlo casino
Major industries: chemicals, food processing, precision instruments, glassmaking,
printing
Electric power: 8,000 kw. capacity (1972); 70 million kw.-hr. supplied by France
(1972), 2,000 kw.-hr. per capita
Trade: full customs integration with France, which collects and rebates Monacan
trade duties
Monetary conversion rate: 4.6041 francs=US$1 (central rate)
Agriculture: self-sufficient in animal products; main crops -- wheat, oats,
barley
Industries: processing of animal products and building materials; mining
Exports: animal and dairy products, fluorspar, woolen textiles, leather shoes,
glass, and paper
Imports: machinery and equipment, petroleum, cloth, coal, and building materials,
sugar, and tea
Major trade partners: nearly all trade with Communist countries (approx. 80%
with U.S.S.R.); total turnover about $330 million (1971)
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 3.31 tugriks=US$1 (arbitrarily established)
Fiscal year: calendar year
225
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','39e998a48aa8b76e1cf65d7f0df00a141c9ad899a78cd9079fafe2174c962172','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b87f8009afa112ced60d215a41a3a43e04fffac6735c3d9ddbb600857e172b68',1973,'MA','Morocco','economy',273,'GNP: $4.4 billion (1972 est.), about $280 per capita; average annual real growth
4.4% during 1960-72
Agriculture: cereal farming and livestock raising predominate; main crops --
wheat, barley, citrus fruit, wine, vegetables, olives; some fishing
Major industries: mining and mineral processing (phosphates, smaller quantities
of iron, manganese, lead, zinc, and other minerals), food processing, textiles
Electric power: 858,000 kw. capacity (1972); 2.088 billion kw.-hr. produced
(1972), 123 kw.-hr. per capita
Exports: $553 million (f.0.b., 1971); agricultural goods 54%, phosphates 23%,
other 23%
Imports: $773 million (c.i.f., 1971); food 24%, raw material and semi-finished
goods 38%, equipment 22%, consumer goods 16%
Major trade partners: exports -- France 36%, West Germany 9%, Italy 5%, U.K. 5%,
U.S. 2%; imports -- France 31%, U.S. 14%, West Germany 8%, Italy 6% (1971)
Monetary conversion rate: 4.24 dirhams=US$1 (selling rate February 1973)
Fiscal year: calendar year','747367e679270b6a13f7352ab1a9deb1187b95ea99ec09dc16d165e7d7b960bd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d605bd0fc43494daa21cf35793093468ea89f3d87c2ae38ca2ddb946ce40b6a',1973,'ZM','Zambia','economy',276,'GNP: $1.3 billion (1970 est.), about $170 per capita
Agriculture: cash crops -- raw cotton, cashew nuts, sugar, tea, copra, sisal;
other crops -- corn, wheat, peanuts, potatoes, beans, sorghum, and cassava;
self-sufficient in food except for wheat which must be imported
Major industries: food processing (chiefly sugar, tea, wheat, flour, cashew
kernels); chemicals (vegetable oi], oilcakes, soap, paints); petroleum
products; beverages; textiles; nonmetallic mineral products (cement, glass,
asbestos, cement products); tobacco
Electric power: 232,000 kw. capacity (1972); 563 million kw.-hr. produced (1972),
64 kw.-hr. per capita
229
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Exports: $169 million (f.0.b., 1971); cashew nuts, cotton, sugar, mineral products,
timber products, tea, copra, petroleum products
Imports: $354 million (c.i.f., 1971); machinery and electrical equipment, cotton
textiles, vehicles, petroleum products, wine, iron and steel ‘
Major trade partners: over one-third of foreign trade with Portugal; South Africa,
U.S., U.K., West Germany
Aid: from Portugal only
Monetary conversion rate: 27.25 escudos=US$1 (approximate realigned rate)
until February 1973, since then -- 25.5 escudos=US$1
Fiscal year: calendar year
GNP: $1.8 billion (1972 est.), $410 per capita; real growth rate 11% between 1965
and 1970
Agriculture: main crops -- corn, tobacco, cotton; net importer of all major
agricultural products
Fishing: catch 34,200 metric tons, $4.2 million (1970); imports $4.0 million (1970)
Major industries: copper mining and processing
Electric power: 788,200 kw. capacity (1972); 2,128 billion kw.-hr. produced
(1972), 484 kw.-hr, per capita
Exports: $679 million (f.o.b. 1971 provisional); copper, zinc, cobalt, lead,
tobacco
377
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Imports: $553 million (f.0.b., 197] provisional); consumer goods, machinery,
transport equipment, foodstuffs, fuels
Major trade partners: U.K., South Africa, Japan, Western Europe
Aid:
economic -- China $200 million credit for Tanzam railroad (1970);
(1964-67) U.K. $63 million; IBRD $99 million (1970); U.S. $17 million (FY62~71);
U.S.S.R. $6 million;
military -- $9 million (1964-69), mainly U.K. and Canada
Budget: 1972 est. -- revenue $410.5 million, current expenditure $435.4 million, ©
investment expenditure $192.1 million
Monetary conversion rate: 1 Zambia kwacha=US$1 .555 (official), 0.643 Zambia
kwacha=US$1
Fiscal year: calendar year','a6af4f1646e3f263bc45f24c0c95e773c7ecfe27ee93fbb38e1d8a5438ea77dc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43388ff371c74c37d1a2c9550c676857f7ddc79f8d9621e706d7abfa9d623685',1973,'NP','Nepal','economy',281,'GDP: $1 billion (1970), less than $100 per capita
Agriculture: over 90% of population engaged in agriculture; main crops -- rice,
corn, wheat, sugarcane, oilseeds; largely self-sufficient
Major industries: small rice, jute, sugar, and oilseed mills; match, cigarette,
and brick factories
233
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Electric power: 55,000 kw. capacity (1972); 84 million kw.-hr. produced (1972),
7 kw.-hr. per capita
Exports: $56 million (FY69); rice and other food products, jute, timber
Imports: $74 million (FY69); manufactured consumer goods, food grains and
food products
Major trade partner: over 90% India
Monetary conversion rate: 10.56 Nepalese rupees=US$1
Fiscal year: 15 July - 14 July','5e2207a88c682986e267603db8cdd5b315d69768562e5144852e4569b5fb795e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6885a55fab73f10fa8dccd906c7fab8d4d338609732139fb4c6b5f63df396cd6',1973,'NI','Nicaragua','economy',286,'GDP: $924 million (1971), $450 per capita; 73%
private consumption, 10% government consumption, 19% domestic investment, -2%
net foreign balance (1970); real growth rate 1971, 6.3%
Agriculture: main crops -- cotton, coffee, sugarcane, rice, corn, beans, cattle;
caloric intake, 2,300 calories per day per capita (1966)
Fishing: catch 7,200 metric tons (1970); $6.9 million (1977)
Major industries: food processing, chemicals, metal products, textiles and clothing
Electric power: 175,000 kw. capacity (1972 est.); 660 million kw.-hr. produced
(1972 est.), 340 kw.-hr. per capita
Exports: $187 million (f.0.b., 1971); cotton, coffee, meat, sugar, shrimp and
crayfish
Imports: $210 million (c.i.f., 1971); food and non-food agricultural products,
chemicals and pharmaceticals, transportation equipment, machinery, construction
materials, clothing, fuel
Major trade partners: exports -- U.S. 33%, Japan 18%, CACM 25%, Western Europe
15%; imports -- U.S. 33%, CACM 25%, Western Europe 19%, Japan 8% (1971)
Aid:
economic -- extensions from U.S. (U.S. FY46-71) $117.7 million loans, $61.4
miilion grants; international organizations (U.S. FY46-71) $136.2 million;
military -- from U.S. (U.S. FY46-71), $13.6 million
Monetary conversion rate: 7 cordobas=US$1 (official)
Fiscal year: calendar year','5dfc5f0f5e66e4dd17aff551de83f5ca020b201292126e62b2c438ad2dfd6859','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53267b7cebadc9b32c78e5d270ded5d302a4be365165d486e0c851f142ddaa78',1973,'NE','Niger','economy',290,'GDP: $372 million (1969 est.), less than $100 per capita
Agriculture: commercial -- peanuts, cotton, livestock; main food crops --
millet, sorghum, niebe beans, vegetables
Major industries: cement plant, brick factory, rice mill, small cotton gins, oil
presses, slaughterhouse, and a few other small light industries; uranium
production began in 1971
Electric power: 58,000 kw. capacity (1972); 52 million kw.-hr. produced (1972),
12 kw.-hr. per capita
Exports: $41.6 million (f.o.b., 1971); about 60% peanuts and related
products, rest largely livestock, hides, skins; exports badly understated
because much regional trade not recorded
Imports: $57.6 million (c.i.f.; 1971); fuels, machinery, transport equip-
ment, foodstuffs, consumer goods (largely for European residents); sizable
imports unrecorded
245
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partners: France (over 50%), other EC countries, Nigeria, UDEAC
countries, U.S.; preferential tariff to EC and franc zone countries
Aid:
economic -- France (1960 to mid-1967) $68 million; EC (1966-67) $51.3 million;
U.S. (FY62-71) $17.1 million; West Germany, Israel, Republic of China, and U.N.
have also extended aid;
military -- $2.8 million (1954-68)
Budget: 1970 -- expenditures $42.8 million, current (1970) expenditures (includes
extra budgetary transactions) $40.3 million, investment expenditures $3.7
million ;
Monetary conversion rate: 255.785 CFA as of February 1973 (floating since February
1973) francs=US$1 (official)
Fiscal year: 1 October - 30 September','60834871b445c09e1c0b9e3b90958a716520762b0fd4297e4f5f53baea512d6b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('add865a3dc126487641b83e036bf98610a0bbb96412564c0384b8a69e1d91c9d',1973,'NG','Nigeria','economy',294,'GDP: $6.4 billion (1971), $110 per capita; 12% growth rate 1971
Agriculture: main crops -- peanuts, cotton, cocoa, rubber, yams, cassava,
sorghum, palm kernels, millet, corn, rice; livestock; almost self-sufficient
Fishing: catch 156,000 metric tons (1970); imports $4.1 million (1970)
247
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major industries: processing industries -- oi] palm, peanut, cotton, rubber,
petroleum, wood, hides, skins; manufacturing industries -- textiles, cement,
building materials, food products, footwear, chemical, printing, ceramics;
mining -~ crude oil, natural gas, coal, tin, columbite
Electric power: 1,111,000 kw. capacity (1972); 1.8 billion kw.-hr. produced
(1972), 36 kw.-hr. per capita
Exports: $1.9 billion (f.0.b., 1971); of1, peanuts, palm products, cocoa, rubber,
cotton, timber, tin
Imports: $1.6 billion (c.i.f., 1971); machinery and transport equipment, manu-
factured goods, chemicals
Major trade partners: U.K., EC, U.S.
Budget: FY74 est. -- current revenue $2.14 billion, current expenditure $1.86
billion, capital expenditure $115 million
Monetary conversion rate: 1 Naira=US$1.52 (official )
Fiscal year: 1 April - 31 March','b08401466287f59cd1d063fd9cc69b487dfde30dbbedd90aecc08c0bbac14888','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59f2a1e7cc532cc3db45f4c46bb26ece7aed80619c966c78e6230996203539e5',1973,'NO','Norway','economy',298,'GNP: $15.8 billion (1972), $4,000 per capita; 50.3% consumption; 33.0% investment;
13.7% government; net foreign balance 3.0%; 1972 growth rate 4.0%, in
constant prices
Agriculture: animal husbandry predominates; main crops -- feed grains, potatoes,
fruits, vegetables; 40% self-sufficient; food shortages -- food grains, sugar;
caloric intake, 2,940 calories per day per capita (1969-70)
249
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Fishing: catch 2.8 million metric tons (1971), $243 million; exports $205 million
Major industries: food processing, wood pulp, paper products, metals, machinery,
chemicals, shipbuilding
Shortages: feed and bread grains, coal, petroleum and petroleum products, cotton,
wool
Crude steel: 863,000 metric tons produced (1971), 220 kilograms per capita
Electric power: 14,924,000 kw. capacity (1972); 63.6 billion kw.-hr. produced
(1972), 15,000 kw.-hr. per capita
Exports: $3,250 million (f.o.b., 1972); principal items -- fish and fish
products, metal and metal products, pulp and paper, chemicals, ships
Imports: $4,335 million (c.i.f., 1972); principal items -- ships, machinery,
fuels, foodstuffs
Major trade partners: 18.2% Sweden, 14.6% U.K., 14.7% West Germany, 6.4% U.S.,
6.8% Denmark; 25.6% EC; 45.8% EFTA; 3.7% Communist countries (1971)
Aid:
economic -~ U.S., $403.9 million authorized (1946-71), $2.2 million in 1970,
$48.7 million in 1971; IBRD, $145 million authorized through 1972,
none since 1964; net official economic aid delivered to Tess developed
areas and multilateral agencies, $134.2 million (1960-69) ;
$36.8 million (1970); $42.4 million (1971)
military -~ U.S., $900 million authorized (1946-71), none since 1967
Monetary conversion rate: 5.981 kroner=US$1 (February 1973, floating)
Fiscal year: calendar year','b4f323f5f5460d84f1f0aae3b5e62131b0ab04d77cfd2aa61b54eb35159aa756','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40ffb228feb49abc2cea8443bd8c639958738b3b2dd26c47636db425018e8c48',1973,'OM','Oman','economy',301,'GNP: $300 million (1972 est.), $630 per capita
Agriculture: based on subsistence farming (fruits, dates, cereals, cattle, camels,
fish) and trade
Major industries: petroleum discovery in 1964; production began in 1967; production
1972 equaled 280,000 b.p.d.; pipeline capacity 400,000 b.p.d.3; revenue for
1972 about $134 million est.
Electric power: 24,000 kw. capacity (1972); 70 million kw.-hr. produced (1972),
100 kw.-hr. per capita
Exports: $240 million (1972 est.); most of which is petroleum
Imports: $148 million (1972)
Major trade partners: U.K., Gulf states, India, Australia, China, Japan
Aid: multilateral annual average 1967-69 $350,000
Monetary conversion rate: 1 Riyal Omani=US$2.90 (as of February 1973)
Fiscal year: no budget year','a1333bcce717f5c2642e5abd56d0aeecbd7bd1f4f20cf4dd74ef3be5d9750121','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dae18c423a53a09cec996beee255f3f6ebf1440ab26cc09d47513bd903b806a',1973,'PK','Pakistan','economy',305,'GDP: $3.9 billion (FY72) at exchange rate of 11-rupees=US$1 prevailing June 1972,
less than $100 per capita; real growth (FY72) 1.7%
Agriculture: extensive irrigation; main crops -- wheat and cotton; largely
self-sufficient; foodgrain shortage due to increased consumption level
Fishing: catch 172,800 tons (1970 est.)
253
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major industries: cotton textiles, food processing, tobacco, engineering, chemicals,
natural gas
Electric power: 2,090,000 kw. capacity (1972);-8 billion kw.-hr. produced
(1972), 143 kw.-hr. per capita
Exports: $589 million (f.0.b., FY72); cotton (raw and manufactured)
Imports: $623 million (c.i.f., FY72) machinery, transport equipment, chemicals
Major trade partners: U.S., U.K., Japan, West Germany
Monetary conversion rate: 9.9 rupees=US$1 (Feb 73-May 73)
Fiscal year: 1 July - 30 June','ff3d81d6f10b82e4feda483f4ce69a75e97953ef4a6486d3206d4de80c93834d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ad26a3755ac5bdfff970928151b9158cf35d12e21d1b2d435e722b091f5e9c9',1973,'PG','Papua New Guinea','economy',310,'GNP: $550 million (FY70 estimate), $230 per capita; real average annual growth
rate (1960-69) 7.5%
Agriculture: main crops -- coconuts, coffee, cocoa, tea
Major industries: sawmilling and timber processing, copper mining (Bougainville)
Electric power: 78,000 kw. capacity (1972); 242 million kw.-hr. produced (1972),
93 kw.-hr. per capita
Exports: $117.2 million (f.o.b., FY71); principal products -- coconut products,
coffee beans, cocoa beans, timber
Imports: $292.8 million (f.o.b., FY71)
257
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partners: Australia, U.K., Japan
Aid: economic -- Australia (FY46-69) $909 million extended; World Bank group
(1968-September 1969) -- $7.5 million committed
military -- U.S. $28.7 million extended
Monetary conversion rate: Australian $1=US$1.4167
Fiscal year: 1 July - 30 June','3fa2b9dcd6cfa99a0f0a0b95f5f2ef246fd110274f3ab466d0ded681de6f25dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de2fb080bd0bd76da74cdc4e1df5b079d7c18411b794462c133e77c291e0083d',1973,'PL','Poland','economy',314,'GNP: $54.6 billion in 1972 at 1971 prices, $1,650 per capita; 1972 growth rate
.0%
Agriculture: self-sufficient for minimum requirements; main crops -- grain,
sugar beets, oilseeds, potatoes, exporter of livestock products and sugar;
importer of grains; 3,200 calories per day per capita (1970)
Fishing: catch 520,400 metric tons (1972)
265
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major industries: chemistry, food processing, transportation equipment, machine
building, iron and steel, textiles, and shipbuilding
Crude steel: 13.5 million metric tons produced (1972), about 410 kg. per capita
Exports: $4,929 million (f.0.b., 1972); 42% machinery and equipment, 34% fuels,
raw materials, and semimanufactures, 15% agricultural and food products,
9% light industrial products
Imports: $5,334 million (f.o.b., 1972); 43% machinery and equipment; 38% fuels,
raw materials, and semimanufactures; 12% agricultural and food products;
7% light industrial products
Major trade partners: $10,263 million (1972); 62% with Communist countries, 38%
with West
Monetary conversion rate: 3.32 zlotys=US$1 (commercial); 19.92 zlotys=US$1
(noncommercial); old commercial rates 4.00 zlotys=US$1 prior to 1972,
3.8 zlotys=US$1 in 1972
Fiscal year: same as calendar year; economic data are reported for calendar
years except for caloric intake which is reported for the consumption year,
1 July - 30 June
Note: foreign trade figures were converted at the 1972 rate','b09487ccdf33de4aba80f035db488a7788390e6847ae2d3ac916d83e49b6c737','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('208ba6508bd51ed45716e042e9aee81159d9a1b08d560c112ca9c9a33996f785',1973,'PT','Portugal','economy',318,'GNP: continental Portugal -- $6,956 million, $825 per capita; 75.6%
consumption, 16.9% investment, 14.7% government, -7.2 net exports of goods
and services (1971), growth rate 4.9% (1971) in 1963 constant prices
Agriculture: generally underdeveloped; main crops -- grains, potatoes, olives,
grapes for wine; food shortages -- sugar, wheat; caloric intake, 2,730
calories per day per capita (1969)
Fishing: catch 365,000 tons, $77.4 million; exports $46.6 million, imports $32.6
million, trade includes fish and fish products (1970)
Major industries: cotton textiles, cork processing, fish canning, petroleum
refining, pulp and paper, chenical fertilizer
Shortages: coal, petroleum, cotton, steel
Crude steel: 0.38 million metric tons produced (1970), 40 kg. per capita (1970)
Electric power: 2,900,000 kw. capacity (1972); 8.2 billion kw.-hr. produced
(1972), 900 kw.-hr. per capita
Exports: $1,070 million (f.o.b. 1971); principal items -- cotton textiles, cork
and cork products, canned fish, wine, timber and timber products, resin
Imports: $1,855 million (c.i.f., 1971); principal items -- petroleum, cotton,
industrial machinery, iron and steel, chemicals
Major trade partners: (1970) 16.5% U.K., 12% West Germany, 6.1% France, 7.9%
U.S., 10.7% Angola, 6% Mozambique; 27.5% EC; 28.2% EFTA; .7% Communist
countries
Aid:
economic -- U.S., $197.4 million (1949-71), $17.1 million authorized FY71;
IBRD, $57.5 million authorized (1964-66), none since 1966; net official
aid to less developed areas and multilateral agencies $462 million (1961-70),
$79.5 million (1969), $57.1 million (1970);
military -- U.S., $329.1 million authorized (1949-71)
Monetary conversion rate: 25.50 escudos=US$1 (1973 official), 1 escudo=about
US$0.04
Fiscal year: calendar year
Note: foreign trade figures converted at 28.25 escudos=US$1
GNP: $107 million (1969, in 1963 constant prices), $200 per capita
Agriculture: main crops -- palm oil, root crops, rice, coconuts, peanuts
Electric power: 1,200 kw. capacity (1972); 3 million kw.-hr. produced (1972),
6 kw.-hr. per capita
Exports: $3.6 million (f.o.b., 1969); principally peanuts, coconuts
Imports: $23.3 million (c.i.f., 1969); manufactured goods, fuels, transport
equipment, rice
271
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partners: mostly Portugal, also immediate neighbors
Aid: Portugal, small amounts
Monetary conversion rate: 25.5 escudos=US$1, (fixed. February 1973)
Fiscal year: probably is the calendar year','ddd4b395e0c6d4c31084ef4a62cc8a3fce9a1f0a731d474b39a7b5051aa566fb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0de951f561a9893190a44956c3d8db81cdc4f62a5030294d1bb72c803d1bbfeb',1973,'QA','Qatar','economy',323,'GNP: $275 million (1972 est.) $1,830 per capita
Agriculture: farming and grazing on small scale; commercial fishing increasing
in importance; most food imported; rice and dates staple diet
Major industries: oi] production and refining; crude 071 production from onshore
and offshore averaged 440,000 bbls. per day in 1972; 011 revenues $200
million (est.) in 1972, representing 99% of government/royal
family income; major development projects include $7 million harbor at Ad
Dawhah, fertilizer plant, 2 desalting plants, refrigerated storage for
fishing, and a cement plant
Electric power: capacity 80,000 kw. (1972); 200 million kw.-hr. produced (1972),
1,400 kw.-hr. per capita
Exports: crude oil dominates; reexports $4 million (1972)
Imports: approx. $124 million in 1972
Aid: multilateral annual average $170,000 (1967-69)
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.25 (as of February 1973)
Fiscal year: 1 April - 31 March
Agriculture: cash crops -- almost entirely sugarcane, small amounts of vanilla
and perfume plants; food crops -- tropical fruit and vegetables, manioc,
bananas, corn, market garden produce, also some tea, tobacco, and coffee;
food crop inadequate, most food needs imported
Major industries: 12 sugar processing mills, rum distilling plants, cigarette
factory, 2 tea plants, fruit juice plant, canning factory, a slaughterhouse,
and a number of small shops producing handicraft items
Electric power: 54,400 kw. capacity (1972); 108 million kw.-hr. produced (1972),
246 kw.-hr. per capita
Exports: $50 million (f.o.b., 1970); 90% sugar, 4% perfume essences, 5% rum and
molasses, 1% vanilla and tea
Imports: $162.6 million (c.i.f., 1970); manufactured goods, food, beverages,
and tobacco, machinery and transportation equipment, raw materials and
petroleum products
Major trade partners: France (in 1970 supplied 62% of Reunion''s imports, purchased
76% of its exports); Mauritius (supplied 12% of imports)
279
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1 as
of February 1973 (floating since February 1973)
Fiscal year: probably calendar year
GDP: $1,628 million (1971), $290 per capita; real growth rate 6% (1965-71)
Agriculture: main crops -- tobacco, corn, sugar, cotton; livestock; self-
sufficient in foodstuffs except wheat
Major industries: mining and steel, textiles
Electric power: 1,323,000 kw. capacity (1972); 6,804 million kw.-hr. produced
(1972), 1,195 kw.-hr. per capita
Exports: $420 million (f.o.b., 1971), including net gold sales and reexports;
tobacco, asbestos, copper, meat, chrome, gold, nickel, clothing, sugar
Imports: $418 million (f.o.b., 1971); machinery, petroleum products,
wheat, transport equipment
Major trade partners: South Africa, Portugal, and Portuguese territories
Aid: no substantial military or economic aid
Monetary conversion rate: 1 Rhodesian dollar=US$1.40 (official); 0.714 Rhodesian
dollar=US$]1
Fiscal year: 1 July - 30 June','9aef26a0e0ef98ba3a6d91b358066001ac2f160ee2d1c657a001dab36d606f45','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51e7791a7aa1f922e1ba06b78c0dd3239f7d48ecddb8073a1e167af00e073967',1973,'RW','Rwanda','economy',326,'GDP: $195 million (1970), $50 per capita
Agriculture: cash crops -- mainly coffee, tea, cotton, some pyrethrum; main
food crops -- bananas, cassava; stock raising; self-sufficiency increasing
but country still imports some foodstuffs
Major industries: mining of cassiterite (tin ore), agricultural processing, and
light consumer goods
Electric power: 21,460 kw. capacity (1972); 100 million kw.-hr. produced (1972),
28 kw.-hr. per capita
Exports: $24.1 million (f.o.b., 1971); mainly coffee, tea, pyrethrum, cassiterite
Imports: $35.8 million (c.i.f., 1971); textiles, foodstuffs, machines, equipment
Major trade partners: U.S., Belgium, Zaire
Aid: U.S., FY62-70, $8.1 million; Belgium, France, Germany, and Canada, FY64-67,
$33.4 million obligated
Monetary conversion rate: 92.105 Rwanda francs=US$1 (official) until March 1973,
since then the rate has been determined on a day to day basis
Fiscal year: calendar year
285
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','5ec3aabb5968b79ad7a9e26e31630bfa5b356eacd7b647c1fad094e7d801f0a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a113f92fcce1866c06083c20c5565f2fbc3cc72ed6f8b2366f165c2c423fe1a',1973,'SM','San Marino','economy',330,'Principal economic activities of San Marino are farming, livestock raising, light
manufacturing, and tourism; the government''s total budget for FY71 is about
$12 million, with the largest share of revenue derived from the sale of
postage stamps throughout the world and from payments by the Italian
government in exchange for Italy''s monopoly in retailing tobacco, gasoline,
and a few other goods; main problem is finding an additional $3 million to
finance badly needed water and electric power systems expansions
Agriculture: principal crops are wheat (average annual output about 4,400 metric
tons/year) and grapes (average annual output about 700 metric tons/year);
other grains, fruits, vegetables, and animal feedstuffs are also grown;
livestock population numbers roughly 6,000 cows, oxen, and sheep; cheese
and hides are most important livestock products
Electric power: obtained from Italy
Manufacturing: consists mainly of cotton textile production at Serravalle, brick
and tile production at Dogane, cement production at Acquaviva, Dogane, and
Fiorentino, and pottery production at Borgo Maggiore; some tanned hides,
paper, candy, baked goods, Moscato wine, and gold and silver souvenirs are
also produced
Foreign transactions: dominated by tourism; in summer months 20,000 to 30,000
foreigners visit San Marino every day; a number of hotels and restaurants
have been built in recent years to accommodate them; remittances from
Sanmarinese abroad also represent an important net foreign inflow; commodity
trade consists primarily of exchanging building stone, lime, wood, chestnuts,
wheat, wine, baked goods, hides, and ceramics for a wide variety of consumer
manufactures','bb2d397f69fcffdf8f9e0fd74fb8483082bc7a0a9bb5fd16a27448547525a622','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('774b636255506460a5cce55e74b9ea617cade85c9278a96bd4ae90078392ab77',1973,'SA','Saudi Arabia','economy',334,'GNP: $4.0 billion (FY72 est.), $710 per capita
Agriculture: dates, grains, livestock; not self-sufficient in food
Major industries: petroleum production 5.8 million barrels per day (1972); est.
payments to Saudi Arabian Government, $2,100 million (est.), in
19713; cement production and small steel-rolling mill and oi1 refinery; several
other light industries, including factories producing detergents, plastic
products, furniture, etc.; PETROMIN, a semipublic agency associated with the
Ministry of Petroleum, has recently completed a major fertilizer plant
Electric power: 290,000 kw. capacity (1972); 1 billion kw.-hr. produced (1972),
180 kw.-hr. per capita
Exports: $3,209 million (f.o.b., 1971); 99% petroleum and petroleum products
Imports: $909 million (c.i.f., 1971); manufactured goods, transportation equipment,
construction materials, and processed food products
Major trade partners: exports -- U.S., Western Europe, Japan; imports -- U.S.,
Japan, West Germany
Monetary conversion rate: 1 Saudi riyal=US$0.27 as of February 1973 (IMF par value,
freely convertible)
Fiscal year: follows Islamic year; the 1970-71 Saudi fiscal year covers the
period 2 September 1970 through 20 August 1971
295
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Aid:
economic -- $398 million credits extended through August 1972, $170 million
drawn through 1970; major donors include U.S.S.R., China, U.S. West
Germany, Saudi Arabia;
military -- $77 million from U.S.S.R.; $30 million from Eastern Europe;
$7 million through 1971, western military aid
Monetary conversion rate: 1 Yemeni rial=US$0.22 as of February 1973
Fiscal year: 1 July - 30 June
GNP: $23.0 billion (1972 est. at 1971 prices), $1,110 per capita; 1972 real growth
rate approx. 3.7%
Agriculture: diversified agriculture with many small private holdings and large
agricultural combines; main crops ~- corn, wheat, tobacco, sugar beets, and
sufficient in food except for tropical products, cotton, wool, and vegetable
meal feeds; caloric intake, 3,210 calories per day per capita (1967)
Major industries: metallurgy, machinery and equipment, textiles, wood
Shortages: fuels, steel, textile fibers, chemicals
Crude steel: 2.6 million metric tons produced (1972), 32.8 kg. per capita
Exports: $2,135 million (f.0.b., 1972); 18% foodstuffs and tobacco; 15% raw
materials, fuels, and chemicals; 32% machinery and equipment; 43% other
manufactures
Imports: $3,081 million (c.i.f., 1972); 10% foodstuffs and tobacco; 27.8% raw
materials, fuels, chemicals; 31% machinery and equipment; 31% other
manufactures
Major trade partners: $5,216 million (1972); 70% non-Communist countries (35%
EC, 6% U.S., 30% other non-Communist countries), 30% Communist countries
Aid: postwar credits extended mainly by the U.S. (about $3 billion, including grants
and $700 million in military aid); Western Europe (over $950 million); IBRD
($585 million); IMF (over $400 million); Communist countries extended credits
totaling $464 million in 1956 ($125 million drawing balance suspended in 1958)
Monetary conversion rate: 17.0 new dinars=US$]
Fiscal year: same as calendar year (all data refer to calendar year or to middle
or end of calendar year as indicated)
GDP: $2.1 billion (1971), about $90 per capita; real growth rate
6.5% p.a. 1968-71
Agriculture: main cash crops -- coffee, palm oil, rubber; main food crops --
manioc, bananas, root crops, corn; some provinces self-sufficient
Fishing: catch 122,000 metric tons (1970); imports $15.4 million (1969)
Major industries: mining, mineral processing, light industries
Electric power: 861,380 kw. capacity (1972); 3.5 billion kw.-hr. produced
(1972), 126 kw.-hr. per capita
Exports: $669 million (f.o.b., 1971); copper, cobalt, diamonds, other minerals,
coffee, palm oi]
Imports: $693 million (c.i.f., 1971); consumer goods, foodstuffs, mining
and other machinery, transport equipment, fuels
Major trade partners: Belgium, U.S., and West Germany
375
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Aid: economic -~ U.S. (FY61-70) $449 million; (1970 estimated disbursements)
Belgium, $27.4 million; France, $6.9 million; other bilateral aid $3 million;
U.N., $7.1 million; EC, $14.1 million military -- U.S., $39.2 million (FY62-71)
Budget: 1971 -- revenue $578 million, current expenditure $558.8 million,
investment expenditure $136.6 million
Monetary conversion rate: 1 zaire=US$2
Fiscal year: calendar year','807ab6025db67bfbab59445e63d158ada71dfb261c479447713b389c5b4a1d5b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50b269ef146bff21b8155c217da74c8370255295c56d8959222b261ba12602af',1973,'SN','Senegal','economy',338,'GDP: $746 million (1971); $190 per capita; real growth rate less than 1% (1966-71)
Agriculture: main crops -- peanuts, millet, sorghum, manioc, rice; peanuts
primary cash crop; production of food crops increasing but still
insufficient for domestic requirements
Fishing: catch 220,000 metric tons (1971); exports $12 million (1971),
imports (not available)
Major industries: fishing, agricultural processing plants, light manufacturing,
mining
Electric power: 134,200 kw. capacity (1972); 354 million kw.-hr. produced (1972),
88 kw.-hr. per capita
Exports: $135 million (f.o.b., 1971); approx. 33% peanuts and peanut products;
phosphate rock; canned fish
Imports: $237 million (c.i.f., 1971); food, consumer goods, machinery, transport
equipment
Major trade partners: France, EC (other than France), and franc zone
Aid: economic -- France (1966-70) $115 million; U.S. (1961-71) $39.1 million;
U.S.S.R. $6.7 million loan negotiated; EC (1962-71) $116.1 million;
military -- U.S. (FY61-71) $2.8 million
Budget: 1972 est. -- receipts $162 million, current expenditure $162 million,
investment expenditure $7.8 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
ice 255.785 CFA francs=US$1 as of February 1973 (floating since February
1973
Fiscal year: 1 July - 30 June','94445d03519fb24f667896983d118c65f43579e09fb765b40eb1331cc3f8d9ce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b14f55b326150794698f7044f471749172904da571662e21a84fee440d68fd77',1973,'SC','Seychelles','economy',342,'Agriculture: istands depend largely on coconut production and export of copra;
cinnamon, vanilla, and patchouli (used for perfumes) are other cash crops;
food crops -- small quantities of sweet potatoes, cassava, sugarcane, and
bananas; islands not self-sufficient in foodstuffs and the bulk of the
supply must be imported
Major industries: processing of coconut and vanilla, fishing, small-scale
manufacture of consumer goods, coir rope factory, tea factory
Electric power: 3,500 kw. ¢capacity (1972) 9 million kw.-hr. produced (1972),
171 kw.-hr. per capita
Exports: $2.1 million (f.0.b., 1970); cinnamon (bark and 011) and vanilla account
for almost 50% of the total, copra accounts for about 40%, the remainder
consisting of patchouli, fish, and guano
Imports: $10.1 million (c.i.f., 1970); food, tobacco, and beverages account for
about 40% of imports, manufactured goods about 25%, machinery and transport
equipment, petroleum products, textiles
Major trade partners: exports -- India, U.S.; imports -- U.K., Burma, India,
South Africa, Kenya, Australia
299
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Aid: $1.2 million in aid in both 1965 and 1966 from U.K.
Monetary conversion rate: 5.4 Seychelles rupees=US$1
Fiscal year: calendar year
GDP: $425 million (FY70), approx. $170 per capita; real growth rate 1970, 2%-3%
Agriculture: main crops -- palm kernels, coffee, cocoa, rice, yams, millet, ginger,
cassava; much of cultivated land devoted to subsistence farming; food crops
insufficient for domestic consumption
Fishing: catch 23,000 metric tons (1971)
Major industries: mining -- diamonds, iron ore, bauxite, rutile; manufacturing
~- beverages, textiles, cigarettes, construction goods; 1 oil refinery
301
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Electric power: 57,000 kw. capacity (1972); 154 million kw.-hr. produced (1972),
58 kw.-hr. per capita
Exports: $107 million (f.0.b., 1971); 61% diamonds; iron ore, palm kernels, cocoa,
coffee
Imports: $122 million (c.i.f., 1971); machinery and transportation equipment,
manufactured goods, foodstuffs, petroleum products
Major trade partners: U.K., EC, Japan, U.S., Communist countries
Monetary conversion rate: 1 leone=US$1.30 (official), as of December 1971,
floating with pound sterling since then; in March 1973, effective rate
1 leone=US$1 .18
Fiscal year: 1 July - 30 June (since 1 July 1966)
GNP: about $100 per capita
Agriculture: animal husbandry, cardamon, foodgrains, tea, and oranges
Industry: food processing and handweaving
Foreign trade: conducted and regulated by India
Electric power: 2,700 kw. capacity (1972); 8 million kw.-hr. produced (1972),
40 kw.-hr. per capita
Exports: cardamon and preserved fruits
Imports: consumer goods
Major trade partner: India
Aid: India (1955-66) $19.8 million committed and drawn; India (1967-72) $14.3
million committed (excludes $17.3 million spent on the development of
military roads)
Monetary conversion rate: 7.5 Indian rupees=US$1 (official rate); now floating
with U.K. pound
Fiscal year: 1 April stated year - 31 March','bf2024ce6f48eb7eba1043b657151ab96e5cbd648cbeeac8962493c4d406561a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f929df48d986d0e69a22533b192c1c0dab8b4962782d67e87478d511297a93ca',1973,'SG','Singapore','economy',346,'ur eee a (1972), $1,310 per capita; 13% average annual real growth
1965-71
Agriculture: occupies a position of minor importance in the economy, self-sufficient
in pork, poultry, and eggs, must import much of its other food requirements;
major crops -- rubber, copra, fruit and vegetables
Fishing: catch 14,000 metric tons (1971), imports -- 54,000 metric tons (1971)
Major industries: rubber processing and rubber products, processed food and
beverages, electronics, ship repair, entrepot trade
Electric power: 826,000 kw. capacity (1972); 3.2 billion kw.-hr. produced (1972),
1,488 kw.-hr. per capita
Exports: $1.8 billion (f.0.b., 1971); 60% reexports; petroleum products, rubber,
manufactured goods
305
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Imports: $2.8 billion (c.i.f., 1971); 25% goods reexported; major retained imports
-- capital equipment, manufactured goods, petroleum
Major trade partners: exports -- Malaysia, Indonesia, U.S., Japan, U.K.3
imports -- Japan, Malaysia, U.S., U.K.
Aid: U.K. -- (1960-September 1969) $254 million disbursed; (1969-73) $120
million extended; IBRD -- (1963-June 1970) $114 million committed, $61
million disbursed
Monetary conversion rate: 2.54 Singapore dollars=US$1
Fiscal year: converted to 1 April - 31 March fiscal year on 1 April 1970;
formerly on calendar year basis
GDP: $137 million (1968 est.), about $50 per capita
Agriculture: mainly a pastoral country; main crops -- bananas, livestock,
sugarcane, cotton, cereals
Major industries: a few small industries, including a sugar refinery, tuna
and beef canneries, iron rod plant
Electric power: 9,000 kw. capacity (1972); 18 million kw.-hr. produced (1972),
6 kw.-hr. per capita
Exports: $39.3 million (f.o.b., 1971, est.); bananas, livestock, hides, skins
Imports: $57.6 million (c.i.f., 1971, est.); textiles, cereals, transport
equipment
Major trade partners: Italy and U.K.; Arab countries; $6.9 million imports from
Communist countries (1970 est.)
Monetary conversion rate: 6.9252 Somali shillings=US$1 (official )
Fiscal year: 1 January - 31 December
307
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','27bc25fa0b8cefcbd5204a877aca6bc026dc5464a5835090ee0f13f23e805547','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('232aecb8834964b392d1dbed07a70620bbaefa14ca9de16563a800d3f7182a93',1973,'ZA','South Africa','economy',350,'GNP: $21.1 billion (1972), $940 per capita; real growth rate 3.1% (1972)
Agriculture: main crops -- corn, wool, dairy products, wheat, sugarcane,
tobacco, citrus fruits; self-sufficient in foodstuffs
Fishing: catch 481,000 metric tons (1972)
Major industries: mining, automobile assembly, metal working, machinery,
textiles, iron and steel, chemical, fertilizer, fishing
Electric power: 11,635,000 kw. capacity (1972); 63.993 billion kw.-hr. produced
(1972), 2,750 kw.-hr. per capita
Exports: $2.1 billion (f.o.b., 1971 excluding gold); wool, diamonds, corn,
uranium, sugar, fruit, hides, skins, metals, metallic ores, asbestos,
fish products; gold output $1.3 billion (1971)
Imports: $4.0 billion (f.o.b., 1971); motor vehicles, machinery, metals,
petroleum products, textiles, chemicals
Major trade partners: U.K. and other Commonwealth nations, U.S., Germany, Japan
Aid: no substantial military or economic aid
Budget: FY74 -- revenue $6.4 billion, expenditures $6.8 billion
Monetary conversion rate: 1 SA Rand=US$1.42, 0.7046 SA Rand=US$1
Fiscal year: 1 April ~ 31 March
Agriculture: livestock raising (cattle and sheep) predominates, subsistence
crops (millet, sorghum, corn, and some wheat) are raised but most food
must be imported
Fishing: catch 567,600 metric tons (1972) (processed mostly in South African
enclave of Walvis Bay)
Major industries: meatpacking, fish processing, copper, lead, and diamond
mining, dairy products
Electric power: 155,200 kw. capacity (1972); 543 million kw.-hr. produced (1972),
690 kw.-hr. per capita
Aid: South Africa is only major donor
Monetary conversion rate: 1 South African Rand=US$1.42; 0.7046 SA Rand=US$1
Fiscal year: 17 April - 31 March','d23a5eccfd6ecab74ac1bcd736c3aa6fa187fe62c410eed289a0c62a1a0d4753','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a1bd3e7802b3a47135b3a02ecc957720693d833dc2804dc091413465aa7672c',1973,'SD','Sudan','economy',355,'GDP: $1.6 billion (1969 provisional), under $100 per capita; 8% growth at
current prices 1968-69
Agriculture: main crops -- sorghum, millet, wheat, sesame, peanuts, beans,
barley; not self-sufficient in food production; main cash crops -- cotton,
gum arabic
Major industries: cotton ginning, textiles, brewery, cement, edible oils, soap,
distilling, shoes, pharmaceuticals
Electric power: 197,000 kw. capacity (1971); 453 million kw.-hr. produced (1971),
28 kw.-hr. per capita
Exports: $313 million (f.0.b., FY71); cotton (63%), gum arabic, peanuts,
sesame; $102 million exports to Communist countries (FY71)
Imports: $316 million (c.i.f., FY71); textiles, petroleum products, vehicles,
tea, wheat; $75 million imports from Communist countries (FY71)
Major trade partners: U.K., West Germany, Italy, India, U.S.S.R., China
Monetary conversion rate: 1 Sudanese pound=US$2.87 (official); 0.348 Sudanese
pound=US$1
Fiscal year: 1 July - 30 June
GNP: $300 million (1971); $720 per capita; real growth rate 1971 est., 4%
Agriculture: main crops -- rice, sugarcane, bananas; self-sufficient in major
staple (rice); caloric intake 2,350 calories per day per capita (1968)
Major industries: bauxite mining, alumina and aluminum production, lumbering, *
food processing
Electric power: 220,000 kw. capacity (1971); 1.3 billion kw.-hr. production
(1971), 3,260 kw.-hr. per capita
Exports: $154 million (f.0.b., 1971); bauxite, alumina, aluminum, wood and
wood products, rice a
Imports: $113 million (c.i.f., 1971); capital equipment, petroleum, iron and
steel, cotton, flour, meat, dairy products
Major trade partners: exports -- U.S. 39%, Canada 2%, Netherlands 14%; imports
-- U.S. 35%, Netherlands 22%, Europe 18% (1971)
Aid: economic -- extensions from U.S. (FY53-71), $5.0 million loans, $4.7 million
grants; from international organizations (FY49-71), $33.5 million
Monetary conversion rate: 1.79 Surinam guilders (S. f1.)=US$1 (27 December 1971)
Fiscal year: calendar year
GDP: approx. $80 million (1969), about $200 per capita; real growth rate about
8% (1967)
Agriculture: main crops -- maize, cotton, rice, sugar, and citrus fruits
Major industry: mining
Electric power: 67,800 kw. capacity (1972); 220 million kw.-hr. produced (1972),
500 kw.-hr. per capita
325
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Exports: $80.5 million (f.o.b., 1971); iron ore, asbestos, sugar, wood and forest
products, citrus, meat products, cotton
Imports: $67.9 million (f.0.b., 1971); food products, manufactured goods, machinery,
fertilizer, fuel «
Major trade partners: Japan, U.K., South Africa
Aid: economic aid -- U.K. $14.7 million (budgeted, 1971-73), others approximately
$1.3 million; no military aid
Budget: FY71 -- revenue $22 million, recurrent expenditure $20.1 million,
development expenditure $3.5 million ¢
Monetary conversion rate: 1 South African Rand=US$1.42 (Swaziland uses the South
African Rand; 0.7046 SA Rand=US$1
Fiscal year: 1 April - 31 March','8d5f85b1321aacf6cf13ea60a8f8e73481ad0328af4dee5bb5d89a9bf67ab143','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd4fda0fd3986dcc507748fadff895ecdeb931a48b56dcf474ba43f019be7b3b',1973,'SE','Sweden','economy',358,'GNP: $41.8 billion, $5,140 per capita (1972); 53.5% consumption, 22.1% investment,
23.3% government; 1.1% net exports of goods and services (1971); 1972 growth
rate 2.1% in constant prices
327
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Agriculture: animal husbandry predominates with milk and dairy products
accounting for 40% of farm income; main crops -- grains, sugar beets,
potatoes; 80% self-sufficient; food shortages -- oils and fats, tropical
products; caloric intake, 2,880 calories per day per capita (1967-68)
Major industries: iron and steel, precision equipment (bearings, radio and
telephone parts, armaments), shipbuilding, wood pulp and paper products,
processed foods, textiles, chemicals
Shortages: coal, petroleum, textile fibers, potash, salt
Crude steel: 5.3 million metric tons produced (1971), 650 kilograms per capita
Electric power: 17.15 million kw. capacity (1972); 69 billion kw.-hr. produced
(1972), 8,200 kw.-hr. per capita
Exports: $8,763 million (f.0.b., 1972}; machinery, motor vehicles
and ships, wood pulp, paper products, iron and steel products, metal ores
and scrap, chemicals
Imports: $8,088 million (c.i.f., 1972); machinery, motor vehicles, petroleum and
petroleum products, textile yarn and fabrics, iron and steel, chemicals, food,
and live animals
Major trade partners: (1971) West Germany 15.0%, U.K. 13.8%, U.S. 7.2%, Norway
8.3%, Denmark 9.0%; EFTA 42.4%; EC 29.7%; Communist countries 4.8%
Aid: economic -- U.S., $206.4 million authorized (FY46-71); $18.5 million in 1971;
net official aid to less developed countries and multilateral agencies, $662.4
mitlion (1960-70), $71.4 million in 1968, $120.8 million in 1969, $154.6
million in 1970, $180 million in 1971
Monetary conversion rate: 4.56 kronor=US$1 (17 February, 1973 floating)
Fiscal year: 1 July - 30 June','55be143e0003b9d73f6bd32777d2c5d090fba23c4418d85a3b9b97de7245459f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a337fdacbd96c88386068d2b840adace6f59c49bb754963391a2d3d0361e5bc8',1973,'TG','Togo','economy',364,'GDP: $290 million (1971), about $140 per capita; estimated real growth 1966-70,
5.3% average annual rate
Agriculture: main cash crops -- coffee, cocoa; major food crops -- yams, cassava,
corn, beans, rice, fish; must import some foodstuffs
Major industries: phosphate mining, agricultural processing, handicrafts,
textiles, beverages
Electric power: 18,750 kw. capacity (1972); 42 million kw.-hr. produced (1972),
10 kw.-hr. per capita
Exports: $49.2 million (f.0.b., 1971); phosphates, cocoa, coffee, palm
kernels, and cassava
Imports: $70.2 million (c.i.f., 1971); consumer goods,
fuels, machinery, tobacco, foodstuffs
337
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Major trade partners: mostly with France and other EC countries
Aid: (1970 disbursements) France $2.3 million, West Germany $2.0 million, U.S.
$1.0 million (FY60-71 total commitments $18.3 million), EC $5.5 million,
U.N. $1.0 million, others $1.1 million
Budget: 1972 -- revenue $48.1 million, current expenditure $41.8 million,
investment expenditure $6.3 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; 255.785 CFA francs=US$1 as of February 1973 (since then currency
floating)
Fiscal year: calendar year','eb786c5d5f5d95c1f67a070c2b61f6c9f4bd75be16bada46faa2a3a6b80b2e83','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c00044b5391425076c6102b0ceaf28e40a88e3df86914acdadfaf5c906c22411',1973,'TO','Tonga','economy',368,'Agriculture: largely dominated by coconut production with subsistence crops of
taro, yams, sweet potatoes, and bread fruit
Electric power: 3,500 kw. capacity (1972); 10.4 billion kw.-hr. produced (1972),
114 kw.-hr. per capita
Exports: $3.8 million (f.0.b., 1969); copra, coconut products 71%, bananas 20%
Imports: $5.7 million (c.i.f., 1969)
Major trade partners: (1969) exports -- 30% New Zealand, 30% Norway, 15%
Netherlands; imports -- 32% New Zealand, 25% Australia, 13% U.K.
Monetary conversion rate: 0.840 Tonga dollar=US$1','95ecaa75d99cb2d3596640ff31aa643f612d88d20a2037decf606d665d57edc6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db63a74533b77215cf7902c196ec512820a83fc734cbc4adccb6d4be30e2558d',1973,'TN','Tunisia','economy',373,'GNP: $2.1 billion (1972 est.), $390 per capita; 13.2% average annual growth rate
1970-72
Agriculture: cereal farming and livestock herding predominate; main crops --
wheat, barley, olives, fruits (especially citrus), viticulture, vegetables,
dates
Major industries: mining, food processing, textiles and leather, light
manufacturing, construction materials, chemical fertilizers
Electric power: 300,000 kw. capacity (1972); 768 million kw.-hr. produced (1972),
124 kw.-hr. per capita
343
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Exports: $181 million (f.0.b., 1971); 26% petroleum, 21% phosphates, 9% olive
oil, 16% other agricultural products, 28% other
Imports: $346 million (c.i.f., 1971); 36% raw materials, 23% machinery and
equipment, 14% consumer goods, 19% food and beverages, 3% energy, 5% other
Major trade partners: exports -- France 20%, Italy 20%, West Germany 13%, Libya
10%; imports -- France 36%, U.S. 15%, Italy 19%, West Germany 7% (1971)
Monetary conversion rate: 0.44 dinar=US$1 (1973 par value)
Fiscal year: calendar year
GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2.8 million kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $616.5 million (f.o.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Monetary conversion rate: 14 Turkish liras=US$1 (official rate)
Fiscal year: 1 March - 28 February','9964ba418c14c1e344857662de4a84b9cca21b177bc0fce956f69409fa393fe7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9533a96cb8d0050a62e51666f9e180d44786a4a4caaebefde88fa3cf1487ab5',1973,'UG','Uganda','economy',377,'GDP: $1,039 million (1971) at 1966 prices, $100 per capita; 1.7% real growth
between 1970 and 1971
Agriculture: main cash crops -- coffee, cotton; other cash crops -- sugar,
tobacco, fish, tea, livestock; self-sufficient in food
Fishing: catch 129,000 metric tons (1970), $19.5 million (1970)
Major industries: agricultural processing (textiles, sugar, coffee, plywood,
beer), cement, copper smelter, corrugated iron sheet, shoes, fertilizer
Electric power: 170,700 kw. capacity (1972); 817 million kw.-hr. produced
(1972), 78 kw.-hr. per capita
Exports: $237.8 million (f.0.b., 1971); coffee, cotton, copper, tea; $13.4 million
to Communist countries (1971)
Imports: $268.2 million (c.i.f., 1971); petroleum products, machinery, cotton
noe metals, transport equipment; $8.3 million from Communist countries
1971
Major trade partners: U.K., U.S., Kenya (Uganda, Kenya, and Tanzania form
East African Economic Community)
347
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Aid:
economic -- U.K., $26.6 million (1968); U.S., $42 million cumulative
through 1971; Communist countries, $31 million extended; military --
Communist, $15 million (1965-69); non-Communist, $6.5 million (1954-68) (S)
Monetary conversion rate: 7.143 Uganda shillings=US$1; 1 Uganda shilling=US$0.14
Fiscal year: 1 July - 30 June
Agriculture: principal food crops -- grain (especially wheat), potatoes; main
industrial crops -- sugar beets, cotton, sunflowers, and flax; degree of
self-sufficiency depends on fluctuations in crop yields; given normal yields,
U.S.S.R. is self-sufficient; caloric intake, 3,000-3,200 calories per day
per capita in recent years
349
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Fishing: catch 7,811,100 tons (1971); exports 277,200 tons (1971), imports
22,200 tons (1971)
Major industries: diversified, highly developed capital goods industries; consumer
goods industries comparatively less developed
Shortages: natural rubber, bauxite and alumina, tantalum, tin, and tungsten
Crude steel: 136 million metric ton capacity as of 1 January 1973; 126
million metric tons produced in 1972, 510 kilograms per capita
Exports: fuels (particularly petroleum and derivatives), metals, agricul tural
products (timber, grain) and a wide variety of manufactured goods (primarily
capital goods); $13,806 million (f.o.b. 1971)
Imports: specialized and complex machinery and equipment, textile fibers, consumer
manufactures, and any significant shortages in domestic production (for
(a en imported following poor domestic fapuestey $12,479 million
f.o.b., 1971
Major trade partners: $31.5 billion (1972); trade 65% with Communist countries,
22% with industrialized West, and 13% with less developed countries
Official monetary conversion rate: 0.75 rubles=US$1; 1 ruble=US$1.3333
Fiscal year: calendar year','bea2a1db5ac486b85cf35083437ddc35d185389beeaf81cc906c6f7b9a6b333d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b449adab0124948e9c4386ddebb777473dccc82212ec2adb4c04d90b8a8592eb',1973,'AE','United Arab Emirates','economy',381,'Agriculture: food imported, but some dates, alfalfa, vegetables, fruit, tobacco
raised
Major industries: fishing, trading, oi1 production; oi] production began in Abu
Dhabi in 1962, and in 1972 reached 1,050,000 bbls. per day; oi] revenues
accruing to Abu Dhabi estimated $600 million in 1972; Dubai has best port
and is commercial center -- oi] was discovered in commercial quantities in
1966; production began in 1969, 1972 production 153,000 B.P.D.; oi] revenues
for 1971 estimated at $50 million; small fishing, some boat buiiding,
handicrafts, animal husbandry, pearling throughout area
Electric power: 44,100 kw. capacity (1972); 110 million kw.-hr. produced (1972),
615 kw.-hr. per capita
Exports: crude petroleum, pearls, fish; Abu Dhabi crude exports $624 million (est.
1971) and Dubai $32 million total, of which $30 million reexports (1972)
Imports: food, consumer and capital goods; Abu Dhabi $108 million (est. 1972)
and Dubai $249 million total (1972)
Major trade partners: Japan, U.K., India
351
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Aid: multilateral annual average (1967-69) $1.17 million
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.25; Abu Dhabi, 1 Bahrain
dinar=US$2.52 (as of February 1973)
GDP: $325 million (1971 est.), $60 per capita
Agricuiture: cash crops -- peanuts, shea nuts, sesame, cotton; food crops --
sorghum, millet, corn, rice; livestock; largely self-sufficient
355
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Fishing: catch 5,000 metric tons (1969), $2.7 midlion
Major industries: agricultural processing plants, brewery, bottling, and brick
plants; a few other light industries
Electric power: 15,530 kw. capacity (1972); 53 million kw.-hr. produced (1972),
9 kw.-hr. per capita
Exports: $17 million (f.o.b., 1971); livestock (on the hoof), peanuts, shea
nut products, cotton, sesame
Imports: $55 million (c.i.f., 1971); textiles, food, and other consumer goods,
transport equipment, machinery, fuels
Major trade partners: volume understated because much regional trade is unrecorded;
Ivory Coast and Ghana; overseas trade mainly with France and other EC
countries; preferential tariff to EC and franc zone countries
Aid:
economic -- France (1964-September 1970) $46 million; EC (1960-70) $56.7
million; U.S.S.R., Ghana, West Germany, and Israel have also extended aid;
U.S. (FY62-71) $268 million; international organizations (1960-70) $12.1 million;
military -- France, $3.7 million (1964-70); U.S., $0.2 million (1962-70)
Budget: 1970 -- current revenue $41 million current expenditure $34 million,
investment expenditure $4 million
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
as of February 1973, floating since then
Fiscal year: calendar year','592a61b32f25e4a588ab965fb1117be3512e162331dca79f2f8dc930b385f0c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ff7acfc2a10e2531bb54451260ff1b46cb1496d980125439508ff4d10985139',1973,'UY','Uruguay','economy',384,'GNP: $2.4 billion (at average exchange rate, 1972); $810 per capita; 74%
private consumption, 12% public consumption, 14% gross investment (1969);
real growth rate 1972, none
Agriculture: large areas devoted to extensive livestock grazing (17 million
sheep, 9 million cattle); main crops -- wheat, rice, corn; self-sufficient
in most basic foodstuffs; caloric intake, 3,000 calories per day per capita,
with high protein content
Major industries: meat processing, wool and hides, textiles, footwear, cement,
petroleum refining
Crude steel: 24,000 metric tons produced (1966), 10 kilograms per capita
Electric power: 576,000 kw. capacity (1972); 2.4 billion kw.-hr. produced
(1972), 855 kw.-hr. per capita
Exports: $212 million (f.0.b., 1972 est.); beef, wool, hides
Imports: $201 million (c.i.f., 1972 est.); fuels, metals, machinery, transportation
equipment
Major trade partners: exports -- EC 34%, U.K. 14%, U.S. 7%, LAFTA 15%;
imports -- LAFTA 30%, U.S. 14%, U.K. 6%, EC 19% (1969)
Aid:
economic -- extensions from U.S. (FY46-71), loans $119 million, grants
$23.9 million; from international organizations, IBRD $130.5 million, IDB
$87.3 million, U.N. $9.9 million; $6 million credit from East Germany (1966),
$10 million credit from Hungary (1970), $20 million credit from U.S.S.R.
(1969), $5 million credit from Czechoslovakia (1970), $.4 million credit from
Bulgaria (1969); military -- U.S. (FY53-71), grants $47.4 million, $4.4 million
credits
Monetary conversion rate: trade (selling) -- 845 pesos=US$1; financial -- floating
(840 pesos=US$1 on 30 March 1973)
Fiscal year: calendar year
The Vatican City, seat of the Holy See, is supported financially by contributions
(known as Peter''s pence) from Roman Catholics throughout the world; some
income derived from sale of Vatican postage stamps and tourist mementos,
fees for admission to Vatican museums, and sale of publications; industrial
activity consists solely of printing and production of a small amount of
mosaics and staff uniforms
The banking and financial activities of the Vatican are worldwide; the Institute
for Religious Agencies carries out fiscal operations and invests and transfers
funds of Roman Catholic religious communities throughout the world; the
Cardinal''s Commission controls the administration of ordinary assets of the
Holy See and a Special Administration manages the Holy See''s capital assets
Electric power: obtained from Rome city grid; standby diesel powerplant with
2,100 kw. capacity
359
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GNP: $10.5 billion (at average official exchange rate, 1971), $970 per capita;
64% private consumption, 14% public consumption, 22% gross investment (1970),
real growth rate 1972 est. 4%
Agriculture: main crops -- cotton, Sugarcane, corn, coffee, rice; self-sufficient
in rice and chicken, imports wheat (U.S.} and meat (Colombia); caloric
intake 2,600 calories per day per capita (1964)
Fishing: catch 126,300 tons metric, $33.8 million (1970); exports $5.7 million
(1969 est.), imports $4.6 million (1969)
Major industries: petroleum, iron-ore mining, construction, food processing,
textiles
Crude steel: 923,000 metric tons produced (1970), 90 kilograms per capita
Electric power: 3.18 million kw. capacity (1971); 13.4 billion kw.-hr. produced
(1971), 1,230 kw.-hr. per capita
Exports: $3,129 million (f.o.b., 1971); petroleum $2,783 million (1971), iron
ore, coffee, cocoa
Imports: $1,891 million (c.i.f., 1971); industrial machinery and equipment,
chemicals, manufactures, wheat
Major trade partners: U.S. 41%, Canada 9%, U.K. 5% (1969)
Aid:
economic -- extensions from U.S. (FY46-71), $360.1 million loans; $59.7
million grants; from international organizations (FY46-71), $574.5 million;
from Communist countries (1954-71), $10 million;
military -- assistance from U.S. (FY53-71), $115.6 million
Monetary conversion rate: 4.40 bolivares=US$1 (selling rate)
Fiscal year: calendar year
Agriculture: mainly subsistence; main crops -- rice, corn, sweet potatoes,
manioc, sugarcane; food shortages -- rice, meat, sugar; caloric intake,
1,700-2,200 calories per day per capita
Major industries: food processing, textiles, machine building, mining, cement
Shortages: petroleum, complex machinery and equipment, fertilizer, foodstuffs
Monetary conversion rate (nominal): 3.0 dong=US$1 (1972)
Fiscal year: calendar year
GNP: $2.3 billion (1972 est.), $120 per capita; no real growth estimated for 1972
Agriculture: main crops -- rice, rubber, fruits and vegetables, copra; major food
imports -~ rice, wheat, dairy products, sugar
Fishing: catch 677,000 metric tons (1972); growing trade in fish and fish products
Major industries: manufacturing on small scale, mainly Tight manufacturing and
processing of local agricultural and forest products; factories produce
textiles, beer, cigarettes, glass, tires, sugar, paper, cement, soft drinks
Shortages: capital goods
Electric power: 900,000 kw. capacity (1972); 1.7 billion kw.-hr. produced (1972),
88 kw.-hr. per capita
Exports: $23 million (f.o.b., 1972); major commodities -- rubber, fish and fish
products, logs, scrap metal, duckfeathers
Imports: $678 million (c.i.f., 1972); major commodities -- machinery and trans-
portation equipment, rice, textile fabrics and yarn, petroleum products, base
metals and manufactures
Major trade partners: exports -- France, U.K., West Germany, Japan; imports --
U.S., Japan, Taiwan; no trade with Communist countries
Monetary conversion rate: dual exchange rate system with flexible rates; as
Of 31 March 1973 rates were as follows: 360 piasters=US$1 for U.S.-financed
merchandise imports; 475 piasters=US$1 for other merchandise imports
and most invisible transactions such as personal currency conversions, foreign
investment, and government transfers; 575 piasters=US$1 for most commodity
exports (the official rate plus a 100 piaster subsidy); average black market
rate of 543 piasters=US$1 during first quarter of 1973
Fiscal year: calendar year
GNP: $36 million (1970), $240 per capita
Agriculture: cocoa, bananas, copra; staple foods include coconut, bananas, taro,
and yams
Electric power: 6,800 kw. capacity (1972); 17 million kw.-hr. produced (1972),
114 kw.-hr. per capita
Exports: $6.3 million (1971); copra, cocoa, bananas
Imports: $12.8 million (1971); machinery and equipment, manufactured goods, food
Major trade partners: exports -- New Zealand, West Germany, the Netherlands;
imports -- New Zealand, Australia, US
Aid: New Zealand, $2.5 million committed; U.S., $2 million extended (FY67-70)
Monetary conversion rate: WS$1=US$1.48 (duly 1972)
Major industries: timber, tourism
367
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GNP: $150 million (1972 est.), $100 per capita
Agriculture (all outside Aden): cotton is main cash crop; cereals, dates, kat
(qat), coffee, and livestock are raised and there is a growing fishing
industry; large amount of food must be imported (particularly for Aden);
cotton, hides, skins, dried and salted fish are exported
Major industries: petroleum refinery (production 150,000 bbls. per day) mid 1971;
capacity 178,000 bbls. per day at Little Aden operates on imported crude; oi]
exploration activity
Exports: $113 million (f.o.b., 1971)
Imports: $169 million (c.i.f., 1971)
Electric power: 108,000 kw. capacity (1972); 378 million kw.-hr. produced (1972),
250 kw.-hr. per capita
Major trade partners: Yemen, East Africa, but some cement and sugar imported from
Communist countries; crude oi1 imported from Persian Gulf, exported mainly
to U.K. and Japan
*Excluding the islands of Perim and Kamaran for which no data are available
369
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ECONOMY (cont''d):
Aid: U.S. economic aid FY59-71 $43 million; international organizations FY49-71
$9.9 million; $132 million economic aid extended by Communist countries through
Decenber 1972, only $14 million has been drawn; $27 million military aid
has been extended by U.S.S.R., of which $26 million has been drawn (S)
Monetary conversion rate: 1S. Yemeni dinar=US$2.90
Fiscal year: 1 April - 31 March
Agricul ture: sorghum and millet, gat (a mild narcotic), cotton, coffee, fruits
and vegetables; largely self-sufficient in food
Major industries: cotton textiles and leather goods produced on a small scale;
handicraft and some fishing; small aluminum products factory
Electric power: 4,000 kw. capactiy (1972); 14 million kw.-hr. produced (1972),
2 kw.-hr. per capita
Major trade partners: China, Yemen (Aden), U.S.S.R., Japan, U.K., Australia,','c53debd436ca5b3041a93e751c9a2c2f7b3c25d419894c0037637d819f25ae63','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b017e8a646cac554aced37372bdcb064da0ea1820f0c894bc93fcbf03662d56',1973,'US','United States','economy',390,'GNP: $1,152 billion (1972); 63% consumption, 15% private investment, 22% government;
$5,510 per capita; 1972 growth rate 6.4% (constant 1958 dollars)
Fishing: catch 2.7 million metric tons (1970); imports $832 million (1970); exports
$112 million (1970) :
Crude steel: 129 million metric tons produced (1972), 615 kg. per capita
Electric power: 383.9 billion kw. capacity (1972); 1.8 trillion kw.-hr.
produced (1972 est.), 8,300 kw.-hr. per capita est.
Exports: $49.7 billion (f.o.b., 1972); machinery and transport equipment,
chemicals, cereals, mineral fuels
Imports: $55.6 billion (c.i.f., 1972); transport equipment, machinery, mineral
fuels, steel, nonferrous metals, metal ores
Major trade partners: (1970) Canada 24%, EC 18%, Japan 13%, U.K. 6%
Official development assistance (aid): obligations and loan authorizations (1971),
economic $4,811 million, military $4,436 million
Fiscal year: 1 July - 30 June','ed2ac0969d4d5c81de632e06d5ea17a484e360fb1bb2506a9604804126ec493a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

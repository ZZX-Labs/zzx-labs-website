SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb4c892db30cbc02d94c18de5f9abd48d0620a15575af6dd5bdc7d1819d9faf9',1973,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Cevdet Sunay, Acting Prime Minister Ferit Melen
Suffrage: universal over age 21
Elections: National Assembly (1973); Presidential (1973)
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party eh Bulent Ecevit; Democrats Party (DP), Ferruh Bozbeyli;
Reliance Party (RP), Turhan Feyziogiu; New Turkey Party (NIP), Yusuf Azizoglu;
Nationalist Movement Party (NMP), Alparslan Turkes; Nation Party (NP), Osman
Bolukbas{; Unity Party (UP), Mustafa Timisi; Republican Party (RP), Kemal
Satir (formed in 1972); Communist Party illegal
Voting strength: 1969 National Assembly elections -- 46.6% JP, 27.5% RPP, 3.3%
NP, 2.2% NTP, 2.6% TLP, 5.7% independent, 6.4% RP, 3.1% NMP, 2.5% UP; 1968
Senatorial elections (1/3 of Senate seats) -- 49.9% JP, 27.1% RPP, 6.0% NP,
8.5% Reliance Party, 4.7% TLP, 2.0% RPNP
Communists: strength and support negligible
Other political or pressure groups: military overthrew government in 1960, forced
resignation of Demirel government in March 1971 and remains the dominant
force behind the new government
437
SECRER-
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
“SECRET.
GOVERNMENT (cont''d):
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECO, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO','f4f1ddb6b130a5df944f2a48ea3a62bd2ed409297de9eded809ce7b08c85e07a','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74af73876ce43919a197f121e399b87dc56e6b4c3de7e6f18ea21cff6c817c34',1973,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and ci vil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts :
Government leaders: President Fahri Koruturk, Prime Minister Naim Talu
Suffrage: universal over age 21
ey ais National Assembly and Senate (1/3 of seats) (October 1973); Presidential
0
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party (RPP), Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Republican Reliance Party (RRP), Turhan Feyzioglu; National Action Party
(NAP), Alparslan Turkes; Nation Party (NP), Osman Bolukbasi; Unity Party (UP),
Mustafa Timisi; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced resignation of Demirel
government in March 1971 and remains an influenti a? force in government
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO. IMCO, IMF, ITU, NATO, OECD, Regional
rather has Development, Seabeds Committee (observer), U.N., UNESCO,
447
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
Sere','49099b5e9c45b3b5d46175efa1d3065c75b0f852d14bdef354a8a20e1a861556','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e1f3267fe16cce5754cc41ac716e3f83c131aa8fb09b1b84e7ef97e025bd8fe',1973,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
_ Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Fahri Koruturk, Prime Minister Naim Talu
Suffrage: universal over age 21
mar erhse National Assembly and Senate (1/3 of seats) (October 1973); Presidential
1980
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
Peopic''s Party (RPP), Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Repiblican Reliance Party (RRP), Turhan Feyzioglu; National Action Party
(NAP), Alparslan Turkes; Nation Party (NP), Osman Bolukbasi; Unity Party (UP),
Mustafa Timisi; Communist Party 1]]lega]
Communists: strength and support negligible
Other political or pressure groups: military forced resignation of Demirel
government in March 1971 and remains an influential force in government
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECD, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO
345
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998','ab13b7d52498cd92944d61b57e729cf5486b777d25f34bb9dbaa98cdf50e7cd0','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58205f3587fc7a56325ba2fa5485fb286a52abad570b1eba13315ebcc85435fc',1973,'','','government',3,'Legal name: Kingdom of Afghanistan
Type: constitutional monarchy
Capital: Kabul
Political subdivisions: 28 provinces with centrally appointed governors
Legal system: based on Islamic law; constitution adopted 1964; although provided
for in the law on judicial organization, there has as yet been no judicial
sl review of legislative acts; legal education at University of Kabul; has not
accepted compulsory ICJ jurisdiction
Branches: bicameral legislature with cabinet responsible to lower house
(People''s Council); although elected Parliament is exerting increasing
influence, it has not as yet passed much significant legislation or established
‘ effective control over the centralized administration and has no real voice
in military matters; progressive forces led by King liberalizing the regime;
independent judiciary established in 1967, has not yet had a major institutional
impact; it is too early to assess its future role
Government leaders: King Mohammad Zahir Shah; Prime Minister Abdul Zahir
Suffrage: universal over age 20
Elections: first free nationwide direct elections by secret ballot and universal
suffrage (under 1964 Constitution) held for Parliament August and September
1965; second elections held August and September 1969; Tower house of Parliament
(216 deputies) and one-third (28 Senators) of upper house (Council of Elders)
elected for 4-year terms; 28 Senators appointed by King; remaining 28
Senators to be elected by Provincial Councils when formed
Political parties and leaders: no political parties permitted yet, but enabling
legislation has been passed by Parliament and awaits the King''s signature;
several groups have begun to meet informally, extremists of left and right
best organized
Communists: there are 2 pro-Moscow Communist groups, with about 350-500 active
members; several other groups, further to left, with several hundred members
and sympathizers
Other political or pressure groups: progressive forces led by King Zahir and
cabinet dominate current situation with nascent leftist and rightist groups
forming for action when parties are permitted
® Member of: ADB, Colombo Plan, FAO, FUND, IAEA, IBRD, ICAQ, IDA, IFC, ILO, IMCO,
ITU, U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2004/09/15 : clA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','c58962b4338cb04abe9cc16175e20b406e387733d95fe6c91239bf4b2d4a0455','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70dba354f5e35f20643ecf54e10c1377fb3a5223a7d1d8090fbc47303bd1e291',1973,'AL','Albania','government',8,'Legal name: People''s Republic of Albania
Type: Communist state
Capital: Tirane
Political subdivisons: 27 rethet (districts), including capital, 200 localities,
2,600 villages
Legal system: based on Soviet law; constitution adopted 1950; judicial review
of legislative acts only in the Presidium of the People''s Assembly, which
is not a true court; legal education at State University of Tirane; has not
accepted compulsory ICJ jurisdiction
Branches: People''s Assembly, Council of Ministers, judiciary
Government leaders: Chairman of Council of Ministers, Mehmet Shehu; President,
Presidium of the People''s Assembly, Haxhi Lleshi
Suffrage: universal and compulsory over age 18
Elections: national elections theoretically held every 4 years; last elections
September 1970
Political parties and leaders: Albanian Workers Party only; First Secretary,
Enver Hoxha
Voting strength (1970 election); 99.9% Communist
Communists: 75,637 party members (1970)
Member of: CEMA, IAEA, ITU, U.N., UNESCO, UPU, WHO, WMO; has not participated
in CEMA since rift with U.S.S.R. in 1961; officially withdrew from Warsaw
Pact 13 September 1968
Legal name: Democratic and Popular Republic of Algeria
Type: republic
Capital: Algiers
Political subdivisions: 15 Wilayas (departments or provinces)
Legal system: based on French and Islamic law, with socialist principles;
constitution adopted by referendum 1963 but suspended since June 1965;
judicial review of legislative acts in ad hoc Constitutional Council composed
of various public officials, including several Supreme Court justices; Supreme
Court divided into 4 chambers; legal education at Universities of Algiers,
Oran and Constantine; has not accepted compulsory ICJ jurisdiction
Branches: executive dominant, unicameral legislature has not met since June
1965 coup d''etat but was never formally suspended, judiciary
Government leader: Houari Boumediene, President of Council of the Revolution
and President of the Council of Ministers, overthrew elected President
Ahmed Ben Bella 19 June 1965
Suffrage: universal over age 19
Elections: presidential 15 September 1963; departmental assemblies 25 May 1969;
local councils 14 February 1971
Political parties and leaders: National Liberation Front (FLN), Ahmed Kaid
Voting strength (1963 election): 100% FLN
Communists: 400 (est.); Communist Party illegal (banned 1962)
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, ILO, IMCO, IMF, ITU, OAU,
OPEC, U.N., UNESCO, UPU, WHO
Legal name: The Valleys of Andorra
Capital: Andorra
Political subdivisions: 6 districts -- Andorra la Vella, Sant Julia de Loria,
Encamp, Canillo, La Massana, and Ordino
Type: unique coprincipality under formal sovereignty of President of France and
Spanish Bishop of Seo de Urgel, who are represented by veguers
Legal system: based on French and Spanish civil codes; Plan of Reform adopted
1866 serves as constitution; no judicial review of legislative acts; has
not accepted compulsory ICJ jurisdiction
Branches: legislature (General Council) of 24 members with one-half elected
every 2 years for 4-year term; executive -- syndic and a deputy sub-syndic
chosen by General Council for 3-year terms; judiciary chosen by coprinces
who appoint 2 civil judges, a judge of appeals, and 2 Batles (court
prosecutors)
Suffrage: males of 21 or over who are third generation Andorrans vote for
General Council members; same right granted to women in April 1970
mae te half of General Council chosen every 2 years, last election December
97
Political parties and leaders: no political parties but only partisans for
particular independent candidates for the General Council, on the basis of
competence, personality and orientation toward Spain or France
Communists: none known
Legal name: State of Angola
Type: overseas state of Portugal
Capital: Luanda
Political subdivisions: 16 administrative districts including the coastal
exclave of Cabinda
Legal system: Portuguese civil codes and customary law; legal education
obtained in Portugal
Branches: Governor General appointed by Ministry of Overseas in Lisbon is
executive officer responsible for internal administration; he also has
prescribed legislative functions which he shares with Legislative Council
of elected and nominated members; all action in state may be vetoed by
Minister of Overseas; independent judiciary
Government leader: Governor General Fernado Santos e Castro
Suffrage: all adults able to read and write Portuguese and in full possession
of political and civil rights
Political parties and leaders: only legal group is Portuguese National Popular
oo (ANP), formerly the National Union (UN), headed by Gustavo Neto
Miranda
Other political or pressure groups: principal opposition groups which are
carrying out insurgency are Revolutionary Government of Angola in exile
(GRAE), led by Holden Roberto; Popular Movement for the Liberation of Angola
(MPLA), Ted by Agostinho Neto; and National Union for the Total Independence
of Angola (UNITA) , led by Jonas Savimbi
Communists: none known
Legal name: State of Antigua
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: St. Johns
Political subdivisions: 6 parishes, 2 dependencies (Barbuda, Redonda)
Legal system: based on English law; British Caribbean Court of Appeal has
exclusive original jurisdiction and an appellate jurisdiction, consists of
Chief Justice and 5 justices
Branches: legislative, 21-member popularly elected House of Representatives;
executive, prime minister and cabinet
Government leaders: Prime Minister George Herbert Walter; Governor Wilfred
Ebenezer Jacobs
Suffrage: universal suffrage age 21 and over
Elections: every 5 years; last general election 11 February 1971; last by-election
August 1968
Political parties and leaders: Antigua Labor Party (ALP), Vere C. Bird;
Progressive Labor Movement (PLM), George Herbert Walter; Antigua People''s
Party (APP), J. Rowan Henry
Voting strength: 1971 election -- House of Representative seats -- ALP 4, PLM 13
Communists: none known
Member of: CARIFTA
Legal name: Argentine Republic
Type: republic; military regime jin control since coup in June 1966
Capital: Buenos Aires
Political subdivisions: 22 provinces, 1 district (Federal Capital), and 1
territory
Legal system: based on Spanish and French civil codes; constitution adopted
1853 partially superseded in 1966 by the Statute of the Revolution which
takes precedence over the constitution when the two are in conflict;
judicial review of legislative acts; legal education at University of
Buenos Aires and other public and private universities; has not accepted
compulsory ICJ jurisdiction
Branches: presidency; national judiciary; legislature dismissed after June
1966 coup
Government leader: Gen. Alejandro Lanusse; Lanusse will probably remain in
presidency until transfer of power to elected government on 25 May
Suffrage: universal and compulsory age 18 and over
Elections: general elections scheduled for 11 March 1973; runoff presidential
election will be 8 April if necessary
Political parties: Justicialistas, the official Peronist party; Radical Civic
Union, moderate leftist and nationalist, Ricardo Balbin; Movement of
Integration and Development (MID), small left of center party, former
President Frondizi; New Force, conservative business party, organized by
Alvaro Alsogaray for the 1973 elections; Intransigent Party, formerly the
Intransigent Radicals (UCRI), small nationalist party, Oscar Alende; Union
Popular, neo-Peronist or Peronism without Peron, generally more moderate
than orthodox Peronism, Rodolfo Tecera del Franco; Popular Conservative
Party, not conservative but a member of Peron''s Civic Front, Vicente Solano
Lima; smaller parties include the Revolutionary Christian Party and the
Popular Christian party (both are factions of the Christian Democratic
Party), the Progressive Democrats, the Socialist Party, and the Democratic
Socialist Party; several provincial parties not organized on a national basis
Voting strength: the old political groupings probably continue to command the
loyalty of the populace according to the following figures (est.) -- Peronists
(of all types), 35%; Radicals (former People''s Radical Civic Union, UCRP),
Approved For Release 2004/09/15 : Ga-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GOVERNMENT (cont''d):
25%; Conservatives (former National Federation of Centrist Parties), 5%; minor
parties, 10%; nonaligned, 25%
Communists: some 60,000 members in various party organizations, including a small
nucleus of activists
Other political or pressure groups: Argentine armed forces, Peronist-dominated
labor movement, The Hour of the People (loose grouping of moderate politicians
with various party affiliations), National Meeting of the Argentines (loose
rouping of Communist and leftist politicians), General Economic Confederation
lparontst-leanine association of small businessmen) Argentine Industrial Union
(manufacturers'' association), Argentine Rural Society (large landowners ''
association), business organizations, students, and the Catholic Church
Member of: FAO, IADB, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, LAFTA,
OAS, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','a01c9127b7ab8a83242b43ca2b7041b6eda1a4aaaac31dffa3f6d1052de1314e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa45a603ac632af3663e7f264cf1406eac17afc07fc79809c5395a6b4c9e3f9f',1973,'AT','Austria','government',11,'Legal name: Republic of Austria
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states (Laender) including the capital
Legal system: civil law system with Roman law origin; constitution adopted 1920,
repromulgated in 1945; judicial review of legislative acts by a Constitutional
Court; separate administrative and civil/penal supreme courts; legal education
at Universities of Vienna, Graz, Innsbruck, Salzburg, and Linz; has not
accepted compulsory ICJ jurisdiction
Branches: bicameral Parliament, directly elected President whose functions are
largely representational, independent federal judiciary
Government leaders: Chancellor Bruno Kreisky; President Franz Jonas
Suffrage: universal over age 19; compulsory for presidential elections
Elections: presidential, every 6 years (next 1977); parliamentary, every 4
years (next 1975)
Political parties and leaders: Socialist Party of Austria (SP0e), Bruno Kreisky,
Chairman; Austrian People''s Party (OeVP), Karl Schleinzer, Chairman; Liberal
Party (FPOe), Friedrich Peter, Chairman; Communist Party, Franz Muhri,
Chairman
Voting strength (1971 election): 50.2% SP0e, 43.0% OeVP, 5.4% FPOe, 0.4% dissident
Socialist, 1.4% Communist
Communists: membership 26,000; activists 7,000-8,000; 60,705 votes in 1971 election
ns a Council of Europe, ECE, EFTA, IAEA, ICAO, OECD, Seabeds Committee, U.N.,
NESCO, WHO
Legal name: Commonwealth of the Bahama Islands
Type: British dependent territory with full internal autonomy under U.K. rule
Capital: Nassau (New Providence Island)
Legal system: based on English law
Branches: Governor (appointed by Queen); bicameral legislature (appointed
Senate, elected House); Executive (Prime Minister and cabinet); judiciary
Government leaders: Prime Minister Lynden 0. Pindling; Governor Sir John
Warburton Paul
Elections: House of Assembly (9 September 1972)
Political parties and leaders: Progressive Liberal Party (PLP), predominantly
Negro, Lynden 0. Pindling; Free National Movement (FNM) formed by a merger
of United Bahamian Party (UBP) and Free Progressive Liberal Party (Free PLP),
Cecil Wallace Whitfield
Voting strength (1972 election): PLP 30 seats, FNM 8 seats
Communists: none known
Legal name: State of Bahrain
Type: traditional monarchy; independence declared in 1971
Capital: Al Manamah
Legal system: based on Islamic law and English common law
Government leader: Amir ''Isa ibn Salman Al-Khalifah
Political parties and pressure groups: political parties prohibited; no significant
pressure groups although numerous small clandestine groups are active
Communists: few known
Member of: Arab League, U.N.
Legal name: People''s Republic of Bangladesh
Type: independent republic since December 1971
Capital: Dacca
Political subdivisions: 19 districts, 413 thanas (counties), 4,053 unions (village
groupings )
Legal system: based on English common law
Government leader: Prime Minister Sheikh Mujibur Rahman
Suffrage: universal over age 18
Elections: new national legislature to be elected in February or March 1973
Political parties and leaders: Awami League, Sheikh Mujibur Rahman, President;
National Awami Party (Left), Maulana Bhashani, President; National Awami
Party (Right), Muzaffar Ahmed, President; Communist Party of Bangladesh,
Moni Singh, Chairman, and Abdus Salam, General Secretary; East Bengal
Communist Party, Abdul Matin, leader; Communist Party of Bangladesh (Leninist),
Amal Sen, General Secretary; East Bengal Communist Party (Marxist/Leninist),
Mohammad Toaha, leader; Bangla Communist Party, Devan Sidkar, leader; other
small radical leftist groups
Communists: no information available on membership or degree of popular support
Other political or pressure groups: student groups, bands of former guerrillas
Member of: Afro-Asian People''s Solidarity Organization, Commonwealth, IBRD, IDA,
IMF, ILO, IPU, UNCTAD, UNESCO, WHO','02b9cca65e9aa4359697b013aec942c47c554fb92fbf14486f58508410ca5019','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('292fbeeb4a40561f188201f79e60baafb56cf3ae6f66131884ab888bfbff87ba',1973,'BR','Brazil','government',14,'Legal name: Barbados
Type: independent state since November 1966, recognizing Elizabeth II as chief
of state
Capital: Bridgetown
Political subdivisions: 11 parishes
Legal system: English common Taw; constitution came into effect upon
independence in 1966; no judicial review of legislative acts; has not
accepted compulsory ICJ jurisdiction
Branches: legislature consisting of a 21l-member appointed Senate and a
24-member elected House of Assembly; cabinet headed by Prime Minister
Government leader: Prime Minister Errol Barrow
Suffrage: universal over age 18
Elections: House of Assembly members have terms no longer than 5 years;
last general election held 9 September 1971
Political parties and leaders: Democratic Labor Party (DLP), Errol Barrow;
Barbados Labor Party (BLP), H. Bernard St. John, J. M. G. "Tom" Adams
Voting strength (1971 election): Democratic Labor Party (DLP), 57.5%; Barbados
Labor Party, 42.5%; Independent, negligible; House of Assembly seats -- DLP
18, BLP 6
Communists: none
Other political or pressure groups: People''s Progressive Movement (PPM), a
small black-nationalist group led by Calvin Alleyne
Member of: CARIFTA, Commonwealth, ICAO, IMF, OAS, Seabeds Committee (observer),
U.N.
Legal name: Federative Republic of Brazil
Type: federal republic; military-backed presidential regime since April 1964
Capital: Brasilia
Political subdivisions: 22 states, 4 territories, federal district (Brasilia)
Legal system: based on Latin codes; dual system of courts, state and federal;
constitution adopted 1967 and extensively amended in 1969; has not accepted
compulsory [Cd jurisdiction
Branches: strong executive with very broad powers; bicameral legislature
(powers of the two bodies have been sharply reduced); 11-man Supreme Court
Government leader: President Emilio Garrastazu Medici
Suffrage: compulsory over age 18, except illiterates and those stripped of their
political rights; approximately 30 million registered voters in October 1970
Elections: President Medici''s successor will be chosen on 15 January 1974 and
will take office in March
Political parties and leaders: National Renewal Alliance (ARENA), pro-government;
Brazilian Democratic Movement (MDB), opposition
Communists: less than 13,000; 100,000 sympathizers (est.)
Member of: FAQ, GATT, IADB, IAEA, IBRD, ICAO, IHB, ILO, IMCO, IMF, ITU, LAFTA,
OAS, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Colony of British Honduras
Type: British crown colony; obtained full internal self-government in January
1964
Capital: Belize City; seat of government in Belmopan
Legal system: English law; constitution came into force in 1964, although
country remains a British colony
Branches: 18-member elected National Assembly and 8-member Senate (either house
may choose its speaker or president, respectively, from outside its
elected membership); cabinet; judiciary
Government leader: Premier George Price
Suffrage: universal adult (probably 21)
Elections: within 5 years of last general election held 5 December 1969
Political parties and leaders: People''s United Party (PUP), George Price;
National Independence Party (NIP), Philip Goldson; People''s Development
Movement (PDM), Dean Lindo; United Black Association for Development (UBAD) ,
Evan Hyde
Voting strength (1969 election): 57.6% PUP, 39.8% NIP, 2.6% void ballots
Communists: none identified
Other political or pressure groups: Christian Workers’ Union (CWU) which is
connected with PUP
Legal name: State of Brunei
Type: British protectorate; constitutional sultanate
Capital: Bandar Seri Begawan
Political subdivisions: 4 administrative districts
Legal system: based on Islamic law; constitution promulgated by the Sultan in
1959
Branches: chief of state is Sultan (advised by appointed Privy Council) who
appoints Executive Council and Legislative Council
Government leader: Sultan Hassanal Bolkiah
Suffrage: universal age 21 and over; 3-tiered system of indirect elections;
popular vote cast for lowest level (district councilors)
Elections: last elections -- March 1965; further elections postponed indefinitely
Political parties and leaders: antigovernment People''s Independence Front
(Baker), Pengiran Dato Ali, chairman
Communists: information not available
Legal name: Republic of Chile
Type: republic
Capital: Santiago
Political subdivisions: 25 provinces
Legal system: based on Code 1857 derived from Spanish law and subsequent codes
influenced by French and Austrian law; constitution adopted 1925, amended
since then; judicial review of legislative acts in the Supreme Court; legal
education at University of Chile, Catholic University, and several others;
has not accepted compulsory ICJ jursidiction
Branches: president; bicameral legislature; independent judiciary
Government leader: President Salvador Allende
Suffrage: universal (except enlisted military and police) and compulsory at
age 18
Elections: next presidential election (1976); next Chamber of Deputies election
(1973); 25 senators (1973)
Political parties and leaders: Communist Party, Luis Corvalan; Socialist Party,
Salvador Allende and Carlos Altamirano; Popular Socialist Union, Raul Ampuero;
Christian Democratic Party, Eduardo Frei and Renan Fuentealba; Radical Party,
Anselimo Sule; National Party, Sergio Onofre Jarpa
Voting strength (1970 presidential election): 36.6% Marxist-led coalition, 35.3%
conservative independent, 28.1% Christian Democrat; (1969 Congressional
election) 12.9% Radical, 29.7% Christian Democrat, 12.2% Socialist, 15.7%
Communist, 20.0% National, 9.5% other
Communists: 140,000; sympathizers, 140,000
Other political or pressure groups: organized labor; business organizations;
landowners'' associations (SNA -- Sociedad Nacional de Agricultura) ;
extremist MIR (Movement of Revolutionary Left) and Patria y Libertad
Member of: ECOSOC, IADB, IAEA, IBRD, ICAO, IDB, IHB, IMF, LAFTA and Andean Sub-
Peale Group (created in May 1969 within LAFTA), OAS, Seabeds Committee,
Approved For Release 2004/09/15 : C\\A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Legal name: Colony of the Falkland Islands
Type: British crown colony
Capital: Stanley
Political subdivisions: local government is confined to capital
Legal system: English common law :
Branches: Governor, Executive Council, Legislative Council
Government leader: Governor and Commander in Chief Sir Cosmo Haskard (also
High Commissioner for British Antarctic Colony)
Suffrage: universal
Legal name: State of Grenada
Type: dependent territory with full internal autonomy as a British “Associated
State"
Capital: St. Georges
Political subdivisions: 6 parishes
Legal system: based on English common law
Government leaders: Premier Eric Matthew Gairy; U.K. Governor Dr. Hilda Bynoe
Suffrage: universal adult suffrage
Elections: every 5 years; most recent election 28 February 1972
Political parties and leaders: Grenada United Labor Party (GULP), Eric Matthew
Gairy; Grenada National Party (GNP), Herbert A. Blaize
Voting strength (1972 election): GULP 58.7%, GNP 41.3%; Legislative Council
seats, GULP 13, GNP 2
Communists: negligible
Member of: CARIFTA
Legal name: Overseas Department of Guadeloupe
Type: overseas department of France; represented by 3 deputies in the French
National Assembly and 2 senators in the Senate
Capital: Basse-Terre
Political subdivisions: 3 arrondissements; 34 communes, each with a locally
elected municipal council
Legal system: French legal system; highest court is a court of appeal based
in Martinique with jurisdiction over Guadeloupe, French Guiana, and Martinique
Branches: executive, Prefect appointed by Paris; legislative, popularly elected
General Council of 36 members; judicial, under jurisdiction of French judicial
system
Government leader: Prefect Pierre Brunon
Suffrage: universal over age 2]
Elections: General Council elections coincide with those for the French National
Assembly, normally every 5 years; last General Council election took place
in March 1970
Political parties and leaders: Union of Guadeloupean Democrats for the Republic
(UDG), Paul Gresse; Communist Party of Guadeloupe (PCG) Henri Bangou; Socialist
Party, leader unknown; Progressive Party of Guadeloupe (PPG), Henri Rodes;
Independent Republicans, leader unknown; Federation of the Left, leader unknown
Voting strength: PCG, 1 seat in French National Assembly; UDG, 2 seats;
(1968 election)
Communists: 2,000, 11,000 sympathizers
ae ae or pressure groups: Group of National Organization of Guadeloupe
GONG
Legal name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions: 22 departments
Legal system: civil law system; constitution came into effect 1966; judicial
review of legislative acts; legal education at University of San Carlos of
Guatemala; has not accepted ccempulsory ICJ jurisdiction
Branches: traditionally dominant executive; elected unicameral legislature;
7-member (minimum) Supreme Court
Government leader: President Carlos Arana
Suffrage: universal over age 18, compulsory for literates, optional for iliiterates
Elections: next elections (President and Congress) March 1974
Political parties and leaders: Democratic Institutional Party (PID), Donaldo
Alvarez Ruiz; Revolutionary Party (PR), Carlos Sagastume Perez (Sec. Gen.);
National Liberation Movement (MLN), Mario Sandoval Alarcon; Guatemalan
Christian Democratic Party (DCG), Danilo Barillas Rodriguez, Rene de Leon
Schlotter
Voting strength: for President -- MLN-PID 251,135 (40%), PR 202,241 (32.5%), DCG
125,948 (20%) null, 7.5%; for congressional seats -- PR 16, MLN-PID 34, DCG 5
Communists: communist party outlawed; underground membership estimated at 750
Other political or pressure groups: outlawed (Communist) Guatemalan Labor Party
(PGT), Bernardo Alvarado; United Democratic Revolutionary Front (FURD) Manuel
Colom Argueta
Member of: CACM, IADB, IAEA, ICAO, IHB, OAS, ODECA, U.N.
Legal name: Republic of Guinea
Type: republic; under one-party presidential regime
Capital: Conakry
Political subdivisions: 29 administrative regions, 209 arrondissements, about
8,000 local entities at village level
Legal system: based on French civil law system, customary law, and presidential
decree; constitution adopted 1958; no constitutional provision for judicial
review of legislative acts; has not accepted compulsory ICJ jurisdiction
Branches: executive branch dominant, with power concentrated in President''s
hands and a small group who are both ministers and members of the party''s
politburo; unicameral National Assembly and judiciary have little independence
Government leader: President Ahmed Sekou Toure, who has been designated
"The Supreme Leader of the Revolution"
Suffrage: universal over age 18
Elections: approximate schedule -- 5 years parliamentary, latest in 1968;
7 years Presidential, latest in 1968
Political parties and leaders: only party is Democratic Party of Guinea (PDG),
headed by Sekou Toure
Communists: no Guinean Communists have been identified, although there are some
sympathizers
Member of: ADB, ECA, FAO, ICAO, ILO, ITU, Niger River Commission, OAU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Republic of Panama
Type: republic
Capital: Panama
Political subdivisions: 9 provinces, 1 Indian reservation
Legal system: based on civil law system; constitution adopted in 1972; judicial
review of legislative acts in the Supreme Court; legal education at
University of Panama; accepts compulsory ICJ jurisdiction, with reservations
Branches: popularly elected unicameral legislature which elects the President;
presidentially appointed Supreme Court
Government leaders: Demetrio Lakas is Constitutional President and Chief of
State, but subordinate to Gen. Omar Torrijos, the National Guard
Commandant who was given special powers for 6 years by the assembly in 1972
Suffrage: universal and compulsory over age 21
Elections: elections for assembly of representatives of the corregimientos
August 1972; next election August 1978
Political parties and leaders: political parties suspended pending revision of
electoral code; Communist Party illegal but allowed to operate
Voting strength (1968 election): 55% Arnulfo Arias Madrid (National Union
Coalition), 42% David Samudio (People''s Alliance), 3% Antonio Gonzalez
Revilla (Christian Democratic Party); no parties were active in the 1972
elections
Communists: 100 active and several hundred inactive members People''s Party (PdP);
Communist; 1,000 sympathizers; National Liberation Movement (MLN) and
Vanguard of National Action (VAN) currently inactive as pro-Castro
organizations, 40-60 members
Member of: IADB, IAEA, ICAO, OAS, U.N.','ee85044dd8e835d52ce9c20172982985f52290d99868a3dc788f1c89ce4efda5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81b5de92b19c46b100eefd5dd7cf2940f2594237f7e2c726f79befdbd021d0ac',1973,'BE','Belgium','government',18,'Legal name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: 9 provinces
Legal system: civil law system influenced by English constitutional theory;
constitution adopted 1831, since amended; judicial review of legislative
acts; legal education at 4 law schools; accepts compulsory ICJ jurisdiction,
with reservations
Branches: executive branch consists of King and cabinet; cabinet responsible to
bicameral parliament; independent judiciary; coalition governments are usual
Government leader: Head of State, King Baudouin; Prime Minister Gaston Eyskens
Suffrage: universal over age 21
Elections: held 7 November 1971 (held at least once every 4 years)
Political parties and leaders: Social Christian, Charles-Ferdinand Nothomb and
Wilfred Marteus, co-presidents; Socialist, Edmund LeBurton and Joris Van
Eynde, co-presidents; Liberty and Progress, Senator P. Descamps, party
president; Francophone Democratic Front-Walloon Rally (Walloon nationalist),
Jean Duvieusart, party president; Volksunie (Flemish Nationalist), Wim
Jorrisen, party president; Communist, Marc Drumeaux, president of political
bureau
Voting strength (1971 election): 67 seats Social Christian, 61 seats Socialist,
34 seats Liberty and Progress, 21 seats Volksunie, 21 seats Francophone
Democratic Front-Walloon Rally, 5 seats Communist
Communists: 12,000 members; pro-Peking splinter groups, 400
Member of: Benelux, BLEU (Belgium-Luxembourg Economoc Union), Council of Europe,
ECE, ECOSOC, EC, EMA, FAO, IAEA, ICAO, IMF, NATO, OECD, Seabeds Conmittee,
U.N., UNESCO, WEU, WHO','5ad9d1ca6519ce3c5c710f359a20b81c4b22a464dc4e486532b6c199487b4815','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d6fc4bb0d69529799cf934b00316525d0ab59c7e07c0cc4dea4489a94eb815c',1973,'CA','Canada','government',22,'Legal name: Colony of Bermuda
Type: British crown colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English law .
Branches: elected House of Assembly; appointed Legislative Council; Executive
Council (cabinet)
Government leaders: Governor Lord Martonmere; Government Leader (equivalent to
Prime Minister) Sir Edward Richards
Suffrage: universal over age 21
Elections: at least once every 5 years; last general election, May 1968
Political parties and leaders: United Bermuda Party (UBP), Sir Henry Tucker;
Progressive Labor Party (PLP), Lois Browne-Evans (PLP parliamentary
leader); Bermuda Democratic Labor Party (BDP), Arnold A. Francis,
Charles W. Mayne
Voting strength (1968 elections): UBP 56.5%, PLP 34.4%, BDP 6.7%, Independents
2.4%; House of Assembly seats -- UBP 30, PLP 10
Communists: negligible
Other political or pressure groups: Bermuda Industrial Union (BIU)
Legal name: Kingdom of Bhutan
Type: monarchy; special treaty relationship with India
Capital: Thimphu :
Political subdivisions: 4 regions (east, central, west, south), further
divided into 15-18 subdivisions
Legal system: based on Indian Jaw and English common law; in 1964 the
King assumed full power -- no constitution existed beforehand; a supreme
court hears appeals from district administrators; has not accepted
compulsory ICJ jurisdiction
Branches: appointed minister and indirectly elected assembly consisting of
village elders, monastic representatives, and all district and senior
government administrators
Government leader: King Jigme Singye Wangchuck
Suffrage: each family has one vote
Elections: popular elections on village level held every 3 years
Political parties: all parties illegal
Communists: no overt Communist presence
Other political or pressure groups: Buddhist clergy
Member of: Colombo Plan, UPU, U.N.
Legal name: Republic of Bolivia
Type: republic; de facto military-civilian coalition government by the Popular
Nationalist Front
Capital: La Paz (seat of government); Sucre (judicial capital)
Political subdivisions: 9 departments with limited autonomy
Legal system: based on Spanish law and Code Napoleon; constitution adopted 1967;
constitution in force except where contrary to dispositions dictated by
governments since 1969; legal education at University of San
Andres and several others; has not accepted compulsory [Cd jurisdiction
Branches: executive; congress of two chambers (Senate and Chamber of Deputies),
congress disbanded after 26 September 1969 ouster of President Siles;
judiciary
Government leaders: President Hugo Banzer Suarez
Suffrage: universal and compulsory at age 18 if married, 21 if single
Elections: none scheduled
Political parties and leaders: The Nationalist Revolutionary Movement (MNR) Ted
by Victor Paz Estenssoro and the Bolivian Socialist Falange (FSB) led by Mario
Gutierrez form the governing coalition with the armed forces; other political
parties, although numerous, are relatively inactive and exert little influence;
leftist groups include the Nationalist Leftist Revolutionary Party (PRIN) Juan
Lechin Oquendo (in exile), Christian Democratic Party (PDC) Benjamin Miguel,
Revolutionary Christian Democratic Party (PDCR) Alfonso Camacho, Socialist
Party (PS) Marcelo Quiroga and Alberto Baily (in exile), and Leftist
Revolutionary Movement (MIR) Pablo Ramos Sanchez (in exile); more moderate
parties include the Authentic Revolutionary Party (PRA) Walter Guevara Arze,
Popular Christian Movement (MPC) Hugo Bozo, Leftist Revolutionary Party (PIR)
Ricardo Anaya, and Social Democratic Party (PSD) Hugo Sandoval
Voting strength (1966 elections): Frente de 1a Revolucion Boliviana (a coalition
composed of the MPC, PIR, PRA, PSD, and two interest groups, the campesinos
and Chaco War Veterans) 61%, FSB 12%, MNR 10%, other 17%
Communists: three parties; PCB/Soviet led by Jorge Kolle Cueto, about 1,500
members; PCB/Chinese led by Oscar Zamora, 500 members (est.); POR (Trotskyist),
about 200 members divided between faction led by Hugo Gonzalez Moscoso and
Guillermo Lora Escobar
Member of: IAEA, IADB, ICAO, International Tin Council, LAFTA and Andean
Sub-Regional Group (created in May 1969 within LAFTA), OAS, U.N.
Approved For Release 2004/09/15 : GA-RDP79-01051A000500010001-1
ECONOMY : Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GNP: $1.4 billion (purchasing power parity estimate, 1971), $290 per capita;
78% private consumption, 11% public consumption, 13% gross domestic
investment, -2% net foreign balance (1970); real growth rate 1971, 3.8%
Agriculture: main crops -- potatoes, corn, rice, sugarcane, yucca, bananas;
imports significant quantities of foodstuffs including lard, vegetable oils,
and wheat; caloric intake, 1,800 calories per day per capita (1971)
Major industries: mining, smelting, petroleum refining, food processing, textiles,
and clothing
Electric power: 268,000 kw. capacity (1970); 792 million kw.-hr. produced
(1970), 166 kw.-hr. per capita
Exports: $175.4 million (f.0.b., 1971 est.); tin, petroleum, lead, zinc, silver,
tungsten, antimony, bismuth, gold, coffee, and sugar
Imports: $187.7 million (f.0.b., 1971 est.); foodstuffs, chemicals, capital goods,
pharmaceuticals
Major trade partners: exports -- U.K. 46%, U.S. 39%, West Germany 5%, Argentina 2%;
imports -- U.S. 41%, West Germany 12%, Japan 11%, Argentina 6% (i970)
Aid:
economic -- extensions from U.S. (FY46-71) $230.5 million in loans, $304.4
million in grants; from international organizations (FY46-70), $180.7
million; from other Western countries (1960-70), $43.7 million; Communist
countries (1954-71), $55.5 million; military -- assistance from U.S. (FY58-70),
$25.3 million
Monetary conversion rate: 11.88 pesos=US$1 (selling rate)
Fiscal year: calendar year
Legal name: Republic of Botswana
Type: republic since independence in September 1966
Capital: Gaberone
Political subdivisions: 12 administrative districts
Legal system: based on English common law and local customary law; constitution
came into effect 1966; judicial review limited to matters of interpretation;
legal education at University of Botswana, Lesotho and Swaziland (located
in Lesotho); has not accepted compulsory ICJ jurisdiction
‘ Branches: executive -- President appoints and is the chief minister in the
cabinet which is responsible to Legislative Assembly; legislative --
Legislative Assembly with 31 popularly elected members and 4 members elected
by the 31 representatives, House of Chiefs with deliberative powers only;
judicial -- African courts administer customary law, High Court and
‘ Subordinate courts have criminal jurisdiction over all residents, Court of
Appeal has appellate jurisdiction
Government leader: President Seretse Khama
Suffrage: universal, age 21 and over
Elections: general elections held 18 October 1969
Political parties and leaders: Botswana Democratic Party (BDP), Seretse Khama;
Bechuanaland People''s Party (BPP), P.G. Matante; Botswana Independence
Party (BIP), Motsamai Mpho; Botswana National Front (BNF), Kenneth Koma
and Bathoen Gaseitsiwe
Voting strength: (October 1969 election) 68% BDP (24 seats); 13.5% BPP (3 seats);
12% BNF (3 seats); 6% BIP (1 seat)
Communists: no known Communist organization; Koma of BNF has long history of
Communist contacts
Member of: Commonwealth, FAO, OAU, U.N., WMO','9a8e28753647b7e5690b9fee217ad3fd2d2da6e18fb1cb347c39303c42ffecf2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2354f1d524703f20fe0578bd4f9b114b859d70972cb56c6aa4a117ed382278a9',1973,'BG','Bulgaria','government',28,'Legal name: People''s Republic of Bulgaria
Type: Communist state
Capital: Sofiya
Political subdivisions: 28 okrugs (districts), including capital city of Sofia
Legal system: based on civil law system, with Soviet law influence; new
constitution adopted in 1971; judicial review of legislative acts in the
State Council; legal education at University of Sofiya; has not accepted
compulsory ICJ jurisdiction
Branches: legislative (National Assembly), Council of Ministers, judiciary
Government leaders: Todor Zhivkov, Chairman, State Council (chief of state);
Stanko Todorov, Chairman, Council of Ministers (premier)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every 4 years for National Assembly; last elections
held on 27 June 1971; 99.8% of the electorate voted
Political parties and leaders: Bulgarian Communist Party, Todor Zhivkov, First
Secretary; Bulgarian National Agrarian Union, a puppet party, Georgi Traykov,
secretary
Communists: 699,000 full members (April 1971)
Mass organizations and front groups: Fatherland Front, Dimitrov Conmunist Youth
League, Central Council of Trade Unions, National Committee for Defense of
Peace, Union of Fighters Against Fascism and Capitalism, Committee of
Bulgarian Women, All-National Committee for Bulgarian-Soviet Friendship
Member of: CEMA, GATT, IAEA, ICAO, ILO, IMCO, ITU, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO, Warsaw Pact, International Organization of Journalists,
International Medical Association, International Radio and Television
Organization
Legal name: Union of Burma
Type: military dictatorship since suspension of constitution in 1962
Capital: Rangoon
Political subdivisions: Burma proper, 4 other constituent states and 1 special
division for the ethnic minorities; subdivided into divisions, districts,
muncipalities, townships, and villages
Legal system: based on English common law and incorporates Buddhist, Hindu,
and Islamic relgious law; constitution of 1947 superseded by acts of the
new Revolutionary Government, which seized power in 1962; legal education
at Universities of Rangoon and Mandalay; has not accepted compulsory ICJ
jurisdiction
Branches: Revolutionary Council rules through a Council of Ministers
sa leader: Chairman of Revolutionary Council and Prime Minister, Gen.
e Win
Suffrage: universal over age 18 under suspended constitution
Elections: none held under present regime
Political parties and leaders: government-sponsored Burmese Socialist Program
Party only legal party
Communists: 5,000
Member of: Colombo Plan, FAQ, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF,
ITU, Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Burundi
Type: republic; military government since November 1966; no constitution
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into 18 arrondissements and 78
communes
Legal system: based on German and French civil codes and customary law; has not
accepted compulsory ICJ jurisdiction
Branches: presidential cabinet with Council of Ministers; no legislature
Government leader: President Michel Micombero
Elections: last legislative election May 1965
Political parties and leaders: National Party of Unity and Progress (UPRONA),
a predominantly Tutsi party, was declared sole legitimate party in 1966
Voting strength (1965 elections): UPRONA won 21 of 33 Assembly seats; Hutu-
dominated People''s Party won 10
Communists: no Communist party; resumed diplomatic relations with The People''s
Republic of China in October 1971 following a six-year suspension; U.S.S.R.
and North Korea have diplomatic missions in Burundi
Member of: EAMA, ECA, IBRD, ICAO, ILO, IMO, OAU, U.N., UNESCO, WHO, WMO
Legal name: Khmer Republic
Type: new constitution provides for strong presidential system
Capital: Phnom Penh
Political subdivisions: 21 provinces with centrally appointed governors,
7 3 independent municipalities
Legal system: based on French civil law system; constitution adopted 1947 and
amended 1960; no judicial review of legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
Branches: 126-man national assembly and 40-man senate, popularly elected
‘ Government leader: President Lon Nol
Suffrage: universal over age 18, with major exception of Buddhist clergy
Elections: president elected for 5 year term in June 1962; senate for 6 year term
and assembly for 4 year term in September 1972
Political parties and leaders: Social Republican Party, Hang Thun Hak; Republican
Party, Sirik Matak; Democratic Party, Chau Sau
Communists: party strength unknown; Communist troops estimated between
20 000-400 ,000
Member of: ADB, Colombo Plan, IAEA, IBRD, ICAO, IMF, U.N., WMO
Legal name: United Republic of Cameroon
Type: unitary republic; one-party presidential regine
Capital: Yaounde
Political subdivisions: 7 provinces divided into 39 departments
Legal syster: based on French civil law system, with common law influence;
constitution adopted 1961; judicial review in Supreme Court, when a question
of constitutionality is referred to it by the President of the Republic; has
not accepted compulsory ICd jurisdiction
Branches: executive, legislative, and judicial
Government leader: President Anmadou Ahidjo
Suffrage: universal over age 21
Elections: presidential elections held 28 March 1970; parliamentary elections
last held 7 June 1970
Political parties and leaders: single party, Cameroonian National Union (UNC),
President Ahmacou Ahidjo
Voting strength: (1970 elections - 98% in presidential; 94% in parliamentary
Communists: no Communist Party or significant number of sympathizers
Other political or pressure groups: Cameroon People''s Union (UPC), an illegal
terrorist group now reduced to scattered acts of banditry with its factional
leaders in exile
Member of: ADB, EAMA, ECA, FAQ, GATT, IAEA, IBRE, ICAO, ILO, IMCO, TMF, ITU,
La Francophonie, Lake Chad Basin Conmission, Niger River Commission, OAU,
OCAM, Seabeds Committee, UDEAC, U.N., UNESCO, UPU, WHO, WMO','06dc1eda70d285d5dd622188328ce0a658887bcf383ff273866639fe38a35bda','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ca931b7ac2f769240741a9813ffa6dd1e6758672daa171fd5e9ac7d9e21a954',1973,'CF','Central African Republic','government',32,'Legal name: Central African Republic
Type: republic; constitution abrogated following military coup in January 1966
Capital: Bangui
Political subdivisions: 14 prefectures, 47 subprefectures
Legal system: based on French, Islamic, and tribal law; in 1966 the Chief of
State assumed all power and abrogated the existing constitution; has not
accepted compulsory ICJ jurisdiction
Branches: Gen. Bokassa heads government and rules by decree; assisted by
cabinet called Counci] of Ministers; judiciary, including Supreme Court,
court of appeals, criminal court, and numerous lower courts
Government leader: President Jaan-Bede} Bokassa
Suffrage: universal over age 21
Elections: none nave been neld under Bokassa regime
Political parties and leaders: Black African Social Evolution Movement (MESAN),
ruiing party under former regime, still in existence but plays little role,
led by President Jean-Bedel Bokassa
Communists: no Communist Party or significant number of sympathizers
Member of: ADB, Conference of East and Central African States, EAMA, ECA, FAO,
GATT, IBRD, ICAO, ILO, IMF, ITU, La Francophonie, OAU, OCAM, UDEAC, U.N.,
UNESCO, UPU, WHO, WHO
Legal name: Republic of Chad
Type: republic; one-party presidential regime since 1962
Capital: Fort-Lamy
Political subdivisions: 14 prefectures
Legal system: based on French civil law system and Chadian customary law:
constitution adopted 1962; judicial review of legislative acts in theory a
power of the Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: President, who has sweeping powers, elected by universal adult suffrage
to 7-year term; separate popularly elected unicameral National Assembly
with 5-year term; independent judiciary
Government leader: President Francois Tombalbaye
Elections: presidential elections held June 1969, parliamentary elections last
held December 1969
Political parties and leaders: Chadian Progressive Party (PPT), only legal
party, led by Francois Tombalbaye
Voting strength: (1969 elections) 93% in presidential, 97% in parliamentary
Communists: no front organizations or underground party; probably a few
Communists and some sympathizers
Other political or pressure groups: lightly armed Muslim rebel bands have been
opposing the government since October 1965 in east-central and since August
1969 in northern Chad
Member of: ADB, Conference of East and Central African States, EAMA, ECA, FAO,
GATT, ICAO, IBRD, IDA, ILO, IMF, ITU, La Francophonie, Lake Chad Basin
Commission, Niger River Commission, OAU, OCAM, UEAC, U.N., UNESCO, UPU,','b65330a527fcb1eed8b438fcbee73fd879591d0b60f0a05636ce2b57be30d111','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ecec3f2c072a42c468c411ac952cfc44369a6bff2e0c863873425944718f822',1973,'AU','Australia','government',36,'Legal name: People''s Republic of China
Type: Communist state; since beginning of Cultural Revolution, real authority
has become increasingly diffused as result of persistent rivalries within
the top leadership
Capital: Peking
Political subdivisions: 21 provinces, 3 centrally governed municipalities, and
5 autonomous regions
Legal system: before 1966, a complex amalgam of custom and statute, largely
criminal; little ostensible development of uniform code of administrative
and civil law; highest judicial organ is Supreme People''s Court although
legal activity centered in parallel network of Public Security organs; laws
and legal procedure clearly subordinated to priorities of party policy; whole
system largely suspended during Cultural Revolution and only gradually being
revived
Branches: prior to 1966 control was exercised by Chinese Communist Party, through
State Council, which supervised more than 50 ministries, commissions, bureaus,
etc., all technically under the standing committee of the National People''s
Congress; this system broke down under "Cultural Revolution" pressures and
is currently in process of being reconsolidated and streamlined
Government leader: Premier of State Council, Chou En-lai; Chairman, People''s
Republic of China (chief of state, a ceremonial post currently vacant; party
elder Tung Pi-wu is “acting” chairman); both subordinate to central committee
of CCP, under Chairman Mao Tse-tung
Suffrage: universal over age 18, though this is academic
Elections: no meaningful elections
Political parties and leaders: Chinese Communist Party (CCP), headed by Mao
Tse-tung; Mao is Chairman of political bureau, usually real locus of power
in China, and also Chairman of Central Committee; a new central committee
was formed at the 9th Party Congress held in April 1969 but the National
People''s Congress, the body which would confirm the new state constitution, has
not yet been held; all 29 provincial level party committees were reestablished
by late August 1971 and most sub-provincial levels now have party committees
Approved For Release 2004/09/15 : €IA-RDP79-01051A000500010001-1
GOVERNMENT (coMPiggeved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Voting strength: 100% Communist for practical purposes; no political nonconformity
permitted
Communists: about 20 million party members in 1965
Other political or pressure groups: pre-Cultural Revolution mass organizations
have not yet resumed their former roles of a united front facade; army (PLA)
is dominant force in countryside, with soldiers performing a wide range of
civil political-administrative duties
Member of: U.N., Red Cross, other international bodies
Legal name: Republic of China
Type: republic; one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 4 cities, 1 special municipality (Taipei)
Legal system: based on civil law system; constitution adopted 1947, amended 1960
to permit Chiang Kai-shek to be reelected, and amended 1972 to permit president
to restructure certain government organs; accepts compulsory ICd jurisdiction,
with reservations
Branches: 5 independent branches (executive, legislative, judicial, plus traditional
Chinese functions of examination and control), dominated by executive branch;
President and Vice President elected by National Assembly
Government leaders: President Chiang Kai-shek; Vice President, Premier Yen
Chia-kan; Premier Chiang Ching~kuo
Suffrage: universal over age 20
Elections: national level -- legislative yuan every 3 years but no general election
held since 1948 election on mainland (partial election for Taiwan province
representatives December 1969 and December 1972); local level -- provincial
assembly, county and municipal executives every 4 years; county and municipal
assemblies every 4 years
Political parties and leaders: Kuomintang, or National Party, led by Director
General Chiang Kai-shek, has no real opposition; 2 insignificant parties
are Democratic Socialist Party, Young China Party
Voting strength (1968 provincial assembly election): 61 seats Kuomintang,
10 seats independents
Member of: expelled from U.N. General Assembly and Security Council on 25 October
1971 and withdrew on same date from other charter-designated subsidiary organs;
attempting to retain membership in international financial institutions
65
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Legal name: Republic of Colombia
Type: republic; executive branch dominates government structure
Capital: Bogota
Political subdivisions: 22 departamentos, 4 intendencias, 4 comisarias, ] federal
district
Legal system: based on Spanish law; religious courts regulate marriage and
divorce; constitution decreed in 1886, amendments codified in 1946; judicial
review of legislative acts in the Supreme Court; accepts compulsory ICJ
jurisdiction, with reservations
Branches: President, bicameral legislature, judiciary
Government leader: President Misael Pastrana
Suffrage: universal over age 21
Elections: every fourth year; last presidential and congressional elections
April 1970; municipal and departmental elections, April 1972
Political parties and leaders: Liberal Party, Carlos Lleras Restrepo, Alfonso
Lopez Michelsen; Liberal Party, Julio Cesar Turbay; Conservative Party,
Unionista Wing, Mariano Ospina Perez, Misael Pastrana; Conservative Party,
Alzatista Wing, Alvaro Gomez Hurtado; Conservative Party, Dissident Wing,
J. Emilio Valderrama, Herman Jaramillo Ocawpo; National Popular Alliance
(ANAPO), General Gustavo Rojas Pinilla, Maria Eugenia Rojas de Moreno;
Liberals probably command majority of votes over conservatives, but
constitution under the National Front Coalition calls for 50-50 representation
of Liberals and Conservatives in the National Congress until 1974; in local
legislative bodies, parity terminated with the 1970 election; Conservative
Party united with progovernment and Ospina wing in August 1969 to choose
National Front presidential candidate; opposition wing (Lauro-Alzatista)
led by Gomez
Voting strength: 1970 presidential election -- Misael Pastrana 1.61 million
votes, General Gustavo Rojas Pinilla 1.54 million votes, Belisario Betancur
Cuartas .46 million votes, Evardisto Sourdis .3 million votes; 1972 municipal
council and departmental assembly elections -- three major parties; combined
Liberal Party, 1,383,708; Combined Conservative Party, 917,699; ANAPO, 559,821;
abstention by approximately 70% of eligible voters
Communists: 4,800-5,200; sympathizers, 35,000
Approved For Release 2004/09/15 : @¥A-RDP79-01051A000500010001-1
For Rel 2004/09/15 : CIA-RDP79-01051A000500010001-1
GOVERNMENT (cApProved or Release
Other political or pressure groups: Communist Party (PCC), Gilberto Vieira
White; MRL del Pueblo, Communist front for electoral purposes; PCC/ML, Chinese
Line Communist Party, led by Pedro Lupo Leon Arboleda Roldan
Member of: FAO, IADB, IAEA, IBRD, ICAO, IFC, IHB, ILO, IMF, ITU, LAFTA and
Andean Sub-Regional Group (created in May 1969 within LAFTA), OAS, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Overseas Territory of the Comoro Islands
Type: overseas department of France
Capital: Moroni
Political subdivisions: 4 prefectures, 4 district councils
Legal system: French and Muslim law
Branches: High Commissioner appointed by French government; assisted by elected
Chamber of Deputies of 31 members, and an 8-man Council of Ministers,
President elected by Chanber of Deputies
Government leader: Prince Said Mohamed Jaffar, President of Chamber of Deputies
Suffrage: universal adult
Elections: at discretion of Council of Ministers, on advice of President; must
be held before expiration of 5-year electoral mandate
Political parties and leaders: Comoran Democratic Union, Mohammed Dahlani;
Democratic Assembly of Comoros People, Said Mohamed Jaffar; Comoros Socialist
Party
Voting strength: not available
Communists: information not available
Legal name: Overseas Territory of New Caledonia
Type: French overseas territory; represented in French parliament by one deputy
and one Senator
Capital: Noumea
Political subdivisions: 4 islands or island group dependencies -- Isle of Pines,
Loyalty Islands, Huon Islands, Island of New Caledonia
Legal system: French law
Branches: administered by Governor, who is also High Commissioner for France in
the Pacific; responsible to French Ministry for Overseas France and
Governing Council; Assemblee Territoriale
Government leader: Jean Risterucci, Governor and French High Commissioner
Suffrage: restricted (1957 election roll listed 32,370 males and females over
21 years of age, of whom 18,964 were classed as indigenous inhabitants)
Elections: Assembly elections in 1972
Political parties: Union Caledonienne, Entente Democratique et sociale, Union
Multiraciale, Mouvement Liberal Caledonien, Union Democratique, Mouvement
Populaire Caledonien
Voting strength (1967 election): Union Caledonienne, 12 seats; Entente
Democratique et Sociale, 6 seats; Union Multiraciale, 5 seats; Mouvement
Liberal Caledonien, 5 seats; Union Democratique, 4 seats; Mouvement
Populaire Caledonien, 2 seats; other 1 seat
Communists: number unknown; Union Caledonienne strongly leftist; some political -
ly active Communists were deported during 1950''s; small number of North
Vietnamese
Other political parties and pressure groups: several lesser parties
Legal name: Republic of Nicaragua
Type: republic
Capital: Managua
Political subdivisions: 1 national district and 16 departments
Legal system: based on Spanish civil law system; constitution adopted in 1950,
now being revised; judicial review of legislative acts in the Supreme Court;
legal education at Universidad Nacional de Nicaragua and Universidad
Centroamericana; accepts compulsory ICJ jurisdiction
Branches: President from 1 May 1972 to 1 December 1974 replaced by a triumvirate,
bicameral legislature, judiciary elected by legislature, and Supreme Electoral
Tribunal (4th branch)
Government leaders: Triumvirate members -- Roberto Martinez, Alfonso Lovo Cordero
and Fernando Aguero Rocha
Suffrage: universal over age 18 if married or literate, otherwise 21
Elections: every 6 years; however, due to agreement between liberal and conservative
parties, next elections will be held 1 September 1974; municipal elections
every 3 years
Political parties and leaders: Nationalist Liberal Party (PLN), Anastasio Somoza,
Ramiro Sacasa, Francisco Urcuyo, Alfonso Callejas; Traditional ist Conservative
Party (PCT), Fernando Aguero Rocha; Independent Liberal Party (PLI), not legal,
Roberto Robelo, Juan Manuel Gutierrez; Social Christian Party (PSC), not legal,
Ignacio Zelaya, Cesar Delgadillo (President) and Roberto Ferrey (Secretary
General); National Conservative Action (ANC), not legal, Pedro J. Chamorro
sage: es (1972 elections): PLN 534,171 votes (75.4%), PCT 174,897 votes
24 .6%
Communists: Communist movement split into hard-line Nicaraguan Socialist Party
(PSN) illegal, 60 members; soft-line Nicaraguan Communist Party (PCN) illegal,
40 members, and small pro-Castro Sandinist National Liberation Front (FSLN)
50 to 60 activist; about 1,000 sympathizers
Member of: CACM, FAO, GATT, IADB, IAEA, ICAO, ICJ, ILO, INTELSAT, ITU, OAS,
ODECA, Seabeds Committee (observer) U.N., UNESCO, UNICEF, UPU, WHO, WMO
Legal name: Province of Timor
Type: overseas province of Portugal
Capital: Dili
Political subdivisions: 12 administrative districts
Legal system: based on Portuguese law
Branches: Governor General appointed by Portuguese Minister of Overseas; advised
by a 7-member council composed of 4 ex offico members and 3 members elected
from the Legislative Council of 14 members (3 ex officio and 11 elected);
usual executive departments such as Treasury, Health, Justice, Education,
Transportation exist, each of which is headed by a director
Government leader: Governor Brig. Fernando Alves Aldea (appointed 1972)
Suffrage: high school education required
Elections: Timor elects one representative to the 150-seat Portuguese National
Assembly
Political parties and leaders: single party only, the National Popular Action
on Timor
Voting strength: limited to Portuguese on Timor and small group of Timorese
who fulfill requirement
Communists: prior to 1 October 1965, infiltration by Indonesian Communist Party
from Indonesian Timor, especially in the Oe-Cusse enclave
Legal name: Commonwealth of Puerto Rico
Type: commonwealth voluntarily associated with U.S.
Capital: San Juan
Political subdivisions: 76 municipalities
Legal system: based on civil codes; constitution came into effect 1952, U.S.
Constitution also applies; local courts and U.S. federal court; Tegal
education at University of Puerto Rico Law School
Branches: elected Governor and bicameral legislature; 9-judge Supreme Court
appointed by Governor
Government leader: Governor Luis A. Ferre
Elections: every 4 years, last election November 1968; plebescite held July
1967 on question of opting for statehood, continued commonwealth status, or
full independence; 60.4% for commonwealth status, 39.0% for statehood, 0.6%
for independence
Suffrage: universal over age 18
Political parties and leaders: Popular Democratic Party (PPD), Luis Negron Lopez;
Republican Statehood Party (PER); New Progressive Party (PPN), Luis A. Ferre;
Christian Action Party (PAC), Catholic Church; Independence Party (PI);
People''s Party (formed August 1968), Roberto Sanchez
Voting strength (1968 election): 45.0% PPN, 41.8% PPD; 10.09% People''s Party;
3% PI; distribution of house seats -- PPN 26, PPD 25; distribution of Senate
seats -- PPD 16, PPN 11
Communists: pro-Communist Puerto Rican Socialist Party, Juan Mari Bras
Legal name: The Independent State of Western Samoa
Type: constitutional monarchy under native chief; special treaty relationship
with New Zealand
Capital: Apia
Legal system: based on English common Jaw and local customs; constitution came
into effect upon independence in 1962; judicial review of legislative acts
\\ with respect to fundamental rights of the citizen; has not accepted
compulsory ICJ jurisdiction
Branches: Head of State and Executive Council; Legislative Assembly; Supreme
Court, Court of Appeal, Land and Titles Court, village courts
} Government leaders: Head of State, Malietoa Tanumafili II; Prime Minister,
Tupua Tamasese Leaofi IV
Suffrage: 45 Samoan members of Legislative Assembly are elected by holders of
matai (heads of family) titles (about 5,000); 2 European members are elected
by universal adult suffrage
Elections: held triennially
Political parties and leaders: no clearly defined political party structure
Communists: unknown
Member of: ADB, Commonwealth, ECAFE, WHO
Legal name: People''s Democratic Republic of Yemen
Type: republic
Capital: Aden; Madinat ash Sha''b, administrative capital
Political subdivisions: 6 provinces
Legal system: based on Islamic law (for personal matters) and English common
law (for commercial matters); highest judicial organ, Federal High Court,
interprets constitution and determines disputes between states
Branches: Presidential Council; cabinet; Supreme People''s Council
Government leaders: Chairman of Presidential Council, Salim Rubay Ali; Prime
Minister Ali Nasir Muhammed al-Hasani; NF Secretary General Abd Al-Fattah
Ismail
Political parties and leaders: National Front (NF), only legal party
Communists: few known
Member of: U.N.
Legal name: Yemen Arab Republic
Type: republic
Capital: San‘a’
Political subdivisions: 8 provinces
Legal system: based on Turkish law, Islamic law, aid local customary law; first
constitution promulgated December 1970; has not accepted compulsory ICJ
jurisdiction
Branches: President, Prime Minister, Republican Council, Consultative Council
Government leaders: President Abd al-Rahman Iryani; Prime Minister Muhsin al-Ayni
Communists: few known
Member of: Arab League, FAO, ICAO, ITU, U.N., UNESCO, UPU, WHO
Legal name: Socialist Federal Republic of Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
Political subdivisions: 6 republics with 2 autonomous provinces (within the
Republic of Serbia)
Legal system: mixture of civil law system and Communist legal theory; constitution
adopted 1963 and amended in 1967, 1968, and 1971; in early stage of development
is a system of judicial review of legislative acts in Constitutional Court
(a quasi-judicial body); legal education at several law schools; has not
accepted compulsory ICJ jurisdiction
Branches: parliament (Federal Assembly) constitutionally Supreme; executive
includes cabinet (Federal Executive Council) and the Federal Administration;
independent judiciary; the State Pesidency is a collective policymaking body
based on proportional representation of all the republics and provinces, Tito
presides as President of the Republic
Government leader: Josip Broz Tito, President of Republic and President of
League of Communists of Yugoslavia
Suffrage: universal over age 18
Elections: Federal Assembly elected every 4 years
Political parties and leaders: League of Communists of Yugoslavia (LCY) only;
leaders are President Tito and influential presidium members Edvard Kardelj,
Vel jko Viahovic, Mijalko Todorovic, Vladimir Bakaric, Krste Crvenkovski,
and Stane Dolanc
Voting strength: Voter participation in national elections has declined, as
follows -- 1963, 95.5%; 1965, 93.6%; 1967, 89%; 1969, 88%
Communists: 1,025,000 party members (1971)
Other political or pressure groups: Socialist Alliance of Working People of
Yugoslavia (SAWPY), the major mass front organization for the LCY;
Confederation of Trade Unions of Yugoslavia (CTUY), Union of Youth of
Yugoslavia (UYY), Federation of Yugoslav War Veterans (SUBNOR)
Approved For Release 2004/09/15 3@1/A-RDP79-01051A000500010001-1
Approved F : | i
GOVERNMENT (cont PRT ved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Member of: CEMA (participates in certain commissions), EC {trade agreement with
EC initiated 3 Feb 1970), FAO, GATT, IAEA, IBRD, ICAO, IHB, ILO, IMCO,
IMF, ITU, OECD (participant in some activities), Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WHO
Legal name: Republic of Zaire (until October 1971 known as Democratic Republic
of the Congo)
Type: republic; constitution establishes strong presidential system
Capital: Kinshasa
Political subdivisions: 8 regions and federal district of Kinshasa
Legal system: based on Belgian civil law system and tribal law; new constitution
promulgated 1967; legal education at National University of Zaire;
has not accepted compulsory ICJ jurisdiction
Branches: president elected 1970 for seven-year term; National Legislative
Council of 420 members elected for five-year term; the official party is
the supreme political institution
Government leaders: Lt. Gen Mobutu Sese Seko, President
Elections: presidential and legislative elections in October and November 1970
Political parties and leaders: Mouvement Populaire de la Revolution (MPR), only
legal party, organized from above with actual grassroots popularity not
clearly definable
Communists: no Communist Party, but some politicians are subject to Communist
influence
Member of: EAMA, FAQ, IAEA, ICAO, IHB, ILO, ITU, OAU, UDEAC, U.N., UNESCO,
UPU, WHO, WMO
one','1c560e8ffab8896314eb6fff60a7cc4c8a34be93369a9b7e4845ad8d40d79239','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('932912dbebff306f4326b1bf8dfd95808ceebec8de56915d19302efd8a324996',1973,'CG','Congo','government',41,'Legal name: People''s Republic of the Congo
Type: republic; military regime established September 1968
Capital: Brazzaville
Political subdivisions: 9 regions divided into districts
Legal system: based on French civil Jaw system and customary law; constitution
adopted 1963 and 1969
Branches: President, Council of State; National Assembly dissolved August 1968,
judiciary presumably stil] functions according to provisions of 1963
constitution; all policy made by Congolese Workers Party Central Committee
and Politburo
Government leader: President, Maj. Marien Ngouabi
Suffrage: universal over age 18
Elections: last legislative elections December 1963; none scheduled
Political parties and leaders: Congolese Workers Party (PCT) is only legal party;
President, Maj. Marien Ngouabi
Voting strength: no elections held since PCT formed
Communists: unknown number of Communists and sympathizers
Other political or pressure groups: Union of Congolese Socialist Youth (UJSC),
Congolese Trade Union Congress (CSC), Revolutionary Union of Congolese
Union (URFC), General Union of Congolese Pupils and Students (UGEEC)
Member of: ADB, Conference of East and Central African States, EAMA, ECA, IBRD, FAO,
ICAO, ILO, IMF, ITU, La Francophonie, OAU, UDEAC, UNESCO, UPU, WHO, WMO','8203115859eea457bf3a9ae9feb7cc490844f22bc4cbc672a35df8161ba03152','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20cccea7ff7bf30b1406c7fee9346802b0763df49901c6b14eb42177883ed13e',1973,'CR','Costa Rica','government',45,'Legal name: Republic of Costa Rica
Type: unitary republic
Capital: San Jose
Political subdivisions: 7 provinces
Legal system: based on Spanish civil law system; constitution adopted 1949;
judicial review of legislative acts in the Supreme Court; legal education
at University of Costa Rica; has not accepted compulsory ICJ jurisdiction
Branches: President, unicameral legislature, Supreme Court elected by
legislature
Government leader: President Jose Figueres
Suffrage: universal and compulsory age 18 and over
Elections: every 4 years; next, February 1974
Political parties and leaders: National Liberation Party (PLN), Daniel Oduber;
National Unification (UN), Francisco Calderone; National Republican Party (PRN);
Longino Soto Pacheco; Popular Union Party (PUP), Mario Echandi; National
Independent Party (DNI), Jorge Gonzalez Marten; National Union Party (PUN),
Otilio Ulate; Democratic Renovation Party (PRD), Rodrigo Carazo; Costa Rican
Socialist Party (PMSC), Arnoldo Mora Rodriguez; Christian Democratic Party
(PDC), Jorge Monge Zamora; National Front (EN). Virgilio Calvo; Socialist
Action Party (PASO), Marcial Aguiluz; Popular Vanguard Party (PVP, Communist,
illegal), Manuel Mora
Voting strength (1970 election): National Unification (coalition of PUN, PR, and
PURA), 41.1%; PLN, 55%; PFN, 1.7%; PDC, 0.9%; PASO, 1.3%
Communists: 3,200 members, 10,000 sympathizers
Member of: CACM, IADB, IAEA, ICAO, OAS, U.N.','404581c94f3fca9184aafd39d80be3efaee13b07bca1acb4038df5cc2e647c1a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('867a244e280ab269320c847af0507c199f6f1049e5ea3dbd3160dd5a9f5df8eb',1973,'CU','Cuba','government',49,'Legal name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: 6 provinces
Legal system: based on Spanish and American law, with large elements of
Communist legal theory; Fundamental Law of 1959 replaced constitution
of 1940; legal education at Universities of Havana, Oriente, and Las Villas;
does not accept compulsory ICJ jurisdiction
Branches: executive; no legislature; controlled judiciary
Government leader: Premier Fidel Castro Ruz
Political parties and leaders: Cuban Communist Party (PCC), First Secretary
Fidel Castro Ruz, Second Secretary Raul Castro Ruz
Communists: approx. 120,000 party members
Member of: CEMA, ECLA, FAO, GATT, IADB (nonparticipant), IAEA, ICAO, IHB, ILO,
IMCO, International Rice Commission, International Sugar Council, International
Wheat Agreement, ITU, OAS (nonparticipant), Permanent Court of Arbitration,
Postal Union of the Americas and Spain, Seabeds Committee (observer), U.N.,
UNESCO, UPU, WHO, WMO','39946d29a75b88dba52ff5c19259b866d318aff0fa8e3624e4754d8ca84945d6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f176a3e6a181b5c4757ab52a1a40d9863e5d51faa269ea509ae8f16eec89ac03',1973,'CY','Cyprus','government',52,'Legal name: Republic of Cyprus
Type: republic since March 1961; separate de facto Greek Cypriot, and Turkish
Cypriot governments have evolved since outbreak of communal strife in 1963
Capital: Nicosia
Political subdivisions: 6 administrative districts
Legal system: based on common law, with civil law modifications; constitution
came into force upon independence in 1960, but has often been in abeyance
since then; has not accepted compulsory ICJ jurisdiction
Branches: currently a rump government consisting basically of Greek Cypriot parts
of bodies provided for by constitution; headed by President of the Republic
and comprised of Council of Ministers, House of Representatives, and
Supreme Court
Government leaders: President, Archbishop Makarios III (Greek); Vice President,
Dr. Fazil Kucuk (Turk)
Elections: held every 5 years; 1965 elections suspended; 1968 elections only for
President and Vice President; 1970 parliamentary elections demonstrate
notable increase in strength of Communist Party (AKEL)
Political parties and leaders: Reform Party of the Working People (AKEL)
(Communist Party), Ezekias Papaioannou; Unified Party (UP), Glafkos Clerides;
Progressive Movement (PM) (pro-Makarios), Andreas Azinas; Democratic
National Party (DEK), Takis Evdokas; United Democratic Union of the Center
(EDEK), Vassos Lyssarides; Turkish National Union Party (TNUP), Rauf Denktash
Voting strength: (1968 presidential and vice presidential elections) Greek
Cypriot President Makarios 90%; Turkish Cypriot Vice President Fazil Kucuk
unopposed; (1970 parliamentary elections) 39% of Greek Cypriot vote for
Reform Party of the Working People, 21% of the Greek Cypriot vote for the
Progressive Movement, 9% of the Greek Cypriot vote for the Democratic National
Party as well as 9% for the United Democratic Union of the Center, 4% of the
Greek Cypriot vote for independents, 76% of the Greek Cypriot electorate
voted; 80% of the Turkish Cypriot community voted and overwhelmingly elected
15 of Rauf Denktash''s supporters to the Turk Cypriot House contingent in a
separate election
Communists: 12,000; sympathizers estimated to number 60,000
Approved For Release 2004/09/15 : GYA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GOVERNMENT (cont''d):
Other political or pressure groups: United Democratic Youth Organization (EDON)
(Communist-controlled); Pan Cyprian Confederation of Labor (PEO)
(Communist-controlled); Cyprus Confederation of Labor (SEK) (pro-U.S.);
Cyprus Turkish Federation of Trade Unions (KTBIF)
Member of: Commonwealth, Council of Europe, FAO, IAEA, IBRD, ICAO, IDA, IFC,
ILO, IMF, ITU, U.N., UNESCO, UPU, WHO 4
Legal name: Czechoslovak Socialist Republic
Type: Communist state
Capital: Prague
Political subdivisions: 2 separate autonomous republics (Czech Socialist
Republic and Slovak Socialist Republic); 7 regions (kraj) in Czech lands,
three regions in Slovakia; national capitals of Prague and Bratislava have
regional status
Legal system: civil Taw system based on German codes, modified by Communist
legal theory; revised constitution adopted 1960 under revision; no judicial
review of legislative acts; legal education at Universita Komenskeho School
of Law; has not accepted compulsory ICJ jurisdiction
Branches: executive --- President, cabinet (appointed by President); legislative
-- Federal Assembly (elected directly), Czech and Slovak National Councils
(also elected directly) legislate on limited area of Czech and Slovak affairs;
judiciary -- Supreme Court (elected by Federal Assembly); entire governmental
structure dominated by Communist Party
Government leaders: President Ludvik Svoboda, Premier Lubomir Strougal
Suffrage: universal over age 18
Elections: governmental bodies every 5 years; President every 5 years (last
election, November 1971)
Dominant political party and leader: Communist Party of Czechoslovakia (KSC),
Gustav Husak, General Secretary; Communist Party of Slovakia (KSS) has status
of "provincial KSC organization"
Voting strength (1971 election): 99.81% Communist-sponsored single slate
Communists: 1.2 million party members
Other political groups: puppet parties -- Czechoslovak Socialist Party,
Czechoslovak People''s Party, Slovak Freedom Party, Slovak Revival Party
Member of: CEMA, GATT, IAEA, ICAO, Seabeds Committee, U.N., Warsaw Pact
Legal name: Republic of Dahomey
Type: republic; under military rule since October 1972
Capital: Porto-Novo (official), Cotonou (de facto)
Political subdivisions: 6 departments, 30 arrondissements
Legal system: based on French civil law and customary law; judicial review by
4-chambered Supreme Court; legal education generally obtained in France; has
not accepted compulsory ICJ jurisdiction
Branches: military government with some civilian participation, took over on 26
October 1972, replacing 3-man Presidential Council formed in 1970; independent
judiciary
Government leaders: Major Mathieu Kerekou, President and head of national defense
Suffrage: universal for adults whenever elections or referendums are held
Elections: current government has held no elections and none are scheduled
Political parties: none
Communists: no Communist party; possibly some sympathizers
Member of: ADB, ECA, EAMA, Entente, FAO, ICAO, ILO, ITU, La Francophonie, Niger
River Commission, OAU, OCAM, U.N., UNESCO, UPU, WHO, WMO','3bc077662d94e4d341362c459c5c2d9cca48efc6e63da808a0cc5d0a9dac9ab9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9d779b5900caf1f817494ec5299f564a9f6b6324203c04131702764df141d65',1973,'DZ','Algeria','government',57,'Legal name: Kingdom of Denmark
Type: constitutional monarchy
Capital: Copenhagen
Political subdivisions: 14 counties, 277 communes, 88 towns
Legal system: civil law system; constitution adopted 1953; judicial review of
legislative acts; legal education at Universities of Copenhagen and Arhus;
accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament
(Folketing); executive power vested in Crown but exercised by cabinet
responsible to parliament; Supreme Court, 2 superior courts, 106 lower courts
Government leaders: Queen Margrethe II; Prime Minister Anker Jorgensen
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years (next in 1975)
Political parties and leaders: Social Democratic, Anker Jorgensen; Moderate
Liberal, Poul Hartling; Conservative, Erik Haunstrup Clemmensen; Radical
Liberal, Asqer Baunsbak-Jensen; Socialist Peoples, Sigurd Omann; Communist,
Knud Jespersen; Left Socialist, a triumvirate consisting of Ernst Dahl, Leif
Sondergaard Andersen, and Niels Finn Christiansen
Voting strength (1971 election): 37.4% Social Democratic, 15.7% Moderate Liberal,
16.7% Conservative, 14.3% Radical Liberal, 9.1% Socialist Peoples, 1.4%
Communist, 5.3% other
Communists: 5,000; a number of sympathizers, as indicated by 39,344 Communist
votes cast in 1971 elections
Member of: Council of Europe, EC, FAO, GATT, IAEA, IBRD, ICAQ, IDA, IFC, IHB,
ILO, IMCO, IMF, ITU, NATO, Nordic Council, OECD, Seabeds Committee (observer),
U.N., UNESCO, UPU, WHO, WMO
Legal name: State of Dominica
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Roseau
Political subdivisions: 10 parishes
Legal system: based on English common law; three local magistrate courts and
the British Caribbean Court of Appeals
Branches: legislature, 1] member popularly elected House of Assembly; executive,
cabinet headed by Prime Minister
Government leaders: Premier Edward 0. LeBlanc; U.K. Governor Louis Cools-Lartigue
Suffrage: universal adult suffrage over age 18
Elections: every 5 years; most recent October 1970
Political parties and leaders: Dominica Labor Party (DLP), Edward 0. LeBlanc;
Dominica Freedom Party (DFP), Miss M. Eugenia Charles
Voting strength: House of Assembly seats -- DFP 2 seats, DLP 8 seats, indepen-
dent 1 seat
Communists: negligible
Member of: CARIFTA
Legal name: (The) Spanish State
Type: nominally a monarchy, but without a king; actually a dictatorship under
Generalissimo Franco with Prince Juan Carlos designated to succeed him as
chief of state and become king
Capital: Madrid
Political subdivisions: metropolitan Spain, including the Canaries and Balearics,
divided into 50 provinces with governors appointed by the central government;
also 1 province and 5 places of sovereignty (presidios) in Africa; Ifni
province ceded by Spain to Morocco in June 1969; 2 former provinces com-
prising Equatorial Guinea were granted independence in October 1968
Legal system: civil law system, with regional applications of customary Taw;
7 basic laws including Organic Law of the State of January 1967 serve as
a constitution; legal education at 14 schools of law; does not accept
compulsory ICJ jurisdiction
Branches: executive, with chief of government dominating all branches of
government through his appointive powers and authority to legislate by
decree; legislative with unicameral Cortes dominated by executive; judicial,
independent in principal but generally limited to interpretation of laws
Government leader: Generalissimo Francisco Franco -- who is also Chief of State,
Commander in Chief of the armed forces, and head of the National Movement
(formerly called the Falange)
Suffrage: universal in national referendums, over age 21
Elections: only two types of direct election other than referendum provided:
representatives to municipal councils for which only heads of households
vote (last election November 1970) and, under new constitutional law of 1967,
104 members of the Cortes elected by heads of households and married women
for a 4-year term (last election September 1971)
Approved For Release 2004/09/15 : CAN-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GOVERNMENT (cont''d:
Political parties and leaders: National Movement (formerly called Falange) only
legally recognized party, headed by Franco; Torcuato Fernandez Miranda,
minister-secretary general of the movement; various semiclandestine opposition
groups include -- Christian Democratic factions under Jose Maria Gil Robles
and Joaquin Ruiz Gimenez; the Socialists, whose secretary general, Rodolfo
Llopis, is in exile; “Internal Socialists” under Enrique Tierno Galvan; the
Anarchists; Republicans; Monarchists; smaller regional and national splinter
groups; the Communist Party, whose secretary general, Santiago Carrillo
Solares, is in exile and is challenged by a small dissident pro-Soviet faction
led by exiled Enrique Lister Forjan; and some small pro-Chinese Communist
groups which appear and disappear under varying names; and a pro-Chinese
Communist faction Marxist-Leninist Communist Party of Spain
Voting strength: 561 seats, but somewhat fewer members as some hold more than one
seat -- 19% representing the family elected directly; 45% representing
municipalities, syndicates, and professions elected indirectly under close
regime control; and 36% are appointed by regime or are ex officio
Communists: (inside and outside Spain, est.) 5,000; sympathizers up to 20,000
Other political or pressure groups: the state-controlled organization of
syndicates, comprising representatives of management and labor, an illegal
labor group called the Workers'' Commissions, the Catholic Church, business
and land owning interests, Opus Dei, Catholic Action, university students
Member of: FAQ. IAEA, IBRD. ICAO, ILO, IHB, IMF, ITU, OECD, Seabeds Committee
(observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Province of Sahara
Type: province of Spain, subordinate to Ministry of the Presidency
Capital: El Aaiun
Political subdivisions: two regions -- Rio de Oro and Saguia el Hamra
Legal system: based on Spanish civil law system and customary law
Branches: Provincial Council; 80 members, of whom half are elected natives
Government leader: Governor General responsible to Directorate General of the
Promotion of the Sahara (a division of the Ministry of the Presidency) ,
Br. Gen. Fernando de Santiago y Diaz de Mendivil
Suffrage: heads of families only
Elections: 40 members of Provincial Council, August 1967; half of municipal
councillors May 1969
e Political party: National Movement
Communists: party proscribed; Communist sympathizers, few (if any)
Other political or pressure groups: none
Legal name: Republic of Sri Lanka
Type: independent state since 1948
Capital: Colombo
Political subdivisions: 9 provinces, 22 administrative districts, and four
categories of semiautonomous elected local governments
Legal system: a highly complex mixture of English common Jaw, Roman-Dutch,
Muslim and customary law; new constitution 22 May 1972; no judicial review
of legislative acts; legal education at Sri Lanka Law College and Univers ity
of Sri Lanka, Peradeniya; has not accepted compulsory ICJ jurisdiction
Branches: unitary parliamentary form of government; unicameral legislature
and independent judiciary
Government leader: Prime Minister Sirimavo Bandaranaike
Suffrage: universal over age 18, but most Indian Tamils, who comprise 10.6% of
population, are not enfranchised
Elections: national elections, ordinarily held every 6 years; must be held more
frequently if government loses confidence vote; last election held May 1970,
but new constitution postpones deadline for next election until May 1977
Political parties and leaders: Sri Lanka Freedom Party, Sirimavo Ratwatte Dias
Bandaranaike, President; Lanka Sama Samaja Party (Trotskyite), N. M.
Perera, President; Tamil United Front, S. J. V. Chelvanayakam, leader; United
National Party, Dudley Senanayake, President; Communist Party/Moscow, S. A.
Wickremasinghe, General Secretary; Communist Party/Peking, N. Shanmugathasan,
General Secretary; Mahajana Eksath Peramuna (People''s United Front), M. B.
Ratnayaka, President
Voting strength (1970 election): 37% Sri Lanka Freedom Party, 38% United
National Party, 9% Lanka Sama Samaja Party, 3.5% Communist Party/Moscow,
5% Federal Party, minor parties and independents accounted for remainder
Communists: approximately 169,000 voted for the Communist Party in the May 1970
general election; Communist Party/Moscow approximately 2,000, Communist
Party/Peking 532 (1968 est.)
Other political or pressure groups: Buddhist clergy, Sinhalese Buddhist lay
groups; far-left violent revolutionary groups; labor unions
Approved For Release 2004/09/15 3€#A-RDP79-01051A000500010001-1
Approved F : zi z =
GOVERNMENT fconale® or Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Member of: ADB. Colombo Plan, Commonwealth, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMCO, IMF, ITU, Seabeds Committee, U.N., UNESCO, UPU, WHO. WMO
Legal name: Democratic Republic of the Sudan
Type: republic under military control since coup in May 1969
Capital: Khartoum
Political subdivisions: 9 provinces, provincial and local administrations
controlled by central government; limited regional autonomy in 3 southern
provinces
Legal system: based on English common law and Islamic law; some separate
religious courts; constitution adopted 1956, suspended 1958, restored on an
interim basis in 1964; suspended with military coup in May 1969; temporary
constitution established by Republican order in August 1971; the following
constituent assembly expected to complete draft of permanent constitution
> in 1973; Revolutionary Command Council established in 1969 dissolved in
October 1971 with the installation of Ja'' far al-Numayrias president and
chief executive; Numayri has reorganized government through a series of
Republican decrees; legal education at University of Khartoum and Khartoum
extension of Cairo University at Khartoum; accepts compulsory ICJ jurisdiction,
with reservations
Government leader: President and Prime Minister Ja''far al-Numayri
Suffrage: universal adult but franchise has not been exercised under present regime
Elections: parliamentary elections, first after 6 years of military rule held
in April and May 1965 in 6 northern provinces; latest elections in April
1968; presidential plebescite held in September 1971 elections to constituent
assembly held in September-October 1972
Political parties and leaders: all parliamentary political parties outlawed since
May 1969; the ban on the Sudan Communist Party was not enforced until after
abortive coup in July 1971; the government''s mass political organization, the
Sudan Socialist Union, was formed in January 1972
ie Voting strength: not tabulated by party
Communists: party decimated following July 1971 coup and counter-coup, several
top leaders including Secretary-General Mahjub executed; actual hard-core
membership down to lowest point in years; party control over labor unions,
professional groups and university student groups ended; Communists purged
Approved For Release 2004/09/15 3451A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-R -
scuepuuelin Coane aie DP79-01051A000500010001-1
from government; party is being reorganized underground under leadership of
Secretary-General Muhammad Ni jud
Other political or pressure groups: Ansar Muslim sect, at odds with the military
regime since the May coup, defeated in fighting in spring 1970; Sudan Opposition
Front, composed of former political party elements and other disgruntled
conservative interests, operates in exile
Member of: Arab League, IAEA, IBRD. ICAO, IDA. IFC, ILO, IMF. ITU, OAU, Seabeds
Committee, U.N., UPU, WMO
Legal name: Surinam
Type: territory within Kingdom of the Netherlands, enjoying complete domestic
autonomy
Capital: Paramaribo
Political subdivisions: 9 districts, each headed by district commissioner
responsible to Minister of Internal Affairs
Legal system: Dutch civil law system; country statute of 1955 serves as
constitution
Branches: Council of Ministers headed by a Minister-President, which constitutes
the Cabinet; 39-member legislative council (Staten) popularly elected for
4-year term; court system administered by Attorney-General under Minister
of Justice and Police
Government leader: Minister-President, Jules Sedney
Suffrage: universal over age 23
Elections: every 4 years or earlier upon request of Minister-President
Political parties and leaders: National Party of Surinam (NPS), (temporary
leader M. Ch. Calor); Party of the People''s Welfare (VHP), J. Lachmon; Action
Group (AG), R. Janki; Progressive National Party (PNP), Frank E. Essed;
Surinam Democratic Party (spp) , B. F. J. Oostburg; United Indonesian People''s
Party (SRI), F. Karsowidijojo; Javanese Farmers'' Party (KTPI), H. I. Soemi ta;
Nationalist Republic Party (PNR), Edward Bruma (principal leftist party)
Voting strength (1969): 27.7% NPS, 35.1% VHP, .2% AG, 23.3% PNP, 1.1% SDP, 3.4%
SRI, 8.8% other
Communists: no overt Communist Party; PNP believed to have Communist sympathizers
Member of: EC (associate), WHO
Approved For Release 2004/09/15 : G2A-RDP79-01051A000500010001-1
ECONOMY: Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GNP: $300 million (1971 est.); $720 per capita; real growth rate 1971, 4% est.
Agriculture: main crops -- rice, sugarcane, bananas; self-sufficient in major
staple (rice); caloric intake 2,350 calories per day per capita (1968)
Major industries: bauxite mining, alumina and aluminum production, lumbering,
food processing
Electric power: 220,000 kw. capacity (1971); 1.3 billion kw.-hr. production B
(1971), 3,260 kw.-hr. per capita
Exports: $172 million (f.o.b., 1971 prelim.); bauxite, alumina, aluminum, wood and
wood products, rice
Imports: $126 million (c.i.f., 1971); capital equipment, petroleum, iron and
steel, cotton, flour, meat, dairy products
Major trade partners: exports -- U.S. 39%, Canada 2%, Netherlands 14%; imports :
-- U.S, 35%, Netherlands 22%, Europe 18% (1971)
Aid: economic -- extensions from U.S. (FY53-71), $5.0 million loans, $4.7 million
grants; from international organizations (FY49-71), $33.5 million
Monetary conversion rate: 1.79 Surinam guilders (S. fl.)=US$1 (27 December 1971)
Fiscal year: calendar year
. Legal name: Kingdom of Swaziland
Type: constitutional monarchy, under King Sobhuza II; independent member of
Commonwealth since September 1968
Capital: Mbabane (administrative), Lobamba (royal and legislative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-Dutch law in statutory courts,
Swazi traditional law and custom in traditional courts; constitution
adopted in 1968; legal education at University of Botswana, Lesotho, and
Swaziland (located in Lesotho); has not accepted compulsory ICU jurisdiction
Branches: executive authority vested in King but exercised through Prime Min-
ister and cabinet; cabinet appointed by King from legislative majority;
House of Assembly (24 elected, 6 appointed by King plus Speaker and Attorney
General) and Senate (6 elected by House of Assembly, 6 appointed by King,
Speaker) -- 17 Swazi courts administer customary law for Africans, High
Court and Subordinate Courts have criminal jurisdiction over all residents,
Court of Appeal has appellate jurisdiction
eee leader: Head of State King Sobhuza II; Prime Minister Makhosini
Dalmini
Suffrage: universal for adults
Elections: first elections for Legislative Council held in June 1964; latest
in May 1972
Political parties and leaders: Imbokodvo, the traditionalist party, controlled
by King Sobhuza II; Ngwane National Liberatory Congress (NNLC), led by
Dr. Ambrose Zwane, is only active opposition
Voting strength: in 1972 elections, Imbokodvo won 21 seats, NNLC won 3 seats in
the House of Assembly
Communists: no Communist Party; opposition party slogans have vague Marxist tone
Member of: OAU, U.N.
Legal name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 provinces, 624 communes, 224 towns
© Legal system: civil law system influenced by customary law; Acts of 1809,
1886, 1910, and 1949 serve as constitution; judicial review of legislative
acts in Supreme Court; legal education at Universities of Lund, Stockholm,
and Uppsala; accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament (Riksdag) ;
¢ executive power vested in Crown but exercised by cabinet responsible to
parliament; Supreme Court, 6 superior courts, 152 lower courts
Government leaders: King Gustav VI Adolf; Prime Minister Olof Palme
Suffrage: universal, but not compulsory, over age 20
Elections: every 3 years (next in 1973)
Political parties and leaders: Moderate Coalition (conservative), Gosta Bohman;
Center, Thorbjorn Falldin; Liberal, Gunnar Helen; Social Democratic, Olof
Palme; Communist, Carl-Henrik Hermansson; Communist League of Marxists-Leninists
(KFML), Gunnar Bylin
Voting strength (1970 election): 11.5% Conservative, 19.9% Center, 16.2% Liberal,
45.3% Social Democratic, 4.8% Communist, 0.4% KFML, 1.8% other
Communists: 17,000; a number of sympathizers as indicated by the 236,700
Communist votes cast in 1970 elections; an additional 21,200 votes cast for
Maoist KFML
Member of: Council of Europe, EC (Draft Free Trade Agreement), EFTA, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, Nordic Council, OECD,
Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Swiss Confederation
Type: federal republic
Capital: Bern
Political subdivisions: 22 cantons (3 divided into half cantons)
Legal system: civil law system influenced by customary law; constitution adopted
1874, amended since; judicial review of legislative acts, except with
respect to Federal decrees of general obligatory character; legal education
at Universities of Bern, Geneva and Lausanne, and four other university
schools of law; accepts compulsory ICJ jurisdiction, with reservations
Branches: bicameral parliament has legislative authority; federal council
(Bundesrat) has executive authority; justice left chiefly to cantons
Government leader: Roger Bonvim (1-year term as president begins on January 1973),
President
Suffrage: universal over age 20
Elections: held every 4 years; next elections 1975
Political parties and leaders: Social Democratic Party (SPS), Arthur Schmid,
president; Radical Democratic Party (FDP), Henri Schmitt, president;
Christian Conservative People''s Party (CVP), Franz Josef Kurmann, president;
Farmer, Artisan, and Middle Class Party (BGB), Hans Conzett, president;
Communist Party (PdA), Jean Vincent, leading Secretariat member; Republican
Movement (REP)-National Action (N.A.), James Schwarzenbach
Voting strength (1971 election): 49 seats FDP, 44 seats CVP, 46 seats SPS, 23
seats BGB, 5 seats PdA, 4 seats N.A., 7 seats REP, 22 seats others
Communists: 3,500; 50,831 votes in 1971 election
Member of: Council of Europe, EFTA, FAO, IAEA, ICAO, OECD, U.N. (permanent
observer), WHO, WMO
Legal name: Syrian Arab Republic
Type: republic; under left-wing military regime since March 1963
Capital: Damascus
Political subdivisions: 13 provinces and city of Damascus administered as
separate unit
Legal system: based on Islamic law and civil law system; special religious courts;
provisional constitution promulgated in 1964; legal education at Damascus
University and University of Aleppo; has not accepted compulsory ICJ
jurisdiction
Branches: legislative and executive powers vested in President and Council
of Ministers; seat of power is the Ba''th Party Regional (Syrian) Command
Government leaders: President Hafiz Al-Asad
Suffrage: universal over age 18
Elections: no electoral laws in force; last elections in December 1961; presidential
referendum in 1971; local councils elected in March 1972
Political parties and leaders: ruling party is the Arab Socialist Resurrectionist
(Bath) party; a "national front" cabinet formed in March 1972, dominated by
Ba''thists, includes independents and members of the Syrian Arab Socialist
Party (ASP), Arab Socialist Union (ASU), and Syrian Communist Party (SCP)
Communists: mostly sympathizers, numbering 10,000 to 13,000
Other political or pressure groups: non-Ba''th parties have little effective
political influence; Communist Party ineffective; greatest threat to Ba''thist
regime lies in factionalism in Ba''th Party itself
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU. U.N.,
UNESCO, UPU, WHO, WMO
Legal name: United Republic of Tanzania
Type: republic; single parties dominate both on the mainland and on Zanzibar
Capital: Dar es Salaam
Political subdivisions: 22 regions -- 18 on mainland, 4 on Zanzibar islands
Legal system: based on English common law, Islamic law, customary law, and German
civil law system; interim constitution adopted 1965; judicial review of
legislative acts limited to matters of interpretation; legal education at
University College, Dar es Salaam; has not accepted compulsory ICJ jurisdiction
Branches: President Julius Nyerere has full executive authority on the mainland;
National Asssembly dominated by Nyerere and the Tanganyika African National
Union (TANU), consists of 120 elected members, 18 ex officio members, and up
to 25 appointed members from mainland, and 3 ex officio members and up to 52
appointed members from Zanzibar; First Vice President Aboud Jumbe and the
Revolutionary Council still run Zanzibar despite the efforts of Nyerere to
integrate the islands into the political system of the mainland
Government leader: President Julius Nyerere
Suffrage: universal adult
Political party and leaders: Tanganyika African National Union (TANU), only main-
land political party, dominated by Nyerere with Second Vice President Rashidi
Kawawa as his top lieutenant; Afro-Shirazi Party, the only party in Zanzibar,
is supposed to merge with TANU eventually
Voting strength (October 1970 national elections): 5 million registered voters;
Nyerere received 95% of 3.6 million votes cast
Communists: a few Communists and sympathizers
Member of: Commonwealth, EAC, FAO, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2004/09/15 : CB84RDP79-01051A000500010001-1
004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY: Approved For Release 2
Mainland:
GDP: $1,138 million at 1966 prices (1971), about $80 per capita; growth rate in
constant 1966 prices for 1970-71 4.5%
Agriculture: main crops -- cotton, coffee, sisal on mainland; largely self-
sufficient in food
Fishing: catch 195,000 metric tons, $15.7 million; exports $2.2 million, imports
$554,000 (1970)
Major industries: primarily agricultural processing (sugar, beer, cigarettes,
sisal twine), diamond mine, of] refinery, shoes, cement, textiles, wood
products
Electric power: 119,500 kw. capacity (1971); 460 million kw.-hr. produced (1971),
34 kw.-hr. per capita
Exports: $279 million (f.0.b., 1971); coffee, cotton, sisal, cashew nuts, meat,
diamonds, cloves, tobacco, tea
Imports: $382 million (c.i.f., 1971); manufactured goods, machinery and transport
equipment, cotton piece goods, crude oi], foodstuffs (mainly for Zanzibar)
Major trade partners: exports -- China, U.K., Hong Kong, India, Kenya, U.S.;
imports -- U.K., China, Kenya, West Germany, U.S., Japan
Monetary conversion rate: 1 Tanzanian shilling=US$0.14; 7.143 Tanzanian
shillings=US$1
Fiscal year: 1 July - 30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops -- cloves, coconuts
Industries: agricultural processing
Electric power: see Tanganyika (above)
Exports: $12.6 million (1968); Cloves and clove products, coconut products
Imports: $5.6 million (1968); mainly foodstuffs and consumer goods
Major trade partners: imports -- China, Japan, and mainland Tanzania;
exports --','5c81828abb6f1967510d77027eebdd1000092d9589e4ce65c09ed5e86935eba7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21dd206c9e8a030d42141971988c33a25c57c4bcd70df8535e97f4a83767b9c6',1973,'DZ','Algeria','government',58,'Singapore, China, Hong Kong, Indonesia, India, Pakistan
Aid: U.K. principal source of aid until 1964; China is currently major source
Exchange rate: 1 Tanzanian shilling=US$0.14; 7.143 Tanzanian shillings=US$1
Fiscal year: 1 July - 30 June
Legal name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions: 71 centrally controlled provinces
Legal system: based on civil law system, with influences of conmon law; new
constitution promulgated in 1968, suspended 17 November 1971; legal education
at Thammasat University; has not accepted compulsory ICJ jurisdiction
Branches: King is head of state with nominal powers; Chairman heads a 16-man
national executive council, a caretaker body, pending an appointment of a
new cabinet under a provisional constitution; judiciary relatively independent
except in important political subversive cases
Government leaders: King Phumiphon Adundet; Field Marshal Thanom Kittikachorn,
Chairman; General Praphat Charusathien, Deputy Chairman
Suffrage: universal
Elections: suspended
Political parties and leaders: dissolved under the revolutionary order 17
November 1971
Communists: strength of illegal Communist Party is about 1,000; Thai Communist
insurgents throughout Thailand total about 5,500 ;
Member of: ADB, ASA, ASEAN, ASPAC, Colombo Plan, ECAFE, FAQ, IAEA, ICAO, IDA,
ite nth art ITU, Seabeds Committee, SEAMES, SEATO, U.N., UNESCO, UNICEF,
PU, WHO, W
Legal name: Republic of Togo
Type: republic; under military rule since January 1967
Capital: Lome
” Political subdivisions: 18 circumscriptions
Legal system: based on French civil law and customary practice; no constitution;
has not accepted compulsory ICJ jurisdiction
Branches: military government, with civilian participation in the cabinet, took
over on 14 April 1967, replacing provisional government created after
os January coup; no legislature; separate judiciary including State Security
Court established 1970
Government leader: Brig. Gen. Etienne Eyadema, President
Suffrage: universal adult
Elections: presidential referendum of January 1972 elected Etienne Eyadema for
indefinite period
Political parties: single party formed by President Eyadema in September 1969;
Rassemblement de Peuple Togolais, structure and staffing of party closely
controlled by government
Communists: no Communist Party; possibly some Communists and sympathizers
Member of: ADB, EAMA, ECA, ENTENTE, FAO, IBRD, ICAO, ILO, IMF, ITU, La Francophonie,
OAU, OCAM, U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Tonga
Type: constitutional monarchy
Capital: Nukualofa
Political subdivisions: 3 main island groups (Tongatapu, Haapi, Vavau)
Legal system: based on English law
Branches: Executive (King and Privy Council); Legislative (Legislative Assembly
composed of 7 nobles elected by their peers, 7 elected representatives of
the people, 7 Ministers of the Crown; the King appoints one of the 7 nobles
2 ee speaker); Judiciary (Supreme Court, magistrate courts, Land
our
Government leaders: King Taufa''ahau Tupou IV; Premier, Prince Tu''ipelehake
(younger brother of the King)
Suffrage: granted to all literate adults over 21 years of age who pay taxes
Elections: held triennially
Communists: none known
Member of: Commonwealth
Legal name: Trinidad and Tobago
Type: independent state since August 1962; recognizes Elizabeth II as chief
of state
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards, Tobago is 30th)
Legal system: based on English common law; constitution came into effect
1962; judicial review of legislative acts in the Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: legislative branch consists of 36-member elected House of
* Representatives and 24-member Senate (13 nominated by Prime Minister,
4 by opposition leader, 7 at discretion of Governor General); executive is
cabinet led by the Prime Minister; judiciary is Supreme Court
Government leader: Prime Minister, Dr. Eric Williams
Suffrage: universal over age 21
Elections: last election 24 May 1971, PNM won all seats (constitutionality of
situation is under review)
Political parties and leaders: People''s National Movement (PNM), Dr. Eric
Williams; Democratic Labor Party (DLP), Vernon Jamadar; Democratic Liberation
Party (DLIBP); United National Independence Party, (UNIP) James Millette;
Democratic Action: Congress (DAC), Arthur Napoleon Raymond Robinson
Voting strength (1971 election): 32.9% of registered voters cast ballots, 83.7%
PNM, 16.3% other
Communists: not significant
Other political pressure groups: Tapia House Group (headed by Lloyd Best);
National Youth Congress (NYC); Oilfield Workers Trade Union (OWTU), pro-
Marxist leadership; National Joint Action Committee (NJAC), antigovernment,
extreme organization; United Revolutionary Organization (URO), Marxist-led
amalgam
Member of: CARIFTA, Commonwealth, GATT, IBRD, ICAO, IDB, IMF, OAS, Seabeds
Committee, U.N.
Approved For Release 2004/09/15 : CHA2RDP79-01051A000500010001-1
ECONOMY: Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GDP: $957 million (1971 est.), $990 per capita; real growth rate 1971, 1.4% est.
Agriculture: main crops -- sugarcane, cocoa, coffee, rice, citrus, bananas;
largely dependent upon imports of food
Fishing: catch 4,000 metric tons (1970); exports $2.4 million (1970),
imports $2.5 million (1970)
Major industries: petroleum, tourism, food processing, cement
Electric power: 288,000 kw. capacity (1971); 1.2 billion kw.-hr. produced (1971),
1,155 kw.-hr. per capita
Exports: $563 million (f.o.b., 197] est.); petroleum and petroleum products,
sugar, cocoa
Imports: $713 million (c.i.f., 1971 est.); crude petroleum, machinery,
‘transportation equipment, manufactured goods, food
Major trade partners: exports -- U.S. 47%, U.K. 9%, CARIFTA 11%; imports --
Venezuela and Colombia 25%, U.S. 17%, U.K. 13%, CARIFTA 2% (1971)
Aid: economic -- from U.S. (FY56-70) $24.7 million loans, $40.2
million grants; from international organizations (FY53-71), $64.1 million
Monetary conversion rate: TT$1.84=US$1
Fiscal year: calendar year
Legal name: Republic of Tunisia
Type: republic
Capital: Tunis
Political subdivisions: 14 governorates (provinces)
Legal system: based on French civil law system and Islamic law; constitution
patterned on Turkish and U.S. constitutions adopted 1959; some judicial
review of legislative acts in the Supreme Court in joint session; legal
education at Institute of Higher Studies and Ecole Superieure de Droit of the
k University of Tunis; has not accepted compulsory ICJ jurisdiction
Branches: executive dominant; unicameral legislative largely advisory; judicial,
patterned on French system and Koranic law
Government leader: President Habib Bourguiba; Prime Minister Hedi Nouira
Suffrage: universal over age 21
Elections: national elections held every 5 years; last elections 2 November 1969
Political party and leader: Destourian Socialist Party, Habib Bourguiba
Voting strength (1969 election): 100% Destourian Socialist Party
alle te 100 est.; a few sympathizers; Tunisian Communist Party proscribed in
962
Member of: Arab League, EC (association until 1974), FAQ, IAEA, IBRD, ICAO, IDA,
ee coe IMCO, IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO, UPU,
Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic Taw; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promul gated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Cevdet Sunay, Acting Prime Minister Ferit Melen
Suffrage: universal over age 21
Elections: National Assembly (1973); Presidential (1973)
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party (RPP), Bulent Ecevit; Democrats Party (DP), Ferruh Bozbeyli;
Reliance Party (RP), Turhan Feyzioglu; New Turkey Party (NTP), Yusuf Azizoglu;
Nationalist Movement Party (NMP), Alparslan Turkes; Nation Party (NP), Osman
Bolukbasi; Unity Party (UP), Mustafa Timisi; Republican Party (RP), Kemal
Satir (formed in 1972); Communist Party illegal
Voting strength: 1969 National Assembly elections -- 46.6% JP, 27.5% RPP, 3.3%
NP, 2.2% NTP, 2.6% TLP, 5.7% independent, 6.4% RP, 3.1% NMP, 2.5% UP; 1968
Senatorial elections (1/3 of Senate seats) -- 49.9% JP, 27.1% RPP, 6.0% NP,
8.5% Reliance Party, 4.7% TLP, 2.0% RPNP
Communists: strength and support negligible
Other political or pressure groups: military overthrew government in 1960, forced
resignation of Demirel government in March 1971 and remains the dominant
force behind the new government
Approved For Release 2004/09/15 @ia-RDP79-01 051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-0 -
SVEWNNENE GO: 1051A000500010001-1
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECD, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO
Legal name: Republic of Uganda
Type: republic independent since October 1962
Capital: Kampala
Political subdivisions: 20 districts (being revised)
Legal system: based on English common law and customary law; constitution
adopted 1967; judicial review of legislative acts; legal education at
Makerere University, Kampala; accepts compulsory ICJ jurisdiction, with
reservations
Branches: Gen. Amin rules by decree; assisted by Council of Ministers and Defense
Council, a group of military officers
Government leader: Gen. Idi Amin, President
Suffrage: universal adult
Elections: none scheduled by military government
Political party and leader: Uganda People''s Congress (UPC), principal party
before 1971 coup, not banned but inactive
Communists: possibly a few sympathizers
Member of: Commonwealth, EAC, IAEA, ICAO, ILO, OAU, U.N., UNESCO, WHO
Legal name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow
Political subdivisions: 15 union republics, 20 autonomous republics, 6 krays,
114 oblasts, and 8 autonomous oblasts
Legal system: civil law system as modified by Communist legal theory; constitution
adopted 1936; no judicial review of legislative acts; legal education at 18
universities and 4 law institutes; has not accepted compulsory ICJ jurisdiction
4 Branches: Council of Ministers (executive), Supreme Soviet (legislative), Supreme
Court of U.S.S.R. (judicial)
Government leaders: Leonid I. Brezhnev, General Secretary of the Central Committee
of the Communist Party; Aleksey N. Kosygin, Chairman of the Council of
Ministers; Nikolay V. Podgornyy, Chairman of the Presidium of the U.S.S.R.
Supreme Soviet
Suffrage: universal over age 18; direct, equal
Elections: to Supreme Soviet every 4 years; 1,517 deputies elected in 1970;
72.3% party members
Political parties and leaders: Communist Party of the Soviet Union (CPSU) only
party permitted
Voting strength (1970 election): 153,237,112 persons over 18; claimed 99.96%
voted
Communists: nearly 14,500,000 party members
Other political or pressure groups: Komsomol, trade unions, and other organizations
which facilitate Communist control
Member of: CEMA, IAEA, ICAO ILO, IMCO, ITU, Seabeds Committee (observer), U.N.,
UNESCO, UPU, Warsaw Pact, WHO, WMO
Legal name: United Arab Emirates (comprised of former Trucial States)
Type: federal system; constitution signed December 1971, which delegated
specified powers to the United Arab Emirates central government and
reserved other powers to member sheikhdoms
Capital: Abu Zaby
Legal system: secular codes are being introduced by the U.A.E. government and
in several member sheikhdoms; Islamic law remains very influential
Branches: Supreme Council of Rulers (7 members), from which a President and Vice
President are elected; Prime Minister and Council of Ministers; National
Consultative Council; federal judiciary provided for in constitution but not
yet activated
Government leaders: Sheikh Zayid of Abu Dhabi, President; Sheikh Rashid of Dubai,
Vice President; Sheikh Maktum of Dubai, Prime Minister
Member states: Abu Dhabi; Ajman; Dubai; Fujairah; Ras al Khaimah; Sharjah; Umm
al Qaiwain
Member of: Arab League, U.N.
Legal name: Republic of Upper Volta
Type: republic; transitional military regime in power since January 1966, will
rule until 1974
Capital: Ouagadougou
Political subdivisions: 5 departments consisting of 44 cercles
Legal system: based on French civil law system and customary law; constitution
adopted 1970; judicial review of legislative acts in Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: President is an army officer; 57-man National Assembly was elected in
December 1970; 4 year transition period will follow during which President
will rule over 15-man cabinet, one-third of which will be military; separate
judiciary
Government leader: President Gen. Sangoule Lamizana
Suffrage: universal for adults
Elections: Natiorial Assembly elections held in late December 1970; RDA-UDV holds
38 seats, PRA 12, MLN 5, Independent 2
Political parties and leaders: 7 legally recognized parties; Voltan Democratic
Union-African Democratic Rally (UDV-RDA), Gerard Kango Ouedraogo; African
Regroupment Party (PRA), D. Pale Welte Issa; Movement for National Liberation
(MLN), Joseph ki-Zerbo; People''s Action Group (GAP), Nohoun Sigue; Union for
the New Voltaic Republic (UNR), Blaise Bassoleth; Party of National Regroupment
(PRN), Francois Bassolet; Party of Voltan Workers (PTV), George Kabore
Communists: no Communist party; possibly some sympathizers
Other political or pressure groups: labor organizations are badly splintered
Member of: ADB, EAMA, ECA, ENTENTE, FAO, ICAQ, ILO, ITU, Niger River Commission,
OAU, OCAM, U.N., UNESCO, WHO, WMO
Legal name: Oriental Republic of Uruguay
Type: republic
Capital: Montevideo
Political subdivisions: 19 departments with limited autonomy
Legal system: based on Spanish civil law system; new constitution implemented
x 1967; judicial review of legislative acts in Supreme Court, legal education
} at University of the Republic at Montevideo; accepts compulsory ICJ
jurisdiction
Branches: executive, headed by President; bicameral legislature (30 Senators
plus Vice President who presides and has voice and vote, and 99-member
‘ Chamber of Deputies) elected by popular vote under a complicated system
using proportional representation; national judiciary headed by Supreme
Court
Government leader: President Juan Maria Bordaberry
Suffrage: universal over age 18
Elections: every 5 years; next in 1976
Political parties and leaders: National (Blanco) Party, President of Party
Directorate Homero Murdoch, main factions include Martin Echegoyen''s "Alianza"
faction, List 400 (Washington Beltran), Rocha Movement (Alberto Gallinal),
Orthodox Herreristas (Alberto Heber Usher), and Por La Patria (Wilson Ferreira
Aldunate); Colorado Party, main factions include Colorado and Batllista Union
(Juan Maria Bordaberry), List 15 (Jorge Batlle), List 315 (Amilcar Vasconcellos);
Broad Front (Frente Amplio), leftwing coalition of Leftist Liberation Front
(FIDEL), Communist Front and dissident factions from both the Blanco and
Colorado parties, and including FIDEL, the Christian Democrats, and other
splinter groups
Voting strength (1971 elections): 41% Colorado, 40.2% Blanco, 18.3% Frente Amplio,
0.5% Radical Christian Union
Communists: 35,000-40,000 including Communist youth group (6,000-8,000)
Other political or pressure groups: Communist Party (PCU), Rodney Arismendi;
Christian Democratic Party (PDC); Socialist Party of Uruguay (PSU); Revolu-
tionary Movement of Uruguay (MRO) pro-Cuban Communist Party; National
Liberation Movement of Uruguay (MRO) pro-Cuban Communist Party; National
Liberation Movement (MLN-Tupamaros) Marxist Revolutionary terrorist group
Member of: IADB, IAEA, IBRD, ICAO, ILO, IMF, LAFTA, OAS, U.N.
Approved For Release 2004/09/15 : &A-RDP79-01051A000500010001-1
ECONOMY: Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GNP: $3.3 billion (purchasing power parity estimate, 1971); $1,130 per capita;
74% private consumption, 12% public consumption, 14% gross investment (1969);
real growth rate 1971, -0.7%
Agriculture: large areas devoted to extensive livestock grazing (22 million
sheep, 8 million cattle); main crops -- wheat, rice, corn; self-sufficient
in most basic foodstuffs; caloric intake, 3,000 calories per day per capita,
with high protein content
Major industries: meat processing, wool and hides, textiles, footwear, cement,
petroleum refining
Crude steel: 24,000 metric tons produced (1966), 10 kilograms per capita
Electric power: 555,000 kw. capacity (1971); 2 billion kw.-hr. produced
(1971 est.)}, 700 kw.-hr. per capita
Exports: $206 million ee 1971); beef, wool, hides
Imports: $222 million (c.i.f., 1971); fuels, metals, machinery, transportation
equipment
Major trade partners: exports -- EC 27%, U.K. 25%, U.S. 12%, LAFTA 11%;
nag imports -- LAFTA 26%, U.S. 22%, U.K. 14%, EC 13% (1968)
id:
economic -- extensions from U.S. (FY46-71), loans $119 million, grants
$23.9 million; from international organizations, IBRD $130.5 million, IDB
$87.3 million, U.N. $9.9 million; $6 million credit from East Germany (1966),
$10 million credit from Hungary (1970), $20 million credit from U.S.S.R.
(1969), $5 million credit from Czechoslovakia (1970), $.4 million credit from
Bulgaria (1969); military -- U.S. (FY53-71), grants $47.4 million, $4.4 million
credits
Monetary conversion rate: trade (selling) -- 647 pesos=US$1; financial -- floating
(875 pesos=US$1 on 21 September 1972)
Fiscal year: calendar year
Legal name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes St. Peter''s, the Vatican Palace
and Museum and neighboring buildings covering more than 13 acres; 13
buildings in Rome, although outside the boundaries, enjoy extraterritorial
rights
Legal system: Canon law; constitutional laws of 1929 serve some of the functions
of a constitution
Branches: the Pope possesses full executive, legislative, and judicial powers;
he delegates these powers to the governor of Vatican City, who is subject
to pontifical appointment and recall; high Vatican offices include the
Secretariat of State, the College of Cardinals (chief papal advisers), the
Roman Curia (which carries on the central administration of the Roman
Catholic Church) the Presidence of the Prefecture for the Economy, and
the synod of bishops (created in 1965)
Government leader: Supreme Pontiff, Paul VI, (Giovanni Battista Montini, born
26 September 1897, elected Pope 21 June 1963)
Suffrage: limited to cardinals aged 80 or younger
Elections: Supreme Pontiff elected for life by College of Cardinals
Communists: none known
Other political parties and pressure groups: none (exclusive of influence
exercised by other church officers in universal Roman Catholic Church)
Member: IAEA
Legal name: Republic of Venezuela
Type: republic
Capital: Caracas
Political subdivisions: 20 states, 1 federal district, 2 federal territories
Legal system: based on Spanish civil law system with influence of U.S. law;
constitution promulgated 1961; judicial review of legislative acts in
Cassation Court only; dual court system, state and federal; legal education
at Central University of Venezuela; has not accepted compulsory ICJ
jurisdiction
Branches: executive (President), bicameral legislature, judiciary
Government leader: President Rafael Caldera
Suffrage: universal and compulsory over age 18
Elections: every 5 years; next 9 December 1973
Political parties and leaders: Accion Democratica (AD), Carlos Andres Perez, and
Gonzalo Barrios; Social Christian Party (COPEI), Rafael Caldera, and Lorenzo
Fernandez; People''s Electoral Movement (MEP), Jesus Angel Paz Galarraga;
Cruzada Civica Nacionalista (CCN), Marcos Perez Jimenez, leader;
Union Republicana Democratica (URD), Jovito Villalba; Partido Comunista de
Venezuela (PCV), Secretary-General Jesus Faria; Fuerza Democratica Popular
(FDP), Jorge Dager; Frente Nacional Democratico (FND), Pedro Segnini La Cruz;
Movement to Socialism (MAS), Jose Vincente Rangel, Teodoro Fetkoff, and
Pompey Marquez
Voting strength (1968 election): 25.6% AD, 24.1% COPEI, 13% MEP, 10.9% CCN, 9.3%
URD, 5.3% FDP, 2.8% Union for Advancement (Communist front), 2.6% FND, 2.3%
PRIN
Communists: minuscule in numbers and effectiveness
Member of: FAO, IADB, IAEA, IBRD, ICAO, IDB, IFC, ILO, ITU, OAS, Seabeds Committee
(observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Democratic People''s Republic of Viet-Nam
Type: Communist state
Capital: Hanoi
Political subdivisions: 2 autonomous regions (of 3 and 5 provinces, respectively),
17 other provinces, 2 centrally governed municipalities, 1 special zone
Legal system: based on Communist legal theory and French civil law system;
constitution enacted 1960
a. | Branches: constitution provides for a National Assembly and highly centralized
} executive nominally subordinate to it
Party and government leaders: Le Duan, First Secretary; Ton Duc Thang, President
of DRV; Pham Van Dong, Premier; Truong Chinh, Chairman, Standing Committee
of National Assembly; Vo Nguyen Giap, Minister of National Defense
’ Suffrage: over age 18
Elections: pro forma elections held for national and local assemblies
Political parties: ruled by Lao Dong: Party with no organized opposition;
membership approximately 900,000 (about 4% of population)
Member of: no international bodies
Legal name: Republic of Viet-Nam
Type: republic
Capital: Saigon
Political subdivisions: 4 regions (corresponding to 4 military regions), 1 special
region (corresponding to Capital Special Zone), divided into 44 provinces
and 11 autonomous municipalities
Legal system: based on French civil law system; legal education at Universities
of Saigon and Hue
Branches: constitution provides for modified presidential system with executive,
legislative, and judicial branches
Government leaders: President Nguyen Van Thieu; Vice President Tran Van Huong;
Prime Minister Tran Thien Khiem
Elections: senate elections scheduled for 1973; next presidential elections
scheduled for 1975
Political parties and leaders: numerous small parties reflecting an emphasis on
personal leadership rather than ideological content; parties supporting
government and opposition groups are fragmented and poorly organized; An
Quang Buddhists are the most important opposition group, while several
Catholic parties usually back the government; other significant parties
include two old-line political parties (Revolutionary Dai Viet and Vietnamese
Nationalist-VNQDD), the Progressive Nationalist Movement, and the labor
union-based Farmer-Worker Party; Hoa Hao and Cao Dai politico-religious sects
exert strong influence in local areas
Communists: The People''s Revolutionary Party operates through and within the
National Front for the Liberation of South Vietnam (NLES and the Alliance of
National, Democratic, and Peace Forces (ANDPF), and the Provisional Revolu-
tionary Government (PRG) designed to rival the legal government
Member of: Colombo Plan, FAQ, IAEA, ICAO, ILO, IMCO, ITU, U.N. (certain specialized
U.N. agencies and maintains observer te','4fa3d68284c3afffad14109bf63f4c5ccdf9796fcfd505797fdbfa86c91272c4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f50ff6fcf3ca40ee5e521c11e306b38452a57909027c5b9d7c4baddcf54bc12a',1973,'DZ','Algeria','government',59,'am), UNESCO, UPU, WHO, WMO
369
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ECONOMY Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GNP: $2.3 billion (est. 1972), $120 per capita; no real growth rate estimated
for 1972
Agriculture: main crops -- rice, rubber, peanuts, corn, Sugarcane, sweet potatoes,
copra; major food imports -- rice, dairy products, sugar, wheat flour
Fishing: catch 587,400 metric tons (1971); 1 growing trade in fish and fish
products
Major industries: manufacturing on small scale, mainly light manufacturing and
processing of local agricultural and forest products; factories produce
textiles, beer, cigarettes, glass, tires, sugar, paper, cement, soft drinks;
there are also limited mining operations
Shortages: capital goods
Electric power: 900,000 kw. capacity (1972); 1.9 billion kw.-hr. produced (1972),
99 kw.-hr. per capita
Exports: $14 million (f.0.b., 1971); major commodities -- rubber, scrap metal,
duckfeathers
Imports: $825 million (c.i.f., 1971); major commodities -- machinery and trans-
portation equipment, rice, textile fabrics and yarn, petroleum products, base
metals and manufactures
Major trade partners: exports -- France, U.K., West Germany, Japan; imports --
U.S., Japan, Taiwan; no trade with Communist countries
Monetary conversion rate: multiple exchange rate system with flexible rates; as
of 1 October 1972 rates were as follows: 300 piasters=US$1 for U.S.-financed
merchandise imports; 435 piasters=US$1 for other merchandise imports
and most invisible transactions such as personal currency conversions, foreign
investment, and government transfers; 500 piasters=US$1 for most commodity
exports; average black market rate of 427 piasters=US$1 during third quarter
of 1972
Fiscal year: calendar year','c5941869645921093dc1ae979f0221747f662c60b8eb0e0de628f758060ed6c4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f36799fd547c06a543403b26d03f0b63fea65aa5844ab641d25c1ab88f4bc082',1973,'DO','Dominican Republic','government',66,'Legal name: Dominican Republic
Type: republic
Capital: Santo Domingo
Political subdivisions: 26 provinces and the National District
Legal system: based on French civil codes; 1966 constitution
Branches: President popularly elected for a 4-year term; bicameral legislature
consisting of Senate (27 seats) and Chamber of Deputies (74 seats) elected
for 4-year terms; members of Supreme Court elected by Senate
Government leader: President Joaquin Balaguer
Suffrage: universal and compulsory, over age 18 or married, except members of the
armed forces and police, who cannot vote
Elections: national, May 1974
Political parties and leaders: Reformist Party (PR), Joaquin Balaguer; Dominican
Revolutionary Party (PRD), Juan Bosch Gavino; Democratic Quisqueyan
Party (PQD), Elias Wessin y Wessin; Revolutionary Social Christian Party
(PRSC), Alfonso Moreno Martinez; Movement for National Conciliation (MNC),
Jaime Manuel Fernandez Gonzalez; Anti-reelection Movement of Democratic
Integration (MIDA) Francisco Augusto Lora; National Civic Union (UCN), Pedro
Guillermo Urraca; Fourteenth of June Revolutionary Movement (MR-104), split
into several factions, illegal; Dominican Communist Party (PCD), central
committee, illegal; Dominican Popular Movement (MPD), Rafael Taveras Rosario,
illegal; Communist Party of the Dominican Republic (PCRD), Luis Montas
Gonzalez, illegal; Popular Socialist Party (PSP), illegal
Voting strength (1970 election): 57% PR, (abstained) PRD, 5% PRSC, 14% PQD, 3%
MCN, 21% MIDA
Communists: an estimated 1,500 to 1,800 members in six different factions;
effectiveness limited by ideological differences and organizational
inadequacies
Member of: GATT, IADB, IAEA, ICAO, IHB, OAS, U.N.
Legal name: Republic of Ecuador
Type: republic
Capital: Quito
Political subdivisions: 19 provinces and 1 territory (Galapagos Islands)
Legal system: based on civil law system; modified 1945 constitution re-institutea
in February 1972, legal education at 4 state and 2 private universities; has
not accepted compulsory ICJ jurisdiction
Branches: President and government council assumed power February 1972; government
decisions announced by decree over the president''s signature; judiciary system
supervised by Supreme Court but currently undergoing reorganization
Government leader: President, General Guillermo Rodriguez Lara
Elections: none scheduled
Political parties and leaders: National Velasquista Front, personalistie, Jose
Maria Velasco Ibarra; Radical Liberal Party, Ignacio Hidalgo Villavicencio;
Social Christian Party, generally conservative, Camilo Ponce; Conservative
Party, Galo Pico Mantilla; Concentration of Popular Forces, populist, Assad
Bucaram; National Revolutionary Party, leftist, Carlos Julio Arosemena
Voting strength: in June 1968 national elections, Velasquistas, a center-left
coalition, and a rightist coalition each got approximately one-third
Communists: 500 members plus 2,500 sympathizers; Marxist-Leninist Communist Party,
250; pro-Castro Revolutionary Socialist Party, 450
Member of: ECOSOC, IADB, IAEA, ICAO, LAFTA and Andean Sub-Regional Group
(formed in May 1969 within LAFTA), OAS, Seabeds Conmittee (observer), U.N.
Legal name: Arab Republic of Egypt
Type: republic; under presidential rule since June 1956
Capital: Cairo
Political subdivisions: 25 governorates
% Legal system: based on English common law, Islamic law, and Napoleonic codes;
interim constitution of 1964; judicial review of limited nature in Supreme
Court, also in Council of State which oversees validity of administrative
decisions; legal education at Cairo University; accepts compulsory ICJ
jurisdiction, with reservations
4 Branches: executive power vested in President, who appoints cabinet; People''s
Assembly has little actual power (serves mainly for discussion and automa-
tic approval); independent judiciary administered by Minister of Justice
Government leader: President Anwar Sadat
Suffrage: universal over age 18
Elections: elections to People''s Assembly every 5 years (most recent October
1971); presidential elections every 6 years
Political parties and leaders: political parties banned except for the government-
sponsored sociopolitical grouping, Arab Socialist Union (ASU)
Communists: approximately 500, party members
Member of: AAPSO, Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO,
IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO, WPC','8c0fe49e13446a8f9f1b91de7efcb1d04acd8b4dfb28d4f9ef5197cf43e6bb9c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9725fdff8d4bcb0240a41ae3ea95b767fecdfcc4ec204712b59d4c6ca9aa4d9',1973,'SV','El Salvador','government',70,'Legal name: Republic of El] Salvador
Type: republic
Capital: San Salvador
Political subdivisions: 14 departments
Legal system: based on Spanish law, with traces of common law; constitution
adopted 1962; judicial review of legislative acts in the Supreme Court;
legal education at University of El Salvador; accepts compulsory ICJ
jurisdiction, with reservations
Branches: traditionally dominant executive, fairly independent unicameral
legislature, Supreme Court
Government leader: President Arturo Armando Molina
Suffrage: universal over age 18
Elections: legislative elections every 2 years; presidential elections every 5
years; presidential elections March 1977, legislative and municipal elections
March 1974
Political parties and leaders: National Conciliation Party (PCN), President
Arturo A. Molina, Dr. Enrique Mayorga Rivas, Rafael Rodriguez
Gonzalez; Christian Democratic Party (PDC), Juan Ramirez Rauda, Dr. Pablo
Mauricio Alvergue, Roberto Lara Velado; Dr. Abraham Rodriguez, Jose Napoleon
Duarte; Revolutionary Party (PR -- formerly Renovating Action Party), not
legally recognized, Shafick Handal, Dr. Fabio Castillo Figueroa, Julio Ernesto
Contreras; Salvadoran Popular Party (PPS), Benjamin Wilfredo Navarrete,
Roberto Quinonez Meza, Dr. Jose Antonio Guzman; Communist Party of £1 Salvador
(PCES), illegal, Jorge Shafick Handal; National Revolutionary Movement (MNR),
Dr. Guillermo Manuel Ungo; National Democratic Union Party (PUDN), Francisco
Roberto Lima, Julio Ernesto Contreras, Julio Castro Belloso;. Independent
Democratic United Front (FUDI), Gen. Jose A. Medrano, Raul Salaverria
Voting strength: February 1972 presidential election -- PCN 43.4%, PDC, PUDN,
and MNR coalition, 42.1%; FUDI, 12.3%; PPS 2.2%; March 1972 legislative
election -- PCN, 39 seats; PDC, MNR, and PUDN coalition, 8 seats; PPS 4 seats;
FUDI, 1 seat
Communists: 100 to 200 active members; sympathizers, 5,000
Other political or pressure groups: the military; the "14" prominent families;
General Confederation of Trade Unions (CGS); Unifying Federation of Salvadoran
Approved For Release 2004/09/15 : Ci\\-RDP79-01051A000500010001-1
A : ai el =
GOVERNMENT leone es For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Other political or pressure groups (cont''d):
Trade Unions (FUSS), Communist dominated; Federation of Construction and
Transport Workers Unions (FESINCONSTRANS), independent; Catholic Church;
Salvadoran National Association of Educators (ANDES)
Member of: Central American Common Market, IADB, IAEA, OAS, ODECA, Seabeds
Committee, U.N.','1424a8608145198b46b6783d828a6786a827b4ade8555718e4abf743221de6ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3039f7ba31c99652426e7485828ff316f560fff50541c9148feb8335b1692126',1973,'GQ','Equatorial Guinea','government',74,'Legal name: Republic of Equatorial Guinea
Type: republic, one-party presidential regime since 1968
Capital: Santa Isabel, Fernando Po
Political subdivisions: 2 provinces (Fernando Po and Rio Muni)
Branches: the president assumed all power in May 1971, suspending the
constitution and legislative and judicial branches of government
Government leader: President Francisco Macias Nguema
Suffrage: universal age 21 and over
Elections: national and provincial elections held September 1968
Political parties and leaders: National Unity Party of Workers (PUNT) is the sole
legal party, led by President Macias
Communists: no significant number of Communists or sympathizers
Member of: Conference of East and Central African States, ECA, IBRD, IMF, OAU, U.N.
Legal name: Empire of Ethiopia
Type: constitutional monarchy, but in effect an absolute monarchy
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred to as governorates~general)
Legal system: complex structure with civil, Islamic, common and customary law
influences; constitution adopted 1955; no specific constitutional provision
for review by courts but all legislation inconsistent with the constitution
4s declared null and void; legal education at Haile Selassie I University;
has not accepted compulsory ICJ jurisdiction
Branches: Emperor is all-powerful, with advisory cabinet and Prime Minister;
legislature composed of elected Chamber of Deputies and appointed Senate;
judiciary at higher levels based on Western pattern, at lower levels on
traditional pattern, without jury system in either
Government leader: Emperor Haile Selassie I
Suffrage: universal over age 21
Elections: lower house of Parliament election in 1973
Political parties and leaders: only amorphous reform groups especially among
younger, better educated Ethiopians
Communists: none
Member of: ECA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UPU,
WHO, WMO','ec33379a545d2cbf691779c611186a103af78f596394eac6c68971fac6de5911','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc3569388707035c2c2474017d669b5af6204c678908d1c853b438e80c50e94d',1973,'FR','France','government',77,'Legal name: The Faeroe Islands
Type: self-governing province within the Kingdom of Denmark; 2 representatives
in Danish parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, 1 town
Legal system: based on Danish law; Home Rule Act enacted 1948
Branches: legislative authority rests jointly with Crown, acting through appointed
High Comnissioner, and provincial parliament (Lagting) in matters of strictly
Faeroese concern; executive power vested in Crown, acting through High
Commissioner, but exercised by provincial cabinet responsible to provincial
parliament
Government leaders: Queen Margrethe II; Prime Minister, Atli Dam
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years; next election 1974
Political parties and leaders: Peoples, Hakun Djurhuus; Republican, Erlendur
Patursson; Home Rule, Samuel Petersen; Progressive, Kjartan Mohr; Social
Democratic, Atli Dam; Union, Kristian Djurhuus
Voting strength (1970 election): Peoples 20.0%, Republican 20.0%, Home Rule
5.6%, Progressive 3.5%, Social Democratic 27.2%, Union 21.7%
Communists: insignificant number
Member of: Nordic Council
Legal name: French Republic
Type: republic, with president having wide powers
Capital: Paris
Political subdivisions: 95 departments, 21 regional economic districts
Legal system: civil law system with indigenous concepts; new constitution
adopted 1958, amended concerning election of President in 1962; judicial
review of administrative but not legislative acts; Tegal education at over
25 schools of law; accepts compulsory ICJ jurisdiction, with reservations
Branches: presidentially appointed Prime Minister heads Council of Ministers,
which is formally responsible to National Assembly; bicameral legislature
~~ National: Assembly (490 members), Senate (283 members) restricted to a
delaying action; judiciary independent in principle
Government leader: President Georges Pompidou
Suffrage: universal over age 21; not compulsory
Elections: National Assembly -- every 5 years, last election June 1968, direct
universal suffrage, 2 ballots; Senate -- indirect collegiate system for 9
years, renewable by one-third every 3 years; President -- direct, universal
suffrage every 7 years, 2 ballots, last election June 1969
Political parties and leaders: Union of Democrats for the Republic (UDR), Alain
Peyrefitte; Independent Republicans, Valery Giscard d''Estaing; Communist (PCF),
Waldeck Rochet, George Marchais (acting); Progress and Modern Democracy (PDM),
Jacques Duhamel; Radical Socialists, Jean-Jacques Servan-Schreiber; Socialist
Party, Francois Mitterrand; Unified Socialist Party (PSU), Michel Rocard
Voting strength (first ballot, 1968 election): 43.6% UDR, 20% PCF, 16.5%
Federation of Democratic and Socialist Left (grouping of parties of left),
10.3% Center, 9.6% other
Communists: 250,000-300,000 (est.); Communist voters, 5 million average
Other political or pressure groups: Conmunist-controlled labor union
(Confederation Generale du Travail) nearly 1,000,000 members (est.),
National Council of French Employers (Conseil National de Patronat
Francais -- CNPF or Patronat)
Member of: Council of Europe, EC, FAQ, TAEA, IBRD, ICAO, IHB, ILO, IMCO, IMF, ITU,
NATO (signatory), OECD, Seabeds Committee, SEATO, South Pacific Commission,
U.N., UNESCO, UPU, WEU, WHO, WMO
Approved For Release 2004/09/15 : C+A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Legal name: Overseas Department of French Guiana
Type: overseas department of France; represented by one deputy in French National
Assembly and one senator in French Senate
Capital: Cayenne
Political subdivisions: 2 arrondissements, 19 communes each with a locally elected
municipal counci]
Legal system: French legal system; highest court is Court of Appeal based in
Martinique with jurisdiction over Martinique, Guadeloupe, and French Guiana
Branches: executive: prefect appointed by Paris; legislative: popularly elected
16-member General Council; judicial, under jurisdiction of French judicial
system
Government leader: Prefect, Jean Monfraix
Suffrage: universal over age 2]
Elections: General Council elections coincide with those for the French National
Assembly, normally every 5 years; last election March 1970
Political parties and leaders: Parti Socialiste Guyanais (PSG), Leopold Heder,
Senator; Union du Peuple Guyanaise (UPG), weak, leftist allied with, but
also reported to have been absorbed by, the PSG; Union of Democrats for the
Republic (UDR), Hector Rivierez, delegate to French National Assembly
Communists: no organized Communist party; UPG includes Communist sympathizers
but has little measurable following
Legal name: Overseas Territory of Afars and Issas
Type: overseas territory of France; represented by one deputy in French National
Assembly and by one senator in French Senate
Capital: Djibouti
Legal system: based on French civil law system, traditional practices and
Islamic law
be Branches: President of Council of Government; 8-member Council of Government
appointed by 32-member Chamber of Deputies; ultimate political authority
exercised by Paris-appointed President of the Council of Government, some-
times referred to as Prime Minister
Government leader: Ali Aref Bourhan
» Suffrage: universal
Elections: Chamber of Deputies election held November 1968, next election
scheduled for March 1973
Political parties and leaders: Rassemblement Democratique Afar, Ali Aref Bourhan;
Union Democratique Afar, Mohamed Kamil; Union Populaire Africaine; Union
Democratique Issa, Oman Farah Iitireh; African People''s League, Hassan Gouled
Communists: possibly a few sympathizers
Legal name: Gabonese Republic
Type: republic; one-party presidential regime since 1964
Capital: Libreville
Political subdivisions: 9 regions, 6 communes, 4,500 villages
Legal system: based on French civil law system and customary law; constitution
adopted 1961; judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; legal education at Centre of Higher and Legal Studies
at Libreville; compulsory ICJ jurisdiction not accepted
Branches: power centralized in President, elected by universal suffrage for
7-year term; unicameral 47-member National Assembly has limited powers;
judiciary
Government leaders: President Albert-Bernard Bongo
Suffrage: universal over age 21
Elections: Presidential and parliamentary elections last held March 1967
Political parties and leaders: Gabonese Democratic Party (PDG) led by President
Bongo is only legal party
Communists: no organized party; probably some Communist sympathizers
Member of: ADB, EAMA, Conference of East and Central African States, FAO,
TAEA, IBRD, ICAO, ILO, IMF, ITU, La Francophonie, OAU, OCAM, UDEAC, U.N..
UNESCO, UPU, WHO, WMO
Legal name: Republic of The Gambia
Type: republic; independent since February 1965
Capital: Bathurst
* Political subdivisions: Bathurst and 4 divisions
Legal system: based on English common law and customary law; constitution came
into force upon independence in 1965, new republican constitution adopted in
April 1970; accepts compulsory ICJ jurisdiction, with reservations
Branches: cabinet of 8 members (6 ministers, Attorney General, Vice President) ;
> 4l-member House of Representatives, in which 4 seats are reserved for chiefs,
3 are appointed, 32 are filled by election for 5-year terms, a Speaker js
elected by the House, and the Attorney General is an ex officio member 3
independent judiciary
Government leader: Dawda K. Jawara, President
Political parties and leaders: People''s Progressive Party (PPP), Secretary
General Dawda K. Jawara and United Party (UP), P.S. N''die
Elections: general elections held March 1972; PPP won 28 seats, UP won 3, and one
independent elected
Communists: insignificant number
Member of: Commonwealth, ECA, OAU, U.N.
Legal name: German Democratic Republic
Type: Communist state
Capital: East Berlin (not officially recognized by U.S., U.K., and France, which
together with the U.S.S.R. have special rights and responsibilities in Berlin)
Political subdivisions: (excluding East Berlin) 14 districts (Bezirke), 217
counties (Kreise), 8,867 communities (Gemeinden)
Legal system: Civil law system modified by Communist legal theory; new constitution
adopted 1968 by approx. 95% of the voters in national “referendum;" court
system parallels administrative divisions; no judicial review of legislative
acts; legal education at Universities of Berlin, Leipzig, Halle and Jena;
has not accepted compulsory ICJ jurisdiction; more stringent penal code
adopted 1968
Branches: legislative -- Volkskammer (elected directly); executive -- Chairman
of Council of State, Chairman of Council of Ministers, Cabinet (elected by
Volkskammer); judiciary -- Supreme Court; entire structure dominated by
Socialist Unity (Communist) Party
Government leaders: Chairman, Council of State, Walter Ulbricht (Head of State);
Chairman, Council of Ministers, Willi Stoph (Head of Government)
Suffrage: all citizens age 18 and over
Elections: national and local alternating every 2 years; prepared by an electoral
commission of the National Front; ballot supposed to be secret and voters
permitted to strike names off ballot; more candidates than offices available;
parliamentary elections held 14 November 1971; local elections, 22 March 1970
Political parties and leaders: Socialist Unity (Communist) Party (SED), headed
by First Secretary Erich Honecker, dominates the regime; 4 token parties
(Christian Democratic Union, National Democratic Party, Liberal Democratic
Party, and Democratic Peasants'' Party) and an amalgam of special interest
organizations participate with the SED in National Front
Voting strength: 1971 parliamentary elections: 98.33% voted the regime slate; 1970
local elections: 99.85% voted the regime slate
Communists: 1.9 million party members
Other special interest groups: Free German Youth, Free German Trade Union
Federation, Democratic Women''s Federation of Germany, German Cultural
Federation (all Communist dominated)
Member of: CEMA, IPU, Warsaw Pact
Approved For Release 2004/09/15 ] @A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','168ccd59da4eb8ee852a36479de8e51075317dd45992079106b709feaeb207ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a211a5860d8d6b40285fa24d45192f33f61bc066a67786d1146c8c8b1a9ef662',1973,'FJ','Fiji','government',81,'* Legal name: Fiji
Type: independent state since 1970
Capital: Suva
Political subdivisions: 14 provinces
Legal system: based on British
Branches: executive -- Prime Minister; legislative -- 52-member House of
Representatives; Alliance Party 33 seats, National Federation Party 19 seats
Government leader: Prime Minister Ratu Sir Kamisese Mara
Suffrage: universal adult
Elections: every 5 years unless House dissolves earlier
Political parties: Alliance, primarily Fijian, headed by Ratu Mara; National
Federation, primarily Indian, headed by S. M. Koya
Communists: few, no figures available
Member of: Commonwealth, U.N.
Legal name: Republic of Finland
Type: republic
Capital: Helsinki
Political subdivisions: 12 provinces; 443 communes, 78 towns
Legal system: civil law system based on Swedish law; constitution adopted 1919;
Supreme Court may request legislation interpreting or modifying laws; legal
education at Universities of Helsinki and Turku; accepts compulsory ICJ
jurisdiction, with reservations
Branches: legislative authority rests jointly with President and parliament
(Eduskunta) ; executive power vested in President and exercised through
cabinet responsible to parliament; Supreme Court, 4 superior courts,
193 Tower courts
Government leader: President Urho K. Kekkonen; Prime Minister Kalevi Sorsa
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1976); presidential, every
6 years (next in 1974)
Political parties and leaders: Social Democratic, Rafael Paasio; Center,
Johannes Virolainen; Peoples Democratic League (Communist front), Ele
Alenius; Conservative, Harri Holker; Liberal, Pekka Tarjanne; Swedish Peoples,
Jan-Magnus Jansson; Rural, Veikko Vennamo; Social Democratic League,
Uuno Nokelainen; Communist, Aarne Saarinen
Voting strength (1972 election): 25.8% Social Democratic, 17.5% Conservative,
17.1% People''s Democratic League, 16.5% Center, 9.2% Rural, 5.3% Swedish
Peoples, 5.1% Liberals, 2.5% Christian Peoples, 1.0% other
Communists: 47,000; an additional 65,000 persons belong to Peoples
Democratic League; a further number of sympathizers, as indicated by
421,000 votes cast for Peoples Democratic League in 1970 elections
Member of: EC (draft free trade agreement) EFTA (associate), FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, Nordic Council, OECD, Seabeds
Committee (observer), U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2004/09/15 : @fA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','3f187e7480adde406f9cf7fda0400c61e4a645d461ce07e3b547aa723ea13620','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2e07af6edc9bbaaf921f8d07680d83c3466c66699fa5b91fbb1d4610ba91931',1973,'GH','Ghana','government',86,'Legal name: Republic of Ghana
Type: republic; independent since March 1957
Capital: Accra
Political subdivisions: 8 administrative regions and separate Greater Accra
Area; regions subdivided into 47 districts
Legal system: based on English common law and customary law; legal education at
University of Ghana (Legon); has not accepted compulsory ICJ jurisdiction
Branches: executive authority vested in National Redemption Council (NRC);
independent judiciary
Government leaders: chief of state, chairman of NRC Colonel I.K. Acheampong
Suffrage: universal over 21
Elections: no elections since 1969; none scheduled
Political parties and leaders: parties banned by military junta which took
power 13 January 1972
Communists: a small number of Communists and sympathizers
Member of: ADB, Commonwealth, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU,
OAU, U.N., UNESCO, UPU, WHO, WMO','ec9bcb811b1bf07b8442ae26d05b8f331c2277626721001b256944e65fe22899','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('903eb1aadfbddc56c749b077192b20a7d37a13ce15dc200cdf8fe22d0380611a',1973,'GI','Gibraltar','government',89,'Legal name: Colony of Gibraltar
Type: U.K. colony
Capital: none
Legal system: English law; constitutional talks in July 1968; new system
effected in 1969 after electoral enquiry
Branches: parliamentary system comprised of the Gibraltar House of the Assembly
(15 elected members and 3 ex officio members), the Council of Ministers
headed by the Chief Minister, and the Gibraltar Council; the Governor is
appointed by the Crown
Government leaders: Governor and Commander in Chief, Adm. of the Fleet Sir
Varyl Begg; Chief Minister, Maj. Robert Peliza; Deputy Chief Minister,
Peter Isola
Suffrage: all adult Gibraltarians, plus other U.K. subjects resident 6 months
or more
Elections: every 5 years; last held in July 1969
Political parties and leaders: Association for Advancement of Civil Rights
(AACR), Sir Joshua Hassan; Labor, Sir Joshua Hassan; Independents, Peter
Isola; Integrationists (IWBP), Maj. Robert Peliza
Voting strength: In 1969, the AACR won 7 seats in the Assembly, the IWBP won 5,
the Independents won 3; a coalition between the latter two parties was formed
Communists: none known
Other political or pressure groups: the Housewives Association; the Chamber
of Commerce
Legal name: Kingdom of Greece
Type: constitutional monarchy; power in hands of ex-military leaders since
April 1967
Capital: Athens
Political subdivisions: 52 departments (nomoi) constitute basic political units;
as a result of decentralization measures promulgated August 1971, these nomoi
have now been grouped into seven geographical areas which are called Regional
Administrations, each of which is headed by an Undersecretary of Interior
(Regional Administrator); while each nomos ultimately reports to and is
\\ administered by the central government, the attempt of the decentralization
program is for each nomos and Regional Administration to administer its own
programs and to solve its own problems on a local basis to the greatest degree
possible
Legal system: based on Roman and Byzantine law, substantially altered by civil
codes of 1946-51; martial law decreed in April 1967 remains in force in urban
centers of Athens and Thessaloniki; legal training at University of Athens;
does not accept compulsory ICJ jurisdiction
Branches: new constitution promulgated in November, 1968, however, with key
articles concerning Parliament and powers of the courts still suspended;
certain articles of 1968 constitution pertaining to individual rights, also
suspended, were declared implemented in 1969 and 1970, but in practice
repression of these rights continues; legislative power is currently
exercised through decrees issued in the name of the King by the Regent as
enacted by the Council of Ministers; since early 1971, an Advisory Committee
on Legislation has functioned with the authority to draw attention to the
Pa need for new legislation or comment on legislation proposed by the Government;
the committee''s opinions and suggestions are not binding on the government
Government leaders: King Constantine, head of state (in exile); actual authority
lies in hands of ex-military headed by George Papadopoulos, who holds the
offices of Regent, Prime Minister, Minister of Programming and Government
Policy, Minister of Foreign Affairs and Minister of National Defense; Stylianos
Pattakos, First Deputy Prime Minister; and Nikolaos Makarezos, Second Deputy
Prime Minister
Suffrage: universal age 21 and over
Approved For Release 2004/09/15 : clA2RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GOVERNMENT (cont''d):
Elections: subject to scheduling of government
Political parties and leaders: political activities suppressed; party leadership
and organization in disarray
Communists: 12% of electorate in February 1964; hard-core elements imprisoned;
Communist Party (KKE} outlawed since 1947
Member of: EC (associate member), FAO, FUND, IAEA, IBRD, ICAO, IDA, IFC, IHB
ILO, IMCO, ITU, NATO, OECD, U.N., UNESCO, UPU, WHO, WMO
>','abb380b21cccc83065b9df2f46bc54db9e8070b45de37ddf4719a3eaa1d75cde','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0b1a42421cafa66e4d6e2e3f07a193e51c015864f736f0374699d185b98ef04',1973,'GL','Greenland','government',94,'Legal name: Greenland
Type: province of Kingdom of Denmark; 2 representatives in Danish parliament;
separate Minister for Greenland in the Danish cabinet
Capital: Godthaab (administrative center)
Political subdivisions: 3 counties, 19 communes
Legal system: Danish law; transformed from colony to province in 1953
Branches: legislative authority rests jointly with Crown and Danish parliament;
executive power vested in Crown, acting through provincial governor
responsible to Minister for Greenland; local affairs handled by provincial
council (Landsrad) subject to approval of provincial governor; 19 lower courts
Government leader: Queen Margrethe II; Governor N.0. Christensen
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years (next 1975)
Political parties: Inuit (advocating close ties with Denmark); Sukaq (moderate
socialist, advocating more distinct Greenland identity)','2db56e7570d7d9bed692335062078a1e4ab3898b7ec1445a72eb83b4fa100dab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9642e61d0af7fcdd44e20fdf3bd657f7378064423e4ac764b94b3a685f3a05da',1973,'GY','Guyana','government',98,'Legal name: Cooperative Republic of Guyana
Type: republic within Commonwealth
Capital: Georgetown
Political subdivisions: 9 administrative districts
Legal system: based on English common law with certain admixtures of Roman-
Dutch law; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers presided over by Prime Minister; 53-member
unicameral legislative National Assembly (elected); Supreme Court
Government leader: Prime Minister L.F.S. Burnham
Suffrage: universal over age 21
Elections: last held in December 1968; next elections 1973
Political parties and leaders: People''s Progressive Party (PPP), Cheddi Jagan;
People''s National Congress (PNC), L.F.S. Burnham; United Force (UF),
Feilden Singh
Voting strength (1968 election): 36.5% PPP, 55.8% PNC, 7.4% UF, 0.3% other
Communists: unknown; top echelons of PPP and PYO (Progressive Youth Organization,
militant wing of the PPP) include many Communists, but rank and file is
non-Communist
Other political or pressure groups: Justice Party, Guyana United Muslim Party,
Guyana All-Indian League, African Society for Cultural Relations with
Independent Africa (ASCRIA), Progressive Youth Organization (PPP affiliate),
Young Socialist Movement (PNC affiliate), Guyana United Youth Society (UF
affiliate), Afro-Asian-American Association (AAAA), Committee for National
Reconstruction, Guyana National Party (GNP)
Member of: CARIFTA, FAO, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAS (observer),
Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO','498544aa881671b52a016b0587523b781f347d4d48ea0e71d99b852059b1ae19','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cac54c24c922b616439a145c0119ddba65353037163294abb074e365ebd0b671',1973,'HT','Haiti','government',102,'Legal name: Republic of Haiti
Type: republic under the 14-year dictatorship of Francois Duvalier who was
succeeded upon his death on 21 April 1971 by his constitutional successor,
his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: 5 departments (despite constitutional provision for 9)
Legal system: based on Roman civil law system; constitution adopted 1964 and
amended 1971; legal education at State University in Port-au-Prince and private
Taw colleges in Cap-Haitien, Les Cayes, Gonaives, and Jeremie; accepts
compulsory ICJ jurisdiction
Branches: lifetime President, unicameral 58-member legislature of very limited
powers, judiciary appointed by President
Government leader: President-for-life Jean-Claude Duvalier
Suffrage: universal over age 18
Election: constitution as amended in 1971 provides for lifetime president to be
designated by his predecessor and ratified by electorate in plebiscite; next
legislative elections, which are held every 6 years, are scheduled for 1973
Political parties: National Unity Party, only legal party; United Haitian
Communist Party (PUCH), illegal (Communist)
Voting strength (1967 legislative elections): 100% National Unity Party
(Duvalier)
Communists: strength unknown; party leaders believed in exile
Member of: GATT, IADB, IAEA, ICAO, IMF, IBRD, OAS, U.N.
Legal name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Political subdivisions: 18 departments
Legal system: based on Roman and Spanish civil law; some influence of English
common law; constitution adopted 1965; judicial review of legislative acts
in Supreme Court; legal education at University of Honduras in Tegucigalpa;
accepts compulsory ICJ jurisdiction, with reservations
Branches: constitution provides for elected President, unicameral legislature,
and national judicial branch
Government leader: President Ramon Ernesto Cruz
Suffrage: universal and compulsory over age 18
Elections: May 1971, Nationalist Party candidate won election; next
election February 1977; municipal elections March 1974
Political parties and leaders: Liberal Party (PLH), Carlos Roberto Reina, Felipe
Elvir Rojas, Jorge Bueso Arias, Modesto Rodas Alvarado, and Max Velasquez,
President of Central Executive Council; Nationalist Party (PNH), Ramon
Ernesto Cruz, Ricardo Zuniga Augustinus, General Oswaldo Lopez Arellano,
Mario Rivera Lopez, Martin Aquero, Manuel Acosta Bonilla; Popular Progressive
Party (PPP-uninscribed), Gonzalo Carias Castillo; Orthodox Republican Party
(PRO-uninscribed), Roque Jacinto Rivera; Communist Party of Honduras/Soviet
(PCH/S-outlawed) , Dionisio Ramos Bejarano, Communist Party of Honduras/China
(PCH/C-outlawed) , leadership uncertain; National Inovation and Unity Party
(PINU) (uninscribed), Miguel Andonie Fernandez
Voting strength (1971 elections): Nationalist Party (PNH) 306,028; Liberal
Party (PLH) 276,777
Communists: 400-800; 2,000 sympathizers
Member of: IADB, ICAO, ILO, OAS, CACM, U.N.
Legal name: Colony of Hong Kong
Capital: Victoria
Type: U.K. crown colony
Political subdivisions: Hong Kong, Kowloon, and New Territories
Legal system: English common law
Branches: Governor assisted by advisory Executive Council; he legislates with
advice and consent of Legislative Council; Urban Council which alone includes
elected representatives, responsible for health, recreation, and resettlement;
New Territories divided into 4 districts, each presided over by a District
Officer advised by a locally elected Rural Committee; independent judiciary
Government leader: C.M. MacLehose, Governor and Commander in Chief
Suffrage: limited to 200,000 to 300,000 professional or skilled persons
Elections: every 2 years to select one-half of elected membership of Urban
Council; other Urban Council members appointed by the Governor
Political parties and leaders: Civic Association, Hu Pai-fu; Reform Club, B. A.
Bernacchi; Socialist Democratic Party, Sun Po-kong; Hong Kong Labour Party,
Tang Hon-tsai
Voting strength: (elected Urban Council members) Civic Association 4, Reform
Club 3, and 1 independent
Communists: an estimated 2,000 hard core cadres affiliated with Communist Party
of China
Other political or pressure groups: Federation of Trade Unions (Communist
controlled), Hong Kong and Kowloon Trade Union Council (Nationalist Chinese
dominated), Hong Kong General Chamber of Commerce, Chinese General Chamber
of Commerce (Communist controlled), Federation of Hong Kong Industries,
Chinese Manufacturers'' Association of Hong Kong','c2ff74b4b88187a25a5ca02d54f08bc8a47751e1dbaad24bb6c9ed4be3a98bc3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d288e1d4a73e9ba511b4222e3db6de6552b579b6684b2076796e641a18b1d231',1973,'HU','Hungary','government',106,'Legal name: Hungarian People''s Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 Megyes (counties), 5 autonomous cities in county
Status, 113 Jaras (districts)
Legal system: based on Communist legal theory, with both civil law system (civil
code of 1960) and common law elements; constitution adopted 1949; Supreme
Court renders decisions of principle that sometimes have the effect of
declaring legislative acts unconstitutional; legal education at Eotvos
Lorand Tudomanyegyetem School of Law in Budapest and 2 other schools of law;
has not accepted compulsory ICJ jurisdiction
Branches: executive -- Presidential Council (elected by Parliament); legislative
-- Parliament (elected by direct suffrage); judicial -- Supreme Court
(elected by Parl jament)
Government leaders: Jeno Fock, Chairman, Council of Ministers; Pal Losonczi,
President, Presidential Council
Suffrage: universal over age 18
Elections: every 4 years; national and local elections are held separately, two
years apart
Political parties and leaders: Hungarian Socialist (Communist) Workers! Party
(sole party); Janos Kadar is First Secretary of Central Committee
Voting strength (1971 election): 7,260,856 (98%) for Communist-approved candidates;
76,725 (1.4%) invalid and negative votes; total eligible electorate about
7.3 million
Communists: about 693,000 party members (June 1971)
Member of: CEMA, FAO, IAEA, ICAO, ILO, ITU, UNESCO, U.N., UPU, Warsaw Pact, WHO','554b36ea2634e7995d281b8daf4ce93278548f129caf70493fcf744e5d525e7d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2292c0967d7f6981c77feb0219efda97a5fee8997179dd42576ad1424f7b1ac',1973,'IS','Iceland','government',110,'Legal name: Republic of Iceland
Type: republic
Capital: Reykjavik
Political subdivisions: 16 districts, 212 rural communes, 14 towns
Legal system: civil law system based on Danish law; constitution adopted 1944;
legal education at University of Iceland; does not accept compulsory
ICJ jurisdiction
Branches: legislative authority rests jointly with President and parliament
(Althing); executive power vested in President but exercised by cabinet
responsible to parliament; Supreme Court and 29 lower courts
Government leaders: President Kristjan Eldjarn; Prime Minister Olafur Johannesson
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1975); presidential, every
4 years (next in 1976)
Political parties and leaders: Independence (conservative), Johann Hafstein;
Progressive, Olafur Johannesson; Social Democratic, Gylfi Gislason; Labor
Alliance (Communist front), Ragnar Arnalds; Organization of Liberals and
Leftists, Hannibal Valdimarsson
Voting strength (1971 election): 36.2% Independence, 25.2% Progressive, 10.4%
ae Democratic, 17.1% Labor Alliance, organization of leftists and liberals
8.9%
Communists: 1,000; a number of sympathizers, as indicated by 18,055 votes cast
for Labor Alliance in 1971 election
Member of: Council of Europe, EC (free trade agreement effective 1 March 1973),
EFTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO,
Nordic Council, OECD, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of India
Type: federal republic
Capital: New Dethi
Political subdivisions: 21 states, 9 union territories, 1 protectorate (Sikkim)
Legal system: based on English common law; constitution adopted 1950; judicial
review of legislative acts; accepts compulsory ICJ jurisdiction, with
reservations
Branches: parliamentary government, national and state; independent judiciary
Government leader: Prime Minister Indira Gandhi
Suffrage: universal over age 21
Elections: national and state elections ordinarily held every 5 years; may be
postponed in emergency and may be held more frequently if government loses
confidence vote; next general election to be held by March 1976; 16 states
and two union territories held state elections in March 1972; remaining states
to be polled over next several years
Political parties and leaders: Indian National Congress split into two factions
in 1969, largest faction (the Ruling Congress) loyal to Prime Minister Gandhi
led by S.D. Sharma, and smaller faction (the Organization Congress) led by
Sadiq Ali; Communist Party of India (CPI), S. A. Dange, chairman; Communist
Party of India/Marxist (CPI/M), P. Sundarayya, general secretary; Communist
Party of India/Marxist-Leninist (CPI/ML), Chairman unknown; Swatantra,
M. Masani, president; Bharatiya Jana Sangh, A. B. Vajpayee, president; The
Socialist Party, Kappori Thakur, chairman; Dravida Munnetra Kazhagam (DMK),
N. Karunanidhi, president
Approved For Release 2004/09/15 : CIA9RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GOVERNMENT (cont''d):
Voting strength (1971 election): 43.7% Ruling Congress, 10.5% Organization Congress,
7.4% Bharatiya Jana Sangh, 3.1% Swatantra, 4.8% CPI, 5.2% CPI/M, 3.5% Socialist
Parties, 3.7% DMK, 18.1% other
Communists: 70,000 members of CPI (est.), 70,000 members of CPI/M;
Communist sympathizers, 13 million
Member of: ADB, Colombo Plan, Commonwealth, FAO, IAEA, ICAO, IDA, IFC, IHB, ILO,
IMCO, IMF, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','f1fa1200b4491cb1efa489641fdfab88a7d697efbe1743506ccdb1157ac774ca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62b6434c41fc43ac6e33baa32615950dbfa2140e2a60f0b11ea45fea8108ea4b',1973,'ID','Indonesia','government',113,'Legal name: Republic of Indonesia
Type: republic
Capital: Djakarta
Political subdivisions: 26 first-level administrative subdivisions or provinces
which are further subdivided into 281 second-level areas
Legal system: based on Roman-Dutch law, substantially modified by indigenous
concepts; constitution of 1945 is legal basis of government; legal education
at University of Indonesia, Djakarta; has not accepted compulsory ICd
jurisdiction
Branches: executive headed by President who is chief of state and head of
cabinet (president Suharto is concurrently Minister of Defense and Security);
cabinet selected by President; unicameral legislature (Parliament), of 460
members (100 appointed, 360 elected); second and larger body (Congress) of
920 members and includes the legislature and 460 other members (chosen by
several processes, but not directly elected) elects President and Vice
President, and theoretically determines national policy
Government leader: President Suharto (elected by Congress March 1968)
Suffrage: universal over age 17 and married persons regardless of age
Political parties and leaders: Golkar (quasi-official “party” based on functional
groups), Amir Moertono (acting head); Indonesian National Party (PNI), Mohamad
Isnaeni (acting); Nahdlatul Ulama (NU), Idham Chalid; Indonesian Muslim
Party (PMI), Mintaredja
Voting strength (1971 election): Golkar 236 seats (62.8%), NU 58 seats (18.7%),
PNI 20 seats (6.9%), PMI 24 seats (5.4%), PSII 10 seats, Parkindo 7 seats,
Catholic 3 seats, Perti 2 seats
Communists: Communist Party (PKI) was officially banned in March 1966; current
strength est. at 1,000, with less than 10% engaged in organized activity;
pre-October 1965 hard core membership has been estimated at 1.5 million
Minor legal parties: Catholic Party, Christian Party, Islamic Unity Party (PSII),
Association of Supporters of Indonesian Independence (IPKI), Islamic Unity
Party (PERTI), Murba
Member of: ADB, ASEAN, FAO, IAEA, ICAO, IHB, ILO, IMF, U.N. (resumed membership
in September 1966 and is now active in U.N. affiliated organizations), UNESCO
Approved For Release 2004/09/15 : CIASRDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Legal name: Empire of Iran
Type: constitutional monarchy, actually controlled by the Shah
Capital: Tehran
Political subdivisions: 13 provinces and 6 independent governorates, subdivided
¢ into counties, municipalities, and rural districts
Legal system: based largely on Belgian Taw, with elements drawn from other
continental systems; personal law based on Islamic practice generally with
residual traces of Roman law; constitution adopted 1906 and constitutional
law of 1907; High Court of Appeal may judge disputes relating to government
rT departments acting according to law; legal education at University of Teheran;
has not accepted compulsory ICJ jurisdiction
Branches: executive power rests in Shah who appoints a Prime Minister; Prime
Minister must be approved by lower house (Majlis); while Cabinet theoretically
responsibility of Prime Minister, Shah usually exerts strong influence over
its selection; bicameral legislature; Majlis has 268 seats (with 2 vacant
for islands of the Persian Gulf) elected to 4-year terms, and Senate 60
members serving 4-year terms; half of Senate members appointed by Shah,
other half elected; no provision for judicial review of constitutional ity
of legislative acts
Government leaders: Shah Mohammad Reza Pahlavi and Prime Minister Amir
Abbas Hoveyda
Suffrage: universal over age 20
Elections: Majlis every 4 years; Senate every 4 years; latest national elections
July 1971, district and municipal elections in October 1972
Political parties and leaders: New Iran Party, Manuchehr Kalali; Mardom (Peoples)
Party, Alinagi Kani; Iranians Party, Dr. Fazlollah Sadr; Pan Iranist Party,
Mohsen Pezeshkpur (apparently moribund)
Voting strength (1971 election): Majlis -- New Iran Party, 231 seats; Mardom
Party, 36 seats; Iranians Party, 1 seat; Senate -- New Iran Party, 28 seats;
Mardom Party, 2 seats; plus 30 seats appointed by the Shah; all candidates
government approved
™ Communists: 1,000-2,000 (hard-core, est.); sympathizers (15,000-20,000 est.);
mostly pro-U.S.S.R. but pro-Chinese faction developing
Approved For Release 2004/09/15 : ClIA2RDP79-01051A000500010001-1
GOVERNMENT (conta For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Other political or pressure groups: Tudeh Party (Communist, illegal); National
Front (coalition of neutralist urban elements virtually discredited because
a aye to Shah''s reform program); Confederation of Iranian Students
illegal
Member of: CENTO, Colombo Plan, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO,
IMF, ITU, OPEC, RCD, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Iraq
Type: republic; one-party military regime established in July 1968
Capital: Baghdad
Political subdivisions: 16 provinces under centrally appointed officials
Legal system: based on Islamic law in special religious courts, civil law system
elsewhere; provisional constitution adopted in 1968; judicial review was
suspended; legal education at University of Baghdad; has not accepted
compulsory ICJ jurisdiction
Branches: "moderate" wing of Ba''th Party of Iraq has been in power since 1968 coup
Government leaders: President Hasan al-Bakr; Deputy Chairman of the Revolutionary
Command Council Saddam Tikriti
Suffrage: no elective bodies exist
Elections: none since overthrow of monarchy in 1958
Communists: Communist Party allowed token representation in cabinet
Political or pressure groups: political parties banned, major opposition to
regime is from leftwing of the Ba''th Party, Communist Party and Nasirist
groups, disaffected members of the regime and army officers
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OPEC,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law, substantially modified by indigenous
concepts; constitution adopted 1937; judicial review of legislative acts in
Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: elected President; bicameral parliament reflecting proportional and
vocational representation; judiciary appointed by President on advice of
Government leader: Taoiseach (Prime Minister) John (Jack) Lynch
Suffrage: universal over age 2]
Elections: Dail (lower house) elected every 5 years -- last election June 1969;
President elected for 7-year term
Political parties and leaders: Fianna Fail, John (Jack) Lynch; Labor Party,
Brendan Corish; Fine Gael, Liam Cosgrave; Communist Party of Ireland,
Michael O''Riordan
Voting strength: 70 seats Fianna Fail, 51 seats Fine Gael,
17 seats Labor Party, 1 Aontac Eireann, 5 independent
Communists: approximately 300
Member of: Council of Europe, EC, FAO, IBRD, ICAO, ILO, IMCO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution provides for establishment of 20 regions;
5 (Sicilia, Sardegna, Trentino-Alto Adige, Friuli-Venezia Giulia, and Valle
d''Aosta) have been functioning for some time and the remaining 15 regions
were unsuited on 1 April 1972; 94 provinces
Legal system: based on civil law system, with ecclesiastical law influence;
constitution came into effect 1 January 1948; judicial review of legislative
acts in Constitutional Court; has not accepted compulsory ICJ jurisdiction
Branches: executive -- President empowered to dissolve Parliament and call national
election; he is also Commander of the Armed Forces and presides over the
Supreme Defense Council; otherwise, authority to govern invested in Council
of Ministers; legislative power invested in bicameral, popularly elected
Parliament; Italy has an independent judicial establishment
Government leaders: President Giovanni Leone; Premier Giulio Andreotti
Suffrage: universal over age 21 (except in Senatorial elections where minimum
age of voter is 25)
Elections: national elections for Parliament held every 5 years (most recent,
May 1972); provincial and municipal elections held every 5 years with some
out of phase; regional elections every 5 years
Political parties and leaders: Christian Democratic Party (DC), Arnaldo Forlani
(party secretary) Giulio Andreotti Aldo Moro, Amintore Fanfani (Senate
President); Communist Party (PCI), Luigi Longo, Enrico Berlinguer; Italian
Socialist Party (PSI), Pietro Nenni (ex-party secretary), Giacomo Mancini,
Francesco De Martino; Italian Social Democratic Party (PSDI), Flavio Orzandi
Liberal Party (PLI), Giovanni Malagodi; Italian Social Movement (MSI),
Giorgio Almirante; Republican Party (PRI), Ugo La Malfa
Voting strength (1972 election): 38.8% DC, 27.2% PCI, 9.6% PSI, 3.9% PLI, 8.7%
MST, 2.9% PRI, 5.1% PSDI, 3.8% other
Approved For Release 2004/09/15 : Cl®RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GOVERNMENT (cont''d):
Communists: 1,521,000 members; number of sympathizers cannot be determined
Other political or pressure groups: the Vatican; three major trade union
confederations (CGIL -- Communist dominated, CISL -- Christian Democratic,
and UIL -- Social Democratic and Republican); Italian manufacturers
association (Confindustria); organized farm groups
Member of: ECSC, EC, FAO, IBRD, ICAO, IAEA, IHB, ILO, IMCO, IMF, ITU, NATO,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Ivory Coast
Type: republic, one-party presidential regime
Capital: Abidjan
Political subdivisions: 24 departments subdivided into 127 subprefectures
Legal system: based on French civil law system and customary law; constitution
adopted 1960, amended 1963; judicial review in the Constitutional Chamber
of the Supreme Court; legal education at Abidjan School of Law; has not
accepted compulsory ICJ jurisdiction
Branches: President has sweeping powers, unicameral legislature, separate
judiciary
Government leader: President Felix Houphouet-Boigny
Suffrage: universal over age 21
Elections: uncontested Presidential and legislative elections held in November
1970 for 5-year term
Political parties and leaders: Parti Democratique de la Cote d''Ivoire (PDCI),
(only party); official party leader is Secretary General Philippe Yace, but
Houphouet-Boigny is in control
Communists: no Communist partyp; possibly some sympathizers
Member of: ADB, EAMA, ECA, Entente, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU,
La Francophonie, Niger River Commission, OAU, OCAM, U.N., UNESCO, UPU, WHO,
WMO','8af59ae0e426236ec08b92ce3444416a97b866234e8e5439c367f3e00a7982a9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f660548acbb8f010486889affbf77d79a2d6fcfa2b2bd4520a4bd35c0173bd0e',1973,'JM','Jamaica','government',119,'Legal name: Jamaica
Type: independent state within Commonwealth since August 1962, recognizing
Elizabeth II as head of state
Capital: Kingston
Political subdivisions: 12 parishes and the Kingston-St. Andrew corporate area
Legal system: based on English common law; has not accepted compulsory ICJ
jurisdiction
Branches: cabinet headed by Prime Minister; 53-member elected House of Represent-
atives; 2l-member Senate (13 nominated by the Prime Minister, 8 by opposition
leader); judiciary follows British tradition under a Chief Justice
Government leader: Prime Minister Michael Manley
Suffrage: universal, age 21 and over
Elections: at discretion of Governor-General upon advice of Prime Minister but
within 5 years; latest held 29 February 1972
Political parties and leaders: Jamaica Labor Party (JLP), Sir Alexander
Bustamante, Hugh Shearer; People''s National Party (PNP), Michael Manley
Voting strength (1972 general elections): 56.55% PNP, 43.21% JLP, 0.24% other
Communists: a few hundred Marxist and Communist sympathizers
Other political or pressure groups: New World Group (Caribbean regionalists,
nationalists, and leftist intellectual fraternity); Rastafarians (Negro
religious/racial cultists, pan-Africanists); New Creation International
Peacemakers Tabernacle (leftist group)
Member of: CARIFTA, FAQ, GATT, IAEA, IBRD, ICAQ, IFC, ILO, IMF, OAS, Pan
American Health Organization, Seabeds Committee (observer), U.N.','f058437c490a0d00cf0680d5d67306662001f512e41fb9a043f9671b00aba7e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1aa28745db1bfda5aa1b0273b04f3504f08ebaee9aa57d1acc87c04a7c507a2',1973,'ET','Ethiopia','government',123,'Legal name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital: ''Amman
Political subdivisions: 8 districts (3 are under Israeli occupation) under
centrally appointed officials
Legal system: based on Islamic law and French codes; constitution adopted 1952;
judicial review of legislative acts in a specially provided High Tribunal;
has not accepted compulsory ICJ jurisdiction
Branches: executive branch holds balance of power; King is effective ruler with
Prime Minister exercising executive authority in name of King; Cabinet
appointed by King and responsible to parliament; bicameral parliament with
Chamber of Deputies chosen by national elections, Senate appointed by King;
each house contains equal representation from East and West Jordan; present
parliament subservient to executive as a result of rigged elections (April
1967); secular court system based on differing legal systems of the former
Transjordan and Palestine; law Western in concept and structure; Sharia
(religious) courts for Muslims, and religious community council courts for
non-Muslim communities; desert police carry out quasi-judicial functions
in desert areas
Government leader: King Husayn ibn Talal al-Hashimi
Suffrage: male citizens over age 20
Political parties and leaders: political party activity illegal since 1957;
Palestine Liberation Organization and Fatah, Yasir Arafat; various smaller
fedayeen groups; Ba''th Party of Jordan, Dr. Mun''if Razzaz; National
Socialist Party, Sulayman al-Nabulusi; Muslim Brethren
Approved For Release 2004/09/15 : cIAZADP79-01051A000500010001-1
I 2004/09/15 : CIA-RDP79-01051A000500010001-1
GOVERNMENT (cont Proved For Release
Communists: party actively repressed, active membership Jess than 100
Member of: Arab League, FAO, IAEA, IATA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPL, WHO, WMO
Legal name: Republic of Kenya
Type: republic within Commonwealth since December 1963
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi Area
Legal system: based on English common law, tribal law and Islamic law;
constitution enacted 1963; judicial review in Supreme Court; legal education
at University Kenya School of Law in Nairobi; accepts compulsory ICJ
jurisdiction, with reservations
Branches: President and Cabinet responsible to unicameral legislature (National
Assembly) of 170 seats, 158 directly elected by constituencies and 12
specially elected by the Assembly; Assembly must be reelected at least every
5 years; High Court, with Chief Justice and at least 11 justices, has
unlimited original jurisdiction to hear and determine any civil or criminal
proceedings provision for systems of courts of appeal with ultimate appeal
to East African Court of Appeals
Government leader: President Jomo Kenyatta
Suffrage: universal over age 21
Elections: general election (December 1969) elected present National Assembly
Political party and leaders: Kenyan African National Union (KANU), president,
Jomo Kenyatta
Voting strength: KANU holds all seats in the National Assembly
Communists: may be a few Communists and sympathizers
Member of: EAC, IAcA, ICAO, OAU, Seabeds Committee, U.N.
Legal name: Democratic People''s Republic of Korea
Type: Communist state; one-man rule
Capital: P''yongyang
Political subdivisions: 9 provinces, 3 special cities (P''yongyang, Hamhung,
Ch''ongjin), and 1 special district (Kaesong)
Legal system: based on German civil law system with Japanese influences and
Communist legal theory; constitution adopted 1948; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
Branches: a new constitution is to be announced in December 1972
Government and party leaders: Kim I1-song, Premier and General Secretary
of the Korean Labor Party
Suffrage: Universal at age 18
Elections: election to SPA every 4 years, but this constitutional provision not
necessarily followed -- election scheduled for December 1972
Political party: Korean Labor (Communist) Party; claimed membership of about
1.6 million, or about 12% of population
Member of: no international bodies
Legal name: Republic of Korea
Type: republic; power centralized in a strong executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities; heads centrally appointed
Legal system: combines elements of continental European civil Taw systems,
Anglo-American law, and Chinese classical thought; constitution approved
1972; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative (unicamerat), judiciary, National Conference
for Unification and Self-Reliance
Voting strength: National Assembly suspended, its functions temporarily assumed
Communists: Communist activity banned by government; an estimated 37 ,000-50,000
Former members and supporters
Other political or Pressure groups: Federation of Korean Trade Unions; Korean
Veterans ''! Association; large volatile student population concentrated in Seoul
INTELSAT, Inter-Parliamentary Union, INTERPOL, ITU, UNESCO, U.N. Special Fund,
UPU, WHO, WMO, World Anti-Conmunist League (WACL); does not hold U.N,
members hip
Approved For Release 2004/09/19 sSIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Legal name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Al Kuwayt
Political subdivisions: 3 governorates, 10 voting constituencies
Legal system: civil law system with Islamic law significant in personal matters;
constitution took effect 1963, judicial review of legislative acts not yet
determined; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers; National Assembly
Government leader: Amir Sabah Al Salim Al Sabah
Suffrage: native born and naturalized males over age 21
Elections: held every 4 years for National Assembly; last held January 1971
Communists: insignificant
Member of: Arab League, FAQ, FUND, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO, ITU,
OPEC, OAPEC, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Laos
Type: constitutional monarchy
Capital: Vientiane (Louangphrabang royal capital)
Political subdivisions: 16 provinces subdivided into districts, cantons, and
villages
Legal system: based on civil law system; constitution of 1947 superseded by
international agreements of 1962 and subsequent events; has not accepted
compulsory ICJ jurisdiction
Branches: King, 59-member National Assembly, 12-member King''s Council; provisional
coalition government formally composed of 3 "tendencies" -- neutralists,
Communists, rightists -- but Communists not participating
Government leaders: King Savang Vatthana; Premier Souvanna Phouma, neutralist;
Deputy Premier Prince Souphanouvong, Communist (absent); Deputy Premier
Leuam Insisiengmay, rightist.
Suffrage: universal over age 18
Elections: National Assembly designated by King; general election last held
January 1972
Political parties and leaders: Neo Lao Hak Sat, Communist-front organization
which includes the Lao People''s Party (Communist), only party active
Communists: Lao People''s Party (clandestine) membership unknown
Other political or pressure groups: Communists are resisting “neutralist"
government; insurgent Communist forces with North Vietnamese backing
pose serious threat to existing government; other political groups are
informal and associated with regional family and military leaders; Prince
Boun Oum is the acknowledged, though not formal leader of the Laotian
rightists; Royal Armed Forces (FAR) leaders, Commander in Chief Bounpone
Makthepharack, and Generals Kouprasith Abhay, Phasouk Somly, Vang Pao, Soutchay
Vongsavanh, and Ret. Gen. Ouan Rathikoun
Member of: Colombo Plan, ECAFE, ICAO, IMF, Mekong Committee, SEAMES, U.N., UNCTAD','424444be8ebb12ddc796d24ae875adb1514d65218d3be165fca15640b3702bb0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc50a93023e5394d27a95c80eb192c273c29152f4f7b58458ea5f350237414ba',1973,'LB','Lebanon','government',126,'Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law, and civil law system; consti-
tution mandated in 1920; no judicial review of legislative acts; legal
education at University of Lebanon; has not accepted compulsory ICJ
jurisdiction
Branches: power lies with President elected by parliament (Chamber of Deputies) ;
Cabinet appointed by President, approved by parliament; independent secular
courts on French pattern; religious courts for matters of marriage, divorce,
inheritance, etc.; by custom, President is a Maronite Christian, Prine
Minister a Sunni Muslim, and president of parliament a Shia Muslim; each of
9 religious communities represented in parliament in proportion to national
numerical strength
Government leader: President Sulayman Franjiyyah
Suffrage: compulsory for all males over 21; authorized for women over 21 with
elementary education
Elections: for Chamber of Deputies, held every 4 years or within 3 months of
dissolution of Chamber; held April 1972
Political parties and leaders: political party activity is organized along
sectarian lines; numerous political groupings exist, consisting of individual
political figures and followers motivated by religious, clan, and economic
considerations; political stability dependent on maintenance of balance
between religious communities
Communists: one of largest Communist parties in Middle East; legalized in 1970;
members and sympathizers estimated at 6,000
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
Approved For Release 2004/09/15 : ClA3RDP79-01051A000500010001-1
caloiy Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
E N (hi
Agriculture: fruits, wheat, corn, barley, potatoes, tobacco, olives, onions; not
self-sufficient in food
Major industries: service industries, food processing, textiles, cement, oi]
refining, chemicals, some metal fabricating, tourism
Electric power: 540,909 kw. capacity (1972); 1,378 million kw.-hr. produced
(1972), 472 kw.-hr. per capita
Major trade partners: exports $247 million (f.0.b., 1971); most to Arab
countries; imports $728 million (c.i.f., 1971); chiefly from EC, U.K.,
and Arab countries; trade deficit covered by large net receipts from
invisibles (particularly tourism and transportation) and private capital inflow
Monetary conversion rate: 1 Lebanese pound=US$0.29 as of March 1972
Fiscal year: calendar year
Legal name: Kingdom of Lesotho
Type: constitutional monarchy under King Moshoeshoe II
Capital: Maseru
Political subdivisions: 9 administrative districts
Legal system: based on English common law and Roman-Dutch law, constitution cane
into effect 1966; judicial review of legislative acts in High Court and
Court of Appeal; legal education at University of Botswana, Lesotho, and
Swaziland (located in Lesotho); has not accepted compulsory ICJ jurisdiction
Branches: executive, divided between a largely ceremonial King and a Prime
Minister who leads cabinet of at least 7 members; a bicameral legislature
consisting of a National Assembly (60 seats) and a Senate (33 seats);
judicial -- 63 Lesotho courts administer customary law for Africans, High
Court and subordinate courts have criminal jurisdiction over all residents,
Court of Appeal at Maseru has appellate jurisdiction
Government leader: Prime Minister Chief Leabua Jonathan
Suffrage: universal for adults
Elections: elections held in January 1970; nullified allegedly because of election
irregularities; subsequent elections promised at unspecified date
Political parties and leaders: Basutoland Congress Party (BCP), Ntsu Mokhele;
Marema-tlou Freedom Party (MFP), Edwin Leanya; National Party (BNP),
Chief Leabua Jonathan
Voting strength: National Assembly -- BNP 32 seats, BCP 22 seats, MFP 2 seats,
LDP 2 seats, 2 seats vacant; Senate -- BNP holds 24 of 33 seats (1965
elections)
Communists: Communist Party of Lesotho banned in early 1970
Member of: Commonwealth, FAQ, ILO, ITU, U.N., UNESCO, UPU, WHO
Legal name: Republic of Liberia
Type: republic; dominated by strong executive
Capital: Monrovia
Political subdivisions: country divided into 9 counties; President appoints all
officials of significance
Legal system: based on U.S. constitutional theory; recent codes drawn up by
Cornell University; constitution adopted 1847; amended 1907, 1926, 1934,
and 1955; no constitutional provision for judicial review of legislative
acts; legal education at Louis Arthur Grimes School of Law, University of
Liberia; accepts compulsory ICd jurisdiction, with reservations
Branches: President, elected by popular vote initially for 8-year term and
eligible for successive 4-year terms, controls through appointive powers and
authority over national expenditures; 2-house legislature elected by popular
vote; judiciary consisting of Supreme Court and variety of lower courts
Government leader: President William R. Tolbert
Suffrage: universal over age 21
Elections: members of House of Representatives elected for 4-year terms, most
recently in May 1971; Senate members elected for 6-year terms, one-half
elected in May 1971; President Tolbert, constitutional successor to President
Tubman who died in July 1971, is eligible to complete the four year term to
we Tubman was elected in May 1971; next scheduled presidential election May
Political parties and leaders: True Whig Party, in power since 1878, only
political party; President Tolbert is leader
Voting strength: 1971 elections uncontested; True Whig Party won all but a
handful of votes
Communists: no Communist Party and only a few sympathizers
Member of: ECA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, OAU, Seabeds Committee,
U.N., UNESCO, UPU, WHO
Approved For Release 2004/09/15 : CI8-RDP79-01051A000500010001-1
ECONOMY: Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GDP: $436.9 million (1971 est.), 5.0% current growth rate, $370 per capita
Agriculture: rubber, oi] palm, cassava, coffee, rice; imports of rice, wheat,
and meat are necessary for basic diet
Fishing: catch 18,500 metric tons, $6.1 million (1969)
Industry: rubber processing, food processing, construction materials, furniture,
palm oi] processing, mining (iron ore, diamonds), 10,000 b/d oi] refinery
Electric power: 152,000 kw. capacity (1971); 540 million kw.-hr. produced (1971),
470 kw.-hr. per capita
Exports: $222.8 million (f.o.b., 1971 est.); iron ore, diamonds, rubber, palm
kernels, coffee, cocoa
Imports: $148.6 million (c.i.f., 1971 est.); machinery, transportation equipment,
foodstuffs, manufactured goods
mar trade partners: U.S., West Germany, Japan, U.K.
id:
economic -- (FY46-71) U.S., $279.1 million;
military -- (FY53-71) U.S., $8.8 million; other aid sources include IBRD,
U.N., IMF, and West Germany
Monetary conversion rate: Liberia uses U.S. currency
Fiscal year: calendar year
Legal name: Libyan Arab Republic
Type: republic; under military control following ouster of king on 1 September
1969; provisional constitution promulgated December 1969; loosely confederated
with Egypt and Syria in Confederation of Arab Republics (CAR) on 1 September
1971; complete union with Egypt scheduled for 1 September 1973
Capital: Tripoli (defacto)
Political subdivisions: 10 administrative provinces closely controlled by
central government; district commissioners appointed by Revolutionary
Command Council
Legal system: based on Italian civil Taw system and Islamic law; separate
religious courts; no constitutional provision for judicial review of legislative
acts; legal education at Law School, at University of Libya at Banghazi; has
not accepted compulsory ICJ jurisdiction
Branches: paramount political power and authority rests with the Revolutionary
Command Council (RCC); cabinet of 12 ministers; Parliament has been dissolved
Government leaders: Revolutionary Command Council President Colonel Mu''ammar
Qadhafi
Elections: parliamentary elections last held in May 1965; election for CAR assembly
in March 1972
Political parties and leaders: Libyan Arab Socialist Union, RCC member Major Hawad;,
Secretary General
Communists: no organized party, negligible membership
Other political or pressure groups: various Arab nationalist movements and the
Arab Socialist Resurrection (Ba''th) Party with small, almost negligible
memberships may be functioning clandestinely
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
OPEC, OAPEC, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Principality of Liechtenstein
Type: hereditary constitutional monarchy
Capital: Vaduz
Political subdivisions: 11 districts
Legal system: based on Swiss law; constitution adopted 1921; judicial review of
legislative acts in a special Constitutional Court; accepts compulsory ICJ
jurisdiction, with reservations
Branches: unicameral Parliament, hereditary Prince, independent judiciary
Government leaders: Head of State, Prince Franz Joseph II; Chief of Government,
Dr. Alfred Hilbe
Suffrage: males age 20 and over
Elections: every 4 years; next elections 1974
Political parties and leaders: Fatherland Union Party (VU), Dr. Alfred Hilbe;
Progressive Citizens Party (PCP), Dr. Gerard Batliner
Voting strength (1970 election): 50.5% VU, 49.5% PCP
Communists: none
Member of: IAEA, IPU, ITU; considering U.N. membership; under a 1923 treaty, Switzer-
land handles Liechtenstein''s post and telegraph systems, customs, and foreign
relations
Legal name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for administrative purposes has 3
districts (Luxembourg, Diekirch, Grevenmacher) and 12 cantons
Legal system: based on civil law system; constitution adopted 1868; judicial
review of legislative acts in the Cassation Court only; accepts compulsory
ICJ jurisdiction
Branches: parliamentary democracy; seven ministers comprise Council of Government
headed by President, which constitutes the executive; it is responsible to
the unicameral legislature, the Chamber of Deputies; the Council of State,
appointed for indefinite term, exercises some powers of an upper house; judicial
power exercised by independent courts
Government leaders: Grand Duke Jean, Head of State; Pierre Werner, Minister of
State and President of the Government as well as Minister of Treasury
Suffrage: universal and compulsory over age 2]
Elections: every 5 years for entire Chamber of Deputies; latest elections Dec-
ember 1968; next election, early 1974
Political parties and leaders: Christian Social Union, Pierre Werner and Nic Mosar
(Party President); Socialist, Antone Wehenkel (Party President); Social
Democrat, Henry Cravatte (Party President); Democratic, Gaston Thorn (Party
President and Foreign Minister); Communist, Dominique Urbany
Voting strength (1968 election, approx.): 32% Socialist, 35% Christian Socialist,
15% Communist, 17% Democratic, 1% other; it should be noted that these are
percentages of votes cast rather than voters, since Luxembourg has a weighted
proportional representation system in which voters in most populous areas
have largest multiple votes
Communists: 439 party members (1971)
Other political or pressure groups: group of steel industries representing iron
and steel industry, Centrale Paysanne representing agricultural producers;
Christian and Socialist labor unions, Federation of Industrialists; Artisans
and Shopkeepers Federation
Member of: Benelux, BLEU (Belgium-Luxembourg Economic Union), Council of Europe,
EC, FAO, IAEA, IBRD, ICAO, IFC, ILO, IMF, NATO, OECD, U.N., UPU, WEU, WHO, WMO
Approved For Release 2004/09/15 : cieRDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Legal name: Province of Macao
Type: overseas province of Portugal
Capital: Lisbon (Portugal)
Political subdivisions: municipality of Macao, and 2 islands
Legal system: Portuguese civil law system
Branches: Governor, who dominates legislative and executive branches, assisted
by Legislative Council with unknown number of appointed and 8 elected
members; the Urban Council with 3 governor-appointed and 4 elected members;
all high-ranking officials appointive under provisions of revised Organic
Overseas Law
Government leader: Brigadier Jose Manuel Nobre De Carvalho, Governor
Suffrage: restricted to Portuguese citizens
Elections: conducted every 4 years; last held November 1968
Political parties and leaders: Portuguese National Union (Uniao Nacional) only
legal party, as in Portugal; Governor is leading political figure
Communists: numbers unknown
Other political or pressure groups: wealthy Macanese and Chinese representing
local interests, wealthy pro-Communist merchants representing China''s
interests; in January 1967 Macao Government acceded to Chinese demands which
gave Chinese veto power over administration of the enclave
Legal name: Malagasy Republic
Type: republic; military-civilian government established May 1972; given 5-year
mandate in popular referendum October 1972
Capital: Tananarive
Political subdivisions: 6 provinces
Legal system: based on French civil law system and traditional Malagasy law;
constitution of 1959 modified in October 1972 by law establishing
provisional government institutions; legal education at National School of
Law, University of Tananarive; has not accepted compulsory ICJ jurisdiction
Branches: executive -- Gen. Ramanantsoa heads government assisted by cabinet
called council of Ministers; National Popular Council for Development
created to replace the legislature in October 1972; regular courts are
patterned after French system and a Superior Council of Institutions
reviews all legislation to determine its constitutional validity
Government leader: General Gabriel Ramanantsoa
Suffrage: universal for adults
Elections: government in October 1972 postponed all political elections indefinitely
Political parties and leaders: Parti Social Democrate (PSD), led by Philibert
Tsiranana; Congress Party for the Independence of Madagascar, led by Pastor
Richard Andriamanjato; National Movement for the Independence of Madagascar
(MONIMA), led by Monja Jaona; parties are permitted to exist but barred
from positions of political authority because of postponement of elections
Voting strength: (1972 presidential election) President Tsiranana, running
unopposed, received 99.7% of votes cast; in 1970 National Assembly elections,
PSD candidates won 94%; AKFM 3%
Communists: Communist party virtually of no importance; small and
vocal group of Communists has gained strong position in leadership
of AKFM, the rank and file of which is non-Communist
Member of: EAMA, FAQ, IAEA, ICAQ, ILO, IMCO, ITU, La Francophonie, OAU, OCAM,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2004/09/15 : CIASRDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','c20f8fb4f2e014014935f28d918258b50185f3147cdc9c2721e683f3a5c99eca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('073ccab8973694aeca9177aec80918015a81ee021626dccb73b15fbefbae6258',1973,'MW','Malawi','government',131,'Legal name: Republic of Malawi
Type: republic since July 1966; independent member of Commonwealth
Capital: Zomba
Political subdivisions: local government unit is the district
Legal system: based on English common law and customary law; constitution
adopted 1964; judicial review of legislative acts in the Supreme Court of
Appeal; has not accepted compulsory ICd jurisdiction
Branches: strong presidential system with cabinet appointed by President; uni-
cameral National Assembly of 60 elected and 15 nominated members; High
Court with Chief Justice and at least 2 justices
Government leader: Life President H. Kamuzu Banda
Suffrage: universal adult
Elections: scheduled for April 1971 but not held since MCP candidates were unopposed
Political parties and leaders: Malawi Congress Party (MCP), Dr. H. Kamuzu Banda
Communists: no Communist Party; may be a few Communist sympathizers
Member of: FAO, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU, U.N., UNESCO, WHO, WMO
Legal name: Malaysia
Type:
Malaysia: constitutional monarchy nominally headed by Paramount Ruler (King);
a bicameral Parliament consisting of a 58-member Senate and a 144-member
House of Representatives
West Malaysian states: hereditary rulers in all but Penang and Malacca where
Governors appointed by Malaysian Government; powers of state governments
limited by federal constitution
Sabah: self-governing state within Malaysia in which it holds 16 seats in
House of Representatives; foreign affairs, defense, internal security,
and other powers delegated to federal government
Sarawak: self-governing state within Malaysia in which it holds 24 seats in
House of Representatives; foreign affairs, defense, and internal security,
and other powers are delegated to federal government
Capital:
West Malaysia: Kuala Lumpur
Sabah: Kota Kinabalu (formerly Jessel ton)
Sarawak: Kuching
Political subdivisions: 13 states (including Sabah and Sarawak)
Legal system: based on English common law; constitution came into force 1963;
judicial review of legislative acts in the Supreme Court at request of
Supreme Head of the Federation; has not accepted compulsory ICJ jurisdiction
Branches: 9 state rulers alternate as Paramount Ruler for 5-year terms; locus of
executive power vested in Prime Minister and cabinet, who are responsible
to bicameral parliament; following communal rioting in May 1969, govern-
ment imposed state of emergency and suspended constitutional rights of all
parliamentary bodies; parliamentary democracy resumed in February 1971
West Malaysia: executive branches of 11 states vary in detail but are similar
in design; a Chief Minister, appointed by hereditary ruler or Governor,
heads an executive council (cabinet) which is responsible to an elected,
unicameral legislature
Sarawak and Sabah: executive branch headed by Governor appointed by central
government, largely ceremonial role; executive power exercised by Chief
Minister who heads parliamentary cabinet responsible to unicameral
legislature; judiciary part of Malaysian judicial system
Government leader: Head of State, Tun Abdul Razak
Suffrage: universal over age 20
Elections: minimum of every 5 years, last elections 1969
Political parties and leaders:
West Malaysia: Alliance Party consisting of United Malays National Organiza-
tion (UMNO), Tun Abdul Razak; Malaysian Chinese Association (MCA), Tan
Siew Sin; and Malaysian Indian Congress (MIC), V.T. Sambanthan; major
opposition parties -- Pan Malayan Islamic Party (PMIP), Dato Asri bin Haji
Approved For Release 2064/09/15 : CIA-RDP79-01051A000500010001-1
covPARRHEV eden Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Political parties and leaders (cont''d):
West Malaysia (cont''d):
Muda (acting); Democratic Action Party (DAP); Gerakan Rakyat Malaysia (GRM) ;
minor opposition parties -- Party Rakyat (PR), People''s Progressive Party
(PPP), Labor Party of Malaya (LPM) Partai Keadilan Masharakyat (KEMAS),
United Malaysian Chinese Organization (UMCO); Communist Party illegal
Sabah: United Sabah National Organization (USNO), Tun Mustapha bin Dato
Harun; Sabah Chinese Association (SCA), Khoo Siak Chiew; no organized
opposition
Sarawak: coalition composed of Sarawak Alliance and Sarawak United Peoples
par ey (SUPP), Ong Kee Hui; Opposition Sarawak National Party (SNAP), Stephen
Ningkan
Voting strength:
West Malaysia: (1969 election) Alliance Party controls 9 of 11 state
legislatures, won estimated 49% of total vote; Pan-Malaysian Islamic
Party polled 24%; Democratic Action Party polled 12%; Gerakan 7%
Sabah: (October 1971 Assembly Elections) Alliance unopposed, opposition
candidates disqualified
Sarawak: (1970 elections) Alliance 24 seats, SNAP 12 seats, SUPP 11 seats;
SUPP has joined the Alliance to form a coalition state government
Communists:
West Malaysia: approx. 1,500 armed insurgents on Thailand side of Thai/
Malaysia border; approx. 300 on Malaysian side
Sarawak: 960 armed insurgents in Sarawak; armed element of SCO in Indonesian
West Borneo estimated at 300
Sabah: insignificant
Member of: ADB, ASEAN, ASPAC, Commonwealth, FAO, GATT, IAEA, IBRD, ICAO, IFC,
ILO, IMF, ITU, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Maldives
Type: republic
Capital: Malé
Political subdivisions: 19 administrative districts corresponding to atolls
Legal system: based on Islamic law with admixtures of English common law: primari-
ly in commercial matters; has not accepted compulsory ICJ jurisdiction
Branches: popularly elected unicameral national legislature (Majlis) (members
elected for 5-year terms); elected President, chief executive; appointed
Chief Justice responsible for administration of Islamic law
Government leaders: President Ibrahim Nasir; Prime Minister/External Affairs
Minister Ahmed Zaki
Suffrage: universal over age 21
Political parties and leaders: no organized political parties; country governed
by the Didi clan for the past eight centuries
Communists: negligible number
Member of: Colombo Plan, U.N.
Legal name: Republic of Mali
Type: republic; under military regime since November 1968
Capital: Bamako
Political subdivisions: 6 administrative regions; 42 administrative districts
(cercles), arrondissements, villages; all subordinate to central government
Legal system: based on French civil law system and customary law; constitution
adopted 1960, amended 1961; judicial review of legislative acts in Constitu-
tional Section of Court of State; has not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by Military Committee of National
Liberation (MCNL) composed of 11 army officers; under MCNL functional
cabinet composed of civilians and army officers; judiciary
Government leaders: Col. Moussa Traore, president of MCNL, Chief of State and
head of government
Suffrage: universal over age 2]
Political parties and leaders: former Union Soudanaise-RDA dissolved and political
activity proscribed by military government
Elections: MCNL promises elections at unspecified date
Communists: there are a few Communists and a somewhat larger number of sympathizers;
some are under detention by MCNL
Member of: ADB, EAMA, ECA, FAO, IAEA, ICAQ, ILO, IMF, ITU, La Francophonie, Niger
River Commission, OAU, OMVS, U.N., UNESCO, UPU, WHO, WMO','7489cf7aaf30f675ac3055d89a1f11921120fb8c092cb5fc33f0cd6ab5c1c259','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13f2448d659a08418c445b89db55cd698be7567fe0887f58cceda0ceb96a511b',1973,'MT','Malta','government',137,'Legal name: Malta
Type: parliamentary democracy, independent state within the Commonwealth since
September 1964
Capital: Valletta
Political subdivisions: 2 main populated islands, Malta and Gozo, divided into
10 electoral districts (divisions)
Legal system: based on English common law; constitution adopted 1961, came into
force 1964; has accepted compulsory ICU jurisdication, with reservations
Branches: executive, consisting of prime minister and cabinet; legislative,
comprising 55-member House of Representatives; independent judiciary
Government leader: Prime Minister Dom Mintoff
Suffrage: universal over age 21; registration required
Elections: at the discretion of the Prime Minister, but must be held before the
expiration of a 5-year electoral mandate; last election June 1971
Political parties and leaders: Nationalist Party, George Borg Olivier; Malta Labor
Party, Dom Mintoff
ie ees (1971 election): Labor, 28 seats (50.8%); Nationalist, 27 seats
48 .1%
Communists: less than 100 (est.)
Member of: Commonwealth, Council of Europe, FAO, GATT, ICAO, ILO, IMF, Seabeds
Committee, TDB, U.N., UNESCO, WHO','91e944157d00000d066e9dc7a0ffec76ae6d0de2d8f2ae860af18ce96b172901','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e00bff3d311e38b2e802a2e394b3d7c48e19c72e1d34245c75ae6b13ac0ad64b',1973,'MQ','Martinique','government',141,'Legal name: Overseas Department of Martinique
Type: overseas department of France; represented by 3 deputies in the French
National Assembly and 2 Senators in the Senate
Capital: Fort-de-France
Political subdivisions: 2 arrondissements; 34 communes, each with a locally
elected municipal council
Legal system: French legal system; highest court is a court of appeal based
in Martinique with jurisdiction over Guadeloupe, French Guiana, and Martinique
Branches: executive, Prefect appointed by Paris; legislative, popularly elected
council of 36 members; judicial, under jurisdiction of French judicial system
Government leader: Prefect Jean Terrade
Suffrage: universal over age 2]
Elections: General Council elections coincide with those for the French National
Assembly, normally every five years; last General Council election took place
in March 1970
Political parties and leaders: Union of Democrats for the Republic (UDR), Emil
Maurice; Progressive Party of Martinique (PPM), Aime Cesaire; Communist
Party of Martinique (PCM), Armand Nicolas; Democratic Union of Martinique,
Leon-Laurent Valere; Socialist Party, leader unknown; Federation of the
Left, leader unknown
Voting strength: UDR, 2 seats in French National Assembly; PPM, 1 seat (1968
Becton)
Communists: 700-800 active members, 10,000 sympathizers
Other political or pressure groups: Proletarian Action Group (GAP)','9d61eec7649b2bd536e23a60c8b7e7ac4604b32d834ea6ef9e6e83bc1df57ab0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66bed81df065ad6d808853b657777f72f14b6b26a49cd42af7af2078df15c537',1973,'MR','Mauritania','government',145,'Legal name: Islamic Republic of Mauritania
Type: republic; one-party presidential rule since 1960
Capital: Nouakchott
Political subdivisions: 8 regions and a capital district
Legal system: based on French civil Jaw system and Islamic law; constitution
adopted 1961; judicial review of legislative acts in the Supreme Court;
has not accepted compulsory ICJ jurisdiction
Branches: president; unicameral National Assembly of 50 elected members;
separate judiciary (appointed by president)
Government leader: President Moktar Ould Daddah
Suffrage: universal for adults
Elections: presidential and parliamentary election every 5 years; most recent
August 1971. ,
Political parties and leaders: Mauritanian People''s Party is only legal party,
Secretary General Moktar Ould Daddah
Communists: no Communist Party; sympathizers exist, particularly for Chinese
Communists
Member of: EAMA, FAQ, ICAO, ILO, IMCO, ITU, La Francophonie, OAU, Organization
for the Development of the Senegal River Valley (OMVS), Seabeds Committee,
U.N., UNESCO, WHO, WMO','feeb63692155658db005bec93e8a83fe5c7efd0e19d625bf0e4f3ab6e126f189','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df199dee09fea088a7cc81f0e45ebfb62098f5bbb9623c4cd35958ff6fd8bd68',1973,'MU','Mauritius','government',149,'Legal name: Mauritius
Type: independent state since 1968, recognizing Elizabeth II as chief of state
Capital: Port Louis
Political subdivisions: 5 "organized municipalities" and various island
dependencies
Legal system: based on French civil law system with elements of English common
law in certain areas; constitution adopted 6 March 1968
Branches: executive power exercised by Prime Minister and 21-man Council of
Ministers; unicameral legislature (National Assembly) with 62 members elected
by direct suffrage and 8 specially elected
Government leader: Prime Minister Dr. S. Ramgoolam
Suffrage: universal over age 21
Elections: last held in August 1967; next scheduled in 1972 postponed at least
4 years by constitutional amendment
Political parties and leaders: a loose government coalition consisting of Labor
Party (S. Ramgoolam), Muslim Committee of Action (A. R. Mohamed), and Parti
Mauricien Social Democrate (G. Duval); Independent Forward Bloc (S.
Bissoondoyal); Mauritius Democratic Union (M. Lesage); a few independents;
Mouvement Militant Mauritian (P. Berenger)
Voting strength: Muslim Committee of Action, 6 seats; Independent Forward Bloc,
6 seats; Mauritius Labor Party, 33 seats; Mauritius Democratic Union, 6 seats;
Parti Mauricien Social Democrate, 18 seats; independent 1 seat; Mouvement
Militant Mauritian 1 seat
Communists: may be 2,000 sympathizers; several Communist organizations; Mauritius
Lenin Youth Organization, Mauritius Women''s Committee, Mauritius Communist
Party, Mauritius People''s Progressive Party, Mauritius Young Communist League,
Mauritius Liberation Front, Chinese Middle School Friendly Association,
Mauritius/USSR Friendship Society
Other political or pressure groups: Tamil United Party, Mauritius Workers Party
Member of: ICAO, La Francophonie, Commonwealth, OAU, OCAM, U.N.
Approved For Release 2004/09/15 : @28-RDP79-01051A000500010001-1
ECONOMY: Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GNP: est. $161 million (1970), approximately $190 per capita
Agriculture: sugar crop is major economic asset; about 40% of land area is planted
to sugar; tea production rising slowly; most food imported -- rice is the
staple food -- and since cultivation is already intense and expansion of
cultivable areas is unlikely, heavy reliance on food imports except sugar
and tea will continue
Shortage: land
Industries: mainly confined to processing sugarcane, tea; some small-scale,
simple manufactures; tobacco fiber; some fishing; tourism, diamond cutting,
weaving and textiles
Electric power: 61,340 kw. capacity (1971); 148 million kw.-hr. produced (1971),
171 kw.-hr. per capita
a»
Exports: $69 million (f.o.b., 1970); mainly sugar, tea, molasses ,
Imports: $75.6 million (1970); foodstuffs 30%, manufactured goods 23%
Major trade partners: U.K. has preferential treatment, buys over 50% of Mauritius’
sugar export at heavily subsidized prices; small amount of sugar exported to
Canada, U.S., and Italy; imports from U.K. and EC primarily, also from South
Africa, Australia, and Burma; some minor trade with China
Monetary conversion rate: 5.12 Mauritian rupees=US$1
Fiscal year: 1 July - 30 June','170c7b3c47979615877ce8ab0193a0c547ce2e670d1d4bc4c6e4aba496914425','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e785007980bf2014f29cf15f53fed25a19d63e76c7e1015e66a019240530b11a',1973,'MC','Monaco','government',152,'Legal name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Political subdivisions: 4 sections
Legal system: based on French law; new constitution adopted 1962; has not
accepted compulsory ICJ jurisdiction
Branches: National Council (18 members); Communal Council (15 members, headed
by a mayor)
Government leader: Prince Rainier III
Suffrage: universal
Elections: National Council every 5 years; most recent 1968
Political parties and leaders: National Union of Independents, National Democratic
Entente (1965)
Voting strength: figures for 1968 election not available; (1958) 61% National
Union of Independents, 39% National Democratic Entente
Communists: not available
Member of: IAEA, IHB, ITU, U.N., UNESCO, UPU, WHO','04f681e8afa38264c89b31d264f9f4005f68e31deb076b63b866dd3cb3989fef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08a121d439f3a144ec2efb2ba00edc5843d27537f62bc4099afe00953ab9ec23',1973,'MN','Mongolia','government',156,'Legal name: Mongolian People''s Republic
Type: Communist state
Capital: Ulaanbaatar
Political subdivisions: 18 provinces and 2 autonomous municipalities (Ulaanbaatar
and Darhan)
Legal system: blend of Russian, Chinese, and Turkish systems of law; constitution
adopted 1940; no constitutional provision for judicial review of legislative
acts; legal education at Ulaanbaatar State University; has not accepted
compulsory ICJ jurisdiction
Branches: constitution provides for a Great People''s Hural (national assembly)
and a highly centralized administration
Party and government leader: Y. Tsedenbal, First Secretary of the MPRP and
Chairman of the Council of Ministers
Suffrage: universal; age 18 and over
Elections: national assembly elections held in June 1969; next elections
scheduled for 1972
Political party: Mongolian People''s Revolutionary (Communist) Party (MPRP);
estimated membership, 58,000 (claimed 1972)
Member of: CEMA, ECAFE, U.N., WHO
Legal name: Kingdom of Morocco
Type: constitutional monarchy (constitution adopted 1972)
Capital: Rabat
Political subdivisions: 19 provinces and 2 prefectures
Legal system: based on Islamic law and French and Spanish civil law system;
judicial review of legislative acts in Constitutional Chamber of Supreme
Court; modern legal education at branches of Mohamed V University in Rabat
and Casablanca and Karaouine University in Fes; has not accepted compulsory
ICJ jurisdiction
Branches: constitution provides for Prime Minister and ministers named by and
responsible to King; King has paramount executive powers; unicameral
legislature (two thirds to be directly elected; one third indirectly);
judiciary independent of other branches
Government leaders: King Hassan II; Prime Minister Mohamed Karim-Lamrani
Suffrage: universal over age 20
Elections: last parliamentary elections held 21 and 28 August 1970 for Council
of Representatives which was dissolved in March 1972; elections for new
parliament created by Constitution adopted 15 March 1972 may be held prior
to April 1973
Political parties and leaders: Istiqial Party, Allal el-Fassi; Popular Movement
(MP), Mahjoubi Aherdan; Constitutional and Democratic Popular Movement
(MPCD), Dr. Abdelkrim Khatib; National Union of Popular Forces (UNFP), split
into competitive factions under Abderrahim Bouabid and Abdallah Ibrahim and
Mahjoub Ben Seddik; Democratic Constitutional Party (PDC), Mohamed Hassan
Quazzani; Party for Liberation and Socialism (PLS), established in June 1968
and banned September 1969, is front for Moroccan Communist Party (MCP), which
was proscribed in 1959, Ali Yata; Istiqlal and the UNFP formed a National
Front in July 1970 to oppose the new constitution, boycotted the parliamentary
elections and the 1972 constitutional referendum
Voting strength: August 1970 elections were nonpolitical; 1 March 1972
constitutional referendum tallied 98.7% for new constitution, 1.25% opposed
and National Front abstained from voting
Communists: 300 est.
Approved For Release 2004/09/15 : CIASRDP79-01051A000500010001-1
Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GOVERNMENT (coANARSOVed For
Member of: Arab League, EC (association until 1974), FAO, IAEA, IBRD, ICAO, IDA,
an re de IMF, ITU, OAU, Seabeds Commi ttee (observer), U.N., UNESCO,
> > WM
Legal name: State of Mozambique
Type: overseas state of Portugal
Capital: Lourenco Marques
Political subdivisions: province divided into 10 districts administered by
district governors; municipalities governed by appointed official
Legal system: based on Portuguese civil law system and customary law
Branches: Governor General appointed by Lisbon is chief executive officer for
internal administration; he also has certain legislative powers which he
exercises with a legislative council; all action in state may be vetoed
by Minister of Overseas in Lisbon; judiciary is constitutionally independent
Government leader: Governor General Manuel Pimentel dos Santos
Suffrage: all adults able to read and write Portuguese and in full possession of
political and civil rights
Political parties and leaders: National Popular Action (ANP), formerly the
National Union (UN), state president Manuel Monteiro Ribeiro Veloso; no
legal opposition political parties
Communists: none known
Other political or pressure groups: the National Liberation Front (FRELIMO), led
by Moises Samora Machel, operates primarily from Tanzania; less significant
Revolutionary Committee (COREMO), led by Paulo Gumane, based in Zambia
Legal name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se; government offices in Uaboe District
Political subdivisions: 14 districts
Branches: President elected from and by Parliament for an unfixed term; popularly
elected unicameral legislature, the Parliament; Cabinet to assist the
President, four members, appointed by President from Parliament members
Government leader: President Hammer De Roburt
Suffrage: universal adult
Political parties and leaders: there are no political parties; De Roburt is only
significant political figure
Member of: no present plans to join U.N.; enjoys "special membership" in
Commonwealth; South Pacific Commission, INTERPOL, ECAFE
Legal name: Kingdom of Nepal
Type: constitutional monarchy; King Birendra exercises autocratic control over
multitiered panchayat system of government
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and English common law; legal
education at Nepal Law College in Kathmandu; has not accepted compulsory
ICJ jurisdiction
Branches: Council of Ministers appointed by the King; indirectly elected
National Panchayat (Assembly
Government leader: King Birendra Bir Bikram Shah Deva; Prime Minister Kirti Nidhi
Bista
Suffrage: universal over age 21
Elections: village and town councils (panchayats) elected by universal suffrage;
district, zonal, and National Panchayat members indirectly elected, most
for 6-year terms; 15 National Panchayat members elected from five class
organizations (women, workers, youth, and ex-servicemen), four directly
elected by all voters possessing a B.A. or its equivalent, and 16 are
appointed by the King
Political parties and leaders: all political parties outlawed
Communists: the combined membership of the two wings of the Communist Party
of Nepal (CPN) may be on the order of 6,500, the majority (perhaps 5,000)
in the pro-Chinese wing; the CPN continues to operate more or less openly,
but internal dissension has greatly hindered its effectiveness
Member of: ADB, FAO, IBRD, ICAO, IDA, ILO, IMF, ITU, U.N., UNESCO, UPU, WHO
Legal name: Kingdom of the Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government resides at The Hague
Political subdivisions: 11 provinces governed by centrally appointed commissioners
of Queen
Legal system: civil law system incorporating French penal theory; constitution
of 1815 frequently amended, reissued 1947; judicial review in the Supreme
Court of legislation of lower order than Acts of Parliament; legal education
at six law schools; accepts compulsory ICJ jurisdiction, with reservations
Branches: executive, (Queen and Cabinet of Ministers), which is responsible to
bicameral states general (parliament); independent judiciary
Government leader: Head of State, Queen Juliana; Barend Willem Biesheuvel, Prime
Minister
Suffrage: universal over age 21
Elections: must be held at least every 4 years for lower house (most recent
November 1972), and every 3 years for upper house (most recent April 1971)
Political parties and leaders: Catholic People''s Party (KVP), Dr. D. de Zeeuw3
Antirevolutionary (ARP), A. Veerman; Labor (PvdA), Andre van der Louw; Liberal
(VVD), Mrs. H. van Someren-Downer; Christian Historical Union (CHU),
Baron Otto Willem Anton van Verschuer; Democrats ''66 (D-66), Mrs. R. E. van
der Scheer; Communist (CPN), Henk Hoekstra; Pacifist Socialist (PSP); A. G.
Vander Spek; Political Reformed (SGP), H. G. Abma; Reformed Political Union
(GVP), W. G. Beeftink; Radical Party (PPR), Dolf Coppes; Democratic Socialist
''70 (DS-70), Professor D. Polak; Farmers! Party (BP), leader unknown; Roman
Catholic Party (RKP), leader unknown
Voting strength (1972 election): 17.7% KVP, 14.4% VVD, 8.8% ARP, 4.8% CHU, 27.4%
PvdA, 4.2% D-66, 4.1% DS-70, 4.5% CPN, 1.5% PSP, 4.8% PRP, 2.2% SGP, 1.8% GVP,
1.9% BP, .9% RKP
Communists: 9,000 members; 329,973 votes in 1972 election
Member of: Benelux, Council of Europe, ECE, ECSC, EC, EMA, EURATOM, FAO, IAEA,
IBRD, ICAO, IHB, IMF, NATO, OECD, Seabeds Committee (observer), U.N., UNESCO,
WEU, WHO
Approved For Release 2004/09/15 : CA2@RDP79-01051A000500010001-1
ECONOMY Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GNP: $39.1 billion (1971 preliminary), $2,970 per capita; 56% consumption, 28%
investment, 17% government, -1% net foreign balance; 1971 growth rate 4%, in
1963 constant prices
Agriculture: animal husbandry predominates; main crops -- horticultural crops,
grains, potatoes, sugar beets; food shortages -- grains, fats, oils; caloric
intake, 3,030 calories per day per capita (1968-69)
Fishing: catch 323,100 metric tons, $66,938,000 (1969); exports $94,542,000
(1969), imports $82,531,000 (1969)
Major industries: food processing, metal and engineering products, electrical and
electronic machinery and equipment, chemicals, and petroleum products
Shortages: crude petroleum, raw cotton, base metals and ores, pulp, pulpwood,
lumber, feedgrains, and oilseeds
Crude steel: 5 million metric tons Produced (1970), 380 kilograms per capita
Electric power: 11,500,000 kw. capacity (1971); 44.9 billion kw.-hr. produced
(1971), 3,380 kw.-hr. per capita
Exports: $15,065 million (f.o.b., 1971); foodstuffs, machinery, transportation
equipment, consumer manufactures, chemicals, petroleum products, textiles
Imports: $16,729 million (c.i.f., 1971); machinery, transportation equipment,
consumer manufactures, crude petroleum, foodstuffs, chemicals, raw cotton,
base metals and ores, pulp
Major trade partners: (1970) 58.7% EC, 29.7% W. Germany, 15.5% Belgium-
Luxembourg, 8.7% France, 12.9% EFTA, 6.3% U.K., 7.2% U.S., 1.7% Eastern
Europe
Aid:
economic -- (received) U.S., $1,279 million authorized (FY46-70); none
Since FY58; IBRD, $236 million authorized (FY46-70), none since 1958;
military -- (received) U.S., $1,240 million authorized (FY46-70), none since
FY67; net official aid given to less developed areas and multilateral
agencies -- $1,005 million (FY60-70), $200 million park
Monetary conversion rate: 3.2447 guilders=US$1 (central rate
Fiscal year: calendar year
Legal name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands, enjoying complete domestic
autonomy
Capital: Willemstad; Curacao, center of government
Political subdivisions: 4 island territories -- Aruba, Bonaire, Curacao, and the
Windward Islands -- St. Eustatius, southern part of St. Martin (northern
part is French), Saba
Legal system: based on civil law system, with some English common law influence;
Dutch Country Statute of 1955 serves as constitution
Branches: executive power, under nominal head of Governor (appointed by the
Crown), exercised by 8-member Council of Ministers or Cabinet; legislative
power rests with 22-member Legislative Council; independent court system
under control of Chief Justice of Supreme Court of Justice (administrative
functions under Minister of Justice); each island territory has island
council headed by Lieutenant Governor for local administration
Government leaders: Minister President Ramez Jorge Isa (new government formed
6 February 1971)
Suffrage: universal over age 21
Elections: held every 4 years
Political parties and leaders: the Democratic Party (DP); Antilles Social Progress
Movement (MASA) led by Ciro Kroon; the Aruba Patriotic Party (PPA) led by S.J.
Trompe; the National People''s Party (NVP), S.D. Abbad; the Aruba People''s Party
(AVP) led by Dominico Guzman Croes; the National Aruban Union Party/ Independent
Aruban Party (UNA/PIA) led by A. Werleman/M. Croes; Bonaire Democratic Party
Ted by L.A. Abraham; Windward Island Democratic Party led by A. C. Wathey;
Social Progressive Action Party, S. R. Goeloe; Antillean Reform Union (URA),
Roberto Suriel; Curacao Independent Party (COP), Peter Vander Hoven; Radical
Peoples Party (PRP), Max de Castro; Workers'' Party (Frente Obrero) -- coalition
in power includes DP, PPA, and Workers'' Party
Voting strength (1969 local election): 46% DP/PPA; 15% NVP; 14% Worker Front;
14% AVP; 11% other (new elections may be called soon)
Communists: no Communist Party
Member of: EC (associate), WHO
Approved For Release 2004/09/15 : CIA@ARDP79-01051A000500010001-1
keane Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
NOMY :
GNP: $250 million (1967), $1,170 per capita; real growth rate 1967, 3.6%
Agriculture: little production
Major industries: petroleum refining on Curacao and Aruba; tourism on Curacao,
Aruba, and St. Martin; phosphate mining on Curacao
Electric power: 295,000 kw. capacity (1971); 885 million kw.-hr. produced (1971
est.), 3,950 kw.-hr. per capita -
Exports: $654 million (f.o.b., 1970 est.); petroleum products, phosphate
Imports: $767 million (c.i.f., 1970 est.); crude petroleum, food manufactures
Major trade partners: exports -- U.S. 43%, EC 16%, Latin America 13%, U.K. 10%,
Canada 7%; imports -- Venezuela 72%, U.S. 10%, Netherlands 4% (1968)
Monetary conversion rate: 1.886 Netherlands Antillean florins (NAF)=US$1 (official)
Fiscal year: calendar year 2','38be30c5e6243b26198f2238a1bf1186bc3a1605cf1aebe1bf5c755d9e9d7d4a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c718366f906e5c63a9358722b3ca15b113375133d76ec7cae0e00a5e079ee0d9',1973,'NE','Niger','government',160,'Legal name: Republic of Niger
Type: republic; one-party rule established 1960
Capital: Niamey
Political subdivisions: 7 departments, 32 arrondissements
Legal system: based on French civil law system and customary law; constitution
adopted 1960; judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: President selected for 5 years by direct universal suffrage; unicameral,
60-member National Assembly elected for 5 years; judiciary constitutionally
independent of executive and legislature
Government leader: President Diori Hamani
Suffrage: universal over age 21
Elections: presidential and parliamentary elections in 1970; about 99% of voters
approved unopposed official candidates
Political parties and leaders: Parti Progressiste Nigerien (PPN), led by Diori
Hamani
Communists: some Communists and Communist sympathizers, especially among supporters
of outlawed Sawaba party
Member of: ADB, EAMA, ECA, Entente, FAO, GATT, IBRD, ICAO, ILO, IMF, ITU, La
Francophonie, Lake Chad Basin Commission, Niger River Commission, OAU, OCAM,
U.N., UNESCO, UPU, WHO, WMO
Legal name: The Federal Republic of Nigeria
Type: federal republic since 1963; under military rule since January 1966
Capital: Lagos
Political subdivisions: 12 states, 11 headed by a military governor, and 1 by a
civilian administrator
Legal system: based on English common law, tribal law, and Islamic law; new
constitution to be prepared; accepts compulsory ICJ jurisdiction, with
reservations
Branches: Federal Military Government, administered by Supreme Military Council
largely civilian Federal Executive Council
Government leader: Gen. Yakubu Gowon, Head of Federal Military Government and
Commander in Chief of Nigerian Armed Forces
Suffrage: universal adult suffrage (except for women in former Northern Region)
Elections: expected to be held by 1976
Political parties and leaders: political parties and politically active tribal
societies were dissolved by decree on 24 May 1966; some sub rosa political
activity continues
Communists: the banned Socialist Workers and Farmers Party and the Nigerian Trade
Union Congress have a limited political following
Member of: ADB, Commonwealth, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU,
Lake Chad Basin Commission, Niger River Commission, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 20 counties, 404 communes, 47 towns
Legal system: mixture of customary law, civil law system, and common law traditions;
constitution adopted 1814, modified 1884; Supreme Court renders advisory
opinions to legislature when asked; legal education at University of Oslo;
accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament (Storting);
executive power vested in Crown but exercised by cabinet responsible to
parliament; Supreme Court, 5 superior courts, 104 lower courts
Government leaders: King Olav V; Prime Minister Lars Korvald
Suffrage: universal, but not compulsory, over age 20
Elections: held every 4 years (next in 1973)
Political parties and leaders: Conservative, Kare Willoch; Christian Peoples,
Lars Korvald; Center, John Austrheim; Liberal, Helge Seip; Labor, Trygve
Bratteli; Socialist Peoples, Finn Gustavsen; Communist, Reidar Larsen
Voting strength (1969 election): 19.6% Conservative; 9.4% Christian Peoples;
10.5% Center; 9.4% Liberal; 46.5% Labor; 3.5% Socialist Peoples; 1.0%
Communist
Communists: 2,000; a number of sympathizers as indicated by the 22,500 Communist
votes cast in the 1969 election
Member of: Council of Europe, EFTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IMB,
ILO, IMCO, IMF, ITU, NATO, Nordic Council, OECD, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Sultanate of Oman
Type: absolute monarchy; nominally independent but under strong U.K. influence
Capital: Muscat
Legal system: based on English common law and Islamic law; no constitution;
ultimate appeal to the Sultan; has not accepted compulsory ICJ jurisdiction
Government leader: Sultan Qabus ibn Sa''id Al Bu Sa''id
Member of: Arab League, U.N.
Legal name: Islamic Republic of Pakistan
Type: republic currently in transition from martial law to elected government;
martial law ended April 1972 and permanent constitution is to be written by
August 1973
Capital: Islamabad
Political subdivisions: 4 provinces -- Punjab, Sind, Baluchistan, and Northwest
Frontier -- with the capital territory of Islamabad and certain tribal areas
centrally administered; Pakistan claims that Azad Kashmir is independent
pending a settlement of the dispute with India, but it is in fact under
Pakistani control
Legal system: based on English common law; accepts compulsory ICJ jurisdiction,
with reservations
Government leaders: President Z. A. Bhutto
Suffrage: universal over age 21
Elections: elections for National Assembly based on one-man/one-vote formula,
and for provincial assemblies were held in December 1970; with independence
of Bangladesh, National Assembly consists of 144 West Pakistanis and 2 East
Pakistanis
Political parties and leaders: Pakistan People''s Party (PPP), Z.A. Bhutto;
Council Muslim League (CML), Shaukat Hayat Khan; Pakistan Democratic
Party (PDP), Nurul Amin; National Awami Party (NAP), Abdul Wali Khan;
All Pakistan Muslim League (PMLQ), Abdul Qaiyum Khan; Markazi Jamiat-ul-
Ulema-i-Pakistan (MJUP), Khamaja Qamar-u-Din Sialvi; Jamiat-ul-Ulema-
i-Islam (JUI), Mufti Mahmud
Communists: 750; 3,000-5,000 sympathizers
Member of: ADB, CENTO, Colombo Plan, Commonwealth, FAO, IAEA, IBRD, ICAQ, IDA,
IFC, IHB, ILO, IMCO, IMF, ITU, RCD, Seabeds Committee, SEATO, U.N., UNESCO,
UPU, WHO, WMO','7c73aa84a2c163cff0ab2f2cf9fa832a96a8ea752bbd1d975387368d1f96749d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eee20ca6c4fb7690c82b1f4dc9fa90d969ddba1994ff550f89e529c9af9dbd61',1973,'PG','Papua New Guinea','government',165,'Legal name: Papua New Guinea
Type: dependent territory under Administrator appointed by Australia
Capital: Port Moresby
Political subdivisions: 18 administrative districts (12 in New Guinea, 6 in Papua);
New Guinea (including Bismarck archipelago and Bougainville) is a U.N. Trust
Territory
Legal system: based on English common law; highest judicial organ is High Court
of Australia
y Branches: executive -- Administrator and Executive Council; legislature --
House of Assembly (94 members, including 10 appointed); judiciary -- court
system consists of Supreme Court of Papua New Guinea and various inferior
courts (District Courts, Local Courts, Children''s Courts, Wardens'' Courts);
Supreme Court decisions may be appealed to High Court of Australia
Government leader: Administrator, L. W. Johnson
Elections: preferential-type elections for 100-member House of Assembly every
4 years
Political parties: proindependence Pangu Party is principal political group;
5 or 6 other small parties and numerous independents
Suffrage: universal adult suffrage
Voting strength (1972 election): Pangu Party and allies won 52 seats, United
Party 42 seats, Independence 6 seats
Communists: no significant strength
Legal name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncion
Political subdivisions: 16 departments and the national capital, 154 municipalities
Legal system: based on Argentine codes, Roman law, and French codes; constitution
promulgated 1967; judicial review of legislative acts in Supreme Court; legal
education at National University of Asuncion and Catholic University of Our
Lady of the Assumption; does not accept compulsory ICJ jurisdiction
Branches: President heads executive; bicameral legislature; judiciary headed
by Supreme Court
Government leader: President (General) Alfredo Stroessner
Suffrage: universal; compulsory between ages of 18-60
Elections: President and Congress elected together every 5 years; 4-party
participation for first time in 1968 elections
Political parties and leaders: Colorado Party, Juan Ramon Chavez; Liberal
Party (Levi-Liberal Party), Carlos Levi Ruffinelli; Febrerista Party, Manuel
Benitez; Radical Liberal Party (regular Liberal Party), Efraim Cardozo;
cuietlan Democratic Party (not officially inscribed), Dr. Hermogones Rojas
Silva
Voting strength (February 1968 general election): 71% Colorado Party, 22% Radical
Liberal Party, 4% Liberal Party, 3% Febrerista Party
Communists: Oscar Creydt faction and Miguel Angel Soler faction (both illegal);
perhaps a few thousand party members and sympathizers in Paraguay, very
few are hard core; party in exile is small and deeply divided
Other political or pressure groups: Popular Colorado Movement (MoPoCo) led by
Epifanio Mendez Fleitas, in exile
Member of: FAO, IADB, IAEA, IBRD, ICAO, IMF, LAFTA, OAS, U.N., WHO
Legal name: Republic of Peru
Type: republic; under military regime since October 1968
Capital: Lima
Political subdivisions: 23 departments with limited autonomy plus constitutional
Province of Callao
Legal system: based on civil law system; military government rules by decree;
legal education at the National Universities in Lima, in Trujillo, in Arequipa,
and in Cuzco; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative, judicial; congress disbanded after 3 October
1968 ouster of President Fernando Belaunde Terry
Government leader: President Juan Velasco Alvarado
Elections: none scheduled
Political parties and leaders: Popular Action Party (AP), Fernando Belaunde Terry
(in exile); Christian Democratic Party (PDC) supports the government, Hector
Cornejo Chavez; opposition parties include American Popular Revolutionary
Alliance Party (APRA), Victor Raul Haya de la Torre; and Popular
Christian Party (PPC), Luis Bedoya Reyes
Voting strength (1963 election): 39% AP-PDC, 34% APRA, 25% UNO, 1% Communist,
1% other
Communists: 5,000; sympathizers 15,000-25,000
Member of: GATT, IADB, IAEA, ICAO, LAFTA and Andean Sub-Regional Group (created
in May 1969 within LAFTA), OAS, Seabeds Committee, U.N.','d3613c697ff364c62b2be91250f4dafc90e6855bccc92bf2d97a39808ebf6a07','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c301744f53b5b006f8e2a177646decb67dd355458d7b8d72d63ea6003c916d6',1973,'PH','Philippines','government',169,'Legal name: Republic of the Philippines
Type: republic
Capital: Quezon
Political subdivisions: 68 provinces
Legal system: based on Spanish, Islamic, and Anglo-American law; constitution
passed 1935, ratified as amended 1947; judicial review of legislative acts
in the Supreme Court; legal education at University of the Philippines,
Ateneo de Manila University, and 71 other law schools; accepts compulsory
ICJ jurisdiction, with reservations
Branches: strong executive branch with Presidential Cabinet; bicameral
legislature -- Senate and House of Representatives; judicial branch headed
by Supreme Court with descending authority in a Court of Appeals, Courts
of First Instance in various provinces, municipal courts in chartered
cities, and justices of the peace in towns and municipalities; these
justices have considerably more authority than do justices of the peace
in the U.S,
Government leader: President Ferdinand E. Marcos
Suffrage: universal over age 21, and literate
Elections: elections for President and House of Representatives held every 4 years;
Senate elections staggered with one-third membership elected every 2 years
Political parties and leaders: Liberal Party, Gerardo M. Roxas; Nacional ista
Party, Gil J. Puyat
Voting strength (1971): Senate -- Nacionalista Party, 15 seats; Liberal Party,
8 seats, 1 independent; House of Representatives -- Nacionalista Party, 92;
Liberal Party, 18
Communists: under 1,200 armed insurgents
Member of: ADB, ASEAN, ASPAC, Colombo Plan, ECAFE, IAEA, ICAO, IHB, Seabeds
Committee (observer), SEATO, U.N., UNESCO, UNICEF, WHO
Approved For Release 2004/09/15 : €94-RDP79-01051A000500010001-1
anton Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GNP: $7.5 billion (1971), $190 per capita
Agriculture: main crops -- rice, corn, coconut, sugarcane, abaca, tobacco
Fishing: catch 990,000 tons, $434 million (1970)
Major industries: agricultural processing, textiles, chemicals and chemical
products
Electric power: 2,755,000 kw. capacity (1972); 9.9 billion kw.-hr. produced
(1972), 251 kw.-hr. per capita
Exports: $1,033 million (f.0.b., 1971); copra, sugar, logs and lumber, coconut
oil, copper concentrates, abaca
Imports: $1,186 million (f.0.b., 1971)
Major trade partners: (1971) exports -- 42% U.S., 39% Japan; imports -- 24%
U.S., 30% Japan
Aid:
economic -- U.S. (FY46-71), $1.6 billion committed; Japan (reparations),
$550 million extended in 1956, $337 million drawn through July 1969; IBRD
(1953-71), $239 million committed;
military -- U.S. (FY46-70), $581 million committed
Monetary conversion rate: 6.77 pesos=US$1 (duly, 1972) (floating rate)
Fiscal year: 1 July - 30 June
Legal name: Polish People''s Republic (PRL)
Type: Communist state
Capital: Warsaw
Political subdivisions: 17 provinces, 5 city provinces, 391 districts
Legal system: mixture of Continental (Napoleonic) civil law and Communist legal
theory; constitution adopted 1952; court system parallels administrative
divisions with Supreme Court, composed of 104 justices, at apex; no
judicial review of legislative acts; legal education at 7 law schools; has
not accepted compulsory ICJ jurisdiction
Branches: legislative, executive, judicial system dominated by parallel
Communist Party apparatus
Government leader: Piotr Jaroszewicz, Premier; Henryk Jablonski, chairman
of Council of State (president)
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government every 4 years
Dominant political party and leader: Polish United Workers'' Party (PZPR)
(Communist) Edward Gierek, First Secretary
Voting strength (1972 election): 97% voted for Communist-approved single slate
Communists: 2,100,000 party members (September 1971)
Other political or pressure groups: National Unity Front (FUN), including United
Peasant Party (ZSL), Democratic Party (SD), progovernment pseudo-Catholic
Pax Association and Christian Social Association, Catholic independent Znak
group; powerful Roman Catholic Church, Stefan Cardinal Wyszynski, Primate
Member of: CEMA, GATT, ICAO, IHB, Indochina Truce Commission, Korea Truce
Commission, Seabeds Committee, U.N. and all specialized agencies except IMF
and IBRD, Warsaw Pact','25e7c62b6ff8b0ce92a9fec437f9fc0bb7332a49b723e615b7326c291a8d986c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b81fe92d26187eba79515a83f58aa004284798a2541a8f235f5207d4dc6a4aff',1973,'PT','Portugal','government',173,'Legal name: Republic of Portugal
Type: republic, with single legal party controlled by a Prime Minister
Capital: Lisbon
Political subdivisions: 18 districts in mainland Portugal and 4 "autonomous
districts" in Azores and Madeira Islands; 7 overseas provinces in Africa
and Asia including the state of Portuguese India whose 1961 occupation by
India is not recognized by Lisbon; Angola and Mozambique designated states
of Portugal in 1972
Legal system: civil law system; constitution adopted 1933, frequently amended
since; no judicial review of legislative acts; legal education at Universities
of Lisbon and Coimbra; accepts compulsory ICJ jurisdiction, with reservations
Branches: executive with President overshadowed by Prime Minister and Council of
Ministers; legislative with National Assembly dominated by executive and a
Corporative Chamber, the latter consultative and advisory; and judicial
controlled by executive branch
Government leader: Prime Minister Marcello Caetano, appointed September 1968
Suffrage: all citizens over age 21 who are literate and have not been deprived
of their civil rights
Elections: National Assembly, direct but government-controlled, held every 4 years,
next in October 1973; local direct parish board elections held every 4 years,
next in 1975; President, by government-controlled electoral college every
7 years, latest in July 1972
Political parties and leaders: government-controlled National Popular Action
(ANP) ~- formerly called National Union -- only legally recognized political
organization; insignificant Monarchist Cause group is tolerated by regime;
various opposition groups include -- Communist Party (PCP) whose secretary,
Alvaro Cunhal, is in exile; a dissident Communist exile group, Patriotic
Front of National Liberation (FPLN); and several small non-Communist groups
Approved For Release 2004/09/15 : CRAIRDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GOVERNMENT (cont''d):
Political parties and leaders (cont''d):
such as the moribund Democratic Social Action (ADS); Portuguese Socialist
Action (ASP) leader Mario Soares {in exile); extremist opposition group,
League of Revolutionary Union and Action (LUAR) has been dormant since 1970,
with leader, Herminio de Palma Inacio in exile abroad; Armed Revolutionary
Action (ARA) is radical and violence-prone group which appeared in October
1970, and has claimed credit for various sabotage acts and has ties with the
Portuguese Communist Party; self-styled Revolutionary Brigades with Maoist
orientation involved in several bombings in 1971 and 1972
Voting strength (1969 election): National Union, as ANP was then called, won all
130 seats in National Assembly in first contested election
Communists: 2,000-7,000 est.; sympathizers cannot be determined
Other political or pressure groups: Portuguese Legion, Portuguese Youth,
Association for the Study of Economic and Social Development (SEDES)
authorized in October 1970 as a discussion group with political overtones
Member of: EFTA, FAQ, IAEA, IBRD, ICAQ, IHB, ILO, IMF, ITU, NATO, OECD, Seabeds
Committee (observer), U.N., UPU, WHO, WMO
Legal name: Province of Guinea
Type: overseas province of Portugal
Capital: Bissau
Political subdivisions: 9 municipalities, 3 circumscriptions (predominantly
indigenous population)
Legal system: based on Portuguese law
Branches: Governor General appointed by Ministry of Overseas has wide local
authority; he is assisted by an appointed Secretary-General and an 8-man
Government Council; a 15-member Legislative Council, 11 of whose members
are elected by various groups, represents economic and tribal interests of
province; Minister of Overseas can nullify any provincial legislation or
Governor''s decision; judiciary based on Portuguese system
4 Government leader: Governor General and military commander is Gen. Antonio
Sebastiao Ribeiro de Spinola
Suffrage: limited to those satisfying fairly rigid economic and cultural
requirements
Political parties and leaders: National Popular Action (ANP) of Portugal only
legal party sends one representative to National Assembly in Lisbon; opposition
parties (illegal) include Partido Africano da Independencia da Guinee e Cabo
Verde (PAIGC), led by Amilcar Cabral, a Communist-supported nationalist party
which is chief political force conducting current rebellion against Portuguese
rule and which operates mainly from Republic of Guinea and the Republic of
Senegal; Front de Lutte pour 1''Independence Nationale de 1a Guinee (FLING),
a largely dormant, loose coalition of Senegal-based nationalist elements
opposed both to the Portuguese and the PAIGC, leadership fragmented, headed
by Benjamin Pinto-Bull; other nationalist factions
Communists: none known','74acc568abbf1dcf6900b79c0995db63e2aa71fa4286e7baec00c1bdd2ebbae7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be17decc38159e649856bacd8f3c69d181dea7765f6822a4fb8148bd308194af',1973,'QA','Qatar','government',177,'Legal name: State of Qatar
Type: traditional monarchy; independence declared in 197]
Capital: Ad Dawhah
Legal system: discretionary system of law controlled by the ruler, although new
civil codes are being implemented; Islamic law is significant in personal
matters; a constitution was promulgated in 1970
Government leader: Amir Khalifa ibn Hamad Al-Thani
Political parties and pressure groups: none; a few small clandestine organizations
are active
Branches: Council of Ministers
Member of: Arab League, U.N.','ed395e58ba56fad5a0d962d6e954720e3e0696b7330d01457d959fbb17a54b17','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7df3c9431e151c3db847b95e6cb31ce85444cada85a672c9c490768f9fe4d93a',1973,'IN','India','government',181,'Legal name: Overseas Department of Reunion
Type: overseas department of France; represented in French Parliament by three
Deputies and two Senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a Prefect appointed by the French Minister
of Interior, assisted by a Secretary-General and an elected 36-man General
Counci
Government leader: Prefect Paul Cousseran
Suffrage: universal adult
Elections: last municipal elections in 1971; parliamentary election June 1968
Political parties and leaders: Reunion Communist Party (RCP) led by Paul Verges,
only organized political movement on island; other political candidates
affiliated with metropolitan French parties, which do not maintain permanent
organizations on Reunion
Voting strength (parliamentary election 1968): Gaullist candidates swept all 3
districts
Communists: Communist Party small -- probably only 15-20 hard-line Communists --
but has support among sugarcane cutters and in Le Port district
Legal name: Colony of Southern Rhodesia
Type: self-proclaimed independent state since 1965 (not recognized by U.S.);
provisional settlement with U.K. in November 197] cancelled by U.K. in
May 1972 in response to Pearce Commission''s conclusion that its terms were
- unacceptable to the majority of black Rhodesians
Capital: Salisbury
Political subdivisions: 11 magisterial districts
Legal system: Smith government implemented a republican constitution on 2 March
1970 which institutionalized white rule
* Branches: President Dupont is ceremonial head of state; executive council
(cabinet) lead by Prime Minister Smith; National Assembly gives highly
disproportionate representation to white minority -- 50 white constituency
seats and 16 black constituency seats
Government leaders: Prime Minister Ian Smith and President Clifford Dupont
Suffrage: franchise is based on income, property holdings, and education; there
are separate rolls for Africans and non-Africans
Elections: must be held every 5 years
Political parties and leaders: Rhodesian Front, Prime Minister Smith; Centre
Party, Pat Bashford; African National Council], Abel Muzorewa
Voting strength (1970 elections): Rhodesian Front won all 50 white constituency
seats in Parliament
Communists: negligible
Other pressure groups and leaders: African nationalist organizations banned
from political activity -- Zimbabwe African People''s Union, Joshua Nkomo;
Zimbabwe African National Union, Ndabaningi Sithole; these leaders detained
by government; exiled leaders in Lusaka, Zambia, are Jasopo Moyo (ZAPU)
and Herbert Chitepo (ZANU); Front for the Liberation of Zimbabwe (FROLIZI),
James Chikerema and Nathan Shamuyarra
Member of: no international bodies
Legal name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 39 counties and 46 municipalities, including Bucharest
Legal system: mixture of civil law system and Communist Tegal theory which
increasingly reflects Romanian traditions; constitution adopted 1965; legal
education at University of Bucharest and two other law schools; has not
accepted compulsory ICJ jurisdiction
Branches: Council of Ministers; the Grand National Assembly, under which is
Office of Prosecutor General and Supreme Court; Council of State is a
collective head of state
Government leaders: Ion Gheorghe Maurer, President of the Council of Ministers,
head of government; Nicolae Ceausescu, President of Council of State,
titular head of state
Suffrage: universal over age 18, compulsory
Elections: elections in Romania held every 2 years for the local people''s
councils and every 4 years for Grand National Assembly deputies
Political parties and leaders: Communist Party of Romania only functioning party,
Nicolae Ceausescu, General Secretary
Voting strength (1969 election): overall participation reached 99,96%; of those
registered to vote (13,577,143), 99.75% voted for party candidates
Communists: 2,220,000 party members (April 1972)
Member of: CEMA, FAO, IAEA, ICAO, ILO, ITU, Seabeds Committee, U.N., UNESCO,
UPU, Warsaw Pact, WHO, WMO, GATT
Legal name: Republic of Rwanda
Type: republic, formerly combined with Burundi in U.N, trusteeship under Belgium;
became separate independent country in July 1962
Capital: Kigali
Political subdivisions: 10 prefectures, subdivided into 141 communes
Legal system: based on German and Belgian civil law systems and customary law;
constitution adopted 1962; judicial review of legislative acts in the
Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: executive consists of President, popularly elected for 4-year term,
and 14 cabinet ministers; single house 47-member National Assembly, popularly
elected for 4-year terms; 6-member Supreme Court appointed by President
Government leader: President Gregoire Kayibanda
Suffrage: universal and compulsory over age 18
Elections: last legislative election September 1969; president reelected September
1969; both elected for 4-year terms
Political parties and leaders: Party of the Hutu Emancipation Movement
(PARMEHUTU), led by President Gregoire Kayibanda, dominates at all levels
Communists: no communist party
Member of EAMA, EBRD, ICAO, ILO, IMF, ITU, OCAM, OAU, U.N., UNESCO, WHO, WMO
Legal name: State of St. Christopher-Nevis
Type: dependent territory with full internal autonomy as a British "Associated
State"; Anguilla formally seceded in May 1967 but has not been recognized
as an independent state by any government; in July 1968 a legislative
council headed by Ronald Webster was elected to govern Anguilla; in March
1969 the U.K. sent troops to Anguilla, placing the island again under
colonial rule; in 1971, Anguilla officially reverted to its former colonial
relationship with the U.K.
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law; constitution of 1960; highest judicial
organ is Court of Appeal of Leeward and Windward Islands
Branches: legislative, 10-member popularly elected House of Assembly; executive,
cabinet headed by prime minister
Government leaders: Premier, Robert L. Bradshaw; U.K. Governor, M. P. Allen
Suffrage: universal adult suffrage
Elections: at least every 5 years; most recent 10 May 1971
Political parties and leaders: St. Christopher-Nevis-Anguilla Labor Party, Robert
L. Bradshaw; People''s Action Movement (PAM), William Herbert; Nevis Reformation
Party (NFP), Igor Stevens
Voting strength (1971 election): St. Christopher-Nevis-Anguilla Labor Party won
7 seats in the House of Assembly, PAM won 2, 1 seat remains open for Anguilla
which did not participate in the election as a protest to United Kingdom''s
resumption of control over Anguilla
Communists: none known
Member of: CARIFTA
Legal name: State of St. Lucia
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Castries
Political subdivisions: 14 parishes
Legal system: based on English common law; constitution of 1960; highest judicial
body is Court of Appeal of Leeward and Windward Islands
Branches: legislative, 10-member popularly elected House of Assembly; executive,
cabinet headed by prime minister
Government leaders: Premier John Compton; U.K. Governor Frederick Clarke
Suffrage: universal adult suffrage
Elections: every 5 years; most recent April 1969
Political parties and leaders: United Worker''s Party (UNP), John Compton; St.
Lucia Labor Party (SLP), Martin Jean Baptiste; St. Lucia Labor Party United
Front (LPUF) led by George Charles
Voting strength (1969 election): UWP won 6 of the 10 elected seats in House of
Assembly; SLP won 3 seats; LPUF won 1 seat
Communists: negligible
Member of: CARIFTA
Legal name: State of St. Vincent
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Kingstown
Legal system: based on English common law; constitution of 1960; highest
judicial body is Court of Appeal of Leeward and Windward Islands
Government leader: Premier James F. Mitchell; Administrator (U.K.) Rupert John
Suffrage: universal adult suffrage
Elections: every 5 years; most recent 7 April 1972
Political parties and leaders: People''s Political Party (PPP), Ebenezer Joshua;
St. Vincent Labor Party (LP), R. Milton Cato
Voting strength (1972 election): LP 6 seats, PPP 6 seats, independent 1 seat in
the Legislative
Communists: negligible
Member of: CARIFTA
Legal name: Republic of San Marino
Type: republic (dates from 4th century A.D.); in 1862 the Kingdom of Italy
concluded a treaty guaranteeing the independence of San Marino; although
legally sovereign, San Marino is vulnerable to pressure from the Italian
Capital: San Marino
Political subdivisions: San Marino is divided into 9 sections: Guaita, Fratta,
Serravalle, Domagnano, Acquaviva, Fiorentino, Montegiardino, Faetano,
Chiesanuova
Legal system: based on civil law system with Italian law influences; electoral
law of 1926 serves some of the functions of a constitution; has not accepted
compulsory ICJ jurisdiction
Branches: the Grand and General Council is the legislative body elected by popular
vote; its 60 members serve 5-year terms; Council in turn elects two Captains -
Regent who exercise executive power for term of 6 months, the Council of
State whose members head government administrative departments and the Council
of Twelve, the supreme judicial body; actual executive power is wielded by
the Secretary of State for Foreign Affairs and the Secretary of State for
Internal Affairs
Government leaders: Secretary of State for Foreign Affairs Giancarlo Ghironzi
(Christian Democratic party); Secretary of State for Internal Affairs Gian
Luigi Berti (Christian Democratic party)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General Council required at least every
5 years; next elections 1974
Political parties and leaders: Christian Democratic party (DCS), Federico Bigi,
Giancarlo Social Democratic Party (PSDSM), Alvaro Casali; Socialist Party
(PSS), Ghironzi; Communist Party (PCS), Umberto Barulli
Voting strength (1969 election): 45% DCS, 25% PCS, 18.3% PSDIS, 11.7% PSS
Communists: approx. 300 members (number of sympathizers cannot be determined) ;
PCS is technically autonomous but in fact closely tied to Italian Communist
Party (PCI); PCS-PSS coalition dominated San Marino Government until 1957;
PSS, unlike its Italian counterpart, remains securely allied with PCS
Other political parties and pressure groups: political parties influenced by
policies of their counterparts in Italy, but the two Socialist parties are
not united as in Italy
Member of: ICJ, International Institute for Unification of Private Law,
International Relief Union, IRC, UPU
Approved For Release 2004/09/15 : CiA/RDP79-01051A000500010001-1
ECONOMY : Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Principal economic activities of San Marino are farming, livestock raising, light
manufacturing, and tourism; the government''s total budget for FY71 is about
$12 million, with the largest share of revenue derived from the sale of
postage stamps throughout the world and from payments by the Italian
government in exchange for Italy''s monopoly in retailing tobacco, gasoline,
and a few other goods; main problem is finding an additional $3 million to
finance badly needed water and electric power systems expansions
Agriculture: principal crops are wheat (average annual output about 4,400 metric
tana /yent) and grapes (average annual output about 700 metric tons/year) ;
other grains, fruits, vegetables, and animal feedstuffs are also grown;
livestock population numbers roughly 6,000 cows, oxen, and sheep; cheese
and hides are most important livestock products
Electric power: obtained from Italy
Manufacturing: consists mainly of cotton textile production at Serravalle, brick
and tile production at Dogane, cement production at Acquaviva, Dogane, and
Fiorentino, and pottery production at Borgo Maggiore; some tanned hides,
paper, candy, baked goods, Moscato wine, and gold and silver souvenirs are
also produced
Foreign transactions: dominated by tourism; in summer months 20,000 to 30,000
foreigners visit San Marino every day; a number of hotels and restaurants
have been built in recent years to accommodate them; remittances from
Sanmarinese abroad also represent an important net foreign inflow; commodity
trade consists primarily of exchanging building stone, lime, wood, chestnuts,
wheat, wine, baked goods, hides, and ceramics for a wide variety of consumer
manufactures
Legal name: Kingdom of Saudi Arabia
Type: monarchy
Capital: Riyadh; foreign ministry and foreign diplomatic representatives located
in Juddah
Political subdivisions: 18 amirates
Legal system: largely based on Islamic law, several secular codes have been
introduced; commercial disputes handled by special committees; has not
accepted compulsory ICJ jurisdiction
Branches: King Faysal (Al Saud, Faysal ibn Abd al-Aziz) rules in consultation
with ruling family, Council of Ministers, and religious leaders
Government leader: King Faysal
Communists: negligible
Member of: Arab League, FAO, IAEA, IATA, IBRD, ICAO, IDA, IFC, IMF, ITU, OAPEC,
OPEC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Senegal
Type: republic; only one legal party since 1966
Capital: Dakar
Political subdivisions: 7 regions, each subdivided into 18 departments, 90
districts, and 34 communes
Legal system: based on French civil law system; laws dealing with marriage,
inheritance, succession, etc., based on Islamic law with elements of
traditional practices; constitution adopted 1960, revised 1963 and 1970;
judicial review of legislative acts in Supreme Court (which also audits
the government''s accounting office); legal education at University of Dakar;
has not accepted compulsory ICJ jurisdiction
Branches: Government dominated by President who is assisted by Prime Minister,
appointed by President and subject to dismissal by President or censure by
National Assembly; 80-member National Assembly, elected for 5 years
(effective 1968); President elected for 5-year term (effective 1968) by
universal suffrage; judiciary headed by Supreme Court, with members appointed
by President
Government leaders: Leopold Sedar Senghor, President; Abdou Diouf, Prime Minister
Suffrage: universal adult
Political parties and leaders: Union Progressiste Senegalaise (UPS), ruling
party led by President Leopold Senghor, has absorbed all major opposition
parties; illegal parties include Communist-backed Parti Africain
de 1''Independence (PAI) and Parti Conmuniste Senegalais (PCS) a splinter group
Elections: single party (UPS) presidential and legislative elections held
February 1973
Communists: a few Communists and sympathizers; PAI is pro-Moscow; PCS is pro-Peking
Member of: ADB, EAMA, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, La
Francophonie, OCAM, Organization for the Development of the Senegal River
(OMVS), U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2004/09/15 : CIALRDP79-01051A000500010001-1
ECONOMY : Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GDP: $746 million (1971); $190 per capita; real growth rate less than 1% (1966-71)
Agriculture: main crops -- peanuts, millet, sorghum, manioc, rice; peanuts
primary cash crop; production of food crops increasing but still
insufficient for domestic requirements
Fishing: catch 220,000 metric tons (1971); exports $12 million (1971),
imports (not available)
Major industries: fishing, agricultural processing plants, light manufacturing,
mining
Electric power: 145,000 kw. capacity (1971); 6,804 million kw.-hr. produced (1971),
1,195 kw.-hr. per capita
Exports: $125 million (f.0.b., 1971); approx. 33% peanuts and peanut products;
Phosphate rock; canned fish
Imports: $218 million (f.o.b., 1971); food, consumer goods, machinery, transport
equipment
Major trade partners: France, EC (other than France), and franc zone
Aid: economic -- France (1966-70) $115 million; U.S. (1961-70) $39.1 million;
U.S.S.R. $6.7 million loan negotiated; EC (1962-71) $116.1 million;
military -- U.S. (FY61-71) $2.8 million
Monetary conversion rate: 1 Conmmunaute Financiere Africaine franc=0.02 French
francs; 255.78 CFA francs=US$1
Fiscal year: 1 July - 30 June
Political subdivisions: none known
Legal system: no constitution
Branches: 6-man Executive Council or cabinet appointed by ruler; 24 member State
Council with limited legislative functions; 6 members are appointed, with
remainder apportioned to various ethnic groups on basis of complex electoral
system
Government leader: Maharaja Paldem Thondup Namgyal, known as the Chogyal of
- Sikkim
Suffrage: specifics unknown
Elections: popular elections held on an irregular schedule 4 times since 1958
Political parties and leaders: Sikkim National Congress Party; Sikkim National
Party; Sikkim State Congress; Janta Party
’ Communists: no overt presence','4465ae63acef44d342d3eb31daf472753c4dead4aa85f616fcee469c85b900f4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c93caa3fa9cb3cf0d5b3b25faaf080bad1b4628d811c2c95e45b2c47ebee22cf',1973,'SC','Seychelles','government',185,'Legal name: Colony of the Seychelles
Type: British crown colony
Capital: Victoria, Mahe Island
Legal system: based on English common law, French civil law system, and
customary law
Branches: Governor, Council of Ministers, Legislative Assembly
Government leader: Governor Sir Bruce Greatbatch
Suffrage: universal adult
Elections: November 1970
Political parties and leaders: Seychelles Democratic Party (SDP), James R.
Mancham, President; Seychelles Peoples United Party (SPUP), France
Albert Rene, President
Voting strength: SDP won 4 seats on Governing Council with 52.8% popular vote
in 1970 election; SPUP won 5 seats with 47.2% of votes
Communists: negligible
Other political or pressure groups: trade unions which are appendages of
political parties','0a6c9188866fd10ed86573eba5398f74447c369571e9747304b0094071133cdc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4b4528d88c90fdf16b21072323347e6ff875a251a6c4973ead635157fe76188',1973,'SL','Sierra Leone','government',189,'Legal name: Republic of Sierra Leone
Type: republic under presidential regime since April 1971
Capital: Freetown
Political subdivisions: 3 provinces; divided into 12 districts with 146 chief-
doms, where paramount chief and council of elders constitute basic unit of
government; plus western area, which comprises Freetown and other coas tal
areas of the former colony
Legal system: based on English law and customary laws indigenous to local
tribes; constitution adopted April 1971; highest court of appeal is the
Sierra Leone Court of Appeals; has not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by President; parliament consists of 78
members, 66 of whom are elected representatives and 12 paramount chiefs
representing tribal councils in provincial districts; independent judiciary
Government leader: Siaka Stevens, President, heads APC government composed
of members of his political party
Elections: the maximum life of an elected parliament is 5 years, but it may be
dissolved earlier by the President; next parliamentary election in 1973;
ee is elected by parliament for 5 year term; next presidential election
Political parties and leaders: All People''s Congress (APC), headed by Stevens;
Sierra Leone People''s Party (SLPP) is the opposition party
’ Communists: no party, although there are a few Communists and a slightly larger
number of sympathizers
Member of: ADB, Commonwealth, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Sikkim
Type: autonomous protectorate of India ruled by a hereditary maharaja; according
to 1950 Indo-Sikkim Treaty, the ruler is responsible for internal affairs;
external relations, defense, and communications are conducted solely by','3ecf11de2e69abb04b9b1686c97d97276045c8571dfaf78ac00066cf28bea015','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dca0f07e4d410f3b094720ec5839121594215772207847fe0879d14c360b910',1973,'SG','Singapore','government',193,'Legal name: Republic of Singapore
Type: republic within Commonwealth since separation from Malaysia in August 1965
Capital: Singapore
Legal system: based on English common law; constitution based on preindependence
State of Singapore constitution; legal education at University of Singapore;
has not accepted compulsory ICJ jurisdiction
Branches: ceremonial President; executive power exercised by Prime Minister and
cabinet responsible to unitary legislature
Government leaders: President, Dr. Benjamin Sheares; Prime Minister, Lee Kuan Yew
’ Suffrage: universal over age 20; voting compulsory
Elections: normally every 5 years
Political parties and leaders: government -- People''s Action Party (PAP), Lee
Kuan Yew; opposition -- Barisan Sosialis Party (BSP), Dr. Lee Siew Choh;
Workers'' Party, J.B. Jeyaretnam; Communist Party illegal
Voting strength (1972 election): PAP won all 65 seats in parliament and received
70% of vote; remaining 30% to four opposition parties
Communists: 200-500; Barisan Sosialis Party infiltrated by Communists
Member of: ASEAN, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, U.N., UNESCO, UPU, WHO,
WMO
Legal name: Somali Democratic Republic
Type: republic; under military rule since October 1969
Capital: Mogadiscio
Political subdivisions: 8 regions, 48 districts
Organization: the junta has assumed all authority, calling itself the Supreme
Revolutionary Council, membership of which consists of 18 army and 3 police
officers; the Council has abrogated the constitution, dissolved the parliament,
and banned political parties
Government leader: President of the Supreme Revolutionary Council, Gen. Mohamed
Siad Barre
Communists: possibly some Communist sympathizers in the government hierarchy
Member of: EAMA, FAO, IBRD, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UNICEF, UPU,
WHO','35ae40eeae94a3a7a6472b01c7997569f16aacf62c7e112036128cc68bde1122','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06f4f9526f865650e94ed20b89d224b58f8af9cf94a5a1831c5b1885227bf6cd',1973,'ZA','South Africa','government',197,'Legal name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative, Cape Town; judicial, Bloemfontein
5 Political subdivisions: 4 provinces, each headed by centrally appointed
administrator; provincial councils, elected by white electorate, retain
limited powers
Legal system: based on Roman-Dutch law and English common law; constitution
enacted 1961, changing the Union of South Africa into a Republic; possibility
a of judicial review of Acts of Parliament concerning dual official languages;
accepts compulsory ICJ jurisdiction, with reservations
Branches: President as formal chief of state; Prime Minister as head of
government; Cabinet responsible to bicameral legislature; lower house
elected directly by white electorate; upper house indirectly elected and
appointed; judiciary maintains substantial independence of government
influence
Government leader: Prime Minister Balthazar J. Vorster
Suffrage: general suffrage limited to whites over 18 (17 in Natal Province)
Elections: must be held at least every 5 years; last elections April 1970
Political parties and leaders: National Party, B. J. Vorster, P. W. Botha,
C. Mulder, M. C. Botha, Jan De Klerk; United Party, Sir De Villiers
Graaff; Progressive Party, Colin Eglin, Helen Suzman; Herstigte Nasionale
Party, Albert Hertzog, Jaap Marais
Voting strength (1970 general elections): of 166 legislative seats, National
Party 118, United Party 47, Progressive Party 1
Communists: small Communist Party illegal since 1950; party in exile maintains
headquarters in London; Dr. Yasuf Dadoo, Michael Harmel, Joe Slovo
Other political groups: (insurgent groups in exile) African National Congress (ANC),
Oliver Tambo; Pan-Africanist Congress (PAC), leadership in dispute
Member of: IAEA, IBRD, ICAO, IHB, IMF, ITU, Seabeds Conmittee (observer), U.N.,
UPU, WHO, WMO
Approved For Release 2004/09/15 :3¢8A-RDP79-01051A000500010001-1
ECONOMY: Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GNP: $18.4 billion (1971), $840 per capita; real growth rate 3.6% (1971)
Agriculture: main crops -- corn, wool, dairy products, wheat, sugarcane,
tobacco, citrus fruits; self-sufficient in foodstuffs
Fishing: catch 1,519,000 metric tons (1970); exports $21 million (1971), imports
$10 million (1971)
Major industries: mining, automobile assembly, metal working, machinery,
textiles, iron and steel, chemical, fertilizer, fishing
Electric power: 57,000 kw. capacity (1971); 154 million kw.-hr. produced
(1971), 58 kw.-hr. per capita
Exports: $2.1 billion (f.o.b., 1971 excluding gold); wool, diamonds, corn,
uranium, sugar, fruit, hides, skins, metals, metallic ores, asbestos,
fish products; gold output $1.3 billion (1971)
Imports: $14.0 billion (f.0.b., 1971); motor vehicles, machinery, metals,
petroleum products, textiles, chemicals
Major trade partners: U.K. and other Commonwealth nations, U.S., Germany, Japan
Aid: no substantial military or economic aid
Monetary conversion rate: 1 SA Rand=US$1.25 (South Africa''s currency is linked
to the floating U.K. pound; the Rand exchange rate fluctuated in the range
of $1.24-$1.26 during July-September 1972); 0.800 SA Rand=US$1
Fiscal year: 1 April - 31 March
Legal name: Territory of South-West Africa
Type: administered as part of Republic of South Africa, under a League of
Nations mandate; U.N. formally ended South Africa''s mandate, and status now
in dispute
Capital: Windhoek
Political subdivisions: police zone (police-protected area, consisting of 17
magisterial districts, in which all-white settlement and several Bantu
reserves are found), northern territories (exclusively Bantu magisterial
districts under control of officials of South African Department of Bantu
Administration and Development)
Legal system: based on Roman-Dutch Taw and customary law
Branches: administrator, appointee of South African Government, principal
local executive; structure similar to that of a province of the Republic;
South-West Africa elects 4 Senators and 6 lower house members to the
Republic''s legislature; judicial system patterned on that of Republic
Government leader: B.J. van der Walt, Administrator
Suffrage: limited to white adults
Elections: last general election, 1970
Political parties and leaders: white parties -- National Party (NP), led in
South-West Africa by A. H. du Plessis; United National South-West Party
(UNSWP), J. P. Niehaus; nonwhite parties -- South-West Africa People''s
Organization (SWAPO), almost exclusively based on Ovambo tribe led by Sam
Nujoma, in exile; South-West Africa National Union (SWANU), primarily based
on Herero tribe, leaders in exile; National Unity Democratic Organization
(NUDO), primarily based on Herero tribe led by Clements Kapuuo
Voting strength: NP (1970 election) won all 10 seats in Republic legislature
and all 18 seats in South-West Africa Legislative Assembly
Communists: no Communist Party, but some influence by South African Communists
and other Communists on South-West African Bantu outside territory
Approved For Release 2004/09/15 : ClR-RDP79-01051A000500010001-1
ECONOMY : Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Agriculture: livestock raising (cattle and en predominates, subsistence
crops (millet, sorghum, corn, and some wheat) are raised but most food
must be imported
Fishing: catch 586,600 metric tons (1971) (processed mostly in South African
enclave of Walvis Bay)
Major industries: meatpacking, fish processing, copper, lead, and diamond
mining, dairy products
Electric power: 95,200 kw. capacity (1971); 295 million kw.-hr. produced (1971),
470 kw.-hr. per capita
Aid: South Africa is only major donor
Monetary conversion rate: 1 South African Rand=US$1.25 (South Africa''s currency
is linked to the floating U.K. pound; the Rand exchange rate fluctuated in
the range of $1.24-$1.26 during July-September 1972); 0.800 SA Rand=US$1
Fiscal year: 1 April - 31 March','a11ed1aa1a8084716da4a89a3a649ade9075fb652add23c176a7ae1a17642767','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22cdb3c77499f4a236b4df99549c637b2a779d814b25ce758361ac73b3f51fd2',1973,'ZM','Zambia','government',200,'Legal name: Republic of Zambia
Type: republic since October 1964
Capital: Lusaka
Political subdivisions: 8 provinces
Legal system: based on English common law and customary law; constitution adopted
1972; judicial review of legislative acts in an ad hoc constitutional
council; legal education at University of Zambia in Lusaka; has not accepted
compulsory ICJ jurisdiction
Branches: modified presidential system; unicameral legislature; judiciary
Government leader: President Kenneth Kaunda; prime minister to be appointed
by President
Suffrage: universal adult
Elections: last general election December 1968
Political parties and leaders: United National Independence Party (UNIP),
Kenneth Kaunda
Voting strength (1968 election): UNIP had 73% of vote, but 30 of its candidates
were unopposed; strength probably would have been over 80% if these seats
had been contested; adopted single party system of government in 1972
Communists: no Communist Party, but sympathizers of socialism in upper levels
of government, UNIP, and labor unions
Member of: Commonwealth, FAO, IAEA, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU, U.N.,
UNESCO, UPU, WHO, WMO','5602270c3b5966d3e4a3e3121c567a07d9d85941895cb35c39d76c25143b321a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f644499829ee632bdb7ae39ab928fccfae724745a42ee9282c01cd127943573',1973,'US','United States','government',204,'Legal name: United States of America
Legal system: based on English common law; dual system of courts, state and
federal; constitution adopted 1789; judicial review of legislative acts;
accepts compulsory ICJ jurisdiction, with reservations
Voting strength (1968 presidential election): Republican Party (Nixon),
31,770,237; Democratic Party (Humphrey), 31,270,533; Independent (Wallace),
9,897,141; minor parties, 239,910
Communists: Party membership, 10,000-11,000 (est.); General Secretary, Gus Hall
Member of: ADB, ANZUS, CENTO, Colombo Plan, FAO, GATT, IAEA, IBRD, ICAO, IDA,
IDB, IFC, ILO, IMCO, IMF, ITU, NATO, OAS, OECD, SEATO, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO','d03998d4034ca110b57c4cdb53c020150c090d49deb34925ddb92f4397a8ba4c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('270e39d154f38331c7d3c57cf4e936133e4e8354434112385c0d5b35645390c4',1973,'','','government',3,'Legal name: Kingdom of Afghanistan
Type: constitutional monarchy
Capital: Kabul
Political subdivisions: 28 provinces with centrally appointed governors
% Legal system: based on Islamic law; constitution adopted 1964; although provided
for in the law on judicial organization, there has as yet been no judicial
review of legislative acts; legal education at University of Kabul; has not
accepted compulsory 1CJ jurisdiction
Branches: bicameral legislature with cabinet responsible to lower house (People''s
Council); although elected Parliament is exerting increasing influence, it
has not as yet passed much significant legislation or established effective
control over the central ized administration and has no real voice in military
matters; progressive forces led by King liberalizing the regime; independent
judiciary established in 1967, has not yet had a major institutional impact;
it is too early to assess its future role
Government leaders: King Mohammad Zahir Shah; Prime Minister Mohammad Musa Shafig
Suffrage: universal over age 20
Elections: next election to be held in August and September 1973; lower house of
Parliament (216 deputies) and one-third (28 Senators) of upper house (Council
of Elders) elected for 4-year terms; 28 Senators appointed by King; remaining
28 Senators to be elected by Provincial Councils when formed
Political parties and leaders: no political parties permitted yet, but enabling
legislation has been passed by Parliament and awaits the King''s signature;
several groups have begun to meet informally, extremists of left and right
best organized
Communists: there are 2 pro-Moscow Communist groups, with about 350-500 active
members; several other groups, further to left, with several hundred members
and sympathizers
Other political or pressure groups: progressive forces led by King Zahir and
s cabinet dominate current situation with nascent leftist and rightist groups
forming for action when parties are permitted
Member of: ADB, Colombo Plan, FAO, FUND, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO,
ITU, U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','835ff1d064a9c29fcbcc0e5dce9307939708277da2a69cb6c18d57af588779c2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('128634bd7b8271c757439326c38f59bc3260755f899632f994ac4af099240408',1973,'AL','Albania','government',7,'Legal name: People''s Republic of Albania
Type: Communist state
Capital: Tirane
Political subdivisons: 27 rethet (districts), including capital, 200 localities,
2,600 villages
Legal system: based on Soviet law; constitution adopted 1950; judicial review
of legislative acts only in the Presidium of the People''s Assembly, which
4s not a true court; legal education at State University of Tirane; has not
accepted compulsory CJ jurisdiction
Branches: People''s Assembly, Council of Ministers, judiciary
Government leaders: Chairman of Council of Ministers, Mehmet Shehu; President,
Presidium of the People''s Assembly, Haxhi Lleshi
Suffrage: universal and compulsory over age 18
Elections: national elections theoretically held every 4 years; last elections
September 1970
Political parties and leaders: Albanian Workers Party only; First Secretary,
Enver Hoxha
Voting strength (1970 election); 99.9% Communist
Communists: 75,637 party members (1970)
Member of: CEMA, IAEA, ILO, ITU, U.N., UNESCO, UPU, WHO, WMO; has not participated
an CEMA since rift with U.S.S.R. in 1961; officially withdrew from Warsaw
Pact 13 September 1968','0af246f588db973e1fa93a635e38be4b351d7e07d9cc4f31cd500d4394f47710','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84d8ec92640e442a49e5af49d0b3c738c2df5deaf7493565d9a151034e528296',1973,'DZ','Algeria','government',11,'Legal name: Democratic and Popular Republic of Algeria
Type: republic
Capital: Algiers
Political subdivisions: 15 Wilayas (departments or provinces)
Legal system: based on French and Islamic law, with socialist principles;
constitution adopted by referendum 1963 but suspended since June 1965;
judicial review of legislative acts in ad hoc Constitutional Council composed
of various public officials, including several Supreme Court justices; Supreme
Court divided into 4 chambers; legal education at Universities of Algiers,
Oran and Constantine; has not accepted compul sory IcJ jurisdiction
Branches: executive dominant, unicameral legislature has not met since June
1965 coup d''etat but was never formally suspended, judiciary
Government leader: Houari Boumediene, President of Council of the Revolution
and President of the Council of Ministers, overthrew elected President
Ahmed Ben Bella 19 June 1965
Suffrage: universal over age 19
Elections: presidential 15 September 1963; departmental assemblies 25 May 1969;
local councils 14 February 1971
Political parties and leaders: National Liberation Front (FLN), Ahmed Kaid
Voting strength (1963 election): 100% FLN
Communists: 400 (est.); Communist Party illegal (banned 1962)
Member of: Arab League, FAO, IAEA, IBRD. ICAO, IDA, ILO, IMCO, IMF, ITU, OAU,
OPEC, U.N., UNESCO, UPU, WHO
Legal name: The Valleys of Andorra
Capital: Andorra
Political subdivisions: 6 districts -- Andorra la Vella, Sant Julia de Loria,
Encamp, Canillo, La Massana, and Ordino ;
Type: unique coprincipal ity under formal sovereignty of President of France and
Spanish Bishop of Seo de Urgel, who are represented locally by officials
called veguers
Legal system: based on French and Spanish civil codes; Plan of Reform adopted
1866 serves as constitution; no judicial review of legislative acts; has
not accepted compulsory ICd jurisdiction
Branches: legislature (General Council) of 24 members with one-half elected
every 2 years for 4-year term; executive -- syndic and a deputy sub-syndic
. chosen by General Council for 3-year terms; judiciary chosen by coprinces
who appoint 2 civil judges, a judge of appeals, and 2 Batles (court
prosecutors)
Suffrage: males of 21 or over who are third generation Andorrans vote for
General Council members; same right granted to women in April 1970
. Elections: half of General Council chosen every 2 years, last election December
1971
Political parties and leaders: no political parties but only partisans for
particular independent candidates for the General Council, on the basis of
competence, personality and orientation toward Spain or France; various small
pressure groups developed in 1972
Communists: none known
Legal name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: 9 provinces
Legal system: civil law system influenced by English constitutional theory;
constitution adopted 1831, since amended; judicial review of legislative
acts; legal education at 4 law schools; accepts compulsory ICJ jurisdiction,
with reservations :
Branches: executive branch consists of King and cabinet; cabinet responsible to
bicameral parliament; independent judiciary; coalition governments are usual
Government leader: Head of State, King Baudouin; Prime Minister Edmond Leburton
Suffrage: universal over age 21
Elections: held 7 November 1971 (held at least once every 4 years)
Political parties and leaders: Social Christian, Charles-Ferdinand Nothomb and
Wilfred Marteus, co-presidents; Socialist, Andre Cools and Joris Van
Eynde, co-presidents; Liberty and Progress, Senator P. Descamps, party
president; Francophone Democratic Front-Walloon Rally (Walloon nationalist),
Jean Duvieusart, party president; Volksunie (Flemish Nationalist), Wim
Jorrisen, party president; Communist, Marc Drumeaux, president of political
bureau
Voting strength (1971 election): 67 seats Social Christian, 61 seats Socialist,
34 seats Liberty and Progress, 21 seats Volksunie, 21 seats Francophone
Democratic Front-Walloon Rally, 5 seats Communist
Communists: 12,000 members; pro-Peking splinter groups, 400
Other political or pressure groups: Christian and Socialist Trade Unions; the
Federation of Belgium Industries; numerous other associations representing
bankers, manufacturers, middle-class artisans, and the legal and medical
professions; two major organizations represent the cultural interests of
Flanders and Wallonia
Member of: Benelux, BLEU (Belgium-Luxembourg Economoc Union), Council of Europe,
ECE, ECOSOC, EC, EMA, FAO, IAEA, ICAO, IMF, NATO, OECD, Seabeds Committee,
U.N., UNESCO, WEU, WHO
29
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: Belize
Type: former British crown colony; obtained full internal self-government in
January 1964
Capital: Belize City; seat of government in Belmopan
Legal system: English law; constitution came into force in 1964, although
country remains a British colony
Branches: 18-member elected National Assembly and 8-member Senate (either house
may choose its speaker or president, respectively, from outside its
elected membership); cabinet; judiciary
Government leader: Premier George Price
Suffrage: universal adult (probably 21)
Elections: within 5 years of last general election held 5 December 1969
Political parties and leaders: People''s United Party (PUP), George Price;
National Independence Party (NIP), Philip Goldson; People''s Development
Movement (PDM), Dean Lindo; United Black Association for Development (UBAD),
Evan Hyde
Voting strength (1969 election): 57.6% PUP, 39.8% NIP, 2.6% void ballots
Communists: none identified
Other political or pressure groups: Christian Workers'' Union (CWU) which is
connected with PUP
Legal name: German Democratic Republic
Type: Communist state
Capital: East Berlin (not officially recognized by U.S., U.K.. and France, which
together with the U.S.S.R. have special rights and responsibilities in Berlin)
Political subdivisions: (excluding East Berlin) 14 districts (Bezirke), 218
counties (Kreise), 8,845 communities (Gemeinden)
Legal system: Civil law system modified by Communist legal theory; new constitution
adopted 1968 by approx. 95% of the voters in national “referendum;" court
system parallels administrative divisions; no judicial review of legislative
acts; legal education at Universities of Berlin, Leipzig, Halle and Jena;
has not accepted compulsory ICJ jurisdiction; more stringent penal code
adopted 1968
Branches: legislative -- Volkskammer (elected directly); executive -- Chairman
of Council of State, Chairman of Council of Ministers, Cabinet (elected by
Volkskammer); judiciary -- Supreme Court; entire structure dominated by
Socialist Unity (Communist) Party
Government leaders: Chairman, Council of State, Walter Ulbricht (Head of State);
Chairman, Council of Ministers, Willi Stoph (Head of Governnient)
Suffrage: all citizens age 18 and over
Elections: national and local alternating every 2 years; prepared by an electoral
commission of the National Front; ballot supposed to be secret and voters
permitted to strike names off ballot; more candidates than offices available;
parliamentary elections held 14 November 1971; local elections, 22 March 1970
Political parties and leaders: Socialist Unity (Communist) Party (SED), headed
by First Secretary Erich Honecker, dominates the regime; 4 token parties
(Christian Democratic Union, National Democratic Party, Liberal Democratic
Party, and Democratic Peasants'' Party) and an amalgam of special interest
organizations participate with the SED in National Front
Voting strength: 1971 parliamentary elections: 98.33% voted the regime slate; 1970
local elections: 99.85% voted the regime slate
Communists: 1.9 million party members
Other special interest groups: Free German Youth, Free German Trade Union
Federation, Democratic Women''s Federation of Germany, German Cultural
Federation (all Communist dominated)
Member of: CEMA, IPU, Warsaw Pact; observer status in U.N.
119
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law, substantially modified by indigenous
concepts; constitution adopted 1937; judicial review of legislative acts in
Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: elected President; bicameral parliament reflecting proportional and
vocational representation; judiciary appointed by President on advice of
Government leaders: Taoiseach (Prime Minister) Liam Cosgrave (Fine Gael);
Tanaiste (Deputy Prime Minister) Brendan Corish (Labor)
Suffrage: universal over age 18
Elections: Dail (lower house) elected every 5 years -- last election February
1973; President elected for 7-year term -- next election May 1973
Political parties and leaders: Fianna Fail, John (Jack) Lynch; Labor Party,
Brendan Corish; Fine Gael, Liam Cosgrave; Communist Party of Ireland,
Michael O''Riordan
Voting strength: Fianna Fail 46% (69 seats), Fine Gael 35% (54 seats), Labor Party
14% (19 seats), other 5%; Independents hold 2 seats
Communists: approximately 300
Member of: Council of Europe, EC, FAO, IBRD, ICAO, ILO, IMCO, IMF, ITU, OECD, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution provides for establishment of 20 regions;
5 (Sicilia, Sardegna, Trentino-Alto Adige, Friuli-Venezia Giulia, and Valle
d''Aosta) have been functioning for some time and the remaining 15 regions
were instituted on 1 April 1972; 94 provinces
Legal system: based on civil law system, with ecclesiastical law influence;
constitution came into effect 1 January 1948; judicial review under certain
conditions in Constitutional Court; has not accepted compulsory ICJ jurisdiction
Branches: executive -- President empowered to dissolve Parliament and call national
election; he is also Commander of the Armed Forces and presides over the
Supreme Defense Council; otherwise, authority to govern invested in Council
of Ministers; legislative power invested in bicameral, popularly elected
Parliament; Italy has an independent judicial establishment
Government leaders: President Giovanni Leone; Premier Giulio Andreotti
Suffrage: universal over age 21 (except in Senatorial elections where minimum
age of voter is 25
Flections: national elections for Parliament held every 5 years (most recent,
May 1972); provincial and municipal elections held every 5 years with some
out of phase; regional elections every 5 years
Political parties and leaders: Christian Democratic Party (DC), Arnaldo Forlani
(party secretary) Giulio Andreotti Aldo Moro, Amintore Fanfani (Senate
President); Communist Party (PCI), Luigi Longo, Enrico Berlinguer; Italian
Socialist Party (PSI), Pietro Nenni (ex-party secretary), Giacomo Mancini,
Francesco De Martino; Italian Social Democratic Party (PSDI), Flavio Orlandi
Liberal Party (PL1), Giovanni Malagodi; Italian Social Movement (MSI),
Giorgio Almirante; Republican Party (PRI), Ugo La Malfa
Voting strength (1972 election): 38.8% DC, 27.2% PCI, 9.6% PSI, 3.9% PLI, 8.7%
MST, 2.9% PRI, 5.1% PSDI, 3.8% other
163
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Communists: 1,580,000 (as of 1 October 1972) members; number of sympathizers
cannot be determined
Other political or pressure groups: the Vatican; three major trade union
confederations (CGIL -- Communist dominated, CISL -- Christian Democratic,
and UIL -- Social Democratic and Republican); Italian manufacturers
association (Confindustria); organized farm groups
Member of: ECSC, EC, FAO, IBRD, ICAO, IAEA, THB, ILO, IMCO, IMF, ITU, NATO,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Ivory Coast
Type: republic, one-party presidential regime established 1960
Capital: Abidjan
Political subdivisions: 24 departments subdivided into 127 subprefectures
Legal system: based on French civil law system and customary law; constitution
adopted 1960, amended 1963; judicial review in the Constitutional Chamber
of the Supreme Court; legal education at Abidjan School of Law; has not
accepted compulsory ICJ jurisdiction
Branches: President has sweeping powers, unicameral legislature, separate judiciary
Government leader: President Felix Houphouet-Boigny
Suffrage: universal over age 21
Elections: uncontested Presidential and legislative elections held in November
1970 for 5-year term
Political parties and leaders: Parti Democratique de la Cote d''Ivoire (PDCI),
(only party); official party leader is Secretary General Philippe Yace, but
Houphouet-Boigny is in control
Communists: no Communist partyp; possibly some sympathizers
Member of: ACCT, AFDB, CEAO, EAMA, ECA, Entente, FAQ, IAEA, IBRD, ICAO, ILO, IMCO,
IMF, ITU, Niger River Commission, OAU, OCAM, U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of the Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government resides at The Hague
Political subdivisions: 11 provinces governed by centrally appointed commissioners
of Queen
Legal system: civil law system incorporating French penal theory; constitution
of 1815 frequently amended, reissued 1947; judicial review in the Supreme
Court of legislation of lower order than Acts of Parliament; legal education
at six law schools; accepts compulsory ICJ jurisdiction, with reservations
Branches: executive, (Queen and Cabinet of Ministers), which is responsible to
bicameral states general (parliament); independent judiciary
Government leader: Head of State, Queen Juliana; Barend Willem Biesheuvel, Prime
Minister (in caretaker status since the national elections of November 1972)
Suffrage: universal over age 21
Elections: must be held at least every 4 years for lower house (most recent
November 1972), and every 3 years for upper house (most recent April 1971)
Political parties and leaders: Catholic People''s Party (KVP), Dr. D. de Zeeuws
Antirevolutionary (ARP), A. Veerman; Labor (PvdA), Andre van der Louw; Liberal
(VVD), Mrs. H. van Someren-Downer; Christian Historical Union (CHU),
Baron Otto Willem Anton van Verschuer; Democrats ''66 (D-66), J. ten Brink;
Communist (CPN), Henk Hoekstra; Pacifist Socialist (PSP); A. G. Vander Spek;
Political Reformed (SGP), H. G. Abma; Reformed Political Union (GVP), W. G.
Beeftink; Radical Party (PPR), Dolf Coppes; Democratic Socialist''70 (DS-70),
Jonkheer M. L. de Braew; Farmers'' Party (BP), leader unknown; Roman Catholic
Party (RKP), leader unknown
Voting strength (1972 election): 17.7% KVP, 14.4% WD, 8.8% ARP, 4.8% CHU, 27.4%
PyvdA, 4.2% D-66, 4.1% DS-70, 4.5% CPN, 1.5% PSP, 4.8% PRP, 2.2% SGP, 1.8% GVP,
1.9% BP, .9% RKP
Communists: 9,000 members; 329,973 votes in 1972 election
Other political or pressure groups: great multinational firms; Socialist, Catholic,
and Protestant trade unions; Federation of Catholic and Protestant Employers
Associations; the non-demoninational Federation of Netherlands Enterprises
235
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Member of: Benelux, Council of Europe, ECE, ECSC, EC, EMA, EURATOM, FAQ, IAEA,
TBRD, ICAQ, IHB, IMF, NATO, OECD, Seabeds Committee (observer), U.N., UNESCO,
WEU. WHO
Legal name: (The) Spanish State
Type: nominally a monarchy, but without a king; actually a dictatorship under
Generalissimo Franco with Prince Juan Carlos designated to succeed him as
chief of state and become king
Capital: Madrid
Political subdivisions: metropolitan Spain, including the Canaries and Balearics,
divided into 50 provinces with governors appointed by the central government;
also 1 province and 5 places of sovereignty (presidios) in Africa; Ifni
province ceded by Spain to Morocco in June 1969; 2 former provinces com-
prising Equatorial Guinea were granted independence in October 1968
Legal system: civil law system, with regional applications of customary law;
7 basic laws including Organic Law of the State of January 1967 serve as
a constitution; legal education at 14 schools of law; does not accept
compulsory ICJ jurisdiction
Branches: executive, with chief of government dominating all branches of
government through his appointive powers and authority to legislate by
decree; legislative with unicameral Cortes dominated by executive; judicial,
independent in principal but generally limited to interpretation of laws
Government leader: Generalissimo Francisco Franco -- who is also Chief of State,
Commander in Chief of the armed forces, and head of the National Movement
(formerly called the Falange)
Suffrage: universal in national referendums, over age 21
Elections: only two types of direct election other than referendum provided:
representatives to municipal councils for which only heads of households
vote (last election November 1970) and, under new constitutional law of 1967,
104 members of the Cortes elected by heads of households and married women
for a 4-year term (last election September 1971)
313
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Political parties and leaders: National Movement only legally recognized party,
headed by Franco; Torcuato Fernandez Miranda, minister-secretary general of
the movement; various semiclandestine opposition groups include -- Christian
Democratic factions under Jose Maria Gil Robles and Joaquin Ruiz Gimenez;
the Socialists are split into the "old guard" under exiled Secretary General,
Rodolfo Llopis, the "Young Turks" and the “Internal Socialists" under Enrique
Tierno Galvan; the Anarchists; Republicans; Monarchists; smaller regional and
national splinter groups; the Communist Party, whose secretary general,
Santiago Carrillo Solares, is in exile and is challenged by a small dissident
pro-Soviet faction led by exiled Enrique Lister Forjan; and some small pro-
Chinese Communist groups which appear and disappear under varying names;
and a pro-Chinese Communist faction Marxist-Leninist Communist Party of Spain
Voting strength: 561 seats, but somewhat fewer members as some hold more than one
seat -- 19% representing the family elected directly; 45% representing
municipalities, syndicates, and professions elected indirectly under close
regime control; and 36% are appointed by regime or are ex officio
Communists: (inside and outside Spain, est.) 5,000; sympathizers up to 20,000
Other political or pressure groups: the state-controlled organization of
syndicates, comprising representatives of management and labor, an illegal
labor group called the Workers'' Commissions, the Catholic Church, business
and land owning interests, Opus Dei, Catholic Action, university students
Member of: FAQ, IAEA, IBRD, ICAO, ILO, IHB, IMF, ITU, OECD, Seabeds Committee
(observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Province of Sahara
Type: province of Spain, subordinate to Ministry of the Presidency
Capital: E] Aaiun
Political subdivisions: two regions -- Rio de Oro and Saguia el Hamra
Legal system: based on Spanish civil law system and customary law
Branches: Provincial Council; 80 members, of whom half are elected natives
Government leader: Governor General responsible to Directorate General of the
Promotion of the Sahara (a division of the Ministry of the Presidency),
Br. Gen. Fernando de Santiago y Diaz de Mendivil
Suffrage: heads of families only
Elections: 40 members of Provincial Council, August 1967; half of municipal
councillors May 1969
Political party: National Movement
Communists: party proscribed; Communist sympathizers, few (if any)
Other political or pressure groups: none
Legal name: Republic of Sri Lanka
Type: independent state since 1948
Capital: Colombo
Political subdivisions: 9 provinces, 22 administrative districts, and four
categories of semiautonomous elected local governments
Legal system: a highly complex mixture of English common law, Roman-Dutch,
Muslim and customary law; new constitution 22 May 1972; no judicial review
of legislative acts; legal education at Sri Lanka Law College and University
of Sri Lanka, Peradeniya; has not accepted compulsory ICJ jurisdiction
Branches: unitary parliamentary form of government; unicameral legislature
and independent judiciary
Government leader: Prime Minister Sirimavo Bandaranaike
Suffrage: universal over age 18, but most Indian Tamils, who comprise 10.6% of
population, are not enfranchised
Elections: national elections, ordinarily held every 6 years; must be held more
frequently if government loses confidence vote; last election held May 1970,
but new constitution postpones deadline for next election until May 1977
Political parties and leaders: Sri Lanka Freedom Party, Sirimavo Ratwatte Dias
Bandaranaike, President; Lanka Sama Samaja Party (Trotskyite), N. M.
Perera, President; Tamil United Front, S. J. V. Chelvanayakam, leader; United
National Party, J. R. Jayewardene, General Secretary; Communist Party/Moscow,
S. A. Wickremasinghe, General Secretary; Communist Party/Peking, N.
Shanmugathasan, General Secretary; Mahajana Eksath Peramuna (People''s United
Front), M. B. Ratnayaka, President
Voting strength (1970 election): 37% Sri Lanka Freedom Party, 38% United
National Party, 9% Lanka Sama Samaja Party, 3.5% Communist Party/Moscow,
5% Federal Party, minor parties and independents accounted for remainder
Communists: approximately 169,000 voted for the Communist Party in the May 1970
general election; Communist Party/Moscow approximately 2,000, Communist
Party/Peking 532 (1968 est.)
Other political or pressure groups: Buddhist clergy, Sinhalese Buddhist lay
groups; far-left violent revolutionary groups; labor unions
319
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Member of: ADB, Colombo Plan, Commonwealth, FAQ, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMCO, IMF, ITU, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Swiss Confederation
Type: federal republic
Capital: Bern
Political subdivisions: 22 cantons (3 divided into half cantons)
Legal system: civil law systen influenced by customary law; constitution adopted
1874, amended since; judicial review of legislative acts, except with
respect to Federal decrees of general obligatory character; Tegal education
at Universities of Bern, Geneva and Lausanne, and four other university
schools of law; accepts compulsory ICJ jurisdiction, with reservations
Branches: bicameral parliament has legislative authority; federal council
(Bundesrat) has executive authority; justice left chiefly to cantons
Government leader: Roger Bonvin (1-year term as president begins on January 1973),
President
Suffrage: universal over age 20
Elections: held every 4 years; next elections 1975
Political parties and leaders: Social Democratic Party (SPS), Arthur Schmid,
president; Radical Democratic Party (FDP), Henri Schmitt, president;
Christian Conservative People''s Party (CVP), Franz Josef Kurmann, president;
Farmer, Artisan, and Middle Class Party (BGB), Hans Conzett, president;
Communist Party (PdA), Jean Vincent, leading Secretariat member; Republican
Movement (REP)-National Action (N.A.), James Schwarzenbach
Voting strength (1971 election): 49 seats FDP, 44 seats CVP, 46 seats SPS, 23
seats BGB, 5 seats PdA, 4 seats N.A., 7 seats REP, 22 seats others
Communists: 3,500; 50,831 votes in 1971 election
Member of: Council of Europe, EFTA, FAO, IAEA, ICAO, OECD, U.N. (permanent
observer), WHO, WMO
Legal name: Syrian Arab Republic
Type: republic; under left-wing military regime since March 1963
Capital: Damascus
Political subdivisions: 13 provinces and city of Damascus administered as
separate unit
Legal system: based on Is','30e853c4b57eb50d52a0d4c1b3bf191a2585bce2cdf9192339937d4fa00544fb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55fc5654246bf0cf61b6ba109ee5481bf8786dd7a7aa1018cff84b2283399514',1973,'DZ','Algeria','government',12,'lamic law and civil law system; special religious courts;
constitution promulgated in 1973; legal education at Damascus University and
University of Aleppo; has not accepted compulsory ICJ jurisdiction
Branches: executive powers vested in President and Council of Ministers; legis-
lative power rests in the People''s Assembly (election pending); seat of
power is the Ba''th Party Regional (Syrian) Command
Government leaders: President Hafiz Al-Asad
Suffrage: universal at age 18
Elections: no electoral laws being drafted; last elections in December 1961;
presidential referendum in 1971; local councils elected in March 1972,
assembly elections pending
Political parties and leaders: ruling party is the Arab Socialist Resurrectionist
(Ba''th) party; a "national front" cabinet formed in March 1972, dominated by
Ba''thists, includes independents and members of the Syrian Arab Socialist
Party (ASP), Arab Socialist Union (ASU), and Syrian Communist Party (SCP)
Communists: mostly sympathizers, numbering 10,000 to 13,000
Other political or pressure groups: non-Ba''th parties have little effective
political influence; Communist Party ineffective; greatest threat to Ba''thist
regime lies in factionalism in Ba''th Party itself; conservative religious
leaders
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions: 71 centrally controlled provinces
Legal system: based on civil law system, with influences of common law; new
constitution promulgated in 1968, suspended 17 November 1971; provisional
constitution promulgated December 1972; legal education at Thammasat
University; has not accepted compulsory ICJ jurisdiction
Branches: King is head of state with nominal powers; Prime Minister heads a
22-man cabinet; National Assembly unicameral and appointed by executive
branch; judiciary relatively independent except in important political
subversive cases
Government leaders: King Phumiphon Adundet; Field Marshal Thanom Kittikachon,
Prime Minister; General Praphat Charusathien, Deputy Prime Minister
Suffrage: universal
Elections: suspended
Political parties and leaders: dissolved under the revolutionary order 17
November 1971
Communists: strength of illegal Communist Party is about 1,000; Thai Communist
insurgents throughout Thailand total about 5,500
Other political or pressure groups: none
Member of: ADB, ASA, ASEAN, ASPAC, Colombo Plan, ECAFE, FAO, IAEA, ICAO, IDA,
IFC, IHB, ILO, ITU, Seabeds Committee, SEAMES, SEATO, U.N., UNESCO, UNICEF,
UPU, WHO, WMO','eda2b579407151757ae5a41e173add46ad8294ce429335efa57505b3fdc087dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db743b0d836cc9f3482c90485cf0c36cafb4d988f68843ebd347b779b2576422',1973,'AO','Angola','government',16,'Legal name: State of Angola
Type: overseas state of Portugal
Capital: Luanda
Political subdivisions: 16 administrative districts including the coastal
exclave of Cabinda
Legal system: Portuguese civil codes and customary law; legal education
obtained in Portugal
Branches: Governor General appointed by Ministry of Overseas in Lisbon is
executive officer responsible for internal administration; he also has
prescribed legislative functions which he shares with Legislative Assembly
of directly and indirectly elected members; al] action in state may be
vetoed by Minister of Overseas; independent judiciary
Government leader: Governor General Fernado Santos e Castro
Suffrage: all adults able to read and write Portuguese and in full possession
of political and civil rights
Political parties and leaders: only legal group is Portuguese National Popular
Action (ANP), formerly the National Union (UN), headed by Gustavo Neto
Miranda
Other political or pressure groups: principal opposition groups which are
carrying out insurgency are Revolutionary Government of Angola in exile
(GRAE), led by Holden Roberto; Popular Movement for the Liberation of Angola
(MPLA), led by Agostinho Neto; and National Union for the Total Independence
of Angola (UNITA), led by Jonas Savimbi
Communists: none known','f6199c0d19620474944237ca8f17f5779be41746b1fd38aa481434a5dbb62327','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('747f04e84b4feaae2cf60748fa6786e1d23d74493040d29cc87691e34b7a9a17',1973,'BR','Brazil','government',19,'Legal name: State of Antigua
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: St. Johns
Political subdivisions: 6 parishes, 2 dependencies (Barbuda » Redonda )
Legal system: based on English laws British Caribbean Court of Appeal has
a axclusive original jurisdiction and an appellate jurisdiction, consists of
Chief Justice and 5 justices
Branches: legislative, >1-member popularly elected House of Representatives;
executive, prime minister and cabinet
Government leaders: Prime Minister George Herbert Walters Governor Wilfred
Ebenezer Jacobs
2 Suffrage: universal suffrage age 21 and over
Elections: every 5 years; last general election 11 February 1971; last by-election
August 1968
Political parties and leaders: Antigua Labor Party (ALP), Vere C. Bird;
Progressive Labor Movement (PLM), George Herbert Walters Antigua People''s
Party (APP), J. Rowan Henry
Voting strength: 1971 election -- House of Representative seats -- ALP 4, PLM 13
Communists: none known
Other political or pressure groups: Afro-Caribbean Movement (ACM), a small black
nationalist group led by Timothy Hector; Antigua Freedom Fighters (AFF), 4
small black radical group, Jeaders unknown
Member of: CARIFTA
Legal name: Republic of Bolivia
Type: republic; de facto military-civilian coalition government by the Popular
Nationalist Front
Capital: La Paz (seat of government); Sucre (judicial capital )
Political subdivisions: 9 departments with limited autonomy
Legal system: based on Spanish law and Code Napoleon; constitution adopted 1967;
constitution in force except where contrary to dispositions dictated by
governments since 1969; legal education at University of San
Andres and several others; has not accepted compulsory ICJ jurisdiction
Branches: executive; congress of two chambers (Senate and Chamber of Deputies),
congress disbanded after 26 September 1969 ouster of President Siles;
judiciary
Government leaders: President Hugo Banzer Suarez
Suffrage: universal and compulsory at age 18 if married, 21 if single
Elections: none scheduled
Political parties and leaders: The Nationalist Revolutionary Movement (MNR) led
by Victor Paz Estenssoro and the Bolivian Socialist Falange (FSB) led by Mario
Gutierrez form the governing coalition with the armed forces; other political
parties, although numerous, exert little influence; activist groups include
the Nationalist Leftist Revolutionary Party (PRIN) Juan Lechin Oquendo (in
exile), Revolutionary Christian Democratic Party (PDCR) Alfonso Camacho,
Socialist Party (PS) Marcelo Quiroga and Alberto Baily (in exile), and
Leftist Revolutionary Movement (MIR) Pablo Ramos ‘Sanchez (in exile); more
moderate parties include the Authentic Revolutionary Party (PRA) Walter
Guevara Arze, Popular Christian Movement (MPC) Hugo Bozo, Leftist Revolutionary
Party (PIR) Ricardo Anaya, Social Democratic Party (PSD) Hugo Sandoval, and
Christian Democratic Party (PDC) Benjamin Miguel
Voting strength (1966 elections): Frente de la Revolucion Boliviana (a coalition
composed of the MPC, PIR, PRA, PSD, and two interest groups, the campesinos
and Chaco War Veterans) 61%, FSB 12%, MNR 10%, other 17%
Communists: three parties; PCB/Soviet led by Jorge Kolle Cueto, about 1,500
members; PCB/Chinese led by Oscar Zamora, 500 members (est.); POR (Trotskyist),
about 200 members divided between three factions led by Hugo Gonzalez Moscoso,
Guillermo Lora Escobar, and Amadeo Arze
Member of: IAEA, IADB, ICAO, International Tin Council, LAFTA and Andean
Sub-Regional Group (created in May 1969 within LAFTA), OAS, U.N.
37
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: Federative Republic of Brazil
Type: federal republic; military-backed presidential regime since April 1964
Capital: Brasili
Political subdivisions: 22 states, 4 territories, federal district (Brasilia)
Legal system: based on Latin codes; dual system of courts, state and federal;
constitution adopted 1967 and extensively amended in 1969; has not accepted
compulsory ICJ jurisdiction
Branches: strong executive with very broad powers; bicameral legislature
(powers of the two bodies have been sharply reduced); 11-man Supreme Court
Government leader: President Emilio Garrastazu Medici
Suffrage: compulsory over age 18, except illiterates and those stripped of their
political rights; approximately 30 million registered voters in October 1970
Elections: President Medici''s successor will be chosen by a 505-member electoral
college, composed of the members of Congress and delegates selected from the
state legislatures, on 15 January 1974 and will take office in March; will
really be only ratification of a choice made by Medici and top military chiefs
Voting strength: (November 1970 congressional elections): 46% ARENA, 25% MDB,
28.5% blank and void
Political parties and leaders: National Renewal Alliance (ARENA), pro-government
Filinto Muller, president; Brazilian Democratic Movement (MDB), opposition,
Ulisses Guimaraes, president
Communists: less than 13,000; 100,000 sympathizers (est.)
Other political or pressure groups: excepting the military, the Catholic Church
is the only active nationwide pressure group, however, divisions within the
Church often prevent it from speaking with one voice; labor and student
groups have almost no influence on the government
Member of: FAO, GATT, IADB, IAEA, IBRD, ICAO, IHB, ILO, IMCO, IMF, ITU, LAFTA,
OAS, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: State of Brunei
Type: British protectorate; constitutional sultanate
Capital: Bandar Seri Begawan
Political subdivisions: 4 administrative districts
Legal system: based on Islamic law; constitution promulgated by the Sultan in
1959
Branches: chief of state is Sultan (advised by appointed Privy Council) who
appoints Executive Council and Legislative Council
Government leader: Sultan Hassanal Bolkiah
Suffrage: universal age 21 and over; 3-tiered system of indirect elections;
popular vote cast for lowest level (district councilors)
Elections: last elections -- March 1965; further elections postponed indefinitely
Political parties and leaders: antigovernment People''s Independence Front
(Baker), Pengiran Dato Ali, chairman
Communists: information not available
Legal name: Republic of Chile
Type: republic
Capital: Santiago
Political subdivisions: 25 provinces
Legal system: based on Code 1857 derived from Spanish law and subsequent codes
influenced by French and Austrian law; constitution adopted 1925, amended
since then; judicial review of legislative acts in the Supreme Court; legal
education at University of Chile, Catholic University, and several others;
has not accepted compulsory ICJ jursidiction
Branches: president; bicameral legislature; independent judiciary
Government leader: President Salvador Allende
Suffrage: universal (except enlisted military and police) and compulsory at
age 18
Elections: next presidential election (1976); next Chamber of Deputies election
(1977); 25 senators (1977)
Political parties and leaders: Communist Party, Luis Corvalan; Socialist Party,
Salvador Allende and Carlos Altamirano; Christian Democratic Party, Eduardo
Frei and Renan Fuentealba; Radical Party, Anselmo Sule; National Party,
Sergio Onofre Jarpa
Voting strength (1970 presidential election): 36.6% Popular Unity coalition, 35.3%
conservative independent, 28.1% Christian Democrat; (1973 Congressional
election) 44% Popular Unity coalition, 56% Democratic Confederation
Communists: 140,000; sympathizers, 140,000
Other political or pressure groups: organized labor; business organizations;
landowners! associations (SNA -- Sociedad Nacional de Agricultura) s
extremist MIR (Movement of Revolutionary Left) and Patria y Libertad
Member of: ECOSOC, IADB, IAEA, IBRD, ICAO, IDB, IKB, IMF, LAFTA and Andean Sub-
Regional Group (created in May 1969 within LAFTA), OAS, Seabeds Committee,
U.N.
61
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: People''s Republic of China
Type: Communist state; since beginning of Cultural Revolution, real authority
has become diffused as result of persistent rivalries within
the top leadership
Capital: Peking
Political subdivisions: 21 provinces, 3 centrally governed municipalities, and
5 autonomous regions
Legal system: before 1966, a complex amalgam of custom and statute, largely
criminal; little ostensible development of uniform code of administrative
and civil law; highest judicial organ is Supreme People''s Court although
legal activity centered in parallel network of Public Security organs; laws
and legal procedure clearly subordinated to priorities of party policy; whole
system largely suspended during Cultural Revolution and only gradually being
revived
Branches: prior to 1966 control was exercised by Chinese Communist Party, through
State Council, which supervised more than 50 ministries, commissions, bureaus,
etc., all technically under the standing committee of the National People''s
Congress; this system broke down under "Cultural Revolution" pressures and
is currently in process of being reconsolidated and streamlined
Government leader: Premier of State Council, Chou En-lai; Chairman, People''s
Republic of China (chief of state, a ceremonial post currently vacant; party
elder Tung Pi-wu is "acting" chairman); both subordinate to central committee
of CCP, under Chairman Mao Tse-tung
Suffrage: universal over age 18, though this is academic
Elections: no meaningful elections
Political parties and leaders: Chinese Communist Party (CCP), headed by Mao
Tse-tung; Mao is Chairman of political bureau, usually real locus of power
in China, and also Chairman of Central Committee; a new central committee
was formed at the 9th Party Congress held in April 1969 but the National
People''s Congress, the body which would confirm the new state constitution, has
not yet been held; all 29 provincial level party committees were reestablished
63
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Political parties and leaders (cont''d):
by late August 1971 and most sub-provincial levels now have party committees;
the removal of former defense minister Lin Piao in 1971 has created new
dislocations in the ruling party apparatus, both at the center and in the
provinces
Voting strength: 100% Communist for practical purposes; no political nonconformity
permitted
Communists: about 20 million party members in 1965
Other political or pressure groups: army (PLA) is a dominant force with soldiers
performing a wide range of civil political-administrative duties; veteran
civilian officials, in eclipse since the Cultural Revolution, are gradually
being reinstated; mass organizations, such as the trade unions and the youth
league, are being rebuilt at the local level
Member of: U.N., Red Cross, other international bodies
Legal name: Republic of China
Type: republic; one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 4 cities, 1 special municipality (Taipei)
Legal system: based on civil law system; constitution adopted 1947, amended 1960
to permit Chiang Kai-shek to be reelected, and amended 1972 to permit president
to restructure certain government organs; accepts compulsory ICJ jurisdiction,
with reservations
Branches: 5 independent branches (executive, legislative, judicial, plus traditional
Chinese functions of examination and control), dominated by executive branch;
President and Vice President elected by National Assembly
Government leaders: President Chiang Kai-shek; Vice President, Yen
Chia-kan; Premier Chiang Ching-kuo
Suffrage: universal over age 20
Elections: national level -- legislative yuan every 3 years but no general election
held since 1948 election on mainland (partial election for Taiwan province
representatives December 1969 and December 1972); local level -- provincial
assembly, county and municipal executives every 4 years; county and municipal
assemblies every 4 years
Political parties and leaders: Kuomintang, or National Party, led by Director
General Chiang Kai-shek, has no real opposition; 2 insignificant parties
are Democratic Socialist Party, Young China Party
Voting strength (1972 provincial assembly election): 58 seats Kuomintang,
13 seats independents
Other political or pressure groups: none
Member of: expelled from U.N. General Assembly and Security Council on 25 October
1971 and withdrew on same date from other charter-designated subsidiary organs;
attempting to retain membership in international financial institutions
65
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: State of Dominica
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Roseau
Political subdivisions: 10 parishes
Legal system: based on English common law; three local magistrate courts and
the British Caribbean Court of Appeals
° Branches: legislature, 11 member popularly elected House of Assembly; executive,
cabinet headed by Premier
Government leaders : Premier Edward 0. LeBlanc; U.K. Governor Sir Louis Cools-Lartigue
Suffrage: universal adult suffrage over age 18
Elections: every 5 years; most recent October 1970
Political parties and leaders: Dominica Labor Party (DLP), Edward 0. LeBlanc;
+ Dominica Freedom Party (DFP), Miss M. Eugenia Charles
Voting strength: House of Assembly seats -- DFP 2 seats, DLP 8 seats, indepen-
dent 1 seat
Communists : negligible
Member of: CARIFTA
Legal name: Republic of Haiti
Type: republic under the 14-year dictatorship of Francois Duvalier who was
succeeded upon his death on 21 April 1971 by his constitutional successor,
his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: 5 departments (despite constitutional provision for 9)
Legal system: based on Roman civil law system; constitution adopted 1964 and
amended 1971; legal education at State University in Port-au-Prince and private
law colleges in Cap-Haitien, Les Cayes, Gonaives, and Jeremie; accepts
compulsory ICd jurisdiction
Branches: lifetime President, unicameral 58-member legislature of very limited
powers, judiciary appointed by President
Government leader: President-for-life Jean-Claude Duvalier
Suffrage: universal over age 18
Elections: constitution as amended in 1971 provides for lifetime president to be
designated by his predecessor and ratified by electorate in plebiscite; last
legislative elections, which are held every 6 years, held February 1973
Political parties: National Unity Party, only legal party; United Haitian
Communist Party (PUCH), illegal (Communist)
Voting strength (1967 legislative elections): 100% National Unity Party
(Duvalier)
Communists: strength unknown; party leaders believed in exile
Other political or pressure groups: none
Member of: GATT, IADB, IAEA, ICAO, IMF, IBRD, OAS, U.N.
Legal name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Political subdivisions: 18 departments
Legal system: based on Roman and Spanish civil law; some influence of English
common law; constitution adopted 1965; judicial review of legislative acts
in Supreme Court; legal education at University of Honduras in Tegucigalpa;
accepts compulsory ICJ jurisdiction, with reservations
Branches: constitution provides for elected President, unicameral legislature,
and national judicial branch
Government leader: General Oswaldo Lopez Arellano
Suffrage: universal and compulsory over age 18
Elections: next general election February 1977; municipal elections March 1974
Political parties and leaders: Liberal Party (PLH), Carlos Roberto Reina Idiaguez,
Andres Alvarado Puerto, Jorge Bueso Arias, Modesto Rodas Alvarado, and Max
Velasquez, President of Central Executive Council; National Party (PNH),
Alejandro Lopez Cantarero, Ricardo Zuniga Augustinus, General Oswaldo Lopez
Arellano, Mario Rivera Lopez, Martin Aquero, Manuel Acosta Bonilla, Armando
Velasquez Cerrato; Popular Progressive Party (PPP-uninscribed), Gonzalo Carias
Castillo; Orthodox Republican Party (PRO-uninscribed), Roque Jacinto Rivera;
National Innovation and Unity Party (PINU), non-communist, (uninscribed), Miguel
Andonie Fernandez; Workers Party of Honduras (PTH), illegal, Rogue Ochoa;
Communist Party of Honduras/Soviet (PCH/S-outlawed), Dionisio Ramos Bejarano,
Communist Party of Honduras/China (PCH/C-outlawed), Tomas Erazo Pena
Voting strength (1971 elections): Nationalist Party (PNH) 306,028; Liberal
Party (PLH) 276,777
Communists: 400-800; 2,000 sympathizers
Other political or pressure groups: National Association of Honduran Campesinos
(ANACH); Council of Honduran Private Enterprise (COHEP); Confederation of
Honduran Workers (CTH)
Member of: IADB, ICAO, ILO, OAS, CACM, U.N,
Legal name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands, enjoying complete domestic
autonomy
Capital: Willemstad; Curacao, center of government
Political subdivisions: 4 island territories -- Aruba, Bonaire, Curacao, and the
Windward Islands -- St. Eustatius, southern part of St. Martin (northern
part is French), Saba
Legal system: based on civil law system, with some English common law influence;
Dutch Country Statute of 1955 serves as constitution
Branches: executive power, under nominal head of Governor (appointed by the
Crown), exercised by 8-member Council of Ministers or Cabinet; legislative
power rests with 22-member Legislative Council; independent court system
under control of Chief Justice of Supreme Court of Justice (administrative
functions under Minister of Justice); each island territory has island
council headed by Lieutenant Governor for Jocal administration
Government leaders: Minister President Ramez Jorge Isa (new government formed
6 February 1971)
Suffrage: universal age 18 and over
Elections: held every 4 years
Political parties and leaders: the Democratic Party (DP); Antilles Social Progress
Movement (MASA) led by Ciro Kroon; the Aruba Patriotic Party (PPA) led by S.J.
Trompe; the National People''s Party (NVP), S.D. Abbad; the Aruba People''s Party
(AVP) led by Dominico Guzman Croes; the National Aruban Union Party/ Independent
Aruban Party (UNA/PIA) led by A. Werleman/M. Croes; Bonaire Democratic Party
led by L.A. Abraham; Windward Island Democratic Party led by A. C. Wathey;
Social Progressive Action Party, S. R. Goeloe; Antillean Reform Union (URA) ,
Roberto Suriel; Curacao Independent Party (COP), Peter Vander Hoven; Radical
Peoples Party (PRP), Max de Castro; Workers'' Party (Frente Obrero) -- coalition
in power includes DP, PPA, and Workers'' Party
Voting strength (1969 local election): 46% DP/PPA; 15% NVP; 14% Worker Front;
14% AVP; 11% other (new elections may be called soon)
Communists: no Communist Party
Member of: EC (associate), WHO
237
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: Republic of Panama
Type: republic
Capital: Panama
Political subdivisions: 9 provinces, 1 Indian reservation
Legal system: based on civil law system; constitution adopted in 1972; judicial
review of legislative acts in the Supreme Court; legal education at
University of Panama; accepts compulsory ICJ jurisdiction, with reservations
Branches: popularly elected unicameral legislature which elects the President;
presidentially appointed Supreme Court
Government leaders: Demetrio Lakas is Constitutional President and Chief of
State, but subordinate to Gen. Omar Torrijos, the National Guard
Commandant who was given special powers for 6 years by the assembly in 1972
Suffrage: universal and compulsory over age 21
Elections: elections for assembly of representatives of -the corregimientos
August 1972; next election August 1978
Political parties and leaders: political parties suspended pending revision of
electoral code; Communist Party illegal but allowed to operate
Voting strength (1968 election): 55% Arnulfo Arias Madrid (National Union
coalition’. 42% David Samudio (People''s Alliance), 3% Antonio Gonzalez
Revilla (Christian Democratic Party); no parties were active in the 1972
elections
Communists: 100 active and several hundred inactive members People''s Party (PdP);
Communist; 1,000 sympathizers; National Liberation Movement (MLN) and
Vanguard of National Action (VAN) currently inactive as pro-Castro
organizations, 40-60 members
Other political or pressure groups: National Council of Private Enterprise (CONEP)
Member of: IADB, IAEA, ICAO, OAS, U.N.
Legal name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncion :
Political subdivisions: 16 departments and the national capital, 154 municipalities
Legal system: based on Argentine codes, Roman law, and French codes; constitution
promulgated 1967; judicial review of legislative acts in Supreme Court; legal
education at National University of Asuncion and Catholic University of Our
Lady of the Assumption; does not accept compulsory ICdJ jurisdiction
Branches: President heads executive; bicameral legislature; judiciary headed
by Supreme Court
Government leader: President (General) Alfredo Stroessner
Suffrage: universal; compulsory between ages of 18-60
Elections: President and Congress elected together every 5 years; last election
held in February 1973
Political parties and leaders: Colorado Party, Juan Ramon Chavez; Liberal
Party (Levi-Liberal Party), Carlos Levi Ruffinelli; Febrerista Party, Manuel
Benitez; Radical Liberal Party (regular Liberal Party), Justo Pastor Benitez;
Christian Democratic Party (not officially inscribed), Dr. Hermogenes Rojas
Silva
Voting strength (February 1973 general election): 84% Colorado Party, 13% Radical
Liberal Party, 3% Liberal Party, Febrerista Party boycotted elections
Communists: Oscar Creydt faction and Miguel Angel Soler faction (both illegal);
perhaps a few thousand party members and sympathizers in Paraguay, very
few are hard core; party in exile is small and deeply divided
Other political or pressure groups: Popular Colorado Movement (MoPoCo) led by
Epifanio Mendez Fleitas, in exile
Member of: FAO, IADB, IAEA, IBRD, ICAO, IMF, LAFTA, OAS, U.N., WHO
Legal name: Republic of Peru
Type: republic; under military regime since October 1968
Capital: Lima
Political subdivisions: 23 departments with limited autonomy plus constitutional
Province of Callao
Legal system: based on civil law system; military government rules by decree;
legal education at the National Universities in Lima, Trujillo, Arequipa,
and Cuzco; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative, judicial; congress disbanded after 3 October
1968 ouster of President Fernando Belaunde Terry
Government leader: President Juan Velasco Alvarado
Suffrage: obligatory for citizens (defined as adult men and women and married
persons over age 18) until age 60
Elections: none scheduled
Political parties and leaders: Christian Democratic Party (PDC), Luis Gomez
Sanchez, supports the government; opposition parties include Popular Action
Party (AP), Fernando Belaunde Terry (in exile); American Popular Revolutionary
Alliance Party (APRA), Victor Raul Haya de la Torre; and Popular
Christian Party (PPC), Luis Bedoya Reyes
Voting strength (1963 election): 39% AP-PDC, 34% APRA, 25% UNO, 1% Communist,
1% other
Communists: pro-Soviet (PCP/S) 2,000; pro-Chinese (2 factions) 1,000
Other political or pressure groups: government-sponsored social mobilization
system (SINAMOS)
Member of: GATT, IADB, IAEA, ICAO, LAFTA and Andean Sub-Regional Group (created
in May 1969 within LAFTA), OAS, Seabeds Committee, U.N.
Legal name: Republic of the Philippines
Type: republic
Capital: Quezon
* Political subdivisions: 68 provinces
Legal system: based on Spanish, Islamic, and Anglo-American law; parliamentary
constitution passed 1973; judic','e3d249e48ed99bf6d27a26b0c33bfc633b711b3700339027d8cf325252787ffc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d313111769610bb193781d670d9cbad164829cc9b0111f5b558e79cae1adc82a',1973,'BR','Brazil','government',20,'ial review of legislative acts in the
Supreme Court; legal education at University of the Philippines, Ateneo
de Manila University, and 71 other law schools; accepts compulsory
ICJ jurisdiction, with reservations; currently being ruted under martial law
Branches: new constitution (currently suspended) provides for unicameral National
Assembly, and a strong executive branch under a prime minister; judicial
branch headed by Supreme Court with descending authority in a Court of
Appeals, courts of First Instance in various provinces, municipal courts in
chartered cities, and justices of the peace in towns and municipalities;
these justices have considerably more authority than do justices of the
peace in the U.S.
Government leader: President Ferdinand E. Marcos
Suffrage: universal over age 18
Elections: elections suspended for the indefinite future
Political parties and leaders: Liberal Party, Gerardo M. Roxas; Nacionalista
Party, Gil J. Puyat
Communists: about 1,300 armed insurgents
- Member of: ADB, ASEAN; ASPAC, Colombo Plan, ECAFE, IAEA, ICAO, IHB, Seabeds
Committee (observer), SEATO, U.N., UNESCO, UNICEF, WHO
263
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: Commonwealth of Puerto Rico
Type: commonwealth voluntarily associated with U.S.
Capital: San Juan
Political subdivisions: 80 municipalities
. Legal system: based on civil codes; constitution came into effect 1952, U.S.
Constitution also applies; local courts and U.S. federal court; legal
education at University of Puerto Rico Law School
Branches: elected Governor and bicameral legislature; 9-judge Supreme Court
appointed by Governor
Government leader: Governor Rafael Hernandez Colon
’ Elections: every 4 years, last election November 1972; plebescite held July
1967 on question of opting for statehood, continued commonwealth status, or
full independence; 60.4% for commonwealth status, 39.0% for statehood, 0.6%
for independence
Suffrage: universal over age 18
Political parties and leaders: Popular Democratic Party (PPD), Luis Negron Lopez;
Republican Statehood Party (PER); New Progressive Party (PPN), Luis A. Ferre;
Christian Action Party (PAC), Catholic Church; Independence Party (PI);
People''s Party (formed August 1968), Roberto Sanchez
Voting strength (1972 election): 30% PPN, 52.8% PPD; distribution of house
seats -- PPN 39, PPD 12; distribution of Senate seats -- PPD 20, PPN 7
Communists: pro-Communist Puerto Rican Socialist Party, duan Mari Bras
Legal name: State of St. Christopher-Nevis-Anguilla
Type: dependent territory with full internal autonomy as a British "Associated
State"; Anguilla formally seceded in May 1967 but has not been recognized
as an independent state by any government; in July 1968 a legislative
council headed by Ronald Webster was elected to govern Anguilla; in March
1969 the U.K. sent troops to Anguilla, placing the island again under
colonial rule; in 1971, Anguilla reverted to its former colonial relationship
with the U.K. although nominally remaining part of the Associated state of
St. Christopher-Nevis-Anguiila
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law; constitution of 1960; highest judicial
organ is Court of Appeal of Leeward and Windward Islands
Branches: legislative, 10-member popularly elected House of Assembly; executive,
cabinet headed by prime minister
Government leaders: Premier, Robert L. Bradshaw; U.K. Acting Governor, M. P. Allen
Suffrage: universal adult suffrage
Elections: at least every 5 years; most recent 10 May 1971
Political parties and leaders: St. Christopher-Nevis-Anguilla Labor Party, Robert
L. Bradshaw; People''s Action Movement (PAM), William Herbert; Nevis Reformation
Party (NFP), Ivor Stevens
Voting strength (1971 election): St. Christopher-Nevis-Anguilla Labor Party won
7 seats in the House of Assembly, PAM won 2, 1 seat remains open for Anguilla
which did not participate in the election
Communists: none known
Member of: CARIFTA
Legal name: State of St. Lucia
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Castries
Political subdivisions: 14 parishes
Legal system: based on English common law; constitution of 1960; highest judicial
body is Court of Appeal of Leeward and Windward Islands
Branches: legislative, 10-member popularly elected House of Assembly; executive,
cabinet headed by prime minister
Government leaders: Premier John Compton; U.K. Governor Ira Simmons
Suffrage: universal adult suffrage
Elections: every 5 years; most recent April 1969
Political parties and leaders: United Worker''s Party (UWP), John Compton; St.
Lucia Labor Party (SLP), Kenneth Foster; Saint Lucia Labour Action movement
(SLAM), George Odlum, St. Lucia Labor Party United Front (LPUF) led by
George Charles
Voting strength (1969 election): UWP won 6 of the 10 elected seats in House of
Assembly; SLP won 3 seats; LPUF won 1 seat
Communists: negligible
Member of: CARIFTA
Legal name: State of St. Vincent
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Kings town
Legal system: based on English common law; constitution of 1960; highest
judicial body is Court of Appeal of Leeward and Windward Islands
» Government leader: Premier James F. Mitchell; Governor General (U.K.) Sir Rupert
G. John
Suffrage: universal adult suffrage
Elections: every 5 years; most recent 7 April 1972
Political parties and leaders: People''s Political Party (PPP), Ebenezer Joshua;
St. Vincent Labor Party (LP), R. Milton Cato
° Voting strength (1972 election): LP 6 seats, PPP 6 seats, independent 1 seat in
the Legislative
Communists: negligible
Member of: CARIFTA
Legal name: Trinidad and Tobago
Type: independent state since August 1962; recognizes Elizabeth II as chief
of state
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards, Tobago is 30th)
Legal system: based on English common law; constitution came into effect
1962; judicial review of legislative acts in the Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: legislative branch consists of 36-member elected House of
Representatives and 24-member Senate (13 nominated by Prime Minister,
4 by opposition leader, 7 at discretion of Governor General); executive is
cabinet led by the Prime Minister; judiciary is Supreme Court
Government leader: Prime Minister, Dr. Eric Williams
Suffrage: universal over age 21
Elections: last election 24 May 1971, PNM won all seats
Political parties and leaders: People''s National Movement (PNM), Dr. Eric
Williams; Democratic Labor Party (DLP), Alloy Lequay and Vernon Jamadar ;
United National Independence Party, (UNIP) James Millette; Democratic Action
Congress (DAC), Arthur Napoleon Raymond Robinson
Voting strength (1971 election): 32.9% of registered voters cast ballots, 83.7%
PNM, 16.3% other
Communists: not significant
Other political pressure groups: Tapia House Group (headed by Lloyd Best);
National Youth Congress (NYC); Oilfield Workers Trade Union (OWTU), pro-
Marxist leadership; National Joint Action Committee (NJAC), antigovernment,
extremist organization; United Revolutionary Organization (URO), Marxist-led
amalgam
Member of: CARIFTA, Commonwealth, GATT, IBRD, ICAO, IDB, IMF, OAS, Seabeds
Committee, U.N.
34]
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','9bab87406ecd4a55a1aef20d0ad5bfcf27768a86dfcab0d7facd943fdc074baa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc860e6595c761d4bba0e73184119ed3f1d7a5f50a9000d1d207ebf2c4c5b5c9',1973,'AR','Argentina','government',25,'Legal name: Argentine Republic
Type: republic; elected government took over 25 May 1973 from military regime
in control since coup in June 1966
Capital: Buenos Aires
Political subdivisions: 22 provinces, 1 district (Federal Capital), and 1
territory
Legal system: based on Spanish and French civil codes; constitution adopted
1853 partially superseded in 1966 by the Statute of the Revolution which
takes precedence over the constitution when the two are in conflict,
further changes may be made by new government; judicial review of
legislative acts; legal education at University of Buenos Aires and other
public and private universities; has not accepted compulsory ICd jurisdiction
Branches: presidency; national judiciary; legislature dismissed after June
1966 coup was reopened when new government was inaugurated on 25 May
Government leader: President, Hector Campora
Suffrage: universal and compulsory age 18 and over
Elections: general elections held on 11 March 1973; congressional and
gubernatorial runoffs were held on 15 April; next election in 4 years
Political parties: Justicialistas, the official Peronist party; Radical Civic
Union, moderate leftist and nationalist, Ricardo Balbin; Federal Popular
Alliance, Francisca Manrique; Movement of Integration and Development (MID),
small left of center party, former President Frondizi; New Force, conservative
business party, organized by Alvaro Alsogaray for the 1973 elections;
Intransigent Party, formerly the Intransigent Radicals (UCRI), small
nationalist party, Oscar Alende; Union Popular, neo-Peronist or Peronism
without Peron, generally more moderate than orthodox Peronism, Rodolfo
Tecera del Franco; Popular Conservative Party, not conservative but a member
of Peron''s Civic Front, Vicente Solano Lima; smaller parties include the
Revolutionary Christian Party and the Popular Christian party (both are
factions of the Christian Democratic Party), the Progressive Democrats,
the Socialist Party, and the Democratic Socialist Party; several provincial
parties not organized on a national basis
13
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Voting strength: Justicialista Front, 50%; Radicals (former People''s Radical
Civic Union, UCRP), 22%; Federal Popular Alliance, 15%; others, 13%
Communists: some 60,000 members in various party organizations, including a small
nucleus of activists
Other political or pressure groups: Argentine armed forces, Peronist-dominated
labor movement, National Meeting of the Argentines (loose grouping of
Communist and leftist politicians), General Economic Confederation
(Peronist-leaning association of small businessmen) Argentine Industrial Union
(manufacturers '' association), Argentine Rural Society (large landowners''
association), business organizations, students, and the Catholic Church
Member of: FAO, IADB, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, LAFTA,
OAS, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','7a45136ff83e0294fad831db1759ba0f6bf8ab16fa16df7a00edbca23d83b7c2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1e946537fb62c39cdafc822a656df1dee3ca8f60de6ff3f08b2ae0d4a5540c2',1973,'AT','Austria','government',29,'Legal name: Republic of Austria
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states (Laender) including the capital
Legal system: civil law system with Roman law origin; constitution adopted 1920,
repromulgated in 1945; judicial review of legislative acts by a Constitutional
Court; separate administrative and civil/penal supreme courts; Jegal education
at Universities of Vienna, Graz, Innsbruck, Salzburg, and Linz; has not
accepted compulsory ICJ jurisdiction
Branches: bicameral Parliament, directly elected President whose functions are
largely representational, independent federal judiciary
Government leaders: Chancellor Bruno Kreisky; President Franz Jonas
Suffrage: universal over age 19; compulsory for presidential elections
Elections: presidential, every 6 years (next 1977); parliamentary, every 4
years (next 1975)
Political parties and leaders: Socialist Party of Austria (SP0e), Bruno Kreisky,
Chairman; Austrian People''s Party (OeVP), Karl Schleinzer, Chairman; Liberal
Party (FPOe), Friedrich Peter, Chairman; Communist Party, Franz Muhri, Chairman
Voting strength (1971 election): 50.2% SP0e, 43.0% OeVP, 5.4% FPOe, 0.4% dissident
Socialist, 1.4% Communist
Communists: membership 26,000; activists 7,000-8,000; 60,705 votes in 1971 election
Other political or pressure groups: Federal Chamber of Commerce and Industry;
Austrian Trade Union Federation (primarily socialist); three composite leagues
of the Austrian People''s Party (OeVP) representing business, labor, and farmers;
the OeVP-oriented League of Austrian Industrialists; Roman Catholic Church,
including its chief lay organization, Catholic Action
Member of: Council of Europe, ECE, EFTA, IAEA, ICAO, OECD, Seabeds Committee, U.N.,
UNESCO, WHO','213b5e1473e37dc5355624da937ca81ea7d33fa2eea7471c45074b3fbb0f5d93','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac7b955dd5065598535bad3f41db41ea74f75f01bf25303bdbacd400aecfeb69',1973,'BS','Bahamas','government',33,'Legal name: Commonweal th of the Bahama Islands
Type: British dependent territory with full internal autonomy (to become
independent in July 1973)
Capital: Nassau (New Providence Island)
Legal system: based on English law
Branches: Governor (appointed by Queen); bicameral legislature (appointed
Senate, elected House); Executive (Prime Minister and cabinet); judiciary
Government leaders: Prime Minister Lynden 0. Pindling; Governor Sir John
Warburton Paul
Suffrage: universal over age 18
Elections: House of Assembly (9 September 1972)
Political parties and leaders: Progressive Liberal Party (PLP), predominantly
Negro, Lynden 0. Pindling; Free National Movement (FNM) formed by a merger
of United Bahamian Party (UBP) and Free Progressive Liberal Party (Free PLP),
Kendall Isaacs
Voting strength (1972 election): PLP 29 seats, FNM 9 seats
Communists: none known','6dbb5e33dc0b2e4d0f6263958bed71144260f6bad871eddd0bbab1ec10152071','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('609e8e1304b0b0bf9aa63238889a3ecdd323188967a49380404317dd14ade304',1973,'BH','Bahrain','government',37,'Legal name: State of Bahrain
Type: traditional monarchy; independence declared: in 1971
Capital: Al Manamah
Legal system: based on Islamic law and English common law
Government leader: Amir ‘Isa ibn Salman Al-Khalifah
Suffrage: granted to all native-born or naturalized males 20 and over for
+ constituent assembly election
Elections: elections for 22 members of 44-member constituent assembly held
1 December 1972 (remaining members appointed)
Political parties and pressure groups: political parties prohibited; no significant
pressure groups although numerous small clandestine groups are active
Communists: few known
Member of: Arab League, U.N.','2e596dd769b2ef76dd010ea1c49fa30360edf81d0463ec4475a752fe8f7d65a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7930832ee08398579c0e8c30eb266e8aca07f2bbbfa9d7e9c90f4ea9a52ad5b8',1973,'BD','Bangladesh','government',41,'Legal name: People''s Republic of Bangladesh
Type: independent republic since December 1971
Capital: Dacca
Political subdivisions: 19 districts, 413 thanas (counties), 4,053 unions (village
groupings )
a Legal system: based on English common law; constitution adopted December 1972
Branches: parliamentary government ; constitution provides for unicameral
legislature, strong prime minister; independent judiciary
Government leader: Prime Minister Sheikh Mujibur Rahman
Suffrage: universal over age 18
Elections: First Parliament (House of the Nation) elected in March 1973;
“ elections to be held at least every 5 years
Political parties and leaders: Awami League, Sheikh Mujibur Rahman, President;
National Awami Party/Bhashani, Maulana Bhashani, President; National Awami
Party/Muzaffar, Muzaffar Ahmed, President; National Socialist Party
(Jatiyo Samjtantrik Dal), Abdur Rab, General Secretary and M.A. Jalil,
President; Communist Party of Bangladesh, Moni Singh, leader, and Abdus
Salam, General Secretary; East Bengal Communist Party/Marxist-Leninist,
Mohammed Toaha, leader; Bangladesh National League; Ataur Rahman Khan,
leader; Communist Party of Bangladesh/Leninist, Amal Sen, General Secretary;
East Bengal Communist Party, Tara Mia, Secretary of the Central Committee;
other small radical leftist groups some calling themselves Communi sts
Voting strength: (1973 election) 73.1% Awami League; 8.6% NAP/M; 6.5% JSD;
54% NAP/B; 6.4% independents and others
Communists: no information available on membership or degree of popular support
Other political or pressure groups: student groups, bands of former guerrillas
Member of: Afro-Asian People''s Solidarity Organization, Commonwealth, IBRD, IDA,
IMF, ILO, IPU, UNCTAD, UNESCO, WHO','1cccff3df3b13436396836c9a43cd8c10ec46af22122ea6d76af5e64790786ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33596c5026b61bd7bdcd2aff3bf30ccbfe745dbdf4dd3be956fd92ab79d42d85',1973,'BB','Barbados','government',44,'Legal name: Barbados
Type: independent state since November 1966, recognizing Elizabeth II as chief
of state
Capital: Bridgetown
Political subdivisions: 11 parishes
Legal system: English common law; constitution came into effect upon
independence in 1966; no judicial review of legislative acts; has not
accepted compulsory ICd jurisdiction
Branches: legislature consisting of a 21-member appointed Senate and a
24-mamber elected House of Assembly; cabinet headed by Prime Minister
Government leader: Prime Minister Errol Barrow
Suffrage: universal over age 18
Elections: House of Assembly members have terms no longer than 5 years;
last general election held 9 September 1971
Political parties and leaders: Democratic Labor Party (DLP), Errol Barrow;
Barbados Labor Party (BLP), J. M. G. "Tom" Adams
Voting strength (1971 election): Democratic Labor Party (DLP), 57.5%; Barbados
Labor Party, 42.5%; Independent, negligible; House of Assembly seats -- DLP
18, BLP 6
Communists: none
Other political or pressure groups: People''s Progressive Movement (PPM), a
small black-nationalist group led by Calvin Alleyne
Member of: CARIFTA, Commonwealth, ICAO, IMF, OAS. Seabeds Committee (observer),
U.N.','2c6aeadd4476475877e48476a495fedc037f7eff75c1a1c35094ae1dd559a4b0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fef576127aafe44fbc57418a50c47694c7078318f3aeb028270443e004597f98',1973,'BM','Bermuda','government',48,'Legal name: Colony of Bermuda
Type: British crown colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English law
Branches: elected House of Assembly; appointed Legislative Council; Executive
Council (cabinet)
Government leaders: Acting Governor I.A.C. Kinnear; Government Leader (equivalent
to Prime Minister) Sir Edward Richards
Suffrage: universal over age 21
Elections: at least once every 5 years; last general election, June 1972
Political parties and leaders: United Bermuda Party (UBP), Sir Henry Tucker;
Progressive Labor Party (PLP), Walter N.H. Robinson
Voting strength (1972 elections): UBP 61.2%, PLP 38.8%; House of Assembly seats
-- UBP 30, PLP 10
Communists: negligible
Other political or pressure groups: Bermuda Industrial Union (BIU)','c60ad8cb3a854d974cdf114740bb8c127f4339c01040fbfaa15bbe48b4f8a1b2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fee35db892f7bb8d65660d7547e8742be68c89132884bcf6fc2968552756aec',1973,'BT','Bhutan','government',52,'Legal name: Kingdom of Bhutan
Type: monarchy; special treaty relationship with India
Capital: Thimphu
Political subdivisions: 4 regions (east, central, west, south), further
divided into 15-18 subdivisions
Legal system: based on Indian law and English common law; in 1964 the
a King assumed full power -- no constitution existed beforehand; a supreme
court hears appeals from district administrators; has not accepted
compulsory ICJ jurisdiction
Branches: appointed minister and indirectly elected assembly consisting of
village elders, monastic representatives, and all district and senior
government administrators
bad Government leader: King Jigme Singhi Wangchuk
Suffrage: each family has one vote
Elections: popular elections on village level held every 3 years
Political parties: all parties illegal
Communists: no overt Communist presence
Other political or pressure groups: Buddhist clergy
Member of: Colombo Plan, UPU, U.N.','761670926ebff8d5756cece60b0fc4a5829d98130f4d7f3271fdc16abc58324c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5913c3c8d7b83e898175e19ac7b9f07039b66f665f3e18d6c00fd57aa7e55228',1973,'BW','Botswana','government',56,'Legal name: Republic of Botswana
Type: parliamentary republic since independence in September 1966
Capital: Gaborone
Political subdivisions: 12 administrative districts
Legal system: based on Roman-Dutch law and local customary law; constitution
came into effect 1966; judicial review limited to matters of interpretation;
‘ legal education at University of Botswana, Lesotho and Swaziland (2 1/2 years )
and University of Edinburgh (2 years); has not accepted compu
jurisdiction
Branches: executive -~ President appoints and is the chief minister in the
cabinet which is responsible to Legislative Assembly; legislativ
‘ Legislative Assembly with 31 popularly elected members and 4 members elected
: by the 31 representatives » House of Chiefs with deliberative powers only;
judicial -- local courts administer customary law, High Court and
subordinate courts have criminal jurisdiction over all residents,
Appeal has appellate jurisdiction
Government leader: President Seretse Khama
Suffrage: universal, age 21 and over
Elections: general elections held 18 October 1969
Political parties and leaders: Botswana Democratic Party (BDP), Seretse Khama 3
Bechuanaland People''s Party (BPP), P.G. Matante; Botswana Independence
Party (BIP). Motsamai Mpho; Botswana National Front (BNF), Kenneth Koma
and Bathoen Gaseitsiwe
Voting strength: (October 1969 election) 68% BDP (24 seats); 13.5% BPP (3 seats);
12% BNF (3 seats); 6% BIP (1 seat)
Communists: no known Communist organization; Koma of BNF has long history of
Communist contacts
Member of: AFDB, Commonwealth, FAO, OAU, U.N., WMO','b94f8d4b3ce67a0747b5419fd5016e01eb1e64fe695b1e6e550cfc9e9e7b4685','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('665cc9567cc3d9976760fdf6e0635206ee1ba1f05219aac390b54e9d5914934c',1973,'BG','Bulgaria','government',59,'Legal name: People''s Republic of Bulgaria
Type: Communist state
Capital: Sofiya
Political subdivisions: 28 okrugs (districts), including capital city of Sofia
Legal system: based on civil law system, with Soviet law influence; new
constitution adopted in 1971; judicial review of legislative acts in the
State Council; legal education at University of Sofiya; has not accepted
compulsory ICJ jurisdiction
Branches: legislative (National Assembly), Council of Ministers, judiciary
Government leaders: Todor Zhivkov, Chairman, State Council (chief of state);
Stanko Todorov, Chairman, Council of Ministers (premier)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every 4 years for National Assembly; last elections
held on 27 June 1971; 99.8% of the electorate voted
Political parties and leaders: Bulgarian Communist Party, Todor Zhivkov, First
Secretary; Bulgarian National Agrarian Union, a puppet party, Georgi Traykov,
secretary
Communists: 699,000 party members (April 1971)
Mass organizations and front groups: Fatherland Front, Dimitrov Communist Youth
League, Central Council of Trade Unions, National Committee for Defense of
Peace, Union of Fighters Against Fascism and Capitalism, Committee of
Bulgarian Women, All-National Committee for Bulgarian-Soviet Friendship
Member of: CEMA, GATT, IAEA, ICAO, ILO, IMCO, ITU, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO, Warsaw Pact, International Organization of Journalists,
International Medical Association, International Radio and Television
Organization
Legal name: Union of Burma
Type: military dictatorship since suspension of constitution in 1962
Capital: Rangoon
Political subdivisions: Burma proper, 4 other constituent states and 1 special
division for the ethnic minorities; subdivided into divisions, districts,
muncipalities, townships, and villages
Legal system: based on English common law and incorporates Buddhist, Hindu,
and Islamic relgious law; constitution of 1947 superseded by acts of the
new Revolutionary Government, which seized power in 1962; legal education
a at Universities of Rangoon and Mandalay; has not accepted compulsory ICJ
jurisdiction
Branches: Revolutionary Council rules through a Council of Ministers
Government leader: Chairman of Revolutionary Council and Prime Minister, Gen.
U. Ne Win
Suffrage: universal over age 18 under suspended constitution
Elections: none held under present regime
Political parties and leaders: government-sponsored Burmese Socialist Program
Party only legal party
Communists: 5,000
Other political or pressure groups: United National Liberation Front; Kachin
Independence Army; Shan State Army; Karen Nationalist Union
Member of: Colombo Plan, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF,
ITU, Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO','9da3d51a4b885e4b8f0b9b0219c6c163e24fd0a0c3b5ebbe58a19b08f51bf9ef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0644060cc27b67753b48104db0fb4aa5fdad357fb319f00c0d0cb8201d3383b3',1973,'BI','Burundi','government',64,'Legal name: Republic of Burundi
Type: republic; military government since November 1966; no constitution
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into 18 arrondissements and 78
communes
Legal system: based on German and French civil codes and customary law; has not
'' accepted compulsory ICu jurisdiction
Branches: presidential cabinet with Council of Ministers; no legislature
Government leader: President Michel Micombero
Elections: last legislative election May 1965
Political parties and leaders: National Party of Unity and Progress (UPRONA) ,
a a predominantly Tutsi party, was declared sole legitimate party in 1966
Voting strength (1965 elections): UPRONA won 21 of 33 Assembly seats; Hutu-
dominated People''s Party won 10
Communists: no Communist partys resumed diplomatic relations with The People''s
Republic of China in October 1971 following a six-year suspension; U.S.S.R.
and North Korea have diplomatic missions in Burundi
Member of: AFDB, EAMA, ECA, IBRD, ICAO, ILO, IMO, OAU, U.N., UNESCO, WHO, WMO','bdca9d80d4661f2f4f48d542b0d0f81b06cb5d989e028ad89fbacca288469dcd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('615dbb177c4c888db27c8831de57ac77ec5922d4e65a90b5af4748d898703b3b',1973,'KH','Cambodia','government',68,'Legal name: Khmer Republic
Type: new constitution provides for strong presidential system, 4-man "High
Political Council" to rule by decree until October 1973
¢ Capital: Phnom Penh
Political subdivisions: 24 provinces with centrally appointed governors,
3 independent municipalities
Legal system: based on French civil law system; constitution adopted 1947 and
amended 1960; no judicial review of legislative acts; accepts compulsory 1Cd
jurisdiction, with reservations
* Branches: 126-man national assembly and 40-man senate, popularly elected, in
"suspension" until October 1973
Government leader: President Lon Nol
Suffrage: universal over age 18, with major exception of Buddhist clergy
Elections: president elected for 5 year term in June 1972; senate for 6 year term
and assembly for 4 year term in September 1972
Political parties and leaders: Social Republican Party, Hang Thun Hak; Republican
Party, Sirik Matak; Democratic Party, Chau Sau
Communists: party strength unknown, Communist troops estimated between
35,000-40,000
Other political or pressure groups: none
Member of: ADB, Colombo Plan, IAEA, IBRD, ICAO, IMF, U.N., WMO','9dd0f480ce6520d3e75aa9ff5cc73f06ea0a6c33d1240ec4919aeb11b8f5f497','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d329647f523b646c832fe98ea0962c5bd8dccfa5a82d0d61480431ac4f99663',1973,'CM','Cameroon','government',72,'Legal name: United Republic of Cameroon
Type: unitary republic; one-party presidential regime
Capital: Yaounde
Political subdivisions: 7 provinces divided into 39 departments
Legal system: based on French civil law system, with common law influence; new
unitary constitution adopted 1972; judicial review in Supreme Court, when a
question of constitutionality is referred to it by the President of the
Republic; has not accepted compulsory [CJ jurisdiction
Branches: executive, legislative, and judicial
Government leader: President Ahmadou Ahidjo
Suffrage: universal over age 21
Elections: presidential elections held 28 March 1970; parliamentary elections
last held 18 May 1973
Political parties and leaders: single party, Cameroonian National Union (UNC),
President Ahmadou Ahidjo
Communists: no Communist Party or significant number of sympathizers
Other political or pressure groups: Cameroon People''s Union (UPC), an illegal
terrorist group now reduced to scattered acts of banditry with its factional
leaders in exile
Member of: ACCT, AFBD, EAMA, ECA, FAO, GATT, IAEA, IBRD, ICAO, ILO, IMCO, IMF,
ITU, Lake Chad Basin Commission, Niger River Commission, OAU, OCAM, Seabeds
Committee, UDEAC, U.N., UNESCO, UPU, WHO, WMO','45b18d7d8ed18f9f834d941f5fdd6388230272ff1e023fa40a8710a85f20a830','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15da48b8459977bd0e65ac9051ef1e844ece7a8b6fa64dc6f537fb2304441d02',1973,'CF','Central African Republic','government',76,'Legal name: Central African Republic
Type: republic; constitution abrogated following military coup in January 1966
4 Capital: Bangui
Political subdivisions: 14 prefectures, 47 subprefectures
Legal system: based on French, Islamic, and tribal law; in 1966 the Chief of
State assumed all power and abrogated the existing constitution; has not
accepted compulsory ICJ jurisdiction
Branches: Gen. Bokassa heads government and rules by decree; assisted by
* cabinet called Council of Ministers; judiciary, including Supreme Court,
court of appeals, criminal court, and numerous lower courts
Government leader: President Jean-Bedel Bokassa
Suffrage: universal over age 21
Elections: none have been held under Bokassa regime
Political parties and leaders: Black African Social Evolution Movement (MESAN)
ruling party under former regime, still in existence but plays little role,
led by President Jean-Bedel Bokassa
Communists: no Communist Party or significant number of sympathizers
Member of: ACCT, AFDB, Conference of East and Central African States, EAMA, ECA,
FAQ, GATT, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM, UDEAC, U.N., UNESCO, UPU,
WHO, WMO','dc51c2d29b557577ba9eca6951a4fc33af32a0ba3e86c9fe45590490d66a509b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87330f4a743c0ca5aa235b0d93d17c06b02822e67066e6948a6ee560543c368a',1973,'TD','Chad','government',80,'Legal name: Republic of Chad
Type: republic; one-party presidential regime since 1962
Capital: Fort-Lamy
Political subdivisions: 14 prefectures
Legal system: based on French civil law system and Chadian customary law;
constitution adopted 1962; judicial review of legislative acts in theory a
power of the Supreme Court; has not accepted compulsory ICd jurisdiction
Branches: President, who has sweeping powers, elected by universal adult suffrage
to 7-year term; separate popularly elected unicameral National Assembly
of 105 deputies with 5-year term; independent judiciary
Government leader: President Francois Tombalbaye
Suffrage: universal over age 20
Elections: presidential elections held June 1969, parliamentary elections last
held December 1969
Political parties and leaders: Chadian Progressive Party (PPT), only legal
party, led by Francois Tombalbaye
Communists: no front organizations or underground party; probably a few
Communists and some sympathizers
Other political or pressure groups: lightly armed Muslim rebel bands have been
opposing the government since October 1965 in east-central and since August
1969 in northern Chad
Member of: ACCT, AFDB, Conference of East and Central African States, EAMA, ECA,
FAO, GATT, ICAO, IBRD, IDA, ILO, IMF, ITU, Lake Chad Basin Commission,
Niger River Commission, OAU, OCAM, UEAC, U.N., UNESCO, UPU, WHO, WMO','d1443491a8eeedb4148d5693e28aad5e080f2056283817fda94d608d5d0260c7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5568fd6f04717605ce91a8e1b792a0ccd5ebe5b4fdc9aec11c31c9407ba445b',1973,'CO','Colombia','government',84,'Legal name: Republic of Colombia
Type: republic; executive branch dominates government structure
Capital: Bogota
Political subdivisions: 22 departamentos, 4 intendencias, 4 comisarias, 1 federal
district
Legal system: based on Spanish law; religious courts regulate marriage anc
divorce; constitution decreed in 1886, amendments codified in 1346; jucicial
review of legislative acts in the Supreme Court; accepts compulscry ICJ
2 jurisdiction, with reservations
Branches: President, bicameral legislature, judiciary
Government leader: President Misael Pastrana
Suffrage: universal over age 21
Elections: every fourth year; last presidential and congressional elections
April 1970; municipal and departmental elections, April 1972
Political parties and leaders: Liberal Party, official wing, Carlos Lieras Restrepo,
Alfonso Lopez Michelsen; Liberal Party, dissident wing, Julio Cesar Turbay;
Conservative Party, Unionista Wing, Marianc Ospina Perez, Misaei Pastrana;
Conservative Party, Alzatista Wing, Alvaro Gomez Hurtado; Conservative Party,
Dissident Wing, J. Emilio Valderrama, Herman Jaramillo Ocampo; National
Popular Alliance (ANAFO), General Gustavo Rojas Pinilla, Maria Eugenia Rojas
de Moreno; Liberals probably command majority of votes over conservatives, but
constitution under the National Front Coaliticn calls for 50-50 representation
of Liberals and Conservatives in the National Congress until 1974; in local
legislative bodies, parity terminated with the 1970 election; Conservative
Party united with progovernment and Ospina wing in August 1969 to choose
dential candidate; opposition wing (Lauro-Alzatista)
National Front presi
led by Gomez
‘ Voting strength: 1970 presidential election -- Misael Pastrana 1.61 million
votes, General Gustavo Rojas Pinilla 1.54 million votes, B8elisario Betancur
Cuartas .46 million votes, Evardisto Sourdis .3 million votes; 1972 municipal
council and departmental assembly elections -- three major parties; combined
Liberal Party, 1,383,708; Combined Conservative Party, 917,699; ANAPO, 559,821;
abstention by approximately 70% of eligible voters
= Communists: 4,800-5,200; sympathizers, 25,000
67
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d): ae
Other political or pressure groups: Communist Party (PCC), Gilberto Vieira
White; MRL del Pueblo, Communist front for electoral purposes; PCC/ML,
Chinese Line Communist Party, Ted by Pedro Lupo Leon Arboleda Roldan
Member of: FAO, IADB, IAEA, IBRD, ICAO, IFC, THB, ILO, IMF, ITU, LAFTA and
Andean Sub-Regional Group (created in May 1969 within LAFTA), OAS, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Overseas Territory of the Comoro Islands
Type: overseas territory of France
Capital: Moroni
Political subdivisions: 4 prefectures, 4 district councils
Legal system: French and Muslim law
Branches: High Commissioner appointed by French government; assisted by elected
Chamber of Deputies of 39 members, and an 8-man Council of Ministers,
President elected by Chanber of Deputies
Government leader: Ahmed Abdallah, President of Council of Ministers
Suffrage: universal adult
Elections: at discretion of Council of Ministers, on advice of President; must
be held before expiration of 5-year electoral mandate
Political parties and leaders: Comoran Democratic Union, Mohammed Dahlani;
Democratic Assembly of Comoros People, Said Mohamed Jaffar; Comoros Socialist
Party; Umma, Prince Said IBrahim
Voting strength: not available
Communists: information not available','34bfb817f6f2bdf55017ba7e1d043b37fde6091ff5b13f0d92aa787226d74a4a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3228a6b7b02a09385fe21553ab27b1fdd1d5c7b4808c0004c3d5756d8cea3310',1973,'CG','Congo','government',88,'Legal name: People''s Republic of the Congo
Type: republic; military regime established September 1968
Capital: Brazzaville
Political subdivisions: 9 regions divided into districts
Legal system: based on French civil law system and customary law; constitution
adopted 1963 and 1969
Branches: President, Council of State; National Assembly dissolved August 1968;
judiciary presumably still functions according to provisions of 1963
constitution; all policy made by Congolese Workers Party Central Committee
and Politburo
Government leader: President, General Marien Ngouabi
Suffrage: universal over age 18
Elections: last legislative elections December 1963
Political parties and leaders: Congolese Workers Party (PCT) is only legal party;
President, Marien Ngouabi
Communists: unknown number of Communists and sympathizers
Other political or pressure groups: Union of Congolese Socialist Youth (UJSC),
Congolese Trade Union Congress (CSC), Revolutionary Union of Congolese
Union (URFC), General Union of Congolese Pupils and Students (UGEEC)
Member of: ACCT, AFDB, Conference of East and Central African States, EAMA, ECA,
IBRD, FAO, ICAO, ILO, IMF, ITU, OAU, UDEAC, UNESCO, UPU, WHO, WMO','81e445c8bf65260ebecbcfa8c4ce9e59dab20684f8020a7b06c26b62509401f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2e913d0fafb35c55221388025abaafca82fc0c47e67635bfa7f926a3a2fe2a2',1973,'CR','Costa Rica','government',92,'Legal name: Republic of Costa Rica
Type: unitary republic
Political subdivisions: 7 provinces
Legal system: based on Spanish civil law system; constitution adopted 1949;
judicial review of legislative acts in the Supreme Court; legal education
at University of Costa Rica; has not accepted compulsory ICJ jurisdiction
Branches: President, unicameral legislature, Supreme Court elected by legislature
Government leader: President Jose Figueres
Suffrage: universal and compulsory age 18 and over
Elections: every 4 years; next, February 1974
Political parties and leaders: National Liberation Party (PLN), Daniel Oduber;
National Unification (UN), Francisco Calderon; Republican Party (PR), Longino
Soto Pacheco; Popular Union Party (PUP), Jose Joaquim Trejos Fernandez ;
National Independent Party (PNI), Jorge Gonzalez Marten; National Union
Party (PUN), Otilio Ulate; Democratic Renovation Party (PRD), Rodrigo Carazo;
Costa Rican Socialist Party (PMSC), Arnoldo Mora Rodriguez; Christian Demo-
cratic Party (PDC), Jorge Monge Zamora; National Front (FN)> Virgilio Calvo;
Socialist Action Party (PASO), Marcial Aguiluz; Popular Vanguard Party (PvP,
Communi st » j1legal), Manuel Mora
Voting strength (1970 election): National Unification (coalition of PUN, PR, and
PURA) . 41.1%; PLN, 55%; PFN, 1.7%; PDC, 0.9%; PASO; 1.3%
Communists: 3,200 members, 10,000 sympathizers
Other political or pressure groups: Costa Rican Confederation of Democratic
Workers (CCTD). General Confederation of Costa Rican workers (CGTC), Chamber
of Coffee Growers » National Association for Economic Development (ANFE)
Member of: CACM, TADB, IAEA; ICAO, OAS, U.N.','c14c4cfadb14dd066dd1985ffa8c679818c8ac6e98dadd339a8b154c83e183c4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7149db640e1e1299cd7f9374432775d7938e8b92bf47ffcf1c407531aa0efec5',1973,'CU','Cuba','government',96,'Legal name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: 6 provinces
Legal system: based on Spanish and American law, with large elements of
Mi Communist legal theorys Fundamental Law of 1959 replaced constitution
of 1940; legal education at Universities of Havana, Oriente, and Las Villas;
does not accept compulsory ICJd jurisdiction
Branches: executive; no legislatures controlled judiciary
Government leader: Premier Fidel Castro Ruz
n Political parties and leaders: Cuban Communist Party (PCC), First Secretary
Fidel Castro Ruz, Second Secretary Raul Castro Ruz
Communists: approx. 155,000 party members
Member of: CEMA, ECLA, FAO, GATT, IADB (nonparticipant) » IAEA, ICAO, IHB, ILO,
IMCO, International Rice Commission, International Sugar Council, International
Wheat Agreement, ITU, OAS (nonparticipant) ; Permanent Court of Arbitration,
Postal Union of the Americas and Spain, Seabeds Committee (observer), U.N.
UNESCO, UPU, WHO, WMO','7c3be65956b2d1ece91855f25fe4b670258b2b5afb21c756e80612c3a53790d5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f038b9aa9b3e74d610fd730720a913440e611bd3b5b07d597d76818a5aed69d7',1973,'CY','Cyprus','government',100,'Legal name: Republic of Cyprus
Type: republic since March 1961; separate de facto Greek Cypriot, and Turkish
Cypriot governments have evolved since outbreak of communal strife in 1963
Capital: Nicosia
, Political subdivisions: 6 administrative districts
Legal system: based on common law, with civil law modifications; constitution
came into force upon independence in 1960, but has often been in abeyance
since then; has not accepted compulsory ICJ jurisdiction
Branches: currently a rump government consisting basically of Greek Cypriot parts
h of bodies provided for by constitution; headed by President of the Republic
and comprised of Council of Ministers, House of Representatives, and
Supreme Court
Government leaders : President, Archbishop Makarios Iil (Greek); Vice President,
Rauf Denktash (Turk)
Suffrage: universal age 21 and over
Elections: held every 5 years; 1965 elections suspended; 1968 elections only for
President and Vice President; 1970 parliamentary elections demonstrate
notable increase in strength of Communist Party (AKEL); 1972 elections
only for President and Vice President
Political parties and Jeaders: Reform Party of the working People (AKEL)
(Communist Party), Ezekias Papaioannou; Unified Party (UP), Glafkos Clerides;
Progressive Movement (PM) (pro-Makarios), Andreas Azinas; Democratic
National Party (DEK), Takis Evdokas; United Democratic Union of the Center
(EDEK), Vassos Lyssarides; Turkish National Union Party (TNUP), Rauf Denktash
Voting strength: (1968 presidential and vice presidential elections) Greek
Cypriot President Makarios 90%; Turkish Cypriot Vice President Fazil Kucuk
unopposed; (1970 parliamentary elections) 39% of Greek Cypriot vote for
Reform Party of the Working People, 21% of the Greek Cypriot vote for the
Progressive Movement, “% of the Greek Cypriot vote for the Democratic National
Party as well as 9% for the United Democratic Union of the Center, 4% of the
Greek Cypriot vote for independents, 76% of the Greek Cypriot electorate
voted; 80% of the Turkish Cypriot community voted and overwhelmingly elected
15 of Rauf Denktash''s supporters to the Turk Cypriot House contingent in a
separate election; 1972 elections - Makarios unopposed and Rauf Denktash
- unopposed
Communists: 12,000; sympathizers estimated to number 60,000
77
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Other political or Pressure groups: United Democratic Youth Organization (EDON)
(Communist-controiled); Pan Cyprian Confederation of Labor (PEO)
(Communi st-controlled) ; Cyprus Confederation of Labor (SEK) (pro-U.s.);
Cyprus Turkish Federation of Trade Unions (KTBIF)
Member of: Commonwealth, Council of Europe, FAO, IAEA, IBRD, ICAO, IDA, IFC,
ILO, IMF, ITU, U.N., UNESCO, UPU, WHO
Legal name: Czechoslovak Socialist Republic
Type: Communist state
Capital: Prague
Political subdivisions: 2 separate autonomous republics (Czech Socialist
Republic and Slovak Socialist Republic); 7 regions (kraj) in Czech lands,
three regions in Slovakia; national capitals of Prague and Bratislava have
regional status
Legal system: civil law system based on German codes, modified by Communist
legal theory; revised constitution adopted 1960 amended in 1968 and 1970;
no judicial review of legislative acts; legal education at Universita
Komenskeho School of Law; has not accepted compulsory ICJ jurisdiction
Branches: executive --- President (elected by Federal Assembly), cabinet
(appointed by President); legislative -- Federal Assembly (elected directly),
Czech and Slovak National Councils (also elected directly) Tegislate on
limited area of Czech and Slovak affairs; judiciary -- Supreme Court
(elected by Federal Assembly); entire governmental structure dominated
by Communist Party
Government leaders: President Ludvik Svoboda (reelected March 1973),
Premier Lubomir Strougal
Suffrage: universal over age 18
Elections: governmental bodies every 5 years; President every 5 years, (last
election, November 1971)
Dominant political party and leader: Communist Party of Czechoslovakia (KSC),
Gustav Husak, General Secretary; Communist Party of Slovakia (KSS) has status
of "provincial KSC organization"
Voting strength (1971 election): 99.81% Communist-sponsored single slate
Communists: 1.2 million party members
Other political groups: puppet parties -- Czechoslovak Socialist Party,
Czechoslovak People''s Party, Slovak Freedom Party, Slovak Revival Party
Member of: CEMA, GATT, IAEA, ICAO, Seabeds Committee, U.N.. Warsaw Pact
Legal name: Republic of Dahomey
Type: republic; under military rule since October 1972
Capital: Porto-Novo (official), Cotonou (de facto)
Political subdivisions: 6 departments, 30 arrondissements
Legal system: based on French civil law and customary law; legal education
generally obtained in France; has not accepted compulsory {CJ jurisdiction
Branches: military government with some civilian participation, took over on 26
1 October 1972, replacing 3-man Presidential Council formed in 1970; independent
judiciary
Government leader: Major Mathieu Kerekou, President and head of national defense
Suffrage: universal for adults whenever elections or referendums are held
Elections: current government has held no elections and none are scheduled
Political parties: none
Communists: no Communist party; possibly some sympathizers
Member of: ACCT, AFDB, ECA, EAMA, Entente, FAO, ICAO, ILO, ITU, Niger
River Commission, OAU, OCAM, U.N.; UNESCO, UPU, WHO. WMO','966e444e2403ee647b8f5aaacea1867c2b8096ae2b65a595ddbe4f8c917b1842','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edd57d61210f124424b11ae3b61fdd5c673f89d271405e8452565cfd8767bb29',1973,'DK','Denmark','government',104,'Legal name: Kingdom of Denmark
Type: constitutional monarchy
Capital: Copenhagen
Political subdivisions: 14 counties, 277 communes, 88 towns
Legal system: civil law system; constitution adopted 19533 judicial review of
legislative acts; legal education at Universities of Copenhagen and Arhus;
accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament
(Folketing); executive power vested in Crown but exercised by cabinet
responsible to parliament; Supreme Court, 2 superior courts, 106 lower courts
Government leaders: Queen Margrethe II; Prime Minister Anker Jorgensen
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years (next in 1975)
Political parties and leaders: Social Democratic, Anker Jorgensen; Moderate
Liberal, Poul Hartling; Conservative, Erik Haunstrup Clemmensen; Radical
Liberal, Asqer Baunsbak-Jensen, Socialist Peoples, Sigurd Omann; Communist,
Knud Jespersen; Left Socialist, a triumvirate consisting of Ernst Dahl, Leif
Sondergaard Andersen; and Niels Finn Christiansen
Voting strength (1971 election): 37.4% Social Democratic, 15.7% Moderate Liberal,
16.7% Conservative, 14.3% Radical Liberal, 9.1% Socialist Peoples, 1.4%
Communist, 5.3% other
Communists: 5,000; a number of sympathizers, as indicated by 39,344 Communist
votes cast in 1971 elections
Member of: Council of Europe, EC, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHB,
ILO, IMCO, IMF, ITU, NATO, Nordic Council, OECD, Seabeds Committee (observer).
U.N., UNESCO, UPU, WHO, WMO','8b528cac0f5c448c12b6333672fdebf03c8680ebdbbd8ccdd03a5ee304ad4abb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c6880873e6bb44fd38270c79d4a4aaf3d33d54a285003def99b2c6206def319',1973,'DO','Dominican Republic','government',110,'Legal name: Dominican Republic
Type: republic
Capital: Santo Domi ngo
Political subdivisions: 26 provinces and the National District
Legal system: based on French civil codes; 1966 constitution
° Branches: President popularly elected for a 4-year term; bicameral legislature
consisting of Senate (27 seats) and Chamber of Deputies (74 seats) elected
for 4-year terms; members of Supreme Court elected by Senate
Government leader: President Joaquin Balaguer
Suffrage: universal and compulsory, over age 18 or married, except members of the
armed forces and police, who cannot vote
Elections: national, May 1974
Political parties and leaders: Reformist Party (PR), Joaquin Balaguer; Dominican
Revolutionary Party (PRD), Juan Bosch Gavino; Democratic Quisqueyan
Party (POD), Elias Wessin y Wessin; Reyolutionary Social Christian Party
(PRSC), Alfonso Moreno Martinez; Movement for National Conciliation (MNC),
Jaime Manuel Fernandez Gonzalez; Anti-reelection Movement of Democratic
Integration (MIDA) Francisco Augusto Lora; National Civic Union (UCN), Pedro
Guillermo Urraca; Fourteenth of June Revolutionary Movement (MR-1d4), split
into several factions, illegal; Dominican Communist Party (PCD), central
committee, illegal; Dominican Popular Movement (MPD) Rafael Taveras Rosario,
illegal; Communist Party of the Dominican Republic (PCRD), Luis Montas
Gonzalez, illegal; Popular Socialist Party (PSP), illegal
Voting strength (1970 election): 57% PR, (abstained) PRD, 5% PRSC, 14% PQD, 3%
MCN, 21% MIDA
Communists: an estimated 1,500 to 1,800 members in six different factions;
effectiveness limited by ideological differences and organizational
inadequacies
Member of: GATT, IADB, IAEA, ICAO, IHB, OAS. U.N.','36603c39b9bbff76a3f60be3e2738f0055cc469c5ae7d18c00c8950a7126d646','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff00e6dbd2ffe02dab730998a50a3e926caa403b481c16e5cb485c936d2b3b8b',1973,'EC','Ecuador','government',114,'Legal name: Republic of Ecuador
Type: republic
Mi Capital: Quito
Political subdivisions: 19 provinces and 1 territory (Galapagos Islands)
Legal system: based on civil law system; modified 1945 constitution re-instituted
in February 1972, legal education at 4 state and 2 private universities; has
not accepted compulsory ICd jurisdiction
4 Branches: President and government council assumed power February 1972; government
decisions announced by decree over the president''s signature; judiciary system
supervised by Supreme Court but currently undergoing reorganization
Government leader: President, General Guillermo Rodriguez Lara
Suffrage: universal for literates over age 18
Elections: none scheduled
Political parties and leaders: National Velasquista Front, personalistic, Jose
Maria Velasco Ibarra; Radical Liberal Party, Ignacio Hidalgo Villavicencio;
Social Christian Party, generally conservative, Camilo Ponce; Conservative
Party, Galo Pico Mantilla; Concentration of Popular Forces, populist, Assad
Bucaram; National Revolutionary Party, leftist, Carlos Julio Arosemena
Voting strength: in June 1968 national elections, Velasquistas, a center-left
coalition, and a rightist coalition each got approximately one-third
Communists: 500 members plus 2,500 sympathizers ; Marxist-Leninist Communist Party,
250; pro-Castro Revolutionary Socialist Party, 450
Member of: ECOSOC, IADB, IAEA, ICAO, LAFTA and Andean Sub-Regional Group
(formed in May 1969 within LAFTA), OAS, Seabeds Committee (observer), U.N.','bb7ef8020c19cbc5b160d41df88af46d0491b3e75214e2823a32b9b11b1df64e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3df68383917a8927c9406b78bd4056df5151ade8a60799fffb6aa29ffc130f76',1973,'EG','Egypt','government',118,'Legal name: Arab Republic of Egypt
Type: republic; under presidential rule since June 1956
Capital: Cairo
Political subdivisions: 25 governorates
Legal system: based on English common law, Islamic law, and Napoleonic codes;
interim constitution of 1964; judicial review of limited nature in Supreme
Court, also in Council of State which oversees validity of administrative
decisions; legal education at Cairo University; accepts compulsory ICJ
jurisdiction, with reservations
Branches: executive power vested in President, who appoints cabinet; People''s
Assembly has little actual power (serves mainly for discussion and automa-
tic approval); independent judiciary administered by Minister of Justice
Government leader: President Anwar Sadat
Suffrage: universal over age 18
Elections: elections to People''s Assembly every 5 years (most recent October
1971); presidential elections every 6 years
Political parties and leaders: political parties banned except for the government-
sponsored sociopolitical grouping, Arab Socialist Union (ASU)
Communists: approximately 500, party members
Member of: AAPSO, Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO. IMCO,
IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO, WPC','3fd4982149976a263e32ebb0f8b78f9ec396f256fa90b6e1438c1d8d8887ab83','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ecb4d589d084a3957d44e3028d8c3e038982bc4dd40fb435f3d8e5e6fe3e7ca',1973,'SV','El Salvador','government',122,'Legal name: Republic of El Salvador
Type: republic
Capital: San Salvador
Political subdivisions: 14 departments
Legal system: based on Spanish law, with traces of common law; constitution
adopted 1962; judicial review of legislative acts in the Supreme Court;
legal education at University of E1 Salvador; accepts compulsory ICd
jurisdiction, with reservations
Branches: traditionally dominant executive, fairly independent unicameral
legislature, Supreme Court
Government leader: President Arturo Armando Molina
Suffrage: universal over age 18
Elections: legislative elections every 2 years; presidential elections every 5
years; presidential elections March 1977, legislative and municipal elections
March 1974
Political parties and leaders: National Conciliation Party (PCN), President
Arturo A. Molina, Dr. Enrique Mayorga Rivas, Rafael Rodriguez
Gonzalez; Christian Democratic Party (PDC), Juan Ramirez Rauda, Dr. Pablo
Mauricio Alvergue, Roberto Lara Velado; Dr. Abraham Rodriguez, Jose Napoleon
Duarte; Revolutionary Party (PR -- formerly Renovating Action Party), not
legally recognized, Shafick Handal, Dr. Fabio Castillo Figueroa, Julio Ernesto
Contreras; Salvadoran Popular Party (PPS), Benjamin Wilfredo Navarrete,
Roberto Quinonez Meza, Dr. Jose Antonio Guzman; Communist Party of E] Salvador
(PCES), illegal, Jorge Shafick Handal; National Revolutionary Movement (MNR),
Dr. Guillermo Manuel Ungo; National Democratic Union Party (PUDN), Francisco
Roberto Lima, Julio Ernesto Contreras, Julio Castro Belloso; Independent
Democratic United Front (FUDI), Gen. Jose A. Medrano, Raul Salaverria
Voting strength: February 1972 presidential election -- PCN 43.4%, PDC, PUDN,
and MNR coalition, 42.1%; FUDI, 12.3%; PPS 2.2%; March 1972 legislative
election -- PCN, 39 seats; PDC, MNR, and PUDN coalition, 8 seats; PPS 4 seats;
FUDI, 1 seat
Communists: 100 to 200 active members; sympathizers, 5,000
Other political or pressure groups: the military; the "14" prominent families;
General Confederation of Trade Unions (CGS); Unifying Federation of Salvadoran
93
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Other political or pressure groups (cont''d):
Trade Unions (FUSS), Communist dominated; Federation of Construction and
Transport Workers Unions (FESINCONSTRANS), independent; Catholic Church;
Salvadoran National Association of Educators (ANDES )
Member of: Central American Common Market, IADB, IAEA, OAS, ODECA, Seabeds
Committee, U.N.','4a952a82b199d8f204ce3bdc24222159a24e05a9850c30c8fbf2e04ce9561c3b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('017164d2733eb59bbbb50117741bd963cf9812075067276274415e061d9576dc',1973,'GQ','Equatorial Guinea','government',126,'Legal name: Republic of Equatorial Guinea
Type: republic, one-party presidential regime since 1968
Capital: Santa Isabel, Fernando Po
Political subdivisions: 2 provinces (Fernando Po and Rio Muni)
Legal system: based on Spanish civil law system and customary law, constitution
suspended in 1971; has not accepted compulsory ICJ jurisdiction
Branches: the president assumed all power in May 1971, suspending the
legislative and judicial branches of government
Government leader: President Francisco Macias Nguema
Suffrage: universal age 21 and over
Elections: national and provincial elections held September 1968
Political parties and leaders: National Unity Party of Workers (PUNT) is the sole
legal party, led by President Macias
Communists: no significant number of Communists or sympathizers
Member of: Conference of East and Central African States, ECA, IBRD, IMF, OAU, U.N.','16968f4bf04b5db90dde25c8e142d51751a7ff6a7e5e86a136d41a0f5043b006','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e1cf32548abab8e58229d5e173f4b8ede90d9cf62d21523af33c1b1d3f6cbcb',1973,'ET','Ethiopia','government',130,'Legal name: Empire of Ethiopia
Type: constitutional monarchy, but in effect an absolute monarchy
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred to as governorates ~-general)
Legal system: complex structure with civil, Islamic, common and customary law
influences; constitution adopted 1955; no specific constitutional provision
for review by courts but all legislation inconsistent with the constitution
is declared null and void; legal education at Haile Selassie I University;
has not accepted compulsory ICJ jurisdiction
Branches: Emperor is all-powerful, with advisory cabinet and Prime Minister;
legislature composed of elected Chamber of Deputies and appointed Senate;
judiciary at higher levels based on Western pattern, at lower levels on
traditional pattern, without jury system in either
Government leader: Emperor Haile Selassie I
Suffrage: universal over age 21
Elections: lower house of Parliament election in June 1973
Political parties and leaders: only amorphous reform groups espectally among
younger, better educated Ethiopians
Communists: none
Other political or pressure groups: some dissident ethnic groups, most important
of which is Eritrean Liberation Front, separatist group operating in
northeastern Ethiopia
sta of: ECA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UPU,
0, WMO
Legal name: The Faeroe IsTands
Type: self-governing province within the Kingdom of Denmark; 2 representatives
in Danish parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, | town
« Legal system: based on Danish law; Home Rule Act enacted 1948
Branches: legislative authority rests jointly with Crown, acting through appointed
High Commissioner, and provincial parliament (Lagting) in matters of strictly
Faeroese concern; executive power vested in Crown, acting through High
Commissioner, but exercised by provincial cabinet responsible to provincial
parliament
Government leaders: Queen Margrethe II; Prime Minister, Atli Dam
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years; next election 1975
Political parties and leaders: Peoples, Hakun Djurhuus; Republican, Erlendur
Patursson; Home Rule, Samuel Petersen; Progressive, Kjartan Mohr; Social
Democratic, Atli Dam; Union, Kristian Djurhuus
Voting strength (1970 election): Peoples 20.0%, Republican 20.0%, Home Rule
5.6%, Progressive 3.5%, Social Democratic 27.2%, Union 21.7%
Communists: insignificant number
Member of: Nordic Council
Legal name: Colony of the Falkland Islands
Type: British crown colony
Capital: Stanley
Political subdivisions: local government is confined to capital
Legal system: English common law
Branches: Governor, Executive Council, Legislative Council
Government leader: Governor and Commander in Chief Sir Cosmo Haskard (also
High Commissioner for British Antarctic Colony)
Suffrage: universal','76b7513569881c8b101c45582d4cd10f65569cedb47c1a76b8d2e474afc905a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8684ac9da2b7a440950faf6449dfa943eb7a43d1303a51e030286da7b1e7ed7',1973,'FJ','Fiji','government',134,'Legal name: Dominion of Fiji
Type: independent state within Commonwealth ; Elizabeth I! recognized as head
of state
< Capital: Suva
Political subdivisions: 14 provinces
Legal system: based on British
Branches: executive ~~ Prime Minister; legislative -- 52-member House of
Representatives; Alliance Party 33 seats, National Federation Party 19 seats
Government leader: Prime Minister Ratu Sir Kamisese Mara
Suffrage: universal adult
Elections: every 5 years unless House dissolves earlier, last held March-April 1972
Political parties: Alliance, primarily Fijian, headed by Ratu Mara; National
Federation, primarily Indian, headed by S. M. Koya
Communists: few, no figures avai lable
Member of: Commonwealth, U.N.','483f8f5f2c830e015ebd7d2570fbb4ef4926c6cf5b257ab853d6c2fa583ef195','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b63a4fa868f450c9920a65864ef9ae93589a0077bb3c9208f25f75a0db76b30',1973,'FI','Finland','government',137,'Legal name: Republic of Finland
Type: republic
Capital: Helsinki
Political subdivisions: 12 provinces; 443 communes, 78 towns
Legal system: civil law system based on Swedish law; constitution adopted 1919;
Supreme Court may request legislation interpreting or modifying laws; legal
education at Universities of Helsinki and Turku; accepts compulsory ICJ
jurisdiction, with reservations
Branches: legislative authority rests jointly with President and parliament
(Eduskunta); executive power vested in President and exercised through
cabinet responsible to parliament; Supreme Court, 4 superior courts,
193 lower courts
Government leader: President Urho K. Kekkonen; Prime Minister Kalevi Sorsa
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1976); presidential, every
6 years (extra ordinary parliamentary legislation extended President
Kekkonen''s term, which normally expires in 1974, to 1978)
Political parties and leaders: Social Democratic, Rafael Paasio; Center,
Johannes Virolainen; Peoples Democratic League (Communist front), Ele
Alenius; Conservative, Harri Holker; Liberal, Pekka Tarjanne; Swedish Peoples,
Jan-Magnus Jansson; Rural, Veikko Vennamo; Communist, Aarne Saarinen
Voting strength (1972 election): 25.8% Social Democratic, 17.5% Conservative,
17.1% People''s Democratic League, 16.5% Center, 9.2% Rural, 5.3% Swedish
Peoples, 5.1% Liberals, 2.5% Christian Peoples, 1.0% other
Communists: 47,000; an additional 65,000 persons belong to Peoples
Democratic League; a further number of sympathizers, as indicated by
421,000 votes cast for Peoples Democratic League in 1970 elections
Member of: EC (draft free trade agreement) EFTA (associate), FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, Nordic Council, OECD, Seabeds
Committee (observer), U.N., UNESCO, UPU, WHO, WMO
105
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','f8ef7a289c7466a2d0e1e0f8e1f8c9c61c9a6cbfc58cf714e4e1b349127312bb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cad4caab7212dfb8316ded84fa6eb17adbff9774a1794778ff6c84888bfbfcd',1973,'FR','France','government',140,'Legal name: French Republic
Type: republic, with president having wide powers
Capital: Paris
Political subdivisions: 95 departments, 21 regional economic districts
Legal system: civil law system with indigenous concepts; new constitution
adopted 1958, amended concerning election of President in 1962; judicial
review of administrative but not legislative acts; legal education at over
25 schools of law; accepts compulsory ICJ jurisdiction, with reservations
Branches: presidentially appointed Prime Minister heads Council of Ministers,
which is formally responsible to National Assembly; bicameral legislature
-- National Assembly (490 members), Senate (283 members) restricted to a
delaying action; judiciary independent in principle
Government leader: President Georges Pompidou
Suffrage: universal over age 21; not compulsory
Elections: National Assembly -- every 5 years, last election March 1973, direct
universal suffrage, 2 ballots; Senate -- indirect collegiate system for 9
years, renewable by one-third every 3 years; President —- direct, universal
suffrage every 7 years, 2 ballots, last election June 1969
Political parties and leaders: Union of Democrats for the Republic (UDR);
Independent Republicans (IR), Valery Giscard d''Estaing; Communist (PCF),
George Marchais; Progress and Modern Democracy (PDM), Jacques Duhamel;
Left Radical Party, Robert Fabre: Movement for Reform, coalition of Center
Democratic Party, Jean Lecanuet and Radical Socialists, Jean Jacques
Servan-Sahreiber; Socialist Party, Francois Mitterrand; Unified Socialist
Party (PSU), Michel Rocard
Voting strength (first ballot, 1973 election): 23.9% UDR, 6.9% IR, 21.3% PCF,
20.4% Federation of Democratic and Socialist Left (grouping of parties of
left), 12.4% Center, 15.1% other
Communists: 250,000-300,000 (est.); Communist voters, 5 million average
Other political or pressure groups: Communist-controlled labor union
(Confederation Generale du Travail) nearly 1,500,000 members (est.),
National Council of French Employers (Conseil National de Patronat
Francais -- CNPF or Patronat)
107
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Member of: Council of Europe, EC, FAO, IAEA, IBRD, ICAO, IHB, ILO, IMCO. IMF, ITU,
NATO (signatory), OECD, Seabeds Committee, SEATO, South Pacific Commission,
U.N. , UNESCO, UPU, WEU, WHO, WMO','ed7338dcc6359c349aff26aa6174eb90ddca100da36179cce5442b4c3e7ed544','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fd6b99766c8d6e20a186e3e3d3b4f6a10d5af395bed4ac705351beb02f65c78',1973,'GF','French Guiana','government',144,'Legal name: Overseas Department of French Guiana
Type: overseas department of France; represented by one deputy in French National
Assembly and one senator in French Senate
Capital: Cayenne
Political subdivisions: 2 arrondissements, 19 communes each with a locally elected
municipal council
Legal system: French legal system; highest court is Court of Appeal based in
Martinique with jurisdiction over Martinique, Guadeloupe, and French Guiana
Branches: executive: prefect appointed by Paris; legislative: popularly elected
16-member General Council; judicial, under jurisdiction of French judicial
system
Government leader: Prefect, Jean Delaunay
Suffrage: universal over age 21
Elections: General Council elections coincide with those for the French National
Assembly, normally every 5 years; last election March 1973
Political parties and leaders: Parti Socialiste Guyanais (PSG), Henri Agarande,
Senator; Union du Peuple Guyanaise (UPG), weak, leftist allied with, but
also reported to have been absorbed by, the PSG; Union of Democrats for the
Republic (UDR), Hector Rivierez, delegate to French National Assembly;
Parti Du Travail de Guyane (PTG), leader Jean Claude Montgenie
Communists: no organized Communist party; UPG includes Communist sympathizers
but has little measurable following
Legal name: Overseas Territory of Afars and Issas
Type: overseas territory of France; represented by one deputy in French National
Assembly and by one senator in French Senate
Capital: Djibouti
tb Legal system: based on French civil law system, traditional practices and
Islamic law
Branches: President of Council of Government ; 8-member Council of Government
appointed by 32-member Chamber of Deputies (Chamber to be increased to 40
members in November 1973); ultimate political authority exercised by
Paris-appointed President of the Council of Government, sometimes referred
: to as Prime Minister
Government leader: Ali Aref Bourhan
Suffrage: universal ;
Elections: Chamber of Deputies election held March 1973
Political parties and leaders: Rassemb]ement Democratique Afar, Ali Aref Bourhan;
Union Democratique Afar; Union Populaire Africaine; Union Democratique
Issa, Oman Farah Iitireh; African People''s League, Hassan Gouled
Communists: possibly a few sympathizers','f4d30969e77eda9c07a9416090e4c709d27e329cbc84c605edad268e62cd5405','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b5bfb7211156ad61d46091f61dc59addbdf53fd0ed9a91deab6c6c38587d981',1973,'GA','Gabon','government',148,'Legal name: Gabonese Republic
Type: republic; one-party presidential regime since 1964
Capital: Libreville
Political subdivisions: 9 regions, 6 communes, 4,500 villages
Legal system: based on French civil law system and customary law; cons ti tution
adopted 1961; judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; legal education at Centre of Higher and Legal Studies
at Libreville; compulsory ICJ jurisdiction not accepted
Branches: power centralized in President, elected by universal suffrage for
7-year term; unicameral 70-member National Assembly has limited powers;
judiciary
Government leader: President Albert-Bernard Bongo
Suffrage: universal over age 21
Elections: Presidential and parliamentary elections last held February 1973
Political parties and leaders: Gabonese Democratic Party (PDG) led by President
Bongo is only legal party
Communists: no organized party; probably some Communist sympathizers
Member of: ACCT, AFDB, EAMA, Conference of East and Central African States, FAQ.
IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM, UDEAC, U.N., UNESCO, UPU, WHO, WMO','5155ab0980ab5abed07504d58675e45235401cf74015a571af99462799c44d2d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e6839ad8cb1503fc9fa7f94ae1183681c45b6e5a157480e374ff4710869b920',1973,'GM','Gambia','government',152,'Legal name: Republic of The Gambia
Type: republic; independent since February 1965
Capital: Banjul
Political subdivisions: Bathurst and 4 divisions
Legal system: based on English common law and customary law; constitution came
into force upon independence in 1965, new republican constitution adopted in
April 1970; accepts compulsory ICJ jurisdiction, with reservations
Branches: cabinet of 10 members; 41-member House of Representatives, in which
4 seats are reserved for chiefs, 4 are appointed, 32 are filled by election
for 5-year terms, a Speaker is elected by the House, and the Attorney
General is an ex-officio member; independent judiciary
Government leader: Dawda K. Jawara, President
Political parties and leaders: People''s Progressive Party (PPP), Secretary
General Dawda K. Jawara and United Party (UP), dohn Forster
Suffrage: universal adult
Elections: general elections held March 1972; PPP won 28 seats, UP won 3, and one
independent elected
Communists: insignificant number
Member of: Commonwealth, ECA, OAU, U.N.','6b72f328d6dfd1e894c078c8e953dbc51f37bda8cd41454158a87ceb2874c111','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('278e7cf77093dbbab05dca74b2efa5ae928c4dd7407f5cb7ffb3093400f07b60',1973,'GH','Ghana','government',156,'Legal name: Republic of Ghana
Type: republic; independent since March 1957; Military regime since January 1972
Capital: Accra
Political subdivisions: 8 administrative regions and separate Greater Accra
Area; regions subdivided into 47 districts
Legal system: based on English common law and customary law; constitution
suspended January 1972; legal education at University of Ghana (Legon) ;
has not accepted compulsory [Cd jurisdiction
Branches: executive and legislative authority vested in National Redemption
Council (NRC); independent judiciary
Government leaders: chief of state, chairman of NRC Colonel I.K. Acheampong
Suffrage: universal over 21
Elections: no elections since 1969; none scheduled
Political parties and leaders: parties banned by military junta which took
power 13 January 1972
Communists: a small number of Communists and sympathizers
Member of: AFDB, Commonwealth, ECA, FAO, IAEA, IBRD, ICAO. ILO, IMCO, IMF, ITU,
OAU, U.N., UNESCO, UPU, WHO, WMO
Legal name: Colony of Gibraltar
Type: U.K, colony
Capital: none
Legal system: English law; constitutional talks in July 1968; new system
effected in 1969 after electoral enquiry
Branches: parliamentary system comprised of the Gibraltar House of the Assembly
(15 elected members and 3 ex officio members), the Council of Ministers
headed by the Chief Minister, and the Gibraltar Council; the Governor is
appointed by the Crown
Government leaders: Governor and Commander in Chief, Adm. of the Fleet Sir
Vary] Begg; Chief Minister, Maj. Robert Peliza; Deputy Chief Minister,
Peter Isola
Suffrage: all adult Gibraltarians, plus other U.K. subjects resident 6 months
or more
Elections: every 5 years; last held in July 1969
Political parties and leaders: Association for Advancement of Civil Rights
(AACR), Sir Joshua Hassan; Labor, Sir Joshua Hassan; Independents, Peter
Isola; Integrationists (IWBP), Maj. Robert Peliza
Voting strength: In 1969, the AACR won 7 seats in the Assembly, the IWBP won 5,
the Independents won 3; a coalition between the latter two parties was formed
Communists: none known
Other political or pressure groups: the Housewives Association; the Chamber
of Commerce','86aae611982b31fc263af2158f4c359f58e8ad3ae37870b50f67e55235bec17a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac2b0be8abd6c3f6fd678c3b66b740be071fbaff77465bd234742b77a10dd9be',1973,'GR','Greece','government',160,'Legal name: Hellenic Republic
Type: presidential republic; power in hands of ex-military leaders since
April 1967
Capital: Athens
Political subdivisions: 52 departments (nomoi) constitute basic political units;
as a result of decentralization measures promulgated August 1971, these nomoi
have now been grouped into seven geographical areas which are called Regional
Administrations, each of which is headed by an Undersecretary of Interior
(Regional Administrator); while each nomos ultimately reports to and is
administered by the central government, the attempt of the decentralization
program is for each nomos and Regional Administration to administer its own
prograls and to solve its own problems on a local basis to the greatest degree
possible
Legal system: based on Roman and Byzantine Taw, substantially altered by civil
codes of 1946-51; martial law decreed in April 1967 remains in force in the
major urban center of Athens-Piraeus; legal training at University of Athens
and at the University of Thessaloniki; does not accept compulsory ICJ
jurisdiction
Branches: new constitution promulgated in November, 1968, however, with key
articles concerning Parliament and powers of the courts still suspended;
certain articles of 1968 constitution pertaining to individual rights, also
suspended, were declared implemented in 1969 and 1970, but in practice
repression of these rights continues; on 1 June 1973 the monarchy was
abolished and the presidential republic was proclaimed
Government leaders: George Papadopoulos is President, Minister of Programming
and Government Policy, Minister of Foreign Affairs and Minister of National
Defense; a Vice-President and Premier are to be named
Suffrage: universal age 21 and over
Elections: promised by the end of 1974
Political parties and leaders: political activities suppressed; party leadership
and organization tn disarray
Communists: 12% of electorate tn February 1964; hard-core elements imprisoned,
Communist Party (KKE) outlawed since 1947
Member of: EC (assoctate member), FAO, FUND, IAEA, IBRD, ICAO, IDA, IPC, IHB,
TLO, IMCO, ITU, NATO, OECD, U.N., UNESCO, UPU, WHO, WMO
127
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','a9ec0b8d238ed06edaa22a134f9f5c15121f95be5f4b8c294bce032636c7c1c8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('857c068d321ce6ef72bbda56f1effda689b8a8a2140a757ba261e670d5590130',1973,'GD','Grenada','government',167,'Legal name: State of Grenada
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: St. Georges
Political subdivisions: 6 parishes
Legal system: based on English common law
Branches: legislative branch consists of 10-member elected House of Representatives
and 9-member Senate appointed by the Governor; executive branch is cabinet
led by Premier
Government leaders: Premier Eric Matthew Gairy; U.K. Governor Dr. Hilda Bynoe
Suffrage: universal adult suffrage
Elections: every 5 years; most recent election 28 February 1972
Political parties and leaders: Grenada United Labor Party (GULP), Eric Matthew
Gairy; Grenada National Party (GNP), Herbert A. Blaize
Voting strength (1972 election): GULP 58.7%, GNP 41.3%; Legislative Council
seats, GULP 13, GNP 2
Communists: negligible
Member of: CARIFTA','531b70696965efa46d2e3c4d976c44ee0d4ca0e26de8b16400ca9a944ce98938','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d092d61147a328d14afa08d40ff32de77ef8a76076ac3c8e4551a4cf03b9ac66',1973,'GT','Guatemala','government',172,'Legal name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions: 22 departments
Legal system: civil law system; constitution came into effect 1966; judicial
review of legislative acts; legal education at University of San Carlos of
Guatemala; has not accepted compulsory ICJ jurisdiction
Branches: traditionally dominant executive; elected unicameral legislature;
7-member (minimum) Supreme Court
Government leader: President Carlos Arana
Suffrage: universal over age 18, compulsory for literates, optional for illiterates
Elections: next elections (President and Congress) March 1974
Political parties and leaders: Democratic Institutional Party (PID), Donaldo
Alvarez Ruiz; Revolutionary Party (PR), Carlos Sagastume Perez (Sec. Gen.);
National Liberation Movement (MLN), Mario Sandoval Alarcon; Guatemalan
Christian Democratic Party (DCG), Danilo Barillas Rodriguez, Rene de Leon
Schlotter
Voting strength: for President -- MLN-PID 251,135 (40%), PR 202,241 (32.5%), DCG
125,948 (20%) null, 7.5%; for congressional seats -- PR 16, MLN-PID 34, DCG 5
Communists: communist party outlawed; underground membership estimated at 750
Other political or pressure groups: outlawed (Communist) Guatemalan Labor Party
(PGT), Bernardo Alvarado; United Democratic Revolutionary Front (FURD) Manuel
Colom Argueta
Member of: CACM, IADB, IAEA, ICAO, IHB, OAS, ODECA, U.N.
Legal name: Republic of Guinea
Type: republic; under one-party presidential regime
Capital: Conakry
x Political subdivisions: 29 administrative regions, 209 arrondissements, about
8,000 local entities at village level
Legal system: based on French civil law system, customary law, and presidential
decree; constitution adopted 1958; no constitutional provision for judicial
review of legislative acts; has not accepted compulsory [CJ jurisdiction
Branches: executive branch dominant, with power concentrated in President''s
. hands and a small group who are both ministers and members of the party''s
politburo; unicameral National Assembly and judiciary have little independence
Government leader: President Ahmed Sekou Toure, who has been designated
"The Suprene Leader of the Revolution"
Suffrage: universal over age 18
Elections: approximate schedule -- 5 years parliamentary, latest in 1968;
7 years Presidential, latest in 1968
Political parties and leaders: only party is Democratic Party of Guinea (PDG),
headed by Sekou Toure
Communists: no Communist party, although there are some sympathizers
Member of: AFDB, ECA, FAO, ICAO, ILO, ITU, Niger River Commission, OAU, U.N.,
UNESCO, UPU, WHO, WMO','ecea0ef2412e1ce17ed45ea7d6c81186cc3071e53d1a67f7063b657efbdb6107','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51d038215f3a7322dc59e2aee584b7b54f96471138d273b54689463e2abdbd9a',1973,'GY','Guyana','government',177,'Legal name: Cooperative Republic of Guyana
Type: republic within Commonwealth
Capital: Georgetown
Political subdivisions: 9 administrative districts
Legal system: based on English common law with certain admixtures of Roman-
Dutch law; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers presided over by Prime Minister; 53-member
unicameral legislative National Assembly (elected); Supreme Court
Government leader: Prime Minister L.F.S. Burnham
Suffrage: universal over age 21
Elections: last held in December 1968; next elections 1973
Political parties and leaders: People''s Progressive Party (PPP), Cheddi Jagan;
People''s National Congress (PNC) , L.F.S. Burnham; United Force (UF),
Feilden Singh
Voting strength (1968 election): 36.5% PPP, 55.8% PNC, 7.4% UF, 0.3% other
Communists: unknown; top echelons of PPP and PYO (Progressive Youth Organization,
militant wing of the PPP) include many Communists, but rank and file is
non-Communist
Other political or pressure groups: Justice Party, Guyana United Muslim Party,
Guyana All-Indian League, African Society for Cultural Relations with
Independent Africa (ASCRIA), Progressive Youth Organization (PPP affiliate),
Young Socialist Movement (PNC affiliate), Guyana United Youth Society (UF
affiliate), Afro-Asian-American Association (AAAA), Committee for National
Reconstruction, Guyana National Party (GNP)
Member of: CARIFTA, FAQ, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAS (observer),
Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO','0b2ebce30589795ffcf285803fbd58aff1959c7d64f6c812eea034ee0a1af62b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4de6d4edd67caa659905813c8c38c7cdc451665aaace5214549a6a1ae2fb319',1973,'HK','Hong Kong','government',183,'Legal name: Colony of Hong Kong
Capital: Victoria
Type: U.K. crown colony
Political subdivisions: Hong Kong, Kowloon, and New Territories
Legal system: English common law
Branches: Governor assisted by advisory Executive Council; he legislates with
advice and consent of Legislative Council; Urban Council which alone includes
elected representatives, responsible for health, recreation, and resettlement;
independent judiciary
Government leader: C.M. MacLehose, Governor and Commander in Chief
Suffrage: limited to 200,000 to 300,000 professional or skilled persons
Elections: every 2 years to select one-half of elected membership of Urban
Council; other Urban Council members appointed by the Governor
Political parties and leaders: Civic Association, Hu Pai-fu; Reform Club, B. A.
Bernacchi; Socialist Democratic Party, Sun Po-kong; Hong Kong Labour Party,
Tang Hon-tsai
Voting strength: (elected Urban Council members) Civic Association 4, Reform
Ciub 3, and 1 independent
Communists: an estimated 2,000 hard core cadres affiliated with Communist Party
of China
Other political or pressure groups: Federation of Trade Unions (Communist
controlled), Hong Kong and Kowloon Trade Union Council (Nationalist Chinese
dominated), Hong Kong General Chamber of Commerce, Chinese General Chamber
of Commerce (Communist controlled), Federation of Hong Kong Industries,
Chinese Manufacturers'' Association of Hong Kong','9d3dc6e300842ccb8d27fff13dcb7b1e803586959de190ca0acabeeeef0adc08','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad0ecdc0c3da951ae59c11ef6f338f5d0fa2d25029057f01f226d0e6ff06e4f5',1973,'HU','Hungary','government',187,'Legal name: Hungarian People''s Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 megyes (counties), 5 autonomous cities in county
status, 97 jaras (districts
Legal system: based on Communist legal theory, with both civil law system (civil
code of 1960) and common law elements; constitution adopted 1949 amended 1972;
Supreme Court renders decisions of principle that sometimes have the effect of
declaring legislative acts unconstitutional; legal education at Lorand Eotvos
Tudomanyegyetem School of Law in Budapest and 2 other schools of law; has not
accepted compulsory ICd jurisdiction
Branches: executive -- Presidential Council (elected by Parliament); legislative
-- Parliament (elected by direct suffrage); judicial -- Supreme Court
(elected by Parliament)
Government leaders: Jeno Fock, Chairman, Council of Ministers; Pal Losonczi,
President, Presidential Council
Suffrage: universal over age 18
Elections: every 4 years; national and local elections are held separately, two
years apart
Political parties and leaders: Hungarian Socialist (Communist) Workers Party
(sole party); Janos Kadar is First Secretary of Central Committee
Voting strength (1971 election): 7,260,856 (98%) for Communist-approved candidates;
76,725 (1.4%) invalid and negative votes; total eligible electorate about
7.3 million
Communists: about 693,000 party members (June 1971)
Member of: CEMA, FAO, IAEA, ICAO, ILO, ITU, UNESCO, U.N., UPU, Warsaw Pact, WHO
Legal name: Republic of Iceland
Type: republic
Capital: Reykjavik
Political subdivisions: 23 rural districts, 215 parishes, 14 incorporated towns
Legal system: civil law system based on Danish law; constitution adopted 1944,
legal education at University of Iceland; does not accept compulsory
ICJ jurisdiction
Branches: legislative authority rests jointly with President and parliament
(Althing); executive power vested in President but exercised by cabinet
responsible to parliament; Supreme Court and 29 lower courts
Government leaders: President Kristjan Eldjarn; Prime Minister Olafur Johannesson
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1975); presidential, every
4 years (next in 1976)
Political parties and leaders: Independence (conservative), Johann Hafstein;
Progressive, Olafur Johannesson; Social Democratic, Gylfi Gislason; Labor
Alliance (Communist front), Ragnar Arnalds; Organization of Liberals and
Leftists, Hannibal Valdimarsson
Voting strength (1971 election): 36.2% Independence, 25.2% Progressive, 10.4%
Social Democratic, 17.1% Labor Alliance, organization of leftists and liberals
8.9%
Communists: 1,000; a number of sympathizers, as indicated by 18,055 votes cast
for Labor Alliance in 1971 election
Member of: Council of Europe, EC (free trade agreement pending resolution of fishing
limits issue), EFTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO,
IMF, ITU, NATO, Nordic Council, OECD, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO','e168f82c356708cd086137a63e5fee5369c133d76fa69c8d95bf5e3d4ecf89da','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0075ffb69c2456eed59284f879cabfc9bcf37bd31e5afa1fc3b6a4125b101e6',1973,'IN','India','government',191,'Legal name: Republic of India
Type: federal republic
Capital: New Dethi
Political subdivisions: 21 states, 9 union territories, 1 protectorate (Sikkim)
Legal system: based on English common law; constitution adopted 1950; judicial
review of legislative acts; accepts compulsory ICJ jurisdiction, with
reservations .
Branches: parliamentary government, national and state; independent judiciary
Government leader: Prime Minister Indira Gandhi
Suffrage: universal over age 21
Elections: national and state elections ordinarily held every 5 years; may be
postponed in emergency and may be held more frequently if government loses
confidence vote; next general election to be held by March 1976; 16 states
and two union territories held state elections in March 1972; remaining states
to be polled over next several years
Political parties and leaders: Indian National Congress split into two factions
in 1969, largest faction (the Ruling Congress) loyal to Prime Minister Gandhi
led by $.D. Sharma, and smaller faction (the Organization Congress) led by
Sadiq Ali; Communist Party of India (CPI), S. A. Dange, chairman; Communist
Party of India/Marxist (CPI/M), P. Sundarayya, general secretary; Communist
Party of India/Marxist-Leninist (CPI/ML), L.K. Advani, chairman Swatantra,
P, Mody, chairman; Bharatiya Jana Sangh, A. B. Vajpayee, president; The
Socialist Party, Kappori Thakur, chairman; Dravida Munnetra Kazhagam (DMK),
N. Karunanidhi, president
151
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Voting strength (1971 election): 43.7% Ruling Congress, 10.5% Organization Congress,
7.4% Bharatiya Jana Sangh, 3.1% Swatantra, 4.8% CPI, 5.2% CPI/M, 3.5% Socialist
Parties, 3.7% DMK, 18.1% other
Communists: 70,000 members of CPI (est.), 70,000 members of CPI/M; Communist
sympathizers, 13 million
Other political or pressure groups: Anna Dravida Munnetra Kazhagam (ADMK), M.G.
Ramachandran, president, opposing DMK in Tamil Nadu; splintered Akali Dal
representing Sikh religious community in the Punjab; various separatist groups
seeking reorganization of states, particularly in Andhra Pradesh; numerous
"senas" or militant/chauvinistic organizations, including Shiv Sena in Bombay
Member of: ADB, Colombo Plan, Commonwealth, FAO, IAEA, ICAO, IDA, IFC, IHB, ILO,
IMCO, IMF, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','75eba78e78c24d375caef3bba41dcedabad1879316e85a7c6511a57abfbdf8e2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67cebbb199fad8aad49b5a86ea141ce195dce000f7b28eee62b9b8f4b2158266',1973,'AU','Australia','government',195,'Legal name: Republic of Indonesia
» Type: republic
Capital: Jakarta
Political subdivisions: 26 first-level administrative subdivisions or provinces
which are further subdivided into 281 second-level areas
Legal system: based on Roman-Dutch law, substantially modified by indigenous
concepts; constitution of 1945 is legal basis of government; legal education
: at University of Indonesia, Jakarta; has not accepted compulsory ICJ
jurisdiction
Branches: executive headed by President who is chief of state and head of
cabinet; cabinet selected by President; unicameral legislature (Parliament),
of 460 members (100 appointed, 360 elected); second and larger body (Congress)
of 920 members and includes the legislature and 460 other members (chosen by
several processes, but not directly elected) elects President and Vice
President, and theoretically determines national policy
Government leader: President Suharto (elected by Congress March 1973)
Suffrage: universal over age 17 and married persons regardless of age
Political parties and leaders: Golkar (quasi-official "party" based on functional
groups), Amir Moertono (acting head); Indonesian Democratic Party (federation
of former Nationalist and Christian parties), Mohammed Isnaeni; Unity Development
Party (federation of former Islamic parties), Idham Chalid
Voting strength (1971 election): Golkar 236 seats, Indonesian Democratic 30,
Development Unity 94
Communists: Communist Party (PKI) was officially banned in March 1966; current
strength est. at 1,000, with less than 10% engaged in organized activity;
pre-October 1965 hard core membership has been estimated at 1.5 million
x Member of: ADB, ASEAN, FAO, IAEA, ICAO, IHB, ILO, IMF, U.N., UNESCO
153
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: Empire of Iran
Type: constitutional monarchy, controlled by the Shah
Capital: Tehran
Political subdivisions: 14 provinces and 9 independent governorates, subdivided
into districts, sub-districts, counties, and villages
Legal system: based largely on French law, with elements drawn from other
continental systems; personal law based on Islamic practice generally with
residual traces of Roman law; constitution adopted 1906 and constitutional
law of 1907; High Court of Appeal may judge disputes relating to government
departments acting according to law; legal education at University of Teheran;
has not accepted compulsory ICd jurisdiction
Branches: executive power rests in Shah who appoints a Prime Minister; Prime
Minister must be approved by lower house (Majlis); while Cabinet theoretically
responsibility of Prime Minister, Shah usually exerts strong influence over
its selection; bicameral legislature; Majlis has 268 seats (with 2 vacant
for islands of the Persian Gulf) elected to 4-year terms, and Senate 60
members serving 4-year terms; half of Senate members appointed by Shah,
other half elected; no provision for judicial review of constitutional ity
of legislative acts
Government leaders: Shah Mohammad Reza Pahlavi and Prime Minister Amir
Abas Hoveyda
Suffrage: universal over age 20
Elections: Majlis every 4 years; Senate every 4 years; latest national elections
July 1971, district and municipal elections in October 1972
Political parties and leaders: New Iran Party, Manuchehr Kalali; Mardom (Peoples)
Party, (position of Secretary General is temporarily vacant); Iranians Party,
Dr. Fazlollah Sadr; Pan Iranist Party, Mohsen Pezeshkpur (apparently moribund)
Voting strength (1971 election): Majlis -- New Iran Party, 230 seats; Mardom
Party, 37 seats; Iranians Party, 1 seat; Senate -- New Iran Party, 28 seats;
Mardom Party, 2 seats; plus 30 seats appointed by the Shah; all candidates
government approved
Communists: 1,000-2,000 (hard-core, est.); sympathizers (15,000-20,000 est.);
mostly pro-U.S.S.R. but pro-Chinese faction developing
155
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Other political or pressure groups: Tudeh Party (Communist, illegal); National
Front (coalition of neutralist urban elements virtually discredited because
i re as to Shah''s reform program); Confederation of Iranian Students
illegal
Member of: CENTO, Colombo Plan, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO,
IMF, ITU, OPEC, RCD, U.N., UNESCO, UPU, WHO, WMO
Legal name: Overseas Territory of New Caledonia
Type: French overseas territory; represented in French parliament by one deputy
and one Senator
Capital: Noumea
Political subdivisions: 4 islands or island group dependencies -- Isle of Pines,
Loyalty Islands, Huon Islands, Island of New Caledonia
Legal system: French law
Branches: administered by Governor, who is also High Commissioner for France in
the Pacific; responsible to French Ministry for Overseas France and
» Governing Council; Assemblee Territoriale
Government leader: Jean Risterucci, Governor and French High Commissioner
Suffrage: restricted (1957 election roll listed 32,370 males and females over
21 years of age, of whom 18,964 were classed as indigenous inhabitants)
Elections: Assembly elections in 1972
Political parties: Union Caledonienne, Entente Democratique et sociale, Union
Multiraciale, Mouvement Liberal Caledonien, Union Democratique, Mouvement
Populaire Caledonien
Voting strength (1972 election): Union Caledonienne, 12 seats; Entente
Sociale et Democratique, 6 seats; Union Multiraciale, 5 seats; Mouvement
Liberal Caledonien, 5 seats; Union Democratique, 4 seats; Mouvement
Populaire Caledonien, 2 seats; Caledonie Francaise, 1 seat
Communists: number unknown; Union Caledonienne strongly leftist; some political -
ly active Communists were deported during 1950''s; small number of North
Vietnamese
Other political parties and pressure groups: several lesser parties
Legal name: Province of Timor
Type: overseas province of Portugal
Capital: Dili
Political subdivisions: 12 administrative districts
Legal system: based on Portuguese law
Branches: Governor General appointed by Portuguese Minister of Overseas; advised
by a 7-member council composed of 4 ex offico members and 3 members elected
from the Legislative Council of 14 members (3 ex officio and 11 elected);
usual executive departments such as Treasury, Health, Justice, Education,
Transportation exist, each of which is headed by a director
Government leader: Governor Brig. Fernando Alves Aldea (appointed 1972)
Suffrage: high school education required
Elections: Timor elects one representative to the 150-seat Portuguese National
Assembly
Political parties and leaders: single party only, the National Popular Action
on Timor
Voting strength: limited to Portuguese on Timor and small group of Timorese
who fulfill requirement
Communists: prior to 1 October 1965, infiltration by Indonesian Communist Party
from Indonesian Timor, especially in the Oe-Cusse enclave','d5b359f17bf32686715e191dce973a6784e13a5fde21c41647eb82e03775c444','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b46b7087fb3dd32fe009c8b497b4677c54ab7913495cbf70ecddb11fcb5e578',1973,'IQ','Iraq','government',200,'Legal name: Republic of Iraq
Type: republic; one-party military regime established in July 1968
Capital: Baghdad
Political subdivisions: 16 provinces under centrally appointed officials
Legal system: based on Islamic law in special religious courts, civil law system
elsewhere; provisional constitution adopted in 1968; judicial review was
suspended; legal education at University of Baghdad; has not accepted
compulsory ICJ jurisdiction
Branches: "moderate" wing of Ba''th Party of Iraq has been in power since 1968 coup
Government leaders: President Ahmad Hasan al-Bakr; Deputy Chairman of the
Revolutionary Command Council Saddam Husayn ''Abd-al-Majid al-Tikriti
Suffrage: no elective bodies exist
Elections: none since overthrow of monarchy in 1958
Communists: Communist Party allowed token representation in cabinet
Political or pressure groups: political parties banned, major opposition to
regime is from leftwing of the Ba''th Party, Communist Party and Nasirist
groups, disaffected members of the regime and army officers
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OPEC,
U.N., UNESCO, UPU, WHO, WMO','53ff710912be850d84065fe5d20ded650a5f5db481ad300b104a44abba2aa35b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('568e25e2245826e4f491b26aca28689df5dd7dcc0a8fdca3d9b24cc5ef3288ca',1973,'NL','Netherlands','government',205,'Legal name: Jamaica
Type: independent state within Commonwealth since August 1962, recognizing
Elizabeth II as head of state
Capital: Kingston
Political subdivisions: 12 parishes and the Kingston-St. Andrew corporate area
Legal system: based on English common law; has not accepted compulsory ICJ
jurisdiction
Branches: cabinet headed by Prime Minister; 53-member elected House of Represent-
atives; 21-member Senate (13 nominated by the Prime Minister, 8 by opposition
leader); judiciary follows British tradition under a Chief Justice
Government leader: Prime Minister Michael Manley
Suffrage: universal, age 21 and over
Elections: at discretion of Governor-General upon advice of Prime Minister but
within 5 years; latest held 29 February 1972
Political parties and leaders: Jamaica Labor Party (JLP), Sir Alexander
Bustamante, Hugh Shearer; People''s National Party (PNP), Michael Manley
Voting strength (1972 general elections): 56.55% PNP, 43.21% JLP, 0.24% other
Communists: a few hundred Marxist and Communist sympathizers
Other political or pressure groups: New World Group (Caribbean regionalists,
nationalists, and leftist intellectual fraternity); Rastafarians (Negro
religious/racial cultists, pan-Africanists); New Creation International
Peacemakers Tabernacle (leftist group)
Member of: CARIFTA, FAO, GATT, IAEA, IBRD, ICAO, IFC, ILO, IMF, OAS, Pan
American Health Organization, Seabeds Committee (observer), U.N.','09358871f33c9782c20ab1e8e3ab0bbc24a7a4f013f86ff78e44fa5a3a313bc0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c349f72a9d9ddd03b70fa61cd25f8057a49d47972d6a5cc435f47fee9e86711c',1973,'JO','Jordan','government',209,'Legal name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital: ‘Amman
Political subdivisions: 8 districts (3 are under Israeli occupation) under
centrally appointed officials
Legal system: based on Islamic law and French codes; constitution adopted 1952;
judicial review of legislative acts in a specially provided High Tribunal;
has not accepted compulsory ICd jurisdiction
Branches: King holds balance of power; Prime Minister exercises executive authority
in name of King; Cabinet appointed by King and responsible to parliament;
bicameral parliament with Chamber of Deputies last chosen by national elections
in April 1967, Senate last appointed by King in September 1971; each house
contains equal representation from East and West Jordan; present parliament
subservient to executive as a result of rigged elections (April 1967);
secular court system based on differing legal systems of the former
Transjordan and Palestine; law Western in concept and structure; Sharia
(religious) courts for Muslims, and religious community council courts for
non-Muslim communities; desert police carry out quasi-judicial functions
in desert areas
Government leader: King Husayn ibn Talal al -Hashimi
Suffrage: all citizens over age 20
Political parties and leaders: political party activity illegal since 1957;
Palestine Liberation Organization and Fatah, Yasir Arafat; various smaller
fedayeen groups; Ba''th Party of Jordan, Dr. Mun''if Razzaz; National
Socialist Party, Sulayman al-Nabulusi; Muslim Brethren
173
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Communists: party actively repressed, active membership less than 100
Member of: Arab League, FAO, IAEA, IATA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO','abcc30b292bb98adfde7034b1ab20477fac970c8a64b8a18d7d5a7a528821169','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb00aecc345a882b6078771b5bb1fd896767e352eec36b8d77c642e950c5c833',1973,'KE','Kenya','government',213,'Legal name: Republic of Kenya
Type: republic within Commonwealth since December 1963
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi Area
Legal system: based on English common law, tribal law and Islamic law;
constitution enacted 1963; judicial review in Supreme Court; legal education
at University Kenya School of Law in Nairobi; accepts compulsory ICJ
jurisdiction, with reservations
Branches: President and Cabinet responsible to unicameral legislature (National
Assembly) of 170 seats, 158 directly elected by constituencies and 12
appointed by the President; Assembly must be reelected at least every
5 years; High Court, with Chief Justice and at least 11 justices, has
unlimited original jurisdiction to hear and determine any civil or criminal
proceeding; provision for systems of courts of appeal with ultimate appeal
to East African Court of Appeals
Government leader: President Jomo Kenyatta
Suffrage: universal over age 21
Elections: general election (December 1969) elected present National Assembly;
next elections promised for 1974
Political party and leaders: Kenya Africa National Union (KANU), president,
Jomo Kenyatta
Voting strength: KANU holds all seats in the National Assembly
Communists: may be a few Communists and sympathizers
Other political or pressure groups: labor unions
Member of: EAC, IAEA, ICAO, OAU, Seabeds Committee, U.N.
Legal name: Democratic People''s Republic of Korea
Type: Communist state; one-man rule
Capital: P''yongyang
Political subdivisions: 9 provinces, 3 special cities (P''yongyang, Hamhung,
Ch''ongjin), and 1 special district (Kaesong)
Legal system: based on German civil law system with Japanese influences and
a Communist legal theory; constitution adopted 1948; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
Branches: Supreme Peoples Assembly theoretically supervises Legislative and
Judicial function
Government and party leaders: Kim I1l-song, President and General Secretary
of the Korean Labor Party; Kim I1, Premier
* Suffrage: Universal at age 17
Elections: election to SPA every 4 years, but this constitutional provision not
necessarily followed -- last election December 1972
Political party: Korean Labor (Communist) Party; claimed membership of about
1.6 million, or about 12% of population
Member of: no international bodies
Legal name: Republic of Korea
Type: republic; power centralized in a strong executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities; heads centrally appointed
Legal system: combines elements of continental European civil law systems,
Anglo-American law, and Chinese classical thought; constitution approved
1972; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative (unicameral), judiciary, National Conference
of Unification
Government leaders: President Pak Chong-hui; Prime Minister Kim Chong-pil
Suffrage: universal over age 20
Elections: presidential every 6 years indirectly by the National Conference of
Unification, last election December 1972; two-thirds of the 219-member
National Assembly is elected directly for the same period within six
months of the presidential election, remaining third nominated by the
President and elected by the National Conference for a three-year term;
last election February 1973, Revitalization Group - 73 seats, Democratic
Republican Party - 73 seats, New Democratic Party - 52 seats, Democratic
Unification Party - 2 seats, Independents - 19 seats
Political parties and leaders: pro-government -- Revitalization Group (appointed)
(Chairman, Pak Tu-Chin) and Democratic Republican Party (Acting Chairman,
Yi Hyo-sang); New Democratic Party (Chairman, Yu Chin-san); Democratic
Unification (Chairman, Yang I1-tong)
Voting strength: popular vote 11,896,484; DRP 38.8%, NDP 32.8%, DUP 10.2%,
Independent 18.1%, 0.1% invalid
Communists: Communist activity banned by government; an estimated 37,000-50,000
former members and supporters
Other political or pressure groups: Federation of Korean Trade Unions; Korean
Veterans'' Association; large potentially volatile student population
concentrated in Seoul
179
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Member of: ADB, Asian Parliamentary Union, Asian People''s Anti-Communist League
(APACL), ASPAC, Colombo Plan, ECAFE, FAO, GATT, Geneva Conventions of 1949
for the protection of war victims, IAEA, IBRD, ICAO, IDA, IFC, IHB, IMCO, IMF,
INTELSAT, Inter-Parliamentary Union, INTERPOL, ITU, UNESCO, U.N. Special Fund,
UPU, WHO, WMO, World Anti-Communist League (WACL); does not hold U.N.
membership','8f74f5e65d5976750c95f622535e700efda6415572cb6607e2d8897cdf667d43','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bfd0e7fef445d70b8bf319a05462dceb1a1607270f97d8e874349f82ed7f533',1973,'KW','Kuwait','government',217,'Legal name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Al Kuwayt
Political subdivisions: 3 governorates, 10 voting constituencies
Legal system: civil law system with Islamic law significant in personal matters;
constitution took effect 1963, judicial review of legislative acts not yet
determined; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers; National Assembly
Government leader: Emir Sabah al Salim Al Sabah
» Suffrage: native born and naturalized males age 21 or over
Elections: held every 4 years for National Assembly; last held January 1971
Political parties and leaders: political parties prohibited, some small
clandestine groups are active
Communists: insignificant
Other political or pressure groups: none
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, ITU,
OPEC, OAPEC, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Laos
Type: constitutional monarchy
Capital: Vientiane (Luang Prabang royal capital)
Political subdivisions: 16 provinces subdivided into districts, cantons, and
villages
Legal system: based on civil law system; constitution of 1947 has not accepted
compulsory ICJ jurisdiction
Branches: King, 59-member National Assembly, 12-member King''s Council; according
to 1973 peace agreement, the new provisional coalition government will be
composed of Communists, non-Communists, and two individuals acceptable to both
Government leaders: King Savang Vatthana; Premier Souvanna Phouma
Suffrage: universal over age 18
Elections: National Assembly designated by King; general election last held
January 1972
Political parties and leaders: Neo Lao Hak Sat, Communist-front organization
which includes the Lao People''s Revolutionary Party (Communist), only
party active
Communists: Lao People''s Revolutionary Party (clandestine) membership unknown
Other political or pressure groups: non-Communist political groups are
informal and associated with regional family and military leaders;
Royal Armed Forces (FAR) leaders, Commander in Chief Bounpone
Makthepharack, and Generals Kouprasith Abhay, Phasouk Somly, Vang Pao,
Soutchay Vongsavanh, and Ret. Gen. Ouan Rathikoun
Member of: Colombo Plan, ECAFE, ICAO, IMF, Mekong Committee, SEAMES, U.N., UNCTAD','8869bb9dac2d921dc1a7e7e10f0fc932cb281cebb1055863d71facd44e8e49c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72ea1244146db30d666e5dfae6efc24736b5fde855f9284a63ac865cbd4acc48',1973,'LB','Lebanon','government',221,'Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law, and civil law system; consti-
tution mandated in 1920; no judicial review of legislative acts; legal
education at University of Lebanon; has not accepted compulsory ICJ
jurisdiction
Branches: power lies with President elected by parliament (Chamber of Deputies);
Cabinet appointed by President, approved by parliament; independent secular
courts on French pattern; religious courts for matters of marriage, divorce,
inheritance, etc.; by custom, President is a Maronite Christian, Prime
Minister a Sunni Muslim, and president of parliament a Shia Muslim; each of
9 religious communities represented in parliament in proportion to national
numerical strength
Government leader: President Sulayman Franjiyah
Suffrage: compulsory for all males over 21; authorized for women over 21 with
elementary education
Elections: for Chamber of Deputies, held every 4 years or within 3 months of
dissolution of Chamber; held April 1972
Political parties and leaders: political party activity is organized along
sectarian lines; numerous political groupings exist, consisting of individual
political figures and followers motivated by religious, clan, and economic
considerations; political stability dependent on maintenance of balance
between religious communities
Communists: one of largest Communist parties in Middle East; legalized in 1970;
members and sympathizers estimated at 6,000
Other political or pressure groups: Palestinian guerrilla organizations
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
185
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','b69fdc856614a36ebf537d26e46e53f0789681e3bdd4e288b57090d85356023c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61c13aef7f3613ffe699e78c299e1120116c0de9ee9eb0393efe831ff0f2d2a6',1973,'LS','Lesotho','government',225,'Legal name: Kingdom of Lesotho
Type: constitutional monarchy under King Moshoeshoe IT
Capital: Maseru
Political subdivisions: 9 administrative districts
Legal system: based on English common law and Roman-Dutch law; constitution came
into effect 1966; judicial review of legislative acts in High Court and
Court of Appeal; legal education at University of Botswana, Lesotho, and
Swaziland (located in Lesotho); has not accepted compulsory CJ jurisdiction
Branches: executive, divided between a largely ceremonial King and a Prime
Minister who leads cabinet of at least 7 members; a bicameral legislature
consisting of a National Assembly (60 seats) and a Senate (33 seats);
judicial -- 63 Lesotho courts administer customary law for Africans, High
Court and subordinate courts have criminal jurisdiction over all residents,
Court of Appeal at Maseru has appellate jurisdiction
Government leader: Prime Minister Chief Leabua Jonathan
Suffrage: universal for adults
Elections: elections held in January 1970; nullified allegedly because of election
irregularities; subsequent elections promised at unspecified date
Political parties and leaders: Basutoland Congress Party (BCP), Ntsu Mokhele;
Marema-tlou Freedom Party (MFP), Edwin Leanya; National Party (BNP),
Chief Leabua Jonathan
Voting strength: National Assembly -- BNP 32 seats, BCP 22 seats, MFP 2 seats,
LDP 2 seats, 2 seats vacant; Senate -- BNP holds 24 of 33 seats (1965
elections)
Communists: Communist Party of Lesotho banned in early 1970
Member of: Commonwealth, FAO, ILO, ITU, U.N., UNESCO, UPU, WHO
Legal name: Republic of Liberia
Type: republic; dominated by strong executive
Capital: Monrovia
Political subdivisions: country divided into 9 counties; President appoints all
officials of significance
Legal system: based on U.S. constitutional theory; recent codes drawn up by
Cornell University; constitution adopted 1847; amended 1907, 1926, 1934,
and 1955; no constitutional provision for judicial review of legislative
acts; legal education at Louis Arthur Grimes School of Law, University of
Liberia; accepts compulsory ICJ jurisdiction, with reservations
Branches: President, elected by popular vote initially for 8-year term and
eligible for successive 4-year terms, controls through appointive powers and
authority over national expenditures; 2-house legislature elected by popular
vote; judiciary consisting of Supreme Court and variety of lower courts
Government leader: President William R. Tolbert
Suffrage: universal 18 years and over
Elections: members of House of Representatives elected for 4-year terms, most
recently in May 1971; Senate members elected for 6-year terms, one-half
elected in May 1971; President Tolbert, constitutional successor to President
Tubman who died in July 1971, is eligible to complete the four year term to
vue Tubman was elected in May 1971; next scheduled presidential election May
75
Political parties and leaders: True Whig Party, in power since 1878, only
political party; President Tolbert is leader
Voting strength: 1971 elections uncontested; True Whig Party won all but a
handful of votes
Communists: no Communist Party and only a few sympathizers
Member of: AFDB, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WHO
189
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','5e2ac511ad245e3975d522993e4333a132c1f1b7f093749235c43afe1a95a98f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd73828a4ceaa1ca702675874a6daedd3303cdfd86468939614f4379d0181488',1973,'LY','Libya','government',229,'Legal name: Libyan Arab Republic
Type: republic; under military control following ouster of king on 1 September
1969; provisional constitution promulgated December 1969; loosely confederated
with Egypt and Syria in Confederation of Arab Republics (CAR) on 1 September
1971; complete union with Egypt scheduled for 1 September 1973
Capital: Tripoli (defacto)
Political subdivisions: 10 administrative provinces closely controlled by
central government; district commissioners appointed by Revolutionary
Command Council
Legal system: based on Italian civil law system and Islamic law; separate
religious courts; no constitutional provision for judicial review of legislative
4 acts; legal education at Law School, at University of Libya at Banghazi; has
not accepted compulsory ICJ jurisdiction
Branches: paramount political power and authority rests with the 11-man
Revolutionary Command Council (RCC); cabinet of 12 ministers; Parliament has
been dissolved
Government leaders: Revolutionary Command Council President Colonel Mu ‘ammar
Qadhafi
Suffrage: universal
Elections: parliamentary elections last held in May 1965; election for CAR assembly
in March 1972
Political parties and leaders: Libyan Arab Socialist Union, RCC member Major Hawad,
Secretary General; Mu-ammar Qadhafi, President
Communists: no organized party, negligible membership
Other political or pressure groups: various Arab nationalist movements and the
Arab Socialist Resurrection (Ba''th) Party with small, almost negligible
memberships may be functioning clandestinely
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
OPEC, OAPEC, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','733e93e9091a37b25ab6263669105f4a67b3171c1d198fb78989b90b64097474','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc5f2108869cb2a325d3b76fd9586062e334e7a5807b0738dc0a24f583efa1c4',1973,'LI','Liechtenstein','government',233,'Legal name: Principality of Liechtenstein
Type: hereditary constitutional monarchy
Capital: Vaduz
Political subdivisions: 11 districts
Legal system: based on Swiss law; constitution adopted 1921; judicial review of
legislative acts in a special Constitutional Court; accepts compulsory ICJ
jurisdiction, with reservations
Branches: unicameral Parliament, hereditary Prince, independent judiciary
Government leaders: Head of State, Prince Franz Joseph 11; Chief of Government,
Dr. Alfred Hilbe
Suffrage: males age 20 and over
Elections: every 4 years; next elections 1974
Political parties and leaders: Fatherland Union Party (VU), Dr. Alfred Hilbe;
Progressive Citizens Party (PCP), Dr. Gerard Batliner
Voting strength (1970 election): 50.5% VU, 49.5% PCP
Communists: none
Member of: IAEA, IPU, ITU; considering U.N. membership; under a 1923 treaty,
Switzerland handles Liechtenstein''s post and telegraph systems, customs, and
foreign relations','58ca129a7a1e9311424887dd11a9487afa524f09eb3578319cf4196118796e20','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6fc6a7c83df3fba1dcefb990d8fb31426090772ae54c5820baf939c56df992f',1973,'LU','Luxembourg','government',237,'Legal name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for administrative purposes has 3
districts (Luxembourg, Diekirch, Grevenmacher) and 12 cantons
Legal system: based on civil law system; constitution adopted 1868; judicial
review of legislative acts in the Cassation Court only; accepts compulsory
ICJ jurisdiction
Branches: parliamentary democracy; seven ministers comprise Council of Government
headed by President, which constitutes the executive; it is responsible to
the unicameral legislature, the Chamber of Deputies; the Council of State,
appointed for indefinite term, exercises some powers of an upper house;
judicial power exercised by independent courts
Government leaders: Grand Duke Jean, Head of State; Pierre Werner, Minister of
State and President of the Government as well as Minister of Treasury
Suffrage: universal and compulsory over age 21
Elections: every 5 years for entire Chamber of Deputies; latest elections Dec-
ember 1968; next election, early 1974
Political parties and leaders: Christian Social Union, Pierre Werner and Nic Mosar
(Party President); Socialist, Antone Wehenkel (Party President); Social
Democrat, Henry Cravatte (Party President); Democratic, Gaston Thorn (Party
President and Foreign Minister); Communist, Dominique Urbany
Voting strength (1968 election, approx.): 32% Socialist, 35% Christian Socialist,
15% Communist, 17% Democratic, 1% other; it should be noted that these are
percentages of votes cast rather than voters, since Luxembourg has a weighted
proportional representation system in which voters in most populous areas
have largest multiple votes
Communists: 439 party members (1971)
Other political or pressure groups: group of steel industries representing iron
and steel industry, Centrale Paysanne representing agricul tural producers;
Christian and Socialist labor unions, Federation of Industrialists; Artisans
and Shopkeepers Federation
Member of: Benelux, BLEU (Belgium-Luxembourg Economic Union), Council of Europe,
EC, FAO, IAEA, IBRD, ICAO, IFC, ILO, IMF, NATO, OECD, U.N., UPU, WEU, WHO, WMO
195
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','bd451a91b02638237383fe94ea665906280141f3f3263a7171306f11dfce8603','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84dd57af5c55c18fdd4896f64f007d91d9a7ace5f393799aabf358bbd4875ee0',1973,'MO','Macao','government',241,'Legal name: Province of Macao
Type: overseas province of Portugal
Capital: Lisbon (Portugal )
Political subdivisions: municipality of Macao, and 2 islands
Legal system: Portuguese civil law system
» Branches: Governor, who dominates legislative and executive branches, assisted
by Legislative Council with unknown number of appointed and 8 elected
members; the Urban Council with 3 governor-appointed and 4 elected members;
all high-ranking officials appointive under provisions of revised Organic
Overseas Law; new organic law to have come into effect in January 1973 to
replace legislative council with a legislative assembly
4 Government leader: Brigadier Jose Manuel Nobre De Carvalho, Governor
Suffrage: restricted to Portuguese citizens
Elections: conducted every 4 years; last held December 1972
Political parties and leaders: Portuguese National Union (Uniao Nacional) only
legal party, as in Portugal; Governor is leading political figure
Communists: numbers unknown
Other political or pressure groups: wealthy Macanese and Chinese representing
local interests, wealthy pro-Communist merchants representing China''s
interests; in January 1967 Macao Government acceded to Chinese demands which
gave Chinese veto power over administration of the enclave','b022a9d09a54092dfeef631ce252324366bdbc36d52285783bf19f374b7e33fd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a6ef78f82b7b5ed50521f4266c407f09200d544b4e6687f9ff5b43747a2afb5',1973,'MG','Madagascar','government',245,'Legal name: Malagasy Republic
Type: republic; military-civilian government established May 1972; given 5-year
mandate in popular referendum October 1972
Capital: Tananarive
Political subdivisions: 6 provinces
Legal system: based on French civil law system and traditional Malagasy law;
constitution of 1959 modified in October 1972 by law establishing
provisional government institutions; Tegal education at National School of
Law, University of Madagascar; has not accepted compulsory ICJ jurisdict4on
Branches: executive -- Gen. Ramanantsoa heads government assisted by cabinet
called Council of Ministers; National Popular Development Council
created to replace the legislature in October 1972; regular courts are
patterned after French system, and a High Council of Institutions
reviews all legislation to determine its constitutional validity
Government leader: General Gabriel Ramanantsoa
Suffrage: universal for adults
Elections: government in October 1972 postponed all political elections indefinitely
Political parties and leaders: Parti Social Democrate (PSD), led by Philibert
Tsiranana; Congress Party for the Independence of Madagascar (AKFM), led by
Richard Andriamanjato; National Movement for the Independence of Madagascar
(MONIMA), led by Monja Jaona; parties are permitted to exist but are barred
from positions of political authority because of postponement of elections
Voting strength: number of registered voters (1972) -- 3.5 million; (1972
presidential election) President Tsiranana, running unopposed, received
99.7% of votes cast; in 1970 National Assembly elections, PSD candidates
won 94%; AKFM 3%
199
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Communists: Communist party of virtually no importance; smal] and
vocal group of Communists has gained strong position in leadership
of AKFM, the rank and file of which is non-Communist
Other political or pressure groups: Joint Struggle Committee (KIM), association
af students, teachers, workers, and unemployed youth
Member of: ACCT, EAMA, FAQ, IAEA, ICAO, ILO, IMCO, ITU, OAU, OCAM,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','515a1ca348a7a33eb201b429c7309c7da4822faa3560616006b3e3f808cfe23f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7221277d021d918dbbbf61aad0418874b98a3fa0b9f1454f468ca48a5d72c3b',1973,'MW','Malawi','government',249,'Legal name: Republic of Malawi
Type: republic since July 1966; independent member of Commonwealth
Capital: Zomba
Political subdivisions: local government unit is the district
Legal system: based on English common law and customary Jaw; constitution
adopted 1964; judicial review of legislative acts in the Supreme Court of
Appeal; has not accepted compulsory ICd jurisdiction
Branches: strong presidential system with cabinet appointed by President; uni-
cameral National Assembly of 60 elected and 15 nominated members; High
Court with Chief Justice and at least 2 justices
Government leader: Life President H. Kamuzu Banda
Suffrage: universal adult
Elections: scheduled for April 1971 but not held since MCP candidates were unopposed
Political parties and leaders: Malawi Congress Party (MCP), Dr. H. Kamuzu Banda
Communists: no Communist Party; may be a few Communist sympathizers
Member of: AFDB, FAO, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU, U.N., UNESCO,
WHO, WMO','d90b1942c59f4d93c01b8e65e5f0842fce34f165bee05e5e7f3c59ce64c4bfb5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef1e6f5022c32162102ee1bdac26400f791ba1d6e1d98f0b15bf6b229baa51b8',1973,'MV','Maldives','government',256,'Legal name: Republic of Maldives
Type: republic
Capital: Male
Political subdivisions: 19 administrative districts corresponding to atolls
Legal system: based on Islamic law with admixtures of English common law primari-
Ty in commercial matters; has not accepted compulsory ICJ jurisdiction
Branches: popularly elected unicameral national legislature (Majlis) (members
elected for 5-year terms); elected President, chief executive; appointed
Chief Justice responsible for administration of Islamic law
Government leaders: President Ibrahim Nasir; Prime Minister/External Affairs
Minister Ahmed Zaki
Suffrage: universal over age 21
Political parties and leaders: no organized political parties; country governed
by the Didi clan for the past eight centuries
Communists: negligible number
Member of: Colombo Plan, U.N.
Legal name: Republic of Mali
Type: republic; under military regime since November 1968
Capital: Bamako
Political subdivisions: 6 administrative regions; 42 administrative districts
(cercles), arrondissements, villages; all subordinate to central government
Legal system: based on French civil taw system and customary law; constitution
adopted 1960, amended 1961; judicial review of legislative acts in Constitu-
tional Section of Court of State; has not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by Military Committee of National
Liberation (MCNL) composed of 11 army officers; under MCNL functional
cabinet composed of civilians and army officers; judiciary
Government leaders: Col. Moussa Traore, president of MCNL, Chief of State and
head of government
Suffrage: universal over age 2]
Political parties and leaders: former Union Soudanaise-RDA dissolved and political
activity proscribed by military government
Elections: MCNL promises elections at unspecified date
Communists: there are a few Communists and a somewhat larger number of
sympathizers
Member of: ACCT, AFDB, CEAQ, ECA, FAO, IAEA, ICAO, ILO, IMF, ITU, Niger
River Commission, OAU, OMVS, U.N., UNESCO, UPU, WHO, WMO','900dc7598137c8a59deb1439ee7bfe02611792979904b5a4fa6f91400708db85','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ea523c2511e706f72a6af628a377a6ed5d653e76c75d1b942a2ea5322fafabb',1973,'CN','China','government',261,'Legal name: Malta
Type: parliamentary democracy, independent state within the Commonwealth since
September 1964
Capital: Valletta
Political subdivisions: 2 main populated islands, Malta and Gozo, divided into
; 10 electoral districts (divisions)
Legal system: based on English common law; constitution adopted 1961, came into
force 1964; has accepted compulsory ICJ jurisdication, with reservations
Branches: executive, consisting of prime minister and cabinet; legislative,
comprising 55-member House of Representatives; independent judiciary
Government leader: Prime Minister Dom Mintoff
- Suffrage: universal over age 21; registration required
Elections: at the discretion of the Prime Minister, but must be held before the
expiration of a 5-year electoral mandate; last election June 1971
Political parties and leaders: Nationalist Party, Georgio Borg Olivier; Malta
Labor Party, Dom Mintoff
ata oo (1971 election): Labor, 28 seats (50.8%); Nationalist, 27 seats
48.1%
Communists: less than 100 (est.)
Member of: Commonwealth, Council of Europe, FAO, GATT, ICAO, ILO, IMF, Seabeds
Committee, TDB, U.N., UNESCO, WHO
Legal name: Overseas Department of Martinique
Type: overseas department of France; represented by 3 deputies in the French
National Assembly and 2 Senators in the Senate
* Capital: Fort-de-France
Political subdivisions: 2 arrondissements; 34 communes, each with a locally
elected municipal council
Legal system: French legal system; highest court is a court of appeal based
in Martinique with jurisdiction over Guadeloupe, French Guiana, and Martinique
Branches: executive, Prefect appointed by Paris; legislative, popularly elected
council of 36 members; judicial, under jurisdiction of French judicial system
Government leader: Prefect Jean Terrade
Suffrage: universal over age 21
Elections: General Council elections coincide with those for the French National
Assembly, normally every five years; last General Council election took place
in March 1973
Political parties and leaders: Union of Democrats for the Republic (UDR), Emil
Maurice; Progressive Party of Martinique (PPM), Aime Cesaire; Communist
Party of Martinique (PCM), Armand Nicolas; Democratic Union of Martinique,
Leon-Laurent Valere; Socialist Party, leader unknown; Federation of the
Left, leader unknown
Voting strength: UDR, 2 seats in French National Assembly; PPM, 1 seat (1968
election)
Communists: 700-800 active members, 10,000 sympathizers
Other political or pressure groups: Proletarian Action Group (GAP)','cb1e5c4c0c442437c3b9d711eebb36494a6038ddc50b02e4223e902556411fcb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff6c3121f0ca364aea5478b98be14f4daee60c632f609273a716da4dfbdc06fe',1973,'MR','Mauritania','government',264,'Legal name: Islamic Republic of Mauritania
Type: republic; one-party presidential rule since 1960
Capital: Nouakchott
Political subdivisions: 8 regions and a capital district
Legal system: based on French civil law system and Islamic law; constitution
adopted 1961; judicial review of legislative acts in the Supreme Court;
has not accepted compulsory ICJ jurisdiction
Branches: president; unicameral National Assembly of 50 elected members;
separate judiciary (appointed by president)
Government leader: President Moktar Ould Daddah
Suffrage: universal for adults
Elections: presidential and parliamentary election every 5 years; most recent
August 1971
Political parties and leaders: Mauritanian People''s Party is only legal party,
Secretary General Moktar Ould Daddah
Communists: no Communist Party, but there is a scattering of Maoist sympathizers
Member of: ACCT, CEAQ, EAMA, FAO, ICAO, ILO, IMCO, ITU, OAU, Organization
for the Development of the Senegal River Valley (OMVS), Seabeds Committee,
U.N., UNESCO, WHO, WMO','5ea84bb738428b266aa9cfdd1c23631c3bc48227b13c0f7b564a66e1eb8fa307','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c065567fd50f491de5d0c6a101046f17f5807966836ebeb57f83b43e721b835b',1973,'MU','Mauritius','government',268,'Legal name: Mauritius
Type: independent state since 1968, recognizing Elizabeth II as chief of state
7 Capital: Port Louis
Political subdivisions: 5 “organized municipalities" and various island
dependencies
Legal system: based on French civil law system with elements of English common
law in certain areas; constitution adopted 6 March 1968
Branches: executive power exercised by Prime Minister and 21-man Council of
Ministers; unicameral legislature (National Assembly) with 62 members elected
by direct suffrage and 8 specially elected
Government leader: Prime Minister Dr. Seewoosagur Ramgoolam
Suffrage: universal over age 21
Elections: last held in August 1967; next scheduled in 1972 postponed at least
4 years by constitutional amendment
Political parties and leaders: a loose government coalition consisting of Labor
Party (S. Ramgoolam), Muslim Committee of Action (A. R. Mohamed), and Parti
Mauricien Social Democrate (G. Duval); Independent Forward Bloc (S.
Bissoondoyal); Mauritius Democratic Union (M. Lesage); a few independents;
Mouvement Militant Mauritian (P. Berenger)
Voting strength: Muslim Committee of Action, 6 seats; Independent Forward Bloc,
6 seats; Mauritius Labor Party, 33 seats; Mauritius Democratic Union, 5 seats;
Parti Mauricien Social Democrate, 18 seats; independent 1 seat
Communists: may be 2,000 sympathizers; several Communist organizations; Mauritius
Lenin Youth Organization, Mauritius Women''s Committee, Mauritius Communist
Party, Mauritius People''s Progressive Party, Mauritius Young Communist League,
Mauritius Liberation Front, Chinese Middle School Friendly Association,
Mauritius/USSR Friendship Society
~ Other political or pressure groups: Tamil United Party, Mauritius Workers Party
Member of: ICAO, La Francophonie, Commonwealth, OAU, OCAM, U.N.
219
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Political subdivisions: 4 sections F
Legal system: based on French law; new constitution adopted 1962; has not
accepted compulsory ICJ jurisdiction
Branches: National Council (18 members); Communal Council (15 members, headed
by a mayor)
Government leader: Prince Rainier III
Suffrage: universal
Elections: National Council every 5 years; most recent 1968
Political parties and leaders: National Union of Independents, National Democratic
Entente (1965)
Voting strength: figures for 1968 election not available; (1958) 61% National
Union of Independents, 39% National Democratic Entente
Communists: not available
Member of: IAEA, IHB, ITU, U.N., UNESCO, UPU, WHO
Legal name: Mongolian People''s Republic
Type: Communist state
Capital: Ulaanbaatar
Political subdivisions: 18 provinces and 2 autonomous municipalities (Ulaanbaatar
and Darhan)
Legal system: blend of Russian, Chinese, and Turkish systems of law; constitution
adopted 1940; no constitutional provision for judicial review of legislative
acts; legal education at Ulaanbaatar State University; has not accepted
compulsory ICJ jurisdiction
Branches: constitution provides for a Great People''s Hural (national assembly)
and a highly centralized administration
Party and government leader: Y. Tsedenbal, First Secretary of the MPRP and
Chairman of the Council of Ministers
Suffrage: universal; age 18 and over
Elections: national assembly elections held every 4 years; next elections
scheduled for June 1973
Political party: Mongolian People''s Revolutionary (Communist) Party (MPRP);
estimated membership, 58,000 (claimed 1972)
Member of: CEMA, ECAFE, U.N., WHO','d55baa7948fddfdfea49c64013847b94683abeca912154ad012eac9f46345df3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20e5854480318b93d03e9af8a069a46eaf315893316a0220f1df28a5d618fe3f',1973,'MA','Morocco','government',272,'Legal name: Kingdom of Morocco
us Type: constitutional monarchy (constitution adopted 1972)
Capital: Rabat
Political subdivisions: 19 provinces and 2 prefectures
Legal system: based on Islamic law and French and Spanish civil law system;
judicial review of legislative acts in Constitutional Chamber of Supreme
Court; modern legal education at branches of Mohamed V University in Rabat
and Casablanca and Karaouine University in Fes; has not accepted compulsory
IcJ jurisdiction :
Branches: constitution provides for Prime Minister and ministers named by and
responsible to King; King has paramount executive powers; unicameral
legislature (two thirds to be directly elected; one third indirectly);
judiciary independent of other branches
Government leaders: King Hassan II; Prime Minister Ahmed Osman
Suffrage: universal over age 20
Elections: last parliamentary elections held 21 and 28 August 1970 for Council
of Representatives which was dissolved in March 1972; elections for new
parliament created by Constitution adopted 15 March 1972 have not been held
Political parties and leaders: Istiqlal Party, Allal el-Fassi; Popular Movement
(MP), Mahjoubi Aherdan; Constitutional and Democratic Popular Movement
(MPCD), Dr. Abdelkrim Khatib; National Union of Popular Forces (UNFP), split
into competitive factions under Abdallah Ibrahim and Mahjoub Ben Seddik of
Casablanca-based faction and Abderrahim Bovabid of Rabat-based faction (Rabat
faction of UNFP was suspended in April 1973); Democratic Constitutional Party
(PDC), Mohamed Hassan Quazzani; Party for Liberation and Socialism (PLS),
established in dune 1968 and banned September 1969, is front for Moroccan
Communist Party (MCP), which was proscribed in 1959, Ali Yata; Istiqlal and
e
the UNFP formed a National Front in July 1970 to oppose the new constitution,
boycotted the parliamentary elections and the 1972 constitutional referendum
Voting strength: August 1970 elections were nonpolitical; 1 March 1972
constitutional referendum tallied 98.7% for new constitution, 1.25% opposed
4 and National Front abstained from voting
Communists: 300 est.
227
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Member of: Arab League, EC (association until 1974), FAQ, IAEA, IBRD, ICAO, IDA,
TLO, IMC, IMCO, IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO','762e8508cdf9272e6959423ffd21cd0855b889cf72bf7f55afc9a3b257125003','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c03688b89e087540a2f3b28e0cddeaa72239eae1d15cf0633e4f765cd9fdffd2',1973,'NI','Nicaragua','government',285,'Legal name: Republic of Nicaragua
Type: republic
Capital: Managua
Political subdivisions: 1 national district and 16 departments
Legal system: based on Spanish civil law system; constitution adopted in 1950,
now being revised; judicial review of legislative acts in the Supreme Court;
legal education at Universidad Nacional de Nicaragua and Universidad
Centroamericana; accepts compulsory ICJ jurisdiction
Branches: President from 1 May 1972 to 1 December 1974 replaced by a triumvirate,
bicameral legislature, judiciary elected by legislature, and Supreme Electoral
Tribunal (4th branch)
Government leaders: Triumvirate members -- Roberto Martinez, Alfonso Lovo Cordero
and Edmundo Paguaga
Suffrage: universal over age 18 if married or literate, otherwise 21
Elections: every 6 years; however, due to agreement between liberal and conservative
parties, next elections will be held 1 September 1974; municipal elections
every 3 years
Political parties and leaders: Nationalist Liberal Party (PLN), Anastasio Somoza,
Ramiro Sacasa, Francisco Urcuyo, Alfonso Callejas; Traditionalist Conservative
Party (PCT), Edmundo Paguaga and Fernando Aguero Rocha; Independent Liberal
Party (PLI), not legal, Roberto Robelo, Juan Manuel Gutierrez; Social Christian
Party (PSC), not legal, Ignacio Zelaya, Manolo Morales Peralta (President)
and Roberto Ferrey (Secretary General); National Conservative Action (ANC),
not legal, Pedro J. Chamorro
aa ag (1972 elections): PLN 534,171 votes (75.4%), PCT 174,897 votes
24 .6%
Communists: Communist movement split into hard-line Nicaraguan Socialist Party
(PSN) illegal, 60 members; soft-line Nicaraguan Communist Party (PCN) illegal,
40 members, and small pro-Castro Sandinist National Liberation Front (FSLN)
50 to 60 activist; about 1,000 sympathizers
Other political or pressure groups: wealthy families; businessmen
Member of: CACM, FAO, GATT, IADB, IAEA, ICAO, ICJ, ILO, INTELSAT, ITU, OAS,
ODECA, Seabeds Committee (observer) U.N., UNESCO, UNICEF, UPU, WHO, WMO
243
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','2907dc4f29294f233b813459ba1a45a1b38854004fab44c5f81f42b4a2e7f379','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c51eb080a48e81d6833713b3542f388c52a0daed393ee0859aa62f3f709813a',1973,'NE','Niger','government',289,'Legal name: Republic of Niger
Type: republic; one-party rule established 1960
Capital: Niamey
Political subdivisions: 7 departments, 32 arrondissements
Legal system: based on French civil law system and customary law; constitution
adopted 1960; judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: President selected for 5 years by direct universal suffrage; unicameral,
60-member National Assembly elected for 5 years; judiciary constitutionally
independent of executive and legislature
Government leader: President Diori Hamani
Suffrage: universal over age 21
Elections: presidential and parliamentary elections in 1970; about 99% of voters
approved unopposed official candidates
Political parties and leaders: Parti Progressiste Nigerien (PPN), led by Diori
Hamani
Communists: no Communist party; some sympathizers in outlawed Sawaba party ;
Member of: ACCT, AFDB, CEAO, EAMA, ECA, Entente, FAO, GATT, IBRD, ICAO, ILO, IMF,
ITU, Lake Chad Basin Commission, Niger River Commission, OAU, OCAM, U.N.,
UNESCO, UPU, WHO, WMO','6a9dac9c727f56f875ccbeeb3d1110ef827d8f29b93f81ebd3f666ac311dbd42','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0034a8bf59527f02adb90a8ebea284a1cac04f7f1e8f647ab585952b0a3087d1',1973,'NG','Nigeria','government',293,'Legal name: The Federal Republic of Nigeria
Type: federal republic since 1963; under military rule since January 1966
Capital: Lagos
Political subdivisions: 12 states, 11 headed by a military governor, 1 by a
civilian administrator
Legal system: based on English common law, tribal Taw, and Islamic law; new
constitution to be prepared; accepts compulsory ICJ jurisdiction with
reservations
Branches: Federal Military Government; decrees issued by Supreme Military Council,
advised by largely civilian Federal Executive Council; effective
administrative power held by senior civil servants
Government leader: Gen. Yakubu Gowon, Head of Federal Military Government and
Commander in Chief of Nigerian Armed Forces
Suffrage: universal adult suffrage (except for women in former Northern Region)
Elections: expected to be held by 1976
Political parties and leaders: political parties and politically active tribal
societies were dissolved by decree on 24 May 1966; some sub rosa political
activity continues
Communists: the banned Socialist Workers and Farmers Party and the Nigerian Trade
Union Congress have a limited political following, no influence on government
Member of: AFDB, Commonwealth, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU,
Lake Chad Basin Commission, Niger River Commission, OAU, OPEC, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO','4a063ab330ae147d826b75adaee30d37ec1681e60fb747a96704a1a5b70ef732','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d5d2b113e760d616d4e24ac801ca53024766222393adb6db587126d6939470d',1973,'NO','Norway','government',297,'Legal name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 20 counties, 404 communes, 47 towns
Legal system: mixture of customary law, civil law system, and common law traditions;
constitution adopted 1814, modified 1884; Supreme Court renders advisory
opinions to legislature when asked; legal education at University of Oslo;
accepts compulsory ICJd jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament (Storting);
executive power vested in Crown but exercised by cabinet responsible to
parliament; Supreme Court, 5 superior courts, 104 lower courts
Government leaders: King Olav V; Prime Minister Lars Korvald
Suffrage: universal, but not compulsory, over age 20
Elections: held every 4 years (next in September 1973)
Political parties and leaders: Conservative, Kare Willoch; Christian Peoples,
Lars Korvald; Center, John Austrheim; Liberal, Helge Seip; Labor, Trygve
Bratteli; Socialist Peoples, Finn Gustavsen; Communist, Reidar Larsen
Voting strength (1969 election): 19.6% Conservative; 9.4% Christian Peoples;
10.5% Center; 9.4% Liberal; 46.5% Labor; 3.5% Socialist Peoples; 1.0%
Communist
Communists: 2,000; a number of sympathizers as indicated by the 22,500 Communist
votes cast in the 1969 election
Member of: Council of Europe, EC (Draft Free Trade Agreement), EFTA, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, Nordic Council,
OECD, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','5a9dace0951b2c95c8ab1f2ea316fcc740fc65712344618eba9f97ea3afb6707','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f61e02d1d9e136dc5cf3104112e914002f4c8a20ebd46415f8287e2f6d8566e',1973,'PK','Pakistan','government',304,'Legal name: Islamic Republic of Pakistan
Type: parliamentary, federal republic; constitution adopted April 1973, effective
August 1973, provides for bi-cameral legislature; strong prime minister
Capital: Islamabad
Political subdivisions: 4 provinces -- Punjab, Sind, Baluchistan, and Northwest
Frontier -- with the capital territory of Islamabad and certain tribal areas
centrally administered; Pakistan claims that Azad Kashmir is independent
pending a settlement of the dispute with India, but it is in fact under
Pakistani control
Legal system: based on English common law; accepts compulsory IcJ jurisdiction,
with reservations
Government leaders: President Z. A. Bhutto
Suffrage: universal over age 21
Elections: elections for National Assembly based on one-man/one-vote formula,
and for provincial assemblies were held in December 1970; with independence
of Bangladesh, National Assembly consists of 144 West Pakistanis and 2 East
Pakistanis
Political parties and leaders: Pakistan People''s Party (PPP), Z.A. Bhutto;
United Muslim League (UML), Shaukat Hayat Khan; National Awami Party (NAP),
Abdul Wali Khan; All Pakistan Muslim League (QML), Abdul Qaiyum Khan;
Markazi Jamiat-ul-Ulema-i-Pakistan (MJUP), Khamaja Qamar-u-Din Sialvi;
Jamiat-ul-Ulema-i-Islam (JUI), Mufti Mahmud
Communists: 750; 3,000-5,000 sympathizers
Other political or pressure groups: military remains potentially strong
political force
Member of: ADB, CENTO, Colombo Plan, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO,
IMCO, IMF, ITU, RCD, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','554bcce378c82f816b7277478861244432e5bb020dcfd0f7c3930a2d059cc3c6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68dd232c9208c238f523d0cb3ac81476d3ae5e261b0b8bb90ca5f5cdfcb2faf4',1973,'PG','Papua New Guinea','government',309,'Legal name: Papua New Guinea
Type: dependent territory under Administrator appointed by Australia
Capital: Port Moresby
Political subdivisions: 18 administrative districts (12 in New Guinea, 6 in Papua );
New Guinea (including Bismarck archipelago and Bougainville) is a U.N. Trust
Territory
Legal system: based on English common law; highest judicial organ is High Court
of Australia
Branches: executive -- Administrator and Executive Council; legislature --
House of Assembly (94 members, including 10 appointed); judiciary -- court
system consists of Supreme Court of Papua New Guinea and various inferior
courts (District Courts, Local Courts, Children''s Courts, Wardens’ Courts);
Supreme Court decisions may be appealed to High Court of Australia
Government leader: Administrator, L. W. Johnson; Chief Minister, Michael Somare
Suffrage: universal adult suffrage
Elections: preferential-type elections for 100-member House of Assembly every
4 years
Political parties: Pangu Party is principal political group; 5 or 6 other
small parties and numerous independents
Voting strength (1972 election): Pangu Party and allies won 52 seats, United
Party 42 seats, Independence 6 seats
Communists: no significant strength','1fd267fef9876638a05c5ad85e33558e70c21be01e4f49cff2996b8cd07c4c03','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae854c220566cc0fef86dd62a786b44e022ac0131ab3555eb78ad7608b7432f3',1973,'PL','Poland','government',313,'Legal name: Polish People''s Republic (PRL)
Type: Communist state
Capital: Warsaw
Political subdivisions: 17 provinces, 5 city provinces, 391 districts
Legal system: mixture of Continental (Napoleonic) civil law and Communist legal
theory; constitution adopted 1952; court system parallels administrative
divisions with Supreme Court, composed of 104 justices, at apex; no
judicial review of legislative acts; legal education at 7 law schools; has
not accepted compulsory ICJ jurisdiction
Branches: legislative, executive, judicial system dominated by parallel
Communist Party apparatus
Government leader: Piotr Jaroszewicz, Premier; Henryk Jablonski, chairman
of Council of State (president)
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government every 4 years
Dominant political party and leader: Polish United Workers'' Party (PZPR)
(Communist) Edward Gierek, First Secretary
Voting strength (1972 election): 97% voted for Communist-approved single slate
Communists: 2,100,000 party members (September 1971)
Other political or pressure groups: National Unity Front (FUN), including United
Peasant Party (ZSL), Democratic Party (SD), progovernment pseudo-Catholic
Pax Association and Christian Social Association, Catholic independent Znak
group; powerful Roman Catholic Church, Stefan Cardinal Wyszynski, Primate
Member of: CEMA, GATT, ICAO, IHB, Indochina Truce Commission, Korea Truce
Commission, Seabeds Committee, U.N. and all specialized agencies except IMF
and IBRD, Warsaw Pact, Vietnam ICCS (International Commission for Control
and Supervision)','14c03adeb7c93e902cc1b1d8a2449a405c68f1d46e9f746e6a86273abab656c2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51d278c8c4e7db437aa82b513149affaa302ec990a57e9f1b90f3ee0ff401c10',1973,'PT','Portugal','government',317,'Legal name: Republic of Portugal
Type: republic, with single legal party controlled by a Prime Minister
Capital: Lisbon
Political subdivisions: 18 districts in mainland Portugal and 4 "autonomous
districts" in Azores and Madeira Islands; 7 overseas provinces in Africa
and Asia, plus the state of Portuguese India whose 1961 occupation by
India is not recognized by Lisbon; Angola and Mozambique designated states
of Portugal in 1972
Legal system: civil law system; constitution adopted 1933, frequently amended
since; no judicial review of legislative acts; legal education at Universities
of Lisbon and Coimbra; accepts compulsory ICJ jurisdiction, with reservations
Branches: executive with President overshadowed by Prime Minister and Council of
Ministers; legislative with National Assembly dominated by executive and a
Corporative Chamber, the latter consultative and advisory; and judicial
controlled by executive branch
Government leader: Prime Minister Marcello Caetano, appointed September 1968
Suffrage: all citizens over age 21 who are literate and have not been deprived
of their civil rights
Elections: National Assembly, direct but government-controlled, held every 4 years,
next in October 1973; local direct parish board elections held every 4 years,
next in 1975; President, by government-controlled electoral college every
7 years, latest in July 1972
Political parties and leaders: government-controlled National Popular Action
(ANP) -- formerly called National Union -- only legally recognized political
organization; insignificant Monarchist Cause group is tolerated by regime;
various opposition groups include -- Communist Party (PCP) whose secretary,
Alvaro Cunhal, is in exile; a dissident Communist exile group, Patriotic
Front of National Liberation (FPLN); and several small non-Communist groups
267
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Political parties and leaders (cont''d):
such as the moribund Democratic Social Action (ADS); Portuguese Socialist
Action (ASP) leader Mario Soares (in exile); extremist opposition group,
League of Revolutionary Union and Action (LUAR) has been dormant since 1970,
with leader, Herminio de Palma Inacio in exile abroad; Armed Revolutionary
Action (ARA) is radical and violence-prone group which appeared in October
1970, and has claimed credit for various sabotage acts and has ties with the
Portuguese Communist Party; self-styled Revolutionary Brigades with Maoist
orientation involved in various bombings since 1971
Voting strength (1969 election): National Union, as ANP was then called, won all
130 seats in National Assembly in first contested election; seats raised to
150 in 1971
Communists: 2,000-7,000 est.; sympathizers cannot be determined
Other political or pressure groups: Portuguese Legion, Portuguese Youth,
Association for the Study of Economic and Social Development (SEDES)
authorized in October 1970 as a discussion group with political overtones
Member of: EFTA, FAQ, IAEA, IBRD, ICAO, IHB, ILO, IMF, ITU, NATO, OECD, Seabeds
Committee (observer), U.N., UPU, WHO, WMO
Legal name: Province of Guinea
Type: overseas province of Portugal
Capital: Bissau
Political subdivisions: 9 municipalities, 3 circumscriptions (predominantly
indigenous population)
Legal system: based on Portuguese law
Branches: Governor General appointed by Ministry of Overseas has wide local
authority; he is assisted by an appointed Secretary-General and a 9-man
consultative Council; a 17-member Legislative Assembly, 12 of whose members
are elected by various groups, represents economic and tribal interests of
province; Minister of Overseas can nullify any provincial legislation or
Governor''s decision; judiciary based on Portuguese system
Government leader: Governor General and military commander is Gen. Antonio
Sebastiao Ribeiro de Spinola
Suffrage: limited to those satisfying fairly rigid economic and cultural
requirements
Elections: Legislative Assembly elections held every 4 years in March, last
held in 1973
Political parties and leaders: National Popular Action (ANP) of Portugal only
legal party sends one representative to National Assembly in Lisbon; opposition
parties (illegal) include Partido Africano da Independencia da Guinee e Cabo
Verde (PAIGC), led by Aristide Pereira, a Communist-supported nationalist party
which is chief political force conducting current rebellion against Portuguese
rule and which operates mainly from Republic of Guinea and the Republic of
Senegal; Front de Lutte pour 1''Independence Nationale de la Guinee (FLING),
a largely dormant, loose coalition of Senegal-based nationalist elements
opposed both to the Portuguese and the PAIGC, leadership fragmented;
other nationalist factions
Communists: none known','90e8000881635aea3d45430def5db95c5841d24e0a6052203e807e255a11e10e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44c719d8cfdf63ac652705b544eb75f685336150e832d97893a08002387eb14e',1973,'QA','Qatar','government',322,'Legal name: State of Qatar
Type: traditional monarchy; independence declared in 1971
Capital: Ad Dawhah
Legal system: discretionary system of law controlled by the ruler, although new
civil codes are being implemented; Islamic law is significant in personal
matters; a constitution was promulgated in 1970
Government leader: Amir Khalifa ibn Hamad Al-Thani
Suffrage: no specific provisions for suffrage laid down
Elections: constitution calls for elections for part of State Advisory Council,
semi-legislative body, but none have been held
Political parties and pressure groups: none; a few small clandestine organizations
are active
Branches: Council of Ministers
Member of: Arab League, U.N.
Legal name: Overseas Department of Reunion
Type: overseas department of France; represented in French Parliament by three
Deputies and two Senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a Prefect appointed by the French Minister
of Interior, assisted by a Secretary-General and an elected 36-man General
Council
Government leader: Prefect Paul Cousseran
Suffrage: universal adult
Elections: last municipal elections in 1971; parliamentary election March 1973
Political parties and leaders: Reunion Communist Party (RCP) led by Paul Verges,
only organized political movement on island; other political candidates
affiliated with metropolitan French parties, which do not maintain permanent
organizations on Reunion
Voting strength (parliamentary election 1973): Gaullist candidates swept all 3
districts
Communists: Communist Party small -- probably only 15-20 hard-line Communists --
but has support among sugarcane cutters and in Le Port district
Legal name: Colony of Southern Rhodesia
Type: self-proclaimed independent state since 1965 (not recognized by U.S.)s
provisional settlement with U.K. in November 1971 cancelled by U.K. in
May 1972 in response to Pearce Commission''s conclusion that its terms were
unacceptable to the majority of black Rhodesians
Capital: Salisbury
Political subdivisions: 11 magisterial districts
Legal system: Smith government implemented a republican constitution on 2 March
1970 which institutionalized white rule
Branches: President Dupont is ceremonial head of state; executive council
(cabinet) lead by Prime Minister Smith; National Assembly gives highly
disproportionate representation to white minority -- 50 white constituency
seats and 16 black constituency seats
Government leaders: Prime Minister Ian Smith and President Clifford Dupont
Suffrage: franchise is based on income, property holdings, and education; there
are separate rolls for Africans and non-Africans
Elections: must be held every 5 years
Political parties and leaders: Rhodesian Front, Prime Minister Smith; Centre
Party, Pat Bashford; Rhodesian Party, Allan Savory; African National Council,
Abel Muzorewa
Voting strength (1970 elections): Rhodesian Front won all 50 white constituency
seats in Parliament
Communists: negligible
Other pressure groups and leaders: African nationalist organizations banned
from political activity -- Zimbabwe African People''s Union, Joshua Nkomo;
Zimbabwe African National Union, Ndabaningi Sithole; these leaders detained
by government; exiled leaders in Lusaka, Zambia, are Jasopo Moyo (ZAPU)
and Herbert Chitepo (ZANU); Front for the Liberation of Zimbabwe (FROLIZI),
James Chikerena and Nathan Shamuyarra
Member of: no international bodies
281
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','8697f40241b7d404f6d7555190ba42906d00708b1e9cf322391a586dda4c786a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a1b6d18ab60726d3e9c7ad503ed563c89f695abeef968ee022bfb2184a6b745',1973,'SM','San Marino','government',329,'Legal name: Republic of San Marino
Type: republic (dates from 4th century A.D.); in 1862 the Kingdom of Italy
concluded a treaty guaranteeing the independence of San Marino; although
legally sovereign, San Marino is vulnerable to pressure from the Italian
Capital: San Marino
Political subdivisions: San Marino is divided into 9 sections: Guaita, Fratta,
Serravalle, Domagnano, Acquaviva, Fiorentino, Montegiardino, Faetano,
Chiesanuova
Legal system: based on civil law system with Italian law. influences; electoral
Jaw of 1926 serves some of the functions of a constitution; has not accepted
compulsory ICJ jurisdiction
Branches: the Grand and General Council is the legislative body elected by popular
vote; its 60 members serve 5-year terms; Council in turn elects two Captains-
Regent who exercise executive power for term of 6 months, the Council of
State whose members head government administrative departments and the Council
of Twelve, the supreme judicial body; actual executive power is wielded by
the Secretary of State for Foreign Affairs and the Secretary of State for
Internal Affairs
Government leaders: Secretary of State for Foreign Affairs Gian Luigi Berti
(Christian Democratic party); Secretary of State for Internal Affairs
Giuseppe Lonferini (Christian Democratic party); Secretary for finance Remy
Giacomini (Socialist)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General Council required at least every
5 years; next elections 1974
Political parties and leaders: Christian Democratic party (DCS), Gian Luigi Berti;
Social Democratic Party (PSDSM), Alvaro Casali; Socialist Party (PSS), Remy
Giacomini; Communist Party (PCS), Umberto Barulli
Voting strength (1969 election): 45% DCS, 25% PCS, 18.3% PSDIS, 11.7% PSS
Communists: approx. 300 members (number of sympathizers cannot be determined) ;
PSS, in government with Christian Democrats since March 1973, formed a
government with the PCS from the end of World War II to 1957
Other political parties or pressure groups: political parties influenced by
policies of their counterparts in Italy, the two Socialist parties are
not united
Member of: ICd, International Institute for Unification of Private Law,
International Relief Union, IRC, UPU
293
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','00be464daec6bd1c49eddbb553a165d6cd1836c12af8e1abdc78b601a6b3cb0f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('083ae5a3d23ba1cbdd5e37df971fef2bb687de468f65591b8d481728b20b0e1e',1973,'SA','Saudi Arabia','government',333,'Legal name: Kingdom of Saudi Arabia
Type: monarchy
Capital: Riyadh; foreign ministry and foreign diplomatic representatives located
in Juddah
Political subdivisions: 18 amirates
Legal system: largely based on Islamic law, several secular codes have been
introduced; commercial disputes handled by special committees; has not
accepted compulsory ICd jurisdiction
Branches: King Faysal (Al Saud, Faysal ibn Abd al-Aziz) rules in consultation
with ruling family, Council of Ministers, and religious leaders
Government leader: King Faysal
bd Communists: negligible
Member of: Arab League, FAO, IAEA, IATA, IBRD, ICAO, IDA, IFC, IMF, ITU, OAPEC,
OPEC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Socialist Federal Republic of Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
Political subdivisions: 6 republics with 2 autonomous provinces (within the
Republic of Serbia)
Legal system: mixture of civil law system and Communist legal theory; constitution
adopted 1963 and amended in 1967, 1968, and 1971; in early stage of development
is a system of judicial review of legislative acts in Constitutional Court
(a quasi-judicial body); legal education at several law schools; has not
accepted compulsory ICJ jurisdiction
Branches: parliament (Federal Assembly) constitutionally supreme; executive
includes cabinet (Federal Executive Council) and the federal administration;
independent judiciary; the State Pesidency is a collective policymaking body
based on proportional representation of all the republics and provinces, Tito
presides as President of the Republic
Government leader: Josip Broz Tito, President of Republic and President of
League of Communists of Yugoslavia
Suffrage: universal over age 18
Elections: Federal Assembly elected every 4 years
Political parties and leaders: League of Communists of Yugoslavia (LCY) only;
leaders are President Tito and influential presidium members Edvard Kardelj,
Veljko Viahovic, Mijalko Todorovic, Viadimir Bakaric, Krste Crvenkovski,
and Stane Dolanc
Voting strength: Voter participation in national elections has declined, as
follows -- 1963, 95.5%; 1965, 93.6%; 1967, 89%; 1969, 88%
Communists: 1,025,000 party members (1971)
Other political or pressure groups: Socialist Alliance of Working People of
Yugoslavia (SAWPY), the major mass front organization for the LCY;
Confederation of Trade Unions of Yugoslavia (CTUY), Union of Youth of
Yugoslavia (UYY); Federation of Yugoslav War Veterans (SUBNOR)
373
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Member of: CEMA (observer but participates in certain commissions), EC (trade
agreement effective 1 May 1970, FAQ, GATT, IAEA, IBRD, ICAO, IHB, ILO, IMCO,
IMF, ITU, OECD (participant in some activities), Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Republic of Zaire (until October 1971 known as Democratic Republic
of the Congo)
Type: republic; constitution establishes strong presidential system
Capital: Kinshasa
Political subdivisions: 8 regions and federal district of Kinshasa
Legal system: based on Belgian civil law system and tribal law; new constitution
promulgated 1967; legal education at National University of Zaire;
has not accepted compulsory ICJ jurisdiction
Branches: president elected 1970 for seven-year term; National Legislative
Council of 420 members elected for five-year term; the official party is
the supreme political institution
Government leaders: Lt. Gen Mobutu Sese Seko, President
Suffrage: universal and compulsory over age 18
Elections: presidential and legislative elections in October and November 1970
Political parties and leaders: Mouvement Populaire de la Revolution (MPR), only
legal party, organized from above with actual grassroots popularity not
clearly definable
Voting strength: MPR slate polled 96.3% of vote in 1970 elections
Communists: no Communist Party; U.S.S.R. and People''s Republic of China have
diplomatic missions in Zaire
Member of: AFDB, EAMA, FAO, IAEA, ICAO, IHB, ILO, ITU, OAU, UDEAC, U.N., UNESCO,
UPU, WHO, WMO','09476164891660cec9247a7c2bcc0fc2d7271d4e93655755d9c4f15f2ff381df','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3c9b99aad6dd6c3eeb94c3b45f11f7d3b95a8e4ff086651d638b1dff2b96b87',1973,'SN','Senegal','government',337,'Legal name: Republic of Senegal
Type: republic; only one legal party since 1966
Capital: Dakar
Political subdivisions: 7 regions, each subdivided into 18 departments, 90
districts, and 34 communes
Legal system: based on French civil law system; constitution adopted 1960,
revised 1963 and 1970; judicial review of legislative acts in Supreme
Court (which also audits the government''s accounting office); legal
education at University of Dakar; has not accepted compulsory ICJ jurisdiction
Branches: Government dominated by President who is assisted by Prime Minister,
appointed by President and subject to dismissal by President or censure by
National Assembly; 80-member National Assembly, elected for 5 years
(effective 1973); President elected for 5-year term (effective 1973) by
universal suffrage; judiciary headed by Supreme Court, with members appointed
by President
Government leaders: Leopold Sedar Senghor, President; Abdou Diouf, Prime Minister
Suffrage: universal adult
Elections: single party (UPS) presidential and legislative elections held
February 1973
Political parties and leaders: Union Progressiste Senegalaise (UPS), ruling
party led by President Leopold Senghor, has absorbed all major opposition
parties; illegal parties include Communist-backed Parti Africain
de 1''Independence (PAI) and Parti Communiste Senegalais (PCS), a splinter
group
Communists: a few Communists and sympathizers; PAI is pro-Moscow; PCS is
pro-Peking
Other political or pressure groups: labor unions are controlled by party;
students and teachers occasionally strike
Member of: ACCT, AFDB, CEAO, EAMA, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF,
ITU, OCAM, Organization for the Development of the Senegal River (OMVS),
U.N., UNESCO, UPU, WHO, WMO
297
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','de5be60e3f68826b023e5b3f9c1e115a3989b1fba1b8d38ead58b80c29712ed3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bba3cf73425a3b2993d53809bc126647f0257431102f53e355d55e81e993d31',1973,'SC','Seychelles','government',341,'Legal name: Colony of the Seychelles
Type: British crown colony
Capital: Victoria, Mahe Island
Legal system: based on English common law, French civil law system, and
customary Taw
Branches: Governor, Council of Ministers, Legislative Assembly
Government leader: Governor Sir Bruce Greatbatch
Suffrage: universal adult
Elections: November 1970, held every 5 years
Political parties and leaders: Seychelles Democratic Party (SDP), James R.
Mancham, President; Seychelles Peoples United Party (SPUP), France
Albert Rene, President ;
Voting strength: SDP won 4 seats on Governing Council with 52.8% popular vote
in 1970 election; SPUP won 5 seats with 47.2% of votes
Communists: negligible
Other political or pressure groups: trade unions which are appendages of
political parties
Legal name: Republic of Sierra Leone
Type: republic under presidential regime since April 1971
Capital: Freetown
Political subdivisions: 3 provinces; divided into 12 districts with 146 chief-
doms, where paramount chief and council of elders constitute basic unit of
government; plus western area, which comprises Freetown and other coastal
areas of the former colony
Legal system: based on English law and customary laws indigenous to local
tribes; constitution adopted April 1971; highest court of appeal is the
Sierra Leone Court of Appeals; has not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by President; parliament consists of 97
members, 85 of whom are elected representatives and 12 paramount chiefs
representing tribal councils in provincial districts; independent judiciary
Government leader: Siaka Stevens, President, heads APC government composed
of members of his political party
Suffrage: universal over age 21
Elections: the maximum life of an elected parliament is 5 years, but it may be
dissolved earlier by the President; parliamentary election held in May 1973;
President is elected by parliament for 5 year term; next presidential election
1976
Political parties and leaders: All People''s Congress (APC), headed by Stevens;
Sierra Leone People''s Party (SLPP) is the opposition party
Communists: no party, although there are a few Communists and a slightly larger
number of sympathizers
Member of: AFDB, Commonwealth, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Sikkim
Type: autonomous protectorate of India ruled by a hereditary maharaja as
titular ruler; tied to India by 1950 treaty and brought under further
control by 1973 agreement; ruler controls only palace affairs;
external relations, defense, and communications are India''s exclusive
responsibility
Political subdivisions: none known
Legal system: constitution in preparation
Branches: Executive Council appointed from elected legislature with Indian
chief executive as head of administration
Government leader: Maharaja Paldem Thondup Namgyal, known as the Chogyal of
Sikkim
Suffrage: universal suffrage
Elections: to be held every 4 years beginning in 1973
Political parties and leaders: Sikkim National Congress Party; Sikkim National
Party; Sikkim State Congress/Janta Congress
Communists: no overt presence','724281b0e53c322677aef8b3c08491a85faa5787f5d94e22d85e78b9da8888f5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7fd7d7ac230b2a7f78dd155cc90703ff1cffb85f285d2c8b95092a710dec72a',1973,'SG','Singapore','government',345,'Legal name: Republic of Singapore
Type: republic within Commonwealth since separation from Malaysia in August 1965
Capital: Singapore
Legal system: based on English common law; constitution based on preindependence
State of Singapore constitution; legal education at University of Singapore;
has not accepted compulsory ICJ jurisdiction
Branches: ceremonial President; executive power exercised by Prime Minister and
cabinet responsible to unitary legislature
Government leaders: President, Dr. Benjamin Sheares; Prime Minister, Lee Kuan Yew
Suffrage: universal over age 20; voting compulsory
Elections: normally every 5 years
Political parties and leaders: government -- People''s Action Party (PAP), Lee
Kuan Yew; opposition -- Barisan Sosialis Party (BSP), Dr. Lee Siew Choh;
Workers'' Party, J.B. Jeyaretnam; Communist Party i1]egal
Voting strength (1972 election): PAP won all 65 seats in parliament and received
70% of vote; remaining 30% to four opposition parties
Communists: 200-500; Barisan Sosialis Party infiltrated by Communists
Member of: ADB, ASEAN, Colombo Plan, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Somali Democratic Republic
Type: republic; under military rule since October 1969
Capital: Mogadiscio
Political subdivisions: 11 regions, 56 districts
Organization: the junta has assumed all authority, calling itself the Supreme
Revolutionary Council, membership of which consists of 18 army and 3 police
officers; the Council has abrogated the constitution, dissolved the parliament,
and banned political parties
Government leader: President of the Supreme Revolutionary Council, Gen. Mohamed
Siad Barre
Communists: possibly some Communist sympathizers in the government hierarchy
Member of: AFDB, EAMA, FAO, IBRD, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UNICEF,
UPU, WHO','f20d7130c024560e295390d460ff493115bbeeef584220ac4750c800cd9561f7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df3118f335f41859ee2670e19aa571ef31fdb53617ff1d1d9949ca8282e3b277',1973,'ZA','South Africa','government',349,'Legal name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative, Cape Town; judicial, Bloemfontein
Political subdivisions: 4 provinces, each headed by centrally appointed
administrator; provincial councils, elected by white electorate, retain
limited powers
Legal system: based on Roman-Dutch Taw and English common law; constitution
enacted 1961, changing the Union of South Africa into a Republic; possibility
of judicial review of Acts of Parliament concerning dual official languages;
accepts compulsory ICJ jurisdiction, with reservations
Branches: President as formal chief of state; Prime Minister as head of
government; Cabinet responsible to bicameral legislature; lower house
elected directly by white electorate; upper house indirectly elected and
appointed; judiciary maintains substantial independence of government
influence
Government leader: Prime Minister Balthazar J. Vorster
Suffrage: general suffrage limited to whites over 18 (17 in Natal Province)
Elections: must be held at least every 5 years; last elections April 1970
Political parties and Jeaders: National Party, B. J. Vorster, P. W. Botha,
C. Mulder, M. C. Botha, Jan De Klerk; United Party, Sir De Villiers
Graaff; Progressive Party, Colin Eglin, Helen Suzman; Herstigte Nasionale
Party, Albert Hertzog, Jaap Marais
Voting strength (1970 general elections): of 166 legislative seats, National
Party 118, United Party 47, Progressive Party 1
Communists: small Communist Party illegal since 1950; party in exile maintains
headquarters in London; Dr. Yasuf Dadoo, Michael Harmel, Joe Slovo
Other political groups: (insurgent groups in exile) African National Congress
(ANC), Oliver Tambo; Pan-Africanist Congress (PAC), leadership in dispute
Member of: IAEA, IBRD, ICAO, IHB, IMF, ITU, Seabeds Committee (observer), U.N.,
UPU, WHO, WMO
309
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: Territory of South-West Africa
Type: administered as part of Republic of South Africa, since a League of
Nations mandate in 1920; U.N. formally ended South Africa''s mandate, and
status now in dispute
Capital: Windhoek
7 Political subdivisions: police zone (police-protected area, consisting of 17
magisterial districts, in which all-white settlement and several Bantu
reserves are found), northern territories (exclusively Bantu magisterial
districts under control of officials of South African Department of Bantu
Administration and Development )
Legal system: based on Roman-Dutch law and customary law
Branches: administrator, appointee of South African Government, principal
local executive; structure similar to that of a province of the Republic;
South-West Africa elects 4 Senators and 6 lower house members to the
Republic''s legislature; judicial system patterned on that of Republic
Government leader: B.J. van der Walt, Administrator
Suffrage: limited to white adults
Elections: last general election, 1970
Political parties and leaders: white parties -- National Party (NP), led in
South-West Africa by A. H. du Plessis; United National South-West Party
(UNSWP), J. P. Niehaus; nonwhite parties -- South-West Africa People''s
Organization (SWAPO), almost exclusively based on Ovambo tribe led by Sam
Nujoma, in exile; South-West Africa National Union (SWANU), primarily based
on Herero tribe, leaders in exile; National Unity Democratic Organization
. (NUDO), primarily based on Herero tribe Ted by Clements Kapuuo
Voting strength: NP (1970 election) won all 10 seats in Republic legislature
and all 18 seats in South-West Africa Legislative Assembly
Communists: no Communist Party, but some influence by South African Communists
and other Communists on South-West African Bantu outside territory
* Other political or pressure groups: National Convention, an alliance of 10 non-
white parties and other groups that oppose separate development for tribal
homelands
31]
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','485e7b0fb6a77bb6b5169b055d657699db9c41c60fa52179c6b31758a58afb0b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('807a06219b0fdc81573b88afbba312325e9c98467b3b249cc8fa765b0bdf72eb',1973,'SD','Sudan','government',354,'Legal name: Democratic Republic of the Sudan
Type: republic under military control since coup in May 1969
Capital: Khartoum
Political subdivisions: 9 provinces, provincial and local administrations
controlled by central government; limited regional autonomy in 3 southern
provinces
Legal system: based on English common Taw and Islamic law; some separate
religious courts; constitution adopted 1956, suspended 1958, restored on an
interim basis in 1964; suspended with military coup in May 1969; temporary
constitution established by Republican order in August 1971; the following
constituent assembly expected to complete draft of permanent constitution
in 1973; Revolutionary Command Council established in 1969 dissolved in
October 1971 with the installation of Ja''far al-Numayrias president and
chief executive; Numayri has reorganized government through a series of
Republican decrees; legal education at University of Khartoum and Khartoum
extension of Cairo University at Khartoum; accepts compulsory ICJ jurisdiction,
with reservations
Branches: Numayri was installed as president on 12 October 1971 following
presidential plebiscite in which he was the only candidate; present cabinet
appointed 9 October; local and provincial closely administered by central
government (C)
Government leader: President and Prime Minister Ja''far al-Numayri
Suffrage: universal adult
Elections: parliamentary elections, first after 6 years of military rule held
in April and May 1965 in 6 northern provinces; latest elections in April
1968; presidential plebescite held in September 1971 elections to constituent
assembly held in September-October 1972
Political parties and leaders: all parliamentary political parties outlawed since
May 1969; the ban on the Sudan Communist Party was not enforced until after
abortive coup in July 1971; the government''s mass political organization, the
Sudan Socialist Union, was formed in January 1972
Voting strength: not tabulated by party
Communists: party decimated following July 1971 coup and counter-coup, several
top leaders including Secretary-General Mahjub executed; actual hard-core
membership down to lowest point in years; party control over labor unions,
professional groups and university student groups ended; Communists purged
321
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
from government; party is being reorganized underground under leadership of
Secretary-General Muhammad Nijud
Other political or pressure groups: Ansar Muslim sect, at odds with the military
regime since the May coup, defeated in fighting in spring 1970; Sudan Opposition
Front, composed of former political party elements and other disgruntled
conservative interests, operates in exile
Member of: AFDB, Arab League, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
Seabeds Committee, U.N., UPU, WMO
Legal name: Surinam
Type: territory within Kingdom of the Netherlands, enjoying complete domestic
autonomy
Capital: Paramaribo
Political subdivisions: 9 districts, each headed by district commissioner
responsible to Minister of Internal Affairs
Legal system: Dutch civil law system; country statute of 1955 serves as
constitution
Branches: Council of Ministers headed by a Minister-President, which constitutes
the Cabinet; 39-member legislative council (Staten) popularly elected for
4-year term; court system administered by Attorney-General under Minister
of Justice and Police
Government leader: Minister-President, Jules Sedney
Suffrage: universal over age 23
Elections: every 4 years or earlier upon request of Minister-President
Political parties and leaders: National Party of Surinam (NPS), Hendrick A. E.
Arron; United Hindustani Party (VHP), J. Lachmon; Action Group (AG), R. Janki;
Progressive National Party (PNP), Frank E. Essed; Surinam Democratic Party
(SDP), B. F. J. Oostburg; United Indonesian People''s Party (SRI), F.
Karsowidijojo; Javanese Farmers! Party (KTPI), H. I. Soemita; Nationalist
Republic Party (PNR), Edward Bruma (principal leftist party); United Peoples
Party (VVP), led by apolitical or Chinese businessmen
Voting strength (1969): 27.7% NPS, 35.1% VHP, .2% AG, 23.3% PNP, 1.1% SDP, 3.4%
SRI, 8.8% other
Communists: no overt Communist Party; PNP believed to have Communist sympathizers
Member of: EC (associate), WHO
323
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: Kingdom of Swaziland
Type: monarchy, under King Sobhuza I1; independent member of
Commonwealth since September 1968
Capital: Mbabane (administrative), Lobamba (royal and legislative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-Dutch law in statutory courts,
Swazi traditional law and custom in traditional courts; constitution
adopted in 1968; legal education at University of Botswana, Lesotho, and
Swaziland (located in Lesotho); has not accepted compulsory ICJ jurisdiction
Branches: in April 1973 King repealed the constitution, dismissed parliament, and
assumed personal rule; he intends ruling under a King-in-Council arrangement
with the cabinet being retained as an advisory council; former members of
parliament continue to receive their salaries and new constitution probably
will be drawn up later
Government leader: Head of State and government King Sobhuza II; Prime
Minister Makhosini Dlamini
Suffrage: universal for adults
Elections: first elections for Legislative Council held in June 1964; latest
in May 1972
Political parties and leaders: Imbokodvo, the traditionalist party, controlled
by King Sobhuza II; the opposition Ngwane National Liberatory Congress
(NNLC), led by Dr. Ambrose Zwane, has been dissolved
Voting strength: in 1972 elections, Imbokodvo won 21 seats, NNLC won 3 seats in
the House of Assembly
Communists: no Communist Party
Member of: AFDB, OAU, U.N.','3d81f301cbf3272a1d88c13a0e2e12c8b5993f3f35a7314a34dc22e793ab918b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f354b72a486ab77eba74a7e156210f0c900ea8d19beacae84e38082f8f3961fc',1973,'TG','Togo','government',363,'Legal name: Togolese Republic
Type: republic; under military rule since January 1967
Capital: Lome
Political subdivisions: 19 circumscriptions
Legal system: based on French civil Jaw and customary practice; no constitution;
has not accepted compulsory ICU jurisdiction
Branches: military government, with civilian participation in the cabinet, took
over on 14 April 1967, replacing provisional government created after
January coup; no legislature; separate judiciary including State Security
Court established 1970
Government leader: Maj. Gen. Etienne Eyadema, President
Suffrage: universal adult
Elections: presidential referendum of January 1972 elected Etienne Eyadema for
indefinite period
Political parties: single party formed by President Eyadema in September 1969,
Rassembiement du Peuple Togolais, structure and staffing of party closely
controlled by government
Communists: no Communist Party; possibly some Communists and sympathizers
Member of: ACCT, AFDB, EAMA, ECA, ENTENTE, FAO, IBRD, ICAO, ILO, IMF, ITU,
OAU, OCAM, U.N., UNESCO, UPU, WHO, WMO','5b227735573a0db92338acb8c689d27315dd67e78099e81bea89c69c35d50ad9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95e2b683ce77b038e8d08126d0162d0d31a5989e32d5dc17ff771aa47e5a8ae2',1973,'TO','Tonga','government',367,'Legal name: Kingdom of Tonga
Type: constitutional monarchy
Capital: Nukualofa
Political subdivisions: 3 main island groups (Tongatapu, Haapi, Vavau)
Legal system: based on English law
Branches: Executive (King and Privy Council); Legislative (Legislative Assembly
composed of 7 nobles elected by their peers, 7 elected representatives of
the people, 7 Ministers of the Crown; the King appoints one of the 7 nobles
to a speaker); Judiciary (Supreme Court, magistrate courts, Land
Court
Government leaders: King Taufa''ahau Tupou IV; Premier, Prince Tu''ipelehake
(younger brother of the King)
Suffrage: granted to all literate adults over 21 years of age who pay taxes
Elections: held triennially
Communists: none known
Member of: Commonwealth','415ff5c954051240448e44c74057e4026220d360065e8a25b1943c2143884f4e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9102aeab6a3b2abc03bd8a2fb7f2e4de297af5f8e410c2219e5e5a80a8184fa',1973,'TN','Tunisia','government',372,'Legal name: Republic of Tunisia
Type: republic
Capital: Tunis
Political subdivisions: 14 governorates (provinces)
Legal system: based on French civil law system and Islamic law; constitution
patterned on Turkish and U.S. constitutions adopted 1959; some judicial
review of legislative acts in the Supreme Court in joint session; legal
education at Institute of Higher Studies and Ecole Superieure de Droit of the
University of Tunis; has not accepted compulsory ICU jurisdiction
Branches: executive dominant; unicameral legislative largely advisory; judicial,
patterned on French system and Koranic law
Government leader: President Habib Bourguiba; Prime Minister Hedi Nouira
Suffrage: universal over age 21
Elections: national elections held every 5 years; last elections 2 November 1969
Political party and leader: Destourian Socialist Party, Habib Bourguiba
Voting strength (1969 election): 100% Destourian Socialist Party
Communists: 100 est.; a few sympathizers; Tunisian Communist Party proscribed in
1962
Member of: Arab League, EC (association until 1974), FAO, IAEA, IBRD, ICAO, IDA,
IFC, ILO, IMCO, IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO, UPU,
WHO, WMO
Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Fahri Koruturk, Prime Minister Naim Talu
Suffrage: universal over age 2]
Sega. National Assembly and Senate (1/3 of seats) (October 1973); Presidential
1980
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
Peopie''s Party (RPP), Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Republican Reliance Party (RRP), Turhan Feyzioglu; National Action Party
(NAP), Alparslan Turkes; Nation Party (NP), Osman Bolukbasi; Unity Party (UP),
Mustafa Timisi; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced resignation of Demirel
government in March 1971 and remains an influential force in government
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAQ, IAEA,
TBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECD, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO
345
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','7e50fd0bde2e3e11a6e2f40596c9e4073f8ad328e66903ce5ee3c119e05acdde','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1454f1204e4c9cb313ca4ca095f40962993982ad3cef2f86c31e428c4c3e52b9',1973,'UG','Uganda','government',376,'Legal name: Republic of Uganda
Type: republic independent since October 1962
Capital: Kampala
Political subdivisions: 9 provinces and 34 districts
Legal system: based on English common law and customary law; constitution
adopted 1967; present government has abrogated some parts of constitution;
judicial review of legislative acts; legal education at Makerere University,
Kampala; accepts compulsory ICJ jurisdiction, with reservations
Branches: Gen. Amin rules by decree; assisted by Council of Ministers and Defense
Council, a group of military officers
Government leader: Gen. Idi Amin, President
Suffrage: universal adult
Elections: none scheduled by military government
Political party and leader: Uganda People''s Congress (UPC), principal party
before 1971 coup, not banned but inactive
Communists: possibly a few sympathizers
Member of: AFDB, Commonwealth, EAC, IAEA, ICAO, ILO, OAU, U.N., UNESCO, WHO
Legal name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow
Political subdivisions: 15 union republics, 20 autonomous republics, 6 krays,
116 oblasts, and 8 autonomous oblasts
Legal system: civil law system as modified by Communist legal theory; constitution
adopted 1936; no judicial review of legislative acts; legal education at 18
universities and 4 law institutes; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers (executive), Supreme Soviet (legislative), Supreme
Court of U.S.S.R. (judicial)
Government leaders: Leonid I. Brezhnev, General Secretary of the Central Committee
of the Communist Party; Aleksey N. Kosygin, Chairman of the Council of
Ministers; Nikolay V. Podgornyy, Chairman of the Presidium of the U.S.S.R.
Supreme Soviet
Suffrage: universal over age 18; direct, equal
Elections: to Supreme Soviet every 4 years; 1,517 deputies elected in 1970;
72.3% party members
Political parties and leaders: Communist Party of the Soviet Union (CPSU) only
party permitted
Voting strength (1970 election): 153,237,112 persons over 18; claimed 99.96%
voted
Communists: nearly 14,700,000 party members
Other political or pressure groups: Komsomol, trade unions, and other organizations
which facilitate Communist control
Member of: CEMA, Geneva Disarmament Conference, IAEA, ICAO, ILO, IMCO, ITU, U.N.,
UNESCO, UPU, Warsaw Pact, WHO, WMO','2e04d8db83562cd481be1db694de2003d9d46510eaf72a43fc814d536c29ca86','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1f0f12c9ea6a5f639f170732b75c631185618a3c825537bdf097f23c84404c4',1973,'AE','United Arab Emirates','government',380,'Legal name: United Arab Emirates (composed of former Trucial States)
Type: federal system; constitution signed December 1971, which delegated
specified powers to the United Arab Emirates central government and
reserved other powers to member sheikhdoms
Capital: Abu Zaby
Legal system: secular codes are being introduced by the U.A.E. government and
in several member sheikhdoms; Islamic law remains very influential
Branches: Supreme Council of Rulers (7 members), from which a President and Vice
President are elected; Prime Minister and Council of Ministers; National
Consultative Council; federal judiciary provided for in constitution but not
yet activated
Government leaders: Sheikh Zayid of Abu Dhabi, President; Sheikh Rashid of Dubai,
Vice President; Sheikh Maktum of Dubai, Prime Minister
Suffrage: none
Elections: none
Member states: Abu Dhabi; Ajman; Dubai; Fujairah; Ras al Khaimah; Sharjah; Umm
al Qaiwain
Member of: Arab League, U.N.
Political or pressure groups: none; a few small clandestine groups are active
Legal name: Republic of Upper Volta
Type: republic; transitional military regime in power since January 1966, will
rule until 1974
Capital: Ouagadougou
Political subdivisions: 5 departments consisting of 44 cercles
Legal system: based on French civil law system and customary law; constitution
adopted 1970; judicial review of legislative acts in Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: President is an army officer; 57-man National Assembly was elected in
December 1970; 4 year transition period will follow during which President
will rule over 15-man cabinet, one-third of which will be military; separate
judiciary
Government leader: Gen. Sangoule Lamizana, president
Suffrage: universal for adults
Elections: National Assembly elections held in late December 1970; RDA-UDV holds
38 seats, PRA 12, MLN 5, Independent 2
Political parties and leaders: 7 legally recognized parties; Voltan Democratic
Union-African Democratic Rally (UDV-RDA), Gerard Kango Quedraogo; African
Regroupment Party (PRA), D. Pale Welte Issa; Movement for National Liberation
(MLN), Joseph Kizerbo; People''s Action Group (GAP), Nohoun Sigue; Union for
the New Voltaic Republic (UNR), Blaise Bassoleth; Party of National Regroupment
(PRN), Francois Bassolet; Party of Voltan Workers (PTV), George Kabore;
National Union of Independents (UNI), Kassoum Kargougou
Communists: no Communist party; possibly some sympathizers
Other political or pressure groups: labor organizations are badly splintered,
students and teachers occasionally strike
Member of: ACCT, AFDB, EAMA, CEAQ, ECA, ENTENTE, FAQ, ICAO, ILO, ITU, Niger River
Commission, OAU, OCAM, U.N., UNESCO, WHO, WMO','325d47b974effc1343b3a311f27df371e75843639d8a82448ab2fd025086b989','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('841265b00212c442fe8459aa14f3b98e61d766af156b220a73801a5ab1af30b0',1973,'UY','Uruguay','government',385,'Legal name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes St. Peter''s, the Vatican Palace
and Museum and neighboring buildings covering more than 13 acres; 13
buildings in Rome, although outside the boundaries, enjoy extraterritorial
rights
Legal system: Canon law; constitutional laws of 1929 serve some of the functions
of a constitution
Branches: the Pope possesses full executive, legislative, and judicial powers;
he delegates these powers to the governor of Vatican City, who is subject
to pontifical appointment and recall; high Vatican offices include the
Secretariat of State, the College of Cardinals (chief papal advisers), the
Roman Curia (which carries on the central administration of the Roman
Catholic Church) the Presidence of the Prefecture for the Economy, and
the synod of bishops (created in 1965)
Government leader: Supreme Pontiff, Paul VI, (Giovanni Battista Montini, born
26 September 1897, elected Pope 21 June 1963)
Suffrage: limited to cardinals less than 80 in age
Elections: Supreme Pontiff elected for life by College of Cardinals
Communists: none known
Other political or pressure groups: none (exclusive of influence exercised
by other church officers in universal Roman Catholic Church)
Member: IAEA
Legal name: Republic of Venezuela
Type: republic
Capital: Caracas
Political subdivisions: 20 states, 1 federal district, 2 federal territories
Legal system: based on Spanish civil law system with influence of U.S. law;
constitution promulgated 1961; judicial review of legislative acts in
Cassation Court only; dual court system, state and federal ; legal education
at Central University of Venezuela; has not accepted compulsory ICJ
jurisdiction
Branches: executive (President), bicameral legislature, judiciary
Government leader: President Rafael Caldera
Suffrage: universal and compulsory over age 18
Elections: every 5 years; next 9 December 1973
Political parties and leaders: Accion Democratica (AD), Carlos Andres Perez, and
Gonzalo Barrios; Social Christian Party (COPEI), Rafael Caldera, and Lorenzo
Fernandez; People''s Electoral Movement (MEP), Jesus Angel Paz Galarraga;
Cruzada Civica Nacionalista (CCN), Marcos Perez Jimenez, leader; Union
Republicana Democratica (URD), Jovito Villalba; Partido Comunista de
Venezuela (PCV), Secretary-General Jesus Faria; Fuerza Democratica Popular
(FDP), Jorge Dager; Frente Nacional Democratico (FND), Pedro Segnini La Cruz;
Movement to Socialism (MAS), Jose Vincente Rangel, Teodoro Petkoff, and
Pompey Marquez
Voting strength (1968 election): 25.6% AD, 24.1% COPEL, 13% MEP, 10.9% CCN, 9.3%
URD, 5.3% FDP, 2.8% Union for Advancement (Communist front), 2.6% FND, 2.3%
PRIN
Communists: minuscule in numbers and effectiveness
Other political or pressure groups: APEL (a conservative business group); PRO
VENEZUELA (leftist, nationalist economic group); DESARROLLISTAS (group of
wealthy, independent businessmen led by former finance minister Pedro Tinoco
and historian Guillermo Moron)
Member of: Andean Pact, CARIFTA, FAO, IADB, IAEA, IBRD, ICAO, IDB, IFC, ILO, ITU,
OAS, Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO
361
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: Democratic Republic of Viet-Nam
Type: Communist state
Capital: Hanoi
Political subdivisions: 2 autonomous regions {of 3 and 5 provinces, respectively),
17 other provinces, 2 centrally governed municipalities, 1 special zone
Legal system: based on Communist legal theory and French civil Taw system;
constitution enacted 1960
Branches: constitution provides for a National Assembly and highly centralized
executive nominally subordinate to it
Party and government leaders: Le Duan, First Secretary; Ton Duc Thang, President
of DRV; Pham Van Dong, Premier; Truong Chinh, Chairman, Standing Committee
of National Assembly; Vo Nguyen Giap, Minister of National Defense
Suffrage: over age 18
Elections: pro forma elections held for national and local assemblies
Political parties: ruled by Lao Dong Party with no organized opposition;
membership approximately 900,000 (about 4% of population)
Member of: no international bodies
Legal name: Republic of Viet-Nam
Type: republic
Capital: Saigon
Political subdivisions: 4 regions (corresponding to 4 military regions), 1 special
region (corresponding to Capital Special Zone), divided into 44 provinces
and 11 autonomous municipalities
Legal system: based on French civil law system; legal education at Universities
of Saigon and Hue
Branches: constitution provides for modified presidential system with executive,
legislative, and judicial branches
Government leaders: President Nguyen Van Thieu; Vice President Tran Van Huong;
Prime Minister Tran Thien Khiem
Elections: senate elections scheduled for August 1973; next presidential elections
scheduled for 1975
Suffrage: all citizens 18 and older are eligible to register to vote
Political parties and leaders: under a December 1972 law, President Thieu''s
Democracy Party is the only fully qualified legal party; two new independent
coalitions, the Catholic based Freedom Party and the Local Democratic
Alliance will have provisional status until early 1974
Communists: The People''s Revolutionary Party operates through and within the
National Front for the Liberation of South Vietnam (NLF) and the Alliance of
National, Democratic, and Peace Forces (ANDPF), and the Provisional Revolu-
tionary Government (PRG) designed to rival the legal government
Other political or pressures groups: religious groups often have more influence
than parties; the An Quang Buddhists are the most important opposition group;
Catholic groups range from progovernment to opposition; the independent Hoa
Hao and Cao Dai politico-religious sects exert strong influence in local areas.
Member of: Colombo Plan, FAO, IAEA, ICAO, ILO, IMCO, ITU, U.N. (certain specialized
U.N. agencies and maintains observer team), UNESCO, UPU, WHO, WMO
365
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Legal name: The Independent State of Western Samoa
Type: constitutional monarchy under native chiefs special treaty relationship
with New Zealand
Capital: Apia
Legal system: based on English common law and local customs; constitution came
into effect upon independence in 1962; judicial review of legislative acts
with respect to fundamental rights of the citizen; has not accepted
compulsory ICd jurisdiction
Branches: Head of State and Executive Council; Legislative Assembly; Supreme
Court, Court of Appeal, Land and Titles Court, village courts
Government leaders: Head of State, Malietoa Tanumafili II; Prime Minister,
Fiame Mata‘afa
Suffrage: 45 Samoan members of Legislative Assembly are elected by holders of
matai (heads of family) titles (about 5,000); 2 European members are elected
by universal adult suffrage
Elections: held triennially, last in February 1973
Political parties and leaders: no clearly defined political party structure
Communists: unknown
Member of: ADB, Commonwealth, ECAFE, WHO
Legal name: People''s Democratic Republic of Yemen
Type: republic; power centered in ruling National Front Party
Capital: Aden; Madinat ash Sha''b, administrative capital
Political subdivisions: 6 provinces
Legal system: based on Islamic law (for personal matters) and English common
law (for commercial matters); highest judicial organ, Federal High Court,
interprets constitution and determines disputes between states
Branches: Presidential Council; cabinet; Supreme People''s Council
Government leaders: Chairman of Presidential Council, Salim Rubay Ali; Prime
Minister Ali Nasir Muhammed al-Hasani; NF Secretary General Abd Al-Fattah
Ismail
Suffrage: granted by constitution to all citizens 18 and over
Elections: elections for legislative body, Supreme People''s Council, called for
in constitution; none have been held
Political parties and leaders: National Front (NF), only legal party
Communists: few known
Member of: U.N.
Legal name: Yemen Arab Republic
Type: republic
Capital: San‘a’
Political subdivisions: 8 provinces
Legal system: based on Turkish law, Islamic law, and local customary law; first
constitution promulgated December 1970; has not accepted compulsory ICJ
: jurisdiction
a Branches: President, Prime Minister, Republican Council, Consultative Council
Government leaders: President Abd al-Rahman Iryani; Prime Minister Abdullah
al-Hajri
Communists: few known
Political parties or pressure groups: some pro-Iraqi Baathists, other small
4 clandestine groups supported by Yemen (Aden)
Member of: Arab League, FAO, ICAO, ITU, U.N., UNESCO, UPU, WHO','34125c56d9444d89821908de233ec6ff428b766a8eef454923b8a179960ac70e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abecc38f689037b9a2153ef10c1907a257305dcccd6f383e00235ad1ada17b9e',1973,'US','United States','government',389,'Legal name: United States of America
Legal system: based on English common law; dual system of courts, state and
federal; constitution adopted 1789; judicial review of legislative acts;
accepts compulsory ICJ jurisdiction, with reservations
Voting strength (1972 presidential election): Republican Party (Nixon),
45,767,000; Democratic Party (McGovern), 28,358,000; minor parties, 1,121,000
Communists: Party membership, 10,000-11 ,000 (est.); General Secretary, Gus Hall
Member of: ADB, ANZUS, CENTO, Colombo Plan, FAO, GATT, IAEA, IBRD, ICAO, IDA,
IDB, IFC, ILO, IMCO, IMF, ITU, NATO, OAS, OECD, SEATO, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO','356f59592fb8997a1a0db315dde6096d678233b15d59fd62ba51b0f620a3cf9d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

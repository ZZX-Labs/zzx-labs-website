SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69a5dafda996059cace0542ad882a5ddb988661759d868c3c0965782892ba793',1973,'','','people-and-society',2,'Population: 37,717,000, average annual growth rate 2.6%
(current) ,
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English ;
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force
ARABIA','f8b7605ba1b2a23088aac7fcfb362b6313b7efb6c969c93029fd1c2dc7706c95','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3861891b1c6e2cd763eea1fd3dc536ee99130dfbefde5373ed053fbc5573860',1973,'','','people-and-society',2,'Population: 38,198,000, average annual growth rate 2.6%
(10/65-10/70)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force','49fded7edad1505d176731698caed4da46556420727747bae87bb3d1dba995fc','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05d94d4742982ae05e3bb6772389ef6dd500b78e4f95d900fea438b210c0253f',1973,'','','people-and-society',2,'Population: 38,198,000, average annual growth rate 2.6%
(10/65-10/70)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force','49fded7edad1505d176731698caed4da46556420727747bae87bb3d1dba995fc','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e94e62c0ee9aa337904ebd5e009737d7da46ef935bb338da5e2784a3a0a4f8ba',1973,'','','people-and-society',2,'Population: 18,088,000, average annual growth rate
2.3% (FY71)
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9% Uzbeks,
©: 9% Hazaras, minor ethnic groups include Chahar,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11%
Turkic languages (primarily Uzbeki and Turkmeni), 10% 30 minor languages
(primarily Baluchi and Pashai); much bilingualism
Literacy: under 10%
Labor force: about 4.3 million (official est.); 75%-80% agriculture and animal
husbandry, 20%-25% commerce, small industry, services; massive shortage of
skilled labor
Organized labor: none','eb350ad090aeeeb95c3532fa4c6e5d206b82fdeddb321f54d4d08d93150e7382','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13488a25586232a1f91554eace053b972aad0918fd8951a3531791cd682c2cf5',1973,'AL','Albania','people-and-society',7,'Population: 2,288,000, average annual growth rate 2.8% :
(current) pers
Ethnic divisions: 96% Albanian, remaining 4% are Greeks,
Viachs, Gypsies, and Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10% Roman Catholic (observances
prohibited; Albania claims to be the world''s first atheist state)
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics available, but probably
greatly improved
Labor force: 911,000 (1969); 60.5% agriculture, 17.9% industry, 21.6% other
nonagricultural
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ALGERTA
950,000 sq. mi.; 3% cultivated, 16% pasture and meadows,
1% forested, 80% desert, waste, or urban
Land boundaries: 3,890 mi.
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 735 mi.
Ty 15,455,000, average annual growth rate 3.1%
FY71
Ethnic divisions: 99% Arab-Berbers, less than 1% Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 2.8 million; 47% agriculture, 8% industry, 24% other (military,
police, civil service, transportation workers, teachers, merchants,
construction workers); 40% of urban labor unemployed
Organized labor: 17% of labor force claimed; General Union of Algerian
Workers (UGTA) is the only labor organization and is subordinate to the
National Liberation Front
Population: 26,000, average annual growth rate 9.3%
(FY62-69)
Ethnic divisions: Catalan stock; 30% Andorrans, 61%
Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French and
Castilian
Labor force: unorganized; largely shepherds and farmers
i woseco) ALGERIA
Population: 5,861,000, average annual growth rate 1.6%
(December 60-70)
Ethnic divisions: 93.6% African, 5% Europeans, 1.4% mulatto (1960)
Religion: about 84% animist, 12% Roman Catholic, 4% Protestant
Language: Portuguese (official), many native dialects
Literacy: 10%-15%
Labor force: 2.6 million economically active (1964); 531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)
Population: 75,000, average annual growth rate 2.6% erase
(April 60-70)
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other Protestant sects and some
Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000
Population: 24,193,000, average annual growth rate 1.6%
(September 60-70)
Ethnic divisions: approximately 85% white, 15% mestizo, Indian, or other
nonwhite groups
Religion: 90% nominally Roman Catholic (less than 20% practicing), 2%
Protestant, 2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 9.5 million; 19% agriculture, 25% manufacturing, 20% services,
11% commerce, 6% transport and communications, 19% other
Organized labor: 25% of labor force (est.)
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','58b57c910343dd91d5ced19f68435e46cff014a4b972aa9adc1228e1d048a709','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8470d8f46945803efa640df7d5dc922455b41459f1c5a91cc2e845110b8a654a',1973,'AT','Austria','people-and-society',10,'32,400 sq. mi.; 20% cultivated, 27% meadows and pastures,
14% waste or urban, 38% forested, 1% inland water
Land boundaries: 1,605 mi.
Population: 7,475,000, average annual growth rate 0.2%
(January 71-72)
Ethnic divisions: 98.1% German, .7% Croatian, .3% Slovene,
.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8% none or Bey ‘Aumcnin
other
Language: German
Literacy: 98%
Labor force: 3,248,000 (of which 828,200 are self-employed); 18% agriculture
and forestry, 49% industry and crafts, 18% trade and communications, 7%
professions, 6% public service, 2% other; 2.4% registered unemployed; an
estimated 200,000 Austrians are employed in other European countries;
foreign labor about 75,000 (1970)
Organized labor: about 2/3 of wage and salary workers (1971)
Population: 195,000, average annual growth rate 4%
(November 63-April 70)
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: mainly Church of England; some Protestant, Greek Orthodox, and
Roman Catholic
Language: English
Labor force: 60,000 (1963); 25% organized
Population: 228,000, average annual growth rate 2.9%
(February 65-April 71)
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani, and
Indian, 3% other
Religion: Muslim
Language: Arabic
Literacy: about 30% (1965)
Labor force: 53,274 (1965)
geo Ny 63,590,000*, average annual growth rate 1.9%
FY70
Ethnic divisions: predominantly Bengali; fewer than ]
million "Biharis" and fewer than 1 million tribals
Religion: about 83% Muslim, 16% Hindu; less than 1% Buddhist and other
Language: Bengali
Literacy: about 20%
Labor force: about 24 million; majority are unemployed or underemployed;
over 80% of labor force is in agriculture
Population: 236,000 (official estimate for 1 July 1971)
Ethnic divisions: 80% African, 15% mixed, 5% European
Religion: Anglican, Roman Catholic, Methodist, and Moravian
Language: English
Literacy: over 90%
Labor force: 60,000 wage and salary earners
Organized labor: 19,300 (32%)','5a109fe06f7e1128f524a4715ab3379e8e2cfe77416baec3631495fd9cfce31a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79661427c223d2c0f00513881f5e964723bad04292d3314947b7dfd4b48ddb31',1973,'BE','Belgium','people-and-society',20,'Approved For Release Sa A ae Reo esa ace
21 sq. mi.3; 8% arable, 60% forested, 21% built on,
wasteland, and other, 11% leased for air and
naval bases','70aedffe6ad8d307a76d135b957414c6aa25fa8bdf70adfe0ea79fa07c1c0c0f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42e427c5cfec5ab2d8404ee56f3ca96e9d7842d31c727f43c818a864a97892a2',1973,'CA','Canada','people-and-society',21,'Limits of territorial waters (claimed): 3 n. mi. vireo stares
Coastline: 64 mi. a
Population: 55,000, average annual growth rate 2.1%
(October 60-70)
Ethnic divisions: approximately 63% African, 37% white
Religion: 47.5% Church of England, 10.2% Catholic, 38.2% other Protestant, 4.2%
other
Language: English
Literacy: virtually 100%
Labor force: 19,498 employed (1960)
Population: 884,000, average annual growth rate 2.3%
(current)
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese,
15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25% Buddhist-influenced
Hinduism
Language: Bhotias speak various Tibetan dialects, most
widely spoken dialect is Druk-ke, the official language; Nepalese speak
various Nepalese dialects
Literacy: insignificant
at force: 300,000; 99% agriculture, 1% industry; massive lack of skilled
abor
Population: 4,952,000, average annual growth rate 2.5%
(current)
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic
Language: Spanish Aymara, Quechua
Literacy: 35%-40%
Labor force: 1.9 million (1967); 69.1% agriculture, 3.3% mining, 9.6% services
and utilities, 8% manufacturing, 10% other
Organized labor: 40%-50% of labor force
ea. 699,000, average annual growth rate 3.1%
FY71)
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% European
» Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 32% in Tswana;
less than 1% secondary school graduates
Labor force: most are engaged in sheep raising and subsistence agriculture
(statistics unavailable); about 28,000 in internal cash economy, another
39,000 spend at least 6 to 9 months per year as wage earners in South
Africa (1971)
Organized labor: negligible','39de82dac2657818a9d4176b5f449efcb237b2df6bbdd08811a9964ff2364484','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be87c476468107ba64ff9173100ff654638456e8964605b750c548b3aa8cdd3e',1973,'BR','Brazil','people-and-society',25,'Population: 96,622,000, average annual growth rate 2.9%
(September 1960-70)
Ethnic divisions: 61.8% white, 26.6% brown, 11% Negro, 0.6% yellow (Brazilian
census color classifications, 1950)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: about 61% over age 14
Labor force: 33 million in 1970 (est.); 44.2% agriculture, livestock, forestry,
and fishing, 17.8% industry, 15.3% services, transportation, and communication,
8.9% commerce, 4.8% social activities, 3.9% public administration, 5.1% other
Organized labor: about 50% of labor force; only about 1.5 million pay dues
Population: 129,000, average annual growth rate 2.9%
(April 60-70)
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican, Seventh-day Adventist, Methodist,
Baptist, Jehovah''s Witnesses, Mennonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 34,000; 39% agriculture, 14% manufacturing, 8% commerce,
12% construction, 20% transportation, and 7% services; shortage of skilled
labor and all types of technical personnel; over 15% are unemp loyed
Organized labor: 8% of labor force
Population: 145,000, average annual growth rate 4.5%
(August 60-71)
Ethnic divisions: 52% Malays, 28% Chinese, 15% indigenous
tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8% Christian; 32% other (Buddhist
and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture, 32.8% industry, manufacturing, and
construction, 33.8% trade, transport, services, 2.9% other
Organized labor: 8.4% of labor force
Population: 9,721,000, average annual growth rate 2%
(November 60-April 70)
Ethnic divisions: 85%-90% mestizo, 3% Indian, 7% European, Asiatic, and other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 84%
Labor force: 3.1 million (1969); 26% agricultural, 25% industry and construction,
27% services, 14% commerce, 4% mining, 4% other (1969)
Organized labor: 25% of labor force (1969)
Population: 2,000 (official est. for 1 July 1971)
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); over 95% (est.) in agriculture, mostly sheepherding
eae 340,000, average annual growth rate 1.5%
FY7] BRAZIL
Ethnic divisions: 90% Negro or Mulatto, less than 5% East
Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force
Population: 5,651,000, average annual growth rate 2.8%
(current)
Ethnic divisions: 41.4% Indian, 58.6% Ladino (mestizo and
westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks an Indian language as
a primary tongue
Literacy: about 30%
Labor force: 1.5 million (1969); 63.2% agriculture, 12.4% manufacturing, 11.8%
services, 12.6% other, 2% unemployed; severe shortage of skilled labor;
oversupply of unskilled labor; of this total an estimated 10% are unemployed
at any one time
Organized labor: 5% of labor force (1970)
ea 4,068,000, average annual growth rate 2.6%
FY67)
Ethnic divisions: 99% African (3 major tribes - Fulani,
Malinke, Sodssou; and 15 smaller tribes)
Religion: 75% Muslim, 24% animist, 1% Christian
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written language
Labor force: 1.8 million, of which less than 10% are wage earners; most of
population engages in subsistence agriculture
Organized labor: virtually 100% of wage labor force loosely affiliated with the
National Confederation of Guinean Workers, which is closely tied to the PDG
ee eas 1,547,000, average annual growth rate 3.1%
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7% Indian and other
Religion: over 90% Roman Catholic, remainder mainly Protestant
Language: Spanish; about 14% speak English as native tongue; many Panamanians
bilingual
Literacy: 80% of population 10 years of age and over
Labor force: 468,000 (1969 est.); 40% agriculture, 19.9% services, 11% commerce,
12% manufacturing, 6% construction, 5% transportation and communications, 26%
other (1969 poy 5.6% Canal Zone; national average of 7%-8% unemployed; 25%
to 30% of unemployed in Panama and Colon; shortage of skilled labor but an
oversupply of unskilled labor
Organized labor: 5% of labor force','841f3da94ec48013058e144fabeebe649c635a50975417aaf8a01062267e5911','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95e7fbc8036a96585e88e18eed83f0a29170d0c8add2b854166fc0a730e3e70e',1973,'BG','Bulgaria','people-and-society',27,'Population: 8,624,000, average annual growth rate 0.7% ne
(current)
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsies, 2.5% Macedonians, 0.3% Armenians, 0.2% Russians, 0.6% other
Religion: regime promotes atheism; religious background of population is 85%
Bulgarian Orthodox, 13% Muslim, 0.8% Jewish, 0.7% Roman Catholic, 0.5%
Protestant, Gregorian-Armenian and other
Language: Bulgarian; secondary languages closely correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 4.4 million (July 1970); 38% agriculture, 33% industry, 29% other
hg 29,156,000, average annual growth rate 2.2%
FY70
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2% Kachin,
2% Chin, 2% Chinese, 3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their own languages
Literacy: 60% (official claim)
Labor force: 10 million; 67% agriculture, 13% industry, 20% services, commerce,
and transportation
Organized labor: no figure available; old labor organizations have been
disbanded, and government is forming one central labor organization
be 3,724,000, average annual growth rate 2.0%
FY71
Ethnic divisions: Africans -- 86% Hutu (Bantu), 13% Tutsi
(Hamitic), 1% Twa (Pigmy); non-Africans include (late
1968) 3,000 Europeans, 1,000 Asians
Religion: over 60% Christian (50% Catholic, 10% Protestant) 3].
rest mostly animist plus smal] number of Muslims
Language: Kirundi and French official
Literacy: about 55% in Kirundi, 10% in Swahili, or 6% in French
Labor force: 1,865,471 (1970 est.)
Organized labor: sole group is the Union of Burundi Workers (UTB), membership
about 30,000, affiliated with government party
gear 7,231,000, average annual growth rate 2.2%
FY69
Ethnic divisions: 89% Khmer (Cambodian), 3% Vietnamese,
5% Chinese, 3% other minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian
Literacy: 55% (est.)
Labor force: 2.56 million; 80.9% agriculture, 5.5% sales, 4.7% manufacturing,
transport, communications, 3.9% professional, administrative, clerical,
3.5% defense; 1.5% unemployed
Organized labor: .5% of labor force
pe ey 6,094,000, average annual growtn rate 1.7%
(FY70
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroori Hightanders, 19% Equatorial Bantu, 8% North West
Bantu, 10% Fulani, 7% Eastern Nigritic, 11% Kirdi, 13% other African, less
than 1% non-African
Religion: about one-half animist, one-third Christian; rest Muslim
Language: English and French official, 24 major African language groups
Literacy: South 49%, North 10%
Labor force: most of population engaged in subsistence agriculture and herding;
260,000 wage earners (maximum) including 22,000 government employees, 63,000
paid agricultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force','28723152d83c30319d0e9adb14ff853561d717f19c58f40aee67110071adb4c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52a533a1ed55439efb08a6e5307f5dbd53bbeee7b55e3d3f97d952235caf1e4f',1973,'CF','Central African Republic','people-and-society',31,'Population: 1,692,000, average annual growth rate 2.2%
(FY68-71)
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and linguistic
characteristics; Banda (32%) and Baya-Mandjia (29%) aref
largest single groups; 6,500 Europeans, of whom 6,000
are French and majority of the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 27% animist, 5% Muslim; animistic
beliefs and practices strongly influence the Christian majority
Language: French official; Sangho, the lingua franca and unofficial national
language ;
Literacy: estimated at 5%-10%
Labor force: about half the population economically active, 80% of whom are in
agriculture; approximately 50,000 salaried workers
Organized labor: 1% of labor force
Approved For Release 2004/09/15 : cae aca dese ea
496,000 sq. mi.; 17% arable, 35% pastureland, 2% forest
and scrub, 46% other uses and waste
Land boundaries: 3,720 mi.
Population: 3,828,000, average annual growth rate 2.0%
(FY67-71)
Ethnic divisions: over 240 tribes representing 12 major
ethnic groups -- Muslims (Arabs, Toubou, Fulani,
Kotoko, Hausa, Kanembou, Baguirmi, Boulala, and
Wadai) in the north and center and non-Muslims (Sara,
Mayo-Kebbi, and Chari) in the south; some 150,000
nonindigenous, 5,000 of them French
Religion: about half Muslim, 5% Christian, remainder animist
Language: French official; Chadian Arabic is lingua franca in north, Sara and
Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically active group, of which 90%
are engaged in unpaid subsistence farming, herding, and fishing; 60,000
wage earners in industry and civil service
Organized labor: about 20% of wage labor force','b7331fb0835d090e6f3d84d9bdcb841505c3be796cd1bfc535403c15f7d00bad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3124b306cdc6782391242e42e4e5409222fb8b0cf2342457520660c8faea3953',1973,'AU','Australia','people-and-society',35,'Population: 884,300,000, average annual growth rate 2.3% (current)
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur, Hui, Yi, Tibetan, Miao,
Manchu, Mongol, Pu-I, Korean, and numerous lesser nationalities
Religion: most people, even before 1949, have been pragmatic and eclectic,
not seriously religious; most important elements of religion are Confucian-
ism, Taoism, Buddhism, ancestor worship; about 2%-3% Muslim, 1% Christian
Language: Chinese (Mandarin mainly; also Cantonese, Wu, Fukienese, Amoy, Hsiang,
Kan, Hakka dialects), and minority languages (see ethnic divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85% agriculture, 15% other; shortage of
skilled labor (managerial, technical, mechanics, etc.); surplus of unskilled
labor
Approved For Release 2004/99(t5 ‘febAeRRP §p-01051A000500010001-1
PEOPLE''S REP.
OF CHINA
14,000 sq. mi. (Taiwan and Pescadores); 24% cultivated,
6% pasture, 55% forested, 15% other (urban, industrial,
denuded, water area)
Limits of territorial waters (claimed): 3 n. mi. (fishing
12 n. mi. in practice)
Coastline: 615 mi. Taiwan, 285 mi. offshore islands
Population: 15,321,000 (excluding the population of
Quemoy and Matsu Islands and foreigners), average
annual growth rate 2.2% (January 71-72)
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese, 2% aborigines
Religion: 93% mixture of Buddhism, Confucianism, and Taoism; 4.5% Christian;
2.5% other
Language: Mandarin, Taiwanese, Japanese, English
Literacy: about 90%
Labor force: 4.8 million; 34% agriculture, forestry, fishing, 24% manufacturing,
14% services, 14% commerce, 5% transportation and communications,
6% construction, 2% mining (1968)
Organized labor: about 10% of 1968 labor force (government controlled)
Population: 23,647,000, average annual growth rate 3.2%
(current)
Ethnic divisions: 58% mestizo, 20% caucasian, 14% mulatto, 4% Negro, 3% mixed
Negro-Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture, 13% manufacturing, 18% services,
9% commerce, 13% other (1964)
Organized labor: 13% of labor force (1968)
Population: 288,000, average annual growth rate 2.72
(September 66-70)
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor Force: mainly agricultural
Organized labor: information not available
Population: 111,000, average annual growth rate 2.6% (May
63-March 69)
Ethnic divisions: Melanesian-Polynesian admixture, over
28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese laborers were imported for
plantations and mines in pre-World War II period; immigrant labor now
coming from Wallis Islands, New Hebrides, and French Polynesia
Organized labor: unorganized
Population: 2,003,000, average annual growth rate 2.8%
(April 63-71)
Ethnic divisions: 75% mestizo, 15% white, 10% Negro, Indian or mulatto
Religion: 95% Roman Catholic
Language: Spanish (official); small English-speaking minority on Atlantic coast
Literacy: 50% of population 10 years of age and over
Labor force: 650,000 (est. 1972); 60% agriculture, 12% manufacturing, 14%
services, 14% other; shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: about 5% of labor force
Population: 632,000, average annual growth rate 1.7%
(December 60-70)
Ethnic divisions: 95% indigenous Timorese belonging to
the Malay racial group; 9 ethnic divisions, each
speaking a distinct dialect of Malay structure;
approx. 4,600 Chinese and 10,000 halfcastes
Religion: 17% Christian (almost equally divided between Catholic and
Protestant), remainder practice animism
Language: an estimated 9-15 dialects, of Malay origin but mutually unintelligible;
75% of the population speaks the Tetum dialect
Literacy: rate of literacy is unknown, but is very low; educational system being
expanded under first Five Year Development Plan; by 1967 total school
enrollment was 25,000 out of total school-age population of 80,000; 5% of
natives can speak Portuguese
Labor force: 90% engaged in primitive village subsistence economy, 10% engaged
as town laborers and domestics
Population: 2,790,000, average annual growth rate 1.0% eerie
(FY67-70)
Ethnic divisions: 80% white, 20% mixed (with Indian and
Negro elements)
Religion: predominantly Roman Catholic
Language: Spanish, English
Literacy: 88%
Labor force: 706,000; 19% agriculture, 14% manufacturing, 7% construction, 39%
government services and trade, 8% other, 13% unemployed
Organized labor: 45% of labor force
Population: 147,000, average annual growth rate 1.8%
(December 66-71)
Ethnic divisions: Polynesians, about 12,000 Euronesians (persons of European
and Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of population associated with the London
Missionary Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all children from 7-15 years)
Labor force: agriculture 19,148; mining and manufacturing 1,716 (1961)
Organized labor: unorganized
dear ey 1,535,000*, average annual growth rate 2.7%
FY7]
Ethnic divisions: almost all Arabs; a few Indians,
Somalis, and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 6,164,000, average annual growth rate 2.9%
(current)
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and herding
2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release icos| AULA
98,700 sq. mi.; 32% arable, 25% meadows and pastures,
34% forested, 9% urban, waste, and other
Land boundaries: 1,865 mi.
Limits of territorial waters (claimed): 10 n. mi.
(fishing, 12 n. mi.)
Coastline: 945 mi. (mainland), plus 1,500 mi. (offshore
islands)
Population: 20,841,000, average annual growth rate 1.0%
(current)
Ethnic divisions: 43% Serb, 23% Croat, 8% Slovene, 6% Macedonian, 3% Montenegrin,
5% Albanian, 3% Hungarian, 9% other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic, 12% Muslim, 3% other, 12%
~ none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Albanian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 13.5 million (1970); 49.6% agriculture, 16% mining and manufacturing,
34.4% other nonagricultural activities; reported unemployment averaged 8%
of registered labor force (social sector) in 1967
eee 23,918,000, average annual growth rate 4.2%
FY71
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes -- Mongo, Luba, Kongo (all Bantu),
and the Mangbetu-Azande (Hamitic) make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo, and Chiluba are all
classified as official languages
Literacy: 5% fluent in French, about 35% have an acquaintance with French
Labor force: about 8 million, but only about 13% in wage structure','2106e9ee5e44c17be4040cb952aed1d96de9edf076dc142c9cf777809dfdb19d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f001ed7bd6446df06c66bfe2f641507a1198ca9a20accee5c1ec22bdda61ae02',1973,'CG','Congo','people-and-society',40,'Population: 982,000, average annual growth rate 2%
(current)
Ethnic divisions: about 15 ethnic groups divided into some 75 tribes, almost all
Bantu; most important ethnic groups are Kongo (48%) in south, Teke (17%) in
center, M''Bochi (12%) and Sangha (20%) in north; about 8,500 Europeans,
mostly French
Religion: about half animist, half nominally Christian, less than 1% Muslim
Language: French official, many African languages with Lingala and Kikongo
most widely used
Literacy: about 20%
Labor force: about 40% of population economically active, most engaged in
subsistence agriculture; 79,100 wage earners; 40,000-60,000 unemployed
Organized labor: 16% of total labor force (1965 est.)','f1eed61dd82fa0cc39198c1b687d4967fb84247475bcc5b7d99d9d27299e2e58','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fd93a642db41a30e06da23b894f94b0c98a2a81a4a650114452e667a3647032',1973,'CR','Costa Rica','people-and-society',44,'Population: 1,862,000, average annual growth rate 2.8%
(FY71)
Ethnic divisions: 98% white (including mestizo), 2% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: approximately 80%
Labor force: 530,000 (1970); 46.3% agriculture; 13.2% manufacturing; 11% commerce;
8% construction, transportation, and communications; 21.5% other; shortage
of skilled labor (1968)
Organized labor: about 6% of labor force','4ef0453170d705091a1fab789e81e4363eeff68c87ae3eb8dde1355594ac574b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bf23ec6cf3026f485aa6affc0fc3d9176d4ddee22b510327b20630b048b7989',1973,'CU','Cuba','people-and-society',48,'Population: 8,850,000, average annual growth rate 1.7%
(current) eer
Ethnic divisions: 51% mulatto, 37% white, 11% Negro, ,
1% Chinese
Religion: at least 85% nominally Roman Catholic before Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.6 million; 34% agriculture, 17% industry, 6% construction, 6%
transportation, 29% services, 8% unemployed and underemployed
Organized labor: 70% of total force','da546de4eddbe0e95e06feed3e6fd2d03032209640b768de2c697964b93cc938','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f58f8d7be7f431f188eb094c3a25a1318f513b747d8b71d20019e3168a08add0',1973,'CY','Cyprus','people-and-society',54,'Population: 14,523,000, average annual growth rate 0.6%
(current) :
Ethnic divisions: 64.5% Czechs, 29.6% Slovaks, 3.9% Magyars, la
1% Germans, 1% Ukrainians, Jews, Poles iS
Religion: 77% Roman Catholic, 20% Protestant, 2% Orthodox, \\" gb eae.
1% other HEYA TECYPRELWABIA Mivtpad
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.1 million; 18% agriculture, 37% industry, 11% services, 34%
construction, communications and others
Population: 2,915,000, average annual growth rate 2.8%
(FY65-68)
Ethnic divisions: 99% Africans (42 ethnic groups, most important being Fon, Adja,
Yoruba, Bariba), 5,500 Europeans
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most common vernaculars in south,
at least 6 major tribal languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture; 15% civil service,
artisans, and industry
Organized labor: approximately 75% of wage earners, divided among two major
and several minor unions
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','b4346752163bd8c348d6289a1b71957f06878b138cdedea1a588a46a5a6b2b49','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adaaa0c5d8de66fbffd4a6c760007216e1d91c67212c27ee75a3ded8e436a9ac',1973,'DK','Denmark','people-and-society',55,'16,600 sq. mi. (exclusive of Greenland and Faeroe Islands);
64% arable, 8% meadows and pastures, 11% forested, 17%
other
Land boundaries: 42 mi.
Limits of aa waters (claimed): 3 n. mi. (fishing
12 n. mi.
Coastline: 2,100 mi.','bef26ed9f078005c70bfd96d0d1e34336e06db5edf23a11bf4fd5fa323f19ee9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c841f769caa9dcc5874f8b1418cc6f67930620b6c94341a3030f6e5bfd482bba',1973,'DZ','Algeria','people-and-society',56,'Population: 4,984,000, average annual growth rate 0.4%
(current)
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant and Roman Catholic, 1%
other
Language: Danish; small German-speaking minority
Literacy: 99%
Labor force: 2.4 million; 14.5% agriculture, forestry, fishing, 29.4% mining and
manufacturing, 8.1% construction, 15.0% commerce, 6.6% transportation and
communications, 23.6% services, 0.2% other; 4.0% (monthly average) unemployed
Organized labor: 65% of labor force
Population: 34,675,000 (including the Balearic and Canary Islands; also including
Alhucemas, Ceuta, Chafarinas, Melilla, and Penon de Velez de la Gomera) ;
average annual growth rate 1.1% (current)
Ethnic divisions: homogeneous composite of Mediterranean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great majority; but 17% speak Catalan,
7% Galician, and 2% Basque
Literacy: about 90%
Labor force (1970): 12.7 million; 29.1% agriculture, 37.3% industry, 33.6%
services; registered unemployment is 1.5% of labor force
Organized labor: 90% of labor force in compulsory government-control led
syndicates
Population: 76,000 (preliminary total from the census of
31 December 1970)
Ethnic divisions: 51.2% Arab, Berber, and Negro nomads;
48.8% Spanish
Religion: 51% Muslim, 49% Catholic
Language: Spanish (official), local Arabic or Hassania
Literacy: among Spanish, probably nearly 100%; among nomads, perhaps 5%
Labor force: 12,000; 50% agriculture, 50% other
Organized labor: none
Population: 13,107,000, average annual growth rate 2.3%
(July 63-October 71)
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor, 2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6% Muslim, 1% other
Language: Sinhala official, spoken by about 70% of population; Tamil spoken by
about 22%; English commonly used in government and spoken by about 10%
of the population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed; employed persons -- 53.4% agriculture,
14.8% mining and manufacturing, 12.4% trade and transport, 19.4% services
and other
Organized labor: 43% of labor force, over 50% of which employed on tea, rubber,
and coconut estates
eae 16,695,000, average annual growth rate 2.5%
FY70
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23% pagan, 4% Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects of Nilotic, Nilo-Hamitic,
and Sudanic languages, English; program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15% industry, commerce, services,
etc.; labor shortages exist for almost all categories of employment
Approved For Release 2004/09/15 che. oo eee
55,100 sq. mi.; negligible amount of arable land, meadows
and pastures, 76% forest, 8% unused but potentially at
productive, 16% built-on area, wasteland, and other Beey
Land boundaries: 970 mi.
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 240 mi.
Population: 440,000, average annual growth rate 3.5%
(FY65-70)
Ethnic divisions: 35.5% Creole (Negro and mixed), 34.7% Hindustani (East Indian),
14.9% Javanese, 8.5% Bush Negro, 2.2% Amerindian, 1.6% Chinese, 1.3% Europeans,
1.3% other and unknown
Religion: Muslim, Hindu, Moravian, Roman Catholic, other -- in order of size
(% figures unknown)
Language: Dutch official; English widely spoken; Taki-Taki (Surinam Creole)
is native language of Creoles and lingua franca; Hindi; Japanese
Literacy: 70% to 75%
Labor force: 80,190 (1964); 24.9% agriculture, 6.9% mining, 10% industry, 2.8%
building trades, 13.5% trade and transport, 6.7% services, 22.2% government
employees, 13% other
Organized labor: approx. 10% of labor force
Population: 441,000 (African population only), average
annual growth rate 3.2% (current)
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence agriculture; 55-60,000
wage earners, many only intermittently, with 31% agriculture, 11% government,
11% manufacturing, 12% mining and forestry, 35% other (1968 est.); 7,900
employed in South African mines (1969)
Organized labor: about 15% of wage earners are unionized
Population: 8,150,000, average annual growth rate 0.4%
(January 71-72)
Ethnic divisions: homogeneous white population; smal] Lappish minority
Religion: 92% Evangelical Lutheran, 7% other Protestant, Roman Catholic, Eastern
Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking minorities
Literacy: 99%
Labor force: 3.5 million; 11.8% agriculture, forestry, fishing; 33.5% mining
and manufacturing; 9.6% construction; 15.5% commerce; 7.2% transportation
and communications; 20.9% services; 2.8% unemployed
Organized labor: 70% of labor force
Population: 6,394,000, average annual growth rate 0.9%
(January 71-72)
Ethnic divisions: total population -- 69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals -- 74% German, 20% French, 4% Italian,
1% Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals -- 74% German, 20% French, 4% Italian, 1% Romansch,
1% other; total population -- 69% German, 19% French, 10% Italian, 1%
Romansch, 1% other
Literacy: 98%
Labor force: 3.0 million, about one-fifth foreign workers, mostly Italian;
16% agriculture and forestry, 47% industry and crafts, 20% trade and
transportation, 5% professions, 2% in public service, 10% domestic and
other; no significant unemployment shortage of both skilled and
unskilled labor -- 4,400 unfilled vacancies in January 1971
Organized labor: 20% of labor force
Population: 6,775,000, average annual growth rate 3.3%
(current)
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians, and other
Religion: 70.5% Sunni Muslim, 16.3% other Muslim sects, 13.2% Christians of
various sects
Language: Arabic, Kurdish, Armenian; French and English widely understood
Literacy: about 40%
Labor force: 1.2 million; 53% agriculture, 17% industry, 30% miscellaneous
services; majority unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 14,195,000, average annual growth rate 2.7% (FY71)
Ethnic divisions: 99% native Africans consisting of well over 100 tribes; 1%
Asian, European, and Arab
Religion: Tanganyika -- 40% animist, 30% Christian, 30% Muslim; Zanzibar --
almost all Muslim
Language: Swahili English and official English primary language of commerce,
administration and higher education; Swahili widely understood and generally
used for communication between ethnic groups; first language of most people
is one of the local languages
Literacy: 15%-20%
Labor force: under ‘400,000 in paid employment, over 90% in agriculture
Organized labor: 15% of labor force
Population: 36,714,000, average annual growth rate 2.7%
(April 60-70)
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70%
Labor force: 88% agriculture, 9% commerce, 3% industry
Population: 2,102,000, average annual growth rate 2.6%
(FY68-71)
Ethnic divisions: some 40 tribes; largest and most
important are Ewe in south and Cabrais in north; under 1% European and
Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of commerce; major African languages
are Ewe and Mina in south and Dagoma, Tim, and Cabrais in north
Literacy: 5% to 10%
Labor force: over 90% of population engaged in subsistence agriculture; about
30,000 wage earners, evenly divided between public and private sectors
Organized labor: less than half of wage earners divided among 2 major and several
minor unions
Population: 92,000, average annual growth rate 2.9%
(FY68-70)
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized
Population: 980,000, average annual growth rate 1.3%
(April 60-70)
Ethnic divisions: 43% Negro, 36% East Indian, 16% mixed, 2% white, 3% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23% Hindu, 6% Muslim, 13% unknown
Language: English
Literacy: 80%
Labor force: about 368,400 (June 1969), about 20.4% agriculture, 18.3% mining,
quarrying, and manufacturing, 15.8% commerce; 14.6% construction and
utilities; 6.9% transportation and communications; 20.8% services,
3,270 other (1965)
Organized labor: 24% of labor force
ean 5,423,000, average annual growth rate 2.2%
FY71
Ethnic divisions: 98% Arab, 1% European, less than 1% Jewish
Religion: 98% Muslim, 1% Christian, less than 1% Hebrew
Language: Arabic (official), Arabic and French (commerce)
Literacy: about 30%
Labor force: 1.5 million; 70% agriculture, 10% manufacturing and construction,
20% other; 25% underemployed; shortage of skilled labor
Organized labor: 10% of labor force; General Union of Tunisian Workers (UGTT),
subordinate to Destourian Socialist Party
Population: 37,717,000, average annual growth rate 2.6%
(current)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force
te 10,615,000, average annual growth rate 3.2%
FY71)
Ethnic divisions: 98.7% African, 1.3% European, Asian,
Arab
Religion: about 60% nominally Christian, rest Muslim or
pagan
Language: English official; Luganda and Swahili widely used; other Bantu and
Nilotic languages
Literacy: about 20%-40% ;
Labor force: estimated 4.5 million, of which 256,799 in paid labor, remaining
in subsistence activities
Organized labor: 123,284 union members
Population: 248,726,000, average annual growth rate 1%
(current)
Ethnic divisions: 74% Slavic, 26% among some 170 ethnic groups
Religion: 70% atheist, 18% Russian Orthodox, 9% Muslim, 3% other
Language: more than 200 languages and dialects (at least 18 with more than ]
million speakers); 76% Slavic group, 8% other Indo-European, 11% Altaic,
3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: 126 million (1971), 32% agriculture, 68% industry and other non-
agricultural fields, unemployed not reported, shortage of skilled labor
not reported, no shortage of unskilled labor
Population: 179,000 (census of 15 March - 16 April 1968)
Ethnic divisions: Arabs 72%; others include Iranians,
Pakistanis, and Indians
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 20% est. (1968)
Labor force: 77,000 (1968)
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
UPPER VOLTA
D:
106,000 sq. mi.; 50% pastureland, 21% fallow, 10%
cultivated, 9% forest and scrub, 10% waste and other
uses (1967)
Land boundaries: 2,055 mi.
ae tea 5,659,000, average annual growth rate 2.0%
FY70
Ethnic divisions: more than 50 tribes; principal tribe
is Mossi (about 2.5 million); other important groups
are Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to Sudanic family, spoken
by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active population engaged in animal
husbandry, subsistence farming, and related agricultural pursuits; about
30,000 are wage earners; about 20% of male labor force migrates annually to
neighboring countries for seasonal employment
Organized labor: 3 primary and several small specialized unions
Eek 2,974,000, average annual growth rate 1.2%
FY71
Ethnic divisions: 85%-90% white, 5% Negro, 5%-10% mestizo
Religion: 66% Roman Catholic (less than half adult population attends church
regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed in important sectors --
25% government; 34% industry; 10% service; 13% other; 8% agriculture, forestry,
fishing and mining; no shortage of skilled labor
Organized labor: about 25% of labor force (largely Communist influenced)
Population: 1,000 (official estimate for 1 July 1964)
Ethnic divisions: primarily Italians but also many
other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees divided
into 3 categories -- executives, officeworkers,
and salaried employees
Organized labor: none
Population: 11,370,000 (excluding Indian jungle population
estimated at 32,000 in 1961), average annual growth
rate 3.6% (FY70)
Ethnic divisions: 67% mestizo, 21% white, 10% Negro, 2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 74% (claimed, 1970 est.)
Labor force: 3 million (1969); 24% agriculture, 6% construction, 17% manufacturing,
6% transportation, 18% commerce, 25% services, 4% petroleum, utilities, and
other
Organized labor: 45% of labor force
ha ta 19,550,000, average annual growth rate 2.6%
FY70
Ethnic divisions: 87.7% Vietnamese, 6% Chinese, 3.2%
mountain tribesmen, 2.9% Khmer, 2% Cham
Religion: 70% Buddhist (at least 5% Hoa Hao), 5% Cao Dai, and 10% Catholic; others
include animist, and smal] numbers of Protestant, Muslim and Hindu; most
Buddhists are of Mahayana school or practice combination of Buddhism, Taoism,
and Confucianism
Language: Vietnamese, French, Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian), Cham (Malayo-Polynesian dialect)
Labor force: civilian work force 5.8 million (not including armed forces);
67% agriculture, fishing, and forestry; 17% industry and commerce; 3%
domestic and personal services; 3% employed by U.S.; 5% government; 5%
unemployed
Organized labor: unknown','ad014f02f6ce1e7763ac2053eac11e7ab22aba3dcb19fe5edbde24d96540688b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca5e03d43091bc91431be5e567e3846b278c2782f79ba4ab8002b331149660b5',1973,'DO','Dominican Republic','people-and-society',65,'Population: 4,377,000, average annual growth rate 3.0%
(FY71)
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 35% to 40% of adult population
Labor force: 1.3 million; 73% agriculture, 8% industry, 19% services and other
Organized labor: 12% of labor force
Population: 6,617,000 (excluding nomadic Indian tribes),
average annual rate of growth 3.3% (FY71)
Ethnic divisions: 41% mestizo, 39% Indian, 10% white, 5% Negro, 5% Oriental and
other
Religion: 95% Roman Catholic (majority nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 55% agriculture, 16% manufacturing, 4%
construction, 7% trade, 9% services, 9% other; shortage of skilled labor
Organized labor: 12% of labor force
Qa
Population: 35,370,000, average annual growth rate 2.4% (FY71)
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek, Italian, Syro-Lebanese
Religion: 94% Muslim, 6% Copt and other
Language: Arabic official, English and French widely understood by educated
classes
Literacy: around 40%
Labor force: 8 to 12 million; 45% to 50% agriculture, 10% industry, 10% trade
and finance, 30% services and other; serious shortage of skilled labor
Organized labor: 1 to 3 million','a5feab86e97439c1710516e012843fa010a46b098d2a9ff9c1367dcd96a79d71','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98a17d62387aa235581784bd1ee0bc730ebcf2c85a69268aa1c142ffce33034b',1973,'SV','El Salvador','people-and-society',69,'Population: 3,728,000, average annual growth rate 3.4%
(May 61-June 71)
Ethnic divisions: 84%-88% mestizo; Indian and white minorities, 6%-8% each
Religion: predominantly Roman Catholic, probably 97%-98%
Language: Spanish
Literacy: 50% of population 10 years of age and over (1966 est.)
Labor force: 1,126,000 (est. mid 1971); 57% agriculture, 14% services, 14%
manufacturing, 6% commerce, 9% other; shortage of skilled labor and large
pool of unskilled labor, but manpower training programs improving situation
Organized labor: 4.5% of total labor force; 8% of nonagricultural labor force','85794f5880ce141ce40076ee66cae2bda83e0ed668d42884b320bfeac82a6e2a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c99c7a08873278dc7e9f551e639b876a2d195f03f33cd2efeb5ace7d69120be7',1973,'GQ','Equatorial Guinea','people-and-society',73,'Population: 304,000, average annual growth rate 1.8%
(FY69); Rio Muni, 217,000, average annual growth rate
1.8% (FY69); Fernando Po, 87,000, average annual growth
rate 2.6% (FY69)
Ethnic divisions: indigenous population of Fernando Po primarily Bubi, some
Fernandinos; of Rio Muni primarily Fang; some 10,000-20,000 Nigerians, mostly
on Fernando Po; less than 1,000 Europeans, primarily Spanish
Religion: natives all nominally Christian and predominantly Roman Catholic; some
pagan practices retained
Language: Spanish official language of government and business; also pidgin
English, Fang
Literacy: 20% (est.)
Labor force: most Equatorial Guineans involved in subsistence agriculture;
smal] wage labor force dominated by Nigerian contract laborers
Population: 26,205,000, average annual growth rate 2.5%
(January 70-71)
Ethnic divisions: Galla 40%, Amhara and Tigrat 32%, Sidamo 9%, Shankella 6%,
Somali 6%, Afar 4%, Gurage 2%, other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Muslims, 15%-20% animist, 5% other
Language: Amharic official; many local languages and dialects; English major
foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10% government, military,
and quasi-government
Organized labor: 60,000 registered labor union members','fd4b533b0731b6d41d972f52ad4897bf0c9da306e2906cb628d3d65187aaf44a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a9d7d5e96009641364c516b7208dd32cc2f2b120b706d6d593acf263cb92bc2',1973,'FR','France','people-and-society',76,'Population: 39,000, average annual growth rate 0.9%
(April 66-November 70)
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faeroese (derived from Old Norse), Danish
Literacy: 99% |
Labor force: 15,000; largely engaged in fishing, manufacturing, transportation,
and commerce
Population: 58,000, average annual growth rate 5.0%
(FY67-70)
Ethnic divisions: 95% Negro or mulatto, 5% caucasian, 10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%, construction 21%, agriculture
18%, industry 8%, transportation 4%; information on unemployment unavailable
Organized labor: 7% of labor force
Population: 125,000 (official estimate for 1 July 1967)
Ethnic divisions: 59,350 Somalis (large number of the
Somalis are temporary immigrants from Somalia -- not
citizens of territory), 53,650 Afars, 6,000 Arabs; 7,000 French (inclusive
of French military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at port
Organized labor: some 3,000 railway workers organized
Population: 521,000, average annual growth rate 1.7%
(FY67~-70)
Ethnic divisions: about 40 Bantu tribes, including 4
major tribal groupings (Fang, Eshira, Mbede, Okande); about 21,000 expatriate
Africans and Europeans, including 14,000 French
Religion: 55% to 75% Christian, less than 1% Muslim, remainder animist
Language: French official language and medium of instruction in schools; Fang
is-a major vernacular language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are wage earners in the modern sector
Organized labor: less than 30% of wage labor force
Population: 388,000, average annual growth rate 2.2%
(FY67-71)
Ethnic divisions: over 99% Africans (Malinke 40.8%, Fulani 13.5%, Wolof 12.9%,
remainder made up of several smaller groups), fewer than 1% Europeans and
Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Malinke and Wolof most widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in subsistence farming; about
15,000 are wage earners (government, trade, services)
Organized labor: 25% to 30% of wage Tabor force at most
Population: 17,050,000 (including East Berlin), average
annual growth rate 0% (current) aed
Ethnic divisions: 99.7% German, .3% Slavic and other
Religion: 80% Protestant, 9% Roman Catholic, 11% unaffiliated or other; less than
5% of Protestants and about 25% of Roman Catholics actively participate
Language: German, small Sorb (West Slavic) minority
Literacy: 99%
Labor force: 8.2 million; 36.5% industry; 5.2% handicrafts; 7.4% construction;
12.8% agriculture; 7.3% transport and communications; 11.0% commerce; 17.5%
services; 2.3% other
Organized labor: 86% of total labor force','3ec5d409fd303d3420f5bd6ab93c3a84d9d4388fde21350a1f7b6369f4f059ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5136ff1ddccb552853ef81a62f195b91d747c7ea14b1140eb0eaff2b3080c36b',1973,'FJ','Fiji','people-and-society',80,'ha 546,000, average annual growth rate 2.1%
FY7]
Ethnic divisions: 42% Fijian, 50% Indian, 8% European, Chinese and others
Religion: Fijians mainly Christian, Indians are Hindu with a Muslim minority
Language: English and Fijian (official), Hindustani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no breakdown on remainder
Organized labor: about 50% of labor force organized into 22 unions; unions
organized along lines of work, breakdown by ethnic origin causes further
fragmentation
Population: 4,654,000, average annual growth rate 0.3%
(January 71-72)
Ethnic divisions: homogeneous white population, small
Lappish minority :
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox, 1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and Russian-speaking minorities
Literacy: 99%
Labor force: 2.3 million; 28.1% agriculture, forestry, and fishing, 24.2% mining
and manufacturing, 9.0% construction, 13.7% commerce, 6.6% transportation and
communications, 16.5% services; 2.9% unemployed
Organized labor: 60% of labor force','da159741337d2ddbb8e0b94fa4db2f7a156ad0dc9a02ec2f5b2657c65a5e18bf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10b5fd9af7d4d4b7ca7e78c2d086fd7f94edb044e58593b9a36ca9126ba60f53',1973,'GH','Ghana','people-and-society',85,'Population: 9,224,000, average annual growth rate 2.7%
(March 60-July 71)
Ethnic divisions: 99.8% Negroid African (major tribes
Fanti, Ashanti, Ewe), 0.2% European and other
Religion: 45% animists, 42.8% Christian, 12% Muslim
Language: English official; African languages include Akan 44%, Mole-Dagbani 16%,
Ewe 13%, and Ga-Adangbe 8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing, 16.8% industry, 15.2%
sales and clerical, 4.1% services, transportation, and communications ,
2.9% professional; 400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor force','54f7c0ffdf491629097b013d39d9ca0ba571ddeb4de466c643596af7520348ff','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ecfeeff1565c355bd777a09d6e2dba1b6b2299bb3f5a2d43b57c4ebbd00996c',1973,'GI','Gibraltar','people-and-society',91,'uieya
Population: 8,839,000, average annual growth rate 0.4%
(March 61-71)
Ethnic divisions: 96% Greek, 2% Turkish, 1% Albanian, 1% other
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total about 82%
Labor force: 3,866,000 (1969 est.); 50% agriculture, 15% industry, 9% trade,
26% other; unemployment and underemployment, 20% total in all fields;
shortage of skilled labor in nonagricul tural sectors aggravated by large-
scale emigration
Organized labor: 10% of labor force','398d604f5b2990efe5c88ef3d1bf26c0277154fffc40f26d62ab40e623e20ae4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ee663585c5a366aefc0cfcb8d6dac8bc57954e451ab1df6e4a8724d373c8d49',1973,'GL','Greenland','people-and-society',93,'Population: 50,000, average annual growth rate 3.3%
(January 66-71)
Ethnic divisions: 86% Greenlander (Eskimos and Greenland-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep breeding','fff6635a21ccfac80885c732bd8d2dc27f9b439faaec12584dc415b1b0fdcb13','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6a32d492a2f94f7aefbf918480479216dd5eb1d7faa9d26c83052c701666228',1973,'GY','Guyana','people-and-society',97,'Population: 763,000, average annual growth rate 2.5%
(April 60-70)
Ethnic divisions: 50% East Indians, 44% Negro and Negro
mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1% other
Language: English
Literacy: 86%
Labor force: 175,000; about 75% agriculture, 10% mining, services, and
manufacturing, 15% other; 21% unemployed; shortage of technical and
managerial personnel
Organized labor: 25% of labor force','b433f7f4f6007ce2aaec2f53da2e32e03f3e93ddca8a997bb3dbcf8f67def598','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('240bf10768145e234bb6b79b2fea16683fde006a13b6f3fa116bb7f943d3e8a4',1973,'HT','Haiti','people-and-society',101,'eae ods 5,126,000, average annual growth rate 2.1%
FY71
Ethnic divisions: over 90% Negro, nearly 10% mulatto,
few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of which an overwhelming
majority also practice Voodoo)
Language: French (official) spoken by only 10% of population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.6 million (est. January 1968); 86% agriculture, 12% industry,
2% unemployed; shortage of skilled labor; unskilled labor abundant
Organized labor: less than 1% of labor force
Population: 2,813,000, average annual growth rate 3.5%
(FY70)
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 57.4% of persons 10 years of age and over (est. 1970)
Labor force: approx. 900,000 (est. mid-1972); 66% agriculture, 12% services, 8%
manufacturing, 5% commerce, 6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-1972)
ae ee 4,179,000, average annual growth rate 2.2%
FY71
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local religions
Language: Chinese, English
Literacy: 75%
Labor force (1969 est.): 1.52 million; 40% manufacturing, 28% services, 11%
construction, mining, quarrying and utilities, 11% commerce, 5% agriculture,
forestry, fisheries, and hunting, 6% communications, 2% other; under-
employment is a serious problem
Organized labor: 12% of 1969 labor force','9ceb0120e77b96d0b96b09fbdc485f65ac9d1139fb6deca537955982b07d73fe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6365b9250d2ea2bec11f0594d3794a8bc9de5e90a799be2c6413ffa4bfc1d678',1973,'HU','Hungary','people-and-society',105,'Population: 10,405,000, average annual growth rate 0.3%
(current)
Ethnic divisions: 93.3% Magyar, 2.5% German, 2.4% Gypsy,
0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20% Calvinist, 5%
Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5.0 million (1 January 1971); 26% agriculture, 44% industry and
building, 30% other nonagricul tural','f1e97ea5d5231cf61421b559ae347dc95e20a913c3937f21fb9affc2741de6ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d22e1d2e710d8da1dd25c6821e3bb65c3bcaf96d36f9b8db5832c15791f6b1d1',1973,'IS','Iceland','people-and-society',109,'Population: 209,000, average annual growth rate 1.0% 3 re
(December 66-71) Penvy
Ethnic divisions: homogeneous white population :
Religion: 95% Evangelical Lutheran, 3% other Protestant and Roman Catholic, 2%
no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 85,000; 22.6% agriculture and fishing; 25.6% mining and manufac turing;
10.7% construction; 12.8% commerce; 7.8% transportation and communications;
15.2% services; and 4.0% other; unemployment is insignificant
Organized labor: 60% of labor force
Population: 571,034,000 (including Sikkim and the Indian-held part of disputed
Jammu-Kashmir, and excluding the several million refugees who entered India
from East Pakistan during 1971), average annual growth rate 2.5% (FY71)
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.6% Christian, .7% Buddhist,
.7% other
Language: 24 languages spoken by a million or more persons each; numerous
other languages and dialects, for the most part mutually unintelligible;
Hindi is the national language and primary tongue of 30% of the people;
English enjoys "associate" status but is the most important language for
national, political, and commercial communication; Hindustani, a popular
variant of Hindi/Urdu, is spoken widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29% (1971 census)
Labor force: about 184 million; 70% agriculture, more than 10% unemployed and
underemployed; shortage of skilled labor is significant and unemployment is
rising
Organized labor: about 2.5% of total labor force','bd0b75fd17d29d11278059faaca766283c0f69298479a875942ffdafa29f7312','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4462d0b7f6c5b8d8034c210c2883221c0fce21a8eaaf876dfab105c4844c5f26',1973,'ID','Indonesia','people-and-society',112,'736,000 sq. mi.; 11% small holdings and estates, 64% for-
ests, 25% inland water, waste, urban, and other
Land boundaries: 1,700 mi.
Limits of territorial waters (claimed): under an archipelag
theory, claim is 12 n. mi., measured seaward from
straight baselines connecting the outermost islands soertnin
Coastline: 34,000 mi. :
Population: 123,180,000 (including West Irian), average
annual growth rate 2.5% (current)
Ethnic divisions: 45% Javanese, 14% Sundanese, 7.5% Madurese, 7.5% Coastal Malays,
26% other
Religion: 90% Muslim, 4% Christian, 2% Buddhist, 2% Hindu, 2% other
Language: Indonesian (modified form of Malay) official; English, and Dutch
leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 41 million; 70% agriculture, 15% industry, 15% miscellaneous and
unemployed
Organized labor: 10% of labor force
Population: 30,805,000, average annual growth rate 3.0%
(January 71-72)
Ethnic divisions: 63% Ethnic Persians, 3% Kurds, 13% other Iranian, 18% Turkic,
3% Arab and other Semitic, 1% other
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2% Zoroastrians, Jews, Christians
and Baha''is
Language: Farsi (Persian), Turki, Kurdish, Arabic
Literacy: about 30% of those 10 years of age and older
Labor force: 7.5 million; 47% agriculture, 53% industry, commerce and services;
shortage of skilled labor substantial
Organized labor: 1.1% of labor force
Population: 10,142,000, average annual growth rate 3.3%
(October 70-71)
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7% Assyrians, 2.4% Turkomans, 7.7%
other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry, 6.7% government,
16.8% other; rural underemployment high, but not serious because low
subsistence levels make it easy to care for unemployed; severe shortage
of technically trained personnel
Organized labor: 11% of labor force
Population: 5,013,000 (resident African population only),
average annual growth rate 3.3% (January 66-71)
Ethnic divisions: 7 major indigenous ethnic groups; no single tribe more than
20% of population; most important are Agni, Baoule, Krou, Senoufou, Mandingo;
approx. 1 million foreign Africans, mostly Voltaics; about 33,000 non-Africans
(25,000 French)
Religion: 66% animist, 22% Muslim, 12% Christian
Language: French official, over 60 native dialects, Dioula most widely spoken
Literacy: about 20%
Labor force: over 85% of population engaged in agriculture, forestry, livestock
raising; about 11% of labor force are wage earners, nearly half in agricul-
ture, remainder in government, industry, commerce, and professions
Organized labor: 20% of wage labor force','11877dcfb4283b14624fbdad09a5d3daff13a77584c12a7bd39175141d5f67e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4fe78cba38d79ad5bb899432125c8178e35b730e0e7f45406f5aa113b356ea7',1973,'JM','Jamaica','people-and-society',118,'Population: 1,937,000, average annual growth rate 1.5%
(Apri ] 60-70) BRAZIL
Ethnic divisions: African 76.3%, Afro-European 15.1%, oa
Chinese and Afro-Chinese 1.2%, East Indian and
Afro-East Indian 3.4%, white 3.2%, other 0.9%
Religion: predominantly Protestant, some Roman Catholic, some spiritualist cults
Language: English
Literacy: Ministry of Education estimates between 43% and 57% of adult population
functionally literate
Labor force: about 687,000; 33% in agriculture, 1% forestry and fishing, 13%
manufacturing, 7% construction, 8% commerce, 2% transportation and comnuni-
cations, 13% services, 23% unaccounted for; 16% to 20% (est.) unemployed
(seasonal unemployment in agriculture can push the unemployment figure to
25%); shortage of technical and managerial personnel
Organized labor: about 25% of labor force (1966)','a46a3e0c81c6a17e3e8aacc8e129afed8727194ab2eae236ffa20e03455ba3cb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7636c6458dcb6895a70307e52d0ef0859e28ed357554b54ad5720ad3a43b08c',1973,'ET','Ethiopia','people-and-society',122,'Population: 2,466,000 (including West Bank and East Jerusalem), average annual
growth rate 3.1% (current)
Ethnic divisions: 98% Arab, 1% Circassian, 1% Armenian
Religion: 95% Sunni Muslim, 5% Christian
Language: Arabic official, English widely understood among upper and middle
classes
Literacy: about 40% in East Jordan; somewhat less than 50% in West Jordan
Labor force: 564,000; 33% unemployed
Organized labor: 5% of labor force
Population: 12,364,000, average annual growth rate 3.8%
(FY66-71)
Ethnic divisions: 97% native African (including Bantu, Nilotic, Hamitic and
Nilo-Hamitic); 2% Asian; 1% European, Arab and others
Religion: 56% Christian, 36% animist, 7% Muslim, 1% Hindu
Language: English official; each tribe has own language
Literacy: 27%
Labor force: 2.5 million; about 977,000, (39%) in monetary economy (1967)
Organized labor: about 215,000
Population: 15,185,000, average annual growth rate 2.8%
(current)
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 47.7% agriculture, 52,3 non-agricultural; shortage of
skilled and unskilled labor
ey 32,665,000, average annual growth rate 1.7%
FY71
Ethnic divisions: homogeneous; small Chinese minority
(approx. 20,000)
Religion: strong Confucian tradition; pervasive folk religion (Shamanism) ;
vigorous Christian minority (5.5% of population); Buddhism (including
estimated 20,000 members of Soka Gakkai); Chondokyo (religion of the heavenly
way), eclectic religion with nationalist overtones founded in 19th century,
Claims about 1.5 million adherents
Language: Korean
Literacy: about 90%
Labor force: about 10.2 million (1971); 46.2% agriculture, fishing, forestry,
32.3% services, 14% mining and manufacturing, 3% construction, 4.5% unemployed
Organized labor: about 10% of nonagricultural labor force
ee 957,000, average annual growth rate 9.8% ;
FY71
Ethnic divisions: 87% Arabs, 12% Iranians, Indians, and Pakistani, 1% other
Religion: 95% Muslim, 5% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign language
Literacy: about 55% (1965)
Labor force: 250,000 (1969); 9% manufacturing, 16% construction, 45% services,
13% commerce
Organized Tabor: labor unions, first authorized in 1964, formed in oi] industry
and among government personnel
page tN 3,143,000, average annual growth rate 2.4%
FY71
Ethnic divisions: 47% Lao; 14% Tai; 25% Phoutheng (Kha),
Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant foreign
language also used jin administration
Literacy: about 12%
Labor force: about 1,268,000; 80%-90% agriculture; 159,286 engaged in
manufacturing and services; 11,864 government employees
Organized labor: only civil servants are organized','cd831b11cf27d4fbb234180108ca99ba781f7be2e4c495f44332c58155be26f8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2a482a46c50a954c6602f8810135f4cbdc89e2445fcd492fe11b681187c6227',1973,'LB','Lebanon','people-and-society',127,'Population: 965,000, average annual growth rate 1.9%
(April 70-71)
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800 Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in
subsistence agriculture; 150,000 to 250,000 spend 6 months to many years
as wage earners in South Africa
Organized labor: negligible
Population: 1,650,000, average annual growth rate 3.3%
(current)
Ethnic divisions: 5% coastal descendants of immigrant
Negroes; 95% indigenous Negroid African tribes including Gola, Kissi, Vai,
Kpelle, Kru, and Mandingo
Religion: probably more Muslims than Christians; 80%-90% animist
Language: English official; 28 tribal languages or dialects, pidgin English used
by about 20%
Literacy: about 24% over age 5
Labor force: 450,000, of which 360,000 are in tribal, nonmonetary economy; of
90,000 in modern economy, 45% in agriculture; 23% government services; 20%
mining, construction, and manufacturing; and 12% in trade and transportation;
about 3,000 non-African foreigners hold about 95% of the top level manage-
ment and engineering jobs
Organized labor: 2% of labor force
bake 2,123,000, average annual growth rate 3.7%
FY71
Ethnic divisions: 97% Berber and Arab with some Negroid
stock; some Greeks, Maltese, Jews, Italians
Religion: 97% Muslim
Language: Arabic; Italian and English widely understood in major cities
Literacy: 35%
Labor force: 485,000; between ages 15-64, 405,000-430,000; 61% of labor force
in agriculture (1964)
Population: 343,000, average annual growth rate 0.4%
(FY66-71 )
Ethnic divisions: 83% Luxembourger, including an estimated
5% of Italian descent; remainder French, German,
Belgian, etc.
Religion: 97% Roman Catholic, remaining 3% Protestant
and Jewish
Language: Luxembourgish, German, French; most educated Luxembourgers also speak
English
Literacy: 98%
Labor force: (1970) 144,000; 11% agriculture (including forestry and fishing),
A7% industry, 42% services, no significant unemployment; 30% of labor force
is foreign, comprising workers from neighboring areas of Belgium, France,
and West Germany, as well as Italy and Portugal
Organized labor: 45% of labor force
, FRANCE
ae ae 249,000 (official estimate for 15 December
1970
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about one-half are Chinese
Language: Chinese 98%, Portuguese 2%
Literacy: almost 100% among Portuguese and Macanese; no data on Chinese
population
Labor force: 5% agriculture, 30% manufacturing, 3% construction, 1% utilities,
27% commerce, 8% transportation and communications, 26% services (1960 data)
230,000 sq. mi.; 5% cultivated, 58% pastureland, 21%
forested, 8% wasteland, 2% rivers and lakes, 6% other
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 3,000 mi.
Se ON 7,141,000, average annual growth rate 2.3%
FY70
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting
of Merina (1,643,000) and related Betsileo (760,000), on the one hand, and
coastal tribes with mixed Negroid, Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include Betsimisaraka 941,000, Tsimihety 442,000,
Sakalava 375,000, Antaisaka 415,000; there are also 38,000 French, 66,000
other
Religion: more than half animist; about 35% Christian, less than 10% Muslim
Language: French and Malagasy official
Literacy: 30% to 35%
Labor force: about 3.4 million, of which 90% are nonsalaried family workers
engaged in subsistence agriculture; of 175,000 wage and salary earners,
26% agriculture, 17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscellaneous
Organized labor: 4% of labor force','31a81eb6fc50d291bd39b170bcc57c4a28775562bb77f82805b137e0d2c28bfe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16989d07a5558b8550af114160b5cccd295ce1f518b691ae53f65438be018c28',1973,'MW','Malawi','people-and-society',130,'boars 4,721,000, average annual growth rate 2.5%
FY7]
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is second
African language
Literacy: 6% of population over 21 years old
Labor force: 180,000 wage earners employed in Malawi (1971); 6,000 Europeans
permanently employed; 300,000 Malawians live and work in Rhodesia, South
Africa, and Zambia; 30% agriculture, 11% construction, 10% commerce, 13%
manufacturing, 10% administration, 26% miscellaneous services
Organized labor: small minority of wage earners are unionized
Population: 11,104,000 average annual growth rate 2.7% (current)
West Malaysia: 9,349,000, average annual growth rate 2.6% (June 57-August 70)
Sabah: 715,000, average annual growth rate 3.7% (August 60-70)
Sarawak: 1,040,000, average annual growth rate 2.7% (June 60-August 70)
Ethnic divisions:
Malaysia: 44% Malay, 36% Chinese, 8% tribal, 10% Indian and Pakistani,
2% other
ae Malaysia: 50.1% Malay, 36.9% Chinese, 11% Indian and Pakistani,
2% other
Sabah: 23.1% Chinese, 67.3% indigenous tribes, 9.6% other
Sarawak: 31.5% Chinese, 50% indigenous tribes, 17.5% Malay, 1% other
Religion:
West Malaysia: Malays nearly atl Muslim, Chinese predominantly Buddhists,
Indians predominantly Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist, 16% Christian, 35%
tribal religion, 2% other
Language:
West Malaysia: Malay (official); English, Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dialects, Mandarin and Hakka dialects
predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal languages
Literacy:
West Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 3.45 million (1967)
West Malaysia: 2.9 million; 55% agriculture, forestry, and fishing, 11%
manufacturing and construction, 34% trade, transport, and services
Sabah: 213,000 (1967); 80% agriculture, forestry, and fishing, 6% manu-
facturing and construction, 13% trade and transportation, 1% other
Approved For Release 2004/09/15 : @DX-RDP79-01051A000500010001-1
PEOPLE (cont ''aApproved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Sarawak: 341,000 (1967); 80% agriculture, forestry, and fishing, 6% manu-
facturing and construction, 13% trade, transportation, and services,
1% other
Organized labor: 370,000 (official 1967 est.) about 10.5% of total labor force;
28% of wage labor force; unemployment about 8% of total
labor force, but higher in urban areas
Population: 114,000, average annual growth rate 2% (current
Ethnic divisions: admixtures of Sinhalese, Dravidian, Arab and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the male population
ropu ay 5,330,000, average annual growth rate 2.4%
FY71
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African languages,
of which Mande group most widespread
Literacy: under 5%
Labor force: approximately 60,000 salaried, 40,000 of whom are civil servants;
most of population engaged in agriculture and animal husbandry
Organized labor: UNTM, which claimed all eligible employees, dissolved; thirteen
national unions currently directed by a government controlled Coordination
Committee of Mali Trade Unions (ccsMy','be49f6bf2ff0fe4c5f4a0f06316e7122da257f95a3f2831221eeba7ecf82288d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a650595f7aa04c1c9adcc201340c4a23cd9e5b2163fb9e10045e330bd63e6682',1973,'MT','Malta','people-and-society',136,'ee 322,000 (official estimate for 31 December
1971
Ethnic divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in 1946
Labor force: 99,000; 38% services, 28% government, 21% manufacturing, 7%
agriculture, 6% unemployed
Organized labor: approximately 33% of labor force','2c271d141f8c993d6ed7ac3ef88aed2a026414e3a29b19960ce9605adb168fad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59ad6f18ab34049a39465057e2bf24a19976796cad08f439fcbc35206e20b17c',1973,'MQ','Martinique','people-and-society',140,'Population: 349,000, average annual growth rate 1.6%
(FY67-71) Saris
Ethnic divisions: 90% African and African-Caucasian-Indian
mixture, less than 5% East Indian Lebanese, Chinese,
5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public services, 11% construction
and public works, 10% commerce and banking, 10% services, 9% industry, 17%
other
Organized labor: 17% of labor force','0c98057c39c5431e8eddef1d0bffb41705c30984078ea68e4807930daf68b241','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdba5cddb9dcc3d5a9b89abc5839b0fca617fcd37b4fab06a95ebb3896e42d17',1973,'MR','Mauritania','people-and-society',144,'Population: 1,241,000, average annual growth rate 2.3%
(FY67-68)
Ethnic divisions: 70% Moor, 30% Negro
Religion: nearly 100% Muslim
Language: French and Arabic official
Literacy: under 5%
Labor force: about 18,000 wage earners (1964); remainder of population in
farming and herding
Organized labor: 18,000 union members claimed by single union, Mauritanian
Workers'' Union','013f14a1749bff647178cea0634745062a4a2788071b923c276a8c90b07259bb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0195f54723cdd3fdfca86414111912cc6dd0ae76af6af15b70bc62976548eb27',1973,'MU','Mauritius','people-and-society',148,'Population: 866,000, average annual growth rate 1.4%
Ethnic divisions: Indians 67%, Creoles 29%, Chinese 3.5%, English and French 0.5%
Religion: 51% Hindu, 33% Christian (mostly Catholic with a few Anglican
Protestants), 16% Muslim
Language: English official language; Hindi, Chinese, French Creole
Literacy: estimated 60% for those over 21, and 90% for those of school age
Labor force: 120,000; 65% agriculture, 5% industry; 30% are unemployed, under-
employed, or self-employed
Organized labor: about 10% of labor force','819958bd1fbaf7dbd02844807738c6779b252052f1a99b4b7b9f07e27a10c0cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31cc3db6f6612cdeb9c028dcbd38f1fb7f112ae48af5c05b0b9bae0a2c071ee4',1973,'MC','Monaco','people-and-society',151,'Population: 23,000 (official estimate for 31 December 1971)
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
Literacy: almost complete
Labor force: not available
Organized labor: not available','efa58a5c07c361720c9aa07f7fc3680a00e8c87050a439c2536bcea9ac3f8408','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e14376e9dc52ae9cab67e434dbfeba84effab67a43d0237916eb20ca44d7f099',1973,'MN','Mongolia','people-and-society',155,'Population: 1,338,000, average annual growth rate 2.8%
(current)
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese, 2%
Russian, 2% other s
Religion: predominantly Tibetan Buddhist, about 4% Muslim, AUSTRALIA
limited religious activity because of Communist regime
Languages: Khalkha Mongol used by over 90% of population; minor languages
include Turkic, Russian, and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the population is in the labor
force, including a large percentage of Mongolian women; acute shortage of
both skilled and unskilled labor (no reliable information available)
Population: 16,033,000, average annual growth rate 2.9%
(June 60-July 71)
Ethnic divisions: 99.1% Arab-Berber , .2% Jewish, .7% non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2% Hebrew
Language: Arabic (official); several Berber dialects; French is language of much
business, government, diplomacy, and postprimary education
Literacy: 20%
Labor force: almost 5.9 million (1970 est.) 69% agriculture, military, police,
civil service, transportation, mines, teachers, merchants, construction
workers, 10% industry and mining, 10% commerce and government
Organized labor: about 5% of the labor force
Population: 8,604,000, average annual growth rate 2.2%
(September 60-December 70)
Ethnic divisions: 97% African, 3% European, Asian, and Mulatto
Religion: primarily animist, 1,100,000 Muslims, 860,000 Christians
Language: Portuguese (official); many tribal dialects
Literacy: 10% (estimate)
Labor force: (1963 est.) 610,000; 50,000 non-African wage earners, 560,000
African wage earners in Mozambique; 290,000 additional African wage earners
temporarily working in Rhodesia and South Africa; unemployment serious
problem; most native Africans provide unskilled Tabor or remain in
subsistence agricultural sector
Organized labor: approx. 44,000 (end of 1970); 75% are white
Approved For Release 2004/09/15 : Gl AjRDP79-01051A000500010001-1
8.2 sq. mi.; insignificant arable land, no urban areas,
extensive phosphate mines
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 15 mi. AUSTRALIA
Population: 7,000 (official estimate for 30 June 1969)
Ethnic divisions: 2,921 Nauruans, 1,167 Chinese, 428
Europeans, 1,532 other Pacific Islanders
Religion: Christian (2/3 Protestant, 1/3 Catholic)
Language: Nauruan, a distinct Pacific Island tongue; English, the language of
school instruction, spoken and understood by nearly all
Literacy: nearly universal
Population: 12,448,000, average annual growth rate 2.5%
(June 61-71)
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%) 5
representing considerable intermixture of Indo-Aryan
and Mongolian racial strains; country divided among
many quasi-tribal communities
Religion: only official Hindu Kingdom in world, although no sharp distinction
between many Hindu and Buddhist groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided into numerous dialects;
Nepali official language and lingua franca for much of the country; same
script as Hindi
Literacy: about 12%
peed force: 4.1 million; 95% agriculture, 5% industry; great lack of skilled
abor
Population: 231,000, average annual growth rate 1.7%
(January 70-71)
Ethnic divisions: 85% largely mixed Negro stock except on ae
Aruba where 12% Negro and approx. 55% mixed Carib
Indian and European; rest European with some Chinese,
especially on Aruba
Religion: predominantly Roman Catholic; sizable Protestant, smaller Jewish
minorities
Language: officially Dutch; predominantly English; colloquial “papiamento,"” a
Spanish-Portuguese-Dutch-Engl ish mixture
Literacy: 75%-80%
Labor force: 66,000; 1% agriculture, 21% industry, 21% unemployed, 8%
construction, 41% government and services, 8% other
Organized labor: approx. 15% of labor force','417395cfbd82337191c1a114faa72354c2645548f9837d93388de02026a7dcd1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fa0b46b074f3e48433a56579b725ce7f92a4cd84d534cf15c92afe5704de1e5',1973,'NE','Niger','people-and-society',159,'ee a 4,297,000, average annual growth rate 2.7%
FY7]
Ethnic divisions: main Negroid groups 75% (of which, Hausa
50%, Djerma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a
very few Christians
Language: French official, many African languages; Hausa used for trade
Literacy: about 5%
Labor force: 26,000 wage earners; bulk of population engaged in subsistence
agriculture and animal husbandry
Organized labor: negligible
Population: about 58,814,000, average annual growth rate
2.7% (current)
Ethnic divisions: 250 tribal groups, of which most important are Hausa-Fulani
(north), Ibo and Yoruba (south); these 3 tribes total over 60% of population;
about 27,000 non-Africans
Religion: 47% Muslim, 34.5% Christian, 18.5% other
Literacy: est. 25%
Language: English official; Hausa, Yoruba, and Ibo also widely used
Labor force: approx. 22.5 million; about 41% of total population; only
about 700,000 are wage earners, of whom 8% are in agriculture, forestry,
hunting, and fishing; 7% mining and quarrying; 8% manufacturing; 22%
construction; 2% electricity; 8% commerce; 8% transportation and communication;
37% services
Organized labor: about 530,000 wage earners, approx. 2% of total labor force,
belong to some 700 unions
Population: 3,957,000, average annual growth rate 0.9% (current)
Ethnic divisions: homogeneous white population, small Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant and Roman Catholic, 1%
other
Language: Norwegian, small Lapp and Finnish-speaking minorities
Literacy: 99%
Labor force: 1.6 million; 19.5% agriculture, forestry, fishing, 27.0% mining and
manufacturing, 9.5% construction, 13.3% commerce, 11.9% transportation and
communication, 17.7% services; 1.5% unemployed
Organized labor: 60% of labor force
Population: 710,000, average annual growth rate 3.2%
(current)
Ethnic divisions: almost entirely Arab with small groups
of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low
Population: 56,724,000 (excluding Junagardh, Manavador,
Gilgit, Baltistan, and the disputed area of Jammu-Kashmir), average annual
growth rate 2.4% (FY70)
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages -- 7% Urdu, 64% Punjabi, 12%
Sindhi, 8% Pushtu, 9% other; English is lingua franca
Literacy: about 14%
Labor force: 12.7 million (est. 1961); 60% agriculture, 16% industry, 7% commerce,
15% service, 2% unemployed
Organized labor: 5% of labor force','e8f70024bed7f1079822fdb75380eb9866dbe213b94e63354ce44fc83ade7f8e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e385295967f73c8c766766fc4aef44dfa61ca111c482f0c740c20de8756997e6',1973,'PG','Papua New Guinea','people-and-society',164,'Population: 2,688,000, average annual growth rate 3.1%
(FY67-70)
Ethnic divisions: predominantly Melanesian and Papuan, some Negrito, Micronesian,
and Polynesian types
Religion: over one-half of population nominally Christian (490,000 Catholic,
320,000 Lutheran, other Protestant sects); remainder animist
Language: 700 indigenous languages; pidgin English and 2 or 3 native languages
are Tinguae francae for over one-half of population; English spoken by
1% to 2% of population
Literacy: 1%; in English, 0.1%
Labor force: no available figures; mostly subsistence farmers
ea 2,576,000, average annual growth rate 3.1%
FY7
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 715,000 (1968 est.); 55% agriculture, forestry, fishing; 8%
transport and other services; 19% manufacturing and construction; 13%
commerce and professions; 5% miscellaneous (est. 1962)
Organized labor: about 6% of labor force
Population: 14,686,000 (excluding Indian jungle population
which was estimated at 101,000 in 1961), average annual
growth rate 3.2% (FY71)
Ethnic divisions: 46% Indian; 38% mestizo (white-Indian); 15% white; 1% Negro,
Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 3.5 million (1967); 46% agriculture, 17% services, 14% manufacturing,
9% trade, 4% construction, 4% transportation, 2% mining, 4% other
Organized labor: 25% of labor force','a596d58af47753359e4b3870f022f26a1c078855d063787c8a60ab8d30247f3e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9235a3f332e1d3d1d29ec5188db54597512d25ee9f49d9dc7ab95fe7124767a7',1973,'PH','Philippines','people-and-society',168,'Population: 39,693,000, average annual growth rate 3.0%
(January 71-72)
Ethnic divisions: 91.5% Filipino (Malay), 4% Moros (Malay), 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4% Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national language of the Philippine
Republic; English is the language of school instruction and government
business
Literacy: about 75%
Labor force: 11 million; 60% agriculture, forestry, fishing, 12% manufacturing,
10.5% commerce, 10.5% government and services (business, recreation, domestic,
personal), 3.5% transport, storage, communication, 3% construction; 0.5% other
Population: 33,146,000, average annual growth rate 0.9% pe EGE
(current)
Ethnic divisions: 98.7% Polish, .6% Ukrainians, .5% Belorussians, less than
.05% Jews, .2% other
Religion: 95% Roman Catholic (about 75% practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26% industry, 36% other nonagricultural*','c6f95af6cff4d750fd2ac0b47a4ec5f6cf928e1e1424c2097595c20f9f87b69a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f30180491392f9a24a50409a4978b7ace61b4987308d4be10ec8a73ddecec3dd',1973,'PT','Portugal','people-and-society',172,'Population: metropolitan Portugal 8,870,000, average annual growth rate 0%
(current); Cape Verde Islands 250,300 (1969)
Ethnic divisions: homogeneous Mediterranean stock in mainland, Azores, Madeira
Islands; small, but growing number of black workers principally from the
Cape Verde Islands
Religion: 97% Roman Catholic, 1% Protestant sects, 2% other
Language: Portuguese
Literacy: 65% (a figure considered very high by some sources)
Labor force: 3.3 million (1970); 32% agriculture, 34% industry, 34% services;
unemployment virtually nil, but some underemployment widespread
Organized labor: 33.4% of labor force in syndicates subject to varying degrees
of government control
re 489,000, average annual growth rate 0.2%
FY69
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes); less than 1%
European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese official, numerous African languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in subsistence agriculture','25351796f6cedcd341214ed8e6b0050059ea871cb1eddfcbad0681cc92f1c683','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8852713c3f4bedcdb380f510e10c8511e9683d3e5f664147f78dde9618cd7fc',1973,'QA','Qatar','people-and-society',176,'Population: 143,000, average annual growth rate 10.8%
(FY65-69)
Ethnic divisions: 56% Arab; 23% Iranian; 14% Pakistani;
7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: 48,000 (1969)','2656d1d9cd1beb369d07d134217a76c1819f691e8843936fefac9e846500268c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('997b1bf5d6072f5c174c5ecfb709d009eafb940cf94f97efe49351d36593a020',1973,'IN','India','people-and-society',180,'eae 469,000, average annual growth rate 2.0%
FY71
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal unemployment
Population: 5,787,000, average annual growth rate 3.5%
z (January 71-72)
Ethnic divisions: 96% African, 3% European, less than
1% Coloreds and Asians
Religion: 51% syncretic (part Christian, part animist),
24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and Sindebele also widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including some migrants from Zambia and
Malawi), 108,000 Europeans, Asians, and coloreds (people of mixed heritage);
35% agriculture, 25% mining, manufacturing, construction, 40% transport and
services
Organized labor: about one-third of European wage earners are unionized, but
only a small minority of Africans (1966)
Population: 20,796,000, average annual growth rate 1,1%
(current)
Ethnic divisions: 87% Romanian, 8% Hungarian, 2% German,
3% other
Religion: 14,000,000 Romanian Orthodox, 1,000,000 Roman Catholic, 1,000,000
Protestants, 100,000 Jews, 30,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.4 million (est. 1 July 1966); 57% agriculture, 19% industry,
24% other nonagricultural
Population: 4,004,000 (African population only), average
annual growth rate 3.1% (FY65-67)
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa (Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French official; Kiswahili
language of African commerce, Kinyarwanda language
of interior and used in National Assembly
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy
Population: 106,000, average annual growth rate 1.6% Pat
(April 60-70)
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 27,000 (1960); 50% agriculture
Organized Tabor: 20% of labor force
Population: 18,000 (official estimate for 1 July 1971)
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of
Sanmarinese Workers (affiliated with ICFTU) has about
1,800 members; Communist-dominated Camera del Lavoro, about 1,000 members
Population: 5,688,000, average annual growth rate 2.8%
(current)
Ethnic divisions: 90% Arab, 10% Afro-Asian (est.)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 25% of population; 40% agriculture and herding, 12%
construction, 12% service, 12% government, 11% commerce
fog ei 4,077,000, average annual growth rate 2.2%
FY69
Ethnic divisions: 36% Wolof, 17.5% Fulani, 16.5% Serer, 9% Tukulor, 9% Dyola,
6.5% Malinke, 4.5% other African, 1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly Roman Catholic)
Language: French official, but regular use limited to literate minority; most
Senegalese speak own tribal language; use of Wolof vernacular spreading --
now spoken to some degree by nearly half the population
Literacy: 5-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence agricultural workers; about 125,000
wage earners
Organized labor: majority of wage-labor force represented by unions; however,
dues-paying membership very limited','c070c3a62ebcbaf79eb943cdd915a5a280333578f7dc1b405ae6be848d69a2ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('311abefb5bb18f354a8e653801cdf4b9c553ff3a3e218e1fc99a6307883f28a5',1973,'SC','Seychelles','people-and-society',184,'Population: 55,000, average annual growth rate 2.0% (FY69)
Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans)
Religion: 90% Roman Catholic
Language: English official; Creole most widely spoken
Literacy: limited
Labor force: 22,000 agriculture
Organized labor: 3 major trade unions','56b9a2e907802b5206c82bc922af8447ac77fd064828ccc2cc9f2e3da17c1cc1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62c0ef94a4cf6e2d92db593efc6a254509caa5ea15b20ffe40f91d0c9150ed74',1973,'SL','Sierra Leone','people-and-society',188,'baie 2,646,000, average annual growth rate 1.5%
FY7]
Ethnic divisions: over 99% native African, rest European and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to literate minority;
principal vernaculars are Mende in south and Temne in north; “Creole,” a
form of pidgin English, is also widely spoken
Literacy: about 10%
Labor force: about 1.5 million; most of population engages in subsistence
agriculture; only small minority, some 70,000, earn wages
Organized labor: 35% of wage earners','360f837234670b27cdc6e3a675acd7b0921caff50aec39b3a426ea39b34a4ff1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb553d55ffc85047c3ff109561fb62a5e57d5e3ca1cc9dc2698a1fb318c89dc9',1973,'SG','Singapore','people-and-society',192,'7 Population: 2,163,000, average annual growth rate 1.6%
(FY68-71)
Ethnic divisions: 76.2% Chinese, 15% Malay, 7% Indians
and Pakistani, 3% other
Religion: majority of Chinese are Buddhists or atheists; Malays nearly all Muslim;
minorities include Christians, Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay, Tamil, and English are
official languages
Literacy: 70% (1970)
Labor force: 474,718; 0.5% agriculture, forestry, and fishing, 0.4% mining and
quarrying, 32.2% manufacturing, 30.4% services, 5.2% construction, 21.5%
commerce, 9.8% transport, storage, and communications; 6% other
Organized labor: 24% of labor force
Population: 2,963,000, average annual growth rate 2.3%
(FY66~71)
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000 Arabs, 3,000 Europeans ,
800 Asians
Religion: almost entirely Muslim
Language: Somali (but no written form); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled laborers; 70% pastoral
nomads, 30% agriculturists, government employees, traders, fishermen,
handicraftsmen, other
Organized labor: law providing for government-controlled Tabor union promul gated
in June 1971, but union so far not established','a433da6e8eb602f74d178139831e24fd1c3c8de573fba3f2eff4ae5e41b73a79','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f9410d9bf273be9329af9775b3714f520dd77fccfda3a4f4524452af4030759',1973,'ZA','South Africa','people-and-society',196,'Population: 23,275,000, average annual growth rate 3.2%
(FY67~-70)
Ethnic divisions: 17.8% white, 69.9% Bantu, 9.4% Colored, 2.9% Asian
Religion: primarily Christian except Asian and Bantu; 60% of Bantu are animists
Language: Afrikaans and English official, Bantu have many vernacular languages
Literacy: almost all white population literate; government estimates 35% of
Bantu literate
Labor force: 8.7 million (total of economically active, 1960); 53% agriculture,
8% manufacturing, 7% mining, 5% commerce, 27% miscellaneous services
Organized labor: about 5% of total labor force is unionized (mostly white
workers); nonwhites have no bargaining power
Population: 788,000, average annual growth rate 1.9%
(FY61-65)
Ethnic divisions: 14% white, 81% Africans, 5% Coloured
(mulattoes); almost half the Africans belong to Ovambo
tribe; Herero, Okavango, Nama, and Damara tribes have
about 30,000 members each
Religion: whites predominantly Christian, nonwhites either animist or Christian
Language: Afrikaans principal language of about 70% of white population, German
of 22%, and English of 8%; several African languages
Literacy: high for white population; low for nonwhite
Labor force: 75,000 African wage earners (1964 est.); 68% agriculture, 15%
railroads, 13% mining, 4% fishing
Organized labor: no trade unions, although some white wage earners belong to
South African unions','db96fd1bc95df14a545aabb5f41b32af7073070fde21152301d8548e7b222074','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('851bb892fff2114bca189705f0afc8611bf2615fee9fcfb3065a789703b7185a',1973,'ZM','Zambia','people-and-society',199,'Population: 4,400,000, average annual growth rate 2.4%
(May 63-August 69)
Ethnic divisions: 98.7% African, 1.1% European, .2% other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000 Africans, 27,000 non-Africans;
15% mining, 9% agriculture, 9% domestic service, 19%
construction, 9% commerce, 10% manufacturing, 23% government and miscellaneous
services, 6% transport
Organized labor: 100,000 wage earners, primarily in industrial sector, are
unionized (early 1968)','af65cb919a27260eb7d65a1e3ca3bc3a035d6a6f98511384123f51fc30a99a41','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ef8c2fa18cee9cf65cfda9fc8fb8a47f64f3c7c2b9640038c7ebe5b732b72f7',1973,'US','United States','people-and-society',203,'Population: 209,648,000, average annual growth rate 1% (current)
Ethnic divisions: population basically of West European extraction,. modified
by subsequent waves of immigration
Religion: total membership in religious bodies, 128,470,000; Protestant
69,424,000, Roman Catholic 47,873,000, Jewish 5,780,000, other religions
5,393,000
Language: English, predominantly
Literacy: almost complete
Labor force: 86 million (1972)
Organized labor: 28.8% of total','029a660442caa197af5afa1e26fcd26937b0a672a93123871ca793e31873917f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f1191130be68049a9ab5f3204212be75b071ff19723aeb195f9795f484c36c4',1973,'','','people-and-society',2,'Population: 18,293,000, average annual growth rate
Lad 2.3% (7/70-7/71)
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9% Uzbeks,
9% Hazaras, minor ethnic groups include Chahar,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11%
Turkic languages (primarily Uzbeki and Turkmeni), 10% 30 minor languages
(primarily Baluchi and Pashai); much bilingualism
Literacy: under 10%
Labor force: about 4.3 million (official est.); 75%-80% agriculture and animal
husbandry, 20%-25% commerce, small industry, services; massive shortage of
skilled labor
Organized labor: none','009f0722bb6c62e7231caf25e059d37daef5ce4f3debdc9ef35e2294fd7e7875','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfa2a1e9038770abbbe427bcea7f9aa07a80bb1b4d663f8f09aacdc5062334cf',1973,'DZ','Algeria','people-and-society',10,'Population: 15,688,000, average annual growth rate 3.1%
(7/70-7/71)
Ethnic divisions: 99% Arab-Berbers, less than 1% Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 2.8 million; 47% agriculture, 8% industry, 24% other (military,
police, civil service, transportation workers, teachers, merchants,
construction workers); 40% of urban labor unemployed
Organized labor: 17% of labor force claimed; General Union of Algerian
Workers (UGTA) is the only labor organization and is subordinate to the
National Liberation Front
Population: 19,000 (official estimate for 1 July 1969)
4 Ethnic divisions: Catalan stock; 30% Andorrans, 61%
Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French and
Castilian
Labor force: unorganized; largely shepherds and farmers
Population: 9,738,000, average annual growth rate 0.3%
(current)
Ethnic divisions: 55% Flemings, 33% Walloons, 12% mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch); divided along ethnic lines
Literacy: 97%
Labor force: 4.0 million; approximately 95% is found in the following sectors:
32% manufacturing, 24% services, 16% commerce, banking, and insurance, 8%
construction, 7% transportation and communication, 5% agriculture, forestry,
and fishing, 1.5% mining, .8% public utilities and sanitary services; 3.1%
unemployed (1971)
Organized labor: 48% of labor force (1969)
Population: 132,000, average annual growth rate 2.9%
(4/60-4/70)
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican, Seventh-day Adventist, Methodist,
Baptist, Jehovah''s Witnesses, Mennonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 34,500; 39% agriculture, 14% manufacturing, 8% commerce, 12%
construction and transport, 20% services, 7% other; shortage of skilled
labor and all types of technical personnel; over 15% are unemployed
Organized labor: 8% of labor force
Population: 17,054,000 (including East Berlin), average
annual growth rate 0% (current)
Ethnic divisions: 99.7% German, .3% Slavic and other
Religion: 53% Protestant, 8% Roman Catholic, 39% unaffiliated or other; less than
5% of Protestants and about 25% of Roman Catholics actively participate
Language: German, small Sorb (West Slavic) minority
Literacy: 99%
Labor force: 8.2 million; 34.1% industry; 4.7% handicrafts; 6.8% construction;
11.9% agriculture; 6.8% transport and communications ; 10.1% commerce; 16.8%
services; 2.5% other
Organized labor: 87.7% of total labor force
Population: 3,021,000 average annual growth rate 0.6%
(4/66-4/71)
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 2% other
Language: English and Gaelic official; English is generally spoken
Literacy: 98%-99%
Labor force: about 1,130,000; 28% agriculture, forestry, fishing; 19% manufac-
turing; 15% commerce; 6% construction; 5% transportation; 4% government;
18% other
Organized labor: 36% of labor force
Population: 54,588,000, average annual growth rate 0.7%
(10/61-10/71)
Ethnic divisions: primarily Italian but population includes small clusters of
German-, French-, and Slovene-Italians in the north and of Albanian-Italians
in the south
Religion: almost 100% nominally Roman Catholic (de facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region (e.g., Bolzano) are
predominantly German speaking; significant French-speaking minority in Valle
d''Aosta Region; Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5-7% of population illiterate (1967); illiteracy varies widely by region
Labor force: 19,019,000 (April 1972); 17.7% agriculture, 42.5% industry,
36.5% other, 3.3% unemployed; underemployment, particularly in southern
Italy, renains widespread; 1.5 million Italians employed in other Western
European countries
Organized labor: 20% (est.) of labor force
Population: 5,095,000 (resident African population only),
average annual growth rate 3.3% (1/66-1/71)
Ethnic divisions: 7 major indigenous ethnic groups; no single tribe more than
20% of population; most important are Agni, Baoule, Krou, Senoufou, Mandingo;
approx. 1 million foreign Africans, mostly Voltaics; about 33,000 non-Africans
(25,000 French)
Religion: 66% animist, 22% Muslim, 12% Christian
Language: French official, over 60 native dialects, Dioula most widely spoken
Literacy: about 20%
Labor force: over 85% of population engaged in agriculture, forestry, livestock
raising; about 11% of labor force are wage earners, nearly half in agricul-
ture, remainder in government, industry, commerce, and professions
Organized labor: 20% of wage labor force
Population: 13,472,000, average annual growth rate 1.1%
(current)
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 41% Protestant, 40% Roman Catholic, 19% unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24% services, 16% commerce, 10%
agriculture, 9% construction, 7% transportation and communications, 4%
other; 1.05% registered unemployed; no shortage of skilled labor but shortage
of semi-skilled labor; 129,000 unfilled vacancies reported by employers in
January, 1971
Organized labor: 33% of labor force
Population: 235,000, average annual growth rate 2.0%
(1/71-1/72)
Ethnic divisions: 85% largely mixed Negro stock except on
Aruba where 12% Negro and approx. 55% mixed Carib
Indian and European; rest European with some Chinese,
especially on Aruba
Religion: predominantly Roman Catholic; sizable Protestant, smaller Jewish
minorities
Language: officially Dutch; predominantly English; colloquial "papiamento," a
Spanish-Portuguese-Dutch-English mixture
Literacy: 75%-80%
Labor force: 66,000; 1% agriculture, 21% industry, 21% unemployed, 8%
construction, 41% government and services, 8% other
Organized labor: approx. 15% of labor force
Population: 34,857,000 (including the Balearic and Canary Islands; also including
Alhucemas, Ceuta, Chafarinas, Melilla, and Penon de Velez de la Gomera),
average annual growth rate 1.1% (current)
Ethnic divisions: homogeneous composite of Mediterranean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great majority; but 17% speak Catalan,
7% Galician, and 2% Basque
Literacy: about 90%
Labor force (1970): 12.7 million; 29.1% agriculture, 37.3% industry, 33.6%
services; registered unemployment is 1.5% of labor force
Organized labor: 90% of labor force in compulsory government-controlled
syndicates
Population: 76,000 (preliminary total from the census of
31 December 1970)
Ethnic divisions: 51.2% Arab, Berber, and Negro nomads;
48 .8% Spanish
Religion: 51% Muslim, 49% Catholic
Language: Spanish (official), local Arabic or Hassania
Literacy: among Spanish, probably nearly 100%; among nomads, perhaps 5%
Labor force: 12,000; 50% agriculture, 50% other
Organized labor: none
Population: 13,208,000, average annual growth rate 2.2%
(7/63-10/71)
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor, 2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6% Muslim, 1% other
Language: Sinhala official, spoken by about 70% of population; Tamil spoken by
about 22%; English commonly used in government and spoken by about 10%
of the population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed; employed persons -- 53.4% agriculture,
14.8% mining and manufacturing, 12.4% trade and transport, 19.4% services
and other
Organized labor: 43% of labor force, over 50% of which employed on tea, rubber,
and coconut estates
Population: 6,885,000, average annual growth rate 3.3%
(current)
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians, and other
Religion: 70.5% Sunni Muslim, 16.3% other Muslim sects, 13.2% Christians of
various sects
Language: Arabic, Kurdish, Armenian; French and English widely understood
Literacy: about 40%
Labor force: 2.0 million; 67% agriculture, 12% industry (including construction),
21% miscellaneous services; majority unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 14,368,000, average annual growth rate 2.7% (7/71-7/72)
Ethnic divisions: 99% native Africans consisting of well over 100 tribes; 1%
Asian, European, and Arab
Religion: Tanganyika -- 40% animist, 30% Christian, 30% Muslim; Zanzibar --
almost all Muslim
Language: Swahili English and official English primary language of commerce,
administration and higher education; Swahili widely understood and generally
used for communication between ethnic groups; first language of most people
is one of the local languages
Literacy: 15%-20%
Labor force: under 400,000 in paid employment, over 90% in agriculture
Organized labor: 15% of labor force
GOV ERNMENT:
Legal name: United Republic of Tanzania
Type: republic; single parties dominate both on the mainland and on Zanzibar
Capital: Dar es Salaam
Political subdivisions: 22 regions -- 18 on mainland, 4 on Zanzibar islands
Legal system: based on English common law, Islamic law, customary law, and German
civil law system; interim constitution adopted 1965; judicial review of
legislative acts limited to matters of interpretation; legal education at
University College, Dar es Salaam; has not accepted compulsory ICJ jurisdiction
Branches: President Julius Nyerere has full executive authority on the mainland;
National Asssembly dominated by Nyerere and the Tanganyika African National
Union (TANU), consists of 120 elected members, 18 ex officio members, and up
to 25 appointed members from mainland, and 3 ex officio members and up to 52
appointed members from Zanzibar; First Vice President Aboud Jumbe and the
Revolutionary Council still run Zanzibar despite the efforts of Nyerere to
integrate the islands into the political system of the mainland
Government leader: President Julius Nyerere
Suffrage: universal adult
Political party and leaders: Tanganyika African National Union (TANU), only main-
land political party, dominated by Nyerere with Prime Minister and Second
Vice President Rashidi Kawawa as his top lieutenant; Afro-Shirazi Party, the
only party in Zanzibar, is supposed to merge with TANU eventually
Voting strength (October 1970 national elections): 5 million registered voters;
Nyerere received 95% of 3.6 million votes cast
Communists: a few Communists and sympathizers
Member of: AFDB, Commonwealth, EAC, FAO, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
333
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Population: 37,200,000, average annual growth rate 2.7%
(4/60-4/70)
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70%
Labor force: 88% agriculture, 9% commerce, 3% industry','924d1e32e014b07a1768358b177f64ff8fbe9326dba23e51bf95b9a9a7c2006e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ab831be249921efa32c378f766b267b37f15ebcdc8f9695ad89629c092dc34b',1973,'AO','Angola','people-and-society',15,'Population: 5,908,000, average annual growth rate 1.6%
(12/60-12/70)
Ethnic divisions: 93.6% African, 5% Europeans, 1.4% mulatto (1960)
Religion: about 84% animist, 12% Roman Catholic, 4% Protestant
Language: Portuguese (official), many native dialects
Literacy: 10%-15%
Labor force: 2.6 million economically active (1964); 531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)','e039b7d7b24c4c4a63430715480d7f9f59fa7c683aa453a198610b579ecda451','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('504aa6f961d8efc7be53343ed8c2d30346a81a6ab98c111ed1f9ef5e3ca35ab3',1973,'BR','Brazil','people-and-society',18,'Population: 76,000, average annual growth rate 2.6%
(4/60-4/70)
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant) » other Protestant sects and some
Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000
Population: 5,013,000, average annual growth rate 2.5%
(current)
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic; active protestant
minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.5 million (1972); 69.1% agriculture, 3.3% mining, 9.6% services
and utilities, 8% manufacturing, 10% other
Organized labor: 150-200,000, concentrated in mining, industry, construction,
and transportation
Population: 101,035,000, average annual growth rate 2.9%
(9/60-9/70)
Ethnic divisions: 60% white, 30% mixed, 8% Negro, and 2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal )
Language: Portuguese
Literacy: 67% of the population 15 years or older (1970)
Labor force: about 30 million in 1970 (est.); 44.2% agriculture, livestock,
forestry, and fishing, 17.8% industry, 15.3% services, transportation, and
communication, 8.9% commerce, 4.8% social activities, 3.9% public administra-
tion, 5.1% other
Organized labor: about 50% of labor force; only about 1.5 million pay dues
Population: 148,000, average annual growth rate 4.5%
(8/60-8/71)
Ethnic divisions: 52% Malays, 28% Chinese, 15% indigenous
tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8% Christian; 32% other (Buddhist
and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture, 32.8% industry, manufacturing, and
construction, 33.8% trade, transport, services, 2.9% other
Organized labor: 8.4% of labor force
Population: 9,815,000, average annual growth rate 2%
(9/60-4/70)
Ethnic divisions: 85%-90% mestizo, 3% Indian, 7% European, Asiatic, and other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 89%
Labor force: 3.1 million (1969); 26% agricultural, 25% industry and construction,
27% services, 14% commerce, 4% mining, 4% other (1969)
Organized labor: 25% of labor force (1969)
Population: 898,582,000, average annual growth rate 2.4% (current)
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur, Hui, Yi, Tibetan, Miao,
Manchu, Mongol, Pu-I, Korean, and numerous lesser nationalities
Religion: most people, even before 1949, have been pragmatic and eclectic,
not seriously religious; most important elements of religion are Confucian-
ism, Taoism, Buddhism, ancestor worship; about 2%-3% Muslim, 1% Christian
Language: Chinese (Mandarin mainly; also Cantonese, Wu, Fukienese, Amoy, Hsiang,
Kan, Hakka dialects), and minority languages (see ethnic divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85% agriculture, 15% other; shortage of
skilled labor (managerial, technical, mechanics, etc.); surplus of unskilled
labor
Population: 15,434,000 (excluding the population of
Quemoy and Matsu Islands and foreigners), average
annual growth rate 2% (7/71-7/72)
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese, 2% aborigines
Religion: 93% mixture of Buddhism, Confucianism, and Taoism; 4.5% Christian;
2.5% other
Language: Mandarin, Taiwanese, Japanese, English
Literacy: about 90%
Labor force: 4.9 million; 33% primary industry (agriculture), 32.1% secondary
industry (including manufacturing, mining, construction), 34.9% tertiary
industry (including commerce and services) 1972
Organized labor: about 12% of 1972 labor force (government controlled)
Population: 5,180,000, average annual growth rate 2.1%
(current)
Ethnic divisions: over 90% Negro, nearly 10% mulatto,
few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of which an overwhelming
majority also practice Voodoo)
Language: French (official) spoken by only 10% of population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.6 million (est. January 1968); 86% agriculture, 12% industry,
2% unemployed; shortage of skilled labor; unskilled labor abundant
Organized labor: less than 1% of labor force
Population: 2,862,000, average annual growth rate 3.5%
(7/69-7/70)
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 57.4% of persons 10 years of age and over (est. 1970)
Labor force: approx. 900,000 (est. mid-1972); 66% agriculture, 12% services, 8%
manufacturing, 5% commerce, 6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-1972)
Population: 1,570,000, average annual growth rate 3.1%
(7/70-7/71)
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7% Indian and other
Religion: over 90% Roman Catholic, remainder mainly Protestant
Language: Spanish; about 14% speak English as native tongue; many Panamanians
bilingual
Literacy: 80% of population 10 years of age and over
Labor force: 468,000 (1969 est.); 40% agriculture, 19.9% services, 11% commerce,
12% manufacturing, 6% construction, 5% transportation and communications, 26%
other (1969 gees 5.6% Canal Zone; national average of 7%-8% unemployed; 25%
to 30% of unemployed in Panama and Colon; shortage of skilled labor but an
oversupply of unskilled labor
Organized labor: 5% of labor force
Population: 2,387,000, average annual growth rate 2.6%
(10/62-7/72)
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 800,000 (1971 est.); 55% agriculture, forestry, fishing; 8%
transport and other services; 19% manufacturing and construction; 13%
commerce and professions; 5% miscellaneous (est. 1962)
Organized labor: about 5% of labor force
Population: 13,995,000 (excluding Indian jungle population
which was estimated at 101,000 in 1961), average annual
growth rate 2.9% (7/61-6/72)
Ethnic divisions: 46% Indian; 38% mestizo (white-Indian); 15% white; 1% Negro,
Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 3.5 million (1967); 46% agriculture, 17% services, 14% manufacturing,
9% trade, 4% construction, 4% transportation, 2% mining, 4% other
Organized labor: 25% of labor force
Population: 40,194,000, average annual growth rate 3.0%
(7/71-7/72)
Ethnic divisions: 91.5% Filipino (Malay), 4% Moros (Malay), 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4% Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national language of the Philippine
Republic; English is the language of school instruction and government
business
Literacy: about 83%
Labor force: 11 million; 60% agriculture, forestry, fishing, 12% manufacturing,
10.5% commerce, 10.5% government and services (business, recreation, domestic,
e personal), 3.5% transport, storage, communication, 3% construction; 0.5% other
Population: 2,804,000, average annual growth rate 1.0%
(7/66-7/70)
Ethnic divisions: 80% white, 20% mixed (with Indian and
Negro elements)
Religion: predominantly Roman Catholic
Language: Spanish, English
Literacy: 88%
Labor force: 706,000; 19% agriculture, 14% manufacturing, 7% construction, 39%
government services and trade, 8% other, 13% unemployed
Organized labor: 45% of labor force
Population: 106,000, average annual growth rate 1.6%
(4/60-4/70)
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 27,000 (1960); 50% agriculture
Organized labor: 20% of labor force
Population: 987,000, average annual growth rate 1.3%
(4/60-4-70)
Ethnic divisions: 43% Negro, 36% East Indian, 16% mixed, 2% white, 3% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23% Hindu, 6% Muslim, 13%
unknown
Language: English
Literacy: 80%
Labor force: about 361,000 (1971 est.), about 20.4% agriculture, 18.3% mining,
quarrying, and manufacturing, 15.8% commerce; 14.6% construction and
utilities; 6.9% transportation and communications; 20.8% services,
3,270 other (1965)
Organized labor: 28% of labor force','e6869ee2ae912773f6a493d38b3a4f9aa5c811a094783793ce2756f0f5c623f2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df190eb98bb74765da15ad5106b038315ea5bc24d78b0f9ed8ab1821a9f130fa',1973,'AR','Argentina','people-and-society',24,'Population: 24,380,000, average annual growth rate 1.6%
(9/60-9/70)
Ethnic divisions: approximately 85% white, 15% mestizo, Indian, or other
nonwhite groups
Religion: 90% nominally Roman Catholic (less than 20% practicing), 2%
Protestant, 2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 9.5 million; 19% agriculture, 25% manufacturing, 20% services,
11% commerce, 6% transport and communications, 19% other
Organized labor: 25% of labor force (est.)','f9504057bbf36e644a492fdc8fae06dbced045c34b40b2916e20a53013819def','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60fe336b7d1c521940fdebc0520df20c5983faa1d89e0ede47b77efc437cec60',1973,'AT','Austria','people-and-society',28,'Population: 7,481,000, average annual growth rate 0.2%
(1/71-1/72)
Ethnic divisions: 98.1% German, .7% Croatian, .3% Slovene,
.9% other 2 ALGERIA
Religion: 85% Roman Catholic, 7% Protestant, 8% none or
other
Language: German
Literacy: 98%
Labor force: 2,614,600 (1972); 18% agriculture and forestry, 49% industry and
crafts, 18% trade and communications, 7% professions, 6% public service,
2% other; 2.4% registered unemployed; an estimated 200,000 Austrians are
employed in other European countries; foreign laborers in Austria number
more than 200,000 (1972); unemployment 2.1% (1972)
Organized labor: about 2/3 of wage and salary workers (1971)','6e31d0c45ad72de970d7d232d5cbd973d8033799f81c4c68294a48c533f7026e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f539c778d3178e710f5990b5d11ed8fe6ba5c34f14d95ce8ef97322f10a79ff8',1973,'BS','Bahamas','people-and-society',32,'Population: 199,000, average annual growth rate 4%
(11/63-4/70)
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: mainly Church of England; some Protestant, Greek Orthodox, and
Roman Catholic
Language: English
Labor force: 60,000 (1963); 25% organized','2362e49a3ac75bc365709d499568313c2076183b5b16ddfa297dfbfb9992dc8a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66569d7b69ac57a6e92f96944da0b3797866a2b062ed7e95a45fedaf9ac7dd46',1973,'BH','Bahrain','people-and-society',36,'Population: 231,000, average annual growth rate 2.9%
(2/65-4/71)
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani, and
Indian, 3% other
Religion: Muslim
Language: Arabic
Literacy: about 30% (1965)
Labor force: 53,274 (1965)','550b29403badc120e227bc4cd66b738e34fb3ae17248a5d2d1a840e755c6f296','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5320ffb70156a4115594c58e18c3069cb9eee338c579e7c1cb62ecaa1ca67db1',1973,'BD','Bangladesh','people-and-society',40,'Population: 64,186 ,000*, average annual growth rate 1.9%
(7/69-7/70)
Ethnic divisions: predominantly Bengali; fewer than 1
million "Biharis" and fewer than 1 million tribals
Religion: about 83% Muslim, 16% Hindu; less than 1% Buddhist and other
Language: Bengali
Literacy: about 20%
Labor force: about 25 million; majority are unemployed or part-time employees ;
over 80% of labor force is in agriculture','0c9c7510c6549caa20d8eea84b75df7342871de2dd9548123c064149d23a171d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db2b7a644cf92fe2df46b469ecf81fe334eff25e8c5732c57b2273b016e79791',1973,'BM','Bermuda','people-and-society',47,'Population: 55,000, average annual growth rate 2.1%
(10/60-10/70)
Ethnic divisions: approximately 63% African, 37% white
Religion: 47.5% Church of England, 10.2% Catholic, 38.2% other Protestant, A 2%
other
Language: English
Literacy: virtually 100%
Labor force: 24,700 (1970)','8ddb468155770e8b43599503cb7cb30fde44d20404ff6841923ceef437089e0c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6dfac4ce9d651dc29504aac7ae478502f1e323393fedcdfa11342c3fad82122',1973,'BT','Bhutan','people-and-society',51,'j Population: g94,000, average annual growth rate 2.3%
(current)
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese,
15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25% Buddhist-influenced
Hinduism
Language: Bhotias speak various Tibetan dialects, most
widely spoken dialect is Druk-ke, the official languages Nepalese speak
various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry; massive lack of skilled
labor','a7f42cbe4fd23d8349bb21f612081e698e9680d7afacc765e5ec4eeaa7671c34','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afee3925e6b60a839073f819bf6d41392c4f2e825b4af6859a85fa38a34574d9',1973,'BW','Botswana','people-and-society',55,'4 Population: 646,000, average annual growth rate 2.4%
(current)
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% European
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 29% in English; about 32% in Tswana;
less than 1% secondary school graduates
Labor force: 385,000; most are engaged in cattle raising and subsistence
agriculture; about 51,000 in internal cash economy, another 60,000 spend
at least 6 to 9 months per year as wage earners in South Africa (1971)
Organized labor: eight trade unions organized with a total membership of
approximately 9,000 (1972 est.)','0534c3eb4d6f3bb2524eb6394a225a0efded386fa336931f4b701793ab22188b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08c0f1c2cf86c353ea73ab99af8ea2420cd70419dca02d68d0baa40f20cd7e49',1973,'BG','Bulgaria','people-and-society',61,'Population: 29,479,000, average annual growth rate 2.2%
(7/69-7/70)
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2% Kachin,
2% Chin, 2% Chinese, 3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their own languages
Literacy: 60% (official claim)
Labor force: 10 million; 67% agriculture, 13% industry, 20% services, commerce,
and transportation
Organized labor: no figure available; old labor organizations have been
disbanded, and government is forming one central labor organization','37354c792a3dc0ea7fde0ed681c4426045fc81c36e5f9ca43dc0a8af3f6ee08c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44bd0f9e39c084481ff1645446175583cd95f365636e566044b971a293f37cdb',1973,'BI','Burundi','people-and-society',63,'‘ Population: 3,767,000, average annual growth rate 2.0%
(7/70-7/71)
Ethnic divisions: Africans -- 86% Hutu (Bantu), 13% Tutsi
(Hamitic), 1% Twa (Pigmy)s non-Africans include (late
1968) 3,000 Europeans, 1,000 Asians
Religion: over 60% Christian (50% Catholic, 10% Protestant) ;
rest mostly animist plus smal] number of Muslims
Language: Kirundi and French official
Literacy: about 55% in Kirundi, 10% in Swahili, or 6% in French
Labor force: 1,865,471 (1970 est.)
Organized labor: sole group is the Union of Burundi Workers (UTB), membership
about 30,000, affiliated with government party','283e28ce5703859b1fd95d007595eac685c328f33ec1906502bf8a717fbc0e86','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbe93eaff2f0d8892c247f50994a939d9c70aa0e83205595367189ab6aa91f65',1973,'KH','Cambodia','people-and-society',67,'Population: 7,309,000, average annual growth rate 2.2%
(7/68-7/69)
Ethnic divisions: 89% Khmer (Cambodian), 3% Vietnamese,
5% Chinese, 3% other minorities :
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian
Literacy: 55% (est.)
Labor force: 2.56 million; 80.9% agriculture, 5.5% sales, 4.7% manufacturing,
transport, communications, 3.9% professional, administrative, clerical,
3.5% defense; 1.5% unemployed
Organized labor: .5% of labor force','2bc0a717bd413be17b3bdb74400aad4f162f6b9a68cdd8569342504dbb682329','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20e0fee9cb336a9d9ec5d5ed11c241ac9bf5df2ddad866d4dd086f6205702dcb',1973,'CM','Cameroon','people-and-society',71,'Population: 6,147,000, average annual growth rate 1.7%
(7/69-7/70)
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroon Highlanders, 19% Equatorial Bantu, 8% North West
Bantu, 10% Fulani, 7% Eastern Nigritic, 11% Kirdi, 13% other African, less
than 1% non-African
Religion: about one-half animist, one-third Christian; rest Muslim
Language: English and French official, 24 major African language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence agriculture and herding;
200,000 wage earners (maximum) including 22,000 government employees, 63,000
paid agricultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force','43a3dd20708c7d35992afbd168a985754daf160d2b8558f97ef21eb3d3d0549e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dca13e4156c729605b340000aa00b32402478ccf7f684de72eee71ebf665b4c6',1973,'CF','Central African Republic','people-and-society',75,'Population: 1,710,000, average annual growth rate 2.2%
(7/67-7/71)
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and linguistic
characteristics; Banda (32%) and Baya-Mandjia (29%) are
largest single groups; 6,500 Europeans, of whom 6,000
are French and majority of the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 27% animist, 5% Muslim; animistic
beliefs and practices strongly influence the Christian majority
Language: French official; Sangho, the lingua franca and unofficial national
language
Literacy: estimated at 5%-10%
Labor force: about half the population economically active, 80% of whom are in
agriculture; approximately 64,000 salaried workers
Organized labor: 1% of labor force','13520cf66133c01ae955ee18c4af3d82c07f0228de60f420078c5b08313ca159','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3215c7703da1dc9c1cd6010615aeebcd49d58d5e09a3e6a41cc1abfff02db332',1973,'TD','Chad','people-and-society',79,'Population: 3,867,000, average annual growth rate 2.0%
(7/66-7/71)
Ethnic divisions: over 240 tribes representing 12 major
ethnic groups -- Muslims (Arabs, Toubou, Fulani,
Kotoko, Hausa, Kanembou, Baguirmi, Boulala, and
Wadai) in the north and center and non-Muslims (Sara,
Mayo-Kebbi, and Chari) in the south; some 150,000
nonindigenous, 5,000 of them French
Religion: about half Muslim, 5% Christian, remainder animist
Language: French official; Chadian Arabic is lingua franca in north, Sara and
Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically active group, of which 90%
are engaged in unpaid subsistence farming, herding, and fishing; 47,000
wage earners in industry and civil service
Organized labor: about 20% of wage labor force','8b83f71af8217e5204513200de0b38493452ce4c0d8a2ff5ba7c09c4e9372fc5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1098a73611ca948fadbc50c5e4b94fbf7d9e8f8628078f19b4aab467097e645f',1973,'CO','Colombia','people-and-society',83,'Population: 24,019,900, average annual growth rate 3.2%
(current)
Ethnic divisions: 58% mestizo, 20% caucasian, 14% mulatto, 4% Negro, 3% mixed
Negro-Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Litaracy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture, 13% manufacturing, 18% services,
9% commerce, 13% other (1964)
Organized labor: 13% of labor force (1963)
Population: 292,000, average annual growth rate 2.7%
(9/66-9/70)
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor Force: mainly agricultural
Organized labor: information not available','efab0800b81d13d84caaad710e69e3db29ef31779c03c3586d29a80f1dace1cc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b6465933389afd421e68d2a5d38c264735f813f3b2c3bada29241a7c464aa1a',1973,'CG','Congo','people-and-society',87,'Population: 991,000, average annual growth rate 2%
(current)
Ethnic divisions: about 15 ethnic groups divided into some 75 tribes, almost all
Bantu; most important ethnic groups are Kongo (48%) in south, Teke (17%) in
center, M''Bochi (12%) and Sangha (20%) in north; about 8,500 Europeans,
mostly French
Religion: about half animist, half nominally Christian, less than 1% Muslim
Language: French official, many African languages with Lingala and Kikongo
most widely used
Literacy: about 20%
Labor force: about 40% of population economically active, most engaged in
subsistence agriculture; 79,100 wage earners; 40 ,000-60,000 unemp]oyed
Organized labor: 16% of total labor force (1965 est.)','41d66b8a41987f035f0e8ccbe9889b6c314602988f412819ca6a25c82d9c36b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7216a929d38ddba6f314e83bebd298443c02a290a8070bcb71a44602e46cf877',1973,'CR','Costa Rica','people-and-society',91,'Population: 1,888,000, average annual growth rate 2.8%
(7/70-7/71)
Ethnic divisions: 98% white (including mestizo), 2% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 85%
Labor force: 530,000 (1970)s 46.3% agriculture; 13.2% manufacturing; 11% commerce;
8% construction, trans ortation, and communicationss 21.5% other; shortage
of skilled labor (1968
Organized labor: about 6% of labor force','3b22f3b93dca9bae5ad0a6857c0d005a5015a569977a37b3fcd5104dbcf711a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3d74ebc7166d442b41323b085ec9f8edb1f1eeddb2510960d77ac58d3f7ebb7',1973,'CU','Cuba','people-and-society',95,'Population: 8,925,000, average annual growth rate 1.7%
(current
Ethnic divisions: 51% mulatto, 37% white, 11% Negro,
1% Chinese
Religion: at least 85% nominally Roman Catholic before Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.36 million; 34% agriculture, 17% industry, 6% construction, 6%
transportation, 29% services, 8% unemployed and underemp1oyed
Organized labor: 46% of total force','755fb59e48aa43bf023af8f9f116c65a1b81be06e1843ce8dc63252f3fa5d4db','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3573828121030dcf78baef995a670abe2c09a73f6dd759d25d55dc4184862e1b',1973,'CY','Cyprus','people-and-society',99,'Population: 651,000, average annual growth rate 0.9%
(7/71-7/72)
Ethnic divisions: 78% Greek; 18% Turkish; 4% British,
Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Armenian Orthodox and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Labor force: 267,000 (1970 est.), 38% agriculture, 23% industry, 9% commerce,
2% mining, 28% other; 3,130 registered unemployed (December 1968)
Organized labor: 24% of labor force
Population: 14,563,000, average annual growth rate 0.6%
(current)
Ethnic divisions: 62.5% Czechs, 31.8% Slovaks, 3.9% Maayars, ve d
1% Germans, 1% Ukrainians, Jews, Poles uBvA leo yeR Ue Say
Religion: 77% Roman Catholic, 20% Protestant, 2% Orthodox, ; oor:
1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.1 million; 18% agriculture, 37% industry, 11% services, 34%
construction, communications and others
Population: 2,955,000, average annual growth rate 2.8%
(7/64-7/68)
Ethnic divisions: 99% Africans (42 ethnic groups, most important being Fon, Adja,
Yoruba, Bariba), 5,900 Europeans
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most common vernaculars in south,
at least 6 major tribal languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture; 15% civil service,
artisans, and industry
Organized labor: approximately 75% of wage earners, divided among two major
and several minor unions','c121c723fe09c9f366dc4fb8a332a817ae17b4685b91c0dc4d029d29b33b69e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e14a6df11003c2df9153e465103fd90eef99f906ce69381158b63ab46ed81413',1973,'DK','Denmark','people-and-society',103,'Population: 5,016,000, average annual growth rate 0.4%
(current
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant and Roman Catholic, 1%
other
Language: Danish; small German-speaking minority
Literacy: 99%
Labor force: 2.4 million; 14.5% agriculture, forestry, fishing, 29.4% mining and
manufacturing, 8.1% construction, 15.0% commerce, 6.6% transportation and
communications, 23.6% services, 0.2% other; 3.7% unemployed
Organized labor: 65% of labor force','01a357fc446c0e3b6ca5ea3abcf37e5c1fb2e4fc255604d2f0d2038565bd5aff','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e18916e3bbde908b55a188c80f972663a00907554e8bbfc18ce70bc711c4d84',1973,'DM','Dominica','people-and-society',107,'Population: 74,000, average annual growth rate 1.6%
(4/60-4/70)
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist
Language: English; French patois
Literacy: about 80%
Labor force: est. at 23,000 in 1960; about 50% in agriculture
Organized labor: 25% of the labor force','14af7bb896c3d0d64926e34fd786c1d961bc5cdd48965dddc4866bd01f8f9d88','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd1524a54260b65c7da028c22dd96abe7d3dedf64ad8626726ccce1615865b0e',1973,'DO','Dominican Republic','people-and-society',109,'Population: 4,441,000, average annual growth rate 3.0%
(7/70-7/71)
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 35% to 40% of adult population
Labor force: 1.3 million; 73% agriculture, 8% industry, 19% services and other
Organized labor: 12% of labor force','d088b0c1663505a7f682c648f36df00ded5b20f5fac63deb63f952558fbeed94','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c590d738df3d61ec9f6e0c14a7ef2e3eee9fc5bec0aae6e17ffc8760d7618a60',1973,'EC','Ecuador','people-and-society',113,'Population: 6,726,000 (excluding nomadic Indian tribes),
average annual growth rate 3.4% (7/71-7/72)
Ethnic divisions: 40% mestizo, 40% Indian, 10% white, 5% Negro, 5% Oriental and
other
Religion: 95% Roman Catholic (majority nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture, 13% manufacturing, 4%
construction, 7% commerce, 4% public administration, 12% other services,
4% other
Organized labor: 12% of labor force','392f88ad67e1a3155032a8eedc6b3236854c6bd0d525a9920c9de7641d3e1f3a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c377a93b637ab9a1b81b7613d9689dd93f301bfbd83833b99c8822b29f56f1d8',1973,'EG','Egypt','people-and-society',117,'Population: 35,620,000, average annual growth rate 2.2% (7/70-7/72)
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek, Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt and other
Language: Arabic official, English and French widely understood by educated
classes
Literacy: around 40%
Labor force: 8 to 12 million; 45% to 50% agriculture, 10% industry, 10% trade
and finance, 30% services and other; serious shortage of skilled labor
Organized labor: 1 to 3 million','88f8b9244f8a0c25223c05cb3abe57d96f69fea821a2f2dbb599e86a73e0b43c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('628e448b128b1fc74c6e63466e8916e2f7ffed621aa396d13166f06c413bd728',1973,'SV','El Salvador','people-and-society',121,'Population: 3,800,000, average annual growth rate 3.5%
(5/61-6/71)
Ethnic divisions: 84%-88% mestizo; Indian and white minorities, 6%-8% each
Religion: predominantly Roman Catholic, probably 97%-98%
Language: Spanish
Literacy: 50% of population 10 years of age and over (1973 est.)
Labor force: 1,395,000 (est. 1973); 57% agriculture, 14% services, 14%.
manufacturing, 6% commerce, 9% other; shortage of skilled labor and large
pool of unskilled labor, but manpower training programs improving situation
ee ae 3.5% of total labor force; 6.6% of nonagricultural labor force
1972 est.','96130e0258a65feeaf23de65a3a156d5c49467f6d011d7e99de5811d0890be26','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9083662dedd9fff2a5e6c6bf36d689ebb9b953e4eb9b91fd370b8f875310afdc',1973,'GQ','Equatorial Guinea','people-and-society',125,'Population: 307,000, average annual growth rate 1.8%
(7/68-7/69); Rio Muni, 218,000, average annual growth
rate 1.5% (7/68-7/69); Fernando Po, 89,000, average annual growth
rate 2.6% (7/68-7/69)
Ethnic divisions: indigenous population of Fernando Po primarily Bubi, some
Fernandinos; of Rio Muni primarily Fang; some 4,000-5,000 Nigerians, mostly
on Fernando Po; less than 1,000 Europeans, primarily Spanish
Religion: natives all nominally Christian and predominantly Roman Catholic; some
Pagan practices retained
Language: Spanish official language of government and business; also pidgin
English, Fang
Literacy: 12% (est.)
Labor force: most Equatorial Guineans involved in subsistence agriculture;
smal] wage labor force dominated by Nigerian contract laborers','be96045efe5e3002e5348bfa272b9a226639023db56164486d2eab1a93fe5e4a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b20959573c7561f97aefc2cf8de6b62b81ff990b9663c7def40de50c43bec32a',1973,'ET','Ethiopia','people-and-society',129,'Population: 26,541,000, average annual growth rate 2.5%
(7/70-7/71)
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%, Sidamo 9%, Shankella 6%,
Somali 6%, Afar 4%, Gurage 2%, other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Muslims, 15%-20% animist, 5% other
Language: Amharic official; many local languages and dialects; English major
foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10% government, military,
and quasi-government
Organized labor: 60,000 registered labor union members
Population: 39,000, average annual growth rate 0.9%
(4/66-11/70)
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faeroese (derived from Old Norse), Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufacturing, transportation,
and commerce
2, FRANCE 4
Population: 2,000 (official est. for 1 July 1971)
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 {est.); over 95% {est.) in agriculture, mostly sheepherding','65591d0035b92e61c38ab9ba74d9717aa314f9db52e7774c4a7daf698f5d677d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('174840a73dfa4f2a97eced755d35e040d326832d75887ceba98fed03bbab6078',1973,'FJ','Fiji','people-and-society',133,'Population: 551,000, average annual growth rate 1.9%
(7/71-7/72)
Ethnic divisions: 42% Fijian, 50% Indian, 8% European,
Chinese and others
Religion: Fijians mainly Christian, Indians are Hindu with a Muslim minority
Language: English and Fijian (official). Hindustani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no breakdown on remainder
Organized labor: about 50% of labor force organized into 22 unions; unions
organized along lines of work, breakdown by ethnic origin causes further
fragmentation','e500685bd09d727f9058973a1a4a3169fd1db6c6bbeade49f85cf63fc88d845a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a4d9387d3fde21b5bc13375f65234208290cd3a577b35f144adc6083eb77a23',1973,'GF','French Guiana','people-and-society',143,'Population: 59,000, average annual growth rate 5.0%
(7/66-7/70) :
Ethnic divisions: 95% Negro or mulatto, 5% caucasian, 10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
_ Labor force: 17,012 (1967 census); services 49%, construction 21%, agriculture
18%, industry 8%, transportation 4%; information on unemployment unavailable
Organized labor: 7% of labor force
Population: 125,000 (official estimate for 1 July 1967)
Ethnic divisions: 59,350 Somalis (large number of the
Somalis are temporary immigrants from Somalia -- not
citizens of territory), 53,650 Afars, 6,000 Arabs, 7,000 French (inclusive
of French military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at port
Organized labor: some 3,000 railway workers organized','d6e5c023621b702d7603cb318b8498af1e93461140b727dd5242a3f5baf479b9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc66ec6441c062ff03d2449c1657b39211eb37321983502b1b613817bd6a1767',1973,'GA','Gabon','people-and-society',147,'Population: 525,000, average annual growth rate 1.7%
(7/66-7/70)
Ethnic divisions: about 40 Bantu tribes, including 4
major tribal groupings (Fang, Eshira, Mbede, Okande); about 21,000 expatriate
Africans and Europeans, including 14,000 French
Religion: 55% to 75% Christian, less than 1% Muslim, remainder animist
Language: French official language and medium of instruction in schools; Fang
is a major vernacular language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are wage earners in the modern sector
Organized labor: less than 30% of wage labor force','ed359ec48b26f0e10d40302c76c359c26adc7ecfc259635cda4f9cc392dbb147','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d0e5d149fa5eb41a97b3ebf387c1048c1cc45f890cbc3652fec7d23267687b7',1973,'GM','Gambia','people-and-society',151,'Population: 392,000, average annual growth rate 2.2%
(7/66-7/71)
Ethnic divisions: over 99% Africans (Malinke 40.8%, Fulani 13.5%, Wolof 12.9%,
remainder made up of several smaller groups), fewer than 1% Europeans and
Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Malinke and Wolof most widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in subsistence farming; about
15,000 are wagg earners (government, trade, services)
Organized labor: 25% to 30% of wage labor force at most','b22239251df371b83f2e41f32f3d8b5478935dc8fc517fca72ff6a24ae24839a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fc09c13f8ace6d6e602f507a69337e831019f8e68fe0a6666b1f4e1c40f2564',1973,'GH','Ghana','people-and-society',155,'Population: 9,348,000, average annual growth rate 2.7%
(3/70-7/71)
Ethnic divisions: 99.8% Negroid African (major tribes
Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 42.8% Christian, 12% Muslim
Language: English official; African languages include Akan 442, Mole-Dagbani 162,
Ewe 13%, and Ga-Adangbe 8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing, 16.8% industry, 15.2%
sales and clerical, 4.1% services, transportation, and communications,
2.9% professional; 400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor force','03e59e8e8a243719722710a9559f65754f3cb4f395a669aca0189d1c8f9e0a76','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ab0bdac4f89002743093cb5899a773383997c1c261d4d122c1258ad7fac35a6',1973,'GR','Greece','people-and-society',159,'Population: 8,930,000, average annual growth rate 0.4%
(3/61-3/71)
Ethnic divisions: 96% Greek, 2% Turkish, 1% Albanian, 1% other
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total about 82%
Labor force: 3,866,000 (1969 est.); 50% agriculture, 15% industry, 9% trade,
26% other; unemployment and underemployment, 20% total in all fields;
shortage of skilled labor in nonagricultural sectors aggravated by large-
scale emigration
Organized Tabor: 10% of labor force','735b28c8a6f1604b1747c539d6294d98514f2e3ce9f2f3d30024dbff38cd27d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39f23b0fa1f731f4663f587944aaab92b4f37615fa6cc1116b3ee73ded182675',1973,'GD','Grenada','people-and-society',166,'Population: 96,000, average annual growth rate 0.6%
(4/60-4/70)
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects; Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 25,170 (1960); 40% agriculture, 30% unemployed or underemployed
Organized labor: 33% of labor force','ea5c96616543723867025afbc8bf215411775bc7141b981843c1a8f133019b2b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e536578873d553555e9cd4bbba961409668558acc359d9bfb47b1b200c7d3f2',1973,'GT','Guatemala','people-and-society',174,'Population: 4,121,000, average annual growth rate 2.6%
(7/66-7/67)
Ethnic divisions: 99% African (3 major tribes - Fulani,
Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less than 1%
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written language
Labor force: 1.8 million, of which less than 10% are wage earners; most of
population engages in subsistence agriculture
Organized labor: virtually 100% of wage labor force loosely affiliated with the
National Confederation of Guinean Workers, which is closely tied to the PDG','c9e377e1f27a541580e04dce341de738c4fcca0a2c08db5b20649868eed53e32','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a406cc7b63bb834ae0514c7f69ab6da24f88b1c7297c4214942dc710ff2a2b6',1973,'GY','Guyana','people-and-society',176,'Population: 773,000, average annual growth rate 2.5%
(4/60-4/70)
Ethnic divisions: 51% East Indians, 43% Negro and Negro
mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1% other
Language: English
Literacy: 86%
Labor force: 175,000; about 25% agriculture, 14% manufacturing, 16% services,
11% commerce, 3% mining and quarrying, 10 other; 21% unemployed; shor tage
of technical and managerial personnel
Organized labor: 25% of labor force','cbc113a4b87f53b9df931c4563e76fcc0f52b6e9467cdb93342775c0e1a38573','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('849700519e08326693bf9eb38ce3a3d8a65db7c30591821b400340dd0d71a97a',1973,'HK','Hong Kong','people-and-society',182,'Population: 4,149,000, average annual growth rate 1.8%
(7/68-7/72)
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local religions
Language: Chinese, English
Literacy: 75%
Labor force (1969 est.): 1.52 million; 40% manufacturing, 28% services, 11%
construction, mining, quarrying and utilities, 11% commerce, 5% agriculture,
forestry, fisheries, and hunting, 6% communications, 2% other; under-
employment is a serious problem
Organized labor: 12% of 1969 labor force','b250aee3c472619c0dc30d944a4af5e1302c3b4f4f0ffa55b30b18cf067e7c33','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fa7f5a32ff5b687c514e448ab094d1f746920636be53f81644ad9eacb0c3ee1',1973,'HU','Hungary','people-and-society',186,'Population: 10,420,000, average annual growth rate 0.3% : . 4
(current) . mie
Ethnic divisions: 93.3% Magyar, 2.5% German, 2.4% Gypsy, i" es
0.7% Jews, 1.1% other SS evs coreg yee ti,
Religion: 67.5% Roman Catholic, 20% Calvinist, 5%
Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5.0 million (1 January 1971); 26% agriculture, 44% industry and
building, 30% other nonagricul tural','2194beefb5f341b2cc573bab3f1072feb89e80d7b6cf1f5a8acdd2c664ed5d36','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2103f1cda3811145a78636d4d2928047a5d2e2aa1306a4361bfe0fc613224b33',1973,'IN','India','people-and-society',190,'Population: 578,034,000 (including the Indian-held part of disputed Jammu-Kashmir,
and excluding the several million refugees who entered India from East Pakistan
during 1971), average annual growth rate 2.5% (7/70-7/71)
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.6% Christian, .7% Buddhist,
.7% other
Language: 24 languages spoken by a million or more persons each; numerous
other languages and dialects, for the most part mutually unintelligible;
Hindi is the national language and primary tongue of 30% of the people;
English enjoys "associate" status but is the most important language for
national, political, and commercial communication; Hindustani, a popular
variant of Hindi/Urdu, is spoken widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29% (1971 census)
Labor force: about 184 million; 70% agriculture, more than 10% unemployed and
underemployed; shortage of skilled labor is significant and unemployment is
rising
Organized labor: about 2.5% of total labor force','8aca79f3f4276f4417ece456ff8261f73b4d8c262d6a089884b9f22271c12458','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a762b471c2c758bca314947ecde9feef88ecfff00fcdb54abd72178fa814c538',1973,'AU','Australia','people-and-society',194,'Population: 124,559,000 (including West Irian), average
annual growth rate 2.5% (current)
Ethnic divisions: 45% Javanese, 14% Sundanese, 7.5% Madurese, 7.5% Coastal Malays,
26% other
Religion: 90% Muslim, 4% Christian, 2% Buddhist, 2% Hindu, 2% other
Language: Indonesian (modified form of Malay) official; English, and Dutch
leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 41 million; 70% agriculture, 15% industry, 15% miscellaneous and
unemployed
Organized labor: 10% of labor force
Population: 31,272,000, average annual growth rate 3.0%
(1/71-1/72)
Ethnic divisions: 63% Ethnic Persians, 3% Kurds, 13% other Iranian, 18% Turkic,
3% Arab and other Semitic, 1% other
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2% Zoroastrians, Jews, Christians
and Baha''is
Language: Farsi (Persian), Turki, Kurdish, Arabic
Literacy: about 33% of those 10 years of age and older (1972 est.)
Labor force: 7.5 million; 47% agriculture, 53% industry, commerce and services;
shortage of skilled labor substantial
Organized labor: 1.1% of labor force
Population: 7,000 (official estimate for 30 June 1969)
Ethnic divisions: 2,921 Nauruans, 1,167 Chinese, 428
Europeans, 1,532 other Pacific Islanders
Religion: Christian (2/3 Protestant, 1/3 Catholic)
Language: Nauruan, a distinct Pacific Island tongue; English, the language of
school instruction, spoken and understood by nearly all
Literacy: nearly universal
GOV ERNMENT:
Legal name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se; government offices in Uaboe District
Political subdivisions: 14 districts
Branches: President elected from and by Parliament for an unfixed term; popularly
elected unicameral legislature, the Parliament; Cabinet to assist the
President, four members, appointed by President from Parliament members
Government leader: President Hammer De Roburt
Suffrage: universal adult
Elections: last held in January 1971
Political parties and leaders: there are no political parties; De Roburt is only
significant political figure
Member of: no present plans to join U.N.; enjoys "special membership" in
Commonwealth; South Pacific Commission, INTERPOL, ECAFE
Population: 112,000, average annual growth rate 2.6%
(5/63-3/69)
Ethnic divisions: Melanesian-Polynesian admixture, over
28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese laborers were imported for
plantations and mines in pre-World War IT period; immigrant labor now
coming from Wallis Islands, New Hebrides, and French Polynesia
Organized labor: unorganized
Population: 637,000, average annual growth rate 1.7%
(12/60-12/70)
Ethnic divisions: 95% indigenous Timorese belonging to
the Malay racial group; 9 ethnic divisions, each
speaking a distinct dialect of Malay structure;
approx. 4,600 Chinese and 10,000 hal fcastes
Religion: 17% Christian (almost equally divided between Catholic and
Protestant), remainder practice animism ''
Language: an estimated 9-15 dialects, of Malay origin but mutually unintelligible;
75% of the population speaks the Tetum dialect
Literacy: rate of literacy is unknown, but is very low; educational system being
expanded under first Five Year Development Plan; by 1967 total school
enroliment was 25,000 out of total school-age population of 80,000; 5% of
natives can speak Portuguese
Labor force: 90% engaged in primitive village subsistence economy, 10% engaged
as town laborers and domestics','2311e45d503786e045685690f8b62c09840d660d815f596c0d057bfc84559363','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('882ce573d14afd82b9fc848c1fd179c07b9dd97c1719b9614f6bd5aa556ab681',1973,'IQ','Iraq','people-and-society',199,'Population: 10,306,000, average annual growth rate 3.3%
(10/70-10/71)
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7% Assyrians, 2.4% Turkomans,
7.7% other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry, 6.7% government,
16.8% other; rural underemployment high, but not sertous because low
subsistence levels make it easy to care for unemployed; severe shortage
of technically trained personnel
Organized labor: 11% of labor force','3d24ad450689e42803a12496f3cfa9fd1fea8199dc766cd2fc335dbfc28434dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a4cb399cf22f51c2f781aa883d6d0d2d5f5ff11a5530918512b281293eda965',1973,'NL','Netherlands','people-and-society',204,'Population: 1,951,000, average annual growth rate 1.5%
(4/60-4/70)
Ethnic divisions: African 76.3%, Afro-European 15.1%,
Chinese and Afro-Chinese 1.2%, East Indian and
Afro-East Indian 3.4%, white 3.2%, other 0.9%
Religion: predominantly Protestant, some Roman Catholic, some spiritualist cults
Language: English
Literacy: Ministry of Education estimates between 43% and 57% of adult population
functionally literate
Labor force: about 687,000; 33% in agriculture, 1% forestry and fishing, 13%
manufacturing, 7% construction, 8% commerce, 2% transportation and communi-
cations, 13% services, 23% unaccounted for; 16% to 20% (est.) unemployed
(seasonal unemployment in agriculture can push the unemployment figure to
25%); shortage of technical and managerial personnel
Organized Tabor: about 25% of labor force (1966)','4f0b3095085e23873123e60ee178283d99b1894df9185281f501dde1da12b75b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb31100a5cc04f0bbaf237be37d07ba10e82b680686320fd3c5e780386d8d93f',1973,'JO','Jordan','people-and-society',208,'Population: 2,504,000 (including West Bank and East Jerusalem), average annual
growth rate 3.1% (current)
Ethnic divisions: 98% Arab, 1% Circassian, 1% Armenian
Religion: 95% Sunni Muslim, 5% Christian
Language: Arabic official, English widely understood among upper and middle
classes
Literacy: about 40% in East Jordan; somewhat less than 50% in West Jordan
Labor force: 564,000; 33% unemployed
Organized labor: 5% of labor force','4cb5875912f937d11e3553ca757059d2a31facf83ac656a6eb9fe7f77aafc7ca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c973b43504d686b64790acbe3f082918656a9979482d113d1f7f9f50f6b13701',1973,'KE','Kenya','people-and-society',212,'Population: 12,476,000, average annual growth rate 3.4%
(7/71-7/72)
Ethnic divisions: 97% native African (including Bantu, Nilotic, Hamitic and
Nilo-Hamitic); 2% Asian; 1% European, Arab and others
Religion: 56% Christian, 36% animist, 7% Muslim, 1% Hindu
Language: English official; each tribe has own language
Literacy: 27%
Labor force: 2.5 million; about 977,000, (39%) in monetary economy (1967)
Organized labor: about 215,000
Population: 15,524,000, average annual growth rate 3.0%
(current)
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 47.7% agriculture, 52.3 non-agricultural; shortage of
skilled and unskitled labor
Population: 32,877,000, average annual growth rate 1.6%
(7/71-7/72)
Ethnic divisions: homogeneous; small Chinese minority
(approx. 20,000)
Religion: strong Confucian tradition; pervasive folk religion (Shamanism);
vigorous Christian minority (5.5% of population); Buddhism (including
estimated 20,000 members of Soka Gakkai); Chondokyo (religion of the heavenly
way), eclectic religion with nationalist overtones founded in 19th century,
claims about 1.5 million adherents
Language: Korean
Literacy: about 90%
Labor force: about 10.2 million (1971); 46.2% agriculture, fishing, forestry,
32.3% services, 14% mining and manufacturing, 3% construction, 4.5% unemployed
Organized labor: about 10% of nonagricultural labor force','854383524788cfa3138d36ee781ec4b5a556ea0240e9f8833bcf2953aefa5e71','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a32b423a7ac29bc088becee145ebd596fa1766deac2dbda1ff95cb9bb5ba6e4c',1973,'KW','Kuwait','people-and-society',216,'Population: 1,005,000, average annual growth rate 10.0%
(7/71-7/72)
Ethnic divisions: 87% Arabs, 12% Iranians, Indians, and Pakistani, 1% other
Religion: 95% Muslim, 5% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign language
Literacy: about 55% (1965)
Labor force: 250,000 (1969); 9% manufacturing, 16% construction, 45% services,
13% commerce
Organized labor: labor unions, first authorized in 1964, formed in oil industry
and among government personnel
Population: 3,181,000, average annual growth rate 2.4%
(7/71-7/72)
Ethnic divisions: 47% Lao; 14% Tai; 25% Phoutheng (Kha),
Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant foreign
language also used in administration
Literacy: about 12%
Labor force: about 1,268,000; 80%-90% agriculture; 159,286 engaged in
manufacturing and services; 11,864 government employees
Organized labor: only civil servants are organized','89504ff785e90eb2bec940c827fa26e305a23ba1d283ee22793797dd34c42516','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5483e57e3434557e5d48d4d181745dc7d6168d528f66b2be004c24d8d650fe92',1973,'LB','Lebanon','people-and-society',220,'Population: 3,055,000 (including Lebanese nationals living
outside the country who are on the population register,
but excluding registered Palestinian refugees numbering
182,000 on 31 December 1971), average annual growth rate 3.1% (current)
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1% other (official estimates);
Muslims believed to constitute slight majority
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically active; 49% agriculture, 11% industry,
14% commerce, 26% other; moderate unemployment
Organized labor: about 55,000','9a636ad123c96693541c9899c5add76a9ccb0c366faba79fb7e633e700a4ab04','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae4ce4620b68bc64001ffeab2ee9f449a39b90f982c02d04ae170b33b2cd447e',1973,'LS','Lesotho','people-and-society',224,'Population: 973,000, average annual growth rate 1.8%
(4/71 -4/72)
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800 Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in
subsistence agriculture; 150,000 to 250,000 spend 6 months to many years
as wage earners in South Africa
Organized labor: negligible
Population: 1,677,000, average annual growth rate 3.3%
(current)
Ethnic divisions: 5% coastal descendants of immigrant
Negroes; 95% indigenous Negroid African tribes including Gola, Kissi, Vai,
Kpelle, Kru, and Mandingo
Religion: probably more Muslims than Christians; 70%-80% animist
Language: English official; 28 tribal languages or dialects, pidgin English used
by about 20%
Literacy: about 24% over age 5
Labor force: 500,000, of which 150,000 are in modern economy; about 2,000 non-
African foreigners hold about 95% of the top level management and
engineering jobs
Organized labor: 2% of labor force','0e0eebb5c1da4a32b2e023e33af2c79e26f43f7e2b4e1a0a7a2552b029e176c2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49b1cd5c957cad7b3e04ff982553540ffbb9c58e35315905408fe73ff0ec8429',1973,'LY','Libya','people-and-society',228,'Population: 2,162,000, average annual growth rate 3.7%
(7/70-7/71)
Ethnic divisions: 97% Berber and Arab with some Negroid
stock; some Greeks, Maltese, Jews, Italians
Religion: 97% Muslim
Language: Arabic; Italian and English widely understood in major cities
Literacy: 35%
Labor force: 485,000; between ages 15-64, 405,000-430 ,000; 61% of labor force
in agriculture (1964)
Population: 20,906,000, average annual growth rate 1.1%
(current)
Ethnic divisions: 87% Romanian, 8% Hungarian, 2% German,
3% other
Religion: 14,000,000 Romanian Orthodox, 1,060,000 Roman Catholic, 1,000,000
Protestants, 100,000 Jews, 30,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.4 million (est. 1 July 1966); 57% agriculture, 19% industry,
24% other nonagricul tural
GOV ERNMENT:
Legal name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 39 counties and 46 municipalities, including Bucharest
Legal system: mixture of civil law system and Communist legal theory which
increasingly reflects Romanian traditions; constitution adopted 1965; legal
education at University of Bucharest and two other law schools; has not
accepted compulsory ICU jurisdiction
Branches: Council of Ministers; the Grand National Assembly, under which is
Office of Prosecutor General and Supreme Court; Council of State isa
collective head of state
Government leaders: Ion Gheorghe Maurer, President of the Council of Ministers,
head of government; Nicolae Ceausescu, President of Council of State,
titular head of state
Suffrage: universal over age 18, compulsory
Elections: elections in Romania held every 4 years for the local people''s
councils and every 5 years for Grand National Assembly deputies
Political parties and leaders: Communist Party of Romania only functioning party,
Nicolae Ceausescu, General Secretary ,
Voting strength (1969 election): overall participation reached 99.96%; of those
registered to vote (13,577,143), 99.75% voted for party candidates
Communists: 2,220,000 party members (April 1972)
Member of: CEMA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, Seabeds Committee, U.N.,
UNESCO, UPU, Warsaw Pact, WHO, WMO, GATT','709c1962a2c2ce53d48a5e7287e1b177c9328918bab811e5cc34a97f58c07768','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68806b0785723d40f6476bfd8d9fe67a5f39cc3d068bee3a44007b678efeb40d',1973,'LI','Liechtenstein','people-and-society',232,'Population: 23,000, average annual growth rate 2.5%
(12/60-12/70)
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly from
Austria and Italy); 59% industry, 20% trade and
commerce, 13% professional and other, 8% agriculture','e65f02c8df0c5defaeee06a8ccb7533caf0403e3ff826e2b6b7b69d056ac0795','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c82c1eed34663a24d816686d558f5b5aaccfae2a17ef27016a4761ca3edfe12',1973,'LU','Luxembourg','people-and-society',236,'Population: 346,000, average annual growth rate 0.5%
(7/65-7/71)
Ethnic divisions: 83% Luxembourger, including an estimated
5% of Italian descent; remainder French, German,
Belgian, etc.
Religion: 97% Roman Catholic, remaining 3% Protestant
and Jewish
Language: Luxembourgish, German, French; most educated Luxembourgers also speak
English
Literacy: 98%
Labor force: (1970) 144,000; 11% agriculture (including forestry and fishing),
47% industry, 42% services, no significant unemployment; 30% of labor force
is foreign, comprising workers from neighboring areas of Belgium, France,
and West Germany, as well as Italy and Portugal
Organized labor: 45% of labor force','9ca236c965f42acb72079800b13369b250f6cc1f5bd2c7e0b37057ba7c7bfff9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae45d76263b2907fdb9a5257e29fafa8c5d6156cb68d660f2e096e4e4abf70da',1973,'MO','Macao','people-and-society',240,'Oa 249,000 (official estimate for 15 December
1970
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about one-half are Chinese
Language: Chinese 98%, Portuguese 2%
Literacy: almost 100% among Portuguese and Macanese; no data on Chinese
population
Labor force: 5% agriculture, 30% manufacturing, 3% construction, 1% utilities,
27% commerce, 8% transportation and communications, 26% services (1960 data)','efcc21c0133e047007bd3734f5df2758bcfe3c06d37b1c3c2300ae8dcc43e657','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e7f572ebb657024628faa6c705356c1be7ec2d7dd7275967da1dcfd8044c787',1973,'MG','Madagascar','people-and-society',244,'Population: 7,221,000, average annual growth rate 2.3%
(7/69-7/70)
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting
of Merina (1,643,000) and related Betsileo (760,000), on the one hand, and
coastal tribes with mixed Negroid, Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include Betsimisaraka 941,000, Tsimihety 442,000,
Sakalava 375,000, Antaisaka 415,000; there are also 38,000 French, 66,000
other
Religion: more than half animist; about 41% Christian, 7% Mus 1im
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are nonsalaried family workers
engaged in subsistence agriculture; of 175,000 wage and salary earners,
26% agriculture, 17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscellaneous
Organized labor: 4% of labor force','0d353efd1e625433002ba07cf9b5526f78bd19fd33ed0ef19e0b9196a10220e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f473e05e57fcdd9606e33e9524c5907f240113d9d15a5237fd8fed21bb5e24ff',1973,'MW','Malawi','people-and-society',248,'Population: 4,786,000, average annual growth rate 2.6%
(7/71-7/72)
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is second
African language
Literacy: 6% of population over 21 years old
Labor force: 180,000 wage earners employed in Malawi (1971); 6,000 Europeans
permanently employed; 300,000 Malawians live and work in Rhodesia, South
Africa, and Zambia; 30% agriculture, 11% construction, 10% commerce, 13%
manufacturing, 10% administration, 26% miscellaneous services
Organized labor: small minority of wage earners are unionized','c679471c00ec8c46f21870b8506ccc264d4fd2723e706c2cfaf64123691ff99f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f98f125206b69da1d75fe5dda0f1b5f7d33267a8b28b5a08c5d78e0b96006904',1973,'MY','Malaysia','people-and-society',252,'Population: 11,250,000 average annual growth rate 2.7% (current)
West Malaysia: 9,468,000, average annual growth rate 2.6% (6/57-8/70)
Sabah: 728,000, average annual growth rate 3.7% (8/60-8/70)
Sarawak: 1,054,000, average annual growth rate 2.7% (6/60-8/70)
Ethnic divisions:
Malaysia: 44% Malay, 36% Chinese, 8% tribal, 10% Indian and Pakistani,
2% other
West Malaysia: 50.1% Malay, 36.9% Chinese, 11% Indian and Pakistani,
2% other
Sabah: 23.1% Chinese, 67.3% indigenous tribes, 9.6% other
Sarawak: 31.5% Chinese, 50% indigenous tribes, 17.5% Malay, 1% other
Religion:
West Malaysia: Malays nearly all Muslim, Chinese predominantly Buddhists,
Indians predominantly Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist, 16% Christian, 35%
tribal religion, 2% other
Language:
West Malaysia: Malay (official); English, Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dialects, Mandarin and Hakka dialects
predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal languages
Literacy:
West Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 3.45 million (1967)
West Malaysia: 2.9 million; 55% agriculture, forestry, and fishing, 11%
manufacturing and construction, 34% trade, transport, and services
Sabah: 213,000 (1967); 80% agriculture, forestry, and fishing, 6% manu-
facturing and construction, 13% trade and transportation, 1% other
203
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
PEOPLE (cont''d):
Sarawak: 341,000 (1967); 80% agriculture, forestry, and fishing, 6% manu-
facturing and construction, 13% trade, transportation, and services,
1% other
Organized labor: 370,000 (official 1967 est.) about 10.5% of total labor force;
28% of wage labor force; unemployment about 8% of total
labor force, but higher in urban areas
GOV ERNMENT:
Legal name: Malaysia
Type:
Malaysia: constitutional monarchy nominally headed by Paramount Ruler (King);
a bicameral Parliament consisting of a 58-member Senate and a 144-member
House of Representatives
West Malaysian states: hereditary rulers in all but Penang and Malacca where
Governors appointed by Malaysian Government; powers of state governments
limited by federal constitution
Sabah: self-governing state within Malaysia in which it holds 16 seats in
House of Representatives; foreign affairs, defense, internal security,
and other powers delegated to federal government
Sarawak: self-governing state within Malaysia in which it holds 24 seats in
House of Representatives; foreign affairs, defense, and internal security,
and other powers are delegated to federal government
Capital:
West Malaysia: Kuala Lumpur
Sabah: Kota Kinabalu (formerly Jesselton)
Sarawak: Kuching
Political subdivisions: 13 states (including Sabah and Sarawak)
Legal system: based on English common law; constitution came into force 1963;
judicial review of legislative acts in the Supreme Court at request of
Supreme Head of the Federation; has not accepted compulsory ICJ jurisdiction
Branches: 9 state rulers alternate as Paramount Ruler for 5-year terms; locus of
executive power vested in Prime Minister and cabinet, who are responsible
to bicameral parliament; following communal rioting in May 1969, govern-
ment imposed state of emergency and suspended constitutional rights of all
parliamentary bodies; parliamentary democracy resumed in February 1971
West Malaysia: executive branches of 11 states vary in detail but are similar
in design; a Chief Minister, appointed by hereditary ruler or Governor,
heads an executive council (cabinet) which is responsible to an elected,
unicameral legislature
Sarawak and Sabah: executive branch headed by Governor appointed by central
government, largely ceremonial role; executive power exercised by Chief
Minister who heads parliamentary cabinet responsible to unicameral
legislature; judiciary part of Malaysian judicial system
Government leader: Head of State, Tun Abdul Razak
Suffrage: universal over age 20
Elections: minimum of every 5 years, last elections 1969
Political parties and leaders:
West Malaysia: Alliance Party consisting of United Malays National Organiza-
tion (UMNO), Tun Abdul Razak; Malaysian Chinese Association (MCA), Tan
Siew Sin; and Malaysian Indian Congress (MIC), V.T. Sambanthan; major
opposition parties -- Pan Malayan Islamic Party (PMIP), Dato Asri bin Haji
204
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GOVERNMENT (cont''d):
Political parties and leaders (cont''d):
West Malaysia (cont''d):
Muda (acting); Democratic Action Party (DAP); Gerakan Rakyat Malaysia (GRM);
minor opposition parties -- Party Rakyat (PR), People''s Progressive Party
(PPP), Labor Party of Malaya (LPM) Partai Keadilan Masharakyat (KEMAS),
United Malaysian Chinese Organization (UMCO); Communist Party illegal
Sabah: United Sabah National Organization (USNO), Tun Mustapha bin Dato
Harun; Sabah Chinese Association (SCA), Khoo Siak Chiew; no organized
opposition
Sarawak: coalition composed of Sarawak Alliance and Sarawak United Peoples
Party (SUPP), Ong Kee Huis Opposition Sarawak National Party (SNAP), Stephen
Ningkan
Voting strength:
West Malaysia: (1969 election) Alliance Party controls 9 of 11 state
legislatures, won estimated 49% of total vote; Pan-Malaysian Islamic
Party polled 24%; Democratic Action Party polled 12%; Gerakan 7%
Sabah: (October 1971 Assembly Elections) Alliance unopposed, opposition
candidates disqualified
Sarawak: (1970 elections) Alliance 24 seats, SNAP 12 seats, SUPP 11 seats;
SUPP has joined the Alliance to form a coalition state government
Communists:
West Malaysia: approx. 1,500 armed insurgents on Thailand side of Thai/
Malaysia border; approx. 300 on Malaysian side
Sarawak: 960 armed insurgents in Sarawak; armed element of SCO in Indonesian
West Borneo estimated at 300
Sabah: insignificant
Member of: ADB, ASEAN, ASPAC, Commonwealth, FAO, GATT, IAEA, IBRD, ICAO, IFC,
ILO, IMF, ITU, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','1ece4d31bdd00316a6df38cdd5ecfdf0698d085dac835902f62e1393935d3cca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b29b62de1638752849dd5bb2e78cad6139160f18dacadf6e2129ec16fe99d934',1973,'MV','Maldives','people-and-society',255,'Population: 115,000, average annual growth rate 2% (current)
Ethnic divisions: admixtures of Sinhalese, Dravidian, Arab and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the male population
Population: 5,374,000, average annual growth rate 2.2%
(7/71-7/72)
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African languages,
of which Mande group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried, 50,000 of whom are employed by the
government; most of population engaged in agriculture and animal husbandry
Organized labor: UNTM, which claimed all eligible employees, dissolved; thirteen
national unions currently directed by a government controlled Coordination
Committee of Mali Trade Unions (CCSM)','dfe257762c4bf97230d9d2a643566555a6223e646c152ad8b7dac058fb3af440','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57573413d8f2be5e46e6e9a567425f14fe0caa25dbbbc991eb5381f09e787962',1973,'CN','China','people-and-society',260,'es 319,000 (official estimate for 30 September
1972
Ethnic divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in 1946
Labor force: 111,000; 33% services, 20% government, 21% manufacturing, 7%
agriculture, 6% unemployed
Organized labor: approximately 35% of labor force','d715dba60b8c91f00fc69bb2175343286a386ba40c88a006a4ef1084ae4afb7a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de3a981c344c33b6a4813b93a8550d1879bf5e4e2a446d683ecb22d70290d131',1973,'MR','Mauritania','people-and-society',263,'Population: 1,157,000, average annual growth rate 1.1%
(7/66-7/70)
Ethnic divisions: 70% Moor, 30% Negro
Religion: nearly 100% Muslim
Language: French and Arabic official
Literacy: under 5%
Labor force: about 18,000 wage earners (1973); remainder of population in
farming and herding
Organized labor: 18,000 union members claimed by single union, Mauritanian
Workers'' Union','493ebb4c85564f394641a88ddf66e9997da4dbcb66c9d24d1800981c47b985ab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f843f3ac2b9e3c4e55eddafba036c3e8f4423f2591d82cf1ea04fd2a22164ae',1973,'MU','Mauritius','people-and-society',267,'Population: 871,000, average annual growth rate 1.4%
(7/70-7/71)
Ethnic divisions: Indians 67%, Creoles 29%, Chinese 3.5%, English and French 0.5%
Religion: 51% Hindu, 33% Christian (mostly Catholic with a few Anglican
Protestants), 16% Muslim
Language: English official language; Hindi, Chinese, French Creole
Literacy: estimated 60% for those over 21, and 90% for those of school age
Labor force: 120,000; 65% agriculture, 5% industry; 30% are unemployed, under-
employed, or self-employed
Organized labor: about 10% of labor force
Population: 23,000 (official estimate for 3] December 1971)
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
Literacy: almost complete
Labor force: not available
Organized labor: not available
Population: 1,359,000, average annual growth rate 2.9%
(current) :
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese, 2% | AUSTRALIA
Russian, 2% other
Religion: predominantly Tibetan Buddhist, about 4% Muslim,
limited religious activity because of Communist regime
Languages: Khalkha Mongol used by over 90% of population; minor languages
include Turkic, Russian, and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the population is in the labor
force, including a large percentage of Mongolian women; acute shortage of
both skilled and unskilled labor (no reliable information available)','7282aa4bf279bc233f26b8e306e5bd0b782aceaf72790e1e4ad6db0f04089bf1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2930e14445a9201524c0303675340cbc0bc7ddcaa40f9984e5d77a9dc613d1a8',1973,'MA','Morocco','people-and-society',271,'Population: 16,259,000, average annual growth rate 2.9%
(current)
Ethnic divisions: 99.1% Arab-Berber, .2% Jewish, .7% non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2% Jewish
Language: Arabic (official); several Berber dialects; French is language of much
business, government, diplomacy, and postprimary education
Literacy: 20%
Labor force: almost 5.9 million (1970 est.) 69% agriculture, military, police,
civil service, transportation, mines, teachers, merchants, construction
workers, 10% industry and mining, 10% commerce and government
Organized labor: about 5% of the labor force, mainly in the Union of Moroccan
Workers (UMT)','aed3083d15a1aa610108108126d7474f78b87ecac4b3482655d5b1d310533091','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01e652436734225139ae255bf698f63411b33f5697561b0fecdc2b2a910e3209',1973,'MZ','Mozambique','people-and-society',275,'Population: 8,698,000, average annual growth rate 2.2%
(9/60-12/70)
Ethnic divisions: 97% African, 3% European, Asian, and Mulatto
Religion: 65.6% animist, 21.5% Christian, 10.5% Muslim, 2.4% other
Language: Portuguese (official); many tribal dialects
Literacy: 7%-10% (est.)
Labor force: (1963 est.) 610,000; 50,000 non-African wage earners, 560,000
African wage earners in Mozambique; 290,000 additional African wage earners
temporarily working in Rhodesia and South Africa; unemployment serious
problem; most native Africans provide unskilled labor or remain in
subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970); 75% are white
GOV ERNMENT:
Legal name: State of Mozambique
Type: overseas state of Portugal
Capital: Lourenco Marques
Political subdivisions: 10 districts administered by district governors;
municipalities governed by appointed official
Legal system: based on Portuguese civil law system and customary law
Branches: Governor General appointed by Lisbon is chief executive officer for
internal administration; he also has certain legislative powers which he
exercises with Legislative Assembly; all action in state may be vetoed
by Minister of Overseas in Lisbon; judiciary is constitutionally independent
Government leader: Governor General Manuel Pimentel dos Santos
Suffrage: all adults able to read and write Portuguese and in full possession of
political and civil rights
Political parties and leaders: National Popular Action (ANP), formerly the
National Union (UN), state president Manuel Monteiro Ribeiro Veloso; no
legal opposition political parties
Communists: none known
Other political or pressure groups: the Mozambique Liberation Front (FRELIMO), led
by Moises Samora Machel, operates from Tanzania and Zambia; less significant
Mozambique Revolutionary Committee (COREMO), led by Paulo Gumane, based in','a6f3e8bbb596683a6a32973cd30b02b13f195b90592812764a772eb7120cc160','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffbe2c1aae18c87bcb6596d81f84c74f73a10363fa26ebc504f1b290ee555d32',1973,'NP','Nepal','people-and-society',280,'Population: 12,598,000, average annual, growth rate 2.5%
(6/61-6/71)
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%),
representing considerable intermixture of Indo-Aryan
and Mongolian racial strains; country divided among
many quasi-tribal communities
Religion: only official Hindu Kingdom in world, although no sharp distinction
between many Hindu and Buddhist groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided into numerous dialects;
Nepali official language and lingua franca for much of the country; same
script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5% industry; great lack of skilled
labor
GOV ERNMENT:
Legal name: Kingdom of Nepal
Type: constitutional monarchy; King Birendra exercises autocratic control over
multitiered panchayat system of government
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and English common law; legal
education at Nepal Law College in Kathmandu; has not accepted compulsory
IcJ jurisdiction
Branches: Council of Ministers appointed by the King; indirectly elected
National Panchayat (Assembly)
Government leader: King Birendra Bir Bikram Shah Deva; Prime Minister Kirti Nidhi
Bista
Suffrage: universal over age 21
Elections: village and town councils (panchayats) elected by universal suffrage;
district, zonal, and National Panchayat members indirectly elected, most
for 6-year terms; 15 National Panchayat members elected from five class
organizations (women, workers, youth, and ex-servicemen), four directly
elected by all voters possessing a B.A. or its equivalent, and 16 are
appointed by the King
Political parties and leaders: all political parties outlawed
Communists: the combined membership of the two wings of the Communist Party
of Nepal (CPN) may be on the order of 6,500, the majority (perhaps 5,000)
in the pro-Chinese wing; the CPN continues to operate more or less openly,
but internal dissension has greatly hindered its effectiveness
Other political or pressure groups: proscribed Nepali Congress Party led by
B.P. Koirala from exile in India
Member of: ADB, FAO, IBRD, ICAO, IDA, ILO, IMF, ITU, U.N., UNESCO, UPU, WHO','c5353357938b1b6b5de4dc6b9cb5ba225b9a28ad53f9f5549e4d91d4a3815675','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6568b6bd57a0d5bceead84df0456ac0205e33bcd036621e44b6457fed57fa07',1973,'NI','Nicaragua','people-and-society',284,'Population: 2,030,000, average annual growth rate 2.8%
(4/63-4/71)
Ethnic divisions: 75% mestizo, 15% white, 10% Negro, Indian or mulatto
Religion: 95% Roman Catholic
Language: Spanish (official); small English-speaking minority on Atlantic coast
Literacy: 50% of population 10 years of age and over
Labor force: 650,000 (est. 1972); 60% agriculture, 12% manufacturing, 14%
services, 14% other; shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: about 1.5% of labor force','d1f9aae218f881f7a211d3f9eeb08a5c5302cf485e618be56380028e8cb7f94d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a86349074fd947ca17cb019a0c231fb412089eb23df1768fe85bc82b3e3e98cf',1973,'NE','Niger','people-and-society',288,'Population: 4,363,000, average annual growth rate 2.8%
(7/71-7/72)
Ethnic divisions: main Negroid groups 75% (of which, Hausa
50%, Djerma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a
very few Christians
Language: French official, many African languages; Hausa used for trade
Literacy: about 5%
Labor force: 26,000 wage earners; bulk of population engaged in subsistence
agriculture and animal husbandry
Organized labor: negtigible','9383bee70e5fc97caabe3c2ffebde9066bc5f9f9216f0278d57b610eebdd20db','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e2bcd6ac4cd67d0dd6ac786ed4a9db08d84385b97b38e7f9bbf3d8c24e89910',1973,'NG','Nigeria','people-and-society',292,'Population: 59,607,000, average annual growth rate
2.8% (current)
Ethnic divisions: 250 tribal groups, of which most important are Hausa-Fulani
(north), Ibo and Yoruba (south); these 3 tribes total over 60% of population;
about 27,000 non-Africans
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25%
Language: English official; Hausa, Yoruba, and Ibo also widely used
Labor force: approx. 22.5 million; about 41% of total population; roughly
1.3 million wage earners, of whom 560,000 work in modern enterprises
Organized labor: about 530,000 wage earners, approx. 2.4% of total labor force,
belong to some 700 unions','8e13562d8446c9be2f5238c5b7f015bb254bad3f557ee8b22e4bc785884e20d5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('320c74340e1827a30434dfb51d11a05d17578278a670fb732c2276910ecda618',1973,'NO','Norway','people-and-society',296,'Population: 3,964,000, average annual growth rate 0.7% (current)
Ethnic divisions: homogeneous white population, small Lappish minority
pee Mae 96% Evangelical Lutheran, 4% other Protestant and Roman Catholic, 1%
other
Language: Norwegian, small Lapp and Finnish-speaking minorities
Literacy: 99%
Labor force: 1.6 million; 19.5% agriculture, forestry, fishing, 27.0% mining and
manufacturing, 9.5% construction, 13.3% commerce, 11.9% transportation and
communication, 17.7% services; 1.0% unemployed
Organized labor: 60% of labor force','493e1826b1ac74b7a07814233cba973af5b2cb31dab54ee653ff6e4be70c7167','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be4898640f5a7e1badf6c02a9522a1462a41728465291f5f61cfbb63c1dd9a7d',1973,'OM','Oman','people-and-society',300,'Population: 470,000, average annual growth rate 2.9%
(current)
Ethnic divisions: almost entirely Arab with small groups
of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low
GOV ERNMENT:
Legal name: Sultanate of Oman
Type: absolute monarchy; nominally independent but under strong U.K. influence
Capital: Muscat
Legal system: based on English common law and Islamic law; no constitution;
ultimate appeal to the Sultan; has not accepted compulsory I¢J jurisdiction
Government leader: Sultan Qabus ibn Sa''id Al Bu Sa''id
Other political or pressure groups: none
Member of: Arab League, U.N.','53981e731b01c08a1d5ec53931f16ba8863a8790c59dcdad0d8f48e73581a97d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d08064014ab21977d036f062d79e15b3cb2b1cce6b19207739aed3579383fb9b',1973,'PK','Pakistan','people-and-society',303,'Population: 57,384,000 (excluding Junagardh, Manavadar,
Gilgit, Baltistan, and the disputed area of Jammu-Kashmir), average annual
growth rate 2.4% (7/69-7/70)
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages -- 7% Urdu, 64% Punjabi, 12%
Sindhi, 8% Pushtu, 9% other; English is lingua franca
Literacy: about 14%
Labor force: 12.7 million (est. 1961); 60% agriculture, 16% industry, 7% commerce,
15% service, 2% unemployed
Organized labor: 5% of labor force','7eeff9591020ca017a31b0c836fb35fe83a2fe48991e1b6136d69b96a73369f5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0a0a2b9ee78f3837e1c2011d332c016cea49053e6b7448ef3c378267051e1a2',1973,'PG','Papua New Guinea','people-and-society',308,'Population: 2,659,000, average annual growth rate 2.7%
(7/66-7/71)
Ethnic divisions: predominantly Melanesian and Papuan, some Negrito, Micronesian,
and Polynesian types
Religion: over one-half of population nominally Christian (490,000 Catholic,
320,000 Lutheran, other Protestant sects); remainder animist
Language: 700 indigenous languages; pidgin English and 2 or 3 native languages
are linguae francae for over one-half of population; English spoken by
1% to 2% of population
Literacy: 1%; in English, 0.1%
Labor force: no available figures; mostly subsistence farmers','90d44d22ab3ccedad13c0328e957a5732be47f02463b28afdebf1c52eecbd865','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d822a6a3b09e4a91906d82c667bcf62005bae709ccc84ff4bd9646d59fba80f5',1973,'PL','Poland','people-and-society',312,'Population: 33,299,000, average annual growth rate 0.9%
(current)
Ethnic divisions: 98.7% Polish, .6% Ukrainians, .5% Belorussians, less than
.05% Jews, .2% other
Religion: 95% Roman Catholic (about 75% practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26% industry, 36% other nonagricul tural*','54d7d4923e3afaa41a32cc468c1f45fd5a0bc73eb00c0287833f962eebbcbba5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1e2517614a29182a68061ec8ad05e63540a8c3ad3b040f31f0aa1d782c9a424',1973,'PT','Portugal','people-and-society',316,'Population: metropolitan Portugal 8,870,000,.average annual growth rate 0%
(current); Cape Verde Islands 250,300 (1969)
Ethnic divisions: homogeneous Mediterranean stock in mainland, Azores, Madeira
Islands; smal], but growing number of black workers principally from the
Cape Verde Islands
Religion: 97% Roman Catholic, 1% Protestant sects, 2% other
Language: Portuguese
Literacy: 65% (a figure considered very high by some sources)
Labor force: 3.3 million (1970); 32% agriculture, 34% industry, 34% services;
unemployment virtually nil, but some underemployment widespread
Organized labor: 33.4% of labor force in syndicates subject to varying degrees
of government control
Population: 490,000, average annual growth rate 0.2%
(7/68-7/69)
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes); less than 1%
European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese official, numerous African languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in subsistence agricul ture','9ae6870577c0d9f7916560311a365f46480fa253961762678b24568812c074af','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f21bb06d71f8b7a7096998252d06f3cce02ce11cfb48b3b0104bab40457b3a4',1973,'QA','Qatar','people-and-society',321,'Population: 150,000, average annual growth rate 10.8%
(7/64-7/69)
Ethnic divisions: 56% Arab; 23% Iranian; 14% Pakistani;
7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: 48,000 (1969)
Population: 476,000, average annual growth rate 2.2%
(7/69-7/72)
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal unemployment
Population: 5,887,000, average annual growth rate 3.5%
(7/71-7/72)
Ethnic divisions: 96% African, 3% European, less than
1% Coloreds and Asians
Religion: 51% syncretic (part Christian, part animist),
24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and Sindebele also widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including some migrants from Zambia and
Malawi), 108,000 Europeans, Asians, and coloreds (people of mixed heritage);
35% agricul ture, 25% mining, manufacturing, construction, 40% transport and
services
Organized labor: about one-third of European wage earners are unionized, but
only a small minority of Africans (1966)','279ac5359382e4928ff70daac1fb8c89a950f87a68ab77a015cf7eec535d0078','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('164eee85e4bbf651965a46bd1a9736642c2ef31d0ecb73427eed6d1748a3d592',1973,'RW','Rwanda','people-and-society',325,'Population: 4,064,000, average annual growth rate 3.1%
(7/64-7/67)
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa (Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French official; Kiswahili
language of African commerce, Kinyarwanda language
of interior and used in National Assembly
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy
GOV ERNMENT:
Legal name: Republic of Rwanda
Type: republic, formerly combined with Burundi in U.N. trusteeship under Belgium;
became separate independent country in July 1962
Capital: Kigali
Political subdivisions: 10 prefectures, subdivided into 141 communes
Legal system: based on German and Belgian civil law systems and customary law;
constitution adopted 1962; judicial review of legislative acts in the
Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: executive consists of President, popularly elected for 4-year term,
and 14 cabinet ministers; single house 47-member National Assembly, popularly
elected for 4-year terms; 6-member Supreme Court appointed by President
Government leader: President Gregoire Kay ibanda
Suffrage: universal and compulsory over age 18
Elections: last legislative election September 1969; president reelected September
1969; both elected for 4-year terms
Political parties and leaders: Party of the Hutu Emancipation Movement
(PARMEHUTU), led by President Gregoire Kayibanda, dominates at all levels
Communists: no communist party; U.S.S.R. and People''s Republic of China have
diplomatic missions in Rwanda
Member of AFDB, EAMA, IBRD, ICAO, ILO, IMF, ITU, OCAM, OAU, U.N., UNESCO, WHO,
WMO
Population: 67,000, average annual growth rate 1.2%
(4/60-4/70)
Ethnic divisions: mainly of African Negro descent
Religion: Church of England, other Protestant sects,
Roman Catholic
Language: English
Literacy: about 80%
Labor force: not available
Organized labor: 6,700','4aef92d2325b4110800d5d0dbf193eb5b20547d5072d66f8464538808280324d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aca4c3071670d565e5cd187f00ca42eabe4b788039bc181429cabf7a1e579512',1973,'SM','San Marino','people-and-society',328,'Population: 18,000 (official estimate for 30 June 1971)
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of
Sanmarinese Workers (affiliated with ICFTU) has about
1,800 members; Communist-dominated Camera del Lavoro, about 1,000 members','4c45fbfc826cbae02d536358fd1b440575a874e914c6e07ef4dfaab76f438ce8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5008e1ec4bdcf62a01b64d7b020834fbb9e5353e53687f3bc59e24a52a90d4fd',1973,'SA','Saudi Arabia','people-and-society',332,'Population: 5,766,000, average annual growth rate 2.8%
(current
Ethnic divisions: 90% Arab, 10% Afro-Asian (est.)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 25% of population; 40% agriculture and herding, 12%
construction, 12% service, 12% government, 11% commerce
Population: 20,940,000, average annual growth rate 1.0%
(current)
Ethnic divisions: 39% Serb, 22.1% Croat, 9.2% Slovene, 5.8% Macedonian, 2.5%
Montenegrin, 6.4% Albanian, 3% Hungarian, 9% other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic, 12% Muslim, 3% other, 12%
none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Albanian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 13.5 million (1970); 49.6% agricul ture, 16% mining and manufacturing,
34.4% other nonagricul tural activities; reported unemployment averaged 8%
of registered labor force (social sector) in 1967
Population: 23,535,000, average annual growth rate 3.0%
(7/70-7/72)
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes -- Mongo, Luba, Kongo (all Bantu),
and the Mangbetu-Azande (Hamitic) make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo, and Chiluba are all
classified as official languages
Literacy: 5% fluent in French, about 35% have an acquaintance with French
Labor force: about 8 million, but only about 13% in wage structure','c2ad00639e7a03b7fc14007b499f35a7d5b83fcd5c1067c9f73872c7600acfe0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5047f52aba1d18dce31d101a36fd16ab82f2dd23330b78ca5373cd0f09ab660a',1973,'SN','Senegal','people-and-society',336,'Population: 4,122,000, average annual growth rate 2.2%
(7/67-7/69)
Ethnic divisions: 36% Wolof, 17.5% Fulani, 16.5% Serer, 9% Tukulor, 9% Dyola,
6.5% Malinke, 4.5% other African, 1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly Roman Catholic)
Language: French official, but regular use limited to literate minority; most
Senegalese speak own tribal language; use of Wolof vernacular spreading --
now spoken to some degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence agricul tural workers; about 125,000
wage earners
Organized labor: majority of wage-labor force represented by unions; however,
dues-paying membership very limited','19f96ae0996140aa62e62aa4970abcdc0851f2fa54685e329656a365279a9780','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88c5abd899d794a01a80a149ba2a29c6a7306354ae370b03cf63b73f090eb90f',1973,'SC','Seychelles','people-and-society',340,'Population: 55,000, average annual growth rate 2.0%
(7/69-7/70)
Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans)
Religion: 90% Roman Catholic
Language: English official; Creole most widely spoken
Literacy: limited
Labor force: 22,000 agricul ture
Organized labor: 3 major trade unions
Population: 2,666,000, average annual growth rate 1.5%
(7/70-7/71)
Ethnic divisions: over 99% native African, rest European and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to literate minority;
principal vernaculars are Mende in south and Temne in north; "Krio," a
form of pidgin English, is also widely spoken
Literacy: about 10%
Labor force: about 1.5 million; most of population engages in subsistence
agriculture; only small minority, some 70,000, earn wages
Organized labor: 35% of wage earners
Population: 216,000, average annual growth rate 2.3%
(3/61-4/71)
Ethnic divisions: 75% Nepalese; 25% Bhotias, Lepchas, and
a few tribal groups
Religion: Tibetan or Lamaist Buddhism (the state religion)
33.3%; Nepalese majority are primarily Hindu
Language: English, official; Nepali, lingua franca; Bhotias
and Lepchas speak Tibeto-Burman dialects
Literacy: probably less than 15%
Labor force: predominantly agricultural; minimal skilled
labor','b37a50521d00a13b8a69d09a12672282b008b41d59c883c90227ef6e7cb4583a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83806d74aedfe24e84b3b4f2794be9073859001626cc26b395c1cfa3f9c3e0de',1973,'SG','Singapore','people-and-society',344,'Population: 2,185,000, average annual growth rate 1.8%
(7/71-7/72)
Ethnic divisions: 76.2% Chinese, 15% Malay, 7% Indians
and Pakistani, 3% other
Religion: majority of Chinese are Buddhists or atheists; Malays nearly all Muslim;
minorities include Christians, Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay, Tamil, and English are
official languages
Literacy: 70% (1970)
Labor force: 474,718; 0.5% agriculture, forestry, and fishing, 0.4% mining and
quarrying, 32.2% manufacturing, 30.4% services, 5.2% construction, 21.5%
commerce, 9.8% transport, storage, and communications; 6% other
Organized labor: 24% of labor force
Population: 3,010,000, average annual growth rate 2.3%
(7/65-7/72)
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000 Arabs, 3,000 Europeans,
800 Asians
Religion: almost entirely Mus] im
canguage: Somali (written form being developed by government); Arabic, Italian,
English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled laborers; 70% pastoral
nomads, 30% agriculturists, government employees, traders, fishermen,
handicraftsmen, other
Organized labor: law providing for government-controlled labor union promul gated
in June 1971, but union so far not establistied','4f8a0fd74040cb321a35f7c11982f46769a675f220982ce492c7bf6a1e82b543','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3741aaa773ab2e39620f8020b01a040bf09bb5d37338ed8d25112d19062f49e3',1973,'ZA','South Africa','people-and-society',348,'Population: 23,638,000, average annual growth rate 3.2%
(7/66-7/70)
Ethnic divisions: 17.8% white, 69.9% African, 9.4% Colored, 2.9% Asian
Religion: primarily Christian except Asian and African; 60% of Africans are
animists
Language: Afrikaans and English official, Africans have many vernacular languages
Literacy: almost all white population literate; government estimates 35% of
Africans literate
Labor force: 8.7 million (total of economically active, 1970); 53% agriculture,
8% manufacturing, 7% mining, 5% commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is unionized (mostly white
workers); nonwhites have no bargaining power
Population: 795,000, average annual growth rate 1.9%
(7/60-7/65)
Ethnic divisions: 14% white, 81% Africans, 5% Coloured
(mulattoes); almost half the Africans belong to Ovambo
tribe; Damara tribe has almost 45,000 members; Herero, Okavango, Nama tribes
have about 30,000 members each
Religion: whites predominantly Christian, nonwhites either animist or Christian
Language: Afrikaans principal language of about 70% of white population, German
of 22%, and English of 8%; several African languages
Literacy: high for white population; low for nonwhite
Labor force: 75,000 African wage earners (1964 est.); 68% agriculture, 15%
railroads, 13% mining, 4% fishing
Organized labor: no trade unions, although some white wage earners belong to
South African unions','fe854e3be1ef2507d69cd17ac0e458678456ebb206dae3e46dfa1862f014dccd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb88c279991578644b634c4ab2bb13e38a01b1f9e8d90fd5df98bc1f967fd183',1973,'SD','Sudan','people-and-society',353,'Population: 16,901,000, average annual growth rate 2.5%
(7/71-7/72)
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23% pagan, 4% Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects of Nilotic, Nilo-Hamitic,
and Sudanic languages, English; program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15% industry, commerce, services,
etc.; labor shortages exist for almost all categories of employment
Population: 447,000, average annual growth rate 3.5%
(7/64-7/70)
Ethnic divisions: 35.5% Creole (Negro and mixed), 34.7% Hindustani (East Indian),
14.9% Javanese, 8.5% Bush Negro, 2.2% Amerindian, 1.6% Chinese, 1.3% Europeans,
1.3% other and unknown
Religion: Muslim, Hindu, Moravian, Roman Catholic, other -- in order of size
(% figures unknown)
Language: Dutch official; English widely spoken; Taki-Taki (Surinam Creole)
is native language of Creoles and Tingua franca; Hindi; Japanese
Literacy: 70% to 75%
Labor force: 80,190 (1964); 24.9% agriculture, 6.9% mining, 10% industry, 2.8%
building trades, 13.5% trade and transport, 6.7% services, 22.2% government
employees, 13% other
Organized labor: approx. 10% of labor force
Population: 460,000, average annual growth rate 3.1%
(current)
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence agriculture; 55-60,000
wage earners, many only intermittently, with 31% agriculture, 11% government ,
11% manufacturing, 12% mining and forestry, 35% other (1968 est.); 7,900
employed in South African mines (1969)
Organized labor: about 15% of wage earners are unionized','96da3416cba675b02c5142d47d5262db742e82397dc6af9596c95993a46b7b84','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8db0d36e0210a58539426c3bccd8d21089af1ceffa95ef83c345ece07d6917f7',1973,'SE','Sweden','people-and-society',357,'Population: 8,139,000, average annual growth rate 0.2%
(1/72-1/73)
Ethnic divisions: homogeneous white population; smal] Lappish minority
Religion: 92% Evangelical Lutheran, 7% other Protestant, Roman Catholic, Eastern
Orthodox, 1% other
Language: Swedish, smal] Lapp- and Finnish-speaking minorities
Literacy: 99%
Labor force: 3.9 million; 11.8% agriculture, forestry, fishing; 33.5% mining
and manufacturing; 9.6% construction; 15.5% commerce; 7.2% transportation
and communications; 20.9% services; 3.2% unemployed
Organized labor: 80% of labor force
GOV ERNMENT :
Legal name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 provinces, 624 communes, 224 towns
Legal system: civil law system influenced by customary law; Acts of 1809, 1810,
1866, and 1949 serve as constitution; legal education at Universities of
Lund, Stockholm, and Uppsala; accepts compulsory ICJ jurisdiction, with
reservations
Branches: legislative authority rests jointly with Crown and parliament
(( (Riksdag); )) executive power vested in Crown but exercised by cabinet
responsible to parliament; Supreme Court, 6 superior courts, 108 lower courts
Government leaders: King Gustav VI Adolf; Prime Minister Olof Palme
Suffrage: universal, but not compulsory, over age 20
Elections: every 3 years (next in September 1973)
Political parties and leaders: Moderate Coalition (conservative), Gosta Bohman;
Center, Thorbjorn Falldin; Liberal, Gunnar Helen; Social Democratic, Olof
Palme; Communist, Carl-Henrik Hermansson; Communist League of Marxists-Leninists
(KFML), Gunnar Bylin
Voting strength (1970 election): 11.5% Moderate Coalition, 19.9% Center, 16.2%
Liberal, 45.3% Social Democratic, 4.8% Communist, 2.3% other
Communists: 17,000; a number of sympathizers as indicated by the 236,700
Communist votes cast in 1970 elections; an additional 21,200 votes cast for
Maoist KFML
Member of: Council of Europe, EC (Free Trade Agreement), EFTA, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, Nordic Council, OECD,
Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO','4d4d2489ea16aa70a7fc486c690e16591b707308b6b9e21d2011cfbb35ab2f26','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3615d28265f093efe0049c0c34e3069bf57d3c8e0784b40633eb1522919b6b88',1973,'CH','Switzerland','people-and-society',360,'Population: 6,409,000, average annual growth rate 0.8%
(1/71-1/72)
Ethnic divisions: total population -- 69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals -- 74% German, 20% French, 4% Italian,
1% Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals -- 74% German, 20% French, 4% Italian, 1% Romansch,
1% other; total population -- 69% German, 19% French, 10% Italian, 1%
Romansch, 1% other
Literacy: 98%
Labor force: 3.0 million, about one-fifth foreign workers, mostly Italian;
16% agriculture and forestry, 47% industry and crafts, 20% trade and
transportation, 5% professions, 2% in public service, 10% domestic and
other; no significant unemployment shortage of both skilled and
unskilled labor -- 6,537 unfilled vacancies in April 1972
Organized labor: 20% of labor force','6c259f6663a777657ae8c08988985a2fdc3e358d80542aa45569ea07245bb422','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3aa30f4c7a3d08b97cc204edc446b377b45c1fcc7febfb4764dbfadea236a5ab',1973,'TG','Togo','people-and-society',362,'Population: 2,126,000, average annual growth rate 2.6%
(7/66-7/72)
Ethnic divisions: some 40 tribes; largest and most
important are Ewe in south and Cabrais in north; under 1% European and
Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of commerce; major African languages
are Ewe and Mina in south and Dagoma, Tim, and Cabrais in north
Literacy: 5% to 10%
Labor force: over 90% of population engaged in subsistence agriculture; about
30,000 wage earners, evenly divided between public and private sectors
Organized labor: less than half of wage earners divided among 2 major and several
minor unions','b94b567b1a7f4bb3c9480f5d32d2f2704dba2e4c49ebafd780b56eb13e4eacd4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9012a9f4aa596438bec4aa22c56ebfb2a5eeffd618ebf4f2b671293dded512b9',1973,'TO','Tonga','people-and-society',366,'Population: 93,000, average annual growth rate 3.0%
(7/67-7/71)
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized','e3f1d566096d020c2a9079310496cd5c13577980812cc8cba320342465d742fb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1600474908194741eda0edf8463c6f58338fa122872ad5b52d22d0cc77308c6a',1973,'TN','Tunisia','people-and-society',371,'Population: 5,482,000, average annual growth rate 2.2%
(7/69-7/70)
Ethnic divisions: 98% Arab, 1% European, less than 1% Jewish
Religion: 98% Muslim, 1% Christian, less than 1% Hebrew
Language: Arabic (official), Arabic and French (commerce)
Literacy: about 30%
Labor force: 1.5 million; 70% agriculture, 10% manufacturing and construction,
20% other; 25% underemployed; shortage of skilled jabor
Organized labor: 10% of labor force; General Union of Tunisian Workers (UGTT),
subordinate to Destourian Socialist Party
Population: 38,198,000, average annual growth rate 2.6%
(10/65-10/70)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force','24d093448d1d7807accc3b7c969034cfcbd4a9b514c1ac5ce56a35265fd02f2c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac40ce18f5a819bfd1cc812e20a490e6f05aa0e766eda37e526637a84a552991',1973,'UG','Uganda','people-and-society',375,'Population: 10,810,000, average annual growth rate 3.4%
(current)
Ethnic divisions: 98.7% African, 1.3% European, Asian,
Arab
Religion: about 60% nominally Christian, 5%-10% Muslim,
rest pagan
Lanquage: English official; Luganda and Swahili widely used; other Bantu and
Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which 256,799 in paid labor, remaining
in subsistence activities
Organized labor: 123,284 union members
Population: 249,962,000, average annual growth rate 1%
(current)
Ethnic divisions: 74% Slavic, 26% among some 170 ethnic groups
Religion: 70% atheist, 18% Russian Orthodox, 9% Muslim, 3% other
Language: more than 200 languages and dialects (at least 18 with more than |]
million speakers); 76% Slavic group, 8% other Indo-European, 11% Altaic,
3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 125 million (1972), 29% agriculture, 71% industry and other
non-agricultural fields, unemployed not reported, shortage of skilled labor
reported, no shortage of unskilled labor','4f606de33e67b6f993248af09160e81b508a0632cddef38eab975e29b829cab8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45fae340fb622b64bb137458b1a96c07878fc1d3b3928d99f5976fb5775f3d3b',1973,'AE','United Arab Emirates','people-and-society',379,'Population: 179,000 (census of 15 March - 16 April 1968)
Ethnic divisions: Arabs 72%; others include Iranians,
Pakistanis, and Indians
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 20% est. (1968)
Labor force: 77,000 (1968)
Population: 5,715,000, average annual growth rate 2.0%
(7/69-7/70)
Ethnic divisions: more than 50 tribes; principal tribe
is Mossi (about 2.5 million); other important groups
are Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to Sudanic family, spoken
by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active population engaged in animal
husbandry, subsistence farming, and related agricultural pursuits; about
30,000 are wage earners; about 20% of male labor force migrates annually to
neighboring countries for seasonal employment
Organized labor: 3 primary and several small specialized unions','9d31577635d6e6133c956cfcf7e3583198c5e411dddb5feaa5ef6d4671caf4ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed30b36387957746e36c2d84c6b7fe9832c69a1881e10712dbebd7ca52367530',1973,'UY','Uruguay','people-and-society',383,'Population: 2,992,000, average annual growth rate 1.2%
(7/70-7/71)
Ethnic divisions: 85%-90% white, 5% Negro, 5%-10% mestizo
Religion: 66% Roman Catholic (less than half adult population attends church
regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed in important sectors --
25% government; 34% industry; 10% service; 13% other; 8% agriculture, forestry,
fishing and mining; no shortage of skilled labor
Organized labor: about 25% of labor force (largely Communist influenced)
GOV ERNMENT:
Legal name: Oriental Republic of Uruguay
Type: republic
Capital: Montevideo
Political subdivisions: 19 departments with limited autonomy
Legal system: based on Spanish civil law system; new constitution implemented
1967; judicial review of legislative acts in Supreme Court, legal education
at University of the Republic at Montevideo; accepts compulsory ICJ
jurisdiction
Branches: executive, headed by President; since 1973 the military has had
considerable influence in policymaking; bicameral legislature (30 Senators
plus Vice President who presides and has voice and vote, and 99-member
Chamber of Deputies) elected by popular vote under a complicated system
using proportional representation; national judiciary headed by Supreme
Court
Government leader: President Juan Maria Bordaberry
Suffrage: universal over age 18
Elections: every 5 years; next in 1976
Political parties and leaders: National (Blanco) Party, President of Party
Directorate Homero Murdoch, main factions include Martin Echegoyen''s "Alianza"
faction, List 400 (Washington Beltran), Rocha Movement (Alberto Gallinal),
Orthodox Herreristas (Alberto Heber Usher), and Por La Patria (Wilson Ferreira
Aldunate); Colorado Party, main factions include Colorado and Batllista Union
(Juan Maria Bordaberry), List 15 (Jorge Batlle), List 315 (Amilcar Vasconcellos);
Broad Front (Frente Amplio), leftwing coalition of Leftist Liberation Front
(FIDEL), Communist Front and dissident factions from both the Blanco and
Colorado parties, and including FIDEL, the Christian Democrats, and other
splinter groups
Voting strength (1971 elections): 41% Colorado, 40.2% Blanco, 18.3% Frente Amplio,
0.5% Radical Christian Union
Communists: 35,000-40,000 including Communist youth group (6,000-8,000)
Other political or pressure groups: Communist Party (PCU), Rodney Arismendi;
Christian Democratic Party (PDC); Socialist Party of Uruguay (PSU); Revolu-
tionary Movement of Uruguay (MRO) pro-Cuban Communist Party; National
Liberation Movement of Uruguay (MRO) pro-Cuban Communist Party; National
Liberation Movement (MLN-Tupamaros) Marxist Revolutionary terrorist group
Member of: IADB, IAEA, IBRD, ICAO, ILO, IMF, LAFTA, OAS, U.N.
357
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Population: 1,000 (official estimate for 1 July 1964)
Ethnic divisions: primarily Italians but also many
other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees divided
into 3 categories -- executives, officeworkers,
and salaried employees
Organized labor: none
Population: 11,330,000 (excluding Indian jungle population
estimated at 32,000 in 1961), average annual growth
rate 3.4% (2/61-11/71)
Ethnic divisions: 67% mestizo, 21% white, 10% Negro, 2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 74% (claimed, 1970 est.)
Labor force: 3 million (1969); 24% agriculture, 6% construction, 17% manufacturing,
6% transportation, 18% commerce, 25% services, 4% petroleum, utilities, and
other
Organized labor: 45% of labor force
Population: 19,866,000, average annual growth rate 1.2%
(current)
Ethnic divisions: 85%-90% predominantly Vietnamese; ethnic
minorities include Muong, Thai, Meo, and Man
Religion: Confucianism, Buddhism, Taoism, Catholicism
Language: closely corresponds to the breakdown of ethnic groups
Literacy: claimed to be 95% (1964)
Labor force: (1 January 1970) 9.6 million, not including military; about 70%
agriculture and 10% industry
Population: 19,801,000, average annual growth rate 2.6%
(7/70-7/71)
Ethnic divisions: 87.7% Vietnamese, 6% Chinese, 3.2%
mountain tribesmen, 2.9% Khmer, 2% Cham
Religion: 70% Buddhist (at least 5% Hoa Hao), 5% Cao Dai, and 10% Catholic; others
include animist, and small numbers of Protestant, Muslim and Hindu; most
Buddhists are of Mahayana school or practice combination of Buddhism, Taoism,
and Confucianism
Language: Vietnamese, French, Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian), Cham (Malayo-Polynesian dialect)
Labor force: civilian work force 5.8 million (not including armed forces);
67% agriculture, fishing, and forestry; 17% industry and commerce; 3%
domestic and personal services; 3% employed by U.S.; 5% government; 5%
unemployed
Organized labor: unknown
Population: 148,000, average annual growth rate 1.8%
(11/66-11/71)
Ethnic divisions: Polynesians, about 12,000 Euronesians (persons of European
and Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of population associated with the London
Missionary Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all children from 7-15 years)
Labor force: agriculture 19,148; mining and manufacturing 1,716 (1961)
Organized labor: unorganized
Population: 1,555,000*, average annual growth rate 2.7%
(current)
Ethnic divisions: almost all Arabs; a few Indians,
Somalis, and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 6,254,000, average annual growth rate 2.9%
(current
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and herding','2433bc7a3751712850d66116d1deeb1ddccd3d0d3b1cc027d40a95784f0f15b1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f0e7b7d436a6aaf3808211b724c27ecbab7124ae061c6eb118f3cd962d89ff4',1973,'ZM','Zambia','people-and-society',386,'Population: 4,688,000, average annual growth rate 3.8%
(8/69-7/72)
Ethnic divisions: 98.7% African, 1.1% European, .2% other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000 Africans, 27,000 non-Africans;
15% mining, 9% agriculture, 9% domestic service, 19%
construction, 9% commerce, 10% manufacturing, 23% government and miscellaneous
services, 6% transport
Organized labor: 100,000 wage earners, primarily in industrial sector, are
unionized (early 1968)
GOV ERNMENT:
Legal name: Republic of Zambia
Type: republic since October 1964
Capital: Lusaka
Political subdivisions: 8 provinces
Legal system: based on English common law and customary law; constitution adopted
1972; judicial review of legislative acts in an ad hoc constitutional
council; legal education at University of Zambia in Lusaka; has not accepted
compulsory ICd jurisdiction
Branches: modified presidential system; unicameral legislature; judiciary
Government leader: President Kenneth Kaunda; prime minister to be appointed
by President under new 1 party system
Suffrage: universal adult
Elections: last general election December 1968; due again sometime in late 1973
Political parties and leaders: United National Independence Party (UNIP),
Kenneth Kaunda; former opposition party banned in December 1972 when
1 party state proclaimed
Voting strength (1968 election): UNIP had 73% of vote, but 30 of its candidates
were unopposed; strength probably would have been over 80% if these seats
had been contested; adopted single party system of government in 1972
Communists: no Communist Party, but sympathizers of socialism in upper levels
of government, UNIP, and Tabor unions
Member of: AFDB, Commonwealth, FAO, IAEA, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU,
U.N., UNESCO, UPU, WHO, WMO','a5104176ddd7ed505c0b779dd2864eb498996a7a90b3d8bdc2166fbc8e484500','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d71d89366f149a5bbc42841f00ee5cc36a0de1a8ac7e89fe5a42cc47cf53e6ef',1973,'US','United States','people-and-society',388,'Population: 210,501,000, average annual growth rate 0.8% (current)
Ethnic divisions: population basically of West European extraction, modified
by subsequent waves of immigration
Religion: total membership in religious bodies, 128,470,000; Protestant
69,424,000, Roman Catholic 47,873,000, Jewish 5,780,000, other religions
5,393,000
Language: English, predominantly
Literacy: almost complete
Labor force: 86 million (1972)
Organized labor: 28.8% of total','67b515298a2d919f9aa0511fc2a6ca3aa946f22786829e54fcb0334cecdb8479','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

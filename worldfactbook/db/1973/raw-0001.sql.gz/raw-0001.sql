SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('600a1eaf17c6a8886a477a5c0140d72dd22bb494bd3fbff2984eec86d90e1954',1973,'','','raw',1,'A pproved for Release: 2018/04/27 C06726997 =
NATIONAL INTELLIGENCE SURVEY
; BASIC INTELLIGENCE FACTBOOK
JANUARY 1973
$
Py
; CHIVAL RECORD
des t 1972 i f this Factbook, ''ARCHIV. ,
Supersedes the July 1972 issuance of this Factboo i PLEASE RETURN TO |
copies of which should be destroyed. AGEN i ARCHIVES,
a ORT
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
“SECRE—
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data
on political entitics worldwide, is coordinated and published
scmiamnually as part of the NIS Program by the Office of Basic
and Geographic Intelligence, Central Intelligence Agency. The
data are prepared by components of the Defensc Intelligence
Agency and the Central Intelligence Agency. Comments and
suggestions should be addressed to the Office of Basic and
Geographic Intelligence (Attn: NIS Factbook), Central Intel-
ligence Agency, Washington, D.C. 20505.
Additional copics of the Factbook, both classificd and un-
classificd issucs, are obtainable through established channels for
disscmination of the NIS.
THIS MATERIAL CONTAINS INFORMATION AFFECTING
THE NATIONAL DEFENSE OF TIIE UNITED STATES
WITHIN THE MEANING OF THE ESPIONAGE LAWS,
TITLE 18, USC, SECS. 793 AND 794, THE TRANSMISSION
OR REVELATION OF WHICH IN ANY MANNER TO AN
UNAUTIIORIZED PERSON IS PROHIBITED BY LAW.
CLASSIFIED BY 58-0001, EXEMPT FROM GENERAL DECLASSIFICATION SCHEDULE
OF €. O. 11652 EX zea CATEGORIES SB (2) AND (3). DECLASSIFIED ONLY
ON APPROVAL OF OCI
Approved for Release: 2018/04/27 C06726997
em det
ee ee
Approved for Release: 2018/04/27 C06726997
WARNING
The NIS is National Intelligence and may not be re-
leased or shown to representatives of any foreign govern-
ment or international body except by specific authorization
of the Director of Central Intelligence in accordance with
the provisions of National Security Council Intelligence Di-
rective No. 1.
For NIS containing unclassified material, however, the
portions so marked may be made available for official pur-
poses to foreign nationals and nongovernment personnel
provided no attribution is made to National Intelligence or
the National Intelligence Survey.
Unless otherwise indicated, individual items
are UNCLASSIFIED/FOR OFFICIAL USE ONLY.
Classification designations are:
(2) ee Confidential
(S)...... Secret
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
SECRET
Table of Contents (cont''d):
SENEGAL. oe be so ec bs Bate oor Ra we ee el ee SO ale le or SP es
SEYCHELLES =o) 5.95. et te ee A fe ee ee Sa es oa hte erie eae
Sharjah (see UNITED ARAB EMIRATES)
STERRA LEONE: 3. 3. 3,6: jose aoe koe: eee eo Aca 4 be ee RE are
SIKKIM esol aoe Wn ea ey eee ae ee SO We we Aaa ter eS ete
SOMALT As. for) ec se coh Oe ewe se ee Gc ce ites) Srl a as ae ew ele
SOUTHARRIGCA |e. oi: eh ee il el oe ere ww Bea ch Swe wwe als
Southern Rhodesia (see RHODESIA)
SOUTH=WEST |AFRIGAS: e555 55 Soke, Woe les ae ec OS es
SPAIWNs o.oo oe lertene ce mar Cove! Cee oh Wow LSS? o> He Rua coy See ee Ged Saas
SRT LANKA si i50c3. oe hate faa tes. a ER a ee EK ey
i i i i i i |
2Tz
|
Middl (see peace
THAILAND... .... B Meas i) Ate ha kak oA Gheeiued Ma, Mor iy ode te melee fo
TONGA. ee, ee rare
TRINTOAD AND TOBAGOs 2 3 Gav 0 Soba actbnoe and fo aces a
TUNISIA. 2... ww ee Sol Gat cat anh oy Weel oe aoe ol Ga Sakae fee be oh Oe
TURKEY, |, 5353-6 co: sic ae Ges Gos 0 as a te ec Bye Pol Gn eS Tecate faire a
-U-
S.R
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm "al Qaiwain. .. 1. ee ew eee
United Arab Republic (see EGYPT)
UNITED KINGDOM. 2... 1 2 we ee ee ee
UNITED: STATES > 5. eas ce. Ss ber evs ie el en a eee ee
UPPER ‘VOLTA S. a ten ves és ce ete oe Nel ie Sele a? ec ee ea Mee ea
URUGUAY 6 ese ccs aise Melee yee og oo ley ty ce: Sa i a ea ey tea eS La ee
-\\-
VATICAN CLIN io a oe dee ae ht a Rees ae es I ae ae cas
VENEZUELA cece seas ol a as $05 ar dk a ce ave dap Pe ay Sa a Se, lw Ae
VIETNAM, NORTH... ....., BS Ae Sia Bye ROSENT RS Jet te be a dh, ae eect, ye
VIETNAM, SOUTH . . 1 eee ee eee we ee eee tt tts
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
—~Sterer—
NIS 27 TURKEY
LAND:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER: Pare
Limits of territorial waters (claimed): 6 n. mi. .
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mt.)
Coastline: 4,475 mi.','3d010a63a9223686fb0d93a0591b381470714a42cab3b49d027269a6eff5c8a9','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9711ec8c59ffaee3f65e5796334dfed691ea5675276d9e618e14212eaf1242d',1973,'','','raw',1,'Approved for Release: 2018/04/27 C06727039
>
“NATIONAL INTELLIGENCE SURVEY
BASIC INTELLIGENCE FACTBOOK
JULY 1973
Supersedes the January 1973 issuance of this “ ARCHIVAL RECOR!
Factbook, copies of which should be destroyed FLEAS? RETURN TO ;
AGENCY ARCHIVES, ELDG. 4+.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data
on political entities worldwide, is coordinated and published
semiannually as part of the NIS Program by the Office of Basic
and Geographic Intelligence, Central Intelligence Agency. The
data are prepared by Office of the Geographer, Department of
State and by components of the Defense Intelligence Agency
and the Central Intelligence Agency. Comments and suggestions
should be addressed to the Office of Basic and Geographic
Intelligence (Attn: NIS Factbook), Central Intelligence Agency,
Washington, D.C. 20505.
Additional copies of the Factbook, both classified and un-
classified issues, are obtainable through established channels for
dissemination of the NIS.
THIS MATERIAL CONTAINS INFORMATION AFFECTING
THE NATIONAL DEFENSE OF THE UNITED STATES
WITHIN THE MEANING OF THE ESPIONAGE LAWS,
TITLE 18, USC, SECS. 793 AND 794, THE TRANSMISSION
OR REVELATION OF WHICH IN ANY MANNER TO AN
UNAUTHORIZED PERSON IS PROHIBITED BY LAW.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
WARNING
The NIS is National Intelligence and may not be re-
leased or shown to representatives of any foreign govern-
ment or international body except by specific authorization
of the Director of Central Intelligence in accordance with
the provisions of National Security Council Intelligence Di-
rective No. 1.
For NIS containing unclassified material, however, the
portions so marked may be made available for official pur-
poses to foreign nationals and nongovernment personnel
provided no attribution is made to National Intelligence or
the National Intelligence Survey.
Unless otherwise indicated, individual items
are UNCLASSIFIED/FOR OFFICIAL USE ONLY.
Classification designations are:
(OC) testes Confidential
(S)ve. 32) Secret
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
“SECRET.
Table of Contents
Page
SAN: MARINO: ce 6 cee See ge Sere Se a lade Gee an A ee ie a ae 383
SAUDE ARABIA g:o5 3 sd. ceed & Reel Se) eS ee es 385
SENEGAL 2. fms oe So te a te Se at ee LE Si eh aes PE eee 387
SEYCHELLES cigar ee eas oe be este eS he Ge so es eee Sa ae So Be 389
Sharjah (see UNITED ARAB EMIRATES)
STERRA (LEONE: ~) 05. &. gee Sees ete A Sa ae te Re ey ne ye pe en ee 391
ST KKEM 3.2 caste see A es ce sl ee Gave Con Be eee, Ree ee We eS 393
STINGAPORE 6 ~ eieccoe otesecs desea We: obo eG" Annee Moh ee io oes nao es Wee eee 395
SOMALTA Sic: senor SBS ee Pa EE ne ae ie een ee eee “al GE ws Rees of? 397
SOUTH: AFRICA? oc. cei eo 8 See eer te ar ee Ss Tee 0 We ee Se 399
Southern Rhodesia (see RHODESIA)
SOUTH-WEST AFRICA. . . 2. 2 1 ee we ee te we te 403
SPAINGG se Se oe Se ee ls Ba Sera tS re wl hee os tay Janine 8s 405
SPANTSH ‘SAHARA 5. 232-0. ee kee ee ee see ee eee ww Ce 409
SRE LANKA Ses setae ib tie es re ote Sore a wren ie) eo ee tated See ae 411
SUDAN o. ie-.g. oe sehen Sek mol as he Bh “Seer se tgs Sha tah re win et ems NS Ge tee eh oe 415
SURINAME. 02 xsc260 ve sei Soro ce A SE ee eR he ee as ar tar Sh eee eee 419
SWAZILAND =. 2.62 ccs S) nO ee Fe Oo Se Blea Mek % Bee, Byway teu ke 421
SWEDEN cue ce nea caetot le conte on medic phase, Gti Gams Mean Se 423
SWITZERUAND sc od ce ''o: 1,006 os van ts Fen Saas Ag Be, eae! Tey Cage 427
SYR TRG oy ec secs etek be ee ek eng es areas 429
-T:
Tanganyika (see TANZANIA)
TANZANTAS ob cake. oie eh ce etn eh nin 8 Case a a te cle Ca aS wate Se 431
Tasmania (see AUSTRALIA)
THAILAND 3. wc -8 we ees eR ee be aoe & ie we ee 495
TOGO a: yee UR Ow aw ae ee wd Se ee A Se wee ee 439
TONGA © 6. edge ee Se Sc ae eS rae ; : ‘ 44]
oe AND TOBAGO. F Bae bode al eh awe hare ee ss . . =. 443
iia Bah GPL Baa aE ND ON Cie DER ea vs ect aay ce Fs 445
TURKEY gn eh weet Ai APS ae i sg ge eet, BMG ee eit te aa Sk: 447
-U-
UGANDA 555 io oe eo do reser ree ee nse ae a eles wes es ee 451
nes al Qaiwain (see UNITED ARAB EMIRATES)
Sk, ake Byles Be Sw Gon Ey fa els NDR ne Ot age, ee 453
ED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain. ........2... 457
United Arab Republic (see EGYPT)
UNITED KINGDOM. 2... 1 1 we ee ee ee we tt ee te et 459
UNETED “STATES. o°-2 oc. se? Gece oe an ce ere Vel Gh ewe Sal Bek ele ne a 497
UPPER: VOLTA so: o:ce) te tee es oe I ee Be BO be Oe bes 463
URUGUAY cei eo ie eho eae Ser ay Boal ww Boer SP Gee: Be, Sas 82 weer 8 465
-V-
VATICAN: CLI a: 22-2, ecg: sés fortes Se et Se ea SCR te. ae a Gales 469
VENEZUELA se 5- ower ver era RS, “eee eee te yee el HS Bey Sere Re 471
VIETNAM, ‘NORTH gees detec tee ca eel ceive ei Ba ee ee 475
VEETNAM,. “SQUTHD ec. ce ios wee ae Se ee ee ae ee EP 479
v
SEGRE.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
““SRCRET.
NIS 27 TURKEY
D:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mi.)
Coastline: 4,475 mi.','d81506181d04ffbecc364831122ff5a940f94bbc6ccef504917bcbbdae630814','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('605f81601fcb9c90e0c3ab344f1a052ef4f7af24a148759bb2da1a322203d131',1973,'','','raw',1,'Approved for Release: 2018/04/27 C06726998
BASIC INTELLIGENCE FACTBOOK
JULY 1973
Supersedes the January 1973 issuance of this
Factbook, copies of which should be destroyed.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998 :
ae
teow
i
{
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data on political
entitics worldwide, is coordinated and published semiannually as part of the NIS
Program by the Office of Basic and Geographic Intelligence, Central Intelli-
_» gence Agency. The data are prepared by Office of the Geographer, Department
of State and by componcnts of the Defense Intelligence Agency and the Central
Intelligence Agency. Comments and canuestions should be addressed to the
Office of Basic ana Geographic Intelligence (Attn: NIS Factbook), Central
Intelligence Agency, Washington, D.C. 20505.
Additional copies of the Factbook are obtainable through established
~ channels for dissemination of the NIS.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
This edition is a compilation of the unclassified
information in the classified version of the Factbook.
It is issued for use by U. S. Government departments
and agencies.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
Table of Contents
Page
SAN MARINO. 2... 2 ee ee ee ee ee ee eS 293
SAUDI ARABIA... - ee ee eee tee et ee eee 295
SENEGAL. . 2-2 ee et et ee te ee eee te eee 297
SEYCHELLES . 2. ee ee eet te ee te ee 299
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE. 2. we ee ee ee ee ee et 301
SIKKIM... 2 ee ee ee ee tt eet te HE 303
SINGAPORE. . .- - 2 es © eng aoe: Re a Meas lee SARI a NES, TEES Ms 305
SOMALIA. . .. 2. - eee ponies ee Yornlg vies Ro eee dats tet Se wee We 2 . . 307
SOUTH AFRICA... ee ee ee te ee ee 309
Southern Rhodesia (see RHODESTAJ
Sil aaah AFRICA. .... > bees Je ghigs vate Go are em 6 ieee ise uy
SPANISH SAHARA... .- hc le wale “ae ae Gah tae ee ogi Cee SS 317
SRI LANKA. 2. ee ee te et ee ee 319
SUDAN. . .. 2 ss eo eel Wes eee ce tat gi rel cal get, Ser ton ah Say va Sg, ea nes 321
SURINAM. » 2 ee ee ee te ee 323
SWAZILAND be gy ose ental a: atctah eae pO) be bg Wik en WE TES Be ew TS 325
SWEDEN . 2. we ee te ee te ee ewe ee ee ee 327
SWITZERLAND. . 2... 2 ee ee ee te ee eee ee eS oe « 329
SYRIA. 2. ew ee et te tee we ee ES 331
-T-
Tanganyika (see TANZANIA)
TANZANIA. wc eee te ee ee et ee ee & 333
Tasmania (see AUSTRALIA)
THAILAND... 2... ee ee te ee te ees gf ehhiig ig fe eel eh % 3330
TOGO... . es cia, ais tae ong. And Keen oper ae Pah te NS a ject wy eS
TONGA, . 2 ee ee et tte ett we eet we ee ee . . 339
TRINIDAD AND TOBAGO. ....-+.-s Se clbt ee hg seh ke Tal yor et to? ow) Ca seas . 341
TUNISIA. 2 2. ew ee ee eee te ee ee Sag Se 2849
TURKEY . 2... ee ee ee ee Band May US Sain EPS Mee tay seh ain aie S. te es TORO GS 345
-U-
UGANDA. 2. we ee ee te ee te ee wee ee 347
Umm al Qaiwain (see UNITED ARAB EMIRATES)
| ee eee ee PP To a 349
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Unm al Qaiwain . . 2 2 6 eee ees 351
United Arab Republic (see EGYPT)
UNITED KINGDOM... . eee ee eee te ee ee eee 353
UNITED STATES. . 2. eee ee te eee eet ee he eH 379
UPPER VOLTA, . . 2. ee ee eee et ee ee ee ee eee 355
URUGUAY. . .. 2 «> Ly cgi gh tortie. Ue dies Nel vas Meneses Sept ere, ee? cote ree. 357
-y-
VATICAN CITY 2. 2 we ee ee ee ee 359
VENEZUELA. . 2. 1 ee ee ee et ee ee ee he eee 361
VIETNAM, NORTH. . 2... - ee ee we ee Sree nds. Ghceear barr") sat War 0 eso fe 363
VIETNAM, SOUTH . 2. 6 6 we ee te ee eee te eh ee ee 365
v
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
TURKEY
D:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive SPRY
Land boundaries: 1,600 mi. Seat
cover SAUDI
WATER: "Sy nama
Limits of territorial waters (claimed): 6 n. mi. Be
except in Black Sea where it is 12 n. mi. SUDAN ‘
(fishing, 12 n. mi.) £ RSS
Coastline: 4,475 mi. ETHIOPYA','a24946e0eda2487814d38bc598fdbba53715746ebaacc57387c8bc055ad24a8d','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb5013ef6d07d0770f362312b12e6d65c56a914072ec7fb7bc7cd6da8338f925',1973,'','','raw',1,'co
“
ee oe oe ee
Approved For Release Bere 30) ol) Hennes on crore
8 August 1973
MEMORANDUM FOR: 25X1A
OPS /INT/RC/IE
SUBJECT : Release of National Intelligence Survey
weic Intelligence Factbook to the
REFERENCE 3
1. in response to your request, the Director, OBGI, has
approved release of the attached UNCLASSIFIED edition of the
Basic Intelligence Factbook, dated July 1973, ENE X1C
25X1C
2. The fly leaf referring to the existence of a classified
os edition of the NIS Basic intelligence Factbook has been removed.
25X1CSince the recipients certainly know the origin of the
Factbook, we see no need for further sanitization. You, of course,
ave free to apply your owa criteria for a
before releasing it to
25X1A
Special Assistant to Director
Basic and Geographic Intelligence
Attachment:
as stated
Distribution: .
Ok1 - Addressee (with attachment)
1 - O/DDI Sc igpremepee of incoming) 25X1A
1 - Ch/PSB/NISD/BGI (w/cy of incoming
2 - D/BGI (w/orig of incoming)
SA/D/BGl jc /3334(8 August 73)
= 25X1A
Approved For Release 2001/03/03 : QR GAP Tej0502 advo THOBAGT BES
ee','4816fe85c84fe93eb1ad36d474c6b2f544a2a3e0cb4e37e1dac7ccd46ae3bac1','internet-archive','cia-readingroom-document-cia-rdp78-05927a000100040118-5','txt','94baabaac55a2984a8a056ecb5590cee07abf0ed319814b6381939e64d68859e','https://archive.org/download/cia-readingroom-document-cia-rdp78-05927a000100040118-5/cia-rdp78-05927a000100040118-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dafa2d259adaf087594922cf50332128b4540ca768ac347599e6cab33abea18a',1973,'','','raw',1,'BASIC INTELLIGENCE FACTBOOK
JANUARY 1973 ;
DIA review(s) completed.
Supersedes the July 1972 issuance of this Factbook, .
copies of which should be destroyed.
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1 " :
FORKWORI])
the baste Intelligence Factbook. a compilation of basic data on political
entines worldwide. is coordinated and published semiannually as part of the NIS
Proeramy by the Ottiee of Basic and Geographic Intelligence. Central Intelli-
vence Avencew. The data are prepared by components of the Defense Intelligence
\\genev and the Central Intelligence Agencv. Comments and suggestions should
he addressed to the Office of Basie and Geographic Intelligence «Attn: NIS
Factbook). Central Intelligence Agency. Washington. 10.C. 20505.
Additional copies of the Factbook are obtainable through established
channels for dissemination of the NIS.
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
{
This edition is a compilation of the unclassified
information in the classified version of the Factbook,
It is issued for use by U. S. Government departments
and agencies.
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Next 5 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
AAPSO
ADB
ANZUS
ASA
ASPAC
BENELUX
BLEU
CACM
CARIFTA
CEMA
CENTO
DAC
EAMA
EC
ECAFE
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
TADB
ICFTU
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
Afro-Asian People''s Solidarity Organization
Asian Development Bank
ANZUS Council; treaty signed by Australia, New Zealand,
and the United States
Association of Southeast Asia
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Free Trade Association
Council for Mutual Economic Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
Economic Commission for Asia and the Far East
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Launcher Development Organization
European Monetary Agreement
Political-Economic Association of Ivory Coast, Dahomey,
Niger, Upper Volta, and Togo
European Space Research Organization
European Atomic Energy Community
Inter-American Defense Board
International Confederation of Free Trade Unions
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
IDB Inter-American Development Bank
IFCTU International Federation of Christian Trade Unions
IHB International Hydrographic Bureau
IRC International Red Cross
La Francophonie Agency for Cultural and Technical Cooperation
LAFTA Latin American Free Trade Association
LICROSS League of Red Cross Societies
NATO North Atlantic Treaty Organization
OAPEC Organization of Arab Petroleum Exporting Countries
OAS Organization of American States
OAU Organization of African Unity
OCAM Afro-Malagasy Common Organization
ODECA Organization of Central American States
OECD Organization for Economic Cooperation and Development
OPEC Organization of Petroleum Exporting Countries
SEATO South-East Asia Treaty Organization
UAM Union Africaine et Malgache
UEAC Union of Central African States
UDEAC Economic and Customs Union of Central Africa
WEU Western European Union
WFTU World Federation of Trade Unions
WPC World Peace Council
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
SC Security Council
GA General Assembly
ECOSOC Economic and Social Council
TC Trusteeship Council
ICJ International Court of Justice
Secretariat
Approved For Release 2004/09/45 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES (cont''d)
Operating Bodies:
UNCTAD U.N. Conference for Trade and Development
TDB Trade and Development Board
UNICEF U.N. Children''s Fund
Regional Economic Commissions:
ECA Economic Commission for Africa
ECAFE Economic Commission for Asia and the Far East
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development
(World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural
Organization
UPU Universal Postal Union
UNCTAD U.N. Conference on Trade and Development
WHO World Health Organization
WMO World Meteorological Organization
IAEA
Autonomous Organization Under the U.N.:
International Atomic Energy Agency
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES (cont''d)
Committees:
Seabeds Committee United Nations Committee on the Peaceful Uses of the
Sea-Bed and Ocean Floor beyond the Limits of National
Jurisdiction
Approved For Release 2004/0915 : CIA-RDP79-01051A000500010001-1
ay
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
NOTE:
Political, sociological, and economic data, including monetary conversion
rates, generally reflect information through mid-October 1972, except for population
estimates, which have been projected to 1 January 1973. Military manpower estimates are
as of 1 January 1973 except for average number of males reaching military age, which
are projected averages for the 5-year period 1972-76. Military and communications data
are as of 1 October 1972 unless otherwise indicated.
Most of the land utilization estimates are rough approximations, and most of
the statistical data are rounded (thousands and millions). Figures for “arable” may
reflect only the area actually under crops rather than the potential cultivable.
Fishing limits are included only when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The difference between
the two is in the addition or subtraction of the value of return on foreign investment.
GDP equals GNP plus income earned in the country but sent abroad, minus income earned
abroad but sent into the country. GDP thus tends to exceed GNP in debtor countries,
and the reverse is true in creditor countries.
Major ports are the largest maritime ports of the country, relative to other
ports of the same country, on the basis of estimated port capacity, alongside berthing
accommodations, and commercial or naval importance. Minor ports are the remaining
ports of a country which have, relative to the major ports, significantly lower
estimated port capactiy, fewer alongside berthing accommodations, are of less
commercial or naval importance. Major transport aircraft are those weighing over 20,000
pounds. Military budgets are in U.S. dollar equivalents. The dollar sign refers to
U.S. dollars unless otherwise stated. The abbreviation FY stands for U.S. fiscal year;
all years are calendar years unless otherwise indicated.
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15.) Gl AcRP79-01051A000500010001-1
D:
250,000 sq. mi.; 22% arable (including 6.5% cultivated) , PEOPLE''S REPUBLIC
5% pasture, 71% desert, waste or urban, 2% fores ted : OF CHINA
Land boundaries: 3,425 mi. Ne
¥* Prec RBS, ny”','b2fe953ff54f19cd2b91e0e27e132d5f88d40f58b7bb6db7f6ef13a6431e1cfa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a570ac175512f737b85d07f66ad4bc2b12cbfa0f1ffabd0fee23d891f0a4b3a4',1973,'','','raw',1,'my pe Qh
4X pa {a ly
%
BASIC INTELLIGENCE FACTBOOK
JULY 1973
DIA review(s) completed.
Supersedes the January 1973 issuance of this
Factbook, copies of which should be destroyed.
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data on political
entities worldwide, is coordinated and published semiannually as part of the NIS
Program by the Office of Basic and Geographic Intelligence, Central Intelli-
gence Agency. The data are prepared by Office of the Geographer, Department
of State and by components of the Defense Intelligence Agency and the Central
Intelligence Agency. Comments and suggestions should be addressed to the
Office of Basic and Geographic Intelligence (Attn: NIS Factbook), Central
Intelligence Agency, Washington, D.C. 20505.
Additional copies of the Factbook are obtainable through established
channels for dissemination of the NIS.
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
This edition is a compilation of the unclassified
information in the classified version of the Factbook.
It is issued for use by U. S. Government departments
and agencies.
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Next 5 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
AAPSO Afro-Asian People''s Solidarity Organization
ACCT Agency for Cultural and Technical Cooperation of
French-speaking Countries
ADB Asian Development Bank
AFDB African Development Bank
ANZUS ANZUS Council; treaty signed by Australia, New Zealand,
and the United States
ASA Association of Southeast Asia
ASPAC Asian and Pacific Council
BENELUX Belgium, Netherlands, Luxembourg Economic Union
BLEU Belgium-Luxembourg Economic Union
CACM Central American Common Market
CARIFTA Caribbean Free Trade Association
CEAO West African Economic Community
CEMA Council for Mutual Economic Assistance
CENTO Central Treaty Organization
Colombo Plan
Council of Europe
DAC Development Assistance Committee (OECD)
EAMA African States associated with the EEC
EC European Communities (EEC, ECSC, EURATOM )
ECAFE Economic Commission for Asia and the Far East
ECSC European Coal and Steel Community
EEC European Economic Community (Common Market)
EFTA European Free Trade Association
EIB European Investment Bank
ELDO European Launcher Development Organization
EMA European Monetary Agreement
ENTENTE Political-Economic Association of Ivory Coast, Dahomey,
Niger, Upper Volta, and Togo
ESRO European Space Research Organization
vii
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
EURATOM European Atomic Energy Community
IADB Inter-American Defense Board
IDB Inter-American Development Bank
IFCTU International Federation of Christian Trade Unions
IHB International Hydrographic Bureau
IRC International Red Cross
LAFTA Latin American Free Trade Association
LICROSS League of Red Cross Societies
NATO North Atlantic Treaty Organization
OAPEC Organization of Arab Petroleum Exporting Countries
OAS Organization of American States
OAU Organization of African Unity
OCAM Afro-Malagasy and Mauritian Common Organization
ODECA Organization of Central American States
OECD Organization for Economic Cooperation and Development
OPEC Organization of Petroleum Exporting Countries
SEATO South-East Asia Treaty Organization
UEAC Union of Central African States
UDEAC Economic and Customs Union of Central Africa
WEU Western European Union
WCL World Confederation of Labor
WFTU World Federation of Trade Unions
WPC World Peace Council
viii
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
Sc
GA
ECOSOC
TC
ICd
Operating Bodies:
UNCTAD
TDB
UNICEF
Regional Economic
ECA
ECAFE
ECE
ECLA
Intergovernmental
FAO
GATT
IBRD
ICAO
IDA
IFC
ILO
IMCO
IMF (FUND)
ITU
UNESCO
Security Council
General Assembly
Economic and Social Council
Trusteeship Council
International Court of Justice
Secretariat
U.N. Conference for Trade and Development
Trade and Development Board
U.N. Children''s Fund
Commissions:
Economic Commission for Africa
Economic Commission for Asia and the Far East
Economic Commission for Europe
Economic Commission for Latin America
Agencies Related to the U.N.:
Food and Agriculture Organization
General Agreement on Tariffs and Trade
International Bank for Reconstruction and Development
(World Bank)
International Civil Aviation Organization
International Development Association (IBRD Affiliate)
International Finance Corporation (IBRD Affiliate)
International Labor Organization
Inter-Governmental Maritime Consultative Organization
International Monetary Fund
International Teleconmunication Union
United Nations Educational, Scientific, and Cul tural
Organization
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
UNITED NATIONS (U.N.}: STRUCTURE AND RELATED AGENCIES
UPU Universal Postal Union
UNCTAD U.N. Conference on Trade and Development .
WHO World Health Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
Committees:
Seabeds Committee United Nations Committee on the Peaceful Uses of the
Sea-Bed and Ocean Floor beyond the Limits of National
Jurisdiction
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
nl
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Political, sociological, and economic data,
including monetary
conversion rates, generally reflect informatio
n through mid-April
1973, except for population estimates, which have been projected to
1 July 1973. Military manpower estimates are as of 1 July 1973
except for average number of males reachin
g military age, which
are projected averages for the 5-year period 1973-77. Mi
communications data are as of 1 April 1973 unless otherwise indicated.
Most of the land utilization estimates are rough approximations,
s and millions).
and most of the statistical data are rounded (thousand
Figures for "arable" may reflect only the area actually under crops
rather than the potential cultivable. Fishing limits are included
only when they differ from the territorial limits.
is shown, The difference
For some countries GDP, rather than GNP,
between the two is in the addition or subtraction of the value of
s income earned
return on foreign investment. GDP equals GNP plu
in the country but sent abroad, minus income earned abroad but
sent into the country. GDP thus tends to exceed GNP in debtor
a countries, and the reverse is true in credito
Major ports are the largest maritime ports of the coun
relative to other ports of the same country, on the basis of
ccommodations , and
estimated port capacity, alongside berthing a
commercial or naval importance. Minor ports are the rem
aining ports
of a country which have, relative to the major ports,
significantly
lower estimated port capacity, fewer alongside berthing accommodations,
are of less commercial or naval importance. Major trans
port aircraft
are those weighing over 20,000 pounds. Military budgets are in U.S.
dollar equivalents. The dollar sign refers to U.S. dollars unless
otherwise stated. The abbreviation FY stands for U
.§. fiscal years
all years are calendar years unless otherwise indicated.
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ee
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
AFGHANISTAN a a
“PEOPLE''S REPUBLIC
OF CHINA
ES 550,000 sq. mi.3 22% arable (including 6.5% cultivated),
5% pasture, 71% desert, waste or urban, 2% forested
Land boundaries: 3,425 mi.','09e5bcda9a204c59a0e9a96c800ceb764132a465d9360a6b3f54d3a56bef865b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6d1e19a2a6bc4775b439f6ba71fdbaf46c60245296263f1cf8f0cbacde29158',1973,'','','raw',1,'C ''**- i-ci *■
Approved For Release 2001/03/03 TCIA4RCTP78-05927A0001 000401 18-5
t August 1971
memorandum for* MMH m
QF8/INT/RC/IE
25X1 A
SUBJECT
REFERENCE
s Release of National Intelligence Survey
B*pi«JjatelU|eTC^Paethooj^^h^^^
* Tw9oI^^ovemi»e^97^^^^^^^
1. la ntpesn to your request, the Director, OBGI, has
approved release of the attached UNCLASSIFI ED edition of the
Basic Intelligence Factbook. dated July 197$,
1 (','385336b454653592363e2ad9ebc79f58df4aeef75857e1faec2a5105b8dc9245','internet-archive','CIA-RDP78-05927A000100040118-5','txt','ca0d609388dd746f8c4766cfb37aae23f860256fc176dc06b30131bd8005b5a9','https://archive.org/download/CIA-RDP78-05927A000100040118-5/CIA-RDP78-05927A000100040118-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83848be830a7134d9a879fcb6c00d7e1d0d6eb69636dd2e2dd9ca3e3f5071d6e',1973,'','','raw',1,'Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
UNITED STATES INTELLIGENCE BOARD /
USIB-D-71. a
31 October 1975
MEMORANDUM FOR THE UNITED STATES INTELLIGENCE BOARD \\
\\
\\
SUBJECT : A Guide to the National Intelligence \\
Community''s Production Organizations
and Their Products
ILLEGIB
REFERENCE : USIB-D-71.11/15, 28 July 1975
1. The attached Guide, prepared by the Product Review Division
[PRD] of the Intelligence Community Staff [ICS] at the request of the
National Security Council Intelligence Committee [NSCIC] Working
Group, is forwarded for your information. A draft of this paper was
circulated [see reference] to the USIB Principals for their comments
and suggestions, which have, for the most part, been incorporated in
the attached study.
25X11
2. In accordance with the request of the NSCIC Working Group, the
PRD is distributing additional copies to various intelligence community
consumers,
STAT
tC _YBRUCE A, LOWE
Executive Secretary
Attachment
Exempt from general
declassification schedule of E.O, 11652
exemption category 5B(1),@), (3)
Automatically declassified on
Date Impossible to Determine
25X11
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
= aad SECRET
=—
CI)
=
_
A Guide to the
_ National Intelligence
Community''s Production Organizations
2s and Their Products
a
_—_
it
od
om
Prepared by the Product Review Division of the Intelligence Community
= Staff in response to a request from the Working Group of the National Security
Council Intelligence Committee.
= Questions or comments on this publication should be addressed to Chief
Product Review Division, Intelligence Community Staff, CIA Headquarters
Building, Washington, D.C. 20505, | STAT
~~
SECRET
elt
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11
: CIA-RDP82M00591R000400010010-7
ai > SECRET
“ CONTENTS
Page
ad I, INTRODUCTION? §.. 5030-0194 guSuleenode d puteelchia boy buddy beeen 1
Il. ORGANIZATIONS FOR PRODUCTION .......................... 1
me A. National Intelligence Officers ................................. I
B. Central Intelligence Agency ................................... 2
C. Defense Intelligence Agency ...... «1.2.0.0... 3
al D. State Department/Bureau of Intelligence and Research ........... 4
E. Other Intelligence Community Members ........................ 4
Ill. MAJOR PRODUCTS .......00000 0.00 5
vs A. National Estimates ...0.000000000 0 ee. 5
B. Defense Estimates ......00.00 0c cee cece cee. 5
ay C. State/INR Analytical/Estimative Papers’ ee uence kit ees ned 6
D. Current Intelligence ......0.00000000000000.0.....0..0....000... 6
Be WARTS 55) Sra eacash eh leg Sl Bitte Mol eR Oe te gc tg ee cin 7
-~
ANNEXES
= Page
A—Selected Intelligence Products .................................. 9
B—National Intelligence Officers ................................. 13
= C—CIA Production Offices... 000.0.0.0.000.0.....0...0.... 14
D—DIA Production Offices ...000.000.0.00000..00................. 1
a E—Defense Intelligence Officers .................................. 16
F-—State/INR Production Offices .................................. 17
a
tl
a
i
SECRET
—
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11
: CIA-RDP82M00591R000400010010-7
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
ms ~~ SECRET ee,
= A Guide to the
National intelligence
= Community’s Production Organizations
and Their Products
_
I. INTRODUCTION
= This paper indicates which elements of the intelligence community are pri-
marily responsible for national intelligence production. It also identifies and
briefly describes several selected end products of the intelligence process. Much
wait of the data in this paper is summarized in matrix form at Annex A.
Il. ORGANIZATIONS FOR PRODUCTION
aaa A. National Intelligence Officers
1. By memorandum of 3 October 1973, the Director of Central Intelligence
(DCI) advised the United States Intelligence Board (USIB) of the estab-
=
lishment of a system of National Intelligence Officers to replace and expand
the functions previously performed by the Board and Office of National Esti-
= mates, which had been disbanded.
2. The DCI memorandum states that each National Intelligence Officer
(NIO) is his personal representative and reports directly to him. By tasking
abs USIB members through the normal chain-of-command, the NIOs satisfy the
requirements for National Intelligence Estimates, for the responses to National
Security Study Memoranda, and for DCI briefings. The task of each NIO
a is “to provide contact laterally . . . across the functionally organized intelligence
community and with customers and outside consultants as required” to provide
coordinated products using panels of experts or ad hoc committees.
= 3. The specific tasks of the National Intelligence Officers are to:
a. identify customer needs for national intelligence;
ao b. evaluate the intelligence product and the effectiveness of programs;
ce. specify uncertainties which require collection guidance; and
d. report problems in analysis, production, or national policy on which
a national intelligence might offer assistance.
4. The directive states that National Intelligence Officers will maintain
close personal contact with the National Security Council (NSC) Staff and
—s other principal intelligence consumers and contributors. Every NIO will also
present fully objective presentations of alternative views.
=
1
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
SECRET
5. The Director of Central Intelligence placed the NIOs outside the CIA
organization and created a Deputy to the DCI for the NIOs. The directive
states that NIOs may be appointed for geographic areas or functions as the
DCI may deem necessary from time to time. NIOs are chosen for their
expertise, not their affiliation, and may be selected from the military services,
CIA, DIA, NSA, State, and other government departments, academia, or
industry. A list of the current NIOs and their assignments is attached (Annex 8).
6. In addition to overseeing various kinds of national intelligence production,
the NIOs have specific responsibility (as noted above) for the preparation,
coordination, and dissemination of the four major types of national estimative
papers and Intelligence Alert Memoranda.
BR. Central Intelligence Agency
J. As indicated on the chart at Annex C, the bulk of CIA’s production
responsibilities rests with the Directorate of Intelligence (DDI), in the fol-
lowing seven specialized offices:
a. Office of Current Intelligence (OC1)—This office produces all-source
current intelligence in support of the White House, the NSC and other
agencies as directed by the DCI. OCI, in conjunction with other CIA
offices, prepares the National Intelligence Daily (NID), the Weekly Review,
and the Weekly Summary. It provides the managing editor and other staff
support for the National Intelligence Bulletin (NIB), including its actual
production and preparation for dissemination. At the request of the DCI
and NIOs, it prepares special studies in support of the policymaking appa-
ratus of the government and the production of National Intelligence Esti-
mates (NIEs).
b. Office of Economic Research (OER)—OER produces all-source eco-
nomic analyses of the national policies, internal structure, recent develop-
ments, future prospects, external policics, and strengths and weaknesses
of all foreign countries of significance to US policy. OER publishes two
weeklies, the Economic Intelligence Weekly and International Oil Develop-
ments, as well as numerous intelligence memoranda representing detailed
economic analysis on major intelligence topics, Its analysts participate in
the preparation of all national products which have an economic dimension.
c, Office of Political Research (OPR)—This office produces political
and interdisciplinary studies of key intelligence issues affecting important US
interests including, for example, analyses of the external actions and policies
of major countries and regions as well as studies that describe and forecast
the interaction of social, political, economic and military considerations in
the development of major policies of these countries. During the past year,
among others, OPR has published papers on possible longer-term (5-10
years) developments in Sino/Soviet relations, on authoritarian movements
in southern Europe, and on Japan’s changing leadership.
d. Office of Strategic Research (OSR)—OSR produces all-source military
and military-economic intelligence on foreign military forces with principal
emphasis on the USSR, the PRC, and other Communist countries. It responds
to requirements from the NSC Staff and the Office of the Secretary of
2
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
234
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
acd SECRET
Defense. It provides support to the SALT and MBFR delegations and to
the Verification Panels. It provides major support to the NIOs in the pro-
duction of NIEs on Warsaw Pact forces and Soviet intercontinental forces.
OSR also produces both intelligence reports and current intelligence as an
input to the publications of OCI.
e. Office of Geographic and Cartographic Research (OGCR)—This office
is responsible for producing all-source basic and geographic intelligence and
for providing map reference and specialized all-source cartographic services.
It coordinates and produces the National Basic Intelligence Factbook.
f, Central Reference Service (CRS)—CRS produces all-source biographic
intelligence on leading non-military foreign personalities. |
g. Foreign Broadcast Information Service (FBIS)—Although not a pro-
ducer of all-source intelligence in the sense that the other six DDI offices
described above are, FBIS produces daily reports of radio broadcasts which
receive wide dissemination inside and outside of the intelligence community.
It also produces the weekly Trends in Communist Media, providing analysis
based on media sources it monitors.
2, CIA’s Directorate of Science and Technology (DDS&T), in addition to
collection and processing responsibilities, has major production responsibilities.
These are concentrated in the following two elements:
a. Office of Scientific Intelligence (OSI1)—OSI produces all-source intelli-
gence on foreign scientific and engineering research and advanced tech-
nology in the physical and life sciences. Current intelligence items in these
areas are contained in the Weekly Surveyor. A monthly compilation of ana-
lytical articles is provided in the Scientific Intelligence Digest and in-depth
studies are published as Scientific and Technical Intelligence Reports
(STIRs).
b. Office of Weapons Intelligence (OW1)—tThis office is responsible for
producing all-source intelligence on the technical capabilities of foreign
offensive and defensive weapons systems and space systems. OWI produces
a daily Weapons Intelligence Summary, prepares special studies on weapons-
related issues (mainly STIRs), and contributes heavily to the Weekly
Surveyor and the Scientific Intelligence Digest.
C. Defense Intelligence Agency
1. The organization of the Defense Intelligence Agency for production
is given on the chart at Annex D. Four major components are involved.
2. Defense Intelligence Officers (DIOs )—The responsibility of DIOs within
DIA is similar to that of the NIOs with respect to the community as a whole.
A list of the current DIOs and their assignments is attached (Annex E).
3
SECRET
20X1
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
SECRET
3. Deputy Director for Intelligence (D1)—All-source finished general in-
telligence is produced by this directorate, including current intelligence (daily
reports and memoranda) and studies in the area of military capabilities.
Studies and reports are produced on such subjects as military economics,
demography, terrain, transportation, and escape and evasion. This directorate
develops and maintains all target systems and produces assessments of bomb
damage and research on physical vulnerability. It also makes in-depth assess-
ments of military operations. DI produces the Defense Intelligence Notice
(DIN) and the DIA Intelligence Appraisal series as well as contributing to
the NID and NIB.
4. Deputy Director for Science and Technology (DT)—This directorate has
three divisions which produce scientific and technical intelligence in their
designated areas: Nuclear Energy and Applied Sciences, Weapons and Systems,
and Electronics and Command and Control. Over 200 annual products, cata-
logued in the Scientific and Technical Intelligence Register (STIR}, provide
military S&T data and analysis at several classification levels to developers,
operators, and leaders.
5. Deputy Director for Estimates (DE)—This directorate produces all DIA
estimates on foreign military strategies, policies and capabilities primarily for
DoD planners and policymakers. It is the primary source of military intelli-
gence estimates for national-level authorities, other governmental authorities
and for certain allies. DE works with the NIOs, DIOs and other departments
and agencies in production of national estimates and other estimative studies
and memoranda.
D. State Department{ Bureau of Intelligence and Research (INR)
{. INR’s products are intended primarily to support departmental needs
but are also distributed to other elements of the intelligence community. INR
analysts do, however, participate actively in the preparation and coordination
of national intelligence products, such as NIEs, the NID, and the NIB.
2. As indicated by the chart at Annex F, INR consists of three major produc-
tion elements. Most of the analytic and estimative work is done in the Re-
search Directorate, which is subdivided into four geographic and four func-
tional offices.
3. The Current Intelligence Staff, in addition to producing the daily Brief-
ing Notes for senior officers of the Department, is heavily engaged in the
preparation and presentation of oral briefings.
4. The Office of External Research manages the Department''s program of
contract research on foreign affairs; arranges for outside experts to work with
the Department as consultants, conferees and seminar leaders; coordinates
other government-supported research on foreign affairs; and collects and dis-
seminates academic research papers and reports.
E. Other Intelligence Community Members
The intelligence organizations listed above are the primary producers of
finished national intelligence in the United States. Additionally, other members
of the intelligence community, including Treasury, National Security Agency
4
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
ot |
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
=e -_ SECRET ws
(NSA), Environmental Research Development Agency (ERDA), and the mili-
a] tary services do publish intelligence information—some of which reaches a wide
readership outside the publishing organizations—that also contributes to meeting
the needs of national and departmental intelligence consumers. These issuances
ay are not addressed here because they were not viewed, by us at least, to be
‘within the scope of this paper.
III. MAJOR PRODUCTS
=
A. National Estimates
; 1. There are four major types of national estimative papers, as listed below.
~ They are prepared and coordinated among appropriate elements of the com-
munity under the sponsorship of the appropriate National Intelligence Officer.
a 2. National Intelligence Estimate (NIE)—The NIE is intended for NSC-
level policy-making authorities. Topics selected for treatment in the NIE for-
mat are limited to those of high policy concern. The exposition is normally
structured in such a way as to illuminate policy issues and, when appropriate,
al the choices which may be open to policy authorities. If back-up material is
required, it is often published in separate annexes. NIEs are published by
the DCI after approval by USIB.
3. Special National Intelligence Estimate (SNIE)—SNIEs differ from NIEs
in that they address specific policy problems immediately on the horizon.
They are generally shorter and prepared more quickly than NIEs.
4, National Intelligence Analytical Memorandum (NIAM)—The NIAM is
intended for officials involved in policy support activities below the NSC
level. Topics selected for treatment in NIAMs are of important policy concern
but usually do not have the high priority of NIE topics. The analysis and sup-
porting evidence in a NIAM will normally be exposed in some detail. NIAMs
are issued by the DCI generally after telephonic approval by the USIB.
5. Interagency Intelligence Memorandum (IIM)—The key difference be-
tween an IIM and other estimates is the fact that an ITM does not require
USIB concurrence. The IIM is a coordinated effort of several agencies which
addresses relatively broad and complex issues and is intended for a high-level
audience.
- B. Defense Estimates
1. DIA produces four main types of estimative papers. They focus primarily
on military subjects and are addressed primarily to National and DoD con-
sumers.
2. Defense Intelligence Estimates (DIE) are coordinated with the intelli-
= gence chiefs of the services whereas Defense Intelligence Estimate Memo-
randa (DIEM) are not coordinated. DIEMs often are used as vehicles for
more immediate estimative responses than are possible with DIEs. Special
_ Defense Intelligence Estimates (SDIE) generally address subjects or issues
which are narrower in scope or more specific in impact than the subjects of
DIEs. SDIEs are coordinated with the services. Defense Intelligence Analytical
5
SECRET
—_
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
SECRET
Memoranda (DIANM), which are not coordinated with the services, are used
to address major analytical problems and often include a historical review.
‘They do not necessarily include a forecast as an estimate would.
C. State/INR Analytical/Estimative Papers
INR produces Reports designed to give State Department officers back-
ground information on policy-related subjects or to draw their attention to
phenomena of potential importance for the security or foreign relations of
the United States. These studies may, for example, examine the social and po-
litical factors shaping the outcome of an election, changing patterns of third-
world cooperation and competition, the implications of trade arrangements, the
issues to be discussed at an international conference, or general political, eco-
nomic and military developments. They may speculate on the thoughts and plans
of national leaders. Wherever possible, estimates of likely prospects are included
in the studies.
1). Current Intelligence
l. Dailies—
a. National Intelligence Daily--A compilation in tabloid format of key
items of current intelligence produced six days a week by CIA’s Office of
Current Intelligence. To the extent possible, it is prepared in consultation
limited, and there is no classification limit.
b. National Intelligence Bulletin—With CIA’s Office of Current Intelli-
gence acting as the DCI’s executive agent, the NIB is published six days
a week by an interagency editorial board. The NIB receives a relatively wide
dissemination. TS COMINT is the highest classification included in the
NIB.
c. Defense Intelligence Notices—Prepared by DIA, DINs each discuss
a single development of current intelligence interest. They are issued ir-
regularly (normally several a day) and are disseminated in as near real-time
as practicable. Those items which deserve immediate attention to support
current decision making are identified as Special DINs. Distribution is
largely within the DoD and to the military commands world-wide.
d. DIA Executive Summary—This summary is a brief recapitulation of
the DIA DINs and Intelligence Appraisals published during the preceding
24 hours. It is produced six days a week, and its distribution is very limited.
9. Weeklies—
a. DIA Weekly Intelligence Summary—A world-wide compilation of
items of current intelligence interest issued on Fridays.
b. DIA Intelligence Appraisal—DIA’s current appraisals are issued ir-
regularly (normally one or two a week) and contain in-depth analysis, re-
flect community-wide consultation, and present greater graphics support
than is possible in the DINs.
6
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
shal
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
ad SECRET w
aal
c. CIA Weekly Review—Issued every Friday by OCI, this review reports
a5 and analyzes significant developments of the week through noon on Thurs-
day. Material in this periodical is at the TS/COMINT levcl. An expurgated
version of the Review at the Secret level, entitled The Weekly Summary,
is distributed more widely.
A al
d. CIA Weekly Surveyor. This publication, which is distributed through-
out the Intelligence Community, contains items briefly analyzing current
a significant material received in CIA’s Office of Scientific Intelligence.
e. Economic Intelligence Weekly—An analysis of major foreign economic
developments and trends, published each Wednesday morning by CIA’s
pee Office of Economic Research for top-level policymakers. It is accompanied
by an unclassified annex, Economic Indicators, which provides the latest
statistical data on domestic and external economic activities of the leading
non-Communist developed countrics.
~
f. International Oil Developments—An analysis of major developments
in foreign oil production, consumption, prices and policies, published each
Thursday morning by OER for officials dealing with energy matters. It is
- : af , 2
accompanied by an unclassified annex, International Oil Developments:
Statistical Survey, which presents comprehensive data for leading producing
and consuming countries.
2
E. Warning
j. Intelligence Alert Memorandum (IAM)—An interagency publication
] issued by the DCI on behalf of the community. It is addressed to the members
of WSAG and disseminated, inter alia, to all USIB Principals. It provides ex-
plicit warning of possible developments abroad of major concern to the US
and is normally prepared under the direction of the appropriate NIO.
2. Strategic Warning Notice—Issued by the Special Assistant to the DCI
for Strategic Warning to the DCI, who will notify the President and NSC
eal or take such other action as he deems necessary. When time is of the essence,
the Special Assistant may issue such notices directly to the President and NSC
with concurrent dissemination to the DCI and USIB Principals.
- 3. DIA Warning Appraisal—This publication is a form of time-sensitive
alerting intelligence which contains greater depth of analysis than that per-
mitted in a Special DIN.
ol 4. Strategic Warning Staff (SWS) Monthly Report—This publication is pre-
pared by the SWS for the DCI and is disseminated within the USIB Com-
mittees. It summarizes developments bearing on the staff''s capability to provide
w','d6f5963283024d3dd3ec8ed40afd677528eeee76b0c960b23f47facf8685411c','internet-archive','cia-readingroom-document-cia-rdp82m00591r000400010010-7','txt','8de2a9bc25d8d13c8fb7f11471776bf6bad782b130029de59a262926a186ae5b','https://archive.org/download/cia-readingroom-document-cia-rdp82m00591r000400010010-7/cia-rdp82m00591r000400010010-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0c221379c5f2ca4293a17045038bf93f80c252a5e027e486240d5ba6987c833',1973,'','','raw',2,'w strategic warning.
—_
~
_
7
SECRET
=
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
25X14 Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
\\
Next 1 Page(s) In Document Denied
Q
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
—_
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
wo?
ANNEX B
SECRET
~w
NATIONAL INTELLIGENCE OFFICERS
Deputy to the DCI for National Intel-
ligence Officers','a4865a91f389c3e769bd671ce07eebd1c55ab31f3c97870c403b8b88377d528b','internet-archive','cia-readingroom-document-cia-rdp82m00591r000400010010-7','txt','8de2a9bc25d8d13c8fb7f11471776bf6bad782b130029de59a262926a186ae5b','https://archive.org/download/cia-readingroom-document-cia-rdp82m00591r000400010010-7/cia-rdp82m00591r000400010010-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10a15792c637d897e57df7b66a0b4a74d492891e6093bc5d6e9737da0a6f0601',1973,'CN','China','raw',3,'CONVENTIONAL FORCES
ECONOMICS
JAPAN/PACIFIC
LATIN AMERICA
MIDDLE EAST
SOUTH/SOUTHEAST ASIA
SPECIAL ACTIVITIES
STRATEGIC PROGRAMS
USSR and EAST EUROPE
WESTERN EUROPE
13
SECRET
George A. Carver, Jr.
James Lilley
RAdm Daniel E. Bergin, Jr.
Hans Heymann
Evelyn S. Colbert
Louis Marengo
Samuel M. Hoskinson
William A. Christison
D. Barry Kelly
Howard Stoertz
John Whitman
Keith Clark
STAT
STAT
STAT
STAT
STAT
STAT
STAT
STAT
STAT
STAT
STAT
STAT
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
ANNEX C
CIA Production Offices
DIRECTOR
CIA
m
a
=
°
=
=z
a
a
Ss
=
i
Deputy Director fs |
Intelligence Bulletin Science & Technology
Editor National
Intelligence Daily
134a34S
Lal
Office of Economic Research
Office of Political Research
Office of Geographic &
Cartographic Research
Foreign Broadcast
Information Service
Central Reference Service
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
LaaDI$
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
25X11
~@
©
Next 2 Page(s) In Document Denied
Pod
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
aa
— SECRET ed
—SECRET—
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7 |
Sie ect ie. . aieetie » et ati Hoe
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
‘ SECRET cad
25X11
| A Guide to the
National Intelligence
Community''s Production Organizations
and Their Products
October 1975
SECRET
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
a irieiteenatiatiiateenetheetriaeiinetieene wherein,
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7
w rae : ow :
mt
Warning Notice
Sensitive Intelligence Sources and Methods Involved
NATIONAL SECURITY INFORMATION
Unauthorized Disclosure Subject to Criminal Sanctions :
25X11
Declassified in Part - Sanitized Copy Approved for Release 2014/02/11 : CIA-RDP82M00591R000400010010-7 o','90d41405f55d8909b08dc85633e21d6a0cdb44dd658f2be824dc680d943b6ece','internet-archive','cia-readingroom-document-cia-rdp82m00591r000400010010-7','txt','8de2a9bc25d8d13c8fb7f11471776bf6bad782b130029de59a262926a186ae5b','https://archive.org/download/cia-readingroom-document-cia-rdp82m00591r000400010010-7/cia-rdp82m00591r000400010010-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c38f637afed887d1f6fe6f8d9b3733cd2cfa45fec0954f9e2bbd383d71c8e78a',1973,'','','communications',5,'Ratlroads: 4,991 mi.; 4,940 mi. 4''8 1/2” gage, 5] mi, double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 402 mi.; refined products, 1,277 mi.
Ports: 10 major, 35 minor
Merchant marine: 88 ships (1,000 GRT or over) totaling 596,300 GRT, 829,500 DWT;
includes 12 passenger, 52 cargo, 11 tanker, 11 bulk, 2 specialized carrier
Civil air: 17 major transport aircraft
Airfields: 119 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 18 with runways 8,000-11,999 ft., 25 with runways
4,000-7 ,999 ft.; 2 seaplane stations
Teleconmunications: excellent international radioconmunication and fair domestic
telecommunication services; 577,000 telephones; 3.1 million radio and 50,000
TV receivers; 39 AM, 2 FM, and 7 TV stations; communications satellite ground
station to be operational in 1972 .
DEFENSE FORCES:
Military manpower: males 15-49, 9,585,000; 5,655,000 fit for military service;
about 402,000 reach military age (20) annually
Personnel: army 375,000 navy 39,500, air force 54,600 (1,082 pilots),
gendarmerie 75,000 (S)
Major ground units: 3 armfes, 10 corps with corps troops, 13 infantry divisions,
2 mechanized divisions, 1 mechanized brigade, 1 armored division, 4 separate
armored brigades, 2 armored cavalry brigades, 4 infantry brigades, 2 regiments
(1 border, 1 armored cavalry), 32 battalions (20 artillery, 11 border, 1 on
Cyprus), and 1 commando brigade; army aviation companies with about 5 aircraft
each are assigned to each army, corps, and divisfon
438
Seca
‘Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
SECRET
DEFENSE FORCES (cont''d):
Ships: 15 destroyers, 1 destroyer escort, 16 submarines, 71 patrol craft, 33
mine warfare, 62 amphibious craft, 38 auxiliary, 47 service
Aircraft: 1,223 including 428 (nonjet) in army aviation, 4 (nonjet) in naval
air, 791 (602 jet) in air force
Missiles: 8 SAM squadrons (Nike Ajax/Hercules)
Supply: mostly dependent on foreign sources, primarfly U.S., Canada, and West
Germany; manufactures some smatl arms, tru adequate quantities of
ammunition; builds some of its naval ships
Military budget: for fiscal year ending 28 February 1973, $599.7 million;
about 19% of central government budget
INTELLIGENCE AND SECURITY:
National Intelligence Organization (MIT), including Turkish National Security
Service Directorate (TNSS), domes tic/foreign; Turkish General Staff, J-2
Section, Intelligence Branch, domestic/foreign; Turkish National Police,
domestic; Ministry of Foreign Affairs, foreign; Gendarmerie, domestic
439
Approved for Release: 2018/04/27 C06726997','c7a3c13800a7f80209df199f4e15cd31ac06b3366a1526781ce16a01816910d3','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e98bc91f7916b331e9c294c01ea35742bb780f8dfa848472ead957022e4b6247',1973,'','','communications',5,'Railroads: 4,991 mi.; 4,940 mi. 4''8 1/2" gage, 51 mi. double track: 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. grave? or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 594,900 GRT, 826,600 DWT;
includes 12 passenger, 52 cargo, 11 tanker, 10 bulk, 2 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 123 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 22 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international radiocommunication and fair domestic
telecommunication services; 654,500 telephones; 3.94 million radio and 133,000
TV receivers; 39 AM, 2 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,707,000; 5,730,000 fit for military service;
about 402,000 reach military age (20) annual ly
78,000) ee navy 39,500, air force 54,600 (1,082 pilots), gendarmerie
75 ,000
Major ground units: 3 armies, 10 corps with corps troops, 13 infantry divisions,
2 mechanized divisions, 1 mechanized brigade, 1 armored division, 4 separate
armored brigades, 2 armored cavalry brigades, 4 infantry brigades, ] border
regiment, 34 battalions (22 artillery, 11 border, 1 on Cyprus), and 7
airborne/commando brigade; army aviation companies with about 5 aircraft
each are assigned to each army, corps, and division
Ships: 13 destroyers, 12 submarines, 71 patrol » 28 mine warfare, 60
amphibious craft, 40 auxiliary, 47 service
Aircraft: 1,252 including 437 (nonjet) in arny aviation, 15 (nonjet) in naval
air, 800 (605 jet) in air force
Missiles: 8 SAM squadrons (Nike Ajax/Hercules)
Supply: mostly dependent on foreign sources, primarily U.S., Canada, and West
Germany; manufactures some small arms, trucks and adequate quantities of
ammunition; builds some of its naval ships
448
““SECRE
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
_ SEsRET,
DEFENSE FORCES (cont''d):
Military budget: for fiscal year ending 28 February 1974, $792.8 million; about
16% of central government budget
INTELLIGENCE AND SECURITY:
National Intelligence Organization (MIT), including Turkish National Security
Service Directorate (TNSS), domestic/foreign; Turkish General Staff, J-2
Section, Intelligence Branch, domestic/foreign; Turkish National Polf
domestic; Ministry of Foreign Affairs, foreign; Gendarmerie, domestic
449
Approved for Release: 2018/04/27 C06727039','9d4a2b2fc51ea58b3df2ca018de5da87ff79463fa05f18e4af69d388d6b68cd4','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df1d69581a4ba6e7fdf621e6854de782a711914d70300ea4b4c28f4063f10e31',1973,'','','communications',5,'Railroads: 4,991 mi.; 4,940 mi. 4''8 1/2" gage, 51 mi. double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi1, 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 594,900 GRT, 826,600 DHT;
includes 12 passenger, 52 cargo, 11 tanker, 10 bulk, 2 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 123 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 22 with runways
4 ,000-7 ,999 ft.; 2 seaplane stations
Teleconmunications: excellent international radiocommunication and fair domestic
telecommunication services; 654,500 telephones; 3.94 million radio and 133,000
TV receivers; 39 AM, 2 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,707,000; 5,730,000 fit for military service;
about 402,000 reach military age (20) annually
Military budget: for fiscal year ending 28 February 1974, $792.8 million; about
16% of central government budget
346
Approved for Release: 2018/04/27 C06726998','3f12afb7679ed6d6fbd9995b63f1709fd9f751fa11e529d9e6974f040abec1d6','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f06cc277eb9fd41278044f1ac5e5e02859e4105627451b304e13b57fe16dc767',1973,'','','communications',5,'Railroads: 6 mi. (single track) 5''O"-gage, government-owned spur of Soviet line
Highways: 10,740 mi.; 420 mi. concrete, 980 mi. bituminous surfaced, 2,100 mi.
gravel, 3,630 mi. improved earth, and 3,610 mi. unimproved earth
Inland waterways: total navigability 760 mi.; steamers use Amu Darya
Ports: only minor river ports
Civil air: 8 major transport aircraft
Airfields: 72 total, 42 usable; 9 with permanent-surface runways; 7 with runways
8,000-11,999 ft., 10 with runways 4,000-7,999 ft.
Teleconmunications: limited telephone, telegraph, and radiobroadcast services,
barely sufficient to meet civil and military requirements; 13,967 telephones;
est. 400,000 radio receivers; no TV receivers; 1 AM, no FM, no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 4.7 million; 2.5 million fit for military
service; about 165,000 reach military age (22) annually
Supply: dependent on foreign sources, almost exclusively the U.S.S.R.
Military budget: for fiscal year ending 31 March 1972, $36.8 million; 20.3%
of total budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','d75894b20ea1983705501a1e5272984690a4d2ea5691b438f1119070db28b83c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8861079650a9a2b25c665680268a7dab1f558c4c21856d79e756ff2eb212cc00',1973,'AL','Albania','communications',6,'LAND:
11,100 sq. mi.; 19% arable, 24% other agricultural, 43%
forested, 14% other
Land boundaries: 445 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 225 mi. (including Sazan Island) aes
Railroads: 127 mi. standard gage, single track; government owned (1972)
Highways: 3,100 mi.; 300 mi. paved, 1,200 mi. crushed stone and/or gravel, 1,600
mi. improved or unimproved earth (1972)
Inland waterways: 27 mi. plus Albanian sections of Lake Scutari, Lake Ohrid,
and Lake Prespa (1972)
Freight carried: rail -- 3.0 million short tons, 123.3 million short ton/mi. (1971);
highways -- 42.9 million short tons, 616.5 million short ton/mi. (1970)
Ports: 2 major (Durres, Vlore), 2 minor (1972) (C)
Merchant marine: 1] cargo ships (1,000 GRT or over) totaling 53,000 GRT, 72,700
DWT, includes 8 cargo, 3 bulk
Pipelines: crude oi], 110 mi.
Civil air: no major transport aircraft (1972)
Airfields: 11 total; 4 with permanent-surface runways; 6 with runways 8,000-
11,999 ft., 5 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 542,000; 448,000 fit for military service; 25,000
reach military age (19) annually
Military budget: for fiscal year ending 31 December 1972, 588,000,000 leks;
about 8.7% of total budget
Approved For Release 2004/69/15 : CIA-RDP79-01051A000500010001-1
WATER:
Railroads: 2,414 mi.; 1,660 mi. standard gage, 663 mi. 3''5 9/16" gage, 91 mi.
meter gage; 188 mi. electrified; 120 mi. double track
Highways: 40,600 mi., of which 17,000 mi. are concrete or bituminous and the
remainder gravel or crushed stone
Ports: 9 major, 8 minor
Merchant marine: 13 ships (1,000 GRT or over) totaling 124,000 GRT, 150,900 DWT;
includes 5 cargo, 1 tanker, 3 bulk, 4 specialized carriers
Pipelines: crude of], 2,250 mi.; refined products, 180 mi.; natural gas, 1,420 mi.
Civil air: 22 major transport aircraft
Airfields: 249 total, 196 usable; 56 with permanent-surface runways; 19 with
runways 8,000-11,999 ft., 113 with runways 4,000-7,999 ft.; 3 seaplane
stations
Telecommunications: adequate domestic and international facilities in the north,
primarily radio communications in the desert; 182,000 telephones; 1,150,000
radio receivers; 250,000 TV receivers; 16 AM and 13 TV stations; 3 submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,645,000; 2,090,000 fit for military service;
average number reaching military age (19) annually 135,000
Supply: dependent on foreign sources; in the past on France and to a small
extent on a number of non-Communist countries and China; materiel (including
modern heavy weapons; surface-to-air, air-to-air, and naval missiles; aircraft,
and naval ships) from the U.S.S.R. now predominant
Military budget: for fiscal year ending 31 December 1972, $108,200,000;
approximately 5.5% of national budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15,5 GlA;RDP79-01051A000500010001-1
LAND:
180 sq. mi.
Land boundaries: 65 mi.
Railroads: none
Highways: about 60 mi.
Civil air: no major transport aircraft
Airfields: none
Telecommunications: international circuits to Spain and France; 2 AM, 1 FM, 1 TV
station; about 1,700 telephones; 8,000 radio receivers, 2,800 TV receivers
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
serene tones Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Andorra has no defense forces; Spain and France are responsible for protection
as needed
Approved For Release 2004f09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/1 Wy GGATROP79-01051A000500010001-1
LAND:
481,000 sq. mi.; 1% cultivated, 44% forested, 22% meadows
and pastures, 33% other (including fallow)
Land boundaries: 3,150 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. (navy)
(fishing 12 n. mi.)
Coastline: 1,000 mi.
Railroads: 1,918 mi.; 1,724 mi. 3''6" gage, 194 mi. 1''11 5/8" gage
Highways: 45,000 mi.; 3,260 mi. bituminous-surface treatment, 1,000 mi. crushed
stone or gravel, 25,000 mi. earth :
Inland waterways: 2,000 mi. navigable
Ports: 3 major
Pipelines: crude oil, 111] mi.
Civil air: 12 major transport aircraft
Airfields: 455 total, 395 usable; 19 with permanent-surface runways; 1 with
runway over 12,000 ft., 5 with runways 8,000-11,999 ft., 56 with runways
4 ,000-7 ,999 ft.; 2 seaplane stations
Telecommunications: simple network of low-capacity open-wire and radio-relay
facilities; 25,300 telephones; 100,000 radio receivers; 21 AM, 7 FM, and no
TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,453,000, fit for military service, 725,000;
average number reaching military age (20) annually about 60,000
Defense is responsibility of Portugal
Supply: dependent on Portugal
Military budget: for fiscal year ending 31 December 1972 $82.7 million; about
18.2% of total budget
Approved For Release 2004/80/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 €1AyRDP79-01051A000500010001-1
LAND:
108 sq. mi.; 54% arable, 5% pasture, 14% forested,
9% unused but potentially productive, 18% wasteland
and built on
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 95 mi.
Railroads: 25,000 mi.; 2,000 mi. standard gage (4''8 1/2"), 13,750 mi. broad
gage (5''6") 8,750 mi. meter gage (3''3 3/8"), 500 mi. 2''5 1/2" gage;
about 1,035 mi. double and multiple track; 76 mi. electrified
Highways: 125,000 mi., of which 21,000 mi. paved, 17,000 mi. gravel, 41,000
mi. improved earth, and 46,000 mi. unimproved earth
Inland waterways: 6,800 navigable mi.
Ports: 7 major, 21 minor
Merchant marine: 177 ships (1,000 GRT or over) totaling 1,240,500 GRT,
1,677,100 DWT; includes 6 passenger, 94 cargo, 59 tanker, -10 bulk;
8 specialized carriers; includes 2 naval tankers and 3 naval combination
cargo-transport ships sometimes used commercially
Pipelines: crude oi], 1,960 mi.; refined products, 1,370 mi.; natural
gas, 4,060 mi.
Civil air: 58 major transport aircraft
Airfields: 2,525 total, 1,874 usable; 71 with permanent-surface runways;
] with runway over 12,000 ft., 20 with runways 8,000-11,999 ft., 254 with
runways 4,000-7 ,999 ft.; 10 seaplane stations
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
14
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d):
Telecommunications: foremost in telecom facilities in South America; improving
telephone network has 1.85 million sets, radio relay widely used, 2
communications satellite ground stations; estimated 6.5 million radio receivers
and 3.5 million TV sets; 120 AM, 6 FM, and 49 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 6,179,000; 4,575,000 fit for military service;
average number reaching military age (20) annually about 210,000
Supply: produces some weapons, ammunition, and motor transport; past
dependence upon U.S., Canada, and Western Europe being shifted almost
exclusively to Europe
Military budget: proposed for fiscal year ending 31 December 1972,
$580,000,000 about 15% of total central government budget
Approved For Release 2004/09/15 : GIA-RDP79-01051A000500010001-1
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','077fc08df5251025e4477611d4416bb02ccc22fbdc7fb0b5a6ce9450de66503b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d0ae51e4a2e65ca3ea5353ee5ea25cfa39ba16f13fbbeaaaaaee1d2fec959bf',1973,'AT','Austria','communications',13,'Railroads: none
Highways: 555 mi.; 380 mi. paved, 100 mi. gravel, 20 mi. improved earth; 55 mi.
unimproved earth
Ports: 5 major, 9 minor
Civil air: 5 major transport aircraft
Approved For Release 2004/09/15 : VA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d):
Airfields: 58 total, 52 usable; 21 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 23 with runways 4,000-7,999 ft.; 4 seaplane
stations
Telecomnunications: telecom facilities highly developed, including 45,000
telephones in totally automatic system; tropospheric scatter link with
Florida; 90,000 radio receivers and 25,000 TV sets, 1 AM and 2 FM stations;
2 special coaxial submarine cables
Approved For Release 200409/15 : CIA-RDP79-01051A000500010001-1
Approved For Release OM ee
LAND:
230 sq. mi. plus group of smaller islands; 5% cultivated,
negligible forested area, remainder desert, waste,
or urban
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 100 mi.
Highways: 120 mi. bituminous surfaced; undetermined mileage of natural surface
tracks
Ports: 1 major
Merchant marine: 1 cargo ship (1,000 GRT or over) of 1,600 GRT, 2,600 DWT
Pipelines: crude oi], 35 mi.; refined products, 10 mi.; natural gas, 20 mi.
Civil air: 5 major transport aircraft (all registered in the U.K.)
Approved For Release 2004/09/15 : C1AA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d):
Airfields: 5 total, 3 usable; 1 with permanent-surface runway; 1 with runway over
12,000 ft; 1 with runway 4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent international radiocommunications; limited
domestic services; 11,600 telephones; 57,000 radio receivers; 10,000 TV sets;
1 AM radiobroadcast station; satellite earth station; tropospheric scatter
Bahrain-Qatar
DEFENSE FORCES:
Military manpower: males 15-49, 60,000; fit for military service 33,000
Military budget: for fiscal year ending 31 March 1971; $3,490,000, 6.9% of total
budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000 .
BANGLADESH 00500010001-1
55,000 sq. mi.; 79% arable (including cultivated and Ge ae
fallow), 5% waste or urban, 16% forested =
Land boundaries: 1,575 mi. sibery/)
WATER: a
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 360 mi.
Railroads: 1,732 mi.; 1,158 mi. meter gage, 554 mi. broad gage, 20 mi. narrow
gage; 87 mi. double track; government owned
Highways: 28,350 mi.; 2,450 mi. paved; 1,750 mi. gravel, 24,150 mi. earth
Inland waterways: 4,600 mi.; river steamers navigate main waterways
Ports: 1 major; 50 minor
Merchant marine: 5 cargo ships (1000 GRT or over) totaling 14,100 GRT, 17,800 DWT
Airfields: 61 total, 19 usable; 18 with permanent surface runways; 3 with runways
8,000-11,999 ft., 8 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 4 major transport aircraft
DEFENSE FORCES:
Military manpower: males 15-49, 15,340,000; 8,240,000 fit for military service
Ships: unknown
Supply: military supplies consist of those captured from West Pakistani forces
and materiel provided by India
Military budget: for fiscal year ending 30 June 1973, $52,980,130; about 5.4% of
the central government budget
Approved For Release 2004909/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/1 sahil AypeOP 79-01051A000500010001-1
LAND:
166 sq. mi.; 60% cropped, 10% permanent meadows, 30% built
on, waste, other
WATER: ;
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 60 mi.','aac04c2f5cebcf875bb1449ef08637c005580bdbaace4cdf394abeb3d55b31ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7ab5356a3d3f9f5a9bbf450ef28bf241abc2eb0d2a50747ba9223fd7dd0ad95',1973,'BR','Brazil','communications',16,'Railroads: none
Highways: 950 mi.; 800 mi. paved, 100 mi. gravel, 50 mi. improved earth
Ports: 1 major, 3 minor
Civil air: 4 major transport aircraft
Airfields: 1 with permanent-surface runway 8,000-11,999 ft.; 1 seaplane station
Telecommunications: islandwide automatic telephone system with 33,000
telephones; key international traffic transit center for Caribbean area;
tropospheric scatter link to Trinidad; VHF links to St. Vincent and St. Lucia;
96,000 radio and 22,000 TV sets, 2 AM, 1 FM, and 7? TV stations; | telegraph
_ submarine cable; communications satellite earth station
DEFENSE FORCES:
Military manpower: males 15-49, 48,000; 35,000 fit for military service; average
number reaching military age, (18) annually, 3,000; no conscription
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
LAND:
3,290,000 sq. mi.; 4% cultivated, 14% pastures, 14%
waste, urban, or other, 13% fallow, idle, or
woodlot, 55% forested
Land boundaries: 8,125 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 4,655 mi.
Railroads: 19,935 mi.; 17,586 mi. 3''3 3/8" gage, 2,085 mi. 5''3" gage, 121 mi.
4''8 1/2" gage, 143 mi. narrow gages; 1,62] mi. electrified
Highways: 591,000 mi.; 31,000 mi. paved, 560,000 mi. gravel or earth
Inland waterways: 31,000 mi. navigable
Ports: 6 major, 25 minor
Pipelines: crude of], 770 mi.; refined products, 290 mi.; natural gas, 24 mi.
Merchant marine: 219 ships (1,000 GRT or over) totaling 1,661,400 GRT, 2,438,500
DWT; includes 2 passenger, 143 cargo, 46 tanker, 19 bulk, 7 specialized
carrier; includes 3 naval tankers sometimes used commercially
Civil air: 102 major transport aircraft
Airfields: 2,856 total, 2,474 usable; 117 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 319 with runways 4,000-7,999 ft.; 18 seaplane
stations
Telecommunications: extensive telecom facility expansion programs; radio relay
widely used; communications satellite ground station; 2.3 million telephones;
est. 1] million radio and 7 million TV receivers; 900 AM, 150 FM, and 156
TV stations; 5 telegraph submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 22,757,000; 14,850,000 fit for military service;
1,145,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1972, $1,115 million; 18.7%
of federal budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
BRITISH HONDURAS
LAND:
8,870 sq. mi.3 38% agricultural (5% cultivated), 46%
exploitable forest, 16% urban, waste, water,
offshore islands or other
Land boundaries: 320 mi.
WATER:
Limits of territorial waters (claimed): 3.n. mi.
Coastline: 240 mi.
Railroads: none
Highways: 1,350 mi.; 150 mi. paved, 600 mi. improved (gravel, earth), 600 mi.
unimproved
Inland waterways: 514 mi. river network used by shallow-draft craft
Ports: 1 major, 4 minor
Civil air: no major transport aircraft
Airtields: 50 total, 30 usable; 2 with permanent-surface runways; 1 with
runway 4,000-7,999 ft.; 1 seaplane station
Telecommunications: 3,100 telephones in automatic and manual network; over 60,000
radio receivers; 2 AM stations
DEFENSE FORCES:
Military manpower: males 15-49, 29,000; 17,000 fit for military service; 1,500
reach military age (18) annually
Approved For Release 20042709/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 Oe me iced oe ke acess
LAND:
2,230 sq. mi.; 3% cultivated; 3% industry, waste, or
urban; 94% forested
Land boundaries: 237 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 100 mi.
Railroads: 6 mi. narrow gage (2'')
Highways: 750 mi.; 334 mi. paved (bituminous treated), 250 mi. gravel or stone,
266 mi. unimproved
Inland waterways: 130 mi.; navigable by shallow-draft craft
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d)
Ports: 2 minor (Bandar Seri Begawan, formerly Brunei, and Kuala Belait)
Pipelines: crude oi1, 84 mi.; refined products, 35 mi.; natural gas, 35 mi.;
crude oil and natural gas, 150 mi. under construction
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface runway; 1 with runway
over 12,000 ft., 2 with runways 4,000-7,999 ft.
Telecommunications: service throughout country is adequate for present needs;
international service good to adjacent Sabah and Sarawak; radiobroadcast
coverage good; 3,819 telephones; 13,000 radio sets; Radio Brunei
broadcasts from 3 stations and uses 4 mediumwave and 1 shortwave
transmitter
DEFENSE FORCES:
Military manpower: males 15-49, 38,000; 20,000 fit for military service; about
1,000 reach military age (18) annually
Ships: 4 coastal patrol, 4 river/roadstead patrol craft
Military budget: for fiscal year ending 31 December 1970, $9.8 million for the
military and $7.1 million for the police; about 15% of the total budget
Approved For Release 2004409/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
WATER:
Limits of territorial waters (claimed): 200 n. mi.
(fishing, 200 n. mi.)
Coastline: 4,000 mi.
Railroads: 5,511 mi.; 2,086 mi. 5''6" gage, 154 mi. 4''8 1/2" gage, 2,644 mi.
3''3 3/8" gage, 69 mi. 2''6" gage, 22 mi. 1''11 5/8" gage, 536 mi. specific gage
not given; 199 mi. double track; 711 mi. electrified
Highways: 45,300 mi.; 4,900 mi. paved, 19,900 mi. gravel, 20,500 mi. improved
and unimproved earth
Inland waterways: 451 mi.
Pipelines: crude oi], 470 mi.; refined products, 490 mi.; natural gas, 200 mi.
Ports: 10 major, 20 minor
Civil air: 48 major transport aircraft
Airfields: 450 total, 342 usable; 43 with permanent-surface runways; 2 with run-
ways 8,000-11,999 ft., 55 with runways 4,000-7,999 ft.; 7 seaplane stations
Telecommunications: extensive radio relay network; telephone network modern,
405,000 instruments; communications satellite ground station; est. 2.5 million
radio and 600,000 TV receivers; 145 AM, 30 FM, and 29 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,392,000; 1,795,000 fit for military service;
average number reaching military age (19) annually about 90,000
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
CHINA, PEOPLE''S REPUBLIC OF
LAND:
3.7 million sq. mi.; 11% cultivated, sown area extended by
multicropping, 78% desert, waste, or urban (32% of
this area consists largely of denuded wasteland,
plains, rolling hills, and basins from which about 3%
could be reclaimed), 8% forested; 2%-3% inland water
Land boundaries: 15,000 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 9,000 mi.
Railroads: none
Highways: 512 mi.; 9 mi. paved, 23 mi. gravel, 480 mi. earth
Ports: 1 major, 4 minor
Civil air: no major transport aircraft
*The possession of the Falkland Islands has been disputed by the U.K. and Argentina
(which refers to them as the Malvinas) since 1833.
101
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Airfields: 1 seaplane station
Telecommunications: government-operated open-wire and radiotelephone networks
providing effective service to almost all points on both islands; approx-
imately 550 telephones; 1 AM station and approximately 1,100 radiobroadcast
receivers
Approved For Release 2004/89/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Railroads: none
Highways: none
Ports: 7 major, 16 minor
Civil air: 3 major transport aircraft
Airfields: 11 total, 8 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 7 seaplane stations
Approved For Release 2004/09/15 : CBR-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d):
Telecommunications: adequate domestic and international service provided by
cables and radio; 4,500 telephones; 7,200 radiobroadcast receivers; 5 AM,
2 FM, and 2 TV stations; 2 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, included with Denmark
Approved For Release 2004/99/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/1 Ser GA ROP 79-0105 1A000500010001-1
LAND:
133 sq. mi. (Grenada and southern Grenadines); 47%
cultivated, 3% pastures, 12% forests, 20% unused but
potentially productive, 18% built on, wasteland,
other |
WATER: 7 VENEZUELA
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 75 mi. COLOMBIA
PEOPLE: BRAgI
Population: 96,000, average annual growth rate 0.6% é
(April 60-70)
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects; Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 25,170 (1960); 40% agriculture, 30% unemployed or underemployed
Organized labor: 33% of labor force
Railroads: none
Highways: 600 mi.; 380 mi. paved, 100 mi. gravel, crushed stone, or earth
surface; 120 mi. unimproved
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 4 total, 3 usable; 1 with asphalt runway 5,000 ft.
Telecommunications: automatic, islandwide telephone system with 3,100 telephones;
VHF island link to Trinidad and Carriacou; 18,000 radios and 100 TV
receivers; 2 AM stations
Approved For Release 2004/09/15 : GiA-RDP79-01051A000500010001-1
Approved For Release 2004/09/1 Buavefy fie? 72-01051A000500010001-1
LAND:
687 sq. mi.; 25% cropland, 8% pasture, 19% forest, 48%
wasteland, built on; area consists of two islands
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 190 mi.
Railroads: privately owned, narrow-gage plantation lines
Highways: 1,200 mi.; 780 mi. paved, 420 mi. gravel and earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
Civil air: 1 major transport
Airfields: 8 total, 7 usable, 5 with permanent-surface runways; 1 with runway .
8,000-11,999 ft.; 1 seaplane station
Telecommunications: domestic facilities inadequate; 17,400 telephones;
inter-island VHF radio links; 2 AM radio and 2 TV transmitters, with about
27,500 radio and 8,000 TV receivers
Approved For Release 2004/69/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15,; ClA;RRP79-01051A000500010001-1
LAND:
42,040 sq. mi.; 14% cultivated, 10% pasture, 57% forest,
19% other
Land boundaries: 1,010 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. : ee vei
Coastline: 250 mi.
Railroads: 592 mi., 3''O" gage; single-tracked; 520 mi. government owned, 72 mi.
privately owned
Highways: 7,600 mi., 1,300 mi. bituminous, 4,200 mi. gravel, 2,100 mi. improved
or unimproved earth
Inland waterways: 164 mi. navigable year-round; additional 458 mi. navigable
during high-water season
Pipelines: crude oi], 30 mi.
Freight carried: rail (1960) -- 191.8 million ton/miles, 1.1 million tons
Ports: 2 major, 3 minor
Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 3,600 GRT, 5,500 DWT
Airfields: 496 total, 329 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 11 major transport aircraft
Telecommunications: modern telecom facilities limited to Guatemala City;
41,000 telephones; est. 360,000 radio and 90,000 TV receivers, 78 AM, 20 FM,°
and 3 TV stations; connection to international Central American microwave
net
DEFENSE FORCES:
Military manpower: males 15-49, 1,390,000; 700,000 fit for military service;
about 60,000 reach military age (18) annually
Military budget: proposed for fiscal year ending 3] December 1972, $18.9 million;
about 7.5% of central government budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 oi ttzRDP79-01051A000500010001-1
LAND:
95,000 sq. mi.; 3.3% cropland, 10% forest
Land boundaries: 2,160 mi.
WATER:
Limits of territorial waters (claimed): 130 n. mi.
Coastline: 215 mi.
Railroads: 500 mi. meter gage, 5 mi. standard gage
Highways: 4,725 mi.; 465 mi. paved, 2,610 mi. all weather, 1,650 mi. unimproved
earth
Inland waterways: 1,115 mi.; 310 mi. navigable by small oceangoing vessels,
805 mi. navigable by shallow-draft steamers and barges
Ports: 1 major, 3 minor
Merchant marine: 1 bulk carrier (1,000 GRT or over) totaling 10,800 GRT,
15,300 DWT
Civil air: 5 major transport aircraft
Airfields: 20 total, 16 usable; 2 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 2 seaplane landing areas
Telecommunications: inadequate system of open-wire lines, small radio
communication stations, and 1 radio-relay link; principal center Conakry,
secondary center Kankan; 6,600 telephones; 91,000 radio receivers; 1 AM,
no FM, and no TV stations; 3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 959,000; 460,000 fit for military service
Military budget: for fiscal year ending 30 September 1970, $6,073,000; 8.0%
of total budget
Approved For Release 2064/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Railroads: 345 mi.; 48 mi. 5''0" gage, 107 mi. 3''O" gage; 190 mi. plantation
feeder lines
Highways: 4,200 mi.; 1,100 mi. paved, 600 mi. gravel or crushed stone, 300 mi.
improved earth, 2,200 mi. unimproved earth; Panama Canal Zone 145 mi.;
140 mi. paved; 5 mi. gravel
Inland waterways: 500 mi. navigable by shallow draft vessels; 50-mile
Panama Canal
Pipelines: refined products, 60 mi.
Ports: 2 major, 10 minor
Merchant marine: 889 ships (1,000 GRT or over) totaling 7,619,500 GRT, 12,207,300
DWT; includes 15 passenger, 549 cargo, 190 tanker, 73 bulk, 42 specialized
carrier; all foreign owned and operated
Civil air: 31 major transport aircraft
Airfields: 238 total, 119 usable; 16 with permanent-surface runways; 3 with
runways 8,000-11,999 ft.; 11 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: domestic and international telecom facilities well developed,
including nearly nationwide radio-relay system; connection to international
Central American microwave net; communications satellite ground station;
80,000 telephones; 550,000 radio and 160,000 TV receivers; 76 AM, 18 FM,
and 13 TV stations; 1 coaxial submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 346,000; 240,000 fit for military service;
no conscription
Approved For Release 2064hb9/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','b9c122d51b9b5cc75e258aece7f04c5ff60b42a9886ae5bf815a10278cc29ef1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6b061daca228a86a668a804f416e62c4eecc54933510b306f8fa44caca29ddd',1973,'BE','Belgium','communications',17,'LAND:
11,800 sq. mi.; 28% cultivated, 24% meadow and pasture,
28% waste, urban, or other; 20% forested
Land boundaries: 856 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 40 mi.
PEOPLE: ALGERIA
Population: 9,710,000, average annual growth rate 0.3%
(current)
Ethnic divisions: 55% Flemings, 33% Walloons, 12% mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch); divided along ethnic lines
Literacy: 97%
Labor force: 3.9 million; approximately 95% is found in the following sectors:
32% manufacturing, 24% services, 16% commerce, banking, and insurance, 8%
construction, 7% transportation and communication, 5% agriculture, forestry,
and fishing, 1.5% mining, .8% public utilities and sanitary services; 3%
unemp 1 oyed ;
Organized labor: 48% of labor force (1969)
Railroads: 2,818 mi.; 2,643 mi. standard gage and government owned, 1,615 mi.
double track, 698 mi. electrified; 175 mi. privately owned, electrified
narrow gage (3''3 3/8")
Highways: 57,700 mi.; 26,550 mi. bituminous, stone block, or concrete; 31,150
mi. crushed stone, gravel, earth
Inland waterways: 1,270 mi., of which 950 are in regular use by commercial
transport
Ports: 5 major, 1 minor
Merchant marine: 76 ships (1,000 GRT or over) totaling 1,084,400 GRT, 1,632,300
DWT; includes 1 passenger, 46 cargo, 14 tanker, 13 bulk, 2 specialized
carrier
Pipelines: refined products, 460 mi.; crude, 90 mi.; natural gas, 145 mi.
Civil air: 58 major transport aircraft, including 5 based in Libya
Airfields: 52 total, 38 usable; 2] with permanent-surface runways; 13 with
runways 8,000-11,999 ft., 5 with runways 4,000-7,999 ft.
Teleconmmunications: excellent domestic and international telephone and
telegraph facilities; 2,163,000 telephones; 3.83 million radio receivers;
2.26 million TV receivers; 7 AM, 11 FM, and 27 TV stations; 5 coaxial
submarine cables; communications satellite station
DEFENSE FORCES:
Military manpower: males 15-49, 2,235,000; 1,775,000 fit for military service;
average number reaching military age (19) annually 74,000
Military budget: proposed for fiscal year ending 31 December 1972, $720.0 million;
about 7.3% of proposed central government budget
Approved For Release 2004109/15 : CIA-RDP79-01051A000500010001-1','270bd9f1dba5bd25befe5fa624f02679e5c9ba0a83a2cdfcd5733be76ee57f35','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08eb162322eb2f8036fd6c3aab306410391a61e467e0efe3bd5a031f295d340c',1973,'CA','Canada','communications',24,'Railroads: none
Highways: 130 mi., all paved
Ports: 4 major
Civil air: no major transport aircraft
Approved For Release 2004/09/15 :30IA-RDP79-01051A000500010001-1
: - 79-01051A000500010001-1
COMMUNICATIONS’ (een eV gt For Release 2004/09/15 : CIA-RDP
Airfields: 1 with concrete runway 9,660 ft.; 1 seaplane station
Telecommunications: modern telecom system suited to island needs, includes fully
automatic telephone system with 32,000 instruments; 38,000 radio and
18,000 TV receivers, 2 AM, 1 FM, and 2 TV stations; 3 submarine coaxial cables
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 EM
LAND:
18,000 sq. mi.; 15% agricultural, 15% desert, waste,
urban, 70% forested
Land boundaries: about 540 mi.
oS 810 mi.; 260 mi. surfaced, 320 mi. improved, 230 mi. unimproved
eart :
Freight carried: not available, very light traffic
Civil air: no major transport aircraft
Approved For Release 2004/09/15 : CH@RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d):
Airfields: 1 asphalt runway 4,500 ft.
Telecommunications: facilities almost nonexistent; data not available on
telephones; 6,000 radio sets; no TV sets; data not available on AM; no
FM; and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 230,000; 120,000 fit for military service;
about 8,000 reach military age (18) annually
Supply: dependent on India
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
BOLIVIA
LAND:
424,000 sq. mi.; 2% cultivated and fallow, 11% pasture
and meadow, 45% urban, desert, waste, or other, BRAZIL
40% forest, 2% inland water
Land boundaries: 3,780 mi.
Railroads: 2,310 mi., single track; 2,290 mi., meter gage, 20 mi., 2''6" gage;
all government owned except 60 mi. of meter-gage track; 5.6 mi. of meter-
gage track electrified
Highways: 15,900 mi.; 600 mi. paved, 7,200 mi. gravel, 1,600 mi. improved
earth, 6,500 mi. unimproved earth
Inland waterways: officially estimated to be 6,250 mi. of commercially
navigable waterways
Pipelines: crude oi], 1,040 mi.; refined products and crude 930 mi.; natural gas
350 mi.
Ports: none (Bolivian cargo moved through Arica and Antofagasta, Chile, and
Matarani, Peru)
Civil air: 32 major transport aircraft
Airfields: 506 total, 425 usable; 3 with permanent-surface runways; ] with
runway over 12,000 ft., 3 with runways 8,000-11,999 ft., 81 with runways
4,000-7,999 ft.
Telecommunications: poorest telecom facilities on continent; 40,100 telephones; est.
750,000 radio and 12,000 TV receivers; 1 TV, 80 AM, and 16 FM stations
DEFENSE FORCES:
Military manpower: males 15-49 1,163,000; 735,000 fit for military service;
average number reaching military age (19) annually about 58,000
Military budget: for fiscal year ending 31 December 1972, $22.8 million;
about 16.3% of central government budget
Approved For Release 2004/69/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/1 Bote ARRDP79-01051A000500010001-1
LAND:
220,000 sq. mi.; about 6% arable, less than 1% under
cultivation, mostly desert
Land boundaries: 2,345 mi.
~
Railroads: 400 mi. 3''6" gage, single track; owned and operated by the Rhodesia
Railroads
Highways: 5,016 mi.; 16 mi. paved, 471 mi. crushed stone, gravel, or stabilized
soil; 4,529 mi. improved or unimproved earth
Inland waterways: native craft only; of local importance
Civil air: 9 major transport aircraft
Airfields: 83 total, 72 usable; 2 with permanent-surface runways; 17 with
runways 4,000-7,999 ft.
Teleconmunications: the system is a minimal combination of a single main wire
line and a few radiocommunication stations; Gaberone is the center; 4,000
telephones; 20,000 radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 164,000; 85,000 fit for military service; 8,000
reach military age (18) annually
Police only
Approved For Release 2004/99/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','c1a8bfb7bc2110a62b3717d0a4f5d3871f4ade917c82fd843a850ca039f762e1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7821ec278cd273a94b80a37856d755873ba2128fe316c022d4b30a849b5f842a',1973,'BG','Bulgaria','communications',26,'LAND:
42,800 sq. mi.; 41% arable, 11% other agricultural,
33% forested, 15% other
Land boundaries: 1,170 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 220 mi.
Railroads: 2,650 mi.; about 2,470 mi. standard gage, 180 mi. narrow gage; 148 mi.
double track; 528 mi. electrified; government owned (1971)
Highways: 20,700 mi.; 7,900 mi. paved, 8,100 mi. crushed stone and gravel,
4,700 mi. earth (1971)
Inland waterways: 300 mi. (1972)
Freight carried: rail -- 77.2 million short tons, 10.1 billion short ton/mi.
(1970); highway -- 546.8 million short tons, 5.8 billion short ton/mi. (1971);
waterway -- 3.5 million short tons, 1.2 billion short ton/mi. (1970)
Ports: 2 major (Varna, Burgas), 10 minor (1972)
Merchant marine: 104 ships (1,000 GRT and over) totaling 678,800 GRT, 994,250
DWT; includes 5 passenger, 55 cargo, 17 tanker, 29 bulk
DEFENSE FORCES:
Military manpower: males 15-49, 2,246,000; 1,875,000 fit for military service;
about 69,000 reach military age (19) annually
Supply: dependent primarily on U.S.S.R.; domestic production of small] arms,
ammunition, antitank grenades, grenade launchers, trucks, and small
quantities of defensive chemical warfare materiel
Military budget: for fiscal year ending 31 December 1971, 366,000,000 leva;
about 6.4% of total budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
rz |
Approved For Release 2004/09/15 Ma ee
R
LAND:
262,000 sq. mi.; 28% arable, of which 12% is cultivated,
62% forest, 10% urban and other area
Land boundaries: 3,630 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,900 mi.
Railroads: 2,022 mi.; 1,952 mi. meter gage, 70 mi. narrow-gage industrial lines;
204 mi. double track; government owned
Highways: 15,540 mi.; 4,210 mi. paved, 4,770 mi. gravel, 5,810 improved earth,
750 mi. unimproved earth
Inland waterways: 8,000 mi.; 2,000 mi. navigable by large commercial vessels
Ports: 4 major, 6 minor
Merchant marine: 9 cargo ships (1,000 GRT or over) totaling 55,500 GRT, 73,600
DWT
Airfields: 119 total, 83 usable; 24 with permanent-surface runways; 2 with
runways 8,000-11,999 ft., 39 with runways 4,000-7,999 ft.; 2 seaplane
stations
Telecommunications: provide minimum requirements for local intercity service;
international service is fair; radiobroadcast coverage is limited to the
more populous areas; 24,654 telephones; 500,000 radio sets; 1 AM, 1 FM,
and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 6,954,000; 3,560,000 fit for military service;
about 290,000 males and 270,000 females reach military age (18) annually;
both are liable for military service
Military budget: for fiscal year ending 30 September 1971; $112.3 million, 35%
of total budget
4
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 ;, (4A, RDP79-01051A000500010001-1
LAND:
11,000 sq. mi.; about 37% arable (about 66% cultivated),
23% pasture, 10% scrub and forest, 30% other
Land boundaries: 605 mi.
Railroads: 409 mi. meter gage; government owned
Highways: 8,200 mi.; 1,300 mi. bituminous, 3,900 mi. crushed stonc, gravel, or
improved earth; and 3,000 mi. unimproved earth
Inland waterways: 1,220 mi. during high water, 1,010 mi. during low water;
90% of total navigability on Mekong system and Tonle Sap
Freight carried: (1970) rail -- 50 million ton-miles; waterway -- approximately
300,000 short tons annually; figures unavailable for highways
Ports: 2 major, 6 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,400 GRT, 2,600 DWT
Airfields: 100 total, 47 usable, 8 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 16 with runways 4,900-7 ,999 ft.; 1 seaplane station
Telecomnunications: service to general public considered poor; bareiy adequate
for government requirements; internationai service fair to adjoining countries
and a few other nations; radiobroadcasts and television coverage limited by
small number of stations and receivers; 8,139 telephones; 105,090 radio
receivers; 30,000 (est.) TV receivers; 1 AM, 2 AM relay, no FM, anc 1 TV
station; no submarine cables
DEFENSE FORCES:
Military manpower: mates 15-45, 1,624,000; 900,009 fit for military service;
83,000 reach military age (18) annually
Approved For Release 2004/69/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 ;;\\CkadRDP79-01051A000500010001-1
LAND:
183,400 sq. mi.; 4% cultivated, 18% grazing, 13% failow,
50% forest, 15% other
Land boundaries: 2,830 mi.
WATER: .
Limits of territorial waters (claimed): 18 n. mi.
Coastline: 250 mi.
Railroads: 623 mi.; 533 mi. meter gage, 90 mi. 1''11 5/8" gage
Highways: approximately 14,000 mi.; including 900 mi. bituminous , 13,100 mi.
gravel and earth
Inland waterways: 1,300 mi.
Ports: 1 major, 3 minor
Civil air: 6 major transport aircraft
Airfields: 59 total, 56 usable; 5 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: good telephone service between Douala and Yaounde, fair in
southern part; fair to good telegraph service; 5,800 telephones; 214,000
radio receivers; 4 AM, no FM, and no TV stations; limited wired broadcast;
1 submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 1,379,000; 720,000 fit for military service;
average number reaching military age (18) annually about 62,000
Supply: mostly from France and U.S.
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','4b2fcbb2ba0ea0bd5bd8ef85085d83e4a238fb9a01c0560ac0e7e14f0c5c6288','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('499893e5bde6363dc22d55e5cfec1e7a475ae5e5e256b8a70cdcdaf52f8e97ea',1973,'CF','Central African Republic','communications',30,'LAND:
242,000 sq. mi.; 10%-15% cultivated, 5% dense forests, rs 5
80%-85% grazing, fallow, vacant arable land, urban, Koen) ueva EGYaT,, ol
was te ‘ ‘ RABIA
Land boundaries: 3,095 mi. E “
Railroads: none
Highways: 13,250 mi.; 115 mi. bituminous, 2,265 mi. gravel and/or crushed stone,
3,420 mi. improved earth, 7,450 mi. unimproved earth
Inland waterways: 4,400 mi.; traditional trade carried on by means of dugouts
on the extensive system of rivers and streams; only the Oubangui River
between Bangui and Brazzaville and short sections of the Sangha and the
Lobaye Rivers are navigable throughout year; during high-water period
(July - December) Oubangui navigable upstream from Bangui as far as Quango
Ports: Bangui, Quango (river ports)
Civil air: 5 major transport aircraft
Airfields: 65 total, 49 usable; 3 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 16 with runways 4,000-7,999 ft.
Telecommunications: facilities are meager and provide only barely sufficient
services; principal network is 39 low-capacity, low-powered radiocommunica-
tion stations; no cables or radio relay links are used; single center of
Bangui has only international radio connections; 3,500 telephones; 50,000
radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES: :
Military manpower: males 15-49, 439,000; 210,000 fit for military service
Supply: completely dependent on France
Military budget: for fiscal year ending 31 December 1972, $5,111,500; about
9.5% of total budget
Approved For Release 2004f09/15 : CIA-RDP79-01051A000500010001-1
Railroads: none
Highways: 19,200 mi.; 160 mi. bituminous, 3,300 mi. gravel and laterite, and
15,740 mi. unimproved
Inland waterways: approximately 1,300 mi. of year-round navigability, increased
to 3,000 mi. during high-water period
Civil air: 4 major transport aircraft
Airfields: 75 total, 60 usable; 4 with permanent-surface runways; | with runway
8,000-11,999 ft., 2 with runways 4,000-7 ,999 ft.
Telecommunications: fair system of radioconmunication stations only for intercity
links; principal center Fort-Lamy, secondary center Fort-Archambault; 5,000
telephones; 60,000 radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 927,000; 480,000 fit for military service;
average number reaching military age (20) annually about 35,000
Military budget: for fiscal year ending 31 December 1971, $13,960,000; about
28.9% of total budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','c5732d478e55553686d5d66db17cd2a56af3cd2c46e2a084d9c09f3dd4bf8398','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adfa2861997c5a861bc5d082c9e5afab7cd1963b838160cc15b32352145bc059',1973,'CL','Chile','communications',34,'LAND:
286,000 sq. mi; 2% cultivated, 7% other arable, 15%
permanent pasture, grazing, 29% forest, 47% barren
mountains, deserts, and cities
Land boundaries: 3,930 mi.','42f696a09c777aa2ac691a90a76f841d8f99640c2032f1a10028eda71b21c144','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef517976cb28f2ff7699f2917f2f72bc607487a59a1828cd1e55a8cc85bd804c',1973,'AU','Australia','communications',38,'Railroads: about 25,000 mi., of which 370 mi. 3''3 3/8" gage, 30 mi. 3''6" gage,
24,600 mi. 4''8 1/2" gage; mostly single track, less than 1% electrified;
government owned
Highways: 325,000 mi.; 1,000 mi. paved, 74,000 mi. gravel and crushed stone,
80,000 mi. improved earth, and 170,000 mi. unimproved earth, including tracks
Inland waterways: 105,000 mi.; 25,000 mi. navigable by modern motorized craft
Ports: 9 major, 157 minor
Airfields: 303 total; 213 with permanent-surface runways; 6 with runways over
12,000 ft., 63 with runways 8,000-11,999 ft., 200 with runways 4,000-7 ,999
ft.; 1 seaplane station
Approved For Release 2004/69/15 : CIA-RDP79-01051A000500010001-1
WATER:
Railroads: 2,823 mi., all narrow gage; 130 mi. double track; 623 mi. government
owned, 2,200 mi. industrial
Highways: 10,300 mi. plus 300 mi. on Penghu and offshore islands; 3,300 mi. paved,
5,000 mi. gravel and crushed stone, 2,000 mi. earth
Ports: 7 major, 9 minor
Airfields: 61 total, 37 usable; 23 with permanent-surface runways; 2 with runways
over 12,000 ft., 10 with runways 8,000-11,999 ft., 13 with runways 4,000-7,999
ft.; 2 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 3,826,000; 2,895,000 fit for military service;
average number currently reaching military age (19) annually 180,000
Military budget: proposed for fiscal year ending 30 June 1973, $700 million;
about 45% of central government budget
Approved For Release 2004409/15 : CIA-RDP79-01051A000500010001-1
we
Approved For Release eT
LAND:
440,000 sq. mi.; settled area 28% consisting of cropland
and fallow 5%, pastures 14%, woodland, swamps, and en
water 6%, urban and other 3%; unsettled area 72% --
mostly forest and savannah
Land boundaries: 3,750 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,500 mi.
Railroads: 2,160 mi., al? 3''0" gage, single track, 22 mi. electrified
Highways: 28,600 mi.; 3,700 mi. paved, 19,900 mi. crushed stone or gravel,
3,100 mi. improved earth, 1,900 mi. unimproved earth
Inland waterways: 8,900 mi., navigable by river boats
Pipelines: crude 011, 2,000 mi.; refined products, 830 mi.; natural gas, 370 mi.;
natural gas liquids 80 mi.
Ports: 5 major, 5 minor
Merchant marine: 38 ships (1,000 GRT or over) totaling 217,100 GRT, 267,600 DWT;
32 cargo, 3 bulk, 3 tanker (includes 3 naval tankers sometimes used
commercially)
Civil air: 111 major transport aircraft
Airfields: 879 total, 701 usable; 34 with permanent-surface runways; 1 with
runway over 12,000 ft.; 6 with runways 8,000-11,999 ft., 80 with runways
4,000-7,999 ft.; 11 seaplane stations
Telecommunications: rapidly improving nationwide telecom system; communications
satellite ground station; over 1 million telephones; est. 6 million radio
and 810,000 TV receivers; 280 AM, 130 FM, and 16 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 5,539,000; 3,290,000 fit for military service;
average number reaching military age (18) annually about 244,000
Military budget: proposed for fiscal year ending 31 December 1972, $95.0 million;
about 10.2% of central government budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMORO ISLANDS
LAND:
838 sq. mi.; 4 main islands; forests 16%, pasture 6.8%,
cultivable area 48.3%, non-cultivable area 28.9%
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 211 mi.
Railroads: none
Highways: 600 mi.; approximately 100 mi. bituminous, 450 mi. crushed stone or
gravel, remainder tracks
Ports: 1 minor (Moroni on Grande Comore)
Civil air: 2 major transports
Airfields: 4 total, 4 usable; 4 with permanent surface runways; 4 with runways
4,000-7,999 ft.; 1 seaplane alighting area
Approved For Release 2004/09/15 : €%-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (oont''d):
Telecommunications: one central telephone exchange; number of telephones not
available; 4 radiotelephone and radiotelegraph stations link the islands
and the Malagasy Republic; direct radio telegraph link to Paris; 35,000
radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Defense is the responsibility of France
Approved For Release 2004/9115 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Railroads: none
Highways: 2,900 mi.; 180 mi. paved; 1,170 mi. gravel, crushed stone, or stabilized
surface; 1,550 mi. unimproved earth
Inland waterways: none
Ports: 1 major, 21 minor
Civil air: no major transport aircraft
Airfields: 34 total, 29 usable; 2 with permanent-surface runways; 2 with
runways 4,000-7,999 ft.; 1 airfield over 8,000 ft.; 1 seaplane station
Telecommunications: 9,265 telephones; 25,550 radio and 8,100 TV sets; 7 AM,
no FM, and 1 TV stations
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/45 & GMA RDP79-01051A000500010001-1
LAND:
57,100 sq. mi.; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other
Land boundaries: 760 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 200 n. mi.)
Coastline: 565 mi.
Railroads: 220 mi.; 200 mi. of 3''6" gage, government owned; 20 mi. narrow gage,
privately owned
Highways: 8,750 mi.; 800 mi. paved, 3,250 mi. otherwise improved, 4,700 mi.
unimproved
Inland waterways: 1,380 mi., including 2 Jarge lakes
Pipelines: crude oi], 40 mi.
Ports: 4 major, 6 minor
Merchant marine: 8 cargo ships (1,000 GRT or over) totaling 18,300 GRT,
26,000 DWT; includes 7 cargo, 1 tanker
Civil air: 11 major transport aircraft
Airfields: 459 total, 408 usable; 5 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 8 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: low-capacity wire network; connection to international
Central American microwave net; 26,500 telephones; est. 700,000 radio and
56,000 TV receivers; 74 AM, 26 FM, and 6 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 491,000; 295,000 fit for military service;
23,000 reach military age (18) annually
Supply: dependent primarily upon U.S.
Military budget: for fiscal year ending 31 December 1972, $8.8 million for the
Ministry of Defense, including civil functions (e.g., police and civil air);
8.3% of central government budget
Approved For Release 208409/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Railroads: none
Highways: 463 mi.; 293 mi. gravel or crushed stone, 170 mi. improved and
unimproved earth
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 14 total, 10 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: domestic and international radio stations used primarily
for administrative and military purposes; 1 low-power radiobroadcast station;
unreliable open-wire lines and 12 small manual switchboards serve about 679
telephones; 3,000 radio sets
Approved For Release 2004/09/45 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09 aT FlAFRDP79-01051A000500010001-1
LAND:
3,440 sq. mi.; 33% arable, 35% meadow and pasture, 13%
forested, 19% waste, urban, or other
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 300 mi.
Railroads: more than 450 mi. plantation lines; 6 gages from 1''8" to 3''3 3/8"
with latter predominating
Highways: 4,800 mi.; 3,900 mi. paved, 260 mi. gravel, 640 mi. improved and
unimproved earth
Inland waterways: negligible
Pipelines: refined products, 90 mi.
Ports: 3 major, 7 minor
Civil air: major transport aircraft are included in U.S. registered total
Airfields: 32 total, 18 usable; 18 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 9 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: highly developed telecom system of open-wire and radio relay
links; communications satellite ground station; 380,000 telephones; over 1.65
million radio and 440,000 TV receivers; 49 AM, 18 FM, and 13 TV stations;
2 coaxial submarine cables
DEFENSE FORCES:
Defense is responsibility of U.S.
Approved For Release 200448915 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ea
Railroads: none
Highways: 3,350 mi.; 120 mi. bituminous treated, 30 mi. crushed stone and gravel,
3,200 motorable track
*Excluding the islands of Perim and Kamaran for which no data are available.
Approved For Release 2004/09/15 3G@1A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d):
Ports: 1 major
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,600 GRT, 2,500 DWT
Pipelines: refined products, 20 mi.
Civil air: 7 major transport aircraft
Airfields: 138 total, 78 usable; 2 with permanent-surface runways; 2 with
runways 8,000-11,999 ft., 41 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent international radiocommunications; excellent
domestic wire facilities; 9,400 telephones; 250,000 radio receivers; 25,000
TV receivers; 5 TV and 1 AM stations; 4 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 372,000; 200,000 fit for military service
Military budget: for fiscal year ending 31 March 1971, $15,816,000; about 34.4%
of total budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/ VE Gl AdRIYR 79-0105 1A000500010001-1
LAND:
about 75,000 sq. mi. (parts of border with Saudi Arabia
and Southern Yemen undefined); 20% agricultural,
1% forested, 79% desert, waste, or urban
Land boundaries: 950 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 325° mi.
Railroads: 6,393 route mi.; 5,709 mi. standard gage, 684 mi. narrow gage;
463 mi. double track (1970)
Highways: 56,565 mi.; 14,850 mi. paved, 25,715 mi. gravel, crushed stone, 15,600
mi. improved earth, 400 mi. unimproved earth (January 1971)
Inland waterways: 1,231 mi. (1972)
Freight carried: rail -- 88.0 million short tons, 14.2 billion short ton/mi. (1971);
highway -- 64.7 million short tons, 4.5 billion short ton/mi. (1971);
waterway -- 25.4 million short tons, est. 4.8 billion short ton/mi. (1971)
Pipelines: crude oil, 200 mi.; natural gas, 1,000 mi.
Ports: 9 major (most important: Rijeka, sae 24 minor (1972)
Merchant marine: 190 ships (1,000 GRT or over) totaling 1,504,500 GRT, 2,196,900
DWT; includes 4 passenger, 144 cargo, 16 tanker, 26 bulk in addition Yugoslavia
owns 4 cargo ships (1,000 GRT or over) totaling 37,600 GRT, 60,000 DWT which
appear under Panamanian flag
Airfields: 194 total, 90 usable; 34 with permanent-surface runways; 18 with
runways 8,000-11,999 ft., 29 with runways 4,000-7,999 ft.; 2 seaplane
stations
Approved For Release 2004768/15 : CIA-RDP79-01051A000500010001-1
-—
‘®
DEFENSE Red For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Military manpower: males 15-49, 5,605,000; 4,525,000 fit for military service;
201,000 reach military age (19) annually
Supply: produces general transport trucks, jet aircraft, weapons and ammunition
up to medium artillery, explosives, small quantities of offensive and defensive
chemical warfare materiel, signal equipment, and a small number of armored
4 personnel carriers; builds smal] submarines, fast patrol boats, and units up
to PC size; other materiel now obtained primarily from U.S.S.R.
Military budget: for fiscal year ending 31 December 1972, 11,731 million new
dinars; about 48.4% of the central government budget
Approved For Release 2004/09/15 : CI-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 >A RDP79-01051A000500010001-1
LAND:
905,000 sq. mi.; 22% agricultural land (1% cultivated),
45% forested, 33% other
Land boundaries: 6,153 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 23 mi.
Railroads: 3,218 mi.; 2,419 mi. 3''6" gage, 78 mi. 3'' 3 3/8" gage, 85 mi.
2'' 0 1/4" gage, 636 mi. 1'' 11 5/8" gage; 421 mi. of 3''6" gage electrified
Highways: 86,930 mi.; 1,095 mi. bituminous, 10,427 mi. gravel or crushed stone,
75,408 mi. earth
Inland waterways: comprising the Zaire, its tributaries, and unconnected lakes,
the waterway system affords over 9,329 mi. of navigable routes
Ports: 2 major, 1 minor
Merchant marine: 4 ships (1,000 GRT or over) totaling 35,900 GRT, 45,700 DUT;
includes 1 passenger, 3 cargo
Pipelines: refined products, 460 mi.
Civil air: 26 major transport aircraft
Airfields: 486 total, 319 usable; 19 with permanent-surface runways; 1 with
runway over 12,000 ft., 2 with runways 8,000-11,999 ft., 55 with runways
4,000-7,999 ft.; 5 seaplane stations
Telecommunications: limited, barely adequate telephone service, telegraph service
good; 23,000 telephones; 75,000 radio receivers; 7,100 TV receivers;
12 AM, 1 FM, and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 5,854,000; 2,805,000 fit for military service
Military budget: for fiscal year ending 31 December 1972, $89,528,400; about
13.6% of total proposed budget
Approved For Release 2002969/15 : CIA-RDP79-01051A000500010001-1
we
x
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','4d699ff216f1c0f9a7e9ffcb4153b93eac2c69f6027a5f45c27ff19ca5fa0095','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcb9a2fb0599734d380d8761eb7d3f763646fcf7c5b5b60ceeb580f15df99cce',1973,'CG','Congo','communications',39,'LAND:
135,000 sq. mi.; 63% dense forest or woodland, 33% RORY
cultivable or grazing (2% cultivated est.), 4% urban ALGERIA UBYA FEYAL squoy 9
or waste
Land boundaries: 2,805 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(fishing 3-15 n. mi.)
Coastline: 105 mi.
Railroads: 490 mi., 3''6" gage, single track
Inland waterways: 4,030 mi. navigable
Ports: 1 major
Civil air: 8 major transport aircraft
Airfields: 69 total, 44 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 16 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: all services only fair; barely adequate for government and
public; principal network is comprised of 30 low-capacity, low-powered radio
communication stations; few wire lines connect key centers of Brazzaville,
Pointe-Noire, and Dolisie with maximum of 2] channels; 10,000 telephones;
65,000 radio receivers; 1,900 TV receivers; 3 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 240,000; 115,000 fit for military service;
about 10,000 reach military age (20) annually
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','b8551606598050370aae030e6c497bac0a3ea7653b685c92c697ff61866a443d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52874544025a34a663f18fbb2ce0e5bd5efab245efcafe18e3c7756111348777',1973,'CR','Costa Rica','communications',43,'LAND:
19,700 sq. mi.; 30% agricultural land (8% cultivated, 22%
meadows and pasture), 60% forested, 10% waste, urban,
and other (1964)
Land boundaries: 415 mi.
WATER: :
Limits of territorial waters (claimed): 12 n. mi. (fishing ogee
200 n. mi.)
Coastline: 800 mi.
Railroads: 407 mi.; 395 mi. 3''6" gage, 12 mi. 3''0" gage, all single track, 72 mi.
electrified
Highways: 11,700 mi.; 850 mi. paved, 3,200 mi. gravel, 7,650 mi. earth
Inland waterways: about 455 mi. perennially navigable
Pipelines: refined products, 80 mi.
Ports: 3 major, 4 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 2,600 GRT, 3,700 DWT
Civil air: 14 major transport aircraft
Airfields: 206 total, 129 usable; 10 with permanent-surface runways; 8 with
runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: domestic telephone service greatly improved; 68,000 telephones;
connection to international Central American microwave net; 330,000 radio and
120,000 television receivers in use; 44 AM, 8 FM, and 11 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 406,000; 275,000 fit for military service; average
number reaching military age (18) annually about 23,000
Supply: dependent on imports from U.S.
Military budget: for fiscal year ending 31 December 1971, $3.3 million for
Ministry of Public Security, including the Civil Guard; about 2.3% of total
central government budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','0502b37cb38b249b47cc49d0344a3ad8cff82494595183adb5d2a116e5121f69','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7a2219a6bb86742dfe0fbf9a9737830f7f5168e23d2c750deb20b298d1ce162',1973,'CU','Cuba','communications',47,'LAND:
44,200 sq. mi.; 35% cultivated, 30% meadow and pasture,
20% waste, urban, or other, 15% forested (1968)
WATER: i
Limits of territorial waters (claimed): 3 n. mi. in
Coastline: 2,320 mi. . VENEZUELA
Railroads: 9,150 mi. government owned; 3,150 mi. common carrier lines (8 mi.
double track and 95 mi. electrified) and about 6,000 mi. plantation-
industrial lines; common carrier lines comprise 3,100 mi. 4''8 1/2" standard
gage, and about 50 mi. 3''0" and 2''6" narrow gage; plantation-industrial
lines comprise about 4,000 mi. standard gage and 2,000 mi. narrow gage
Highways: 11,600 mi.; 4,000 mi. (est.) paved, 2,500 mi. (est.) gravel or
otherwise improved hard surfaces, 5,100 mi. (est.) improved or unimproved
earth surface
Inland waterways: 50 mi.
Pipelines: natural gas, 50 mi.
Ports: 8 major, 44 minor; Guantanamo under U.S. control
Merchant marine: 46 ships (1,000 GRT and over) totaling 304,600 GRT, 414,100
DWT; includes 37 cargo, 6 tanker, 3 specialized carrier; Cuba beneficially
owns 3 additional ships (1,000 GRT and over) totaling 28,700 GRT, 40,400 DWT,
which are registered under a Hong Kong company and fly the U.K. flag
Airfields: 376 total, 202 usable; 38 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 30 with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: modern facilities adequately serve military and most civil
needs; excellent international facilities, planned satellite ground station;
300,000 telephones; 1.5 million radio and 600,000 TV receivers, 94 AM, 25 FM,
and 2] TV stations; 6 submarine cables, including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 2,099,000; 1,215,000 fit for military service;
about 85,000 males and 78,000 females reach military age (17) annually
Military budget: for fiscal year ending 31 December 1966, $213 million; about
7.8% of total budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','f7ecda8d861abe9aba96c9eb5ba27972f188ae346a53f7779c16b806f04136b2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46fc274c9bd6c6cd7e62b190c85b565237203068368f31e65c022ad0f9972371',1973,'CY','Cyprus','communications',51,'LAND:
3,570 sq. mi.; 47% arable and land under permanent crops,
18% forested, 10% meadows and pasture, 25% waste,
urban areas, and other
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 400 mi. (approx.)
PEOPLE: eile
baal 647,000, average annual growth rate 1.1%
FY72
Ethnic divisions: 78% Greek; 18% Turkish; 4% British,
Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Armenian Orthodox and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Labor force: 267,000 (1970 est.), 38% agriculture, 23% industry, 9% commerce,
2% mining, 28% other; 3,130 registered unemployed (December 1968)
Organized labor: 24% of labor force
ARABIA
Railroads: 8,269 mi.; 8,089 mi. standard gage, 70 mi. broad gage, 110 mi. narrow
gage; 1,745 mi. double track; 1,560 mi. electrified; government owned (1970)
Highways: 45,500 mi.; 600 mi. concrete; 20,700 mi. bituminous; 2,400 mi.
cobblestone, brick sett, stone block; 21,800 mi. crushed stone, gravel,
improved earth (1971)
Inland waterways: 517 mi. (1972)
Pipelines: crude oi], 900 mi.; refined products, 535 mi.; natural gas, 2,200 mi.
Freight carried: rail -- 275.1 million short tons, 40.2 billion short ton/mi.
(1970); highway -- 845.2 million short tons, 7.3 billion short ton/mi. (1971);
waterway -- 4.9 million short tons, 1.7 billion short ton/mi. (1970)
Ports: no maritime ports; outlets are Gdynia, Gdansk, Stettin in Poland; Rijeka,
Yugoslavia; Hamburg, West Germany; Rostock, East Germany; principal river
ports are Prague, Melnik, Usti nad Labem, Decin, Komarno, Bratislava (1972)
Merchant marine: 13 ships (1,000 GRT or over) totaling 117,300 GRT, 171,000 DWT;
includes 8 cargo, 5 bulk
Airfields: 134 total; 33 with permanent-surface runways; 19 with runways
8,000-11,999 ft., 49 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 3,654,000; 2,815,000 fit for military service;
about 124,000 reach military age (18) annually
Supply: produces aircraft, copies of Soviet air-to-air and antitank missiles,
armored vehicles, river patrol boats and gunboats, some light artillery,
substantial quantities of infantry weapons, ammunition, explosives, tactical
signal equipment, trucks, and smal] amounts of chemical warfare agents;
chemical and biological warfare defensive materiel; dependent on the U.S.S.R.
for more complex electronic equipment; amphibious armored reconnaissance
cars obtained from Hungary
Military budget: for fiscal year ending 31 December 1972, 15.9 billion crowns,
about 8.4% of total budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release aman ed perl aaa he
LAND:
44,700 sq. mi.; southern third of country is most fertile;
arable land 80% (actually cultivated 11%), forests and
game preserves 19%, non-arable 1%
Land boundaries: 1,220 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 75 mi.
Railroads: 360 mi., all meter gage (3''3 3/8")
Highways: 4,300 mi.; 470 mi. paved, 1,670 mi. otherwise improved earth, 2,160
mi. unimproved
Inland waterways: 400 mi. navigable
Ports: 1 major, 1 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 10,000 GRT, 13,000 DWT
Civil air: no major transport aircraft
Airfields: 11 total, 10 usable; 1 with permanent-surface runway; 4 with runways
4000-7 ,999 ft.
Telecomnunications: telephone service concentrated in south; telegraph limited,
but more extensive than telephone; 6,500 telephones; 54,000 radio receivers;
2 AM, no FM, and no TV stations; 3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 687,000; 330,000 fit for military service; about
29,000 males and 28,000 females reach military age (18) annually; both sexes
liable for military service
Supply: dependent on France
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','db5e4687f9855af97801fec7ac0c8ac12aec4f2a36bb41ad32118d49c2d2a1db','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb00423b3fcdaaa3cb5bd646390738b3a91b76f55573da7d12b1bc40908dedea',1973,'DZ','Algeria','communications',62,'Railroads: 1,843 mi. Danish State Railways (DSB) 1,460 mi. standard gage (4''8 1/2"),
52 mi. electrified and 451 mi. double tracked; remaining 389 mi. of standard
gage lines are privately owned and operated
Highways: 38,275 mi.; 31,205 mi. concrete, bitumen, or stone block; 5,640 mi.
gravel and crushed stone; 1,430 mi. improved earth
Inland waterways: 259 mi.
Pipelines: refined products, 202 mi.
Ports: 16 major, 42 minor
Merchant marine: 297 ships (1,000 GRT or over) totaling 3,324,900 GRT, 5,393,100
DUT; includes 12 passenger, 190 cargo, 39 tanker, 22 bulk, 34 specialized
carrier
Civil air: 90 major transport aircraft
Airfields: 126 total, 104 usable; 16 with permanent-surface runways; 8 with run-
ways 8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent telephone, telegraph, and broadcast services;
1,803,000 telephones; 1,640,000 radiobroadcast receivers; 1,427,000 TV
receivers; 5 AM, 13 FM, and 30 TV stations; 13 submarine cables
DEFENSE FORCES: sor
Military manpower: males 15-49, 1,184,000; 1,040,000 fit for military service;
38,000 reach military age (20) annually
Military budget: for fiscal year ending 31 March 1973, $457 million; about 7%
of central government budget
Approved For Release 2004/99/15 : CIA-RDP79-01051A000500010001-1
Approved For Release MIG
LAND:
305 sq. mi.; 24% arable, 2% pasture, 67% forests, 7%
other
WATER:
Limits of territorial waters (claimed): 3 n. mi. 4
Coastline: 92 mi. VENEZUELA
PEOPLE: COLOMBIA
Population: 73,000, average annual growth rate 1.6%
(April 60-70) Ps BRAZIL
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist
Language: English; French patois
Literacy: about 80%
Labor force: est. at 23,000 in 1960; about 50% in agriculture
Organized labor: 25% of the labor force
Railroads: none
Highways: 460 mi.; 175 mi. paved, 190 mi. gravel, crushed stone, or stabilized
earth surface, 95 mi. unimproved
Ports: 2 minor
Civil air: no major transport aircraft
Approved For Release 2004/09/15 : 6¥A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d):
Airfields: 1 with asphalt runway 4,830 ft.
Telecommunications: 2,000 in fully automatic telephone network; VHF interisland
link to St. Lucia; 15,000 radio receivers; less than 100 TV receivers; 1
AM station
Approved For Release 2006/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Railroads: 938 mi.; 851 mi. 5''6" gage, 87 mi. 2''6" gage; 63 mi. double track;
no electrification; government owned
Highways: 25,580 mi.; 11,700 mi. paved (mostly bituminous treated), 11,500 mi.
crushed stone or gravel, 530 mi. improved earth, 1,850 mi. unimproved earth;
in addition several thousand mi. of tracks, mostly unmotorable
Inland waterways: 270 mi.; navigable by shallow-draft craft
Ports: 3 major, 9 minor
Merchant marine: 3 cargo ships (1000 GRT or over) totaling 22,100 GRT, 31,900 DWT
Airfields: 17 total, 13 usable; 13 with permanent-surface runways; | with
runway 8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; ] seaplane station
Teleconmunications: an inadequate telephone and a less extensive but more
efficient telegraph system serves most areas, with greatest concentration
around Colombo and Kandy; all areas are served by radio and/or wire
broadcast; excellent international service; 62,954 telephones; 500,000 radio
sets, no TV sets; 1 AM (plus 4 repeater stations), no FM, and no TV stations;
submarine cables extend to India, Malaysia, Seychelle Islands, and Aden
DEFENSE FORCES:
Military manpower: males 15-49, 3,120,000; 2,340,000 fit for military service;
143,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1972, $31.6 million, 3.1% of
total budget
Approved For Release 2004389/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 SAE ee
LAND:
967,000 sq. mi.; 37% arable (3% cultivated), 15% grazing,
33% desert, waste, or urban, 15% forest
a Land boundaries: 4,850 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 530 mi.
Railroads: 2,950 mi.; 2,730 mi, 3''6" gage, 440 mi. 2'' gage plantation line
Highways: 6,550 mi.; 680 mi. crushed stone or gravel, 190 mi. bituminous-treated,
and 5,680 mi. improved and unimproved earth roads; in addition, there are an
undetermined number of tracks
Inland waterways: 3,300 mi. navigable
Ports: 1 major, 7 minor
Civil air: 9 major transport aircraft
Airfields: 87 total, 67 usable; 5 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 29 with runways 4,000-7 ,999 ft.
Telecommunications: large system by African standards, but still barely adequate
for size of country; consists of open-wire lines, radio-relay links, multi-
conductor cables, radio communication stations and a tropospheric scatter
link; principal center of Khartoum, secondary centers at Al Fashir and
Port Sudan; 46,400 telephones; 650,000 radio and 40,000 TY receivers; 2 AM,
no FM, and 1 TV stations; 5 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,789,000; 2,255,000 fit for military service;
average number reaching military age (18) annually, 160,000
Military budget: for fiscal year ending 30 June 1971, $133.3 million; 30.8% of
total budget
Approved For Release 2004/29/15 : CIA-RDP79-01051A000500010001-1
WATER:
Railroads: 104 mi.; 54 mi. 3''3 3/8" gage (government owned) and 50 mi.
narrow gage (industrial lines); all single track
Highways: 1,550 mi,; 300 mi. paved, 130 mi. gravel, 370 mi. improved earth,
750 mi. unimproved earth
Inland waterways: 2,850 mi.; most important means of transport; oceangoing
vessels with drafts ranging from 14 to 23 ft. can navigate many of the
principal waterways while native canoes navigate upper reaches
Ports: |] major, 6 minor
Civil air: 2 major transport aircraft
Airfields: 31 total, 29 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Teleconmunications: international facilities good; domestic radio-relay
system; 11,000 telephones; 95,000 radio and 31,000 TV receivers, 5 AM,
1] FM, and 3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 105,000; 60,000 fit for military service «
Defense is responsibility of the Netherlands; the Netherlands maintains an army
force in Surinam; also available are naval, marine corps, and naval air
personnel located in the Netherlands Antilles
Ships: none
Approved For Release 2004/89/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 | GlAsROP79-01051A000500010001-1
LAND:
6,700 sq. mi.; most of area suitable for crops or
pastureland
Land boundaries: 270 mi.
Railroads: 139 mi. 3''6" gage, single track
Highways: 2,059 mi.; 140 mi. paved; 838 mi. crushed stone, gravel, or stabilized
soil; 685 mi. improved or unimproved earth
Civil air: 5 major transport aircraft
Airfields: 29 total, 26 usable; 1 with permanent-surface runway; 2 with runways
4,000-7,999 ft.
Telecommunications: the system consists of a few open-wire lines and low-powered
radiocommunication stations; Mbabane is the center; 5,100 telephones; 35,000
radio receivers; 7 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 100,000; 50,000 fit for military service
None, police only
Approved For Release 2064909/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 5 CAA-RDP79-01051A000500010001-1
173,000 sq. mi.; 8% arable, 1% meadows and pastures, 55%
forested, 36% other
L Land boundaries: 1,365 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 12 n. mi.)
Coastline: 2,000 mi.
Railroads: 7,578 mi.; Swedish State Railways (SJ) 7,004 mi. standard
gage (4''8 1/2"), 4,373 mi. electrified, 725 mi. double tracked; 165 mi. narrow
gage (3''6" and 2''11"), and 311 mi. standard gage (4'' 8 1/2") and 98 mi. narrow
gage (2''11") are privately owned and operated
Highways: 61,000 mi.; 44,550 mi. are crushed stone, gravel, or improved
earth; and 16,395 mi. are bitumen, concrete, stone block, or cobblestone
Inland waterways: 1,268 mi. navigable for small steamers and barges
Ports: 17 major, and 23 minor
Merchant marine: 345 ships (1,000 GRT or over) totaling 5,181,580 GRT, 7,940,600
DWT; includes 13 passenger, 150 cargo, 49 tanker, 47 bulk, 86 specialized
carrier
Civil air: 66 major transports registered
Airfields: 216 total, 186 usable; 95 with permanent-surface runways; 5 with
runways 8,000-11,999 ft., 65 with runways 4,000-7,999 ft.; 9 seaplane
stations
Telecommunications: excellent domestic and international facilities; 4,636,000
telephones; 42 AM, 85 FM, and 196 TV stations; 5 million radio and 2.7
million TV receivers; 10 submarine cables, 4 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 1,894,000; 1,660,000 fit for military service;
56,000 reach military age (19) annually
Military budget: for fiscal year ending 30 June 1973, $1.47 billion;
about 12% of central government budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 FIA -fRP 79-01051A000500010001-1
LAND:
16,000 sq. mi.; 10% arable, 42% meadows and pastures, 21%
waste or urban, 24% forested, 3% inland water
Land boundaries: 1,171 mi.
Railroads: 3,040 mi.; 2,195 mi. 4''8 1/2" gage, 780 mi. double track; 845 mi.
narrow gage (810 mi. at 3''3 3/8", 35 mi. at 2''7 1/2"); 3,040 mi. electrified
Highways: 37,158 mi., all paved
Pipelines: crude of], 195 mi.
Inland waterways: 41 mi.; Rhine River-Basel to Rheinfelden, Schaffhausen to
Constanz; in addition, there are 12 navigable lakes ranging in size from
Lake Geneva to Hallwilersee
Ne ie rail -- 34.8 million metric tons (1963); 4.59 billion ton/km.
1963
Ports: 1 major, 2 minor
Merchant marine: 28 ships (1,000 GRT or over) totaling 214,600 GRT, 308,300
DWT; includes 25 cargo, 3 bulk; fleet is registered in Basel, operates
mainly out of Genoa, Hamburg, and Rotterdam
Civil air: 60 major transport aircraft
Airfields: 89 total, 73 usable; 35 with permanent-surface runways; 2 with
runways over 12,000 ft., 6 with runways 8,000-11,999 ft., 1] with runways
4,000-7 ,999 ft.
Teleconmmunications: excellent domestic, international, and broadcast services;
3.27 million telephones; 1.92 million radio and 1.52 million TV receivers;
6 AM, 81 FM, and 247 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,520,000; 1,315,000 fit for military service;
45,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December 1972, $546.2 million; 24%
of central government budget
Approved For Release 2004769/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 ‘GIAJRDP79-01051A000500010001-1
LAND:
78,700 sq. mi.; 47% arable, 29% grazing, 2% forest,
21% desert
Land boundaries: 1,365 (1967) (excluding occupied area
1,340 mi.)
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 120 mi.
Railroads: 649 mi.; 459 mi. standard gage, 190 mi. narrow gage (3''5 3/8")
Highways: 7,150 mi.; 4,300 mi. paved, 810 mi. gravel or crushed stone, 1,540 mi.
improved earth, 497 mi. unimproved earth
Inland waterways: 420 mi.; of little importance
Pipelines: crude o11, 1,810 mi.; refined products, 320 mi.; natural gas 140 mi.
Ports: 3 major, 3 minor
Civil air: 7 major transport aircraft
Airfields: 87 total, 26 usable; 22 with permanent-surface runways; 1 with runway
Sys 12,000 ft., 17 with runways 8,000-11,999 ft., 4 with runways 4,000-
7,999 ft.
Telecommunications: fair international radioconmunication service; fair domestic
teleconmmunication service; 115,000 telephones; 1,000,000 radio and 118,000 TV
receivers; 5 TV and 5 AM stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,563,000; 845,000 fit for military service;
about 73,000 reach military age (19) annually
Approved For Release 2004¢09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release sO ee
362,800 sq. mi. (including islands of Zanzibar and Pemba,
1,020 sq. mi.); 6% inland water, 15% cultivated, 31%
grassland, 48% bush forest, woodland, on mainland; 60%
arable, of which 40% cultivated on islands of Zanzibar
and Pemba
Land boundaries: 2,413 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 885 (this includes Mafia Island, 70; Pemba
Island, 110; and Zanzibar, 132)
Railroads: 1,950 mi.; 312 mi. 3''6" gage; 1,638 mi., meter gage, 4 mi. double track;
Tanzania portion of Tan-Zam Railroad currently under construction
Highways: total 30,000 mi., including 390 mi, on Zanzibar Island and 277 mi. on
Pemba and Mafia Islands; about 1,400 mi. bituminous treated, (370 mi. on
Zanzibar and Pemba); 28,600 mi. gravel, crushed stone, or unimproved earth
Pipelines: refined products 610 mi.
Inland waterways: 730 mi. of navigable streams; several thousand mi. navigable
on Lakes Tanganyika, Victoria, and Nyasa
Ports: 4 major, 8 minor
Merchant marine: 3 cargo ships (1,000 GRT or over) totaling 16,000 GRT, 22,100
DWT
Civil air: 9 major transport aircraft
Airfields: 103 total, 91 usable; 8 with permanent-surface runways; 1 with runway
8,000 to 11,999 ft., 39 with runways 4,000-7,999 ft.; 4 seaplane stations
Telecommunications: telephone and telegraph good in main centers, only fair
outside main towns; 36,100 telephones; 200,000 radio receivers; 4 AM, no FM
or TV stations; 4 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 2,263,000; 1,810,000 fit for military service
Approved For Release 2084/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release a TPN ArT ea cece
LAND:
198,000 sq. mi.; 24% in farms, 56% forested, 20% other
Land boundaries: 3,025 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,000 mi.
Railroads: 2,382 mi. meter gage; 60 mi. double track
Highways: 12,590 mi.; 5,440 mi. paved, 4,820 mi. crushed stone or gravel, 2,330
earth and laterite
Inland waterways: 2,485 mi. principal waterways; 2,300 mi. with navigable depths
of 3 ft. or more throughout the year; numerous minor waterways navigable by
shallow-draft native craft
Ports: 2 major, 16 minor
Merchant marine: 43 ships (1,000 GRT or over) totaling 79,700 GRT, 116,700 DWT;
includes 14 cargo, 8 tanker, 1 specialized carrier
Airfields: 223 total, 180 usable; 45 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 2] with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: service to general public being improved, but still inadequate;
bulk of service to government activities provided by numerous radi ocommunica-
tion stations and radio-relay network; satellite ground station connects to
Intelsat LI and will connect to Indian Ocean satellite; 152,959 telephones;
2,800,000 radios; 230,000 televisions; estimated 50 AM, 5 FM, and 6 TV
stations in two government-controlled networks; U.S. military submarine
cable to South Vietnam
DEFENSE FORCES:
Military manpower: males 15-49, 9,336 ,000; 5,685,000 fit for military service;
about 410,000 reach military age (18) annually
Military budget: for fiscal year ending 30 September 1972, $254,000,000; 18% of
central government budget
Approved For Release 2004/0715 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : a ees
0G
LAND:
22,000 sq. mi.; nearly half total is arable, under 15%
cultivated
. Land boundaries: 940 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 35 mi.
Railroads: 275 mi. meter gage, single track
Highways: approx. 4,475 mi.; 235 mi. paved, 120 mi. gravel, 910 mi.
improved earth, 3,210 mi. unimproved
Inland waterways: section of Mono River and about 30 mi. of coastal lagoons
and tidal creeks
Ports: 1 major, 1 minor
Civil air: 1 major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-surface runway 4,000-7,999 ft.
Telecommunications: Togo has poor system based on skeletal network of open-wire
lines, supplemented by a few radiocommunication stations; only center is
Lome; 4,600 telephones; 45,000 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 435,000; 220,000 fit for military service;
no conscription
Approved For Release 200409/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : 7 oY a aac esa
LAND:
385 sq. mi. (150 islands); 77% arable, 3% pasture, 13%
forest, 3% inland water, 4% other
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 260 mi. (est.)
Railroads: none
Highways: 365 mi.; 132 mi. metalled all-weather, 233 mi. earth
Ports: 5 minor
mre marine: 1 cargo ship (1,000 GRT or over) totaling 1,800 GRT, 2,700
Civil air: no major transport aircraft
Airfields: 3 total; 1 usable, with grass runway 7,000 ft.; 1 seaplane station
Teleconmunications: 931 telephones; 8,000 radio sets; no TV sets; 1 AM station
Approved For Release 2004/09/15 : 244-RDP79-01051A000500010001-1
Approved For Release 200A OA Sang fp Beh 79-01051A000500010001-1
LAND:
1,980 sq. mi.; 41.9% in farms (of which 25.7% cropped or
fallow, 1.5% pasture, 10.6% forests, 4.1% unused or
. built-on), 58.1% outside of farms, including
grassland, forest, built-up area, and wasteland
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 225 mi.
Railroads: none
Highways: 4,200 mi.; 2,500 mi. paved, 1,700 mi. gravel or otherwise improved
Pipelines: crude 011, 240 mi.; refined products, 12 mi.; natural gas, 130 mi.
Ports: 3 major, 6 minor
Civil air: 8 major transport aircraft
Airfields: 12 total, 6 usable; 3 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecomnunications: excellent international service via tropospheric scatter
links to Barbados and Guyana; good local service; satellite ground
station; 61,400 telephones; est. 250,000 radio and 64,000 TV receivers;
2 AM, 2 FM, and 3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 241,000; 157,000 fit for military service
Supply: mostly from U.K,
Military budget: proposed for fiscal year ending 31 December 1969, $2,500,000;
about 1.5% of central government budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Rel 2004/09/15 : - - e
pprov ease / Tun YeROP?9 01051A000500010001-1
LAND:
63,400 sq. mi.; 28% arable land and tree crops, 23% range
and esparto grass, 6% forest, 43% desert, waste or
” urban
Land boundaries: 875 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi. follows 50 meter isobath in
south; maximum extent 80 n. mi.)
* Coastline: 710 mi. (includes offshore islands)
Railroads: 1,273 mi.; 309 mi. standard gage (4''8 1/2"), mi. double 964
mi. meter gage (3''3 3/8")
Highways: 10,000 mi.; 4,560 mi. mostly bituminous treatment, 465 mi. gravel,
2,050 mi. improved earth, 2,925 mi. unimproved earth
Pipelines: crude oi], 495 mi.; refined products, 6 mi.; natural gas, 45 mi.
Ports: 4 major, 8 minor
Merchant marine: 10 ships (1,000 GRT or over) totaling 25,800 GRT, 34,400 DWT;
includes 6 cargo, 1 tanker, 3 specialized carrier
Civil air: 6 major transport aircraft
Airfields: 60 total, 36 usable; 10 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: the system is above the African average in amount and
capacity of facilities which consist of open-wire lines with multiconductor
cable or radio relay on trunk routes; key centers are Safaqis, Susah, Bizerte,
and Tunis; 76,400 telephones; 400,000 radio and 75,000 TV receivers; 3 AM,
3 FM, and 7 TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 1,173,000; 630,000 fit for military service;
about 58,000 reach military age (20) annually
Approved For Release 2004/69/15 : CIA-RDP79-01051A000500010001-1
15; CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/ uly
LAND:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mi.)
Coastline: 4,475 mi.
Railroads: 4,991 mi.; 4,940 mi. 4°8 1/2" gage, 51 mi. double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi1, 402 mi.; refined products, 1,277 mi.
Ports: 10 major, 35 minor
Merchant marine: 88 ships (1,000 GRT or over) totaling 596,300 GRT, 829,500 DWT;
includes 12 passenger, 52 cargo, 11 tanker, 11 bulk, 2 specialized carrier
Civil air: 17 major transport aircraft
Airfields: 119 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 18 with runways 8,000-11,999 ft., 25 with runways
4,000-7,999 ft.; 2 seaplane stations
Teleconmunications: excellent international radiocommunication and fair domestic
telecommunication services; 577,000 telephones; 3.1 million radio and 50,000
TV receivers; 39 AM, 2 FM, and 7 TV stations; communications satellite ground
station to be operational in 1972
DEFENSE FORCES:
Military manpower: males 15-49, 9,585,000; 5,655,000 fit for military service;
about 402,000 reach military age (20) annually
Military budget: for fiscal year ending 28 February 1973, $599.7 million;
about 19% of central government budget
Approved For Release 2004/8685 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 ND ee 05000 1000-1
LAND:
91,000 sq. mi.; 21% inland water and swamp, including
territorial waters of Lake Victoria, about 21%
cultivated, 13% national parks, forest, and game
reserves, 45% forest, woodland, and grassland (1970)
Land boundaries: 1,665 mi.
Railroads: 760 mi.; all meter gage, single track
Highways: 31,330 mi. total; 940 mi. bituminous surface treatment; 10,390 mi.
crushed stone, gravel, laterite, and improved earth; 20,000 mi. unimproved
earth roads and tracks
Inland waterways: Lake Victoria, Lake Albert, Lake Kyoga, Lake George, and
Lake Edward (6,010 mi.); Kagera River and Victoria Nile (380 mi.)
Ports: 1 major (Port Bell on Lake Victoria)
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 5,500 GRT, 9,100 DWT
Civil air: 6 major transport aircraft
Airfields: 50 total, 43 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 11 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: telephone and telegraph services fair to good, intercity
connections based on 3 or 12 channel carrier systems; 30,200 telephones;
260,000 radio and 15,000 TV receivers; 2 AM, no FM, and 6 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 2,420,000; about 1,370,000 fit for military
service
Military budget: for fiscal year ending 30 June 1972, $42.7 million; 16.6% of
total budget
Approved For Release 2004/092715 : CIA-RDP79-01051A000500010001-1
Approved For Release apna eh Ee oe epee toons
LAND:
8,600,000 sq. mi.; 9.3% cultivated, 37.1% forest and
brush, 2.6% urban, industrial, and transportation,
# 16.8% pasture and natural hay land, 34.2% desert,
swamp, or waste
Land boundaries: 12,595 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
‘ Coastline: 29,000 mi. (incl. Sakhalin)
Railroads: 84,008 mi.; 81,400 mi. broad gage, 2,609 mi. narrow gage; 58,608 mi.
broad gage single track; 21,064 mi. electrified; does not include industrial
lines (1970)
Highways: 934,000 mi.; 99,000 mi. paved, 266,000 mi. gravel, crushed stone,
569,000 mi. improved or unimproved earth (1970)
Inland waterways: 90,000 mi. navigable, exclusive of Caspian Sea; 27,100 mi.
principal routes (1972)
Pipelines: crude oi1, 21,500 mi.; refined products, 5,500 mi.; natural gas,
44,000 mi.
Ports: 63 major (most important: Leningrad, Murmansk, Odessa, Novorossiysk,
Vladivostok, Nakhodka); 122 selected minor (1972)
Freight carried: rail -- 3,192.3 million short tons, 1,708.6 billion short
ton/mi. (January 1971); highways -- 17,388.0 million short tons, 167.0
billion short ton/mi. (January 1971); waterway -- 419.6 million short tons,
119.2 billion short ton/mi. (January 1972)
Merchant marine:','24ce82f34c71bdb70dd3714e6d0355d07009b946c5bbaa8c20cf260a2fe8947f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9519b285eb003356508687c466ec973bb24741cb84891e6dcdeefb839e5841c',1973,'DZ','Algeria','communications',63,'1,459 ships (1,000 GRT or over) totaling 9,548,750 GRT,
12,321,900 DWT; includes 64 passenger, 695 cargo (includes dry cargo,
refrigerated cargo, combination cargo-passenger, combination cargo-training),
266 tanker, 104 bulk container, 320 timber carrier, 12 specialized carrier;
145 dry cargo ships have long hatches ranging from 53 ft. to 79 ft. in length;
530 merchant ships based in Black Sea, 332 in Baltic Sea, 410 in Soviet Far
East and 193 in Barents/White Seas
Airfields: over 3,200 total; 547 with permanent-surface runways; 36 with
runways over 12,000 ft., 432 with runways 8,000-11,999 ft., 813 with runways
4,000-7,999 ft.; 2 seaplane stations
DEFENSE FORCES:
Nuclear weapons: satisfies major requirements of Soviet forces
Supply: fully supplies own needs
Military budget: estimated military expenditures for 1971 were 16.6 billion rubles,
approximately 5% of estimated GNP, or equivalent to about $60.4 billion; these
expenditures exclude research and development
Approved For Release 200470$/15 : CIA-RDP79-01051A000500010001-1
is
Approved For Release 2004/08/15 AG ERR ee ooo net
LAND:
32,000 sq. mi.; almost al] desert, waste or urban
Land boundaries: 680 mi. (does not include boundaries
between adjacent U.A.E. states)
i
WATER: “Al ARABIA
Limits of territorial waters (claimed): Abu Dhabi 3 n. mi., |svom poh
Sharjah 12 n. mi., others not available
Coastline: 900 mi.
Railroads: 728 mi., 320 mi. meter gage, single track; Ouagadougou to Abidjan,
Ivory Coast line
Highways: 10,380 mi.; 200 mi. paved, 3,550 mi. improved, 6,630 mi. unimproved
Civil air: no major transport aircraft
Airfields: 59 total, 51 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 2 with runway 4,000-7,999 ft.
Telecommunications: al] services generally poor; 2,600 telephones; 88,000 radio
receivers; 6,000 TV receivers; 2 AM, no FM, and 1 TV stations (broadcasts
temporarily suspended)
DEFENSE FORCES: ;
Military manpower: males 15-49, 1,344,000; 640,000 fit for military service; no
conscription
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1972, $5.0 million; 11.8% of
total budget
Approved For Release 2004909/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 icy eee
LAND:
72,200 sq. mi.; 94% agricultural land (73% pasture, 11%
cropland) 16% forest, urban, waste and other
re Land boundaries: 840 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 410 mi.
Railroads: 1,870 mi., all standard gage and government owned (1970)
Highways: 32,200 mi.; 3,700 mi. paved, 4,600 mi. otherwise surfaced, 9,600 mi.
improved earth, 14,300 mi. earth tracks
Inland waterways: 1,068 mi.; used by coastal and shallow-draft river craft
Freight carried: highways 80% of total cargo traffic, rail 15%, waterways 5%
Ports: 4 major, 6 minor
Merchant marine: 13 ships (1,000 GRT or over) totaling 139,800 GRT, 219,500
DWT; includes 6 cargo, 7 tanker; includes 2 naval tanker sometimes used
commercially
Civil air: 9 major transport aircraft
Airfields: 86 total, 62 usable; 6 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 10 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: most modern facilities concentrated in Montevideo; 220,000
telephones; 1.1 million radio and 250,000 TV receivers; 65 AM, 3 FM, and 21
TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 724,000; 565,000 fit for military service; no
conscription
Supply: dependent on U.S. for current supplies, with few exceptions
Military budget: for fiscal year ending 31 December 1972, $26.7 million; 9.5%
of central government budget
Approved For Release 2004/69/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/45 -n FlAPRPP79-01051A000500010001-1
LAND:
0.169 sq. mi.
Land boundaries: 2 mi.
Railroads: 233 mi. 4''8 1/2" gage; al] single track; 107 mi. government owned,
126 mi. privately owned
Highways: 34,600 mi.; 11,200 mi. paved, 9,200 mi. gravel, 4,200 mi. improved
earth, 10,000 unimproved (including trails)
Inland waterways: 4,450 mi.; Orinoco River and Lake Maracaibo accept oceangoing
vessels
Pipelines: crude 01], 3,800 mi.; refined Products, 250 mi.; natural gas,
1,550 mi.
Ports: 6 major, 17 minor
Merchant marine: 38 ships (1,000 GRT or over) totaling 349,200 GRT, 514,300 DhT;
includes 20 cargo, 13 tanker, 3 bulk, 2 specialized carrier
Civil air: 59 major transport aircraft
Airfields: 451 total, 238 usable; 89 with permanent-surface runways; 7 with
runways 8,000-11,999 ft., 72 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: extensive radio relay; local telephone systems greatly expanded;
satellite ground station; over 445 ,000 telephones; est. 3 million radio and
900,000 TV receivers; 150 AM, 50 FM, and 36 TV stations; 3 submarine cables,
1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 2,457,000; 1,685,000 fit for military service;
120,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1972, $292 million;
about 9% of central government budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
VIETNAM, NORTH
LAND:
61,300 sq. mi.; 14% cultivated, 50% forested, 36% urban
inland water, and other
Jo Land boundaries: 1,850 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 490 mi.
b PEOPLE:
Population: 20,324,000, average annual growth rate 1.1%
(current)
Ethnic divisions: 85%-90% predominantly Vietnamese; ethnic
minorities include Muong, Thai, Meo, and Man
Religion: Confucianism, Buddhism, Taoism, Catholicism
Language: closely corresponds to the breakdown of ethnic groups
Literacy: claimed to be 95% (1964)
Labor force: (1 January 1970) 9.6 million, not including military; about 70%
agriculture and 10% industry
Railroads: 602 usable route mi., consists of about 25 mi. of standard gage
bas (4''8 1/2"), 438 mi. of meter gage (3''3 3/8"), and 139 mi. of dual gage
(4''8 1/2" and 3''3 3/8"); all single track, none electrified; all government
owned and operated; new rail line under construction between Kep and port
of Hon Gai
Highways: 9,100 mi., plus about 1,600 mi. of seasonally motorable tracks; 900 to
ed 1,000 mi. bituminous surface-treated, remainder gravel, crushed stone, or earth
Inland waterways: 4,200 mi.; 1,800 mi. navigable perennially by craft drawing 6 ft.
Ports: 3 major, 12 minor
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS CeBRFPMET For Release
Merchant marine: 6 ships (1,000 GRT or over) totaling 14,100 GRT, 14,400 DWT;
includes 3 cargo,
Airfields: 16 total; 11 with permanent-surface runways; 2 with runway 8,000-
11,999 ft., 12 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Supply: dependent chiefly on China and U.S.S.R. for virtually all
equipment; smaller amounts from other Communist countries; produces negligible
quantities of infantry weapons, ammunition, and explosive devices
Military budget: no recent data available; for fiscal year ending 31 December
1962, estimated defense expenditures 382 million dongs; about one-fifth of
total budget (estimated value $103 million); military aid from U.S.S.R. and
China now so extensive that actual allocation of North Vietnam''s domestic
resources to defense would not be indicative of total military effort
Approved For Release 2084/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/19 7 lA-RRFF9-01051A000500010001-1
LAND:
66,000 sq. mi.; 35% arable (17% cultivated), 32% forested,
33% other
Land boundaries: 1,025 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 10.8 n. mi.)
Coastline: 1,650 mi.
Railroads: 770 mi.
Highways: 12,200 mi.; 3,000 mi. bituminous, 1,717 mi. gravel and crushed stone,
1,483 mi. improved earth, 6,000 mi. unimproved earth
Inland waterways: about 6,800 mi. navigable; more than 1,400 mi. navigable at all
times by vessels up to 6 ft. draft
Ports: 6 major, 20 minor
Merchant marine: 34 ships totaling 34,900 GRT, 50,300 DWT; includes 29 cargo, 3
tanker, 2 bulk; only 8 ships over 1,000 GRT
Airfields: 341 total, 172 usable; 66 with permanent-surface runways, 8 with
runways 8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 4 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 4,519,000; 3,025,000 fit for military service;
143,000 reach military age (18) annually
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/18.- GIARhE /9-01051A000500010001-1
LAND:
1,100 sq. mi.; comprised of 2 large islands of Savai''i and
Upolu and several smaller islands, including Manono
> and Apolima; 65% forested, 24% cultivated, 11% industry, |,
waste, or urban
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 250 mi.','9bbe4f58e8d2fc9fbd7401253f24e243403efcb830eb0940a121f722ab52aa01','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bcc8ceb69c57f08a9e74c01b4871a457214fd6e5ba38172efac68ac66c433f6',1973,'DO','Dominican Republic','communications',64,'LAND:
18,800 sq. mi.; 14% cultivated, 4% fallow, 17% meadows
and pastures, 45% forested, 20% built-on or waste
Land boundaries: 224 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. (fishing
12 n. mi.)
Coastline: 800 mi.
Railroads: 1,000 route mi. of which 65 mi. government-owned common carrier
(3''6" gage) and 935 mi. privately owned plantation network (approximately 4
different gages ranging from 1''10 1/2" to 4''8 1/2", with 2’6" predominating)
Highways: 6,200 mi.; 3,200 mi. paved, 900 mi. gravel, 1,400 mi. improved earth,
700 mi. unimproved earth
Pipelines: product lines (1.5 mi. and 43 mi.) under construction, to be completed
in 1971
Ports: 5 major, 17 minor
Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 5,000 GRT, 7,700 DWT
Civil air: 16 major transport aircraft
Airfields: 62 total, 42 usable; 7 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: relatively efficient domestic system based on islandwide
radio relay network; 53,000 telephones; 400,400 radio and 120,000 TV receivers,
101 AM, 27 FM, and 8 TV stations; 3 submarine cables, 1 of which is coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 1,008,000; 640,000 fit for military service;
reach military age (18) annually
Supply: dependent upon U.S. and Western Europe
Military budget: for fiscal year ending 31 December 1972, $33.3 million; about
11.0% of central government budget
Approved For Release 200449/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/1 5c GyROP79-01051A000500010001-1
106,000 sq. mi. (including Galapagos Islands); 11%
cultivated, 8% meadows and pastures, 55% forested,
26% waste, urban, or other
Land boundaries: 1,200 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 750 mi. (includes Galapagos Is.)
Railroads: 710 mi.; 615 mi. 3''6" gage, 95 mi. 2''°5 1/2" gage; all single track
Highways: 14,200 mi.; 1,900 mi. paved, 5,100 mi. gravel, 3,800 mi. improved
earth, 3,400 mi. unimproved earth
Tnland waterways: 960 mi.
Pipelines: crude 011, 390 mi.; refined products, 50 mi.
Ports: 2 major, 11 minor
Merchant marine: 9 ships (1,000 GRT or over) totaling 47,400 GRT, 54,800 DWT;
includes 7 cargo, 2 tanker
Civil air: 43 major transport aircraft
Airfields: 192 total, 169 usable; 13 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: facilities generally adequate only in largest cities; 105,000
telephones; 680,000 radio and 120,000 TV receivers; 220 AM, 20 FM, and 13
TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,547,000; 985,000 fit for military service;
average number reaching military age (20) annually 65,000
Supply: dependent primarily on U.S.; some major purchases from Western Europe
Military budget: for fiscal year ending 31 December 1972, $35.3 million; about
10.4% of central government budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : GAsRDP79-01051A000500010001-1
LAND:
386,000 sq. mi. (including 22,200 sq. mi. occupied by
Israel); 2.8% cultivated (of which about 70% multiple
cropped); 96.5% desert, waste, or urban; 0.7% inland
water
Land boundaries: 1,635 mi. (1967), excludes occupied area
1,534 mi.
WATER:
s Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,140 mi. (1967), excludes occupied area 1,340 mi.
Railroads: 2,976 mi.; 570 mi. double track; 15 mi. electrified; 2,594 mi. 4''8 1/2"
gage, 156 mi. 3''3 3/8" gage, 226 mi. 2''5 1/2" gage
Highways: 29,000 mi.; 5,190 mi. paved, 7,130 mi. gravel, crushed stone, and
improved earth, 16,680 mi. unimproved earth, additional 1,500 mi. (mostly
paved) in territory (Sinai) occupied by Israel]
Inland waterways: 2,100 mi.; Suez Canal, 100 mi, long, temporarily closed to
navigation because of sunken vessels; normally used by ocean-going vessels
drawing up to 38 ft. of water; Alexandria-Cairo waterway navigable by barges
of 500-ton capacity; Nile and large canals by barges of 420-ton capacity;
Ismailia Canal by barges of 200- to 300-ton capacity; secondary canals by
sailing craft of 10- to 70-ton capacity
Freight carried: Suez Canal (1966) -- 242 million tons of which 175.6 million
tons were POL
Pipelines: crude oi], 130 mi.; refined products, 390 mi.; natural gas, 30 mi.
Ports: 3 major, 8 minor
Merchant marine: 42 ships (1,000 GRT or over) totaling 200,000 GRT, 264,200
DWT; includes 5 passenger, 29 cargo, 8 tanker
Civil air: 17 major transport aircraft
Airfields: 146 total, 78 usable; 65 with permanent-surface runways; 42 with
runways 8,000-11,999 ft., 21 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: second best system of coaxial and multiconductor cables,
open-wire lines, and radio communication stations in Africa; principal centers
Alexandria and Cairo, secondary centers Al Mansurah, Ismailia, and Tanta;
365,000 telephones; 4.5 million radio and 560,000 TV receivers; 12 AM, 1 FM,
and 26 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,050,000; 5,090,000 fit for military service;
about 357,000 reach military age (20) annually
Approved For Release 2004/99/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','2b3b0a85a5351f17d27cc4013652daa2cbe62a83b55c1ab47069f62936b39579','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91d068a38a45b841778225bebbee4c05c31ace43d4cf147d0d95cbf30f15ef5c',1973,'SV','El Salvador','communications',68,'LAND:
8,260 sq. mi.; 32% cropland (9% corn, 5% cotton, 7%
coffee, 11% other), 26% meadows and pastures, 31%
nonagricultural, 11% forested
Land boundaries: 320 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 190 mi.
Railroads: 375 mi., 3''0" gage; single-tracked; 285 mi. privately owned, 90 mi.
government owned
Highways: 5,400 mi.; 750 mi. bituminous, 950 mi. gravel or crushed stone, 3,700 mi.
earth
Inland waterways: Lempa River partially navigable
Ports: 3 major, 1 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,600 GRT, 1,800 DWT
Civil air: 8 major transport aircraft
Airfields: 146 total, 116 usable; 3 with permanent-surface runway 4,000-7,999 ft.;
] seaplane station
Telecommunications: nationwide trunk radio relay system; connection to international
Central American microwave net; 40,000 telephones; 500,000 radio and 107,000
TV receivers; 57 AM, 6 FM, and 4 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 860,000; 530,000 fit for military service;
42,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1972, $8.7 million; about
6% of central government budget (excludes public security forces)
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','79fb583b7e4ce64cb2a4221dafba4d327d4046997b51bcdb263c7f8ba405ce14','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d89f9a821b63e384ff0568733c628e4862b95dd4592785d087375edb98b85441',1973,'GQ','Equatorial Guinea','communications',72,'10,800 sq. mi.; Rio Muni, about 10,000 sq. mi., largely
forested; Fernando Po, about 800 sq. mi.
Land boundaries: 335 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 184 mi.
Railroads: 630 mi.; 420 mi. 3''3 3/8" gage, 20 mi. 3''6" gage, 190 mi. 3''1
3/8" gage; all single track
Highways: 14,500 mi.; 1,250 mi. bituminous, 3,000 mi. crushed stone, gravel, or
stabilized earth, 10,250 mi. earth
Inland waterways: navigation possible on Lake Tana and on approx. 140 mi. of
unconnected and basically unimproved waterways, of which only 71 mi. are
navigable year round
Ports: 2 major, 1 minor
Merchant marine: 6 ships (1,000 GRT or over) totaling 40,900 GRT, 60,200 DwT;
includes 3 cargo, 2 tanker, 1 bulk
Civil air: 16 major transport aircraft
Airfields: 197 total, 118 usable; 7 with permanent-surface runways; 5 with run-
ways 8,000-11,999 ft., 50 with runways 4,000-7,999 ft.
Telecommunications: system better than in most African countries; composed of
open-wire lines, radiocommunication stations, and small number of multi-
conductor cable and radio-relay links; principal center Addis Ababa, secondary
center Asmara; 46,000 telephones; 500,000 radio receivers; 8,500 TV receivers;
5 AM, no FM, and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 6,614,000; 3,420,000 fit for military service;
average number reaching military age (18) annually 265,000
Approved For Release 2094/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/45 GARR 79-01 051A000500010001-1
LAND:
540 sq. mi.; less than 5% arable, of which only a fraction
cultivated; archipelago consisting of 18 inhabited
islands and a few uninhabited islets
WATER: :
Limits of territorial waters (claimed): 3n. mi.;
fishing, 12 n. mi. (from extended base lines)
Coastline: 475 mi.','5cce6f39f6f5e65f4a36085d27189ea0a6b497a370f2db0aba39a9f8a4117084','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4ef124c339c066b3e090f704881a04feee643129df004f2e32833bc157240d9',1973,'FJ','Fiji','communications',79,'LAND:
7,055 sq. mi.; landownership -- 83.6% Fijians, 1.7% Indians, F
6.4% government, 7.2% European, 1.1% other; about 30%
of land area is suitable for farming
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing 3 n. mi.) .
Coastline: 700 mi. (est.)
Railroads: none ;
Highways: 1,555 mi.; 150 mi. paved, 1,325 mi. gravel or crushed stone, 80 mi.
unimproved earth
Inland waterways: 126 mi.; 76 mi. navigable by motorized craft and 200-ton barges
Ports: 6 major, numerous minor landings
Approved For Release 2004/09/15 : ©M-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d):
Civil air: 6 major transport aircraft (2 leased)
Airfields: 16, 11 usable; 1 with runway 8,000-11,999 ft., 1 with runway 4,000-7,999
ft., 2 seaplane stations
Telecommunications: modern local, interisland, and international (wire/radio
integrated) public and special-purpose telephone, telegraph, and teleprinter
facilities; regional radio center; important COMPAC cable link between 4
U.S./Canada and New Zealand/Australia, et al; 16,860 telephones; 52,000
radio receivers; 5 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 141,000; 76,000 fit for military service; 6,000 -
reach military age (18) annually
Military budget: the defense of the Fiji Islands was the responsibility of the
U.K. until 10 October 1970; the military budget for 1971 is $314,000
Approved For Release 2094/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release Be eM Te ee
LAND:
130,000 sq. mi.; 8% arable, 65% forested, 27% other
Land boundaries: 1,575 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi.;
Aland Islands, 3 n. mi.
Coastline: 700 mi. (approx.) includes islands','1f42745f94c92b8c4c58eb0661facd1567ab2f55bd8f9ebf00b760f692148021','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11d63b64c37f22a345e4f8bb7d160baeb3c397bf646dfe21ba6175751978a772',1973,'FR','France','communications',83,'Railroads: 24,815 mi.; 23,494 mi. standard gage, 1,321 mi. other gages (3'' 3 3/8"
to 4'' 9"); 5,886 mi. electrified, 9,892 mi. double or multiple track
Highways: National, Departmental, and Communal roads total 487,600 mi. comprising
292,600 mi. paved, 190,000 mi. crushed stone and gravel, and 14,600 mi.
improved earth; in addition, there are approximately 434,000 mi. of local
farm and forest roads
Inland waterways: 9,320 mi.; 4,820 mi. heavily traveled
Pipelines: total, 10,000 mi.; crude oil, 1,400 mi.; refined products, 2,700 mi.;
natural gas, 5,900 mi.
Ports: 22 major, 165 minor
Merchant marine: 428 ships (1,000 GRT or over) totaling 7,031,700 GRT, 11,288,700
DWT; includes 13 passenger, 204 cargo, 112 tanker, 53 bulk, 46 specialized
carrier
Civil air: 320 major transport aircraft
Airfields: 519 total, 427 usable; 169 with permanent-surface runways; 1] with
runway over 12,000 ft., 19 with runways 8,000-11,999 ft., 127 with runways +
4,000-7 ,999 ft.; 10 seaplane stations
Telecommunications: highly developed system provides satisfactory telephone,
telegraph, and radio and TV broadcast services; 9.67 million telephones; 16.5
million radiobroadcast receivers; 12.18 million TV receivers; countrywide AM,
FM, and TV service including 52 AM, 73 FM, and 1,162 TV stations; 17 submarine Ad
cables (16 coaxial); 2 communication satellite ground stations
Approved For Release 2004/99/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
DEFENSE FORCES:
Military manpower: males 15-49, 12,584,000; fit for military service 10,130,000;
423,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1972, $6.1 billion; about
17% of central government budget
Approved For Release 2004/09/15 : GLA-RDP79-01051A000500010001-1
Approved For Release 2004/04 Ay GlAgRPP79-01051A000500010001-1
D:
35,100 sq. mi.; 90% forested, 10% wasteland, built-on,
inland water, and other of which .05% is cultivated
and pasture
Land boundaries: 735 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 235 mi.
Railroads: 20 mi. private plantation line, 1''11 5/8" gage; 8 mi. abandoned
narrow-gage line
Highways: 450 mi.; 250 mi. paved, 200 mi. improved earth or gravel
Inland waterways: 290 mi.; navigable by small oceangoing vessels and river
and coastal steamers; 2,110 mi. possibly navigable by native craft
Ports: 1 major, 7 minor
Civil air: no major transport aircraft
Airfields: 15 total, 13 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft.; 1 seaplane station
Telecommunications: very limited open-wire telecom system with about 6,300
telephones; est. 7,000 radio receivers and 2,900 TV receivers, 1 AM, 2 FM
and 2 TV stations; 1 satellite tracking and control station
DEFENSE FORCES:
Military manpower: males 15-49, 14,000; 10,000 fit for military service
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Releasie2G0 40H :f/AFROIERRS? ARS YARROSO0O 000 1-1
LAND:
9,000 sq. mi.; 89% desert wasteland, 10% permanent pasture,
and less than 1% cultivated
Land boundaries: 321 mi.
&*
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 195 mi. (includes offshore islands)
‘ Railroads: 60 mi. meter gage
Highways: 620 mi.; 50 mi. paved, 570 mi. earth
Ports: 1 major, 1 minor
113
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS ABRROVEd For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Airfields: 27 total, 10 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 5 major transport aircraft (registered in France)
Telecommunications: fair telephone services; poor telegraph facilities; 2,350
telephones; 7,000 radio receivers; 2,000 TV receivers; 1 AM, no FM, and
1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 30,000; about 15,000 fit for military
service
Defense is responsibility of France
]
Approved For Release 2004/69/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 eae
LAND:
102,000 sq. mi.; 75% forested, 15% savanna, 9% urban and
wasteland, less than 1% cultivated
Land boundaries: 1,505 mi.
WATER: :
Limits of territorial waters (claimed): 100 n. mi.
Coastline: 550 mi.
Railroads: none
Highways: 3,820 mi.; 125 mi. paved, 1,960 mi. gravel or crushed stone, 1,425 mi.
improved earth, 310 mi. unimproved earth
Inland waterways: approximately 1,000 mi. perennially navigable
Pipelines: crude oi], 40 mi.
Ports: 3 major, 2 minor
Civil air: 11 major transport aircraft
Airfields: 183 total, 95 usable; 3 with permanent-surface runways; |] with run-
way 8,000-11,999 ft., 15 with runways 4,000-7,999 ft.; 2 seaplane stations
Teleconmunications: fair telephone and telegraph services; good broadcast
coverage in vicinity of Libreville; 2 AM and 2 TV stations; 7,000 telephones;
65,000 radio receivers; 1,300 TV receivers
DEFENSE FORCES:
Military manpower: males 15-49, 128,000; 64,000 fit for military service;
5,000 reach military age (18) annually
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1972, $6,570,000; about
8.7% of total budget
Approved For Release 2004]08/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/1 SETA ee eens 000 1000 tI
LAND:
4,000 sq. mi.; 25% uncultivated savanna, 16% swamps, 4%
forest parks, 55% upland cultivable areas, built-up
areas, etc.
™ Land boundaries: 460 mi.
WATER:
Limits of territorial waters (claimed): 50 n. mi.
(fishing, 18 n. mi.)
% Coastline: 50 mi.
Railroads: none
Highways: 775 mi.; 185 mi. bituminous surface treated, 270 mi. gravel/laterite,
270 mi. unimproved earth
Inland waterways: 377 mi.
Ports: 1 major
Civil air: no major transport aircraft
Airfields: 4 total, 1 usable; 1 with permanent-surface runway; 1 with runway
4,000-7 ,999 ft.; 1 seaplane station
Telecommunications: good telephone and telegraph services; 1,600 telephones;
50,000 radio receivers; 2 AM, no FM or TV stations; 1 submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 91,000: 43,000 fit for military service
Approved For Release 2004/89/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
GERMANY, EAST
LAND:
41,800 sq. mi.; 45% arable, 13% meadows and pasture, 27%
forested, 15% other
Land boundaries: 1,435 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 560 mi. (including islands)
Railroads: 9,050 route mi.; 8,750 mi. standard gage, 300 mi. meter and narrow
gage, 1,750 mi. double track standard gage; 850 mi. overhead electrified (1970)
Highways: about 28,650 mi. classified highways; 8,000 mi. state highways including
950 mi. autobahn; 20,750 mi. district roads; additionally about 29,000 mi.
unclassified minor unpaved roads (1971)
Inland waterways: 1,562 mi. (1972)
Freight carried: rail -- 294.8 million short tons, 29.9 billion short ton/mi.
(1969); highway -- 544.9 million short tons, 8.9 billion short ton/mi. (1971);
waterway -- 17.2 million short tons, 1.6 billion short ton/mi. (1971)
Pipelines: crude oi], 420 mi; refined products, 150 mi., natural gas 200 mi.
Merchant marine: 134 ships (1,000 GRT and over) totaling 1,011,100 GRT, 1,355,100
DWT; includes 1 passenger, 99 cargo, 9 tanker, 12 bulk, 13 specialized
carrier
Airfields: 155 total; 54 with permanent-surface runways; 51 with runways 8,000-
11,999 ft., 42 with runways 4,000-7,999 ft.
DEFENSE FORCES: _. ;
Military manpower: males 15-49, 3,847,000; 3,115,000 fit for military service;
about 132,000 reach military age (18) annually eth
Military budget: for fiscal year ending 31 December 1972, 7.6 billion DME;
about 8.2% of total budget
Approved For Release 2004/@9/15 : CIA-RDP79-01051A000500010001-1
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Next 2 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','e89f7d47571eb14b2533b05be7f784199d32edbae1ccc56990b5da9e3a9fe9a1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a97ac020c14912a6d3500136c89023779f6237efca36deadc2764998b9a6cf16',1973,'GH','Ghana','communications',84,'LAND:
92,000 sq. mi.; 19% agricultural, 60% forest and brush,
21% other
Land boundaries: 1,420 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 335 mi.
Railroads: 599 mi, -- all 3''6" gage; 20 mi. double track; diesel locomotives
gradually replacing steam engines
Highways: 21,350 mi., 3,200 mi. concrete or bituminous surface, 3,750 mi. gravel
or laterite, 3,700 mi. improved earth, 10,800 mi. unimproved earth
Inland waterways: Volta, Ankobra, and Tano rivers provide 145 mi. of perennial
navigation for launches and lighters; additional routes navigable seasonally
by small craft; Lake Volta reservoir provides 700 mi. of arterial and
feeder waterways
Pipelines: refined products, 2 mi.
Ports: 2 major, 1 naval base (Sekondi), 4 minor
Merchant marine: 16 cargo ships (1,000 GRT or over) totaling 117,900 GRT,
157,600 DWT
Civil air: 5 major transport aircraft
Airfields: 22 total, 19 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 8 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone fair to good in urban areas; fairly good telegraph
services; 61,200 telephones; about 750,000 radio receivers; 20 TV receivers;
2 AM, no FM, and 5 TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 2,192,000; 1,170,000 fit for military service;
105,000 reach military age (18) annually
Major ground units: 2 brigades (6 infantry battalions, 1 reinforced airborne
company, 1 mortar battery, 1 field engineer battalion, 1 reconnaissance
battalion)
Military budget: for fiscal year ending 30 June 1972, $38,300,000; 3.5% of
total budget
Approved For Release 200409/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','ad3343edd744641da40b190beb6ef51e35113b83799d2a5c9af9932b7a175bb6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0032214d250b5ce99f235c9d2f74ddeed062acacd4432ac593790c1e8272a722',1973,'GI','Gibraltar','communications',88,'LAND:
2.5 sq. mi.
Land boundaries: 1 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 7.5 mi.
PEOPLE: sieRaL
Population: 27,000 (official estimate for 1 July 1971) =
Ethnic divisions: mostly Italian, English, Maltese, and omen) ALGERIA
Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages; Italian, Portuguese, and
Russian also spoken; English used in the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian laborers
Organized labor: 3,369, in 27 registered trade unions
Railroads: none
Highways: 19 miles, all paved
Ports: 1 major
Civil air: 1 major transport aircraft (registered in U.K.)
Airfields: 1 permanent-surface runway, 4,000-7,999 ft.; 1 seaplane station
Telecommunications: international radioconmunication facilities; automatic
telephone system serving 6,100 telephones; 6,000 radio receivers; 6,870
television receivers; 1 AM, 1 FM, and 2 TV stations; 13 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, about 6,000; about 3,000 fit for military service
Defense is responsibility of United Kingdom
Aircraft: small detachment of fighter/trainer aircraft (3-4)
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 ‘GlAcRDP 79-01 051A000500010001-1
. FINLAND /@y, 1
LAND:
51,200 sq. mi.; 29% arable and land under permanent crops,
40% meadows and pastures, 20% forested, 11% wasteland,
P urban, other
Land boundaries: 740 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
Coastline: 8,500 mi.
v
Railroads: 1,598 mi.; 969 mi. standard gage (4''8 1/2"), 597 mi. meter gage
(3''3 3/8"), 20 mi. 1''11 5/8" narrow gage, 10 mi. 2''5 1/2" narrow gage; all
government owned
Highways: 24,200 mi.; 7,100 mi. paved, 9,100 mi. crushed stone and gravel
4,800 mi. improved earth, 3,200 mi. unimproved earth
Inland waterways: system consists of 3 coastal canals and 3 unconnected rivers
which provide navigable length of just less than 50 mi.
Pipelines: crude oil, 16 mi., refined products, 340 mi.
Ports: 17 major, 37 minor
Merchant marine: 1,553 ships (1,000 GRT or over) totaling 15,816,600 GRT,
25,230,300 DWT; includes 65 passenger, 927 cargo, 255 tanker, 271 bulk,
33 specialized carrier; ethnic Greeks also own an estimated 20,206,300
GRT under other flags: about 17,409,300 GRT under Liberia, 723,300 under
Panama, 2,042,600 under Cyprus, 22,400 under Lebanon, and 8,700 under Somali
Republic
Airfields: 57 total, 54 usable; 36 with permanent-surface runways; 16 with
runways 8,000-11,999 ft., 13 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 35 major transport aircraft
Telecommunications: fairly modern networks reach al] areas on mainland and
islands; 1,300,000 telephones; 1.4 million radio receivers; 280,000 TV
receivers; 28 AM, 10 FM and 23 TV stations; 2 coaxial submarine cables;
communications satellite ground station
Approved For Release 20049/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
DEFENSE FORCES:
Military manpower: males 15-49, 2,172,000; 1,745,000 fit for military service;
about 69,000 reach military age (21) annually
Military budget: for fiscal year ending 31 December 1971, $552 million; 28%
of central government budget
Approved For Release 2004/09/15 : GIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','a1d72e8a2c9a3c632998b1dbd0be49d2a8fb209e4ee7407a53bd4490fc97b142','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec8724022c0cff0b6f01e81d0810686183de197dfd7fc8cfb3d8bf0d26e1b3e2',1973,'GL','Greenland','communications',92,'LAND:
840,000 sq. mi.; less than 1% arable (of which only a
fraction cultivated), 83% permanent ice and snow,
16% other
WATER:
Limits of eo waters (claimed): 3 n. mi. (fishing,
12 n. mi.
Coastline: 27,400 mi. (approx., includes minor islands)','709969546112d614ec50bed7f1b6f57dbd4a76cdefefd33444b973c69e079dd9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7ca7f33e682d4b8df0d8cc35b3d23d63e2b13f3560dc684e3217aa7e0808a30',1973,'GY','Guyana','communications',96,'LAND:
83,000 sq. mi.; 1% cropland, 3% pasture, 9% savanna,
77% forested, 10% water, urban, and waste BRAZIL
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 285 mi.
Railroads: 103 mji., all single track; 85 mi. 3''0" gage, 18 mi. 3''6" gage
Highways: 1,450 mi.; 290 mi. paved, 620 mi. otherwise improved, 540 mi. unimproved
Inland waterways: 3,700 mi.; Demerara River navigable to Mackenzie by ocean
steamers, others by ferryboats, small craft only
Ports: 1] major, 3 minor
Merchant marine: 1 bulk carrier (1,000 GRT or over) totaling 3,000 GRT, 3,100
DWT
Civil air: 6 major transport aircraft
Airfields: 102 total, 89 usable; 4 with permanent-surface runways; 12 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: highly developed telecom system with radio relay network and
over 16,000 telephones; tropospheric scatter link to Trinidad; 250,000 radio
receivers, 2 AM and 1] FM stations
DEFENSE FORCES:
Military manpower: males 15-49, 178,000; 122,000 fit for military service
Supply: mostly U.K., some U.S. equipment
Military budget: for fiscal year ending 31 December 1969, $2.35 million; 2.8%
of central government budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','995eea045dcade12701a0cdc9398005a44d4dcdd8720a8da8475271699429199','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7f7f2fb1a731777cb8526d7fdd068ad4de92980d3c24c6305a5ff4e5c00ffd0',1973,'HT','Haiti','communications',100,'LAND:
10,700 sq. mi.; 31% cultivated, 18% rough pastures,
10% forested, 44% unproductive
Land boundary: 224 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. & rcmua
Coastline: 1,100 mi.
Railroads: 120 mi. 2'' 6" gage, single-track, privately owned industrial line; 5
mi. dual-gage 2'' 6"-3'' 6"; government line dismantled
Highways: 2,000 mi.; 350 mi. paved, 600 mi. otherwise improved, 1,050 mi.
unimproved
Inland waterways: negligible; about 60 mi. navigable
Ports: 2 major, 12 minor
Civil air: 4 major transport aircraft; 3 owned by the air force, 1 privately owned
Airfields: 31 total, 17 usable; 3 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: al) domestic facilities inadequate, international facilities
only slightly better; slow progress in large-scale telephone expansion
program; only 4,450 telephones, est. 282,000 radio and 8,000 TV receivers,
25 AM, 3 FM, and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,286,000; 660,000 fit for military service;
about 53,000 reach military age (18) annually
Military budget: for fiscal year ending 30 September 1972, $5,800,000; about
18% of operational budget
Approved For Release 2094/09/15 : CIA-RDP79-01051A000500010001-1
1-1
2004/09/15 : CIA-RDP79-01051A00050001000
Approved For Release Hea
LAND:
43,300 sq. mi.; 27% forested, 30% pasture, 36% waste,
7% cropland
Land boundaries: 950 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 510 mi.
Railroads: 743 mi.; 443 mi. of 3''6" gage, 300 mi. of 3''0" gage
Highways: 5,300 mi.; 600 mi. paved, 1,500 mi. otherwise improved, 3,200
unimproved
Inland waterways: 750 mi. navigable by small craft
Ports: 3 major, 9 minor
Merchant marine: 12 cargo ships (1,000 GRT or over) totaling 56,800 GRT, 53,600
DWT; all foreign owned and operated
Civil air: 25 major transport aircraft
Airfields: 215 total, 119 usable; 4 with permanent-surface runways; 9 with run-
ways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: improved, but stil] inadequate; connection to international
Central American microwave net; 15,200 telephones; 300,000 radio and 25,000
TV receivers; 104 AM, 10 FM, and 6 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 687,000; 405,000 fit for military service;
about 28,000 reach military age (18) annually
Supply: traditional dependence on U.S. has for the time being shifted to
Western Europe
Approved For Release 2004/9915 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/13), ClA;RDP79-01051A000500010001-1
LAND:
400 sq. mi.; 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country)
Land boundaries: 15 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 455 mi.
Railroads: 22 mi. standard gage; government owned
Highways: 600 mi.; 419 mi. paved, 190 mi. gravel and crushed stone, or earth
Freight carried: rail -- 903,180 short tons (FY68)
Ports: 1 major
Merchant marine: 41 ships (1,000 GRT or over) totaling 383,300 GRT, 584,600
DWT; includes 3 passenger, 22 cargo, 4 tanker, 10 bulk, 2 specialized
carrier; ships registered in Hong Kong fly the U.K. flag; over 400 Hong
Kong-owned ships are registered elsewhere
Civil air: 12 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.; 1 seaplane station
DEFENSE FORCES:
Military manpower: males 15-49, 1,061,000; 820,000 fit for military service;
about 45,000 reach military age (18) annually
Defense is the responsibility of U.K.
Ships: Hong Kong Marine Police, 38 police boats; U.K., U.K. naval ships homeported
in the U.K. operate in the Indian Ocean, Gulf, and Far East; they rotate
assignments within the area and normally one destroyer escort is deployed to
the Hong Kong area; a varied number of auxiliary/service craft are assigned
to the Commander Hong Kong
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','d3f866219b5d1dc9fc9f27cfc898328db20cd0c9148d7c9783961a9b2624cebd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ad6cfbe2cac008a6b7a31ae8f3b74840eeb4b4a2abce990686e831f580950e9',1973,'HU','Hungary','communications',104,'LAND:
35,900 sq. mi.; 60% arable, 14% other agricultural, 16%
forested, 10% other
Land boundaries: 1,395 mi.
Railroads: 5,908 route mi.; 5,098 mi. standard gage, 788 mi. narrow gage
(mostly 2'' 5 7/8"), 22 mi. broad gage (5''0"), 688 mi. double track, 58]
mi. electrified; government owned (1970)
Highways: 18,360 mi.; 11,048 mi. paved, 6,558 mi. crushed stone or gravel, 754
mi. earth (1970)
Pipelines: crude oi1, 500 mi.; refined products, 200 mi.; natural gas, over
1,500 mi.
Inland waterways: 1,320 mi. (1972)
Freight carried: rail -- 129.8 million short tons (1971), 14.0 billion short ton/m
(1971); highway -- 492.0 million short tons, 4.7 million short ton/mi. (1971);
waterway -- 15.4 million short tons, 1.9 billion short ton/mi. includes
international transit traffic (1971)
River ports: 2 principal (Budapest, Dunaujvaros); no maritime ports; outlets are
Rostock, East Germany and ports in Poland (1972)
Merchant marine: 18 cargo ships (1,000 GRT or over) totaling 33,200 GRT,
44,500 DWT
Airfields: 75 total; 13 with permanent-surface runways; 17 with runways 8,000-
11,999 ft., 20 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 2,659,000; 2,140,000 fit for military service;
about 90,000 reach military age (18) annually
Supply: produces small arms, ammunition, explosives, light artillery, naval
ships and craft, an armored reconnaissance vehicle, some trucks, chemical
warfare defensive materiel and small quantities of agents, some types of
electronic equipment; dependent upon Communist countries, primarily the
U.S.S.R., for other military equipment including radar and missiles
Military budget: for fiscal year ending 31 December 1972, 9.72 billion forints;
about 4.5% of total budget
Appr :
pproved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','9765b84b8bf08108b8d04ce05b602877cafad102310cf14b7daee55039875c10','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1b937133e3f6299a8b24b3cda65f6b010329534ac9e564cd8027da238695f38',1973,'IS','Iceland','communications',108,'LAND : GREENLAND
39,750 sq. mi.; arable negligible, 22% meadows and
pastures, forested negligible, 78% other
WATER:
Limits of territorial waters (claimed): 4 n. mi. (fishing,
50 n. mi., effective 1 September 1972)
Coastline: 3,100 mi.
Railroads: none
Highways: 7,400 mi.; 4,760 mi. crushed stone (including lava) and gravel, 2,593
mi. unsurfaced roads and motorable tracks, 47 mi. concrete (some bituminous
stretches)
Ports: 4 major, and about 50 minor
Merchant marine: 25 ships (1,000 GRT or over) totaling 58,200 GRT, 80,600 DWT;
includes 1 passenger, 22 cargo, 1 tanker, 1 specialized carrier
Civil air: 14 major transport aircraft
Airfields: 108 tatal, 93 usable; 4 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.; 5 seaplane stations
Telecommunications: adequate domestic service, wire and radio communication
system; 74,900 telephones; 75,000 radio and 40,000 TV receivers; 15 AM,
12 FM, and 73 TV stations; 2 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 50,000; 43,000 fit for military service (Iceland
has no conscription or compulsory military service)
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 FIA RDP79-01051A000500010001-1
LAND:
1,211,000 sq. mi. (includes Indian part of Jammu-
Kashmir, Sikkim, Goa, Damao and Diu); 50% arable,
5% permanent meadows and pastures, 20% desert,
waste, or urban, 22% forested, 3% inland water
Land boundaries: 7,880 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing,
12 n. mi.; additional 100 mi. is fisheries conservation
zone, December 1968)
Coastline; 4,378 mi.
Railroads: 37,281 mi.; 16,072 mi. meter (3''3 3/8") gage, 18,299 mi. broad gage,
2,781 mi. (2''6" and 2''0") narrow gage government owned; 129 mi. 2''6" and
2''O" gage privately owned; 6,933 mi. double track; 2,303 mi. electrified
Highways: 643,028 mi.; 106,854 mi. paved, 95,054 gravel or crushed stone, 184,631
improved earth, 256,489 mi. unimproved earth
Inland waterways: 8,410 mi.; 1,600 mi. navigable by river steamers
Ports: 7 major 53 minor
Merchant marine: 250 ships (1,000 GRT or over) totaling 2,637,300 GRT,
4,058,700 DWT; includes 3 passenger, 192 cargo, 12 tanker, 34 bulk, and
9 specialized carrier
Airfields: 617 total, 367 usable; 187 with permanent-surface runways; 2 with
runway over 12,000 ft., 49 with runways 8,000-11,999 ft., 132 with runways
4,000-7,999 ft.; 4 seaplane stations
Telecommunications: fair domestic telephone service where available in and
between major cities; facilities and services diminish in quantity and
quality as size of communities decreases and distance between increases;
telephone distribution is less than 2 per 1,000 population; telegraph
facilities widespread; AM broadcast adequate; TV limited to Delhi -- New
Delhi; international telephones and telegraph adequate; 1,245,352 telephones;
11.7 million radio and 24,833 TV sets; AM stations at 70 locations, 7 TV
station; submarine cables extend to Malaysia, Sri Lanka, and Aden
DEFENSE FORCES:
Military manpower: males 15-49, 136,535,000; 77,680,000 fit for military service;
about 6,214,000 reach military age (17) annually
Military budget: for fiscal year ending 3] March 1973, $2.1 billion; 25% of
total budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
LAND:
WATER:','6a042760e32a39ecf827337b717361519c6a6e993a546b8f017238cc797fc2bf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34209bb17ff89c4831f7454673b7093e192f2b9302c5f56876136d6618fdee40',1973,'ID','Indonesia','communications',115,'Railroads: 4,364 mi.; 3,990 mi. 3''6" gage, 317 mi. 2''5 1/2" gage, 57 mi.
1''11 5/8" gage; 132 mi. double track; 74 mi. electrified; government owned
Highways: 57,460 mi.; 12,600 mi. paved, 25,200 mi. gravel or crushed stone,
19,660 mi. improved or unimproved earth
Inland waterways: 14,010 mi.; Sumatra 4,000 mi., Java and Madura 510 mi., Borneo
6,500 mi., Celebes 150 mi., and Irian Barat 2,850 mi.
Ports: 10 major, 63 minor
Merchant marine: 150 ships (1,000 GRT or over) totaling 480,000 GRT, 580,600
DWT; includes 8 passenger, 114 cargo, 14 tanker, 11 bulk, 3 specialized
carrier -- includes ] naval tanker and 5 troop transports sometimes used
commercially; a small proportion of the fleet is in international trade;
in the domestic fleet about one half are commercially inoperable because of
a chronic lack of spare parts and trained personnel
Airfields: 350 total, 236 usable; 33 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 55 with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: extensive police net for interisland service; international
and domestic service is limited; radiobroadcast coverage adequate but TV
available on Java only; 182,319 telephones; 3.2 million radio sets; 90,000
TV sets; AM stations at 53 locations; 1 FM and 5 TV stations; 2 submarine
cables to Singapore
DEFENSE FORCES:
Military manpower: males 15-49, 28,580,000; 16,310,000 fit for military service;
about 1,480,000 reach military age (18) annually
Approved For Release 2064/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : RDP 2 O1es TA0C0S00010001-
LAND:
636,000 sq. mi.; 14% agricultural, 11% forested, 16%
cultivable with ageduece irrigation, 51% desert,
7 waste, or urban, 8% migratory grazing and other
Land boundaries: 3,305 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,580 mi.
se
Railroads: 2,373 mi. 4"8 1/2" gage, 57 mi. 5''6" gage
Highways: 26,535 mi.; 7,084 mi. paved, 12,943 mi. gravel and crushed stone,
6,508 mi. improved earth
Inland waterways: 565 mi., not including Caspian Sea and Shatt al Arab and Lake
Urmia »
Pipelines: crude 011, 1,640 mi.; refined products, 3,235 mi.; natural gas,
1,440 mi.
Ports: 7 major, 6 minor
Merchant marine: 16 ships {1,000 GRT or over) totaling 158,400 GRT, 227,400 DWT;
includes 12 cargo, 4 tanker ¥
Civil air: 18 major transport aircraft
Airfields: 231 total, 145 usable; 50 with permanent-surface runways; 7 with
runways over 12,000 ft., 15 with runways 8,000-11,999 ft., 51 with runways
4,000-7 ,999 ft.
Telecommunications: advanced system of high-capacity radio-relay links, open-wire
lines, cables, and tropospheric links; principal center Teheran, secondary
centers Istahan, Meshed, and Tabriz; 307,500 telephones; 1.8 million radio
and 250,000 TV receivers; 20 AM, 1 FM, and 9 TV stations; satellite earth
station
DEFENSE FORCES:
Military manpower: males 15-49, 7,255,000; 4,290,000 fit for military service;
about 317,000 reach military age (21) annually
Military budget: for fiscal year ending 20 March 1973, $1,323.7 million; about
16.8% of total budget
Approved For Release 2008909/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : ee
LAND:
172,000 sq. mi.; 18% cultivated, 68% desert, waste, or
urban, 10% seasonal and other grazing land, 4% forest
and woodland
Land boundaries: 2,280 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 36 mi.
Railroads: 1,408 mi.; 698 mi. 4''8 1/2" gage, 710 mi. meter (3''3 3/8") gage;
10 mi. meter gage double track
Highways: 12,900 mi.; 4,000 mi. paved; 2,900 mi. crushed stone, gravel, or
improved earth; 6,000 mi. earth and sand tracks
Inland waterways: 635 mi.; Shatt al Arab navigable by maritime traffic for
about 65 mi.; Tigris and Euphrates navigable by shallow-draft steamers
Ports: 3 major
Pipelines: crude oil, 1,660 mi.; 30 mi. refined products; 430 mi. natural gas
Merchant marine: 8 ships (1,000 GRT or over) totaling 89,000 GRT, 132,900
DWT includes 6 cargo, 2 tanker
Civil air: 6 major transport aircraft
Airfields: 168 total, 70 usable; 20 with permanent-surface runways; 40 with
runways 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.
Telecommunications: fair international radiocommunication service; poor
domestic telephone and telegraph service; 120,000 telephones; 1,100,000 radio
receivers; 200,000 TV receivers; 4 TV and 4 AM stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,310,000; 1,250,000 fit for military service;
about 121,000 reach military age (18) annually
Approved For Release 2004/69/15 : CIA-RDP79-01051A000500010001-1
004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2 Teh
LAND:
26,600 sq. mi.; 17% arable, 51% meadows and pastures ,
3% forested, 2% inland water, 27% waste and urban
Land boundaries: 224 mi,
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing,
12 n. mi.)
Coastline: 900 mi.
PEOPLE: ALGERIA
Population: 3,002,000 average annual growth rate 0.6%
(April 66-71)
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Episcopalian, 2% other
Language: English and Gaelic official; English is generally spoken
Literacy: 98%-99%
Labor force: about 1,130,000; 28% agriculture, forestry, fishing; 19% manufac-
turing; 15% commerce; 6% construction; 5% transportation; 4% government;
18% other
Organized labor: 36% of labor force
Railroads: 1,333 mi., 5''3" gage; government-owned
Highways: 53,700 mi.; 46,950 mi. surfaced, 6,750 mi. earth
Inland waterways: approx. 650 mi.
Ports: 6 major, 38 minor
Merchant marine: 16 ships (1,000 GRT or over) totaling 129,200 GRT, 182,600
DWT; includes 2 passenger, 19 cargo, 5 bulk, 1 specialized carrier
Civil air: 27 major transport aircraft, plus 9 withdrawn from service
Airfields: 30 total, 25 usable; 7 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; ] seaplane station
Telecommunications: small, modern system; all cities interconnected for telephone
and telegraph service; 337,000 telephones; 615,000 radiobroadcast receivers;
502,000 TV receivers; 3 AM, 5 FM, and 19 TV stations; 4 coaxial submarine s
cables
DEFENSE FORCES:
Military manpower: males 15-49, 695,000; 545,000 fit for military service;
about 29,000 reach military age (17) annually 7
Supply: formerly from the U.K. primarily, but since 1961 from other European
countries
Military budget: for fiscal year ending 31 March 1973, $68.7 million; about
4.2% of the central government budget
Approved For Release 2004/09745 : CIA-RDP79-01051A000500010001-1
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 Si cia ce ace eae
LAND:
116,300 sq. mi.; 50% cultivated, 17% meadow and pasture, 21%
forest, 2% inland water, 10% waste or urban
Land boundaries: 1,058 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. (fishing,
12 n. mi.)
Coastline: 3,105 mi.
PEOPLE: ALGERIA
Population: 54,250,000, average annual growth rate 0.7%
(October 61-71)
Ethnic divisions: primarily Italian but population includes small clusters of
German-, French-, and Slovene-Italians in the north and of Albanian-Italians
in the south
Religion: almost 100% nominally Roman Catholic (de facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region (e.g., Bolzano) are
predominantly German speaking; significant French-speaking minority in Valle
d''Aosta Region; Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5-7% of population illiterate (1967); illiteracy varies widely by region
Labor force: 19,019,000 (April 1972); 17.7% agriculture, 42.5% industry,
36.5% other, 3.3% unemployed; underemployment, particularly in southern
Italy, remains widespread; 1.5 million Italians employed in other Western
European countries
Organized labor: 20% (est.) of labor force
Railroads: 12,857 mi.; 9,907 mi. government owned; 9,805 mi. standard gage; 4,906
mi. electrified; 102 mi. narrow gage (3'' 1 1/8"); 2,950 mi. non-government
owned; 1,567 mi. standard gage; 794 mi. electrified; 1,383 mi. narrow gage;
323 electrified
Highways: 126,500 mi.; state highways 25,985 mi., provincial highways 45,850 mi.,
communal highways 54,665 mi.; 60,200 mi. concrete, bituminous, or stone block,
66,300 mi. gravel and crushed stone
Inland waterways: 2,547 mi. navigable routes; 1,180 mi. are rivers and
canals, 1,367 mi. are lake routes
Pipelines: crude oj]. 1,300 mi.; refined products, 980 mi.; natural gas, 5,500
mi.
Ports: 16 major, 148 minor
Civil air: 130 major transport aircraft
Airfields: 228 total, 151 usable; 79 with permanent-surface runways; 2 with
runways over 12,000 ft., 25 with runways 8,000-11,999 ft., 47 with runways
4,000-7 ,999 ft.; 11 seaplane stations
Approved For Release 2064/09/15 : CIA-RDP79-01051A000500010001-1
roved For Release 2004/09/15 : CIA-RDP79-0
cOMMUNEER RTOS once. | D 1051A000500010001-1
Telecommunications: well engineered, well constructed, and efficiently operated;
10.8 million telephones; 12.6 million radio and 10.85 million TV
receivers; 86 AM, 550 FM, and 855 TV stations, each with numerous repeater
stations; 9 coaxial submarine cables; communication satellite ground stations
DEFENSE FORCES:
Military manpower: males 15-49, 13,540,000; 11,360,000 fit for military service;
413,000 reach military age (18) annual ly
Military budget: proposed for fiscal year ending 31 December 1972, $3.2 billion;
about 12% of central government budget
Approved For Release 2004/09/15 : ClA#RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
IVORY COAST
LAND:
125,000 sq. mi.; 40% forest and woodland, 8% cultivated, Oe
52% grazing, fallow, and waste, 200 mi. of lagoons Aseria} weve EGYAT Sr
and connecting canals along eastern coast
Land boundaries: 2,005 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 320 mi.
Railroads: 408 mi. of the 728 mi. Abidjan to Ouagadougou, Upper Volta line, all
single track meter gage; only diesel locomotives in use
Highways: 24,600 mi.; 800 mi. bituminous and bituminous-surface treatment;
11,200 mi. gravel, crushed stone, laterite, and improved earth; 12,600
mi. unimproved earth roads
Inland waterways: 460 mi. navigable rivers and numerous coastal lagoons
Ports: 2 major, 3 minor
Civil air: 15 major transport aircraft
Airfields: 50 total, 44 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: system only slightly above African average; consists of
microwave relays, open-wire lines and radio relay links, which provide
incomplete coverage of country; Abidjan is only center; 24,800 telephones;
80,000 radio and 70,000 TV receivers; 3 AM, 2 FM, and 4 TV stations; 2
submarine cables; satellite earth station under construction
DEFENSE FORCES:
Military manpower: males 15-49, 1,095,000; 525,000 fit for military service
Supply: principally dependent on France; has purchased transport aircraft from','bfad198114c11c3e5c3fa317cfa5390b52ab3301f3869da87e7657ff7bc0534f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbd69d6fb50001976e3fbdabaf1ffab97aadb98880fc3ca8f20a02620006c934',1973,'NL','Netherlands','communications',116,'Military budget: for fiscal year ending 31 December 1972, $21,431,400; about
8.0% of total budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','36a3d833109bad147551bebcef268586f81c4eae42531b126954175e6fb8af6d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5471ad6dca52867152d366c9bfbb0ce1835f4792d4e4d24a19aecfa992bd2f02',1973,'JM','Jamaica','communications',117,'LAND:
4,410 sq. mi.; 21% arable, 23% meadows and pastures, 19%
forested, 37% waste, urban, or other
WATER: ;
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 635 mi.
‘VENEZUELA
Railroads: 204 mi. government-owned, 43 mi. privately owned, all standard gage,
single track
Highways: 7,100 mi.; 1,200 mi. paved, 4,400 mi. gravel, 1,500 mi. unimproved
earth surfaces
Pipelines: refined products, 6 mi.
Ports: | major, 11 minor
Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 11,900 GRT, 10,500
DWT
Civil air: 3 major transport aircraft
Airfields: 48 total, 38 usable; 12 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 2 with runway 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fully automatic domestic telephone network with 77,800
telephones; satellite ground station; 500,000 radio and 73,000 TV receivers;
8 AM, 5 FM, and 8 TV stations; 5 submarine cables, including 2 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 410,000; 275,000 fit for military service; no
conscription; average number currently reaching minimum volunteer age (18)
22 ,000
Supply: dependent on U.K. and U.S.
Military budget: for fiscal year ending 31 March 1973, $8.2 million; about 2.0%
of central government budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Ie,
ian
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 ‘ fo)aROP79-01051A000500010001-1
NOTE:
LAND:
WATER:
The war between Israel and the Arab states in June 1967
ended with Israel in control of West Jordan. Although
approx. 930,000 persons resided in this area prior to the
start of the war. fewer than 750,000 of them remain there
under the Israeli occupation, the remainder having fled
to East Jordan. Over 14,000 of those who fled were
repatriated in August 1967, but their return has been
more than offset by other Arabs who have crossed and are
continuing to cross from West to East Jordan. These and
certain other effects of the Arab-Israeli war are not
included in the data below.
ARABIA','71e2b360716244a388e21ba7acdce6b5d819e9eb7feeded0b307eaca7da76557','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e061e54f8ab10b334141522a6500157b512878f1a6b9915f18f2426e9eb6d64a',1973,'ET','Ethiopia','communications',121,'37,100 sq. mi. (including about 2,100 sq. mi. occupied by Israel); 11%
agricultural, 88% desert, waste, or urban, 1% forested
Land boundaries: 1,141 mi. (1967, 1,037 mi. excluding occupied areas )
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 16 mi.
Railroads: 227 mi. 3''5 3/8" gage, single track
Highways: 4,400 mi.; 3,486 mi. bituminous, 249 mi. improved, 665 unimproved earth
(these mileages include approximately 670 mi. -- mostly bituminous -- of
Jordanian territory held by Israel)
Pipelines: crude oi], 130 mi.
Ports: 1 major
Civil air: 5 major transport aircraft
Airfields: 53 total, 18 usable; 10 with permanent-surface runways; 2 with
runways over 12,000 ft., 9 with runways 8,000-11,999 ft. » 4 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate telecommunication system for the needs of the
country; 31,100 telephones; 300,000 radio and 132,000 TV receivers; 1 AM
and 1 TV stations; 1 earth satellite station
DEFENSE FORCES:
Military manpower: males 15-49, 542,000; 410,000 fit for military service;
average number currently reaching military age (18) annually 29,000
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 ete
LAND:
225,000 sq. mi.; about 21% forest and woodland, 13%
suitable for agriculture, 66% mainly grassland
adequate for grazing
Land boundaries: 2,093 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 333 mi.
Railroads: 2,818 route mi. operating in 1968; 2,137 mi. standard gage, 681 mi.
2''6" narrow gage; 99 mi. double tracked; about 588 mi. electrified; government
owned
Highways: about 12,600 mi., 95% gravel or earth surface
Inland waterways: 1,400 mi.; mostly navigable by small craft only
Freight carried (1969): rail -- 13 billion metric ton/km., 62 million metric
tons; highway -- 765 million metric ton/km. , 116 million metric tons;
waterway -- 540 million metric ton/km., 7.7 million metric tons; coastal --
170 million metric ton/km., 0.4 million metric tons
Ports: 6 major, 26 minor
DEFENSE FORCES:
Military manpower: males 15-49, 3,378,000; 2,005,000 fit for military service;
174,000 reach military age (18) annually
Approved For Release 2004/68/15 : CIA-RDP79-01051A000500010001-1
: - - 1A000500010001-1
For Release 2004/09/15 : CIA-RDP79-0105
sd KOREA, SOUTH
PEOPLE''S REP.
OF CHINA
LAND:
38,000 sq. mi.; 23% arable (22% cultivated), 10% urban
and other, 67% forested
Land boundaries: 150 mi.
WATER:
Limits of territorial waters (claimed): 20-200 n. mi.
Coastline: 4,550 mi.
Railroads: 1,964 mi.; 1,887 mi. standard gage, 77 mi. (2''6") narrow gage; 280
mi. double track; government owned
Highways: 25,500 mi.; 1,845 mi. paved, 18,500 m. gravel, 3,200 mi. improved
earth, 1,955 mi. unimproved earth
Inland waterways: 1,000 mi.; use restricted to small native craft
Freight carried: rail (1968) 4.5 billion short ton/mi., 30.4 million short
tons; highway 24 million short tons; air (1959) 796,260 Ibs. carried
Pipelines: 255 mi., refined products, under construction
Ports: 10 major, 10 minor
Merchant marine: 127 ships (1,000 GRT or over) totaling 936,800 GRT, 1,546,400
DWT; includes 83 cargo, 24 tanker, 13 bulk, 7 specialized carriers
Airfields: 262 total, 126 usable; 47 with permanent-surface runways; 11 with
runways 8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 2 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,159,000; 5,165,000 fit for military service;
average number reaching military age (18) annually 345,000
Military budget: for fiscal year ending 31 December 1972, $458.7 million; about
26.4% of total budget
Approved For Release 2004/99/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15; GIA-RDP79-01051A000500010001-1
LAND:
6,200 sq. mi. (excluding neutral zone but including islands);
insignificant amount forested; nearly all desert,
waste, or urban
Land boundaries: 285 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 310 mi.
Railroads: none
Highways: 1,550 mi.; 465 mi. bituminous; 1,085 mi. earth, sand, light gravel
Pipelines: crude oil, 255 mi.; refined products, 25 mi.; natural gas, 75 mi.
Ports: 2 major, 1 minor
Merchant marine: 26 ships (1,000 GRT or over), totaling 647,200 GRT, 1,090,000
DWT; includes 23 cargo, 6 tankers, 3 specialized carrier
Civil air: 5 major transport aircraft
Airfields: 13 total, 5 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.
Telecommunications: excellent international radiocommunications; adequate
domestic telecommunication facilities; 66,600 telephones; 110,000 radio
and 120,000 TV sets; 3 AM and 3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 322,000; about 175,000 fit for military
service
Supply: dependent on U.K.
Military budget: for fiscal year ending 31 March 1973, $98,900,000; about 10.6%
of total recurrent budget
Approved For Release 2004969/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : Ve ee
LAND:
91,430 sq. mi.; 7% agricultural, 60% forests, 33% urban,
waste, and other; except in very limited areas, soil
is very poor; most of forested area is not exploitable
Land boundaries: 2,700 mi.
Highways: about 9,200 mi. (including Communist-held areas); 500 mi. bituminous
or bituminous treated, 1,900 mi. gravel, crushed stone, or improved earth;
6,800 mi. unimproved earth and often impassable during rainy season
mid-May to mid-September
Inland waterways: about 2,850 mi., primarily Mekong and tributaries; 1,800
additional miles are sectionally navigable by craft drawing less than 1.5 ft.
Ports (river): 5 major, 4 minor
Airfields: 279 total, 212 usable; 5 with permanent-surface runways; 18 with
runways 4,000-7,999 ft., I with runway 8,000-11,999 ft.
Telecommunications: service to general public considered poor; radio network
provides generally erratic service to government users; poor international
service recently improved by radio relay link to Thailand; radiobroadcast
transmitters operate in a few towns; 1,148 telephones; 70,000 (est.) radio
receivers
DEFENSE FORCES:
Military manpower: males 15-49, 750,000; 400,000 fit for military service;
average number currently reaching usual military age (18) annually, 33,000;
no conscription age specified
Military budget: for fiscal year ending 30 June 1973, $6 million; about 45%
of proposed central government budget
Approved For Release 2004409/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','896c78d5ae4429841a1878ec0bdd6c9273082bd4d49d4ee5bd2a4f1affde92cc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0006e8e93c8cf72296f379a0b7f412d8e87cf28d442159f306306698f3b8eca',1973,'LB','Lebanon','communications',125,'LAND:
4,000 sq. mi.; 27% agricultural land, 64% desert, waste,
or urban, 9% forested f
Land boundaries: 285 mi. ‘ TURKEY
WATER: :
Limits of territorial waters (claimed): no specific claims
(fishing, 6 n. mi.
Coastline: 140 mi. ea
PEOPLE: oka
Population: 3,009,000 (including Lebanese Nationals living
outside the country who are on the population register,
but excluding registered Palestinian refugees numbering
176,000 on 30 June 1970), average annual growth rate 3.1% (current)
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1% other (official estimates);
Muslims believed to constitute slight majority
Language: Arabic (official); French is widely spcken
Literacy: 86%
Labor force: about 1 million economically active; 49% agriculture, 11% industry,
14% commerce, 26% other; moderate unemployment
Organized labor: about 55,000
Highways: 5,133 mi.; 3,821 mi. paved, 342 mi. gravel and crushed stone, 373 mi.
improved earth, 597 mi. unimproved earth
Pipelines: crude ofl, 45 mi.
Ports: 3 major, 5 minor
Merchant marine: 36 ships (1,000 GRT or over) totaling 85,700 GRT, 127,400 DUT;
includes 41 cargo, 2 bulk; 10 ships are foreign owned and operated
Civil air: 25 major transport aircraft
Airfields: 11 total, 3 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft.; 1 seaplane station
Telecomnunications: excellent international teleconmunication facilities include
satellite ground station; good domestic telephone and telegraph service;
192,000 telephones; 605,900 radio and 300,000 TV receivers; 7 TV, 2 FM, and
1 AM radiobroadcast stations; 1 submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 751,000; 445,000 fit for military service;
average of about 30,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1972, $69.1 million; about
22.0% of proposed total budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
A dF : - = 3
pproved For Release 2004/09/15 :-ClA-RDP79 01051A000500010001-1
LAND:
11,700 sq. mi.; 15% cultivable; largely mountainous
Land boundaries: 500 mi.
Railroads: 1 mi.; owned, operated, and included in the statistics of the Republic
of South Africa
Highways: approx. 1,346 mi.; 107 mi. paved; 463 mi. crushed stone, gravel, or
stablized soil; 770 mi. improved or unimproved earth
Civil air: no major transport aircraft
Airfields: 37 total, 22 usable; 3 with runways 4,000-7,000 ft.
Telecommunications: system a modest one consisting of a few landlines, a small
radio-relay system, and minor radioconmunication stations; Maseru is the
center; 2,400 telephones; 10,100 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 198,000; fit for military service 100,000
None, police only
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 GLA TROP 79-01 051A000500010001-1
LAND:
43,000 sq. mi.; 20% agricultural, 30% jungle and swamps,
40% forested, 10% unclassified
Land boundaries: 830 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 360 mi.
Railroads: 310 mi.; 220 mi. standard gage, 90 mi. narrow gage (3''6"); all lines
single track; rail systems owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
Highways: 4,150 mi.; 325 mi. bituminous treated, 875 mi. laterite, 2,950 mi.
unimproved
Inland waterways: 230 mi. navigable
Ports: 3 major, 4 minor
Civil air: 2 major transport aircraft
Airfields: 65 total, 55 usable; 3 with permanent-surface runways; | with runway
8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone and telegraph limited; main center is Monrovia;
6,000 telephones; 155,000 radio and 7,000 TV receivers; 3 AM, no FM,
2 TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 389,000; 205,000 fit for military service;
no conscription
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
iy
Approved For Release 2004/09/15 : ca
LIBY.
LAND:
679,000 sq. mi.; 6% agricultural, 1% forested, 93%
desert, waste, or urban
Land boundaries: 2,700 mi.
WATER:
Limits of territorial waters (claimed): 12 nh. mi.
Coastline: 1,100 mi.
Railroads: none
Highways: 8,915 mi.; 3,772 mi. bituminous or bituminous treated, 5,143
mi. improved and unimproved earth and gravel
Pipelines: crude oi] 1,520 mi.; natural gas 175 mi.; refined products 135 mi.
Ports: 3 major, 6 minor
Merchant marine: 1 cargo ship (1000 GRT-or over) totaling 1,200 GRT, 2,200 DUT
Civil air: 8 major transport aircraft; an additional 27 major transports are
operated by external carriers engaged in charter work for several oi] companies
Airfields: 103 total, 77 usable; 14 with permanent-surface runways; 6 with runways
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: system is just within top one-third of African systems; con-
sists of radio-relay and tropospheric-scatter links, open-wire lines, and
radiocommunication stations; principal centers are Tripoli and Benghazi;
41,500 telephones; 225,000 radio and 72,500 TV receivers; 7 AM, 1 FM, and
2 TV stations; 3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 479,000; 280,000 fit for military service;
about 20,000 reach military age (17) annually; conscription now being
implemented
Military budget: for fiscal year ending 31 March 1973, $121,580,000; 17.3% of
operating budget
Approved For Release 2004/0915 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/18 GlA-RDPP79-01051A000500010001-1
: NORWAY.
LAND:
65 sq. mi.
Land boundaries: 47 mi. an
GED: C East POLAND
ETH. J oe \\
PEOPLE: ; aoe aoe
Population: 22,000, average annual growth rate 2.5% : 7
(December 60-70) 4
Ethnic divisions: 95% Germanic, 5% Italian and other barat
Religion: 92% Roman Catholic :
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly from
Austria and Italy); 59% industry, 20% trade and
commerce, 13% professional and other, 8% agricul ture
Railroads: 9.94 mi. 4''8 1/2" gage, electrified; owned, operated, and included in
statistics of Austrian Federal Railways
Highways: no information on total mileage
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system serving about 11,600 telephones;
no broadcast facilities; 4,000 radio and 3,500 TV receivers (programed from
Switzerland)
Approved For Release 2004/09/15 : |@7A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
DEFENSE FORCES:
Defense is responsibility of Switzerland
Approved For Release 200409/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 + GlAsiHee 79-0105 1A000500010001-1
LAND:
1,000 sq. mi.; 26% arable, 26% meadows and pasture, 16%
waste or urban, 32% forested, negligible amount of
inland water
Land boundaries: 221 mi.
ae
LUXE
Railroads: 203 mi. standard gage; 100 mi. double track; 85 mi. electrified
Highways: 3,070 mi.; all paved
Pipelines: refined products, 30 mi.
Inland waterways: 23 mi.; Moselle River
Port: Mertert
Civil air: 7 major transport aircraft
Airfields: 2 total, 1 usable with permanent-surface runway 8,000-11,999 ft.
Telecommunications: adequate and efficient system; 124,600 telephones; 171,200
radiobroadcast receivers; 85,000 TV receivers; AM megawatt service of Radio
Luxembourg reaches most of Europe; 3 FM stations; 1 TV station with 6 relays
DEFENSE FORCES:
Military manpower: males 15-49, 79,000; 63,000 fit for military service; about
2,500 reach military age (19) annually
Military budget: for fiscal year ending 31 December 1972, $10.1 million; 3.0% of
central government budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 ag ne
MAC
LAND:
6 sq. mi.; 10% agricultural, 90% urban
Land boundaries: 220 yds.
WATER:
Limits of territorial waters (claimed): 6 n. mi;
fishing, 12 n. mi.
Coastline: 25 mi.
Railroads: 549 mi. of meter gage
Highways: 5,300 mi.; 1,875 mi. paved, 2,225 mi. crushed stone, gravel, or stabi-
lized soil; 1,200 mi. improved and unimproved earth; remainder are tracks
Inland waterways: 1,200 mi. navigable; Lac Alaotra (200 sq. mi.)
Ports: 4 major, 13 minor
Civil air: 9 major transport aircraft
Airfields: 365 total, 166 usable; 24 with permanent-surface runways; 3 with run-
ways 8,000-11,999 ft., 49 with runways 4,000-7,999 ft.; 6 seaplane stations
Telecommunications: telephone and telegraph generally adequate in urban ‘areas;
27,000 telephones; 500,000 radio and 300 TV receivers; 4 AM, no FM, and
1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,614,000; 950,000 fit for military service;
average number reaching military age (20) annually about 75,000
Supply: largely dependent on France; has received some ground force materiel
from Israel and West Germany
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','3a49d6e7f4bd8fa95f512cb259cc362bd4020842b262d7992f79e2cf4fa540c0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23b44d7eca7f3d93cfb957cbd71198095f6126dd0745bd5c1d5a4206ef913da6',1973,'MW','Malawi','communications',129,'LAND:
36,700 sq. mi.; about 31% of land area arable (of which
less than half is cultivated), nearly 25% forested,
6% meadow and pasture, 38% other
Land boundaries: 1,790 mi.
Railroads:
West Malaysia: 1,014 mi. 3''3 3/8" gage; 8 mi. double track; government-owned
East Malaysia: 96 mi. meter gage in Sabah
Highways:
West Malaysia: 10,500 mi.; 8,925 mi. hard surfaced (mostly bituminous surface
treatment), 1,150 mi. crushed stone/gravel, 425 mi. improved or unimproved
earth
East Malaysia: about 3,140 mi. (1,608 in Sarawak, 1,532 in Sabah); 520 mi.
hard surfaced (mostly bituminous surface treatment), 1,853 mi. gravel or
crushed stone, 767 mi. earth
Inland waterways:
West Malaysia: 1,985 mi.
East Malaysia: 2,540 mi. (975 mi. in Sabah, 1,565 mi. in Sarawak)
Ports:
West Malaysia: 3 major, 10 minor
East Malaysia: 4 major, 7 minor (3 major, 3 minor in Sabah; 1 major, 4 minor
in Sarawak)
Merchant marine: 18 ships (1,000 GRT or over) totaling 130,200 GRT, 167,500 DWT;
includes 13 cargo, 3 tanker, 2 bulk
Civil air: 13 major transport aircraft
Pipelines: crude oj], 90 mi.; refined products, 35 mi.
Airfields:
West Malaysia: 105 total, 70 usable; 15 with permanent-surface runways;
2 with runways 8,000-11,999 ft., 11 with runways 4,000-7,999 ft.; 3
seaplane stations
Sabah: 37 total, 33 usable; 5 with permanent-surface runways; 5 with runways
4,000-7,999 ft.; 3 seaplane stations
Sarawak: 50 total, 45 usable; 5 with permanent-surface runways; 4 with
runways 4,000-7,999 ft.
Telecommunications:
West Malaysia: good intercity service provided mainly by microwave relay;
international service good; good coverage by radio and television broad-
casts; 153,395 telephones; 430,000 radio and 150,000 TV receivers; 9 towns
have AM stations; no FM, 8 TY stations; submarine cables extend to India,
Ceylon, and Singapore; connected to SEACOM submarine cable terminal at
Singapore by microwave relay
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
2004/09/15 : CIA-RDP79-01051A000500010004-1
COMMUNTERRSBNE 4 For Release
Telecommunications (cont''d):
Sabah: adequate intercity radio-relay network extends to Sarawak via Brunei;
10,246 telephones; 55,064 radio receivers; 3 AM, 1 FM, no TV stations;
SEACOM submarine cable links to Hong Kong and Singapore
Sarawak: adequate intercity radio-relay network extends to Sabah via Brunei;
w 13,365 telephones; 50,000 radio and no TV receivers; 2 AM, no FM, no TV
stations
DEFENSE FORCES:
Military manpower: West Malaysia: males 15-49, 2,186,000; 1,385,000 fit for
military service; Sabah: males 15-49, 167,000; 100,000 fit for military
- service; Sarawak: males 15-49, 244,000; 145,000 fit for military service;
conscription age for Malaysia is 21 -- an age reached by about 1,121,000
annually
External defense dependent on loose Five Power Defense Agreement (FPDA) which
replaced Anglo-Malayan Defense Agreement of 1957 as amended in 1963; FPDA,
effective as of 1 November 1971, also provides for small ANZUK Joint Force
composed of Australia, New Zealand, and U.K. ground, naval, and air elements,
headquarters in Singapore
Military budget: for fiscal year ending 31 December 1972, $209.2 million; 14.5%
of central government budget
Approved For Release 2004/09/15 2 GIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 weilbTRRP 79-01051A000500010001-1
LAND:
115 sq. mi.; 2,000 islands grouped into 12 atolls, about
220 islands inhabited
WATER:
Limits of territorial waters (claimed): the land and
sea between latitudes 7°9''N. and 0°45''S. and between
longitudes 72°30''E. and 73°48''E; these coordinates
form a rectangle of approximately 37,000 sq. n. mi.
Coastline: 400 mi. (approx.)
Railroads: none
Highways: none
Ports: 2 minor ports (Male and Gan)
Civil air: no major transport aircraft
Airfields: 3 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Approved For Release 2004/09/15 : &l&-RDP79-010514000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d): ‘ ;
Telecommunications: minimal domestic and international teleconmmunication
facilities; 300 telephones; 1,750 radio sets; 1 AM station
Approved For Release 2004409/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : Gif RDP79-01051A000500010001-1
LAND:
465,000 sq. mi.; only about a fourth of area arable,
forests negligible, rest sparse pasture or desert
Land boundaries: 4,635 mi.','ddfaf6d6427d769fc87fa7f9ff683de85cdfa66860c5ab840a7882a224960f64','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('600dd242506f358452f4f35d15bbca439d047fcd0ff669037bd0f5a6092bf2d2',1973,'CN','China','communications',134,'Railroads: 400 mi. meter gage
Highways: approximately 7,500 mi.; 870 mi. bituminous, 3,215 mi. gravel, 580 mi.
improved earth, 2,835 mi. unimproved earth
Inland waterways: 1,141 mi. navigable
Civil air: 7 major transport aircraft
Airfields: 55 total, 38 usable; 6 with permanent-surface runways; 2 with runway
8,000-11,999 ft., 11 with runways 4,000-7,999 ft.
Telecommunications: system poor and provides only minimum service to government,
business, and public; open-wire and radiocommunication used for long distance
telecommunications; radio sometimes only link to outlying points; 6,670
telephones; 60,000 radio receivers; 2 AM, no FM, and no TY stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,257,000; 705,000 fit for military service;
no conscription
Military budget: for fiscal year ending 31 December 1972, $8,369,000; about 16.6%
of total budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','4dbc3296814dbaa38512a1059e2eefc24439613676a72ca50bc0b915fa67759e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acbab5288fafc7923261c900ca2b3b646df7b0774a430a0a436215635affc02d',1973,'MT','Malta','communications',135,'LAND: i] i GOSLAVIA
121 sq. mi.; 50% arable, negligible amount forested,
remainder urban, waste, or other (1965)
WATER:
Limits of territorial waters (claimed): 6 n. mi.
Coastline: 87 mi.
Highways: 760 mi., 650 mi. paved (asphalt), 80 mi. crushed stone, 30 mi. improved
and unimproved earth
Ports: 2 minor
Merchant marine: 2 ships (1,000 GRT or over) totaling 3,600 GRT, 4,200 DWT;
Civil air: no major transport aircraft, 2 on lease from U.K.
Airfields: 4 total, all usable; 4 with permanent-surface runways; 3 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: modern automatic telephone system centered in Valletta;
45,000 telephones; 80,000 radio receivers (including 60,000 wired sets);
65,000 television receivers; 5 AM, 2 FM, and 1 TY stations; 8 submarine cables,
1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 87,000; 65,000 fit for military service
Military budget: for fiscal year ending 31 March 1971, $739,200; about 1.6% of
central government budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','b0e60c3126f3f34f08caee09b3ae2f4ad04a7de8087d6db354c5d1696987dc17','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69f04da2b8f1859298af74eefa328a48a6761fb065dd416adcc789dac141778f',1973,'MQ','Martinique','communications',139,'LAND:
425 sq. mi.; 31% cropland, 16% pasture, 29% forest, 24%
wasteland, built on
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 180 mi.
Railroads: none
Highways: 1,100 mi.; 600 mi. paved, 500 mi. gravel and earth
Ports: 1 major (Fort-de-France), 5 minor
Civil air: no major transport
Airfields: 2 usable; 1 with permanent-surface runway; 1 with runway 4,000-7,999
ft; 1 seaplane station
Telecommunications: domestic facilities inadequate; 19,500 telephones, inter-island
VHF radio links; satellite earth station February 1972; 1 AM radio station
and 5 TV stations; about 33,000 radio and 10,200 TV receivers
DEFENSE FORCES:
Military manpower: males 15-49, included in France
Defense is responsibility of France; data are for French military forces
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','dceb387955a854816d0a81677029dc2f631dbb337c95060bf0e375150305c146','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffd8031562d7d88701d2e3dd79c769da8040ad7e4207929fd3527270c53db37f',1973,'MR','Mauritania','communications',143,'LAND:
419,000 sq. mi.; less than 1% suitable for crops, 10%
pasture, 90% desert
Land boundaries: 3,180 mi.
WATER:
Limits of territorial waters (claimed): 30 n. mi.
(fishing, 6 n. mi. exclusive rights, 6 n. mi.
contiguous zone)
Coastline: 490 mi.
Railroads: 400 mi. standard gage, single track, privately owned
Highways: 3,785 mi.; 280 mi. paved; 440 mi. gravel, crushed stone, or otherwise
improved; 3,065 mi. unimproved
Inland waterways: 500 mi.
Ports: 3 major
Civil air: 5 major transport aircraft
Airfields: 40 total, 29 usable; 9 with permanent-surface runways; 16 with run-
ways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone poor, telegraph fair; 1,200 telephones; 75,000
radio receivers; 7 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,292,000; 145,000 fit for military service;
conscription law not implemented
Supply: primarily dependent on France
Military budget: for fiscal year ending 31 December 1972, $6,117,600; 15.4%
of total budget
Approved For Release 200409/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','c682c80379f34a6dd2ae505e641f1def9f2a5d3443298086e2dadc67aa5b0ea2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89c3ff58612c16f4e27ecdec6b4b9435378cc39dbc86ac156487b46aaa1d8f28',1973,'MU','Mauritius','communications',147,'pene \\ AR
LAND: ata er tora
720 sq. mi. (excluding dependencies); 50% agricultural, in- [7% sg,
tensely cultivated; 39% forests, woodlands, mountains, iss +a sa
river, and natural reserves; 3% built-up areas; 5%
water bodies, 2% roads and tracks, 1% permanent
wastelands
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 110 mi.
Highways: 1,100 mi.; 990 mi. paved, 110 mi. earth
Civil air: no major transport aircraft
Ports: 1 major, 2 minor
Airfields: 7 total, 6 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft.
Telecommunications: 18,100 telephones; radio telegraph service with Reunion,
Malagasy Republic, Seychelles, Zanzibar, and other places in Africa; 1 AM,
no FM, and 4 TY stations; 160,000 radio and 19,600 TV sets; submarine cables
extend to Republic of South Africa and Seychelles Islands ''
DEFENSE FORCES:
Military manpower: males 15-49, 203,000; 100,000 fit for military service
Military budget: for fiscal year 1972-73, $3,999,400 (combined military and internal
security); 6.6% of total budget .
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','3f26a57b0a026b77689980c872ce7588460e4442ec36d7bd9856faa422054a16','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d78cb11c6bfa69d99b89949f8f8e8a006a5db2d2c297833e0239c73eef13891f',1973,'MC','Monaco','communications',150,'LAND:
0.6 sq. mi.
Land boundaries: 2.3 mi. ae
o ; Ae es ick yore
WATER: gga RECS oe CT
Limits of territorial waters (claimed): 3 n. mi. (fishing ;
12 n. mi.)
Coastline: 2.6 mi.
Railroads: 1 mi. (see France)
Highways: none; city streets
Ports: 1 minor
Merchant marine: 4 ships (1,000 GRT or over) totaling 31,400 GRT, 45,300 DWT;
includes 2 cargo, 2 tankers
Civil air: no major aircraft
Airfields: none
Approved For Release 2004/09/1522¢IA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d): ; . :
Telecommunications: served by the French wire communications system; automatic
telephone system with about 16,500 telephones; international AM broadcast;
FM and TV facilities; 10,500 radio and 15,000 TV receivers
DEFENSE FORCES:
France responsible for defense
Approved For Release 2004/0945 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','b449abd2dc7bbb728113def3a060dc8cdbfb4ecd047ba1752055f2bbc3e0ca38','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2fddac8de154741393fa4614aff1f5b61c04fa22071c8b4bbc44b3c3cfca176',1973,'MN','Mongolia','communications',154,'LAND:
604,100 sq. mi.; almost 90% of land area is pasture or
desert wasteland, varying in usefulness, less than
1% arable, 10% forested
Land boundaries: 4,975 mi.
Railroads: 1,130 route mi.; 800 mi. broad gage (5''0"), 330 mi. meter gage
(3''3 3/8") (1971)
Highways: 52,000 mi.; 200 mi. paved, 5,200 mi. improved natural surface and
gravel, 46,600 mi. unimproved earth (1972)
Approved For Release 2004/09/15 : CPAORDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d):
Inland waterways: 585 mi. navigable; used primarily for local transport (1972)
Freight carried: rail -- unknown; highway -- about 10 million short tons (1966);
291 million short ton/mi. (1966); waterway -- 2.5 million short ton/mi.
(1970)
Airfields: 42 total; 5 with permanent-surface runways; 25 with runways 8,000-
11,999 ft., 11 with runways 4,000-7,999 ft., 6 additional airfields under
4,000 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 294,000; 190,000 fit for military service;
average number reaching military age (18) annually, about 15,000
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 31 December 1969, 141.7 million tugriks,
7% of total budget; value in dollars $33 million (est.)
Approved For Release 20094409/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15y;,G4AcRRDP79-01051A000500010001-1
158,100 sq. mi.; about 32% arable and grazing land,
17% forest and esparto, 51% desert, waste, and urban
Land boundaries: 1,240 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,140 mi.
Railroads: 1,700 mi. standard gage, 93 mi. double track; 493 mi. electrified
Pipelines: crude of], 85 mi.; refined products, 305 mi.; natural gas, 70 mi.
Ports: 8 major (including Spanish-controlled Ceuta and Mellila), 1] minor
Merchant marine: 15 ships (1,000 GRT or over) totaling 40,500 GRT, 54,300 OWT;
includes 13 cargo, 2 specialized carrier
Civil air: 10 major transport aircraft
Airfields: 143 total, 87 usable; 23 with permanent-surface runways; 2 with
runways over 12,000 ft., 9 with runways 8,000-11,999 ft., 40 with runways
4,000-7,999 ft.; 4 seaplane stations
Telecommunications: superior system by African standards composed of open-wire
lines, coaxial, multiconductor and submarine cables and radio-relay links;
principal centers Casablanca and Rabat, secondary centers Fes, Marrakech,
Oujda, Sebaa Aioun, Tangier and Tetouan; 170,000 telephones; 1,000,000 radio
and 220,000 TV receivers; 24 Moroccan AM, 1 Voice of America AM, 3 FM, 17 TV
stations; 11 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,897,000; 2,600,000 fit for military service;
about 180,000 reach military age (18) annually; limited conscription
Military budget: for fiscal year ending 3] December 1971, $143.9 million; 16.5%
of total budget
Approved For Release 44/09/15 : CIA-RDP79-01051A000500010001-1
D:
303,769 sq. mi.; 30% arable, of which 1% cultivated, 56%
woodland and forest, 14% wasteland and inland water
Land boundaries: 2,691 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,535 mi.
Railroads: 2,021 mi.; 1,933 mi. 3''6" gage (6 mi. double track), 88 mi. 2''5 1/2"
gage
Highways: 20,000 mi.; 1,740 mi. paved; 18,260 other (mostly earth)
Inland waterways: approx. 2,330 mi. of navigable routes
Pipelines: crude oil, 190 mi.
Ports: 3 major, 13 minor
Civil air: 17 major transport aircraft
Airfields: 344 total, 303 usable; 18 with permanent-surface runways; 5 with run-
ways 8,000-11,999 ft., 29 with runways 4,000-7,999 ft.; 5 seaplane stations
Telecommunications: system ranks at the bottom of top two-fifths of African
systems and employs a basic low-capacity open-wire network supplemented
by numerous small radiocommunication stations and a single tropospheric
scatter system; important centers are Lourenco Marques, Beira, Nampula,
and Tete; 28,000 telephones; 110,000 radio receivers; 9 AM, 1 FM, and no
TV stations
DEFENSE FORCES: ;
Military manpower: males 15-49, 2,094,000; 1,010,000 fit for military service
Defense is responsibility of Portugal
Military budget: for fiscal year ending 31 December 1972, $39.4 million; about
12.5% of national budget
234
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
LAND:
WATER:
Railroads: none
Highways: about 17 mi.; 13 mi. paved, 4 mi. improved earth
Inland waterways: none
Ports: 1 minor
Civil air: 3 major transport aircraft (includes 2 leased)
Airfields: 1, coral-surfaced, 5,270 ft.
Telecommunications: adequate interisland and international radiocommunications
provided via Australian facilities; 525 telephones; 1 AM, but no TV or FM
radiobroadcasting facilities; number of radios unknown
235
Approved For Release 2004/09/15 : cf&-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
DEFENSE FORCES:
Military manpower: males 15-49, about 1,800; fit for military service, about
950; average number reaching military age (18) annually, 1971-75, less
than 100
No formal defense structure and no regular armed forces
Approved For Release 2064909/15 : CIA-RDP79-01051A000500010001-1
Approved For Release SOO ean te ne oeroore nny a
PEOPLE''S REPUBLIC
54,600 sq. mi.; 16% agricultural area, 14% ermanent meadows Shee
and pastures, 38% alpine land are peble. waste, or
urban; 32% forested
Land boundaries: 1,720 mi.
Railroads: 63 mi., all narrow gage (2''6"); 50% government owned; all in Teraiarea
close to Indian border; only 15 mi. sector from border to Janakpur presently
in use
Highways: 1,660 mi.; 410 mi. paved, 255 mi. gravel or crushed stone, 475 mi.
improved earth; 525 mi. unimproved earth, 200 mi. of seasonally motorable
tracks
Civil air: 13 major transport aircraft
Airfields: 47 total, 43 usable; 4 with permanent-surface runways; 6 with runways
4 ,000-7 ,999 ft.
Telecommunications: poor telephone and telegraph service; good radiocommunication
and broadcast service; international radiocommunication service iS poor;
6,200 telephones, 60,000 radio and no TV sets, 2 AM, no FM, and no TV stations
DEFENSE FORCES: ;
Military manpower: males 15-49, 3,071,000; 1,550,000 fit for military service;
140,000 reach military age (17) annually
Approved For Release 20649/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000 -
NETHERLANDS aaa
"14,100 sq. mi.; 70% cultivated, 5% waste, 8% forested,
8% inland water, 9% other
Land boundaries: 635 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 280 mi.
PEOPLE: Soe ALGERIA
Population: 13,412,000, average annual growth rate 1.1% ial
(current)
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 41% Protestant, 40% Roman Catholic, 19% unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24% services, 16% commerce, 10%
agriculture, 9% construction,: 7% transportation and conmunications, 4%
other; 1.05% registered unemployed; no shortage of skilled labor but shortage
of semi-skilled labor; 129,000 unfilled vacancies reported by employers in
January, 1971
Organized labor: 33% of labor force
Railroads: 1,956 mi., standard gage; 970 mi. double track; 1,022 mi. electrified
Highways: 46,000 mi.; 26,000 mi. paved, 4,000 mi. crushed stone and gravel,
16,000 mi. earth
Inland waterways: 3,940 mi.; less than 962 mi. is natural river; more than 1,400
mi. navigable by craft of 1,000-ton capacity; 1,011 mi. will take 1,500-ton
vessels
Pipelines: crude oi], 254 mi.; refined products, 602 mi.; natural gas, 2,540 mi.
Ports: 8 major, 5 minor
Merchant marine: 405 ships (1,000 GRT or over) totaling 3,454,000 GRT, 4,773,400
DWT; includes 6 passenger, 310 cargo, 61 tanker, 18 bulk, 10 specialized
carrier
Civil air: 89 major transport aircraft
Airfields: 28 total, 26 usable; 16 with permanent-surface runways; 12 with
runways 8,000-11,999 ft., 3 with runways 4,000-7,999 ft.
Telecommunications: highly developed, excellently maintained, and well integrated;
extensive system of multiconductor cables, supplemented by radio relay links,
submarine cables, and radiocommunication stations; 3.75 million telephones;
4.81 million radiobroadcast and 3.34 million TV receivers; 5 AM, 12 FM, and
10 TV stations; 11 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,355,000; 3,010,000 fit for military service;
average number reaching military age (20) annually 116,000
Military budget: proposed for fiscal year ending 31 December 1972, $1,433 million;
about 12% of central government budget
Approved For Release 20@4f09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
NETHERLANDS ANTILLES
LAND:
394 sq. mi.; 5% arable, 95% waste, urban, or other
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 226 mi.
Railroads: none
Highways: 700 mi.; 350 mi. paved, 220 mi. otherwise improved, 130 mi. unimproved
Ports: 3 major, 6 minor
Merchant marine: 37 ships (1,000 GRT or over) totaling 1,040,000 GRT, 1,825,
700 DWT; includes 2 passenger, 12 cargo, 12 tanker, 8 blk, 3 specialized
carrier
Civil air: 6 major transport aircraft
Airfields: 7 total, all usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: generally adequate telecom facilities; extensive inter-
island VHF links; 29,000 telephones, 120,000 radio and 32,000 TV receivers,
11 AM and 3 TV stations, 4 telegraph submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 59,000; 30,000 fit for military service;
about 2,000 reach military age (20) annually *
Defense is responsibility of the Netherlands
Approved For Release 2804/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/14 :-GiA7RDP79-01051A000500010001-1
LAND:
8,500 sq. mi.; 6% cultivable, 22% pasture land, 15% forests,
57% waste or other
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 3 n. mi.)
Coastline: 1,400 mi.','f7f1aa419190567f91ced799421ef002438633ee0feb5478b4fcb354864dfc21','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f7ed54ec6d4f86201bef54b8dfafe3375255d2793cf74ce011242eee89f16dd',1973,'NE','Niger','communications',158,'LAND:
489,000 sq. mi.; about 3% cultivated, perhaps 20% somewhat
arable, remainder desert
Land boundaries: 3,570 mi.
Railroads: none
Highways: approx. 4,335 mi.; 375 mi. bituminous, 1,820 mi. gravel, 2,140 mi.
unimproved earth
Inland waterways: Niger River navigable 185 miles from Niamey to Gaya on the
Dahomey frontier from mid-December through March
Ports: Niger landlocked; outlet to sea is Cotonou, Dahomey
Civil air: 5 major transport aircraft
Airfields: 74 total, 58 usable; 4 with pernmanent-surface runways; 1 with runway
8,000-11,999 ft., 15 with runways 4,000-7,999 ft.
Telecommunications: principal telecommunication center Niamey; telephone poor,
telegraph fair, 3,300 telephones; 90,000 radio receivers; unknown number of
TV receivers; 4 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,013,000; 570,000 fit for military service;
about 43,000 reach military age (18) annually
Military budget: for fiscal year ending 30 September 1972, $5,767,000; 12.3%
of total budget .
Approved For Release 2004/99/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 Te
LAND:
357,000 sq. mi.; 24% arable (13% of total land area
under cultivation), 35% forested, 41% desert, waste,
urban, or other
Land boundaries: 2,507 mi.
WATER:
Limits of territorial waters (claimed): 30 n. mi.
Coastline: 530 mi.
Railroads: 2,180 route mi.; 3''6" gage
Highways: 55,400 mi.; 9,500 mi. paved (mostly bituminous surface treatment);
45,925 mi. laterite, gravel, crushed stone, improved earth
Inland waterways: 5,330 mi. consisting of Niger and Benue rivers and smaller
rivers and creeks; additionally, the newly formed Kainji Lake has several
hundred miles of navigable lake routes
Pipelines: crude oj], 580 mi.; natural gas, 40 mi.; refined products, 3 mi.
Ports: 2 major, 10 minor
Merchant marine: 13 cargo ships (1,000 GRT or over) totaling 83,300 GRT,
122,100 DWT
Civil air: 13 major transport aircraft
Airfields: 90 total, 77 usable; 12 with permanent-surface runways; 5 with runways
8,000-11,999 ft., 25 with runways 4,000-7,999 ft.; 4 seaplane stations
Telecommunications: composed of radio-relay links, open-wire lines, and
radiocommunication stations; principal center Lagos, secondary centers Ibadan
and Kaduna; 80,000 telephones; 1.3 million radio receivers, 75,000 TV
receivers; 25 AM, 6 FM, and 8 TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 13,365,000; 6,450,000 fit for military service
Approved For Release 2294/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release ON MN ee
LAND:
Norway: 125,000 sq. mi.; Svalbard, 24,000 sq. mi.;
Jan Mayen, 144 sq. mi.; 3% arable, 2% meadows
and pastures, 21% forested, 74% other
Land boundaries: 1,603 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 12 n. mi.)
Coastline: mainland 2,125 mi.; islands 1,500 mi. (excludes x
long fjords and numerous small islands and minor REA eww |
indentations which total as much as 10,000 mi. overal1) LIBYA |EGYPILA RAGA Wp,
Railroads: 2,634 mi.; 2,587 mi. single track standard gage; 1,526 mi. electrified,
including 47 mi. double track
Highways: 44,180 mi.; 7,135 mi. paved, 37,045 mi. crushed stone and gravel
Inland waterways: 980 mi.; 5'' draft vessels maximum
Pipelines: refined products, 33 mi.
Ports: 9 major, 69 minor
Merchant marine: 1,162 ships (1,000 GRT or over) totaling 20,957,100 GRT,
35,149,900 DWT; includes 29 passenger, 398 cargo, 291 tanker, 259 bulk,
185 specialized carrier
Civil air: 54 major transport aircraft
Airfields: 75 total, 69 usable; 40 with permanent-surface runways; 11 with
runways 8,000-11,999 ft., 13 with runways 4,000-7,999 ft.; 24 seaplane
stations
Telecommunications: high-quality domestic and international telephone, telegraph,
and telex service; 1,224,000 telephones; 2.0 million radiobroadcast receivers;
929,000 TV receivers; 41 AM, 214 FM, and 420 TV stations (including many high
powered transmitters); 5 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 914,000; 740,000 fit for military service;
average number reaching military age (20) annually, 32,000
Military budget: proposed for fiscal year ending 31 December 1972, $487.5 million;
about 12% of central government budget
Approved For Release 2002/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CO ee ee ee
LAND:
About 82,000 sq. mi.; negligible amount forested, eke
remainder desert, waste, or urban Te On
Land boundaries: 860 mi.
TURKEY
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 1,300 mi.
Highways: 1,750 total; 3 mi. bituminous surface, remainder motorable natural -
surface track
Pipelines: crude oil 230 mi.
Ports: 7 minor
Civil air: no major transport aircraft
Airfields: 192 total, 107 usable; 2 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 37 with runways 4,000-7,999 ft.
Telecommunications: poor international radiocommunications (service to Bahrain
only); very poor domestic wire service; 1,040 telephones; 1 AM station;
tropospheric scatter-link to Bahrain
DEFENSE FORCES:
Military manpower: males 15-49, 172,000; 100,000 fit for military service
Supply: mostly from U.K.; some ground equipment also from Belgium and Jordan
Approved For Release 2004/09/15 : @4A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15; lA: P79-01051A000500010001-1
LAND:
310,000 sq. mi. (includes Pakistani part of Jammu-Kashmir)
40% arable, including 24% cultivated; 24% unsuitable
for cultivation; 34% unreported, probably mostly waste
4% forested
Land boundaries: 5,350 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 650 mi.
Railroads: 5,322 mi.; 277 mi. meter gage, 4,665 broad gage, 380 narrow gage;
635 double track; government owned
Highways: 43,500 mi.; 12,700 mi. paved, 12,450 mi. gravel, 18,350 mi. earth
Inland waterways: 1,150 mi.
Pipelines: crude oi], 143 mi.; natural gas, 1,200 mi.
Ports: 2 major, 10 minor
Merchant marine: 66 ships (1,000 GRT or over) totaling 541,000 GRT, 728,500 DWT;
includes 5 passenger, 59 cargo, 2 bulk
Civil air: 12 major transport aircraft
Airfields: 201 total, 110 usable; 64 with permanent-surface runways; 1 with runway
over 12,000 ft., 20 with runways 8,000-11,999 ft., 53 with runways 4,000-
7,999 ft.; 2 seaplane stations
Telecommunications: excellent international radjocommunication service over
CENTO links; domestic wire and radiocommunication and broadcast service very
good; 207,281 telephones; 1,630,000 radio and 80,000 TV sets; 12 AM, no FM,
and 7 stations
DEFENSE FORCES:
Military manpower: males 15-49, 13,684,000; 4,350,000 fit for military service;
682,000 reach military age (17) annually
Military budget: for fiscal year ending 30 June 1972 $714,000,000; about 23%
of total budget
Approved For Release 2064/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','b1a214c4a0b2ae82a5366366c807086736e01635ead748885c782aaf232b8d7b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('236e9c3fbe1d8d30d87f46609bbeaa4c0fcb00de79bd7c957b9cfed395d08784',1973,'PA','Panama','communications',162,'LAND:
29,208 sq. mi. (excluding Canal Zone, 553 sq. mi.); 24%
agricultural land (9% fallow, 4% cropland, 11%
pasture), 20% exploitable forest, 56% other forests,
urban, and waste
Land boundaries: 390 mi.
VENEZUELA
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,545 mi.','df75d2b261fe2ee5950b11283aa2077ae3e46723fb4f83f0253842841d6edc87','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bafb969fbb1f907c11e1fc715d1fda743015437c459dd33026f0895ac2e362d',1973,'PG','Papua New Guinea','communications',163,'LAND:
183,540 sq. mi. (Papua 90,540 sq. mi., New Guinea
93,000 sq. mi.)
. Land boundaries: 600 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.) een
Coastline: about 3,200 mi.
Papua:
Railroads: none
Highways: approx. 2,480 mi.; about 1,360 mi. suitable for heavy and medium
traffic, and about 1,120 mi. suitable for light traffic
Inland waterways: 800 mi., not including minor rivers
Ports: 1 principal (Port vist 1 secondary
Civil air: see New Guinea (below
Airfields: see New Guinea (below)
Telecommunications: see New Guinea (below)
New Guinea:
Railroads: none
Highways: approx. 6,430 mi.; approx. 3,865 mi. suitable for heavy and medium
traffic, and 2,565 mi. suitable for light traffic only
Inland waterways: 1,350 mi., northeast New Guinea; minor rivers not included
Pipelines: crude oil, 87 mi.
Ports: 4 principal (Rabaul, Lae, Madang, Kavieng), 4 minor
Civil air: 17 major transport aircraft (plus 26 registered in Australia)
Airfields: 647 total, 440 usable; 13 with permanent-surface runways; 46 with
runways 4,000-7,999 ft.; 12 seaplane stations, inactive
Telecommunications: Papua New Guinea telecom services are adequate and are
being improved; principal telecom centers include Goroka, Lae, Madang,
Mount Hagen, and Wewak in New Guinea; and Daru, Port Moresby and Samarai
in Papua; facilities provide radiobroadcast, radiotelephone and telegraph,
coastal radio, aeronautical radio and international radiocommunication
services; numerous privately owned radio facilities exist; submarine
cables extend from Madang to Australia and Guam; 22,659 telephones, 80,000
radios, but no TV sets; 11 AM, no FM and no TV facilities
DEFENSE FORCES:
Military manpower: males 15-49, 644,000 (Papua 169,000, New Guinea 473,000);
about 330,000 fit for military service (Papua 85,000, New Guinea 245,000)
Defense is responsibility of Australia
Approved For Release 2004/99/15 : CIA-RDP79-01051A000500010001-1
: CIA-RDP79-01051A000500010001-1
Approved For Release Scab ht Ty
LAND:
157,000 sq. mi.; 2% under crops, 24% meadow and pasture,
52% forested, 22% urban, waste, and other : BRAZIL
Land boundaries: 2,140 mi.
Railroads: 652 mi.; 273 mi. standard gage, 85 mi. 3°3 3/8'''' gage, 294 mi. various
narrow gage (privately owned)
Highways: 9,900 mi.; 400 mi. bituminous treated, 3,100 mi. otherwise improved,
6,400 mi unimproved earth
Inland waterways: 1,970 mi.
Ports: 1 major, 7 minor (all river)
Merchant marine: 14 ships (1,000 GRT or over) totaling 15,700 GRT, 14,900 DWT;
includes 2 passenger, 9 cargo, 2 tanker, | specialized carrier; domestic
ships are operated mostly in river traffic; most international waterborne
trade is carried by foreign flag ships
Civil air: 7 major transport aircraft
Airfields: 933 total, 766 usable; 1 with permanent-surface runway; 2 with runways
8,000-11,999 ft., 27 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: local telecom facilities in Asuncion good, but intercity net
still poor; 24,000 telephones; est. 720,000 radio and 50,000 TV receivers;
20 AM, 5 FM, and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 624,000; 430,000 fit for military service;
average number currently reaching military age (17) annually, 25,000
Military budget: for fiscal year ending 31 December 1972, $17.2 million; about
17% of proposed central government budget
Approved For Release 2004769/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : gti eda cael cd
LAND:
496,000 sq. mi. (other estimates range as low as 482,000
sq. mi.); 2% cropland, 14% meadows and pastures, 55%
forested, 29% urban, waste, other
Land boundaries: 3,810 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,500 mi.
Railroads: approx. 2,144 mi.; 1,800 mi. 4° 8 1/2" gage; 130 mi. gage Tess than
3''0"; 214 mi. 3'' O" gage; 9 mi. double track
Highways: 31,100 mi.; 3,000 mi. paved, 5,400 mi. gravel or crushed stone, 8,500
mi. improved earth, 14,200 mi. unimproved earth
Inland waterways: 5,400 mi. of navigable tributaries of Amazon River system and
130 mi. Lake Titicaca
Pipelines: crude oi], 200 mi.; natural gas and natural gas liquids, 40 mi.
Ports: 7 major, 20 minor
Merchant marine: 39 ships (1,000 GRT or over) totaling 296,400 GRT, 419,600 DWT;
includes 28 cargo, 9 tanker (includes 5 naval tankers sometimes used
commercially), 2 bulk
Civil air: 33 major transport aircraft
Airfields: 336 total, 291 usable; 19 with permanent-surface runways; 2 with
runway over 12,000 ft., 18 with runways 8,000-11,999 ft., 47 with runways
4,000-7 ,999 ft.; 3 seaplane stations
Telecommunications: fairly adequate for most requirements; new radio relay system
under construction; communications satellite ground station; 250,000 telephones;
est. 1.85 million radio and 460,000 TV receivers; 210 AM, 7 FM, and 30 TV
stations
DEFENSE FORCES:
Military manpower: males 15-49, 3,358,000; 2,275,000 fit for military service;
average number currently reaching military age (20) annually, 140,000
Supply: produces some small arms ammunition; army materiel is supplied by
Belgium, France, and the U.5.; aircraft and ships from France and U.K.
represent three fourths of the total value of non-U.S. imports since 1953
Military budget: a biennial budget for 1 January 1971 through 31 December 1972,
$485.2 million; about 16.2% of central government biennial budget
Approved For Release 2004Af9/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','8d96e3f360dfe83e2cc5bd062642aab6be7acf93cf8599d8e2716aa3953128d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f45494b1f1d03e3a9e3b7b2e9067f3b77b5d45fcaedfd443a155ae385d004e8f',1973,'PH','Philippines','communications',167,'PEOPLE''S REP
OF CHINA
LAND:
116,000 sq. mi.; 37% cropland, 41% forested, 22% other
WATER:
Limits of territorial waters (claimed): under an archipelago
theory, waters within straight lines joining appropriate
points of outermost islands are considered internal
waters; waters between these baselines and the limits
described in the Treaty of Paris, December 10, 1898,
the U.S.-Spain Treaty of November 7, 1900, and the
U.S.-U.K. Treaty of January 2, 1930 are considered
to be the territorial sea
Coastline: about 14,000 mi.
Railroads: 2,160 mi.; 2 common-carrier systems (3''6" gage) totaling about 710
mi.; 19 industrial systems with 4 different gages totaling 1,450 mi.; 34%
government owned
Highways: 45,690 mi.; 8,886 mi. paved; 23,770 mi. gravel, crushed stone, or
stabilized soil surface; 13,034 mi. improved earth
Inland waterways: 2,000 mi.; limited to shallow-draft (less than 5 ft.) vessels
Pipelines: refined products, 157 mi.
Ports: 13 major, 89 minor
Merchant marine: 176 ships (1,000 GRT or over) totaling 870,600 GRT, 1,251,800
DWT; includes 9 passenger, 121 cargo, 30 tanker, 9 bulk, 7 specialized *
carrier
Civil air: 87 major transport aircraft
Airfields: 354 total, 245 usable; 417 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 26 with runways 4,000-7,999 ft.; 8 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,800,000; 5,750,000 fit for military service;
about 375,000 reach military age (20) annually
Military budget: for fiscal year ending 30 June 1972, $111 million; about 15%
of total budget
Approved For Release 2004/89/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 parhipro 7 9-01051A000500010001-1
LAND:
120,600 sq. mi.; 49% arable, 14% other agricultural, 27%
forested, 10% other
Land boundaries: 1,920 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 305 mi.
Railroads: 16,469 route mi.; 14,381 mi. standard gage, 2,088 mi. narrow gage;
4,644 mi. double track; 2,400 mi. electrified; government owned (1970)
Highways: 190,095 mi.; 40,389 mi. paved; 39,479 mi. crushed stone, gravel;
110,227 mi. earth {improved and unimproved) (1971)
Inland waterways: 3,158 mi. navigable streams and canals (1972)
Pipelines: 2,000 mi. for natural gas; 1,000 mi. for crude oi1; 200 mi. for refined
products
Freight carried: rail -- 438.8 million short ton, 71.4 million short ton/mi.
(1971); highway 1,080.3 million short tons, 12.2 billion short ton/mi. (1970);
waterway -- 10.6 million short tons, 1.5 billion short ton/mi. (1971)
Merchant marine: 254 ships (1,000 GRT and over) totaling 1,792,600 GRT and
2,525,100 DWT; includes 1 passenger, 172 cargo, 4 tanker, 76 bulk
DEFENSE FORCES:
Military manpower: males 15-49, 8,749,000; 6,910,000 fit for military service;
356,000 reach military age (19) annually
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','229c687c04f46e9922569e9441b3bd192b6caac40669276e4a069998b054e375','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7303267591418229494feacf54d717184c112f9a54abbcc5b994f911707d2c49',1973,'PT','Portugal','communications',171,'LAND:
Metropolitan Portugal: 35,520 sq. mi., including the Azores
and Madeira Islands; 48% arable, 6% meadow and pasture,
31% forested, 15% waste and urban, inland water, and
other
Cape Verde Islands: 1,560 sq. mi., divided among 10 islands
and several islets (not a part of Metropolitan Portugal )
Land boundaries: 750 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 535 mi. (excludes Azores, Maderia, and Cape
Verde Islands, 1,180 mi.)
MOROCCO : ALGERIA
Railroads: 2,230 mi.; 472 mi. 3''3 3/8" meter gage, 1,758 mi. broad gage (5''5 9/16");
265 mi. double track; 274 mi. electrified
Highways: 18,500 mi.; 11,000 mi. bituminous, bituminous treatment, concrete and
stoneblock; 7,200 mi. gravel and crushed stone; 300 mi. improved earth; plus
an additional 10,500 mi. of unimproved earth roads (motorable tracks)
Iniand waterways: 508 mi. navigable; relatively unimportant to national economy,
used by shallow-draft craft limited to 330-ton cargo capacity
Pipelines: crude oil 7 mi.
Ports: 7 major, 33 minor
Approved For Release 20@4#09/15 : CIA-RDP79-01051A000500010001-1
communReLPRS Fo ar ete 2004/09/15 : CIA-RDP79-01051A000500010001-1
Merchant marine: 116 ships (1,000 GRT or over) totaling 904,500 GRT, 1,195,200 DWT;
includes 13 passenger, 75 cargo, 19 tanker, 6 bulk, 3 specialized carrier
Civil air: 22 major transport aircraft
Airfields (including Azores, Cape Verde Islands, and Madeira Islands): 62 total,
54 usable; 26 with permanent-surface runways; 1 with runways over 12,000 ft.,
10 with runways 8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 7 seaplane
stations
Telecommunications: facilities are generally adequate; 817,000 telephones; 1.6
million radio receivers; 474,000 television receivers; 37 AM, 34 FM, and 36
TV stations; 2 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 2,160,000; 1,670,000 fit for military service;
average number reaching age (20) annually, about 75,000
Military budget: proposed for fiscal year ending 31 December 1972, $462 million;
about 34% of central government budget
Approved For Release 2004/09/15 : GAR RDP79-01051A000500010001-1
Approved For Release 2004/09/47 GSR anh! 051A000500010001-1
LAND:
14,000 sq. mi. (includes Bijagos archipelago)
Land boundaries: 460 mi.
'' WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 170 mi.','fdfdef035192e1105e9ccb591c26677c56a26315ade2ebe8ee673d594e22ac24','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07711cbcc02c8b752509bb69f4466b94004faa7cf90763d1403523501ded0e47',1973,'QA','Qatar','communications',175,'LAND:
About 4,000 sq. mi.; negligible amount forested; mostly
desert, waste, or urban
Land boundaries: 35 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 350 mi.
Railroads: none
Highways: 275 mi. bituminous; 225 mi. gravel; surfaced; undetermined mileage of
earth tracks
Pipelines: crude oi1, 105 mi.; natural gas, 60 mi.
Ports: 2 minor
Airfields: 10 total, 1 usable; 1 with permanent-surface runway over 12,000 ft.
Civil air: no major transport aircraft
Approved For Release 2004/09/15 : ClA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d):
Telecommunications: all international telecom traffic is by radio thru Bahrain;
fair domestic wire facilities; 10,730 telephones; 30,000 radio and 22,000 TV
receivers; 1 AM and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 35,000; about 20,000 fit for military
service
Supply: mostly from U.K.
Approved For Release 2034/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release OM ee','700d503c835f1af7f835f9cb6340e239806585d616249f02274f1c3add6b3952','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b8dfacea85d8a1ee5d7ff81352794ff40028d5eeeb34e079027b99b192bacc2',1973,'IN','India','communications',179,'LAND:
970 sq. mi.; two-thirds of island extremely rugged,
consisting of volcanic mountains; 120,000 acres (less
than one-fifth of the land) under cultivation
WATER: Fan
Limits of territorial waters (claimed): 3 n. mi
Coastline: 125 mi.
Railroads: none
Highways: 1,092 mi.; 814 mi. paved, 278 mi. gravel, crushed stone, or stabilized
earth
Ports: 1 major
Civil air: no major transport aircraft
Airfields: 6 total, 6 usable; 1 with permanent-surface runway; | with runway
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.
Telecommunications: adequate for size of island and fairly modern; international
communications by radio to France, Malagasy Republic, and Mauritius; 16,000
telephones; 71,000 radio and 23,000 TV receivers; 1 AM, no FM, and 8 TV
stations
DEFENSE FORCES:
Military manpower: military age males included with France
Approved For Releas#&004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 GlASRRPT9-01051A000500010001-1
* RHODEST
LAND:
151,000 sq. mi.; 40% arable (of which 6% cultivated); 60%
available for extensive cattle grazing; European
. alienated lands (farmed by modern methods) 39%,
African 48%, national land 7%, 6% not alienated
Land boundaries: 1,875 mi.
Railroads: 1,610 mi. narrow gage (3''6"); 26 mi. double track
Highways: 48,733 mi.; 4,968 mi. paved, 20,415 mi. crushed stone, gravel,
stabilized soil, or improved earth; 23,350 mi. unimproved earth
Inland waterways: 175 mi. on Lake Kariba
Airfields: 307 total, 210 usable; 8 with permanent-surface runways; 1 with run-
way over 12,000 ft., 22 with runways 4,000-7,999 ft.
Civil afr: 12 major transport aircraft
Telecommunications: system is one of the best in Africa; consists of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Salisbury, secondary center Bulawayo; 132,000 telephones; 212,350 radio
and 50,000 TV receivers; 8 AM, no FM and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,336,000; 815,000 fit for military service;
average number reaching military age (18) annually, 53,000
Military budget: for fiscal year ending 30 June 1972, $51,260,000; 15.5% of
total budget
Approved For Release 2664/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : ih ee
LAND:
91,700 sq. mi.; 44% arable, 19% other agriculture, 27%
forested, 10% other
Land boundary: 1,845 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. ee Ny
Coastline: 140 mi. ener! caer
Railroads: 9,700 mi.; 6,430 mi. standard gage, 3,252 mi. narrow gage, 18 mi.
Ase 243 mi. electrified, 783 mi. double track; government owned
1971
Highways: 48,000 mi.; 7,600 mi. paved; 16,300 mi. other improved surfaces,
24,100 mi. earth (1970)
Inland waterways: 1,445 mi. (1972)
Pipelines: crude oi], 1,600 mi.; refined products, 888 mi.; natural gas, 3,100
mi.
Freight carried: rail -- 198.9 million short tons, 31.7 billion short ton/mi.
(1971); highway -- 490 million short tons, 5.3 billion short ton/mi. (1971);
waterway -- 3.4 million short tons, .77 billion short ton/mi. (1970)
Ports: 4 major (Constanta, Galati, Braila, Mangalia), 4 minor (1972)
Merchant marine: 58 ships (1,000 GRT or over) totaling 413,100 GRT, 593,500
DWT; includes 1 passenger, 38 cargo, 4 tanker, 15 bulk
Airfields: 149 total; 25 with permanent-surface runways; 1] with runways 8,000-
11,999 ft.; 25 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 5,429,000; 4,525,000 fit for military service;
188,000 reach military age (20) annually
Supply: most military equipment and small naval ships imported from U.S.S.R.;
smal] arms, rocket launchers and ammunition, explosives, and chemical warfare
defensive materiel, medium trucks and jeeps, and small naval craft produced
locally
Military budget: for fiscal year ending 31 December 1972, 7,845 million lei;
about 5.2% of total budget
Approved For Release 2804/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/1 Buiatha ROP 79-01051A000500010001-1
D:
10,000 sq. mi.; almost all the arable land, about 1/3
under cultivation, about 1/3 pastureland
Land boundaries: 545 mi.
Railroads: 36 mi., narrowgage (2''6") on St. Kitts for sugar cane
Highways: 180 mi.; 60 mi. paved, 90 mi. otherwise improved, 30 mi. unimproved
earth
Ports: 3 minor (1 on each island)
Civil air: no major transport aircraft
Airfields: 2 total, 2 usable; 1 with asphalt runway 5,700 ft.
Telecommunications: good interisland VHF radio connections and international
link via Antigua; about 1,650 telephones; 1,500 radio receivers; 2 AM
and 5 TV stations
Approved For Release 2004/99/15 : CIA-RDP79-01051A000500010001-1
Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Re ari
LAND:
238 sq. mi.; 34% arable, 5% pasture, 21% forest, 22%
unused but potentially productive, 18% wasteland
and built-on
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 98 mi.
Railroads: none ,
Highways: 415 mi.; 175 mi. paved; 240 mi. otherwise improved
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
Approved For Release 2004/09/1529€1A-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d):
Airfields: 3 total, 3 usable; 2 airfields with permanent surface runways; one
with a 9,000 foot runway; one with a 5,700 foot runway; 2 seaplane stations
Telecommunications: fully automatic telephone system with 3,690 telephones; direct
radio link with Martinique; interisland tropospheric links to Barbados and
Antigua; 20,000 radio and 50,000 TV receivers; 1 AM, and 1 TV station
Approved For Release 2004/99415 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/45 : GiAcRRP 79-01051A000500010001-1
LAND:
150 sq. mi. (including northern Grenadines); 50% arable,
3% pasture, 44% forest, 3% wasteland and built-on
WATER:
Limits of territorial waters (claimed): 3 n. mi. ;
Coas tl i ne: 52 mi ° : VENEZUELA
PEOPLE : COLOMBIA
Population: 92,000, average annual growth rate 1.1% (April
60-70) BRAZIL
Ethnic divisions: mainly of African Negro descent; remainder
mixed with some white and East Indian and Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 24,000 (1960); about 40% in agriculture
Organized labor: 10% of labor force
Railroads: none
Highways: about 65 mi.
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system serving 3,150 telephones; no
radiobroadcasting or television facilities, 3,000 radio and 600 TV receivers
(Italian broadcasts)
Approved For Release 2004709/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/11 Gd Aria Py 9-01051A000500010001-1
LAND:
618,000 sq. mi. (boundaries are poorly defined); 1%
agricultural, 1% forested, 98% desert, waste, or
urban
Land boundaries: 2,820 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,560 mi.
Railroads: 640 mi. meter gage; 40 mi. double track
Highways: 8,725 mi.; 1,335 mi. bituminous, 990 mi. gravel, 400 mi. improved
earth, 6,000 mi. unimproved earth
Inland waterways: 935 mi.
Merchant marine: 3 ships (1,000 GRT and over) totaling 4,600 GRT, 6,700
DWT; includes 2 cargo, 1 tanker
Ports: 1 major, 4 minor
Civil air: 3 major transport aircraft, including 1 leased to Air Mauritanie
Airfields: 41 total, 26 usable; 8 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: relatively advanced for Africa; 29,300 telephones; 275,000
radio receivers; 1,500 TV receivers; 3 AM, no FM, and 1 TV stations;
3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 961,000; 460,000 fit for military service;
45,000 reach military age (18) annually
Supply: primarily dependent on France
Military budget: for fiscal year ending 30 June 1973, $19,289,000; about 8.7%
of total budget
Approved For Release 2014/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Railroads: none
Highways: 575 mi.; 252 mi. paved, 129 mi. crushed stone or gravel, 194 mi. earth
Civil air: no major transport aircraft
Approved For Release 2004/09/15 : @PA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','bcb9689fb3839bf5eb8a4a869bd3637fd75a609db9418f3a65ca0d472dafe22f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad70900879a58f1cb920379dcc970abc634e2ba551cd91294eefed9eb53cd2a9',1973,'SC','Seychelles','communications',183,'LAND:
156 sq. mi.; 54% arable land, nearly all of it is under
cultivation, 17% wood and forest land, 29% other
(mainly reefs and other surfaces unsuited for
agriculture); 40 granitic and 43 coral islands
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 305 mi. (Mahe Island 58 mi.)
Railroads: none
Highways: 141 mi.; 62 mi. bituminous, 79 mi. crushed stone or earth
Ports: 1 minor port (Victoria)
Civil air: no major transport aircraft
Airfields: 2 total, 1 usable on Astove Island, 1 permanent surface 8,000-11,999
ft.; former RAF seaplane station at Victoria, Mahe Island, although not in
present use, could be used in emergency
Telecommunications: direct radiotelegraph communications with other adjacent
islands and African coastal countries; 900 telephones; 12,000 radio sets;
no TV sets; 2 AM, no FM, and no TV stations; submarine cables extend to
Aden, Tanzania, and Sri Lanka
DEFENSE FORCES:
Military manpower: males 15-49, 13,000; 7,000 fit for military service
Defense is responsibility of U.K.; no U.K. troops present
Approved For Release 20Q4/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','c847b29c1a2f107f2d126a5b19eb6ad2afc48b33020efd13bce36a164203797b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66d19721f4e39f5467a4674022a48ecab948e4fec8b5886dbcbaab8035d1ac69',1973,'SL','Sierra Leone','communications',187,'27,900 sq. mi.; 65% arable (6% of total land area under
cultivation), 27% pasture, 4% swampland, 4% forested
Land boundaries: 580 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
(no fishing claim)
Coastline: 250 mi.
Railroads: 370 route miles; 310 mi. narrow gage (2''6") Sierra Leone Government
Railroad (SLR), 60 mi. narrow gage (3''6") privately owned mineral line
operated by the Sierra Leone Development Company
Highways: 4,950 mi.; 450 mi. bituminous (including some bituminous treatment),
1,750 mi. laterite (some gravel}, and 2,750 mi. earth
Inland waterways: 500 mi.; 372 mi. navigable year-round
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 15 total, 15 usable; 5 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecomnunications: telephone and telegraph are adequate; 6,500 telephones;
35,000 radio and 3,050 TV receivers; 1 AM, no FM, and 1 TV stations;
3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 623,000; 300,000 fit for military service; no
conscription
Military budget: for year ending 30 June 1972, 6,122,000; 8.4% of total
budget
Approved For Release 2094j09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release co OOS eee on ne 000 100011
ee
" 2,800 sq. mi. ee
Land boundaries: 265 mi.
LAND
PEOPLE: sly
Ethnic divisions: 75% Nepalese; 25% Bhotias, Lepchas, and ra
a few tribal groups |
Religion: Tibetan or Lamaist Buddhism (the state religion)
33.3%; Nepalese majority are primarily Hindu
Language: English, official; Nepali, lingua franca; Bhotias
and Lepchas speak Tibeto-Burman dialects
Literacy: probably less than 15%
Labor force: predominantly agricultural; minimal skilled
labor','97cdf81a2388989bd36d95e85b2888adab27fad8123df5edba41022b980be0fa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d81b468c28657d7459bf9194ea9162dab5890be4554cbc352afb79cb90484f93',1973,'SG','Singapore','communications',191,'LAND:
225 sq. mi.; 31% built up area, roads, railroads, and
airfields, 22% agricultural, 47% other
rN
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi.
Railroads: 24 mi. of meter gage
Hilghiwe ys | 1,226 mi.; 773 mi. paved, 243 mi. crushed stone, 210 mi. improved
eart
Ports: 3 major
Civil air: 13 major transport aircraft
Airfields: 5 total, 5 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate domestic facilities; good international service;
good radio and television broadcast coverage; about 161,310 telephones;
est. 251,000 radio and 168,853 TV sets; 2 AM, 4 FM, and 2 TV stations; new
SEACOM submarine cable extends to Hong Kong via Sabah, Malaysia
DEFENSE FORCES:
Military manpower: males 15-49, 575,000; 390,000 fit for military service
Military budget: for fiscal year ending 31 March 1972, $201.2 million; 39% of
total budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 CT a a
D:
246,000 sq. mi.; 13% arable (0.3% cultivated), 32%
grazing, 14% scrub and forest, 41% mainly desert,
urban, or other
Land boundaries: 1,406 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,880 mi.
Railroads: none
Highways: 8,414 mi.; 582 mi. paved; 478 mi. crushed stone, gravel, or
stablized soil; 7,354 mi. improved or unimproved earth
Inland waterways: Fiume Giuba navigable 345 mi. from May to mid-June and
August to late November
Ports: 4 major, 17 minor
Civil air: 6 major transport aircraft
Airfields: 107 total, 57 usable; 2 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 12 with runways 4,000-7,999 ft.; 5 seaplane
stations
Telecommunications: telephone poor, telegraph fair; 4,740 telephones; 50,000
radio receivers; 2 AM, no FM or TY stations
DEFENSE FORCES:
Military manpower: males 15-49, 715,000; 389,000 fit for military service; no
conscription
Approved For Release 2004/69/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','5177a1e95b8dfc010ffaab8351cb2df187938dac481b3d285c8b1105d3ec9148','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a93a01f7a473cd48ede2e930f48b3f439b361821cd572c38ea6f4f38e70d5e8',1973,'ZA','South Africa','communications',195,'LAND:
472,000 sq. mi. (includes enclave of Walvis Bay,
434 sq. mi.); 12% cultivable, 2% forested, 86% desert,
a waste, or urban
Land boundaries: 1,270 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n, mi.)
Coastline: 1,790 mi.
Railroads: 12,318 mi.; 11,879 mi. 3''6" gage of which 1,323 mi. are multiple
track; 2,726 mi. electrified; 440 mi. 2''0" gage single track
Highways: 220,000 mi.; 27,300 mi. paved, 47,050 mi. crushed stone or gravel,
145,650 mi. improved and unimproved earth
Pipelines: crude oil, 520 mi.; refined products, 450 mi.; natural gas, 200 mi.
Ports: 5 major, 6 minor
Civil air: 49 major transport aircraft
Airfields: 743 total, 573 usable; 42 with permanent-surface runways; 1 with runway
over 12,000 ft., 7 with runways 8,000-11,999 ft., 129 with runways 4,000-7 ,999
ft.; 4 seaplane stations
Teleconmunications: the system, except for the lack of television, is the best
developed, most modern, and highest capacity in Africa and consists of
carrier-equipped open-wire lines, coaxial cables, radio-relay links, and
radiocommunication stations; key centers are Bloemfontein, Cape Town,
Durban, Johannesburg, Port Elizabeth, and Pretoria; 1.6 million telephones;
2.5 million radio receivers; 13 AM, 60 FM, and no TV stations; 4 submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 5,312,000; 3,250,000 fit for military service;
obligation for service in Citizen Force begins at 18; volunteers for service
in permanent force must be 17
Approved For Release 200470$/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/04/15: ClA-BDP TH -01051A000500010001-1
LAND:
318,000 sq. mi.; mostly desert except for interior
plateau and area along northern border
Land boundaries: 2,360 mi.
WATER:
Limits of territorial waters (claimed): 6 n, mi.
(fishing, 12 n. mi.)
Coastline: 925 mi.
Railroads: 1,454 mi., all 3''6" gage, single track
Highways: 21,000 mi.; 2,344 mi. bituminous treated, 220 mi. gravel and 18,436 mi.
earth road and tracks
Ports: 1 major, 1 minor
Civil air: 3 major transport aircraft (registered in South Africa)
Airfields: 123 total, 95 usable; 10 with permanent-surface runways; 4 with
runways 8,000-11,999 ft., 39 with runways 4,000-7 ,999 ft.; 1 seaplane station
Teleconmunications: system is a meager combination of open-wire lines, a single
short radio-relay link, and scattered radiocommunication stations; Windhoek
is the center; 33,400 telephones; unknown number of radio receivers; no
AM, 1 FM, and no TV stations
DEFENSE:
Military manpower: males 15-49, about 190,000; about 110,000 fit for military
service
Defense is responsibility of Republic of South Africa
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 GIAJROP79-01051A000500010001-1
LAND:
195,000 sq. mi., including Canary (2,900 sq. mi.) and
Balearic Islands (1,940 sq. mi.); 41% arable and
land under permanent crops, 27% meadow and pasture,
22% forest, 10% urban or other
Land boundaries: 1,180 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 3,085 mi. (includes Balearic Islands, 420 mi.,
and Canary Islands, 720 mi.)','1b76cf77b62caaa1de22a8d557ffdf085ccc8176241e64a4cffe893cba520341','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c37f5596f2736faa03c94f6a34bc7ce73863370bd71d4252aa5b678e7631409a',1973,'ZM','Zambia','communications',198,'D:
288,000 sq. mi.; 5% under cultivation, 5% arable, 10%
grazing, 13% dense forest, 6% marsh, 61% scattered
trees and grassland
Land boundaries: 3,730 mi.
Railroads: 664 mi., government owned, all narrow gage (3''6"); 8 mi. double track
Highways: 21,220 mi.; 1,600 mi. paved, 3,020 mi. crushed stone, gravel, or
stabilized soil; 16,600 mi. improved and unimproved earth
Inland waterways: 1,409 mi. including Zambezi River, Luapula River, Lake Kariba,
Lake Bangweulu, Lake Tanganyika; principal port on Lake Tanganyika is Mpulungu
Pipelines: 450 mi. refined
Civil air: 11 major transport aircraft
Airfields: 193 total, 162 usable; 8 with permanent-surface runways; 1 with
runway over 12,000 ft., 1 with runway 8,000-11,999 ft., 20 with runways
4 000-7 3999 ft.
Telecommunications: al] services being modernized and increased; presently
adequate but must be expanded to permit growth; high-capacity wire and
radio relay connect centers of Kitwe in northern mining region and Lusaka
along axial north-south route; 56,000 telephones; 100,000 radio and
18,500 TV receivers; 4 AM, 1 FM, and 2 TY stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,015,000; 485,000 fit for military service
Military budget: for fiscal year ending 31 December 1970, $26,400,000; about
4.8% of total budget
Approved For Release 2008/09/15 : CIA-RDP79-01051A000500010001-1
«
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','dc043253d847c076fd774b90542328e7436942ad3181de8c528e4afd5d17741f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c871dd4fcb4d5905d77cc68f723aae00dd146cae8b34ca6a46604cce991f5713',1973,'US','United States','communications',202,'This "Factsheet" on the U.S. is provided solely as a service to those
wishing to make rough comparisons of foreign country data with a U.S.
"yardstick." Information is from U.S. open sources and publications
and in no sense represents estimates by the U.S. intelligence community.
LAND:
3,615,211 sq. mi. (contiguous U.S. plus Alaska and Hawaii); 19% cultivated,
27% grazing and pasture, 32% forested, 22% waste, urban, and other
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing, 12 n. mi.)
Railroads: 207,000 mi. (1969)
Highways: 3,730,000 mi. (1970); 2,411,000 mi. surfaced (1970)
Approved For Release 2004/09/15 : GiX-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
COMMUNICATIONS (cont''d):
Inland waterways: 25,260 mi. of navigable inland channels, exclusive of the
Great Lakes; freight carried 951 million short tons (1970)
Pipelines: petroleum, 176,000 mi.
Ports: 25 major
Merchant marine: 1,478 ships (1,000 GRT or men totaling 24,474,000 DWT (1971)
Civil air: 3,000 major transport aircraft (1969
Airfields: 11,261 (1970)
Telecommunications: 4,370 AM, 2,722 FM, 1,035 TV operating stations (1970);
120,155,000 telephones (1970), 58.6 telephones per 100 population (1970)
DEFENSE FORCES:
Personnel: army 1,570,186, navy 765,232, air force 904,759, marines 307,252 (1968)
Military budget: $80.5 billion (1968)
Approved For Release 2096409/15 : CIA-RDP79-01051A000500010001-1
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1
ee au 4 a A Bal £5 #9 122 FE El $5 +
i t | i { t {
| : '' | i '' \\ | i
ie dusapato ey oo | ! i ee ce ee Oe as A | N |
AiR Cc { u ! |
| |
: . : = i | i
Or oS E A No | a. FO | |
SVERDRUP ISLANDS _ | \\
= | |
a a ee tes Raa e alg Dy BS 2 of a tas ie
ton yt |
Re ont : '' x al @ A s Lap re v sea pg ‘
Se GREENLAND: ; : * I acer
| a : i : 2 : x eee ee 5
ia a me as ae : : ae 7 we tay SETS EAST SIBERIAN SEA
ea Le : : aan cosh oo : a a 1 + ''
pare . im C ? = ji f pe acer { xo :
is S sy ON . ge = te
é go Se Print Woes ; PNOVAYR ZEMLvA woe Copal Ba Wanesie
waa ER ACU OR SEA err Rend gh ar ; i { I anh aS
ere : me SN Sane | ‘
ats gi RE OS TE SS
| ore Ba Se ig . ! :
<. ee Se
eek pea
aoe UNITED STATES | : SQN i
ES aie {ALASKA} i | = ICELAND |} |
ce Pow eT
“NEAEROE IS, | i i
FA SHETLAND 15. ay |
aaecae ; OF; SOVIET SOCIALIST REPUBLICS
: | \\ aay: .
ae | Peed, oF
oo! —_ Cc A N i ie R Sai:
e : QUEEN CHARLOTTE IS. " q =
4 § oxaopse VU 2 + wae"
\\ Sakhalin rr ALEUTIAN [ISLANDS
vercotieg H PR ts i ( A a
se | of 2
t | | sh i at ot ‘
| ot
| y a [ | so) aE ee
( i <—,.| Fond i od
\\ | as oa sons A :
f TAZORES Y Sardinia A ;
N OR TH \\ UNITED STATES ne co agape SB ach of PF N
v, ! | = i = antes Go Bitty Orda a” sie
, '' Pe ane i i
os Ff N OLR TH ee ye etn th
PAC 7 | jin Ge eS os BERMUDA|''S ia ee e BEA Von: p A
: i ce ye a: y
[20 panne — i | Z il a a
a # ‘ : : A; : > or | GERIA 4 | i +2
SS See AF LIAN PF PC . | caypt ‘a iba ae PAWRIAN 18
O C E A N i i “MEXICO? sf eu HAMALIS \\ | / oy SAUDI ; 7 o © VOLCANO IS. | Marcus I. N i
ea . ARABIA Be O ose: A
- : i i H i 25
a ; i : a 4 “am
me eS | : \\ a st aa e | eng REPUBLIC OF CHINA |
Dawa ; UO eae, et aoe y ! : + Wake
® | ra +
: ! i 2 ey 4 o «lt Js MARIANA IS
: : ~ CAPE oe Pa ay “gen cia, tne ii "
hs te eee oe se Ne SS . + od
NICARAGUA H a Socotra \\ ] ANDAMAN 1S Y Cambon boc ky Agr? PHILIPPINES ‘Gam
: i eat LACCADIVE 1S : 7 j 4 aS Pl aE .
Clipperton 1, aL cs ee Gentpuees me \\ Es . A SRILANKA| ‘ fe Tg 9 FE er A ays Ye. CAROLINE 38 - eee
nat \\ : : — 2 tn , : : TRUK IS.
me % | SOMALIA L MCOBER Be ied Seo dete ge s
Palmyra 1. ° ae a j f i may ~~ BRUNEL/ *s Se
al FRENCH GUIANA MALDIVES : a . GILBERT IS:
''S COLOMBIA / i MR MALAYS Lk 4 mL
Ciwistenas | . 7 . Seon a \\
Enos > WY a - 3, 3 — - : 7 o
( 2 3 GAUPAGOSHIS. SS TECUADOK t= , : 7 v Ac be A, Boren co Ree BS ; : CA NEW GUINEA ee
fy i — fa: PS en : tea ¢
Solu TH eae Jo : ee set OTF mdf
ay | genes SEYCHELLE ARCHIPELAGO TN ELLICE 1S.
i i Ascension 1 ; TANZANIA \\) ! . 3 “oN en . eee: >| SOLOMON] ISLANDS
Z LiL - ; ae Sg at bee TER
Pen L im < \\ Sarees : Se aes at Ras aS ina
by MARQUESAS IS: P AEC ARO PoE C | A . ee rot eee Si = Bee + Cheistmas : : ae sea A 3 8 oe
: : af ! : Pa H Be : : 3 i CORAL AMOA
a '' { i | ZAMBIA ao st ae : cae . ‘ “SAMOA e''s
5 a en AME : jf eels ees ag} nt s : . i: oN NEW HEORIDES Ss, FTIS, : fe
; ARCHIPELAGO O CE AN I i St. Helena 5. | : wer os , : ; : 3
COOK 1s. SOCIETY 1S. 5: i i : | eo é ’ i . SEA iz aD
. Tahiti | ; : hae \\ | MALAGASY pos A N i 3 3
? j i , : BHODESAY © i | REPUBLIC > mavartus | N D ! pene y fall os OF "
TUBUAI IS. i I OUTS ‘ ; : : ore | } ao : New Catedonithy, +
es { Ss ©) i u T H Wai Bay} WEST TROTSWANA 4 : \\ : REUNION v
: ; 4 US (Rep. of S Attia : i é
Pleat, aie = yAFRIC LA bis ‘ AUSTRIALIA i
Exel! e SATILAND 7 | = \\
| ! t O es E A N I : | Norotie be
; ; \\
Pa Come oP , ee ra Lo ek Ne oot rs a (ora Howe tf 7 eee
: i i : JUAN FERNANDEZIS.) 0°} 1 if fe i { ae rae /
i ‘ : ene, (aes : ; i Qo-re ave |/
H i : i _ ; : =a \\
: iwc A __ Teta da Cora : | Amsterdam 1, : | Soy
: : : ia , pee ; i * saint Paut f. | ; eed TASMAN nw 7 7
i : : ; x) fon Bough i i \\ | ise ZEALANDS,
PS ee OC e A eM | oman Se 4 foe
: i | sey ; i | j :
i : Laos gs Be | : aoe) a CHfTHAM 1S
fi \\ i met st i : bo He ate! apes i Sane renner) Cane eee ites 45
ate Tes be pera er Tee as a i t— : | ; i PRINCE EDWARD IS... CROZET IS. r fo
: hy tof : : \\ : . * i 8B BOUNTY IS.
} fee H ; | I | KERGUELEN 1S. } i i
+ eel | ay - '' } | tis i i ANTIPODES. 45
a ; x ra | FALKLAND 1S. | | | i | a AUCKLAND 1S
| { | et Dee
i | Rai ! :
y . ‘ ( MACQUARIE 1.
/ i ee f
{ |
| | sia ig sounoany mttnesen talon 3
t { + 2 | NOT NECESSARILY AUTROSUATIVE:
Approved For Release 2004/09/15 : CIA-RDP79-01051A000500010001-1','bcb51a063027c1c964ec3c70d5554d875f1a4cc0f30749af042e3a2064448df0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000500010001-1','txt','de9957ac625e233f3f15cfe3cbc0eaef7b03f67128a87db9c21b059f87f37cb3','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000500010001-1/cia-rdp79-01051a000500010001-1_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae5cbaeda3e0dc3d53d7f93965475da2a35d641f5a4423d5b9300c048bb86f0a',1973,'','','communications',5,'Railroads: 6 mi. (single track) 5''0"-gage, government-owned spur of Soviet line
Highways: 10,740 mi.; 420 mi. concrete, 980 mi. bituminous surfaced, 2,100 mi.
gravel, 3,630 mi. improved earth, and 3,610 mi. unimproved earth
Inland waterways: total navigability 760 mi.; steamers use Amu Darya
Ports: only minor river ports
Airfields: 72 total, 40 usable; 9 with permanent-surface runways; 6 with runways
8,000-11,999 ft., 9 with runways 4,000-7,999 ft.
Telecommunications: limited telephone, telegraph, and radiobroadcast services,
barely sufficient to meet civil and military requirements; 20,960 telephones;
est. 400,000 radio receivers: no TV receivers; 1 AM, no FM, no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 4.7 million; 2.5 million fit for military
service; about 165,000 reach military age (22) annually
Supply: dependent on foreign sources, almost exclusively the U.S.S.R.
Military budget: for fiscal year ending 31 March 1972, $36.8 million; 20.3%
of total budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
(t-9 aee eeeee
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','032337e2ffdc5cef570e23c9b647e3f6a3773d3c0774c9a6777070156bea7bc9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9c8483f7139c2003b2a0e24e84e3f4d132c20b7b63e995f6dbe96f6ed4e0c26',1973,'AL','Albania','communications',6,'D:
11,100 sq. mi.; 19% arable, 24% other agricultural, 43%
forested, 14% other
Land boundaries: 445 mi.
WATER: ae SS: n . TURKEY
Limits of territorial waters (claimed): 12 n. mi. rk
Coastline: 225 mi. (including Sazan Island)
PEOPLE: upva J eaveT
Population: 2,321,000, average annual growth rate 2.8%
(current)
Ethnic divisions: 96% Albanian, remaining 4% are Greeks,
Vlachs, Gypsies, and Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10% Roman Catholic (observances
prohibited; Albania claims to be the world''s first atheist state)
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics available, but probably
greatly improved
Labor force: 911,000 (1969); 60.5% agriculture, 17.9% industry, 21.6% other
nonagricul tural
Railroads: 127 mi. standard gage, Single track; government owned (1972)
Highways: 3,100 mi.; 300 mi. paved, 1,200 mi. crushed stone and/or gravel, 1,600
mi. improved or unimproved earth (1972)
Inland waterways: 27 mi. plus Albanian sections of Lake Scutari, Lake Ohrid,
and Lake Prespa (1973)
Freight carried: rail -- 3.0 million short tons, 123.3 million short ton/mi. (1971);
highways -- 42.9 million Short tons, 616.5 million short ton/mi. (1970)
Ports: 2 major (Durres, Vlore), 2 minor (1973)
Merchant marine: 11 ships (1,000 GRT or over) totaling 53,800 GRT, 72,700
DWT, includes 8 cargo, 3 bulk
Pipelines: crude oil, 110 mi.
Civil air: no major transport aircraft (1973)
Airfields: 11 total; 4 with permanent-surface runways; 6 with runways 8,000-
11,999 ft., 5 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 552,000; 460,000 fit for military service; 25,000
reach military age (19) annually
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
7.','1f1b2ea2943b5c431c6abbfe7daa74aa95e0af79ddf96c2c6539e80b36438e56','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10fb56e9602887c9658f119621a2bdced3fe75475d033a6555b7c857323fd466',1973,'DZ','Algeria','communications',9,'"950,000 sq. mi.; 3% cultivated, 16% pasture and meadows,
1% forested, 80% desert, waste, or urban
Land boundaries: 3,890 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 735 mi.
Railroads: 2,414 mi.; 1,660 mi. Standard gage, 663 mi. 3''5 9/16" gage, 91 mi.
meter gage; 188 mi. electrified; 120 mi. double track
Highways: 40,600 mi., of which 17,000 mi. are concrete or bituminous and the
remainder gravel or crushed stone
Parts: 9 major, 8 minor
Merchant marine: 17 ships (1,000 GRT or over) totaling 143,400 GRT, 167,700 DWT;
includes 2 passenger, 6 cargo, 1 tanker, 3 bulk, § specialized carrier
Pipelines: crude oi1, 2,250 mi.; refined products, 180 mi.; natural gas, 1,785 mi.
Civil air: 19 major transport aircraft
Airfields: 249 total, 199 usable; 56 with permanent-surface runways; 20 with
runways 8000-11 ,999 ft., 111 with runways 4,000-7,999 ft.; 3 seaplane
Stations
Telecommunications: adequate domestic and international facilities in the north,
primarily radio communications in the desert; 184,000 telephones; 1,150,000
radio receivers; 250,000 Ty receivers; 16 AM and 13 TY stations; 3 submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,762,000; 2,160,000 fit for military service;
average number reaching military age (19) annually 135,000
Supply: dependent on foreign sources; in the past on France and to a small
extent on a number of non-Communist countries and China; materiel (including
modern heavy weapons; surface-to-air, air-to-air, and naval missiles; aircraft,
and naval ships) from the U.S.S.R. now predominant
Military budget: for fiscal year ending 31 December 1973, $119 ,700,000;
approximately 5.1% of national budget
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
A
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ANDORRA ee ee
LAND: é cEnONce :
‘ 180 sq. mi.
Land boundaries: 65 mi.
Railroads: 2,818 mi.; 2,643 mi. standard gage and government owned, 1,615 mi.
double track, 698 mi. electrified; 175 mi. privately owned, electrified
narrow gage (3''3 3/8")
Highways: 57,700 mi.; 26,550 mi. bituminous, stone block, or concrete; 31,150
mi. crushed stone, gravel, earth
Injand waterways: 1,270 mi., of which 950 are in regular use by commercial
transport
Ports: 5 major, 1 minor
Merchant marine: 73 ships (1,000 GRT or over) totaling 1,051,700 GRT, 1,601,700
DWT; includes 43 cargo, 14 tanker, 14 bulk, 2 specialized carrier
Pipelines: refined products, 600 mi.; crude, 100 mi.; natural gas, 145 mi.
Civil air: 58 major transport aircraft, including 5 based in Libya
Airfields: 53 total, 39 usable; 21 with permanent-surface runways; 13 with
runways 8,000-11,999 ft., 6 with runways 4,000-7,999 ft.
Telecommunications: excellent domestic and international telephone and
telegraph facilities; 2,163,000 telephones; 3.83 million radio receivers;
2.3 million TV receivers; 7 AM, 11 FM, and 21 TV stations; 5 coaxial
Submarine cables; communications satellite station
DEFENSE FORCES:
Military manpower: males 15-49, 2,241,000; 1,780,000 fit for military service;
average number reaching military age (19) annually 74,000
Military budget: proposed for fiscal year ending 31 December 1972, $720.0 million;
about 7.3% of proposed central government budget
30
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
BELIZE (formerly British Honduras)
LAND:
8,870 sq. mi.; 38% agricultural (5% cultivated), 46%
exploitable forest, 16% urban, waste, water,
offshore islands or other ica, fs
Land boundaries: 320 mi. eee
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 240 mi. BRAZIL
Railroads: none
Highways: 1,350 mi.; 150 mi. paved, 600 mi. improved (gravel, earth), 600 mi.
unimproved
Inland waterways: 514 mi. river network used by shallow-draft craft
Ports: 1 major, 4 minor
Civil air: no major transport aircraft
Airfields: 51 total, 31 usable; 2 with permanent-surface runways; | with
runway 4,000-7,999 ft.; 1 seaplane station
Telecommunications: 3,200 telephones in automatic and manual network; over 62,000
radio receivers; 2 AM stations
DEFENSE FORCES:
Military manpower: males 15-49, 29,000; 17,000 fit for military service; 1,500
reach military age (18) annually
32
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: 9,010 route mi.; 8,810 mi. standard gage, 200 mi. meter or other narrow
gage, 1,810 mi. double track standard gage; 860 mi. overhead electrified (1972)
Highways: about 28,650 mi. classified highways; 8,000 mi. state highways including
950 mi. autobahn; 20,750 mi. district roads; additionally about 29,000 mi.
unclassified minor unpaved roads (1972)
Inland waterways: 1,562 mi. (1973)
Freight carried: rail -- 295.0 million short tons, 30.0 billion short ton/mi.
(1972); highway -- 544.9 million short tons, 8.9 billion short ton/mi. (1971);
waterway -- 21.2 million short tons, 2.0 billion short ton/mi. (1972)
Pipelines: crude oi], 420 mi; refined products, 150 mi., natural gas 250 mi.
eee vo (Rostock, Wismar, Stralsund, Sassnitz, Peenemunde), 12 minor
973
Merchant marine: 133 ships (1,000 GRT and over) totaling 1,026,200 GRT, 1,402,600
DWT; includes 1 passenger, 100 cargo, 9 tanker, 13 bulk, 10 specialized
carrier
Airfields: 155 total; 54 with permanent-surface runways; 50 with runways 8,000-
11,999 ft., 43 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 3,876,000; 3,140,000 fit for military service;
about 132,000 reach military age (18) annually
120
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
a a A a
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: 1,36] mi., 5''3" gage; government owned
Highways: 53,700 mi.; 46,950 mi. surfaced, 6,750 mi. earth
Inland waterways: approx. 650 mi.
Ports: 6 major, 38 minor
Merchant marine: 17 ships (1,000 GRT or over) totaling 139,000 GRT, 198,600
DWT; includes 2 passenger, 7 cargo, 1 tanker, 6 bulk, 1 specialized carrier
Civil air: 19 major transport aircraft, plus 1 withdrawn from service
Airfields: 32 total, 27 usable; 7 with permanent-surface runways; 1 with runway
&,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: small, modern system; all cities interconnected for telephone
and telegraph service; 337,000 telephones; 615,000 radiobroadcast receivers;
539,000 TV receivers; 6 AM, 9 FM, and 19 TV stations; 4 coaxial submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 699,000; 549,000 fit for military service;
about 29,000 reach military age (17) annually
Supply: formerly from the U.K. primarily, but since 1961 from other European
countries; one naval service fishing protection ship produced domestically
Military budget: for fiscal year ending 31 March 1973, $68.7 million; about
4.2% of the central government budget
160
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: 12,857 mi.; 9,907 mi. government owned; 9,805 mi. standard gage; 4,906
mi. electrified; 102 mi. narrow gage (3'' 1 1/8"); 2,950 mi. non-government
owned; 1,567 mi. standard gage; 794 mi. electrified; 1,383 mi. narrow gage;
323 electrified
Highways: 179,000 mi.; autostrade 3,000 mi., state highways 25,750 mi., provincial
highways 57,000 mi., communal highways 93,250 mi.; 159,000 mi. concrete,
bituminous, or stone block, 15,500 mi. gravel and crushed stone, 4,500 mi.
earth
Inland waterways: 1,538 mi. navigable routes; 708 mi. rivers, 529 mi. canals,
307 mi. are lake routes
Pipelines: crude 011, 1,100 mi.; refined products, 900 mi.; natural gas, 6,000 mi.
Ports: 16 major, 122 significant minor
Civil air: 130 major transport aircraft
164
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Airfields: 230 total, 151 usable; 81 with permanent-surface runways; 2 with
runways over 12,000 ft., 26 with runways 8,000-11,999 ft., 47 with runways
4,000-7 ,999 ft.; 11 seaplane stations
Telecommunications: well engineered, well constructed, and efficiently operated;
10.8 million telephones; 12.6 million radio and 10.85 million TV receivers;
86 AM, 550 FM, and 855 TV stations, each with numerous repeater stations;
9 coaxial submarine cables; 3 communication satellite ground stations
DEFENSE FORCES:
Military manpower: males 15-49, 13,587,000; 11,400,000 fit for military service;
413,000 reach military age (18) annually
Military budget: proposed for fiscal year ending 31 December 1973, $3.9 billion;
about 12% of central government budget
165
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
IVORY COAST
D:
125,000 sq. mi.; 40% forest and woodland, 8% cultivated,
52% grazing, fallow, and waste, 200 mi. of lagoons
and connecting canals along eastern coast
Land boundaries: 2,005 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 320 mi.
Railroads: 408 mi. of the 728 mi. Abidjan to Quagadougou, Upper Volta Tine, all
single track meter gage; only diesel locomotives in use
Highways: 24,600 mi.; 800 mi. bituminous and bituminous-surface treatment;
11,200 mi. gravel, crushed stone, laterite, and improved earth; 12,600
mi. unimproved earth roads
Inland waterways: 460 mi. navigable rivers and numerous coastal lagoons
Ports: 2 major, 3 minor
Civil air: 15 major transport aircraft (includes 2 aircraft registered in Gabon) ,
Airfields: 50 total, 44 usable; 3 with permanent-surface runways; 2 with runways
8,000-11,999 feet; 8 with runways 4,000-7,999 feet; 1 seaplane station
Telecommunications: system only slightly above African average; consists of
microwave relays, open-wire lines and radio relay links, which provide
incomplete coverage of country; Abidjan is only center; 24,300 telephones;
80,000 radio and 70,000 TV receivers; 3 AM, 2 FM, and 4 TV stations; 2 .
submarine cables; satellite earth station
DEFENSE FORCES:
Military manpower: males 15-49, 1,113,000; 535,000 fit for military service;
60,000 males reach military age (18) annually
Supply: principally dependent on France; has purchased transport aircraft from
Railroads: 1,956 mi., standard gage; 970 mi. double track; 1,022 mi. electrified
Highways: 46,000 mi.; 26,000 mi. paved, 4,000 mi. crushed stone and gravel,
16,000 mi. earth
Inland waterways: 3,940 mi.; less than 962 mi. is natural river; more than 1,400
mi. navigable by craft of 1,000-ton capacity; 1,011 mi. will take 1,500-ton
vessels
Pipelines: crude oi1, 260 mi.; refined products, 600 mi.; natural gas, 2,600 mi.
Ports: 8 major, 5 minor
Merchant marine: 350 ships (1,000 GRT or over) totaling 3,179,400 GRT, 4,460,000
DWT; includes 2 passenger, 269 cargo, 55 tanker, 18 bulk, 6 specialized
carrier
Civil air: 90 major transport aircraft
Airfields: 28 total, 26 usable; 16 with permanent-surface runways; 12 with
runways 8,000-11,999 ft., 3 with runways 4,000-7,999 ft.
Teleconmunications: highly developed, excellently maintained, and well integrated;
extensive system of multiconductor cables, supplemented by radio relay links
and submarine cables; 3.75 million telephones; 4.81 million radiobroadcast
and 3.9 million TV receivers; 5 AM, 12 FM, and 10 TV stations; 11 coaxial bf
submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,370,000; 3,020,000 fit for military service;
average number reaching military age (20) annually 116,000 :
Military budget: proposed for fiscal year ending 31 December 1973, $1,684 million;
about 12% of central government budget
236
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
NETHERLANDS ANTILLES
LAND:
394 sq. mi.; 5% arable, 95% waste, urban, or other es
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 226 mi.
Railroads: 10,667 mi.; 8,427 mi.; (5''6" gage), 2,240 mi. other gages
(4''8 1/2" to 1''11 5/8"), 1,318 mi., double track; 2,359 mi. electrified
Highways: 83,080 mi.; national -- 24,800 mi., bituminous, 22,940 mi. crushed
+ stone; provincial -- 32,860 mi., 80% crushed stone, 20% paved; 2,480 mi. other
Inland waterways: about 650 mi.; of minor importance as transport arteries and
contribute little to economy
Pipelines: crude 011, 230 mi.; refined products, 515 mi.; natural gas, 90 mi.
Ports: 23 major, 20 minor
ny Civil air: 166 major transport aircraft
Airfields (including Balearic and Canary Islands): 121 total, 82 usable; 46
with permanent-surface runways; 4 with runways over 12,000 ft., 18 with
runways 8,000-11,999 ft., 34 with runways 4,000-7,999 ft.; 5 seaplane
stations
Telecommunications: modern, well engineered, well maintained; 5.38 million
telephones; 7.7 million radio and 4.75 million television receivers; 190
AM, 221 FM, and 645 TV stations; 5 coaxial submarine cables; 3 communication
satellite ground stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,507,000; 6,535,000 fit for military service;
275,000 reach military age (20) annually
Military budget: for biennium ending 31 December 1972, $1,695 million; 23% of
central government budget
315
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
SPANISH SAHARA
LAND:
103,000 sq. mi., nearly all desert
Land boundaries: 1,296 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 690 mi.
Railroads: none
Highways: 3,790 mi.; 305 bituminous treated, 3,485 mi. unimproved earth roads
and tracks
Ports: 2 major, 2 minor
317
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Civil air: no major transport aircraft
Airfields: 25 total, 17 usable; 3 with permanent-surface runways; 5 with
runways 4,000-7,999 ft.
Telecommunications: telephone poor, telegraph poor to fair; 550 telephones;
1,500 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 15,000; 7,000-8,000 fit for military service
318
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
SRI LANKA (formerly Ceylon)
D:
25,300 sq. mi.; 25% cultivated; 44% forested; 31% waste,
urban, and other (1962)
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi. plus pearling in the Gulf of
Mannar )
Coastline: 835 mi.
Railroads: 938 mi.; 851 mi. 5''6" gage, 87 mi. 2''6" gage; 63 mi. double track;
no electrification; government owned
Highways: 25,580 mi.; 11,700 mi. paved (mostly bituminous treated), 11,500 mi.
crushed stone or gravel, 530 mi. improved earth, 1,850 mi. unimproved earth;
in addition several thousand mi. of tracks, mostly unmotorable
Inland waterways: 270 mi.; navigable by shallow-draft craft
Ports: 3 major, 9 minor
Merchant marine: 5 cargo ships (1000 GRT or over) totaling 33,200 GRT, 45,000 DWT
Civil air: 5 major transport (including 1 leased)
Airfields: 17 total, 10 usable; 10 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: an inadequate telephone and a less extensive but more
efficient telegraph system serves most areas, with greatest concentration
around Colombo and Kandy; all areas are served by radio and/or wire broadcast;
excellent international service; 64,338 (est.) telephones; 505,000 radio sets,
no TV sets; 1 AM (plus 4 repeater stations), no FM, and no TV stations;
submarine cables extend to India, Malaysia, Seychelle Islands, and Aden
DEFENSE FORCES:
Military manpower: males 15-49, 3,144,000; 2,355,000 fit for military service;
143,000 reach military age (18) annually
320
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: 3,040 mi.; 2,195 mi. 4''8 1/2" gage, 780 mi. double track; 845 mi.
narrow gage (810 mi. at 3''3 3/8", 35 mi. at 2''7 1/2"); 3,040 mi. electrified
Highways: 37,158 mi., all paved
Pipelines: crude o71, 195 mi.
Inland waterways: 41 mi.; Rhine River-Basel to Rheinfelden, Schaffhausen to
Constanz; in addition, there are 12 navigable lakes ranging in size from
Lake Geneva to Hallwilersee
Ports: 1 major, 2 minor
Merchant marine: 27 ships (1,000 GRT or over) totaling 200,700 GRT, 288,000
DUT; includes 25 cargo, 2 bulk; fleet is registered in Basel, operates
mainly out of Genoa, Hamburg, and Rotterdam
Civil air: 65 major transport aircraft
Airfields: 91 total, 75 usable; 37 with permanent-surface runways; 2 with
runways over 12,000 ft., 8 with runways 8,000-11,999 ft., 11 with runways
4,000-7 ,999 ft.
Telecommunications: excellent domestic, international, and broadcast services;
3.27 million telephones; communications satellite station under construction;
1.94 million radio and 1.7 million TV receivers; 5 AM, 81 FM, and 247 TV
stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,524,000; 1,315,000 fit for military service;
45,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December 1973, $770 million; 22%
of central government budget
330
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
SYRIA
LAND: TURKEY
78,700 sq. mi.; 47% arable, 29% grazing, 2% forest,
21% desert
Land boundaries: 1,365 (1967) (excluding occupied area
] » 340 mi .) SAUDI
WATER: ARABIA
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 120 mi.
Railroads: 649 mi.; 459 mi. standard gage, 190 mi. narrow gage (3''5 3/8")
Highways: 7,150 mi.; 4,300 mi. paved, 810 mi. gravel or crushed stone, 1,540 mi.
improved earth, 497 mi. unimproved earth
Inland waterways: 420 mi.; of little importance
Pipelines: crude oi1, 1,010 mi.; refined products, 320 mi.; natural gas 140 mi.
Ports: 3 major, 3 minor
Civil air: 7 major transport aircraft
Airfields: 89 total, 28 usable; 22 with permanent-surface runways; 1 with runway
over 12,000 ft., 18 with runways 8,000-11,999 ft., 4 with runways 4 ,000-
7,999 Ft.
Telecommunications: fair international radiocommunication service; fair domestic
telecommunication service; 120,000 telephones; 1,000,000 radio and 135,000 TV
receivers; 5 TV and 5 AM stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,589,000; 860,000 fit for military service;
about 73,000 reach military age (19) annually
332
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
TANZANIA
LAND:
362,800 sq. mi. (including islands of Zanzibar and Pemba,
1,020 sq. mi.); 6% inland water, 15% cultivated, 31%
grassland, 48% bush forest, woodland, on mainland; 60%
arable, of which 40% cultivated on islands of Zanzibar
and Pemba
Land boundaries: 2,413 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 885 (this includes Mafia Island, 70; Pemba
Island, 110; and Zanzibar, 132)
Railroads: 1,950 mi.; 312 mi. 3''6" gage; 1,638 mi., meter gage, 4 mi. double track;
Tanzania portion of Tan-Zam Railroad currently under construction
Highways: total 30,000 mi., including 390 mi. on Zanzibar Island and 277 mi. on
Pemba and Mafia Islands; about 1,400 mi. bituminous treated, (370 mi. on
Zanzibar and Pemba); 28,600 mi. gravel, crushed stone, or unimproved earth
Pipelines: refined products 610 mi.
Inland waterways: 730 mi. of navigable streams; several thousand mi. navigable
on Lakes Tanganyika, Victoria, and Nyasa
Ports: 4 major, 8 minor
Merchant marine: 4 cargo ships (1,000 GRT or over) totaling 25,400 GRT, 34,200
DWT
Civil air: 9 major transport aircraft
Airfields: 111 total, 98 usable; 8 with permanent-surface runways; 1 with runway
over 12,000 ft.; 1 with runway 8,000 to 11,999 ft., 42 with runways 4,000-
7,999 ft.; 4 seaplane stations
Telecommunications: telephone and telegraph good in main centers, only fair
outside main towns; 40,150 telephones; 225,000 radio receivers; 4 AM, no FM
or TV stations; 4 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,303,000; 1,835,000 fit for military service
334
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
THA ILAND
LAND:
198,000 sq. mi.; 24% in farms, 56% forested, 20% other
Land boundaries: 3,025 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,000 mi.
Railroads: 2,382 mi. meter gage; 60 mi. double track
Highways: 12,590 mi.; 5,440 mi. paved, 4,820 mi. crushed stone or gravel, 2,330 y
earth and laterite
Intand waterways: 2,485 mi. principal waterways; 2,300 mi. with navigable depths
of 3 ft. or more throughout the year; numerous minor waterways navigable by
shallow-draft native craft
Ports: 2 major, 16 minor
Merchant marine: 26 ships (1,000 GRT or over) totaling 158,300 GRT, 255,400 DWT;
includes 15 cargo, 10 tanker, 1 specialized carrier
Civil air: 26 major transport aircraft
Airfields: 230 total, 178 usable; 45 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 23 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: service to general public improved, but inadequate;
bulk of service to government activities provided by radiocommunication
stations and radio-relay network; satellite ground station; 202,023 telephones;
3 million radios; 653,487 televisions; estimated 50 AM, 5 FM, and 6 TV
stations in two government-controlled networks; U.S. military submarine
cable to South Vietnam
DEFENSE FORCES:
Military budget: for fiscal year ending 30 September 1973, $276.7 million; 18.2% of
central government budget ''
336
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','abe7bce2c674906f4365f9aa85bba445805499dc1929d159ef80e147b52015b4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4ad7b385083ab379232d5f4e5727ce554ff026e77326dc9bf00d5dde02cbd29',1973,'AO','Angola','communications',17,'Railroads: 1,918 mi.; 1,724 mi. 3''6" gage, 194 mi. 1''11 5/8" gage
Highways: 45,000 mi.; 3,300 mi. bituminous-surface treatment, 1,000 mi. crushed
stone or gravel, 25,000 mi. earth
Inland waterways: 2,000 mi. navigable
Ports: 3 major
Pipelines: crude oi1, 111 mi.
Civil air: 15 major transport aircraft
Airfields: 457 total, 385 usable; 21 with permanent-surface runways; 1 with
runway over 12,000 ft., 6 with runways 8,000-11,999 ft., 55 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: simple network of Tow-capacity open-wire and radio-relay
facilities; 30,450 telephones; 110,000 radio receivers; 21 AM, 7 FM, and no
TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,465,000, fit for military service, 730,000; .
average number reaching military age (20) annually about 60,000
Defense is responsibility of Portugal
Supply: dependent on Portugal
Military budget: for fiscal year ending 31 December 1972 $82.7 million; about
18.2% of total budget
10
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
a
A
pproved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ANTIGUA
LAND:
¥ 108 sq. mi.3 54% arable, 5% pasture, 14% forested,
9% unused but potentially productive, 18% wasteland
and built on
WATER:
Limits of territorial waters (claimed): 3n. mi.
Coastline: 95 mi.','effe56eb7a7bfd38d7497fd75db69e96ea3736cb5c76c7384c2e59af77788c0a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13ccdbff167b36ef9ea2c38a2cd778d371dcbfbdf9473e26130506d30c257259',1973,'BR','Brazil','communications',22,'Railroads: 49 mi. narrow gage (2''6"), employed almost exclusively for hand] ing
cane
Highways: 235 mi.; 150 mi. main, 85 mt. secondary
Ports: 1 major, 1 minor .
Civil air: 1] major transport aircraft
Airfields: 3 total, 1 usable; ] with asphalt runway 9,000 ft.; ] Seaplane
station
Telecommunications: automatic telephone System; 2,800 telephones; tropospheric
Scatter links with Tortola and St. Lucia; 20,0090 radio receivers, 8,500 Ty .
sets; 2 AM, 1 FM, and 1 TV stations; 2 Coaxial submarine cables
12
00010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A0006
Tc
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: 2,310 mi., single track; 2,290 mi., meter gage, 20 mi., 2''6" gage;
all government owned except 60 mi. of meter-gage track; 5.6 mi. of meter-
gage track electrified
Highways: 15,900 mi.; 600 mi. paved, 7,200 mi. gravel, 1,600 mi. improved
earth, 6,500 mi. unimproved earth
Inland waterways: officially estimated to be 6,250 mi. of commercially
navigable waterways
Pipelines: crude oi1, 1,040 mi.; refined products and crude 930 mi.; natural gas
350 mi.
Ports: none (Bolivian cargo moved through Arica and Antofagasta, Chile, and
Matarani, Peru)
Civil air: 32 major transport aircraft
Airfields: 513 total, 435 usable; 3 with permanent-surface runways; 1 with
runway over 12,000 ft., 3 with runways 8,000-11,999 ft., 87 with runways
4,000-7,999 ft.
Telecommunications: poorest telecom facilities on continent; 44,200 telephones; est.
750,000 radio and 12,000 TV receivers; 1 TV, 80 AM, and 14 FM stations
DEFENSE FORCES:
Military manpower: males 15-49 1,178,000; 745,000 fit for military service;
average number reaching military age (19) annually about 58,000
Military budget: for fiscal year ending 31 December 1973, $22 million;
about 15% of central government budget
38
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ne
A
pproved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ND:
3,290,000 sq. mi.; 3% cultivated, 13% pastures, 23%
built-on area, waste, and other, 61% forested
Land boundaries: 8,125 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 4,655 mi.
Railroads: 19,935 mi.; 17,586 mi. 3''3 3/8" gage, 2,085 mi. 5''3" gage, 121 mi.
4''8 1/2" gage, 143 mi. narrow gages; 1,621 mi. electrified
Highways: 591,000 mi.; 31,000 mi. paved, 560,000 mi. gravel or earth
Inland waterways: 31,000 mi. navigable
Ports: 6 major, 25 significant minor
Pipelines: crude oi1, 770 mi.; refined products, 290 mi.; natural gas, 24 mi.
Merchant marine: 219 ships (1,000 GRT or over) totaling 1,688,700 GRT, 2,466,300
DWT; includes 2 passenger, 149 cargo, 41 tanker, 20 bulk, 7 specialized
carrier; includes 2 naval tankers sometimes used commercially
Civil air: 110 major transport aircraft
Airfields: 3,256 total, 2,814 usable; 120 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 334 with runways 4,000-7,999 ft.; 13 seaplane
stations
Telecommunications: extensive telecom facility expansion programs; radio relay
widely used; communications satellite ground station; 2.3 million telephones;
est. 11 million radio and 7 million TV receivers; 900 AM, 150-FM, and 156
TV stations; 6 submarine cables, including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 23,080,000; 15,065,000 fit for military service;
1,145,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1972, $1,115 million; 18.7%
of federal budget
42
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
BRUNEI
LAND:
2,230 sq. mi.3 3% cultivated; 22% industry, waste,
urban or other; 75% forested
Land boundaries: 237 mi.
WATER:
Limits of territorial waters (claimed): 3n. mi.
Coastline: 100 mi.
Railroads: 6 mi. narrow gage (2'')
Highways: 750 mi.; 334 mi. paved (bituminous treated), 250 mi. gravel or stone,
266 mi. unimproved
Inland waterways: 130 mi.; navigable by shallow-draft craft
Ports: 2 minor (Bandar Seri Begawan, formerly Brunei, and Kuala Belait)
Pipelines: crude oi1, 84 mi.; refined products, 35 mi.; natural gas, 35 mi.;
crude oil and natural gas, 150 mi. under construction
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface runway; 3 with runways
4,000-7,999 ft.
Telecommunications: service throughout country is adequate for present needs;
international service good to adjacent Sabah and Sarawak; radiobroadcast
coverage good; 5,947 telephones; 16,000 radio sets; Radio Brunei
broadcasts from 3 stations and uses 4 mediumwave and 1 shortwave
transmitter
DEFENSE FORCES:
Military manpower: males 15-49, 38,000; 20,000 fit for military service; about
1,000 reach military age (18) annually
44
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
D:
286,000 sq. mi; 2% cultivated, 7% other arable, 15%
permanent pasture, grazing, 29% forest, 47% barren
mountains, deserts, and cities
Land boundaries: 3,930 mi.
WATER: '' : : ARGENTINA :
Limits of territorial waters (claimed): 200 n. mi. ;
Coastline: 4,000 mi.
Railroads: 5,51] mi.; 2,086 mi. 5''6" gage, 154 mi. 4''8 1/2" gage, 2,644 mi.
3''3 3/8" gage, 69 mi. 2''6" gage, 22 mi. 1''ll 5/8" gage, 536 mi. specific gage
not given; 199 mi. double track; 711 mi. electrified
Highways: 45,300 mi.; 4,900 mi. paved, 19,900 mi. gravel, 20,500 mi. improved
and unimproved earth
Inland waterways: 451 mi.
Pipelines: crude oi], 470 mi.; refined products, 490 mi.; natural gas, 200 mi.
Ports: 10 major, 20 minor
Civil air: 48 major transport aircraft
Airfields: 458 total, 349 usable; 43 with permanent-surface runways; 2 with run-
ways 8,000-11,999 ft., 56 with runways 4,000-7,999 ft.; 7 seaplane stations
Telecommunications: extensive radio relay network; telephone network modern,
405,000 instruments; communications satellite ground station; est. 2.5 million
radio and 600,000 TV receivers; 145 AM, 30 FM, and 29 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,416,000; 1,815,000 fit for military service;
average number reaching military age (19) annually about 90,000
Military budget: for fiscal year ending 31 December 1972, US$226.5 ''
million; about 10% of central government budget
62
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
CHINA, PEOPLE''S REPUBLIC OF
LAND:
3.7 million sq. mi.; 11% cultivated, sown area extended by
multicropping, 78% desert, waste, or urban (32% of
this area consists largely of denuded wasteland,
plains, rolling hills, and basins from which about 3%
could be reclaimed), 8% forested; 2%-3% inland water
Land boundaries: 15,000 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. AGStRALIA
Coastline: 9,000 mi. ar
Railroads: about 25,000 mi., of which 370 mi. 3''3 3/8" gage, 20 mi. 3''6" gage,
24,600 mi. 4''8 1/2" gage; nearly 4,000 mi. double track; 440 mi. electrified;
government owned
Highways: 425,000 mi. (est.); about 5,000 mi. paved and treated, 120,000 mi. gravel
and crushed stone, 100,000 mi. improved earth, and 200,000 mi. unimproved
earth, including tracks
Inland waterways: 105,000 mi.; 25,000 mi. navigable by modern motorized craft
Ports: 9 major, 180 minor
Airfields: 363 total; 232 with permanent-surface runways; 6 with runways over
12,000 ft., 68 with runways 8,000-11,999 ft., 212 with runways 4,000-7,999
ft.; 1 seaplane station
64
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
PEOPLE''S REP.
CHINA, REPUBLIC OF OF CHINA
LAND:
14,000 sq. mi. (Taiwan and Pescadores); 24% cultivated,
6% pasture, 55% forested, 15% other (urban, industrial,
denuded, water area)
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing
12 n. mi. in practice)
Coastline: 615 mi. Taiwan, 285 mi. offshore islands
vk > > BHILIPPINES:,
Railroads: 2,823 mi., all narrow gage; 130 mi. double track; 623 mi. government
owned, 2,200 mi. industrial
Highways: 10,300 mi. plus 300 mi. on Penghu and offshore islands; 3,300 mi. paved, ’
5,000 mi. gravel and crushed stone, 2,000 mi. earth
Ports: 7 major, 9 minor
Airfields: 61 total, 37 usable; 24 with permanent-surface runways; 2 with runways
over 12,000 ft., 10 with runways 8,000-11,999 ft., 13 with runways 4,000-7 ,999
ft.; 2 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 3,854,000; 2,890,000 fit for military service;
average number currently reaching military age (19) annually 180,000
66
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ee
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: none
Highways: 460 mi.; 175 mi. paved, 190 mi. gravel, crushed stone, or stabilized
3 earth surface, 95 mi. unimproved
Ports: 2 minor
Civil air: no major transport aircraft
85
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002
COMMUNICATIONS (cont''d):
Airfields: 1 with asphalt runway 4,830 ft.
Teleconmuni cations: 2,200 in fully automatic telephone net
link to St. Lucia;
work; VHF interisland
15,000 radio receivers; Tess than 10
AM station
Oo TV receivers; 1]
86
-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002
CO ee
a enna
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: 120 mi. 2'' 6" gage, single-track, privately owned industrial line; 5
mi. dual-gage 2’ 6"-3'' 6"; government line dismantled
Highways: 2,000 mi.; 350 mi. paved, 600 mi. otherwise improved, 1,050 mi.
unimproved
Inland waterways: negligible; about 60 mi. navigable
Ports: 2 major, 12 minor
Civil air: 5 major transport aircraft; 3 owned by the air force, 2 privately owned
Airfields: 31 total, 16 usable; 3 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: all domestic facilities inadequate, international facilities
only slightly better; telephone expansion program underway; only 4,600
telephones, est. 282,000 radio and 12,000 TV receivers, 25 AM, 3 FM, and 1
TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,300,000; 665,000 fit for military service;
about 53,000 reach military age (18) annually
Military budget: for fiscal year ending 30 September 1973, $6.4 million; about
20% of operational budget
142
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
the
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: 357 mi.; 202 mi. of 3''6" gage, 155 mi. of 3''0" gage
Highways: 3,500 mi.; 750 mi. bituminous surfaced, 1,850 mi. gravel surfaced or
improved earth, 900 unimproved earth
Inland waterways: 750 mi. navigable by small craft
Ports: 3 major, 9 minor
Merchant marine: 8 cargo ships (1,000 GRT or over) totaling 40,400 GRT, 37,500
DWT; all foreign owned and operated
Civil air: 24 major transport aircraft
Airfields: 228 total, 139 usable; 4 with permanent-surface runways; 10 with run-
ways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: improved, but still inadequate; connection into Central
American microwave net; 15,200 telephones; 300,000 radio and 25,000
TV receivers; 102 AM, 10 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 699,000; 410,000 fit for military service;
about 30,000 reach military age (18) annually
Supply: traditional dependence on U.S. has for the time being shifted to
Western Europe
144
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: none
Highways: 700 mi.; 350 mi. paved, 220 mi. otherwise improved, 130 mi. unimproved
Ports: 3 major, 6 minor
Merchant marine: 38 ships (1,000 GRT or over) totaling 1,396,200 GRT, 2,362,500
DWT; includes 4 passenger, 48 cargo, 15 tanker, 9 bulk, 7 specialized
carrier
Civil air: 6 major transport aircraft
Airfields: 7 total, all usable; 6 with permanent~surface runways; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: generally adequate telecom facilities; extensive inter-
island VHF links; 33,800 telephones, 125,000 radio and 33,000 TV receivers,
11 AM and 3 TV stations, 4 telegraph submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 60,000; 31,000 fit for military service;
about 2,000 reach military age (20) annually
Defense is responsibility of the Netherlands
238
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: 345 mi.; 48 mi. 5''O" gage, 107 mi. 3''0" gage; 190 mi. plantation
feeder lines
Highways: 4,200 mi.; 1,100 mi. paved, 600 mi. gravel or crushed stone, 300 mi.
improved earth, 2,200 mi. unimproved earth; Panama Canal Zone 145 mi.;
140 mi. paved; 5 mi. gravel
Inland waterways: 500 mi. navigable by shallow draft vessels; 50-mile
Panama Canal
Pipelines: refined products, 60 mi.
Ports: 2 major, 10 minor
Merchant marine: 1,000 ships (1,000 GRT or over) totaling 8,959,600 GRT, 14,356,400
DWT; includes 16 passenger, 618 cargo, 200 tanker, 108 bulk, 58 specialized
carrier; all foreign owned and operated
Civil air: 28 major transport aircraft
Airfields: 238 total, 119 usable; 16 with permanent-surface runways; 3 with
runways 8,000-11,999 ft.; 11 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: domestic and international telecom facilities well developed,
including nearly nationwide radio-relay system; connection into
Central American microwave net; communications satellite ground station;
107,100 telephones; 550,000 radio and 200,000 TV receivers; 80 AM, 22 FM,
and 13 TV stations; 1 coaxial submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 351,000; 245,000 fit for military service;
no conscription
256
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
"157,000 sq. mi.; 2% under crops, 24% meadow and pasture,
52% forested, 22% urban, waste, and other
Land boundaries: 2,140 mi.
Railroads: 652 mi.; 273 mi. standard gage, 85 mi. 3''3 3/8'''' gage, 294 mi. various
narrow gage (privately owned)
Highways: 9,900 mi.; 400 mi. bituminous treated, 3,100 mi. otherwise improved,
6,400 mi unimproved earth
Inland waterways: 1,970 mi.
Ports: 7 major, 7 minor (all river)
Merchant marine: 14 ships (1,000 GRT or over) totaling 15,700 GRT, 14,900 DWT;
includes 2 passenger, 9 cargo, 2 tanker, 1 specialized carrier; domestic
ships are operated mostly in river traffic; most international waterborne
trade is carried by foreign flag ships
Civil air: 7 major transport aircraft
Airfields: 1,031 total, 855 usable; 1 with permanent-surface runway; 2 with runways
8,000~-11,999 ft., 29 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: local telecom facilities in Asuncion good, intercity microwave
net under construction; 26,600 telephones; est. 720,000 radio and 57,000 TV
receivers; 23 AM, 5 FM, and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 579,000; 395,000 fit for military service;
average number currently reaching military age (17) annually, 25,000
Military budget: for fiscal year ending 31 December 1973, $18.6 million; about
15% of proposed central government budget
260
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
496,000 sq. mi. (other estimates range as low as 482 ,000
sq. mi.); 2% cropland, 14% meadows and pastures, 55%
forested, 29% urban, waste, other
Land boundaries: 3,810 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,500 mi.
Railroads: approx. 2,144 mi.; 1,800 mi. 4'' 8 1/2" gage; 130 mi. gage less than
3''0"; 214 mi. 3'' 0" gage; 9 mi. double track
Highways: 31,100 mi.; 3,000 mi. paved, 5,400 mi. gravel or crushed stone, 8,500
mi. improved earth, 14,200 mi. unimproved earth
Inland waterways: 5,400 mi. of navigable tributaries of Amazon River system and
130 mi. Lake Titicaca
Pipelines: crude 071, 200 mi.; natural gas and natural gas liquids, 40 mi.
Ports: 7 major, 20 minor
Merchant marine: 40 ships (1,000 GRT or over) totaling 313,400 GRT, 444,200 DWT;
includes 28 cargo, 9 tanker, 3 bulk; (includes 5 naval tankers sometimes used
commercially)
Civil air: 33 major transport aircraft
Airfields: 337 total, 292 usable; 19 with permanent-surface runways; 2 with
runway over 12,000 ft., 19 with runways 8,000-11,999 ft., 47 with runways
4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fairly adequate for most requirements; new radio relay system
under construction; communications satellite ground station; 250,000 telephones;
est. 1.85 million radio and 460,000 TV receivers; 210 AM, 7 FM, and 30 TV
stations
DEFENSE FORCES:
Military manpower: males 15-49, 3,200,000; 2,165,000 fit for military service;
average number currently reaching military age (20) annually, 140,000
Military budget: a biennial budget for 1 January 1973 through 31 December 1974,
$520 million; about 14% of central government biennial budget
262
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
PEOPLE''S REP.
PHILIPPINES OF CHINA
LAND:
® 116,000 sq. mi.; 53% forested, 30% arable land, 5%
permanent pasture, 12% other
WATER:
Limits of territorial waters (claimed): under an archipelago
a theory, waters within straight lines joining appropriate
points of outermost islands are considered internal
waters; waters between these baselines and the limits
described in the Treaty of Paris, December 10, 1898,
the U.S.-Spain Treaty of November 7, 1900, and the
U.S.-U.K. Treaty of January 2, 1930 are considered
to be the territorial sea
Coastline: about 14,000 mi.
PRIIPPINES
Railroads: 2,177 mi.; 2 common-carrier systems (3''6" gage) totaling about 727
mi.; 19 industrial systems with 4 different gages totaling 1,450 mi.; 34%
government owned
Highways: 45,690 mi.; 8,886 mi. paved; 23,770 mi. gravel, crushed stone, or
stabilized soil surface; 13,034 mi. improved earth
Inland waterways: 2,000 mi.; limited to shallow-draft (less than 5 ft.) vessels
Pipelines: refined products, 157 mi.
Ports: 11 major, 100 minor
Merchant marine: 172 ships (1,000 GRT or over) totaling 839,800 GRT, 1,200,800
DWT; includes 9 passenger, 121 cargo, 30 tanker, 7 bulk, 5 specialized
carrier (includes 1 naval tanker sometimes used commercially)
Civil air: 87 major transport aircraft
Airfields: 40] total, 290 usable; 44 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 25 with runways 4,000-7,999 ft.; 8 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,911,000; 5,820,000 fit for military service;
about 375,000 reach military age (20) annually
Military budget: for fiscal year ending 30 June 1973, $164.2 million; about 21.6%
of total budget
264
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: more than 450 mi. plantation lines; 6 gages from 1''8" to 3''3 3/8"
with latter predominating
Highways: 4,800 mi.; 3,900 mi. paved, 260 mi. gravel, 640 mi. improved and
unimproved earth
Inland waterways: negligible
Pipelines: refined products, 90 mi.
Ports: 3 major, 7 minor
Civil air: major transport aircraft are included in U.S. registered total
Airfields: 32 total, 28 usable; 18 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 9 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: highly developed telecom system of open-wire and radio relay
Tinks; communications satellite ground station; 380,000 telephones; over 1.7
million radio and 600,000 TV receivers; 517 AM, 18 FM, and 13 TV stations;
2 coaxial submarine cables
DEFENSE FORCES:
Defense is responsibility of U.S.
276
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: 36 mi., narrowgage (2''6") on St. Kitts for sugar cane
Highways: 180 mi.; 60 mi. paved, 90 mi. otherwise improved, 30 mi. unimproved
earth
Ports: 3 minor (1 on each island)
Civil air: no major transport aircraft
Airfields: 2 total, 2 usable; 1 with asphalt runway 5,700 ft.
Telecomnunications: good interisland VHF radio connections and international
link via Antigua; about 1,650 telephones; 1,500 radio receivers; 3 AM
and 5 TV stations a
288
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ST. LUCIA
LAND:
238 sq. mi.; 34% arable, 5% pasture, 21% forest, 22%
unused but potentially productive, 18% wasteland
and built-on
VENEZUELA
WATER :
Limits of territorial waters (claimed): 3 n. mi. COLOMBIA
Coastline: 98 mi.
Railroads: none
Highways: 415 mi.; 175 mi. paved; 240 mi. otherwise improved
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
Airfields: 2 airfields with permanent surface runways; one with a 9,000 foot
runway; one with a 5,700 foot runway; 2 seaplane stations
Telecommunications: fully automatic telephone system with 3,600 telephones; direct
radio link with Martinique; interisland tropospheric links to Barbados and
Antigua; 20,000 radio and 50,000 TV receivers; 2 AM, and 1 TV station
290
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ST. VINCENT
LAND:
fe 150 sq. mi. (including northern Grenadines); 50% arable,
3% pasture, 44% forest, 3% wasteland and built-on
WATER : VENEZUELA
Limits of territorial waters (claimed): 3 n. mi. ;
~~ Coastline: 52 mi. COLOMBIA
PEOPLE: BRAZIL
Population: 92,000, average annual growth rate 1.1%
(4/60-4/70)
Ethnic divisions: mainly of African Negro descent; remainder
mixed with some white and East Indian and Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60% unemployed
Organized labor: 10% of labor force
- Railroads: none
Highways: 550 mi.; 170 mi. paved; 180 mi. otherwise improved; 200 mi. unimproved
earth
Ports: 1 minor
291
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Civil air: no major transport aircraft
Airfields: 3 total; 2 usable, 17 with asphalt runway 4,800 ft.
Telecommunications: islandwide fully automatic telephone system with 3,300
instruments; VHF interisland links to Barbados and the Grenadines; no data s
on radio and 400 TV receivers; 2 AM stations
292
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: none
Highways: 4,200 mi.; 2,500 mi. paved, 1,700 mi. gravel or otherwise improved
Pipelines: crude 011, 270 mi.; refined products, 12 mi.; natural gas, 130 mi.
Ports: 3 major, 6 minor
Civil air: 8 major transport aircraft
Airfields: 12 total, 6 usable; 3 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international service via tropospheric scatter
links to Barbados and Guyana; good local service; satellite ground
station; 63,000 telephones; est. 250,000 radio and 70,000 TV receivers;
2 AM, 2 FM, and 3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 242,000; 170,000 fit for military service
Supply: mostly from U.K.
Military budget: proposed for fiscal year ending 31 December 1969, $2,500,000;
about 1.5% of central government budget
342
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','a72334bb36882f3bed11054d3063d58b00af2578c1c89071eda531b8127f65e0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c73e7286240018840fe645d1ee0234cc574ea1812292f99399d76df8a5ea168',1973,'AR','Argentina','communications',23,'LAND:
1,070,000 sq. mi.; 57% agricul tural (11% crops, improved
pasture and fallow, 46% natural grazing land), 25%
forested, 18% mountain, urban, or waste (1972 est.)
Land boundaries: 5,850 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 3,100 mi.
Railroads: 25,000 mi.; 2,000 mi. standard gage (4''8 1/2"), 13,750 mi. broad
gage (5''6") 8,750 mi. meter gage (3''3 3/8"), 500 mi. 2''5 1/2" gage;
about 1,035 mi. double and multiple track; 76 mi. electrified
Highways: 125,000 mi., of which 21,000 mi. paved, 17,000 mi. gravel, 41,000
mi. improved earth, and 46,000 mi. unimproved earth
Inland waterways: 6,800 navigable mi.
Ports: 7 major, 21 minor
Merchant marine: 173 ships (1,000 GRT or over) totaling 1,229,700 GRT, 1,675,600
DWT; includes 5 passenger, 92 cargo, 58 tanker, 10 bulk, 8 specialized
carrier; includes 2 naval tankers and 1 naval combination cargo-transport
ship sometimes used commercially.
Pipelines: crude 011, 1,960 mi.; refined products, 1,370 mi.; natural
gas, 4,060 mi.
Civil air: 51 major transport aircraft
Airfields: 2,690 total, 1,999 usable; 71 with permanent-surface runways;
1 with runway over 12,000 ft., 21 with runways 8,000-11,999 ft., 262 with
runways 4,000~7,999 ft.; 10 seaplane stations
14
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
——
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Telecommunications: foremost in telecom facilities in South America; improving
telephone network has 1.85 million sets, radio relay widely used, 2
communications satellite ground stations; estimated 6.5 million radio receivers
and 3.5 million TV sets; 120 AM, 6 FM, and 50 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 6,228,000; 4,610,000 fit for military service;
average number reaching military age (20) annually about 210,000
Supply: produces some weapons, ammunition, and motor transport; past
dependence upon U.S., Canada, and Western Europe being shifted almost
a
exclusively to Europe
Military budget: proposed for fiscal year ending 31 December 1973,
$446 400,000 about 10% of total central government budget
e
15
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','7c6407eebfce1c5c70a812e51796f1545e615b6ece3ebd95c09a18a34b9c75b8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1ee34f9d92716068265ba65226755cd7bf5dbff69631785d5a374c11324ecc4',1973,'AT','Austria','communications',27,'LAND
2 FED.” E sPOL.
Rep ‘GER.
"32,400 sq. mi.; 20% cultivated, 27% meadows and pastures,
14% waste or urban, 38% forested, 1% inland water
Land boundaries: 1,605 mi.
Railroads: 4,073 mi.; 3,673 mi. government owned; 3,373 mi. standard gage of which
1,408 mi. electrified and 833 mi. double tracked; 300 mi. narrow gage (2''6")
of which 57 mi. electrified; 400 mi. privately owned; 229 mi. standard gage
of which 109 mi. electrified; 171 narrow gage (2''6" and 3''3 3/8") of which
55 mi. electrified
Highways: 20,356 mi. total; 6,056 mi. Federal (5,656 mi. bituminous, concrete,
stone block, 400 mi. crushed stone, gravel, improved earth); 14,290 mi.
Provincial (4,340 mi. bituminous, concrete, stone block, 9,950 mi. crushed
stone, gravel, improved earth); additionally about 38,000 mi. of communal
roads, mostly of gravel, crushed stone, and improved earth
Inland waterways: 267 mi.; carries 5% freight, 6% passengers
Ports: 3 major river
Merchant marine: 18 ships (1000 GRT or over) totaling 72,700 GRT, 109,000 DWT;
includes 16 cargo, 2 bulk
Pipelines: crude oi1, 500 mi.; natural gas, 775 mi.
Civil air: 10 major transport aircraft
Airfields: 65 total, 12 usable; 54 with permanent-surface runways; 2 with run-
ways 8,000-11,999 ft., 9 with runways 4,000-7,999 ft.
Telecommunications: highly developed and efficient; excellent national and
international services; extensive TV and radiobroadcast systems with 100 AM,
68 FM, and 195 TV stations; 1.59 million telephones; 2.48 million radio
receivers; 1.65 million television receivers
DEFENSE FORCES:
Military manpower: males 15-49, 1,679,000; 1,680,000 fit for military service;
average number reaching military age (19) annually about 52,000
Supply: produces some small arms and ammunition, trucks, and tank destroyers;
current sources of other items are the U.S., Western Europe, Sweden,
and the Communist countries
Military budget: for fiscal year ending 31 December 1973, $246 million; about
3.6% of the federal budget
20
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','07c6cb1bc7a197472e1f6a802e1afcf946ad058be989b72fdc43084b2f9d6b25','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('992e09b7611159e6a0d700ca62750ce6436a15b60bba2e9b2559359f679e4354',1973,'BS','Bahamas','communications',31,'LAND:
4,400 sq. mi.; 1% cultivated, 29% forested, 70% built
on, wasteland, and other
WATER: ; etn
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 2,200 mi. (New Providence Is. 47 mi.)
Railroads: none
Highways: 555 mi.; 380 mi. paved, 100 mi. gravel, 20 mi. improved earth; 55 mi.
unimproved earth
Ports: 5 major, 9 minor
2]
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Civil air: 5 major transport aircraft
Airfields: 58 total, 52 usable; 23 with permanent--surface runways; 3 with
runways 8,000-11,999 ft., 23 with runways 4,000-7,999 ft.; 4 seaplane
stations
Telecommunications: telecom facilities highly developed, including 45,000
telephones in totally automatic system; tropospheric scatter link with
Florida; 90,000 radio receivers and 25,000 TV sets, 1 AM and 2 FM stations;
3 coaxial submarine cables
22
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ee
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','7712d277b632c6630a138dd8f4db49c578379461f8b0fa88429efd7a5fa65111','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0917f2d2510eaba5c7e5e78d3d0970a6730791a902394fb92871255979d0c3c7',1973,'BH','Bahrain','communications',35,'LAND: Cianpeceeehy IRAN
* 230 sq. mi. plus group of smaller islands; 5% cultivated,
negligible forested area, remainder desert, waste,
or urban
WATER:
2 Limits of territorial waters (claimed): 3n. mi.
Coastline: 100 mi.
Telecommunications: excellent international radiocommunications; limited
domestic services; 12,850 telephones; 75,000 radio receivers; 10,000 TV sets;
1 AM radiobroadcast station; satellite earth Station; tropospheric scatter
Bahrain~Qatar
DEFENSE FORCES:
Military manpower: males 15-49, 61,000; fit for military service 33,000
Military budget: for fiscal year ending 31 March 1971; $3,490,000, 6.9% of total
budget
24
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
TT
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','abe81ab54be9baa7d046f771d36d3023f46e82c0c27dcf4968ec23f0f493fb73','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d45e53d9f4d7f9293ee8b983351874b673b49f5e70883a5175976e67d9d74dda',1973,'BD','Bangladesh','communications',39,'* “55,000 sq. mi.3 79% arable (including cultivated and
fallow), 5% waste or urban, 16% forested
Land boundaries: 1,575 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
f Coastline: 360 mi.','1562c2447b7f18ee59132991b7d51619880281c11366999dde9b348b4ae4d6c1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42e701065358775b6d0496d388daca373bdd22d4ecf1daedf8a75f137e798958',1973,'BM','Bermuda','communications',46,'LAND: vl
21 sq. mi.; 8% arable, 60% forested, 21% built on, CANADA
wasteland, and other, 11% leased for air and i
naval bases 8 UNITED STATES
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 64 mi.
Railroads: none
Highways: 130 mi., all paved
Ports: 4 major
Civil air: no major transport aircraft
Airfields: 1 with concrete runway 9,660 ft.; 1 seaplane station
33
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Telecommunications: modern telecom system suited to island needs, includes fully
automatic telephone system with 32,000 instruments; 40,000 radio and
20,190 TV receivers, 2 AM, 1 FM, and 2 TY stations; 3 submarine coaxial cables
34
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
a
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','b78df505d1dc5451e1407364911acd8cb2b47853f33d1a20819399b5b1fc0cc0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f2252cbdee8caf7f0fbde5b39f0da8053defa71650856ac11cb99a518bdf30e',1973,'BT','Bhutan','communications',50,'PEOPLE''S REPUBLIC
OF CHINA
D:
~y 18,000 sq. mi.; 15% agricultural; 15% desert, waste,
urban, 70% forested
Land boundaries: about 540 mi.','7a168f8f919f21e579e10099c7319a5beab24209201c63d5e621e537a2304ba9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f54bcbf4fe7d0bea975c8561139059b74138923002831aa37712ac4bad82bf8e',1973,'BW','Botswana','communications',54,'LAND:
‘ 220,000 sq. mi. (1973); about 6% arable, 1ess than 1%
under cultivation, mostly desert
Land boundaries: 2,345 mi.
Railroads: 400 mi. 3''6" gage, Single track; owned and Operated by the Rhodesia
Railroads
Highways: 5,016 mi.; 16 mi. Paved, 471 mi. crushed stone, gravel, or stabilized
SOiT; 4,529 mi. improved or unimproved earth
Inland waterways: native craft only; of local importance
Civil air: 9 major transport aircraft
Airfields: 93 total, 71 usable; 2 with permanent-surface runways; 17 with
runways 4,000-7,999 ft.
Telecommunications: the system is a minimal combination of a single main wire
line and a few radiocommunication Stations; Gaborone is the center; 4,435
telephones; 30,000 radio receivers; ] AM, 1 FM, and no TY Stations
DEFENSE FORCES:
Military Manpower: males 15-49, 152,000; 80,000 fit for military service; 8,000
reach military age (18) annually
Police only
40
0002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A00060001
OT
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','8d6de148539c4b56e45ff7328bd0f558121a175fc0523a28cfdc1d8f051d8356','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17684305acbff806eb4dc5481327cc55cc10c4968983699cdbcbb37ba73ea0f7',1973,'BG','Bulgaria','communications',58,'42,800 sq. mi.; 41% arable, 11% other agricultural,
33% forested, 15% other
Land boundaries: 1,170 mi.
WATER: chien
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 220 mi.
PEOPLE . LIBYA EGYPT z
Population: 8,654,000, average annual growth rate 0.7%
(current)
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsies, 2.5% Macedonians, 0.3% Armenians, 0.2% Russians, 0.6% other
Religion: regime promotes atheism; religious background of population is 85%
Bulgarian Orthodox, 13% Muslim, 0.8% Jewish, 0.7% Roman Catholic, 0.5%
Protestant, Gregorian-Armenian and other.
Language: Bulgarian; secondary languages closely correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 4.4 million (duly 1970); 38% agriculture, 33% industry, 29% other
Railroads: 2,650 mi.; about 2,470 mi. standard gage, 180 mi. narrow gage; 148 mi.
double track; 610 mi. electrified; government owned (1972)
Highways: 20,700 mi.; 12,400 mi. paved, 5,500 mi. crushed stone and gravel,
2,800 mi. earth (1972)
Inland waterways: 300 mi. (1973)
Freight carried: rail -- 77.2 million Short tons, 10.1 billion short ton/mi.
(1970); highway -- 546.8 million short tons, 5.8 billion short ton/mi. (1971);
waterway -- 8.2 million short tons, 2.3 billion short ton/mi. (1972)
Ports: 2 major (Varna, Burgas), 10 minor (1973)
Airfields: 379 total; 105 with permanent-surface runways; 13 with runways
8 ,000-9,999 ft., 26 with runways 4,000-7,999 ft.
Merchant marine: 107 ships (1,000 GRT and over) totaling 705,200 GRT, 1,029,800
DWT; includes 5 passenger, 56 cargo, 18 tanker, 28 bulk
Civil air: 36 major transport aircraft (1973)
DEFENSE FORCES:
Military manpower: males 15-49, 2,247,000; 1,875,000 fit for military service;
about 65,000 reach military age (18) annually
Supply: dependent primarily on U.S.S.R.3 domestic production of small arms,
ammunition, antitank grenades, grenade launchers, trucks, and small
quantities of defensive chemical warfare materiel
46
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
BURMA
LAND:
262,000 sq. mi.; 28% arable, of which 12% is cultivated,
62% forest, 10% urban and other (1969)
Land boundaries: 3,630 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
4 Coastline: 1,900 mi.
Railroads: 2,022 mi.; 1,952 mi. meter gage, 70 mi. narrow-gage industrial lines;
204 mi. double track; government owned
Highways: 15,540 mi.; 4,210 mi. paved, 4,770 mi. gravel, 5,810 improved earth,
750 mi. unimproved earth
Inland waterways: 8,000 mi.; 2,000 mi. navigable by large commercial vessels
Ports: 4 major, 6 minor
Merchant marine: 9 cargo ships (1,000 GRT or over) totaling 55,500 GRT, 73,600
DWT
Civil air: 17 major transport aircraft
Airfields: 119 total, 81 usable; 23 with permanent-surface runways; 2 with
runways 8,000-11,999 ft., 38 with runways 4,000-7,999 ft.; 2 seaplane
stations
Telecommunications: provide minimum requirements for local intercity service;
international service is fair; radiobroadcast coverage is limited to the
more populous areas; 27,000 (est.) telephones; 500,000 (est.) radio sets;
1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 7,030,000; 3,600,000 fit for military service;
about 290,000 males and 270,000 females reach military age (18) annually;
both are liable for military service
Military budget: for fiscal year ending 30 September 1973; $140.3 million, 36.2%
of total budget
48
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
era
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','3d157b9fe7629fba5e114473824a1725e371dd8ea6c223b3feb1e95fb9b04dd5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6eac858c5f8532694e31ff103b62b82520a8dfeaa70b329a9fd3c1bae84f5e9c',1973,'BI','Burundi','communications',62,'ND:
« 11,000 sq. mi.; about 37% arable (about 66% cultivated),
23% pasture, 10% scrub and forest, 30% other
Land boundaries: 605 mi.
Railroads: none
Highways: 3,700 mi.; 45 mi. bituminous, 3,655 mi. crushed stone, gravel, laterite,
and improved or unimproved earth
Inland waterways: Lake Tanganyika navigable for lake steamers and barges
Ports: 1 minor lake
Civil air: no major transport aircraft
Airfields: 32 total, 22 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 Ft.
Telecommunications: telegraph is principal service, limited telephones; 5,875
telephones, 100,000 radio receivers; 2 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 882,000; 425,000 Fit for military service; 42,000
reach military age (16) annual ly
Military budget: for fiscal year ending December 1973, $5,600,000; about 19.4% of
Ordinary budget
50
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
aa
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','8845eb2fb6ec421980718c3e60ec468406b0f2ac4c1857ad1b165c5648817541','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e965dbb6be936d0d099d9615e6dbf2a390648d0dfd11136219f4d62ab211b741',1973,'KH','Cambodia','communications',66,'AND:
“ 70,000 sq. mi.; 16% cultivated, 74% forested, 10% built-on
area, wasteland, and other
Land boundaries: 1,515 mi.
WATER:
4 Limits of territorial waters (claimed): 12 n. mi.
Coastline: about 275 mi.
Railroads: 409 mi. meter gage; government owned
Highways: 9,300 mi.; 1,600 mi. bituminous, 1,300 mi. crushed stone, gravel, or
improved earth; and 6,400 mi. unimproved earth
Inland waterways: 1,220 mi. during high water, 1,010 mi. during low water;
90% of total navigability on Mekong system and Tonle Sap
Freight carried: (1970) rail -- 50 million ton-miles; waterway -- approximately
300,000 short tons annually; figures unavailable for highways
Ports: 2 major, 6 minar
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,400 GRT, 2,600 DWT
Airfields: 100 total, 45 usable; 8 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 16 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: service to general public considered poor; barely adequate
for government requirements; international service fair to adjoining countries
and a few other nations; radiobroadcasts and television coverage limited by
smal] number of stations and receivers; 9,600 telephones; 1.2 million (est. )
radio receivers; 40,000 (est.) TV receivers; 1 AM, 2 AM relay, 1 FM, and
1 TV station; no submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 1,642,000; 910,000 fit for military service;
83,000 reach military age (18) annually
52
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','9fa6c7ca7fe7bfe2b2a5cae7e9756687ad110ea9e619604e1997f4779b762052','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a83ee528afc90aa8a206f042a7c3b67a26dd23266ac67e29619362627f848be7',1973,'CM','Cameroon','communications',70,'LAND:
183,400 sq. mi.; 4% cultivated, 18% grazing, 13% fallow,
50% forest, 15% other
Land boundaries: 2,830 mi.
WATER:
Limits of territorial waters (claimed): 18 n. mi.
Coastline: 250 mi.
Railroads: 623 mi.; 533 mi. meter gage, 90 mi. 1''11 5/8" gage
Highways: approximately 14,000 mi.; including 900 mi. bituminous, 13,100 mi.
gravel and earth
Inland waterways: 1,300 mi.
Ports: 1 major, 3 minor
Civil air: 8 major transport aircraft
Airfields: 59 total, 56 usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: good telephone service between Douala and Yaounde, fair in
southern part; fair to good telegraph service; 21,850 telephones; 216,000
radio receivers; 4 AM, no FM, and no TV stations; limited wired broadcast;
1 submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 1,391,000; 725,000 fit for military service;
average number reaching military age (18) annually about 62,000
Supply: mostly from France and U.S.
54
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
a
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','6d6cfad1c7d74aa8f3998c311aecb2efc22803bcfe45b91a6e7697211d67ec84','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8acb15cbb4d878831a844453d5e560c8921109d9711891dd0fbf1e756a9ee70',1973,'CF','Central African Republic','communications',74,'D a3 oie tieya |EGYRY 2s:
% "942,000 sq. mi.3 10%-15% cultivated, 5% dense forests,
80%-85% grazing, fallow, vacant arable land, urban,
waste
Land boundaries: 3,095 mi.
Railroads: none
Highways: 13,250 mi.; 115 mi. bituminous, 2,265 mi. gravel and/or crushed stone, ig
3,420 mi. improved earth, 7,450 mi. unimproved earth
Inland waterways: 4,400 mi.; traditional trade carried on by means of dugouts
On the extensive system of rivers and streams; only the Oubangui River
between Bangui and Brazzaville and short sections of the Sangha and the
Lobaye Rivers are navigable throughout year; during high-water period
(July - December) Oubangui navigable upstream from Bangui as far as Ouango
Ports: Bangui, Quango (river Barts}
Civil air: 5 major transport aircraft
Airfields: 65 total, 49 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 17 with runways 4,000-7,999 ft,
Telecommunications: facilities are meager and provide only barely sufficient
Services; principal network is 39 low-capacity, low-powered radiocommunica-
tion stations; no cables or radio relay links are used; single center of
Bangui has only international radio connections; 5,100 telephones; 60,000
radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 444,000; 215,000 fit for military service
Supply: completely deperdent on France ’
Military budget: for fiscal year ending 31 December 1972, $5,111,500; about
9.5% of total budget
58
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','b8abdebe4718c1eac6223067fbd3605a8eb44d5fea4197d8754b2156877ec395','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97541d8539dd9357f203e7482eb5a3a0acc70eba2ab1b91e27f66a67a76a8088',1973,'TD','Chad','communications',78,'D:
496,000 sq. mi.; 17% arable, 35% pastureland, 2% forest
and scrub, 46% other uses and waste
Land boundaries: 3,720 mi.
Railroads: none
Highways: 19,200 mi.; 160 mi. bituminous, 3,300 mi. gravel and laterite, and
15,740 mi. unimproved
Inland waterways: approximately 1,300 mi. of year-round navigability, increased
to 3,000 mi. during high-water period
Civil air: 3 major transport aircraft
Airfields: 76 total, 60 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 22 with runways 4,000-7,999 ft.
Telecommunications: fair system of radiocommunication stations only for intercity
links; principal center Fort-Lamy, secondary center Fort-Archambault; 5,000
telephones; 70,000 radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 936,000; 485,000 fit for military service;
average number reaching military age (20) annually about 35,000
Military budget: for fiscal year ending 31 December 1972, $13,622,000; about
24.4% of total budget
60
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','51106d66c43d41e052d71e25235698d248007ccee698ace92204bf7b19a44b2b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87e47e893b1d9f92450e9773167d94ab4d7223adc920b3267f076b8949b821b8',1973,'CO','Colombia','communications',82,'A ‘ ; BRAZIL
; 440,000 sq. mi.; settled area 28% consisting of cropland
ss and fallow 5%, pastures 14%, woodland, swamps, and
water 6%, urban and other 3%; unsettled area 72% --
mostly forest and savannah
Land boundaries: 3,750 mi.
¥ WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,£00 mi.
Railroads: 2,160 mi., all] 3''0" gage, single track, 22 mi. electrified
Highways: 28,600 mi.; 3,700 mi. paved, 19,900 mi. crushed stone or gravel,
3,100 mi. improved earth, 1,900 mi. unimproved earth
Inland waterways: 8,900 mi., navigable by river boats
Pipelines: crude oil, 2,000 mi.; refined products, 830 mi.; natural gas, 370 mi.;
natural gas liquids 80 mi.
Ports: 5 major, 5 minor
Merchant marine: 40 ships (1,000 GRT or over) totaling 216,500 GRT, 283,800 DWT;
32 cargo, 3 tanker, 5 bulk; includes 3 naval tankers sometimes used
commercially
Civil air: 111 major transport aircraft
Airfields: 876 total, 678 usable; 35 with permanent-surface runways; 1 with
runway over 12,000 ft.; 6 with runways 8,000-11,999 ft., 80 with runways
4,000-7,999 ft.; 11 seaplane stations
Telecommunications: rapidly improving nationwide telecom system; communications
satellite ground station; over 1 million telephones; est. 6 million radio
and 810,000 Ty receivers; 290 AM, 130 FM, and 18 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 5,627,000; 3,345,000 fit for military service;
average number reaching military age (18) annually about 249,000
Military budget: proposed for fiscal year ending 31 December 1973, $155.7 million;
about 8% of central government budget
68
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMORO ISLANDS
LAND:
838 sq. mi.; 4 main islands; forests 16%, pasture 6.8%,
cultivable area 48.3%, non-cultivable area 28.9%
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 211 mi.','f22c810f24d34c50af4d81c03c9f31eada32a172264616fc665ec5c6d9d38677','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c19cdf0f5b7f04550691b910cfed811f3149a5b944d0ab1d73d61ccea7248ef5',1973,'CG','Congo','communications',89,'Railroads: 490 mi., 3''6" gage, single track
Inland waterways: 4,030 mi. navigable
Ports: 1 major
Civil air: 8 major transport aircraft
Airfields: 69 total, 44 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 16 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: all services only fair; barely adequate for government and
publics principal network is comprised of 30 low-capacity, low-powered radio
communication stations; few wire lines connect key centers of Brazzaville,
Pointe-Noire, and Dolisie with maximum of 21 channels; 10,600 telephones;
70,000 radio receivers; 2,500 TV receivers; 3 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 242,000; 115,000 fit for military service;
about 10,000 reach military age (20) annually
72
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ee
A
pproved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','3bf3d402f51573ab20c811d64786d6e1638a7d1f7c01a1ce217ed2d824d578d6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8248c67563269414bcc00b1689403ece2d596aa2da3d8c11fde60ddec7a67bd0',1973,'CR','Costa Rica','communications',90,'LAND:
4 19,700 sq. mi. 30% agricultural land (8% cultivated, 22%
meadows and pasture) » 60% forested, 10% waste, urban,
and other (1964)
Land boundaries: 415 mi.
: WATER:
Limits of territorial waters (claimed): 12 0. mi. (fishing
200 n. mi.)
Coastline: 800 mi.
Railroads: 407 mi.; 395 mi. 316" gage, 12 mi. 3''Q" gage, all single track, 72 mi,
electrified
Highways: 11,700 mi.; 850 mi. Paved, 3,200 mi. gravel, 7,650 mi. earth
Inland waterways: about 455 mi, perennially navigable
Pipelines: refined Products, 80 mi.
Ports: 3 major, 4 minor
Merchant marine: 1 Cargo ship (1,000 GRT or over) totaling 2,600 GRT, 3,700 DWT
Civil air: 15 major transport aircraft
Airfields: 207 total, 129 usable; 9 with permanent-surface runways; 10 with
runways 4,000-7,999 ft.; 2 seaplane stations
Teleconmunications: domestic telephone service greatly improved; 68,000 telephones;
connection into Central American microwave net; 330,000 radio and 120,000 Ty
receivers; 44 AM, 8 FM, and 11 Ty stations
Military budget: for fiscal] year ending 31 December 1973, $5.2 million for
Ministry of Public Security, including the Civil Guard; about 2, 3% of total
ceittral government budget
74
10002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A0006000
nen
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
urban, and waste (1970) wetaiucla
Land boundaries: 390 mi. EEE ASE Coomera
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,545 mi.','5491301d42f8403b1c9dbd6b5f029820ffe1c729eb522b42a22d8e75843ff7c1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e00dedd07f4fd39d7bb525351e253545b3fe85aa1ea9d5b3002e761e6de1bd7a',1973,'CU','Cuba','communications',94,'D:
: 44,200 sq. mi.; 35% cultivated, 30% meadow and pasture,
20% waste, urban, or other, 15% forested (1968)
WATER: Pe NerOnLn
Limits of territorial waters (claimed): 3.n. mi.
? Coastline: 2,320 mi.
industrial lines; common carrier lines comprise 3,100 mi. 4''8 1/2" standard
gage, and about 50 mi. 3''0" and 2''6" narrow gage; plantation-industrial
lines comprise about 4,000 mi. standard gage and 2,000 mi. narrow gage
Highways: 12,800 mi.; 5,400 mi. paved, 7,400 mi. gravel and earth surfaced
Merchant marine: 58 ships (1,000 GRT and over) totaling 347,300 GRT, 465,800
DWT; includes 46 cargo, 8 tanker, 1 bulk, 3 specialized carrier; Cuba
beneficially owns 5 additional ships (1,000 GRT and over) of 46,100 GRT,
65,300 DWT which are registered under a Hong Kong company and fly the U.K.
and Somali flags
Civil air: 33 major transport aircraft
Airfields: 376 total, 198 usable; 38 with permanent~surface runways; 10 with
runways 8,000-11,999 ft., 29 with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: modern facilities adequately serve military and most civil
needs; excellent international facilities, satellite ground station under
construction; 300,000 telephones; 1.5 million radio and 600,000 Ty receivers,
100 AM, 25 FM, and 23 TV stations; 6 submarine cables, including 1 coaxial
DEFENSE FORCES:
76
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
a
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','0331d571dc05c15a7f61d348d463d6b4bbcd063b1bd38aabd46da0753626f34f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('626a68e2960f52abef8504e4a5c73f01ac2c6c1091499c831daecb89d295b193',1973,'CY','Cyprus','communications',98,'LAND : TURKEY
: 3,572 sq. mi.3 47% arable and land under permanent crops;
18% forested, 10% meadows and pasture, 25% waste,
urban areas, and other
WATER:
q Limits of territorial waters (claimed): 12 n. mi.
Coastline: 400 mi. (approx. )
ARABIA
Railroads: none
Highways: 5,000 mi.; 2,100 mi. bituminous surface treated; 2,900 mi. gravel,
Crushed stone, and earth
Ports: 3 major, 6 minor
Merchant marine: 494 ships (1,000 GRT or over) totaling 2,737,500 GRT, 3,936,400
DWT; includes 9 Passenger, 395 cargo, 29 tanker, 52 bulk, 9 specialized
carriers; all but a few are owned and operated by Greek nationals
Civil air: 8 major transport aircraft
Airfields: 20 total, 14 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft.3; 3 with runways 4,000-7,999 ft.
Telecommunications: moderately good telecommunication system; 47,600
telephones; 174,000 radio receivers; 62,500 TV receivers; 5 TV, 12 AM, and
4 FM stations; tropospheric scatter circuits to Greece and Turkey
DEFENSE FORCES:
Military manpower: males 15-49, 156,000; 110,000 fit for military service,
about 7,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1971, $7.5 million about
9.7% of central government budget
78
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
CZECHOSLOVAKIA
D:
49,400 sq. mi.; 42% arable, 14% other agricultural, 35%
forested, 9% other
Land boundaries: 2,200 mi.
Railroads: 360 mi., all meter gage (3''3 3/8")
Highways: 4,300 mi.; 470 mi. paved, 1,670 mi. otherwise improved earth, 2,160
mi. unimproved
Inland waterways: 400 mi. navigable
Ports: 1 major, 1 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 10,600 GRT, 13,300 DWT
Civil air: no major transport aircraft
Airfields: 117 total, 10 usable; 1 with permanent-surface runway; 4 with runways
4,000-7,999 ft,
TeTecommuni cations: telephone service concentrated in south; telegraph limited,
but more extensive than telephone; 6,500 telephones; 54,000 radio receivers;
2 AM, no FM, and no TY stations; 3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 697,000; 335,000 fit for military service; about
29,000 males and 28,000 females reach military age (18) annually; both sexes
liable for military service
Supply: dependent on France
82
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
AERO','81e449815a7b72f3b8cff85453d9e5b057d01a9ea719385df99806af08fcd76b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b393c464a098b4bcc1e3e4bb28b54cc0c9cc17000ac410b51a2a1f151792b21',1973,'DK','Denmark','communications',102,'16,600 sq. mi. (exclusive of Greenland and Faeroe Islands);
64% arable, 8% meadows and pastures, 11% forested, 17%
other
Land boundaries: 42 mi.
WATER:
Limits of territorial waters (claimed): 3.n. mi- (fishing
12 n. mi.
Coastline: 2,100 mi.
Railroads: 1,810 mi. Danish State Railways (DSB) 1,461 mi. standard gage (4''8 1/2"),
52 mi. electrified and 453 m. double tracked; remaining 349 mi. of standard 7
gage lines are privately owned and operated
Highways: 33,275 mi.; 31,205 mi. concrete, bitumen, or stone block; 5,649 mi.
gravel and crushed stone; 1,430 mi. improved earth
Inland waterways: 259 mi.
Pipelines: refined Products, 290 mi.
Ports: 16 major, 42 minor 4
Merchant marine: 302 shins (1,000 GRT or over) totaling 3,761,400 GRT, 6,138,600
DNT; includes 12 passenger, 195 cargo, 38 tanker, 23 bulk, 34 specialized
carrier :
Civil air: 95 major transport aircraft
Airfields: 134 total, 113 usable; 16 with permanent-surface runways; 8 with run-
ways 8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommuni cations: excellent telephone, telegraph, and broadcast services;
1,603,000 telephones; 1,640,000 radiobroadcast receivers; 1,500,000 Ty
receivers; 5 AM, 13 FM, and 30 TV stations; 13 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 1,191,000; 1,047,000 fit for military service;
38,000 reach military age (20) annually
Military budget: for fiscal year ending 31 March 1973, $457 million; about 7%
of central government budget
84
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ee
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','3cca433ece03fa5bfbf32e0ea2a79b55f954673676a7eccbfbf11cab12251938','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82f2a1797a5c1be42fbf6c087b111ef56d64f3658b6664a9298983ce1b920a14',1973,'DM','Dominica','communications',106,'LAND:
. 305 sq. mi.; 24% arable, 2% pasture, 67% forests, 7%
other
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 92 mi.','371e46e45e0dddcee53ec9ff3b742dca0eb579d7be1e60e8b07d8013fbd3fc7b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66bb8f923364da358585b6fbf6ef8bddf9545e14db4c5a7ea3ae22b1756eb0ef',1973,'DO','Dominican Republic','communications',108,'‘ “18,800 sq. mi.3 14% cultivated, 4% fallow, 17% meadows
and pastures, 45% forested, 20% built-on or waste
Land boundaries: 224 mi.
VENEZUELA
WATER: ~covomein
‘ Limits of territorial waters (claimed): 6 n. mi. (fishing pen
12 0. mi.) bo 55
Coastline: 800 mi. oe BRAZIL
Railroads: 1,000 route mi. of which 65 mi. government-owned common carrier
(3''6" gage) and 935 mi. Privately owned plantation network (approximately 4
different gages ranging from 1''10 1/2" to 4''g 1/2", with 2''6" predominating)
Highways: 6,200 mi.; 3,200 mi. paved, 900 mi. gravel, 1,400 mi. improved earth,
700 mi. unimproved earth
Pipelines: product lines (1.5 mi. and 43 mi.) under construction, to be completed
in 197]
Ports: 5 major, 17 minor
Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 5,000 GRT, 7,700 DWT
Civil air: 16 major transport aircraft
Airfields: 64 total, 43 usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 7 seaplane station
Teleconmunications: relatively efficient domestic system based on istandwide
radio relay network; 56,000 telephones; 400,400 radio and 150,000 Tv receivers,
107 AM, 37 FM, and 8 Ty Stations; 3 submarine cables, including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 1,023,000; 650,000 Fit for military service;
reach military age (18) annually
Supply: dependent upon U.S. and Western Europe
Military budget: for fiscal year ending 31 December 1972, $33.3 million; about
11.0% of central government budget
88
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','70facb9263d836c157c0b6dce173985b95fa11394e3f0ffaff99f90431a7507c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('877247a0c4a6526c9292e48b832b48296930344b97abe31a6a26551477a99604',1973,'EC','Ecuador','communications',112,'LAND:
‘ 106,000 sq. mi. (including Galapagos Islands); 11%
cultivated, 8% meadows and pastures, 55% forested,
26% waste, urban, or other
Land boundaries: 1,200 mi.
4 WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,390 mi. (includes Galapagos Is.)
Railroads: 660 mi.; 615 mi. 3''6" gage, 45 mi. 2''5 1/2" gage; all single track
Highways: 14,200 mi.; 1,900 mi. paved, 5,100 mi. gravel, 3,800 mi. improved
earth, 3,400 mi. unimproved earth
Inland waterways: 960 mi.
Pipelines: crude of1, 390 mi.; refined products, 50 mi.
Ports: 2 major, 11 minor
Merchant marine: 10 ships (1,000 GRT or over) totaling 65,500 GRT, 88,100 DWT;
includes 7 cargo, 3 tanker
Civil air: 46 major transport aircraft
Airfields: 200 total, 177 usable; 15 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: facilities generally adequate only in largest cities;
satellite ground station; 105,000 telephones; 680,000 radio and 120,000 TV
receivers; 230 AM, 20 FM, and 11 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,572,000; 1,000,000 fit for military service;
average number reaching military age (20) annually 65,000
Supply: dependent primarily on U.S.; some major purchases from Western Europe
Military budget: for fiscal year ending 31 December 1972, $35.3 million; about
10.4% of central government budget
90
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','45ffbbb0a6480959833a6302f47906ec1296ce39f755aaf7a89a06edfcc8ecc5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1505416b3a356df89871c3e702583c1149979086afab7ab8d14e9a7bbe567d1b',1973,'EG','Egypt','communications',116,'D:
386,200 sq. mi. (including 22,200 sq. mi. occupied by
Israel); 2.8% cultivated (of which about 70% multiple
cropped); 96.5% desert, waste, or urban; 0.7% inland
water
Land boundaries: 1,570 mi. (1967), excludes occupied area
1,534 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,140 mi. (1967), excludes occupied area 1,340 mi.
Railroads: 3,358 mi.; 570 mi. double track; 15 mi. electrified; 2,976 mi. 4''8 1/2"
gage, 156 mi. 3''3 3/8" gage, 226 mi. 2''5 1/2" gage
Highways: 29,000 mi.; 5,190 mi. paved, 7,130 mi. gravel, crushed stone, and
improved earth, 16,680 mi. unimproved earth, additional 1,500 mi. (mostly
paved) in territory (Sinai) occupied by Israel
Inland waterways: 2,100 mi.; Suez Canal, 100 mi. long, temporarily closed to
navigation because of sunken vessels; normally used by ocean~-going vessels
drawing up to 38 ft. of water; Alexandria-Cairo waterway navigable by barges
of 500-ton capacity; Nile and large canals by barges of 420-ton capacity;
Ismailia Canal by barges of 200- to 300-ton capacity; secondary canals by
sailing craft of 10- to 70-ton capacity
Freight carried: Suez Canal (1966) -- 242 million tons of which 175.6 million
tons were POL
Pipelines: crude oi], 130 mi.; refined Products, 390 mi.; natural gas, 30 mi.
Ports: 3 major, 8 minor
Merchant marine: 42 ships (1,000 GRT or over) totaling 200,000 GRT, 264,200 ”
DWT; includes 5 passenger, 29 cargo, 8 tanker
Civil air: 15 major transport aircraft
Airfields: 149 total, 76 usable; 65 with permanent-surface runways; 42 with
runways 8,000-11,999 ft., 20 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: second best system of coaxial and multiconductor cables, ,
open-wire lines, and radio communication stations in Africa; principal centers
Alexandria and Cairo, secondary centers Al Mansurah, Ismailia, and Tanta;
365,000 telephones; 5 million radio and 575,000 TV receivers; 12 AM, 1 FM,
and 26 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,106,000; 5,125,000 fit for military service;
about 357,000 reach military age (20) annually
92
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','775b50f8df7813d85a9f643b61ebbfa15b6b311718542f03f38692cd2cb98064','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be4a89ac9f48d1fde8d99520327d0f3869b730e4b908fd87c738b82b2ce91482',1973,'SV','El Salvador','communications',120,'LAND:
8,260 sq. mi.; 32% cropland (9% corn, 5% cotton, 7%
coffee, 11% other), 26% meadows and pastures, 31%
nonagricultural, 11% forested
Land boundaries: 320 mi.
fo :
VENEZUELA
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 190 mi.
Railroads: 375 mi., 3''0" gage; single-tracked; 285 mi. privately owned, 90 mi.
government owned
Highways: 5,400 mi.; 750 mi. bituminous, 950 mi. gravel or crushed stone, 3,700 mi.
earth
Inland waterways: Lempa River partially navigabie
Ports: 3 major, 1 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,600 GRT, 1,800 DWT
Civil air: 7 major transport aircraft
Airfields: 149 total, 119 usable; 3 with permanent~surface runway 4,000-7,999 ft.;
1 seaplane station
Telecommunications: nationwide trunk radio relay system; connection into
Central American microwave net; 40,100 telephones; 500,000 radio and 108,000
TV receivers; 57 AM, 6 FM, and 4 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 878,000; 535,000 fit for military service;
42,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1973, $14.7 million; about
8.8% of central government budget (includes public security forces)
94
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','3ca23dcdb9a011803fd8fccec3676684ed0863cad60b43cb9bac20bbba5b0298','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbf3787f7bcbb12b944469bf4695427a8feca20d2d76ba11f2b2afc73625d5f1',1973,'GQ','Equatorial Guinea','communications',124,'LAND: an
10,800 sq. mi.; Rio Muni, about 10,000 sq. mi., largely E
forested; Fernando Po, about 800 sq. mi. Oy T
Land boundaries: 335 mi. F equar
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 184 mi.
Railroads: none
Highways: Rio Muni -- 1,553 mi., including approx. 115 mi. bituminous,
remainder gravel and earth; Fernando Po -- 186 mi., including $1 mi.
bituminous, remainder gravel and earth
Inland waterways: Rio Muni has approximately 104 mi. of year-round navigable
waterway, used mostly by pirogues
Ports: 2 major, 3 minor
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: fairly adequate for the size and stage of development of the
country; international communications by radio from Bata and Santa Isabel
to Cameroon, Nigeria, and Spain; 1,500 telephones; 75,000 radio receivers;
2 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 75,000; 35,000 fit for military service
Military budget: for FY70, $3,475,000, 14.3% of total budget
96
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','ea7c47e33b2fb17ce86a79f2729fd02cc00370fc1ac402e84d3ebfafa820bb9b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d2b7df4b2480d8a15cd2d4d354a0db968836543d79222cd0419ab8ae02ef492',1973,'ET','Ethiopia','communications',128,'D:
455,000 sq. mi.; 9.5% cropland and orchards, 54.6% meadows
and natural pastures, 6.5% forests and woodlands,
29.4% wasteland, built-on areas, and other
Land boundaries: 3,230 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 680 mi. (includes offshore islands)
Railroads: 630 mi.; 420 mi. 3''3 3/8" gage, 20 mi. 3''6" gage, 190 mi. 3''1
3/8" gage; all single track
Highways: 14,500 mi.; 1,250 mi. bituminous, 3,000 mi. crushed stone, gravel, or
stabilized earth, 10,250 mi. earth
Inland waterways: navigation possible on Lake Tana and on approx. 140 mi. of
unconnected and basically unimproved waterways, of which only 71 mi. are
navigable year round
Ports: 2 major, 1 minor
Merchant marine: 5 ships (1,000 GRT or over) totaling 35,500 GRT, 51,100 DWT;
includes 2 cargo, 2 tanker, 1 bulk
Civil air: 17 major transport aircraft
Airfields: 200 total, 121 usable: 7 with permanent-surface runways; 5 with run-
ways 8,000-11,999 ft., 51 with runways 4,000-7 ,999 ft.
Telecommunications: system better than in most African countries; composed of
open-wire lines, radiocommunication stations, and small number of multi- ¥
conductor cable and radio-relay links; principal center Addis Ababa, secondary
center Asmara; 50,500 telephones; 500,000 radio receivers; 8,600 TV receivers;
5 AM, no FM, and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 6,673,000; 3,450,000 Fit for military service; ;
average number reaching military age (18) annually 265,000
98
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
— eS
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
FAEROE ISLANDS
LAND:
‘ 540 sq. mi.; less than 5% arable, of which only a fraction
cultivated; archipelago consisting of 18 inhabited
islands and a few uninhabited islets
WATER:
my Limits of territorial waters (claimed): 3 n. mi.
fishing, 12 n. mi. (from extended base lines)
Coastline: 475 mi.
Railroads: none
Highways: 512 mi.; 9 mi. paved, 23 mi. gravel, 480 mi. earth
Ports: 1 major, 4 minor
Civil air: no major transport aircraft
*The possession of the Falkland Islands has been disputed by the U.K. and Argentina
(which refers to them as the Malvinas) since 1833.
101
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Airfields: 1 seaplane station
Telecommunications: government-operated open-wire and radiotelephone networks
providing effective service to almost all points on both islands; approx-
imately 580 telephones; 1 AM station and approximately 1,100 radiobroadcast
receivers
102
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
na
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','c3be1b6583e8c1f7641aa1e38dede8057ac4ed4ff1cd7f383edb0c9be50e34b9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60d98b2c6753f446728f5f9a004e2ff53e8f8db0e7acaf23d64f0552215991d7',1973,'FJ','Fiji','communications',132,'LAND:
‘ 7,055 sq. mi.3 landownership -- 83.6% Fijians, 1.7% Indians,
6.4% government , 7.2% European, 1.1% other; about 30%
of land area is suitable for farming
WATER:
« Limits of territorial waters (claimed): 3.n. mi.
Coastline: 700 mi. (est. )
Railroads: none
Highways: 1,550 mi. 166 mi. paved, 1,384 mi. gravel or crushed stone, 80 mi.
cA unimproved earth
Inland waterways: 126 mi.; 76 mi. navigable by motorized craft and 200-ton barges
103
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Ports: 6 major, numerous minor Tandings
Civil air: 6 major transport aircraft
Airfields: 17, 12 usable; 1 with runway 8,000-11,999 ft., 1 with runway 4 ,000-7,999
ft., 2 seaplane stations
Teleconmuni cations: modern local, interisland, and international (wire/radio
integrated) public and special-purpose telephone, telegraph, and teleprinter
facilities; regional radio center; important COMPAC cable link between
U.S./Canada and New Zealand/Australia, at al; 19,560 telephones; 53,000
radio receivers; 5 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 143,000; 77,000 fit for military service; 6,000
reach military age (18) annually
Military budget: the defense of the Fiji Islands was the responsibility of the
U.K. until 10 October 1970; the military budget for 19717 is $314,000
104
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
° 2 se
a
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','319154ecdcf545c6068c22bc0bd6e3aae00fa4abd4cd1ec27963f7d3185a4e46','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90fa1c6cb55522bfd4eb9d1ebe17bf1473573eec103c5d0a887b11f52ab338d4',1973,'FI','Finland','communications',136,'ND:
130,000 sq. mi.; 8% arable, 58% forested, 34% other
Land boundaries: 1,575 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi.;
Aland Islands, 3 n. mi.
Coastline: 700 mi. (approx.) includes islands
PEOPLE: 2 uevs lecven saure
Population: 4,644,000, average annual growth rate 0.4%
(1/72-1/73)
Ethnic divisions: homogeneous white population, smal]
Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox, 1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and Russian-speaking minorities
Literacy: 99%
Labor force: 2.3 million; 28.1% agriculture, forestry, and fishing, 24.2% mining
and manufacturing, 9.0% construction, 13.7% commerce, 6.6% transportation and
communications, 16.5% services; 2.8% unemployed
Organized labor: 60% of labor force
Railroads: 3,676 mi.; Finnish State Railways (VR) operate a total
3,658 mi. broad gage (5''0"), 288 mi. multiple track, and 68 mi. electrified;
14 mi. narrow gage (2'' 5 1/2") and 4 mi. broad gage are privately owned
Highways: 44,660 mi., 12,060 mi. bituminous, 31,900 mi. stablized gravel, 700
mi. gravel and earth; 12,400 mi. of private roads (surface type na)
Inland waterways: 4,100 mi. total (including Saimaa Canal); 2,300 mi. suitable
for steamers; canal locks (275 ft. by 42 ft. with a 16.7 ft. depth over sill)
can accommodate vessels of up to 225 ft. in length, 36 ft. beam, and 14.5
ft. draft
Ports: 11 major, 14 minor
Merchant marine: 218 ships (1,000 GRT or over) totaling 1,436,900 GRT, 2,083,700
DWT; includes 10 passenger, 117 cargo, 47 tanker, 14 bulk, 30 specialized
carrier
Civil air: 33 major transport aircraft
Airfields: 96 total, 77 usable; 29 with permanent-surface runways; 17 with
runways 8,000-11,999 ft., 22 with runways 4,000-7,999 ft.
Telecommunications: facilities provide essential services for government, public,
and industry; 1,301,000 telephones; 1,877,000 radiobroadcast receivers ;
1,185,000 TV receivers; 11 AM, 40 FM, and 58 TV stations; 4 submarine cables,
including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 1,195,000; 888,000 fit for military service;
38,000 reach military age (17) annually
Military budget: proposed for fiscal year ending 31 December 1973, $260 million;
about 6% of central government budget
106
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','9a813f01ccb970f582184c358c55b1e7322d9a342b948351bae95c7463d5b414','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abacef0b448187ca9fcea3ca24560fd807baa1f6489b85baa733f263b6584377',1973,'FR','France','communications',139,'LAND:
213,000 sq. mi.; 35% cultivated, 26% meadows and pastures,
14% waste, urban, or other, 25% forested
Land boundaries: 1,795 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,130 mi. (includes Corsica, 400 mi.)
PEOPLE : : ALGERIA
Population: 52,182,000, average annual growth rate 0.9%
(7/65-7/72)
Ethnic divisions: 45% Celtic; remainder Latin, Germanic, Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1% Muslim (North African
workers), 11% unaffiliated
Language: French (100% of population); rapidly declining regional patois --
Provencal, Breton, Germanic, Corsican, Catalan, Basque, Flemish
Literacy: 97%
Labor force: 21,200,000 (1972 est.); 12% agriculture, 39% industry, 47% services,
2% unemployed
Organized labor: 17% of labor force, 23.4% of salaried labor force
Railroads: 24,815 mi.; 23,494 mi. standard gage, 1,321 mi. other gages (3'' 3 3/8"
to 4'' 9"); 5,886 mi. electrified, 9,892 mi. double or multiple track
Highways: National, Departmental, and Communal roads total 487,600 mi. comprising
292,600 mi. paved, 190,000 mi. crushed stone and gravel, and 14,600 mi.
improved earth; in addition, there are approximately 434,000 mi. of local
farm and forest roads
Inland waterways: 9,320 mi.; 4,820 mi. heavily traveled
ie crude oi], 1,400 mi.; refined products, 2,700 mi.; natural gas,
9,300 mi.
Ports: 22 major, 165 minor
Merchant marine: 411 ships (1,000 GRT or over) totaling 7,490,800 GRT, 12,293,600
DWT; includes 13 passenger, 196 cargo, 109 tanker, 48 bulk, 45 specialized
carrier
Civil air: 327 major transport aircraft t
Airfields: 520 total, 428 usable; 170 with permanent-surface runways; 1 with
runway over 12,000 ft., 19 with runways 8,000-11,999 ft., 127 with runways
4,000-7,999 ft.; 10 seaplane stations
Teleconmunications: highly developed system provides satisfactory telephone, :
telegraph, and radio and TV broadcast services; 9.67 million telephones; 16.5 .
million radiobroadcast receivers; 12.4 million TV receivers; 52 AM, 73 FM,
and 1,162 TV stations; 17 submarine cables (16 coaxial); 3 communication
satellite ground stations
108
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
DEFENSE FORCES:
Military manpower: males 15-49, 12,647,000; fit for military service 10,180,000;
423,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1973, $7.6 billion; about
17% of central government budget
109
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','5853852f3b614484139edc327e39dc59619cccce582257367fbe91243b413479','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b6657abe1028c9fc60d7a0a10c6d660ffd02f57cb10eb7b13a16da04651e4fa',1973,'GF','French Guiana','communications',142,'LAND:
35,100 sq. mi.; 90% forested, 10% wasteland, built~-on,
inland water, and other of which .05% is cultivated
and pasture
Land boundaries: 735 mi.
WATER: ;
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 235 mi.
Railroads: 20 mi. private plantation line, 1''11 5/8" gage; 8 mi. abandoned
narrow-gage line
Highways: 450 mi.; 250 mi. paved, 200 mi. improved earth or gravel
Inland waterways: 290 mi.; navigable by small oceangoing vessels and river
and coastal steamers; 2,110 mi. possibly navigable by native craft
Ports: 1 major, 7 minor
Civil air: no major transport aircraft ;
Airfields: 15 total, 10 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft.; 1 seaplane station
Telecommunications: very limited open-wire telecom system with about 6,300
telephones; est. 7,000 radio receivers and 2,900 TV receivers, 1 AM, 2 FM
and 2 TV stations; 1 satellite tracking and control station
DEFENSE FORCES:
Military manpower: males 15-49, 14,000; 10,000 fit for military service
V2
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
FRENCH TERRITORY OF THE AFARS AND ISSAS
LAND: :
b 9,000 sq. mi.3 89% desert wasteland, 10% permanent pasture» ESP aun
and less than 1% cultivated a
Land boundaries: 321 mi.
i "
wh ARABIA
y
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 195 mi. (includes offshore islands)','d35a71e3536aec7feef6c654e6fb93a3db0df80ca93e98e80b1a0d7f6c7238eb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d8e5d4cbc2cea1d00a9deafe5ada8d7c5779fa9523c28eefb8bfa8954015dad',1973,'GA','Gabon','communications',149,'Railroads: none
Highways: 3,820 mi.; 125 mi. paved, 1,960 mi. gravel or crushed stone, 1,425 mi.
improved earth, 310 mi. unimproved earth
Inland waterways: approximately 1,000 mi. perennially navigable
Pipelines: crude oil, 40 mi.
Ports: 3 major, 2 minor
Merchant marine: 1 bulk carrier (1,000 GRT or over) totaling 10,700 GRT,
15,500 DWT
Civil air: 11 major transport aircraft
Airfields: 187 total, 100 usable; 4 with permanent-surface runways; 2 with run-
way 8,000-11,999 ft., 16 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: fair telephone and telegraph services; good broadcast
coverage in vicinity of Libreville; 2 AM and 2 TV stations; 7,000 telephones;
90,000 radio receivers; 5,000 TV receivers
DEFENSE FORCES:
Military manpower: males 15-49, 128,000; 64,000 fit for military service;
5,000 reach military age (18) annually
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1972, $6,570,000; about
8.7% of total budget
116
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','1eca908ee4e13ee9d9d57d275d135ecb6505a2a1ae029aa9bc290fcf488400fb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00115dd0e9103e7ed64d033b8996590bbcb22ce339eea6d9644953d8849b5216',1973,'GM','Gambia','communications',150,'LAND:
4,000 sq. mi.; 25% uncultivated savanna, 16% swamps, 4%
forest parks, 55% upland cultivable areas, built-up
areas, etc.
Land boundaries: 460 mi.
WATER:
Limits of territorial waters (claimed): 50 n. mi.
(fishing, 18 n. mi.)
Coastline: 50 mi.
Railroads: none
Highways: 775 mi.; 185 mi. bituminous surface treated, 270 mi. gravel/laterite,
270 mi. unimproved earth
Inland waterways: 377 mi.
Ports: 1 major hs
Civil air: no major transport aircraft
Airfields: 4 total, 1 usable; 1 with permanent-surface runway; 7? with runway
4,000-7 ,999 ft.; 1 seaplane station
Telecommunications: good telephone and telegraph services; 1,700 telephones;
60,000 radio receivers; 2 AM, no FM or TV stations; 1 submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 92,000; 43,000 fit for military service
118
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GERMANY, EAST
“41,800 sq. mi.; 43% arable, 15% meadows and pasture, 27%
forested, 15% other
Land boundaries: 1,435 mi.
WATER: :
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 560 mi. (including islands)','3bf3f342df57b3f8b8a5c78bf5ef2a034295e9329c00d31376e7a312b31a28ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9c512d467ed70403e9b5f0add667791b2347d671f118fe22e8c079b2fdeaa4c',1973,'GH','Ghana','communications',154,'LAND:
92,000 sq. mi.; 19% agricultural, 60% forest and brush,
21% other
Land boundaries: 1,420 mi.
WATER:
Limits of territorial waters (claimed): 30 n. mi.
Coastline: 335 mi.
Railroads: none
Highways: 19 miles, all paved
Ports: 1 major
Civil air: 1 major transport aircraft (registered in U.K.)
Airfields: 1 permanent-surface runway, 4,000-7,999 ft.; 1 seaplane station
Telecommunications: international radiocommunication facilities; automatic
telephone system serving 6,100 telephones; 6,000 radio receivers; 6,870
television receivers; 1 AM, 1 FM, and 2 TV stations; 13 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, about 6,000; about 3,000 fit for military service
Defense is responsibility of United Kingdom
126
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ta
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
2 PINLAND J,','7f84680faa9c132f8f6d20c2b2c003aa9ad78b54184a7d322c695b3a6e59b4a7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49dc31dfcfd6ff538606f0cee0440301c5516033e0aa42efdeaa3830de25ff94',1973,'GR','Greece','communications',158,'AND: , POLAND
51,200 sq. mi.; 29% arable and land under permanent crops,
40% meadows and pastures, 20% forested, 11% wasteland,
urban, other
Land boundaries: 740 mi.
WATER: : :
Limits of territorial waters (claimed): 6 n. mi.
Coastline: 8,500 mi.
Railroads: 1,598 mi.; 969 mi. standard gage (4''8 1/2"), 597 mi. meter gage
(3''3 3/8"), 20 mi. 1''11 5/8" narrow gage, 10 mi. 2''5 1/2" narrow gage; all
government owned
Highways: 24,200 mi.; 7,100 mi. paved, 9,100 mi. crushed stone and gravel
4,800 mi. improved earth, 3,200 mi. unimproved earth
Inland waterways: system consists of 3 coastal canals and 3 unconnected rivers
which provide navigable length of just Tess than 50 mi.
Pipelines: crude oil, 16 mi., refined products, 340 mi.
Ports: 17 major, 37 minor
Merchant marine: 1,691 ships (1,000 GRT or over) totaling 18,148,300 GRT,
29,286,000 DWT; includes 69 passenger, 959 cargo, 285 tanker, 339 bulk, 39
specialized carrier; Ethnic Greeks also own an estimated 19,185,800 GRT
under other flags: about 16,054,300 under Liberia, 780,000 under Panama,
2,320,000 under Cyprus, 22,800 under Lebanon, and 8,700 under Somali Republic
Airfields: 63 total, 56 usable; 39 with permanent-surface runways; 17 with
runways 8,000-11,999 ft., 16 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 42 major transport aircraft
Telecommunications: adequate modern networks reach all areas on mainland and
tslands; 1.3 million telephones; 1.4 million radio receivers; 500,000 TV
receivers; 30 AM, 9 FM and 24 TV stations; 2 coaxtal submarine cables;
2 communications satellite ground stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,194,000; 1,765,000 fit for military service;
about 70,000 reach military age (21) annually
Military budget: for fiscal year ending 31 December 1972, $547 million; 23%
of central government budget
128
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','26ce333b25ad3a4335b563364b570b2ec884576a2e7f4e3e8950cb4e045d2d95','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84d238ff5d8e7142edf6dd62f0ec39c19b2489fdd895b6445af66e9b49123a95',1973,'GL','Greenland','communications',162,'LAND:
840,000 sq. mi.; less than 1% arable (of which only a
fraction cultivated), 84% permanent ice and snow,
15% other (1970)
WATER: nos
Limits of territorial waters (claimed): 3n. mi. (fishing,
12 n. mi.) onthe
Coastline: 27,400 mi. (approx., includes minor islands) Pa','167aba335e4f5c0dc43e1b2d0bfcea24bccffb79b12b11a3fd7276cb6cb49565','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d94979778754114737c02e9af7c85675e2a614a00adac07b670b935444299944',1973,'PE','Peru','communications',163,'PEOPLE: a.
Population: 50,000, average annual growth rate 3.3%
(1/66-1/71)
Ethnic divisions: 86% Greenlander (Eskimos and Greenland-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep breeding
GCVERNMENT :
Legal name: Greenland
Type: province of Kingdom of Denmark; 2 representatives in Danish parliament;
separate Minister for Greenland in the Danish cabinet
Capital: Godthaab (administrative center)
Political subdivisions: 3 counties, 19 communes
Legal system: Danish law; transformed from colony to province in 1953
Branches: legislative authority rests jointly with Crown and Danish parliament;
executive power vested in Crown, acting through provincial governor
responsible to Minister for Greenland; local affairs handled by provincial
council (Landsrad) subject to approval of provincial governor; 19 lower courts
Government leader: Queen Margrethe II; Governor N.O. Christensen
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years (next 1975)
Political parties: Inuit (advocating close ties with Denmark); Sukaq (moderate
socialist, advocating more distinct Greenland identity)
Railroads: none
Highways: none
Ports: 7 major, 16 minor
Civil air: 4 major transport aircraft
Airfields: 11 total, 8 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 7 seaplane stations
129
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Telecommunications: adequate domestic and international service provided by
cables and radio; 4,500 telephones; 7,200 radiobroadcast receivers; 5 AM,
2 FM, and 2 TV stations; 2 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, included with Denmark
130
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','212f66acab18f5c6da15c6efea5fc7637dba270c86a0a7cec8a6b44a9994fe35','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('206fdcb2ecb95a984b06a2347523152d407b66c532c511d840a2531dbf561a10',1973,'GD','Grenada','communications',165,'LAND:
133 sq. mi. (Grenada and southern Grenadines); 47%
cultivated, 3% pastures, 12% forests, 20% unused but
potentially productive, 18% built on, wasteland,
other
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 75 mi. BRAZIL
Railroads: none
Highways: 600 mi.; 380 mi. paved, 100 mi. gravel, crushed stone, or earth
surface; 120 mi. unimproved
Ports: 2 minor
131
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Civil air: no major transport aircraft
Airfields: 4 total, 3 usable; 1 with asphalt runway 5,000 ft.
Telecommunications: automatic, islandwide telephone system with 3,600 telephones;
VHF links to Trinidad and Carriacou; 18,000 radios and 100 TV receivers;
2 AM stations
132
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','a17b5ee11c4fc54c1b479084666ed02f7e3bcf06fd7099a2ab08cbfaef0e061a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bba40dc9ddb2af0c98d6fb3ad718275fc665ca4f1310f26b2854330efcb6d9db',1973,'GP','Guadeloupe','communications',169,'LAND:
687 sq. mi.; 25% cropland, 8% pasture, 19% forest, 48%
wasteland, built on; area consists of two islands
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 190 mi. COLOMBIA
PEOPLE: BRAZIL
Population: 342,000, average annual growth rate 1.5%
(7/70-7/71)
Ethnic divisions: 90% Negro or Mulatto, less than 5% East
Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force
GOV ERNMENT:
Legal name: Overseas Department of Guadeloupe
Type: overseas department of France; represented by 3 deputies in the French
National Assembly and 2 senators in the Senate
Capital: Basse-Terre
Political subdivisions: 3 arrondissements; 34 communes, each with a locally
elected municipal council
Legal system: French legal system; highest court is a court of appeal based
in Martinique with jurisdiction over Guadeloupe, French Guiana, and Martinique
Branches: executive, Prefect appointed by Paris; legislative, popularly elected
General Council of 36 members; judicial, under jurisdiction of French judicial
system
Government leader: Prefect Pierre Brunon
Suffrage: universal over age 21
Elections: General Council elections coincide with those for the French National
Assembly, normally every 5 years; last General Council election took place
in March 1973
Political parties and leaders: Union of Guadeloupean Democrats for the Republic
(UDG), Paul Gresse; Communist Party of Guadeloupe (PCG) Henri Bangou; Socialist
Party, leader unknown; Progressive Party of Guadeloupe (PPG), Henri Rodes;
Independent Republicans, leader unknown; Federation of the Left, leader unknown
Voting strength: PCG, 1 seat in French National Assembly; UDG, 2 seats;
(1968 election)
Communists: 2,000, 11,000 sympa thizers
re ee or pressure groups: Group of National Organization of Guadeloupe
GONG
Railroads: privately owned, narrow-gage plantation lines
Highways: 1,200 mi.; 780 mi. paved, 420 mi. gravel and earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
Civil air: 1 major transport
Airfields: 8 total, 7 usable, 5 with permanent-surface runways; 1 with runway
8,000-11,999 ft.; ] seaplane station
Telecommunications: domestic facilities inadequate; 17,400 telephones;
inter-island VHF radio links; 2 AM radio and 3 TY transmitters, with about
27,500 radio and 9,070 TV receivers
DEFENSE FORCES:
Military manpower: males 15-49, included with France
134
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','517173efb14a47e9cd94a32a3bdfe9c8bf6e97a654011340c146f37007222b53','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c853c4910d95e27fd39b71e5ac187e55d9a08791723bf708f3e1fbe9780deee',1973,'GT','Guatemala','communications',171,'LAND:
42,040 sq. mi.; 14% cultivated, 10% pasture, 57% forest,
19% other
Land boundaries: 1,010 mi.
COSTARICA 6ocs { %
f Nt VENEZUELA
© PANAMA
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 250 mi.
2 COLOMBIA
PEOPLE: Beate
Population: 5,729,000, average annual growth rate 2.8%
(current)
Ethnic divisions: 41.4% Indian, 58.6% Ladino (mestizo and
westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks an Indian language as
a primary tongue
Literacy: about 30%
Labor force: 1.5 million (1969); 63.2% agriculture, 12.4% manufacturing, 11.8%
services, 12.6% other, 2% unemployed; severe shortage of skilled labor;
oversupply of unskilled labor; of this total an estimated 10% are unemployed
at any one time
Organized labor: 5% of labor force (1970)
Railroads: 592 mi., 3''0" gage; single-tracked; 520 mi. government owned, 72 mi.
privately owned
Highways: 7,600 mi., 1,300 mi. bituminous, 4,200 mi. gravel, 2,190 mi. improved
or unimproved earth
Inland waterways: 164 mi. navigable year-round; additional 458 mi. navigable
during high-water season
Pipelines: crude oi], 30 mi.
Freight carried: rail (1960) -- 191.8 million ton/miles, 1.1 million tons
Ports: 2 major, 2 minor
Merchant marine: 3 cargo ships (1,000 GRT or over) totaling 5,700 GRT, 8,600 DWT
Airfields: 496 total, 329 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 18 with runways 4,000-7,999 ft., 1 seaplane station
Civil air: 11 major transport aircraft
Telecommunications: modern telecom facilities limited to Guatemala City;
44,000 telephones; est. 360,000 radio and 90,000 TV receivers, 82 AM, 20 FM,
and 3 TV stations; connection into Central American microwave net
DEFENSE FORCES:
Military manpower: males 15-49, 1,409,000; 719,000 fit for military service;
about 60,00C reach military age (18) annually
Military budget: proposed for fiscal year ending 31 December 1973, $20.6 million;
about 7% of central government budget
136
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
GUINEA 4 a.
LAND: i il LGERIA 2 LIBYA FEYET sau %
i. 95,000 sq. mi.; 3.3% cropland, 10% forest 5 waclioe RR ABIA
Land boundaries: 2,160 mi. ae
WATER:
Limits of territorial waters (claimed): 130 n. mi.
(fishing 12 n. mi.)
Coastline: 215 mi.
Railroads: 500 mi. meter gage, 5 mi. standard gage
Highways: 4,725 mi.; 465 mi. paved, 2,610 mi. all weather, 1,650 mi. unimproved
earth
Inland waterways: 1,115 mi.; 310 mi. navigable by small oceangoing vessels,
805 mi. navigable by shallow-draft steamers and barges
Ports: 1 major, 3 minor
Merchant marine: 1 bulk carrier (1,000 GRT or over) totaling 10,800 GRT,
15,300 DWT
Civil air: 6 major transport aircraft
Airfields: 20 total, 16 usable; 2 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 3 seaplane landing areas
Telecommunications: inadequate system of open-wire lines, small radio
communication stations, and 1 radio-relay link; principal center Conakry,
secondary center Kankan; 7,500 telephones; 100,000 radio receivers; 1 AM,
no FM, and no TV stations; 3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 971,000; 465,000 fit for military service
Military budget: for fiscal year ending 30 September 1970, $6,073,000; 8.0%
of total budget
138
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','2fcd7e73386585d26fc9b58d6ee3717e783ebc4d7f42417ab35c3ae7cd7c00b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4121f68fe4cebe3ade8bd97e1cec62c4f69df6abfe60b1d77201e2f6d18137f8',1973,'GY','Guyana','communications',175,'"83,000 sq. mi.; 1% cropland, 3% pasture, 8% savanna,
66% forested, 22% water, urban, and waste (1970)
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 285 mi.','2a3153637c57812f0b075ba99243f3f901888d1ae4ce6236eda844bf3a24804c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebee3c17e6214b3ae7a523154645b669d5d6df95edd233927f2fff7c82f24fa7',1973,'HN','Honduras','communications',180,'LAND:
43,300 sq. mi.; 27% forested, 30% pasture, 36% waste
and built-up, 7% cropland (1971)
Land boundaries: 950 mi.
WATER: be ae Ls) COLOMBIA
Limits of territorial waters (claimed): 12 n. mi. : ;
Coastline: 510 mi.','683c6db5a448318890d8d32917ef771bd73bdac9e056330e68dce988e142c63d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6946db115b6030ce7e8ec130362c2a58d8ad156f3bb66d945d74e261199edb8',1973,'HK','Hong Kong','communications',181,'LAND:
400 sq. mi.; 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country)
Land boundaries: 15 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 455 mi.
Railroads: 22 mi. standard gage; government owned
Highways: 600 mi.; 410 mi. paved, 190 mi. gravel and crushed stone, or earth
Freight carried: rail -- 903,180 short tons (FY68)
Ports: J major
Merchant marine: 35 ships (1,000 GRT or over) totaling 309,800 GRT, 476,500
DWT; includes 2 passenger, 19 cargo, 4 tanker, 8 bulk, 2 specialized
carrier; ships registered in Hong Kong fly the U.K. flag; over 500 Hong
Kong-owned ships are registered elsewhere
Civil air: 12 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.; 1 seaplane station
DEFENSE FORCES:
Military manpower: males 15-49, 1,054,000; 815,000 fit for military service;
about 48,000 reach military age (18) annually
Defense is the responsibility of U.K.
Ships: Hong Kong Marine Police, 38 police boats; U.K., U.K. naval ships homeported
in the U.K. operate in the Indian Ocean, Gulf, and Far East; they rotate
assignments within the area and normally one destroyer escort is deployed to
the Hong Kong area; a varied number of auxiliary/service craft are assigned
to the Commander Hong Kong
146
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','51bd4aa0b0a28b1e6a5d04d082352ca71c611ca659280ab93eb51c533c0f6e60','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bcfc90045781859eddc75c71fe38822ca968d2b13434c36b4d8b43c9c228a39',1973,'HU','Hungary','communications',185,'LAND:
35,900 sq. mi.; 60% arable, 14% other agricultural, 16%
forested, 10% other
Land boundaries: 1,395 mi.
Railroads: 5,275 route mi.; 4,465 mi. standard gage, 790 mi. narrow gage
(mostly 2'' 5 7/8"), 22 mi. broad gage (5''0"), 637 mi. double track, 580
mi. electrified; government owned (1971)
Highways: 18,360 mi.; 11,050 mi. paved, 6,560 mi. crushed stone or gravel, 755
mi. earth (1971)
Pipelines: crude oi], 500 mi.; refined products, 180 mi.; natural gas, over
1,500 mi.
Inland waterways: 1,320 mi. (1973)
Freight carried: rail -- 129.8 million short tons (1971), 14.0 billion short ton/mi.
(1971); highway -- 492.0 million short tons, 4.7 million short ton/mi. (1971);
waterway -- 15.4 million short tons, 1.9 billion short ton/mi. includes
international transit traffic (1971)
River ports: 2 principal (Budapest, Dunaujvaros); no maritime ports; outlets are
Rostock, East Germany and ports in Poland (1972)
Civil air: 17 major transport aircraft (1973)
Merchant marine: 19 cargo ships (1,000 GRT or over) totaling 43,000 GRT,
57,000 DWT
Airfields: 82 total; 13 with permanent-surface runways; 17 with runways 8,000-
11,999 ft., 20 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 2,659,000; 2,140,000 fit for military service;
about 90,000 reach military age (18) annually
148
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ICELAND ; GREENLAND ..
"39,750 sq. mi.; arable negligible, 22% meadows and
pastures, forested negligible, 78% other
WATER:
Limits of territorial waters (claimed): 4 n. mi. (fishing,
50 n. mi., effective 1 September 1972)
Coastline: 3,100 mi.
PEOPLE: a al
Population: 211,000, average annual growth rate 1.0%
(12/66-12/71)
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant and Roman Catholic, 2%
no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 85,000; 22.6% agriculture and fishing; 25.6% mining and manufacturing;
10.7% construction; 12.8% commerce; 7.8% transportation and communications;
15.2% services; and 4.0% other; unemployment is insignificant
Organized labor: 60% of labor force
Railroads: none
Highways: 7,400 mi.; 4,760 mi. crushed stone (including lava) and gravel, 2,593
mi. unsurfaced roads and motorable tracks, 47 mi. concrete (some bituminous
stretches)
Ports: 4 major, and about 50 minor
Merchant marine: 24 ships (1,000 GRT or over) totaling 54,200 GRT, 75,500 DWT;
includes 1 passenger, 21 cargo, 1 tanker, 1 specialized carrier
Civil air: 20 major transport aircraft
Airfields: 108 total, 93 usable; 4 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.; 5 seaplane stations
Telecommunications: adequate domestic service, wire and radio communication
system; 75,200 telephones; 75,000 radio and 44,000 TV receivers; 17 AM,
14 FM, and 73 TV stations; 2 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 50,000; 43,000 fit for military service (Iceland
has no conscription or compulsory military service)
150
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','e5cfbbf0da641c809a2544d2525c4249a575c4841b889f4f0216277c84c0356f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f84254521b8be020e9442e2a895367a37c3d6dceac9ae5e7066b6fe39b2c78aa',1973,'IN','India','communications',189,'LAND:
1,211,000 sq. mi. (includes Indian part of Jammu-
Kashmir, Sikkim, Goa, Damao and Diu); 50% arable,
5% permanent meadows and pastures, 20% desert,
waste, or urban, 22% forested, 3% inland water
Land boundaries: 7,880 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing,
12 n. mi.3; additional 100 mi. is fisheries conservation
zone, December 1968)
Coastline; 4,378 mi. (includes offshore islands)
Railroads: 37,281 mi.; 16,072 mi. meter (3''3 3/8") gage, 18,299 mi. broad gage,
2,781 mi. (2''6" and 2''0") narrow gage government owned; 129 mi. 2''6" and
2''0" gage privately owned; 6,933 mi. double track; 2,303 mi. electrified
Highways: 643,028 mi.; 106,854 mi. paved, 95,054 gravel or crushed stone, 184,631
improved earth, 256,489 mi. unimproved earth
Inland waterways: 8,750 mi.; 1,600 mi. navigable by river steamers
Ports: 7 major, 75 minor
Merchant Marine: 257 ships (1,000 GRT or over) totaling 2,718,800 GRT,
4,176,200 DWT; includes 3 passenger, 198 cargo, 12 tanker, 35 bulk, and
9 specialized carrier
Civil air: 116 major transport aircraft
Airfields: 619 total, 359 usable; 187 with permanent-surface runways; 2 with
runway over 12,000 ft., 49 with runways 8,000-11,999 ft., 130 with runways
4,000-7,999 ft.; 4 seaplane stations
Telecommunications: fair domestic telephone service where available; telegraph
facilities widespread; AM broadcast adequate; TV limited to Bombay, New Delhi,
and Srinagar; international radio communications adequate; 1,351,200 telephones;
13 million radio and 40,000 est. TV sets; about 270 AM stations at 75 locations,
3 TV stations, one earth satellite station; submarine cables extend to Malaysia,
Sri Lanka, and Aden
DEFENSE FORCES:
Military manpower: males 15-49, 138,212,000; 78,630,000 fit for military service;
about 6,214,000 reach military age (17) annually
152
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','d0a6ac08e5a35fb5aabbf3ecfc900abb2bd1f963a5d1a67843c2435a08b3a10d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d77e62b26f7ea9e99014a2134674ecede04b4998ba0cde3d73ccf8555066cac5',1973,'ID','Indonesia','communications',193,'LAND:
» 736,000 sq. mi.; 11% small holdings and estates, 64% for-
ests, 25% inland water, waste, urban, and other
Land boundaries: 1,700 mi.
WATER:
Limits of territorial waters (claimed): under an archipelago
theory, claim is 12 n. mi., measured seaward from
straight baselines connecting the outermost islands
Coastline: 34,000 mi.','3c2e4db13d9ae77740a31afed3c884ab0ce986ae35834379853d85abbd2b7e14','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56070823e9e7bb754c33811dbf12c9dec5ebc6bc60412fed5dc1741bfa7862a6',1973,'AU','Australia','communications',197,'Railroads: 4,364 mi.; 3,990 mi. 3''6" gage, 317 mi. 2''5 1/2" gage, 57 mi.
1''11 5/8" gage; 132 mi. double track; 74 mi. electrified; government owned
Highways: 57,460 mi.; 12,600 mi. paved, 25,200 mi. gravel or crushed stone,
19,660 mi. improved or unimproved earth
Inland waterways: 13,410 mi.; Sumatra 3,400 mi., Java and Madura 510 mi., Borneo
6,500 mi., Celebes 150 mi., and Irian Barat 2,850 mi.
Ports: 10 major, 63 minor
Merchant marine: 155 ships (1,000 GRT or over) totaling 497,700 GRT, 611,000
DWT; includes 8 passenger, 117 cargo, 14 tanker, 11 bulk, 5 specialized
carrier; includes ] naval tanker and 5 troop transports sometimes used
commercially; a small proportion of the fleet is in international trade;
in the domestic fleet about one-half are commercially inoperable because of
a chronic lack of spare parts and trained personnel
Civil air: 90 major transport aircraft (includes 2 leased)
Airfields: 351 total, 236 usable; 35 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 59 with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: extensive police net for interisland service; international
and domestic service fair but improving; radiobroadcast coverage adequate
but TV limited to Java only; 229,636 telephones; 3.5 million radio and 236,000
TV sets; AM stations at over 50 locations; 1 FM and 7 TV stations; 1 earth
satellite station on Java; 2 submarine cables to Singapore no longer in service
DEFENSE FORCES:
Military manpower: males 15-49, 28,900,000; 16,495,000 fit for military service;
about 1,480,000 reach military age (18) annually
154
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
i
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
TRAN
LAND:
636,000 sq. mi.; 14% agricultural, 11% forested, 16%
cultivable with adequate irrigation, 51% desert,
waste, or urban, 8% migratory grazing and other
Land boundaries: 3,305 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,980 mi., including islands, 420 mi.
Railroads: 2,373 mi. 4''8 1/2" gage, 57 mi. 5''6" gage
Highways: 26,535 mi.; 7,084 mi. paved, 12,943 mi. gravel and crushed stone,
6,508 mi. improved earth
Inland waterways: 565 mi., excluding the Caspian Sea, 64.6 mi. on the Shatt
al Arab
Pipelines: crude oi], 1,640 mi.; refined products, 2,235 mi.; natural gas,
1,440 mi.
Ports: 7 major, 6 minor
Merchant marine: 16 ships (1,000 GRT or over) totaling 158,400 GRT, 228,900 DWT;
includes 12 cargo, 4 tanker
Civil air: 18 major transport aircraft
Airfields: 236 total, 149 usable; 53 with permanent-surface runways; 7 with
runways over 12,000 ft., 15 with runways 8,000-11,999 ft., 52 with runways
4000-7 ,999 ft.
Telecommunications: advanced system of high-capacity radio-relay links, open-wire
lines, cables, and tropospheric links; principal center Teheran, secondary
centers Isfahan, Meshed, and Tabriz; 307,500 telephones; 1.8 million radio
and 260,000 TV receivers; 20 AM, 1 FM, and 9 TV stations; satellite earth
station
DEFENSE FORCES:
Military manpower: males 15-49, 7,364,000; 4,355,000 fit for military service;
about 317,000 reach military age (21) annually
Military budget: for fiscal year ending 20 March 1973, $1,323.7 million; about
16.8% of total budget
156
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: none
Highways: about 17 mi.; 13 mi. paved, 4 mi. improved earth
Inland waterways: none
Ports: 1 minor
Civil air: 1 major transport aircraft
Airfields: 1, coral-surfaced, 5,270 ft.
Telecommunications: adequate interisland and international radiocommunications
provided via Australian facilities; 525 telephones; 1 AM, but no TV or FM
radiobroadcasting facilities; number of radios unknown
231
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
DEFENSE FORCES:
Military manpower: males 15-49, about 1,800; fit for military service, about
950; average number reaching military age (18) annually, 1971-75, less
than 100
No formal defense structure and no regular armed forces
232
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: none
Highways: 2,900 mi.; 180 mi. paved; 1,170 mi. gravel, crushed stone, or stabilized
surface; 1,550 mi. unimproved earth
Iniand waterways: none
Ports: 1 major, 21 minor -
Civil air: no major transport aircraft
Airfields: 35 total, 30 usable; 2 with permanent-surface runways; 2 with
runways 4,000-7,999 ft.; 1 airfield over 8,000 ft.; 1 seaplane station
Telecommunications: 10,711 telephones; 26,000 radio and 11,000 TV sets; 1 AM,
no FM, and 1 TV stations
x
A
240
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 400 mi.
Railroads: none
Highways: 463 mi.; 293 mi. gravel or crushed stone, 170 mi. improved and
unimproved earth
Inland waterways: none
Ports: 1 minor ‘
Civil air: no major transport aircraft
Airfields: 14 total, 11 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: domestic and international radio stations used primarily
for administrative and military purposes; 1 low-power radiobroadcast station;
unreliable open-wire lines and 58 small manual switchboards serve about 689
telephones; 13,145 radio sets
4
%
4
+
274
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','ca3ad7c4fd7b912e723e193bb78bd1c933c7cb72a2d4450c8c91c31e5daf925e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7393a873e9d4a0020b6bcc18b7d18554a5ec67e3fecfcc5850e5e8236cb708ac',1973,'IQ','Iraq','communications',198,'LAND:
172,000 sq. mi.; 18% cultivated, 68% desert, waste, or
urban, 10% seasonal and other grazing land, 4% forest
and woodland
Land boundaries: 2,280 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 36 mi.
Railroads: 1,408 mi.; 698 mi. 4''8 1/2" gage, 710 mi. meter (3''3 3/8") gage;
10 mi. meter gage double track
Highways: 12,919 mi.; 4,033 mi. paved; 2,886 mi. crushed stone, gravel, or
improved earth; 6,000 mi. earth and sand tracks
Inland waterways: 635 mi.; Shatt al Arab navigable by maritime traffic for
about 65 mi.; Tigris and Euphrates navigable by shallow-draft steamers
Ports: 3 major
Pipelines: crude oi1, 1,660 mi.; 25 mi. refined products; 430 mi. natural gas
Merchant marine: 10 ships (1,000 GRT or over) totaling 133,500 GRT,203,100
DWT includes 6 cargo, 4 tanker
Civil air: 6 major transport aircraft
Airfields: 171 total, 73 usable; 21 with permanent-surface runways; 44 with
runways 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.
Telecommunications: fair international radiocommunication service; poor
domestic telephone and telegraph service; 120,000 telephones; 1.25 million
radio receivers; 350,000 TV receivers; 4 TV and 4 AM stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,348,000; 1,270,000 fit for military service;
about 121,000 reach military age (18) annually
Military budget: for fiscal year ending 31 March 1973, $450.4 million; 25.1% of
total budget
158
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
TRELAND
LAND:
26,600 sq. mi.; 17% arable, 51% meadows and pastures,
3% forested, 2% inland water, 27% waste and urban
Land boundaries: 224 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing,
12 n. mi.) ae
Coastline: 900 mi . Lgaerocco','6592aafe0548450396f79079c3352715fab1176f930fbe4b749c3c017ec566a9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58ff746c631c428178e5a4b61d05248f61e1699ab99ebbc612ffd3c923c19acc',1973,'IT','Italy','communications',202,'116,300 sq. mi.; 50% cultivated, 17% meadow and pasture,
21% forest, 3% unused but potentially productive,
9% waste or urban (1970)
Land boundaries: 1,058 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. (fishing,
12 n. mi.)
Coastline: 3,105 mi.','c3d62797a1675ea630a03a3a28a26bd4a814563bc45ec35cbebce570900c2167','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2f60de8910fb9f17287444c2751ab4ab8343afdba21ecaf53fac82ae65d9aaa',1973,'NL','Netherlands','communications',203,'Military budget: for fiscal year ending 31 December 1973, $23,500,000; about
7.2% of total operating budget
168
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
JAMATCA
LAND:
4,410 sq. mi.; 21% arable, 23% meadows and pastures, 19%
forested, 37% waste, urban, or other (1968)
WATER: psotianen rs
Limits of territorial waters (claimed): 12 n. mi. :
Coastline: 635 mi.
Railroads: 204 mi. government-owned, 43 mi. privately owned, all standard gage,
single track
Highways: 7,100 mi.; 1,200 mi. paved, 4,400 mi. gravel, 1,500 mi. unimproved
earth surfaces
Pipelines: refined products, 6 mi.
Ports: 1 major, 11 minor
Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 11,900 GRT, 10,500
DWT
Civil air: 5 major transport aircraft
Airfields: 48 total, 38 usable: 11 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 2 with runway 4,000-7,999 ft.; 3 seaplane stations
Teleconmunications: fully automatic domestic telephone network with 77,800
telephones; satellite ground station; 600,000 radio and 84,000 TV receivers;
8 AM, 7 FM, and 8 TV stations; 5 submarine cables, including 2 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 413,000; 277,000 fit for military service; no
conscription; average number currently reaching minimum volunteer age (18)
22,000
Supply: dependent on U.K. and U.S.
Military budget: for fiscal year ending 31 March 1973, $6.9 million; about 2.0%
of central government budget
170
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
LAND:
14,100 sq. mi.; 70% cultivated, 5% waste, 8% forested,
8% inland water, 9% other (1971)
Land boundaries: 635 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 280 mi.','05c7c0830e542d129db4034003c18cf69dd0b724527b193fbf6a2042f5342f2d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2810b00ccab58c372e8b8b1fdfbee66a460c9cf0a740b1bad1f904ceea08904',1973,'JO','Jordan','communications',207,'NOTE: The war between Israel and the Arab states in June 1967
ended with Israel in control of West Jordan. Although
approx. 930,000 persons resided in this area prior to the
start of the war, fewer than 750,000 of them remain there
under the Israeli occupation, the remainder having fled
to East Jordan. Over 14,000 of those who fled were
repatriated in August 1967, but their return has been
more than offset by other Arabs who have crossed and are
continuing to cross from West to East Jordan. These and
certain other effects of the Arab-Israeli war are not
included in the data below.
SUDAN is oe
LAND:
37,100 sq. mi. (including about 2,100 sq. mi. occupied by Israel); 11%
agricultural, 88% desert, waste, or urban, 1% forested
Land boundaries: 1,100 mi. (1967, 1,037 mi. excluding occupied areas)
WATER :
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 16 mi.
Railroads: 227 mi. 3''5 3/8" gage, single track
Highways: 4,400 mi.; 3,486 mi. bituminous, 249 mi. improved, 665 unimproved earth
(these mileages include approximately 670 mi. -- mostly bituminous -- of
Jordanian territory held by Israel)
Pipelines: crude oi1, 130 mi.
Ports: 1 major
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 6,000 GRT, 10,500 DWT
Civil air: 5 major transport aircraft
Airfields: 53 total, 18 usable; 10 with permanent-surface runways; 2 with
runways over 12,000 ft., 9 with runways 8,000-11,999 ft., 4 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate telecommunication system for the needs of the
country; 33,000 telephones; 300,000 radio and 132,000 TV receivers; 1 AM
and 1 TV stations; ] earth satellite station
DEFENSE FORCES:
Military manpower: males 15-49, 550,000; 415,000 fit for military service;
average number currently reaching military age (18) annually 29,000
174
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ln
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','875eac66283a11b98b976120b5af4750492fe43a970a115ba6aa096bdbd9f1f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1e823ce3b8aeb358e3f76c6f429824056c83628482b78116bc18b24bb9d24ab',1973,'KE','Kenya','communications',211,'LAND:
225,000 sq. mi.; about 21% forest and woodland, 13%
suitable for agriculture, 66% mainly grassland
adequate for grazing (1971)
Land boundaries: 2,093 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 333 mi.
Railroads: 1,275 mi.; meter gage
Highways: 25,787 mi.; 1,824 mi. paved, 3,728 mi. gravel, 7,745 mi. improved earth,
about 12,490 mi. unimproved earth
Inland waterways: part of Lake Victoria and Lake Rudolph are within boundaries
of Kenya
Ports: I major, 3 minor
Merchant marine: 7 ships (1,000 GRT or over) totaling 89,400 GRT, 158,600 DWT;
includes 3 cargo, 2 tanker, 2 specialized carrier
Civil air: 9 major transport aircraft
Airfields: 270 total, 214 usable; 6 with permanent-surface runways; 1 with
runway over 12,000 ft., 1 with runways 8,000-11,999 ft., 43 with runways
4,000-7,999 ft.; 3 seaplane stations
Telecommunications: in top group of African systems; consists of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Nairobi, secondary centers Mombasa and Nakuru; 85,200 telephones; 774,000
radio and 37,000 TV receivers; 5 AM, 2 FM, and 3 TV stations; 2 submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 2,770,000; 1,335,000 fit for military service;
no conscription
176
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
PEOPLE''S REP.
KOREA, NORTH eae
LAND:
y 47,000 sq. mi.; 17% arable and cultivated, 74% in forest,
scrub, and brush; remainder wasteland and urban
Land boundaries: 1,440 mi.
WATER:
Pr Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,550 mi.
Railroads: 2,818 route mi. operating in 1968; 2,137 mi. standard gage, 681] mi.
2''6" narrow gage; 99 mi. double tracked; about 588 mi. electrified; government
owned
Highways: about 12,600 mi., 95% gravel or earth surface
Inland waterways: 1,400 mi.; mostly navigable by small craft only
Freight carried (1969): rail -- 13 billion metric ton/km., 62 million metric
tons; highway -- 765 million metric ton/km., 116 million metric tons;
waterway -- 540 million metric ton/km., 7.7 million metric tons; coastal --
170 million metric ton/km., 0.4 million metric tons
Ports: 6 major, 26 minor
DEFENSE FORCES:
Military manpower: males 15-49, 3,457,000; 2,050,000 fit for military service;
174,000 reach military age (18) annually
178
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
PEOPLE''S REP.
KOREA, SOUTH OF CHINA
LAND:
38,000 sq. mi.; 23% arable (22% cultivated), 10% urban
and other, 67% forested
Land boundaries: 150 mi.
WATER:
Limits of territorial waters (claimed): 20-200 n. mi.
Coastline: 1,500 mi.
Railroads: 1,964 mi.; 1,887 mi. standard gage, 77 mi. (2''6") narrow gage; 280
mi. double track; government owned
Highways: 25,500 mi.; 1,845 mi. paved, 18,500 mi. gravel, 3,200 mi. improved
earth, 1,955 mi. unimproved earth
Inland waterways: 1,000 mi.; use restricted to small native craft
Freight carried: rail (1968) 4.5 billion short ton/mi., 30.4 million short
tons; highway 24 million short tons; air (1959) 796,260 Ibs. carried
Pipelines: 255 mi., refined products, under construction
Ports: 10 major, 18 minor
Merchant marine: 120 ships (1,000 GRT or over) totaling 830,200 GRT, 1,338,400
DWT; includes 83 cargo (includes 1 combination cargo-training), 22 tanker,
14 bulk, 10 specialized carrier
Civil air: 21 major transport aircraft
Airfields: 262 total, 127 usable; 52 with permanent-surface runways; 12 with
runways 8,000-11,999 ft., 15 with runways 4,000-7,999 ft.; 2 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,213,000; 5,200,000 fit for military service;
average number reaching military age (18) annually 345,000
180
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','ef8ad5b8fe23f13e394a4e02472e60a29bd8da1b5307c2f03c6b332f81fa95a1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f62c2b357571a68b4290e7341063caa447dd41c446a8027b089968a43e3f008',1973,'KW','Kuwait','communications',215,'LAND:
> 6,200 sq. mi. (excluding neutral zone but including islands);
insignificant amount forested; nearly all desert,
waste, or urban
Land boundaries: 285 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 310 mi.
Railroads: none
Highways: 1,550 mi.; 465 mi. bituminous; 1,085 mi. earth, sand, Tight gravel
Pipelines: crude oi], 255 mi.; refined products, 25 mi.; natural gas, 75 mi.
Ports: 2 major, 1 minor
Merchant marine: 35 ships (1,000 GRT or over), totaling 647,700 GRT, 1,091,800
DWT; includes 26 cargo, 6 tankers, 3 specialized carrier
Civil air: 5 major transport aircraft
Airfields: 13 total, 3 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: excellent international radiocommunications; adequate
domestic telecommunication facilities; 68,100 telephones; 200,000 radio
and 125,000 TV sets; 3 AM and 3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 338,000; about 185,000 fit for military
service
Military budget: for fiscal year ending 31 March 1973, $98,900,000; about 10.6%
of total recurrent budget
182
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
LAOS
91,430 sq. mi.; 7% agricultural, 60% forests, 33% urban,
waste, and other; except in very limited areas, soil
is very poor; most of forested area is not exploitable
Land boundaries: 2,700 mi.
Highways: about 9,200 mi. (including Communist-held areas); 500 mi. bituminous
or bituminous treated, 1,900 mi. gravel, crushed stone, or improved earth;
6,800 mi. unimproved earth and often impassable during rainy season
mid-May to mid-September
Inland waterways: about 2,850 mi., primarily Mekong and tributaries; 1,800
additional miles are sectionally navigable by craft drawing less than 1.5 ft.
Ports (river): 5 major, 4 minor
Airfields: 396 total, 129 usable; 7 with permanent-surface runways; 13 with
runways 4,000-7,999 ft., 1 with runway 8,000-11,999 ft.
Telecommunications: service to general public considered poor; radio network
provides generally erratic service to government users; poor international
service improved by radio relay link to Thailand; radiobroadcast
transmitters operate in a few towns; 1,936 telephones; 100,000 (est.) radio
receivers
DEFENSE FORCES:
Military manpower: males 15-49, 760,000; 405,000 fit for military service;
average number currently reaching usual military age (18) annually, 33,000;
no conscription age specified
Military budget: for fiscal year ending 30 June 1973, $16.9 million; about 45%
of proposed central government budget
184
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','5524534f73b7ebc00b6d216f68679d46a553db470739f43e9572614454712e90','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd505190c3ca67e426d0d590bd5719f4d0971546c8b4f8d83329144048650ed8',1973,'LB','Lebanon','communications',219,'LAND
TURKEY
“4,000 sq. mi.; 27% agricul tural land, 64% desert, waste,
or urban, 9% forested
Land boundaries: 285 mi.
WATER:
Limits of territorial waters (claimed): no specific claims
(fishing, 6n. mi. ARABIA
Coastline: 140 mi.
Highways: 5,133 mi.; 3,821 mi. paved, 342 mi. gravel and crushed stone, 373 mi.
improved earth, 597 mi. unimproved earth
Pipelines: crude oi1, 45 mi.
Ports: 3 major, 5 minor
Merchant marine: 37 ships (1,000 GRT or over) totaling 95,800 GRT, 140,200 DWT;
includes 35 cargo, 2 bulk: 10 ships are foreign owned and operated
Civil air: 26 major transport aircraft
Airfields: 11 total, 3 usable; 3 with permanent-surface runways; 3 with runways
&,000-11,999 ft.; 1 seaplane station
Telecommunications: excellent international telecommunication facilities include
satellite ground station; good domestic telephone and telegraph service;
192,000 telephones; 1.3 million radio and 320,000 TV receivers; 7 TV, 2 FM,
and 1 AM radiobroadcast stations; 1 submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 760,000; 405,000 fit for military service;
average of about 30,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1973, $75.5 million; about
22.0% of total budget
186
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','b5de08ecd052496763018793eae98ca27b21f01e235109e9a1bacc62ee0b9821','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb165b1b617748aa5f71810198a3f0bbe27c2e9f4e26672d7b016dfa23dee0f8',1973,'LS','Lesotho','communications',223,'LAND:
11,700 sq. mi.; 15% cultivable; largely mountainous
Land boundaries: 500 mi.
Railroads: 1 mi.; owned, Operated, and included in the statistics of the Republic
of South Africa
Highways: approx. 1,346 mi.; 107 mi. paved; 463 mi. crushed stone, gravel, or
stablized soil; 770 mi. improved or unimproved earth
Civil air: no major transport aircraft
Airfields: 37 total, 22 usable; 3 with runways 4,000-7,999 ft.
Telecommunications: system a modest one consisting of a few landlines, a smal]
radio-relay system, and minor radiocommunication stations; Maseru is the
center; 2,650 telephones; 10,100 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 200,000; fit for military service 100,000
None, police only
188
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
LIBERTA
LAND:
43,000 sq. mi.; 20% agricultural, 30% jungle and swamps,
40% forested, 10% unclassified
Land boundaries: 830 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 360 mi.
Railroads: 310 mi.; 220 mi. standard gage, 90 mi. narrow gage (3''6"); all lines
single track; rail systems owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
Highways: 4,950 mi.; 340 mi. bituminous treated; remainder improved and
unimproved laterite, gravel, and/or earth
Inland waterways: 230 mi. navigable
Ports: 3 major, 4 minor
Civil air: 2 major transport aircraft
Airfields: 69 total, 59 usable; 3 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone and telegraph limited; main center is Monrovia;
6,000 telephones; 250,000 radio and 7,000 TV receivers; 5 AM, no FM,
5 TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 395,000; 210,000 fit for military service;
no conscription
Military budget: for year ending 31 December 1972, $3,306,830; 4.6% of total
budget
190
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
a
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','cbd5a323d6692fc400dd87d4fb2acdb9216e68cb29b193bbe98891ada4c0bb25','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fc72e4cf614d1723ec9d2ecb78c56413d0137faf8cb34dac28c1c7692a45173',1973,'LY','Libya','communications',227,'"679,000 sq. mi.3 6% agricultural, 1% forested, 93%
desert, waste, or urban
Land boundaries: 2,700 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,100 mi.
Railroads: none
Highways: 8,915 mi.; 3,772 mi. bituminous or bituminous treated, 5,143
mi. improved and unimproved earth and gravel
Pipelines: crude oi1 1,520 mi.; natural gas 175 mi.; refined products 135 mi.;
liquid petroleum gas 135 mi.
Ports: 3 major, 6 minor
Merchant marine: 3 ships (1000 GRT or over) totaling 5,600 GRT, 8,800 DWT;
includes 2 cargo, 1 specialized carrier
Civil air: 6 major transport aircraft; an additional 30 major transports are
operated by external carriers engaged in charter work for several oi] companies
Airfields: 111 total, 81 usable; 14 with permanent-surface runways; 7 with runways
&,000-11,999 ft. 34 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: system is just within top one-third of African systems; con-
sists of radio-relay and tropospheric-scatter links, open-wire lines, and
radiocommunication stations; principal centers are Tripoli and Benghazi;
49,800 telephones; 225,000 radio and 12,500 TV receivers; 7 AM, 1 FM, and
2 TV stations; 3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 479,000; 280,000 fit for military service;
about 20,000 reach military age (17) annually; conscription now being
implemented
Military budget: announced for fiscal year ending 31 March 1973, $121,580 ,000;
17.3% of operating budget
192
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: 9,700 mi.; 6,430 mi. standard gage, 3,250 mi. narrow gage, 18 mi.
rie gage; 340 mi. electrified, 850 mi. double track; government owned
1972)
Highways: 48,000 mi.; 7,600 mi. paved; 16,300 mi. other improved surfaces,
24,100 mi. earth (1970)
Inland waterways: 1,445 mi. (1973)
Pipelines: crude oil, 1,600 mi.; refined products, 888 mi.; natural gas, 3,100
mi.
Freight carried: rail -- 198.9 million short tons, 31.7 billion short ton/mi.
(1971); highway -- 490 million short tons, 5.3 billion short ton/mi. (1971);
waterway -- 3.4 million short tons, .77 billion short ton/mi. (1970)
Ports: 4 major (Constanta, Galati, Braila, Mangalia), 4 minor (1973)
Merchant marine: 60 ships (1,000 GRT or over) totaling 406,000 GRT, 582,100
DWT; includes 1 passenger, 41 cargo, 3 tanker, 15 bulk
Civil air: 52 major transport aircraft (1973)
Airfields: 155 total; 25 with permanent-surface runways; 11 with runways 8,000-
11,999 ft.; 25 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 5,451,000; 4,575,000 fit for military service;
188,000 reach military age (20) annually
Supply: most military equipment and small naval ships imported from U.S.S.R.;
small arms, rocket launchers and ammunition, explosives, and chemical warfare
defensive materiel, medium trucks and jeeps, and small naval craft produced
locally
284
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','c1ae61a320a3c7e39337f601c3bd3abc4a008c9c4d01e915958ff5b5fa458d56','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2edf499bab612397b12818e20f004510024f500d035fc36e5bf3cf9036b0966',1973,'LI','Liechtenstein','communications',231,'LAND: or, [ED Cease ¢
He
REP,
“GERMANY »
FON
65 sq. mi.
Land boundaries: 47 mi.
Railroads: 9.94 mi. 4''8 1/2" gage, electrified; owned, operated, and included in
statistics of Austrian Federal Railways
Highways: no information on total mileage
Civil air: no major transport aircraft
Airfields: none
193
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Telecommunications: automatic telephone system serving about 11,600 telephones;
no broadcast facilities; 4,000 radio and 3,500 TV receivers (programed from
Switzerland)
DEFENSE FORCES:
Defense is responsibility of Switzerland
194
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
NORWAYLES','1f9261fe3e8651d8ab1186f900d8c85f7a19173bc5ad3261d45aad74764efef0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0d3b4e8c89a2ded521fc2dee3387d0530c4326315d55eb3bdab495694ef3ed1',1973,'LU','Luxembourg','communications',235,'LAND
é
: : FEO CC agt POLAND
1,000 sq. mi.; 25% arable, 27% meadows and pasture, 15% - Br Jaan cern
waste or urban, 33% forested, negligible amount of eabece| sa
inland water (1971) HUXEMBOUR
Land boundaries: 221 mi. ett
Railroads: 203 mi. standard gage; 100 mi. double track; 85 mi. electrified
Highways: 3,070 mi.; all paved
Pipelines: refined products, 30 mi.
Inland waterways: 23 mi.; Moselle River
Port: Mertert
Civil air: 10 major transport aircraft (includes 3 registered in Iceland)
Airfields: 2 total, 1 usable with permanent-surface runway 8,000-11,999 ft,
Telecommunications: adequate and efficient system; 124,600 telephones; 171,200
radiobroadcast receivers; 85,000 TY receivers; AM megawatt service of Radio
Luxembourg reaches most of Europe; 3 FM stations; 1 TV station with 6 relays
DEFENSE FORCES:
Military manpower: males 15-49, 79,000; 63,000 fit for military service; about
2,500 reach military age (19) annually
Military budget: for fiscal year ending 31 December 1972, $10.1 million; 3.0% of
central government budget
Supply: completely dependent on other NATO countries, primarily the U.S.
196
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','63ac1c348f6ed403e3cfc6704f04f84267f5a6e13ca448f459fdbd7cb38fed22','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('082a8664a6fddf3aa8d101edff81af27689338b3b603afdc88086b9b192b2483',1973,'MO','Macao','communications',239,'LAND:
" 6 sq. mi.; 10% agricultural, 90% urban
Land boundaries: 220 yds.
WATER:
Limits of territorial waters (claimed): 6 n. mis;
fishing, 12 n. mi.
Coastline: 25 mi.
Highways: 26 mi. paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
DEFENSE FORCES:
Military manpower: males 15-49, 69,000; 43,000 fit for military service
Defense is responsibility of Portugal
198
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','535d77d5e7e6669eac213ea08f284f39218db971261d62fa2fa091dddce65029','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c479af97b61d6f19c69ee304da41cc94964a21642b7c1d2df1fdfacda4768a1',1973,'MG','Madagascar','communications',243,'LAND:
230,000 sq. mi.; 5% cultivated, 58% pastureland, 21%
Gaae 8% wasteland, 2% rivers and lakes, 6% other
197]
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 3,000 mi.
Railroads: 549 mi. of meter gage
Highways: 5,300 mi.; 1,875 mi. paved, 2,225 mi. crushed stone, gravel, or stabi-
lized soil; 1,200 mi. improved and unimproved earth; remainder are tracks
Inland waterways: 1,200 mi. navigable; Lac Alaotra (200 sq. mi.)
Ports: 4 major, 9 minor
Civil air: 10 major transport aircraft
Airfields: 366 total, 150 usable; 25 with permanent-surface runways; 3 with run-
ways 8,000-11,999 ft., 47 with runways 4,000-7,999 ft.; 6 seaplane stations
Telecommunications: system above African average; includes open wire-lines, some
radio-relay and coaxial links and a communication satellite ground station;
28,200 telephones; 501,000 radio and 5,000 TV receivers; 1 AM, no FM, and
] TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,632,000; 960,000 fit for military service;
average number reaching military age (20) annually about 75,000
Supply: largely dependent on France; has received some ground force materiel
from Israel and West Germany
200
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','1960e6e7f9a3b1d7471de5d70e29bb9dac41f8742a9dca8f503dfc0b2d78ab56','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c08db97dda8c8812e0317aedd67bd2377da054e2da923e5d0abe96a2827b0dc8',1973,'MW','Malawi','communications',247,'Af. TURKEY a
LAND: “KALGERIA ) LIBYA ESV or
36,700 sq. mi.; about 31% of land area arable (of which :
less than half is cultivated), nearly 25% forested,
6% meadow and pasture, 38% other (1971)
Land boundaries: 1,790 mi.
Railroads: 352 mi. (3''6" gage)
Highways: 6,610 mi.; 580 mi. paved; 500 mi. crushed stone, gravel, or stabilized
soil; 5,530 mi. earth
Inland waterways: Lake Nyasa (Lake Malawi), 800 route mi. and Shire River, 90 mi.
Ports: 2 minor
Civil air: 5 major transport aircraft
Airfields: 42 total, 40 usable; 1 with permanent-surface runway; 7 with
runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: the system is barely above average for African countries
and consists of thinly spread open-wire lines, radio-relay links, and
radiocommunication stations; principal centers are Blantyre and Zomba;
13,800 telephones; 110,000 radio receivers; 5 AM, 4 FM and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 995,000; about 502,000 fit for military service
202
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','fa6e74b17dd89fbf861de8d282f6fa1010b98b8fa622bdaddfc5c014512128ff','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74fd494067ae07b5122b8236a22425a54e99fd39a90bb6377b6aa43971371f68',1973,'MY','Malaysia','communications',251,'NOTE:
Malaysia, which came into being on 16 September 1963,
consists of West Malaysia, which includes 11 states
of the former Federation of Malaya, plus East
Malaysia, which includes the 2 former colonies of
North Borneo (renamed Sabah) and Sarawak
LAND:
West Malaysia: 50,700 sq. mi.; 20% cultivated, 26%
forest reserves, 54% other
Sabah: 29,400 sq. mi.; 13% cultivated, 34% forest
reserves, 53% other
Sarawak: 48,300 sq. mi.; 21% cultivated, 24% forest
reserves, 55% other
Land boundaries: West Malaysia 315 mi., East Malaysia 1,110 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: West Malaysia, 1,285 mi., East Malaysia 1,620 mi.
Railroads:
West Malaysia: 1,014 mi. 3''3 3/8" gage; 8 mi. double track; government-owned
East Malaysia: 96 mi. meter gage in Sabah
Highways:
West Malaysia: 10,500 mi.; 8,925 mi. hard surfaced (mostly bituminous surface
treatment), 1,150 mi. crushed stone/gravel, 425 mi. improved or unimproved
ear th
East Malaysia: about 3,140 mi. (1,608 in Sarawak, 1,532 in Sabah); 520 mi.
hard surfaced (mostly bituminous surface treatment), 1,853 mi. gravel or
crushed stone, 767 mi. earth
Inland waterways:
West Malaysia: 1,985 mi.
East Malaysia: 2,540 mi. (975 mi. in Sabah, 1,565 mi. in Sarawak)
Ports:
West Malaysia: 3 major, 10 minor
East Malaysia: 4 major, 7 minor (3 major, 3 minor in Sabah; 1 major, 4 minor
in Sarawak)
Merchant marine: 16 ships (1,000 GRT or over) totaling 158,400 GRT, 190,500 DUT;
includes 12 cargo, 1 tanker, 2 bulk, 1 specialized carrier
Civil air: 16 major transport aircraft (including 1 Boeing 707 leased from U.K.)
Pipelines: crude of], 90 mi.; refined products, 35 mi.
Airfields:
West Malaysia: 106 total, 70 usable; 16 with permanent-surface runways;
2 with runways 8,000-11,999 ft., 12 with runways 4,000-7,999 ft.; 3
seaplane stations
Sabah: 39 total, 34 usable; 5 with permanent-surface runways; 5 with runways
4,000-7 ,999 ft.; 3 seaplane stations
Sarawak: 52 total, 47 usable; 5 with permanent~surface runways; 4 with
runways 4,000-7,999 ft.
Telecommunications:
West Malaysia: good intercity service provided mainly by microwave relay;
international service good; good coverage by radio and television broad-
casts; 163,897 telephones; 430,000 radio and 240,000 TV receivers; 9 towns
have AM stations; no FM, 14 TV stations; submarine cables extend to India,
Ceylon, and Singapore; connected to SEACOM submarine cable terminal at
Singapore by microwave relay
206
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Telecommunications (cont''d):
Sabah: adequate intercity radio-relay network extends to Sarawak via Brunei;
10,246 telephones; 60,000 radio receivers; 2,000 TV receivers; 6 AM, 1 FM,
5 TV stations; SEACOM submarine cable links to Hong Kong and Singapore
Sarawak: adequate intercity radio-relay network extends to Sabah via Brunei;
15,040 telephones; 75,000 radio and no TV receivers; 2 AM, no FM, no TV
stations
DEFENSE FORCES:
Military manpower: West Malaysia: males 15-49, 2,215,000; 1,403,000 fit for
military service; Sabah: males 15-49, 169,000; 100,000 fit for military
service; Sarawak: males 15-49, 248,000; 147,000 fit for military service;
conscription age for Malaysia is 21 -- an age reached by about 112,000
annually
External defense dependent on loose Five Power Defense Agreement (FPDA) which
replaced Anglo-Malayan Defense Agreement of 1957 as amended in 1963; FPDA,
effective as of 1 November 1971, also provides for small ANZUK Joint Force
composed of Australia, New Zealand, and U.K. ground, naval, and air elements,
headquarters in Singapore
Military budget: for fiscal year ending 31 December 1973, $272.1 million; 14.7%
of central government budget
207
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','036eb192f0ce5d227941445b047eab1be348388541623502c9f357e7b5fa6f80','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83163a6ab1e981e043d788f385409bf7e40ded8a894deb27788c959d0b8bc8dc',1973,'MV','Maldives','communications',254,'LAND:
115 sq. mi.; 2,000 islands grouped into 12 atolls, about
220 islands inhabited
WATER:
Limits of territorial waters (claimed): the land and
sea between latitudes 7°9''N. and 0°45''S. and between
longitudes 72°30''E. and 73°48''E; these coordinates
form a rectangle of approximately 37,000 sq. n. mi.
Coastline: 400 mi. (approx.)
Railroads: none
Highways: none
Ports: 2 minor ports (Male and Gan)
Civil air: no major transport aircraft
209
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Airfields: 3 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: minimal domestic and international telecommunication
facilities; 300 telephones; 2,000 radio sets; 1 AM station
210
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
MALT
LAND:
465,000 sq. mi.; only about a fourth of area arable,
forests negligible, rest sparse pasture or desert
Land boundaries: 4,635 mi.','a743be0900ce46da0005d45ceb57125bc6808f197baa61706a3628b51106275c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55eb816f43365134bd2764056d0d854175f578575721c9034b2266399c64c2a2',1973,'CN','China','communications',259,'Railroads: 400 mi. meter gage
Highways: approximately 7,500 mi.; 870 mi. bituminous, 3,215 mi. gravel, 580 mi.
improved earth, 2,835 mi. unimproved earth
Inland waterways: 1,141 mi. navigable
Civil air: 5 major transport aircraft
Airfields: 55 total, 38 usable, 6 with permanent-surface runways; 2 with runway
8,000-11,999 ft., 11 with runways 4,000-7,999 ft.
Telecommunications: system poor and provides only minimum service to government,
business, and public; open-wire and radiocommunication used for long distance
telecommunications; radio sometimes only link to outlying points; 6,670
telephones; 75,000 radio receivers; 2 AM, no FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,267,000; 715,000 fit for military service;
no conscription
Military budget: for fiscal year ending 31 December 1972, $8,369,000; about 16.6%
of total budget
212
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
MALTA a ImaLy
LAND:
121 sq. mi.; 45% agricultural, negligible amount forested,
remainder urban, waste, or other 11965)
WATER:
Limits of territorial waters (claimed): 6 n. mi.
Coastline: 87 mi.
Highways: 760 mi., 650 mi. paved (asphalt), 80 mi. crushed stone or gravel,
30 mi. improved and unimproved earth
Ports: 1 major, 2 minor
Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 3,600 GRT, 4,200 DUT;
Civil air: no major transport aircraft
Airfields: 4 total, all usable; 4 with permanent-surface runways; 3 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: modern automatic telephone system centered in Valletta;
45,000 telephones; 80,000 radio receivers (including 60,000 wired sets);
66,000 television receivers; 4 AM, 2 FM, and 1 TV stations; 8 submarine cables,
including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 87,000; 65,000 fit for military service
Military budget: for fiscal year ending 31 March 1973, $1,740,000; about 1.4% of
central government budget
214
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
MART INIQUE
LAND:
a 425 sq. mi.; 31% cropland, 16% pasture, 29% forest, 24%
wasteland, built on
WATER:
Limits of territorial waters (claimed): 12 n. mi.
¥ Coastline: 180 mi.
PEOPLE: ae BRAZIL
Population: 352,000, average annual growth rate 1.6% PERO
(7/66-7/71)
Ethnic divisions: 90% African and African-Caucasian-Indian
mixture, less than 5% East Indian Lebanese, Chinese,
5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public services, 11% construction
and public works, 10% commerce and banking, 10% services, 9% industry, 17%
other
Organized labor: 17% of labor force
Railroads: none
Highways: 1,100 mi.; 600 mi. paved, 500 mi. gravel and earth
Ports: 1 major (Fort-de-France), 5 minor
Civil air: no major transport
Airfields: 2 usable; 1 with permanent-surface runway; 1 with runway 8,000-11,999
ft; 1 seaplane station
Telecommunications: domestic facilities inadequate; 19,500 telephones, inter-island
VHF radio links; satellite earth station; 1 AM, 1 FM,
and 5 TV stations; about 33,000 radio and 11,800 TV receivers
DEFENSE FORCES:
Military manpower: males 15-49, included in France
Defense is responsibility of France; data are for French military forces
216
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','2fe70571daf0ee03a9aa3c35f7af26dd24b2e720b9ce50da705dbb8bcbc73b47','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ff8e093fc6026f33e8589d95fc4d0160b20491d4b865b159bafac4f7563d0a1',1973,'MR','Mauritania','communications',262,'LAND:
419,000 sq. mi.; Tess than 1% suitable for crops, 10%
pasture, 90% desert
Land boundaries: 3,180 mi.
WATER:
Limits of territorial waters (claimed): 30 n. mi.
(fishing, 6 n.« mi. exclusive rights, 6 n. mi.
contiguous zone)
Coastline: 490 mi.
Railroads: 400 mi. standard gage, single track, privately owned
Highways: 3,785 mi.; 285 mi. paved; 435 mi. gravel, crushed stone, or otherwise
improved; 3,065 mi. unimproved
Inland waterways: 500 mi.
Ports: 3 major
Civil air: 5 major transport aircraft
Airfields: 40 total, 29 usable; 9 with permanent-surface runways; 16 with run-
ways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone poor, telegraph fair; 1,300 telephones; 80,000
radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 273,000; 135,000 fit for military service;
conscription law not implemented
Supply: primarily dependent on France
Military budget: for fiscal year ending 31 December 1972, $6,117,600; 15.4%
of total budget
218
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','223fb0239e013b26dbe8f35a43aa41b19e57f6ac0b3596b14a1343f1c93ddc07','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a5d3563faa345026feb3adc2019e98a70812c4e8b67095348550a405ddd0ef6',1973,'MU','Mauritius','communications',266,'LAND:
. 720 sq. mi. (excluding dependencies); 50% agricultural, in-
tensely cultivated; 39% forests, woodlands, mountains,
river, and natural reserves; 3% built-up areas; 5%
water bodies, 2% roads and tracks, 1% permanent
wastelands (1971)
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 110 mi.
Highways: 1,100 mi.; 990 mi. paved, 110 mi. earth
Civil air: no major transport aircraft
Ports: 1 major, 2 minor
Merchant marine: 3 cargo ships (1,000 GRT or over) totaling 20,200 GRT,
29,700 DWT
Airfields: 6 total, 5 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft.
Telecommunications: 19,100 telephones; radio telegraph service with Reunion,
Malagasy Republic, Seychelles, Zanzibar, and other places in Africa; 1 AM,
no FM, and 4 TV stations; 160,000 radio and 23,300 TV sets; submarine cables
extend to Republic of South Africa and Seychelles Islands
DEFENSE FORCES:
Military manpower: males 15-49, 205,000; 100,000 fit for military service
Military budget: for fiscal year 1972-73, $3,999,400 (combined military and internal
security); 6.6% of total budget
220
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
NORWAY. 2
MONACO : : . : een foe
LAND: iia
0.6 sq. mi. ree GERMANY)
Land boundaries: 2.3 mi. :
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing
12 n. mi.)
Coastline: 2.6 mi.
Railroads: 1 mi. (see France)
Highways: none; city streets
Ports: 1 minor
Merchant marine: 3 tankers (1,000 GRT or over) totaling 26,600 GRT, 40,400 DWT
Civil air: no major aircraft
Airfields: none
223
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Teleconmunications: served by the French wire communications system; automatic
telephone system with about 16,600 telephones; international AM broadcast;
FM and TV facilities; 10,500 radio and 16,000 TV receivers
DEFENSE FORCES: ‘
France responsible for defense
224
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
MONGOL IA
604,100 sq. mi.; almost 90% of land area is pasture or
desert wasteland, varying in usefulness, less than
1% arable, 10% forested
Land boundaries: 4,975 mi.
Railroads: 1,130 route mi.; 885 mi. broad gage (5''0") (1972)
Inland waterways: 585 mi. navigable; used primarily for local transport (1972)
Freight carried: rail -- 5.1 million short tons, 1,046 million short ton mi.
(1972); highway -- about 10 million short tons (1970); 415.1 million short
ton/mi. (1970); waterway -- 2.5 million short ton/mi. (1970)
Airfields: 41 total; 5 with permanent-surface runways; 24 with runways 8,000-
12,999 ft., 11 with runways 4,000-7,999 ft., 6 additional airfields under
4,000 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 298,000; 195,000 fit for military service;
average number reaching military age (18) annually, about 15,000
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 31 December 1969, 141.7 million tugriks,
7% of total budget; value in dollars $33 million (est.)
226
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','b0ba9437ee40ced94ad844ff5a55c539152108b1a38639248018746a0a231347','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('662e81680faa54b3d0981522a10649a818ac192cb715078d8e6872f5c4cac80a',1973,'MA','Morocco','communications',270,'D:
: 158,100 sq. mi.; about 32% arable and grazing Jand,
17% forest and esparto, 51% desert, waste, and urban
Land boundaries: 1,240 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
* (fishing, 70 n. mi.)
Coastline: 1,140 mi.
Railroads: 1,100 mi. standard gage, 93 mi. double track; 493 mi. electrified
Pipelines: crude oi1, 85 mi.; refined products, 305 mi.; natural gas, 70 mi.
Ports: 8 major (including Spanish-controlled Ceuta and Mellila), 11 minor
Merchant marine: 18 ships (1,000 GRT or over) totaling 45,300 GRT, 61,900 DWT;
includes 17 cargo, 1 specialized carrier
Civil air: 10 major transport aircraft
Airfields: 141 total, 83 usable; 24 with permanent-surface runways; 2 with
runways over 12,000 ft., 10 with runways 8,000-11,999 ft., 37 with runways
4,000-7 ,999 ft.; 4 seaplane stations
Telecommunications: superior system by African standards composed of open-wire
lines, coaxial, multiconductor and submarine cables and radio-relay links;
principal centers Casablanca and Rabat, secondary centers Fes, Marrakech,
Qujda, Sebaa Aioun, Tangier and Tetouan; 171,500 telephones; 1.5 million radio
and 225,000 TV receivers; 24 Moroccan AM, 1 Voice of America AM, 3 FM, 17 TV
stations; 11 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,879,000; 2,640,000 fit for military service;
about 180,000 reach military age (18) annually; limited conscription
Military budget: for fiscal year ending 31 December 1973, $133.3 million; 10.8%
of total budget
228
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','8ddf1374f692052ae1d2d535c5dd3540f407929e7a336eac9233884ef0c12379','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc976638f3b0bde43eff0d4279642382b615fbbdd738bf14dd15dd47cd93efd8',1973,'MZ','Mozambique','communications',274,'LAND:
303,769 sq. mi.; 30% arable, of which 1% cultivated, 56%
woodland and forest, 14% wasteland and inland water
Land boundaries: 2,875 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,535 mi.','e11439df707a9c02788b29db82496c633f44a5f56f365f73c0bb84669b6f92be','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7a2a20ca46f752f5a172b77928255e14bd9cfb3b1fd5301901c21bf53b33612',1973,'ZM','Zambia','communications',277,'Railroads: 1,965 mi.; 1,877 mi. 3''6" gage (6 mi. double track), 88 mi. 2''5 1/2"
gage
Highways: 20,000 mi.; 1,740 mi. paved; 18,260 other (mostly earth)
Inland waterways: approx. 2,330 mi. of navigable routes
Pipelines: crude oil, 190 mi.
Ports: 3 major, 2 significant minor
Civil air: 12 major transport aircraft
Airfields: 350 total, 307 usable: 18 with permanent-surface runways; 4 with run-
ways 8,000-11,999 ft., 33 with runways 4,000-7 ,999 ft.; 5 seaplane stations
Telecommunications: above African average system of open-wire lines,
radiocommunication stations, and radio-relay and tropospheric-scatter links;
principal center Lourenco Marques, secondary centers Beira, Nampula, and
Quelimane; 30,300 telephones; 110,000 radio receivers; 9 AM, 2 FM, and no
TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,117,000; 1,020,000 fit for military service ra
Defense is responsibility of Portugal]
Military budget: for fiscal year ending 31 December 1973, $41.6 million; about
11.3% of national budget
230
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ND:
288,000 sq. mi.; 5% under cultivation, 5% arable, 10%
grazing, 13% dense forest, 6% marsh, 61% scattered
trees and grassland
Land boundaries: 3,730 mi.
Railroads: 664 mi., government owned, all narrow gage (3''6"); 8 mi. double track
Highways: 21,220 mi.; 1,600 mi. paved, 3,020 mi. crushed stone, gravel, or
stabilized soil; 16,600 mi. improved and unimproved earth .
Iniand waterways: 1,409 mi. including Zambezi River, Luapula River, Lake Kariba,
Lake Bangweulu, Lake Tanganyika; principal port on Lake Tanganyika is Mpulungu
Pipelines: 450 mi. refined
Civil air: 10 major transport aircraft
Airfields: 194 total, 163 usable; 8 with permanent-surface runways; 1 with
runway over 12,000 ft., 1 with runway 8,000-11,999 ft., 22 with runways
4,000-7,999 ft.
Telecommunications: all services being modernized and increased; presently
adequate but must be expanded to permit growth; high-capacity wire and
radio relay connect centers of Kitwe in northern mining region and Lusaka
along axial north-south route; 56,800 telephones; 100,000 radio and
20,000 TV receivers; 4 AM, 1 FM, and 2 TV stations ,
DEFENSE FORCES:
Military manpower: males 15-49, 1,081,000; 520,000 fit for military service
Military budget: for fiscal year ending 31 December 1972, $70,000,000; about
10% of total budget c
te
378
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
~?
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','8a4218fd889ed7f901734f1768e5309c4c6e6e1025a2869d4e10c4d447a1a1a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca91fa552358083076131e898ce3f623fc50709c8a612ca54bb45d3bd5bf66e4',1973,'NR','Nauru','communications',278,'LAND:
8.2 sq. mi.3; insignificant arable land, no urban areas,
extensive phosphate mines
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 15 mi.','c8cfb7305087703f0aa96623319812cc792d52495e66386b92df97a6550c6bbf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9c726510a40e04309b7f8da738a94d9b31b256f9a6ab045f65447db98971611',1973,'NP','Nepal','communications',279,'LAND:
54,600 sq. mi.; 16% agricultural area, 14% permanent meadows
and pastures, 38% alpine land (unarable), waste, or
urban; 32% forested
Land boundaries: 1,720 mi.
Railroads: 105 mi., all narrow gage (2''6"); mostly government owned; all in Terai
close to Indian border; only 33 mi. sector from border to Bizalpura presently
in use; a 28 mi. segment has been abandoned and 44 mi. utilized to transport
rock from quarry near Dharau to Kosi Dam near Rajbiras
Highways: 1,686 mi.; 510 mi. paved, 270 mi. gravel or crushed stone, 906 mi.
improved and unimproved earth, 200 mi. of seasonally motorable tracks
Civil air: 7 major transport aircraft
Airfields: 47 total, 43 usable; 4 with permanent-surface runways; 6 with runways
4,000-7,999 ft.
Telecommunications: poor telephone and telegraph service; good radiocommunication
and broadcast service; international radiocommunication service is poor;
7,071 telephones, 100,000 radio and no TV sets, 2 AM, no FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 3,108,000; 1,510,000 fit for military service;
140,000 reach military age (17) annually
234
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','d54335e78c0e184d883f85b91b99dfefa177f2854035e46ce76f4f5c57ca3b6d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b10a732a01533b4e7ae9eea26abedf1395ebd4f745129bc004da421131e3bc7',1973,'NC','New Caledonia','communications',282,'LAND:
8,500 sq. mi.; 6% cultivable, 22% pasture land, 15% forests,
57% waste or other
WATER :
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 3 n. mi.)
a Coastline: 1,400 mi.','3643e92f703a6022d7f9574976dc89193d0ccc07a38279ec4b99ead6888c0f70','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1e4348232f060f395db6097fe1aaac3834bc88eb29960f0cb07c6661aec4a64',1973,'NI','Nicaragua','communications',283,'"57,100 sq. mi.; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other
Land boundaries: 760 mi.
COSTA RICA 22) ey
ork
PANAMA?
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 200 n. mi.)
Coastline: 565 mi.
Railroads: 220 mi.; 200 mi. of 3''6" gage, government owned; 20 mi. narrow gage,
privately owned
Highways: 8,750 mi.; 800 mi. paved, 3,250 mi. otherwise improved, 4,700 mi.
unimproved
Inland waterways: 1,380 mi., including 2 large lakes
Pipelines: crude oi1, 40 mi.
Ports: 4 major, 6 minor
Merchant marine: 8 cargo ships (1,000 GRT or over) totaling 18,300 GRT,
26,000 DWI; includes 7 cargo, 1 tanker
Civil air: 13 major transport aircraft
Airfields: 468 total, 419 usable; 6 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 8 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: low-capacity wire network; connection into Central American
microwave net; satellite ground station; 26,500 telephones; est. 700,000
radio and 60,000 TV receivers; 80 AM, 30 FM, and 6 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 498,000; 295,000 fit for military service;
23,000 reach military age (18) annually
Supply: dependent primarily upon U.S.; has purchased aircraft from Israel
Military budget: for fiscal year ending 31 December 1972, $8.8 million for the
Ministry of Defense, including civil functions (e.g., police and civil air);
8.3% of central government budget
244
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','f75274f68285c972135aa831a4cf8e98fdd7a92ed14a48a871c34d1e7cb24452','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ce9b7e17044d544a93287bff79c91c07747bad952e761569817ffdf64575c0e',1973,'NE','Niger','communications',287,'ALGERIA ) LIBYA |EGYRI.
ND: (savor
489,000 sq. mi.; about 3% cultivated, perhaps 20% somewhat a> x
arable, remainder desert 3 supan f oat
Land boundaries: 3,570 mi.
Railroads: none
Highways: approx. 4,335 mi.; 375 mi. bituminous, 1,820 mi. gravel, 2,140 mi.
unimproved earth
Inland waterways: Niger River navigable 185 miles from Niamey to Gaya on the
Dahomey frontier from mid-December through March
Ports: Niger landlocked; outlet to sea is Cotonou, Dahomey
Civil air: 5 major transport aircraft
Airfields: 74 total, 58 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 15 with runways 4,000-7,999 ft.
Telecommunications: principal telecommunication center Niamey; telephone poor,
telegraph fair, 3,300 telephones; 100,000 radio and 500 TV receivers; 4 AM,
no FM, and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,029,000; 580,000 fit for military service;
about 43,000 reach military age (18) annually
Military budget: for fiscal year ending 30 September 1973, $6,376,400; 10.4%
af total budget
246
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','523e5a8a6791e39903e730e45be7a0136d02b8104ffdcefeb6766d113d5e91fe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37bee097a8b1bc410756d359c13adccddafce4ace9c4c1a7f9fdb7dd8b38dd06',1973,'NG','Nigeria','communications',291,'LAND:
357,000 sq. mi.; 24% arable (13% of total land area
under cultivation), 35% forested, 41% desert, waste,
urban, or other
Land boundaries: 2,507 mi.
WATER:
Limits of territorial waters (claimed): 30 n. mi.
Coastline: 530 mi.
Railroads: 2,180 route mi.; 3''6" gage
Highways: 55,400 mi.; 9,500 mi. paved (mostly bituminous surface treatment);
45,925 mi. laterite, gravel, crushed stone, improved earth
Inland waterways: 5,330 mi. consisting of Niger and Benue rivers and smaller
rivers and creeks; additionally, the newly formed Kainji Lake has several
hundred miles of navigable lake routes
Pipelines: crude oi], 580 mi.; natural gas, 40 mi.; refined products, 3 mi.
Ports: 2 major, 10 minor
Merchant marine: 14 cargo ships (1,000 GRT or over) totaling 92,400 GRT,
132,800 DWT
Civil air: 10 major transport aircraft
Airfields: 91 total, 78 usable; 12 with permanent-surface runways; 5 with runways
8,000-11,999 ft., 25 with runways 4,000-7,999 ft.; 4 seaplane stations
Telecommunications: composed of radio-relay links, open-wire lines, and
radiocommunication stations; principal center Lagos, secondary centers Ibadan
and Kaduna; 86,800 telephones; 1.5 million radio receivers, 75,000 TV
receivers; 25 AM, 6 FM, and 8 TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 13,545,000; 6,560,000 fit for military service
248
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','57a55648856130a372d4aa721984d553dc60a62720e071874549b32067ed86c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecffe38095eaabb075b6a023793a3397ddb8fdd0ea80bac2447a11a343169753',1973,'NO','Norway','communications',295,'LAND:
Norway: 125,000 sq. mi.; Svalbard, 24,000 sq. mi.;
Jan Mayen, 144 sq. mi.; 3% arable, 2% meadows
and pastures, 21% forested, 74% other
Land boundaries: 1,603 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 12 n. mi.)
Coastline: mainland 2,125 mi.; islands 1,500 mi. (excludes
tong fjords and numerous small islands and minor
indentations which total as much as 10,000 mi. overall)
Railroads: 2,662 mi.; State (NSB) operates 2,636 mi. standard gage, 2,589 mi.
Single track, 1,516 mi. electrified, 47 mi. double track; 10 mi. standard
gage electrified privately owned; 16 mi. meter (3''3 3/8") gage electrified
privately owned
Highways: 44,180 mi.; 7,135 mi. paved, 37,045 mi. crushed stone and gravel
Inland waterways: 980 mi.; 5'' draft vessels maximum
Pipelines: refined products, 33 mi.
Ports: 9 major, 69 minor
Merchant marine: 1,119 ships (1,000 GRT or over) totaling 21,956,800 GRT,
37,583,100 DWT; includes 31 passenger, 386 cargo, 276 tanker, 242 bulk,
184 specialized carrier
Civil air: 55 major transport aircraft
Airfields: 76 total, 73 usable; 41 with permanent-surface runways; 11 with
runways 8,000-11,999 ft., 13 with runways 4,000-7,999 ft.; 24 seaplane
stations
Telecommunications: high-quality domestic and international telephone, telegraph,
and telex service; 1,224,000 telephones; 2.0 million radiobroadcast receivers;
929,000 TV receivers; 41 AM, 214 FM, and 420 TV stations (including many high
powered transmitters); 5 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 911,000; 738,000 fit for military service;
average number reaching military age (20) annually, 32,000
Military budget: proposed for fiscal year ending 31 December 1973, $590.7 million;
about 11% of central government budget
250
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','0bdcd814d6848c7e543683f1aa049750b6f420de0b3760f4ae18b561ddae5f7c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0a4feaf4cf8fd5fe248f04cf293d4d4594f55a1d3ab82160d2faa797bddc8cc',1973,'OM','Oman','communications',299,'ND:
About 82,000 sq. mi.; negligible amount forested,
remainder desert, waste, or urban
Land boundaries: 860 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,300 mi.
Highways: 1,750 total; 3 mi. bituminous surface, remainder motorable natural -
surface track
Pipelines: crude oi] 230 mi.
Ports: 7 minor
Civil air: no major transport aircraft
Airfields: 199 total, 116 usable; 2 with permanent-surface runways; 4 with runways
8,000-11,999 ft., 37 with runways 4,000-7,999 ft.
Telecommunications: poor international radiocommunications (service to Bahrain
only); very poor domestic wire service; 1,630 telephones; 1 AM station;
tropospheric scatter-link to Bahrain
DEFENSE FORCES:
Military manpower: males 15-49, 114,000; 66,000 fit for military service
251
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','81694612fb186ee09f12c3b74d8e9185886913060fdda9931720406b50ef0da6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9d48e5974ee6c8ce9764bb0431a598d60035f742f6b5faec5e719394b6df19e',1973,'PK','Pakistan','communications',302,'PEOPLE''S REPUBLIC
OF CHINA
LAND:
310,000 sq. mi. (includes Pakistani part of Jammu-Kashmir)
40% arable, including 24% cultivated; 23% unsuitable
for cultivation; 34% unreported, probably mostly waste
3% forested
Land boundaries: 5,350 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 650 mi.
Railroads: 5,465 mni.; 277 mi. meter gage, 4,808 broad gage, 380 narrow gage;
635 double track; government owned
Highways: 43,500 mi.; 12,700 mi. paved, 12,450 mi. gravel, 18,350 mi. earth
Inland waterways: 1,150 mi.
Pipelines: crude oi1, 143 mi.; natural gas, 1,200 mi.
Ports: 1 major, 5 minor
Merchant marine: 63 ships (1,000 GRT or over) totaling 523,100 GRT, 702,900 DwT:
includes 5 passenger, 56 cargo, 2 bulk
Civil air: 15 major transport aircraft
Airfields: 203 total, 11] usable; 63 with permanent-surface runways; 1 with runway
over 12,000 ft., 21 with runways 8,000-11,999 ft., 53 with runways 4,000-
7,999 ft.; 2 seaplane stations
Telecommunications: excellent international radiocommunication service over
CENTO links; domestic wire and radiocommunication and broadcast service very
good; 159,000 (est.) telephones; 1,000,000 (est.) radio and 120,000 (est.)
TV sets; 7 AM, no FM, and 5 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 13,843,000; 7,440,000 fit for military service;
682,000 reach military age (17) annually
254
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','cf81c11448c06566ea257a0e54fabf477bef312c3bd1ec5995d7606d6317392c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c7b2608352329d305410def3b61c4efdf5a02214f4169d841a16dc508d9a99a',1973,'PA','Panama','communications',306,'LAND:
29,208 sq. mi. (excluding Canal Zone, 553 sq. mi.); 24%
agricultural land (9% fallow, 4% cropland, 11%
pasture), 20% exploitable forest, 56% other forests,
™-','bd843eb77cdc28739e80c9705765a172203525b328984a33cb47b5c179710814','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c23e5ccad1981725ddaebabdcf68ba731ec524d87498843369d9bb5351ce0c18',1973,'PG','Papua New Guinea','communications',307,'LAND:
183,540 sq. mi. (Papua 90,540 sq. mi., New Guinea
93,000 sq. mi.)
Land boundaries: 600 mi.
WATER : , AUSTRALIA
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: about 3,200 mi.
Papua:
Railroads: none
Highways: approx. 2,480 mi.; about 1,360 mi. suitable for heavy and medium
traffic, and about 1,120 mi. suitable for light traffic
Inland waterways: 800 mi., not including minor rivers
Ports: 1 principal (Port Moresby), 1 secondary
Civil air: see New Guinea (below)
Airfields: see New Guinea (below)
Telecommunications: see New Guinea (below)
New Guinea:
Railroads: none
Highways: approx. 6,430 mi.; approx. 3,865 mi. suitable for heavy and medium
traffic, and 2,565 mi. suitable for light traffic only
Inland waterways: 1,350 mi., northeast New Guinea; minor rivers not included
Pipelines: crude oi1, 87 mi.
Ports: 4 principal (Rabaul, Lae, Madang, Kavieng), 4 minor
Civil air: 12 major transport aircraft (registered in Australia)
Airfields: 661 total, 447 usable; 13 with permanent-surface runways; 46 with
runways 4,000-7,999 ft.
Telecommunications: Papua New Guinea telecom services are adequate and are
being improved; principal telecom centers include Goroka, Lae, Madang,
Mount Hagen, and Wewak in New Guinea; and Daru, Port Moresby and Samarai
in Papua; facilities provide radiobroadcast, radiotelephone and telegraph,
coastal radio, aeronautical radio and international radiocommunication
services; numerous privately owned radio facilities exist; submarine
cables extend from Madang to Australia and Guam; 25,300 telephones, 100,000
radios, but no TV sets; 1? AM, no FM and no TV facilities
DEFENSE FORCES:
Military manpower: males 15-49, 637,000 (Papua 168,000, New Guinea 469,000)
about 325,000 fit for military service (Papua 85,000, New Guinea 240,000)
Defense is responsibility of Australia
258
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','89d865d3dcec293d14d648e1123a74544bb1a6a6573ad5da58ae51219bf8ccf0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e44a30fe9b37fabf1176c3448775169891e4988ee4fd0a5fbd349479bbfd7b09',1973,'PL','Poland','communications',311,'D : NORWAT aes
120,600 sq. mi.; 49% arable, 14% other agricultural, 27% pos : :
forested, 10% other : ay
Land boundaries: 1,920 mi. ee
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 305 mi.
vA Saupis
ae EGYPT ARABIA
Railroads: 16,470 route mi.; 14,380 mi. standard gage, 2,090 mi. narrow gage;
4,645 mi. double track; 2,400 mi. electrified; government owned (1972)
Highways: 190,095 mi.; 40,390 mi. paved; 39,480 mi. crushed stone, gravel;
110,225 mi. earth (improved and unimproved) (1972)
Inland waterways: 3,158 mi. navigable streams and canals (1973)
Pipelines: 2,100 mi. for natural gas; 1,300 mi. for crude 011; 200 mi. for refined
products
Freight carried: rail -- 443.0 million short ton, 75.2 million short ton/mi.
(1972); highway 1,080.3 million short tons, 12.3 billion short ton/mi. (1971);
waterway -- 11.9 million short tons, 1.7 billion short ton/mi. excludes
international transit traffic (1972)
Ports: 4 major (Gdansk, Gdynia, Szczecin, Swinoujscie), 6 minor (1973)
Merchant marine: 252 ships (1,000 GRT and over) totaling 1,786,300 GRT and
2,513,400 DWT; includes 2 passenger, 171 cargo, 3 tanker, 76 bulk
Civil air: 47 major transport aircraft (1973)
Airfields: 147 total; 75 with permanent-surface runways; 36 with runways
8,000-11,999 ft., 71 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 8,821,000; 6,975,000 fit for military service;
356,000 reach military age (19) annually
266
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
YRELANG;','f0133da9052fd104ab44691817e077c5830aa370002fedd438bc915419f1048d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9708f60141abed0a6f186391ff49ec68ce2b1abed86c3e72de76ecd4297574e7',1973,'PT','Portugal','communications',315,'LAND:
Metropolitan Portugal: 36,400 sq. mi., including the Azores
and Madeira Islands; 48% arable, 6% meadow and pasture,
31% forested, 15% waste and urban, inland water, and
other
Cape Verde Islands: 1,560 sq. mi., divided among 10 islands
and several islets (not a part of Metropolitan Portugal)
Land boundaries: 750 mi.
: f SPAIN wd
-. SEs
“Morocco 4 ALGERIA
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 535 mi. (excludes Azores, Maderia, and Cape
Verde Islands, 1,180 mi.)
Railroads: 2,230 mi.; 472 mi. meter gage (3''3 3/8"), 1,758 mi. broad gage
(5''5 9/16"); 265 mi. double track; 274 mi. electrified
Highways: 18,500 mi.; 11,000 mi. bituminous, bituminous treatment, concrete and
stoneblock; 7,200 mi. gravel and crushed stone; 300 mi. improved earth; plus
an additional 10,500 mi. of unimproved earth roads (motorable tracks)
Inland waterways: 508 mi. navigable; relatively unimportant to national economy,
used by shallow-draft craft limited to 330-ton cargo capacity
268
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
‘ty
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Pipelines: crude oi] 7 mi.
Ports: 7 major, 33 minor
Merchant marine: 119 ships
includes 12 passenger, 78 cargo, 20 tan
Civil air: 24 major transport aircraft
Airfields (including Azores, Cape Verde Islands, and Madeira Islands): 52 total,
49 usable; 23 with permanent-surface runways; 1 with runways over 12,000 ft.,
9 with runways 8,000-11,999 ft., 13 with runways 4,000-7,999 ft.; 6 seaplane
stations
(1,000 GRT or over) totaling 975,700 GRT, 1,327,900 DWT;
ker, 6 bulk, 3 specialized carrier
.
Telecommunications: facilities are generally adequate; 817,000 telephones; 1.6
million radio receivers; 524,000 television receivers; 37 AM, 34 FM, and 36
TV stations; 2 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 2,160,000; 1,670,000 fit for military service;
average number reaching age (20) annually, about 75,000
Military budget: proposed for fiscal year ending 31 December 1973, $521 million:
about 30% of central government budget
z®
&
’
269
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
PORTUGUESE GUINEA
LAND:
14,000 sq. mi. (includes Bijagos archipelago)
Land boundaries: 460 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 170 mi.
Railroads: none
Highways: approx. 2,000 mi. (260 mi. bituminous, remainder earth)
Inland waterways: 994 mi.
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 63 total, 60 usable; 4 with permanent-surface runways; 9 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: limited telephone and telegraph service; 2,580 telephones ;
8,800 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 115,000; 65,000 fit for military service
Defense is responsibility of Portugal
272
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
PORTUGUESE TIMOR
LAND:
7,000 sq. mi.; 34% forest, 33% grassland, and 33%
cul tivated aRCGUKSE
Land boundaries: 90 mi. P= = TIMOR','36dc6e9fbbbbe030f5672bb4eed99584a2509c68de3af5949e02a7242839e8aa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28b2da8c4d7e389c2e0fafba53130607dcf2eb706adeb8162e0836c4e5f21b69',1973,'PR','Puerto Rico','communications',319,'LAND:
‘ 3,440 sq. mi.; 33% arable, 35% meadow and pasture, 13%
forested, 19% waste, urban, or other ~
WATER: : VENEZUELA
Limits of territorial waters (claimed): 3 n. mi.
o (fishing, 12 n. mi.) COLOMBIA
Coastline: 300 mi.','51ec071325e47dafa102191e2834a4011a2f1ce10ededa36afe9df35ef77fa85','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98e050009c2df207dfb68a739a37ceb2d9ae17eac3dc2f5ce58dae314a0813d7',1973,'QA','Qatar','communications',320,'a.
TURKEY
LAND: . ,
About 4,000 sq. mi.; negligible amount forested; mostly i Nb,
desert, waste, or urban y
Land boundaries: 35 mi.
{ ARABIA
WATER :
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 350 mi.
Railroads: none
Highways: 275 mi. bituminous; 225 mi. gravel; surfaced; undetermined mileage of
earth tracks
Pipelines: crude oi1, 105 mi.; natural gas, 60 mi.
277
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Ports: 2 minor
Airfields: 10 total, 1 usable; 1 with permanent-surface runway over 12,000 ft.
Civil air: no major transport aircraft
Telecommunications: al] international telecom traffic is by radio thru Bahrain;
fair domestic wire facilities; 12,200 telephones; 35,000 radio and 27,000 TV
receivers; 1 AM and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 35
service
Supply: mostly from U.K.
000; about 20,000 fit for military
278
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
REUNION
LAND:
970 sq. mi.; two-thirds of island extremely rugged,
consisting of volcanic mountains; 120,000 acres (less
than one-fifth of the land) under cultivation (1970)
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 125 mi.
Railroads: none
Highways: 1,092 mi.; 814 mi. paved, 278 mi. gravel, crushed stone, or stabilized
earth
Ports: 1 major a
Civil air: no major transport aircraft
Airfields: 6 total, 6 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.
Telecommunications: adequate system for size of island of fairly modern open-wire
lines and radiocommunication stations; principal center Saint-Denis; external
radiocommunications to Comoro Islands, France, Malagasy, and Mauritius;
17,900 telephones; 71,000 radio and 23,500 TV receivers; 2 AM, no FM, and
8 TV stations
DEFENSE FORCES:
Military manpower: military age males included with France
280
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
RHODESIA
D: ;
151,000 sq. mi.; 40% arable (of which 6% cultivated); 60%
available for extensive cattle grazing; European
alienated lands (farmed by modern methods) 39%,
African 48%, national land 7%, 6% not alienated
Land boundaries: 1,875 mi.
Railroads: 1,610 mi. narrow gage (3''6"); 26 mi. double track
Highways: 48,733 mi.; 4,968 mi. paved, 20,415 mi. crushed stone, gravel,
stabilized soil, or improved earth; 23,350 mi. unimproved earth
Inland waterways: 175 mi. on Lake Kariba
Airfields: 310 total, 210 usable; 8 with permanent-surface runways; 1 with run-
way over 12,000 ft., 23 with runways 4,000-7,999 ft.
Civil air: 12 major transport aircraft
Teleconmunications: system is one of the best in Africa; consists of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Salisbury, secondary center Bulawayo; 140,900 telephones; 215,000 radio
and 57,000 TV receivers; 8 AM, no FM and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,359,000; 830,000 fit for military service;
average number reaching military age (18) annually, 53,000
Military budget: for fiscal year ending 30 June 1973, $59,300,000; 11.5% of
total budget
282
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
x
ROMANTA
LAND:
91,700 sq. mi.; 44% arable, 19% other agriculture, 27%
forested, 10% other
Land boundary: 1,845 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 140 mi.','af9ab674a208cb2715175ff9ebf88f6d9a7cb01a0f030963f2ed140965d2a07d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b43e83babf6774f1ec3abbd711850f22ab32ff21cf53e755428ee8ac5d1078d0',1973,'RW','Rwanda','communications',324,'LAND:
10,000 sq. mi.; almost all the arable land, about 1/3
under cultivation, about 1/3 pastureland
Land boundaries: 545 mi.
Railroads: none
Highways: 3,728 mi.; 1,243 mi. primary roads (only 6 mi. paved), 2,485 mi.
secondary roads; most roads improved or unimproved earth
Inland waterways: Lake Kivu navigable by steamers and barges
Civil air: no major transport aircraft
Airfields: 20 total, 15 usable; 2 with permanent-surface runways; 2 with
runways 4,000-7,999 ft., 1 with runway 8,000-11,999 ft.
Telecommunications: telephone and telegraph limited; main center is Kigali;
1,800 telephones; 50,000 radio receivers; 2 AM, no FM or TV stations 4
DEFENSE FORCES:
Military manpower: males 15-49, 939,000; 450,000 fit for military service;
mo conscription; 40,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1972, $4,753,000; about
20.5% of total budget
286
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ST. CHRISTOPHER-NEV IS-ANGUILLA
LAND:
150 sq. mi.; 40% arable, 10% pasture, 17% forest, 33%
wasteland and built-on (1962)
WATER: i VENEZUELA {
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi. COLOMBIA','ffb97ab1d07570e59bcfb54658a83a37126595a5c1ff622fe9dd8004deeb25fd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01b0d4167b5653c07f8ce7b14e79c3c8f576778a0bc08ac35d23ae4e791386f2',1973,'SM','San Marino','communications',327,'LAND:
24 sq. mi.; 74% cultivated, 22% meadows and pastures,
4% built-on
Land boundaries: 21 mi.
Railroads: none
Highways: about 65 mi.
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system serving 3,150 telephones; no
radiobroadcasting or television facilities, 3,200 radio and 600 TV receivers
(Italian broadcasts)
294
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','e36f91286cd21be4e54f4f39547a2ce3a9347f2c64a29ba4d2987ff893237e41','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7efadddf591568f925a417a295545acfb03bd00321c8ceb8d5405c252c99e84e',1973,'SA','Saudi Arabia','communications',331,'D:
618,000 sq. mi. (boundaries are poorly defined); 1%
agricultural, 1% forested, 98% desert, waste, or
urban
Land boundartes: 2,820 mi.
& WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,560 mi.
Railroads: 350 mi., 4''8 1/2" gage
Highways: 7,767 mi.; 5,282 mi. bituminous, 2,485 mi. gravel and improved earth,
undetermined mileage of earth roads and tracks
Pipelines: crude oi1, 1,435 mi.; refined products, 95 mi.; natural gas, 95 mi.
Ports: 3 major, 6 minor
Civil air: 20 major transport aircraft
Airfields: 237 total, 74 usable; 19 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 41 with runways 4,000-7,999 ft.
Telecommunications: excellent international radio communications; poor domestic
wire service; 81,600 telephones; 250,000 radio and 150,000 TV receivers; 11
TV, 1 FM, and 4 AM stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 1,393,000; 745,000 fit for military service;
about 60,000 reach military age (18) annually
Military budget: for fiscal year ending 10 August 1973, $952.2 million; about
29.9% of total budget
296
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Railroads: none
Highways: 2,160 mi.; 290 mi. bituminous; 270 mi. crushed stone and gravel;
- 1,600 mi. earth, sand, and light gravel
Ports: 3 major, 2 minor
371
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Civil air: 8 major transport aircraft
Airfields: 35 total, 22 usable; 6 with permanent-surface runways; 1 with
runway over 12,000 ft., 4 with runways 8,000-11,999 ft., 12 with runways
4,000-7 ,999 ft,
Telecommunications: Systems among mideast''s worst; consists of meager open-wire
lines and low-power radio communication stations; principal center Sana,
secondary centers Al Hudaydah and Taizz; 4,600 t
elephones; 85,000 radio
receivers (approx.); 1 AM radio-broadcast station
DEFENSE FORCES:
Military manpower: males 15-49, 1,510,000; 790,000 fit for military service;
about 65,000 reach military age (18)
annually; univeral military conscription
law (10 January 1963) makes military service obligatory for all Yemeni
males 18-30
372
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
YUGOSLAV TA
LAND:
98,800 sq. mi.; 32% arable, 25% meadows and pastures,
34% forested, 9% other
Land boundaries: 1,865 mi.
WATER:
Limits of territorial waters (claimed): 10 n. mi.
(fishing, 12 n. mi.)
Coastline: 945 mi. (mainland), plus 1,500 mi. (offshore : ;
islands ) EGYPT, “ARABIA ;
Railroads: 6,420 route mi.; 5,740 mi. standard gage, 680 mi. narrow gage;
465 mi. double track; 940 mi. electrified (1971)
Highways: 56,565 mi.; 14,850 mi. paved, 25,715 mi. gravel, crushed stone, 15,600
mi. improved earth, 400 mi. unimproved earth (January 1971)
Inland waterways: 1,231 mi. (1973)
Freight carried: rail -- 88.0 million short tons, 14.2 billion short ton/mi. (1971);
highway -~ 64.7 million short tons, 4.5 billion short ton/mi. (1971);
waterway -- 25.4 million short tons, est. 4.8 billion short ton/mi. (1971)
Pipelines: crude oi1, 200 mi.; natural gas, 580 mi.
Ports: 9 major (most important: Rijeka, Split), 24 minor (1973)
Merchant marine: 186 ships (1,000 GRT or over) totaling 1,528,800 GRT, 2,263,300
DWT; includes 4 Passenger, 139 cargo, 16 tanker, 27 bulk in addition Yugoslavia
owns 4 cargo ships (1,000 GRT or over) totaling 37,600 GRT, 60,000 DWT which
appear under Panamanian flag
Civil air: 37 major transport aircraft (including 1 leased) (1973)
Airfields: 194 total, 90 usable; 34 with permanent-surface runways; 18 with
runways 8,000-11,999 ft., 29 with runways 4,000-7,999 ft.; 2 seaplane
stations
DEFENSE FORCES:
Military manpower: males 15-49, 5,636,000; 4,550,000 fit for military service;
201,000 reach military age (19) annually
374
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
a
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
ZAIRE
D:
905,000 sq. mi.; 22% agricultural land (1% cultivated),
45% forested, 33% other
Land boundaries: 6,153 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 23 mi.
Railroads: 3,218 mi.; 2,419 mi. 3''6" gage, 78 mi. 3‘ 3 3/8" gage, 85 mi.
2'' 0 1/4" gage, 636 mi. 1'' 11 5/8" gage; 421 mi. of 3''6" gage electrified
Highways: 86,930 mi.; 1,095 mi. bituminous, 10,427 mi. gravel or crushed stone,
75,408 mi. earth
Inland waterways: comprising the Zaire, its tributaries, and unconnected lakes,
the waterway system affords over 9,329 mi. of navigable routes
Ports: 2 major, 1 minor
Merchant marine: 5 ships (1,000 GRT or over) totaling 49,400 GRT, 60,900 DWT;
includes 1 passenger, 4 cargo
Pipelines: refined products, 460 mi.
Civil air: 26 major transport aircraft
Airfields: 488 total, 320 usable; 19 with permanent-surface runways; 1 with
runway over 12,000 ft., 2 with runways 8,000-11,999 ft., 54 with runways
4,000-7,999 ft.; 5 seaplane stations
Telecommunications: limited, barely adequate telephone service, telegraph service
good; 23,000 telephones; 100,000 radio receivers; 7,100 TV receivers;
12 AM, 1 FM, and 2 TV stations
DEFENSE FORCES:
Military manpower: mates 15-49, 5,760,000; 2,760,000 fit for military service
Military budget: for fiscal year ending 31 December 1973, $124,800,000; about
17.1% of total budget
376
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','d839d57866ee2af60a516d617de5b4f4d298c725069c3230dc4b077f2820617e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e042345a3cdcef5ea9336be2c5338703a62fe100304f38f0119fcf6dfbd4bde3',1973,'SN','Senegal','communications',335,'"76,000 sq. mi.; 13% forested, 40% agricultural (12%
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 1,665 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing
122 n. mi.)
Coastline: 330 mi.
Railroads: 640 mi. meter gage; 40 mi. double track
Highways: 8,725 mi.; 1,335 mi. bituminous, 990 mi. gravel, 400 mi. improved
earth, 6,000 mi. unimproved earth
Inland waterways: 935 mi.
Merchant marine: 3 ships (1,000 GRT and over) totaling 4,600 GRT, 6,700
DWT; includes 2 cargo, 1 tanker
Ports: 1 major, 4 minor
Civil air: 3 major transport aircraft, including 1 leased to Air Mauritanie
Airfields: 42 total, 27 usable; 9 with permanent-surface runways; 1 with runway
8 ,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: relatively advanced for Africa; 29,300 telephones; 280,000
radio receivers; 1,600 TV receivers; 3 AM, no FM, and 1 TV stations;
3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 972,000; 465,000 fit for military service;
45,000 reach military age (18) annually
Supply: primarily dependent on France
Military budget: for fiscal year ending 30 June 1973, $19,289,000; about 8.7%
of total budget
298
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','b42b086143cacc16a5956f8b5ea5590b86f147c4553db7972606d175f81ae042','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b312aabc0072bbfe386f1163191a0e1bc093eb66876d8f04cfbf119430f81b4d',1973,'SC','Seychelles','communications',339,'LAND:
156 sq. mi.; 54% arable land, nearly all of it is under
cultivation, 17% wood and forest land, 29% other
(mainly reefs and other surfaces unsuited for
agriculture); 40 granitic and 43 coral islands (1971)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 305 mi. (Mahe Island 58 mi.)
Railroads: none
Highways: 141 mi.; 62 mi. bituminous, 79 mi. crushed stone or earth
Ports: 1 minor port (Victoria)
Civil air: no major transport aircraft
Airfielas: 3 total, 1 usable on Prasin Island, 1 usable on Astove Island, 1
permanent surface 8,000-11,999 ft. on Mahe Island; former RAF seaplane
station at Victoria, Mahe Island, although not in present use, could be
used in emergency
Telecommunications: direct radiotelegraph communications with other adjacent
islands and African coastal countries; 1,200 telephones; 15,000 radio sets;
no TV sets; 2 AM, no FM, and no TV stations; submarine cables extend to
Aden, Tanzania, and Sri Lanka
DEFENSE FORCES:
Military manpower: males 15-49, 13,000; 7,000 fit for military service
Defense is responsibility of U.K.; no U.K. troops present
300
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
STERRA LEONE
LAND:
27,900 sq. mi.; 65% arable (6% of total land area under
cultivation), 27% pasture, 4% swampland, 4% forested
Land boundaries: 580 mi.
WATER:
‘ Limits of territorial waters (claimed): 200 n. mi.
(no fishing claim)
Coastline: 250 mi.
Railroads: 370 route miles; 310 mi. narrow gage (2''6") Sierra Leone Government
Railroad (SLR), 60 mi. narrow gage (3''6") privately owned mineral line
operated by the Sierra Leone Development Company
Highways: 4,950 mi.; 450 mi. bituminous (including some bituminous treatment),
1,750 mi. laterite (some gravel), and 2,750 mi. earth
Inland waterways: 500 mi.; 372 mi. navigable year-round
Ports: 1 major, 2 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,000 GRT, 1,400 DWT
Civil air: no major transport aircraft
Airfields: 15 total, 15 usable; 5 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone and telegraph are adequate; 6,500 telephones;
50,500 radio and 5,000 TV receivers; 1 AM, no FM, and 1 TV stations;
3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 628,000; 302,000 fit for military service; no
conscription
Military budget: for year ending 30 June 1972, 6,122,000; 8.4% of total
budget
302
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
SIKKIM
PEOPLE''S REP.
OF CHINA
LAND:
2,800 sq. mi.
Land boundaries: 265 mi.
Railroads: none
Highways: 575 mi.; 252 mi. paved, 129 mi. crushed stone or gravel, 194 mi. earth
Civil air: no major transport aircraft
Airfields: 1 gravel runway 600 ft.
303
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','85e012ccda8ddfe40099caf0375e01d0c62cab9027a398daf50a1e7c8033773e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67162c71a5288c4a2b967c34bc68936ed503878cc88267bae28d70af623b1c6c',1973,'SG','Singapore','communications',343,'LAND:
225 sq. mi.; 31% built up area, roads, railroads, and
airfields, 22% agricultural, 47% other
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi.
Railroads: 24 mi. of meter gage
Highways: 1,226 mi.; 773 mi. paved, 243 mi. crushed stone, 210 mi. improved
earth
Ports: 3 major
Civil air: 16 major transport aircraft
Airfields: 5 total, 5 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate domestic facilities; good international service;
good radio and television broadcast coverage; 189,847 telephones; 268,004
radio and 193,120 TV sets; 2 AM, 4 FM, and 2 TV stations; new
SEACOM submarine cable extends to Hong Kong via Sabah, Malaysia
DEFENSE FORCES:
Military manpower: males 15-49, 581,000; 395,000 fit for military service
Military budget: for fiscal year ending 31 March 1973, $201.2 million; 39% of
total budget
306
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
SOMAL TA
D: ;
246,000 sq. mi.; 13% arable (0.3% cultivated), 32%
grazing, 14% scrub and forest, 41% mainly desert,
urban, or other
Land boundaries: 1,406 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,880 mi.
Railroads: none
Highways: 8,414 mi.; 582 mi. paved; 478 mi. crushed stone, gravel, or
stablized soil; 7,354 mi. improved or unimproved earth
Inland waterways: Fiume Giuba navigable 345 mi. from May to mid-June and
August to late November
Ports: 4 major, 17 minor
Civil air: 5 major transport aircraft
Airfields: 107 total, 57 usable; 2 with permanent-surface runways; 2 with
runways 8,000-11,999 ft., 13 with runways 4,000-7,999 ft.; 5 seaplane
stations
Telecommunications: telephone poor, telegraph fair; 4,740 telephones; 60,000
radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 726,000; 385,000 fit for military service; no
conscription
308
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','c133cdcc662ec23d1130598f8fd5bcd26c894ca85fd064efc1f089e26a4d3258','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3a95ed55960b3544b68cdf6474861da4341bee4c9a934a8d9a01a149f05e300',1973,'ZA','South Africa','communications',347,'LAND:
472,000 sq. mi. (includes enclave of Walvis Bay,
434 sq. mi.); 12% cultivable, 2% forested, 86% desert,
waste, or urban (1973)
Land boundaries: 1,270 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,790 mi.
Railroads: 12,318 mi.; 11,879 mi. 3''6" gage of which 1,323 mi. are multiple
track; 2,726 mi. electrified; 440 mi. 2''0" gage single track
Highways: 220,000 mi.; 27,300 mi. paved, 47,050 mi. crushed stone or gravel,
145,650 mi. improved and unimproved earth
Pipelines: crude 071, 520 mi.; refined products, 450 mi.; natural gas, 200 mi.
Ports: 5 major, 6 minor
Civil air: 57 major transport aircraft
Airfields: 747 total, 556 usable; 42 with permanent-surface runways; 1 with runway
over 12,000 ft., 8 with runways 8,000-11,999 ft., 125 with runways 4,000-7,999
ft.; 4 seaplane stations
Telecommunications: the system, except for the lack of television, is the best
developed, most modern, and highest capacity in Africa and consists of
carrier-equipped open-wire lines, coaxial cables, radio-relay links, and
radiocommunication stations; key centers are Bloemfontein, Cape Town,
Durban, Johannesburg, Port Elizabeth, and Pretoria; 1.6 million telephones;
2.5 million radio receivers; 13 AM, 60 FM, and no TV stations; 4 submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 5,431,000; 3,325,000 fit for military service;
obligation for service in Citizen Force begins at 18; volunteers for service
in permanent force must be 17
310
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
SOUTH-WEST AFRICA
LAND:
318,000 sq. mi.; mostly desert except for interior
plateau and area along northern border (1973)
Land boundaries: 2,360 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 925 mi.
Railroads: 1,454 mi., all 3''6" gage, single track
Highways: 21,000 mi.; 2,344 mi. bituminous treated, 220 mi. gravel and 18,436 mi.
earth road and tracks
Ports: 1 major, 1 minor
Civil air: 2 major transport aircraft (registered in South Africa)
Airfields: 124 total, 84 usable; 10 with permanent-surface runways; 1 with runway
over 12,000 ft.; 3 with runways 8,000-11,999 ft., 37 with runways 4,000-7,999
ft.; 1 seaplane station
Telecommunications: system is a meager combination of open-wire lines, a single
short radio-relay link, and scattered radiocommunication stations; Windhoek
is the center; 35,600 telephones; unknown number of radio receivers; no
AM, 1 FM, and no TV stations
DEFENSE:
Military manpower: males 15-49, about 192,000; about 110,000 fit for military
service
Defense is responsibility of Republic of South Africa
312
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','eb53a9267a783fd1b1ad2c87a91119e505f6acce3d886dc0bd359a6734c32190','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('683952fdae3b9d584300742fbe676eb8cb9ee015f582097c21faa31f91282ef3',1973,'ES','Spain','communications',351,'LAND:
195,000 sq. mi., including Canary (2,900 sq. mi.) and
Balearic Islands (1,940 sq. mi.); 41% arable and
land under permanent crops, 27% meadow and pasture,
22% forest, 10% urban or other
Land boundaries: 1,180 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 3,085 mi. (includes Balearic Islands, 420 mi.,
and Canary Islands, 720 mi.)','359f160e905887e3432c45aa33a93ccefc2fa8876a45d375f1f68505e6308c85','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4441f85b8471393e93ec01b6434ce98f1c3eeb097e2d35609a9bc6eb8194a6e1',1973,'SD','Sudan','communications',352,'LAND:
967,000 sq. mi.; 37% arable (3% cultivated), 15% grazing,
33% desert, waste, or urban, 15% forest
Land boundaries: 4,850 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 530 mi.
Railroads: 2,950 mi.; 2,730 mi. 3''6" gage, 440 mi. 2'' gage plantation Tine
Highways: 6,550 mi.; 680 mi. crushed stone or gravel, 190 mi. bituminous-treated,
and 5,680 mi. improved and unimproved earth roads; in addition, there are an
undetermined number of tracks
Inland waterways: 3,300 mi. navigable
Ports: 1 major, 7 minor
Civil air: 9 major transport aircraft
Airfields: 87 total, 67 usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 29 with runways 4,000-7,999 ft.
Telecommunications: large system by African standards, but still barely adequate
for size of country; consists of open-wire lines, radio-relay links, multi-
conductor cables, radio communication stations and a tropospheric scatter
link; principal center of Khartoum, secondary centers at Al Fashir and
Port Sudan; 46,400 telephones; 650,000 radio and 60,000 TV receivers; 2 AM,
no FM, and 1 TV stations; 5 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,845,000; 2,270,000 fit for military service;
average number reaching military age (18) annually, 160,000
Military budget: for fiscal year ending 30 June 1973, $113.5 million; 20.8% of
total budget
322
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
SURINAM
LAND:
55,100 sq. mi.; negligible amount of arable land, meadows
and pastures, 76% forest, 8% unused but potentially
productive, 16% built-on area, wasteland, and other
Land boundaries: 970 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 240 mi.
Railroads: 104 mi.; 54 mi. 3''3 3/8" gage (government owned) and 50 mi.
narrow gage (industrial lines); all single track
Highways: 1,550 mi.; 300 mi. paved, 130 mi. gravel, 370 mi. improved earth,
750 mi. unimproved earth
Inland waterways: 2,850 mi.; most important means of transport; oceangoing
vessels with drafts ranging from 14 to 23 ft. can navigate many of the
principal waterways while native canoes navigate upper reaches
Ports: 1 major, 6 minor
Merchant marine: 2 cargo ships (1000 GRT or over) totaling 3,800 GRT, 5,300 DWT
Civil air: 2 major transport aircraft
Airfields: 31 total, 29 usable; 2 with permanent-surface runways; 1 with runway
8,000-11 ,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: international facilities good; domestic radio-relay
system; 11,000 telephones; 100,000 radio and 32,000 TV receivers, 5 AM,
1 FM, and 3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 107,000; 61,000 fit for military service
Defense is responsibility of the Netherlands; the Netherlands maintains an army
force in Surinam; also available are naval, marine corps, and naval air
personnel located in the Netherlands Antilles
Ships: none
324
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
SWAZILAND
LAND:
6,700 sq. mi.; most of area suitable for crops or
pastureland
Land boundaries: 270 mi.
Railroads: 139 mi., 3''6" gage, single track
Highways: 2,059 mi.; 140 mi. paved; 838 mi. crushed stone, gravel, or stabilized
soil; 685 mi. improved or unimproved earth
Civil air: 5 major transport aircraft
Airfields: 29 total, 25 usable; 1 with permanent-surface runway; 1 with runway
4,000-7 ,999 ft.
Telecommunications: the system consists of a few open-wire lines and low-powered
radiocommunication stations; Mbabane is the center; 5,700 telephones; 50,000
radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 103,000; 53,000 fit for military service
None, police only
326
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','b9a4d28f8ed354c34a6fd537a837fbbfc98b59073e8375058a4d04bd6fe9263b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9595aca8436df2a9b0f9cbae12a316857ec63df26514780ee86e95bf6d9a21cf',1973,'SE','Sweden','communications',356,'LAND:
173,000 sq. mi.; 8% arable, 1% meadows and pastures, 55%
forested, 36% other (1972)
Land boundaries: 1,365 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 12 n. mi.) ;
Coastline: 2,000 mi. a oo
LiBya Saupl a,
EGY PR ARABIA Vaio,
Railroads: 7,56] mi.; Swedish State Railways (SJ) 7,004 mi. standard
gage (4''8 1/2"), 4,373 mi. electrified, 725 mi. double tracked; 165 mi. narrow
gage (3''6" and 2''11"), and 294 mi. standard gage (4'' 8 1/2") and 98 mi. narrow
gage (2''11") are privately owned and operated, 284 mi. electrified
Highways: 61,000 mi.; 44,550 mi. are crushed stone, gravel, or improved
earth; and 16,395 mi. are bitumen, concrete, stone block, or cobblestone
Inland waterways: 1,268 mi. navigable for smal] steamers and barges
Ports: 17 major, and 23 significant minor
Merchant marine: 344 ships (1,000 GRT or over) totaling 5,230,600 GRT, 8,286,200
DWT; includes 18 passenger, 140 cargo, 44 tanker, 47 bulk, 95 specialized
carrier
Civil air: 73 major transports registered
Airfields: 221 total, 191 usable; 97 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 65 with runways 4,000-7,999 ft.; 9 seaplane
stations
Telecommunications: excellent domestic and international facilities; 4.7 million
telephones; 42 AM, 85 FM, and 196 TV stations; 5 million radio and 3
million TV receivers; 10 submarine cables, including 4 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 1,891,000; 1,680,000 fit for military service;
56,000 reach military age (19) annually
Military budget: for fiscal year ending 30 June 1974, $1.67 billion;
about 11% of central government budget
328
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','b3b73cb7d4f9e6b6f239229a67cd7f668b0c5cccbbdb1ce076c494f079c5b155','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e9de84738fd343f31aa41c825e205ed73b8ac5f91d71e3f645ea19858a9f0cc',1973,'CH','Switzerland','communications',359,'LAND :
16,000 sq. mi.; 10% arable, 42% meadows and pastures, 21%
waste or urban, 24% forested, 3% inland water
Land boundaries: 1,171] mi.','147b149593f0a1f8fab52f85559b4e939df2faa84099011b2f4bd8869f9a5571','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3e98f139b63542700a446a195c50ebdd32226faef31fcd88f3f47be1ee9beb3',1973,'TG','Togo','communications',361,'LAND:
22,000 sq. mi.; nearly half total is arable, under 15%
cultivated
Land boundaries: 940 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 35 mi.
Railroads: 275 mi. meter gage, single track
Highways: approx. 4,475 mi.; 300 mi. paved, 120 mi. gravel, 845 mi. improved
earth, 3,210 mi. unimproved
Inland waterways: section of Mono River and about 30 mi. of coastal lagoons
and tidal creeks
Ports: 1 major, 1 minor
Civil air: 1 major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-surface runway 4,000-7,999 ft.
Telecommunications: Togo has poor system based on skeletal network of open-wire
lines, supplemented by a few radiocommunication stations; only center is
Lome; 6,100 telephones; 46,000 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 440,000; 225,000 fit for military service;
no conscription
338
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','df26029f141f3ada245cf7b172b01b9c86c6602b7cb21d561dd01ce97946ffa0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2ae2a64bc0ef5fd24cf8c00f451ced8918e798226d3f625dcd7a2253e3744cb',1973,'TO','Tonga','communications',365,'LAND:
385 sq. mi. (150 islands); 77% arable, 3% pasture, 13%
forest, 3% inland water, 4% other
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 260 mi. (est.)
: AUSTRALIA
Railroads: none
Highways: 365 mi.; 132 mi. metalled all-weather, 233 mi. earth
Ports: 5 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,800 GRT, 2,700
DWT
Civil air: no major transport aircraft
Airfields: 3 total; 1 usable, with grass runway 7,000 ft.; 1 seaplane station
Telecommunications: 1,073 telephones; 9,000 radio sets; no TV sets; 1 AM station
339
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','64ca3ad1e437264e369ac9f5a87952606508f436cb2fe6ba24fe09a003c84f71','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('233f44bfc9d5cb0bbbfd0d3004366806b464eb4c560287de1eb07191f0a3d485',1973,'TT','Trinidad and Tobago','communications',369,'LAND:
1,980 sq. mi.; 41.9% in farms (of which 25.7% cropped or
fallow, 1.5% pasture, 10.6% forests, 4.1% unused or
built-on), 58.1% outside of farms, including :
grassland, forest, built-up area, and wasteland VENEZUELA
WATER: COLOMBIA
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 225 mi.','7a595cb74ca1e243cbe56b83ae3fa9a6c84db5ea81043c26303b4d5a89de3e4e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6411ed7a2e99fc996e42ee341190cc19e8ed544c616b476e41554ead69cf866',1973,'TN','Tunisia','communications',370,'* TURKEY
,
eae
Be em LiBYA IEG
LAND:
63,400 sq. mi.; 28% arable land and tree crops, 23% range
and esparto grass, 6% forest, 43% desert, waste or
urban
Land boundaries: 875 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi. follows 50 meter isobath in
south; maximum extent 80 n. mi.)
Coastline: 710 mi. (includes offshore islands)
Railroads: 1,273 mi.; 309 mi. standard gage (4''8 1/2"), double 964 mi. meter
gage (3''3 3/8")
Highways: 10,000 mi.; 4,560 mi. mostly bituminous treatment, 465 mi. gravel,
2,050 mi. improved earth, 2,925 mi. unimproved earth
Pipelines: crude oi1, 495 mi.; refined products, 6 mi.; natural gas, 45 mi.
Ports: 4 major, 8 minor
Merchant marine: 10 ships (1,000 GRT or over) totaling 25,200 GRT, 34,300 DWT;
includes 8 cargo, 1 tanker, 1 specialized carrier
Civil air: 6 major transport aircraft
Airfields: 60 total, 35 usable; 11 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 1 seaplane station
Tetecommunications: the system is above the African average in amount and
capacity of facilities which consist of open-wire lines with multiconductor
cable or radio relay on trunk routes; key centers are Safaqis, Susah, Bizerte,
and Tunis; 88,000 telephones; 400,000 radio and 80,000 TV receivers; 3 AM,
3 FM, and 7 TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 1,175,000; 630,000 fit for military service;
about 58,000 reach military age (20) annually
344
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
TURKEY
LAND:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER: 2 ARABIA
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi. SUDAN
(fishing, 12 n. mi.)
Coastline: 4,475 mi. EXH(ORS
Railroads: 4,991 mi.; 4,940 mi. 4''8 1/2" gage, 51 mi. double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 594,900 GRT, 826,600 DhT;
includes 12 passenger, 52 cargo, 11 tanker, 10 bulk, 2 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 123 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 22 with runways
4 ,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international radiocommunication and fair domestic
telecommunication services; 654,500 telephones; 3.94 million radio and 133,000
TV receivers; 39 AM, 2 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,707,000; 5,730,000 fit for military service;
about 402,000 reach military age (20) annually
Military budget: for fiscal year ending 28 February 1974, $792.8 million; about
16% of central government budget
346
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','71e0ea2e0ff5bd65b704e6be81639b146e82b3e713959507b70fc8b2d2c96331','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69db16f8a8a72ffef308fef84ed5cc04f4068cd5f523daf40ddb9393958174ed',1973,'UG','Uganda','communications',374,'LAND:
91,000 sq. mi.; 21% intand water and swamp, including
territorial waters of Lake Victoria, about 21%
cultivated, 13% national parks, forest, and game
reserves, 45% forest, woodland, and grassland (1970)
Land boundaries: 1,665 mi.
Railroads: 760 mi.; all meter gage, single track
Highways: 31,330 mi. total; 940 mi. bituminous surface treatment; 10,390 mi.
crushed stone, gravel, laterite, and improved earth; 20,000 mi. unimproved
earth roads and tracks
Inland waterways: Lake Victoria, Lake Albert, Lake Kyoga, Lake George, and
Lake Edward (6,010 mi.); Kagera River and Victoria Nile (380 mi.)
Ports: 1 major (Port Bell on Lake Victoria)
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 5,500 GRT, 9,100 DWT
Civil air: 6 major transport aircraft
Airfields: 50 total, 42 usable; 3 with permanent-surface runways; 7 with runway
over 12,000 ft., 2 with runways 8,000-11,999 ft., 11 with runways 4,000-7 ,999
ft.; 3 seaplane stations
Telecommunications: telephone and telegraph services fair to good, intercity
connections based on 3 or 12 channel carrier systems; 34,200 telephones;
275,000 radio and 15,000 TV receivers; 2 AM, no FM, and 6 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 2,516,000; about 1,395,000 fit for military
service
Military budget: for fiscal year ending 30 June 1972, $42.7 million; 16.6% of
total budget
348
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
U.S.S.R.
LAND:
8,600,000 sq. mi.; 9.3% cultivated, 37.1% forest and
brush, 2.6% urban, industrial, and transportation,
16.8% pasture and natural hay land, 34.2% desert,
swamp, or waste
Land boundaries: 12,595 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 29,000 mi. (incl. Sakhalin)
Railroads: 84,500 mi.; 82,270 mi. broad gage, 2,240 mi. narrow gage; 58,610 mi.
broad gage single track; 21,065 mi. electrified; does not include industrial
lines (1972)
Highways: 845,620 mi.; 128,340 mi. paved, 188,850 mi. gravel, crushed stone,
528,425 mi. improved or unimproved earth (1971)
Inland waterways: 90,000 mi. navigable, exclusive of Caspian Sea (1972)
Pipelines: crude oi1, 23,000 mi.; refined products, 5,800 mi.; natural gas,
46,000 mi.
Ports: 62 major (most important: Leningrad, Murmansk, Odessa, Novorossiysk,
Vladivostok, Nakhodka); 122 selected minor (1972)
Freight carried: rail -- 3,477.7 million short tons, 1,891.8 billion short
ton/mi. (1972); highways -- 17.3 billion short tons, 161.8
billion short ton/mi. (1971); waterway -- 435.4 million short tons,
123.3 billion short ton/mi. (1972)
Merchant marine: 1,489 ships (1,000 GRT or over) totaling 9,787,700 GRT,
12,775,800 DWT; includes 64 passenger, 684 cargo (includes dry cargo,
refrigerated cargo, container, combination cargo-passenger, combination
cargo-training), 266 tanker, 107 bulk container, 356 timber carrier, 12
specialized carrier; 145 dry cargo ships have long hatches ranging from
53 ft. to 79 ft. in length;
543 merchant ships based in Black Sea, 337 in Baltic Sea, 417 in Soviet Far
East and 192 in Barents/White Seas
Airfields: over 3,250 total; 550 with permanent-surface runways; 36 with
runways over 12,000 ft., 434 with runways 8,000-11,999 ft., 806 with runways
4,000-7 ,999 ft.
DEFENSE FORCES:
Nuclear weapons: satisfies major requirements of Soviet forces
Supply: fully supplies own needs
Military budget: the announced defense budget for 1972 is 17.9 billion rubles;
10.3% of total expenditures; this amount excludes certain items such as
military research and development; the dollar estimate of military expenditures,
less research and development, for 1972 is approximately $169 billion
350
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','7edad1d7d1bbd7ad23820057b9ba2f8eab612fd09b264ff3c951bb7b475897c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84bee3675ed5cbe2982b7aa38b69a16453e9e54dcf30f90e515b05faf17982d2',1973,'AE','United Arab Emirates','communications',378,'LAND:
32,000 sq. mi.; almost all desert, waste or urban
Land boundaries: 680 mi. {does not include boundaries
between adjacent U.A.E. states)
WATER:
Limits of territorial waters (claimed): 3 n. mi. for all
states except Sharjah-12 n. mi.
Coastline: 900 mi.
Railroads: none
Highways: 175 mi. bituminous, undetermined mileage of earth tracks
Pipelines: crude oil, 175 mi.
Ports: 2 major, 4 minor
Merchant marine: 3 cargo ships (1,000 GRT or over) totaling 7,700 GRT, 11,900 DWT
Civil air: no major transport aircraft
Airfields: 91 total, 37 usable; 3 with permanent-surface runways; 1 with runway
over 12,000 ft., 1 with runway 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.
Telecommunications: telephone system in Dubayy and Ash Sharigah, also links
these towns; Abu Dhabi Petroleum operates a telecom system throughout
the sheikhdom; key centers are at At Tarif, Habshan, and Az Zannah; 14,300
telephones; 35,000 radio and 15,000 TV receivers; 3 AM, 1 FM, and 2 TV
stations
DEFENSE FORCES:
Military manpower: males 15-49, about 43,000; about 22,000 fit for military service
Supply: mostly from U.K.
352
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
STAT Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Next 1 Page(s) In Document Exempt
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
UPPER VOLTA
LAND:
106,000 sq. mi.; 50% pastureland, 21% fallow, 10%
cultivated, 9% forest and scrub, 10% waste and other
uses (1967)
Land boundaries: 2,055 mi.
Railroads: 728 mi., 320 mi. meter gage, single track; Ouagadougou to Abidjan,
Ivory Coast line
Highways: 10,380 mi.; 250 mi. paved, 3,500 mi. improved, 6,630 mi. unimproved
Civil air: no major transport aircraft
Airfields: 59 total, 51 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 2 with runway 4,000-7,999 ft.
Telecommunications: all services generally poor; 2,600 telephones; 90,000 radio
receivers; 6,000 TV receivers; 2 AM, no FM, and 1 TV stations (broadcasts
temporarily suspended)
DEFENSE FORCES:
Military manpower: males 15-49, 1,347,000; 645,000 fit for military service; no
conscription
Supply: dependent on France
Military budget: for fiscal year ending 31 December 1973, $5.6 million; 12.1% of
total budget
356
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9','8a9572b1df0922ff0bb12f151adfd2911b039b1dea4c35142dd4799450a79c48','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cf6f0671b78a4c5f845e2a30b1a325994598ed7d6e275a5477d921c52871e37',1973,'UY','Uruguay','communications',382,'LAND:
72,200 sq. mi.; 84% agricultural land (73% pasture, 11%
cropland) 16% forest, urban, waste and other
Land boundaries: 840 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 410 mi.
Railroads: 1,870 mi., all standard gage and government owned
Highways: 32,200 mi.; 3,700 mi. paved, 4,600 mi. otherwise surfaced, 9,600 mi.
improved earth, 14,300 mi. earth tracks
Inland waterways: 1,068 mi.; used by coastal and shallow-draft river craft
Freight carried: highways 80% of total cargo traffic, rail 15%, waterways 5%
Ports: 4 major, 6 minor
Merchant marine: 13 ships (1,000 GRT or over) totaling 139,800 GRT, 219,500
DWT; includes 6 cargo, 7 tanker; includes 2 naval tanker sometimes used
commercially
Civil air: 15 major transport aircraft
Airfields: 98 total, 76 usable; 6 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 11 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: most modern facilities concentrated in Montevideo; 236,000
telephones; 1.1 million radio and 300,000 TV receivers; 68 AM, 3 FM, and 17
TY stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 728,000; 570,000 fit for military service; no
conscription
Supply: dependent on U.S. for current supplies, with few exceptions
Military budget: proposed for fiscal year ending 31 December 1973, $61.9 million
14% of central government budget
358
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
VATICAN CITY
LAND:
0.169 sq. mi.
Land boundaries: 2 mi.
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Telecommunications: 1 AM and 1 FM radiobroadcasting stations; 2,000-1ine
automatic telephone exchange
DEFENSE FORCES:
Defense is responsibility of Italy
360
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
VENEZUELA
D:
352,000 sq. mi.; 4% cropland, 18% pasture, 21% forest,
57% urban, waste, and other
Land boundaries: 2,598 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,740 mi.
Railroads: 233 mi. 4''8 1/2" gage; all single track; 107 mi. government owned,
126 mi. privately owned
Highways: 34,600 mi.; 11,200 mi. paved, 9,200 mi. gravel, 4,200 mi. improved
earth, 10,000 unimproved (including trails)
Inland waterways: 4,450 mi.; Orinoco River and Lake Maracaibo accept oceangoing
vessels
Pipelines: crude oi1, 3,800 mi.; refined products, 250 mi.; natural gas,
1,550 mi.
Ports: 6 major, 17 minor
Merchant marine: 42 ships (1,000 GRT or over) totaling 377,100 GRT, 548,600 DWT;
includes 24 cargo, 13 tanker, 3 bulk, 2 specialized carrier
Civil air: 59 major transport aircraft
Airfields: 453 total, 221 usable; 89 with permanent-surface runways; 7 with
runways 8,000-11,999 ft., 71 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: extensive radio relay; local telephone systems greatly expanded;
satellite ground station; over 445,000 telephones; est. 3 million radio and
980,000 TV receivers; 150 AM, 50 FM, and 36 TV stations; 3 submarine cables,
including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 2,448,000; 1,680,000 fit for military service;
120,000 reach military age (18) annually
Military budget: proposed for fiscal year ending 31 December 1973, $320.6 million;
about 10% of central government budget
362
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
‘Nts
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
VIETNAM, NORTH
LAND:
61,300 sq. mi.; 14% cultivated, 50% forested, 36% urban
inland water, and other
Land boundaries: 1,850 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 490 mi.
Railroads: 602 usable route mi., consists of about 25 mi. of standard gage
(4''8 1/2"), 438 mi. of meter gage (3''3 3/8"), and 139 mi. of dual gage
(4''8 1/2" and 3''3 3/8"); all single track, none electrified; all government
owned and operated; new rail line under construction between Kep and port
of Hon Gai
Highways: 9,100 mi., plus about 1,600 mi. of seasonally motorable tracks; 900 to
1,000 mi. bituminous surface-treated, remainder gravel, crushed stone, or earth
Inland waterways: 4,200 mi.; 1,800 mi. navigable perennially by craft drawing 6 ft.
363
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Ports: 3 major, 12 minor
Merchant marine: 6 ships (1,000 GRT or over) totaling 14,100 GRT, 14,400 DWT;
includes 3 cargo, 3 tanker; North Vietnam beneficially owns 2 additional ships
(1,000 GRT or over) of 13,700 GRT, 17,500 DWT which are operated by Hong Kong
shipping company under U.K. and Somali flags
Airfields: 16 total; 11 with permanent-surface runways; 2 with runway 8,000-
11,999 ft., 12 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Supply: dependent chiefly on U.S.S.R. and China for virtually all equipment;
smaller amounts from other Communist countries; produces negligible quantities
of infantry weapons, ammunition, and explosive devices
Military budget: no recent data available; for fiscal year ending 31 December
1962, estimated defense expenditures 382 million dongs; about one-fifth of
total budget (estimated value $103 million); military aid from U.S.S.R. and
China now so extensive that actual allocation of North Vietnam''s domestic
resources to defense would not be indicative of total military effort
364
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
VIETNAM, SOUTH
LAND:
66,000 sq. mi.; 25% arable (15% cultivated), 33% forested,
42% other
Land boundaries: 1,025 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 50 n. mi.)
Coastline: 1,650 mi.
Railroads: 770 mi.
Highways: 13,000 mi.; 3,000 mi. bituminous, 2,200 mi. gravel and crushed stone,
1,900 mi. improved earth, 5,900 mi. unimproved earth
Inland waterways: about 6,800 mi. navigable; more than 1,400 mi. navigable at all
times by vessels up to 6 ft. draft
Ports: 6 major, 20 minor
Merchant marine: 35 ships totaling 36,900 GRT, 53,500 DWT; includes 30 cargo, 3
tanker, 2 bulk; only 9 ships over 1,000 GRT
Airfields: 341 total, 168 usable; 64 with permanent-surface runways, 8 with
runways 8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 4 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 4,526,000; 3,065,000 fit for military service;
159,000 reach military age (18) annually
366
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
iv
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
WESTERN SAMOA
LAND:
1,100 sq. mi.; comprised of 2 large islands of Savai''i and
Upolu and several smaller islands, including Manono
and Apolima; 65% forested, 24% cultivated, 11% industry, ;
waste, or urban aueteatia
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 250 mi.
Railroads: none
Highways: 477 mi.; 80 mi. bituminous, remainder mostly gravel, crushed stone,
or earth
Inland waterways: none
Ports: 1 principal (Apia), 1 minor
Civil air: 2 major transport aircraft
Airfields: 4 total, all usable; 1 with runway 4,000-7,999 ft.; 1 seaplane
station
Telecommunications: 1,960 telephones; 32,000 radio receivers; 1 AM station
368
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
YEMEN (ADEN)
TURKEY
LAND:
111,000 sq. mi. (border with Saudi Arabia undefined); only
about 1% arable (of which less than 25% cultivated)
Land boundaries: 1,120 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 860 mi.
Railroads: none
Highways: 3,360 mi.; 200 mi. bituminous treated, 180 mi. crushed stone and gravel,
2,920 motorable track
Ports: 2 major (Aden and Al Mukalla)
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 1,600 GRT, 2,600 DWT
Pipelines: refined products, 20 mi.
Civil air: 7 major transport aircraft
Airfields: 138 total, 77 usable; 2 with permanent-surface runways; 2 with
runways 8,000-11,999 ft., 41 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: small system of open-wire line, multiconductor cable, and
radiocommunications stations; only center Aden; 9,600 telephones; 250,000
radio and 25,500 TV receivers; 3 TV and 1 AM stations; 4 submarine cables
(2 operational )
DEFENSE FORCES:
Military manpower: males 15-49, 377,000; 205,000 fit for military service
Military budget: for fiscal year ending 31 March 1971, $15,816,000; about 34.4%
of total budget
370
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
A
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
YEMEN (SANA)
D:
about 75,000 sq. mi. (parts of border with Saudi Arabia
| and Southern Yemen undefined); 20% agricultural,
1% forested, 79% desert, waste, or urban
Land boundaries: 950 mi.
_ WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 325 mi.','d8d34feefe490fdcd5b48e2ef0610cc2a915556bd9434728607247c62676cdf4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86aefe6dce519cb7bcc90d3a678da948379d5c6315dd00dd7d1faa01bccf3ae4',1973,'US','United States','communications',387,'This "Factsheet" on the U.S. is provided solely as a service to those
wishing to make rough comparisons of foreign country data with a U.S.
"yardstick." Information is from U.S. open sources and publications
and in no sense represents estimates by the U.S. intelligence community .
LAND:
3,615,211 sq. mi. (contiguous U.S. plus Alaska and Hawaii); 19% cultivated,
27% grazing and pasture, 32% forested, 22% waste, urban, and other
WATER :
Limits of territorial waters (claimed): 3 n. mi. (fishing, 12 n. mi.)
Railroads: 207,000 mi. (1969)
Highways: 3,730,000 mi. (1970); 2,411,000 mi. surfaced (1970)
379
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
COMMUNICATIONS (cont''d):
Inland waterways: 25,260 mi. of navigable inland channels, exclusive of the
Great Lakes; freight carried 951 million short tons (1970)
Pipelines: petroleum, 176,000 mi.
Ports: 25 major
Merchant marine: 1,478 ships (1,000 GRT or or) totaling 24,474,000 DWT (1971)
Civil air: 3,970 major transport aircraft (1970
Airfields: 12,000 (1971)
Telecommunications: 4,370 AM, 2,722 FM, 1,035 TV operating stations (1970);
120,155,000 telephones (1970), 58.6 telephones per 100 population (1970)
DEFENSE FORCES:
Personnel: army 1,386,000, navy and marines 1,151,000, air force 1,048,000 (1971)
Military budget: $78 billion (1972 est.)
380
Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
" Approved For Release 2004/09/15 : CIA-RDP79-01051A000600010002-9
Be NE ES TE OE i ae
< 1
= ° : : - S er a JERNAYA ZE
: Ss” eliesmere 2s ae A oe yen 2 a . ; ‘ 2 2 £3 oo SEVERNAYA ZEMLYA
F ; i i oR ; Peal ee ed : 2 ie . I : eed ss 4 % { Sy
i ¢ r
SvERDRUP ISLANDS.
wa bn
i wee a oc oF ALN |
ate
yi
— a re - | : : ee ee eee eee 2
: accel ain, oer Qo gateg on | 8 | oe a | ‘ : "> NOVAYA.ZEMLYA ie
| A) Sa bee ES Se ee : Gen A
Z . eee s Se : 3 é
; peaue gee 34 ; | | oc - > he: i |
i pe 1 eS p : So, ae é ! : : 7 sé Z . ae Oe Ne j Peas
a “Pee “ ah bic 2 ek. 8 oe a & i F ! ae fl) B® | : Sn
ae, ; '' ae % x4 " , y 4 . : ee ae aoe
“s | < aa | a or eee Poo. see ee -.
ae | BS Jaee | a | A : : im 4, St Lawrences
ot UNITED STATES | SEE ee . : 4 acre
ae (ALASKA) | A oe : tS a al ae . art | s
Wo { u + a ag i
i
i
|
Le
7
: ! \\ | '' Pl
= i 1 | 1
: i ! i i y Fe
: | “NPAEROE Is, 3 i “ : ay qT :
H ° : a
Seeaty’ SHETLANG IS. | : ere 5 i t =
. ORKNEY 15.9 | ES a F Cana | NG :
Is & A
sea lor H
H
a a HK ae ae ose
f ‘ i : 5 \\ Prva
: 4 ine e ‘ ! eT ae é os oysK eb ff: ALEUTIAN |ISLANDS
b ton Sor | a a ; { i é A } 7 an atin Ra
| : QUEEN CHARLOTTE IS’ Oy, '' arte % {i i | s yo: ae ’ $ oo
i H ;
* . MADEIRALIS.
Bo A Gr eka 4 ae A
ey
. 1, BONIN IS. HAWAIIAN 1S.
S mankaner 1s. | Marcus.
io ea DI A ARATAR coms . VOLCANO IS baled O C E A N
OnE. oA. IN PUR 6a = 2
oN REPUBLIC OF CHINA J. es
re ¢ of Hernan : ‘
i °° 94. UNITED STATES Nee 5
HAWANAN 1S. sy : b ims gut # 7
"> (HAMAL)) p . rc
} i CHAD | La
a ; — CHINA
: : om : SUD|AN \\ } c4
i GK - aes Saint Lucia : LACCADIVE 1S i : “ : . 1s -
ae | FORAY wICARAGUA Mahe OFM ecsnade Gee PORT. GUI oY (fn SRELANKAl , Ne ws oon
r eal fh eee oe mG NICOBAR IS. ¢ boa :
| Caopectin dosta mek ae eS be weroe rR pomee e oS ; :
| j oll 4 a a REPUBL MALDIVES GILBERT IS
be | pa rors
Palmore ts” | d o COLOMBIA . 4 toe | ; ’ & Ae =. i aie LL 4,
, “ : \\ , } Guck o#leu Fe : + Gt % Borneo F / ee A NEW GUINEA
sChrstmas | | f : Ar 7 G y f aa . Reg LA ft ia ss
of : - : GALAPAGOS {S. ai <4 Sumatra | ‘ es a } Vy. Pag? ''y : . ELLICE 1S.
el 1 hiked ae ‘ , S77 SS... sonomon}istanos . :
5 oO U T H j ARCHIPELAGO. moe oft oy De
H : : | , “ta “ eres, NS te. “, AG
- : ere Christmas +" 4 Pg ao Se
: . : Eee, * ;
: ; i ‘ i CORAL ty SAMOA BBP + |
Penrhyn 1. 3 bec H 4S hs
ney MARQUESAS 15. PA CAF ms +~— aE nEBRIOE, ol FITS -
i_ | — e : 5 SEA ‘ S
cen : — St. Helena |. { MALAGASY z | a 8 7
5 " TORROTO H 7 | A ‘ , :
— * 1. ARCHIPELAGO! O Cc IE A N j } x RERUBLIC MAURITIUS [ N D | A N ti 33 “y : New Catedonishy, **
} COOK 1s: SOCIETY IS. otahiti i : | H f Gime: REUNION ; is
f j j
S O10 72? A! AUSTRALIA
Tyaual IS. \\e .
, : \\ | Norfolk
| eels ee i OC ie Ade i wal. |i Teel + —RERWADEC TIS]
| | Faster t. { am 4+ t Lord Home t .
1 | i
if t “4 2 ina e
, | . 1 t Jo Wat aes N T ae ee $ e
+ . 4
| fb ntice on ‘he
j . Amsterdam t ay an TAS MAN NEW }
__ Teton de Cua “saint Paul b. : : SN ZEALAND,
; : a * SEA Palt
O C E > A N i : nt} v é CHATHAM IS.
x \\ phos 5 t
| 4 ’ | fs 48
i : Tt : | aT BOUNTY 1S
+ PRINCE EDWARD $$: ©, CROZET IS :
: oh. mae 1. Sa | * . ; KERGUELEN JS. ANTIPODES 1S
4 = i AUCKLAND 15.
| : FALKLAND 18. ; Pe ee 7 :
i : Eee? i 7 : : . MACQUARIE L.
gu col . | oles . 7.
i OC SOUTH H BOUNDARY REPRESENTATION IS : meee | 4
| SANDWICH IS. : NOT NECESSARILY AUTHORITATIVE q : + = at ——55 Tes 1a
: : . i 75 30 5
1s 20 45 a
45 30 15 >
a £5 i$ 120 195 30) Ss
Kpproved ror Kelease 2004/09/15 : CIA-RDP79-01051A000600010002-9','771e4eebdd6b64bf6862969bc233e0af702eb4b28bd0143cf104631440f4e7f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010002-9','txt','f2de3f556887a93f8ed5f172bc3a4b9bba2921c8e5d66782ba9b6148f100c44b','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010002-9/cia-rdp79-01051a000600010002-9_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcc9267cb94fa54bf0842e3f704f5b3629add9ba0b2ceb226065c539b7a33136',1974,'','','raw',1,'Bee
Approved for Release: 2018/04/27 C06727041
National 59 U (3° “Secret
Foreign
Assessment
Center
National
Basic Intelligence
Factbook
January 1979
~Seeret_
GC BIF 79-001
January 1979
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
NATIONAL SECURITY INFORMATION
Unauthorized Disclosure Subject to Criminal Sanctions
DISSEMINATION CONTROL ABBREVIATIONS
NOFORN-— Not Releasable to Foreign Nationals
NOCONTRACT~- Not Releasable to Contractors or
Contractor /Consultants
PROPIN- Caution—Proprietary Information Involved
NFIBONLY— NFIB Departments Only
ORCON- Dissemination and Extraction of Information
REL...
Controlled by Originator
This Information has been Authorized for
Release to...
Unless otherwise indicated, individual items are
TUNCTASSHHED.———
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
National Basic Intelligence
FACTBOOK
January 1979
Supersedes the July 1978 issuance of this
Factbook, copies of which should be destroyed.
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
FOREWORD
The National Basic Intelligence Factbook, a compilation of basic data
on political entities worldwide, is coordinated and published semiannually
by the Central Intelligence Agency. The data are prepared by components
of the Central Intelligence Agency, the Defense Intelligence Agency, and
the Department of State. Comments and suggestions should be addressed to
the Office of Geographic and Cartographic Research (Att: Factbook),
Central Intelligence Agency, Washington, D.C. 20505.
This publication is prepared for the use of U.S. Government officials.
The format, coverage and contents of the publication are designed to mect
the specific requirements of those users. U.S. Government officials may
obtain additional copies of this document directly or through liaison
channels from the Central Intelligence Agency.
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
~SECRET- January 1979
-t- Page
TANZANIA, loses ht tee teak te tl Ra A aM poate al oN ath 244
Tasmania (see AUSTRALIA)
THAILAND: os sscisechtist Seustecs eae aee cet, Shab clei ab a OR eels Pts cout Maree tt elaes BOR ot 245
FOG, ieecrisk EL AI Nol Sole hk AN EY Oya tt ote dedthee ch ped nd eve 247
TONGA ooo llassiinad tia dba ots ale het ae ea oa ee ed tenth tal Mids faut Seven 248
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO ooo. cceccecececcecesestctetevtte coves ceteveseiteteeeetece 249
TUNISIA ee 2oee Se STON get ales SPN es eel ee ase SAN etl Oct a pe 251
CORRE ic. 2e5ote 502 oN ciel ats po eile as ee aN Me la on Be ek oat a ete ee ta vt 252
TUVALU (formerly Ellice Islands) 00.0.0 ceccccccecee tcc cecececeeeeeeeeeeeeeee ce, 254
=
UGANDA 2) acted ese acd deed te i Trt Lele a tak ttn togh ote 255
Umm al Qaiwain (see UNITED ARAB EMIRATES)
USSR? siesta ee Nees a eet Sas tet el ee ne a Saf Te OT a 256
UNITED ARA® EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain oo. 259
United Arab Republic (see EGYPT)
UNITED KINGDOM ooo ccc cece cccececacecetevavenerestetieevins ss ccutvevestititeteveveneees 260
UNITED “STATES © ects. csc inal Pah Sia Re COT uh Ee peda itn oie ay 280
UPPER VOLEAS f3cccess3 20) ag ea Ge Ee ae se ea ts aaa 262
URUGUAY > -5s:che eset och iat ath tes lahat ae Le Ma A Cat, (heel val iy 263
ye.
VATICAND CIV. 2.3 ited Stat etek e al Orie ld, Grech tte ce eee A ade 265
VENEZUELA 220.3 5 footy Ei ec ett reech conden aloha es eR es oe 266
VIETNAM 252.022 css. Dect LE sea seerass Seen t Nl inn Sane chet ee tet ge! Be 268
—w—
WALLIS and FUTUNA once cc ccsesceecesteeestevsecetevesesceteeceveteteteeeteeere, 270
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara) 0.0.0.0. cocccceccccceseeeeeceeeeccce 270
WESTERN SAMOA ooo ccceecces sees sense nes ecucevevevevevesteseatsisesitivatesttavstivesteseterteceece. 271
—y—
YEMEN. (Adon). ¢:c0:2.35.05 Sy. esa tn a en Hei dewees din lee Ai rece, nie & 272
YEMEN ''(Sona) \\ 20: 30.6 Ones aes Recetas eon, Ga 8 OR a a ak 273
VUGOSLAVIA 4. iee tases, etegsle iS ea bebe Aten tenty hvac Mae aba 275
—7—
LAURE ects weet teen beaded land ihe So, nA RO Nt et tat ate cms ee a Ht ae Le Pog 277
AMBIA Shep Me vet Beret recenseblen at ert ithe, Wee EE De BER as ot tee ae Ct aie! 278
Zanzibar (see TANZANIA)
viii ~SECREF-
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
January 1979
SECRER.
NR Record TURKEY NR Record
NR Record
LAND
766,640 km*; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
252 “SEGREL_
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
January 1979
“SECRET
TURKEY
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km','91cbd5d071dd25ea465713c0f86903693de45bbebdbbbc2608e54b323ca18688','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61a47fdda5b69e339b353494fbedb99b29f2317d3406bb373d56fce97551d574',1974,'','','raw',1,'Approved for Release: 2018/04/27 C06726998
BASIC INTELLIGENCE FACTBOOK
JULY 1973
Supersedes the January 1973 issuance of this
Factbook, copies of which should be destroyed.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998 :
ae
teow
i
{
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data on political
entitics worldwide, is coordinated and published semiannually as part of the NIS
Program by the Office of Basic and Geographic Intelligence, Central Intelli-
_» gence Agency. The data are prepared by Office of the Geographer, Department
of State and by componcnts of the Defense Intelligence Agency and the Central
Intelligence Agency. Comments and canuestions should be addressed to the
Office of Basic ana Geographic Intelligence (Attn: NIS Factbook), Central
Intelligence Agency, Washington, D.C. 20505.
Additional copies of the Factbook are obtainable through established
~ channels for dissemination of the NIS.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
This edition is a compilation of the unclassified
information in the classified version of the Factbook.
It is issued for use by U. S. Government departments
and agencies.
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
Table of Contents
Page
SAN MARINO. 2... 2 ee ee ee ee ee ee eS 293
SAUDI ARABIA... - ee ee eee tee et ee eee 295
SENEGAL. . 2-2 ee et et ee te ee eee te eee 297
SEYCHELLES . 2. ee ee eet te ee te ee 299
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE. 2. we ee ee ee ee ee et 301
SIKKIM... 2 ee ee ee ee tt eet te HE 303
SINGAPORE. . .- - 2 es © eng aoe: Re a Meas lee SARI a NES, TEES Ms 305
SOMALIA. . .. 2. - eee ponies ee Yornlg vies Ro eee dats tet Se wee We 2 . . 307
SOUTH AFRICA... ee ee ee te ee ee 309
Southern Rhodesia (see RHODESTAJ
Sil aaah AFRICA. .... > bees Je ghigs vate Go are em 6 ieee ise uy
SPANISH SAHARA... .- hc le wale “ae ae Gah tae ee ogi Cee SS 317
SRI LANKA. 2. ee ee te et ee ee 319
SUDAN. . .. 2 ss eo eel Wes eee ce tat gi rel cal get, Ser ton ah Say va Sg, ea nes 321
SURINAM. » 2 ee ee ee te ee 323
SWAZILAND be gy ose ental a: atctah eae pO) be bg Wik en WE TES Be ew TS 325
SWEDEN . 2. we ee te ee te ee ewe ee ee ee 327
SWITZERLAND. . 2... 2 ee ee ee te ee eee ee eS oe « 329
SYRIA. 2. ew ee et te tee we ee ES 331
-T-
Tanganyika (see TANZANIA)
TANZANIA. wc eee te ee ee et ee ee & 333
Tasmania (see AUSTRALIA)
THAILAND... 2... ee ee te ee te ees gf ehhiig ig fe eel eh % 3330
TOGO... . es cia, ais tae ong. And Keen oper ae Pah te NS a ject wy eS
TONGA, . 2 ee ee et tte ett we eet we ee ee . . 339
TRINIDAD AND TOBAGO. ....-+.-s Se clbt ee hg seh ke Tal yor et to? ow) Ca seas . 341
TUNISIA. 2 2. ew ee ee eee te ee ee Sag Se 2849
TURKEY . 2... ee ee ee ee Band May US Sain EPS Mee tay seh ain aie S. te es TORO GS 345
-U-
UGANDA. 2. we ee ee te ee te ee wee ee 347
Umm al Qaiwain (see UNITED ARAB EMIRATES)
| ee eee ee PP To a 349
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Unm al Qaiwain . . 2 2 6 eee ees 351
United Arab Republic (see EGYPT)
UNITED KINGDOM... . eee ee eee te ee ee eee 353
UNITED STATES. . 2. eee ee te eee eet ee he eH 379
UPPER VOLTA, . . 2. ee ee eee et ee ee ee ee eee 355
URUGUAY. . .. 2 «> Ly cgi gh tortie. Ue dies Nel vas Meneses Sept ere, ee? cote ree. 357
-y-
VATICAN CITY 2. 2 we ee ee ee ee 359
VENEZUELA. . 2. 1 ee ee ee et ee ee ee he eee 361
VIETNAM, NORTH. . 2... - ee ee we ee Sree nds. Ghceear barr") sat War 0 eso fe 363
VIETNAM, SOUTH . 2. 6 6 we ee te ee eee te eh ee ee 365
v
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998
TURKEY
D:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive SPRY
Land boundaries: 1,600 mi. Seat
cover SAUDI
WATER: "Sy nama
Limits of territorial waters (claimed): 6 n. mi. Be
except in Black Sea where it is 12 n. mi. SUDAN ‘
(fishing, 12 n. mi.) £ RSS
Coastline: 4,475 mi. ETHIOPYA','a24946e0eda2487814d38bc598fdbba53715746ebaacc57387c8bc055ad24a8d','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50529365c70b7b4f93bd8d2878da727fe8f70fda6ff0806869fadffdcfe8460b',1974,'','','raw',1,'Approved for Release: 2018/04/27 C06727039
>
“NATIONAL INTELLIGENCE SURVEY
BASIC INTELLIGENCE FACTBOOK
JULY 1973
Supersedes the January 1973 issuance of this “ ARCHIVAL RECOR!
Factbook, copies of which should be destroyed FLEAS? RETURN TO ;
AGENCY ARCHIVES, ELDG. 4+.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data
on political entities worldwide, is coordinated and published
semiannually as part of the NIS Program by the Office of Basic
and Geographic Intelligence, Central Intelligence Agency. The
data are prepared by Office of the Geographer, Department of
State and by components of the Defense Intelligence Agency
and the Central Intelligence Agency. Comments and suggestions
should be addressed to the Office of Basic and Geographic
Intelligence (Attn: NIS Factbook), Central Intelligence Agency,
Washington, D.C. 20505.
Additional copies of the Factbook, both classified and un-
classified issues, are obtainable through established channels for
dissemination of the NIS.
THIS MATERIAL CONTAINS INFORMATION AFFECTING
THE NATIONAL DEFENSE OF THE UNITED STATES
WITHIN THE MEANING OF THE ESPIONAGE LAWS,
TITLE 18, USC, SECS. 793 AND 794, THE TRANSMISSION
OR REVELATION OF WHICH IN ANY MANNER TO AN
UNAUTHORIZED PERSON IS PROHIBITED BY LAW.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
WARNING
The NIS is National Intelligence and may not be re-
leased or shown to representatives of any foreign govern-
ment or international body except by specific authorization
of the Director of Central Intelligence in accordance with
the provisions of National Security Council Intelligence Di-
rective No. 1.
For NIS containing unclassified material, however, the
portions so marked may be made available for official pur-
poses to foreign nationals and nongovernment personnel
provided no attribution is made to National Intelligence or
the National Intelligence Survey.
Unless otherwise indicated, individual items
are UNCLASSIFIED/FOR OFFICIAL USE ONLY.
Classification designations are:
(OC) testes Confidential
(S)ve. 32) Secret
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
“SECRET.
Table of Contents
Page
SAN: MARINO: ce 6 cee See ge Sere Se a lade Gee an A ee ie a ae 383
SAUDE ARABIA g:o5 3 sd. ceed & Reel Se) eS ee es 385
SENEGAL 2. fms oe So te a te Se at ee LE Si eh aes PE eee 387
SEYCHELLES cigar ee eas oe be este eS he Ge so es eee Sa ae So Be 389
Sharjah (see UNITED ARAB EMIRATES)
STERRA (LEONE: ~) 05. &. gee Sees ete A Sa ae te Re ey ne ye pe en ee 391
ST KKEM 3.2 caste see A es ce sl ee Gave Con Be eee, Ree ee We eS 393
STINGAPORE 6 ~ eieccoe otesecs desea We: obo eG" Annee Moh ee io oes nao es Wee eee 395
SOMALTA Sic: senor SBS ee Pa EE ne ae ie een ee eee “al GE ws Rees of? 397
SOUTH: AFRICA? oc. cei eo 8 See eer te ar ee Ss Tee 0 We ee Se 399
Southern Rhodesia (see RHODESIA)
SOUTH-WEST AFRICA. . . 2. 2 1 ee we ee te we te 403
SPAINGG se Se oe Se ee ls Ba Sera tS re wl hee os tay Janine 8s 405
SPANTSH ‘SAHARA 5. 232-0. ee kee ee ee see ee eee ww Ce 409
SRE LANKA Ses setae ib tie es re ote Sore a wren ie) eo ee tated See ae 411
SUDAN o. ie-.g. oe sehen Sek mol as he Bh “Seer se tgs Sha tah re win et ems NS Ge tee eh oe 415
SURINAME. 02 xsc260 ve sei Soro ce A SE ee eR he ee as ar tar Sh eee eee 419
SWAZILAND =. 2.62 ccs S) nO ee Fe Oo Se Blea Mek % Bee, Byway teu ke 421
SWEDEN cue ce nea caetot le conte on medic phase, Gti Gams Mean Se 423
SWITZERUAND sc od ce ''o: 1,006 os van ts Fen Saas Ag Be, eae! Tey Cage 427
SYR TRG oy ec secs etek be ee ek eng es areas 429
-T:
Tanganyika (see TANZANIA)
TANZANTAS ob cake. oie eh ce etn eh nin 8 Case a a te cle Ca aS wate Se 431
Tasmania (see AUSTRALIA)
THAILAND 3. wc -8 we ees eR ee be aoe & ie we ee 495
TOGO a: yee UR Ow aw ae ee wd Se ee A Se wee ee 439
TONGA © 6. edge ee Se Sc ae eS rae ; : ‘ 44]
oe AND TOBAGO. F Bae bode al eh awe hare ee ss . . =. 443
iia Bah GPL Baa aE ND ON Cie DER ea vs ect aay ce Fs 445
TURKEY gn eh weet Ai APS ae i sg ge eet, BMG ee eit te aa Sk: 447
-U-
UGANDA 555 io oe eo do reser ree ee nse ae a eles wes es ee 451
nes al Qaiwain (see UNITED ARAB EMIRATES)
Sk, ake Byles Be Sw Gon Ey fa els NDR ne Ot age, ee 453
ED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain. ........2... 457
United Arab Republic (see EGYPT)
UNITED KINGDOM. 2... 1 1 we ee ee ee we tt ee te et 459
UNETED “STATES. o°-2 oc. se? Gece oe an ce ere Vel Gh ewe Sal Bek ele ne a 497
UPPER: VOLTA so: o:ce) te tee es oe I ee Be BO be Oe bes 463
URUGUAY cei eo ie eho eae Ser ay Boal ww Boer SP Gee: Be, Sas 82 weer 8 465
-V-
VATICAN: CLI a: 22-2, ecg: sés fortes Se et Se ea SCR te. ae a Gales 469
VENEZUELA se 5- ower ver era RS, “eee eee te yee el HS Bey Sere Re 471
VIETNAM, ‘NORTH gees detec tee ca eel ceive ei Ba ee ee 475
VEETNAM,. “SQUTHD ec. ce ios wee ae Se ee ee ae ee EP 479
v
SEGRE.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
““SRCRET.
NIS 27 TURKEY
D:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mi.)
Coastline: 4,475 mi.','d81506181d04ffbecc364831122ff5a940f94bbc6ccef504917bcbbdae630814','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b16d6189ad9fe36c5252e0f77a26cfa56aa1a3cc574655574f8dac5dcc41680',1974,'','','raw',1,'NATIONAL INTELLIGENCE SURVEY
BASIC INTELLIGENCE FACTBOOK
JANUARY 1974
DIA review(s) completed.
Supersedes the July 1973 issuance of this Factbook,
copies of which should be destroyed.
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data on political
entities worldwide, is coordinated and published semiannually as part of the NIS
Program by the Office of Basic and Geographic Intelligence, Central Intelli-
gence Agency. The data are prepared by Office of the Geographer, Department
of State and by components of the Defense Intelligence Agency and the Central
Intelligence Agency. Comments and suggestions should be addressed to the
Office of Basic and Geographic Intelligence (Attn: NIS Factbook), Central
Intelligence Agency, Washington, D.C, 20505.
Additional copies of the Factbook are obtainable through established
channels for dissemination of the NIS.
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
This edition is a compilation of the unclassified
information in the classified version of the Factbook.
It is issued for use by U. S, Government departments
and agencies.
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Next 5 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
AAPSO
ACCT
ADB
AFDB
ANZUS
ASA
ASPAC
BENELUX
BLEU
CACM
CARICOM
CARIFTA
CEAO
CEMA
CENTO
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
Afro-Asian People''s Solidarity Organization
Agency for Cultural and Technical Cooperation of
French-speaking Countries
Asian Development Bank
African Development Bank
ANZUS Council; treaty signed by Australia, New Zealand,
and the United States
Association of Southeast Asia
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market
Caribbean Free Trade Association
West African Economic Conmunity
Council for Mutual Economic Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
Economic Commission for Asia and the Far East
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Launcher Development Organization
European Monetary Agreement
vii
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
ENTENTE Political-Economic Association of Ivory Coast,
Dahomey, Niger, Upper Volta, and Togo
ESRO European Space Research Organization
EURATOM European Atomic Energy Comnunity
IADB Inter-American Defense Board
IDB Inter-American Development Bank
IFCTU International Federation of Christian Trade Unions
IHB International Hydrographic Bureau
IPU Inter Parliamentary Union
IRC International Red Cross
LAFTA Latin American Free Trade Association
LICROSS League of Red Cross Societies
NATO North Atlantic Treaty Organization
OAPEC Organization of Arab Petroleum Exporting Countries
OAS Organization of American States
OAU Organization of African Unity
OCAM Afro-Malagasy and Mauritian Common Organization
ODECA Organization of Central American States
OECD Organization for Economic Cooperation and Development
OPEC Organization of Petroleum Exporting Countries
SEATO South-East Asia Treaty Organization
UEAC Union of Central African States
UDEAC Economic and Customs Union of Central Africa
WEU Western European Union
WCL World Confederation of Labor
WFTU World Federation of Trade Unions
WPC World Peace Council
viii
A RT FE TE EE PED SE a TEES PTO VTA
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
sc
GA
ECOSOC
Tc
ICJ
Operating Bodies:
UNCTAD
TDB
UNICEF
Regional Economic
ECA
ECAFE
ECE
ECLA
Intergovernmental
FAO
GATT
IBRD
ICAO
IDA
IFC
ILO
IMCcO
IMF (FUND)
ITU
UNESCO
Security Council
General Assembly
Economic and Social Council
Trusteeship Council
International Court of Justice
Secretariat
U.N. Conference for Trade and Development
Trade and Development Board
U.N. Children''s Fund
Commissions:
Economic Commission for Africa
Economic Commission for Asia and the Far East
Economic Commission for Europe
Economic Commission for Latin America
Agencies Related to the U.N.:
Food and Agriculture Organization
General Agreement on Tariffs and Trade
International Bank for Reconstruction and Development
(World Bank}
International Civil Aviation Organization
International Development Association (IBRD Affiliate)
International Finance Corporation (IBRD Affiliate)
International Labor Organization
Inter-Governmental Maritime Consultative Organization
International Monetary Fund
International Telecommunication Union
United Nations Educational, Scientific, and Cultural
Organization
ix
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
UPU Universal Postal Union e a
UNCTAD U.N. Conference on Trade and Development
WHO World Health Organization
WMO World Meteorological Organization +
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
Committees:
Seabeds Committee United Nations Committee on the Peaceful Uses of the
Sea-Bed and Ocean Floor beyond the Limits of National
Jurisdiction
re]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Political, sociological, and economic data, including monetary
conversion rates, generally reflect information through mid-October
1973, except for population estimates, which have been projected to
1 January 1974. Military manpower estimates are as of 1 January 1974
except for average number of males reaching military age, which
are projected averages for the 5-year period 1974-78. Military and
communications data are as of 31 October 1974 unless otherwise indicated.
Most of the land utilization estimates are rough approximations,
and most of the statistical data are rounded (thousands and millions).
Figures for "arable" may reflect only the area actually under crops
rather than the potential cultivable. Fishing limits are included
only when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The difference
between the two is in the addition or subtraction of the value of
return on foreign investment. GDP equals GNP plus income earned
in the country but sent abroad, minus income earned abroad but
sent into the country. GDP thus tends to exceed GNP in debtor
countries, and the reverse is trué in ‘creditor countries.
Major ports are the largest maritime ports of the country,
relative to other ports of the same country, on the basis of
estimated port capacity, alongside berthing accommodations, and
commercial or naval importance. Minor ports are the remaining ports
of a country which have, relative to the major ports, significantly
lower estimated port capacity, fewer alongside berthing accommodations,
are of less commercial or naval importance. Major transport aircraft
are those weighing over 20,000 pounds. Military budgets are in U.S.
dollar equivalents. The dollar sign refers to U.S. dollars unless
otherwise stated. The abbreviation FY stands for U.S. fiscal year;
all years are calendar years unless otherwise indicated.
xi
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 34 APGHANISTAN
PEOPLE''S REPUBLIC
OF CHINA
LAND: ra
250,000 sq. mi.; 22% arable (12% cultivated, 10% mre
pasture), 75% desert, waste or urban, 3% forested >
Land boundaries: 3,425 mi.','42487cde1556db2d94966cab7c1565da7f44fd5a85a53bd57a6dc06a89e60c4b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ba2f864f58235aec31799c157c198a28f5bc71c8ba6529681ef113645c5e790',1974,'','','raw',1,'po ee ER
| Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
BASIC INTELLIGENCE FACTBOOK
JULY 1974
a
State Dept. review completed
DIA review
completed.
—y
Supersedes the January 1974 issuance of this
Factbook, copies of which should be destroyed.
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
rPORKEWORD
‘The Basic Intelligence Factbook. a compilation of basic data on political
«nuities worldwide, is coordinated and published semiannually as part of the NIS
Program by the Office of Basic and Geographic Intelligenc:, Central Intelli-
sence Agency. The data are prepared by Office of the Geographer, Department
of State and by components of the Defense Intelligence Agency and the Central
iutelligence Agency. Comments and suggestions should be addressed to the
Office of Basic and Geographic Intelligence (Attn: NIS Factbook), Central
intelligence Agency, Washington. D.C. 20505.
Additional copies of the Factbook are obtainable through established
vhannels for dissemination of the NIS.
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
a
aw:
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
CENTRAL INTELLIGENCE AGENCY
WASHINGTON, D.C. 20505
July 1974
MEMORANDUM FOR: All Factbook Recipients
SUBJECT : User Questionnaire for new Factbook
]. Publication of the NIS Factbook will terminate with
this issue. It will be replaced by a new USIB-approved basic
intelligence factbook. The new publication will closely
resemble the NIS Factbook in scope and will be produced semi-
annually. The first issue of the new factbook will appear in
January 1975.
2. The attached questionnaire is designed to assist us
in determining how future issues of the factbook can best serve
user needs. Your response is earnestly solicited. Please
return the completed questionnaire as soon as possible, using
the envelope provided.
“JOHN KERRY KING 27 ‘Oi
“Director
Basic and Geographic Intelligence
Attachment:
Factbook Questionnaire STAT
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
DATE _
1. Below is a listing of individual factbook entrics under the major subject headings. Please indicate your usc or non-use of each
item in the column provided.
U = Use it : N = Do not use it
Land Economy
Area —._._. GNP or GDP
—__._. Usage __._... Agriculture
—_.—.._ International boundaries ——_—. Fishing
-______. Major industries
Water ~-—_.... Shortages in foods, minerals, fuels
_____. Claimed limits of territorial seas
—__.___ Claimed limits for fishing
—_____. Crude steel
__...... Electric power
—_.___ Coastline —...... Exports
-—_..—.. Imports
People —_.__.. Major trade partners
—_.._. Population —.. Aid
_____. Ethnic divisions ——.... Economie
—____— Religion are Military
—____... Language —_—— Budget
Literacy ——._— Monetary conversion rate
_..__... Labor foree
Organized labor
—._ Fiscal year','58ce2942cff64f27e5ffee96f40caf7330c52f50d8de285dad50836a5904465e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5cf4f8f83508feb76353647f0aaeb784694201155d5fa76d09dcec86d173f3a',1974,'','','raw',1,'2 a GENTRAL INTELLIGENCE AGENEGY 00040004-5
41 6] Approved For Releagg,2005/0G/09 : C Pere saemeoueee
7 November 1975
STAT
YOON 31
Mellon Hall
Harvard Business School
Boston, Massachusetts 02163
STAT Dear | |
This is to let you know how much I enjoyed my
visit to the Harvard Business School last Monday,
Iwas very pleased to see how well you are getting
along with your associates and professors in the
PMD. I guess it was obvious that I felt rather
comfortable in the academic environment although
Umust admit some frustration from having to keep
my mouth closed,
After having heard the discussion in the
afternoon class on Soviet economics, ete., I did
. offer to send the professor some unclassified
material on the subject. Please pass the enclosed
publications to him,
Thank you again for your hospitality. I really
had a great time,
Sincerely,
aay
‘iE . Proctor
Deputy Director for Intelligence
Enclosures
Ee ait watt Distribution;
“oe”. Original - ia US mail _
ee oh, - a .. hee oG with list of enclosures
DDI Chrono with list of enclosures
C Ak Ale
Approved For Release 2005/06/09 : CIA-RDP80B01495R000200040004-5
STAT
Approved For Releage,2005/06/09 : CIA-RDP80B01495R000200040004-5
From: Deputy Director for Intelligence
List of Enclosures to the letter:
Allocation of Resources in the Soviet Union and China--1975
Hearings before the Subcommittee on Priorities and Economy in
Government of the Joint Economic Committee --Executive Sessions
of June 18 and July 21, 1975
Research Aid A(ER) 75-62
The Soviet Economy: 1974 Results and 1975 Prospects
March 1975
Research Aid A(ER) 75-68
The Soviet Grain Balance, 1960-73
September 1975
Research Aid A(ER) 75-71
Soviet Long-Range Energy Forecasts
September 1975
National Basic Intelligence Factbook
July 1975
Research Aid A(ER) 75-65
Handbook of Economic Statistics--1975
August 1975
USSR Agriculture Atlas
Approved For Release 2005/06/09 : CIA-RDP80B01495R000200040004-5
Approved For Release 2005/06/09 : Hess An Serene ON rag
WRarES
HARVARD UNIVERSITY
GRADUATE SCHOOL OF
BUSINESS ADMINISTRATION
pub SE Moyiated / GIS
Cwigtt erent (hes ry fc’ ZA2aé a
Zz . ey
aefrevodciar Belease 200519809 ; SI8-RDPSIE1495 000400040004-
ae fe Gor rae','674087b309872457ec150e15ec5140d3375443a307b5e81b7dac31bca3a7fc82','internet-archive','cia-readingroom-document-cia-rdp80b01495r000200040004-5','txt','d58c555ef07b70735498bb92e4c617a6de90cfdcf6392d2ff4afe6321017abd4','https://archive.org/download/cia-readingroom-document-cia-rdp80b01495r000200040004-5/cia-rdp80b01495r000200040004-5_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a7ee39b7089ea7d9e78e2b57c7f888b0b4eafc83b096bb80d7d6c3ee572100d',1974,'','','raw',1,'Neal
Approved For Release 2004/07/08 : CIA-RDP81M00980R000800080004-2 4
CENTRAL INTELLIGENCE AGENCY
Office of Legislative Counsel
Washinaton, D. C. 20505
Telephone:
27 November
Honorable Benjamin A. Gilman
House of Representatives
1226 Longworth House Office Building
TO:
Att: Rick Garon
Per your request, I am enclosing
three publications entitled "Potential
Implications of Trends in World
Population, Food Production, and
Climate (August 1974), "China: 1977
Midyear Grain Outlook (October 1977)
and the National Basic Intelligence
Factbook (July 1978).
~
tL
FORM GBSO E
poe) PGS Shen wens oe
EDITIONS
Approved For Release 2004/07/08 : CIA-RDP81M00980R000800080004-2','39c351f92602398c9aa092b3fc0ec8de958204408dc2d7e6decfb014ba0a37ed','internet-archive','cia-readingroom-document-cia-rdp81m00980r000800080004-2','txt','ba55f0335b31b2370fa0646489bca690232a110cf3a5ba52d09dab55c75eeb95','https://archive.org/download/cia-readingroom-document-cia-rdp81m00980r000800080004-2/cia-rdp81m00980r000800080004-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

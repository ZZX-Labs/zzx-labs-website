SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4f67ee14f906eccc24f83c71141359ccb44f2680b5f3cf03668605c3fd6a2bb',1974,'','','communications',5,'Railroads: 8,253 km standard gage (1.435 m); 143 km
double track; 72 km electrified
Highways: 60,000 km total; 21,000 km _ bituminous;
28,000 km gravel or crushed stone; 2,500 km improved
earth, 8,500 km unimproved earth
Inland waterways: approx. 1,689 km
253
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
“SECRET.
TURKEY}
January 1979
NR Record
Pipelines: 1,288 km crude oil; 2,055 km refined products
Ports: 10 major, 35 minor
Merchant marine: 162 ships (1,000 GRT or over) totaling
1,206,000 CRT, t,850,600 DWT; includes 14 passenger, 95
cargo, | liquefied gas, 22 tanker, 21 bulk, 7 specialized
carrier, 2. roll-on/roll-off cargo| |
Civil air: 24 major transport aircraft
Airfields: 120 total, 101 usable; 58 with permanent-sur-
face runways, 3 with runways over 3,660 m, 23 with
runways 2,440-3,659 m, 22 with runways 1,220-2.439 mn
Telecommunications: new trunk domestic radio-relay
net, good international service; 1.1 million telephones (2.7
per 100 popl.); 40 AM, 4 FM, and 36 TV stations; | coaxial
submarine cable; COMSAT. station near completion
DEFENSE FORCES
Military manpower: males 15-49, 9,786,000; 5,778,000 fit
for military service; about 430,000 reach military age (20)
annually
Personnel: 480,000 army, 45,400 navy, 53,000 air force
(970 pilots), 100,000 gendarmerie
Major ground units: 4 armies, 10 corps with corps troops,
15 infantry divisions, 2 mechanized divisions, 6 separate
armored brigades, 4 mechanized infantry brigades, 6
infantry brigades, 1 airborne brigade, 1 commando brigade,
3 mobile gendarmerie brigades, 2 regiments (1 infantry, !
armored), 33 battalions (22 artillery, 11 border); each field
army has | aviation regiment assigned und each corps has |
aviation hattalion
Shins: 12 destroyers, 2 Frigates, 13 submarines, 45 patrol
craft, 32 mine warfare, 5 amphibious ships, 74 amphibious
craft, 35 auxiliary, 55 service
Aircraft: 1,159 (464 jet); 647 (464 jet) in air force, 493 in
army aviation, 19 in naval air
Missiles: 8 SAM squadrons (Nike Hercules with 72
launchers)
Supply: mostly dependent on foreign sources, primarily
U.S.. Canada, and West Germany; manufactures some small
arms, trucks and adequate quantities of ammunition; builds
some of its naval ships including submarines with technical
and material assistance
Military budget: for fiscal year ending 28 February 1979,
$2.3 billion; about 20.7% of proposed central government
budget
INTELLIGENCE AND SECURITY
Turkish National Intelligence Organization (TNIO), in-
cluding Turkish National Security Service Directorate
(TNSS), domestic; Foreign Collection Directorate (FCD),
foreign; and Intelligence Directorate, Turkish General Staff
(J-2), domestic/foreign; Turkish National Police, domestic.
Ministry of Foreign Affairs, foreign; Gendarmerie, Intelli-
gence Section, domestic
NR Record
254
Approved for Release: 2018/04/27 C06727041','e15ab1be0a6b6ebcb9aae67d7ddc1e74018cab931be844b350fcf85746186f15','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3d05bcdcd6ba0fcec48be62738e02bb73dad2655fe6b67d67d7ff247e9a879f',1974,'','','communications',5,'Railroads: 4,991 mi.; 4,940 mi. 4''8 1/2" gage, 51 mi. double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi1, 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 594,900 GRT, 826,600 DHT;
includes 12 passenger, 52 cargo, 11 tanker, 10 bulk, 2 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 123 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 22 with runways
4 ,000-7 ,999 ft.; 2 seaplane stations
Teleconmunications: excellent international radiocommunication and fair domestic
telecommunication services; 654,500 telephones; 3.94 million radio and 133,000
TV receivers; 39 AM, 2 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,707,000; 5,730,000 fit for military service;
about 402,000 reach military age (20) annually
Military budget: for fiscal year ending 28 February 1974, $792.8 million; about
16% of central government budget
346
Approved for Release: 2018/04/27 C06726998','3f12afb7679ed6d6fbd9995b63f1709fd9f751fa11e529d9e6974f040abec1d6','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edc4b376aa3b3a0f3898440c466a9f8160eb0bb271ee572637c41d452f572f48',1974,'','','communications',5,'Railroads: 4,991 mi.; 4,940 mi. 4''8 1/2" gage, 51 mi. double track: 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. grave? or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 594,900 GRT, 826,600 DWT;
includes 12 passenger, 52 cargo, 11 tanker, 10 bulk, 2 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 123 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 22 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international radiocommunication and fair domestic
telecommunication services; 654,500 telephones; 3.94 million radio and 133,000
TV receivers; 39 AM, 2 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,707,000; 5,730,000 fit for military service;
about 402,000 reach military age (20) annual ly
78,000) ee navy 39,500, air force 54,600 (1,082 pilots), gendarmerie
75 ,000
Major ground units: 3 armies, 10 corps with corps troops, 13 infantry divisions,
2 mechanized divisions, 1 mechanized brigade, 1 armored division, 4 separate
armored brigades, 2 armored cavalry brigades, 4 infantry brigades, ] border
regiment, 34 battalions (22 artillery, 11 border, 1 on Cyprus), and 7
airborne/commando brigade; army aviation companies with about 5 aircraft
each are assigned to each army, corps, and division
Ships: 13 destroyers, 12 submarines, 71 patrol » 28 mine warfare, 60
amphibious craft, 40 auxiliary, 47 service
Aircraft: 1,252 including 437 (nonjet) in arny aviation, 15 (nonjet) in naval
air, 800 (605 jet) in air force
Missiles: 8 SAM squadrons (Nike Ajax/Hercules)
Supply: mostly dependent on foreign sources, primarily U.S., Canada, and West
Germany; manufactures some small arms, trucks and adequate quantities of
ammunition; builds some of its naval ships
448
““SECRE
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
_ SEsRET,
DEFENSE FORCES (cont''d):
Military budget: for fiscal year ending 28 February 1974, $792.8 million; about
16% of central government budget
INTELLIGENCE AND SECURITY:
National Intelligence Organization (MIT), including Turkish National Security
Service Directorate (TNSS), domestic/foreign; Turkish General Staff, J-2
Section, Intelligence Branch, domestic/foreign; Turkish National Polf
domestic; Ministry of Foreign Affairs, foreign; Gendarmerie, domestic
449
Approved for Release: 2018/04/27 C06727039','9d4a2b2fc51ea58b3df2ca018de5da87ff79463fa05f18e4af69d388d6b68cd4','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('697725a4522b3578f17829ad17ac1afd61da26f8022bccc1f51a3013f7073354',1974,'','','communications',5,'Railroads: 6 mi. (single track) 5''0"-gage, government-owned spur of Soviet line
Highways: 10,740 mi.; 420 mi. concrete, 980 mi. bituminous surfaced, 2,100 mi.
gravel, 3,630 mi. improved earth, and 3,610 mi. unimproved earth
Inland waterways: total navigability 760 mi.; steamers use Amu Darya
Ports: only minor river ports
Airfields: 72 total, 39 usable; 9 with permanent-surface runways; 6 with runways
8,000-11,999 ft., 10 with runways 4,000-7,999 ft.
Telecommunications: limited telephone, telegraph, and radiobroadcast services,
barely sufficient to meet civil and military requirements; 20,960 telephones;
108,000 radio receivers; no TV receivers; 1 AM, no FM, no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 4.7 million; 2.5 million fit for military
service; about 165,000 reach military age (22) annually
Supply: dependent on foreign sources, almost exclusively the U.S.S.R.
Military budget: for fiscal year ending 31 March 1972, $36.8 million; 20.3%
of total budget
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
vt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 20 ALBANIA
LAND:
WATER:
Railroads: 142 mi. standard gage, single track; government owned (1973)
Highways: 3,100 mi.; 300 mi. paved, 1,200 mi. crushed stone and/or gravel, 1,600
mi. improved or unimproved earth (1973)
Inland waterways: 27 mi. plus Albanian sections of Lake Scutari, Lake Ohrid,
and Lake Prespa (1973)
Freight carried: rail -- 3.1 million short tons, 123.3 million short ton/mi. (1971);
highways -- 43,0 millton short tons, 616.4 million short ton/mi. (1971)
Ports: 2 major (Durres, Vlore), 2 minor (1973)
Pipelines: crude oil, 110 mi.
Civil air: no major transport aircraft (1973)
Airfields: 11 total; 5 with permanent-surface runways; 6 with runways 8,000-
11,999 ft., 5 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military budget (announced): for fiscal year ending 31 December 1973, 589,000,000
leks; about 8.6% of total budget and 6.0% of est. GNP
PERE PERS
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
n
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 47 ALGERIA
LAND:
950,000 sq. mi.; 3% cultivated, 16% pasture and meadows,
1% forested, 80% desert, waste, or urban
Land boundaries: 3,890 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 735 mi.
Railroads: 2,414 mi.; 1,660 mi. standard gage, 663 mi. 3''5 9/16" gage, 91 mi.
meter gage; 188 mi. electrified; 120 mi. double track
Highways: 42,100 mi., of which 17,950 mi. are concrete or bituminous and the
remainder gravel, crushed stone, or improved earth
Ports: 9 major, 8 minor
Pipelines: crude oi1, 2,250 mi.; refined products, 180 mi.; natural gas, 1,785 mi.
Civil air: 20 major transport aircraft
Airfields: 252 total, 198 usable; 56 with permanent-surface runways; 21 with
runways 8,000-11,999 ft., 111 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: adequate domestic and international facilities in the north,
primarily radio communications in the desert; 184,100 telephones; 1,150,000
radio receivers; 250,000 TV receivers; 16 AM and 13 TV stations; 3 submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,840,000; 2,200,000 fit for military service;
average number reaching military age (19) annually 150,000
PARSE KLE EE OT LIS oS TT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 9 ANDORRA
LAND:
180 sq. mi.
Land boundaries: 65 mi.
Railroads: none
Highways: about 60 mi.
Civil air: no major transport aircraft
Airfields: none
Telecommunications: international circuits to Spain and France; 2 AM, 1 FM, 1 TV
station; about 1,800 telephones; 8,000 radio receivers, 2,800 TV receivers
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
DEFENSE FORCES:
Andorra has no defense forces; Spain and France are responsible for protection
as needed
TE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 59 ANGOLA
D:
481,000 sq. mi.; 1% cultivated, 44% forested, 22% meadows
and pastures, 33% other (including fallow)
Land boundaries: 3,150 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. (navy)
(fishing 12 n. mi.)
Coastline: 1,000 mi.
Railroads: 1,918 mi.; 1,724 mi. 3''6" gage, 194 mi. 1''11 5/8" gage
Highways: 45,000 mi.; 4,270 mi. bituminous-surface treatment, 28,000 mi. crushed
stone, gravel, or improved earth, remainder unimproved earth
Inland waterways: 2,000 mi. navigable
Ports: 3 major, 15 minor
Pipelines: crude of], 111 mi.
Civil air: 15 major transport aircraft
Airfields: 468 total, 390 usable; 21 with permanent-surface runways; 1 with
runway over 12,000 ft., 6 with runways 8,000-11,999 ft., 53 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: simple network of low-capacity open-wire and radio-relay
facilities; 30,450 telephones; 110,000 radio receivers; 21 AM, 7 FM, and no
TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,475,000, fit for military service, 735,000;
average number reaching military age (20) annually about 60,000 re
Defense is responsibility of Portugal
a
01S TAOOOGOOO OOO aan Ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010 -
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 81A ANTIGUA
LAND:
108 sq. mi.; 54% arable, 5% pasture, 14% forested,
9% unused but potentially productive, 18% wasteland
and built on VENEZUELA f
WATER: COLOMBIA mf
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 95 mi. ; ae
Railroads: 49 mi. narrow gage (2''6"), employed almost exclusively for handling
cane
Highways: 235 mi.; 150 mi. main, 85 mi. secondary
Ports: 1 major, 1 minor -
Civil air: 13 major transport aircraft
Airfields: 3 total, 1 usable; 1 with asphalt runway 9,000 ft.; 1 seaplane
station
Teleconmunications: automatic telephone system; 2,850 telephones; tropospheric
scatter links with Tortola and St. Lucia; 21,000 radio receivers, 8,600 TV
sets; 2 AM, 1 FM, and 1 TV stations; 2 coaxial submarine cables
12
ERC GALANT RRC e NTN NETO TAN ROPE DETRRN HEPRRETE:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
e
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 90 ARGENTINA','de116ef0f865166cb3d0b834cabe01f0c2ba1d1596194f449a062850b159ef02','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('075143e1e78d1d13aab3e8a0fc174f37ca598313ecda0bd25328a71f8a500c53',1974,'BR','Brazil','communications',6,'LAND:
1,070,000 sq. mi.; 57% agricultural (11% crops, improved
pasture and fallow, 46% natural grazing land), 25%
forested, 18% mountain, urban, or waste
Land boundaries: 5,850 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
(continental shelf, including sovereignty over
superjacent waters)
Coastline: 3,100 mi.
Railroads: 25,000 mi.; 2,000 mi. standard gage (4''8 1/2"), 13,750 ny. ‘broad
gage (5''6") 8,750 mi. meter gage (3''3 3/8"), 500 mi. 2''5S 1/2" gage;
about 1,035 mi. double and multiple track; 76 mi. electrified
Highways: 136,800 mi., of which 21,100 mi. paved, 40,700 mi. gravel, 72,400
mi. improved earth, and 2,600 mi.. unimproved earth
Inland waterways: 6,800 navigable mi.
Ports: 7 major, 21 minor
Pipelines: crude 011, 1,960 mi.; refined products, 1,370 mi.; natural
gas, 5,500 mi.
Civil air: 51 major transport aircraft
Airfields: 2,756 total, 2,002 usable; 75 with permanent-surface runways;
1 with runway over 12,000 ft., 22 with runways 8,000-11,999 ft., 263 with
runways 4,000-7,999 ft.; 10 seaplane stations
Telecommunications: foremost in telecom facilities in South America;
telephone network has 1,925,000 sets, radio relay widely used, 2
communications satellite ground stations; estimated 7 million radio receivers
and 3.6 million TV sets; 126 AM, 11 FM, and 50 TV stations
14
TT TT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
‘wi
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
DEFENSE FORCES:
Military manpower: males 15-49, 6,242,000; 4,620,000 fit for military service;
average number reaching military age (20) annually about 215,000
Supply: produces some weapons, ammunition, and motor transport, past
dependence upon U.S., Canada, and Western Europe being shifted almost
exclusively to Europe
Military budget: proposed for fiscal year ending 31 December 1973,
$444 ,000,000, about 10% of total central government budget
15
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 16 AUSTRIA
LAND:
32,400 sq. mi.; 20% cultivated, 26% meadows and pastures,
15% waste or urban, 38% forested, 1% inland water
Land boundaries: 1,605 mi.
Railroads: 4,073 mi.; 3,673 mi. government owned; 3,373 mi. standard gage of which
1,408 mi. electrified and 833 mi. double tracked; 300 mi. narrow gage (2''6")
of which 57 mi. electrified; 400 mi. privately owned; 229 mi. standard gage
of which 109 mi. electrified; 171 narrow gage (2''6" and 3''3 3/8") of which
55 mi. electrified
Highways: 20,346 mi. total; 6,056 mi. federal (5,656 mi. bituminous, concrete,
stone block, 400 mi. crushed stone, gravel, improved earth); 14,290 mi.
provincia! (4,340 mi. bituminous, concrete, stone block, 9,950 mi. crushed
stone, gravel, improved earth); additionally about 38,000 ii. of communal
roads, mostly of gravel, crushed stone, and improved earth
Inland waterways: 267 mi.; carries 5% freight, 6% passengers
Ports: 2 major river
Pipelines: crude oi], 500 mi.; natural gas, 1,000 mi.
Civil air: 10 major transport aircraft
Airfields: 65 total, 54 usable; 12 with permanent-surface runways; 2 with run-
ways 8,000-11,999 ft., 9 with runways 4,000-7,999 ft.
Telecommunications: highly developed and efficient; excellent national and
international services; extensive TV and radiobroadcast systems with 100 AM,
76 FM, and 200 TV stations; 1.75 million telephones; 2.55 million radio
receivers; 1.76 million television receivers
DEFENSE FORCES:
Military manpower: males 15-49, 1,686,000; 1,355,000 fit for military service;
average number reaching military age (19) annually about 55,000
Personnel: army 42,200, air force 4,400 (143 pilots), gendarmerie 11,000
Major ground units: 7 brigades (4 infantry, 3 armored infantry), 3 artillery
regiments (battalion-size), 3 armored battalions, 1 infantry battalion, 4
engineer battalions, 3 antiaircraft battalions, 1 reconnaissance battalion
Aircraft: 164 (55 jets); 48 prop; 2 turboprop; 64 helicopters
Supply: produces some small arms and ammunition, trucks, and tank destroyers;
current sources of other items are the U.S., Western Europe, Sweden,
and the Communist countries
Military budget: for fiscal year ending 31 December 1973, $247 million; about
3.6% of the federal budget
20
PEELE IGE! I LI a OA TT OI OM RTT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
|
i
Cease cet ceiemetithencalccilnedlhineiilieh iene il i ictimmanimmeaanlll
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 81B BAHAMAS
LAND:
4,400 sq. mi.; 1% cultivated, 29% forested, 70% buiit
on, wasteland, and other
VENEZUELA
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 2,200 mi. (New Providence Is. 47 mi.)
Railroads: none
Highways: 1,150 mi.
Ports: 2 major, 9 minor
21
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Civil air: 5 major transport aircraft
Airfields: 58 total, 51 usable; 23 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 22 with runways 4,000-7,999 ft.; 4 seaplane
stations ci
Telecommunications: telecom facilities highiy developed, including 50,000
telephones in totally automatic system; tropospheric scatter link with
Florida; 90,000 radio receivers and 2,000 TV sets, 1 AM and 2 FM stations;
3 coaxial submarine cables
22
eT NE a NT ean | TT Se ane” Se inn ® EReen NNN Fe Se ma aay ROT NaI NG £5 GEES H WAR! NENT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 32C BAHRAIN
LAND :
230 sq. mi. plus group of smaller islands; 5% cultivated,
negligible forested area, remainder desert, waste,
or urban
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 100 mi.
Highways: 120 mi. bituminous surfaced; undetermined mileage of natural surface
tracks
Ports: 1 major
Piplines: crude oi], 35 mi.; refined products, 10 mi.; natural gas, 20 mi.
Civil air: 5 major transport aircraft (all registered in the U.K.)
23
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Airfields: 5 total, 2 usable; 1 with permanent-surface runway; 1 with runway over
12,000 ft; 1 seaplane station
Teleconmunications: excellent international telecommunications; limited
domestic services; 12,850 telephones; 75,000 radio receivers; 10,000 TV sets; =
1 AM radiobroadcast station; satellite earth station; tropospheric scatter
Bahrain to Qatar and United Arab Emirates
DEFENSE FORCES:
Military manpower: males 15-49, 62,000; fit for military service 34,000
24
i a ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 36A BANGLADESH
LAND:
55,000 sq. mi.; 66% arable (including cultivated and
fallow), 18% not available for cultivation, 16%
forested
Land boundaries: 1,575 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 360 mi,
Railroads: 1,752 mi.; 1,178 mi. meter gage, 554 mi. broad gage, 20 mi. narrow
gage; 87 mi. double track; government owned
Highways: 28,350 mi.; 2,450 mi. paved; 1,750 mi. gravel, 24,150 mi. earth
Inland waterways: 4,600 mi.; river steamers navigate main waterways
Ports: 1 major; 5 minor
Civil air: 8 major transport aircraft
Airfields: 62 total, 20 usable; 19 with permanent surface runways; 3 with runways
8,000-11,999 ft., 9 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: inadequate international radiocommunications and landline
service; fair domestic wire and radiocommunication service; fair broadcast
service; 52,000 (est.) telephones; 630,000 (est.) radio sets; 30,000
(est.) TV sets; 5 AM, no FM, and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 15,677,000; 8,425,000 fit for military service -
Supply: military supplies consist of those captured from West Pakistani forces
and materiel provided by India and U.S.S.R.
Military budget: for fiscal year ending 30 June 1973, $52,980,130; about 5.4% of
the central government budget
26
LT a OT a a age ol
aici itil iiaea ied tesa aan ealeth amie ne nies neg nn el A RE EEO:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 81E BARBADOS
LAND:
166 sq. mi.; 60% cropped, 10% permanent meadows, 30% built
on, waste, other
VENEZUELA g
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 60 mi.
Railroads: none
Highways: 850 mi.; 800 mi. paved, and 50 mi. gravel, and earth
Ports: 1 major, 2 minor
Civil air: 4 major transport aircraft
Airfields: 1 with permanent-surface runway 8,000-11,999 ft.; 1 seaplane station
Telecommunications: islandwide automatic telephone system with 36,700
telephones; tropospheric scatter link to Trinidad; VHF links to St. Vincent
and St. Lucia; 97,000 radio and 26,000 TV sets, 2 AM, 1 FM, and 1 TV stations;
1 telegraph submarine cable; communications satellite earth station .
DEFENSE FORCES:
Military manpower: males 15-49, 49,000; 36,000 fit for military service; average
number reaching military age, (18) annually, 3,000; no conscription
! TT A Te a ea TE a oe a ee ae Sane i NaN SINESSE Coe
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 5 BELGIUM
LAND:
11,800 sq. mi.; 28% cultivated, 24% meadow and pasture,
28% waste, urban, or other; 20% forested
Land boundaries: 856 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 40 mi.
D:
286,000 sq. mi; 2% cultivated, 7% other arable, 15%
permanent pasture, grazing, 29% forest, 47% barren
mountains, deserts, and cities
Land boundaries: 3,930 mi.
ARGENTINA) >
WATER:
Limits of territorial waters (claimed): 3n. mi. (fishing
200 n. mi.)
Coastline: 4,000 mi.
Railroads: 5,511 mi.; 2,086 mi. 5''6" gage, 154 mi. 4''8 1/2" cage, 2,644 mi.
3''3 3/8" gage, 69 mi. 2''6" gage, 22 mi. 1''11 5/8" gage, 536 mi. specific gage
not given; 199 mi. double track; 711 mi. electrified
Highways: 38,400 mi.; 5,200 mi. paved, 19,200 mi. gravel, 14,000 mi. improved
and unimproved earth
Inland waterways: 451 mi.
Pipelines: crude oi], 470 mi.; refined products, 490 mi.; natural gas, 200 mi.
Ports: 10 major, 20 minor
Civil air: 48 major transport aircraft
Airfields: 459 total, 345 usable; 44 with permanent-surface runways; 3 with run-
ways &,000-11,999 ft., 56 with runways 4,000-7,999 ft.; 7 seaplane stations
Telecommunications: extensive radio relay network; telephone network modern,
425,000 instruments; communications satellite ground station; 2.5 million
radio and 600,000 TV receivers; 148 AM, 30 FM, and 29 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,569,000; 1,935,000 fit for military service;
average number reaching military age (19) annually about 108,000
64
eA ASI TTL EET RSI EE SE CH GE TERI LES OS ADESSO PATE SS SE SP NES
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 39A CHINA, PEOPLE''S REPUBLIC OF
LAND:
3.7 million sq. mi.; 11% cultivated, sown area extended by
multicropping, 78% desert, waste, or urban (32% of
this area consists largely of denuded wasteland,
plains, rolling hills, and basins from which about 3%
could be reclaimed), 8% forested; 2%-3% inland water
Land boundaries: 15,000 mi.
WATER: ;
Limits of territorial waters (claimed): 12 n. mi. AUSTRALIA
Coastline: 9,000 mi. : :
Inland waterways: 105,000 mi.; 25,000 mi. navigable by modern motorized craft
Pipelines: 90 mi. crude in Sinkiang Province, about 500 mi. crude network under *
construction between oilfields and ports in Northeast China
Ports: 9 major, 180 minor
Airfields: 379 total; 239 with permanent-surface runways; 6 with runways over
12,000 75 with runways 8,000-11,999 ft., 216 with runways 4,000-7,999
ft.; 1 seaplane station A
x
y
66
atten aan nannemen atime aaaatiolinnpsnne Ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
PEOPLE''S REP.
NIS 39B CHINA, REPUBLIC OF Oren
LAND:
14,000 sq. mi. (Taiwan and Pescadores); 24% cultivated,
6% pasture, 55% forested, 15% other (urban, industrial,
denuded, water area)
bf ser or ctins
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 615 mi. Taiwan, 285 mi. offshore islands
(PHILIPPINE S,
Pipelines: 382 mi. refined products, 60 mi. natural gas
Ports: 7 major, 9 minor
Airfields: 61 total, 37 usable; 25 with permanent-surface runways; 2 with runways
over 12,000 ft., 10 with runways 8,000-11,999 ft., 13 with runways 4,000-7 ,999
ft.; 2 seaplane stations
Telecommunications: good international and domestic service; 493,000 telephones;
3 million radio receivers; 1 million TV receivers; 74 AM, 4 FM, and 3 main «
TV stations, 2 secondary and 2 rebroadcast TV stations, plus 5 relay stations;
1 international satellite station (operational), 1 under construction;
radio-relay links to Hong Kong and the Philippines; submarine cables planned
DEFENSE FORCES:
Military manpower: males 15-49, 3,910,000; 2,930,000 fit for military service;
average number currently reaching military age (19) annually 200,000
68
LL eT TY PN TH ESE Fe Rese Pega DOTTIE NPN SE BSS SSS DETTORI POON (I OHORO:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 85 COLOMBIA
LAND: : BRAZIL
440,000 sq. mi.; settled area 28% consisting of cropland os
and fallow 5%, pastures 14%, woodland, swamps, and
water 6%, urban and other 3%; unsettled area 72% --
mostly forest and savannah
Land boundaries: 3,750 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,500 mi.
Railroads: 2,160 mi., all 3''0" gage, single track, 22 mi. electrified «
Highways: 29,200 mi.; 4,000 mi. paved, 18,200 mi. crushed stone or gravel,
3,900 mi. improved earth, 3,100 mi. unimproved earth
Inland waterways: 8,900 mi., navigable by river boats
Pipelines: crude oi1, 2,000 mi.; refined products, 830 mi.; natural gas, 370 mi.;
natural gas liquids 80 mi.
Ports: 5 major, 5 minor
Civil air: 108 major transport aircraft (including 9 military commercial transports)
Airfields: 884 total, 685 usable; 39 with permanent-surface runways; | with
runway over 12,000 ft.; 6 with runways 8,000-11,999 ft., 82 with runways
4,000-7,999 ft.; 11 seaplane stations
Telecommunications: rapidly improving nationwide telecom system; communications
satellite ground station; 1.05 million telephones; 6 million radio and
1.2 million TV receivers; 290 AM, 130 FM, and 18 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 5,704,000; 3,375,000 fit for military service;
average number reaching military age (18) annually about 248,000
70
2 ENN NESTE PSE ASAT DEPENDS AM RISER RRR 00 EEN NN TOS NET CAG ES OPT EGE OM AN ERTS TIE OH PR NORE A ET MU ERR! 19 FT ARERR
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 62 COMORO ISLANDS
LAND:
Bs 838 sq. mi.; 4 main islands; forests 16.0%, pasture 6.8%,
cultivable area 48.3%, non-cultivable area 28.9%
WATER:
Limits of territorial waters (claimed): 12 n. mi.
t Coastline: 211 mi.
Railroads: none
Highways: 621 mi.; approximately 183 mi. bituminous, remainder crushed stone or
gravel
Ports: 1 minor (Moroni on Grande Comore)
Civil air: 4 major transports (registered in France)
71
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Airfields: 4 total, 4 usable; 4 with permanent surface runways; 4 with runways
4,000-7,999 ft.; 1 seaplane alighting area
Telecommunications: minimal system of HF radiocommunication stations for inter-
island and external communications to Malagasy and Reunion; Dzaoudzi center
but of slight significance; 500 telephones; 35,000 radio receivers; 1] AM,
1 FM, and no TV stations
DEFENSE FORCES:
Defense is the responsibility of France
72
Te eT eT | Oa a ee a 4 A RE TaN tTNSTaNG Penn SNORE SS
CRED TROOPS.
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 52E CONGO
D:
135,000 sq. mi.; 63% dense forest or woodland, 33%
cultivable or grazing (2% cultivated est.), 4% urban
or waste
Land boundaries: 2,805 mi.
WATER:
Limits of territorial waters (claimed): 15 n. mi.
Coastline: 105 mi.
Railroads: 490 mi., 3''6" gage, single track
Highways: 6,741 mi.; 360 mi. bituminous surface treated; remainder gravel,
laterite, or improved earth
Inland waterways: 4,030 mi. navigable
Ports: 1 major
Civil air: 8 major transport aircraft
Airfields: 69 total, 44 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 16 with runways 4,000~-7 ,999 ft.; 1 seaplane station
Telecommunications: all services only fair; barely adequate for government and
public; principal network is comprised of 30 low-capacity, low-powered radio
communication stations; few wire lines connect key centers of Brazzaville,
Pointe-Noire, and Dolisie with maximum of 21 channels; 10,600 telephones;
70,000 radio receivers; 2,500 TV receivers; 3 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 244,000; 115,000 fit for military service;
about 10,000 reach military age (20) annually
74
ail tet a ee ee Te
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 103 COOK ISLANDS
ND:
About 93 sq. mi.
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: about 75 mi.
Railroads: none
Highways: at least 70 mi.
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
75
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 76 COSTA RICA
LAND:
19,700 sq. mi.; 30% agricultural land (8% cultivated, 22%
meadows and pasture), 60% forested, 10% waste, urban,
and other
Land boundaries: 415 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing
200 n. mi.; “specialized competence" over living
resources to 200 n. mi.)
Coastline: 800 mi.
Railroads: 407 mi.; 395 mi. 3''6" gage, 12 mi. 3''0" gage, all single track, 72 mi.
electrified
Highways: 13,700 mi.; 1,000 mi. paved, 3,800 mi. otherwise improved, 8,900 mi.
unimproved earth
Inland waterways: about 455 mi. perennially navigable
Pipelines: refined products, 80 mi.
Ports: 3 major, 4 minor
Civil air: 15 major transport aircraft
Airfields: 207 total, 128 usable; 9 with permanent-surface runways; 10 with
runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: good domestic telephone service; 75,500 telephones; «
connection into Central American microwave net; 340,000 radio and 125,000 TV
receivers; 44 AM, 8 FM, and 11 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 424,000; 290,000 fit for military service; average Pe
number reaching military age (18) annually about 24,000
Supply: dependent on imports from U.S.
78
ES SIE HEE THERESE EPP OP HERE 1 ET PO FRB PT CSE CRO TR SCTE EM PE PG TE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 78 CUBA
LAND:
44,200 sq. mi.; 35% cultivated, 30% meadow and pasture,
20% waste, urban, or other, 15% forested
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 2,320 mi.
Railroads: 9,150 mi. government owned; 3,150 mi. common carrier lines (8 mi.
double track and 95 mi. electrified) and about 6,000 mi. plantation- ’
industrial lines; common carrier lines comprise 3,100 mi. 4''8 1/2" standard
gage, and about 50 mi. 3''0" and 2''6" narrow gage; plantation-industrial
lines comprise about 4,000 mi. standard gage and 2,000 mi. narrow gage
Highways: 12,800 mi.; 5,400 mi. paved, 7,400 mi. gravel and earth surfaced
Iniand waterways: 150 mi.
Pipelines: natural gas, 50 mi.
Ports: 8 major (including U.S. Naval Base at Guantanamo), 44 minor; Guantanamo
under U.S. control
Civil air: 33 major transport aircraft
Airfields: 378 total, 194 usable; 40 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 27 with runways 4,000-7 ,999 ft.; 11 seaplane
stations
Telecommunications: modern facilities adequately serve military and most civil
needs; excellent international facilities, satellite ground station under
construction; 320,000 telephones; 1.5 million radio and 600,000 TV receivers,
100 AM, 25 FM, and 23 TV stations; 6 submarine cables, including 1 coaxial
80
a TT a Te He ee iY eSNG Gh HENSON: a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 25C CYPRUS
LAND
TURKEY
"3,572 sq. mi.; 47% arable and land under permanent crops,
18% forested, 10% meadows and pasture, 25% waste,
urban areas, and other
WATER:
Limits of territorial waters (claimed): 12 n. mi. eeu
Coastline: 400 mi. (approx . ) ‘ ARABIA
Railroads: none :
Highways: 5,000 mi.; 2,100 mi. bituminous surface treated; 2,900 mi. gravel,
crushed stone, and earth
Ports: 3 major, 6 minor o
Civil air: 9 major transport aircraft
Airfields: 20 total, 12 usable; 5 with permanent-surface runways; 2 with runways
8,000-11,999 ft.; 3 with runways 4,000-7,999 ft.
Telecommunications: moderately good telecommunication system; 52,706
telephones; 180,000 radio receivers; 65,000 TV receivers; 5 TV, 12 AM, and
4 FM stations; tropospheric scatter circuits to Greece and Turkey
82
ere ieee en iy 1010) by daeeemeenaiaiame bammeeed
Approved For Release 2004/08/31 : CIA-RDP79-01051A0006000 -
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 18 CZECHOSLOVAKIA
Eo NORWAY,
LAND:
49,400 sq. mi.; 42% arable, 14% other agricultural, 35%
forested, 9% other
Land boundaries: 2,200 mi.
Railroads: none
Highways: 460 mi.; 230 mi. paved, 160 mi. gravel, crushed stone, or stabilized
earth surface, 70 mi. unimproved
Ports: 2 minor
89
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Civil air: no major transport aircraft
Airfields: 1 with asphalt runway 4,830 ft.
Telecommunications: 2,300 in fully automatic telephone network; VHF interisland
link to St. Lucia; 15,000 radio receivers; 100 TV receivers; 1 AM station ¥
90
RADE RE GLEE SET OTTER
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 80 DOMINICAN REPUBLIC
18,800 sq. mi.; 14% cultivated, 4% fallow, 17% meadows
and pastures, 45% forested, 20% built-on or waste
Land boundaries: 224 mi. “costa ih
— ‘dbname,
WATER: “ E : COLOMBIA
Limits of territorial waters (claimed): 6 n. mi. (fishing
12 n. mi.)
Coastline: 800 mi.
VENEZUELA
V@CUADOR
Railroads: 1,000 route mi. of whic
(3''6" gage) and 935 mi. private
different gages ranging from 1''
Highways: 6,700 mi.; 3,250 mi. pav
Pipelines: product lines (1.5 mi.
Ports: 5 major, 17 minor
Civil air: 16 major transport airc
h 65 mi. government-owned common carrier
ly owned plantation network (approximately 4
10 1/2" to 4''8 1/2", with 2''6" predominating)
ed, 3,450 mi. gravel and improved earth
and 43 mi.) under construction
raft
Airfields: 65 total, 45 usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 7 with runway
Telecommunications: relatively eff
radio relay network; 65,000 tel
101 AM, 31 FM, and 8 TV station
DEFENSE FORCES:
Military manpower: males 15-49, 1,
S$ 4,000-7,999 ft.; 1 seaplane station
icient domestic system based on islandwide
ephones; 450,400 radio and 160,000 Ty receivers,
S; 3 submarine cables, inc','a9793922c7f32d5944bda6726b1bc42ff71186a971bd9c1afe215ee70a13efee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecdb9d9c8c6397aefa8615c0a30dbc3d4d3dad508035113278db44cbb55a0d46',1974,'BR','Brazil','communications',7,'luding 1 coaxial
036,000; 655,000 fit for military service; 52,000
reach military age (18) annually
Supply: dependent upon U.S. and Western Europe
PT i RY
Approved For Rele
92
ase 2004/08/31 : CIA-RDP79-0100 1 ROOTS OOO TUCO aT nemanennNIE:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 87 ECUADOR
106,000 sq. mi. (including Galapagos Islands); 11%
cultivated, 8% meadows and pastures, 55% forested,
26% waste, urban, or other (excludes the Oriente
and the Galapagos Islands, for which information is
not available)
Land boundaries: 1,200 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,390 mi. (includes Galapagos Is.)
Railroads: 660 mi.; 615 mi. 3''6" gage, 45 mi. 2''5 1/2" gage; al] single track
Highways: 14,200 mi.; 1,900 mi. paved, 5,000 mi. gravel, 1,800 mi. improved
earth, 5,500 mi. unimproved earth
Inland waterways: 960 mi.
Pipelines: crude oi1, 390 mi.; refined products, 50 mi.
Ports: 2 major, 1] minor
Civil air: 46 major transport aircraft (includes 5 military/commercial transports)
Airfields: 200 total, 178 usable; 15 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: facilities generally adequate only in largest cities; 2
satellite ground station; 110,000 telephones; 680,000 radio and 120,000 TY
receivers; 240 AM, 37 FM, and 11 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,606,000; 1,020,000 fit for military service;
average number reaching military age (20) annually 66,000
94
ee TT TTT Ty ay oe a SN nT Ferme eSerneD Gh Pepe vn SERS SSaTGI-RSSDGD GT SHOUT GUTH BONEN FOEPENREEE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 53 EGYPT
D:
386,200 sq. mi. (including 22,200 sq. mi. occupied by
Israel); 2.8% cultivated (of which about 70% multiple
cropped); 96.5% desert, waste, or urban; 0.7% inland
water
Land boundaries: 1,570 mi. (1967), excludes occupied area
1,534 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (plus
n. mi. “necessary supervision zone")
Coastline: 2,140 mi. (1967), excludes occupied area 1,340 mi.
Railroads: 3,358 mi.; 570 mi. double track; 15 mi. electrified; 2,976 mi. 4''8 1/2"
gage, 156 mi. 3''3 3/8" gage, 226 mi. 2''5 1/2" gage
Highways: 29,000 mi.; 5,190 mi. paved, 7,130 mi. gravel, crusned stone, and
improved earth, 16,680 mi. unimproved earth, additional 1,150 mi. (mostly
paved) in territory (Sinai) occupied by Israel
Inland waterways: 2,100 mi.; Suez Canal, 100 mi. long, temporarily closed to
navigation because of sunken vessels; normally used by ocean-going vessels
drawing up to 38 ft. of water; Alexandria-Cairo waterway navigable by barges
of 500-ton capacity; Nile and large canals by barges of 420-ton capacity;
Ismailia Canal by barges of 200- to 300-ton capacity; secondary canals by
sailing craft of 10- to 70-ton capacity
Freight carried: Suez Canal (1966) -- 242 million tons of which 175.6 million
tons were POL
Pipelines: crude oil, 185 mi.; refined products, 390 mi.; natural gas, 30 mi.
Ports: 3 major, 8 minor
Civil air: 19 major transport aircraft
Airfields: 152 total, 76 usable; 67 with permanent-surface runways; 42 with
runways 8,000-11,999 ft., 21 with runways 4,000-7,999 ft.; 2 seaplane stations ‘
Telecommunications: second best system of coaxial and multiconductor cables,
open-wire lines, and radio communication stations in Africa; principal centers
Alexandria and Cairo, secondary centers Al Mansurah, Ismailia, and Tanta;
365,000 telephones; 5 million radio and 575,000 TV receivers; 12 AM, 1 FM,
and 26 TV stations
y
DEFENSE FORCES:
Military manpower: males 15-49, 8,347,000; 5,280,000 fit for military service;
about 375,000 reach military age (20) annually
*
96
TP ETT EASE PS HS Pe OSE 8 ETE PEC HPS ESRB MT SR ORI ERS ESR | SUE SOOA-
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
|
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 74 EL SALVADOR
LAND:
8,260 sq. mi.; 32% cropland (9% corn, 5% cotton, 7%
coffee, 11% other), 26% meadows and pastures, 31% :
nonagricultural, 11% forested prvewsncice |
Land boundaries: 320 mi. “ghwama! VENEZUELA
WATER: eg
Limits of territorial waters (claimed): 200 n. mi. eae
Coastline: 190 mi. a array arr
Railroads: 375 mi., 3''0" gage; single-tracked; 285 mi. privately owned, 90 mi.
government owned
Highways: 5,400 mi.; 750 mi. bituminous, 950 mi. gravel or crushed stone, 3,700 mi.
earth oe
Inland waterways: Lempa River partially navigable
Ports: 3 major, 1 minor
Civil air: 8 major transport aircraft (includes 2 military/commercial transports)
Airfields: 150 total, 123 usable; 6 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: nationwide trunk radio relay system; connection into
Central American microwave net; 41,500 telephones; 500,000 radio and 110,000
TV receivers; 57 AM, 6 FM, and 4 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 895,000; 545,000 fit for military service;
44,000 reach military age (18) annually
4
98
ETA LL ERE EL TOR ST Re eT A EU Ce SOL A NLT PLE a TTS TTT COE Tee aN ene ee Te ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 52F EQUATORIAL GUINEA
LAND: Ds Pe Gas
10,800 sq. mi.; Rio Muni, about 10,000 sq. mi., largely 5 lwallivicen
forested; Fernando Po, about 800 sq. mi. nae
Land boundaries: 335 mi. sao
Gui MINES a) ae
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 184 mi.
Railroads: none
Highways: Rio Muni -- 1,553 mi., including approx. 115 mi. bituminous,
remainder gravel and earth; Fernando Po -- 186 mi., including 91 mi.
bituminous, remainder gravel and earth
Inland waterways: Rio Muni has approximately 104 mi. of year-round navigable ?
waterway, used mostly by pirogues
Ports: 2 major, 3 minor
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7 ,999 ft.
Telecormunications: fairly adequate for the size and stage of development of the
country; international communications by radio from Bata and Santa Isabel
to Cameroon, Nigeria, and Spain; 1,500 telephones; 75,000 radio receivers;
2 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 73,000; 37,000 fit for military service
-
w
199
LL Le ET NE Ee ET eT EP IE TNT HT TD RP I 2 EL EEL BIE TNR TATE 0 EFT SRIE. Me SO eT oN DE IES
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 55A ETHIOPIA
LAND:
455,000 sa. mi.; 9.5% cropland and orchards, 54.6% meadows
and natural pastures, 6.5% forests and woodlands,
29.4% wasteland, built-on areas, and other
Land boundaries: 3,230 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(sedentary fisheries extends to limit of fisheries)
Coastline: 680 mi. (includes offshore islands)
Railroads: 630 mi.; 420 mi. 3''3 3/8" gage, 20 mi. 3''6" gage, 190 mi. 3''1
3/8" gage; all single track
Highways: 14,500 mi.; 1,250 mi. bituminous, 8,000 mi. crushed stone, gravel, or
stabilized earth, 10,250 mi. earth
Inland waterways: navigation possible on Lake Tana and on approx. 140 mi. of
unconnected and basically unimproved waterways, of which only 71 mi. are
navigable year round
Ports: 2 major, 1 minor
Civil air: 17 major transport aircraft
Airfields: 202 total, 113 usable; 7 with permanent-surface runways; 4 with run-
ways 8,000-11,999 ft., 47 with runways 4,000-7,999 ft.
Telecommunications: system better than in most African countries; composed of
open-wire lines, radiocommunication stations, and small number of multi-
conductor cable and radio-relay links; principal center Addis Ababa, secondary
center Asmara; 50,500 telephones; 500,000 radio receivers; 8,600 TV receivers;
5 AM, no FM, and 2 TV stations 5
DEFENSE FORCES:
Military manpower: males 15-49, 6,869,000; 3,550,000 fit for military service;
average number reaching military age (18) annually 265,000
102
ERE RI BSS OM se TO VEE CEO OD ESET EPO
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 7 FAEROE ISLANDS
LAND:
540 sq. mi.; less than 5% arable, of which only a fraction
cultivated; archipelago consisting of 18 inhabited
islands and a few uninhabited islets
IRECAND
WATER:
Limits of territorial waters (claimed): 3 n. mi.;
fishing, 12 n. mi. (from extended base lines)
Coastline: 475 mi.
Railroads: none
Highways: none
Ports: | minor
Airfields: 1 with permanent-surface runway, less than 4,000 ft.
Civil air: no major transport aircraft
Telecommunications: good internationational radiocommunications; fair domestic
wire facilities; 9,500 telephones, 12,000 radio receivers, 1 AM, and 3 FM
stations; 3 coaxial submarine cables
104
EILEEN TOY THURS ROTOR 2 OE PEA CR SASTETD EE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 64 FALKLAND ISLANDS (MALVINAS)*
LAND: q BRAZIL
Colony -- 4,700 sq. mi.; area consists of some 200 small
islands, chief of which are East Falkland (2,580 sq.
mi.) and West Falkland (2,038 sq. mi.); dependencies--
consists of the South Sandwich Islands, South Georgia,
and the Shag and Clerke Rocks
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 800 mi.
Railroads: none
Highways: 512 mi.; 9 mi. paved, 23 mi. gravel, 480 mi. earth
Ports: 1 major, 4 minor
Civil air: no major transport aircraft
*The possession of the Falkland Islands has been disputed by the U.K. and Argentina
(which refers to them as the Malvinas) since 1833.
105
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Airfields: 1 seaplane station
Telecommunications: government-operated open-wire and radiotelephone networks
providing effective service to almost all points on both islands; approx-
imately 580 telephones; 1 AM station and approximately 1,100 radiobroadcast
receivers
106
EARLE SRPMS
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 102 FIJI
LAND:
7,055 sq. mi.; landownership -- 83.6% Fijians, 1.7% Indians,
6.4% government, 7.2% European, 1.1% other; about 30% niet di
of land area is suitable for farming
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 700 mi. (est.)
Railroads: none
Highways: 1,550 mi.; 166 mi. paved, 1,384 mi. gravel or crushed stone, 80 mi.
unimproved earth
Inland waterways: 126 mi.; 76 mi. navigable by motorized craft and 200-ton barges
107
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Ports: 6 major, numerous minor landings
Civil air: 4 major transport aircraft
Airfields: 20, 15 usable; 1 with runway 8,000-11,999 ft., 1 with runway 4,000-7,999
ft., 2 seaplane stations
Telecommunications: modern local, interisland, and international (wire/radio
integrated) public and special-purpose telephone, telegraph, and teleprinter
facilities; regional radio center; important COMPAC cable link between
U.S./Canada and New Zealand/Australia, et al; 19,560 telephones; 53,000
radio receivers; 5 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 143,000; 76,000 fit for military service; 6,000
reach military age (18) annually
Military budget: the defense of the Fiji Islands was the responsibility of the
U.K. until 10 October 1970; the military budget for 1971 is $314,000
108
biaceratae dae caeeataedahtaattiinnttbtiinadimtaeteterteanliie nanan ath em anihneninnnarnnienaaisaiameitamaliiidn daiesatonelsanan.animamreaeccre.onaa
Approved For Release ee : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 12 FINLAND
ND: Peete,
130,000 sq. mi.; 8% arable, 58% forested, 34% other = /‘y§ ‘
Land boundaries: 1,575 mi. 5 oe
WATER: go
Limits of territorial waters (claimed): 4 n. mi.;
Aland Islands, 3 n. mi.
Coastline: 700 mi. (approx.) includes islands
(RAN
- SAUDI
LIBYA JEGYPT “ARABIA S''S.
Railroads: 3,676 mi.; Finnish State Railways ''|(VR) operate a total
3,658 mi. broad gage (5''0"), 288 mi. multiple track, and 68 mi. electrified;
14 mi. narrow gage (2'' 5 1/2") and 4 mi. broad gage are privately owned
Highways: 44,660 mi., 12,060 mi. bituminous, 31,900 mi. stablized gravel, 700
mi. gravel and earth; 12,400 mi. of private roads (surface type na)
Inland waterways: 4,100 mi. total (including Saimaa Canal); 2,300 mi. suitable
for steamers; canal locks (275 ft. by 42 ft. with a 16.7 ft. depth over sill)
can accommodate vessels of up to 225 ft. in length, 36 ft. beam, and 14.5
ft. draft
Ports: 11 major, 14 minor
Civil air: 31 major transport aircraft
Airfields: 98 total, 79 usable; 30 with permanent-surface runways; 17 with
runways 8,000-11,999 ft., 22 with runways 4,000-7,999 ft.
Teleconmunications: facilities provide essential services for government, public,
and industry; 1,470,000 telephones; pene radiobroadcast receivers;
1,252,000 TV receivers; 11 AM, 40 FM, and 59 TV stations; 4 submarine cables,
including 1 coaxial |
DEFENSE FORCES:
Military manpower: males 15-49, 1,196,000; 960 ,000 fit for military service;
38,000 reach military age (17) annually
110
teen cetera aiaeienriaiianeie naib datenteted inlet sipbtiene said saan ece] 2 RET Ne a aE 8 MITES |
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 3 FRANCE
LAND:
213,000 sq. mi.; 35% cultivated, 26% meadows and pastures,
14% waste, urban, or other, 25% forested
Land boundaries: 1,795 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,130 mi. (includes Corsica, 400 mi.) :
PEOPLE : ALGERIA
Population: 52,363,000, average annual growth rate 0.9%
(7/65-7/72)
Ethnic divisions: 45% Celtic; remainder Latin, Germanic,
Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1% Muslim (North African
workers), 11% unaffiliated
Language: French (100% of population); rapidly declining regional patois --
Provencal, Breton, Germanic, Corsican, Catalan, Basque, Flemish
Literacy: 97%
Labor force: 21,200,000 (1972 est.); 12% agriculture, 39% industry, 47% services,
2% unemp] oyed
Organized labor: 17% of labor force, 23.4% of salaried labor force
Railroads: 23,229 mi.; 22,381 mi. standard gage, 848 mi. other gages (3'' 3 3/8"
to 4'' 9"); 5,824 mi. electrified, 9,892 mi. double or multiple track
Highways: National, Departmental, and Communal roads total 487,600 mi. comprising
292,600 mi. paved,, 190,000 mi. crushed stone and gravel, and 14,600 mi.
improved earth; in’ addition, there are approximately 434,000 mi. of local
farm and forest roads
Inland waterways: 9,320 mi.; 4,820 mi. heavily traveled
Pipelines: crude oi1, 1,400 mi.; refined products, 2,700 mi.; natural gas,
9,300 mi.
Ports: 22 major, 165 minor
Civil air: 301 major transport aircraft (including 9 foreign owned but French
registered)
Airfields: 532 total, 442 usable; 185 with permanent-surface runways; 1 with
runway over 12,000 ft., 20 with runways 8,000-11,999 ft., 131 with runways
4,000-7,999 ft.; 10 seaplane stations
Telecommunications: highly developed system ee satisfactory telephone,
telegraph, and radio and TV broadcast services; 10.3 million telephones; 17.2
million radiobroadcast receivers; 13.2 million TV receivers; 52 AM, 74 FM,
and 1,190 TV stations; 17 submarine cables (16 coaxial); 3 communication
satellite ground stations
112
SE ONSEN GMD BS HELE TE STE TRG FH TEA TIOS ESE DEE OT IHS
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
DEFENSE FORCES: ;
Military manpower: males 15-49, 12,715,000; fit for military service 10,250,000;
424,000 reach military age (18) annually
113
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 95C FRENCH GUIANA
LAND:
35,100 sq. mi.; 90% forested, 10% wasteland, built-on,
inland water, and other of which .05% is cultivated
and pasture
Land boundaries: 735 mi.
aces
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 235 mi.
Railroads: 60 mi. meter gage
Highways: 620 mi.; 50 mi. paved, 570 mi. earth
Ports: | major, 7 minor
Airfields: 27 total, 9 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; ] Seaplane station
Civil air: 4 major transport aircraft (registered in France)
Telecommunications: fair telephone services; poor telegraph facilities; 2,590
telephones; 10,000 radio receivers; 2,500 TV receivers; 1 AM, no FM, and
1 TV stations : 4
DEFENSE FORCES:
Military manpower: males 15-49, about 30,000; about 17,000 fit for military
service
Defense is responsibility of France
seen
Approved For Release 2004/08/31 : CIA-RDP79-010 -
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 52D GABON x s, Sane €
=. TURKEY
ALGERIA ) LIBYA [EGYPT
D: oo SAUDI ~
102,000 sq. mi.; 75% forested, 15% savanna, 9% urban and 2s!
Y
wasteland, less than 1% cultivated
Land boundaries: 1,505 mi.
WATER:
Limits of territorial waters (claimed): 100 n. mi.
(fishing 30 n. mi.)
Coastline: 550 mi.
Railroads: none
Highways: 3,815 mi.; 135 mi. paved, 3,725 mi. improved earth, 555 mi. unimproved
earth
Inland waterways: approximately 1,000 mi. perennially navigable
Pipelines: crude oi], 40 mi.
Ports: 3 major, 2 minor
Civil air: 12 major transport aircraft
Airfields: 187 total, 100 usable; 5 with permanent-surface runways; 2 with run-
way 8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: fair telephone and telegraph services; good broadcast
coverage in vicinity of Libreville; 2 AM and 2 TV stations; 7,000 telephones;
90,000 radio receivers; 5,000 TY receivers
DEFENSE FORCES:
Military manpower: males 15-49, 129,000; 65,000 fit for military service;
5,000 reach military age (20) annually
Supply: dependent on France
122
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7 —
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
UW. 5.5. R,
A
we
NIS 50S GAMBIA
* TURKEY.
pate
LAND:
4,000 sq. mi.; 25% uncultivated savanna, 16% swamps, 4%
forest parks, 55% upland cultivable areas, built-up
areas, etc.
Land boundaries: 460 mi.
WATER:
Limits of territorial waters (claimed): 50 n. mi.
Coastline: 50 mi.
Railroads: none
Highways: 775 mi.; 185 mi. bituminous surface treated, 270 mi. gravel/laterite,
270 mi. unimproved earth
Inland waterways: 377 mi.
Ports: 1 major
Civil air: no major transport aircraft
Airfields: 4 total, 1] usable; 1 with permanenti-surface runway; 1 with runway
4,000-7,999 ft.; 1 seaplane station (non-operational )
Telecommunications: good telephone and telegraph services; 1,700 telephones;
60,000 radio receivers; 2 AM, no FM or TV stations; ? submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 93,000; 43,000 fit for military service
124
Lad
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 13A GERMANY, EAST
LAND:
41,800 sq. mi.; 43% arable, 15% meadows and pasture, 27%
forested, 15% other
Land boundaries: 1,435 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 560 mi. (including islands)
Railroads: 9,010 route mi.; 8,810 mi. standard gage, 200 mi. meter or other narrow
gage, 1,810 mi. double track standard gage; 860 mi. overhead electrified (1972)
Highways: about 28,650 mi. classified highways; 8,000 mi. state highways including
950 mi. autobahn; 20,750 mi. district roads; additionally about 29,000 mi.
unclassified minor unpaved roads (1972)
Inland waterways: 1,562 mi. (1973)
Freight carried: rail -- 295.0 million short tons, 30.0 billion short ton/mi.
(1972); highway -- 544.9 million short tons, 8.9 billion short ton/mi. (1971);
waterway -- 21.2 million short tons, 2.0 bitlion short ton/mi. (incl. int''l.
transit traffic) (1972)
Pipelines: crude oi], 420 mi; refined products, 150 mi.; natural gas 250 mi.
ae 2 es (Rostock, Wismar, Stralsund, Sassnitz, Peenemunde), 12 minor
1973
Airfields: 152 total; 54 with permanent-surface runways; 49 with runways 8,000-
11,999 ft., 44 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military budget (announced): for fiscal year ending 31 December 1973, 8.3 billion
DME; about 9.2% of total budget and 5.5% of est. GNP
126
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
daha anata ini emaehdieeasinteh tiaataatatateleadehaanlidaadioabiiaaibteasnsinideatinateiaihenieinetetl
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50A GHANA eS So
TUR
LAND:
92,000 sq. mi.; 19% agricultural, 60% forest and brush,
21% other
Land boundaries: 1,420 mi.
WATER:
Limits of territorial waters (claimed): 30 n. mi. (undefined
protective areas may be proclaimed seaward of territorial
sea, and up to 100 n. mi. seaward may be proclaimed
fishing conservation zone)
Coastline: 335 mi.
Railroads: 592 mi. -- all 3''6" gage; 20 mi. double track; diesel locomotives
gradually replacing steam engines
Highways: 21,350 mi., 3,100 mi. concrete or bituminous surface, 3,750 mi. gravel
or laterite, 3,700 mi. improved earth, 10,800 mi. unimproved earth
Inland waterways: Volta, Ankobra, and Tano rivers provide 145 mi. of perennial
navigation for launches and lighters; additional routes navigable seasonally
by small craft; Lake Volta reservoir provides 700 mi. of arterial and
feeder waterways
Pipelines: refined products, 2 mi.
Ports: 2 major, 1 naval base (Sekondi), 4 minor
Civil air: 5 major transport aircraft
Airfields: 22 total, 19 usable; 4 with permanent-surface runways; 2 with runways
8,000-11 ,999 ft., 8 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone fair to good in lurban areas; fairly good telegraph
services; 49,100 telephones; about 775,000 radio receivers; 21,000 TV
receivers; 2 AM, 1 FM, and 1 TV station; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 2,190,000; 1,825,000 fit for military service;
114,000 reach military age (18) annually
130
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 102 GILBERT AND ELLICE ISLANDS
LAND:
¥ About 376 sq. mi.
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: about 725 mi.
Railroads: none
Highways: 30 mt.
Inland waterways: none
Ports: none
Civil air: no major transport aircraft
Telecommunications: 2 AM broadcast stations; 8,000 radio receivers and 1,405
telephones; connected with Lisbon, Portugal, via cable broadcasts
13]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
CIRELAND,
NIS 25A GIBRALTAR ee ae le /
ove, BERGIUM
LAND: OS. FRANCE
2.5 sq. mi. ey
Land boundaries: 1 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 7.5 mi.
2? GIBRALTAR
Railroads: 1,598 mi.; 969 mi. standard gage (4''8 1/2"), 597 mi. meter gage
(3''3 3/8"), 20 mi. 1''11 5/8" narrow gage, 10 mi. 2''5 1/2" narrow gage; all
government owned
Highways: 24,200 mi.; 10,000 mi. paved, 8,500 mi. crushed stone and gravel
3,500 mi. improved earth, 2,200 mi. unimproved earth
Inland waterways: system consists of 3 coastal canals and 3 unconnected rivers
which provide navigable length of just less than 50 mi.
Pipelines: crude oi1, 16 mi., refined products, 340 mi.
Ports: 17 major, 37 minor
Airfields: 64 total, 57 usable; 39 with permanent-surface runways; 17 with
runways 8,000-11,999 ft., 1','105d4fad509faa6bb75247474db1ddf0ebe65293de5245b52228e76e4a88934d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71d44c4e9254672840c1152a44ec5dd0192a32c4ce2a2b59c67a1e20a7ff71f8',1974,'BR','Brazil','communications',8,'6 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 39 major transport aircraft (including 6 withdrawn from service)
Telecommunications: adequate modern networks reach all areas on mainland and
islands; 1.35 million telephones; 1.4 million radio receivers; 900,000 TV
receivers; 30 AM, 9 FM and 24 TV stations; 2 coaxial submarine cables;
2 communications satellite ground stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,215,000; 1,780,000 fit for military service;
about 74,000 reach military age (21) annually
136
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
RS ERR EP LSE AGMA TENE MS) OU ETON? LEN RLU RETO EP EU EE ERTS!
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 67 GREENLAND
2 OO AGELAND
LAND:
840,000 sq. mi.; less than 1% arable (of which only a
fraction cultivated), 84% permanent ice and snow,
15% other (1970)
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing,
12 n. mi.)
Coastline: 27,400 mi. (approx., includes minor islands)
Railroads: none
Highways: none
Ports: 7 major, 16 minor
Civil air: 4 major transport aircraft (registered in Denmark)
Airfields: 11 total, 8 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 7 seaplane stations
137
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Telecommunications: adequate domestic and international service provided by
cables and radio; 5,000 telephones; 7,300 radiobroadcast receivers; 5 AM,
2 FM, and 2 TV stations; 2 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, included with: Denmark
138
SEE ED ETON
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 81A GRENADA
LAND:
133 sq. mi. (Grenada and southern Grenadines); 47%
cultivated, 3% pastures, 12% forests, 20% unused but
potentially productive, 18% built on, wasteland,
other
\\ VENEZUELA
‘ BRAZIL
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 75 mi.
Railroads: none
Highways: 600 mi.; 380 mi. paved, 100 mi. gravel, crushed stone, or earth
surface; 120 mi. unimproved
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 4 total, 3 usable; 1 with asphalt runway 5,000 ft.
Teleconmmunications: automatic, islandwide telephone system with 3,900 telephones;
VHF Tinks to Trinidad and Carriacou; 18,000 radios and 100 TV receivers;
3 AM stations as
140
STAT
2 TN PLR UE RS ER EH A EEL we TT
se 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Relea
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 83 GUADELOUPE
LAND: 5) eUapeLouiee
687 sq. mi.; 25% cropland, 8% pasture, 19% forest, 48% (ihee oes sis
wasteland, built on; area consists of two islands
WATER: 7 . VENEZUELA
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 190 mi. COLOMBIA
PEOPLE: BRAZIL
Population: 345,000, average annual growth rate 1.5%
(7/70-7/71)
Ethnic divisions: 90% Negro or Mulatto, less than 5% East
Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force
Railroads: privately owned, narrow-gage plantation lines
Highways: 1,200 mi.; 780 mi. paved, 420 mi. gravel and earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
Civil air: 1 major transport
Airfields: 8 total, 7 usable, 6 with permanent-surface runways; 1 with runway
8,000-11,999 ft.; 1 seaplane station
Telecommunications: domestic facilities inadequate; 19,000 telephones;
inter-island VHF radio links; 2 AM radio and 3 TY transmitters, with about
28,000 radio and 10,000 TV receivers
DEFENSE FORCES:
Military manpower: males 15-49, included with France
ITER OAR AA OTIC EA
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 7] GUATEMALA
LAND : :
42,040 sq. mi.; 14% cultivated, 10% pasture, 57% forest, r ——
19% other
Land boundaries: 1,010 mi. ee
SRETAINGA oR) : VENEZUELA
WATER: gaa
Railroads: more than 450 mi. plantation lines; 6 gages from 1''8" to 3''3 3/8"
with latter predominating
Highways: 5,100 mi.; 4,200 mi. paved, 250 mi. gravel, 650 mi. improved and
unimproved earth «
Inland waterways: negligible
Pipelines: refined products, 90 mi.
Ports: 3 major, 7 minor
Civil air: major transport aircraft are included in U.S. registered total
Airfields: 32 total, 28 usable; 18 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 9 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecomnunications: highly developed telecom system of open-wire and radio relay
links; communications satellite ground station; 396,000 telephones; over 1.8
million radio and 620,000 TV receivers; 51 AM, 18 FM, and 13 TV stations;
2 coaxial submarine cables
DEFENSE FORCES:
Defense is responsibility of U.S.
286
LT a a TTT ee NOTIRERERET ice
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 32C QATAR
LAND : oat
About 4,000 sq. mi.; negligible amount forested; mostly EGYPT, savor Game PAK,
desert, waste, or urban i :
Land boundaries: 35 mi.
ARABIA
SUOAN
WATER:
Limits of territorial waters (claimed): 3.n. mi. ba
Coastline: 350 mi.
PEOPLE: pxranzan
Population: 159,000, average annual growth rate 10.8%
(7/64-7/69)
Ethnic divisions: 56% Arab; 23% Iranian; 14% Pakistani;
7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: 48,000 (1969)
Railroads: none
Highways: 275 mi. bituminous; 225 mi. gravel surfaced; undetermined mileage of
earth tracks
Pipelines: crude oil, 105 mi.; natural gas, 60 mi.
287
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Ports: 1 major, 1 minor
Airfields: 10 total, 1 usable; 1 with permanent-surface ruriway over 12,000 ft.
Civil air: no major transport aircraft
Telecommunications: all international telecom traffic is by
fair domestic wire facilities; 12,200 te
receivers; 1 AM and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 39,000; about 22,000 fit for military
service
radio through Bahrain; a
lephones; 35,000 radio and 27,000 TV
cal
Supply: mostly from U.K.
a
md
288
ae ieee a : | steamer ieeeteniel einen
ENTE SD aE
Approved For Release i : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 62 REUNION
LAND:
970 sq. mi.; two-thirds of island extremely rugged,
consisting of volcanic mountains; 120,000 acres (less
than one-fifth of the land) under cultivation
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 125 mi.
Railroads: none
Highways: 1,366 mi.; 1,056 mi. paved, 310 mi. gravel, crushed stone, or stabilized
earth
Ports: 1 major
Civil air: no major transport aircraft
Airfields: 6 total, 6 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.
Telecommunications: adequate system for size of island of fairly modern open-wire
lines and radiocommunication stations; principal center Saint-Denis; external
radiocommunications to Comoro Islands, France, Malagasy, and Mauritius;
17,900 telephones; 71,000 radio and 23,500 TV receivers; 2 AM, no FM, and
8 TV stations
DEFENSE FORCES:
Military manpower: military age males included with France
EL EERE ESE SETS SR 01H ESET GANEN ATES EE ISO OES ETE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 57B RHODESIA
D:
151,000 sq. mi.; 40% arable (of which 6% cultivated); 60%
available for extensive cattle grazing; European
alienated lands (farmed by modern methods) 39%,
African 48%, national land 7%, 6% not alienated
Land boundaries: 1,875 mi.
Railroads: 1,610 mi. narrow gage (3''6"); 26 mi. double track
Highways: 48,733 mi.; 4,968 mi. paved, 20,415 mi. crushed stone, gravel,
stabilized soil, or improved earth; 23,350 mi. unimproved earth
Inland waterways: 175 mi. on Lake Kariba
Airfields: 323 total, 218 usable; 8 with permanent-surface runways; 1 with run-
way over 12,000 ft., 22 with runways 4,000-7,999 ft.
Civil air: 15 major transport aircraft
Telecommunications: system is one of the best in Africa; consists of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Salisbury, secondary center Bulawayo; 140,900 telephones; 215,000 radio
and 57,000 TV receivers; 8 AM, no FM and 2 TY stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,343,000; 840,000 fit for military service;
average number reaching military age (18) annually, 63,000
292
nteenmneedeenee Ee --N-- a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 22 ROMANTA
"91,700 sq. mi.; 44% arable, 19% other agriculture, 27%
forested, 10% other
Land boundary: 1,845 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 140 mi.
PEOPLE: peve
Population: 20,956,000, average annual growth rate 0.9%
(current)
Ethnic divisions: 87% Romanian, 8% Hungarian, 2% German,
3% other
Religion: 14 million Romanian Orthodox, 1 million Roman Catholic, 1 million
Protestants, 100,000 Jews, 30,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.4 million (est. 1 July 1966); 57% agriculture, 19% industry,
24% other nonagricultural
Railroads: 7,464 mi.; 6,442 mi. standard gage, 1,014 mi. narrow gage, 8 mi.
ea 404 mi. electrified, 852 mi. double track; government owned
1973
Highways: 48,000 mi.; 7,600 mi. paved; 16,300 mi. other improved surfaces,
24,100 mi. earth (1970)
Inland waterways: 1,445 mi. (1973)
Pipelines: crude oil, 1,600 mi.; refined products, 888 mi.; natural gas, 3,100
mi.
eretone carried: rail -- 218.3 million short tons, 33.8 billion short ton/mi.
(1972); highway -- 515 million short tons, 5.3 billion short ton/mi. (1971);
waterway -- 16.4 million short tons, 6.9 billion short ton/mi. (incl. int''l.
transit traffic) (1972)
Ports: 4 major (Constanta, Galati, Braila, Mangalia), 4 minor (1973) as
Civil air: 53 major transport aircraft (1973)
Airfields: 154 total; 24 with permanent-surface runways; 11 with runways 8,000-
11,999 ft.; 25 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military budget (announced): for fiscal year ending 31 December 1973, 7.9 billion
lei; about 4.6% of total budget and 1.8% of est. GNP
294
a neater headin iniaattin em aerietenematataitebimenaatel paeraecsdcmnnn nent neti, gee tie, sal sageiiiaos,.,\\inesan arena
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 60C RWANDA
"10,000 sq. mi.; almost all the arable land, about 1/3
under cultivation, about 1/3 pastureland
Land boundaries: 545 mi.
Railroads: none
Highways: 3,815 mi.; 36 mi. paved, 19 mi. gravel, 1,367 mi. improved earth,
2,393 mi. unimproved; 2,485 mi. secondary roads; most roads improved or
*
unimproved earth
Inland waterways: Lake Kivu navigable by steamers and barges
Civil air: no major transport aircraft
Airfields: 20 total, 15 usable; 2 with pennanent-surface runways; 2 with
runways 4,000-7,999 ft., 1 with runway 8,000-11,999 ft.
Telecommunications: telephone and telegraph limited; main center is Kigali;
1,800 telephones; 50,000 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 935,000; 450,000 fit for military service; no
conscription; 38,000 reach military age (18) annually
296
. LY LT Ta THe eer Pee a SSS SSNS SOSERNOIESNTGN 1 UREN: eTEEEE:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 81A ST. CHRISTOPHER-NEVIS-ANGUILLA
LAND:
150 sq. mi.; 40% arable, 10% pasture, 17% forest, 33%
wasteland and built-on
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi.
Railroads: none
Highways: 415 mi.; 175 mi. paved; 240 mi. otherwise improved
Ports: 1 major, 1 minor
Civil air: no major transport aircraft -
Airfields: 2 airfields with permanent surface runways; one with a 9,000 foot
runway; one with a 5,700 foot runway; 2 seaplane stations
Telecommunications: fully automatic telephone system with 4,000 telephones; direct
radio link with Martinique; interisland tropospheric links to Barbados and
Antigua; 20,000 radio and 500 TV receivers; 2 AM, and 1 Ty station
300
; 08-0105 1 AOOOC O00 OOO rane
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 81A ST. VINCENT
LAND:
150 sq. mi. (including northern Grenadines); 50% arable,
3% pasture, 44% forest, 3% wasteland and built-on
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 52 mi.
LAND:
72,200 sq. mi.; g4% agricultural land (73% pasture, 11%
cropland) 16% forest, urban, waste and other
Land boundaries: 840 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 410 mi.
Railroads: 1,870 mi., all standard gage and government owned
Highways: 32,200 mi.; 3,700 mi. paved, 4,600 mi. otherwise surfaced, 9,600 mi.
improved earth, 14,300 mi. earth tracks
Inland waterways: 1,070 mi.; used by coastal and shallow-draft river craft ‘
Freight carried: highways 80% of total cargo traffic, rail 15%, waterways 5% °
Ports: 4 major, 6 minor
Civil air: 15 major transport aircraft
Airfields: 101 total, 80 usable; 6 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 11 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: most modern facilities concentrated in Montevideo: 245,000
telephones; 1.2 million radio and 310,000 TV receivers; 68 AM, 3 FM, and 17
TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 733,000; 565,000 fit for military service; no
conscription
Supply: dependent on U.S. for current supplies, with few exceptions
368
ji iene Ee - ; =
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004 ’ ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 17 VATICAN CITY
LAND:
0.169 sq. mi.
Land boundaries: 2 mi.
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft F
Airfields: none
Telecommunications: 1 AM and 1 FM radiobroadcasting stations; 2,000-line
automatic telephone exchange
DEFENSE FORCES:
Defense is responsibility of Italy =
2 TEM PP RC PE LO IH DE EN PPE OS ED ET A RE EERE I SP
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 86 VENEZUELA
LAND:
352,000 sq. mi.; 4% cropland, 18% pasture, 21% forest,
57% urban, waste, and other
Land boundaries: 2,598 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,740 mi.
Railroads: 233 mi. 4''8 1/2" gage; all single track; 107 mi. government owned,
126 mi. privately owned
Highways: 37,500 mi.; 11,900 mi. paved, 10,200 mi. gravel, 5,400 mi. improved
earth, 10,000 unimproved (including trails) 4
Inland waterways: 4,450 mi.; Orinoco River and Lake Maracaibo accept oceangoing
vessels
Pipelines: crude 011, 3,800 mi.; refined products, 250 mi.; natural gas,
1,550 mi.
Ports: 6 major, 17 minor =
Civil air: 61 major transport aircraft
Airfields: 453 total, 223 usable; 90 with permanent-surface runways; 7 with
runways 8,000-11,999 ft., 69 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: extensive radio relay; local telephone systems greatly expanded;
satellite ground station; 490,000 telephones; 3 million radio and 990,000 TV
receivers; 150 AM, 50 FM, and 39 TV stations; 3 submarine cables, including
1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 2,491,000; 1,710,000 fit for military service;
130,000 reach military age (18) annually
s
a
372
TL a a ee HTT TT a ny SN ey ae eT Seen ve aT | DE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 43¢ VIETNAM, NORTH
LAND:
61,300 sq. mi.; 14% cultivated, 50% forested, 36% urban
inland water, and other
Land boundaries: 1,850 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 490 mi. (excluding islands)
Railroads: 602 usable route mi., consists of about 25 mi. of standard gage
(4''8 1/2"), 438 mi. of meter gage (3''3 3/8"), and 139 mi. of dual gage
(4''8 1/2" and 3''3 3/8"); all single track, none electrified; all government
owned and operated; new rail line remains incomplete between Kep and port
of Hon Gai
Highways: 9,110 mi., plus about 1,600 mi. of seasonally motorable tracks; 900 to
1,000 mi. bituminous surface-treated, remainder gravel, crushed stone, or earth
Inland waterways: 4,200 mi.; 1,800 mi. navigable perennially by craft drawing 6 ft.
373
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
‘7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Ports: 3 major, 12 minor
Airfields: 16 total; 1] with permanent-surface runways; 2 with runway 8,000-
11,999 ft., 12 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Supply: dependent chiefly on U.S.S.R. and China for virtually all equipment;
smaller amounts from other Communist countries; produces negligible quantities
of infantry weapons, ammunition, and explosive devices
Military budget: no recent data available; for fiscal year ending 31 December
1962, estimated defense expenditures 382 million dongs; about one-fifth of
total budget (estimated value $103 million); military aid from U.S.S.R. and
China now so extensive that actual allocation of North Vietnam''s domestic
resources to defense would not be indicative of total military effort
374
PERCE CEEOL
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
4&
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 43D VIETNAM, SOUTH
LAND:
66,000 sq. mi.; 25% arable (15% cultivated), 33% forested,
42% other
Land boundaries: 1,025 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 50 n. mi.)
Coastline: 1,650 mi.
Railroads: 770 mi.
Highways: 14,500 mi.; 3,000 mi. bituminous, 3,000 mi. gravel and crushed stone,
2,500 mi. improved earth, 6,000 mi. unimproved earth
Inland waterways: about 6,800 mi. navigable; more than 1,400 mi. navigable at all 7
times by vessels up to 6 ft. draft
Ports: 6 major, 20 minor
Airfields: 341 total, 163 usable; 64 with permanent-surface runways, 8 with
runways 8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 4 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 4,597,000; 3,005,000 fit for military service;
173,000 reach military age (18) annually
&
a
376
earn eeeatiatlaeeieitiinnin nil ammentemaenmenmiadaisanee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
|
|
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 102 WALLTS AND FUTUNA
LAND:
About 80 sq. mi.
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: about 80 mi.
Railroads: none
Highways: 477 mi.; 80 mi. bituminous, remainder mostly gravel, crushed stone,
or earth
Inland waterways: none y
Ports: 1 principal (Apia), 1 minor ;
Civil air: 2 major transport aircraft
Airfields: 4 total, all usable; 1 with runway 4,000-7,999 ft.; 1 seaplane
station
Telecommunications: 1,960 telephones; 32,000 radio receivers; 1 AM station
380
ToT oT NT TT ee Hee eT See Fenn or SaD Oe MES SEY Sean ie TEE P| HoFPEPENPURNIGA © BORER He
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 32B YEMEN (ADEN) Rd ee
LAND:
111,000 sq. mi. (border with Saudi Arabia undefined); only
about 1% arable (of which less than 25% cultivated)
Land boundaries: 1,120 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (300
meters plus exploitability, plus 6 n. mi. "necessary
supervision zone")
Coastline: 860 mi.','6ff63f6c3244ac2d195c1f47e4302763513453e327ff71318f69550635a6e244','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('551c052db7674a2c43a1d393bb59ed24de01811689289d2c90d6f952986b2239',1974,'DZ','Algeria','communications',18,'UBYA
Railroads: 2,818 mi.; 2,643 mi. standard gage and government owned, 1,615 mi.
double track, 698 mi. electrified; 175 mi. privately owned, electrified
narrow gage (3''3 3/8")
Highways: 57,700 mi.; 26,550 mi. bituminous, stone block, or concrete; 31,150 »
mi. crushed stone, gravel, earth
Inland waterways: 1,270 mi., of which 950 are in regular use by commercial
transport
Ports: 5 major, 1 minor
Pipelines: refined products, 600 mi.; crude, 100 mi.; natural gas, 145 mi.
Civil air: 62 major transport aircraft
Airfields: 53 total, 39 usable; 21 with permanent-surface runways; 13 with
runways 8,000-11,999 ft., 6 with runways 4,000-7,999 ft.
Teleconmunications: excellent domestic and international telephone and
telegraph facilities; 2,230,090 telephones; 3.83 million radio receivers;
2.45 million TV receivers; 7 AM, 11 FM, and 21 TV stations; 5 coaxial
Submarine cables; communications satellite station
DEFENSE FORCES:
Military manpower: males 15-49, 2,238,000; 1,790,000 fit for military service;
average number reaching military age (19) annually 74,000
30
LL Le Peeve GUS SSE HESSEN SRST a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
us
NIS 72 BELIZE (formerly British Honduras )
LAND:
8,870 sq. mi.; 38% agricultural (5% cultivated), 46%
exploitable forest, 16% urban, waste, water,
offshore islands or other
Land boundaries: 320 mi.
4 VENEZUELA
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 240 mi.
OR
LGE LIBYA EGYPT cauor
"14,000 sq. mi. (includes Bijagos archipelago)
Land boundaries: 460 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n,. mi.)
Coastline: 170 mi.
Railroads: none
Highways: approx. 2,000 mi. (260 mi. bituminous, remainder earth)
Inland waterways: 994 mi.
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 63 total, 60 usable; 4 with permanent-surface runways; 9 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: limited telephone and telegraph service; 2,580 telephones;
8,800 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 115,000; 65,000 fit for military service
Defense is responsibility of Portugal
282
eT a TT TL eT oie ee eee Sea PenIDaED INO Penn He SNH SNS Sse EH
Approved For Release eee : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 100 PORTUGUESE TIMOR
LAND:
7,000 sq. mi.; 34% forest, 33% grassland, and 33%
cultivated
Land boundaries: 90 mi.','1be9ff700b2cc731988343e064ba61a3bacc9eda45d3282af30ddefe174c6461','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b621d59d84d81079072e86257390153670730d20258894cfc6534ca50dbfb038',1974,'PE','Peru','communications',25,'Railroads: none
Highways: 1,400 mi.; 200 mi. paved, 500 mi. gravel, 550 mi. improved earth
arid 150 mi. unimproved earth
Inland waterways: 514 mi. river network used by shallow-draft craft
Ports: 1 major, 4 minor
Civil air: no major transport aircraft
Airfields: 51 total, 31 usable; 2 with permanent-surface runways; 1 with
runway 4,000-7, 999 ft.; 1 seaplane station
Telecommunications: 3,670 " tel ephones in automatic and manual network; over 63,000
radio receivers; 2 AM stations
DEFENSE FORCES:
Military manpower: males 15-49, 29,000; 17,000 fit for military service; 1,500
reach military age (18) annually
32
TL TT aT TT TT saa yee St er OHNE FSR GRE SSNRESSSNSTRDN INRESTSL SOU
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
RRA EOI.
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 81B BERMUDA
LAND: Zé
21 sq. mi.; 8% arable, 60% forested, 21% built on, CANADA
wasteland, and other, 11% leased for air and a
naval bases |, UNITED STATES
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 64 mi.
Railroads: none
Highways: 130 mi., all paved
Ports: 3 major
Civil air: no major transport aircraft
Airfields: 1 with concrete runway 9,660 ft.; 1 seaplane station
33
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Telecommunications: modern telecom system suited to island needs, includes fully
automatic telephone system with 34,200 instruments; 40,000 radio and
20,200 TV receivers, 2 AM, 2 FM, and 2 TV stations; 3 coaxial Submarine cables
>
’
«
34
aaa ate nannies bnitciadanin rine aaeiemanaesnie nnaanneala alee ieee TRY ORT slate taal ilalnineaialesnitan amend
a ieee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 35 BHUTAN
PEOPLE''S REPUBLIC
OF CHINA
LAND:
18,000 sq. mi.; 15% agricultural, 15% desert, waste,
urban, 70% forested
Land boundaries: about 540 mi.
Highways: 810 mi.; 260 mi. surfaced, 320 mi. improved, 230 mi. unimproved earth
Freight carried: not available, very light traffic
Civil air: no major transport aircraft
35
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Airfields: 1 asphalt runway 4,500 ft.
Telecommunications: facilities almost nonexistent; data not available on
telephones; 6,000 radio sets; no TV sets; data not available on AM; no
FM; and no TV stations %
DEFENSE FORCES:
Military manpower: males 15-49, 233,000; 121,000 fit for military service;
about 8,000 reach military age (18) annually
Supply: dependent on India
36
AEA A RAEN TR A INNER NaN EDOM NID EAE | ORES ATIC A GEOG AID BE ENTE SPU AP SSE RISTEEN (FEHR PRAT ERE RT OAH NARI OE EAE A RE:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 93 BOLIVIA
LAND: * BRAZIL
424,000 sq. mi.; 2% cultivated and fallow, 11% pasture
and meadow, 45% urban, desert, waste, or other,
40% forest, 2% inland water
Land boundaries: 3,780 mi.
Railroads: 2,310 mi., single track; 2,290 mi., meter gage, 20 mi., 2''6" gage;
all government owned except 60 mi. of meter-gage track; 5.6 mi. of meter-
gage track electrified
Highways: 17,600 mi.; 700 mi. paved, 4,100 mi. gravel, 3,700 mi. improved
earth, 9,100 mi. unimproved earth =
Inland waterways: officially estimated to be 6,250 mi. of commercially
navigable waterways
Pipelines: crude oi1, 1,040 mi.; refined products and crude 930 mi.; natural gas
350 mi.
Ports: none (Bolivian cargo moved through Arica and Antofagasta, Chile, and
Matarani, Peru)
Civil air: 39 major transport aircraft
Airfields: 519 total, 435 usable; 3 with permanent-surface runways; 1 with
runway over 12,000 ft., 3 with runways 8,000-11,999 ft., 88 with runways
4,000-7,999 ft.
Telecommunications: poorest telecom facilities on continent; radio-relay station
under construction; 47,200 telephones; est. 750,000 radio and 12,000 TV
receivers; 2 TV, 80 AM, and 14 FM stations
DEFENSE FORCES:
Military manpower: males 15-49 1,194,000; 750,000 fit for military service;
average number reaching military age (19) annually about 75,000
38
SEES GER TET IAP ED EEE ETI A EIN FTN EN FSR USF EY FE SE SES ESTAR REG |S
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 61 BOTSWANA
D:
220,000 sq. mi.; about 6% arable, less than 1%
under cultivation, mostly desert
Land boundaries: 2,345 mi.
Railroads: 400 mi. 3''6" gage, single track; owned and operated by the Rhodesia
Railroads
Highways: 3,260 mi.; 85 mi. paved, 725 mi. crushed stone or gravel; 990 mi. ’
improved earth, 1,460 mi. unimproved earth
Inland waterways: native craft only; of local importance
Civil air: 8 major transport aircraft
Airfields: 84 total, 71 usable; 2 with permanent-surface runways; 17 with
runways 4,000-7,999 ft.
Telecommunications: the system is a minimal combination of a single main wire
line and a few radiocommunication stations; Gaborone is the center; 4,435
telephones; 30,000 radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 154,000; 80,000 fit for military service; 8,000
reach military age (18) annually
No military; police, 1,400
40
Se ESR 5 PE NLT PDA PD IS Set TO RU ES EBA HET ES SESE EEC SPENCE DERE HERE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 94 BRAZIL
D:
3,290,000 sq. mi.; 4% cultivated, 13% pastures, 23%
built-on area, waste, and other, 60% forested
Land boundaries: 8,125 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 4,655 mi.
Railroads: 19,935 mi.; 17,586 mi. 3''3 3/8" gage, 2,085 mi. 5''3" gage, 121 mi.
4''8 1/2" gage, 143 mi. narrow gages; 1,621 mi. electrified
Highways: 591,000 mi.; 31,000 mi. paved, 560,000 mi. gravel or earth
Inland waterways: 31,000 mi. navigable
Ports: 6 major, 25 significant minor
Pipelines: crude 011, 770 mi.; refined products, 290 mi.; natural gas, 24 mi.
Civil air: 114 major transport aircraft
Airfields: 3,477 total, 3,009 usable; 130 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 355 with runways 4,000-7,999 ft.; 18 seaplane
stations
Telecommunications: moderately good telecom system; radio relay
widely used; communications satellite ground station; 2.45 million telephones;
est. 11.5 million radio and 7.3 million TV receivers; 920 AM, 150 FM, and 160
TV stations; 6 submarine cables, including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 23,606,000; 15,405,000 fit for military service;
1,170,000 reach military age (18) annually
42
TT ee aT eae ET! Fe Daa Se es SSNS ATP SR SER SNS! NSPROIDNERINNLINN
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 102 BRITISH SOLOMON ISLANDS
“About 11,500 sq. mi.
WATER:
Limits of territorial waters: 2 n. mi.
Coastline: about 3,300 mi.
Railroad: none
Highways: 518 mi.; 150 mi. sealed or all-weather
Inland waterways: none
Ports: 3 minor
Civil air: no major transport aircraft
Telecommunications: 3 AM broadcast stations, 8,000 radio receivers, 674
telephones; international connections with London, England, via cable
broadcasts
43
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NTIS 44 BRUNEI
LAND:
2,230 sq. mi.; 3% cultivated; 22% industry, waste,
urban or other; 75% forested
Land boundaries: 237 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 100 mi.
Railroads: 6 mi. narrow gage (2''0")
Highways: 750 mi.; 334 mi. paved (bituminous treated), 250 mi. gravel or stone,
266 mi. unimproved
Inland waterways: 130 mi.; navigable by shallow-draft craft
Ports: 2 minor (Bandar Seri Begawan, formerly Brunei, and Kuala Belait)
Pipelines: crude oi1, 84 mi.; refined products, 35 mi.; natural gas, 35 mi.;
crude oi! and natural gas, 150 mi. under construction
Civil air: no major transport aircraft
Airfields: 5 total, 3 usable; 2 with permanent-surface runway; 1 with runway ;
over 12,000 ft.; 2 with runways 4,000-7,999 ft.
Telecommunications: service throughout country is adequate for present needs;
international service good to adjacent Sabah and Sarawak; radiobroadcast
coverage good; 5,947 telephones; 16,000 radio sets; Radio Brunei
broadcasts from 3 stations and uses 4 mediumwave and 1 shortwave
transmitter
DEFENSE FORCES:
Military manpower: males 15-49, 39,000; 20,000 fit for military service; about
1,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December 1970, $9.8 million for the
military and $7.1 million for the police; about 15% of the total? budget
46
i taheiesietaeeetisieinatamnid aba tachiinnainiectiaineninaeatiunDbiuaeininatestmtanaieamialivouneanhintetsiansipeern mmladipmmmanantessass easter tipiessauicesiesssonaatiecnsaeanen’
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 23 BULGARIA
LAND:
42,800 sq. mi.; 41% arable, 11% other agricultural,
33% forested, 15% other
Land boundaries: 1,170 mi.
WATER: Ps “ TURKEY
Limits of territorial waters (claimed): 12 n. mi. en.
Coastline: 220 mi. ee
PEOPLE: LIBYA ecypt .—xeagia
Population: 8,659,000, average annual growth rate 0.7%
(current)
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsies, 2.5% Macedonians, 0.3% Armenians, 0.2% Russians, 0.6% other
Religion: regime promotes atheism; religious background of population is 85%
Bulgarian Orthodox, 13% Muslim, 0.8% Jewish, 0.7% Roman Catholic, 0.5%
Protestant, Gregorian-Armenian and other
Language: Bulgarian; secondary languages closely correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 4.4 million (July 1970); 38% agriculture, 33% industry, 29% other
Railroads: 2,650 mi.; about 2,470 mi. standard gage, 180 mi. narrow gage; 148 mi.
double track; 708 mi. electrified; government owned (1973}
Highways: 20,700 mi.; 12,400 mi. paved, 5,500 mi. crushed stone and gravel,
2,800 mi. earth (1973)
Inland waterways: 300 mi. (1973)
Freight carried: rail -- 80.4 million short tons, 10.8 billion short ton/mi.
(1972); highway -- 630.3 million short tons, 6.0 billion short ton/mi. (1972);
waterway ~- 8.2 million short tons, 2.3 billion short ton/mi. (incl. int''l.
transit traffic) (1972)
Ports: 2 major (Varna, Burgas), 10 minor (1973)
Airfields: 379 total; 105 with permanent-surface runways; 13 with runways
8,000-9,999 ft., 26 with runways 4,000-7,999 ft.
Civil air: 37 major transport aircraft (1973) <
DEFENSE FORCES:
Military manpower: males 15-49, 2,247,000; 1,876,000 fit for military service;
about 68,000 reach military age (18) annually
Military budget (announced): for fiscal year ending 31 December 1973, 700,000,000
leva; about 10.0% of total budget and 4.0% of GNP °
48
TPT Ne a Ne Ne | ey NT a Ne Te | LT Te aT Tae al TALI Ny Nam LEN ce een: DONOR NU OEE ES 4 SIU || SEI
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 38 BURMA
LAND:
262,000 sq. mi.; 28% arable, of which 12% is cultivated,
62% forest, 10% urban and other (1969)
Land boundaries: 3,630 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,900 mi.
Railroads: 2,022 mi.; 1,952 mi. meter gage, 70 mi. narrow-gage industrial lines; ‘
204:mi. double track; government owned
Highways: 15,540 mi.; 4,210 mi. paved, 4,770 mi. gravel, 5,810 improved earth,
750 mi. unimproved earth
Inland waterways: 8,000 mi.; 2,000 mi. navigable by large comercial vessels
Ports: 4 major, 6 minor
Civil air: 15 major transport aircraft
Airfields: 119 total, 79 usable; 23 with permanent-surface runways; 2 with
runways 8,000-11,999 ft., 38 with runways 4,000-7 ,999 ft.; 2 seaplane
stations
Telecommunications: provide minimum requirements for local intercity service;
international service is fair; radiobroadcast coverage is limited to the
more populous areas; 27,000 (est.) telephones; 440,000 radio sets;
1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 7,054,000; 3,625,000 fit for military service;
about 290,000 males and 270,000 females reach military age (18) annually;
both are liable for military service
Military budget: for fiscal year ending 30 September 1973; $154.3 million, 36.2%
of total budget
50
TA TS DRS SS |S PR a ee TES I a SN SSL SS
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 60B BURUNDI Moora Se Pe
TURKEY
oa
LAND: aa ALGERIA LIBYA Penn saunl :
11,000 sq. mi.; about 37% arable (about 66% cultivated), WALGER
23% pasture, 10% scrub and forest, 30% other 24
Land boundaries: 605 mi. {
Railroads: none
Highways: 3,700 mi.; 45 mi. bituminous, 3,655 mi. crushed stone, gravel, laterite,
and improved or unimproved earth
Inland waterways: Lake Tanganyika navigable for lake steamers and barges ©
Ports: 1 minor lake
Civil air: 3 major transport aircraft
Airfields: 32 total, 22 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft.
Telecommunications: telegraph is principal service, limited telephones; 5,875
telephones, 100,000 radio receivers; 2 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 898,000; 435,000 fit for military service; 42,000
reach military age (16) annually
52
nis cnt iahami mantel ene shina eben canteen aed abe tane imate aa lente inet ialepe canned tae ata taa tian eneiemamienie aielinemsicieainitea iid it linetemed inlined
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Was
at
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 43A CAMBODIA
LAND:
70,000 sq. mi.; 16% cultivated, 74% forested, 10% built-on
area, wasteland, and other
Land boundaries: 1,515 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. Sac ee:
Coastline: about 275 mi. ae “ngone sta
PEOPLE: oe
Population: 7,390,000, average annual growth rate 2.2%
(7/68-7/69)
Ethnic divisions: 89% Khmer (Cambodian), 3% Vietnamese,
5% Chinese, 3% other minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian
Literacy: 55% (est.)
Labor force: 2.56 million; 80.9% agriculture, 5.5% sales, 4.7% manufacturing,
transport, communications, 3.9% professional, administrative, clerical,
3.5% defense; 1.5% unemployed
Organized labor: .5% of labor force
Railroads: 409 mi. meter gage; government owned
Highways: 9,300 mi.; 1,600 mi. bituminous, 1,300 mi. crushed stone, gravel, or
improved earth; and 6,400 mi. unimproved earth
Inland waterways: 1,220 mi. during high-water season, 1,010 mi. during low-water
season; 90% of total navigability on Mekong system and Tonle Sap
Freight carried: (1970) rail -- 50 million ton-miles; waterway -- approximately
300,000 short tons annually; figures unavailable for highways
Ports: 2 major, 6 minor
Airfields: 101 total, 42 usable; 7 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 16 with runways 4,000-7,999 ft.; 1 seaplane station
DEFENSE FORCES:
Military manpower: males 15-49, 1,743,000; 920,000 fit for military service;
78,000 reach military age (18) annually
54
Pea ON LE NNT LET «FETE PENS
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 52C CAMEROON
LAND:
183,400 sq. mi.; 4% cultivated, 18% grazing, 13% fallow,
50% forest, 15% other
Land boundaries: 2,830 mi.
WATER:
Limits of territorial waters (claimed): 18 n. mi.
Coastline: 250 mi.
Railroads: 623 mi.; 533 mi. meter gage, 90 mi. 1''11 5/8" gage
Highways: approximately 14,000 mi.; including 900 mi. bituminous, 13,100 mi.
gravel and earth
Inland waterways: 1,300 mi.
Ports: 1 major, 3 minor
Civil air: 8 major transport aircraft
Airfields: 61 total, 59 usable; 7 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: good telephone service between Douala and Yaounde, fair in
southern part; fair to good telegraph service; 21,850 telephones; 216,000
radio receivers; 4 AM, no FM, and no TV stations; limited wired broadcast;
1 submarine cable; microwave radio-relay under construction Yaounde to Fort
Foureau; satellite earth communications station under construction in Yaounde
DEFENSE FORCES:
Military manpower: males 15-49, 1,407,000; 735,000 fit for military service;
average number reaching military age (18) annually about 65,000
Supply: mostly from France and U.S.
56
a aie ete ian ta eaeiina iid atinan diidartaataiadentaananmamae nists een dante nese) nae) a PA
Leeaashtesiatignamteninte etal iapigieicens Le amereryneny-drtgryw-a-aunle-|
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 52B CENTRAL AFRICAN REPUBLIC
D:
242 000 sq. mi.; 10%-15% cultivated, 5% dense forests,
80%-85% grazing, fallow, vacant arable land, urban,
waste
Land boundaries: 3,095 mi.
Railroads: none
Highways: 13,250 mi.; 115 mi. bituminous, 2,265 mi. gravel and/or crushed stone,
3,420 mi. improved earth, 7,450 mi. unimproved earth
Inland waterways: 4,400 mi.; traditional trade carried on by means of dugouts
on the extensive system of rivers and streams; only the Oubangui River
between Bangui and Brazzaville and short sections of the Sangha and the
Lobaye Rivers are navigable throughout year; during high-water period
(July - December) Oubangui navigable upstream from Bangui as far as Quango
Ports: Bangui, Ouango (river soRES|
Civil air: 3 major transport aircraft
Airfields: 67 total, 52 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 17 with runways 4,000-7,999 ft,
Telecommunications: facilities are meager and provide only barely sufficient
services; principal network is 39 low-capacity, low-powered radiocommunica-
tion stations; no cables or radio relay links are used; single center of
Bangui has only international radio connections; 5,100 telephones; 60,000
radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 449,000; 215,000 fit for military service
Supply: completely dependent on France
60
TS eT TT a eae tT ner Sane SIS OH aR SOHN FESS SN OSE HD ROO SERNINDN NE HORII HRSA
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 52A CHAD
LAND:
496,000 sq. mi.; 17% arable, 35% pastureland, 2% forest
and scrub, 46% other uses and waste
Land boundaries: 3,720 mi.
Railroads: none
Highways: 19,200 mi.; 160 mi. bituminous, 3,300 mi. gravel and laterite, and
15,740 mi. unimproved
Inland waterways: approximately 1,300 mi. of year-round navigability, increased
to 3,000 mi. during high-water period
Civil air: 3 major transport aircraft
Airfields: 76 total, 61 usable; 4 with permanent-surface runways; 1 with runway
8 000-11 ,999 ft., 23 with runways 4,000-7,999 ft.
Telecommunications: fair system of radiocommunication stations only for intercity
Tinks; principal center Ndjamena, secondary center Fort-Archambault; 5,000
telephones; 70,000 radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES: *
Military manpower: males 15-49, 944,000; 484,000 fit for military service;
average number reaching military age (20) annually about 35,000
Supply: dependent on France primarily
62
TL Se aL LN Ne yeaa yea: 0 a enn aya a Ne On aE ee am RU TG Nae ae EE a an PIAA aN Ts 5 aaa Eee ER
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 89 CHILE','5fae6725ee6845c5c22b433243266c795fa4cc607bb167a13cd0ee6e93ab60e1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d362dd4eca0c168baa7eb341e6f3685f548d1368e3696c7d22917ebb9e252e0a',1974,'LY','Libya','communications',29,'Railroads: 8,260 mi.; 8,080 mi. standard gage, 70 mi. broad gage, 110 mi. narrow
gage; 1,014 mi. double track; 1,560 mi. electrified; government owned (1972)
Highways: 45,500 mi.; 800 mi. concrete; 28,650 mi. bituminous; 2,400 mi.
cobblestone, brick sett, stone block; 13,650 mi. crushed stone, gravel,
improved earth (1972)
Inland waterways: 517 mi. (1973)
Pipelines: crude oi1, 900 mi.; refined products, 535 mi.; natural gas, 2,800 mi.
Freight carried: rail -- 248.9 million short tons, 41.2 billion short ton/mi.
(1972); highway -- 901.4 million short tons, 8.1 billion short ton/mi. (1972) ;
waterway -- 9.5 million short tons, 2.5 billion short ton/mi. (incl. int''l.
transit traffic) (1972)
Ports: no maritime ports; outlets are Gdynia, Gdansk, Stettin in Poland; Rijeka,
Yugoslavia; Hamburg, West Germany; Rostock, East Germany; principal river
ports are Prague, Melnik, Usti nad Labem, Decin, Komarno, Bratislava (1973)
Civil air: 45 major transport aircraft (1973)
Airfields: 134 total; 33 with permanent-surface runways; 19 with runways
8,000-11,999 ft., 49 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military budget: for fiscal year ending 31 December 1972, 17.1 billion crowns, bs
about 6.6% of total budget and 4.2% of est. GNP; 1973 budget unannounced as
of 1 November 1973
84
Cet ssieaesesesadlenlinmmusiemmenmniieanemeedicempnanitpeieemesinbbiniaeeieten sbapipineahiimebiecataemdealedpamusnabbieslpesiainaiidainieiiesiiiiibiieiuiniamaiiiill
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50M DAHOMEY
44,700 sq. mi.; southern third of country is most fertile;
arable land 80% (actually cultivated 11%), forests and
game preserves 19%, non-arable 1%
Land boundaries: 1,220 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (100 n.
mi. mineral exploitation limit
Coastline: 75 mi.
Railroads: 360 mi., all meter gage (3''3 3/8")
Highways: 4,300 mi.; 515 mi. paved, 2,665 mi. gravel and/or improved earth,
remainder unimproved
Inland waterways: 400 mi. navigable
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
Airfields: 11 total, 10 usable; 1 with permanent-surface runway; 4 with runways
4,000-7 ,999 ft.
Telecommunications: telephone service concentrated in south; telegraph limited,
but more extensive than telephone; 6,500 telephones; 54,000 radio receivers;
2 AM, no FM, and no TV stations; 3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 700,000; 335,000 fit for military service; about
30,000 mates and 29,000 females reach military age (18) annually; both sexes
liable for military service
Supply: dependent on France
86
eae neni ntamamiianesiineinnne ORAL ed Se pe
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 7 DENMARK
LAND: one ee fae
Rep ‘GER.
16,600 sq. mi. (exclusive of Greenland and Faeroe Islands);
64% arable, 8% meadows and pastures, 11% forested, 17%
other
Land boundaries: 42 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing
12 n. mi.)
Coastline: 2,100 mi.
Railroads: 1,810 mi. Danish State Railways (DSB) 1,461 mi. standard gage (4''8 1/2"),
52 mi. electrified and 453 mi. double tracked; remaining 349 mi. of standard
gage lines are privately owned and operated _
Highways: 38,295 mi.; 31,196 mi. concrete, bitumen, or stone block; 5,645 mi.
gravel and crushed stone; 1,454 mi. improved earth
Injand waterways: 259 mi.
Pipelines: refined products, 260 mi.
Ports: 16 major, 44 minor
Civil air: 104 major transport aircraft (including 4 belonging to Greenland)
Airfields: 139 total, 115 usable; 19 with permanent-surface runways; 8 with run-
ways 8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent telephone, telegraph, and broadcast services;
1,850,000 telephones; 1,650,000 radiobroadcast receivers; 1,500,000 TV
receivers; 5 AM, 13 FM, and 30 TV stations; 13 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 1,195,000; 1,050,000 fit for military service;
38,000 reach military age (20) annually
88
A AL ENE FO EL ED IH ERO PTS HEED TTS OG EE WTA SD NS 2 PRN POP CEH | ET
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 81A DOMINICA
LAND:
305 sq. mi.; 24% arable, 2% pasture, 67% forests, 7%
other ;
WATER: : VENEZUELA
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 92 mi. COLOMBIA
islands) EGYPT Auda Os
Railroads: 6,393 route mi.; 5,710 mi. standard gage, 683 mi. narrow gage;
463 mi. double track; 940 mi. electrified (1971)
Highways: 56,565 mi.; 14,850 mi. paved, 25,715 mi. gravel, crushed stone, 15,600
mi. improved earth, 400 mi. unimproved earth (January 1971)
Inland waterways: 1,231 mi. (1973)
Freight carried: rail -- 79.2 million short tons, 15.0 billion short ton/mi. (1971);
highway ~~ 78.7 million short tons, 5.0 billion short ton/mi. (1971);
waterway -- 27.6 million short tons, est. 5.3 billion short ton/mi. (incl. int''l.
transit traffic) (1972)
Pipelines: crude oi1, 200 mi.; natural gas, 580 mi.
Ports: 9 major (most important: Rijeka, Split), 24 minor {1973)
Civil air: 41 major transport aircraft (including 3 leased) (1973) :
Airfields: 194 total, 90 usable; 34 with permanent-surface runways; 18 with
runways 8,000-11,999 ft., 29 with runways 4,000-7,999 ft.; 2 seaplane
Stations
DEFENSE FORCES:
Military budget (announced): for fiscal year ending 31 December 1973, 13.6 -
billfon dinars; about 45% of total budget
386
in eee ee
, LTS AL TA el SRE RR TET ee TEIINI 1S ERG WR ERTS:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ed
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 60A ZAIRE
ND:
905,000 sq. mi.; 22% agricultural land (1% cultivated),
45% forested, 33% other
Land boundaries: 6,153 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 23 mi.
Railroads: 3,218 mi.; 2,419 mi. 3''6" gage, 78 mi. 3'' 3 3/8" gage, 85 mi.
2'' 0 1/4" gage, 636 mi. 1'' 11 5/8" gage; 532 mi. of 3''6" gage electrified
Highways: 87,800 mi.; 1,200 mi. bituminous, 11,300 mi. gravel or crushed stone,
75,300 mi. earth
Inland waterways: comprising the Zaire, its tributaries, and unconnected lakes,
the waterway system affords over 9,320 mi. of navigable routes
Ports: 2 major, 1 minor
Pipelines: refined products, 460 mi.
Civil air: 28 major transport aircraft
Airfields: 492 total, 338 usable; 19 with permanent-surface runways; 1 with
runway over 12,000 ft., 2 with runways 8,000-11,999 ft., 56 with runways
4,000-7,999 ft.; 5 seaplane stations
Telecommunications: limited, barely adequate telephone service, telegraph service
good; 23,000 telephones; 100,000 radio receivers; 7,100 TV receivers; 12 AM,
1 FM, and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 5,816,000; 2,795,000 fit for military service
388
TT ae ee TE ee a eT a tT 1 STNG PGE SSRI eee enn On RRO RSS} nEnOS SANTEE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 57A ZAMBIA
LAND:
\\ 288,000 sq. mi.; 5% under cultivation, 5% arable, 10%
grazing, 13% dense forest, 6% marsh, 61% scattered
trees and grassland
Land boundaries: 3,730 mi.
Railroads: 664 mi., government owned, all narrow gage (3''6"); 8 mi. double track
Highways: 21,375 mi.; 2,145 mi. paved, 4,690 mi. crushed stone, gravel, or
stabilized soil; 14,540 mi. improved and unimproved earth
Inland waterways: 1,409 mi. including Zambezi River, Luapula River, Lake Kariba,
Lake Bangweulu, Lake Tanganyika; principal port on Lake Tanganyika is Mpulungu
Pipelines: 450 mi. refined
Civil air: 9 major transport aircraft
Airfields: 196 total, 165 usable; 10 with permanent-surface runways; 1 with
runway over 12,000 ft., 2 with runways 8,000-11,999 ft., 23 with runways
4,000-7,999 ft.
Telecommunications: all services being modernized and increased; presently
adequate but must be expanded to permit growth; high-capacity wire and
radio relay connect centers of Kitwe in northern mining region and Lusaka
along axial north-south route; 56,800 telephones; 100,000 radio and
20,000 TV receivers; 4 AM, 1 FM, and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,140,000; 545,000 fit for military service
390
retain acer iteanti eit amnininninisiintnam lope nih iettiees ale aniaannnnennpnemmnnte imamate
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7','68e3459302e1cfc86d0a73eede41fdf246cf4bb7df90d6971e0838497f2314ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdf5e066ea66bff6a5c037cc1807bbad3d903fccbafb774428bf22a8544745f0',1974,'CO','Colombia','communications',30,'Limits of territorial waters (claimed): 12 n. mi.
Coastline: 250 mi.
PEOPLE: BRAZIL
Population: 5,809,000, average annual growth rate 2.8%
(current)
Ethnic divisions: 41.4% Indian, 58.6% Ladino (mestizo and
westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks an Indian language as
a primary tongue
Literacy: about 30%
Labor force: 1.7 million (1973); 63.2% agriculture, 12.4% manufacturing, 11.8%
services, 12.6% other, 2% unemployed; severe shortage of skilled labor;
oversupply of unskilled labor; of this total 15 to 20% are unemployed
at any one time
Organized Tabor: 4% of labor force (1973)
Railroads: 592 mi., 3''0" gage; single-tracked; 520 mi. government owned, 72 mi.
privately owned
Highways: 7,600 mi., 1,300 mi. bituminous, 4,400 mi. gravel, 2,100 mi. improved
or unimproved earth
Inland waterways: 164 mi. navigable year-round; additional 458 mi. navigable
during high-water season
Pipelines: crude oi], 30 mi.
Freight carried: rail (1960) -- 191.8 million ton/miles, 1.1 million tons
Ports: 2 major, 3 minor
Airfields: 497 total, 330 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 18 with runways 4000-7 999 ft.; 1 seaplane station 3
Civil air: 11 major transport aircraft
Telecommunications: modern telecom facilities|limited to Guatemala City;
47,000 telephones; 360,000 radio and 90,000 TV receivers, 86 AM, 20 FM,
and 3 TV stations; connection into Central) American microwave net
DEFENSE FORCES:
Military manpower: males 15-49, 1,432,000; Hose fit for military service;
about 65,000 reach military age (18) annually
144
no, a eel aehieneneeenemnnalll
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50E GUINEA
£ Speer
oo ALGERIA) Lipya [EGYPT
i
LAND:
95,000 sq. mi.; 3.3% cropland, 10% forest
Land boundaries: 2,160 mi.
5,SAUDI ©
WATER:
Limits of territorial waters (claimed): 130 n. mi.
Coastline: 215 mi.
Railroads: 500 mi. meter gage, 5 mi. er gage
Highways: 4,725 mi.; 465 mi. paved, 2,610 mi. all weather, 1,650 mi. unimproved
earth
Inland waterways: 1,115 mi.; 310 mi. navigable by small oceangoing vessels,
805 mi. navigable by shallow-draft steamers and barges
Ports: 1 major, 3 minor
Civil air: 7 major transport aircraft ;
Airfields: 20 total, 16 usable; 2 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 3 seaplane landing areas
Telecommunications: inadequate system of open-wire lines, small radio
communication stations, and 1 radio-relay link; principal center Conakry,
secondary center Kankan; 7,500 telephones; 100,000 radio receivers; 1 AM,
no FM, and no TV stations; 3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 872,000; 465,000 fit for military service
146
Liliaceae gi
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 95A GUYANA
LAND:
83,000 sq. mi.; 1% cropland, 3% pasture, 8% savanna,
66% forested, 22% water, urban, and waste
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 285 mi.
Railroads: 103 mi., all single track; 85 mil 3''0” gage, 18 mi. 3''6" gage
Highways: 1,800 mi.; 450 mi. paved, 850 mi. otherwise improved, 500 mi. unimproved
Inland waterways: 3,700 mi.; Demerara River navigable to Mackenzie by ocean
steamers, others by ferryboats, small craft only
Ports: 1 major, 3 minor
Civil air: 3 major transport aircraft
Airfields: 102 total, 89 usable; 4 with permanent-surface runways; 12 with runways
4,000~7 999 ft.; 2 seaplane stations
Telecommunications: highly developed telecom system with radio relay network and
over 16,500 telephones; tropospheric scatter link to Trinidad; 260,000 radio
receivers, 2 AM and 1 FM stations
DEFENSE FORCES: |
Military manpower: males 15-49, 183,000; 125,000 fit for military service
Supply: mostly U.K., some U.S. equipment
148
Br]
Approved For Release 2004/08/31 : CIA-RDP79-01051A0006000 -
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 79 HAITI
LAND:
10,700 sq. mi.; 31% cultivated, 18% rough pastures,
7% forested, 44% unproductive, 1965
Land boundary: 224 mi. costa dea fe
WATER: hye COLOMBIA
Limits of territorial waters (claimed): 12 n. mi.
(fishing 15 n. mi.) 7
Coastline: 1,100 mi. eae Perern
Railroads: 50 mi. 2'' 6" gage, single-track, privately owned industrial line; 5
mi. dual-gage 2'' 6"-3'' 6"; government as dismantled
Highways: 2,000 mi.; 350 mi. paved, 600 mi. otherwise improved, 1,050 mi.
unimproved
Inland waterways: negligible; about 60 mi. navigable
Ports: 2 major, 12 minor
Civil air: 7 major transport aircraft; 4 owned by the air force
Airfields: 31 total, 15 usable; 3 with permanent-surface runways; 1 with
runway 87000-11,999 ft., 5 with runways 4,,000-7,999 ft.; 2 seaplane stations
Telecommunications: all domestic facilities. nadequate, international facilities
slightly better; telephone expansion program underway; only 4,800 telephones,
290,000 radio and 12,000 TV receivers, 30''AM, 3 FM, and 1 TV station
DEFENSE FORCES:
Military manpower: males 15-49, 1,231,000; ae fit for military service;
about 51,000 reach military age (18) annu lly
150
ET EA ATT ET TENE Aa EEE NAGE PERE RI AP PLP RE AN SE PL NT POL PPP HE TI”
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 73 HONDURAS
LAND:
43,300 sq. mi.; 27% forested, 30% pasture, 36% waste
and built-up, 7% cropland AA
Land boundaries: 950 mi. eGsinnon
PANAMA‘
VENEZUELA
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 510 mi.
Railroads: 357 mi.; 202 mi. of 3''6" gage, 155 mi. of 3''0" gage
Highways: 5,400 mi.; 700 mi. bituminous surfaced, 1,550 mi. gravel surfaced or
improved earth, 3,150 unimproved earth |
Inland waterways: 750 mi. navigable by small craft
Ports: 3 major, 9 minor
Civil air: 22 major transport aircraft
Airfields: 239 total, 154 usable; 4 with permanent-surface runways; 10 with run-
ways 4,000-7 ,999 ft. 2 seaplane stations:
Telecommuni cations : tinroved: but still inadequate; connection into Central
American microwave net; 17,000 telephones; 300,000 radio and 35,000
TV receivers; 102 AM, i0 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 680,000; 400,000 fit for military service;
about 30,000 reach military age (18) annually
Supply: traditional dependence on U.S. has for the time being shifted to
Western Europe
152
IE IS TTI EN TET
Approved For Release 2004/08/31 : CIA- RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 39C HONG KONG
LAND:
400 sq. mi.; 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country)
Land boundaries: 15 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 455 mi.
Ports: 1 major
Civil air: 13 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft,
Telecommunications: modern facilities are adequate for domestic and international
requirements; excellent coverage is provided by radiobroadcast; limited
wired television reception is available; 691,616 telephones; 725,000 radia
receivers; 300,000 Ty receivers; 2 AM; 1 wired broadcast network; 1 FM;
2 TV stations (1 closed circuit); 4 submarine caples, 2 international
satellite stations in operation; radio relay links to the Republic of China
and to Canton, China; coaxial cable link |junder construction to Canton, China
DEFENSE FORCES:
Military manpower: males 15-49, 1,062,000; 790,000 fit for military service;
about 48,000 reach military age (18) annually
Defense is the responsibility of U.K.
Ships: Hong Kong Marine Police, 38 police eat U.K., U.K. naval ships homeported
in the U.K. operate in the Indian Ocean, ulf, and Far East; they rotate
assignments within the area and normally one destroyer escort is deployed to
the Hong Kong area; a varied number of auxiliary/service craft are assigned
to the Commander Hong Kong .
154
Ps -| -! -
Approved For Release 2004/08/31 : CIA-RDP79-01
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 19 HUNGARY
LAND:
35,900 sq. mi.; 60% arable, 14% other agricultural, 16%
forested, 10% other
Land boundaries: 1,395 mi.
Railroads: 5,275 route mi.; 4,465 mi. standard gage, 790 mi. narrow gage
(mostly 2'' 5 7/8"), 22 mi. broad gage (5''0"), 637 mi. double track, 580
mi. electrified; government owned (1971)
Highways: 18,360 mi.; 11,050 mi. paved, 6,560 mi. crushed stone or gravel, 755
mi. earth (1971)
Pipelines: crude oi1, 650 mi.; refined products, 180 mi.; natural gas, over
1,500 mi.
Inland waterways: 1,320 mi. (1973)
Freight carried: rail ~- 130.5 million short! tons (1971), 14.2 billion short ton/mi.
(1971); highway -- 483.8 million short tons, 4.7 million short ton/mi. (1972);
waterway -- 15.7 million short tons, 5.9 billion short ton/mi. incl. int''l
transit traffic (1972)
River ports: 2 principal (Budapest, Dunaujvaros); no maritime ports; outlets are
Rostock, East Germany and ports in Poland|(1972)
Civil afr: 18 major transport aircraft (1973
Airfields: 85 total; 13 with permanent-surface runways; 17 with runways 8,000--
11,999 ft., 20 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 2,658,000; 2,140,000 fit for military service;
about 84,000 reach military age (18) annually
Supply: produces small arms, ammunition, explosives, light artillery, naval
ships and craft, an armored reconnaissance vehicle, some trucks, chemical
warfare defensive materiel and small quantities of agents, some types of
electronic equipment; dependent upon Communist countries, primarily the
U.S.S.R., for other military equipment including radar and missiles
Military budget (announced): for fiscal year ending 31 December 1973, 9.85
billion forints; about 3.0% of total budget and 2.7% of est. GNP
156
Se TE RST aE SE 9 NP HO] EO IG HA ET SDP720 1081 AO00GonO non
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 68 ICELAND
Railroads: none
Highways: 1,100 mi.; 600 mi. paved, 500 mi. gravel and earth
Ports: | major, 5 minor
Civil air: no major transport
Airfields: 2 usable; 1 with permanent-surface runway; 1 with runway 8,000-11,999
ft; 1 seaplane station
Telecommunications: domestic facilities inadequate; 21,500 telephones, inter-island
VHF radio links; satellite earth station; 1 AM, 1 FM, and 5 TV stations; about
34,000 radio and 12,000 TV receivers
DEFENSE FORCES: |
Military manpower: males 15-49, included in France
224
a ET TTT Ty ei ee ea a Le een SnSRnC® een EP eee nNOS! PSE HESS:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50F MAURITANIA
D:
419,000 sq. mi.; less than 1% suitable for crops, 10%
pasture, 90% desert
Land boundaries: 3,180 mi.
WATER:
Limits of territorial waters (claimed): 30 n. mi.
(fishing, 6 n. mi. exclusive rights, 6m. mi.
contiguous zone)
Coastline: 490 mi.
Railroads: 400 mi. standard gage, single track, privately owned
Highways: 3,790 mi.; 350 mi. paved; 380 mi. gravel, crushed stone, or otherwise
improved; 3,070 mi. unimproved :
Inland waterways: 500 mi.
Ports: 3 minor
Civil air: 6 major transport aircraft
Airfields: 40 total, 29 usable; 9 with permanent-surface runways; 16 with run-
ways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone poor, telegraph fair; 1,300 telephones; 80,000
radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 274,000; 135,000 fit for military service;
conscription law not implemented
Supply: primarily dependent on France
a
a
«
e
226
aetna atin nena nee AT SON LG BOOSIE HE ERTS
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 63A MAURITIUS
LAND:
720 sq. mi. (excluding dependencies); 50% agricultural, in-
tensely cultivated; 39% forests, woodlands, mountains,
river, and natural reserves; 3% built-up areas; 5%
water bodies, 2% roads and tracks, 1% permanent
wastelands (1971)
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 110 mi.
Highways: 1,100 mi.; 990 mi. paved, 110 mi. earth
Civil air: no major transport aircraft
Ports: 1 major, 2 minor
Airfields: 6 total, 5 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft.
Telecomnunications: 19,100 telephones; radio telegraph service with Reunion,
Malagasy Republic, Seychelles, Zanzibar, and other places in Africa; 1 AM, 7
no FM, and 4 TV stations; 160,000 radio and 23,300 TV sets; submarine cables
extend to Republic of South Africa and Seychelles Islands
DEFENSE FORCES:
Military manpower: males 15-49, 200,000; 100,000 fit for military service
228
: eae ieee etaat inna aiaeaniaiinnee nmi inne ninzene, cides ;
Approved For Release — : CIA-RDP79-01051AQ00600010004-7 ree
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
BS NORWAY. 23
ESA. SWEDEN he
NIS 3 MONACO OENMARK CE vet ae
LAND:
0.6 sq. mi.
Land boundaries: 2.3 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing
2n. mi.)
Coastline: 2.6 mi.
Railroads: 1 mi. (see France)
Highways: none; city streets
Ports: 1 minor
Civil air: no major aircraft
Airfields: none
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont‘d):
Telecommunications: served by the French wire communications system; automatic
telephone system with about 16,800 telephones; international AM broadcast;
FM and TV facilities; 10,500 radio and 16,000 TV receivers
DEFENSE FORCES:
France responsible for defense
SE TO I INN a TIE OM OE TO SAE LEIA DETR
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 40 MONGOLIA
604,100 sq. mi.; almost 90% of land area is pasture or
desert wasteland, varying in usefulness, less than
1% arable, 10% forested
Land boundaries: 4,975 mi.
Railroads: 1,130 route mi.; 885 mi. broad gage (5''0") (1972)
Inland waterways: 585 mi. navigable; used primarily for local transport (1972)
Freight carried: rail -- 5.1 million short tons, 1,046 million short ton mi.
(1972); highway -- about 10 million short tons (1970); 415.1 million short *
ton/mi. (1970); waterway -- 2.5 million short ton/mi. (1970)
Airfields: 41 total; 5 with permanent-surface runways; 24 with runways 8,000-
12,999 ft., 11 with runways 4,000-7,999 ft., 6 additional airfields under
4,000 ft.
DEFENSE FORCES: :
Military manpower: males 15-49, 298,000; 195,000 fit for military service;
average number reaching military age (18) annually, about 15,000
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 31 December 1973, 212 million tugriks,
9% of total budget
234
i aeclaallaintnltiainheeimdinsten aa ahpianseaaniarultadianeasnined HERR Ee RRR
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 48 MOROCCO
LAND:
158,100 sq. mi.; about 32% arable and grazing land,
17% forest and esparto, 51% desert, waste, and urban
Land boundaries: 1,240 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 70 n. mi.)
Coastline: 1,140 mi.
Railroads: 1,100 mi. standard gage, 93 mi. double track; 493 mi. electrified
Highways: 32,180 mi.; 11,203 mi. bituminous, 3,244 mi. gravel, crushed stone, and
improved earth, 17,733 mi. unimproved earth
Pipelines: crude oi], 85 mi.; refined products, 305 mi.; natural gas, 60 mi.
Ports: 8 major (including Spanish-controlled Ceuta and Mellila), 11 minor »
Civil air: 11 major transport aircraft
Airfields: 143 total, 87 usable; 24 with permanent-surface runways; 2 with
runways over 12,000 ft., 10 with runways 8,000-11,999 ft., 38 with runways
4,000-7,999 ft.; 4 seaplane stations
Telecommunications: superior system by African standards composed of open-wire a
lines, coaxial, multiconductor and submarine cables and radio-relay links;
principal centers Casablanca and Rabat, secondary centers Fes, Marrakech,
Oujda, Sebaa Aioun, Tangier and Tetouan; 171,500 telephones; 1.5 million radio
and 225,000 TV receivers; 24 Moroccan AM, 1 Voice of America AM, 3 FM, 17 TV
stations; 1] submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,879,000; 2,640,000 fit for military service;
about 180,000 reach military age (18) annually; limited conscription
236
EI A GAS RTS BT CPOE TT ER OI ISA
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 58 MOZAMBIQUE
D:
303,769 sq. mi.; 30% arable, of which 1% cultivated, 56%
woodland and forest, 14% wasteland and inland water
Land boundaries: 2,875 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,535 mi.
Railroads: none
Highways: 700 mi.; 350 mi. paved, 220 mi. lotherwise improved, 130 mi. unimproved
Ports: 3 major, 6 minor
Civil air: 6 major transport aircraft
Airfields: 7 total, all usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: generally adequate telecom facilities; extensive inter-
island VHF links; 37,000 telephones, 125,000 radio and 34,000 TV receivers,
11 AM and 3 TV stations, 4 telegraph submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 60,000; 30,000 fit for military service;
about 2,000 reach military age (20) annually
Defense is responsibility of the Netherlands
>
a
¢
246
a tiated aminaiidintaiinietiedenii nem angen. nl LY LS Oe a Tn Hen ANE HOON | i DURES?
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 102 NEW CALEDONIA
LAND:
8,500 sq. mi.; 6% cultivable, 22% pasture land, 15% forests,
57% waste or other
WATER: i} AUSTRALIA
Limits of territorial waters (claimed): 12 n. mi. ae
(fishing, 3 n. mi.)
Coastline: 1,400 mi.
EW: :
“ZEALAND.
Railroads: none
Highways: 2,900 mi.; 180 mi. paved; 1,170 mi.
surface; 1,550 mi. unimproved earth
Intand waterways: none |
Ports: 1 major, 21 minor
Civil air: no major transport aircraft
]
4
nce (42%), Japan (47%), U.S. (9%);
gravel, crushed stone, or stabilized
Airfields: 36 total, 31 usable; 2 with permanent-surface runways; 2 with
runways 4,000-7,999 ft.; 1 airfield over
8,000 ft.; 1 seaplane station
Telecommunications: 10,711 telephones; 26,000 radio and 11,000 TV sets; 1 AM,
no FM, and 1 TV stations
248
8 LL NT een eee EE Lee am i HD SOO
TACT LARS NATE ES SS aOR LT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 102 NEW HEBRIDES
LAND:
About 5,700 sq. mi.
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: about 1,570 mi.
Railroads: none
Highways: at least 150 mi. sealed or all-weather roads
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Telecommunications: 1 AM broadcast station; 11,000 radio receivers, and 650
telephones
DEFENSE FORCES:
Personnel: no military forces maintained, however, the French and British maintain
constabularies of about 70 men each
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 75 NICARAGUA
ND:
7 57,100 sq. mi.; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other
Land boundaries: 760 mi.
COSTARICA OY”
Taare en f Mes § VENEZUELA
oe SRANAMAS
WATER: oS covomeia
~ Limits of territorial waters (claimed): 3 n. mi. RCP Soe
(fishing, 200 n. mi.; continental shelf, including ean joy neteees
sovereignty over superjacent waters) : 2 aaasic
Coastline: 565 mi.
Railroads: 220 mi.; 200 mi. of 3''6" gage, government owned; 20 mi. narrow gage,
privately owned
Highways: 8,500 mi.; 900 mi. paved, 3,250 mi. otherwise improved, 4,350 mi.
unimproved
Inland waterways: 1,380 mi., including 2 large lakes
Pipelines: crude oi1, 40 mi.
Ports: 4 major, 6 minor
Civil air: 12 major transport aircraft
Airfields: 468 total, 419 usable; 6 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: low-capacity wire network; connection into Central American
microwave net; satellite ground station; 26,500 telephones; est. 700,000
radio and 60,000 TV receivers; 80 AM, 30 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 515,000; 305,000 fit for military service;
24,000 reach military age (18) annually
254
lite iteaeeindem aii nde ORT ETE STOTT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
t od
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50L NIGER
"489,000 sq. mi.; about 3% cultivated, perhaps 20% somewhat
arable, remainder desert
Land boundaries: 3,570 mi.
Railroads: none
Highways: approx. 4,440 mi.; 425 mi. bituminous, 1,800 mi. gravel, 2,215 mi.
unimproved earth
Inland waterways: Niger River navigable 185 miles from Niamey to Gaya on the
Dahomey frontier from mid-December through March
Ports: Niger landlocked; outlet to sea is Cotonou, Dahomey
Civil air: 6 major transport aircraft
Airfields: 74 total, 58 usable; 4 with permanent-surface runways; 1 with runway
8,000-11 ,999 ft., 15 with runways 4,000-7,999 ft.
Telecommunications: principal telecommunication center Niamey; telephone poor,
telegraph fair, 3,300 telephones; 100,000 radio and 500 TV receivers; 4 AM,
no FM, and | TY stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,028,000; 565,000 fit for military service;
about 45,000 reach military age (18) annually 6
w
¢
256
etait ee ER
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50B NIGERIA
LAND:
357,000 sq. mi.; 24% arable (13% of total land area
under cultivation), 35% forested, 41% desert, waste,
urban, or other
Land boundaries: 2,507 mi.
< WATER:
Limits of territorial waters (claimed): 30 n. mi.
Coastline: 530 mi.
Railroads: 2,180 route mi.; 3''6" gage
Highways: 55,400 mi.; 9,500 mi. paved (mostly bituminous surface treatment) ;
45,925 mi. laterite, gravel, crushed stone, improved earth
Inland waterways: 5,330 mi. consisting of Niger and Benue rivers and smaller
rivers and creeks; additionally, the newly formed Kainji Lake has several
hundred miles of navigable lake routes
Pipelines: crude oil, 645 mi.; natural gas, 40 mi.; refined products, 3 mi.
Ports: 2 major, 10 minor
Civil air: 13 major transport aircraft
Airfields: 91 total, 78 usable; 14 with permanent-surface runways; 5 with runways
8,000-11,999 ft., 25 with runways 4 ,000-7,999 ft.; 4 seaplane stations
Telecommunications: composed of radio-relay links, open-wire lines, and radio-
communication stations; principal center Lagos, secondary centers Ibadan
and Kaduna; 86,800 telephones; 1.5 million radio receivers, 75,000 TV
receivers; 25 AM, 6 FM, and 8 TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 13,770,000; 6,675,000 fit for military service Q
»
258
TT a a a Te aT mT 0% a HH oe a SPEER POO Gann FUE: a HY OSS 6 SSE SONG HOOTERS 9 JPEGs DERSSI:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NTIS 10 NORWAY
LAND:
Norway: 125,000 sq. mi.; Svalbard, 24,000 sq. mi.;
Jan Mayen, 144 sq. mi.; 3% arable, 2% meadows
and p','780c07507240dd651a12ea8424ee4c3c3a61ffe37a5d33a741b3f4cbe7fa2ecc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92a1f2e2ab40c3b05741ec8f904e8f95db60b03c82bb7429bc94f4697228b057',1974,'CO','Colombia','communications',31,'astures, 21% forested, 74% other
Land boundaries: 1,603 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 12 n. mi.)
Coastline: mainland 2,125 mi.; islands 1,500 mi. (excludes
long fjords and numerous small islands and minor
indentations which total as much as 10,000 mi. overall)
Highways: 1,750 total; 3 mi. bituminous surface, remainder motorable natural -
surface track
Pipelines: crude oi] 230 mi.
Ports: 1 major, 6 minor
Civil air: no major transport aircraft
Airfields: 201 total, 131 usable; 4 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 40 with runways 4,000-7 ,999 ft.
Teleconmunications: poor international radiocommunications (service to Bahrain
only); very poor domestic wire service; 1,630 telephones; 1 AM station
DEFENSE FORCES:
Military manpower: males 15-49, 115,000; 66,000 fit for military service
261
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
\\
PEOPLE''S REPUBLIC
OF CHINA
NIS 36A PAKISTAN
LAND:
310,000 sq. mi. (includes Pakistani part of Jammu-Kashmir)
40% arable, including 24% cultivated; 23% unsuitable
for cultivation; 34% unreported, probably mostly waste
3% forested
Land boundaries: 3,650 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing
50 n. mi.; plus right to establish 100 n. mi. con-
servation zones beyond territorial sea)
Coastline: 650 mi.
Railroads: 5,465 mi.; 277 mi. meter gage, 4,808 broad gage, 380 narrow gage;
635 double track; government owned
Highways: 43,500 mi.; 12,700 mi. paved, 12,450 mi. gravel, 18,350 mi. earth
Iniand waterways: 1,150 mi.
Pipelines: crude oi1, 143 mi.; natural gas, 1,200 mi.
Ports: 1 major, 5 minor
Civil air: 19 major transport aircraft
Airfields: 203 total, 110 usable; 63 with permanent-surface runways; 1 with runway
over 12,000 ft., 20 with runways 8,000-11,999 ft., 54 with runways 4,000-
7,999 ft.; 2 Seaplane stations
Telecommunications: excellent international radiocommunication service over
CENTO Tinks; domestic wire and radiocommunication and broadcast service very
good; 211,000 (est.) telephones; 1,000,000 (est.) radio and 120,000 (est.)
TV sets; 7 AM, no FM, and 5 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 14,048,000; 7,550,000 fit for military service; ‘
689,000 reach military age (17) annually
264
a PLEIN SIE MET FB PSE ET TEN OTH CEE RR I SORT 8 AS EES ADEE HE TTR PTT SE I
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 77 PANAMA
ND:
29,208 sq. mi. (excluding Canal Zone, 553 sq. mi.); 24%
agricultural land (9% fallow, 4% cropland, 11%
pasture), 20% exploitable forest, 56% other forests,
urban, and waste (1970)
VENEZUELA
Land boundaries: 390 mi. os ee
WATER : CO EEA
Limits of territorial waters (claimed): 200 n. mi. pa Re BRAZIL
(continental shelf including sovereignty over super-
jacent waters)
Coastline: 1,545 mi.
Railroads: 305 mi.; 48 mi. 5''0" gage, 107 mi. 3''0" gage; 150 mi. plantation
feeder lines
Highways: 4,250 mi.; 1,200 mi. paved, 650 mi. gravel or crushed stone, 2,400 mi.
improved and unimproved earth; Panama Canal Zone 145 mi.; 140 mi. paved;
5 mi. gravel ‘
Inland waterways: 500 mi. navigable by shallow draft vessels; 51-mile
Panama Canal
Pipelines: refined products, 60 mi.
Ports: 2 major, 10 minor
Civil air: 30 major transport aircraft 7
Airfields: 238 total, 120 usable; 17 with permanent-surface runways; 3 with
runways 8,000-11,999 ft.; 11 with runways: 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: domestic and international telecom facilities well developed,
including nearly nationwide radio-relay system; connection into central
American microwave net; communications satellite ground station; 112,000
telephones; 550,000 radio and 200,000 TV receivers; 80 AM, 22 FM, and 13 TV
stations; ] coaxial submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 354,000; 245,000 fit for military service;
no conscription
266
— sasha taepesereterendyserpepd-eru: tre
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 102 PAPUA NEW GUINEA
LAND:
183,540 sq. mi. (Papua 90,540 sq. mi., New Guinea
93,000 sq. mi.)
Land boundaries: 600 mi.
PEOPLE: mae Ke
Population: 67,000, average annual growth rate 1.2%
(4/60-4/70)
Ethnic divisions: mainly of African Negro descent
Religion: Church of England, other Protestant sects,
Roman Catholic
Language: English
Literacy: about 80%
Labor force: 19,616 (1960 est.)
Organized labor: 6,700
Railroads: 36 mi., narrowgage (2''6"} on St. Kitts for sugar cane
Highways: 180 mi.; 60 mi. paved, 90 mi. otherwise improved, 30 mi.. unimproved
earth
Ports: 3 minor (1 on each island) as
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 1 with asphalt runway 5,700 ft.
Telecommunications: good interisland VHF radio connections and international
link via Antigua; about 1,700 telephones; 1,600 radio and 1,400 TV receivers;
5 AM and 5 TV stations *
lal
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 81A ST. LUCIA
LAND:
238 sq. mi.; 34% arable, 5% pasture, 21% forest, 22%
unused but potentially productive, 18% wasteland
and built-on
WATER:
Limits of territorial waters (claimed): 3 n. mi. coceels
Coastline: 98 mi.
PEOPLE: BRAZIL
Population: 93,000, average annual growth rate 1.1%
(4/60-4/70)
Ethnic divisions: mainly of African Negro descent; remainder
mixed with some white and East Indian and Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60% unemployed
Organized labor: 10% of labor force
Railroads: none
Highways: 600 mi.; 200 mi. paved; 200 mi. otherwise improved; 200 mi. unimproved
earth
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 3 total; 2 usable, 1 with asphalt runway 4,800 ft.
301
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Telecommunications: islandwide fully automatic telephone system with 3,800
instruments; VHF interisland links to Barbados and the Grenadines; 10,000
radio and 400 TV receivers; 2 AM stations
302
SS RO RP a TA SELLE ATES OT NL TOC PETES IU
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 17 SAN MARINO
LAND:
24 sq. mi.; 74% cultivated, 22% meadows and pastures,
4% built-on
Land boundaries: 21 mi.
Railroads: none
Highways: about 65 mi.
Civil air: no major transport aircraft
Airfields: none «
Telecommunications: automatic telephone system serving 3,200 telephones; no
radiobroadcasting or television facilities, 3,200 radio and 600 TV receivers
(Italian broadcasts)
>
a
.
304
i aaa emmeniiataiiatenaeennendines none tn sarin ieetah hte aattattenernedatearataenadpaiss adden ise insole suede
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 32D SAUDI ARABIA
D:
618,000 sq. mi. (boundaries are poorly defined); 1%
agricultural, 1% forested, 98% desert, waste, or
urban
Land boundaries: 2,820 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (plus
6 n. mi. "necessary supervision zone")
Coastline: 1,560 mi.
Railroads: 350 mi., 4''8 1/2" gage
Highways: 8,700 mi.; 5,400 mi. bituminous, 3,300 mi. gravel and improved earth,
undetermined mileage of earth roads and tracks
Pipelines: crude oil, 1,435 mi.; refined products, 95 mi.; natural gas, 95 mi.
Ports: 3 major, 6 minor %
Civil air: 22 major transport aircraft
Airfields: 239 total, 78 usable; 20 with permanent-surface runways; 12 with
runways 8,000-11,999 ft., 42 with runways 4,000-7,999 ft., 1 with runway over
12,000 ft.
Telecommunications: excellent international radio communications; poor domestic
wire service; 81,600 telephones; 250,000\\radio and 150,000 TV receivers; 11
TV, 1 FM, and 4 AM stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 1,410,000; 755,000 fit for military service;
about 62,000 reach military age (18) annually
«
cd
4
306
SLL TL TT LT NTI te A PTR al edie heeaihaienentatettiniahitieartaaterieaiasiaamalatstiinanpennnin ieee linbenaieall
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 506 SENEGAL
D:
76,000 sq. mi.; 13% forested, 40% agricultural (12%
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 1,665 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing
110 n. mi.; fisheries zone beyond territorial sea)
Coastline: 330 mi.
Railroads: 640 mi. meter gage; 40 mi. double track
Highways: 8,725 mi.; 1,335 mi. bituminous, 990 mi. gravel, 400 mi. improved
earth, 6,000 mi. unimproved earth
Inland waterways: 935 mi. ~
Ports: 1 major, 2 minor
Civil air: 5 major transport aircraft
Airfields: 42 total, 27 usable; 9 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: relatively advanced for Africa; 29,300 telephones; 280,000 ‘
radio receivers; 1,600 TV receivers; 3 AM, no FM, and 1 TV stations; 3
submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 942,000; 455,000 fit for military service;
50,000 reach military age (18) annually
Supply: primarily dependent on France
308
area emeeitinsaemeiiieie otal PER OTN RRA ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 63A SEYCHELLES
LAND:
156 sq. mi.; 54% arable land, nearly all of it is under
cultivation, 17% wood and forest land, 29% other
(mainly reefs and other surfaces unsuited for
agriculture); 40 granitic and 43 coral islands
WATER:
Limits of oe waters (claimed): 3.n. mi. (fishing
12 n. mi.
Coastline: 305 mi. (Mahe Island 58 mi.)
Railroads: none
Highways: 141 mi.; 78 mi. bituminous, 63 mi. crushed stone or earth
Ports: 1 minor port (Victoria) .
Civil air: no major transport aircraft
Airfields: 3 total, 1 usable on Prasin Island, 1 usable on Astove Island, 1
permanent surface 8,000-11,999 ft. on Mahe Island; former RAF seaplane
station at Victoria, Mahe Island, although not in present use, could be
used in emergency
Telecommunications: direct radiotelegraph communications with other adjacent
islands and African coastal countries; 1,200 telephones; 15,000 radio sets;
no TV sets; 2 AM, no FM, and no TV stations; submarine cables extend to
Aden, Tanzania, and Sri Lanka
DEFENSE FORCES:
Military manpower: males 15-49, 13,000; 7,000 fit for military service
310
eee itn eneennemmamuneuseseee En - Hh
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50Q SIERRA LEOME
D:
27,900 sq. mi.; 65% arable (6% of total land area under
cultivation), 27% pasture, 4% swampland, 4% forested
Land boundaries: 589 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 250 mi.
Railroads: 370 route miles; 310 mi. narrow gage (2''6") Sierra Leone Government
Railroad (SLR), 60 mi. narrow gage (3''6") privately owned mineral line
operated by the Sierra Leone Development Company
Highways: 5,130 mi.; 550 mi. bituminous (including some bituminous treatment) ,
1,470 mi. laterite (some gravel), and 3,110 mi. earth
Inland waterways: 500 mi.; 372 mi. navigable year-round
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 15 total, 15 usable; 5 with permanent-surface runways; 1 with runway
8,000-11 ,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone and telegraph are adequate; 6,500 telephones;
50,500 radio and 5,000 TV receivers; 1 AM, no FM, and 1 TV stations;
3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 632,000; 303,000 fit for military service; no
conscription
312
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 36 SIKKIM
PEOPLE''S REP.
OF CHINA
LAND:
2,800 sq. mi.
Land boundaries: 265 mi.
Railroads: none
Highways: 575 mi.; 252 mi. paved, 129 mi. crushed stone or gravel, 194 mi. earth
Civil air: no major transport aircraft
Airfields: 1 gravel runway 600 ft.
DEFENSE FORCES:
Supply: dependent on India
313
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 44¢ SINGAPORE
LAND:
225 sq. mi.; 31% built up area, roads, railroads, and
airfields, 22% agricultural, 47% other
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi.
Railroads: 24 mi. of meter gage
Highways: 1,226 mi.; 773 mi. paved, 243 mi. crushed stone, 210 mi. improved
earth
Ports: 3 major
Civil air: 16 major transport aircraft
Airfields: 5 total, 5 usable; 4 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate domestic facilities; good international service;
good radio and television broadcast coverage; 189,847 telephones; 268,004
radio and 193,120 TV sets; 2 AM, 4 FM, and 2 TV stations; new seacom
submarine cable extends to Hong Kong via Sabah, Malaysia
DEFENSE FORCES:
Military manpower: males 15-49, 586,000; 395,000 fit for military service
316
SRT LA CA IE OT OVE EID 2 LE SR ERS ES CE PR TRE PSST EET OPCW 1 SERS HSA
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 55B SOMALIA
246,000 sq. mi.; 13% arable (0.3% cultivated), 32%
grazing, 14% scrub and forest, 41% mainly desert,
urban, or other
Land boundaries: 1,406 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,880 mi.
Railroads: none
Highways: 8,414 mi.; 582 mi. paved; 478 mi. crushed stone, gravel, or
stablized soil; 7,354 mi. improved or unimproved earth
Inland waterways: Fiume Giuba navigable 345 mi. from May to mid-June and
August to late November
Ports: 4 major, 17 minor
Civil air: 5 major transport aircraft
Airfields: 111 total, 53 usable; 2 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.; 5 seaplane
stations
Telecommunications: telephone poor, telegraph fair; 4,740 telephones; 60,000
radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 735,000; 395,000 fit for military service; no
conscription
318
LS a ee a Ne I [Pa SNR Ou NT EE GP eh -
Lesdieiehaeisiedaeiiemesie a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 61 SOUTH AFRICA
LAND:
472,000 sq. mi. (includes enclave of Walvis Bay,
434 sq. mi.); 12% cultivable, 2% forested, 86%
desert, waste, or urban
Land boundaries: 1,270 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,790 mi.','d52219efcbe7c7973b90dd33faf22d3fc1e3c9be5b02b25040242edae78f8c15','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c13988d9d136b0291a21f7117e5f948dfd10dd3fd901d5dc892f84ea03699914',1974,'GL','Greenland','communications',38,'LAND: | a
39,750 sq. mi.; arable negligible, 22% meadows and :
pastures, forested negligible, 78% other
WATER:
Limits of territorial waters (claimed): 4 n. mi. (fishing,
50 n. mi., effective 1 September 1972)
Coastline: 3,100 mi.
PEOPLE: sey
Population: 213,000, average annual growth rate 1.1%
(12/66-12/72)
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant and Roman Catholic, 2%
no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 85,000; 22.6% agriculture and fishing; 25.6% mining and manufacturing;
10.7% construction; 12.8% commerce; 7.8% transportation and communications;
15.2% services; and 5.7% other; unemployment is insignificant
Organized labor: 60% of labor force
Railroads: none
Highways: 7,400 mi.; 4,760 mi. crushed stone |(including lava) and gravel, 2,593
mi. unsurfaced roads and motorable tracks, 47 mi. concrete (some bituminous
stretches)
Ports: 4 major, and about 50 minor
Civil air: 20 major transport aircraft
Airfields: 108 total, 93 usable; 4 with permanent-surface runways; | with
runway 8,000-11,999 ft., 13 with runways 4,000-7,999 ft. ; 5 seaplane stations
Telecommunications: adequate domestic service, wire and radio communication
system; 77,200 telephones; 75,000 radio and 47,000 TV receivers; 17 AM,
14 FM, and 73 TV stations; 2 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 51,000; 44 ,000 fit for military service (Iceland
has no conscription or compulsory military service)
158
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 35 INDIA
PEOPLE''S REPUBLIC.
OF CHINA
LAND:
1,211,000 sq. mi. (includes Indian part of Jammu-
Kashmir, Sikkim, Goa, Damao and Diu); 50% arable,
5% permanent meadows and pastures, 20% desert,
waste, or urban, 22% forested, 3% inland water
Land boundaries: 7,880 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing,
12 n. mi.; additional 100 mi. is fisheries conservation
zone, December 1968; archipelago concept baselines)
Coastline; 4,378 mi. (includes offshore islands)
Railroads: 4,364 mi.; 3,990 mi. 3''6" gage, 317 mi. 2''5 1/2" gage, 57 mi.
1''11 5/8" gage; 132 mi. double track; 74 mi. electrified; government owned
Highways: 57,460 mi.; 12,600 mi. paved, 25,200 mi. gravel or crushed stone,
19,660 mi. improved or unimproved earth
Inland waterways: 13,410 mi.; Sumatra 3,400 mi., Java and Madura 510 mi., Borneo
6,500 mi., Celebes 150 mi., and Irian Barat 2,850 mi.
Ports: 10 major, 63 minor
Civil air: 95 major transport aircraft (includes 2 leased)
Airfields: 363 total, 248 usable; 39 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 62 with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: extensive police net for interisland service; international a
and domestic service fair but improving; radiobroadcast coverage adequate :
but TV limited to Java only; 229,636 telephones ; 2.6 million radio and 236,000
TV sets; AM stations at over 50 locations; 1 FM and 7 TV stations; 1 earth
satellite station on Java; 2 submarine cables to Singapore no longer in service
162
SDP 79.0105 1 AOOUGO00 000 aE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 33 IRAN
LAND:
636,000 sq. mi.; 14% agricultural, 11% forested, 16%
cultivable with adequate irrigation, 51% desert,
waste, or urban, 8% migratory grazing and other
Land boundaries: 3,305 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 50 n. mi.)
Coastline: 1,980 mi., including islands, 420 mi.
Railroads: 2,373 mi. 4''8 1/2" gage, 57 mi. 5''6" gage
Highways: 27,000 mi.; 7,500 mi. bituminous and bituminous treatment, 14,250 mi.
gravel and crushed stone, 6,508 mi. improved earth
Inland waterways: 565 mi., excluding the Caspian Sea, 64.6 mi. on the Shatt a
al Arab
Pipelines: crude oi], 1,640 mi.; refined products, 2,235 mi.; natural gas,
1,440 mi.
Ports: 7 major, 6 minor
Civil air: 20 major transport aircraft *
Airfields: 239 total, 146 usable; 53 with permanent-surface runways; 7 with
runways over 12,000 ft., 17 with runways 8 ,000-11 ,999 ft., 53 with runways
4 ,000-7 ,999 ft.
Telecommunications: advanced system of high-capacity radio-relay links, open-wire
lines, cables, and tropospheric links; Brinetpal center Teheran, secondary
centers Isfahan, Meshed, and Tabriz; 307,500 telephones; 1.8 million radio
and 260,000 TV receivers; 20 AM, 1 FM, and 9 TV stations; satellite earth
station
DEFENSE FORCES:
Military manpower: males 15-49, 7,469,000; 44455 000 fit for military service;
about 327,000 reach military age (21) annually
164
nalaheeaeeeeeereneetteaimesiaiiam enamine. nadie ta cna DTS ETE SEDER 1 PL INC POSTE GU ECA GENO
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 30 TRAQ
TURKEY
LAND:
172,000 sq. mi.; 18% cultivated, 68% desert, waste, or
urban, 10% seasonal and other grazing land, 4% forest
and woodland
Land boundaries: 2,280 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 36 mi.
Railroads: 1,408 mi.; 698 mi. 4''8 1/2" gage,''710 mi. meter (3''3 3/8") gage;
10 mi. meter gage double track
Highways: 12,919 mi.; 4,033 mi. paved; 2,886: mi. crushed stone, gravel, or
improved earth; 6,000 mi. earth and sand tracks
Iniand waterways: 635 mi.; Shatt al Arab navigable by maritime traffic for
about 65 mi.; Tigris and Euphrates navigable by shallow-draft steamers
Ports: 3 major
Pipelines: crude oi], 1,660 mi.; 25 mi. refined products; 430 mi. natural gas
Civil air: 6 major transport aircraft
Airfields: 176 total, 77 usable; 23 with permanent-surface runways; 46 with
runways 8,000-11,999 ft., 15 with runways |4,000-7,999 ft.
Telecommunications: fair international radiocommunication service; poor
domestic telephone and telegraph service; 120,000 telephones; 1.25 million
radio receivers; 350,000 TV receivers; 4 TV and 4 AM stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,395,000; 1,295,000 fit for military service;
about 122,000 reach military age (18) annually
166
* sehen TAT ENN ST TOE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 2 IRELAND
LAND:
26,600 sq. mi.; 17% arable, 51% meadows and pastures,
3% forested, 2% inland water, 27% waste and urban
Land boundaries: 224 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing,
12 n. mi.)
Coastline: 900 mi.
Railroads: 1,361 mi., 5''3" gage; government |owned
Highways: 53,700 mi.; 46,950 mi. surfaced, 6,750 mi. earth
Inland waterways: approx. 650 mi.
Ports: 6 major, 38 minor
Civil air: 23 major transport aircraft, plus 4 withdrawn from service
Airfields: 38 total, 34 usable; 7 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: small, modern system; all cities interconnected for telephone
and telegraph service; 350,000 telephones; 803,000 radiobroadcast receivers;
540,000 TV receivers; 6 AM, 5 FM, and 19/TV stations; 4 coaxial submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 663,000; 520,000 fit for military service;
about 28,000 reach military age (17) annually *
168
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 17 ITALY
-f ot eo
i FED.S E \\pou.
REP ‘GER.
116,300 sq. mi.; 50% cultivated, 17% meadow and pasture,
21% forest, 3% unused but potentially productive,
9% waste or urban
Land boundaries: 1,058 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. (fishing,
12 n. mi.)
Coastline: 3,105 mi.
Railroads: 12,857 mi.; 9,907 mi. government owned; 9,805 mi. standard gage; 4,906
mi. electrified; 102 mi. narrow gage (3'' 1 1/8"); 2,950 mi. non-government
owned; 1,567 mi. standard gage; 794 mi. electrified; 1,383 mi. narrow gage;
323 electrified
Highways: 179,000 mi.; autostrade 3,000 mi., state highways 25,750 mi., provincial
highways 57,000 mi., communal highways 93,250 mi.; 159,000 mi. concrete,
bituminous, or stone block, 15,500 mi. gravel and crushed stone, 4,500 mi.
earth
Inland waterways: 1,538 mi. navigable routes; 708 mi. rivers, 529 mi. canals,
307 mi. are lake routes 4
Pipelines: crude oi], 1,100 mi.; refined products, 900 mi.; natural gas, 6,000 mi.
Ports: 16 major, 22 significant minor
Civil air: 138 major transport aircraft (including 1 foreign owned but Italian
registered)
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ED EG HRT biiapeanatunl LET LET OGRE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Airfields: 230 total, 150 usable; 81 with permanent-surface runways; 2 with
runways over 12,000 ft., 27 with runways 8,000-11,999 ft., 46 with runways
4,000-7,999 ft.; 11 seaplane stations
Teleconmunications: well engineered, well constructed, and efficiently operated;
11.8 million telephones; 12.6 million radio and 11.3 million TV receivers;
82 AM, 570 FM, and 860 TV stations, each with numerous repeater stations;
9 coaxial submarine cables; 3 communication satellite ground stations
DEFENSE FORCES:
Military manpower: males 15-49, 13,705,000; 11,485,000 fit for military service;
423,000 reach military age (18) annually
173
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50K IVORY COAST
LAND:
125,000 sq. mi.; 40% forest and woodland, 8% cultivated,
52% grazing, fallow, and waste, 200 mi. of lagoons
and connecting canals along eastern coast
Land boundaries: 2,005 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 320 mi.
Railroads: 408 mi. of the 728 mi. Abidjan to
Single track meter gage; only diesel locom
Highways: 24,600 mi.; 1,045 mi. bituminous an
21,385 mi. gravel, crushed stone, laterite
mi. unimproved earth roads
Inland waterways: 460 mi. navigable rivers an
Ports: 2 major, 3 minor
Civil air: 13 major transport aircraft (inclu
Airfields: 50 total, 44 usable; 3 with perman
8,000-11,999 feet; 8 with runways 4,000-7,
1 : CIA-RDP79-01051A000600010004-7
788 million kw.-hr. produced (1972),
tropical woods, cocoa, 80% of total;
Ww
r goods about 40%, raw materials and
ished products, about 50%
ntries about 65%, U.S. 13%, Communist
EC $123 million, including 1971
others (1960-71), $76 million,
nist aid programs
million (1954-67)
current expenditures $280.3 million,
iere Africaine franc=0.02 French
uary 1973 (currency floating since
Ouagadougou, Upper Volta line, all
otives in use
d bituminous-surface treatment;
> and improved earth; 12,600
d numerous coastal lagoons
des 2 aircraft registered in Gabon)
ent-surface runways; 2 with runways
Telecommunications: system only slightly above African average; consists of
microwave relays, open-wire lines and radi
incomplete coverage of country; Abidjan is
80,000 radio and 70,000 TV receivers; 3 AM
submarine cables; satellite earth station
DEFENSE FORCES:
Military manpower: males 15-49, 1,134,000; 54
63,000 males reach military age (18) annua
176
Approved For Release 2004/08
999 feet; 1 seaplane station a
o relay links, which provide
only center; 24,800 telephones;
is 2 FM, and 4 TY stations; 2
¥
5,000 fit for military service;
ly
4
?
" ESR SE
A LN a Ta ae ee ee
131 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 81C JAMAICA
LAND:
4,410 sq. mi.; 21% arable, 23% meadows and pastures, 19%
forested, 37% waste, urban, or other (1968)
COSTA RICA ¢ = :
WATER: chiara? VENEZUELA
Limits of territorial waters (claimed): 12 n. mi. oe “1 covomata
Coastline: 635 mi. ce oe
PEOPLE: ay
PERU BRAZIL
w : ae
Population: 1,965,000, average annual growth rate 1.5%
(4/60-4/70)
Ethnic divisions: African 76.3%, Afro-European 15.1%,
Chinese and Afro-Chinese 1.2%, East Indian and
Afro-East Indian 3.4%, white 3.2%, other 0.9%
Religion: predominantly Protestant, some Roman Catholic, some spiritualist cults
Languages English
Literacy: Ministry of Education estimates between 43% and 57% of adult population
functionally literate
Labor fofce: 808,300; 26% in agricu]ture, forestry, fishing and mining, 10%
manufacturing, 8% public administration, 5% construction, 10% conmerce, 3%
transportation and utilities, 15% services, 23% unemployed (seasonal unemploy-
ment in agriculture can push the unemployment figure to 25%); shortage of
technical and managerial personnel
Organized labor: about 25% of labor force (1966)
Railroads: 204 mi. government-owned, 43 mi. privately owned, all standard gage,
single track
Highways: 7,100 mi.; 1,500 mi. paved, 4,100 mi. gravel, 1,500 mi. unimproved
earth surfaces
Pipelines: refined products, 6 mi.
Ports: 3 major, 10 minor
Civil air: 5 major transport aircraft
Airfields: 48 total, 38 usable; 11 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 2 with runway 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fully automatic domestic) telephone network with 82,800
telephones; satellite ground station; 600|,000 radio and 90,000 TV receivers;
8 AM, 8 FM, and 8 TV stations; 5 submarine cables, including 2 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 416,000; 280,000 fit for military service; no
conscription; average number currently reaching minimum volunteer age (18)
22 ,000
Supply: dependent on U.K. and U.S.
178
LOL LT aT i ee NPT oe HG ba
eS eS 0 RSI EEG
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ed
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 29 JORDAN
NOTE: The war between Israel and the Arab states in June 1967
ended with Israel in control of West Jordan. Although
approx. 930,000 persons resided in this area prior to the
start of the war, fewer than 750,000 of them remain there
under the Israeli occupation, the remainder having fled
to East Jordan. Over 14,000 of those who fled were
repatriated in August 1967, but their return has been
more than offset by other Arabs who have crossed and are
continuing to cross from West to East Jordan. These and
certain other effects of the Arab-Israeli war are not
included in the data below.
LAND:
37,100 sq. mi. (including about 2,100 sq. mi. occupied by Israel); 11%
agricultural, 88% desert, waste, or urban, 1% forested
Land boundaries: 1,100 mi. (1967, 1,037 mi. exctuding occupied areas)
WATER:
Limits of territorial waters (claimed): 3.n. mi.
Coastline: 16 mi.
Railroads: 227 mi. 3''5 3/8" gage, single track
Highways: 4,400 mi.; 3,486 mi. bituminous, 249 mi. improved, 665 unimproved earth
(these mileages include approximately 670 mi. -- mostly bituminous -- of
Jordanian territory held by Israel)
Pipelines: crude oi1, 130 mi.
Ports: 1 major o
Airfields: 53 total, 21 usable; 11 with permanent-surface runways; 2 with
runways over 12,000 ft., 9 with runways 8),000-11,999 ft., 4 with runways
4,000-7 ,999 ft.; 1 seaplane station
Telecommunications: adequate telecomnunication system for the needs of the
country; 33,000 telephones; 300,000 radio and 132,000 TY receivers; 1 AM Py
and 1 TV stations; 1 earth satellite station
DEFENSE FORCES:
Military manpower: males 15-49, 608 ,000; 460,000 fit for military service;
average number currently reaching military age (18) annually 30,000
182
i ettteeineeeeeee en ee WAY TE WVATGTITVITVT0 5 (010107. dopammeameneneeameeny
Approved For Release 2004/08/31 : CIA-RDP79-01051A0006000
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 56D KENYA
LAND:
WATER:
225,000 sq. mi.; about 21% forest and woodland, 13%
suitable for agriculture, 66% mainly grassland
adequate for grazing (1971)
Land boundaries: 2,093 mi.
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 333 mi.
Railroads: 1,275 mi.; meter gage
Highways: 29,075 mi.; 2,075 mi. paved, 27,000 mi. gravel and/or earth
Inland waterways: part of Lake Victoria and Lake Rudolph are within boundaries
of Kenya :
Ports: 1 major, 3 minor
Civil air: 9 major transport aircraft
Airfields: 270 total, 214 usable; 6 with permanent-surface runways ; 1 with
runway over 12,000 ft., 1 with runways 8,000-11,999 ft., 45 with runways
4,000-7 ,999 ft.; 3 seaplane stations
Telecommunications: in top group of African systems; consists of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Nairobi, secondary centers Mombasa and Nakuru; 85,200 telephones; 774,000
radio and 37,000 TV receivers; 3 AM, 1 FM, and 5 TV stations; 1 submarine
cable; satellite ground station
DEFENSE FORCES:
Military manpower: males 15-49, 2,809,000; 1,365,000 fit for military service;
no conscription
184
Las iaainiininin theann ca dsatmaiein etetnemienciane nin attended th calcein itaieninletaonte lian hteaeateall
Approved For Release 2004/08/83 1 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
PEOPLE''S REP
NIS 41A KOREA, NORTH OF CHINA
"47,000 sq. mi.; 17% arable and cultivated, 74% in forest,
scrub, and brush; remainder wasteland and urban
Land boundaries: 1,440 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,550 mi.
Railroads: 2,818 route mi. operating in 1968; 2,137 mi. standard gage, 681 mi.
2''6" narrow gage; 99 mi. double tracked; about 588 mi. electrified; government
owned
Highways: about 12,600 mi., 95% gravel or earth surface .
Inland waterways: 1,400 mi.; mostly navigable by small craft only
Freight carried (1969): rail -- 13 billion metric ton/km., 62 million metric
tons; highway -- 765 million metric ton/km., 116 million metric tons;
waterway -~ 540 million metric ton/km., 7.7 million metric tons; coastal --
170 million metric ton/km., 0.4 million metric tons
Ports: 6 major, 26 minor ae
DEFENSE FORCES:
Military manpower: males 15-49, 3,457,000; 2,050,000 fit for military service;
174,000 reach military age (18) annually
186
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
PEOPLE''S REP.
NIS 41B KOREA, SOUTH re
LAND:
38,000 sq. mi.; 23% arable (22% cultivated), 10% urban
and other, 67% forested
Land boundaries: 150 mi.
WATER:
Limits of territorial waters: 3 n. mi. (fishing, 20-200
n. mi.; continental shelf including sovereignty over
superjacent waters)
Coastline: 1,500 mi.
pal roeas: 1,964 mi.; 1,887 mi. standard gages 77 mi. (2''6") narrow gage; 280 °
double track; government owned
sighuaya: 25,500 mi.; 1,845 mi. paved, 18, 500 mi. gravel, 3,200 mi. improved
earth, 1,955 mi. cnieprsved earth
Inland waterways: 1,000 mi.; use restricted to small native craft
Freight carried: rail (1968) 4.5 billion short ton/mi., 30.4 million short é
tons; highway 24 million short tons; air (1959) 796,260 Ibs. carried
Pipelines: 255 mi., refined products, under construction
Ports: 10 major, 18 minor
Civil air: 26 major transport aircraft
Airfields: 264 total, 118 usable; 53 with permanent-surface runways; 13 with
runways 8,000-11,999 ft., 13 with runways 4,000-7,999 ft.; 2 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,056,000; 5,100,000 fit for military service;
average number reaching military age (18) annually 340,000
188
a aN REIT OE PERG ESATA D1 RST BRE PNET EN EE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 32C KUWAIT
LAND:
6,200 sq. mi. (excluding neutral zone but including islands);
insignificant amount forested; nearly all desert,
waste, or urban
Land boundaries: 285 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 310 mi.','44add2f10789766d97e79d78dd9933571e286fe3009c7622667fa71b8882981f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a208f1a7b92f22a167fd79dac907af9ac9ccfbb3d6e4262d896b1eb7e2f154d7',1974,'DE','Germany','communications',43,'Railroads: none
Highways: 1,550 mi.; 465 mi. bituminous; 1,085 mi. earth, sand, light gravel
Pipelines: crude oi], 255 mi.; refined products, 25 mi.; natural gas, 75 mi.
Ports: 3 major, 4 minor
Civil air: 6 major transport aircraft
Airfields: 13 total, 3 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: excellent international radiocommunications; adequate
domestic telecommunication facilities; 68,100 telephones; 200,000 radio
and 125,000 TV sets; 3 AM and 3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 308,000; about 185,000 fit for military
service
190
LE Sy Ne | RE a EAE LY a Lee ET a ER
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 43B LAOS
LAND:
91,430 sq. mi.; 7% agricultural, 60% forests, 33% urban,
waste, and other; except in very limited areas, soil
is very poor; most of forested area is not exploitable
Land boundaries: 3,140 mi.
Highways: about 9,600 mi. (including Comnunist-held areas); 600 mi. bituminous
or bituminous treated, 3,600 mi. gravel, crushed stone, or improved earth;
5,400 mi. unimproved earth and often impassable during rainy season
mid-May to mid-September
Inland waterways: about 2,850 mi., Palme eetong and tributaries; 1,800
additional miles are sectionally navigable by craft drawing less than 1.5 ft.
Ports (river): 5 major, 4 minor ;
Airfields: 411 total, 138 usable; 7 with permanent-surface runways; 13 with
runways 4,000-7,999 ft., 1 with runway 8,000-11,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 769,000; 410,000 fit for military service;
average number currently reaching usual military age (18) annually, 34,000;
no conscription age specified
192
3 Be] EE TDS NET Ta
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ww
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 28B LEBANON
LAND: TURKEY
4,000 sq. mi.; 27% agricultural land, 64% desert, waste,
or urban, 9% forested
Land boundaries: 285 mi.
WATER:
Limits of territorial waters (claimed): no specific claims
(fishing, 6 n. mi.) 08 SAUDI
Coastline: 140 mi. s ARABIA
Railroads: 238 mi.; 184 mi. 4''8 1/2", 51 mi. 3''5 3/8"; all single track
Highways: 5,160 mi.; 3,850 mi. paved, 310 mi. gravel and crushed stone, 404 mi.
improved earth, 596 mi. unimproved earth
Pipelines: crude oi], 45 mi.
Ports: 3 major, 5 minor
Civil air: 24 major transport aircraft
Airfields: 11 total, 3 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft.; 1 seaplane station
Telecommunications: excellent international telecommunication facilities include
satellite ground station; good domestic telephone and telegraph service;
192,000 telephones; 1.3 million radio and. 320,000 TV receivers; 7 TV, 2 FM,
and 1 AM radiobroadcast stations; 1 submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 734,000; 435,000 fit for military service;
average of about 27,000 reach military age (18) annually ©
’
AQ
+
194
HRN ROS LA SMELT 6 OG ETS IR EON STR TE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 61 LESOTHO
LAND:
11,700 sq. mi.; 15% cultivable; largely mountainous
Land boundaries: 500 mi.
Railroads: 1 mi.; owned, operated, and included in the statistics of the Republic >
of South Africa
Highways: approx. 1,370 mi.; 120 mi. paved; 580 mi. crushed stone, gravel, or
stablized soil; 670 mi. improved or unimproved earth
Civil air: no major transport aircraft
Airfields: 37 total, 20 usable; 3 with runways 4,000-7,999 ft.
Telecommunications: system a modest one consisting of a few landlines, a smal}
radio-relay system, and minor radiocommunication stations; Maseru is the
center; 2,650 telephones; 10,100 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 203,000; fit for military service 105,000
196
1 ATS SAS LT TT HP TP TE OO NT MP NTN fH
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 51 LIBERIA
LAND:
43,000 sq. mi.; 20% agricultural, 30% jungle and swamps,
40% forested, 10% unclassified
Land boundaries: 830 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 360 mi.
Railroads: 312 mi.; 220 mi. standard gage, 90 mi. narrow gage (3''6"); all lines
single track; rail systems owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
Highways: 4,950 mi.; 340 mi. bituminous treated; remainder improved and
unimproved laterite, gravel, and/or earth
Inland waterways: 230 mi. navigable
Ports: 3 major, 4 minor
Civil air: 2 major transport aircraft
Airfields: 85 total, 75 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone and telegraph limited; main center is Monrovia;
6,000 telephones; 250,000 radio and 8,000 TV receivers; & AM, no FM,
5 TV stations; 2 submarine cables
DEFENSE FORCES: .
Military manpower: males 15-49, 401,000; 215,000 fit for military service;
no conscription
198
Teeeeneiteeena ee na
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7 re
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 49 LIBYA
D:
679,000 sq. mi.; 6% agricultural, 1% forested, 93%
desert, waste, or urban
Land boundaries: 2,700 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(except for Gulf of Sidra where sovereignty is claimed
and northern limit of jurisdiction fixed at 32° 30'' N.
and the unilaterally proclaimed 100 n. mi. zone around)
Coastline: 1,100 mi.
Railroads: none
Highways: 9,450 mi.; 4,300 mi. bituminous or bituminous treated, 5,150 mi.
improved and unimproved earth and gravel
Pipelines: crude oi] 1,520 mi.; natural gas 175 mi.; refined products 140 mi.;
liquid petroleum gas 135 mi.
Ports: 3 major, 6 minor
Civil air: 6 major transport aircraft; an additional 30 major transports are
operated by external carriers engaged in charter work for several of] companies
Airfields: 111 total, 81 usable; 13 with permanent-surface runways, 1 with runway
over 12,000 ft., 7 with runways 8,000-11 ,999 ft., 33 with runways 4,000-7,999
ft.; 2 seaplane stations
Telecommunications: system is just within top one-third of African systems; con-
sists of radio-relay and ees aa links, open-wire lines, and
radiocommunication stations; principal centers are Tripoli and Banghazi;
49,800 telephones; 225,000 radio and 2,500 TV receivers; 7 AM, 1 FM, and
2 TV stations; 3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 489,000; 285,000 fit for military service;
about 20,000 reach military age (17) annually; conscription now being
imp] emented
200
LT TS Te a oS TE OT Om STEEN STRIPS SSG‘ PUNE SRONED SPOUSES CURINVELSeSEDO”
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NORWAY» TS
\\SWEDEN
NIS 15 LIECHTENSTEIN
GENMARK f.
LAND:
65 sq. mi.
Land boundaries: 47 mi.
Railroads: 9.94 mi. 4''8 1/2" gage, electrified; owned, operated, and included in
statistics of Austrian Federal Railways
Highways: no information on total mileage
Civil air: no major transport aircraft
Airfields: none
201
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Telecommunications: automatic telephone system serving about 11,600 telephones;
no broadcast facilities; 4,000 radio and 3,500 TV receivers (programs from
Switzerland)
DEFENSE FORCES:
Defense is responsibility of Switzerland
202
G0 GE RNTERD FO. LTTE TRS el TT PT TON ORT A LTT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ee SNORWAY: 74
NIS 6 LUXEMBOURG Somenen
SO ENMARK SS soothes
LAND vere ins, |S Conse pour
2 2 (7 REP.
oe
Pes “GERMANY )
LG. OF \\
1,000 sq. mi.; 25% arable, 27% meadows and pasture, 15%
waste or urban, 33% forested, negligible amount of
inland water (1971)
Land boundaries: 221 mi.
é GERMANY \\ CZECH.
LUXEMBOUR''
| FRANCE
Railroads: 203 mi. standard gage; 100 mi. double track; 85 mi. electrified
Highways: 3,070 mi.; all paved
Pipelines: refined products, 30 mi.
Inland waterways: 23 mi.; Moselie River
Port: Mertert
Civil air: 10 major transport aircraft (includes 3 registered in Iceland)
Airfields: 2 total, 1 usable with permanent-surface runway 8,000-11,999 ft.
Telecommunications: adequate and efficient system; 127,400 telephones; 176,000
radiobroadcast receivers; 86,000 TV receivers; 2 AM, 3 FM, 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 78,000; 62,000 fit for military service; about
3,000 reach military age (19) annually »
4
a
204
SS ESI HENS SEA LH SRS ER OA OSES 7 EA RL ENE RET LEESON FT EER SAIL
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 39C MACAO
LAND:
6 sq. mi.; 10% agricultural, 90% urban
Land boundaries: 220 yds.
WATER:
Limits of territorial waters (claimed): 6 n. mi;
fishing, 12 n. mi.
Coastline: 25 mi.
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
Telecommunications: fairly modern facilities provide adequate services for
domestic and international requirements; excellent coverage is provided
by AM and FM radiobroadcasts; 5,576 telephones; 65,000 radio receivers;
2 AM, 2 FM, and no TV stations; no submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 69,000; 43,000 fit for military service
Defense is responsibility of Portugal
A A ORAL | hailed hia ta temsennsinraraiaraisiahsanpaaiadialasin-ad
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 62 MADAGASCAR
D: SALGERIA) LIBYA ECYET savor “g
230,000 sq. mi.; 5% cultivated, 58% pastureland, 21% a
forested, 8% wasteland, 2% rivers and lakes, 6% other
(1971)
“ARABIA
WATER:
Limits of territorial waters (claimed): 50 n. mi.
Coastline: 3,000 mi.
Railroads: 549 mi. of meter gage
Highways: 5,300 mi.; 1,875 mi. paved, 2,225 mi. crushed stone, gravel, or stabi-
lized soil; 1,200 mi. improved and unimproved earth; remainder are tracks
Inland waterways: 1,200 mi. navigable; Lac Alaotra (200 sq. mi.)
Ports: 4 major, 13 minor
Civil air: 10 major transport aircraft
Airfields: 366 total, 143 usable; 26 with permanent-surface runways; 3 with run-
ways 8,000-11,999 ft., 48 with runways 4,000-7,999 ft.; 6 seaplane stations
Telecommunications: system above African average; includes open wire lines, some
radio-relay and coaxial links and a communication satellite ground station;
28,200 telephones; 501,000 radio and 5,000 TV receivers; | AM, no FM, and
1 TV station
a
DEFENSE FORCES:
Military manpower: males 15-49, 1,650,000; 975,000 fit for military service;
average number reaching military age (20) annually about 79,000
»
208
A LLL LETTS EP A EMS EN FSGS HT TST HG Gh ST PPP Denial aaa a tath ta snapetetnigmteelptennzcenmmisadapr iil asapeia same aliie sinatra a
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ah
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 57C MALAWI
LAND:
36,700 sq. mi.; about 31% of land area arable (of which
Jess than half is cultivated), nearly 25% forested,
6% meadow and pasture, 38% other
Land boundaries: 1,790 mi.
Railroads: 352 mi. (3''6" gage)
Highways: 6,710 mi.; 540 mi. paved; 4,040 mi. crushed stone, gravel, or stabilized
soil; 2,130 mi. unimproved earth
Inland waterways: Lake Nyasa (Lake Malawi), 800 route mi. and Shire River, 90 mi.
Civil air: 5 major transport aircraft
Airfields: 45 total, 42 usable; 1 with permanent-surface runway, 7 with
runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: the system is barely above average for African countries
and consists of thinly spread open-wire lines, radio-relay links, and
radioconmunication stations; principal centers are Blantyre and Zomba;
13,800 telephones; 110,000 radio receivers; 5 AM, 4 FM and no TV stations
°e
DEFENSE FORCES:
Military manpower: males 15-49, 1,009,000: about 510,000 fit for military service
bald
210
eee lactate tienen nial taiaaeteinttemeaiemmninimniniee aera tient, LE —~_e
Approved For Release as : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 44 MALAYSIA
NOTE:
Malaysia, which came into being on 16 September 1963,
consists of West Malaysia, which includes 11 states ''
of the former Federation of Malaya, plus East See
Malaysia, which includes the 2 former colonies of aoe ren
North Borneo (renamed Sabah) and Sarawak Se on
LAND:
West Malaysia: 50,700 sq. mi.; 20% cultivated, 26%
forest reserves, 54% other
Sabah: 29,400 sq. mi.; 13% cultivated, 34% forest
reserves, 53% other
Sarawak: 48,300 sq. mi.; 21% cultivated, 24% forest
reserves, 55% other
Land boundaries: West Malaysia 315 mi., East Malaysia 1,110 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: West Malaysia, 1,285 mi., East Malaysia 1,620 mi.
Railroads:
West Malaysia: 1,014 mi. 3''3 3/8" gage; 8 mi. double track; government-owned
East Malaysia: 96 mi. meter gage in Sabah
Highways:
West Malaysia: 10,500 mi.; 8,925 mi. hard surfaced (mostly bituminous Surface
treatment), 1,150 mi. crushed Stone/gravel, 425 mi. improved or unimproved
earths
East Malaysia: about 3,140 mi. (1,608 ‘in Sarawak, 1,532 in Sabah); 520 mi.
hard surfaced (mostly bituminous surface treatment), 1,853 mi. gravel or
crushed stone, 767 mi. earth
Inland waterways:
West Malaysia: 1,985 mi.
East Malaysia: 2,540 mi. (975 mi. in Sabah, 1,565 mi. in Sarawak)
Ports:
West Malaysia: 3 major, 10 minor
East Malaysia: 4 major, 7 minor (3 major, 3 minor in Sabah; 1 major, 4 minor a
in Sarawak)
Civil air: 17 major transport aircraft (including 1 Boeing 707 leased from U.K.)
Pipelines: crude oi1, 90 mi.; refined products, 35 mi.
Airfields:
West Malaysia: 106 total, 70 usable; 16 with permanent-surface runways;
2 with runways 8,000-11 ,999 ft., 12 with runways 4,000-7,999 ft.; 3
seaplane stations
Sabah: 41 total, 33 usable: 5 with permanent-surface runways; 5 with runways
4 ,000-7,999 ft.; 3 seaplane stations
Sarawak: 52 total, 47 usable; 5 with permanent-surface runways; 4 with
runways 4,000-7,999 ft.
Telecommunications:
West Malaysia: good intercity service provided mainly by microwave relay;
international service good; good coverage by radio and television broad-
casts; 163,897 telephones; 417,000 radio and 240,000 Ty receivers; 9 towns
have AM stations; no FM, 14 TY Stations; submarine cables extend to India,
Ceylon, and Singapore; connected to SEACOM submarine cable terminal at
Singapore by microwave relay
Sabah: adequate intercity radio-relay network extends to Sarawak via Brunei;
10,246 telephones; 60,000 radio receivers; 2,000 TV receivers; 6 AM, 1 FM,
5 TV stations; SEACOM submarine cable links to Hong Kong and Singapore
Sarawak: adequate intercity radio-relay network extends to Sabah via Brunei;
15,040 telephones; 75,000 radio and no TV receivers; 2 AM, no FM, no TV »
stations
|e Fee SSG Se SNSEENREEEP-Or UE OP eNeIEGEINONSE —— :
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004 ’
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
DEFENSE FORCES:
Military manpower: West Malaysia: males 15-49, 2,242,000; 1,420,000 fit for
military service; Sabah: males 15-49, 172,000; 108,000 fit for military
service; Sarawak: males 15-49, 248,000; 157,000 fit for military service;
conscription age for Malaysia is 21 -- an age reached by about 116,000
annually
External defense dependent on loose Five Power Defense Agreement (FPDA) which
replaced Anglo-Malayan Defense Agreement of 1957 as amended in 1963; FPDA,
effective as of 1 November 1971, also provides for smal] ANZUK Joint Force
composed of Australia, New Zealand, and U.K. ground, naval, and air elements,
headquarters in Singapore
215
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 63 MALDIVES
LAND:
115 sq. mi.; 2,000 islands grouped into 12 atolls, about
220 islands inhabited
WATER:
Limits of territorial waters (claimed): the land and
sea between latitudes 7°9''N. and 0°45''S. and between
longitudes 72°30''E. and 73°48''E; these coordinates
form a rectangle of approximately 37,000 sq. n. mi.
Coastline: 400 mi. (approx. )
Railroads: none
Highways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 3 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: minimal domestic and international teleconmunication
facilities; 300 telephones; 2,000 radio sets; 1 AM station
217
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50H MALI
TURKEY (124
Fe es)
aT. &
ALGERIA LIBYA EGYPT s aupt 4
"465,000 sq. mi.; only about a fourth of area arable,
forests negligible, rest sparse pasture or desert
Land boundaries: 4,635 mi.','0db319ba2cbed67e39d47a3217b90f0f159d2a3eaf0c3388ba4cde234e7f0d4f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42d3c3f04f34343f0ad70d695d6e8cc66df2b0d48c514e596286190905ea73c4',1974,'CN','China','communications',47,'Railroads: 400 mi. meter gage
Highways: approximately 8,200 mi.; 1,010 mi. bituminous, 1,050 mi. improved
earth, 6,140 mi. unimproved earth
Inland waterways: 1,141 mi. navigable
Civil air: 5 major transport aircraft
Airfields: 55 total, 38 usable; 6 with permanent-surface runways; 2 with runway
8,000-11,999 ft., 11 with runways 4,000-7,999 ft.
Telecommunications: system poor and provides only minimum service to government,
business, and public; open-wire and radiocomintcatien used for long distance
telecommunications; radio sometimes only ljink to outlying points; 7,800
telephones; 75,000 radio receivers; 2 AM, no FM, and no TY stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,278,000; 720,000 fit for military service;
no conscription
220
HE TEATS NAAR TT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 25B MALTA . ys. YUGOSLAVIA
LAND:
121 sq. mi.; 45% agricultural, negligible amount forested,
remainder urban, waste, or other
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 87 mi.
Highways: 760 mi., 650 mi. paved (asphalt), 30 mi. crushed stone or gravel,
30 mi. improved and unimproved earth
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 4 total, all usable; 4 with permanent-surface runways; 3 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: modern automatic telephone system centered in Valletta;
46,000 telephones; 80,000 radio receivers (including 60,000 wired sets);
66,000 television receivers; 3 AM, 3 FM, and 1 TV stations; 8 submarine cables,
including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 87,000; 65,000 fit for military service
222
NLS SRT SAT LI HE CRO GI PETE ROTEL LPL SST RTE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 83 MARTINIQUE
LAND:
425 sq. mi.; 31% cropland, 16% pasture, 29% forest, 24%
wasteland, built on
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 180 mi.
PEOPLE: i q BRAziC
Population: 355,000, average annual growth rate 1.6% remy
(7/66-7/71)
Ethnic divisions: 90% African and African-Caucasian-Indian
mixture, less than 5% East Indian Lebanese, Chinese,
5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public services, 11% construction
and public works, 10% commerce and banking, 10% services, 9% industry, 17%
other
Organized labor: 17% of labor force','df1f9be58268cf7e1d3f309361eae509db78ba4e845668c00d7eee1c9b6dac52','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8a71eb53cd114e8b7d9295bb99dc964d6f403b4f81abc125be38e474a30ccb4',1974,'ZM','Zambia','communications',51,'Railroads: 1,965 mi.; 1,877 mi. 3''6" gage (6 mi. double track), 88 mi. 2''5 V/e"
gage
Highways: 20,000 mi.; 1,740 mi. paved; 18,260 other (mostly earth)
Inland waterways: approx. 2,330 mi. of navigable routes
Pipelines: crude oi1, 190 mi.
Ports: 3 major, 2 significant minor
Civil air: 12 major transport aircraft
Airfields: 353 total, 308 usable; 25 with permanent-surface runways; 4 with run-
ways 8,000-11,999 ft., 32 with runways 4,000-7,999 ft.; 5 seaplane stations
Telecommunications: above African average system of open-wire lines,
radiocommunication stations, and radio-relay and tropospheric-scatter links;
principal center Lourenco Marques, secondary centers Beira, Nampula, and
Quelimane; 30,300 telephones; 110,000 radio receivers; 9 AM, 2 FM, and no
TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,147,000; 1,035,000 fit for military service a
Defense is responsibility of Portugal
238
OT TL eT a NT, a a IT ae a Ite ee ena ea D a ae onan | ov aE:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 102 NAURU
LAND:
8.2 sq. mi.; insignificant arable land, no urban areas,
extensive phosphate mines
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 15 mi.','d4c5dc663d7b4a03c30b8d1c22578b0bad45edd1ee8d1af8679a71679be85d15','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a97343169384819df6aaf0e415094a10bbce5773240cc0e5843e9ecf93ec5114',1974,'AU','Australia','communications',56,'Railroads: none
Highways: about 17 mi.; 13 mi. paved, 4 mi. improved earth
Inland waterways: none
Ports: 1 minor
Civil air: 1 major transport aircraft
Airfields: 1, coral-surfaced, 5,270 ft.
Telecommunications: adequate interisland and international radiocommunications
provided via Australian facilities; 525 telephones; 1 AM, but no TV or FM
radiobroadcasting facilities; number of radios unknown
DEFENSE FORCES:
Military manpower: males 15-49, about 1,800; fit for military service, about
950; average number reaching military age (18) annually, 1971-75, less than 100
No formal defense structure and no regular armed forces
239
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 35A NEPAL
“PEOPLE''S REPUBLIC
OF CHINA
54,600 sq. mi.; 16% agricultural area, 14% permanent meadows riben/)
and pastures, 38% alpine land (unarable), waste, or =
urban; 32% forested
Land boundaries: 1,720 mi.
Railroads: 105 mi., all narrow gage (2''6"); mostly government owned; all in Terai Sy
close to Indian border; only 33 mi. sector from border to Bizalpura presently
in use; a 28 mi. segment has been abandoned and 44 mi. utilized to transport
rock from quarry near Dharau to Kosi Dam near Rajbiras
Highways: 1,686 mi.; 510 mi. paved, 270 mi. gravel or crushed stone, 906 mi.
improved and unimproved earth, 200 mi. of seasonally motorable tracks
Civil air: 7 major transport aircraft
Airfields: 47 total, 40 usable; 4 with permanent-surface runways; 6 with runways
4,000-7,999 ft.
Telecommunications: poor telephone and telegraph service; good radiocommunication
and broadcast service; international radiocommunication service is poor;
7,071 telephones, 100,000 radio and no TY sets, 2 AM, no FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 3,108,000; 1,510,000 fit for military service;
140,000 reach military age (17) annually
=
*
a
242
LT aE Ta ET a yon i AD ED Sen STH} PUP ORSSECSENERSTEENES OTT RTA DOR EER
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 4 NETHERLANDS
Sy :
Mjreo.“ FE ear.
; "14,100 sq. mi.; 70% cultivated, 5% waste, 8% forested, nor XG
8% inland water, 9% other (1971)
Land boundaries: 635 mi.
WATER:
< Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 280 mi.
Railroads: 1,956 mi., standard gage; 970 mi. double track; 1,022 mi. electrified
Highways: 46,000 mi.; 26,000 mi. paved, 4,000 mi. crushed stone and gravel,
16,000 mi, earth
Inland waterways: 3,940 mi.; less than 962 mi. is natural river; more than 1,400
mi. navigable by craft of 1,000-ton capacity; 1,011 mi. will take 1,500-ton
vessels
Pipelines: crude oi], 260 mi.; refined products, 600 mi.; natural gas, 2,600 mi.
Ports: 8 major, 5 minor
Civil air: 105 major transport aircraft (including 3 foreign owned but registered
in the Netherlands)
Airfields: 28 total, 26 usable; 16 with permanent-surface runways; 12 with
runways 8,000-11,999 ft., 3 with runways 4,000-7,999 ft.
Telecommunications: highly developed, excellently maintained, and well integrated;
extensive system of multiconductor cables, supplemented by radio relay-links;
3.9 million telephones; 4.81 million radiobroadcast and 3.9 million TV
receivers; 5 AM, 12 FM, and 10 TV Stations; 11 coaxial submarine cables;
communications satellite ground station under construction
DEFENSE FORCES:
Military manpower: males 15-49, 3,381,000; 3,035,000 fit for military service;
average number reaching military age (20) annually 116,000 *
244
PRCT ROI HALO
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 82 NETHERLANDS ANTILLES
LAND:
394 sq. mi.; 5% arable, 95% waste, urban, or other
WATER:
Limits of territorial waters (claimed): 3.n. mi.
Coastline: 226 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: about 3,200 mi.
Papua:
Railroads: none
Highways: approx. 2,480 mi.; about 1,360 mi. suitable for heavy and medium
traffic, and about 1,120 mi. suitable for light traffic
Inland waterways: 800 mi., not including minor rivers
Ports: 1 principal (Port Moresby), 1 secondary
Civil air: see New Guinea (below)
Airfields: see New Guinea (below)
Telecommunications: see New Guinea (below)
New Guinea:
Railroads: none
Highways: approx. 6,430 mi.; approx. 3,865 mi. suitable for heavy and medium
traffic, and 2,565 mi. suitable for light traffic only
Inland waterways: 1,350 mi., northeast New Guinea; minor rivers not included
Pipelines: crude of1, 87 mi.
Ports: 4 principal (Rabaul, Lae, Madang, Kavieng), 4 minor
Civil air: 12 major transport aircraft (registered in Australia)
Airfields: 651 total, 451 usable; 12 with permanent-surface runways; 46 with
runways 4,000-7,999 ft.; 1 with runway 8,000 ft. -- Nadzab
Telecommunications: Papua New Guinea telecom services are adequate and are
being improved; principal telecom centers include Goroka, Lae, Madang,
Mount Hagen, and Wewak in New Guinea; and Daru, Port Moresby and Samarai
in Papua; facilities provide radiobroadcast, radiotelephone and telegraph,
coastal radio, aeronautical radio and international radiocommuni cation
services; numerous privately owned radio facilities exist; submarine
cables extend from Madang to Australia and Guam; 25,300 telephones, 100,000
radios, but no TV sets; 11 AM, no FM and no TV facilities
DEFENSE FORCES:
Military manpower: males 15-49, 637,000 (Papua 168,000, New Guinea 469,000) ;
about 325,000 fit for military service (Papua 85,000, New Guinea 240,000)
Defense is responsibility of Australia
268
TT Te PPS HHH eam i TD A HT CAT MSO OE SN TE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 92 PARAGUAY
LAND: BRAZIL
157,000 sq. mi.; 2% under crops, 24% meadow and pasture,
52% forested, 22% urban, waste, and other
Land boundaries: 2,140 mi.
Railroads: 652 mi.; 273 mi. standard gage, 85 mi. 3''3 3/8'''' gage, 294 mi. various
narrow gage (privately owned)
Highways: 9,900 mi.; 400 mi. bituminous treated, 3,100 mi. otherwise improved,
6,400 mi unimproved earth
Inland waterways: 1,970 mi.
Ports: 1 major, 7 minor (all river)
Civil air: 7 major transport aircraft
Airfields: 1,031 total, 855 usable; 1 with permanent-surface runway; 2 with runways
8,000-11,999 ft., 29 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: local telecom facilities in Asuncion good, intercity microwave
net under construction; 26,600 telephones; est. 720,000 radio and 57,000 TV
receivers; 23 AM, 5 FM, and 1 TY stations
DEFENSE FORCES:
Military manpower: males 15-49, 624,000; 430,000 fit for military service;
average number currently reaching military age (17) annually, 25,000
Military budget: for fiscal year ending 31 December 1973, $18.5 million; about
15% of proposed central government budget
270
58 NCGS ESL OPT SEER TN AT TTT SEN OI PHT | DOTS DETTE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 88 PERU
LAND: 1 q BRAZIL
496,000 sq. mi. (other estimates range as Tow as 482,000 eae.
sq. mi.); 2% cropland, 14% meadows and pastures, 55%
forested, 29% urban, waste, other
Land boundaries: 3,810 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,500 mi.
Railroads: approx. 1,560 mi.; 1,227 mi. 4'' 8 1/2" gage; 4] mi. gage less than
3''O": 282 mi. 3'' 0" gage; 9 mi. double track
Highways: 31,300 mi.; 3,050 mi. paved, 6,250 mi. gravel or crushed stone, 8,900
mi. improved earth, 13,100 mi. unimproved earth
Inland waterways: 5,400 mi. of navigable tributaries of Amazon River system and
130 mi. Lake Titicaca
Pipelines: crude oi], 200 mi.; natural gas and natural gas liquids, 40 mi.
Ports: 7 major, 20 minor
Civil air: 34 major transport aircraft
Airfields: 338 total, 293 usable; 19 with permanent-surface runways; 2 with
runway over 12,000 ft., 19 with runways 8,000-11,999 ft., 48 with runways
4,000-7 ,999 ft.; 3 seaplane stations |
Telecommunications: fairly adequate for most requirements; new radio-relay system
under construction; communications satellite ground station; 280,000 telephones;
2 million radio and 480,000 TV receivers; 215 AM, 7 FM, and 30 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 3,256,000; 2,205,000 fit for military service;
average number currently reaching military age (20) annually, 144,000
272
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
PEOPLE''S REP
NIS 99 PHILIPPINES OFcHINA
LAND:
116,000 sq. mi.; 53% forested, 30% arable land, 5%
permanent pasture, 12% other
WATER:
Limits of territorial waters (claimed): 0-300 n. mi.
(under an archipelago theory, waters within straight
lines joining appropriate points of outermost islands
are considered internal waters; waters between these
baselines and the limits described in the Treaty of
Paris, December 10, 1898, the U.S.-Spain Treaty of
November 7, 1900, and the U.S.-U.K. Treaty of January 2,
1930 are considered to be the territorial sea)
Coastline: about 14,000 mi.
Railroads: 2,177 mi.; 2 common-carrier systems (3''6" gage) totaling about 727
mi.; 19 industrial systems with 4 different gages totaling 1,450 mi.; 34%
government owned
Highways: 45,690 mi.; 8,886 mi. paved; 23,770 mi. gravel, crushed stone, or
stabilized soil surface; 13,034 mi. improved earth
Inland waterways: 2,000 mi.; limited to shallow-draft (less than 5 ft.) vessels
Pipelines: refined products, 157 mi.
Ports: 11 major, 100 minor
Civil air: 75 major transport aircraft
Airfields: 422 total, 315 usable; 44 with permanent-surface runways; 7 with
runways 8,000-11,999 ft., 24 with runways 4,000-7,999 ft.; 8 seaplane stations
DEFENSE FORCES: 7
Military manpower: males 15-49, 9,209,000; 6,020,000 fit for military service;
about 392,000 reach military age (20) annually
Military budget: for fiscal year ending 30 June 1973, $164.2 million; about 21.6%
of total budget r
*
274
A EES ELT EL LTT IEE ELE OEM PERCH N MONTE TW RRR GF SA
ANS LN RET
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 14 POLAND
MORWAY.
D:
120,600 sq. mi.; 49% arable, 14% other agricultural, 27%
forested, 10% other
Land boundaries: 1,920 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi. Re Z
(fishing, 12 n. mi.)
Coastline: 305 mi. “
Railroads: 16,470 route mi.; 14,380 mi. standard gage, 2,090 mi. narrow gage;
4,645 mi. double track; 2,400 mi. electrified; government owned (1972)
Highways: 190,095 mi.; 40,390 mi. paved; 39,480 mi. crushed stone, gravel;
110,225 mi. earth (improved and unimproved) (1972)
Inland waterways: 3,158 mi. navigable streams and canals (1973)
Pipelines: 2,100 mi. for natural gas; 875 mi. for crude oi1; 200 mi. for refined
products ;
Freight carried: rail -- 458.5 million short ton, 75.2 billion short ton/mi.
(1972); highway 1,264.0 million short t ns, 14.5 billion short ton/mi. (1972);
waterway -- 11.9 million short tons, 1.7 billion short ton/mi. excl. int.
transit traffic (1972)
Ports: 4 major (Gdansk, Gdynia, Szczecin, Swinoujscie), 6 minor (1973)
Civil air: 48 major transport aircraft (1973)
Airfields: 146 total; 75 with permanent-surface runways; 36 with runways 8,000-
11,999 ft., 71 with runways 4,000-7,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 8,893,000; 7,030,000 fit for military service;
356,000 reach military age (19) annually
Military budget: for fiscal year ending 31 December 1973, 39.2 billion Zlotys;
about 8.4% of total and 3.8% of est. GNP
276
eee -
Ls ciidaiaiAdeceaicngiecas
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-
OES IR RARE
f
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
2 ARELANB |
NIS 8 PORTUGAL
LAND:
Metropolitan Portugal: 36,400 sq. mi., including the Azores
and Madeira Islands; 48% arable, 6% meadow and pasture,
31% forested, 15% waste and urban, inland water, and
other
Cape Verde Islands: 1,560 sq. mi., divided among 10 islands
and several islets (not a part of Metropolitan Portugal )
Land boundaries: 750 mi.
MOROCCO ALGERIA
WATER: bf |
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.
Coastline: 535 mi. (excludes Azores, Maderia, and Cape
Verde Islands, 1,180 mi.)
Railroads: 2,230 mi.; 472 mi. meter gage (3''3 3/8"), 1,753 mi. broad gage
(5''5 9/16"); 265 mi. double track; 274 mi. electrified
Highways: 18,500 mi.; 11,000 mi. bituminous, bituminous treatment, concrete and
stoneblock; 7,200 mi. gravel and crushed stone; 300 mi. improved earth; plus :
an additional 10,500 mi. of unimproved earth roads (motorable tracks)
Inland waterways: 508 mi. navigable; relatively unimportant to national economy,
used by shallow-draft craft limited to 330-ton cargo capacity
278
eal ae ''
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Pipelines: crude oi] 7 mi.
Ports: 7 major, 33 minor
Civil air: 27 major transport aircraft
Airfields (including Azores, Cape Verde Islands, and Madeira Islands): 53 total,
43 usable; 26 with permanent-surface runways; 1 with runways over 12,000 ft.,
9 with runways 8,000-11,999 ft., 10 with runways 4,000-7,999 ft.; 6 seaplane
stations
Telecommunications: facilities are generally adequate; 884,000 telephones; 1.65
million radio receivers; 550,000 television receivers; 37 AM, 34 FM, and 36
TV stations; 2 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 2,080,000; 1,610,000 fit for military service;
average number reaching age (20) annually, about 71,000
279
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50R PORTUGUESE GUINEA
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 400 mi.
Railroads: none
Highways: 463 mi.; 293 mi. gravel or crushed stone, 170 mi. improved and
unimproved earth
Inland waterways: none
Ports: 1 minor *
Civil air: no major transport aircraft
Airfields: 14 total, 11 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: domestic and international radio stations used primarily
for administrative and military purposes; 1 low-power radiobroadcast station;
unreliable open-wire lines and 58 small manual switchboards serve about 689
telephones; 13,145 radio sets
284
_ EE ENTE I SEIT DDS TPE FER A od
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 84 PUERTO RICO
LAND:
3,440 sq. mi.; 33% arable, 35% meadow and pasture, 13%
forested, 19% waste, urban, or other
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 300 mi.
Railroads: none
Highways: 365 mi.; 132 mi. metalled all-weather, 233 mi. earth
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 3 total; 1 usable, with grass runway 7,000 ft.; 1 seaplane station
Telecomnunications: 1,073 telephones; 9,000 radio sets; no TV sets; 1] AM station
349
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 81D TRINIDAD AND TOBAGO Rune ke
eee pease
PUERT:
LAND:
1,980 sq. mi ; 41.9% in farms (of which 25.7% cropped or
fallow, 1.5% pasture, 10.6% forests, 4.1% unused or
built-on), 58.1% outside of farms, including
grassland, forest, built-up area, and wasteland
WATER: COLOMBIA
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 225 mi. BRAZIL
Railroads: none
Highways: 4,200 mi.; 2,500 mi. paved, 1,700'' mi. gravel or otherwise improved
Pipelines: crude oi1, 270 mi.; refined products, 12 mi.; natural gas, 130 mi.
Ports: 3 major, 6 minor
Civil air: 10 major transport aircraft
Airfields: 12 total, 6 usable; 3 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international service via trapospheric scatter
Tinks to Barbados and Guyana; good local service; satellite ground station;
69,500 telephones; 260,000 radio and 75,000 TV receivers; 2 AM, 2 FM, and x
3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 247,000; 175,000 fit for military service
Supply: mostly from U.K. *
352
ST eT ENED I OE PE NN eT Te eC NI mee GO | TES
SAF PAREN
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 46 TUNISIA rp Si
nee § Pee
‘ “i a iayA FOvEtsauoy
63,400 sq. mi.; 28% arable land and tree crops, 23% range ation
and esparto grass, 6% forest, 43% desert, waste or L
urban
Land boundaries: 875 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi. exclusive fisheries zone follows the
50-meter isobath for part of the coast, maximum 65 n. mi.)
Coastline: 710 mi. (includes offshore islands)
Railroads: 1,273 mi.; 309 mi. standard gage (4''8 1/2"), double 964 mi. meter
gage (3''3 3/8")
Highways: 10,250 mi.; 4,750 mi. mostly bituminous treatment, 500 mi. gravel,
2,050 mi. improved earth, 2,950 mi. unimproved earth
Pipelines: crude o71, 495 mi.; refined products, 6 mi.; natural gas, 45 mi.
Ports: 4 major, 8 minor
Civil air: 7 major transport aircraft
Airfields: 61 total, 36 usable; 11 with permanent-surface runways; 2 with runways
cable or radio relay on trunk routes; key centers are Safaqis, Susah, Bizerte,
and Tunis; 88,000 telephones; 400,000 radio and 80,000 TV receivers; 3 AM,
3 FM, and 7 TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 1,200,000; 640,000 Fit for military service;
about 60,000 reach military age (20) annually
354
ern ntmerrr mirror 1417 see
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 27 TURKEY
D:
296,000 sq. mi.; 35% cultivated, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi. SUDAN
(fishing, 12 n. mi.) Ps
Coastline: 4,475 mi. STHIOPIA
Railroads: 5,075 mi.; 5,055 mi. 4''8 1/2" gage, 89 mi. double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Civil afr: 25 major transport aircraft
Airfields: 125 total, 102 usable; 49 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 23 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international and fair domestic teleconmunication
services; 700,000 telephones; 4 million radio and 160,000 TV receivers; 40
AM, 2 FM, and 10 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,874,000; 5,820,000 fit for military service;
about 407,000 reach military age (20) annually
356
eet eatereenneialintetina tetera dient ees
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 56B UGANDA
ut ict RP OE, y .
ALGERIA EGYPT %
< LIBYA ee,
91,000 sq. mi.; 21% inland water and swamp, including
territorial waters of Lake Victoria, about 21%
cultivated, 13% national parks, forest, and game
reserves, 45% forest, woodland, and grassland
Land boundaries: 1,665 mi.
Railroads: 760 mi.; all meter gage, Single track
Highways: 31,330 mi. total; 1,200 mi. bituminous surface treatment; 10,130 mi.
crushed stone, gravel, laterite, and improved earth; 20,000 mi. unimproved
earth roads and tracks
Inland waterways: Lake Victoria, Lake Albert, Lake Kyoga, Lake George, and
Lake Edward (6,010 mi.); Kagera River and Victoria Nile (380 nits
Civil air: 7 major transport aircraft
Airfields: 50 total, 42 usable; 3 with permanent-surface runways; 1 with runway
over 12,000 ft., 2 with runways 8,000-11,999 ft., 117 with runways 4,000-7 ,999
ft.; 3 seaplane stations
Telecommunications: telephone and telegraph services fair to good, intercity
connections based on 3 or 12 channel carrier systems; 34,200 telephones;
275,000 radio and 15,000 Ty receivers; 2 AM, no FM, and 6 TY stations
DEFENSE FORCES:
Military manpower: males 15-49, about 2,677,000; about 1,430,000 fit for military
service
358
eee eee nee = enenetsee perenrns senate
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ORG 8 A Fp ee:
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 26 U.S.S.R.
LAND:
8,600,000 sq. mi.; 9.3% cultivated, 37.1% forest and
brush, 2.6% urban, industrial, and transportation,
16.8% pasture and natural hay land, 34.2% desert,
swamp, or waste
Land boundaries: 12,595 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 29,000 mi. (incl. Sakhalin)
Railroads: 84,500 mi.; 82,270 mi. broad gage, 2,240 mi. narrow gage; 58,610 mi.
broad gage single track; 21,065 mi. electrified; does not include industrial
lines (1872)
Highways: 845,620 mi.; 128,340 mi. paved, 188,855 mi. gravel, crushed stone,
528,425 mi. improved or unimproved earth (1972)
Inland waterways: 90,000 mi. navigable, exclusive of Caspian Sea (1973)
Pipelines: crude oi], 25,000 mi.; refined products, 6,000 mi.; natural gas,
49,000 mi.
Ports: 62 major (most important: Leningrad, Murmansk, Odessa, Novorossiysk,
Vladivostok, Nakhodka); 122 selected minor (1973)
Freight carried: rail -- 3,477.7 million short tons, 1,891.8 billion short <
ton/mi. (1972); highways -- 18.8 billion short tons, 178 billion short
ton/mi. (1972); waterway -- 435.4 million short tons, 123.3 billion short
ton/mi. (1972)
Airfields: over 3,250 total; 558 with permanent-surface runways; 32 with runway
over 12,000 ft., 434 with runways 8,000-11,999 ft., 793 with runways 4,000- %
7,999 ft.
DEFENSE FORCES:
Nuclear weapons: satisfies major requirements of Soviet forces
Supply: fully supplies own needs
360
SL YE SE ED AE ST SE DE TE ED EE TS EH MCE ET ET.
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 32C UNITED ARAB EMIRATES
LAND:
32,000 sq. mi.; almost all desert, waste or urban
Land boundaries: 680 mi. (does not include boundaries
between adjacent U.A.E. states)
WATER:
Limits of territorial waters (claimed): 3 .n. mi. for all
states except Sharjah-12 n. mi.
Coastline: 900 mi.
Railroads: none
Highways: 175 mi. bituminous, undetermined mileage of earth tracks
Pipelines: crude oi], 175 mi.
Ports: 3 major, 3 minor
Civil air: no major transport aircraft
Airfields: 93 total, 37 usable; 3 with permanent-surface runways; 1 with runway
over 12,000 ft., 1 with runway 8,000-11,999 ft., 13 with runways 4,000-7,999 ft.
Telecommunications: telephone system in Dubayy and Ash Sharigah, also links
these towns; Abu Dhabi Petroleum operates a telecom System throughout
the sheikhdom; key centers are at At Tarif, Habshan, ancl Az Zannah; 14,300
telephones; 35,000 radio and 15,000 TV receivers; 3 AM, 1 FM, and 2 TY
stations
DEFENSE FORCES:
Military manpower: males 15-49, about 43,000; about 22,000 fit for military service
Supply: mostly from U.K.
362
eran ean ene ee Ee
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-
STAT Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Next 1 Page(s) In Document Exempt
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50d UPPER VOLTA
D:
106,000 sq. mi.; 50% pastureland, 21% fallow, 10%
cultivated, 9% forest and scrub, 10% waste and other
uses
Land boundaries: 2,055 mi.
Railroads: 72','67b6087399459766e1d5d2a800c9edba5201d0af9190acf4f0dc05ab88a43369','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f1882b376b31349a6b6bba61dc9360a5a5506c973cc6a7bce02533115d00df8',1974,'AU','Australia','communications',57,'8 mi., 320 mi. meter gage, single track; Ouagadougou to Abidjan,
Ivory Coast line
Highways: 10,380 mi.; 325 mi. paved, 3,425 mi. improved, 6,630 mi. unimproved
Civil air: no major transport aircraft
Airfields: 59 total, 51 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 2 with runway 4,000-7,999 ft.
Telecommunications: all services generally poor; 2,600 telephones; 90,000 radio <
receivers; 6,000 TV receivers; 2 AM, no FM, and 1 TV stations (broadcasts ;
temporarily suspended)
DEFENSE FORCES:
Military manpower: males 15-49, 1,357,000; 650,000 fit for military service; no ms
conscription
Supply: dependent on France
366
ET a ee ee a aS E ENC FREE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
|
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 91 URUGUAY','0b45f8f42cece928560880796b8820b4a2f7b11c0b57399e7983dd5516e89ce5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fa5890b2616380517039f4165c6af84c0cfd4b32c45a2276de668b44fdb3248',1974,'JP','Japan','communications',59,'Railroads: 12,318 mi.; 11,879 mi. 3''6" gage of which 1,323 mi. are multiple
track; 2,726 mi. electrified; 440 mi. 2''0" gage single track
Highways: 220,000 mi.; 31,700 mi. paved, 42,650 mi. crushed stone or gravel,
145,650 mi. improved and unimproved earth
Pipelines: crude oi], 520 mi.; refined products, 450 mi.; natural gas, 200 mi.
Ports: 5 major, 6 minor
Civil air: 57 major transport aircraft
Airfields: 756 total, 532 usable; 48 with permanent-surface runways; 1 with runway
over 12,000 ft., 8 with runways 8,000-11,999 ft., 125 with runways 4,000-7,999
ft.; 4 seaplane stations
Telecommunications: the system, except for the lack of television, is the best
developed, most modern, and highest capacity in Africa and consists of
carrier-equipped open-wire lines, coaxial cables, radio-relay links, and
radiocommunication stations; key centers are Bloemfontein, Cape Town,
Durban, Johannesburg, Port Elizabeth, and Pretoria; 1.6 million telephones;
2.5 million radio receivers; 13 AM, 60 FM, and no TV stations; 4 submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 5,444,000; 3,335,000 fit for military service;
obligation for servicevin Citizen Force begins at 18; volunteers for service
in permanent force must be 17
320
LT ERAS SENT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 61 SOUTH-WEST AFRICA
"318,000 sq. mi.; mostly desert except for interior
plateau and area along northern border
Land boundaries: 2,360 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 925 mi.
Railroads: 1,454 mi., all 3''6" gage, single :track
Highways: 21,000 mi.; 2,344 mi. bituminous treated, 220 mi. gravel and 18,436 mi.
earth road and tracks
Ports: 1 major, 1 minor
Civil air: 2 major transport aircraft (registered in South Africa)
Airfields: 125 total, 83 usable; 10 with permanent-surface runways; 1 with runway
over 12,000 ft.; 3 with runways 8,000-11,999 ft., 37 with runways 4,000-7,999
ft.; 1 seaplane station
Telecommunications: system is a meager combination of open-wire lines, a single
short radio-relay link, and scattered radiocommunication stations; Windhoek
is the center; 35,600 telephones; unknown number of radio receivers; no ~
AM, 1 FM, and no TV stations :
DEFENSE:
Military manpower: males 15-49, about 192,000; about 113,000 fit for military
service a
Defense is responsibility of Republic of South Africa
322
| “ 01ST AOOOGOOO TOON a ma
Approved For Release 2004/08/31 : CIA-RDP79-01051A0006 -
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 9 SPAIN
: 195,000 sq. mi., including Canary (2,900 sq. mi.) and
Balearic Islands (1,940 sq. mi.}; 41% arable and
land under permanent crops, 27% meadow and pasture,
22% forest, 10% urban or other
Land boundaries: 1,180 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 3,085 mi. (includes Balearic Islands, 420 mi.,
and Canary Islands, 720 mi.)
Railroads: 10,484 mi.; 8,374 mi.; (5''6" gage), 2,110 mi. other gages (4''8 1/2"
to 1''11 5/8"), 1,346 mi., double track; 2,368 mi. electrified
Highways: 86,600 mi.; national -- 35,175 mi. bituminous treatment, 9,400 mi. 4
crushed stone, 4,225 mi. bituminous, stone block and concrete; provincial
-- 18,200 mi. bituminous treatment, 18,400 mi. crushed stone, 1,200 mi.
bituminous, concrete, and stone block
324
TT AH BEE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Inland waterways: about 650 mi.; of minor importance as transport arteries and
contribute little to economy
Pipelines: crude 011, 230 mi.; refined products, 515 mi.; natural gas, 90 mi.
Ports: 23 major, 20 minor
Civil air: 183 major transport aircraft (including 2 foreign owned but Spanish
registered)
Airfields (including Balearic and Canary Islands): 122 total, 83 usable; 46
with permanent-surface runways; 4 with runways over 12,000 ft., 18 with
runways 8,000-11,999 ft., 34 with runways 4,000-7,999 ft.; 5 seaplane
stations
Telecommunications: modern, well engineered, well maintained; 5.9 million
telephones; 8 million radio and 5.02 million television receivers; 175 AM,
230 FM, and 650 TV stations; 6 coaxial submarine cables; 3 communication
satellite ground stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,544,000; 6,560,000 fit for military service;
275,000 reach military age (20) annually
325
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50P SPANISH SAHARA
LAND:
103,000 sq. mi., nearly all desert
Land boundaries: 1,296 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 690 mi.
Railroads: none
Highways: 3,790 mi.; 305 bituminous treated, 3,485 mi. unimproved earth roads
and tracks
Ports: 2 major, 2 minor
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
COMMUNICATIONS (cont''d):
Civil air: no major transport aircraft
Airfields: 25 total, 17 usable; 3 with permanent-surface runways; 5 with
runways 4,000-7,999 ft.
Telecommunications: telephone poor, telegraph poor to fair; 550 telephones;
1,500 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 15,000; 7,000-8,000 fit for military service
328
a all
Approved For Release a : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 37 SRI LANKA (formerly Ceylon)
PEOPLE''S REPUBLIC
OF CHINA
LAND:
25,300 sq. mi.; 25% cultivated; 44% forested; 31% waste,
urban, and other
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi. plus pearling in the Gulf of
Mannar, and right to establish 100 n. mi. conservation
zone)
Coastline: 835 mi.
Railroads: 938 mi.; 851 mi. 5''6" gage, 87 mi. 2''6" gage; 63 mi. double track;
no electrification; government owned
Highways: 25,580 mi.; 11,700 mi. paved (mostly bituminous treated), 11,500 mi.
crushed stone or gravel, 530 mi. improved earth, 1,850 mi. unimproved earth;
in addition several thousand mi. of tracks, mostly unmotorable
Inland waterways: 270 mi.; navigable by shallow-draft craft
Ports: 3 major, 9 minor
Civil air: 5 major transport (including 1 leased)
Airfields: 17 total, 10 usable; 10 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: an inadequate telephone and a less extensive but more
efficient telegraph system serves most areas, with greatest concentration
around Colombo and Kandy; all areas are served by radio and/or wire
broadcast; excellent international service; 64,338 (est.) telephones; 505,000
radio sets, no TV sets; 1 AM (plus 4 repeater Stations), no FM, and no TV
stations; submarine cables extend to India, Malaysia, Seychelle Islands,
and Aden
DEFENSE FORCES:
Military manpower: males 15-49, 3,362,000; 2,530,000 fit for military service;
153,000 reach military age (18) annually
330
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 54 SUDAN
LAND:
967,000 sq. mi.; 37% arable (3% cultivated), 15% grazing,
33% desert, waste, or urban, 15% forest
Land boundaries: 4,850 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (plus
6 n. mi. "necessary supervision zone")
Coastline: 530 mi.
Railroads: 2,950 mi.; 2,730 mi. 3''6" gage, 440 mi. 2'' gage plantation line
Highways: 6,550 mi.; 680 mi. crushed stone or gravel, 190 mi. bituminous-treated,
and 5,680 mi. improved and unimproved earth roads; in addition, there are an
undetermined number of tracks
Inland waterways: 3,300 mi. navigable
Ports: 1 major, 7 minor
Civil air: 8 major transport aircraft
Airfields: 90 total, 68 usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 29 with runways 4,000-7,999 ft.
Telecommunications: large system by African standards, but still barely adequate
for size of country; consists of open-wire lines, radio-relay links, multi-
conductor cables, radio communication stations and a tropospheric scatter
link; principal center of Khartoum, secondary centers at Al Fashir and
Port Sudan; 46,400 telephones; 650,000 radio and 60,000 TV receivers; 2 AM,
no FM, and 1 TV stations; 5 submarine cables ,
DEFENSE FORCES:
Military manpower: males 15-49, 3,889,000; 2,310,000 fit for military service;
average number reaching military age (18) annually, 160,000
332
EE SRT ol email
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 95B SURINAM
55,100 sq. mi.; negligible amount of arable land, meadows
and pastures, 76% forest, 8% unused but potentially
productive, 16% built-on area, wasteland, and other
Land boundaries: 970 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 240 mi.
Railroads: 104 mi.; 54 mi. 3''3 3/8" gage (government owned) and 50 mi.
narrow gage (industrial lines); all single track
Highways: 1,550 mi.; 300 mi. paved, 130 mi. gravel, 370 mi. improved earth,
750 mi. unimproved earth
Inland waterways: 2,850 mi.; most important means of transport; oceangoing
vessels with drafts ranging from 14 to 23 ft. can navigate many of the
principal waterways while native canoes navigate upper reaches
Ports: 1 major, 6 minor
Civil air: 2 major transport aircraft
Airfields: 31 total, 29 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4 ,000-7 999 ft.; 1 seaplane station
Telecommunications: international facilities good; domestic radio-relay
system; 11,200 telephones; 100,000 radio and 32,000 TV receivers, 5 AM,
1 FM, and 3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 109,000; 60,000 fit for military service
334
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 61 SWAZILAND
LAND:
6,700 sq. mi.; most of area suitable for crops or
pastureland
Land boundaries: 270 mi.
Railroads: 139 mi., 3''6" gage, single track °
Highways: 2,100 mi.; 150 mi. paved; 850 mi. crushed Stone, gravel, or stabilized
soil; 1,100 mi. improved or unimproved earth
Civil air: 6 major transport aircraft
Airfields: 29 total, 25 usable; 1 with runway 4,000-7,999 ft.
Telecommunications: the system consists of a few open-wire lines and low-powered
radiocommunication stations; Mbabane is the center; 5,700 telephones; 50,000
radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 106,000; 60,000 fit for military service
336
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
"173,000 sq. mi.3; 8% arable, 1% meadows and pastures, 55%
forested, 36% other
Land boundaries: 1,365 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi,
(fishing, 12 n. mi.)
Coastline: 2,000 mi.
Railroads: 7,561 mi.; Swedish State Railways (SJ) -- 7,004 mi. standard gage
(4''8 1/2"), 165 mi. narrow gage (3''6" and 2''11"), 4,373 mi. electrified, 725
mi. double tracked; 294 mi. standard gage (4'' 8 1/2"), 98 mi. narrow gage =
(2''11"), 284 mi. electrified are privately owned and operated ;
Highways: 61,000 mi.; 44,550 mi. are crushed stone, gravel, or improved earth;
and 16,395 mi. are bitumen, concrete, stone block, or cobblestone
Inland waterways: 1,268 mi. navigable for small steamers and barges
Ports: 17 major, and 23 significant minor
Civil air: 66 major transports .
Airfields: 234 total, 204 usable; 107 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 75 with runways 4,000-7,999 ft.; 9 seaplane stations
Telecommunications: excellent domestic and international facilities; 5 million
telephones; 24 AM, 85 FM, and 198 TY Stations; 5 million radio and 3 million
TV receivers; 10 submarine cables, including 4 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 1,884,000; 1,675,000 fit for military service;
96,000 reach military age (19) annually
ne tite eee =
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7 ; :
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 15 SWITZERLAND
LAND:
16,000 sq. mi.; 10% arable, 43% meadows and pastures, 20%
waste or urban, 24% forested, 3% inland water
Land boundaries: 1,171 mi.
Railroads: 3,186 mi.; 1,809 government owned (SBB), 1,763 mi. 4'' 8 1/2" gage,
46 mi. 3'' 3 3/8" gage, 837 mi. double track, 972 mi. single track, 99%
electrified; 1,377 mi. non-government owned, 444 mi. 4'' 8 1/2" gage, 886
mi. 3'' 3 3/8" gage, 47 mi. 2'' 7 1/2" gage, 100% electrified
Highways: 37,158 mi., all paved
Pipelines: crude oi1, 195 mi.
Inland waterways: 41 mi.; Rhine River-Basel to Rheinfelden, Schaffhausen to
Constanz; in addition, there are 12 navigable lakes ranging in size from <
Lake Geneva to Hallwilersee
Ports: 1 major, 2 minor
Civil air: 66 major transport aircraft
Airfields: 91 total, 75 usable; 36 with permanent-surface runways; 2 with
runways over 12,000 ft., 8 with runways 8,000-11,999 ft., 11 with runways 7
4,000-7 ,999 ft.
Telecommunications: excellent domestic, international, ard broadcast services;
3.5 million telephones; communications satellite station under construction;
1.99 million radio and 1.6 million TV receivers; 6 AM, 88 FM, and 255 TV
stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,531,000; 1,325,000 fit for military service;
45,000 reach military age (20) annually
ETE TES EH FEET TE TR CTE SPE BA IES Te TM eS EE EEE TEN NATE RIN LE RSI
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 28A SYRIA
TURKEY
72,000 sq. mi. including 500 sq. mi. of Israeli-occupied
territory; 48% arable, 29% grazing, 2% forest, 21%
desert
Land boundaries: 1,365 (1967) (excluding occupied area
1,340 mi.)
SAUDI
ARABIA
SUDAN nd
ETHIOPIA i
WATER:
Limits of territorial waters (claimed): 12 n. mi. (plus
6n. mi. "necessary supervision zone")
Coastline: 120 mi.
Railroads: 649 mi.; 459 mi. standard gage, 190 mi. narrow gage (3''5 3/8")
Highways: 7,150 mi.; 4,300 mi. paved, 810 mi. gravel or crushed stone, 1,540 mi.
improved earth, 497 mi. unimproved earth
Inland waterways: 420 mi.; of little importance
Pipelines: crude oi1, 810 mi.; refined Products, 320 mi.; natural gas 140 mi.
Ports: 3 major, 3 minor
Civil air: 7 major transport aircraft
Airfields: 90 total, 29 usable; 23 with permanent-surface runways; 1 with runway
over 12,000 ft., 18 with runways 8,000-11,999 ft., 4 with runways 4,000-
7,999 ft.
Telecommunications: fair international radiocommunication service; fair domestic
telecommunication service; 120,000 telephones; 1,000,000 radio and 135,000 Ty
receivers: 5 TV and 5 AM stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,631,000; 880,000 fit for military service; x
about 90,000 reach military age (19) annually
342
mre Ine TT 1 ae
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 56€ TANZANIA
LAND:
362,800 sq. mi. (including islands of Zanzibar and Pemba,
1,020 sq. mi.); 6% inland water, 15% cultivated, 31%
grassland, 48% bush forest, woodland, on mainland; 60%
arable, of which 40% cultivated on islands of Zanzibar
and Pemba
Land boundaries: 2,413 mi.
WATER:
Limits of territorial waters (claimed): 50 n. mi.
Coastline: 885 (this includes Mafia Island, 70; Pemba
Island, 110; and Zanzibar, 132)
Railroads: 1,950 mi.; 600 mi. 3''6" gage; 1,638 mi., meter gage, 4 mi. double track;
Tanzania portion of Tan-Zam Railroad completed
Highways: total 30,000 mi., including 390 mi. on Zanzibar Island and 277 mi. on
Pemba and Mafia Islands; about 1,400 mi. bituminous treated, (370 mi. on
Zanzibar and Pemba); 28,600 mi. gravel, crushed stone, or unimproved earth
Pipelines: refined products 610 mi.
Inland waterways: 730 mi. of navigable streams; several thousand mi. navigable
on Lakes Tanganyika, Victoria, and Nyasa
Ports: 4 major, 8 minor
Civil air: 9 major transport aircraft
Airfields: 114 total, 101 usable; 8 with permanent-surface runways; 1 with run-
way 8,000 to 11,999 ft., 42 with runways 4,000-7,999 ft., 4 seaplane stations
Telecommunications: telephone and telegraph good in main centers, only fair
outside main towns; 40,150 telephones; 225,000 radio receivers; 4 AM, no FM
or TV stations; 4 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,354,000; 1,860,000 fit for military service
344
Approved For Release creer : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 42 THAILAND
LAND:
198,000 sq. mi.; 24% in farms, 56% forested, 20% other
Land boundaries: 3,025 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,000 mi.
Railroads: 2,382 mi. meter gage; 60 mi. double track
Highways: 12,590 mi.; 5,440 mi. paved, 4,320 mi. crushed stone or gravel, 2,330)
earth and laterite
Inland waterways: 2,485 mi. principal waterways; 2,300 mi, with navigable depths
of 3 ft. or more throughout the year; numerous minor waterways navigable by
shallow-draft native craft
Ports: 2 major, 16 minor
Civil air: 26 major transport aircraft
Airfields: 236 total, 179 usable; 54 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 25 with runways 4,000-7,999 ft.; 3 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,807,000; 5,930,000 fit for military service;
about 424,000 reach military age (18) annually
Military and internal security budget: for fiscal year ending 30 September 1974,
$430 million; 25% of central government budget
eS IP TET I A a 2 eR HERES ES PETE CE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 50N TOGO
TURKEY
ALGERIA YA YP,
LIB EG Pleauol
"22,000 sq. mi.; nearly one-half is arable, under 15%
cultivated
Land boundaries: 940 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 35 mi.
Railroads: 275 mi. meter gage, single track
Highways: approx. 4,475 mi.; 300 mi. paved, 120 mi. gravel, 345 mi.
improved earth, 3,210 mi. unimproved
Inland waterways: section of Mono River and about 30 mi. of coastal lagoons
and tidal creeks
Ports: 1 major, 1 minor
Civil air: 1 major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-surface runway 4,000-7,999 ft.
Telecommunications: Togo has poor system based on skeletal network of open-wire
lines, supplemented by a few radiocommunication stations; only center is
Lome; 6,100 telephones; 46,000 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 453,000; 230,000 fit for military service;
no conscription
348
sa aineeteeiaarnemeem nel anaes ienaemmentlidadtientey ange eit Ne
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 102 TONGA
LAND:
385 sq. mi. (150 islands); 77% arable, 3% pasture, 13%
forest, 3% inland water, 4% other
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 260 mi. (est.)','b2978c8c35ee3808590069d58fc90aaff9fb762fc72ccdb87861157635a673f0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0db66fcf7ba2b8cddc38ddd7a2a9210bafad0051d44e009aa91300910074bd85',1974,'SA','Saudi Arabia','communications',63,'Railroads: none
Highways: 2,160 mi.; 290 mi. bituminous; 270 mi. crushed stone and gravel;
1,600 mi. earth, sand, and light gravel
Ports: 3 major, 2 minor a
Civil air: 8 major transport aircraft
Airfields: 35 total, 22 usable; 6 with Ppermanent-surface runways; 1] with
runway over 12,000 ft., 4 with runways 8,000-11,999 ft., 12 with runways
4,000-7,999 Ft.
Telecommunications: Systems among mideast''s worst; consists of meager open-wire
lines and low-power radio communication stations, principal center Sana,
secondary centers A] Hudaydah and Taizz; 4,600 telephones; 85,000 radio
receivers (approx.); 1 AM radio-broadcast station
DEFENSE FORCES:
Military Manpower: males 15-49, 1,520,000; 810,000 fit for military service;
about 67,000 reach military age (18) annually; univeral military conscription
(10 January 1963) makes military service obligatory for al] Yemeni
0
males 18-3
384
1. a :
Approved For Release 2004/08/31 : CIA-RDP79-0105 1 AUOUCOUU TUCO IEP seme, SAL
ee?
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 2] YUGOSLAVIA
“98 ,800 sq. mi.; 32% arable, 25% meadows and pastures,
34% forested, 9% other
Land boundaries: 1,865 mi.
WATER:
Limits of territorial waters (claimed): 10 n. mi.
(fishing, 12 n. mi.)
Coastline: 945 mi. (mainland), plus 1,500 mi. (offshore
ot fralye
ALG)','9f54c623b6c89cc9ec008eda549745b08d47bbc5144d6f12cc556a9009f0feab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a38cb421ad69eca4cb16c4bebca926b6aab2be50dff16d2e0da832a41a33ef6a',1974,'US','United States','communications',64,'This "Factsheet" on the U.S. is provided solely as a service to those
wishing to make rough comparisons of foreign country data with a U.S.
"vardstick." Information is from U.S. open sources and publications
and in no sense represents estimates by the U.S. intelligence community.
LAND:
3,615,211 sq. mi. (contiguous U.S. plus Alaska and Hawaii); 19% cultivated,
27% grazing and pasture, 32% forested, 22% waste, urban, and other
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing, 12 n. mi.)
Railroads: 207,000 mi. (1969)
Highways: 3,730,000 mi. (1970); 2,411,000 mi. Surfaced (1970)
Inland Waterways: 25,260 mi. of navigable inland channels, exclusive of the
Great Lakes; freight carried 951 million short tons (1970) Pe
Pipelines: petroleum, 176,000 mi.
Ports: 25 major
Civil air: 3,970 major transport aircraft (1970)
Airfields: 12,000 (1971)
Teleconmunications: 4,370 AM, 2,722 FM, 1,035 Ty operating stations (1970); a
120,155,000 telephones (1970), 58.6 telephones per 100 population (1970)
DEFENSE FORCES:
Personnel: army 1,386,000, Navy and bie 1,151,000, air force 1,048,000 (1971)
Military budget: $78 billion (1972 est.
a
, oA RENE:
Approved For Release 2004/08/31 : CIA-RDP79-0105 1AQOUGOOO TOO Tey nnn ERENT
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
— 7 7 = T 13 2 ce o aa yi ts Ve 13 2 Les =
i : : i } |
| i : |
| ;
| | | | ia. Ge cmens ee Mee ce of «cle oA’ N
AIR Ooh AP | | |
i ! ! | i | !
H d i : i i Hy
I : ia j
t oO Cc EA NG : A s © SEVERNAYH ZEMLYA |
: SVERDRUP ISLANDS. — : : i
: i
i 1% i !
! i £ i
: : i |
iF — + S ,
: 1 af : SEA
H = ae FOS
: ; bE ‘
i | i | WRANGEL I.
! we SEA ‘ eWEGien | aa
ee A Re ‘ i ct
i | | ;
a a a
i Se ™
: 2 5 !
7S UNITED STATES } : ‘tee
< > i ee ~
eat a ‘ es
3 (ALASKA) a Q | eri | | | Loo
ese Beh 5) | i | ma SOE
ie 3 SWEDEN .-" ; '' nee
6 FINLAND > | : : : | 4 St Lament
Hl : oe | !
os ; £ \\ i i | ae | a
é 1 ~ ‘a =
'' a Se
OF, SOvVI E me & |
: - BARING
¢ 2
| ! UA om IS Ee
: | ee sea lor ee ie
i ark get = Mul.
: i ! Ak oraotse tg . 5 sagen
! : NEWFOUNDLAND | H : i £20) Sakhatin Ra ALEUTIAN] ISLANDS
! me ! Hl aie ee
: oa Ah a
i B ; a) \\ Paar ‘
i | Nm” ROMANIA rc MONGOLIA * bof OS wy} 4
'' a ‘ MAL q fast S
3 + | ou 5 aeavoeinnaaes 2 eo —_ See a! We aeane gy L
i : : : rd : t : x 3
: i - : : ’ D ne ! a
NORTH 9 | pe ete Ss |
f i i ‘ AZORES ; |
{ ! . Ref F ee ! i 5 iTURKEY nN, “ N O R T H
‘ ; . ft i i a ; © ; % |
: N O|R T H speatra oi Se en Re ach Daye aca
: RUS oo SYRIA} r PEOPLE’S REPUBLIC OF CHINA
p A C / MADEIRA 11S, 2 eee AQ | i
i t t boa P SRAEL i . i
i : i i | a ae ORDAN : > ia | Lap PA Ci] F |
BC , eee eainey a ‘ fn Z han | a :
i i ANARY IS 7 ae ; ; ca ro t : T
AN Tae iis © OT sie We Pa Sey ee
@> CME A N | ae 2 ores <7 eanama is : EGYPT 8. Bon ly 4 coal y 4 Ovinawar S a BON INSIST "HAWAIIAN, 15,
; wo SMEXICO! vere ale i : ace NN re a INDIA < BaS Apkgn Patan eo" VOLCANO IS. | Marcus. |
| 6 OS | | : ; ee eee | POC. AN
*<_, UNITED STATES : ecu te : : | ye : a ACA ORG i | |
JAWAIIAN IS. : Bae : - : SP iE PL + tHIN H : !
K Ss. (aaa i : oe sataica. 7 fiatip Grune O cy E A N | ! : Y nog RONG REPUBLIC OF CHINA | hae !
! ag ee ae 4. Be eee ts <8 2 : , i+ Wake
| { | ? BELIZE “Puerto Rico’ ;Aatigue | . oe 4 Wines -. ! f ac OS *Y ansialects ! !
: ‘ Se ON ae UR AS cadigeae 2.Guadelo ICAPE VERDE * ee MALI i Z j Z THAILANE +
he en a Faia = an ___* Dominica : Sel wa ie i ‘ ge
: i t r GUATEMALE ee Martiniace ''shint Lucie tT + S <I a : | 2a : 7 eases .. 5
: i : aL PNAS NICARAGUA , renada’ | b2rbedes i 2 : We c os Sorta | 5 ANDAMAN § * Guar ;
| | Clipperton 7 costa rica: Gt oe. Peo AND i : "CE DaHOMEY Oe LEGCADIVE. 1S
i ipperton 3. SA ZONE - CBAGO : _ Sup piece - “i el }
: : : | i kaa oY WVENEZUELS i tie ce GER ” a Sal '' Jp, SRELANKA pe YE - CAROLIINE 18 ! : i
H i ] NAMA + SIERR Al LEQNE” i : " ETHIOPIA Diet is ¢ mY 3 . . FRUK IS. MARSHALL
; / ! i ‘ Neen Guyana ; yk 7. ov ‘. “SOMALIA . NICOBAR 1S y : ua
Paimfra IL | i H 5 [ (7 SUBIIEM : | BERL Ng g i i fe ~ : ~ : |
} H FRENCH GUIANA Saray: ES at . o ae s |
| > COLOMBIA S % | | . yet CAMEROO! 4 an laa al ; MALDIVES '' " \\ eapeerig
i “Chvistenas [. t H & ALL? aS ; fron 7 H e : Ml :
: a | : r. ! i i f KENYA > : a E :
'' : i GALAPAGOS 1S.“ EcvapoR 4» AS tT : ¥ ; nee - y a : ere a ot cs ;
: H G O i at as he “ = | ZAIRE Rw: fa, - : a 5 ANEW GUINEA
'' ! '' i = Nes i i Zet No i . i | Sumatr, : ioe |
| i : i ‘ ig lansiber SevoHELLEg Pein : ‘ al 5 i
i i i A 2 I L |.Ascenson 1. : Ae = | { oe : ‘> Sox, Sobomond isLanos ‘ be ‘ H
. : 1 ms wf x ‘} i : . | i |
: porn: Fy MARQUESAS ''S LR oA OE HE of ae sere ! i I : wn : i eheihse NOR wt 3 i
i : | i ) : i | > ANGOLA e _.COMORO IS Boeoauig® (I ee > a
i : oT _ '' + f i 2 i | | ; i t soe a a) gana Bes!
y a : Seer y t : 7 a ; +—— 7 sere
1 COOK Is, SOCIETY 18. eps | OC FAN i : ANC RSE Ney | | alee | Pee : : \\ : eer free Baie :
: : \\ : \\ aw, | i H '' i i ee : a
'' i fot a ‘ i i i ae = Z REPUBLIC auririug N dD t il A N ; : : e aa |
i TuBual IS. : “ be f i } _ SOUTH. Saye me i ; I y 4, |
i i \\ PARAGUAY a i S O : U T HI Welvis Bay 2 WEST : BOTSWANA 0” Y ‘“ REUNION H ‘ol New Caledoni i
I : ) ao i i | (Rep. of 8. Afri) co ing! Sef i &
; Piteaien Dutie |. dk r H : AFRICA. ae moet \\y {
: \\ Easter I. Te! : : ! hod a : |
'' i : ; : : : I } i k
oA : : | sad O:cC E AN 1 4 i :
Lf Z fall : 1 i a 7 = 3 j : : | : ’ | | Fort | H
7 i * = at t - L
‘ oF ww (A JT ff | A WN qe be ae '' SOUTH AFRICA : isc] Lord Howe | HERAT
| : caer j y i | i : | : a i | i
| : JUAN FERNANDEZ 1S & URUGUAY - : | : ! x oe : va :
a ae
: i ; i : | : | if ; i
: tar de Cunhe i '' | 4 | I
! | w i i : |, Amsterdam |. jt 3 i i
| é | : f i | "Saint Pauli ae TASMAY }
: : | | Gough i | : | | fe !
| : : | i On uC E@wrA Ni | : : | SEA A Rs : i
| | | | | | | | | | | | aaa |
i : : i i | ‘ : | { i } i : a CHATHAM iS.
. : = ; : ae : : | : i i ! : ae
t + “———— a t : aaa a : + = : oe + * t + gt
: : i boos : : ; PRINCE EDWARD 1S... CROZET IS ; ; i i
| H : i | KERGUELEN IS. | ‘ ROUNTEC TS
i : : ; i i a : ''
i | 4 H ! | : ‘ i : Ne ! ANTIPODES IS | |
i | | i i : '' : i ; | 1a AUCKLAND IS |
'' i i : : ; i
'' ! \\ : i t : i i '' i ! | i
: : ; | sey Sauth Georgia: : I '' i ! : !
I : Hl i i 1 * | i i MACQUARIE [., ! }
i : H i : | fa i i : H
i i { { SOUTH ‘ | : |
| i 1 SANDWICH IS. i BOUNDARY REPRESENTATION (5° ‘ : i \\
ah i i ; : x | Nor NECESSARILY AUTHORITATIVE i : i i
$65 BD Tie TP aoe EB 7 ec 45 Eg 1 TF 30 35 a ae 30 a» 7a =
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7','191d4f7b6789ebeac54e658378b3cc38763f03fc9372747011f4c062297abda5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7783f85e468efd98a98b97c2e38318d0a3a7adc7ed242cb8a2be9e716ed5634e',1974,'','','communications',2,'Government __..... Railroads
—_._—.. Legal name —_..... Highways
____. Type —_—..... Inland waterways
Eaeeee eee Capital Freight carried
-____— Political subdivisions . Pipelines
——__— Legal system —____. Ports
—_——— Branches of government ——... Merchant marine
—_-. Government leaders eee Civil air
—____.. Suffrage —__.._. Airfields
og See Elections (frequency) _._....— Telecommunications
—__.—-. Political partics and leaders
= 3 =F Voting strength
——— Communists
———.. Other political or pressure groups
——..... Member of what international associations
Are there any entries you fcel should be added or changed?
2. Please state how many people in your office or unit use the same copy of the Factbook, ____
1
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
3. The Fa
{
2
3
4,
5
6
4, Would
bureaus—
Pl
Approved For Release 2008/07/18
ctbook is useful to you in what ways?
. Answering spot queries
. Briefings
. Research, analysis, and production
Planning and operations
. General background and orientation
. Other (specify) _
: CIA-RDP79-01051A000700010002-8
a reorganization of the Factbook text on a regional basis—-possibly to conform with the State Department’s regional
facilitate your use of the volume? A small foldout map of each region would follow cach
ease check appropriate space.
_ Yes
No
5. What additional suggestions can you make for improving the Factbook?
6. Your Agency -...
Compone.
Purpose of principal activity (military planning, foreign aid, briefing, research, etc.)
Your position (job title) _
Your fields of responsibility (geographic area and/or specialty)
area grouping of countries.
nt/location
2
Approved For Release 2008/07/18 :
Signature (optional)
CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Office of Basic and Geographic Intelligence
Central Intelligence Agency
Washington, D.C.
20505
Atin: Faetbook
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
~@&
©
Next 6 Page(s) In Document Denied
Pod
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
STAT
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
AAPSO
ACCT
ADB
AFDB
ANZUS
ASA
ASPAC
BENELUX
BLEU
CACM
CARICOM
CARIFTA
CEAO
CEMA
CENTO
DAC
EAMA
EC
ECAFE
ECSC
EEC
EFTA
EIB
ELDO
EMA
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
Afro-Asian Peaple''s Solidarity Organization
Agency for Cultural and Technical Cooperation of
French-speaking Countries
Asian Development Bank
African Development Bank
ANZUS Council; treaty signed by Australia, New Zealand,
and the United States
Association of Southeast Asia
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market
Caribbean Free Trade Association
West African Economic Conmunity
Council for Mutual Economic Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
Economic Commission for Asia and the Far East
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Launcher Development Organization
European Monetary Agreement
vii
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
ENTENTE Political-Economic Association of Ivory Coast,
Dahomey, Niger, Upper Volta, and Togo
ESRO European Space Research Organization
EURATOM European Atomic Energy Community
IADB Inter-American Defense Board
IDB Inter-American Development Bank
IFCTU International Federation of Christian Trade Unions
IHB International Hydrographic Bureau
IPU Inter Parliamentary Union
TRC International Red Cross
LAFTA Latin American Free Trade Association
LICROSS League of Red Cross Societies
NATO North Atlantic Treaty Organization
OAPEC Organization of Arab Petroleum Exporting Countries
OAS Organization of American States
OAU Organization of African Unity
OCAM Afro-Malagasy and Mauritian Conmon Organization
ODECA Organization of Central American States
OECD Organization for Economic Cooperation and Development
OPEC Organization of Petroleum Exporting Countries
SEATO South-East Asia Treaty Organization
UEAC Union of Central African States
UDEAC Economic and Customs Union of Central Africa
WEU Western European Union
WCL World Confederation of Labor
WFTU World Federation of Trade Unions
WPC World Peace Council
viii
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
sc
GA
ECOSOC
TC
ICJ
Secretariat
Operating Bodies:
UNCTAD
TDB
UNICEF
Security Council
General Assembly
Economic and Social Council]
Trusteeship Counci]
International Court of Justice
U.N. Conference for Trade and Development
Trade and Development Board
U.N. Children''s Fund
Regional Economic Commissions:
ECA
ECAFE
ECE
ECLA
Intergovernmental
FAO
GATT
IBRD
ICAO
IDA
IFC
ILO
IMCO
IMF (FUND)
ITU
UNESCO
Economic Commission for Africa
Economic Commission for Asia and the Far East
Economic Commission for Europe
Economic Commission for Latin America
Agencies Related to the U.N.:
Food and Agriculture Organization
General Agreement on Tariffs and Trade
International Bank for Reconstruction and Development
(World Bank)
International Civil Aviation Organization
International Development Association (IBRD Affiliate)
International Finance Corporation (IBRD Affiliate)
International Labor Organization
Inter-Governmental Maritime Consultative Organization
International Monetary Fund
International Teleconmunication Union
United Nations Educational, Scientific, and Cultural
Organization
ix
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
UPU Universal Postal Union
UNCTAD U.N. Conference on Trade and Development
WHO Worid Health Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
Committees:
Seabeds Conmittee United Nations Committee on the Peaceful Uses of the
Sea-Bed and Ocean Floor beyond the Limits of National
Jurisdiction
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Political, sociological, and economic data, including monetary
conversion rates, generally reflect information through mid-May
1974, except for population estimates, which have been projected to
] July 1974. Military manpower estimates are as of 1 January 1974
except for average number of males reaching military age, which
are projected averages for the 5-year period 1974-78. Military and
communications data are as of 30 April 1974 unless otherwise indicated.
Most of the land utilization estimates are rough approximations,
and most of the statistical data are rounded (thousands and millions).
Figures for "arable" may reflect only the area actually under crops
rather than the potential cultivable. Fishing limits are included
only when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The difference
between the two is in the addition or subtraction of the value of
return on foreign investment. GDP equals GNP plus income earned
in the country but sent abroad, minus income earned abroad but
sent into the country. GDP thus tends to exceed GNP in debtor
countries, and the reverse is true in creditor countries.
Major ports are the largest maritime ports of the country,
relative to other ports of the same country, on the basis of
estimated port capacity, alongside berthing accommodations, and
commercial or naval importance. Minor ports are the remaining ports
of a country which have, relative to the major ports, significantly
lower estimated port capacity, fewer alongside berthing accommodations ,
are of less commercial or naval importance. Major transport aircraft
are those weighing over 20,000 pounds. Military budgets are in U.S.
dollar equivalents. The dollar sign refers to U.S. dollars unless
otherwise stated. The abbreviation FY stands for U.S. fiscal year;
all years are calendar years unless otherwise indicated.
xi
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
AFGHANISTAN PEOPLE''S REPUBLIC
OF CHINA
LAND:
: 250,000 sq. mi.3; 22% arable (12% cultivated, 10%
pasture), 75% desert, waste or urban, 3% forested
(1970)
Land boundaries: 3,425 mi.
r PEOPLE:
Population: 18,714,000, average annual growth rate
2.3% (7/71-7/72)
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9% Uzbeks,
9% Hazaras, minor ethnic groups include Chahar,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11%
Turkic languages (primarily Uzbek and Turkmen), 10% 30 minor languages
(primarily Batuchi and Pashai); much bilingualism
Literacy: under 10%
Labor force: about 4.3 million (official est.); 75%-80% agriculture and animal
husbandry, 20%-25% commerce, small industry, services; massive shortage of
skilled labor
Organized labor: none
Railroads: 0.4 mi. (single track) 5''0"-gage, government-owned spur of Soviet line
Highways: 12,970 mi.; 420 mi. concrete, 1,100 mi. bituminous surfaced, 2,430 mi.
gravel, 5,420 mi. improved earth, and 3,590 mi. unimproved earth
Inland waterways: total navigability 760 mi.; steamers use Amu Darya
Ports: only minor river ports
Airfields: 72 total, 37 usable; 9 with permanent-surface runways; 6 with runways
8,000-11,999 ft., 10 with runways 4,000-7,999 ft.
Telecommunications: limited telephone, telegraph, and radiobroadcast services,
barely sufficient to meet civil and military requirements; 22,674 telephones;
110,000 radio receivers; no TV receivers; 2 AM, no FM, no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 4.7 million; 2.5 million fit for military
service; about 165,000 reach military age (22) annually
Supply: dependent on foreign sources, almost exclusively the U.S.S.R.
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ALBANTA
LAND:
11,100 sq. mi.; 19% arable, 24% other agricultural, 43%
forested, 14% other
Land boundaries: 445 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 260 mi. (including Sazan Island)
nee EGYPT . *—~ ARABIA
Railroads: 142 mi. standard gage, single track; government owned (1973)
Highways: 3,100 mi.; 300 mi. paved, 1,200 mi. crushed stone and/or gravel, 1,600
mi. improved or unimproved earth (1973)
Inland waterways: 27 mi. plus Albanian sections of Lake Scutari, Lake Ohrid,
and Lake Prespa (1974)
Freight carried: rail -- 3.1 million short tans, 123.3 million short ton/mi. (1971);
highways -- 43.0 million short tons, 616.4 million short ton/mi. (1971)
Ports: 2 major (Durres, Vlore), 2 minor (1973)
Pipelines: crude oil, 110 mi.
Civil air: no major transport aircraft (1974)
Airfields: 11 total; 5 with permanent-~surface runways; 6 with runways 8,000-
11,999 ft., 5 with runways 4,000-7,999 ft.
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','3accab094a236ec267e142a681889ebf82b3575f403176c573ae662dd9981ad3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8b14ff52af9c5e43e5dc9cb16e2cbc95a6456dce3a146217fa0e8cd7eee4597',1974,'DZ','Algeria','communications',6,'LAND:
950,000 sq. mi.; 3% cultivated, 16% pasture and meadows,
1% forested, 80% desert, waste, or urban
Land boundaries: 3,890 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 735 mi.
Railroads: 2,414 mi.; 1,660 mi. standard gage, 663 mi. 3''5 9/16" gage, 91 mi.
meter gage; 188 mi. electrified; 120 mi. double track
Highways: 42,100 mi., of which 17,950 mi. are concrete or bituminous and the
remainder gravel, crushed stone, or improved earth
Ports: 9 major, 8 minor
Pipelines: crude oil, 2,250 mi.; refined products, 180 mi.; natural gas, 1,785 mi,
Civil air: 22 major transport aircraft
Airfields: 252 total, 196 usable; 56 with permanent-surface runways; 27 with
runways 8,000-11,999 ft., 112 with runways 4,000-7,999 ft.; 3 seaplane
stations
Telecommunications: adequate domestic and international facilities in the north,
primarily radio communications in the desert; 211,250 telephones; 1,150,000
radio receivers; 250,000 TV receivers; 16 AM and 13 TV stations; 3 submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,840,000; 2,200,000 fit for military service;
average number reaching military age (19) annually 150,000
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ueya
Railroads: 1,361 mi., 5''3" gage; government owned
Highways: 53,700 mi.; 46,950 mi. surfaced, 6,750 mi. earth
Inland waterways: approx. 650 mi.
Ports: 6 major, 38 minor
Civil air: 21 major transport aircraft
Airfields: 41 total, 37 usable; 7 with permanent-surface runways; 7 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Teleconmunications: small, modern system; all cities interconnected for telephone
and telegraph service; 359,000 telephones; 850,000 radiobroadcast receivers;
560,000 TV receivers; 6 AM, 5 FM, and 20 TV stations; 4 coaxial submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 663,000; 520,000 fit for military service;
about 28,000 reach military age (17) annually
168
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
~@&
©
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
STAT
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','f2495187cd39927a14e9e40896b7978087207871fcae24ecb463247cc2cd4df7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1868038f97ac3624a0fe65b8ab815083e0c0de86b1e32d91b6f9046ae73a4fec',1974,'AD','Andorra','communications',10,'LAND:
180 sq. mi.
Land boundaries: 65 mi.
Railroads: none
Highways: about 60 mi.
Civil air: no major transport aircraft
Airfields: none
Teleconmunications: international circuits to Spain and France; 2 AM, 1 FM, 1 TY
station; about 1,800 telephones; 8,000 radio receivers, 2,900 TV receivers
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
DEFENSE FORCES:
Andorra has no defense forces; Spain and France are responsible for protection
as needed
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','cc5c7f58847770e754355c13142db5687e502c7382345da3e644c5766e6a0346','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31aa474164cb274e88c1e970d96e36beaf2577d8e41f5465d76bebe5eb0268b7',1974,'AO','Angola','communications',14,'LAND:
481,000 sq. mi.; 1% cultivated, 44% forested, 22% meadows
and pastures, 33% other (including fallow)
Land boundaries: 3,150 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. (navy)
(fishing 12 n. mi.)
Coastline: 1,000 mi.
Railroads: 1,918 mi.; 1,724 mi. 3''6" gage, 194 mi. 1''17 5/8" gage
Highways: 45,000 mi.; 4,970 mi. bituminous-surface treatment, 28,000 mi. crushed
stone, gravel, or improved earth, remainder unimproved earth
Inland waterways: 2,000 mi. navigable
Ports: 3 major, 15 minor
Pipelines: crude oi], 111 mi.
Civil air: 15 major transport aircraft
Airfields: 495 total, 417 usable; 23 with permanent-surface runways; 1 with
runway over 12,000 ft., 6 with runways 8,000-11,999 ft., 54 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: simple network of low-capacity open-wire and radio-relay
facilities; 32,300 telephones; 115,000 radio receivers; 21 AM, 7 FM, and no
TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,475,000, fit for military service, 735,000;
average number reaching military age (20) annually about 60,000
Defense is responsibility of Portugal
Supply: dependent on Portugal
10
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ANTIGUA
LAND:
108 sq. mi.; 54% arable, 5% pasture, 14% forested,
9% unused but potentially productive, 18% wasteland
*
and built on Cons:
WATER: COLOMBIA ae |
Limits of territorial waters (claimed): 3 .n. mi.
Coastline: 95 mi.','9f6da5a4b152df305d9ac0e27ef27a16baee454793ebb8de3758a7ab4ba3e324','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9c64c86344cdffcdaea7ad024723f6fe5227b201f21f21b86efe6fbf353d27c',1974,'BR','Brazil','communications',18,'PEOPLE: ae
Population: 78,000, average annual growth rate 2.6%
(4/60-4/70)
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other Protestant sects and some
Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000
Railroads: 49 mi. narrow gage (2''6"), employed almost exclusively for handling
cane
Highways: 235 mi.; 150 mi. main, 85 mi. secondary
Ports: 1 major, 1 minor
Civil air: 12 major transport aircraft
Airfields: 3 total, 1 usable; 1 with asphalt runway 9,000 ft.; 1 seaplane
station
Teleconmunications: automatic telephone system; 2,950 telephones; tropospheric
scatter links with Tortola and St. Lucia; 21,000 radio receivers, 12,000 TV
sets; 2 AM, 1 FM, and 1 TV stations; 2 coaxial submarine cables
12
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
LAND:
424,000 sq. mi.; 2% cultivated and fallow, 11% pasture
and meadow, 45% urban, desert, waste, or other,
40% forest, 2% inland water
Land boundaries: 3,780 mi.
Railroads: 2,310 mi., single track; 2,290 mi., meter gage, 20 mi., 2''6" gage;
all government owned except 60 mi. of meter-gage track; 5.6 mi. of meter-
gage track electrified
Highways: 17,600 mi.; 700 mi. paved, 4,100 mi. gravel, 3,700 mi. improved
earth, 9,100 mi. unimproved earth
Inland waterways: officially estimated to be 6,250 mi. of commercially
navigable waterways
Pipelines: crude oil, 1,040 mi.; refined products and crude 930 mi.; natural gas
350 mi.
Ports: none (Bolivian cargo moved through Arica and Antofagasta, Chile, and
Matarani, Peru)
Civil air: 39 major transport aircraft
Airfields: 546 total, 471 usable; 3 with permanent-surface runways; 1 with
runway over 12,000 ft., 3 with runways 8,000-11,999 ft., 92 with runways
4,000-7,999 ft.
Telecommunications: poorest telecom facilities on continent; radio-relay station
under construction; 49,000 telephones; est. 750,000 radio and 12,000 TV
receivers; 80 AM, 14 FM, and 3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49 1,194,000; 750,000 fit for military service;
average number reaching military age (19) annually about 75,000
38
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
LAND:
= 3,290,000 sq. mi.; 4% cultivated, 13% pastures, 23%
built-on area, waste, and other, 60% forested
Land boundaries: 8,125 mi.
WATER:
- Limits of territorial waters (claimed): 200 n. mi.
Coastline: 4,655 mi.
Railroads: 19,935 mi.; 17,586 mi. 3''3 3/8" gage, 2,085 mi. 5''3" gage, 121 mi.
4''8 1/2" gage, 143 mi. narrow gages; 1,621 mi. electrified
Highways: 591,000 mi.; 31,000 mi. paved, 560,000 mi. gravel or earth
Inland waterways: 31,000 mi. navigable
Ports: 6 major, 25 significant minor
Pipelines: crude oil, 770 mi.; refined products, 290 mi.; natural gas, 24 mi.
Civil air: 138 major transport aircraft
Airfields: 4,043 total, 3,558 usable; 140 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 378 with runways 4,000-7,999 ft.; 18 seaplane
stations
Teleconmunications: moderately good telecom system; radio relay widely used;
communications satellite ground station; 2.5 million telephones; est. 12.25
million radio and 8.65 million TV receivers; 920 AM, 150 FM, and 165 TV
stations; 6 submarine cables, including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 23,606,000; 15,405,000 fit for military service;
1,170,000 reach military age (18) annually
42
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ie
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
BRITISH SOLOMON ISLANDS
LAND:
About 11,500 sq. mi.
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: about 3,300 mi.
Railroad: none
Highways: 518 mi.; 150 mi. sealed or all-weather
Inland waterways: none
Ports: 3 minor
Civil air: no major transport aircraft
Airfields: 26 total, 1 permanent surface runway 6,300 ft.; 7 natural surface
runways 4,000-7,999 ft., 12 natural surface runways less than 3,999 ft.; 3
seaplane stations
Telecommunications: 3 AM broadcast stations, 7,680 radio receivers, 1,434
telephones; international connections with London, England, via cable
broadcasts
43
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
BRUNEI
LAND:
2,230 sq. mi.3 3% cultivated; 22% industry, waste,
urban or other; 75% forested
Land boundaries: 237 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 100 mi.
Railroads: none
Highways: 621 mi.3; approximately 183 mi. bituminous, remainder crushed stone or
gravel
Ports: 1 minor (Moroni on Grande Comore)
Civil air: 4 major transports (registered in France)
7]
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
LAND:
Colony -- 4,700 sq. mi.; area consists of some 200 small
islands, chief of which are East Falkland (2,580 sq.
mi.) and West Falkland (2,038 sq. mi.); dependencies--
consists of the South Sandwich Islands, South Georgia,
and the Shag and Clerke Rocks
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 800 mi.
Railroads: none
Highways: 22 mi.; 10 mi. paved, 12 mi. gravel, and earth; no other made-up roads
in the islands beyond the immediate vicinity of Stanley
Ports: 1 major, 4 minor
Civil air: no major transport aircraft
*The possession of the Falkland Islands has been disputed by the U.K. and Argentina
(which refers to them as the Malvinas) since 1833.
105
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Airfields: 1 seaplane station
Telecommunications: government-operated open-wire and radiotelephone networks
providing effective service to almost all points on both islands; approx-
imately 600 telephones; 1 AM station and 1,100 est. radiobroadcast receivers
106
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
LAND:
83,000 sq. mi.; 1% cropland, 3% pasture, 8% savanna,
66% forested, 22% water, urban, and waste
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 3n. mi.
Coastline: 285 mi.
Railroads: 103 mi., all single track; 85 mi. 3''0" gage, 18 mi. 3''6" gage
Highways: 1,800 mi.; 450 mi. paved, 850 mi. otherwise improved, 500 mi. unimproved
Inland waterways: 3,700 mi.; Demerara River navigable to Mackenzie by ocean
steamers, others by ferryboats, small craft only
Ports: 1 major, 3 minor
Civil air: 2 major transport aircraft
Airfields: 102 total, 89 usable; 4 with permanent-surface runways; 12 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: highly developed telecom system with radio relay network and
over 17,500 telephones; tropospheric scatter Tink to Trinidad; 260,000 radio
receivers, 2 AM and 1 FM stations
DEFENSE FORCES:
Military manpower: males 15-49, 183,000; 125,000 fit for military service
148
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Railroads: 50 mi. 2'' 6" gage, single-track, privately owned industrial line; 5
mi. dual-gage 2'' 6"-3'' 6"; government line, dismantled
Highways: 2,000 mi.; 200 mi. paved, 900 mi. otherwise improved, 900 mi. unimproved
Inland waterways: negligible; about 60 mi. navigable
Ports: 2 major, 12 minor
Civil air: 9 major transport aircraft; 4 owned by the air force
Airfields: 31 total, 15 usable; 3 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: all domestic facilities inadequate, international facilities
slightly better; telephone expansion program underway; only 5,000 telephones,
290,000 radio and 13,000 TV receivers, 30 AM, 3 FM, and 1 TV station
DEFENSE FORCES:
Military manpower: males 15-49, 1,231,000; 635,000 fit for military service;
about 51,000 reach military age (18) annually
150
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Railroads: 357 mi.; 202 mi. of 3''6" gage, 155 mi. of 3''0" gage
Highways: 5,400 mi.; 700 mi. bituminous surfaced, 1,550 mi. gravel surfaced or
improved earth, 3,150 unimproved earth
Inland waterways: 750 mi. navigable by small craft
Ports: 3 major, 9 minor
Civil air: 23 major transport aircraft
Airfields: 255 total, 180 usable; 4 with permanent-surface runways; 10 with run-
ways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: improved, but still inadequate; connection into Central
American microwave net; 19,000 telephones; 300,000 radio and 46,000 TV
receivers; 102 AM, 10 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 680,000; 400,000 fit for military service;
about 30,000 reach military age (18) annually
152
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Railroads: none
Highways: 7,400 mi.; 4,760 mi. crushed stone (including lava) and gravel, 2,593
mi. unsurfaced roads and motorable tracks, 47 mi. concrete (some bituminous
stretches }
Ports: 4 major, and about 50 minor
Civil air: 22 major transport aircraft
Airfields: 108 total, 93 usable; 4 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 12 with runways 4,000-7,999 ft.; 5 seaplane stations
Telecomnunications: adequate domestic service, wire and radio communication
system; 81,000 telephones; 75,000 radio and 49,250 TV receivers; 17 AN,
14 FM, and 77 TV stations; 2 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 51,000; 44,000 fit for military service (Iceland
has no conscription or compulsory military service)
158
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Railroads: none
Highways: 1,100 mi.; 600 mi. paved, 500 mi. gravel and earth
Ports: 1 major, 5 minor
Civil air: no major transport
Airfields: 2 usable; 1 with permanent-surface runway; 1 with runway 8,000-11,999
fts 1 seaplane station
Telecommunications: domestic facilities inadequate; 24,300 telephones, inter-island
VHF radio links; satellite earth station; 1 AM, 1 FM, and 5 TV stations; about
38,000 radio and 14,210 TV receivers
YEFENSE FORCES:
Military manpower: males 15-49, included in France
224
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
MAURITANIA Sony SE aN
ae be
AQ LIBYA Ee
LAND:
419,000 sq. mi.; less than 1% suitable for crops, 10%
pasture, 90% desert
Land boundaries: 3,180 mi.
WATER:
Limits of territorial waters (claimed): 30 n. mi.
(fishing, 6 n. mi. exclusive rights, 6n. mi.
contiguous zone)
Coastline: 490 mi.
Railroads: 400 mi. standard gage, single track, privately owned
Highways: 3,790 mi.; 350 mi. paved; 380 mi. gravel, crushed stone, or otherwise
improved; 3,070 mi. unimproved
Inland waterways: 500 mi.
Ports: 3 minor
Civil air: 8 major transport aircraft
Airfields: 40 total, 29 usable; 9 with permanent~surface runways; 1 with runway
8,000 to 11,999 ft.; 15 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone poor, telegraph fair; 1,300 telephones; 81,000
radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 274,000; 135,000 fit for military service;
conscription law not implemented
226
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
MAURITIUS For kg
a ‘t
LAND: ne esas /
720 sq. mi. (excluding dependencies); 50% agricultural, in- gl se Ny ee ren etter
tensely cultivated; 39% forests, woodlands, mountains, ands ee
river, and natural reserves; 3% built-up areas; 5% : a
water bodies, 2% roads and tracks, 1% permanent \\ gE. gee erm sea
was te lands [eee i
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 110 mi.
Highways: 1,100 mi.; 990 mi. paved, 110 mi. earth
Civil air: no major transport aircraft
Ports: 1 major, 2 minor
Airfields: 6 total, 6 usable; 1 with permanent-surface runway; |] with runway
8,000-11,999 ft.
Telecommunications: 20,400 telephones; radio telegraph service with Reunion,
Malagasy Republic, Seychelles, Zanzibar, and other places in Africa; 1 AM,
no FM, and 4 TV stations; 160,000 radio and 25,300 TV sets; submarine cables
extend to Republic of South Africa and Seychelles Islands
DEFENSE FORCES:
Military manpower: males 15-49, 200,000; 100,000 fit for military service
228
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
~&
4
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
STAT
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
NORWAY."
SWEDEN £85
Railroads: none
Highways: 700 mi.; 350 mi. paved, 220 mi. otherwise improved, 130 mi. unimproved
Ports: 3 major, 6 minor
Civil air: 6 major transport aircraft
Airfields: 7 total, all usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: generally adequate telecom facilities; extensive inter-
island VHF links; 41,000 telephones, 130,000 radio and 34,000 TV receivers,
11 AM and 3 TV stations, 5 telegraph submarine cables, including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 60,000; 30,000 fit for military service;
about 2,000 reach military age (20) annually
246
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
LAND:
496,000 sq. mi. (other estimates range as low as 482,000
sq. mi.); 2% cropland, 14% meadows and pastures, 55%
forested, 29% urban, waste, other
Land boundaries: 3,810 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,500 mi.
Ratlroads: approx. 1,560 mi.; 1,227 mi. 4'' 8 1/2" gage; 41 mi. gage less than
3''0"; 282 mi. 3'' O" gage; 9 mi. double track
Highways: 31,300 mi.; 3,050 mi. paved, 6,250 mi. gravel or crushed stone, 8,900
mi. improved earth, 13,100 mi. unimproved earth
Inland waterways: 5,400 mi. of navigable tributaries of Amazon River system and
130 mi. Lake Titicaca
Pipelines: crude 011, 200 mi.; natural gas and natural gas liquids, 40 mi.
Ports: 7 major, 20 minor
Civil air: 22 major transport aircraft
Airfields: 340 total, 295 usable; 20 with permanent-surface runways; 2 with
runway over 12,000 ft., 20 with runways 8,000-11,999 ft., 47 with runways
4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fairly adequate for most requirements; new radio-relay system
under construction; communications satellite ground station; 289,000 telephones;
2.2 million radio and 490,000 TV receivers; 215 AM, 7 FM, and 30 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 3,256,000; 2,205,000 fit for military service;
average number currently reaching military age (20) annually, 144,000
272
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
PEOPLE''S REP.
OF CHINA
Railroads: none
Highways: 415 mi.; 175 mi. paved; 240 mi. otherwise improved
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
Airfields: 2 airfields with permanent surface runways; one with a 9,000 foot
runways; one with a 5,700 foot runway; 2 seaplane stations
Telecommunications: fully automatic telephone system with 5,500 telephones; direct
radio link with Martinique; interisland tropospheric links to Barbados and
Antigua; 20,000 radio and 500 TV receivers; 2 AM, and 1 TV station
298
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ST. VINCENT
LAND:
150 sq. mi. (including northern Grenadines); 50% arable,
3% pasture, 44% forest, 3% wasteland and built-on
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 52 mi.
PEOPLE: aici
Population: 93,000, average annual growth rate 1.1%
(4/60-4/70)
Ethnic divisions: mainly of African Negro descent; remainder
mixed with some white and East Indian and Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60% unemployed
Organized labor: 10% of labor force
Railroads: none
Highways: 600 mi.; 200 mi. paved; 200 mi. otherwise improved; 200 mi. unimproved
earth
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
Airfields: 3 total; 2 usable, 1 with asphalt runway 4,800 ft.
299
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Telecommunications: islandwide fully automatic telephone system with 4,000
instruments; VHF interisland links to Barbados and the Grenadines; 10,000
radio and 500 TV receivers; 2 AM stations
300
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
SAN MARINO nee .
MGAN MARINO.
LAND:
24 sq. mi.; 74% cultivated, 22% meadows and pastures,
4% built-on
Land boundaries: 21 mi.
Railroads: none
Highways: about 65 mi.
Civil air: no major transport aircraft
Airfields: none
Teleconmunications: automatic telephone system serving 4,020 telephones; no
radiobroadcasting or television facilities, 3,200 radio and 650 TV receivers
(Italian broadcasts)
302
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ea
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
LAND:
55,100 sq. mi.; negligible amount of arable land, meadows
and pastures, 76% forest, 8% unused but potentially
productive, 16% built-on area, wasteland, and other
Land boundaries: 970 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 240 mi.
Railroads: 104 mi.; 54 mi. 3''3 3/8" gage (government owned) and 50 mi.
narrow gage (industrial lines); all single track
Highways: 1,550 mi.; 300 mi. paved, 130 mi. gravel, 370 mi. improved earth,
750 mi. unimproved earth
Inland waterways: 2,850 mi.; most important means of transport; oceangoing
vessels with drafts ranging from 14 to 23 ft. can navigate many of the
principal waterways while native canoes navigate upper reaches
Ports: | major, 6 minor
Civil air: 1 major transport aircraft
Airfields: 31 total, 29 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Teleconmunications: international facilities good; domestic radio-relay
system; 12,200 telephones; 108,000 radio and 33,000 TV receivers, 5 AM,
1 FM, and 3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 109,000; 60,000 fit for military service
332
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
SWAZILAND
LAND:
6,700 sq. mi.s; most of area suitable for crops or
pasture land
Land boundaries: 270 mi.
Railroads: 139 mi., 3''6" gage, single track
Highways: 2,100 mi.; 150 mi. paved; 850 mi. crushed stone, gravel, or stabilized
soil; 1,100 mi. improved or unimproved earth
Civil air: 4 major transport aircraft
Airfields: 29 total, 25 usable; 1 with runway 4,000-7,999 ft.
Telecommunications: the system consists of a few open-wire lines and low-powered
radioconmunication stations; Mbabane is the center; 5,900 telephones; 51,000
‘radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 106,000; 60,000 fit for military service
334
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
LAND:
72,200 sq. mi.; 84% agricultural land (73% pasture, 11%
cropland) 16% forest, urban, waste and other
Land boundaries: 840 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
(fishing 12 n. mi.)
Coastline: 410 mi.
Railroads: 1,870 mi., all standard gage and government owned
Highways: 32,200 mi.; 3,700 mi. paved, 4,600 mi. otherwise surfaced, 9,600 mi.
improved earth, 14,300 mi. earth tracks
Inland waterways: 1,070 mi.; used by coastal and shallow-draft river craft
Freight carried: highways 80% of total cargo traffic, rail 15%, waterways 5%
Ports: 4 major, 6 minor
Civil air: 16 major transport aircraft
Airfields: 101 total, 80 usable; 6 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 10 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: most modern facilities concentrated in Montevideo; 252,000
telephones; 1.5 million radio and 320,000 TV receivers; 68 AM, 3 FM, and 17
TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 733,000; 565,000 fit for military service; no
conscription
366
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
FR. ITALY tev
VATICAN CITY
LAND:
0.169 sq. mi.
Land boundaries: 2 mi.
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Telecommunications: 1 AM and 1 FM radiobroadcasting stations; 2,000-line
automatic telephone exchange
DEFENSE FORCES:
Defense is responsibility of Italy
368
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
\\e
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
VENEZUELA
BRAZIL.
LAND:
352,000 sq. mi.; 4% cropland, 18% pasture, 21% forest,
57% urban, waste, and other
Land boundaries: 2,598 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,740 mi.
Railroads: 233 mi. 4''8 1/2" gage; all single track; 107 mi. government owned,
126 mi. privately owned
Highways: 37,500 mi.; 11,900 mi. paved, 10,200 mi. gravel, 5,400 mi. improved
earth, 10,000 unimproved (including trails)
Inland waterways: 4,450 mi.; Orinoco River and Lake Maracaibo accept oceangoing
vessels
Pipelines: crude oi1, 3,800 mi.; refined products, 250 mi.; natural gas,
1,550 mi.
Ports: 6 major, 17 minor
Civil air: 62 major transport aircraft
Airfields: 463 total, 232 usable; 92 with permanent-surface runways; 7 with
runways 8,000-11,999 ft., 70 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: modern expanding telecom system; satellite ground station;
502,000 telephones; 3 million radio and 1.1 million TV receivers; 150 AM, 50 FM,
and 40 TV stations; 3 submarine cables, including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 2,491,000; 1,710,000 fit for military service;
130,000 reach military age (18) annually
370
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
VIETNAM, NORTH
LAND:
61,300 sq. mi.; 14% cultivated, 50% forested, 36% urban
inland water, and other
Land boundaries: 1,850 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 490 mi. (excluding islands)
Railroads: 602 usable route mi., consists of about 25 mi. of standard gage
(4''8 1/2"), 438 mi. of meter gage (3''3 3/8"), and 139 mi. of dual gage
(4''8 1/2" and 3''3 3/8"); all single track, none electrified; all government
owned and operated; work is again underway to complete the rail line between
Kep and port of Hon Gai
Highways: 13,500 mi., including 900 mi. bituminous surface-treated, 2,100 mi.
gravel, 10,000 mi. improved earth, 500 mi. unimproved earth
Inland waterways: 4,200 mi.; 1,800 mi. navigable perennially by craft drawing 6 ft.
Ports: 3 major, 9 minor
Airfields: 16 total; 11 with permanent-surface runways; 2 with runway 8,000-
11,999 ft., 12 with runways 4,000-7,999 ft.
371
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
VIETNAM, SOUTH
LAND:
66,000 sq. mi.; 25% arable (15% cultivated), 33% forested,
42%','47688de63d074aab986e30817d397259071350f9c825ba2ed7e5501e1581e38c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26fe7752e81b4b6498915535ac54943e419e4fbedb0676c1491ae2cf2a2711cf',1974,'BR','Brazil','communications',19,'other
Land boundaries: 1,025 mi.
WATER:
Limits of territorial waters (claimed): 3.n. mi. : TG es
(fishing, 50 n. mi .) ; HOES a ae INDONESIA”
Coastline: 1,650 mi. eet rads chad
Railroads: 770 mi.; limited section operated by GVN; remainder out of service due
to sabotage and lack of security
Highways: 15,700 mi.; 3,000 mi. bituminous, 3,600 mi. gravel and crushed stone,
3,100 mi. improved earth, 6,000 mi. unimproved earth
Inland waterways: about 6,800 mi. navigable; more than 1,400 mi. navigable at all
times by vessels up to 6 ft. draft
Ports: 6 major, 20 minor
Airfields: 341 total, 160 usable; 63 with permanent-surface runways, 8 with
runways 8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 4 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 4,597,000; 3,005,000 fit for military service;
173,000 reach military age (18) annually
374
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
a
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','05528b5fdaf5242cfef07d8b6d7b41afa72f094fb1279031ecab76420e750e07','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf21b4d7ca3aa593ed2f358a6c971f2de05b16072a8719adfc3158f8edda7ff4',1974,'AR','Argentina','communications',24,'LAND:
1,070,000 sq. mi.; 57% agricultural (11% crops, improved
pasture and fallow, 46% natural grazing land), 25%
forested, 18% mountain, urban, or waste
Land boundaries: 5,850 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
(continental shelf, including sovereignty over
superjacent waters)
Coastline: 3,100 mi.
Railroads: 25,000 mi.; 2,000 mi. standard gage (4''8 1/2"), 13,750 mi. broad
gage (5''6") 8,750 mi. meter gage (3''3 3/8"), 500 mi. 2''5 1/2" gage;
about 1,035 mi. double and multiple track; 76 mi. electrified
Highways: 136,800 mi., of which 21,100 mi. paved, 40,700 mi. gravel, 72,400
mi. improved earth, and 2,600 mi. unimproved earth
Inland waterways: 6,800 navigable mi.
Ports: 7 major, 21 minor
Pipelines: crude oil, 2,310 mi.; refined products, 1,370 mi.; natural gas,
5,500 mi.
Civil air: 53 major transport aircraft ‘
Airfields: 2,807 total, 1,997 usable; 76 with permanent-surface runways;
1 with runway over 12,000 ft., 22 with runways 8,000-11,999 ft., 269 with
runways 4,000-7,999 ft.; 10 seaplane stations
14
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Telecommunications: one of best systems in South America; telephone network has
2,047,000 sets, radio relay widely used, 2 conmunications satellite ground
stations; estimated 7.5 million radio receivers and 3.7 million TV sets; 129
AM, 11 FM, and 55 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 6,242,000; 4,620,000 fit for military service;
average number reaching military age (20) annually about 215,000
Military budget: proposed for fiscal year ending 31 December 1974,
$639,990,000 about 12.8% of total central government budget
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
~&
4
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
STAT
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','7577d6bfc4e1c57b103856c71a8170b94f285f30d66ffdf768794c88cfcb96c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41d835902186d4180d69e25a96958a64f23428a47bc7195767eadacc1f685df4',1974,'AT','Austria','communications',28,'LAND:
32,400 sq. mi.; 20% cultivated, 26% meadows and pastures,
15% waste or urban, 38% forested, 1% inland water
Land boundaries: 1,605 mi.
Railroads: 4,073 mi.; 3,673 mi. government owned; 3,373 mi. standard gage of which
1,408 mi. electrified and 833 mi. double tracked; 300 mi. narrow gage (2''6")
of which 57 mi. electrified; 400 mi. privately owned; 229 mi. standard gage
of which 109 mi. electrified; 171 narrow gage (2''6" and 3''3 3/8") of which
55 mi. electrified
Highways: 20,346 mi. total; 6,056 mi. federal (5,656 mi. bituminous, concrete,
stone biock, 400 mi. crushed stone, gravel, improved earth); 14,290 mi.
provincial (4,340 mi. bituminous, concrete, stone block, 9,950 mi. crushed
stone, gravel, improved earth); additionally about 38,000 mi. of communal
roads, mostly of gravel, crushed stone, and improved earth
Inland waterways: 267 mi.; carries 5% freight, 6% passengers
Ports: 2 major river
Pipelines: crude of], 500 mi.; natural gas, 1,000 mi.
Civil air: 10 major transport aircraft
Airfieids: 66 total, 55 usable; 12 with permanent-surface runways; 2 with run-
ways 8,000-11,999 ft., 10 with runways 4,000-7,999 ft.
Telecommunications: highly developed and efficient; extensive TV and radio-
broadcast systems with 100 AM, 80 FM, and 220 TY stations; 1.8] million
telephones; 2.56 million radio receivers; 1.84 million television receivers;
COMSAT station is planned
DEFENSE FORCES:
Military manpower: males 15-49, 1,686,000; 1,355,000 fit for military service;
average number reaching military age (19) annually about 55,000
Military budget: for fiscal year ending 31 December 1974, $241 million; about
3.8% of the federal budget
20
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','f98a2a7de10fc3255fcd15f4868bc0ba7953e5f83e94212d8f7de8bd20428b66','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ea0fa4a182970b46a62e67bb63d24bed380a4568f3e2e2ab5ee8ccce4e486d3',1974,'BS','Bahamas','communications',32,'LAND:
4,400 sq. mi.3; 1% cultivated, 29% forested, 70% built
on, wasteland, and other
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.}
Coastline: 2,200 mi. (New Providence Is. 47 m.)
Railroads: none
Highways: 1,150 mi.
Ports: 2 major, 9 minor
21
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Civil airs 11 major transport aircraft
Airfields: 58 total, 51 usable; 23 with permanent-surface runways; 3 with
runways 8,000-11,999 ft., 22 with runways 4,000-7,999 ft.; 4 seaplane
stations
Telecommunications: telecom facilities highly developed, including 54, 300
telephones in totally automatic system, tropospheric scatter link with
Florida; 90,000 radio receivers and 28,000 TV sets, 1 AM and 2 FM stations;
3 coaxial submarine cables
22
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
BAHRAIN ‘
yk
IRAQ! IRAN
LAND:
230 sq. mi. plus group of smaller islands; 5% cultivated,
negligible forested area, remainder desert, waste,
or urban
2 SAUDI &
ARABIA
WATER:
Limits of territorial waters (claimed): 3n. mi.
Coastline: 100 mi.','170682936e0f1d902925b40b8e5b59fb7ba6349a04dc5f1f93c8720e9a869d12','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ebd7724b0b5602f8495d2701b3ac4f6fbcfa6cca50be9f829898137502819be',1974,'BD','Bangladesh','communications',39,'Railroads: 1,776 mi.; 1,202 mi. meter gage, 574 mi. broad gage, 87 mi. double
track; government owned
Highways: 28,350 mi.; 2,450 mi. paved; 1,750 mi. gravel, 24,150 mi. earth
Inland waterways: 4,600 mi.; river steamers navigate main waterways
Ports: 1 major; 5 minor
Civil air: 8 major transport aircraft
Airfields: 62 total, 20 usable; 19 with permanent surface runways; 3 with runways
8,000-11,999 ft., 9 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: inadequate international radiocommunications and landline
service; fair domestic wire and radiocommunication service; fair broadcast
service; 52,000 (est.) telephones; 630,000 (est.) radio sets; 30,000 {est.)}
TV sets; 8 AM, 5 FM, and 1 TV station
DEFENSE FORCES:
Military manpower: males 15-49, 15,677,000; 8,425,000 fit for military service
Ships: 4 river patrol boats, 1 seaward defense boat
Supply: military supplies consist of those captured from West Pakistani forces
and materiel provided by India and U.S.S-.R.
Military budget: for fiscal year ending 30 June 1974, $58 million; about 15% of
the central government budget
26
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','7e7b15582a361e35ae9f2b37632dd5be7bdc369dfe707854ff97c0f716b636fe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77e66a1f2a9c3fe56548b33b6dae1953208ef748f778d041122324e96187dc10',1974,'BB','Barbados','communications',40,'LAND:
166 sq. mi.; 60% cropped, 10% permanent meadows, 30% built
on, waste, other
VENEZUELA
WATER:
Limits of territorial waters (claimed): 3 n, mi.
Coastline: 60 mi. COLOMBIA
PEOPLE: Dy BRAZIL
Population: 239,000 (official estimate for 1 duly 1973) 2h
Ethnic divisions: 80% African, 15% mixed, 5% European
Religion: Anglican, Roman Catholic, Methodist, and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1973 est.) wage and salary earners
Organized labor: 32%
Railroads: none
Highways: 850 mi.; 800 mi. paved, and SO mi. gravel, and earth
Ports: 1 major, 2 minor
Civil air: 3 major transport aircraft
Airfields: 1 with permanent-surface runway 8,000-11,999 ft.; 1 seaplane station
Telecommunications: islandwide automatic telephone system with 39,600
telephones; tropospheric scatter link to Trinidad; VHF links to St. Vincent
and St. Lucia; 98,000 radio and 30,000 TV sets, 2 AM, 1 FM, and 1 TV stations;
1 telegraph submarine cable; communications satellite earth station
DEFENSE FORCES:
Military manpower: males 15-49, 49,000; 36,000 fit for military service; average
number reaching military age, (18) annually, 3,000; no conscription
Ships: 4 patrol boats (PB) -- one 65-foot Guardian and three 40-foot vessels
28
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ag
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','8ff8fa14f3f3f0faeb26e2e5d3778a709fca2816821932d08be4e33ef54ab481','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe1cb8f168a4aaa6d806eea2094de6d673466611c5120f76440caf27fb8a9df0',1974,'BE','Belgium','communications',43,'LAND:
11,800 sq. mi.; 28% cultivated, 24% meadow and pasture,
28% waste, urban, or other; 20% forested
Land boundaries: 856 mi.
WATER:
Limits of territorial waters (claimed): 3 n, mi.
(fishing, 12 n. mi.)
Coastline: 40 mi. : ALGERIA
Railroads: 2,746 mi.; 2,573 mi. standard gage and government owned, 1,585 mi.
double track, 765 mi. electrified; 173 mi. privately owned, electrified
narrow gage (3''3 3/8")
Highways: 57,700 mi.; 26,550 mi. bituminous, stone block, or concrete; 31,150
mi. crushed stone, gravel, earth
Inland waterways: 1,270 mi., of which 950 are in regular use by commercial
transport
Ports: 5 major, 1 minor
Pipelines: refined products, 600 mi.; crude, 100 mi.; natural gas. 145 mi.
Civil air: 55 major transport aircraft
Airfields: 55 total, 42 usable; 22 with permanent-surface runways; 13 with
runways 8,000-11,999 ft., 6 with runways 4,000-7,999 ft.
Telecommunications: excellent domestic and international telephone and telegraph
facilities; 2.43 million telephones; 3.83 million radio receivers; 2.61 million
TV receivers; 7 AM, 11 FM, and 21 TV stations; 5 coaxial submarine cables;
communications satellite station
DEFENSE FORCES:
Military manpower: males 15-49, 2,23,000; 1,790,000 fit for military service;
average number reaching military age (19) annually 74,000
30
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
4
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
BELIZE (formerly British Honduras)
4 LAND:
8,870 sq. mi.; 38% agricultural (5% cultivated), 46%
exploitable forest, 16% urban, waste, water,
offshore islands or other '' Bye Ay
Land boundaries: 320 mi. a io
ad WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 240 mi.
Railroads: none
Highways: 1,400 mi.; 200 mi. paved, 500 mi. gravel, 550 mi. improved earth
and 150 mi. unimproved earth
Inland waterways: 514 mi. river network used by shallow-draft craft
Ports: 1 major, 4 minor
Civil air: no major transport aircraft
Airfields: 52 total, 31 usable; 3 with permanent-surface runways; 1 with runway
4,000-7,999 ft.; 1 seaplane station
Telecommunications: 3,700 telephones in automatic and manual network; radio-relay
system under construction; over 67,500 radio receivers; 2 AM stations
DEFENSE FORCES:
Military manpower: males 15-49, 29,000; 17,000 fit for military service; 1,500
reach military age (18) annually
32
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','0b71bbf400082ec8ada36d25c8f556aa54bcb21a3276dab8fb739bdf99a82a26','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db64bfae8f87a298d057bfb7a414836ae49043390fcd0e1f9fdec65ba195e527',1974,'BM','Bermuda','communications',47,'LAND:
21 sq. mi.; 8% arable, 60% forested, 21% built on,
wasteland, and other, 11% leased for air and
naval bases
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 64 mi.
Railroads: none
Highways: 130 mi., all paved
Ports: 3 major
Civil air: no major transport aircraft
Airfields: 1 with concrete runway 9,660 ft.; 1 seaplane station
33
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Telecommunications: modern telecom system suited to island needs, includes fully
automatic telephone system with 34,900 instruments; 49,000 radio and 21,500
TY receivers, 2 AM, 2 FM, and 2 TV stations; 3 coaxial submarine cables
34
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','622710423440e8c7ea73573a34300a4f4efedaab77043e3b0cd4007fa8d8f3b6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5273cbd16165639f1127f9c5ad8ced9a4b15f332d472df8caf68889d2e1120e0',1974,'BT','Bhutan','communications',51,'LAND:
18,000 sq. mi.s 15% agricultural, 15% desert, waste,
urban, 70% forested
Land boundaries: about 540 mi.
Highways: 810 mi.; 260 mi. surfaced, 320 mi. improved, 230 mi. unimproved earth
s Freight carried: not available, very light traffic
Civil afr: no major transport aircraft
35
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Airfields: 1 asphalt runway 4,500 ft.
Telecommunications: facilities almost nonexistent; 570 telephones; 6,000 radio
sets; no TV sets; data not available on AM; no FM; and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 233,000; 121,000 fit for military service;
about 8,000 reach military age (18) annually
Supply: dependent on India
36
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
BOLIVIA','035d8e9284fdddc7b87d41ac2e4c85a058cd7bbd233d73cfdb69fc5866b21259','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ee5329583f60e8a51256a9d820bd0c4e34494a96d9b7b41ecbab2c5bc4ce932',1974,'BW','Botswana','communications',56,'LAND:
220,000 sq. mi.; about 6% arable, less than 1%
under cultivation, mostly desert
Land boundaries: 2,345 mi.
Railroads: 400 mi. 3''6" gage, single track; owned and operated by the Rhodesia
Railroads
Highways: 4,835 mi.; 483 mi. crushed stone or gravel; remainder improved earth
and unimproved earth
Inland waterways: native craft only; of local importance
Civil air: 10 major transport aircraft
Airfields: 84 total, 70 usable; 2 with permanent-surface runways; 17 with
runways 4,000-7,999 ft.
Telecommunications: the system is a minimal combination of a single main wire
line and a few radiocommunication stations; Gaborone is the center; 5,620
telephones; 50,000 radio receivers; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 154,000; 80,000 fit for military service; 8,000
reach military age (18) annually
No military; police, 1,400
40
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','52d8610c47ee75011ed8f91b147b0368fdc3af1d54ec54b3883c992abac6bacc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('629f8eb21203c29b5177c69139dc2583aba8cef0528c60948e293add77b5284a',1974,'CG','Congo','communications',78,'LAND: es
135,000 sq. mi.; 63% dense forest or woodTand, 33% 2
cultivable or grazing (2% cultivated est.), 4% urban
or waste
Land boundaries: 2,805 mi.
- WATER:
Limits of territorial waters (claimed): 15 n. mt.
Coastline: 105 mi.','cae3e06688b3288cbb8a55e4d81238f1cb9e8afc91dccad9bac15fb1206a5acc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f382147d3aa05f862e2d3857475f0b354870f8d2af3d0971d6fac64f736e6cfa',1974,'CK','Cook Islands','communications',84,'Railroads: none
Highways: 162 mi.: 12 mi. paved, 68 mi. gravel, 52 mi. improved earth, 30 mi.
unimproved earth
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 4 total; 1 with composite surface runway 7,240 ft., 3 with natural
surface runways 4,000-7,900 ft.; 1 seaplane station
Telecommunications: 2 AM broadcast stations, 8,000 radio receivers, and 614
« telephones; microwave relay station provides connection with New Zealand
75
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','332182fae38dfce43a05a7a9eba77f253484802eb5067dfb87ba345fbb949687','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f89aff3fa1837292004db87771b880ee99325be27054798984d2f8b7c7f21fe4',1974,'CR','Costa Rica','communications',85,'LAND:
19,700 sq. mi.; 30% agricultural land (8% cultivated, 22%
meadows and pasture), 60% forested, 10% waste, urban,
and other
Land boundaries: 415 mi.
{VENEZUELA
4) COLOMBIA
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing
200 n. mi.; "specialized competence" over living e BRAZIL
resources to 200 n. mi.) saa es
Coastline: 800 mi.
PEQPLE:
Population: 1,955,000, average annual growth rate 3%
(7/71-7/72)
Ethnic divisions: 98% white (including mestizo), 2% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 85%
Labor force: 530,000 (1970); 46.3% agriculture; 13.2% manufacturing; 11% commerce;
8% construction, transportation, and communications; 21.5% other; shortage
of skilled labor (1968)
Organized labor: about 6% of labor force
Railroads: 407 mi.; 395 mi. 3''6" gage, 12 mi. 3''O" gage, all single track, 72 mi.
electrified
Highways: 13,700 mi.; 1,000 mi. paved, 3,800 mi. otherwise improved, 8,900 mi.
unimproved earth
Inland waterways: about 455 mi. perennially navigable
Pipelines: refined products, 80 mi.
Ports: 3 major, 4 minor
Civil air: 23 major transport aircraft
Airfields: 214 total, 130 usable; 11 with permanent~surface runways; 10 with
runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: good domestic telephone service; 85,400 telephones;
connection into Central American microwave net; 345,000 radio and 130,000 TV
receivers; 44 AM, 8 FM, and 11 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 424,000; 290,000 fit for military service; average
number reaching military age (18) annually about 24,000
Supply: dependent on imports from U.S.
78
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','c09f53dfd26deb1b00e70fe6cc390c3eac88176d936993e86493d8b09d0e1e99','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d04cf65ca59a074b74d57f89477d03bb49ccd782490ba7a1644cb3768ef5ee0',1974,'CU','Cuba','communications',88,'LAND:
44,200 sq. mi.; 35% cultivated, 30% meadow and pasture,
20% waste, urban, or other, 15% forested
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 2,320 mi.
Railroads: 9,150 mi. government owned; 3,150 mi. common carrier lines (8 mi.
double track and 95 mi. electrified) and about 6,000 mi. plantation-
industrial lines; common carrier lines comprise 3,100 mi. 4''8 1/2" standard
gage, and about 50 mi. 3''0" and 2''6" narrow gage; plantation-industrial
lines comprise about 4,000 mi. standard gage and 2,000 mi. narrow gage
Highways: 12,800 mi.; 5,400 mi. paved, 7,400 mi. gravel and earth surfaced
Inland waterways: 150 mi.
Pipelines: natural gas, 50 mi.
Ports: 8 major (including U.S. Naval Base at Guantanamo), 44 minor; Guantanamo
under U.S. control
Civil air: 33 major transport aircraft
Airfields: 378 total, 194 usable; 42 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 27 with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: modern facilities adequately serve military and most civil
needs; excellent international facilities, satellite ground station; 325,000
telephones; 1.8 million radio and 600,000 TV receivers; 100 AM, 25 FM, and
23 TV stations; 6 submarine cables, including 7 coaxial
80
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','e6a9cdd0ec39b10a18f95ab3d1a19978dfdbdb1716716fec81b1978ee9a7ac81','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2859266f69bbcab5ac7514c6c78e5c248dbd537843b6b964d4ca86dca992938',1974,'CY','Cyprus','communications',92,'LAND : TURKEY
3,572 sq. mi.; 47% arable and land under permanent crops,
18% forested, 10% meadows and pasture, 25% waste,
urban areas, and other
WATER:
# Limits of territorial waters (claimed): 12 n. mi. ‘ SAUDI
Coastline: 400 mi. (approx. ) ARADIA
Railroads: none
Highways: 5,000 mi.; 2,100 mi. bituminous surface treated; 2,900 mi. gravel,
crushed stone, and earth
Ports: 3 major, 6 minor
Civil air: 9 major transport aircraft
Airfields: 20 total, 12 usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft.; 3 with runways 4,000-7,999 ft.
Telecommunications: moderately good telecommunication system; 58,100 telephones;
182,700 radio receivers; 71,300 TY receivers; 12 AM, 6 FM, and 4 TV stations;
tropospheric scatter circuits to Greece and Turkey
82
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
CZECHOSLOVAKIA
LAND:
49,400 sq. mi.; 42% arable, 14% other agricultural, 35%
forested, 9% other
Land boundaries: 2,200 mi.
Railroads: 8,262 mi.; 8,080 mi. standard gage, 70 mi. broad gage, 110 mi. narrow
gages 1,713 mi. double track; 1,610 mi. electrified; government owned (1974)
Highways: 45,558 mi.; 808 mi. concrete; 28,700 mi. bituminous; 2,400 mi.
cobblestone, brick sett, stone block: 13,650 mi. crushed stone, gravel,
improved earth (1973)
Inland waterways: 517 mi. (1974)
Pipelines: crude oi1, 900 mi.; refined products, 535 mi.; natural gas, 3,000 mi.
Freight carried: rail -- 248.9 million short tons, 41.2 billion short ton/mi.
(1972); highway -- 901.4 million short tons, 8.1 billion short ton/mi. (1972);
waterway -~ 9.4 million short tons, 2.4 billion short ton/mi. (incl. int''l.
transit traffic) (1973)
Ports: no maritime ports; outlets are Gdynia, Gdansk, Stettin in Poland; Rijeka,
Yugostavia; Hamburg, West Germany; Rostock, East Germany; principal river
ports are Prague, Melnik, Usti nad Labem, Decin, Komarno, Bratislava (1974)
Civil air: 50 major transport aircraft (1974)
Airfields; 134 total; 33 with permanent-surface runways; 19 with runways
8,000-11,999 ft., 49 with runways 4,000-7,999 ft.
84
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
DAHOMEY
LAND:
44,700 sq. mi.s; southern third of country is most fertile;
arable land 80% (actually cultivated 11%), forests and
game preserves 19%, non-arable 1%
Land boundaries: 1,220 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (100 n.
mi. mineral exploitation limit)
Coastline: 75 mi.
Railroads: 360 mi., all meter gage (3''3 3/8")
Highways: 4,300 mi.; 547 mi. paved, 2,665 mi. gravel and/or improved earth,
remainder unimproved
Inland waterways: 400 mi. navigable
Ports: 1 major, 1 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 10,600 GRT, 13,300 DWT (C)
Civil air: no major transport aircraft
Airfields: 11 total, 10 usable; 1 with permanent-surface runway; 4 with runways
4,000-7,999 ft.
Telecommunications: telephone service concentrated in south; telegraph limited,
but more extensive than telephone; 6,500 telephones; 54,000 radio receivers;
2 AM, no FM, and no TV stations; 3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 700,000; 335,000 fit for military service; about
30,000 males and 29,000 females reach military age (18) annually; both sexes
liable for military service
86
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','1debdaab26f96510123d068061366530e7261eed21f016e72dc8f66163474b22','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('259960dc68516249eccafadad3143bb4ba974ca13ae09b4a7ed86ee24267c147',1974,'DK','Denmark','communications',96,'LAND:
16,600 sq. mi. (exclusive of Greenland and Faeroe Islands);
64% arable, 8% meadows and pastures, 11% forested, 17%
other
Land boundaries: 42 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing
12 n. mi.)
Coastline: 2,100 mi.
Railroads: 1,810 mi. Danish State Railways (DSB); 1,467 mi. standard gage (4''8 1/2"),
52 mi. electrified and 453 mi. double tracked; remaining 349 mi. of standard
gage lines are privately owned and operated
Highways: 38,295 mi.; 31,196 mi. concrete, bitumen, or stone block; 5,645 mi.
gravel and crushed stone; 1,454 mi. improved earth
Inland waterways: 259 mi.
Pipelines: refined products, 260 mi.
Ports: 16 major, 44 minor
Civil air: 102 major transport aircraft (including 4 belonging to Greenland)
Airfields: 140 total, 116 usable; 19 with permanent-surface runways; 8 with run-
ways 8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: excellent telephone, telegraph, and broadcast services;
2,007,000 telephones; 1,676,000 radiobroadcast receivers; 1,660,000 TY
receivers; 4 AM, 13 FM, and 30 TV stations; 14 submarine coaxial cables
DEFENSE FORCES:
Military manpower: males 15-49, 1,195,000; 1,050,000 fit for military service;
38,000 reach military age (20) annually
8&8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','7e8aff525dc863b6982d3fc7b63d5e7fe787deaba37e5c9f35bc6fc7f0da95e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5d318133c74f0d62a14c5770f679209c716af27457f41f3647596d717abbe28',1974,'DM','Dominica','communications',100,'LAND:
305 sq. mi.; 24% arable, 2% pasture, 67% forests, 7%
other
WATER: VENEZUELA
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 92 mi.','159010d58380761778f0288dbb5c4a92ceebe3f22245da233ab89a76ded10d69','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f08543340d8adb0a696c3b7e3361e5d8e64d03b1840f7845cebf560f1995fc5a',1974,'CO','Colombia','communications',104,'Railroads: none
Highways: 460 mi.; 230 mi. paved, 160 mi. gravel, crushed stone, or stabilized
earth surface, 70 mi. unimproved
Ports: 2 minor
89
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Civil air: no major transport aircraft
Airfields: 1 with asphalt runway 4,830 ft.
Telecommunications: 2,860 telephones in fully automatic network; VHF link to
St. Lucia; 15,000 radio receivers; 100 TV receivers; 1 AM station
90
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
WATER:
aa
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 75 mi.
Railroads: none
Highways: 600 mi.; 380 mi. paved, 100 mi. gravel, crushed stone, or earth
surface; 120 mi. unimproved
Ports: 1 major, | minor
Civil air: no major transport aircraft
Airfields: 4 total, 3 usable; 1 with asphalt runway 5,000 ft.
Telecommunications: automatic, islandwide telephone system with 4,630 telephones ;
VHF Tinks to Trinidad and Carriacou; 20,000 radios and 100 TV receivers;
3 AM stations
140
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','32b96b40def4d95023f570e9f420267091c28dbe379c042b44c30faf5a295771','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6d11fb2dd3f48276b0eb6d587d75581baa57ef0347f5e3caa8a12699eefd9f7',1974,'DO','Dominican Republic','communications',105,'LAND:
18,800 sq. mi.; 14% cultivated, 4% fallow, 17% meadows
and pastures, 45% forested, 20% built-on or waste
Land boundaries: 224 mi.
y- { VENEZUELA
PANAMA’
WATER: f : i : j COLOMBIA
Limits of territorial waters (claimed): 6 n. mi. (fishing a Spyies
12 n. mi.) DPSS
Coastline: 800 mi. Hee oe BRAZIL
Railroads: 1,000 route mi. of which 65 mi. government-owned common carrier
(3''6" gage) and 935 mi. privately owned plantation network (approximately 4
different gages ranging from 1''10 1/2" to 4''8 1/2", with 2''6" predominating)
Highways: 6,700 mi.; 3,250 mi. paved, 3,450 mi. gravel and improved earth
Pipelines: product lines (1.5 mi. and 43 mi.) under construction
Ports: 5 major, 17 minor
Civil air: 14 major transport aircraft
Airfields: 66 total, 43 usable; 6 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: relatively efficient domestic system based on islandwide
radio relay network; 74,700 telephones; 500,000 radio and 180,000 TV receivers,
101 AM, 31 FM, and 1] TV stations; 3 submarine cables, including 1 coaxial;
planned COMSAT station
DEFENSE FORCES:
Military manpower: males 15-49, 1,036,000; 655,000 fit for military service; 52,000
reach military age (18) annually
92
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','f37fce7de0b7068b5ed0bade764fd4923c0d4dd279c6a4d401d3497b9c7dabd6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c67c7039f8b4bdb138226fa853b3bdd5240d909d5db5b4872f5661d895fab7c',1974,'EC','Ecuador','communications',109,'LAND: : BRAZIL
106,000 sq. mi. (including Galapagos Islands); 11% :
cultivated, 8% meadows and pastures, 55% forested,
26% waste, urban, or other (excludes the Oriente
and the Galapagos Islands, for which information is
not available)
Land boundaries: 1,200 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,390 mi. (includes Galapagos Is.)
Railroads: 660 mi.; 615 mi. 3''6" gage, 46 mi. 2''5 1/2" gage; all single track
Highways: 14,200 mi.; 1,900 mi. paved, 5,000 mi. gravel, 1,800 mi. improved
earth, 5,500 mi. unimproved earth
Inland waterways: 960 mi.
Pipelines: crude oi], 390 mi.; refined products, 50 mi.
Ports: 2 major, 11 minor
Civil air: 46 major transport aircraft (includes 5 military/commercial transports )
Airfields: 200 total, 178 usable; 15 with permanent-surface runways 5 6 with
runways 8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 3 seaplane stations
Teleconmmunications: facilities adequate only in largest cities; satellite ground
station; 126,000 telephones; 690,000 radio and 160,000 TV receivers; 240 AM,
38 FM, and 15 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,606,000; 1,020,000 fit for military service;
average number reaching military age (20) annually 66,000
94
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','672b12279e0af3ac7473df060c85b46270926a98c3799a67dba468338232eb2b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('042e3fbb3009149ebe4c1b7a5a414cd103c61501e763a01a351af9e53dacabe6',1974,'EG','Egypt','communications',113,'LAND:
386,200 sq. mi. (including 22,200 sq. mi. occupied by
Israel); 2.8% cultivated (of which about 70% multiple
cropped); 96.5% desert, waste, or urban; 0.7% inland
water
Land boundaries: 1,570 mi. (1967), excludes occupied area
1,534 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (plus
6n. mi. "necessary supervision zone")
Coastline: 2,140 mi. (1967), excludes occupied area 1,340 mi.
Railroads: 3,358 mi.; 570 mi. double track; 15 mi. electrified; 2,976 mi. 4''8 1/2"
gage, 156 mi. 3''3 3/8" gage, 226 mi. 2''5 1/2" gage
Highways: 29,000 mi.; 5,190 mi. paved, 7,130 mi. gravel, crushed stone, and
improved earth, 16,680 mi. unimproved earth, additional 1,150 mi. (mostly
paved) in territory (Sinai) occupied by Israel
Inland waterways: 2,100 mi.;. Suez Canal, 100 mi. long, temporarily closed to
navigation because of sunken vessels; normally used by ocean-going vessels
drawing up to 38 ft. of water; Alexandria-Cairo waterway navigable by barges
of 500-ton capacity; Nile and large canals by barges of 420-ton capacity;
Ismailia Canal by barges of 200- to 300-ton capacity; secondary canals by
sailing craft of 10- to 70-ton capacity
Freight carried: Suez Canal (1966) -- 242 million tons of which 175.6 million
tons were POL
Pipelines: crude oi], 185 mi.; refined products, 390 mi.; natural gas, 30 mi.
Ports: 3 major, 8 minor
Civil air: 16 major transport aircraft
Airfields: 159 total, 79 usable; 69 with permanent-surface runways; 42 with
runways 8,000-11,999 ft., 21 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: second best system of coaxial and multiconductor cables,
open-wire lines, and radio communication stations in Africa; principal centers
Alexandria and Cairo, secondary centers Al Mansurah, Ismailia, and Tanta;
365,000 telephones; 5.1 million radio and 600,000 TV receivers; 12 AM, 1 FM,
and 26 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,347,000; 5,280,000 fit for military service;
about 375,000 reach military age (20) annually
96
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
iT
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','8cccda590c6fdc6ee3204f5b0e125597ad8ef6d672defd73a6743bb5acc7fcb4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65e8392044f16ea2d8d2e8cbe330f8b49514306f3673f04adece8f30d6cae43b',1974,'SV','El Salvador','communications',117,'LAND:
, 8,260 sq. mi.; 32% cropland (9% corn, 5% cotton, 7%
coffee, 11% other), 26% meadows and pastures, 31%
nonagricultural, 11% forested
Land boundaries: 320 mi.
ret
EL SALVADOR.
COSTA RICA &
foe 4 VENEZUELA
SEO PANAMA? ie
, COLOMBIA
aoe)
: PERU “ BRAZIL
~~» WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 190 mi.
Railroads: 375 mi., 3''0" gages single-tracked; 285 mi. privately owned, 90 mi.
government owned
Highways: 5,400 mi.; 750 mi. bituminous, 950 mi. gravel or crushed stone, 3,700 mi.
earth
Inland waterways: Lempa River partially navigable
Ports: 3 major, 1 minor
Civil air: 7 major transport aircraft
Airfields: 151 total, 123 usable; 8 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: nationwide trunk radio relay system; connection into Central
American microwave net; 45,100 telephones; 500,000 radio and 110,000 TV
receivers; 57 AM, 6 FM, and 5 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 895,000; 545,000 fit for military service;
44,000 reach military age (18) annually
98
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','dc4510edc465120464e8dc182dbe9e87a96583fd316a41ea2094509357505454','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c59093c63a082c5bb049c2869b34374963c3d22a0fa897ea78904fd0267bf94',1974,'GQ','Equatorial Guinea','communications',121,'LAND: AS ea eee
10,800 sq. mi.; Rio Muni, about 10,000 sq. mi., largely os ye
forested; Fernando Po, about 800 sq. mi. i
Land boundaries: 335 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 184 mi.
Railroads: none
Highways: Rto Muni -- 1,553 mi., including approx. 115 mi. bituminous,
remainder gravel and earth; Fernando Po -- 186 mi., including 91 mi.
bituminous, remainder gravel and earth
Inland waterways: Rio Muni has approximately 104 mi. of year-round navigable
waterway, used mostly by pirogues
Ports: 2 major, 3 minor
Civil air: no major transport aircraft
Airfields: 5 total, 3 usable; 2 with permanent-surface runways; | with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: fairly adequate for the size and stage of development of the
country; international communications by radio from Bata and Santa Isabel
to Cameroon, Nigeria, and Spain; 1,500 telephones; 76,000 radio receivers;
2 AM, no FM, and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 73,000; 37,000 fit for military service
100
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','cb83fbd172cb40af5b774107be59b74cdbea3ff0ee10d7555d3992d4704e7312','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6931e596fda5da12c5f5204d75dd8ef2980b5cab8aaee18d13ea8dcff2e56b2',1974,'ET','Ethiopia','communications',125,'LAND:
455,000 sq. mi.; 10% cropland and orchards, 55% meadows
and natural pastures, 6% forests and woodlands,
29% wasteland, built-on areas, and other
Land boundaries: 3,230 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
sedentary fisheries extends to limit of fisheries
Coastline: 680 mi. {includes offshore islands}
Railroads: 630 mi.; 420 mi. 3''3 3/8" gage, 20 mi. 3''6" gage, 190 mi. 3''1
3/8" gage; all single track
Highways: 14,500 mi.; 1,250 mi. bituminous, 3,000 mi. crushed stone, gravel, or
stabilized earth, 10,250 mi. earth
Inland waterways: navigation possible on Lake Tana and on approx. 140 mi. of
unconnected and basically unimproved waterways, of which only 71 mi. are
navigable year round
Ports: 2 major, |] minor
Civil air: 16 major transport aircraft
Airfields: 204 total, 114 usable; 7 with permanent-surface runways; 1 with runway
over 12,000 ft., 4 with runways 8,000-11,999 ft., 48 with runways 4,000-7,999 ft.
Telecommunications: system better than most African countries; composed of
open-wire lines, radiocommunication stations, and small number of multi-
conductor cable and radio-relay links; principal center Addis Ababa, secondary
center Asmara; 54,500 telephones; 500,000 radio receivers; 20,000 TV receivers;
5 AM, no FM, and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 6,869,000; 3,550,000 fit for military service;
average number reaching military age (18) annually 265,000
102
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
FAEROE ISLANDS
LAND:
540 sq. mi.; less than 5% arable, of which only a fraction
cultivated; archipelago consisting of 18 inhabited
islands and a few uninhabited islets
WATER:
Limits of territorial waters (claimed): 3 n. mi.;
fishing, 12 n. mi. (from extended base lines)
Coastline: 475 mi.
2, FRANCE ,
Railroads: none
Highways: none
Ports: 1 minor
Airfields: 1 with permanent-surface runway, less than 4,000 ft.
Civil air: no major transport aircraft
Telecommunications: good internationational conmunications; fair domes tic
facilities; 9,500 telephones, 12,000 radio receivers; 1 AM, and 3 FM stations
3 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49 included with Denmark
104
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
FALKLAND ISLANDS (MALVINAS )*','0508b32ca72031cf5d0c1264b4903eb5ef83e7c3cb3059c62844c5cc6c70c6c9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec3827cfed85b8540c819f5d18b20ad4fa0f608f8317c2760385a40b19949f88',1974,'FJ','Fiji','communications',129,'LAND:
7,055 sq. mi.; landownership -- 83.6% Fijians, 1.7% Indians,
6.4% government, 7.2% European, 1.1% other; about 30%
of land area is suitable for farming','ed4166a146ecc97e2df1005b7562bdb1d520326a85e919ced0141b26c0a4c393','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f144f4523f1eb1481e45679847c616ab2718ef2fc4d1e8ade087042feef1d862',1974,'AU','Australia','communications',130,'WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 700 mi. (est.)
Railroads: none
Highways: 1,599 mi.; 172 mi. paved, 1,427 mi. gravel or crushed stone
Inland waterways: 126 mi.; 76 mi. navigable by motorized craft and 200-ton barges
107
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Ports: 1 major, 6 minor
Civil air: 4 major transport aircraft
Airfields: 20, 15 usable; 1 with runway 8,000-11,999 ft., 1 with runway 4,000-7,999
ft., 2 seaplane stations
Telecommunications: modern local, interistand, and international (wire/radio
integrated) public and special-purpose telephone, telegraph, and teleprinter
facilities; regional radio center; important COMPAC cable link between
U.S./Canada and New Zealand/Australia, et al; 21,552 telephones; 250,000
radio receivers; 10 AM, 2 FM and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 143,000; 76,000 fit for military service; 6,000
reach military age (18) annually
Military budget: the defense of the Fiji Islands was the responsibility of the
U.K. until 10 October 1970; military budget for 1971, $314,000
108
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Railroads: 4,364 mi.; 3,990 mi. 3''6" gage, 317 mi. 2''5 1/2" gage, 57 mi.
1''11 5/8" gage; 132 mi. double track; 74 mi. electrified; government owned
Highways: 57,460 mi.; 12,600 mi. paved, 25,200 mi. gravel or crushed stone,
19,660 mi. improved or unimproved earth
Inland waterways: 13,410 mi.; Sumatra 3,400 mi., Java and Madura 510 mi., Borneo
6,500 mi., Celebes 150 mi., and Irian Barat 2,850 mi.
Ports: 10 major, 63 minor
Civil air: 95 major transport aircraft (includes 2 leased)
Airtields: 366 total, 252 usable; 40 with permanent-surface runways; 8 with
runways 8,000-11,999 ft., 64 with runways 4,000-7,999 ft.; 11 seaplane
stations
Telecommunications: extensive police net for interisland service; international
and domestic service fair but improving; radiobroadcast coverage adequate
but TV limited to Java only; 240,210 telephones; 5 million radio and 236,828
TV sets; AM stations at over 50 locations; 1 FM and 13 TV stations; 1 earth
satellite station on Java; 2 submarine cables to Singapore no longer in service
162
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
IRAN
r) LAND:
636,000 sq. mi.3; 14% agricultural, 11% forested, 16%
cultivable with adequate irrigation, 51% desert,
waste, or urban, 8% migratory grazing and other
Land boundaries: 3,305 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 50 n. mi.)
Coastline: 1,980 mi., including islands, 420 mi.
Railroads: 2,373 mi. 4''8 1/2" gage, 57 mi. 5''6" gage
Highways: 27,000 mi.; 7,500 mi. bituminous and bituminous treatment, 14,250 mi.
gravel and crushed stone, 5,250 mi. improved earth
Eland waterways: 565 mi., excluding the Caspian Sea, 64.6 mi. on the Shatt
al Arab
Pipelines: crude oi], 1,640 mi.; refined products, 2,235 mi.; natural gas,
1,440 mi.
Ports: 7 major, 6 minor
Civil air: 21 major transport aircraft
Airfields: 245 total, 146 usable; 53 with permanent-surface runways; 8 with
runways over 12,000 ft., 16 with runways 8,000-11,999 ft., 53 with runways
4,000-7,999 ft.
Telecommunications: advanced system of high-capacity radio-relay links, open-wire
lines, cables, and tropospheric links; principal center Teheran, secondary
centers Isfahan, Meshed, and Tabriz; 447,100 telephones; 1.9 million radio
and 400,000 TV receivers; 20 AM, 1 FM, and 9 TV stations; satellite earth
station
DEFENSE FORCES:
Military manpower: males 15-49, 7,469,000; 4,455,000 fit for military service;
about 327,000 reach military age (21) annually
164
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
TRAQ
LAND:
172,000 sq. mi.; 18% cultivated, 68% desert, waste, or
urban, 10% seasonal and other grazing land, 4% forest
and woodland
Land boundaries: 2,280 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 36 mi.
Railroads: 1,408 mi.; 698 mi. 4''8 1/2" gage, 710 mi. meter (3''3 3/8") gage;
10 mi. meter gage double track
Highways: 12,919 mi.; 4,033 mi. paved; 2,886 mi. crushed stone, gravel, or
improved earth; 6,000 mi. earth and sand tracks
Inland waterways: 635 mi.; Shatt al Arab navigable by maritime traffic for
about 65 mi.; Tigris and Euphrates navigable by shallow-draft steamers
Ports: 3 major
Pipelines: crude oil, 1,660 mi.; 25 mi. refined products; 430 mi. natural gas
Civil air: 6 major transport aircraft
Airfields: 178 total, 75 usable; 23 with permanent-surface runways; 42 with
runways 8,000-11,999 ft., 18 with runways 4,000-7,999 ft.
Telecommunications: fair international radiocommunication service; poor
domestic telephone and telegraph service; 121,500 telephones; 1.25 million
radio receivers; 251,000 TV receivers; 4 TV and 4 AM stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,395,000; 1,295,000 fit for military service;
about 122,000 reach military age (18) annually
166
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Railroads: 1,130 route mi.; 885 mi. broad gage (5''0") (1973)
Inland waterways: 585 mi. navigable; used primarily for local transport
Freight carried: rail -- 5.1 million short tons, 1,046 million short ton mi.
(1972); highway -- about 10 million short tons (1970); 415.1 million short
ton/mi. (1970); waterway -- 2.5 million short ton/mi. (1970)
Airfields: 42 total; 6 with permanent-surface runways; 25 with runways 8,000-
12,999 ft., 11 with runways 4,000-7,999 ft., 6 additional airfields under
4,000 ft.
234
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
WATER:
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: about 3,200 mi.
Papua:
Railroads: none
Highways: approx. 2,480 mi.; about 1,360 mi. suitable for heavy and medium
traffic, and about 1,120 mi. suitable for light traffic
Inland waterways: 800 mi., not including minor rivers
Ports: 1 principal (Port Moresby), 1 secondary
Civil air: see New Guinea (below)
Airfields: see New Guinea (below)
Telecommunications: see New Guinea (below)
New Guinea:
Railroads: none
Highways: approx. 6,430 mi.; approx. 3,865 mi. suitable for heavy and medium
traffic, and 2,565 mi. suitable for light traffic only
Inland waterways: 1,350 mi., northeast New Guinea; minor rivers not included
Pipelines: crude oil, 87 mi.
Ports: 4 principal (Rabaul, Lae, Madang, Kavieng), 4 minor
Civil air: 20 major transport aircraft; Air Niugini, new national airline,
began operations in November 1973
Airfields: 655 total, 456 usable; 12 with permanent-surface runways; 46 with
runways 4,000-7,999 ft.; 1 with runway 8,000 ft. -- Nadzab
Telecommunications: Papua New Guinea telecom services are adequate and are
being improved; principal telecom centers include Goroka, Lae, Madang,
Mount Hagen, and Wewak in New Guinea; and Daru, Port Moresby and Samarai
in Papua; facilities provide radiobroadcast, radiotelephone and telegraph,
coastal radio, aeronautical radio and international radiocommunication
services; numerous privately owned radio facilities exist; submarine
cables extend from Madang to Australia and Guam; 25,300 telephones, 100,000
radios, but no TV sets; 29 AM, no FM and no TV facilities
DEFENSE FORCES:
Military manpower: males 15-49, 637,000 (Papua 168,000, New Guinea 469,000)
about 325,000 fit for military service (Papua 85,000, New Guinea 240 ,000)
Defense is responsibility of Australia
268
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 400 mi.
Railroads: none
Highways: 463 mi.; 293 mi, gravel or crushed stone, 170 mi. improved and
unimproved earth
Inland waterways: none
Ports: 1 minor
Airfields: 15 total, 12 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 3. with, runways, 4,000-7,999, ft.; 1 seaplane station
Telecommunications: domestic and international radio stations used primarily
for administrative and military purposes; 1 low-power radiobroadcast station;
unreliable open-wire Tines and 58 small manual switchboards serve 794
telephones; 13,200 radio sets
284
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','65045a9a4bc81dc0b9369618588a21c992ebac23c35fd82f181f4b8b16f7ec8a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('012e62eea6c873d4a709ae69fc1a074c7ce116e1909d371f92f31d736d438d45',1974,'FI','Finland','communications',134,'LAND:
* 130,000 sq. mi.; 8% arable, 58% forested, 34% other
Land boundaries: 1,575 mi.
WATER:
Limits of territorial waters (claimed): 4 n, mi.;
“s Aland Islands, 3 n. mi.
Coastline: 700 mi. (approx.) includes islands
: : Saupe,
PEOPLE: HIBWA JEGYPEVanagia Tis
Population: 4,663,000, average annual growth rate 0.4%
(7/72-7/73)
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox, 1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and Russian-speaking minorities
Literacy: 99%
Labor force: 2.3 million; 28.1% agriculture, forestry, and fishing, 24.2% mining
and manufacturing, 9.0% construction, 13.7% commerce, 6.6% transportation and
communications, 16.5% services; 2.8% unemployed
Organized labor: 60% of labor force
Railroads: 3,676 mi.; Finnish State Railways (VR) operate a total
3,658 mi. broad gage (5''0"), 288 mi. multiple track, and 68 mi. electrified;
14 mi. narrow gage (2'' 5 1/2") and 4 mi. broad gage are privately owned
Highways: 44,660 mi.; 12,060 mi. bituminous, 31,900 mi. stablized gravel, 700
mi. gravel and earth; 12,400 mi. of private roads (surface type na)
Inland waterways: 4,100 mi. total (including Saimaa Canal); 2,300 mi. suitable
for steamers; canal locks (275 ft. by 42 ft. with a 16.7 ft. depth over sill)
can accommodate vessels of up to 225 ft. in length, 36 ft. beam, and 14.5
ft. draft
Pipelines: natural gas, 100 mi.
Ports: 1] major, 14 minor
Civil air: 31 major transport aircraft
Airfields: 98 total, 79 usable; 30 with permanent-surface runways; 17 with
runways 8,000-11,999 ft., 22 with runways 4,000-7,999 ft.
Telecommunications: facilities provide essential services for government, public,
and industry; 1,519,000 telephones; 2,023,000 radiobroadcast receivers;
1,252,000 TV receivers; 11 AM, 41 FM, and 60 TV stations; 4 submarine cables,
including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 1,196,000; 960,000 fit for military service;
38,000 reach military age (17) annually
110
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','9eb5b55e1b8df825f0b278183bbe2281d000449115cc216f9b7d99fa27adeb8d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1469a602a446cc4b52c44e9f2b764aa26760f1c979d2265501e6fe0d6eb595fa',1974,'FR','France','communications',137,'LAND:
213,000 sq. mi.; 35% cultivated, 26% meadows and pastures,
14% waste, urban, or other, 25% forested
Land boundaries: 1,795 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,130 mi. (includes Corsica, 400 mi.)
UBYA
Railroads: 23,870 mi.; 23,022 mi. standard gage, 848 mi. other gages (3'' 3 3/8"
to 4'' 9"); 5,824 mi. electrified, 9,892 mi. double or multiple track
Highways: National, Departmental, and Communal roads total 487,600 mi. comprising
292,600 mi. paved, 190,000 mi. crushed stone and gravel, and 14,600 mi.
improved earth; in addition, there are approximately 434,000 mi. of local
farm and forest roads
Inland waterways: 9,320 mi.; 4,820 mi. heavily traveled
Pipelines: crude of1, 1,400 mi.; refined products, 2,700 mi.; natural gas,
9,300 mi.
Ports: 22 major, 165 minor
Civil air: 310 major transport aircraft (including 10 foreign owned but French
registered)
Airfields: 536 total, 444 usable; 191 with permanent~surface runways; 17 with
runway over 12,000 ft., 21 with runways 8,000-11,999 ft., 133 with runways
4,000-7,999 ft.; 10 seaplane stations
112
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Telecommunications: highly developed system provides satisfactory telephone,
telegraph, and radio and TV broadcast services; 11.1 million telephones; 17.6
million radiobroadcast receivers; 14.2 million TV receivers; 51 AM, 74 FM,
and 1,220 TV stations; 18 submarine cables (17 coaxial}; 3 communication
satellite ground stations
DEFENSE FORCES:
Military manpower: males 15-49, 12,715,000; fit for military service 10,250,000;
* 424,000 reach military age (18) annually
113
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Railroads: 169 mi. standard gage; 100 mi. double track; 85 mi. electrified
Highways: 3,070 mi.; ali paved
Pipelines: refined products, 30 mi.
Inland waterways: 23 mi.; Moselle River
Port: Mertert
Civil air: 11 major transport aircraft (includes 4 registered in Iceland)
Airfields: 2 total, 1 usable with permanent-surface runway 8,000-11,999 ft.
Telecommunications: adequate and efficient system; 132,300 telephones; 184,000
radiobroadcast receivers; 92,600 TV receivers; 2 AM, 3 FM, 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 78,000; 62,000 fit for military service; about
3,000 reach military age (19) annually
204
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
{%
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','5d02ef69344c9ffa545fa4caa4cb7892929ee4be34fadff5ad6d60b72bb063d7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b6eb43fda5f091190792530b832619d2a2aaf7730a59f3e91972055bd22f4f9',1974,'GF','French Guiana','communications',141,'LAND:
* 35,100 sq. mi.; 90% forested, 10% wasteland, built-on,
inland water and other, of which .05% is cultivated
and pasture
Land boundaries: 735 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 235 mi.
Railroads: 20 mi. private plantation line, 1''11] 5/8" gage; 8 mi. abandoned
narrow-gage line
Highways: 450 mi.; 250 mi. paved, 200 mi. improved earth or gravel
Inland waterways: 290 mi., navigable by small oceangoing vessels and river
and coastal steamers; 2,110 mi. possibly navigable by native craft
Ports: 1 major, 7 minor -
Civil air: no major transport aircraft
Airfields: 15 total, 10 usable; 2 with permanent-surface runways; ] with runway
8,000-11,999 ft.; 1 seaplane station
Telecommunications: limited open-wire telecom system with about 6,700
telephones; 7,100 radio receivers and 2,900 TV receivers, 1 AM, 2 FM
and 2 TV stations; satellite communications station under construction
DEFENSE FORCES:
Military manpower: males 15-49, 13,000; 10,000 fit for military service
116
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','8ea572a3c406399d25f84999e001dd0d0c47cd0e52591169c8929155f64170e5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8514b5ae6a0d7056b86d9beafcbd6326def940999b8bff79028ef9617d3e2d8',1974,'PF','French Polynesia','communications',145,'LAND:
About 1,544 sq. mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: about 975 mi.
Telecommunications: 10,233 telephones
117
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
FRENCH TERRITORY OF THE AFARS AND ISSAS
% LAND:
9,000 sq. mi.; 89% desert wasteland, 10% permanent pasture,
and less than 1% cultivated
Land boundaries: 321 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 195 mi. (includes offshore islands)
Railroads: 60 mi. meter gage
Highways: 1,180 mi.; 62 mi. paved, 1,118 mi. improved earth
Ports: 1 major
Airfields: 27 total, 9 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 5 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 5 major transport aircraft (registered in France)
Telecommunications: fair telephone services; poor telegraph facilities; 2,590
telephones; 10,200 radio receivers; 2,550 TV receivers; 1 AM, no FM, and
1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 30,000; about 17,000 fit for military
service
Defense is responsibility of France
120
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','a3f2b61fcddab7e994aee7be640ba53272a2a4eebf0483a59b441d8da30364f8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4879d5813b481e148d1717d8a660b1c9c085ce59af9d01246ab132467fca6da4',1974,'GA','Gabon','communications',149,'LAND:
102,000 sq. mi.; 75% forested, 15% Savanna, 9% urban and
wasteland, less than 1% cultivated
Land boundaries: 1,505 mi.
WATER:
Limits of territorial waters (claimed): 100 n. mi.
Coastline: 550 mi.
Railroads: none
Highways: 3,815 mi.; 140 mi. paved, 3,268 mi. gravel and/or improved earth,
remainder unimproved earth
Inland waterways: approximately 1,000 mi. perennially navigable
Pipelines: crude oil, 40 mi.
Ports: 3 major, 2 minor
Civil air: 13 major transport aircraft
Airfields: 187 total, 101 usable; 5 with permanent-surface runways; 2 with run-
ways 8,000-11,999 ft., 17 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: fair telephone and telegraph services; good broadcast
coverage in vicinity of Libreville; 2 AM and 2 TY stations; 7,000 telephones;
90,000 radio receivers; 5,100 TV receivers
DEFENSE FORCES:
Military manpower: males 15-49, 129,000; 65,000 fit for military service;
5,000 reach military age (20) annually
Supply: dependent on France
122
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
eee.
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','827516e3827f7f6db11d3a7bacb67049c320615d424b872defae30bda52ca023','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a16ca585fedf7deff2ebe5dd86e178a5cf13d0ab4652f4739e6fbe764adaeec0',1974,'GM','Gambia','communications',153,'LAND: a oo
4,000 sq. mi.; 25% uncultivated savanna, 16% swamps, 4% da
forest parks, 55% upland cultivable areas, built-up =
areas, etc.
Land boundaries: 460 mi.
WATER:
Limits of territorial waters (claimed): 50 n. mi.
Coastline: 50 mi.
Railroads: none
Highways: 775 mi.; 185 mi. bituminous surface treated, 320 mi. gravel/laterite,
270 mi. unimproved earth
Iniand waterways: 377 mi.
Ports: 1 major
Civil air: no major transport aircraft
Airfields: 4 total, 1 usable; 7 with permanent-surface runway; 1 with runway
4,000-7,999 ft.; 1 seaplane station (non-operational)
Telecommunications: good telephone and telegraph services; 1,900 telephones;
60,000 radio receivers; 2 AM, no FM or TV stations; 1 submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 93,000; 43,000 fit for military service
124
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
1S
" NORWAY’ @
ev aan _ J SWEDEN.
GERMANY, EAST
LAND:
41,800 sq. mi.; 43% arable, 15% meadows and pasture, 27%
forested, 15% other
Land boundaries: 1,435 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 560 mi. (including islands)
Lava
Railroads: 8,920 route mi.; 8,680 mi. standard gage, 240 mi. meter or other narrow
gage, 1,390 mi. double track standard gage; 860 mi, overhead electrified (1972)
Highways: about 28.300 mi. classified highways; 7,680 mi. state highways including
910 mi. autobahn; 20,600 mi. district roads; additionally about 34,465 mi.
unclassified minor unpaved roads (1972)
Inland waterways: 1,562 mi. (1974)
Freight carried: rail -- 301.8 million short tons, 30.5 billion short ton/mi.
(1972); highway -- 570.1 million short tons, 9.3 billion short ton/mi. (1972);
waterway -- 20.2 million short tons, 2.0 billion short ton/mi. (incl. int''l.
transit traffic) (1973)
Pipelines: crude oil, 420 mi; refined products, 150 mi.; natural gas 300 mi.
ieee ga (Rostock, Wismar, Stralsund, Sassnitz, Peenemunde), 12 minor
1974
Airfields: 152 total; 54 with permanent-surface runways; 49 with runways 8,000-
11,999 ft., 44 with runways 4,000-7,999 ft.
126
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
~@&
©
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
STAT
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','56867395f4b44b318b7749de74dfac5991836f4411a4bc485013111b6536d8c4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e2cbb3e63f77db5056b0bba94ba5fb34f5f43a6f17e102df15305e9e65f7e7c',1974,'GH','Ghana','communications',157,'LAND:
si 92,000 sq. mi.; 19% agricultural, 60% forest and brush,
21% other
Land boundaries: 1,420 mi.
WATER:
a Limits of territorial waters (claimed): 30 n. mi. (undefined
protective areas may be proclaimed seaward of territorial
sea, and up to 100 n. mi. seaward may be proclaimed
fishing conservation zone)
Coastline: 335 mi.
Railroads: 592 mi. -- all 3''6" gage; 20 mi. double track; diesel locomotives
gradually replacing steam engines
Highways: 21,450 mi., 3,000 mi. concrete or bituminous surface, 5,250 mi. gravel
or laterite, 3,600 mi. improved earth, 9,300 mi. unimproved earth
Inland waterways: Volta, Ankobra, and Tano rivers provide 145 mi. of perennial
navigation for launches and lighters; additional routes navigable seasonally
by small craft; Lake Volta reservoir provides 700 mi. of arterial and
feeder waterways
Pipelines: refined products, 2 mi.
Ports: 2 major, 1 naval base (Sekondi), 4 minor
Civil air: 5 major transport aircraft
Airfields: 22 total, 19 usable; 5 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 8 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone fair to good in urban areas; fairly good telegraph
services; 49,100 telephones; about 1,057,500 radio receivers; 25,000 TV
receivers; 2 AM, 1 FM, and 1 TV station; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 2,190,000; 1,825,000 fit for military service;
114,000 reach military age (18) annually
130
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','18205efde220bcba32c2ccb127c43c9a0ebc2f2a4f4a93fd7891a2f6de7cfd33','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b73a8ae72c1bc219e11bfbcc233c40047439dc147f353c388ceff019367e293',1974,'GI','Gibraltar','communications',161,'LAND:
2.5 sq. mi.
Land boundaries: 1 mi. :
WATER: 48
Limits of territorial waters (claimed): 3 n. mi. “8
Coastline: 7.5 mi. eter
PEOPLE: aS ewOROECO ALGERIA
Population: 27,000 (official estimate for 1 July 1971)
Ethnic divisions: mostly Italian, English, Maltese,
Portuguese and Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages; Italian, Portuguese, and
Russian also spoken; English used in the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian laborers
Organized labor: over 6,000
Railroads: none
Highways: 19 miles, all paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: 1 permanent-surface runway, 4,000-7,999 ft.; 1 seaplane station
Telecommunications: international radiocommunication facilities; automatic
telephone system serving 6,100 telephones; 7,100 radio receivers; 6,950
TV receivers, 1 AM, 1 FM, and 2 TV stations; 13 submarine telegraph cables
DEFENSE FORCES:
Military manpower: males 15-49, about 6,000; about 3,000 fit for military service
Defense is responsibility of United Kingdom
132
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GILBERT AND ELLICE ISLANDS
LAND:
About 376 sq. mi.
WATER:
Limits of territorial waters: 3n. mi.
Coastline: about 725 mi.
Railroads: none
Highways: 30 mi.
Inland waterways: none
Ports: none
Civil air: no major transport aircraft
Telecommunications: 2 AM broadcast stations; 8,000 radio receivers and 369
telephones; connected with Lisbon, Portugal, via cable broadcasts
133
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','cecaf2f23c192ecc06c01f76c92d65d62dbd31bfa785896b2c788558c0bcd759','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b91e512a217b369f1a47e214327f9b2d6600a2c38eb5ba7984ed1a83789a9621',1974,'GR','Greece','communications',165,'LAND:
51,200 sq. mi.; 29% arable and land under permanent crops,
40% meadows and pastures, 20% forested, 11% wasteland,
urban, other
Land boundaries: 740 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. : ‘
Coastline: 8,500 mi. hae
Railroads: 1,598 mi.; 969 mi. standard gage (4''8 1/2"), 597 mi. meter gage
(3''3 3/8"), 20 mi. 1''11 5/8" narrow gage, 10 mi. 2''5 1/2" narrow gage; all
government owned
Highways: 24,200 mi.; 10,000 mi. paved, 8,500 mi. crushed stone and gravel
3,500 mi. improved earth, 2,200 mi. unimproved earth
Inland waterways: system consists of 3 coastal canals and 3 unconnected rivers
which provide navigable length of just less than 50 mi.
Pipelines: crude oil, 16 mi., refined products, 340 mi.
Ports: 17 major, 37 minor
Airfields: 67 total, 59 usable; 40 with permanent-surface runways; 17 with
runways 8,000-11,999 ft., 20 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 39 major transport aircraft (including 6 withdrawn from service)
Telecomnunications: adequate modern networks reach all areas on mainland and
islands; 1.62 million telephones; 2.8 million radio receivers; 950,000 TV
receivers; 30 AM, 9 FM and 25 TV stations; 2 coaxial submarine cables;
2 communications satellite ground stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,215,000; 1,780,000 fit for military service;
about 74,000 reach military age (21) annually
136
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','20c309dc827554e62a215c0efa890b6aab5dc77a6f0b694da7c095de37d4548c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('152933904dbb4465e0564c3ecbabd33eea7c0609145fda53bf20e98afe6e827a',1974,'GL','Greenland','communications',169,'LAND:
840,000 sq. mi.; less than 1% arable (of which only a
fraction cultivated), 84% permanent ice and snow,
15% other
WATER:
Limits of ao waters (claimed): 3n. mi. (fishing,
12 n. mi.
Coastline: 27,400 mi. (approx., includes minor islands)
Railroads: none
Highways? none
Ports: 7 major, 16 minor
Civil air: 4 major transport aircraft (registered in Denmark )
Airfields: 1] total, 8 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 3 with runways 4,000-7,999 ft.; 7 seaplane stations
137
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Telecommunications: adequate domestic and international service provided by
cables and radios 6,400 telephones; 7,500 radiobroadcast receivers; 5 AM,
2 FM, and 2 TV stations; 2 coaxial submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, included with Denmark
138
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','cb33ec35341a16cebeb605454444c69b03d30bcf3caa2b424b1b2e20f5fe9450','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d118514c1ac6761df33a849fde1f798b8f2c5f5007c0d57700c0e5069f253f42',1974,'GD','Grenada','communications',173,'LAND:
133 sq. mi. (Grenada and southern Grenadines); 44%
cultivated, 4% pastures, 12% forests, 17% unused but
potentially productive, 23% built on, wasteland,
other
VENGZUELA
a f
S','6702e5829fd76c10e7a5dcd9b45874232113f33dfefccf6e390747d7ad49bcd5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1e4d14a8b801c5f94de3724506dac866eac2686f749314132f8213de9e5e7a8',1974,'GP','Guadeloupe','communications',174,'LAND:
687 sq. mi.; 24% cropland, 9% pasture, 4% potential
cropland, 16% forest, 47% wasteland, built on; area
consists of two islands
Guyan.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 190 mi. Sei
Railroads: privately owned, narrow-gage plantation lines
Highways: 1,200 mi.; 780 mi. paved, 420 mi. gravel and earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
Civil air: 1 major transport
Airfields: 8 total, 7 usable, 6 with permanent-surface runways; 1 with runway
8,000-11,999 ft.; 1 seaplane station
Telecommunications: domestic facilities inadequate; 19,000 telephones;
inter-island VHF radio links; 2 AM radio and 3 TV transmitters; about
30,000 radio and 10,500 TV receivers
DEFENSE FORCES:
Military manpower: males 15-49, included with France
142
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','79819f231d26db8ba1cc2d52ac13dfb88c15ea3a508a319fd314759c42d17af2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abc4808f7a88cd9b85435357c8f714cfb56a0074f621e90ca093f33b79152b63',1974,'GT','Guatemala','communications',178,'LAND:
42,040 sq. mi.; 14% cultivated, 10% pasture, 57% forest,
19% other
Land boundaries: 1,010 mi.
COBTARICA; Sts
. re VENEZUELA
WATER: ieee : | CoLomeIA
Limits of territorial waters (claimed): 12 n. mi. BS
Coastline: 250 mi. Bese ieee
PEOPLE: : PERU BRAZIL
Population: 5,889,000, average annual growth rate 2.8%
(current)
Ethnic divisions: 41.4% Indian, 58.6% Ladino (mestizo and
wes ternized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks an Indian language as
a primary tongue
Literacy: about 30%
Labor force: 1.7 million (1973); 63.2% agriculture, 12.4% manufacturing, 11.8%
services, 12.6% other, 2% unemployed; severe shortage of skilled labor;
oversupply of unskilled labor; of this total 15 to 20% are unemployed
at any one time
Organized labor: 4% of labor force (1973)
Railroads: 592 mi., 3''0" gage; single-tracked; 520 mi. government owned, 72 mi.
privately owned
Highways: 7,600 mi., 1,300 mi. bituminous, 4,200 mi. gravel, 2,100 mi. improved
or unimproved earth
Inland waterways: 164 mi. navigable year-round; additional 458 mi. navigable
during high-water season
Pipelines: crude oi], 30 mi.
Freight carried: rail (1960) -- 191.8 million ton/miles, 1.1 million tons
Ports: 2 major, 3 minor
Airfields: 498 total, 333 usable; 5 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 18 with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 10 major transport aircraft
Telecommunications: modern telecom facilities limited to Guatemala City;
49,000 telephones; 360,000 radio and 105,000 TV receivers; 86 AM, 20 FM,
and 5 TV stations; connection into Central American microwave net
DEFENSE FORCES:
Military manpower: males 15-49, 1,432,000; 720,000 fit for military service;
about 65,000 reach military age (18) annually
144
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','704a5f5f6dcb72df2b535db95bb502a2d00da1ac540f43e2c9443aa1ee8237e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10877f292130b90b02d8450407e8bd167d17cb31b74ab5b2f0c769cee1f001fc',1974,'GN','Guinea','communications',180,'LAND:
95,000 sq. mi.; 3% cropland, 10% forest
Land boundaries: 2,160 mi.
WATER:
Limits of territorial waters (claimed): 130 n. mi.
Coastline: 215 mi.
Railroads: 500 mi. meter gage, 5 mi. standard gage
Highways: 4,725 mi.; 465 mi. paved, 2,610 mi. all weather, 1,650 mi. unimproved
earth
InTand waterways: 1,115 mi.; 310 mi. navigable by small oceangoing vessels,
805 mi. navigable by shallow-draft steamers and barges
Ports: 1 major, 3 minor
Civil air: 7 major transport aircraft
Airfields: 20 total, 16 usable; 2 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 3 seaplane landing areas
Telecomnunications: inadequate system of open-wire lines, small radio
communication stations, and 1 radio-relay link; principal center Conakry,
secondary center Kankan; 8,300 telephones; 101,000 radio receivers; 1 AM,
no FM, and no TV stations; 3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 872,000; 465,000 fit for military service
146
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','ad2ab2d6fe5deb73cb7f66ef19bc210761aa9605d35123494ff68ccdafd8f18c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc2aa9646089e489407f07850cd42b3d0e9adecf31ef9dc638e0891a70e0d431',1974,'HT','Haiti','communications',184,'LAND:
10,700 sq. mi.; 31% cultivated, 18% rough pastures,
7% forested, 44% unproductive
Land boundary: 224 mi.
LEOSTA RICA \\ :
Fisccrc {We VENEZUELA
a
WATER: . - a = ppm se
Limits of territorial waters (claimed): 12 n. mi.
(fishing 15 n. mi.)
Coastline: 1,100 mi.','aebb1b06413d24b699a436794b4f73f1b94d54cec55100339c022103bfc6c701','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da0af947cdd1f5be80ab81d5b4a874c947d9dd06f09b401d163e3e231f54aa46',1974,'HN','Honduras','communications',185,'LAND:
43,300 sq. mi.; 27% forested, 30% pasture, 36% waste
and built-up, 7% cropland
Land boundaries: 950 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 510 mi.','0f9971be483a0b3b5ebcc20e75fb2497405aa027f2da69106f226f78c09be5ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b0c81f85ade26bdc3ae3afe2043a756ee38e2ffbc8d88085f60b4b69275a0fa',1974,'HK','Hong Kong','communications',187,'LAND:
400 sq. mi.s 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country)
Land boundaries: 15 mi. ae
WATER:
Limits of territorial waters (claimed): 3.n. mi.
Coastline: 455 mi.
Ports: 1 major
Civil air: 13 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.; 1 seaplane station
Teleconmmunications: modern facilities are adequate for domestic and international
requirements; excellent coverage is provided by radiobroadcast; limited
wired television reception is available; 691,616 telephones; 725,000 radio
receivers; 300,000 TV receivers; 2 AM; 1 wired broadcast network; 1 FM:
2 TV stations (1 closed circuit); 4 submarine cables; 2 international
satellite stations in operation; radio relay links to the Republic of China
and to Canton, China; coaxial cable link under construction to Canton, China
DEFENSE FORCES:
Military manpower: males 15-49, 1,062,000; 790,000 fit for military service:
about 48,000 reach military age (18) annually
Defense is the responsibility of U.K.
Ships: Hong Kong Marine Police, 38 police boats; U.K. naval ships homeported
in the U.K. operate in the Indian Ocean, Gulf, and Far East; they rotate
assignments within the area; one destroyer escort permanently assigned as the
Hong Kong guard ship; a varied number of auxiliary/service craft are assigned
to the Commander Hong Kong
154
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','6240e3ea2791278d2f3a1b0a50a6e8a94ab305e378413ab60f00e1e400134b3b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a463c64cec973878de3fd486b6f457fe2db1bbebd349ddd4bfcab7552e26f0d',1974,'HU','Hungary','communications',191,'LAND:
35,900 sq. mi.; 60% arable, 14% other agricultural, 16%
forested, 10% other
Land boundaries: 1,395 mi.
Railroads: 5,275 route mi.; 4,465 mi. standard gage, 790 mi. narrow gage
(mostly 2'' 5 7/8"), 22 mi. broad gage (5''0"), 637 mi. double track, 580
mi. electrified; government owned (1972)
Highways: 18,455 mi.; 564 mi. concrete, 11,218 mi. bituminous, 280 mi. stone block,
5,713 mi. gravel, 680 mi. earth (1972)
Pipelines: crude oi], 800 mi.; refined products, 180 mi.; natural gas, over
1,500 mi.
Inland waterways: 1,320 mi. (1974)
Freight carried: rail -- 130.5 million short tons (1972), 14.2 billion short ton/mi.
(1972); highway -- 489.5 million short tons, 4.85 billion short ton/mi. (1972);
waterway -- 15.6 million short tons, 5.7 billion short ton/mi. incl. int'']
transit traffic (1973)
River ports: 2 principal (Budapest, Dunaujvaros); no maritime ports; outlets are
Rostock, East Germany and ports in Poland
Civil air: 21 major transport aircraft (1974)
Airfields: 85 total; 13 with permanent-surface runways; 17 with runways 8,000-
11,999 ft., 20 with runways 4,000-7,999 ft.
156
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ICELAND fo sarenvano
LAND:
39,750 sq. mi.; arable negligible, 22% meadows and
pastures, forested negligible, 78% other
WATER:
Limits of territorial waters (claimed): 4n. mi. (fishing,
50 n. mi., effective 1 September 1972)
Coastline: 3,100 mi.','3720281187db12141f3a8db6f30dc03a1f5c9c44419c7c30a5dfba26746efe3b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('298e27b9be8c6c03af66b3d6a851164c6c7b9e754b93dd01f543e5c528600618',1974,'IN','India','communications',195,'PEOPLE''S REPUBLIC
OF CHINA
LAND:
1,211,000 sq. mi. (includes Indian part of Jammu-
Kashmir, Sikkim, Goa, Damao and Diu); 50% arable,
5% permanent meadows and pastures, 20% desert,
waste, or urban, 22% forested, 3% inland water
Land boundaries: 7,880 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing,
12 n. mi.; additional 100 mi. is fisheries conservation
zone, December 1968; archipelago concept baselines)
Coastline; 4,378 mi. (includes offshore islands)
Railroads: 38,076 mi.; 16,259 mi. meter (3''3 3/8") gage, 18,892 mi. broad gage,
2,796 mi. (2''6" and 2''0") narrow gage government owned; 129 mi. 2''6" and
2''O" gage privately owned; 7,188 mi. double track; 2,455 mi. electrified
Highways: 795,539 mi.; 148,303 mi. paved, 111,876 gravel or crushed stone, 216,044
improved earth, 319,316 mi. unimproved earth
Iniand waterways: 8,750 mi.; 1,600 mi. navigable by river steamers
Ports: 8 major, 80 minor
Civil air: 115 major transport aircraft
Airfields: 624 total, 354 usable; 185 with permanent-surface runways; 2 with
runways over 12,000 ft., 49 with runways 8,000-11,999 ft., 126 with runways
4,000-7,999 ft.; 4 seaplane stations
Telecommunications: fair domestic telephone service where available; telegraph
facilities widespread; AM broadcast adequate; TV limited to Bombay and New Delhi;
international radio communications adequate; 1,479,475 telephones; 13,500,000
radio and 71,368 TV sets; about 163 AM stations at 75 locations, 2 TV stations,
one earth satellite station; submarine cables extend to Malaysia, Sri Lanka,
and Aden
DEFENSE FORCES: ; ;
Military manpower: males 15-49, 138,974,000; 79,105,000 fit for military service;
about 6,194,000 reach military age (17) annually
160
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','f648ed3c0784ff3bf140d245f7d033b018fd1bc7e4e4940871e040c6ff208046','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28f0bd1398cb7e1057dbc5b3d12d5ce2fc9352297d94d22023a603b336a6a142',1974,'ID','Indonesia','communications',199,'LAND:
736,000 sq. mi.; 12% small holdings and estates, 64% for-
ests, 24% inland water, waste, urban, and other
Land boundaries: 1,700 mi.
WATER:
Limits of territorial waters (claimed): under an archipelago
theory, claim is 12 n. mi., measured seaward from
straight baselines connecting the outermost islands
Coastline: 34,000 mi.','e29d69516ae3d59058119522763998b823c92bfba26219cc534bab903a3bd787','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3291c97102561f387c753c520cf4620a3437fcbb55c4482de9eddfc7aa030fa3',1974,'IE','Ireland','communications',200,'LAND:
26,600 sq. mi.; 17% arable, 51% meadows and pastures,
3% forested, 2% inland water, 27% waste and urban
Land boundaries: 224 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing,
12 n. mi.)
Coastline: 900 mi.','51d2426dde220d25dacddb4750494ec192744d943e6125e8e35ea66a2cc947c3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14ba2995c74430a0e060f39695aaaa61ab61de917c35103887864956d6a0ff0a',1974,'IT','Italy','communications',201,'LAND:
116,300 sq. mi.3 -50% cultivated, 17% meadow and pasture,
21% forest, 3% unused but potentially productive,
9% waste or urban
Land boundaries: 1,058 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi. (fishing,
12 n, mi.)
Coastline: 3,105 mi,
Railroads: 12,857 mi.; 9,907 mi. government owned; 9,805 mi. standard gage; 4,906
mi. electrified; 102 mi. narrow gage (3'' 1 1/8"); 2,950 mi. non-government
owned; 1,567 mi. standard gage; 794 mi. electrified; 1,383 mi. narrow gage;
323 electrified
Highways: 179,000 mi.; autostrade 3,000 mi., state highways 25,750 mi., provincial
highways 57,000 mi., communal highways 93,250 mi.3 159,000 mi. concrete,
bituminous, or stone block, 15,500 mi. gravel and crushed stone, 4,500 mi.
earth
Inland waterways: 1,538 mi. navigable routes; 708 mi. rivers, 529 mi. canals,
307 mi. are lake routes
Pipelines: crude oil, 1,100 mi.; refined products, 900 mi.; natural gas, 6,324 mi.
Ports: 16 major, 22 significant minor
Civil air: 141 major transport aircraft (including | foreign owned but Italian
registered)
172
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Airfields: 230 total, 150 usable; 81 with permanent-surface runways; 2 with
runways over 12,000 ft., 28 with runways 8,000-11,999 ft., 45 with runways
4,000-7,999 ft.; 11 seaplane stations
Telecommunications: well engineered, well constructed, and efficiently operated;
12.3 million telephones; 12.7 million radio and 11.6 million TV receivers;
82 AM, 600 FM, and 870 TV stations; 10 coaxial submarine cables; 3 communication
satellite ground stations
DEFENSE FORCES:
Military manpower: males 15-49, 13,705,000; 11,485,000 fit for military service;
423,000 reach military age (18) annually
173
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
IVORY COAST
LAND: j Hania
125,000 sq. mi.; 40% forest and woodland, 8% cultivated, 4 ; y ;
52% grazing, fallow, and waste, 200 mi. of lagoons i iS f
and connecting canals along eastern coast
Land boundaries: 2,005 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 320 mi.
Railroads: 408 mi. of the 728 mi. Abidjan to Ouagadougou, Upper Volta line, all
single track meter gage; only diesel locomotives in use
Highways: 24,600 mi.; 1,045 mi. bituminous and bituminous-surface treatment;
21,385 mi. gravel, crushed stone, laterite, and improved earth; 12,600
mi. unimproved earth roads
Inland waterways: 460 mi. navigable rivers and numerous coastal lagoons
Ports: 2 major, 3 minor
Civil air: 11 major transport aircraft
Airfields: 50 total, 44 usable; 3 with permanent-surface runways; 2 with runways
8,000-11,999 feet; 8 with runways 4,000-7,999 feet; 1 seaplane station
Telecommunications: system only slightly above African average; consists of
microwave relays, open-wire lines and radio relay links, which provide
incomplete coverage of country; Abidjan is only center; 24,800 telephones;
202,000 radio and 100,000 TV receivers; 3 AM, 2 FM, and 4 TV stations; 2
submarine cables; satellite earth station
DEFENSE FORCES:
Military manpower: males 15-49, 1,134,000; 545,000 fit for military service;
63,000 males reach military age (18) annually
176
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','945864e5dd69951a82db15b5f618aece6c420a5c6e5105d0bb82fbba39309284','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b70eb6f168a2b67abba622254eb84e3f746abdf85090b4be06cdc752e210f142',1974,'JM','Jamaica','communications',205,'Pf LAND:
4,410 sq. mi.; 21% arable, 23% meadows and pastures, 19%
forested, 37% waste, urban, or other
4 VENEZUELA
—
WATER: q : ee
Limits of territorial waters (claimed): 12 n. mi. . : &
Coastline: 635 mi. : eed ¢
PEOPLE: Paha gee
Population: 1,990,000, average annual growth rate 1.5% oe ae
(7/69-7/71)
Ethnic divisions: African 76.3%, Afro-European 15.1%,
Chinese and Afro-Chinese 1.2%, East Indian and
Afro-East Indian 3.4%, white 3.2%, other 0.9%
Religion: predominantly Protestant, some Roman Catholic, some piritualist cults
Language: English
Literacy: Ministry of Education estimates between 43% and 57% of adult population
functionally literate
Labor force: 808,300; 26% in agriculture, forestry, fishing and mining, 10%
manufacturing, 8% public administration, 5% construction, 10% commerce, 3%
transportation and utilities, 15% services, 23% unemployed (seasonal unemploy-
ment in agriculture can push the unemployment figure to 25%); shortage of
technical and managerial personnel
Organized labor: about 25% of labor force (1966)
Railroads: 204 mi. government-owned, 43 mi. privately owned, all standard gage,
single track
Highways: 7,100 mi.; 1,500 mi. paved, 4,100 mi. gravel, 1,500 mi. unimproved
earth surfaces
Pipelines: refined products, 6 mi.
Ports: 3 major, 10 minor
Civil air: 6 major transport aircraft
Airfields: 48 total, 39 usable; 11 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 2 with runway 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fully automatic domestic telephone network with 86,900
telephones; satellite ground station; 600,000 radio and 92,000 TV receivers;
8 AM, 8 FM, and 8 TV stations; 5 submarine cables, including 2 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 416,000; 280,000 fit for military service; no
conscription; average number currently reaching minimum volunteer age (18),
22,000
178
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
~@&
©
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
STAT
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','dbd0dd8c1c4212ddae408c63e0647c05ea35968acc147c729c5d6d8915e3482f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b40916caacaef2ea446908a35c4f66404f0b7b4525e61f5c374bfa3905ac63d',1974,'JO','Jordan','communications',208,'NOTE: The war between Israel and the Arab states in June 1967
a ended with Israel in control of West Jordan. Although
approx. 930,000 persons resided in this area prior to the
start of the war, fewer than 750,000 of them remain there
under the Israeli occupation, the remainder having fled
to East Jordan. Over 14,000 of those who fled were poe
~ repatriated in August 1967, but their return has been :
more than offset by other Arabs who have crossed and are tes
continuing to cross from West to East Jordan. These and fermion
certain other effects of the Arab-Israeli war are not
included in the data below.
LAND:
37,100 sq. mi. (including about 2,100 sq. mi. occupied by Israel); 11%
agricultural, 88% desert, waste, or urban, 1% forested
Land boundaries: 1,100 mi. (1967, 1,037 mi. excluding occupied areas)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 16 mi.
Railroads: 227 mi. 3''5 3/8" gage, single track
Highways: 4,400 mi.; 3,486 mi. bituminous, 249 mi. improved, 665 unimproved earth
(these mileages include approximately 670 mi. -- mostly bituminous -- of
Jordanian territory held by Israel)
Pipelines: crude oil, 130 mi.
Ports: 1 major
Airfields: 53 total, 20 usable; 11 with permanent-surface runways; 1 with
runways over 12,000 ft., 10 with runways 8,000-11,999 ft., 4 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate telecommunication system for the needs of the
country; 37,100 telephones; 300,000 radio and 132,000 TV receivers; 1 AM
and 1 TV stations; 1 earth satellite station
DEFENSE FORCES:
Military manpower: males 15-49, 608,000; 460,000 fit for military service;
average number currently reaching military age (18) annually 30,000
182
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','3702689f2150b0fd27d03bcd6a58eb35edfdc234f28b23b0bea907dd7f0812f2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d39493f477d0d06bce166c6e28f55c4b6165b0a7a7fa0338734dc34241d02fa6',1974,'KE','Kenya','communications',212,'LAND:
225,000 sq. mi.; about 21% forest and woodland, 13%
suitable for agriculture, 66% mainly grassland
adequate for grazing (1971)
Land boundaries: 2,093 mi.
WATER:
Limits of territorial waters (claimed): 12 n, mi.
Coastline: 333 mi.
Railroads: 1,275 mi.; meter gage
Highways:
29,075 mi.3 2,075 mi. paved, 27,000 mi. gravel and/or earth
Inland waterways: part of Lake Victoria and Lake Rudolph are within boundaries
of Kenya
Ports: 1 major, 3 minor
Civil air: 9 major transport aircraft
Airfields: 272 total, 214 usable; 6 with permanent-surface runways; 1 with
runway over 12,000 ft., 1 with runways 8,000-11,999 ft., 43 with runways
4,000-7,999 ft.; 3 seaplane stations
Telecommunications: in top group of African systems: consists of radio-relay
links, open-wire lines, and radiocommunication stations ; principal center
Nairobi, secondary centers Mombasa and Nakuru; 85,200 telephones; 774,000
radio and 37,000 TV receivers; 3 AM, 1 FM, and 5 TV stations; 1 submarine
cable; satellite ground station
DEFENSE FORCES:
Military manpower: males 15-49, 2,809,000; 1,365,000 fit for military service;
no conscription
184
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
PEOPLE''S REP.
OF CHINA
KOREA, NORTH
LAND:
47,000 sq. mi.; 17% arable and cultivated, 74% in forest,
scrub, and brush; remainder wasteland and urban
Land boundaries: 1,440 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,550 mi.
Railroads: 2,782 route mi. operating in 1968; 2,369 mi. standard gage, 413 mi.
2''6" narrow gage; 99 mi. double tracked; about 588 mi. electrified; government
owned
Highways: about 12,600 mi., 95% gravel or earth surface
Inland waterways: 1,400 mi.; mostly navigable by small craft only
Freight carried (1969): rail -- 13 billion metric ton/km., 62 million metric
tons; highway -- 765 million metric ton/km., 116 million metric tons;
waterway -- 540 million metric ton/km., 7.7 million metric tons; coastal --
170 million metric ton/km., 0.4 million metric tons
Ports: 6 major, 26 minor
DEFENSE FORCES:
Military manpower: males 15-49, 3,520,000; 2,090,000 fit for military service;
174,000 reach military age (18) annually
186
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
PEOPLE''S REP.
OF CHINA
KOREA, SOUTH
LAND:
38,000 sq. mi.; 23% arable (22% cultivated), 10% urban
and other, 67% forested
Land boundaries: 150 mi.
WATER:
~ Limits of territorial waters: 3n. mi. (fishing, 20-200
n. mi., continental shelf including sovereignty over
superjacent waters)
Coastline: 1,500 mi.
Railroads: 1,964 mi.; 1,915 mi. standard gage, 32 mi. (2''6") narrow gage; 280
mi. double track; 96 mi. electrified; government owned
Highways: 25,250 mi.; 3,597 mi. paved, 17,673 mi. gravel, 2,013 mi. improved
earth, 1,967 mi. unimproved earth
Inland waterways: 1,000 mi.; use restricted to small native craft
Freight carried: rail (1968) 4.5 billion short ton/mi., 30.4 million short
tons; highway 24 million short tons; air (1959) 796,260 lbs. carried
Pipelines: 255 mi., refined products, under construction
Ports: 10 major, 18 minor
Civil air: 26 major transport aircraft
Airfields: 265 total, 119 usable; 52 with permanent-surface runways; 13 with
runways 8,000-11,999 ft., 15 with runways 4,000-7,999 ft.; 2 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,056,000; 5,100,000 fit for military service;
average number reaching military age (18) annually 340,000
188
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
KUWAIT F
LAND: if TRAQ ne
6,200 sq. mi. (excluding neutral zone but including islands); 9 [°° savor Fw
insignificant amount forested; nearly all desert, waste, tk arapia
or urban
Land boundaries: 285 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 310 mi.','4ff7bed8d1b0e52f17ea47640c2199150e6efe6b5de50cc928726909bb5284ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25b1db0dcbfbf8f1ccf03f29e0888e916c799a25cc8cd4571c52436a13bc9574',1974,'DE','Germany','communications',217,'Railroads: none
Highways: 1,550 mi.; 465 mi. bituminous; 1,085 mi. earth, sand, light gravel
Pipelines: crude oi], 255 mi.; refined products, 25 mi.; natural gas, 75 mi.
Ports: 3 major, 4 minor
Merchant marine: 34 ships (1,000 GRT or over), totaling 651,100 GRT, 1,105,500
DWT; includes 24 cargo, 1 container, 6 tankers, 3 specialized carriers (C)
Civil air: 6 major transport aircraft
Airfields: 13 total, 3 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: excellent international radiocommunications; adequate
domestic telecommunication facilities; 85,100 telephones; 200,000 radio
and 130,000 TV sets; 3 AM and 3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 308,000; about 185,000 fit for military
service
190
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
LAOS
LAND:
91,430 sq. mi.; 8% agricultural, 60% forests, 32% urban,
waste, and other; except in very limited areas, soil
is very poor; most of forested area is not exploitable
Land boundaries: 3,140 mi.','de68a0e8893f9cd0fe2590036514bc6bc166c9c913bb8e22a6f1050476be25b1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abb3ba98decd360a1e4bffaff6d47ee1521a64ea72841950c9979f81171583b3',1974,'LB','Lebanon','communications',223,'Railroads: 238 mi.; 184 mi. 4''8 1/2", 51 mi. 3''5 3/8"; all single track
Highways: 5,160 mi.; 3,850 mi. paved, 310 mi. gravel and crushed stone, 404 mi.
improved earth, 596 mi. unimproved earth
Pipelines: crude oi], 45 mi.
Ports: 3 major, 5 minor
Civil air: 21 major transport aircraft
Airfields: 11 total, 3 usable; 3 with permanent-surface runways; 3 with runways
8,000-11,999 ft.; 1 seaplane station
Telecommunications: excellent international teleconmunication facilities include
satellite ground station; good domestic telephone and telegraph service;
192,000 telephones; 1.3 million radio and 321,000 TV receivers; 7 TV, 2 FM,
and 1 AM radiobroadcast stations; 1 submarine cable
DEFENSE FORCES:
Military manpower: males 15-49, 734,000; 435,000 fit for military service;
average of about 27,000 reach military age (18) annually
194
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','2ccb645d9086c365fc5377af71f816cadeef9c45224b11d815e6c2753fef9bd0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9555787f52fab6d785c2a3fe4ccbefaa024d3dbd6d57dcdafe28819a0c0a530',1974,'LS','Lesotho','communications',224,'LAND:
11,700 sq. mi.; 15% cultivable; largely mountainous
Land boundaries: 500 mi.
Railroads: 1 mi.; owned, operated, and included in the statistics of the Republic
of South Africa
Highways: approx. 1,370 mi.; 120 mi. paved; 580 mi. crushed stone, gravel, or
stablized soil; 670 mi. improved or unimproved earth
Civil air: no major transport aircraft
Airfields: 37 total, 20 usable; 3 with runways 4,000-7,999 ft.
Telecommunications: system a modest one consisting of a few landlines, a smal]
radio-relay system, and minor radioconmunication stations; Maseru is the
center; 3,200 telephones; 10,500 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 203,000; fit for military service 105 ,000
196
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','a9dddfa07f12def49e31ce514bcc7184c9490818fe58bcf056c044d32c3f08cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb86af17b0ab217db338f44cca12bec22bffb4e98cb1075531cbb320e3c447c7',1974,'LR','Liberia','communications',228,'LAND:
43,000 sq. mi.; 20% agricultural, 30% jungle and swamps,
40% forested, 10% unclassified
Land boundaries: 830 mi.
WATER:
> Limits of territorial waters (claimed): 12 n. mi.
Coastline: 360 mi.
Railroads: 312 mi.; 220 mi. standard gage, 90 mi. narrow gage (3''6"); all lines
single track; rail systems owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
Highways: 4,950 mi.; 340 mi. bituminous treated; remainder improved and
unimproved laterite, gravel, and/or earth
Inland waterways: 230 mi. navigable
Ports: 3 major, 4 minor
Civil air: 2 major transport aircraft
Airfields; 88 total, 77 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone and telegraph limited; main center is Monrovia;
3,180 telephones; 260,000 radio and 8,500 TV receivers; 5 AM, no FM,
5 TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 401,000; 215,000 fit for military service;
no conscription
198
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','1c5504cc6a368248ffa4373e5d8095dc26895f5885e0642ff25e654614225599','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed3a4bae964261db03934ae0fe007a235a532836a6d5718eecc1f845d18f7c8b',1974,'LY','Libya','communications',232,'EG yar,
.
» LAND:
679,000 sq. mi.; 6% agricultural, 1% forested, 93%
desert, waste, or urban
Land boundaries: 2,700 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(except for Gulf of Sidra where sovereignty is claimed
and northern limit of jurisdiction fixed at 32° 30'' N.
and the unilaterally proclaimed 100 n. mi. zone around
Tripoli)
Coastline: 1,100 mi.
Railroads: none
Highways: 9,450 mi.; 4,300 mi. bituminous or bituminous treated, 5,150 mi.
improved and unimproved earth and gravel
Pipelines: crude oi] 1,520 mi.; natural gas 175 mi.; refined products 140 mi.;
liquid petroleum gas 135 mi.
Ports: 3 major, 6 minor
Civil air: 6 major transport aircraft; an additional 30 major transports are
operated by external carriers engaged in charter work for several oi] companies
Airfields: 124 total, 81 usable; 14 with permanent-surface runways, 1 with runway
over 12,000 ft., 7 with runways 8,000-11,999 ft., 35 with runways 4,000-7 ,999
ft.; 2 seaplane stations
Telecommunications: system is just within top one-third of African systems; con-
sists of radio-relay and tropospheric-scatter links, open-wire lines, and
radiocommunication stations; principal centers are Tripoli and Banghazi;
49,800 telephones; 225,000 radio and 5,000 TV receivers; 7 AM, 7] FM, and
2 TY stations; 3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 489,000; 285,000 fit for military service;
about 20,000 reach military age (17) annually; conscription now being
implemented
200
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
a2 28 NORWAY 23','cefedbab1f90d48ae8e1fcf65f2ad50cc2d7a431e91f6eb644f53fab39da946d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('160647d16ae622e4698dc7b52a51cb763906c8c640e2747ecb225a4df56f151e',1974,'LI','Liechtenstein','communications',236,'re LAND:
65 sq. mi.
Land boundaries: 47 mi.
Railroads: 9.94 mi. 4''8 1/2" gage, electrified; owned, operated, and included in
statistics of Austrian Federal Railways
Highways: no information on total mileage
: Civil air: no major transport aircraft
Airfields: none
201
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Teleconmunications: automatic telephone system serving about 13,050 telephones;
no broadcast facilities; 5,300 radio and 4,700 TV receivers (programs from
Switzerland)
DEFENSE FORCES:
Defense is responsibility of Switzerland
202
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','c7692578e94dcfe51490c966069889e8ce488e59798c191b515e171af22524ed','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('488c68c0115933dc128623bb5b9408c01755870b852d31b5e51caca1ee16b0cc',1974,'LU','Luxembourg','communications',240,'o. \\
C east POLAND
REP,
‘GERMANY 5
yaa
LAND:
1,000 sq. mi.; 25% arable, 27% meadows and pasture, 15%
waste or urban, 33% forested, negligible amount of
inland water
Land boundaries: 221 mi.
OF
ce RMAA S CZECH:
LUXEMBOUR''','53205dcafeb9f9e36c6c78e9ddbace522f277d44f4a154a16a249618690d161f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ca2e93b5f00ad047d9b39bc1876cd4716a7f932fc97a70f7db4974a0e4da3c6',1974,'MO','Macao','communications',241,'LAND:
6 sq. mi.; 10% agricultural, 90% urban
Land boundaries: 220 yds.
WATER:
Limits of territorial waters (claimed): 6 n. mi;
fishing, 12 n. mi.
Coastline: 25 mi.
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
Telecommunications: fairly modern facilities provide adequate services for
domestic and international requirements; excellent coverage is provided
by AM and FM radiobroadcasts; 5,576 telephones; 65,000 radio receivers;
2 AM, 2 FM, and no TV stations; no submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 69,000; 43,000 fit for military service
Defense is responsibility of Portugal
206
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','82282076938edcb4283d1895cb19d63798b8cb537911e04ca70f34a3f650213d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdeba682d83f955b09853ccf04c80b746bd2038a0111cd30f7c571b980206421',1974,'MG','Madagascar','communications',245,'LAND:
230,000 sq. mi.; 5% cultivated, 58% pastureland, 21%
forested, 8% wasteland, 2% rivers and lakes, 6% other
WATER:
Limits of territorial waters (claimed): 50 n. mi.
as Coastline: 3,000 mi.
Railroads: 549 mi. of meter gage
Highways: 5,300 mi.; 1,875 mi. paved, 2,225 mi. crushed stone, gravel, or stabi-
lized soil; 1,200 mi. improved and unimproved earth; remainder are tracks
Inland waterways: 600 mi. perennially navigable; Lac Alaotra (200 sq. mi.)
Ports: 4 major, 13 minor
Civil air: 10 major transport aircraft
Airfields: 366 total, 129 usable; 28 with permanent~surface runways; 3 with run-
ways 8,000-11,999 ft., 46 with runways 4,000-7,999 ft.; 6 seaplane stations
Telecommunications: system above African average; includes open wire lines, some
radio-relay and coaxial links and a communication satellite ground station;
29,000 telephones; 600,000 radio and 7,000 TV receivers; 1 AM, no FM, and
1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,650,000; 975,000 fit for military service;
average number reaching military age (20) annually about 79,000
208
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
tF
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','55fca4cfaa8951b4511f17a95864243f10192ec711de0080cd56dfb4e3c10eff','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26142e6c930a3fb56e85df901c40fdde09a3c1c4bc6aa24c55c9d8d064fc4013',1974,'MW','Malawi','communications',249,'LAND:
36,700 sq. mi.; about 31% of land area arable (of which
less than half is cultivated), nearly 25% forested,
6% meadow and pasture, 38% other
Land boundaries: 1,790 mi.
Railroads: 352 mi. (3''6" gage)
Highways: 6,710 mi.; 540 mi. paved; 4,040 mi. crushed stone, gravel, or stabilized
soils 2,130 mi. unimproved earth
Inland waterways: Lake Nyasa (Lake Malawi), 800 route mi. and Shire River, 90 mi.
Ports: 3 lake
Civil air: 5 major transport aircraft
Airfields: 46 total, 43 usable; 1 with permanent-surface runway; 7 with
runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: the system is barely above average for African countries
and consists of thinly spread open-wire lines, radio-relay links, and
radioconmunication stations; principal centers are Blantyre and Zomba;
15,200 telephones; 112,000 radio receivers; 5 AM, 4 FM and no TY stations
DEFENSE FORCES:
Military manpower: males 15~49, 1,009,000; about 510,000 fit for military service
210
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','10b7a6dcf7c9e11e408443c67c19ef0483340d76d1cf17503ced2f00703fbbfc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05932a398d798a822502ab999a5476fc47d95e3981e1758257b68032099f206d',1974,'MY','Malaysia','communications',253,'NOTE:
Malaysia, which came into being on 16 September 1963,
consists of West Malaysia, which includes 17 states
of the former Federation of Malaya, plus East
Malaysia, which includes the 2 former colonies of
North Borneo (renamed Sabah) and Sarawak
LAND:
West Malaysia: 50,700 sq. mi. 20% cultivated, 26%
forest reserves, 54% other
Sabah: 29,400 sq. mi.; 13% cultivated, 34% forest
reserves, 53% other
Sarawak: 48,300 Sq. mi.3 21% cultivated, 24% forest
reserves, 55% other
Land boundaries: West Malaysia 315 mi., East Malaysia 1,110 mi.
WATER:
Limits of territortal waters (claimed): 12 n, mi.
Coastline: West Malaysia, 1,285 mi., East Malaysia 1,620 mi,
Railroads:
West Malaysia: 1,014 mi. 3''3 3/8" gage; 8 mi. double track; government-owned
East Malaysia: 96 mi. meter gage in Sabah
Highways:
West Malaysia: 10,500 mi.; 8,925 mi. hard surfaced (mostly bituminous surface
treatment), 1,150 mi. crushed stone/gravel, 425 mi. improved or unimproved
earth
East Malaysia: about 3,140 mi. (1,608 in Sarawak, 1,532 in Sabah); 520 mi.
hard surfaced (mostly bituminous surface treatment), 1,853 mi. gravel or
crushed stone, 767 mi. earth
Inland waterways:
West Malaysia: 1,985 mi.
East Malaysia: 2,540 mi. (975 mi. in Sabah, 1,565 mi. in Sarawak)
Ports:
West Malaysia: 3 major, 10 minor
East Malaysia: 4 major, 7 minor (3 major, 3 minor in Sabah; 1 major, 4 minor
in Sarawak)
Civil air: 17 major transport aircraft (including 1 Boeing 707 leased from U.K.)
Pipelines: crude oil, 90 mi.; refined products, 35 mi.
Airfields:
West Malaysia: 107 total, 71 usable; 16 with permanent-surface runways;
2 with runways 8,000-11,999 ft., 12 with runways 4,000-7,999 ft.; 3
seaplane stations
Sabah: 41 total, 33 usable; 5 with permanent-surface runways; 1] with runway
8,000 to 11,999 ft.; 4 with runways 4,000-7,999 ft.; 3 seaplane stations
Sarawak: 52 total, 47 usable; 5 with permanent-surface runways; 4 with
runways 4,000-7,999 ft.
Telecommunications:
West Malaysia: good intercity service provided mainly by microwave relay;
international service good; good coverage by radio and television broad-
casts; 179,633 telephones; 420,000 radio and 293,600 TV receivers; 9 towns
have AM stations; no FM, 29 TV stations; submarine cables extend to India,
Ceylon, and Singapore; connected to SEACOM submarine cable terminal at
Singapore by microwave relay
Sabah: adequate intercity radio-relay network extends to Sarawak via Brunei;
14,141 telephones; 60,000 radio receivers; 2,000 TV receivers; 5 AM, 1 FM,
4 TV stations; SEACOM submarine cable links to Hong Kong and Singapore
Sarawak: adequate intercity radio-relay network extends to Sabah via Brunei;
16,834 telephones; 80,000 radio and no TV receivers; 1 AM, no FM, no TV
stations
214
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
DEFENSE FORCES:
Military manpower: West Malaysia: males 15-49, 2,242,000; 1,420,000 fit for
military service; Sabah: males 15-49, 172,000; 108,000 fit for military
services Sarawak: males 15-49, 248,000; 157,000 fit for military service;
, conscription age for Malaysia is 21 -- an age reached by about 116,000
annual ly
External defense dependent on loose Five Power Defense Agreement (FPDA) which
replaced Anglo-Malayan Defense Agreement of 1957 as amended in 1963; FPDA,
effective as of 1 November 1971, also provides for small ANZUK Joint Force
composed of Australia, New Zealand, and U.K. ground, naval, and air elements ,
headquarters in Singapore
Military budget: for fiscal year ending 31 December 1973, $281 million; about 15%
of central government budget
215
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','90943bca932de3d5da8199592f6156bb391ecceb1939f3091aeb8bec89dcae22','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51886958d2b5f534e80a05a552d487bb9dc0c13eb77652012b5a18e0269f237f',1974,'MV','Maldives','communications',257,'LAND:
115 sq. mi.3 2,000 islands grouped into 12 atolls, about
220 islands inhabited
WATER:
Limits of territorial waters (claimed): the land and
sea between latitudes 7°9''N. and 0°45''S, and between
longitudes 72°30''E. and 73°48''E; these coordinates
form a rectangle of approximately 37,000 sq. n. mi.
Coastline: 400 mi. (approx. )
Railroads: none
Highways: ‘none
Ports: 2 minor
Civil air: no major transport aircraft
217
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Airfields: 3 total, 2 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 1 with runway 4,000-7,999 ft.
Telecommunications: minimal domestic and international teleconmunication
facilities; 300 telephones; 2,300 radio sets; 1 AM station
218
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','9d0a2a1df7a9be96916aab4fa45c0e7ada259720f63ee1df14502eb71ddbe4b9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c61d73ca6101b474453bdf86389f662c05a77f481645f28b0b205cb97570567',1974,'ML','Mali','communications',261,'LAND:
465,000 sq. mi.; only about a fourth of area arable,
forests negligible, rest sparse pasture or desert
Land boundaries: 4,635 mi.','376cecadeb316672041d1929d099e7048bffbbd894680a38dcbbd977fd6eef61','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c0d8e9e8ea8ffb44bf33d98064dd768359dc8366c4f3c652bc2304f0d5cf2d6',1974,'CN','China','communications',266,'Railroads: 400 mi. meter gage
Highways: approximately 8,200 mi.; 1,010 mi. bituminous, 1,050 mi. improved
earth, 6,140 mi. unimproved earth
Inland waterways: 1,141 mi. navigable
Civil air: 5 major transport aircraft
Airfields: 55 total, 38 usable; 6 with permanent-surface runways; 2 with runway
8,000-11,999 ft., 11 with runways 4,000-7,999 ft.
Telecommunications: system poor and provides only minimum service to government,
business, and public; open-wire and radioconmunication used for long distance
telecommunications; radio sometimes only link to outlying points; 7,800
telephones; 75,000 radio receivers; 2 AM, no FM, and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,278,000; 720,000 fit for military service;
no conscription
220
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
DS, YUGOSLAVIA','2e337e6ea0748d982bf2f3e5df7bed6dcd48f46e5e2405bde8546f66fbe2c733','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f41506781a530ac802478fafdef3e3f4f578085e11281c0c5cf9015c188187b3',1974,'MT','Malta','communications',267,'LAND:
121 sq. mi.; 45% agricultural, negligible amount forested,
remainder urban, waste, or other (1965)
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 87 mi.
Highways: 760 mi., 650 mi. paved (asphalt), 80 mi. crushed stone or gravel,
30 mi. improved and unimproved earth
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 4 total, 2 usable; 4 with permanent-surface runways; 3 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: modern automatic telephone system centered in Valletta;
47,000 telephones; 124,000 radio and 68,000 television receivers; 3 AM, 3 FM,
and 1 TV stations; 8 submarine cables, including 1 coaxial
DEFENSE FORCES:
Military manpower: males 15-49, 87,000; 65,000 fit for military service
222
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
MART INT QUE
LAND;
425 sq. mi.; 31% cropland, 16% pasture, 29% forest, 24%
wasteland, built on
VENEZUELA
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 180 mi.','36cc5e2bfe9bcc57fbf9f4a3f8c9d57af6ec1bf8cae37592c3847ca8e71bd2a3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e5d4ae9beee31228e2d19969e9c3e5277fe8c1ad43a04654175abd23f3416c8',1974,'MC','Monaco','communications',271,': ao
* (wasp POLAND
LAND: , ¥ REP al aean y
0.6 sq. mi. : sas ;
Land boundaries: 2.3 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing
12 n. mi.)
Coastline: 2.6 mi.
Railroads: 1 mi. (see France)
Highways: none; city streets
Ports: 1 minor
Civil air: no major aircraft
Airfields: none
237
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Teleconmunications: served by the French communications system; automatic
telephone system with about 18,100 telephones; international AM broadcast;
FM and TV facilities; 11,000 radio and 16,000 TV receivers
DEFENSE FORCES:
France responsible for defense
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','8a8b11cf9edd8e0d12e649484dca4f44d9fc35529d1ab613a704da630df155f8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6a180e227682752809da79fcf20c0d132fbaeb021c6039a123b7f6b90926ca7',1974,'MN','Mongolia','communications',275,'LAND:
604,100 sq. mi.; almost 90% of land area is pasture or
desert wasteland, varying in usefulness, less than
1% arable, 10% forested
Land boundaries: 4,975 mi.','baf48efb4e47ef532f46f2fd23b7f004317f66ca85fbfcd8cafd7525031fd593','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6c415509b020d9e1056415443177bb5340006a3f2419f0df80eeb7acd6936e3',1974,'MA','Morocco','communications',277,'LAND:
158,100 sq. mi.; about 32%
17% forest and esparto,
Land boundaries: 1,240 mi.
arable and grazing land,
51% desert, waste, and urban
WATER:
Limits of territorial waters (claimed
(fishing, 70 n. mi.)
Coastline: 1,140 mi.
): 12 n. mi.
Railroads: 1,100 mi. standard gage, 93 mi. double track; 493 mi. electrified
Highways: 32,180 mi.; 11,203 mi. bituminous, 3,244 mi. gravel, crushed stone, and
improved earth, 17,733 mi. unimproved earth
Pipelines: crude oi], 85 mi.; refined products, 305 mi.; natural gas, 60 mi.
Ports: 8 major (including Spanish-controlled Ceuta and Mellila), 11 minor
Civil air: 1] major transport aircraft
Airfields: 144 total, 85 usable; 24 with permanent-surface runways; 2 with
runways over 12,000 ft., 11 with runways 8,000-11,999 ft., 36 with runways
4,000-7,999 ft.; 4 seaplane stations
Telecommunications: superior system by African standards composed of open-wire
lines, coaxial, multiconductor and submarine cables and radio-relay links;
principal centers Casablanca and Rabat, secondary centers Fes, Marrakech,
Oujda, Sebaa Aioun, Tangier and Tetouan; 175,000 telephones; 1.5 million radio
and 225,000 TV receivers; 24 Moroccan AM, 1 Voice of America AM, 3 FM, 17 TV
stations; 11 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,879,000; 2,640,000 fit for military service;
about 180,000 reach military age (18) annually; limited conscription
236
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
MOZAMB IQUE
LAND:
303, 769 sq. mi.; 30% arable, of which 1% cultivated, 56%
woodland and forest, 14% wasteland and inland water
Land boundaries: 2,875 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,535 mi.','2d1223987040ce9248ad5afbe6dc47df94c44f75cb0ffcf7f801afbb57bdd2a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13f8c0b04c52ccb7178023c114f0874b3dc149b2dba8b41c1ce66c78339ca8a4',1974,'ZM','Zambia','communications',282,'Railroads: 1,965 mi.; 1,877 mi. 3''6" gage (6 mi. double track), 88 mi. 2''5 1/2"
gage
Highways: 20,000 mi.; 1,740 mi. paved; 18,260 other (mostly earth)
Inland waterways: approx. 2,330 mi. of navigable routes
Pipelines: crude oi], 190 mi.
Ports: 3 major, 2 significant minor
Civil air: 13 major transport aircraft
Airfields: 363 total, 315 usable; 27 with permanent-surface runways; 5 with run-
ways 8,000-11,999 ft.; 34 with runways 4,000-7,999 ft.; 5 seaplane stations
Telecommunications: above African average system of open-wire lines,
radiocommunication stations, and radio-relay and tropospheric-scatter links;
principal center Lourenco Marques, secondary centers Beira, Nampula, and
Quelimane; 49,200 telephones; 176,600 radio receivers; 9 AM, 2 FM, and no
TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 2,147,000; 1,035,000 fit for military service
Defense is responsibility of Portugal
238
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
LAND:
288,000 sq. mi.; 5% under cultivation, 5% arable, 10%
grazing, 13% dense forest, 6% marsh, 61% scattered
trees and grassland
Land boundaries: 3,730 mi.
Railroads: 664 mi., government owned, all narrow gage (3''6"); 8 mi. double track
Highways: 21,375 mi.3; 2,145 mi. paved, 4,690 mi. crushed stone, gravel, or
stabilized soil; 14,540 mi. improved and unimproved earth
Inland waterways: 1,409 mi. including Zambezi River, Luapula River, Lake Kariba,
Lake Bangweulu, Lake Tanganyika; principal port on Lake Tanganyika is Mpulungu
Pipelines: 450 mi. refined
Civil air: 9 major transport aircraft
Airfields: 203 total, 163 usable; 11 with permanent-surface runways; 1 with
runway over 12,000 ft., 2 with runways 8,000-11,999 ft., 21 with runways
4,000-7,999 ft.
Telecommunications: all services being modernized and increased; presently
adequate but must be expanded to permit growth; high-capacity wire and
radio relay connect centers of Kitwe in northern mining region and Lusaka
along axial north-south route; 59,300 telephones; 100,000 radio and
20,000 TV receivers; 4 AM, 1 FM, and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,140,000; 545,000 fit for military service
388
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
we
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','f3236ca3d60547f551c1234b6ff3ed01dfa905c6171f2aac18e3e5dc53396d85','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86b3acb2d29bff3206e388962fa041c59475a7781993f4fe64117b1786f47e39',1974,'NR','Nauru','communications',283,'LAND:
8.2 sq. mi.; insignificant arable land, no urban areas,
extensive phosphate mines
WATER: AUSTRALIA
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 15 mi.
Railroads: none
Highways: about 17 mi.; 13 mi. paved, 4 mi. improved earth
Inland waterways: none
Ports: 1 minor
Civil air: 1 major transport aircraft
Airfields: 1, coral-surfaced, 5,270 ft.
Telecommunications: adequate interisland and international radi ocomnunications
provided via Australian facilities; 525 telephones; 3,561 radio receivers,
1 AM, but no TV or FM radiobroadcasting facilities
239
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
DEFENSE FORCES:
Military manpower: males 15-49, about 1,800; fit for military service, about
950; average number reaching military age (18) annually, 1971-75, less
than 100
No formal defense structure and no regular armed forces
240
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','f65b8a4457bd92954b3213af4751a5c3324e2351baa42635a83f1b2c18f4983a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('849281b1946db38c136fe0893169a294ba7b57c5be416417947b02c5ecdcd19e',1974,'NP','Nepal','communications',287,'PEOPLE''S REPUBLIC
OF CHINA
LAND:
54,600 sq. mi.s 16% agricultural area, 14% permanent meadows
and pastures, 38% alpine land (unarable), waste, or
urban; 32% forested
Land boundaries: 1,720 mi.
Railroads: 105 mi., all narrow gage (2''6"); mostly government owned; all in Terai
close to Indian border; only 33 mi. sector from border to Bizalpura presently
in use; a 28 mi. segment has been abandoned and 44 mi. utilized to transport
rock from quarry near Dharau to Kosi Dam near Rajbiras
Highways: 1,686 mi.; 510 mi. paved; 270 mi. gravel or crushed stone, 906 mi.
improved and unimproved earth, 200 mi. of seasonally motorable tracks
Civil air: 7 major transport aircraft
Airfields: 49 total, 42 usable; 5.with permanent-surface runways; 6 with runways
4,000-7,999 ft.
Telecommunications: poor telephone and telegraph service; good radiocommunication
and broadcast service; international radiocommunication service is poor; 7,647
telephones, 75,000 radio and no TY sets, 2 AM, no FM, and no TV stations
DEFENSE FORCES:
Military manpower: mates 15-49, 3,108,000; 1,510,000 fit for military service;
140,000 reach military age (17) annually
242
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','438481b9937b218b7d0372b96e8c3fd3f234c32776604dd01219ceb3ad856052','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1183a7c80857ab73e1a7c5e96ab54d28f572894636bcc8394a1d2539ea4cfb4d',1974,'NL','Netherlands','communications',291,'LAND:
i 13,100 sq, mi.; 70% cultivated, 5% waste, 8% forested,
8% inland water, 9% other
Land boundaries: 635 mi.
WATER:
e Limits of territorial waters (claimed): 3 n. mi. ae
(fishing, 12 n. mi.) MOROCCO
Coastline: 280 mi. ; farsi
Railroads: 1,956 mi., standard gage; 970 mi. double track; 1,022 mi. electrified
Highways: 47,845 mi.; 27,800 mi. paved, 4,045 mi. crushed stone and gravel,
16,000 mi. earth
Inland waterways: 3,940 mi.; less than 962 mi. is natural river; more than 1,400
mi. navigable by craft of 1,000-ton capacity; 1,011 mi. will take 1,500-ton
vessels
Pipelines: crude oi1, 260 mi.; refined products, 600 mi.; natural gas, 2,790 mi.
Ports: 8 major, 5 minor
Civil air: 93 major transport aircraft (including 4 foreign-owned but registered
in the Nether lands)
Airfields: 30 total, 26 usable; 16 with permanent-surface runways; 12 with
runways 8,000-11,999 ft., 4 with runways 4,000-7,999 ft.
Telecomunications: highly developed, excellently maintained, and well integrated;
extensive system of multiconductor cables, supplemented by radio-relay links;
4.3 million telephones; 4.81 million radiobroadcast and 4.0 million TV
receivers; 5 AM, 12 FM, and 10 TV stations; 11 coaxial submarine cables;
communications satellite ground station
244
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
NETHERLANDS ANTILLES
LAND:
394 sq. mi.: 5% arable, 95% waste, urban, or other
WATER: i VENEZUELA
Limits of territorial waters (claimed): 3 n. mi. Guvan
Coastline: 226 mi. COLOMBIA','55113c9473e18f90b0815c4544253ce78cd3ca533255f3ab75c979fbdf925b77','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ead451cc976f01053af87e56a9b31c5eb884b473a7f157e1483567ebdb4e0214',1974,'NC','New Caledonia','communications',295,'LAND:
8,500 sq. mi.; 6% cultivable, 22% pasture land, 15% forests,
57% waste or other
WATER: ve AUSTRALIA
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 3.n. mi.)
Coastline: 1,400 mi.
Railroads: none
Highways: 1,572 mi.; 184 mi. paved; 838 mi. gravel, crushed stone, or stabilized
surface; 550 mi. improved earth
Inland waterways: none
Ports: 1 major, 21 minor
Civil air: no major transport aircraft
Airfields: 36 total, 31 usable; 2 with permanent~surface runways; 2 with
runways 4,000-7,999 ft.; 1 airfield over 8,000 ft.; 1 seaplane station
Telecommunications: 12, 438 telephones; 30,000 radio and 12,000 TV sets; 1 AM,
no FM, and 3 TV stations
248
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
NEW HEBRIDES
LAND:
About 5,700 sq. mi.
WATER:
Limits of territorial waters: 3 n. mi.
Coastline: about 1,570 mi.
Railroads: none
Highways: at least 150 mi. sealed or all-weather roads
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Telecommunications: 1 AM broadcast station; 9,000 radio receivers, and 650
telephones
DEFENSE FORCES:
Personnel: no military forces maintained, however, the French and British maintain
constabularies of about 70 men each
249
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
~@&
©
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
STAT
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','cc0d7e387c80c2d5d7585607b69e58807ed54ba490d6f42e5ff44d0d9c04e1f2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42722653667ca05fe3a4e7e40140b0be20a43f38ff3e1bdc7694d8688d923c5b',1974,'NI','Nicaragua','communications',299,'LAND:
57,100 sq. mi.; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other er :
Land boundaries: 760 mi. beosamoreccaw (6
e f : LANSNEZHEEA
WAT ER: ee 4 COLOMBIA
Limits of territorial waters (claimed): 3 n. mi. .
(fishing, 200 n. mi.; continental shelf, including wens
sovereignty over superjacent waters) BRAZIL
Coastline: 565 mi. : oh
Railroads: 220 mi.; 200 mi. of 3''6" gage, government owned; 20 mi. narrow gage,
privately owned
Highways: 8,500 mi.; 900 mi. paved, 3,250 mi. otherwise improved, 4,350 mi.
unimproved
Inland waterways: 1,380 mi., including 2 large lakes
Pipelines: crude oi], 40 mi.
Ports: 4 major, 6 minor
Civil air: 10 major transport aircraft
Airfields: 471 total, 417 usable; 6 with permanent-surface runways; 1 with run-
way 8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: low-capacity wire and radfo-relay network; connection into
Central American microwave net; satellite ground station; 19,500 telephones;
est. 700,000 radio and 62,500 TY receivers; 80 AM, 30 FM, and 5 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 515,000; 305,000 fit for military service;
24,000 reach military age (18) annually
254
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','866269e8852d64fe03e559a019bc1c0d58f0b1c779f1e381eae18ebf68910d78','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('832db792b517bc807112ddb15c2bbb83af971fe6820a3b16fb61053c74dcca6a',1974,'NE','Niger','communications',303,'LAND:
489,000 sq. mi.; about 3% cultivated, perhaps 20% somewhat
arable, remainder desert
Land boundaries: 3,570 mi.
Railroads: none
Highways: approx. 4,440 mi.; 425 mi. bituminous, 1,800 mi. gravel, 2,215 mi-
unimproved earth
Inland waterways: Niger River navigable 185 miles from Niamey to Gaya on the
Dahomey frontier from mid-December through March
Ports: Niger landlocked; outlet to sea is Cotonou, Dahomey
Civil air: 6 major transport aircraft
Airfields: 74 total, 58 usable; 4 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 15 with runways 4,000-7,999 ft.
Telecomunications: principal teleconmunication center Niamey; telephone poor,
telegraph fair, 3,300 telephones; 100,000 radio and 500 TV receivers; 4 AM,
no FM, and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,028,000; 565,000 fit for military service;
about 45,000 reach military age (18) annually
256
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','1eca08f63b436e26f4238f4cb304813af5e8e47e663fc95c77f6351c65810fe1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31c61df994384c94b15b2611d73132f697892432d4e4f0d0540ed5a281fdb2d3',1974,'NG','Nigeria','communications',307,'LAND:
357,000 sq. mi.; 24% arable (13% of total land area
under cultivation), 35% forested, 41% desert, waste,
urban, or other
Land boundaries: 2,507 mi.
WATER:
Limits of territorial waters (claimed): 30 n. mi.
Coastline: 530 mi.
Railroads: 2,180 route mi.; 3''6" gage
Highways: 55,400 mi.; 9,500 mi. paved (mostly bituminous surface treatment);
45,925 mi. laterite, gravel, crushed stone, improved earth
Inland waterways: 5,330 mi. consisting of Niger and Benue rivers and smaller
rivers and creeks; additionally, the newly formed Kainji Lake has several
hundred miles of navigable lake routes
Pipelines: crude oi], 645 mi.; natural gas, 40 mi.; refined products, 3 mi.
Ports: 2 major, 10 minor
Civil air: 14 major transport aircraft
Airfields: 91 total, 78 usable; 14 with permanent-surface runways; 5 with runways
8,000-11,999 ft., 25 with runways 4,000-7,999 ft.; 4 seaplane stations
Telecommunications: composed of radio-relay links, open-wire lines, and radio-
communication stations; principal center Lagos, secondary centers Ibadan
and Kaduna; 96,800 telephones; 5 million radio receivers, 85,000 TV
receivers; 25 AM, 6 FM, and 8 TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 13,770,000; 6,675,000 fit for military service
258
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','4cf2f05c9aaf504c12b162d39e586d95b3513038c7c3039a304a9b29b7b3df4e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34c034c9b9e079a5ee867131720ac04bc4b0eb03cf8d4023aacddd92fa19cb37',1974,'NO','Norway','communications',311,'LAND:
Norway: 125,000 sq. mi.; Svalbard, 24,000 sq. mi.;
Jan Mayen, 144 sq, mi.; 3% arable, 2% meadows
and pastures, 21% forested, 74% other
Land boundaries: 1,603 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 12 n. mi.)
Coastline: mainland 2,125 mi.; islands 1,500 mi. (excludes
long fjords and numerous small islands and minor
indentations which total as much as 10,000 mi. overall)
Railroads: 2,662 mi.; State (NSB) operates 2,636 mi. standard gage, 2,589 mi.
single track, 1,516 mi. electrified, 47 mi. double track; 10 mi. standard
gage electrified privately owned; 16 mi. meter (3''3 3/8") gage electrified
privately owned
Highways: 44,180 mi.; 7,135 mi. paved, 37,045 mi. crushed stone and gravel
Inland waterways: 980 mi.; 5'' draft vessels maximum
Pipelines: refined products, 33 mi.
Ports: 9 major, 69 minor
Civil air: 52 major transport aircraft
Airfields: 93 total, 87 usable; 41 with permanent-surface runways; 11 with
runways 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.; 24 seaplane
stations
Telecommunications: high-quality domestic and international telephone, telegraph,
and telex service; 1.32 million telephones; 2.1 million radiobroadcast receivers;
1 million TV receivers; 36 AM, 253 FM, and 550 TV stations; 5 coaxial submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 915,000; 740,000 fit for military service;
average number reaching military age (20) annually, 32,000
260
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','262de1f71156f735a7593efe5c9ae6362e6caf74c55560ec8efe50cad2426ab4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94bf1aae4bbf20d94883aa6618789f344c9c257a7f83d3a105945b2bbab68061',1974,'OM','Oman','communications',315,'LAND:
About 82,000 sq. mi.; negligible amount forested,
remainder desert, waste, or urban
Land boundaries: 860 mi.
WATER:
Limits of territorial waters {claimed): 12 n. mi,
(fishing 50 n. mi.)
Coastline: 1,300 mi.
Highways: 1,750 totals 3 mi. bituminous surface, remainder motorable natural-
surface track
Pipelines: crude oi] 230 mi.
Ports: 1 major, 6 minor
Civil air: no major transport aircraft
Airfields: 214 total, 131 usable; 4 with permanent-surface runways; 3 with runways
8,000-11,999 ft., 47 with runways 4,000-7,999 ft.
Telecommunications: poor international radioconmunications (service to Bahrain
only); very poor domestic wire service; 2,200 telephones; 1 AM station
DEFENSE FORCES:
Military manpower: males 15-49, 115,000; 66,000 fit for military service
261
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
=<
PAKISTAN PEOPLE''S REPUBLIC
OF CHINA
LAND:
310,000 sq. mi. (includes Pakistani part of Jammu-Kashmir)
40% arable, including 24% cultivated; 23% unsuitable
for cultivation; 34% unreported, probably mostly waste
3% forested
Land boundaries: 3,650 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing
50 n. mi.3 plus right to establish 100 n. mi, con-
servation zones beyond territorial sea)
Coastline: 650 mi.
Railroads: 5,465 mi.; 277 mi. meter gage, 4,808 broad gage, 380 narrow gage;
635 double track; 178 mi. electrified; government owned
Highways: 43,500 mi.; 10,306 mi. paved, 7,792 mi. gravel, 1,163 mi. improved earth;
24,239 unimproved earth
Inland waterways: 1,150 mi.
Pipelines: crude of], 143 mi.; natural gas, 1,200 mi.
Ports: 1 major, 5 minor
Civil air: 19 major transport aircraft
Airfields: 203 total, 110 usable; 64 with permanent-surface runways; 1 with runway
over 12,000 ft., 27 with runways 8,000-11,999 ft., 54 with runways 4,000-
7,999 ft.
Telecommunications: excellent international radiocommunication service over
CENTO links; domestic wire and radiocommunication and broadcast service very
good; 175,026 (est.) telephones; 1,010,000 radio and 125,000 TV sets; 19 AM,
no FM, and 3 TV stations
DEFENSE FORCES: mn ‘
Military manpower: males 15-49, 14,048,000; 7,550,000 fit for military service;
689,000 reach military age (17) annually
264
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','77c5343ee6eb6572fb2d47db440563b001538f071fffffa2c15087f7ea273176','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57aaa03e8f07d6b6a2438afc211cd2ad599987f81f957a03dd3a8c9583716362',1974,'PA','Panama','communications',319,'LAND:
29,208 sq. mi. (excluding Canal Zone, 553 sq. mi.); 24%
agricultural land (9% fallow, 4% cropland, 11% :
pasture), 20% exploitable forest, 56% other forests, ;
urban, and waste ee
Land boundaries: 390 mi. : ae Os
WATER: es :
Limits of territorial waters (claimed): 200 n. mi. ee BRAZIL
(continental shelf including sovereignty over super-
jacent waters)
Coastline: 1,545 mi.
Railroads: 305 mi.; 48 mi. 5''0" gage, 107 mi. 3''0" gage; 150 mi. plantation
feeder lines
Highways: 4,400 mi.; 1,300 mi. paved, 1,000 mi. gravel or crushed stone, 2,100 mi.
improved and unimproved earth; Panama Canal Zone 145 mi.; 140 mi. paved;
5 mi. gravel
Inland waterways: 500 mi. navigable by shallow draft vessels; 5l-mile
Panama Canal
Pipelines: refined products, 60 mi.
Ports: 2 major, 10 minor
Civil air: 30 major transport aircraft
Airfields: 238 total, 121 usable; 22 with permanent-surface runways; 3 with
runways 8,000-11,999 ft.; 10 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: domestic and international telecom facilities well developed,
including nearly nationwide radio-relay system; connection into central
American microwave net; communications satellite ground station; 115,000
telephones; 550,000 radio and 230,000 TV receivers; 80 AM, 22 FM, and 13 TY
stations; 1 coaxial submarine cable
DEFENSE FORCES: m3 :
Military manpower: males 15-49, 354,000; 245,000 fit fcr military service;
no conscription
266
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','3fc69ee1596cd66879980e17429558223a818f777d2046144e3591b9759763af','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df5321415f720b42c15cc7b8b9121427a7b2e28a9cb09270c8e00dd38eecf8c9',1974,'PG','Papua New Guinea','communications',323,'LAND:
183,540 sq. mi. (Papua 90,540 sq. mi., New Guinea
93,000 sq. mi.)
Land boundaries: 600 mi.','589f383e82328b5f5ea8f5462797a3d850c2f6a6b66f43d91fc939703926161c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e0037a3788032f0ea5bedba1ed4cba694dbdb0a01c2cbb0f8d1680c15af988b',1974,'PY','Paraguay','communications',324,'BRAZIL.
LAND:
157,000 sq. mi.; 2% under crops, 24% meadow and pasture,
52% forested, 22% urban, waste, and other
Land boundaries: 2,140 mi.
Railroads: 652 mi.; 273 mi. standard gage, 85 mi. 3''3 3/8'''' gage, 294 mi. various
narrow gage (privately owned)
Highways: 9,900 mi.; 400 mi. bituminous treated, 3,100 mi. otherwise improved,
6,400 mi unimproved earth
Inland waterways: 1,970 mi.
Ports: 1 major, 9 minor (all river)
Civil air: 5 major transport aircraft
Airfields: 1,111 total, 863 usable; 1 with permanent-surface runway; 2 with runways
8,000-11,999 ft., 25 with runways 4,000-7,999 ft.; 1 seaplane station
Teleconmunications: local telecom facilities in Asuncion good, intercity microwave
net; 31,000 telephones; est. 730,000 radio and 60,000 TV receivers; 25 AM, 7
FM, and 1 TV station; COMSAT station under construction
DEFENSE FORCES:
Military manpower: males 15-49, 624,000; 430,000 fit for military service;
average number currently reaching military age (17) annually, 25,000
270
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','5c417011cd21b6ea26c98cd4d62bc64aafdf19254bb7b8783be34333b3e19377','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1299a1db222053323714b85ea111ff1f00dbbdeed6be2fe91d5290f21eec72a4',1974,'PH','Philippines','communications',328,'LAND:
116,000 sq. mi.; 53% forested, 30% arable land, 5%
permanent pasture, 12% other
WATER:
Limits of territorial waters (claimed): 0-300 n. mi.
(under an archipelago theory, waters within straight
lines joining appropriate points of outermost islands
are considered internal waters; waters between these
baselines and the limits described in the Treaty of
Paris, December 10, 1898, the U.S.-Spain Treaty of
November 7, 1900, and the U.S.-U.K. Treaty of January 2,
1930 are considered to be the territorial sea)
Coastline: about 14,000 mi.
Railroads: 2,177 mi.; 2 common-carrier systems (3''6" gage) totaling about 727
mi.s 19 industrial systems with 4 different gages totaling 1,450 mi.; 34%
government owned
Highways: 45,690 mi.; 8,886 mi. paved; 23,770 mi. gravel, crushed stone, or
stabilized soil surface; 13,034 mi. improved earth
Inland waterways: 2,000 mi.; limited to shallow-draft (less than 5 ft.) vessels
Pipelines: refined products, 157 mi.
Ports: 11 major, 100 minor
Civil air: 75 major transport aircraft
Airfields: 425 total, 314 usable; 45 with permanent-surface runways; 7 with
runways 8,000-11,999 ft., 24 with runways 4,000-7,999 ft.; 8 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,209,000; 6,020,000 fit for military service;
about 392,000 reach military age (20) annually
Supply: produces some smal] arms ammunition; other materiel obtained almost
exclusively from U.S.; naval ships and equipment from Australia, Japan, and
Italy; aircraft and helicopters from West Germany, Italy, and U.S.
Military budget: for fiscal year ending 30 June 1974, $294 million; about 20%
of total budget
274
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','1f75f812adf06bb5c39a429dc563d592de97e13d418eea1f12a861601f33fd7c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('282a7bd08e43f88fcad101d3bce0d05c3a14d819796f46f9830fab4287b0fbe3',1974,'PL','Poland','communications',332,'LAND:
= 120,600 sq. mi.; 49% arable, 14% other agricultural, 27%
forested, 10% other
Land boundaries: 1,920 mi.
WATER:
« Limits of territorial waters (claimed): 3 n, mi. eee ee
(fishing, 12 n. mi.) 3 : Me
Coastline: 305 mi. yo eee a
HEYA EGY PE ARABIA Te,
Railroads: 16,470 route mi.; 14,380 mi. standard gage, 2,090 mi. narrow gage;
4,645 mi. double track; 2,400 mi. electrified; government owned (1972)
Highways: 190,095 mi.; 40,390 mi. paved; 39,480 mi. crushed stone, gravel;
110,225 mi. earth (improved and unimproved) (1972)
Inland waterways: 3,158 mi. navigable streams and canals (1973)
Pipelines: 2,100 mi. for natural gas; 875 mi. for crude oil; 200 mi. for refined
products
Freight carried: rail -- 458.5 million short ton, 75.2 billion short ton/mi.
(1972); highway 1,264.0 million short tons, 14.5 billion short ton/mi. (1972);
waterway -- 11.3 million short tons, 1.3 billion short ton/mi. excl. int.
transit traffic (1973)
Ports: 4 major (Gdansk, Gdynia, Szczecin, Swinoujscie}, 6 minor (1974)
Civil air: 51 major transport aircraft (1974)
Airfields: 146 total; 76 with permanent-surface runways; 37 with runways 8,000-
11,999 ft., 70 with runways 4,000-7,999 ft.
276
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
| nena wee
ARELAND S23
KINGDOM.
PORTUGAL oe aS gi “BE away a
LAND:
Metropolitan Portugal: 36,400 sq. mi., including the Azores
and Madeira Islands; 48% arable, 6% meadow and pasture,
31% forested, 15% waste and urban, inland water, and
other
Cape Verde Islands: 1,560 sq. mi., divided among 10 islands
and several islets (not a part of Metropolitan Portugal)
Land boundaries: 750 mi.
MOROCCO : ALGERIA
WATER:
UNITED “NETH. /reD]
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 535 mi. (excludes Azores, Maderia, and Cape
Verde Islands, 1,180 mi.)
Railroads: 2,230 mi.; 472 mi. meter gage (3''3 3/8"), 1,758 mi. broad gage
(5''5 9/16"); 265 mi. double track; 482 mi. electrified
Highways: 18,500 mi.; 11,000 mi. bituminous, bituminous treatment, concrete and
stoneblock; 7,200 mi. gravel and crushed stone; 300 mi. improved earth; plus
an additional 10,500 mi. of unimproved earth roads (motorable tracks)
Inland waterways: 508 mi. navigable; relatively unimportant to national economy,
used by shallow-draft craft limited to 330-ton cargo capacity
278
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Pipelines: crude oil 7 mi.
Ports: 7 major, 33 minor
Civil air: 25 major transport aircraft
= Airfields (including Azores, Cape Verde Islands, and Madeira Islands): 54 total,
44 usable; 26 with permanent-surface runways; 1 with runways over 12,000 ft.,
10 with runways 8,000-11,999 ft., 9 with runways 4,000-7,999 ft.3 6 seaplane
stations
Teleconmunications: facilities are generally adequate; 931,700 telephones; 1.67
606,500 television receivers; 37 AM, 34 FM, and 36
million radio receivers;
TV stations; 2 coaxial submarine cables; COMSAT station under construction
DEFENSE FORCES:
Military manpower: males 15-49, 2,080,000; 1,610,000 fit for military service;
average number reaching age (20) annually, about 71,000
279
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
PORTUGUESE GUINEA
LAND ;
14,000 sq. mi. (includes Bijagos archipelago)
Land boundaries: 460 mi.
WATER:
Limits of territorial waters (claimed): 6 n, mi.
(fishing 12 n. mi.)
Coastline: 170 mi.
Railroads: none
Highways: approx. 2,000 mi. (260 mi. bituminous, remainder earth)
Iniand waterways: 994 mi.
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 63 total, 60 usable; 4 with permanent-surface runways; 9 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: limited telephone and telegraph service; 2,700 telephones;
9,800 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 115,000; 65,000 fit for military service
Defense is responsibility of Portugal
282
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
PORTUGUESE TIMOR
LAND:
7,000 sq. mi.; 34% forest, 33% grassland, and 33%
cultivated
Land boundaries: 90 mi.','efc279d9e873804d6225e53120a491d5409ee958409cf7d85a15a63aecee6a1b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb5328d0c99fa33ffb2ba172bf0828bc967ef188af77d315deb41d159b4a9c4e',1974,'QA','Qatar','communications',336,'LAND:
About 4,000 sq. mi.; negligible amount forested; mostly
desert, waste, or urban
Land boundaries: 35 mi.
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 350 mi.
Railroads: none
Highways: 275 mi. bituminous; 225 mi. gravel surfaced; undetermined mileage of
earth tracks
Pipelines: crude of], 105 mi.; natural gas, 60 mi.
285
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Ports: 1 major, 17 minor
Airfields: 10 total, 1 usable; 1 with permanent-surface runway over 12,000 ft.
Civil air: 1 major transport aircraft, registered in the U.S.
Telecommunications: all international telecom traffic is by tropospheric scatter
through Bahrain; fair domestic wire facilities; 14,600 telephones; 35,000 radio
and 28,000 TV receivers; 1 AM and 1 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 39,000; about 22,000 fit for military
service
286
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
REUNION
LAND:
970 sq. mi.; two-thirds of island extremely rugged,
consisting of volcanic mountains; 120,000 acres (less
than one-fifth of the land) under cultivation
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 125 mi.
Railroads: none
Highways: 1,366 mi.; 1,056 mi. paved, 310 mi. gravel, crushed stone, or stabilized
earth
Ports: 1 major
Civil air: no major transport aircraft
Airfields: 6 total, 6 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.
Teleconmunications: adequate system for size of island of fairly modern open-wire
lines and radiocommunication stations; principal center Saint-Denis; external
radiocommunications to Comoro Islands, France, Malagasy, and Mauritius;
19,300 telephones; 90,000 radio and 30,000 TV receivers; 2 AM, no FM, and
8 TV stations
DEFENSE FORCES:
Military manpower: military age males included with France
288
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
RHODESIA
LAND:
151,000 sq. mi.; 40% arable (of which 6% cultivated); 60%
available for extensive cattle grazing; European
alienated lands (farmed by modern methods) 39%,
African 48%, national land 7%, 6% not alienated
Land boundaries: 1,875 mi.
Railroads: 1,610 mi. narrow gage (3''6"); 26 mi. double track
Highways: 48,733 mi.3 4,968 mi. paved, 20,415 mi. crushed stone, gravel,
stabilized soil, or improved earth; 23,350 mi. unimproved earth
Inland waterways: 175 mi. on Lake Kariba
Airfields: 336 total, 231 usable; 8 with permanent-surface runways; 1 with run-
way over 12,000 ft., 23 with runways 4,000-7,999 ft.
Civil air: 13 major transport aircraft
Telecommunications: system is one of the best in Africa; consists of radio-relay
links, open-wire lines, and radiocommunication stations; principal center
Salisbury, secondary center Bulawayo; 151,200 telephones; 225,000 radio
and 57,000 TV receivers; 8 AM, no FM and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,343,000; 840,000 fit for military service;
average number reaching military age (18) annually, 63,000
290
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','6101149a65f2efdd1b9a347ad85d0b9d942f92c1bd2cb5721cedff5dc9905f19','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1b569ba18529352aedfe90b23206b815fedc6985f6067c15ad3839cbfcc794a',1974,'RO','Romania','communications',340,'LAND:
91,700 sq. mi.; 44% arable, 19% other agriculture, 27%
forested, 10% other
Land boundary: 1,845 mi.
WATER: TURKEY
Limits of territorial waters (claimed): 12 n. mi. mak
Coastline: 140 mi. aaa
PEOPLE: LIBYS EGYPT: 3. ARAGIA
Population: 21,059,000, average annual growth rate 1.0%
(current)
Ethnic divisions: 87% Romanian, 8% Hungarian, 2% German,
3% other
Religion: 14 million Romanian Orthodox, 1 million Roman Catholic, 1 million
Protestants, 100,000 Jews, 30,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.4 million (est. 1 July 1966); 57% agriculture, 19% industry,
24% other nonagricultural
Railroads: 7,464 mi.; 6,442 mi. standard gage, 1,014 mi. narrow gage, 8 mi.
Gea 404 mi. electrified, 852 mi. double track; government owned
1973
Highways: 48,000 mi.; 7,600 mi. paved; 16,300 mi. other improved surfaces,
24,100 mi. earth (1970)
Inland waterways: 1,445 mi. (1974)
Pipelines: crude oi1, 1,600 mi.; refined products, 888 mi.; natural gas, 3,100
mi.
Freight carried: rail -- 218.3 million short tons, 33.8 billion short ton/mi.
(1972); highway -- 515 million short tons, 5.3 billion short ton/mi. (1971);
waterway -- 16.4 million short tons, 6.9 billion short ton/mi. (incl. int''l.
transit traffic) (1972)
Ports: 4 major (Constanta, Galati, Braitla, Mangalia), 2 minor (1974)
Civil air: 56 major transport aircraft (1974)
Airfields: 165 total; 25 with permanent-surface runways; 11 with runways 8, 000-
11,999 ft.; 24 with runways 4,000-7,999 ft.
292
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','1d04b537ebd545a9e12e91ab0e034a2575c57930016437b93d99b34210f6f8ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fcc9b844eb3b9af76cfbe1c96fd079f6dfc6a6d76b6c05bf9aade0641665867',1974,'RW','Rwanda','communications',343,'LAND:
10,000 sq. mi.; almost all the arable land, about 1/3
under cultivation, about 1/3 pastureland
Land boundaries: 545 mi.
Railroads: none
Highways: 3,815 mi.; 36 mi. paved, 19 mi. gravel, 1,367 mi. improved earth,
2,393 mi. unimproved; 2,485 mi. secondary roads; most roads improved or
unimproved earth
Inland waterways: Lake Kivu navigable by steamers and barges
Civil air: no major transport aircraft
Airfields: 20 total, 14 usable; 2 with permanent-surface runways; 2 with
runways 4,000-7,999 ft., 1 with runway 8,000-11,999 ft.
Telecommunications: telephone and telegraph limited; main center is Kigali;
2,450 telephones; 55,000 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 935,000; 450,000 fit for military service; no
conscription; 38,000 reach military age (18) annually
294
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ST. CHRISTOPHER-NEVIS-ANGUILLA
LAND:
150 sq. mi.; 40% arable, 10% pasture, 17% forest, 33%
wasteland and built-on
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi.
Railroads: 36 mi., narrowgage (2''6") on St. Kitts for sugar cane
Highways: 180 mi.; 60 mi. paved, 90 mi. otherwise improved, 30 mi. unimproved
earth
Ports: 3 minor (1 on each island)
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 1 with asphalt runway 5,700 ft.
Telecommunications: good interisland VHF radio connections and international
link via Antigua; about 1,700 telephones; 5,000 radio and 1,500 TV receivers;
5 AM and 5 TV stations
296
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ST, LUCIA
LAND:
238 sq. mi.; 50% arable, 3% pasture, 19% forest, 5%
unused but potentially productive, 23% wasteland
and built-on
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 98 mi.','8386535293ba2975f33311cd4e3974375c41a0f3fb71099ab5c7b1ff66773939','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad2b6f0e9d18fada6589a9b20e3e391eacdff548da7eb73bac7d29fb973328e9',1974,'SA','Saudi Arabia','communications',347,'LAND:
618,000 sq. mi. (boundaries are poorly defined); 1%
agricultural, 1% forested, 98% desert, waste, or
urban
Land boundaries: 2,820 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (plus
6 n. mi. "necessary supervision zone")
Coastline: 1,560 mi.
Railroads: 350 mi., 4''8 1/2" gage
Highways: 8,700 mi.; 5,400 mi. bituminous, 3,300 mi. gravel and improved earth,
undetermined mileage of earth roads and tracks
Pipelines: crude oil, 1,435 mi.; refined products, 95 mi.; natural gas, 95 mi.
Ports: 3 major, 6 minor
Civil air: 17 major transport aircraft
Airfields: 239 total, 78 usable; 19 with permanent-surface runways; 12 with
runways 8,000-11,999 ft., 42 with runways 4,000-7,999 ft., 1 with runway over
12,000 ft.
Telecommunications: excellent international radio communications; fair domestic
service; 84,100 telephones; 250,000 radio and 150,000 TV receivers; 11
TV, 1 FM, and 4 AM stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 1,410,000; 755,000 fit for military service;
about 62,000 reach military age (18) annually
304
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Railroads: none
Highways: 2,160 mi.; 290 mi. bituminous; 270 mi. crushed stone and gravel;
1,600 mi. earth, sand, and light gravel
Ports: 1 major, 2 minor
Civil air: 9 major transport aircraft
Airfields: 35 total, 20 usable; 6 with permanent-surface runways; 1 with
runway over 12,000 ft., 4 with runways 8,000-11,999 ft., 9 with runways
4,000-7,999 ft.
Telecommunications: systems among mideast''s worst; consists of meager open-wire
lines and low-power radio communication stations; principal center Sana,
secondary centers Al Hudaydah and Taizz; 4,600 telephones; 86,000 radio
receivers; 1 AM radio-broadcast station
DEFENSE FORCES:
Military manpower: males 15-49, 1,520,000; 810,000 fit for military service;
about 67,000 reach military age (18) annually; univeral military conscription
law (10 January 1963) makes military service obligatory for all Yemeni
males 18-30
382
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ee
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
YUGOSLAVIA
LAND:
98,800 sq. mi.; 32% arable, 25% meadows and pastures,
34% forested, 9% other
Land boundaries: 1,865 mi.
WATER:
Limits of territorial waters (claimed): 10 n. mi.
(fishing, 12 n, mi.)
Coastline: 945 mi. (mainland), plus 1,500 mi. (offshore
islands)
Railroads: 6,393 route mi.; 5,710 mi. standard gage, 683 mi. narrow gage;
463 mi. double track; 940 mi. electrified (1972)
Highways: 59,742 mi.; 379 mi. concrete, 17,429 mi. bituminous, 752 mi. stone
block, 24,873 mi. gravel, 16,309 mi. earth (1972)
Inland waterways: 1,231 mi. (1974)
Freight carried: rail -- 79.2 million short tons, 15.0 billion short ton/mi. (1972);
highway -- 81.4 million short tons, 5.6 billion short ton/mi. (1972);
waterway -- 28.6 million short tons, est. 9.3 billion short ton/mi. (incl. int''l.
transit traffic) (1973)
Pipelines: crude oi], 200 mi.; natural gas, 320 mi.
Ports: 9 major (most important: Rijeka, Split), 24 minor (1974)
Civil air: 43 major transport aircraft (including 4 leased} (1974)
Airfields: 93 tot=1; 35 with permanent-surface runways; 19 with runways 8,000-
10,999 ft., 28 with runways 4,000-7,999 ft.; 2 seaplane stations
384
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
«4
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ZAIRE
LAND:
905,000 sq. mi.; 22% agricultural land (1% cultivated),
45% forested, 33% other
Land boundaries: 6,153 mi.
WATER:
Limits of territorial waters (claimed): 12 n, mi.
Coastline: 23 mi.
Railroads: 3,218 mi.; 2,419 mi. 3°6" gage, 78 mi. 3'' 3 3/8" gage, 85 mi.
2'' 0 1/4" gage, 636 mi. 1'' 11 5/8" gage; 532 mi. of 3''6" gage electrified
Highways: 87,800 mi.; 1,200 mi. bituminous, 11,300 mi. gravel or crushed stone,
75,300 mi. earth
Inland waterways: comprising the Zaire, its tributaries, and unconnected lakes,
the waterway system affords over 9,320 mi. of navigable routes
Ports: 2 major, 1 minor
Pipelines: refined products, 460 mi.
Civil air: 30 major transport aircraft
Airfields: 499 total, 329 usable; 320 with permanent-surface runways; 1 with
runway over 12,000 ft., 2 with runways 8,000-11,999 ft., 54 with runways
4,000-7,999 ft.; 5 seaplane stations
Telecommunications: limited, barely adequate telephone service, telegraph service
good; 24,200 telephones; 100,000 radio receivers; 7,100 TV receivers; 12 AM,
] FM, and 2 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 5,816,000; 2,795,000 fit for military service
386
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','06bf5236ae142344a9bcb2263c59f1821f14ea0788c93a2a06632c73523bf155','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef0d89c138be5b82557017bf7aa81cb5501aecb50c638c3777f54ec62ae468ed',1974,'SN','Senegal','communications',351,'LAND:
76,000 sq. mi.; 13% forested, 40% agricultural (12%
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 1,665 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (fishing
110 n. mi.; fisheries zone beyond territorial sea)
Coastline: 330 mi.
Railroads: 640 mi. meter gage; 40 mi. double track
Highways: 8,725 mi.; 1,335 mi. bituminous, 990 mi. gravel, 400 mi. improved
earth, 6,000 mi. unimproved earth
Inland waterways: 935 mi.
Ports: 1 major, 2 minor
Civil air: 5 major transport aircraft
Airfields: 42 total, 27 usable; 9 with permanent-surface runways; 1 with runway
8,000~-11,999 ft., 19 with runways 4,000-7,999 ft.; 3 seaplane stations
Teleconmunications: relatively advanced for Africa; 29,300 telephones; 280,000
radio receivers; 1,600 TV receivers; 3 AM, no FM, and 1 TV stations; 3
submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 942,000; 455,000 fit for military service;
50,000 reach military age (18) annually
306
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','fcd4338fbc085e14e28c520dd101d64923813c078257be5e9b4878774c25f5da','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f6cb4131c0eb74d2300084aa7836fea02cb2fdea20b549a06610a94614d74c4',1974,'SC','Seychelles','communications',355,'LAND:
156 sq. mi.; 54% arable land, nearly all of it is under
cultivation, 17% wood and forest Tand, 29% other
(mainly reefs and other surfaces unsuited for
agriculture); 40 granitic and 43 coral islands
° WATER:
Limits of oe waters (claimed): 3 n. mi. (fishing
12 on. mi.
Coastline: 305 mi. (Mahe Island 58 mi.)
Railroads: none
Highways: 141 mi.; 78 mi. bituminous, 63 mi. crushed stone or earth
Ports: 1 minor port (Victoria)
Civil air: no major transport aircraft
Airfields: 3 total, 1 usable on Prasin Island, 1 usable on Astove Island, 1
permanent surface 8,000-11,999 ft. on Mahe Island; former RAF seaplane
station at Victoria, Mahe Island, although not in present use, could be
used in emergency
Telecommunications: direct radiotelegraph communications with other adjacent
islands and African coastal countries: 2,000 telephones; 15,000 radio sets;
no TY sets; 2 AM, no FM, and no TY stations; submarine cables extend to
Aden, Tanzania, and Sri Lanka
DEFENSE FORCES:
Military manpower: males 15-49, 13,000; 7,000 fit for military service
308
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','6da8c0df71c1aa74d640cbb10ad1385883fea9b8ae3e9eea092693a7e5a3dcbd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b472bf5a5e7a587e1116653ee0cd85b69fb9b3c1856ca032e3c0f4230d3f6b1',1974,'SL','Sierra Leone','communications',359,'LAND:
27,900 sq. mi.; 65% arable (6% of total land area under
cultivation), 27% pasture, 4% swampland, 4% forested
Land boundaries: 580 mi.
WATER:
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 250 mi.
Railroads: 370 route miles; 310 mi. narrow gage (2''6") Sierra Leone Government
Railroad (SLR), 60 mi. narrow gage (3''6") privately owned mineral line
operated by the Sierra Leone Development Company
Highways: 5,130 mi.; 550 mi. bituminous (including some bituminous treatment),
1,470 mi. laterite (some gravel), and 3,110 mi. earth
Inland waterways: 500 mi.; 372 mi. navigable year-round
Ports: 1 major, 2 minor
Civil air: no major transport aircraft
Airfields: 15 total, 15 usable; 5 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 4 with runways 4,000-7,999 ft.; 1 seaplane station
Teleconmunications: telephone and telegraph are adequate; 6,200 telephones;
60,000 radio and 6,000 TY receivers: 1 AM, no FM, and 1 TV stations;
3 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 632,000; 303,000 fit for military service; no
conscription
310
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
SIKKIM
PEOPLE''S REP.
OF CHINA
LAND:
2,800 sq. mi.
Land boundaries: 265 mi.
Railroads: none
Highways: 575 mi.; 252 mi. paved, 129 mi. crushed stone or gravel, 194 mi. earth
Civil air: no major transport aircraft
Airfields: 1 gravel runway 600 ft.
311
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','a136cfe0f94f4fd105efc679c2baf39f8ef22359d9a35304f681acced967f043','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7db15503229d04f17588835817f62aea7249a9ed678d7c6a8c01fcd11fc5de8',1974,'SG','Singapore','communications',363,'LAND:
225 sq. mi.3; 31% built up area, roads, railroads, and
airfields, 22% agricultural, 47% other
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi.','754ff27aba7a4bab774ab07dea9ba81da1ff1a2b9d421ec4372bfadc9f8cdfc6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f30ef90abf9c591e03e339fa636c13de44368c6536ea1973bd70f8d1bc9fe79',1974,'ES','Spain','communications',372,'- Railroads: 10,484 mi.; 8,374 mi.; (5''6" gage), 2,110 mi. other gages (4''8 1/2"
to 1''11 5/8"), 1,346 mi., double track; 2,368 mi. electrified
Highways: 86,600 mi.; national -- 35,175 mi. bituminous treatment, 9,400 mi.
crushed stone, 4,225 mi. bituminous, stone block and concrete; provincial
-- 18,200 mi. bituminous treatment, crushed stone, 1,200 mi. bituminous,
concrete, and stone block
Inland waterways: about 650 mi.; of minor importance as transport arteries and
contribute little to economy
Pipelines: crude oi], 230 mi.; refined products, 515 mi.; natural gas, 90 mi.
Ports: 23 major, 20 minor
Civil air: 171 major transport aircraft (including 2 foreign owned but Spanish
registered)
Airfields (including Balearic and Canary Islands): 122 total, 83 usable; 47
with permanent-surface runways; 4 with runways over 12,000 ft., 18 with
runways 8,000-11,999 ft., 34 with runways 4,000-7,999 ft.; 5 seaplane
stations
Telecommunications: generally adequate, modern facilities; 6.24 million telephones;
8.2 million radio and 5.42 million television receivers; 170 AM, 230 FM, and
650 TV stations; 6 coaxial submarine cables; 3 communication satellite ground
stations
DEFENSE FORCES:
Military manpower: males 15-49, 8,544,000; 6,560,000 fit for military service;
275,000 reach military age (20) annually
323
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
SPANISH SAHARA
LAND:
103,000 sq. mi., nearly all desert
Land boundaries: 1,296 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n, mi.)
Coastline: 690 mi.
Railroads: none
Highways: 3,790 mi.; 305 bituminous treated, 3,485 mi. unimproved earth roads
and tracks
Ports: 2 major, 2 minor
325
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUNICATIONS (cont''d):
Civil air: no major transport aircraft
Airfields: 25 total, 17 usable; 3 with permanent-surface runways; 5 with
runways 4,000-7,999 ft.
Telecommunications: telephone poor, telegraph poor to fair; 600 telephones;
16,000 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 15,000; 7,000-8,000 fit for military service
326
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
SRI LANKA (formerly Ceylon)
PEOPLE''S REPUBLIC
OF CHINA
LAND: fe
25,300 sq. mi.; 25% cultivated; 44% forested; 31% waste, ribeny/) ey
urban, and other 22
WATER:
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi. plus pearling in the Gulf of
Mannar, and right to establish 100 n. mi. conservation
zone)
Coastline: 835 mi.
Railroads: 938 mi.; 851 mi. 5''6" gage, 87 mi. 2''6" gage; 63 mi. double track;
no electrification; government owned
Highways: 25,580 mi.; 11,700 mi. paved (mostly bituminous treated), 11,500 mi.
crushed stone or gravel, 530 mi. improved earth, 1,850 mi. unimproved earth;
in addition several thousand. mi. of tracks, mostly unmotorable
Inland waterways: 270 mi.; navigable by shallow-draft craft
Ports: 3 major, 9 minor
Civil air: 5 major transport (including 1 leased)
Airfields: 18 total, 11 usable; 10 with permanent-surface runways; 1 with
runway 8,000-11,999 ft., 6 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: an inadequate telephone and a less extensive but more
efficient telegraph system serves most areas, with greatest concentration
around Colombo and Kandy; all areas are served by radio and/or wire
broadcast; excellent international service; 65,329 (est.) telephones; 515,000
radio sets, no TV sets; 7 AM stations, no FM, and no TV stations; submarine
cables extend to India, Malaysia, Seychelle Islands, and Aden
DEFENSE FORCES:
Military manpower: males 15-49, 3,362,000; 2,528,000 fit for military service;
153,000 reach military age (18) annually
328
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','44687567a95d3b00375d1393ed257a7dba0cc4fffc76cc615f9263bc6ce2344e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b18f2bae92e18a393685a4a98362540564973139a81941880d7bc978056de086',1974,'SD','Sudan','communications',374,'LAND:
967,000 sq. mi.; 37% arable (3% cultivated), 15% grazing,
33% desert, waste, or urban, 15% forest
Land boundaries: 4,850 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (plus
6 n. mi. "necessary supervision zone")
Coastline: 530 mi.
Railroads: 2,950 mi.; 2,730 mi. 3''6" gage, 440 mi. 2'' gage plantation line
highways: 6,550 mi.; 190 mi. bituminous-treated, 680 mi. crushed stone or aravel,
and 5,680 mi. improved and unimproved earth roads; in addition, there are an
undetermined number of tracks
Inland waterways: 3,3CO mi. navigable
Ports: 1 major, 7 minor
Civil air: 5 major transport aircraft
Airfields: 90 total, 69 usable; 8 with permanent-surface runways; 2 with runways
8,000-11,999 ft., 30 with runways 4,000-7,999 ft.
Telecommunications: large system by African standards, but still barely adequate
for size of country; consists of open-wire lines, radio-relay links, multi-
conductor cables, radio communication stations and a tropospheric scatter
link; principal center of Khartoum, secondary centers at Al Fashir and
Port Sudan; 51,800 telephones; 650,000 radio and 62,500 TV receivers; 2 AM,
no FM, and 1 TV stations; 5 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,889,000; 2,310,000 fit for military service;
average number reaching military age (18) annually, 160,000
330
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
SURINAM','ef21531392d5fc21ee3f1c1befabd886fd14012c3b2c156cdfc616d4440e5b70','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a7a8d1bc4b9e5f0edf94e7d4353c97c54b1de7d98943c4fc0e11a25e6ac9ec1',1974,'SE','Sweden','communications',378,'LAND:
173,000 sq. mi.; 8% arable, 1% meadows and pastures, 55%
forested, 36% other
Land boundaries: 1,365 mi.
WATER:
Limits of territorial waters (claimed): 4 n. mi.
(fishing; 12 n. mi.)
Coastline: 2,000 mi.
wh,
HBA leona hes 7
: es
Railroads: 7,561 mi.; Swedish State Railways (Sd) -- 7,004 mi. standard gage
(4''8 1/2"), 165 mi. narrow gage (3''6" and 2''11"), 4,373 mi. electrified, 725
mi. double tracked; 294 mi. standard gage (4'' 8 1/2"), 98 mi. narrow gage
(2''11"), 284 mi. electrified are privately owned and operated
Highways: 61,000 mi.; 44,550 mi. are crushed stone, gravel, or improved earth;
and 16,395 mi. are bitumen, concrete, stone block, or cobblestone
Inland waterways: 1,268 mi. navigable for small steamers and barges
Ports: 17 major, and 23 significant minor
Civil air: 61 major transports
Airfields: 246 total, 216 usable; 115 with permanent-surface runways; 6 with
runways 8,000-11,999 ft., 82 with runways 4,000-7,999 ft.; 9 seaplane stations
Telecommunications: excellent domestic and international facilities; 5 million
telephones; 21 AM, 87 FM, and 217 TV stations; 5 million radio and 3.1 million
TV receivers; 10 submarine cables, including 4 coaxial; COMSAT ground station
DEFENSE FORCES:
Military manpower: males 15-49, 1,884,000; 1,675,000 fit for military service;
56,000 reach military age (19) annually
336
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','8368ff635b5377bfb45a9ada42bec92e9b4c4bd899c3a1a2cc4880bac12d90a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de5b311b34441bd6d1c71b89bec1d8ad005d527524bb476f6457fda1b83dbe97',1974,'CH','Switzerland','communications',382,'LAND:
16,000 sq. mi.; 10% arable, 43% meadows and pastures, 20%
waste or urban, 24% forested, 3% inland water
Land boundaries: 1,171 mi.
PEQPLE:
Population: 6,500,000, average annual growth rate 0.9%
(1/72-1/73)
Ethnic divisions: total population -- 69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals -- 74% German, 20% French, 4% Italian,
1% Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals -- 74% German, 20% French, 4% Italian, 1% Romansch,
1% other; total population -- 69% German, 19% French, 10% Italian, 1%
Romansch, 1% other
Literacy: 98%
Labor force: 3.0 million, about one-fifth foreign workers, mostly Italians
16% agriculture and forestry, 47% industry and crafts, 20% trade and
transportation, 5% professions, 2% in public service, 10% domestic and
others no significant unemployment shortage of both skilled and
unskilled labor -- 6,537 unfilled vacancies in April 1972
Organized labor: 20% of labor force
Railroads: 3,186 mi.; 1,809 government owned (SBB), 1,763 mi. 4'' 8 1/2" gage,
46 mi. 3'' 3 3/8" gage, 837 mi. double track, 972 mi. single track, 99%
electrified; 1,377 mi. non-government owned, 444 mi. 4'' 8 1/2" gage, 886
mi. 3'' 3 3/8" gage, 47 mi. 2'' 7 1/2" gage, 100% electrified
Highways: 37,158 mi., all paved
Pipelines: crude oi], 195 mi.; natural gas, 550 mi.
Inland waterways: 41 mi.; Rhine River-Basel to Rheinfelden, Schaffhausen to
Constanz; in addition, there are 12 navigable lakes ranging in size from
Lake Geneva to Hallwilersee
Ports: 1 major, 2 minor
Civil air: 68 major transport aircraft
Airfields: 91 total, 75 usable; 36 with permanent-surface runways; 2 with
runways over 12,000 ft., 8 with runways 8,000-11,999 ft., 11 with runways
4,000-7 ,999 ft.
Telecommunications: excellent domestic, international, and broadcast services;
3.59 million telephones; communications satellite station under construction;
2.01 million radio and 1.66 million TY receivers; 7 AM, 89 FM, and 305 TV
stations
DEFENSE FORCES: ‘
Military manpower: males 15-49, 1,531,000; 1,325,000 fit for military service;
45,000 reach military age (20) annually
338
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
SYRIA
LAND:
72,000 sq. mi. including 500 sq. mi. of Israeli -occupied
territory; 48% arable, 29% grazing, 2% forest, 21%
desert
Land boundaries: 1,365 (1967) (excluding occupied area de
1,340 mi.) ARABIA
WATER: SUDAN =
Limits of territorial waters (claimed): 12 n. mi. (plus rer
6 n. mi. "necessary supervision zone")
Coastline: 120 mi.
Railroads: 649 mi.; 459 mi. standard gage, 190 mi. narrow gage, (3''5 3/8")
Highways: 7,150 mi.; 4,300 mi. paved, 810 mi. gravel or crushed stone, 1,540 mi.
improved earth, 497 mi. unimproved earth
Inland waterways: 420 mi.; of little importance
Pipelines: crude oi], 810 mi.; refined products, 320 mi.; natural gas 140 mi.
Ports: 3 major, 3 minor
Civil air: 6 major transport aircraft
Airfields: 92 total, 30 usable; 24 with permanent-surface runways; 1] with runway
over 12,000 ft., 19 with runways 8,000-11,999 ft.. 4 with runways 4,000-
7,999 ft.
Telecommunications: good international and telecommunication service; 131,800
telephones; 1,000,000 radio and 137,000 TV receivers; 5 TV and 5 AM stations
DEFENSE FORCES:
Military manpower: males 15-49, 1,631,000; 880,000 fit for military service;
about 90,000 reach military age (19) annually
340
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
TANZANIA
LAND:
362,800 sq. mi. (including islands of Zanzibar and Pemba,
1,020 sq. mi.); 6% inland water, 15% cultivated, 31%
grassland, 48% bush forest, woodland, on mainland: 60%
arable, of which 40% cultivated on islands of Zanzibar
and Pemba
Land boundaries: 2,413 mi.
WATER:
Limits of territorial waters (claimed): 50 n. mi.
Coastline: 885 (this includes Mafia Island, 70; Pemba
Island, 110; and Zanzibar, 132)
Railroads: 1,950 mi.; 600 mi. 3''6" gage; 1,638 mi., meter gage, 4 mi. double track;
Tanzania portion of Tan-Zam Railroad completed
Highways: total 30,000 mi., including 390 mi. on Zanzibar Island and 277 mi. on
Pemba and Mafia Islands; about 1,400 mi. bituminous treated, (370 mi. on
Zanzibar and Pemba); 28,600 mi. gravel, crushed stone, or unimproved earth
Pipelines: refined products 610 mi.
Inland waterways: 730 mi. of navigable streams; several thousand mi. navigable
on Lakes Tanganyika, Victoria, and Nyasa
Ports: 4 major, 8 minor
Civil air: 9 major transport aircraft
Airfields: 117 total, 103 usable; 8 with permanent-surface runways; 1 with run-
way 8,000 to 11,999 ft., 42 with runways 4,000-7,999 ft.; 4 seaplane stations
Telecommunications: telephone and telegraph good in main centers, only fair
outside main towns; 40,150 telephones; 230,000 radio receivers; 4 AM, no FM
or TV stations; 4 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 3,354,000; 1,860,000 fit for military service
342
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
THATLAND
LAND:
198,000 sq. mi.; 24% in farms, 56% forested, 20% other
Land boundaries: 3,025 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,000 mi.
PECPLE:
Population: 39,328,000, average annual growth rate 3.2%
(current)
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thais English secondary language of elite
Literacy: 70%
Labor force: 88% agriculture, 9% commerce, 3% industry
Railroads: 2,382 mi. meter gage; 60 mi. double track
Highways: 12,590 mi.; 5,440 mi. paved, 4,820 mi. crushed stone or gravel, 2,330
earth and laterite
Inland waterways: 2,485 mi. principal waterways; 2,300 mi. with navigable depths
of 3 ft. or more throughout the year; numerous minor waterways navigable by
shallow-draft native craft
Ports: 2 major, 16 minor
Civil air: 26 major transport aircraft
Airfields: 237 total, 178 usable; 53 with permanent-surface runways; 10 with
runways 8,000-11,999 ft., 26 with runways 4,000-7,999 ft.; 3 seaplane stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,807,000; 5,930,000 fit for military service;
about 424,000 reach military age (18) annually
Military and internal security budget: for fiscal year ending 30 September 1974,
$430 million; 25% of central government budget
344
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','0c21a80a05902102ef42837cfc3a994664f9141d8ee45a24b106383e292806e9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28facba422d158a4b2a75c1120ffa7f3f1532161e8c52b40884c5458335e63bc',1974,'TG','Togo','communications',386,'LAND:
22,000 sq. mi.; nearly one-half is arable, under 15%
cultivated
Land boundaries: 940 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 35 mi.
Railroads: 275 mi. meter gage, single track
Highways: approx. 4,475 mi.; 415 mi. paved, 120 mi. gravel, 730 mi.
improved earth, 3,210 mi. unimproved
Inland waterways: section of Mono River and about 30 mi. of coastal lagoons
and tidal creeks
Ports: 1 major, 1 minor
Merchant marine: 1 cargo ship (1,000 GRT or over) totaling 4,400 GRT, 4,900 DWT (C)
Civil air: 1 major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-surface runway 4,000-7,999 ft.
Telecommunications: Togo has poor system based on skeletal network of open-wire
lines, supplemented by a few radiocommunication stations; only center is
Lome; 6,100 telephones; 50,000 radio receivers; 1 AM, no FM or TY stations
DEFENSE FORCES:
Military manpower: males 15-49, 453,000; 230,000 fit for military service;
no conscription
346
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','d51ad0c604256c14f08d7a9c614ba24f45ff4544f65685784427976145410fe1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36043b3f5ff224a952b88b504511691045c3eb440e36c7684a9332641e9a019a',1974,'TO','Tonga','communications',390,'LAND:
385 sq. mi. (150 islands); 77% arable, 3% pasture, 13%
forest, 3% inland water, 4% other
WATER: 2 AUSTRALIA
Limits of territorial waters (claimed}: 12 n. mi.
Coastline: 260 mi. (est.)
Railroads: none
Highways: 365 mi.; 132 mi. metalled all-weather, 233 mi. earth
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 3 total; 1 usable, with grass runway 7,000 ft.; 1 seaplane station
Telecommunications: 1,073 telephones; 9,100 radio sets; no TV sets; 1 AM station
347
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','8d12244947cbba9496fc103b748b6cb5afe83d83fb45f82fefaefe3e77cf8f56','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('969bba5f15b11e071a94f2aab72a03aaab670e3270ecc125e268001339430476',1974,'TT','Trinidad and Tobago','communications',394,'LAND:
1,980 sq. mi.; 41.9% in farms (of which 25.7% cropped or
fallow, 1.5% pasture, 10.6% forests, 4.1% unused or
built-on), 58.1% outside of farms, including
grassland, forest, built-up area, and wasteland
VENEZUELA
A WATER: COLOMBIA
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 225 mi. BRAZIL
Railroads: none
Highways: 4,200 mi.; 2,500 mi. paved, 1,700 mi. gravel or otherwise improved
Pipelines: crude oi], 270 mi.; refined products, 12 mi.; natural gas, 130 mi.
Ports: 3 major, 6 minor
Civil air: 19 major transport aircraft
Airfields: 12 total, 6 usable; 3 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 2 with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international service via tropospheric scatter
links to Barbados and Guyana; good local service; satellite ground station;
70,600 telephones; 260,000 radio and 82,000 TV receivers; 2 AM, 2 FM, and
3 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 247,000; 175,000 fit for military service
350
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
TUNISTA
LAND:
63,400 sq. mi.; 28% arable land and tree crops, 23% range
and esparto grass, 6% forest, 43% desert, waste or
urban
Land boundaries: 875 mi.
WATER:
Limits of territorial waters (claimed): 12 n, mi.
(fishing, 12 n. mi. exclusive fisheries zone follows the
50-meter isobath for part of the coast, maximum 65 n. mi.)
Coastline: 710 mi. (includes offshore islands)
Railroads: 1,273 mi.; 309 mi. standard gage (4''8 1/2"), double 964 mi. meter
gage (3''3 3/8")
Highways: 10,250 mi.; 4,750 mi. mostly bituminous treatment, 500 mi. gravel,
2,050 mi. improved earth, 2,950 mi. unimproved earth
Pipelines: crude oi], 495 mi.; refined products, 6 mi.; natural gas, 45 mi.
Ports: 4 major, 8 minor.
Civil air: 7 major transport aircraft
Airfields: 61 total, 36 usable; 1] with permanent-surface runways; 2 with runways
8,000-11,999 ft., 19 with runways 4,000-7,999 ft.; 1 seaplane station
Teleconmunications: the system is above the African average in amount and
capacity of facilities which consist of open-wire lines with multiconductor
cable or radio relay on trunk routes; key centers are Safaqis, Susah, Bizerte,
and Tunis; 96,300 telephones; 401,000 radio and 80,000 TV receivers; 3 AM,
3 FM, and 7 TV stations; 2 submarine cables
DEFENSE FORCES:
Military manpower: males 15-49, 1,200,000; 640,000 fit for military service;
about 60,000 reach military age (20) annually
352
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
TURKEY
LAND:
296,000 sq. mi.; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 1,600 mi.
WATER: ARABIA
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi. cease)
(fishing, 12 n. mi.) eriiapin
Coastline: 4,475 mi.
Railroads: 5,075 mi.; 5,055 mi. 4''8 1/2" gage, 89 mi. double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 402 mi.; refined products, 1,277 mi.
Ports: 10 major, 35 minor
Civil air: 25 major transport aircraft
Airfields: 125 total, 101 usable; 50 with permanent-surface runways; 3 with
runways over 12,000 ft., 20 with runways 8,000-11,999 ft., 23 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international and fair domestic telecommunication
services; 800,000 telephones; 4.27 million radio and 180,000 TV receivers; 40
AM, 2 FM, and 12 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,874,000; 5,820,000 fit for military service;
about 407,000 reach military age (20) annually
354
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','e831a5b3a959126f655e0b3eb56ba6fd135020e9a2d4e6ce8253b1030d494c20','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b763f81dcfcf81a44b2544c81a552f35f42aa4319a70a1f3342010d6bc6f5974',1974,'UG','Uganda','communications',398,'LAND:
91,000 sq. mi.; 21% inland water and swamp, including
territorial waters of Lake Victoria, about 21%
cultivated, 13% national parks, forest, and game
reserves, 45% forest, woodland, and grassland
Land boundaries: 1,665 mi.
Railroads: 760 mi.; all meter gage, single track
Highways: 31.330 mi, total; 1,200 mi. bituminous surface treatment; 10,130 mi.
crushed stone, gravel, laterite, and improved earth; 20,000 mi. unimproved
earth roads and tracks
Inland waterways: Lake Victoria, Lake Albert, Lake Kyoga, Lake George, and
Lake Edward (6,010 mi.); Kagera River and Victoria Nile (380 mi.)
Civil air: 6 major transport aircraft
Airfields: 50 total, 42 usable; 3 with permanent-surface runways; 1 with runway
over 12,000 ft., 2 with runways 8,000-11,999 ft., 11 with runways 4,000-7,999
ft.; 3 seaplane stations
Talecomnunications: telephone and telegraph services fair to good, intercity
connections based on 3 or 12 channel carrier systems; 34,200 telephones;
275,000 radio and 68,000 TV receivers; 2 AM, na FM, and 6 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, about 2,677,000; about 1,430,000 fit for military
service
356
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
U.S.S.R.
LAND:
8,600,000 sq. mi.; 9.3% cultivated, 37.1% forest and
brush, 2.6% urban, industrial, and transportation,
16.8% pasture and natural hay land, 34.2% desert,
swamp, or waste
Land boundaries: 12,595 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 29,000 mi. (incl. Sakhalin)
Railroads: 84,642 mi.; 82,412 mi. broad gage, 2,230 mi. narrow gage; 58,810 mi.
broad gage single track; 21,420 mi. electrified; does not include industrial
lines (1973)
Highways: 845,620 mi.; 128,340 mi. paved, 188,855 mi. gravel, crushed stone,
528,425 mi. improved or unimproved earth (1972)
Inland waterways: 90,000 mi. navigable, exclusive of Caspian Sea (1974)
Pipelines: crude of], 26,000 mi.; refined products, 6,300 mi.; natural gas,
50,000 mi.
Ports: 63 major (most important: Leningrad, Murmansk, Odessa, Novorossiysk,
Ilichevsk, Vladivostok, Nakhodka); 123 selected minor (1974)
Freight carried: rail -- 3,663.0 million short tons, 1,891.8 billion short
ton/mi. (1973); highways -- 18.8 billion short tons, 178 billion short
ton/mi. (1972); waterway - 435.4 million short tons, 123.3 billion short
ton/mi. (1972}
Airfields: over 3,290 total; 567 with permanent-surface runways; 31 with runways
over 12,000 ft., 432 with runways 8,000-11,999 ft., 787 with runways 4,000-
7,999 ft.
358
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','1613cd036688a5261ddb2f1de0c96fc7e8641a1bdb5a75560bfe939084e1ea9f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e83a5d64ad862581de6008e52ba9ad754d412b7a720108447f43f3a0431e449a',1974,'AE','United Arab Emirates','communications',402,'LAND:
32,000 sq. mi.; almost all desert, waste or urban
Land boundaries: 680 mi. (does not include boundaries
between adjacent U.A.E. states)
WATER:
Limits of territorial waters (claimed): 3 n. mi. for all
states except Sharjah (12 n. mi.)
Coastline: 900 mi.
Railroads: nane
Highways: 175 mi. bituminous, undetermined mileage of earth tracks
Pipelines: crude oi1, 175 mi.
Ports: 3 major, 3 minor
Civil air: no major transport aircraft
Airfields: 96 total, 37 usable; 4 with permanent-surface runways; 1 with runway
over 12,000 ft., 1 with runway 8,000-11,999 ft., 13 with runways 4,000-7,999 ft.
Telecommunications: telephone system in Dubayy and Ash Shariqah, also Tinks
these towns; Abu Dhabi Petroleum operates a telecom system throughout
the sheikhdom; key centers are at At Tarif, Habshan, and Az Zannah; 14,300
telephones; 50,000 radio and 16,000 TV receivers; 3 AM, 1 FM, and 2 TV
stations
DEFENSE FORCES:
Military manpower: males 15-49, about 43,000; about 22,000 fit for military service
360
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
~@&
©
Next 1 Page(s) In Document Denied
Pod
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
STAT
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
UPPER VOLTA
LAND:
106,000 sq. mi.; 50% pastureland, 21% fallow, 10%
cultivated, 9% forest and scrub, 10% waste and other
uses
Land boundaries: 2,055 mi.
Railroads: 728 mi., 320 mi. meter gage, single track; Ouagadougou to Abidjan,
Ivory Coast line
Highways: 10,380 mi.; 325 mi. paved, 3,425 mi. improved, 6,630 mi. unimproved
Civil air: no major transport aircraft
Airfields: 59 total, 51 usable; 2 with permanent-surface runways; 1 with runway
8,000-11,999 ft., 2 with runway 4,000-7 ,999 ft.
Telecommunications: all services generally poor; 1,800 telephones; 100,000 radio
receivers; 6,600 TV receivers; 2 AM, no FM, and 1 TV station
DEFENSE FORCES:
Military manpower: males 15-49, 1,357,000; 650,000 fit for military service; no
conscription
364
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','974f53a47f9a96c9e79b98fbfde2e6c11e3ad1944ef933d5d1771b8ee8de3bea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23aba150d00cbe6fccdb260b07f618a70f860295786074c038b6662b6b346598',1974,'WF','Wallis and Futuna','communications',406,'LAND:
About 80 sq. mi.
WATER:
Limits of territorial waters: 12 n. mi.
Coastline: about 80 mi.
Airfields: 3 total, all usable; 1 4,000-7,999 ft., 1 seaplane station
375
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
WESTERN SAMOA
LAND:
1,100 sq. mi.; comprised of 2 large islands of Savai''i and
Upolu and several smaller islands, including Manono
and Apolima; 65% forested, 24% cultivated, 11% industry,
waste, or urban “8 AUSTRALIA
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 250 mi.
Railroads: none
Highways: 477 mi.; 80 mi. bituminous, remainder mostly gravel, crushed stone,
or earth
Inland waterways: none
Ports: 1 principal (Apia), 1 minor
Civil air: 2 major transport aircraft
Airfields: 4 total, all usable; 1 with runway 4,000-7 ,999 ft.; 1 seaplane
station :
Telecommunications: 2,183 telephones; 10,000 radio receivers; 1 AM station
378
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
YEMEN (ADEN)
LAND: #
111,000 sq. mi. (border with Saudi Arabia undefined); only EGYPT: SAUOI
about 1% arable (of which less than 25% cultivated)
Land boundaries: 1,120 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi. (300
meters plus exploitability, plus 6 n. mi. "necessary
supervision zone")
Coastline: 860 mi.
Railroads: none
Highways: 3,360 mi.; 200 mi. bituminous treated, 180 mi. crushed stone and gravel,
2,920 motorable track
Ports: 1 major
Pipelines: refined products, 20 mi.
Civil air: 6 major transport aircraft
Airfields: 140 total, 64 usable; 2 with permanent-surface runways; 3 with run-
ways 8,000-11,999 ft., 33 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: smal] system of open-wire line, milticonductor cable, and
radiocommunications stations; only center Aden; 9,900 telephones; 250,000
radio and 26,000 TV receivers; 3 TV and 1 AM stations; 4 submarine cables
(2 operational)
DEFENSE FORCES:
Military manpower: males 15=49, 380,000; 205,000 fit for military service
380
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
LD, Ss Ss
YEMEN (SANA) ae
LAND: ra) ven
about 75,000 sq. mi. (parts of border with Saudi Arabia SAUDI gos A
and Southern Yemen undefined); 20% agricultural,
1% forested, 79% desert, waste, or urban
Land boundaries: 950 mi.
ee ARABIA
WATER:
Limits of territorial waters (claimed): 12 n. mi. (plus
6n. mi. "necessary supervision zone")
Coastline: 325 mi.','10d32b48c35850fe6354b2b53917df72d34223e2dccc48b80e7c312a81515330','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5d81d123b667af963a407188dd5fd173defe4d18ba7becd1897fbd22ca63ef8',1974,'US','United States','communications',412,'This ‘Factsheet" on the U.S. is provided solely as a service to those
wishing to make rough comparisons of foreign country data with a U.S.
"vardstick." Information is from U.S. open sources and publications
and in no sense represents estimates by the U.S. intelligence community.
LAND:
3,615,211 sq. mi. (contiguous U.S. plus Alaska and Hawaii); 19% cultivated,
27% grazing and pasture, 32% forested, 22% waste, urban, and other
WATER:
Limits of territorial waters (claimed): 3, mi. (fishing, 12 n. mi.)
Railroads: 207,000 mi. (1969)
Highways: 3,730,000 mi. (1970); 2,411,000 mi. surfaced (1970)
Inland waterways: 25,260 mi. of navigable inland channels, exclusive of the
Great Lakes; freight carried 951 million short tons (1970)
Pipelines: petroleum, 176,000 mi.
Ports: 25 major :
Merchant marine: 1,478 ships (1,000 GRT or over) totaling 24,474,000 DWT (1971)
Civil air: 3,970 major transport aircraft (1970)
Airfields: 12,000 (1971)
Telecommunications: 4,370 AM, 2,722 FM, 1,035 TV operating stations (1970);
120,155,000 telephones (1970), 58.6 telephones per 100 population (1970)
DEFENSE FORCES:
Personnel: army 1,386,000, navy and marines 1,151,000, air force 1,048,000 (1971)
Military budget: $78 billion (1972 est.)
390
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
rm','740eacad6ee3698ac318ef9628de8566d7102fc28483ee0e68a1267a025d54a0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

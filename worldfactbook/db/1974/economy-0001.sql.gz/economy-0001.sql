SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce53736689a350db42c4829546d984c27c2c619ec70e20546a26983343631761',1974,'','','economy',4,'GNP: $45.0 billion (1977), $1,070 per capita; 3.8% real
growth 1977, 7%-8% average annual real growth 1970-76
Agriculture: main products—cotton, tobacco, cereals,
sugar bects, fruits, nuts, and livestock products; self-suffi-
cient in food in average years
Major industries: textiles, food processing, mining (coal,
chromite, copper, boron minerals), steel, petroleum
Crude steel: 1.9 million tons produced (1976), 45 kg per
capita
Electric power: 5,000,000 kW capacity (1977); 22.0
billion kWh produced (1977), 510 kWh per capita
Exports: $2,671 million (£.0.b., 1977); cotton, tobacco,
fruits, nuts, metals, livestock products, textiles and clothing
Imports: $6,999 million (f.0.b., 1977); crude oil, machin-
ery, transport equipment, metals, mineral fuels, fertilizers,
chemicals .
Major trade partners: 22% West Germany, 9% U.S., 9%
Iraq, 7% U.K., 7% Italy (1976)
Aid: economic authorizations: U.S., $512 million (FY70-
77); other Western (ODA and OOF), $1,575 million (1971-
77); Communist, $808 million (1970-77), OPEC, ODA,
$1,553 million (1974-76); military authorizations: U.S.,
$1,289 million (FY70-77)
Budget: (FY77) revenues $11.2 billion, expenditures $12.2
billion, deficit $1.01 billion
Monetary conversion rate: 25.25 Turkish liras=US$1
(July 1978)
Fiscal year: 1 March-28 February','f065ae42814d383b3ed98a795c4b6e29d59c19b97c157830a90148f812c491e6','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe004c3b9dbdafb276b668bdf6fd6ae5f8e9c01d090a269c2ebe47c7d6ff4044',1974,'','','economy',4,'GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971 :
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2.8 million kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $616.5 million (f.o.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
Mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Monetary conversion rate: 14 Turkish liras=US$] (official rate)
Fiscal year: 1 March - 28 February','a893c8676599b7e8f9599afa88721528d836b28df6ec5629e7a51b3407d7a703','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96e4b3edf3db35305ec74b89bc9bc9372899b8451c1d5ee7479c860f51a3a3e0',1974,'','','economy',4,'GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2.8 million kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $616.5 million (f.0.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Aid: $390.5 million extended by Communist countries 1955-December 1971; none
extended in 1971; total U.S. economic, $2,727.9 million (1946-71); total
U.S. military $3,250.2 million (July 1946-June 1971); $603 million in aid
commitments from international tes (1946-71); $657 million in bilateral
aid from other sources 1960-70
Monetary conversion rate: 14 Turkish liras=US$1 (official rate)
Fiscal year: 1 March - 28 February','4c5921c18d539de60f8b6e157cd7b171fa7672f2c9502dc3d789c30404de55ea','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3dc7b04e879db537e1d98f5f006aedf8ea4dc84102dc252682f8598ad692f06',1974,'','','economy',4,'GNP: $1.1 billion (FY72), well below $100 per capita; real growth rate
about 4-5% in FY72
Agriculture: agriculture and animal husbandry account for over 50% of GNP and
occupy nearly 80% of the labor force; main crops -- wheat and other grains,
cotton, fruits, nuts; largely self- sufficient; food shortages -- wheat,
sugar, tea
Major industries: cottage industries, food processing, textiles, cement, coal
mining
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $81.8 million (f.o.b., FY72); fruits and nuts, natural gas, karakul,
cotton, carpets and rugs, wool
Imports: $127.1 million (c.i.f., FY72); wheat, textiles, chemicals, tea,
petroleum, transportation equipment s
Major trade partners: exports -- U.S.S.R., India, U.K., Pakistan; imports --
U.S.S.R., Japan, India, U.S.
Monetary conversion rate: 45 Afghanis=US$1 (official); 60 Afghanis=US$1
(August 1973)
Fiscal year: 21 March - 20 March a
GNP: $1.2 billion in 1972 (at 1972 prices), $530 per capita
Agriculture: food deficit area; main crops -- corn, wheat, tobacco, sugar beets,
cotton; food shortages -- wheat; caloric intake, 2,100 calories per day per
capita (1961/62)
Major industries: agricultural processing, textiles and clothing, lumber, and
extractive industries
Shortages: spare parts, machinery and equipment, wheat
Exports: $91 million (1970 est.); 1964 trade -- 55% minerals, metals, fuels;
17% agricultural materials (except foods); 23% foodstuffs (including
cigarettes); 5% consumer goods
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Imports: $159 million (1970 est.); 1964 trade -- 50% machinery, equipment, and
spare parts; 16% minerals, metals, fuels, construction materials; 7%
fertilizers, other chemicals, rubber; 4% agricultural materials (except
foodstuffs); 16% foodstuffs; 7% consumer goods
Monetary conversion rate: 5 leks=US$1 (commercial); 12.5 leks=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported fér consumption year
] July - 30 June
GNP: $6.3 billion (est. 1972), $410 per capita, average annual increase
since 1968 (current prices), 11%
Agriculture: main crops -- wheat, barley, wine, citrus fruits
Major industries: petroleum, light industries, natural gas, mining, petrochemical
and steel plants under construction
Electric power: 1,770,000 kw. capacity (1972); 2.7 billion kw.-hr. produced
(1972), 178 kw.-hr. per capita
Exports: $1,207 million (f.0.b., 1972); crude petroleum 75%, other items -- wine,
citrus fruit, iron ore, vegetables; to France 24%, West Germany 24%, Benelux
9%, Italy 8%, U.S.S.R. 7%
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Imports: $1,372 million (c.i.f., 1972); major items -- capital goods 37%,
semi-finished goods 27%, foodstuffs 13%; from France 38%, West Germany 9%,
Italy 9%, U.S. 8%
Monetary conversion rate: 4.547 dinars=US$1 in 1972, and 4.4093 dinars=US$1
through mid-1973
Fiscal year: calendar year
Agriculture: sheep raising; small quantities of tobacco, rye, wheat, barley,
oats, and some vegetables (only 25% of land can be used for agriculture)
Major industries: tourism ($1 million annually), one cigarette factory (annual
output $1 million), handicrafts, smuggling (tobacco to France; manufactured
items, including automobiles and cameras, to Spain)
Shortages: food
Electric power: 25,000 kw. capacity (1972); 100 million kw.-hr. produced (1972),
370 kw.-hr. per capita; power is mainly exported to Spain and France
Major trade partners: Spain, France
GNP: $1.2 billion (1970 est.), about $220 per capita
Agriculture: cash crops -- coffee, sisal, corn, cotton, Sugar, manioc, and
tobacco; food crops -- cassava, corn, vegetables, plantains, bananas, and
other local foodstuffs; largely self-sufficient in food
Fishing: catch 368,000 metric tons, $8.4 million (1970); exports $18.7 million;
imports $5.5 million (1971)
Major industries: mining (011, iron, diamonds), fish processing, brewing, tobacco,
sugar processing, cement, food processing plants, building construction
Electric power: 443,000 kw. capacity (1971); 838 million kw.-hr. produced
(1972), 140 kw.-hr. per capita
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $479 million (f.0.b., 1972); coffee (about 35%), oi], diamonds, sisal,
fish and fish products, iron ore, oil, timber, and corn
Imports: $392 million (c.i.f., 1972); capital equipment (machinery and electrical
equipment), wines, bulk iron and ironwork, steel and metals, vehicles and -
Spare parts, textiles and clathing, medicines
Major trade partners: main partner Portugal, followed by West Germany, U.S.,
U.K., Japan
Aid: Portugal only donor
Monetary conversion rate: 27.25 escudos=US$1, until] February 1973; 25.5 escudos= x
US$1 thereafter
Fiscal year: calendar year
GDP: $27.6 million (at market prices, 1970), $430 per capita
Agriculture: main crops -- sugar, cotton
Major industries: oi] refining, tourism
Shortages: electric power
Electric power: 22,440 kw. capacity (1972); 45 million kw.-hr. produced (1972),
540 kw.-hr. per capita
Exports: $2.9 million (f.o.b., 1968); sugar, molasses, cotton
Imports: $20/0 million (c.i.f., 1968); food, clothing, oi], wood
Major trade partners: U.K. 30%, U.S. 25%, Conmonwealth Caribbean countries
18% (1966)
Aid: economic -- U.S. (FY46-71), $1.5 million in loans
Monetary conversion rate: 1.92 East Caribbean dollars=US$1 (6 October 1971),
now floating with pound sterling
im
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7','7ae04086a3b5f1244c234bdac4c0aae68e63d01a97b97e0e2bd8ec1075a9e2c7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('147c45fa447523f24fe39ac5be6a978d05dcd5f9a385a3589c61cdb28b71ce76',1974,'BR','Brazil','economy',15,'GDP: $20.7 billion (at average parallel exchange rate, 1972) $860 per capita;
73% consumption, 26% investment, 1.0% net foreign balance
(1972); real growth rate 1972, 4.0%
Agriculture: main products -- cereals, oilseeds, livestock products; Argentina
is a major world exporter of temperate zone foodstuffs
Fishing: catch 290,000 metric tons (1971), $20.2 million; exports $4 million
(1971), imports $3.6 million (1970)
Major industries: food processing (especially meatpacking), motor vehicles,
consumer durables, textiles, chemicals, printing, and metallurgy
Crude steel: 2.1 million metric tons produced (1972)
Electric power: 7,262,000 kw. capacity (1972); 25.4 billion kw.-hr.
produced (1972), 1,000 kw.-hr. per capita
Exports: $1,868 million (f.o.b., 1972) -- meat, wheat, corn, wool, hides, oil-
seeds
Imports: $1,840 million (c.i.f., 1972) -- machinery, fuel and lubricating oils,
jron and steel, intermediate industrial products
Major trade partners (1971): exports -- EC 38%, LAFTA 21%, U.S. 9%, U.K. 7%;
imports -- EC 24%, LAFTA 21%, U.S. 22%, U.K. 6%
Aid: economic -- extensions from U.S. (FY46-71), $803.0 million in loans; $18.0
million in grants; from international organizations (FY46-70), $1,109.8
million; from other Western countries (1960-66), $315.5 million; from
Communist countries (1954-71) $56 million (drawn, $41.0 million);
military -- assistance from U.S. (FY46-71), $152.2 million
Monetary conversion rate: commercial -- 5.00 pesos=US$1; financial -- floating,
9.98 pesos=US$1, December 1972, parallel market 11.00 pesos=US$1 (August 1973)
Fiscal year: calendar year
GNP: $26.9 billion (1972), $3,600 per capita (1972); 55.1% consumption, 31.4%
investment, 14.4% government, -0.4% net foreign balance, -0.5% net errors and
omissions (1972); 1972 growth rate 5.5% constant prices
Agriculture: livestock, cereals, potatoes, sugar beets; 84% self-sufficient;
caloric intake 3,230 calories per day per capita (1969-70)
19
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ST RT Ee TT TA
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major industries: foods, iron and steel, machinery, textiles, chemicals,
electrical, paper and pulp
ae a 4.1 million metric tons produced (1972), 550 kilograms per capita
1972
Electric power: 8,308,000 kw. capacity (1972); 29.4 billion kw.-hr produced
(1972), 3,322 kw.-hr. per capita
Exports: $3.88 billion (f.o.b., 1972); iron and steel products, machinery and
equipment, lumber, textiles and clothing, paper products, chemicals
Imports: $5.22 billion (c.i.f., 1972); machinery and equipment, chemicals,
textiles, coal, petroleum, foodstuffs
Major trade partners: (1972) West Germany 34%, Italy 8%, Switzerland 9%,
U.K. 7%, U.S. 4%; EC 50%; EFTA 22%; Communist countries 10%
Aid:
economic -- authorized - U.S. $1,188.2 million through FY72; IBRD $104.9
million through FY72, none since FY62;
military -- U.S., $147.3 million (FY52-72); net official economic aid delivered
to less developed areas and multilateral agencies -- $205 million (FY62-72),
$17 million in FY72
Monetary conversion rate: 17.7 shillings=US$1, September 1973 (floating rate)
Fiscal year: calendar year
GNP: $390 million (at market prices, 1970 est.), $1,920 per capita
Agriculture: main crops -- fruits, vegetables
Major industries: tourism, cement, oil refining, lumber, salt production
Electric power: 177,000 kw. capacity (1971); 537.0 million kw.-hr. produced
(1971), 3,055 kw.-hr. per capita
Exports: $342 illion (f.0.b., 1972); fuel oil, cement, rum, pulpwood, fruits,
and vegetables
Imports: $487 million (c.i.f., 1972); foodstuffs, manufactured goods, crude oi]
Major trade partners: exports -- U.S. 68%, U.K. 7%, Canada 6%; imports -- U.S.
54%, U.K. 14%, Italy 7%, Canada 4%, other 21% (1970)
Aid: economic -- authorizations from U.S. (FY56-72) -- $23.7 million in loans,
$0.3 million in grants
Monetary conversion rate: 1 Bahamian dollar (B$)=US$1
Fiscal year: calendar year
Agriculture: produces dates, alfalfa, vegetables; dairy and poultry farming;
fishing; not self-sufficient in food
Major industries: petroleum refining, boatbuilding, shrimp fishing, and
sailmaking on a small scale; major development projects include aluminum
smelter, flourmill, and ISA town
Electric power: 108,000 kw. capacity (1972); 270 million kw.-hr. produced (1972),
1,180 kw.-hr. per capita
Exports: non-oi] exports $55 million 1972 rev.; total exports $280 million
1972 (est.)
Imports: including oi1, $340 million (1972 est.)
Major trade partners: U.K., Japan, U.S., EC
Aid: economic -- multilateral Western $360,000 (annual average 1967-69)
Monetary conversion rate: 1 Bahrain dinar=US$2.52 (as of March 1973)
Fiscal year: calendar year
GNP: $5.0 billion FY72 est. (1970 prices), less than $100 per capita; real
growth (FY72 est.) -7%
Agriculture: largely subsistence farming, heavily dependent on monsoon rainfall;
main crops are jute and rice; shortages -- rice, wheat, and cotton
Fishing: catch 273 thousand metric tons, $115 million (1969 est.)
Major industries: jute manufactures, food processing and cotton textiles
Exports: $297 million (f.0.b., 1972); raw and manufactured jute, tea, paper and
paperboard, hides and skins
Imports: $694 million (c.i.f. 1972); chemicals, machinery and other manufactured t
products, transport equipment, foodgrains, fuels, oils and fats
Major trade partners: West Pakistan (until December 1971), U.S., U.K., Japan,
India (since December 1971)
Aid: Bangladesh received roughly one-third of the estimated $8 billion in total
economic aid received by Pakistan between 1950 and 1971; since independence
(17 December 1971-1 January 1973), economic aid: total $1.3 billion extended,
$634 million drawn; US$347 million extended; U.S.S.R. $136 million extended;
Eastern Europe $36 million extended
Monetary conversion rate: 7.5 takas=US$1 (effective April 1973)
Fiscal year: 1 July - 30 June
GDP: $185.6 million (1972), $780 per capita; real growth rate 1972, 0.6% (est.)
Agriculture: main products -- sugar, subsistence foods
Major industries: tourism, sugar milling, manufacturing, edible oils and fats
Electric power: 48,000 kw. capacity (1972); 150 million kw.-hr. produced
(1972), 580 kw.-hr. per capita
Exports: $43.8 million (f.0.b., 1972); sugar, molasses, rum
Imports: $140.6 million (c.i.f., 1972); foodstuffs, lumber, machinery,
manufactured goods
Major trade partners: exports -- U.K. 32%, U.S. 13%, CARIFTA 27%, other 22h;
imports -- U.K. 30%, U.S. 18%, Canada 10%, CARIFTA 12%, other 27% (1971)
Aid: economic -- U.S. (FY67-72), $0.7 million in grants; from international
organizations (FY63-72), $1.8 million
Monetary conversion rate: 7.92 East Caribbean dollars=US$1
Fiscal year: 1 April - 31 March
27
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GNP: $8.25 billion (at average official exchange rate 1972), $890 per capita;
79% private consumption, 12% government consumption, 13% gross investment,
-4% net imports and factor payments abroad (1971 est.); real growth rate
1972 {est.), GNP 2.0%
Agriculture: main crops -- wheat, other cereals, potatoes; about 65% self-
sufficient; 2,650 calories per day per capita (1971 est.)
Fishing: catch 0.82 million metric tons; exports $20.3 million, imports $2.1
million (1972)
Major industries: copper, nitrates, foodstuffs, fish processing, textiles and
apparel, iron and steel, pulp and paper
Crude steel: 0.7 million metric tons capacity (1967); 0.6 million metric tons
produced (1971), 65 kg. per capita
Electric power: 2.13 million kw. capacity (1972); 8.9 billion kw.-hr. produced
(1972), 900 kw.-hr. per capita
Exports: $0.858 billion (f.o.b., 1972 est.); copper, iron ore, nitrates,
and iodine
Imports: $1.4 billion (c.i.f., 1972 est.); foodstuffs, machinery and equipment,
chemicals
Major trade partners: exports -- EC 44%, Japan 14%, U.S. 8%, LAFTA
11%; imports -- EC 28%, U.S. 16%, Japan 3%, LAFTA 18% (1972)
Aid:
economic -- extensions from U.S. (FY46-71) -- $1,502.7 million ($1,289.6
million loans, $213.1 million grants); from international organizations
(FY46-70) -~ $566.3 million (of which IBRD $232.7 million. IDB $253.9
million); from other Western countries (1960-66) -- $170.6 million; from
Communist countries (1967-71) -- $193.3 million;
military (FY53-71) -- from U.S., $25.1 million in loans, $124.4 million in
grants
Monetary conversion rate: dual exchange rate system; 850 escudos=US$1 tourist
rate; 280 escudos=US$1 commercial export rate; varying taxes double effective
rate for some purposes; black market rate is roughly 1200 escudos=US$1
(October 1973)
Fiscal year: calendar year
GNP: $139 billion (1972), $160 per capita
Agriculture: main crops -- rice, wheat, miscellaneous grains, cotton; caloric
intake, 2,000 calories per day per capita (1972); agriculture mainly
subsistence; grain imports 4 million-5 million tons annually, but higher in 1973
Major industries: iron and steel, coal, machine building, armaments, textiles
Shortages: complex machinery and equipment, highly skilled scientists and
technicians
Crude steel: 23 million tons produced (1972), 25 kilograms per capita (1972)
Exports: $3.1 billion (f.0.b., 1972), agricultural products, minerals and metals,
manufactured goods
Imports: $2.8 billion (c.i.f., 1972), grain, chemical fertilizer, industrial
raw materials, machinery and equipment
Major trade partners: Japan, U.S., Hong Kong, West Germany, U.S.S.R., U.K.,
Singapore/Malaysia, Canada (1973)
Monetary conversion rate: about 2 yuan=US$1 (arbitrarily established)
Fiscal year: calendar year
GNP: $7.2 billion (1972), $470 per capita; real growth, 11%
Agriculture: most arable land intensely farmed -- 60% cultivated land under
irrigation; main crops -- rice, sweet potatoes, sugarcane, bananas, pineapples,
citrus fruits; 90% self-sufficient; food shortages -- wheat 7
Fishing: catch 694,000 metric tons, $252 million (1972)
Major industries: textiles, clothing, chemicals, plywood, electronics, sugar
milling, food processing, cement, ship building
Exports: e314 million (f.0.b., 1972); textiles and clothing 28%, footwear 5%,
T.V. and radios 11%, other machinery and equipment 10%, metals and other
manufactures 15%, canned foods 6%, lumber and plywood 5%, seafood 4%
Imports: $2,843 million (c.i.f., 1972) machinery and equipment 33%, basic metals
10%, grains and soybeans 9%, oi] and natural gas 4%, textile raw materials
and intermediates 7%, chemicals and pharmaceuticals 14%
Major trade partners: exports ~~ 41% U.S., 13% Japan; imports -- 38% Japan,
29% U.S.
Aid:
economic -- U.S. (FY53-72) $1.6 billion committed; IBRD (1964-71) $312
million committed; Japan (1965-70) $137 million committed; ADB (1968-72)
$100 million committed;
military ~- U.S. (FY49-71) $3.2 billion committed
Monetary conversion rate: NT$38 (New Taiwan)=US$1
Fiscal year: 1 July - 30 June
ff!
GNP: $7.93 billion (1972), $340 per capita; 72% private consumption, 7% public
consumption, 21% gross investment (1969); real growth rate 1972, 7% (est.)
Agriculture: main crops -- coffee, rice, corn, Sugarcane, plantains, bananas,
Gs). potatoes, yucca; caloric intake, 2,140 calories per day per capita
{1970
Fishing: catch 76,000 metric tons 1970; exports $4.7 million (1969), imports $5.9
million (1969)
Major industries: textiles, food processing, clothing and footwear, beverages,
chemicals, and metal products
Crude steel: 0.39 million metric tons production (1972), 20 kilograms per capita
Electric power: 2.57 million kw. capacity (1971); 9.5 billion kw.-hr. produced
{1971), 424 kw.-hr. per capita
Exports: $586 million (f.o.b., 1972); coffee, petroleum, bananas, tobacco,
catton, sugar, textiles, cattle and hides
Imports: $836 million (c.i.f., 1972); industrial metals and raw materials, chemicals
and pharmaceuticals, transportation equipment, machinery, fuels, fertilizers,
paper and paper products, foodstuffs and beverages, rubber and rubber products
Major trade partners: exports -- U.S. 33%, Western Europe 39%, Latin America 12%;
imports -- U.S. 40%, Western Europe 33%, Latin America 12% (1971)
Aid:
economic -- extensions from U.S. (FY46-72), $1,219.6 million loans, $255.3
million grants; from international organizations (FY46-72), $1,407.2 million;
from other Western countries (1960-71), $77.6 million; from Communist
countries (1954-71) $18.5 million ($2.7 million drawn)
military -- assistance from U.S. (FY46-72) -- $131.6 million
Monetary conversion rate: 23.75 pesos=US$1 (July 1973, changes frequently),
selling rate
Fiscal year: calendar year
Agriculture: food crops -- rice, manioc, potatoes, fruits, vegetables; export
crops -- essential oils for perfumes (mainly ylang-ylang), vanilla, copra,
sisal
Exports: $6.1 million (1971) perfume oils, vanilla, copra, sisal
Imports: $11.1 million (1971) foodstuffs, cement, fuels, chemicals, textiles
Major trade partners: France, Malagasy Republic, Italy, Kenya, Tanzania and U.S.
Electric power: est. 1,000 kw. capacity (1972); est. 2 million kw.-hr. produced
(1972); 7 kw.-hr. per capita
Aid: French aid in 1971 was about $2.7 million, or about 50% of the island''s
entire budget
* Monetary conversion rate: 255.785 Conmunaute Financiere Africaine (CFA) francs=US$1
as of February 1973 (floating since February 1973)
GDP: about $277 million (1970 est.), $310 per capita, real growth rate
about 4% per year
Agriculture: cash crops -- sugarcane, wood, coffee, cocoa, palm kernels, peanuts,
tobacco; food crops -- root crops, rice, com, bananas, manioc, fish
Fishing: catch 13,800 metric tons (1971); imports $3.3 million (1969)
Major industries: sawmills, brewery, cigarettes, sugar mill, soap
Electric power: 43,600 kw. capacity (1972); 88 million kw.-hr. produced (1972),
91 kw.-hr. per capita
73
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $55 million (f.o.b., 1971); lumber, sugar, tobacco, veneer, and plywood;
diamonds smuggled from Zaire
Imports: $113 million (c.i.f., 1971); machinery, transport equipment, manufactured
consumer goods, iron and steel, foodstuffs, petroleum products
Major trade partners: France and other EC countries on preferential basis
Budget: 1970 -- revenue $60 million, expenditure $69 million
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=U5$1
as of February 1973, floating since February 1973 (official)
Fiscal year: calendar year
Agriculture: export crops include copra, citrus fruits, pineapple, tomatoes, and
bananas, with subsistence crops of yams and taro
Industry: fruit processing
Exports: $3.0 million (1970); fruit juice, clothing, citrus fruits
Imports: $6.5 million (1970)
Major trade partners: (1970) exports -- 98% New Zealand, imports -- 76% New
Zealand, 7% Japan
Monetary conversion rate: 0.68 NZ$=US$1
GNP: $1,130 million (1972 est.), $620 per capita; real growth rate 1972, 4.9% (est.)
Agriculture: main products -- bananas, coffee, sugarcane, rice, corn, cocoa,
livestock products; caloric intake, 2,610 calories per day per capita (1966)
Fishing: catch 8,400 metric tons, $4.8 million (1971); exports, $1.8 million
(1970), imports $0.5 million (1970)
77
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major industries: food processing, textiles and clothing, construction
materials, fertilizer
Electric power: 220,000 kw. capacity (1972); 1 billion kw.-hr. produced
(1972), 540 kw.-hr. per capita ,
Exports: $278 million (f.o.b., 1972 prel.); coffee, bananas, sugar, beef,
fertilizers, cacao
Imports: $373 million (c.i.f., 1972 prel.); manufactured products, machinery,
transportation equipment, chemicals, fuels, foodstuffs
Major trade partners: exports -- 41% U.S., 21% CACM, 9% West Germany, 3% Japan; A
imports -- 32% U.S., 22% CACM, 8% West Germany, 11% Japan (1971)
Aid:
economic -- extensions from U.S. (FY46-72), $121.1 million loans, $98.8
million grants; from international organizations (FY46-72), $191.8 million;
from other Western countries (1960-71), $7.7 million;
military -- assistance from U.S. (FY60-72) $1.9 million
Monetary conversion rate: 6.62 colones=US$1 (official buying rate); 6.65
colones=US$1 (official selling rate)
Fiscal year: calendar year
GDP: $4.7 billion (1972 est. at 1972 prices), $540 per capita; 60% private
consumption, 20% public consumption, 20% gross investment; real growth
rate 1972, -2%
Agriculture: main crops -- sugar, tobacco, coffee, rice, potatoes, tubers,
citrus fruits
Fishing: catch 139,600 metric tons (1972); exports $26.3 million (1972), imports
$11.9 million (1971)
Major industries: sugar milling, petroleum refining, food and tobacco processing,
textiles, chemicals, paper and wood products, metals
Shortages: spare parts for transportation and industrial machinery, consumer goods
Crude steel: 0.35 million metric tons capacity (planned 1969); 154,000 metric
tons produced (1972); 20 kg. per capita
Electric power: 1,137,000 kw. capacity (1972); 4.5 billion kw.-hr. produced
(1972), 570 kw.-hr. per capita
Exports: $810 million (f.o.b., 1972 est.); sugar, nickel, tobacco
Imports: $1,340 million (c.i.f., 1972 est.); capital goods, industrial raw
materials, food, petroleum
79
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major trade partners: exports -~ U.S.S.R. 31%, China 6%, other Communist
countries 17%, Japan 17%; imports -- U.S.S.R. 59%, China 6%, other
Communist countries 11% (1972 est.)
Monetary conversion rate: 1 peso=US$1.21 (nominal)
Fiscal year: calendar year
GNP: $835.6 million (1972), $1,300 per capita; 1971 growth rate 14%, 1958 current i
market prices
Agriculture: main crops -- vine products, citrus, potatoes, other vegetables;
food shortages -- grain, dairy products, meat, fish; caloric intake, 2,460
calories per day per capita (1964-66)
Major industries: mining (cupreous and iron pyrites, asbestos), manufactures
principally for local consumption -- food, beverages, footwear
Shortages: water, petroleum
Electric power: 204,000 kw. capacity (1972); 716 million kw.-hr. produced (1972),
930 kw.-hr. per capita
Exports: $134 million (f.0.b., 1972); principal items -- copper, pyrites, citrus,
raisins, and other agricultural products
Imports: $315 million (c.i.f., 1972); Principal items -- manufactured goods,
machinery and transport equipment, petroleum products, foods
Major trade partners: (1972) U.K. 32%, West Germany 7%, Italy 6%, EC-six 23%,
U.S. 5%, U.S.S.R. 4%
Aid: economic -- U.S., $30.3 million authorized (FY46-72); IBRD, $51.5 million
(FY46-72); U.N. Technical Assistance, $1.7 million (FY46-72); U.N. Special
Fund, $9.9 million (FY46-72)
Monetary conversion rate: ] Cyprus pound=US$2.61 (December 197] through January
1973), 1 Cyprus pound=US$2.90 (as of July 1973)
Fiscal year: calendar year
GDP: $21.0 million (1971 est.), $270 per capita; 8.8% increase in 1971 -- including
price changes
Agricultural products: bananas, citrus, coconuts, cocoa
Major industries: agricultural processing, tourism
Electric power: 5,420 kw. capacity (1971), 15 million kw.-hr. produced
(1971 est.), 200 kw.-hr. per capita
Exports: $6.1 million (f.o.b., 1970); bananas, lime juice and oi1, cocoa and
reexports
Imports: $16.3 million (c.i.f., 1970); foodstuffs, manufactured articles
Major trade partners: U.K. 53%, Commonwealth Caribbean countries 15%, Canada
10%, U.S. 7% (1963)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1, now floating with
pound sterling
GNP: $1.9 billion (1972), $440 per capita; real growth rate 1972, 9.0%
Agriculture: main crops -- sugarcane, coffee, cocoa, tobacco, rice, corn; self-
sufficient in rice; caloric intake, 2,200 calories per day per capita (1966)
Major industries: sugar processing, nickel mining, bauxite mining, peanut
processing, textiles, cement
91
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release
ECONOMY (cont''d):
2004/08/31 : CIA-RDP79-01051A000600010004-7
Electric power: 256,500 kw. capacity (1971); 1 billion kw.-hr. produced
(1971), 250 kw.-hr. per capita
Exports: $347 million (f.0.b., 1972); sugar, nickel, tobacco, coffee, cocoa,
bauxite
Imports: $350 million (c.i.f., 1972); foodstuffs, petroleum, industrial raw
materials, capital equipment
Major trade partners: exports -~- U
(1972)
Aid:
Economic -- from U.S. (FY46-72)
-S. 57%, EC 17% (1972); imports -- U.S. 50%
» $217.2 million in grants, $279.5 million
in loans; from international organizations (FY46-72), $103.3 million; from
other western countries (1960-71), $11.7 million
military -- assistance from U.S
. (FY53-71), $31.0 million
Monetary conversion rate: 1] peso=US$1
Fiscal year: calendar year
GDP: $1.8 billion (1972 est.), $280 per capita; 72% private consumption, 14%
public consumption, 14% gross investment (1970 est.); real growth rate 1972
est., 8%
Agriculture: main crops -- bananas, coffee, cocoa, sugarcane, cotton, corn,
potatoes, rice; caloric intake, 1,970 calories per day per capita (1970)
93
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Fishing: catch 99,700 metric tons (1971); exports $18 million (1971), imports
negligible
Major industries: food processing, textiles, chemicals, fishing, petroleum
Electric power: 328,000 kw. capacity (1971); 1 billion kw.-hr. produced .
(1971), 164 kw.-hr. per capita
Exports: $301 million (f.o.b., 1972 est.); bananas, petroleum, coffee, cocoa,
sugar, fish products
Imports: $328 million (c.i.f., 1972 est.); agricultural and industrial machinery,
wheat, petroleum products, chemical products, transportation and communication ‘
equipment
Major trade partners: exports -- U.S. 39%, EC 20%, Japan 17%; imports -- U.S.
34%, EC 21%, Japan 12% (1971)
Aid:
economic -- extensions from U.S. (FY46-72), $211.7 million loans, $110.0
million grants; from international organizations (FY46-72), $236.1 million;
from Communist countries (1954-71), $15.4 million loans;
military -- assistance from U.S. (FY49-72), $63.9 million
Monetary conversion rate: 25.25 sucres=US$1 (official selling rate}
Fiscal year: calendar year
Agriculture: main cash crop -- cotton; other crops -- rice, onions, beans, wheat,
corn, barley; not self-sufficient in food, but agriculture a net earner of
foreign exchange
Major industries: textiles, food processing, chemicals, petroleum, construction,
cement
Electric power: 4,555,000 kw. capacity (1972); 8 billion kw.-hr. produced
(1972), 330 kw.-hr. per capita
95
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Aid:
economic -- Communist countries, $1,976 million in credits through December
1972; U.S., $910.6 million in credits and grants through June 1967
(diplomatic relations and aid suspended June 1967, aid resumed January 1972); »
sizable credits from international agencies, West Germany, Italy; large grants
from Libya since 1969; $250 million annual subsidy from Arab states while
canal is closed;
military -- Communist countries, about $3 billion through December 1972
Monetary conversion rate: 1 Egyptian pound=US$2.54 (selling rate); 0.394 Egyptian
pound=US$1 (selling rate)
Fiscal year: calendar year, beqinning in 1973
GNP: $1.1 billion (current prices, 1972), $300 per capita; 76% private t
consumption, 11% government consumption, 13% domestic investment
(1971); real growth rate 1972 est., 4.0%
Agriculture: main crops -- coffee, cotton, corn, sugar, rice, beans; caloric
intake, 2,000 calories per day per capita (1963-64)
Fishing: catch 16,200 metric tons (1971); exports $6.0 million (1971), imports
$0.5 million (1972)
Major industries: food processing, textiles, clothing, petroleum products
Electric power: 220,000 kw. capacity (1972); 830 million kw.-hr. produced
(1972), 230 kw.-hr. per','fa52d2902c95780b8b4ab2ce37063fb6a4a91b2655f3862fea47f3624a26937a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a8bf59514d3527fcc09f599e0b754f8f2bd8d12eaa76bb46a10ef48840233ec',1974,'BR','Brazil','economy',16,'capita
Exports: 273 million (f.o.b., 1972); coffee, cotton, sugar, chemicals,
other manufactures
Imports: $276 million (c.i.f., 1972); machinery, automotive vehicles, petroleum,
foodstuffs
Major trade partners: exports -- U.S. 23%, CACM 35%, EC 23%, Japan
13%; imports -- U.S. 28%, CACM 25%, EC 16%, Japan 12% (1971)
Aid:
economic -- from U.S. (FY46-72), $90.6 million loans, $63.4 million grants;
from international organizations (FY46-72), $127.2 million; from other Western
countries (1960-71) $9.8 million;
military -- assistance from U.S. (FY53-72), $7.4 million
Monetary conversion rate: 2.5 colones=US$1 (official)
Fiscal year: calendar year ‘4
GDP: $63.7 million (1970 est.); $220 per capita
Agriculture: major cash crops -- Rio Muni, timber, coffee; Fernando Po, cocoa;
main food crops -- rice, yams, cassava, bananas, oil palm nuts, manioc, and
livestock
Fishing: catch 4,000 metric tons (1970); exports $86,000 (1970)
Major industries: fishing, sawmilling
Electric power: 2,800 kw. capacity (1972); 9 million kw.-hr. produced (1972),
about 30 kw.-hr. per capita
Exports: $24.9 million (1970); cocoa, coffee, and wood
Imports: $21.0 million (1970); foodstuffs, chemicals and chemical products,
textiles
Major trade partner: Spain
Aid: Spain, $14.0 million (1969); Libya, $1 million (1971)
99
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Budget: 1970 current budget receipts $14.7 million, current expenditure
$10 million, capital expenditure $10 million
Monetary conversion rate: 64.47 Guinean pesetas=US$1 (official)
.
GDP: $1,629 million (1970 in current prices), $60 per capita; 1970 average annual
growth rate 6.1% (current prices)
Agriculture: main crops -- coffee, teff, durra, barley, wheat, corn, sugarcane,
cotton, pulses, oilseeds, livestock; almost self-sufficient in food
ee 6,927 metric tons (1970), $1.4 million (1970); exports $348,000
1970
Major industries: cement, sugar refining, cotton textiles, food processing,
oil refinery
101
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Electric power: 306,000 kw. capacity (1972); 673 million kw.-hr. produced
(1972), 25 kw.-hr. per capita
Exports: $168 million (f.0.b., 1972); coffee 55.8%, hides and skins 8.2%, ;
oilseeds, oilcakes, and nuts 10.2%, cereals 7.4%; $4.6 million to Communist t
countries (1971)
Imports: $189 million (c.i.f., 1972); metals, machinery and vehicles 47.1%,
petroleum and chemicals 17%, foodstuffs, live animals, and beverages 7.3%;
$9.7 million from Communist countries (1970)
Major trade partners: imports -- Italy, Japan, West Germany, and U.S.;
exports -- U.S., West Germany, Italy, Saudi Arabia, Japan
Monetary conversion rate: 2.303 Ethiopian doll lars=US$1; 2.07 Ethiopian
dollars=US$1 (official as of June 1973)
Fiscal year: 8 July - 7 July
GDP: $77.3 million (1969), about $1,980 per capita
Agriculture: sheep and cattle grazing
Fishing: catch 210,100 tons (1971); exports $42.7 million
Major industry: fishing
Electric power: 27,545 kw. capacity (1972); 66.9 million kw.-hr. produced (1972),
1,713 kw.-hr. per capita
Exports: $36.9 million (f.0.b., 1970); fish and fish products
Imports: $33.6 million (c.i.f., 1970); machinery and transport equipment, pet-
roleum and petroleum products, food products
Major trade partners: (1970) Denmark 48%, U.K. 9%, Sweden 4%, U.S. 6%, Norway
4%; EC 15%; EFTA 68%
Monetary conversion rate: 1 Danish Kroner=US$0.1755 (September 28, 1973, floating)
Fiscal year: 1 April - 31 March
103
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Government budget: Colony -- revenues, $1.0 million (FY68); expenditures,
$1.1 million (FY68)
Agriculture: Colony -- predominantly sheep farming; dependencies -- whaling
and sealing
Major industries: Colony -- wool processing; dependencies -- whale and seal
processing
Electric power: 1,440 kw. capacity (1972); 4 million, kw.-hr. produced (1972),
1,740 kw.-hr. per capita
Exports: Colony -- $2.28 million (1969); wool, hides and skins, and other;
dependencies -- no exports in 1968 or 1969
Imports: Colony -- $1.22 million (1969); food, clothing, fuels, and machinery;
dependencies -- $8,368 (1969); mineral fuels and lubricants, food, and
machinery
Major trade partners: nearly all exports to the U.K., 77% of imports from the
U.K.; dependencies -- exports to the Netherlands (63%) and Japan (37%),
imports from Curacao, Japan, and the U.K.
Monetary conversion rate: 1 Falkland Island pound=US$2 .60
GNP: $270 million (1972), $490 per capita; 6% average annual growth rate (1969-72)
Agriculture: main crops -- sugar, coconut products, bananas, rice; major
deficiency, grains
Major industries: tourism, sugar processing
Exports: $62.1 million (f.o.b., 1972 excluding reexports); sugar, copra, copper
Imports: $164.2 million (c.i.f., 1972); machinery, manufactured goods, food
Major trade partners: U.K., Australia, U.S., Japan, New Zealand
Aid: disbursed 1968 -- Australia $1.5 million, U.S. $600,000, U.K. $4.2 million
Monetary conversion rate: 0.77 Fijian dollar=US$1 (September 1973)
Fiscal year: calendar year
GNP: $14.3 billion (1972), $3,050 per capita; 53% consumption, 26.2%
investment, 21.9% government, -1.1% net exports of goods and services; 1972
growth rate 4.8%, constant prices
Agriculture: animal husbandry, especially dairying, predominates; forestry
important secondary occupation for rural population; main crops -- cereals,
sugar beets, potatoes; 85% self-sufficient; shortages -- food and fodder
grains; caloric intake 2,940 calories per day per capita (1970-71)
Major industries: include metal manufacturing and shipbuilding, forestry and
wood processing (pulp, paper), copper refining
Shortages: fossil fuels; industrial raw materials, except wood, and iron ore
Crude steel: 1.4 million metric tons produced (1972), 300 kilograms per capita
Electric power: 5,562,320 kw. capacity (1972); 22.4 billion kw.-hr. produced
(1972), 4,700 kw.-hr. per capita
Exports: $2,947 million (f.o.b., 1972); timber, paper and pulp, ships, machinery,
iron and steel, clothing and footwear
Imports: $3,198 million (c.i.f., 1972); foodstuffs, petroleum and petroleum
products, chemicals, transport equipment, iron and steel, machinery, textile
yarn and fabrics
Major trade partners (1972): 24% EC, 43% EFTA, 13% West Germany, 15% U.K.,
17% Sweden, 5% U.S., 12% U.S.S.R.
Aid: U.S. $180 million authorized FY46-71, $22.1 million in FY71, none in 1972;
IBRD -~ $276.5 million authorized through 1946-72, $33 million in 1971;
Finnish foreign aid programs have amounted to $23 million 1961-69, $15,000
in 1970
Monetary yee rate: new markka (Fmk) 1+US$0.2710 (spot ate as of August
31, 1973
Fiscal year: calendar year
GNP: $238.4 billion (1972), $4,610 per capita; 60% consumption, 27% investment
(including government), 12% government consumption; 1% net foreign balance;
1972 real growth rate 5.5%
Agriculture: Western Europe''s foremost producer; main crops -- beef, cereals, sugar rn
beets, potatoes, wine grapes; self-sufficient for most temperate zone food- :
stuffs; food shortages -- fats and oils, tropical produce; caloric intake,
3,270 calories per day per capita (1969-70)
Fishing: catch 625,000 metric tons, $385 mill
imports $247 million (1972)
Major industries: steel, machinery and equipment, textiles and clothing,
chemicals, food processing, metallurgy
Shortages: crude oil, textile fibers, most nonferrous ores, coking coal, fats
and oils
Crude steel: 24.1 million metric tons produced (1972), 470 kilograms per capita
Electric power: 40,400,000 kw. capacity (1972); 163.4 billion kw.-hr. produced
(1972), 2,900 kw.-hr. per capita
Exports: $26.4 billion (f.o.b., 1972); principal items -- textiles and clothing,
iron and steel products, machinery and transportation equipment, foodstuffs
and agricultural products, alcoholic beverages
Imports: $24.7 billion (f.o.b., 1972); principal items -- machinery and
equipment, crude petroleum, iron and steel products, textile fibers, coal
and coke, foodstuffs, alcoholic beverages
Major trade partners: (1971) EC-Six 55%; West Germany 24%; Belgium-Luxembourg 12%;
Italy 13%; Netherlands 6%; U.K. 6%; U.S. 7%; Eastern Europe 3%; U.S.S.R. 1%;
franc zone 7%
Aid: )
economic (received) -- U.S., $5,356 million authorized (FY46-72), $19
million in FY72;
military -- U.S., $4,355 million authorized (FY46-72); net official economic
aid to less developed areas and multilateral agencies -- $8,400 million
(FY60-70), $1,550 million (1972 est.)
Monetary conversion rate: 1 franc=US$0.2362 (as of September 28, 1973, floating) _
Fiscal year: calendar year
on (1971); exports $61 million,
GNP: $40 million (at market prices, 1970), $800 per capita
Agriculture: main crops -- rice, corn, manioc, cocoa, bananas, Sugarcane
Fishing: catch 900 metric tons (1969) $378,000; shrimp exports $3.9 million
(1969); imports $2.3 million (1969)
Major industries: timber, rum, gold mining, production of rosewood essence, and
space center
Electric power: 18,560 kw. capacity (1971); 55 million kw.-hr. produced (1971),
1,060 kw.-hr. per capita
Exports: $2.7 million (f.o.b. 1971); shrimp, timber, rum, rosewood essence
Imports: $39.8 million (c.i.f., 1971); food (grains, processed meat), other
consumer goods, producer goods and petroleum
Major trade partners: exports -- U.S. 78%, France 11%, Martinique 5%; imports --
France 49%, U.S. 10%, Trinidad and Tobago 3% (1969)
115
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Monetary conversion rate: 5.525 francs=US$]1 (1972)
Fiscal year: calendar year
COMMUNICATIONS: ‘7
Railroads: 20 mi. private plantation line, 1''11 5/8" gage; 8 mi. abandoned
narrow-gage line
Highways: 450 mi.; 250 mi. paved, 200 mi. improved earth or gravel
Inland waterways: 290 mi.; navigable by small oceangoing vessels and river
and coastal steamers; 2,110 mi. possibly navigable by native craft
Ports: 1 major, 7 minor
Civil air: no major transport aircraft
Airfields: 15 total, 10 usable; 1 with permanent-surface runway; 1 with runway
8,000-11,999 ft.; 1 seaplane station
Telecommunications: limited open-wire telecom system with about 6,400
telephones; 7,000 radio receivers and 2,900 TY receivers, 1 AM, 2 FM
and 2 TV stations; 1 satellite tracking and control station
DEFENSE FORCES:
Military manpower: males 15-49, 13,000; 10,000 fit for military service
116
Slit hii ely
Approved For Relea
se 2004/08/31 : CIA-RDP79-01051 AO006000 1000s
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 103 FRENCH POLYNESIA
"About 1,544 sq. mi.
WATER:
Limits of territorial waters: 3n. mi.
Coastline: about 975 mi.
PEOPLE: ee
Population: 134,000, average annual growth rate 4.2%
(11/62-2/71)
Ethnic divisions: 78% Polynesian, 12% Chinese, 6% local
French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 32% Catholic
Gross territorial product: $68 million (1970)
Agriculture: livestock; desert conditions limit commercial crops to about 15
acres, including fruits and vegetables
Industry: ship repairs
Electric power: 18,000 kw. capacity (1972); 18 million kw.-hr. produced (1972),
x 222 kw.-hr. per capita
Imports: $54 million (1972), almost all domestically needed goods
Exports: $27 million (1972), hides and skins
Aid: $2.4 million in 1967 from France
Monetary conversion rate: 197.11 Djibouti francs=US$1 official through 19723
177.72 Djibouti francs=US$1, thereafter
yr Fiscal year: probably same as that for France (calendar year)
119
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GDP: $407 million (1972, est.), $790 per capita; real GDP
growth 8.5%
Agriculture: commercial -- cocoa, coffee, wood, palm oil, rice; main food crops
-- bananas, manioc, peanuts, root crops; imports food
Fishing: catch 4,000 metric tons (1970); exports $600,000 (1970), imports -- not
available
Major industries: sawmills, petroleum refinery, natural gas, agricultural
processing; mining of increasing importance; major minerals -- manganese,
uranium, gold, and iron
Electric power: 34,200 kw. capacity (1972); 133 million kw.-hr. produced (1972),
255 kw.-hr. per capita
12]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $217.5 million (f.0.b., 1972); wood and wood products 40%; minerals
(manganese, uranium concentrates, gold, crude oil) 60% (1970)
Imports: $137.2 million (c.i.f., 1972) excluding UDEAC trade; mining, roadbuilding 4
machinery, electrical equipment, transport vehicles, foodstuffs, textiles
Major trade partners: France, U.S., West ermany, and Curacao; preferential
tariffs to EC and franc zone
Budget: 1971 -- receipts $93.9 million, current expenditures $72.8 million,
investment expenditures $20.9 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French a
francs; 255.785 CFA francs=US$1 as of february 1973 (currency Floating
since February 1973)
Fiscal year: calendar year
GDP: $46 million (FY71 est.), about $120 per capita
Agriculture: main crops -- peanuts, rice, palm kernels
Fishing: catch 6,000 metric tons (1971); exports $108,000 (1971)
Major industry: peanut processing
Electric power: 7,100 kw. capacity (1972); 17 million kw.-hr. produced (1972),
44 kw.-hr. per capita
Exports: $15.7 million (1970); peanuts and peanut products 90% to 95%, palm
kernels
Imports: $17 million (1970); textiles, foodstuffs, tobacco, machinery,
petroleum products
Major trade partners: exports -- U.K. and France; imports -- U.K. and Japan
Aid: economic -- U.K. (1968-71) about $8 million commitment
123
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Monetary conversion rate: floating with sterling since June 1972; new fixed
relationship as of March 1973 was 1 pound sterling=4 Gambian Dalasis
Fiscal year: 1 July - 30 June
Agriculture: food deficit area; main crops -- potatoes, rye, wheat, barley, oats,
industrial crops; shortages in grain, vegetables, vegetable of], beef;
caloric intake, 3,000 calories per day per capita (1970-71)
Fish catch: 332,000 metric tons (1971)
Major industries: metal fabrication, chemicalsi, light industry, brown coal,
uranium, and shipbuilding
Shortages: coking coal, coke, crude oi], rolled steel products, nonferrous metals
Crude steel: 5.67 million metric tons produced] (1972), approx. 330 kg. per capita
Electric power: 14,181,000 kw. capacity (1972)|; 72.8 billion kw.-hr. produced
(1972), 4,270 kw.-hr. per capita
Exports: $6,298 million (f.0.b. delivering country, 1972)
Imports: $6,014 million (f.0.b. delivering Souneey, 1972)
Major trade partners: $12,312 million (1972); 38% U.S.S.R., 34% other
Communist countries, 29% non-Communist countries
Monetary conversion rate: 2.6 DME=US$1 (present 1973 rate; for 1972,
3.8 DME=US$1; prior to 1972, 4.2 DME=US$1)
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for the consumption year
] July - 30 June
NOTE: foreign trade data converted at 1972 rate
GDP: $2.6 billion (1971) at current prices, about $290 per capita; real growth
rate about 3.6%
Agriculture: main crop -- cocoa; other crops include root crops, corn, sorghum
and millet, peanuts; not self-sufficient, but can become so
Fishing: catch 220,000 metric tons (1971), $35 million, imports $9.3 million
Major industries: mining, lumbering, light manufacturing, fishing, aluminum
Electric power: 893,000 kw. capacity (1972); 3.49 billion kw.-hr. produced
(1972), 380 kw.-hr. per capita
129
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $326 million (f.o.b., 1971); cocoa (about 75%), wood, gold, diamonds,
manganese, bauxite, and aluminum (aluminum|regularly excluded from balance
of payments data)
Imports: $431 million (c.i.f., 1971); textiles and other manufactured goods,
food, fuels, transport equipment
Major trade partners: U.K., EC, and U.S.
Budget: FY71 (Provisional) -- current expenditure $319 million, capital
expenditure $102 million
Monetary conversion rate: 1 Cedi=US$0.87 (official, March 1973); fixed in terms
of SDR''s
Fiscal year: 1 July - 30 June
GNP: $8.5 million (1968), $155 per capita
; Agriculture: subsistence crops of copra, vegetables, supplemented by domestic
fishing
Industry: phosphate production, expected to cease tn 1976
Exports: $8 million (1969 est.); 75% phosphate, copra
Imports: $3 million (1969 est.); foodstuffs, fuel
Monetary conversion rate: 0.67 Australian $=US$1
Economic activity in Gibraltar centers on commerce and large British naval and
air bases. Nearly all trade in the well-developed port is transit trade and
port serves also as important supply depot for fuel, water, and ships’ wares.
Recently built dockyards and machine shops provide maintenance and repair
services to 3,500-4,000 vessels that call at Gibraltar each year.
U.K. military establishments and civil government employ nearly half the insured
labor force. Local industry is confined to manufacture of tobacco, roasted
coffee, ice, mineral waters, candy, and canned fish. Some factories for
manufacture of clothing are being developed. A smal] segment of local
population makes its livelihood by fishing. In recent years tourism has
increased in importance.
133
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Electric power: 29,000 kw. capacity (1972); 45 million kw.-hr. produced (1972),
1,500 kw.~hr. per capita
Exports: $2.9 million (f.o.b., 1971); principally reexports of tobacco,
petroleum, and wine; principally to the EC (31%) and the U.K. (16%) .
Imports: $23.1 million; principally from the EC (21%) and the UK (49%)
Major trade partners: U.K., Morocco, Portugal, Netherlands
Monetary eo tvershel rate: 1 Gibraltar pound=US$2.414 (as of September 28, 1973,
floating
COMMUNICATIONS: st
Railroads: none
Highways: 19 miles, all paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: 1 permanent-surface runway, 4,000-7,999 ft.; 1 seaplane station
Teleconmmunications: international radiocommunication facilities; automatic
telephone system serving 6,100 telephones; 7,000 radio receivers; 6,900
TV receivers, 1 AM, 1 FM, and 2 TV stations; 13 submarine telegraph cables
DEFENSE FORCES:
Military manpower: males 15-49, about 6,000; about 3,000 fit for military service
Defense is responsibility of United Kingdom |
134
tare anianieaiednndn matinee Ree
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 24 GREECE
51,200 sq. mi.; 29% arable and land under permanent crops,
40% meadows and pastures, 20% forested, 11% wasteland,
urban, other
Land boundaries: 740 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
Coastline: 8,500 mi.
GNP: $12.6 billion (1972), $1,425 per capita; 78% consumption, 22% investment;
1971 growth rate 12.4%, current market prices
Agriculture: subject to droughts; main crops) -- wheat, olives, tobacco, cotton;
nearly self-sufficient; food shortages --| livestock products; caloric intake,
2,960 calories per day per capita (1963)
Major industries: food processing, tobacco, chemicals, textiles, petroleum
refining, aluminum processing
Shortages: petroleum, minerals, feed grains
Crude steel: 210,000 metric tons produced (1969), 20 kg. per capita
Electric power: 2,800,000 kw. capacity (1972); 12.1 billion kw.-hr. produced
(1972), 1,350 kw.-hr. per capita
Exports: $870 million (f.o.b., 1972); principal items -- tobacco, cotton, fruits,
metals
Imports: $2,345 million (c.i.f., 1972); principal items -- machinery and
automotive equipment, manufactured consumer goods, petroleum and
petroleum products, chemicals
Major trade partners: (1972) -- 50% EC, 13% sterling area, 14% U.S.,
9% CEMA countries
Aid:
economic (authorized) -- U.S., $1,957.4 million (1946-72); International
Finance Corporation, $14.9 million through 1971; U.N. Technical Assistance,
$4.3 million through 1972; U.N. Special Fund, $11.3 million through 1972;
IBRD, $95.4 million (1968-72), $20 million in 1971; Consortium, $40
million in 1966; EC (1964-71) $69.2 million;
military -- U.S., $2,271.2 million (1946-72)
Monetary conversion rate: 1 drachma=US$0.033 (official)
Fiscal year: calendar year
GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep grazing; garden produce
Fishing: catch 38,400 tons, $6.3 million; exports $16.0 million (1971)
Major industries: mining, slaughtering, fishing, sealing
Electric power: 27,338 kw. capacity (1972); 45.8 million kw.-hr. produced (1972),
935 kw.-hr. per capita
Exports: $15.4 million (f.o.b., 1970); fish and fish products, nonmetallic minerals
Imports: $58.3 million (f.0.b., 1970); machinery and transport equipment,
petroleum and petroleum products, food products
Major trade partners: (1970) Denmark 91%, U.S. 3%, Venezuela 3%
Monetary conversion rate: 1 Danish Kroner=US$0.1755, (September 1973, floating)
Fiscal year: 1 April - 31 March
GDP: $30 million (at marketprices, 1970) $280 per capita
Agriculture: main crops -- cocoa, spices, bananas
Fishing: 1,700 metric tons, $806,000 (1971)
Electric power: 7,000 kw. capacity (1972); 15.2 million kw.-hr. produced
(1972), 140 kw.-hr. per capita
Exports: $5.2 million (f.0.b., 1972 est.)3; cocoa beans, bananas, nutmeg, mace
Imports: $20.5 million (c.i.f., 1972 est.}; textiles, flour, clothing,
miscellaneous manufactured goods
Major trade partners: U.K. 37%, U.S. 9%, Canada 9% (1966)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1, now floating with
pound sterling
139
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GDP: $259 million (1971), $760 per capita; real growth rate (1971) 8.2%
Agriculture: main crops, Sugarcane and bananas
Major industries: agricultural processing, sugar milling and rum distillation
Electric power: 38,000 (est.) kw. capacity (1972); 115 million kw-hr. produced
(1972), 341 kw.-hr. per capita
Exports: $37 million (f.o.b., 1972), sugar, bananas, rum
Imports: $148 million (c.i.f., 1972), foodstuffs, clothing and other consumer
goods, raw materials and supplies, and petroleum
Major trade partners: exports -- France 71%, U.S. 17%, Germany 7%, other
5%; imports -- France 70%, U.S. 9%, Germany 3%, Netherlands Antilles 32,
Netherlands 3%, other 12% (1968)
141
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Monetary conversion rate: 5.051 francs=US$1 (1972)
Fiscal year: calendar year
GNP: $5.2 billion (FY71), $1,890 per capita
Agriculture: main crops -- sugar, coffee, tobacco, bananas
Fishing: catch 57,700 metric tons, $27.9 million (1971)
Major industries: textiles, clothing manufacture, food processing, petroleum
refining, petro-chemicals
Electric power: 1.3 million kw. capacity (1972); 9.2 billion kw.-hr. produced
(1972), 3,365 kw.-hr. per capita
Exports: $1,736 million (f.0.b., 1971); sugar, pineapple, citrus fruits, coffee,
rum, textiles
Imports: $2,884 million (f.0.b., 1971); food, machinery, transportation equip-
ment, fuels, minerals
285
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major trade partner: exports -- U.S, 93%; imports -« U.S. 77%
Monetary conversion rate: uses U.S, currency
Fiscal year: 1 July - 30 June 7
GNP: $425 million (1972 rev. est.) $3,120 per','340e54fd95f99422b91fac62cc3d6092ccd2e7834a3f1a01f6be51576a718b71','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a9f2eaa884f5e9b416e7c6e94a5e1a7f0062ce810ceda97c48d75725d7fa7b8',1974,'BR','Brazil','economy',17,'capita
Agriculture: farming and grazing on small scale; commercial fishing increasing
in importance; most food imported; rice and dates staple diet
Major industries: oi] production and refining; crude oi] production from onshore
and offshore averaged 440,000 bbis. per day in 1972; oil revenues $287
million in 1972, representing 91% of government/royal family income; major
development projects include $7 million harbor at Ad Dawhah, fertilizer plant,
2 desalting plants, refrigerated storage for fishing, and a cement plant
Electric power: capacity 80,000 kw. (1972); 200 million kw.-hr. produced (1972),
1,400 kw.-hr. per capita
Exports: crude oi] dominates; non-oi1 exports $22 million (1972)
Imports: $192 million in 1972
Aid: multilateral annual average $170,000 (1967-69)
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.25 (as of October 1973)
Fiscal year: 1 April - 31 March
Agriculture: cash crops -- almost entirely sugarcane, small amounts of vanilla
and perfume plants; food, crops -- tropical fruit and vegetables, manioc,
bananas, corn, market garden produce, also some tea, tobacco, and coffee;
food crop inadequate, most food needs imported
Major industries: 12 sugar processing mills, rum distilling plants, cigarette
factory, 2 tea plants, fruit juice plant, canning factory, a slaughterhouse,
and a number of small shops producing handicraft items
Electric power: 54,400 kw. capacity (1972); 108 million kw.-hr. produced (1972),
246 kw.-hr. per capita
Exports: $50 million (f.o.b., 1972); 90% sugar, 4% perfume essences, 5% rum and
molasses, 1% vanilla and tea
Imports: $196 million (c.i.f., 1972); manufactured goods, food, beverages,
and tobacco, machinery and transportation equipment, raw materials and
petroleum products
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major trade partners: France (in 1970 supplied 62% of Reunion''s imports, purchased
76% of its exports); Mauritius (supplied 12% of imports)
Monetary conversion rate: 255.785 Conmunaute Financiere Africaine francs=US$1 as
of February 1973 (floating since February 1973)
Fiscal year: probably calendar year
GDP: $1,765 million (1972), $310 per capita; real growth rate 6% (1965-71)
Agriculture: main crops -- tobacco, corn, sugar, cotton; livestock; self-
sufficient in foodstuffs except wheat
Major industries: mining and steel, textiles
Electric power: 1,323,000 kw. capacity (1972); 7.94 billion kw.-hr. produced
(1972), 1,350 kw.-hr. per capita
Exports: $495 million (f.o.b., 1972), including net gold sales and reexports;
tobacco, asbestos, copper, meat, chrome, gold, nickel, clothing, sugar
Imports: $408 million (f.0.b., 1972); machinery, petroleum products,
wheat, transport equipment
Major trade partners: South Africa, Portugal, and Portuguese territories
Aid: no substantial military or economic aid
Monetary conversion rate: 1 Rhodesian dollar=US$1.40; 0.714 Rhodesian dollar=US$1
Fiscal year: 1 July - 30 June
GNP: $30.5 billion in 1972 (at 1971 prices), $1,470 per capita; 1972 growth rate
8.4%
Agriculture: net exporter; main crops -- corn, wheat, oilseed; livestock --
cattle, hogs, sheep; caloric intake, 3,000 calories per day per capita (1967-68)
Fish catch: 75,000 metric tons (1971)
Major industries: machinery, metals, fuels, chemicals, textiles, food processing,
timber processing
Shortages: iron ore, coking coal, metallurgical coke, cotton fibers, natural
rubber :
Crude steel: 7.4 million metric tons produced (1972), 360 kg. per capita
293
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Electric power: 9,100,000 kw. capacity (1972); 43.4 billion kw.-hr. produced
(1972), 2,085 kw.-hr. per capita
Exports: $2,586 million (f.o.b., 1972); 25% machinery and equipment; 36% fuels,
aes eee semifinished products; 20% foodstuffs; and 19% consumer goods
(1972
Imports: $2,613 million (mixture f.o.b. and c.i.f., 1972); 46% machinery and
equipment; 44% fuels, raw materials, semifinished products; 5% foodstuffs;
and 5% consumer goods (1971)
Major trade partners: 5,199 million in 1972; 48% non-Communist countries, 52% re
Communist countries (1971)
Monetary conversion rate: 4.97 lei=US$1 (commercial) 14.4 lei=US$1 (tourist);
old commercial rates: in 1972, 5.53 lei=US$1, prior to 1972 6.00 lei=US$1
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year, 1 July -
30 June
Note: foreign trade data converted at 1972 rate
GDP: $240 million (1971), $60 per capita
Agriculture: cash crops -- mainly coffee, tea, cotton, some pyrethrum; main
food crops -- bananas, cassava; stock raising; self-sufficiency increasing
but country still imports some foodstuffs
Major industries: mining of cassiterite (tin ore), agricultural processing, and
light consumer goods
Electric power: 21,460 kw. capacity (1972); 100 million kw.-hr. produced (1972),
28 kw.-hr. per capita
Exports: $24.1 million (f.o.b., 1971); mainly coffee, tea, pyrethrum, cassiterite
Imports: $35.8 million (c.i.f., 1971); textiles, foodstuffs, machines, equipment
Major trade partners: U.S., Belgium, Zaire
Aid: U.S., FY62-72, $8.0 million; Belgium, France, West Germany, and Canada,
FY64-67, $33.4 million obligated
Monetary conversion rate: 92.105 Rwanda francs=US$1 (official) until March 1973,
since then the rate has been determined on a day to day basis
Fiscal year: calendar year
295
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GNP: $40 million (1970 est.), $350 per capita
Agriculture: main crops -- bananas, copra, sugar, cocoa, spices
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 4,600 kw. capacity (1971); 10 million kw.-hr. produced (1971
est.); 86 kw.-hr. per capita
Exports: $6.0 million (f.o.b., 1969); sugar, bananas, cocoa
Imports: $21.6 million (c.i.f., 1969); foodstuffs, machinery and equipment,
fertilizers, petroleum products
Major trade partners: U.K. 49%, Canada 9%, U.S. 8% (1964)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1, now floating with
pound sterling
299
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GNP: $2.4 billion (at average exchange rate, 1972); $810 per capita; 74% private
consumption, 12% public consumption, 14% gross investment (1969); real growth
rate 1972, none
Agriculture: large areas devoted to extensive livestock grazing (17 million
sheep, 9 million cattle); main crops -- wheat, rice, corn; self-sufficient
in most basic foodstuffs; caloric intake, 3,000 calories per day per capita,
with high protein content
Major industries: meat Processing, wool and hides, textiles, footwear, cement,
petroleum refining «
Crude steel: 24,000 metric tons produced (1966), 10 kilograms per capita
Electric power: 576,000 kw.. capacity (1972); 2.4 billion kw.-hr. produced
(1972), 855 kw.-hr. per capita
Exports: $196.8 million (f.o.b., 1972); beef, wool, hides
Imports: $186.6 million (c.i.f., 1972); fuels, metals, machinery, transportation
equipment
Major trade partners: exports -~ EC 34%, U.K. 14%, U.S. 7%, LAFTA 15%;
imports -- LAFTA 30%, U.S. 14%, U.K. 6%, EC 19% (1969)
Aid:
economic -- extensions from U.S. (FY46-72), loans $123.2 million, grants
$26.0 million; from international organizations (FY46-72), $242.8 million;
from other western countries (1960-71), $14.2 million;
military -- U.S, (FY46-72), $58.7 million
Monetary conversion rate: (buying) 902 pesos=US$1; (selling) 911 pesos=US$1;
financial -- floating (895 pesos=US$1 on October 10, 1973)
Fiscal year: calendar year
The Vatican City, seat of the Holy See, is supported financially by contributions |
{known as Peter''s pence) from Roman Catholics throughout the world; some
income derived from sale of Vatican postage stamps and tourist mementos,
fees for admission to Vatican museums, and sale of publications; industrial
activity consists solely of printing and production of a small amount of
mosaics and staff uniforms
The banking and financial activities of the Vatican are worldwide; the Institute
for Religious Agencies carries out fiscal operations and invests and transfers
funds of Roman Catholic religious communities throughout the world, the
Cardinal''s Commission controls the administration of ordinary assets of the
Holy See and a Special Administration manages the Holy See''s capital assets
Electric power: obtained from Rome city grid; standby diesel powerplant with
2,100 kw. capacity
369
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GNP: $13,08 billion (1972), $1,170 per capita; 64% private consumption, 14% public
consumption, 22% gross investment (1970), real growth rate 1972 est. 4%
Agriculture: main crops -- cotton, sugarcane, corn, coffee, rice; self-sufficient
in rice and chicken, imports wheat (U.S.) and meat (Colombia); caloric intake
2,490 calories per day per capita (1966)
Fishing: catch 138,900 metric tons, $28.7 million (1971); exports $10.1 million
(1970), imports $5.6 million (1970)
Major industries: petroleum, iron-core mining, construction, food processing,
textiles a
Crude steel: 923,000 metric tons produced (1970), 90 kilograms per capita
Electric power: 3.18 million kw. capacity (1971); 13.4 billion kw.-hr. produced
(1971), 1,230 kw.-hr. per capita
Exports: $3,273 million (f.0.b., 1972); petroleum $2,783 million (1971), iron
ore, coffee
Imports: $2,203 million (f.o.b., 1972); industrial machinery and equipment,
chemicals, manufactures, wheat
Major trade partners: imports -- U.S. 44%, West Germany 11%. Japan 9%; exports --
U.S. 41%, Canada 13%, Aruba 12%, Argentina 9%
Aid:
economic -- extensions from U.S. (FY46-72), $388.0 million loans; $66.7
million grants; from international organizations (FY46-72), $627.7 million;
from Communist countries (1954-72), $10 million;
military -- assistance from U.S. (FY46-72), $122.4 million
Monetary conversion rate: 4.30 bolivares=US$1 (selling rate)
Fiscal year: calendar year
Agriculture: mainly subsistence; main crops -- rice, corn, sweet potatoes,
manioc, sugarcane; food shortages -- rice, meat, sugar; caloric intake,
1,700-2,200 calories per day per capita
Major industries: food processing, textiles, machine building, mining, cement
Shortages: petroleum, complex machinery and equipment, fertilizer, foodstuffs
Monetary conversion rate (nominal): 3.0 dong=US$1 (1972)
Fiscal year: calendar year
GNP: $2.3 billion (1972 est.), $120 per capita; no real growth estimated for 1972
Agriculture: main crops -- rice, rubber, fruits and vegetables, copra; major food
imports -- rice, wheat, dairy products, sugar
Fishing: catch 677,000 metric tons (1972); growing trade in fish and fish products y
Major industries: manufacturing on small scale, mainly light manufacturing and
processing of local agricultural and forest products; factories produce
textiles, beer, cigarettes, glass, tires, sugar, paper, cement, soft drinks
Shortages: capital goods
Electric power: 883,000 kw. capacity (1973); 1,900,000 kw.-hr. produced (1973),
95 kw.-hr. per capita
Exports: $23 million (f.o.b., 1972); major commodities -- rubber, fish and fish
products, logs, scrap metal, duckfeathers
Imports: $678 million (c.i.f., 1972); major commodities -~ machinery and trans-
portation equipment, rice, textile fabrics and yarn, petroleum products, base
metals and manufactures
Major trade partners: exports -- France, U.K., West Germany, Japan; imports --
U.S., Japan, Taiwan; no trade with Communist countries
Aid:
economic -- U.S. (including P.L. 480), $414 million (FY69), $477 million
(FY70), $576 million (FY71); $455 million| (FY72); numerous other non-Communist
countries providing assistance;
military -- U.S., $1,608 million (FY69), $1,684 million (FY70), $1,874 million
(FY71), $2,160 million (FY72)
Monetary conversion rate: multiple exchange rate system with flexible rates; as
of 16 October 1973 rates were as follows: 425 piasters=US$1 for U.S.-financed
merchandise imports; 525 piasters=US$1 for other merchandise imports and most
invisible transactions such as personal currency conversions, foreign
investment, and government transfers; 600 piasters=US$1 for most commodity
exports; average black market rate of 499 piasters=US$1 during third quarter
of 1973
Fiscal year: calendar year
4
Agriculture: dominated by coconut production with subsistence crops of yams, taro,
bananas
Trade: exports consist almost entirely of copra; imports are largely foodstuffs
and some equipment associated with development programs
Monetary conversion rate: 70 Colonial Franc Pacifique (CFP)=US$1
377
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 103 WESTERN SAMOA
LAND:
1,100 sq. mi.; comprised of 2 large islands of Savai''i and
Upolu and several smaller islands, including Manono
and Apolima; 65% forested, 24% cultivated, 11% industry, ;
waste, or urban “AUSTRALIA
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 250 mi.
GNP: $38 million (1971), $260 per capita
Agriculture: cocoa, bananas, copra; staple foods include coconut, bananas, taro,
and yams
Exports: $6.3 million (1971); copra, cocoa, bananas
Imports: $12.8 million (1971); machinery and equipment, manufactured goods, food
Major trade partners: exports -- New Zealand, West Germany, the Netherlands;
imports -- New Zealand, Australia, US
Aid: New Zealand, $2.5 million committed; U.S., $2 million extended (FY67-70)
Monetary conversion rate: 1 WS Tala=US$1.65 (August 1973), 0.61 WS Tala=US$1
Major industries: timber, tourism
379
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GNP: $150 million (1972 est.), $100 per capita
Agriculture (a11 outside Aden): cotton is main cash crop; cereals, dates, kat
(qat), coffee, and livestock are raised and there is a growing fishing
industry; large amount of food must be imported (particularly for Aden);
cotton, hides, skins, dried and salted fish are exported
Major industries: petroleum refinery (production 150,000 bbls. per day) mid 1971;
capacity 178,000 bbis. per day at Little Aden operates on imported crude; oil
exploration activity
Exports: $130 million (FY71-72)
Imports: $196 million (FY71-72)
Electric power: 128,000 kw. capacity (1972); 448 million kw.-hr. produced (1972),
290 kw.-hr. per capita
Major trade partners: Yemen, East Africa, but some cement and sugar imported from
Communist countries; crude oi] imported from Persian Gulf, exported mainly to
U.K. and Japan
*Excluding the islands of Perim and Kamaran for which no data are available
38]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Monetary conversion rate: 1 S. Yemeni dinar=US$2.90
Fiscal year: 1 April - 31 March
COMMUNICATIONS: 2
Railroads: none
Highways: 3,360 mi.; 200 mi. bituminous treated, 180 mi. crushed stone and gravel,
2,920 motorable track
Ports: 2 major (Aden and Al Mukalla)
Pipelines: refined products, 20 mi. %
Civil air: 6 major transport aircraft
Airfields: 138 total, 74 usable; 2 with permanent-surface runways; 3 with run-
ways 8,000-11,999 ft., 40 with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: small system of open-wire line, milticonductor cable, and
radioconmunications stations; only center Aden; 9,600 telephones; 250,000
radio and 25,500 TV receivers; 3 TV and 1 AM stations; 4 submarine cables
(2 operational)
DEFENSE FORCES:
Military manpower: males 15-49, 380,000; 205,000 fit for military service
*
Caen oa seme tiuniamasmaanaasnlenpeenlpetpnammaeidiiaannes tudes mensiaens deeeemenremeltieitemiiniielliedeaeetemeeel
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ne
A
pproved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 32A YEMEN (SANA)
TURKEY
LAND : 4 iRAQ IRAN
\\ about 75,000 sq. mi. (parts of border with Saudi Arabia
and Southern Yemen undefined) 5 20% agricultural,
1% forested, 79% desert, waste, or urban
Land boundaries: 950 mi.
Ne SAUDI "Ese
i ARABIA
* WATER:
Limits of territorial waters (claimed): 12 n. mi. (plus
6n. mi. “necessary supervision zone’
Coastline: 325 mi.
Agriculture: sorghum and millet, gat (a mild narcotic), cotton, coffee, fruits .
and vegetables; largely self-sufficient in food
Major industries: cotton textiles and leather goods produced on a small scale;
handicraft and some fishing; small aluminum products factory
Electric power: 4,000 kw. capactiy (1972); 14 million kw.-hr. produced (1972),
2 kw.-hr. per capita
Major trade partners: China, Yemen (Aden) U.S.S.R., Japan, U.K., Australia,','cf0f2370fb869f09c95601844bd74051dbc9f2ecc64abdcfa707e02ff3069cb3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a1b4a593d61a4911e5ae5bd9846cef157eb2ee4dab5e59019e34ce5e65f089e',1974,'DZ','Algeria','economy',21,'GNP: $38.7 billion (1972), $3,970 per capita (1972), 60% consumption,
24% investment, 14% government, 2% net foreign balance; 1972 real GNP
growth rate 4.1% a
Agriculture: livestock production predominates; main crops -- grains, beets,
potatoes; 80% self-sufficient in food; caloric intake, 3,230 calories per
day per capita (1969-70)
Fishing: catch 53,400 metric tons, $20,275,000 (1970); exports $29.0 million (1972)
imports $110.6 million (1972)
Major industries: engineering and metal products, processed food and beverages, i
chemicals, basic metals, textiles, and petroleum
Shortages: iron ore, nonferrous minerals, petroleum
Crude steel: capacity 16.6 million metric tons (1971); 14.5 million metric tons
produced (1972); 1,490 (1972 est.) kilograms per capita
Electric power: 8,290,000 capacity (1972); 35.7 billion kw.~hr. produced (1972),
3,500 kw.-hr. per capita
Exports: $16.1 billion (f.0.b., 1972) motor vehicles, finished or semifinished
precious stones, textile products
Imports: $15.6 billion (c.i.f., 1972), nonelectrical machinery, motor vehicles,
textiles, chemicals
Major trade partners: (Bel gium-Luxembourg Economic Union, 1971) West Germany
25%, France 19%, Netherlands 17%, U.S. 7%, U.K. 5%, Italy 4%; EC-nine 72%,
EFTA, Communist countries 2%
Aid:
economic -- received - U.S., $781.3 million authorized (FY46~72); $13.9 million
in FY72;
military -- received - $1,260.8 million authorized (FY46-72); net official
economic aid to less developed areas and multilateral agencies -- $1,092
million (FY60-70), $231 million in 1972
Monetary conversion rate: 1] franc=US$0.0272 (as of 28 September 1973 floating)
Fiscal year: calendar year 7
GNP: $107 million (1969, in 1963 constant prices), $200 per capita
Agriculture: main crops -- palm oi], root crops, rice, coconuts, peanuts
Electric power: 1,200 kw. capacity (1972); 3 million kw.-hr. produced (1972),
6 kw.-hr. per capita
Exports: $3.6 million (f.o.b., 1969); principally peanuts, coconuts
281
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Imports: $23.3 million (c,i.f., 1969); manufactured goods, fuels, transport
equipment, rice /
Major trade partners: mostly Portugal, also immediate neighbors
Aid: Portugal, small amounts
Monetary conversion rate: 25.5 escudos=US$1, (fixed, February 1973)
Fiscal year: probably is the calendar year','e0f23b7177f9e0d924413bbfb57a1e0923fedb4f1472b790a7c010224f80a3bb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a59c4518fc6495295d0d6fa2c062e55f867ea7c506edad8bfe43bf519eb84147',1974,'PE','Peru','economy',24,'GDP: $72.8 million (1972 est.), $570 per capita; 78% private consumption, 17%
public consumption, 36% domestic investment, -31% net foreign balance
(1968); real growth rate 1971 3.5%
Agriculture: main products -- sugar, citrus fruits, corn, rice, beans, livestock
products; net importer of food; caloric intake, 2,500 calories per day
per capita
Major industries: timber and forest products, food processing, furniture, rum,
soap
Electric power: 6,350 kw. capacity (1972); 19 million kw.-hr. produced
(1972), 150 kw.-hr. per capita
Exports: $19.0 million (f.o.b., 1971 est.); sugar, lumber, citrus fruits, fish
31
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Imports: $35.4 million (c.i.f., 1970); vehicles, petroleum, food, textiles,
machinery
Major trade partners: exports -- U.S. 30%, U.K. 24%, Mexico 22%, Canada 13%;
imports -- U.S. 34%, U.K. 25%, Jamaica 7% (1970)
Aid: economic -- U.S. (FY46— 72), $6.3 million, grants; from international
organizations (1946-72), $1.7 million
Monetary conversion rate: $BHI. 54=US$1 (official)
Fiscal year: calendar year
GNP: $190 million (at market prices, 1970), $3,580 per capita
Agriculture: main products -- bananas, vegetables, Easter lilies, dairy products,
citrus fruits
Major industries: tourism, finance, ship repair, small boat building
Electric power: 66,340 kw. capacity (1971); 226 million kw.-hr. produced (1971),
4,245 kw.-hr. per capita
Exports: $93.0 million (f.0.b., 1971); mostly reexports of drugs and bunker fuel
Imports: $111 million (f.0.b., 1971); fuel, foodstuffs, machinery
Major trade partners: U.S. 45%, U.K. 22%, Canada 9% (1971)
Monetary conversion rate: 1 Bermuda dollar=US$1
Fiscal year: 1 April-31 March
GNP: under $100 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Exports: about $1 million annually; rice, dolomite, and handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic -- India (FY61-72) $180 million
Monetary conversion rate: 7.5 Indian rupees=US$1 (official rate); now floating
with U.K. pound
Fiscal year: 1 April - 31 March
GNP: $1.1 billion (at average exchange rate, 1972) $220 per capita;
78% private consumption, 11% public consumption, 13% gross domestic
investment, -2% net foreign balance (1970); real growth rate 1972, 5.9%
Agriculture: main crops -- potatoes, corn, rice, sugarcane, yucca, bananas; ¥
imports significant quantities of foodstuffs including lard, vegetable oils,
and wheat; caloric intake, 1,800 calories per day per capita (1971)
Major industries: mining, smelting, petroleum refining, food processing, textiles,
and clothing
Electric power: 270,000 kw. capacity (1971); 832 million kw.-hr. produced
(1971), 175 kw.-hr, per capita :
Exports: $271.4 million (f.o.b., 1973 est.); tin, petroleum, lead, zinc, silver,
tungsten, antimony, bismuth, gold, coffee, sugar, cotton
Imports: $261.4 million (f.0.b., 1973 est.); foodstuffs, chemicals, capital goods,
Pharmaceuticals
Major trade partners: exports -- U.K. 46%, U.S. 39%, West Germany 5%, Argentina 2%;
imports -- U.S. 41%, West Germany 12%, Japan 11%, Argentina 6% (1970)
Aid:
economic -- extensions from U.S. (FY46-73) $283.5 million in loans, $304.4
million in grants; from international organizations (FY46-73), $273.6
million; from other Western countries (1960-72), $53.3 million; Communist
countries (1954-71), $55.5 million; military -- assistance from U.S. (FY52-72),
$33.3 million
Monetary conversion rate: 20 pesos=US$1
Fiscal year: calendar year
GDP: $123.5 million (July 1971-June 1972), about $200 per capita
Agriculture: principal crops are corn and sorghum; livestock raised and exported
Major industries: livestock processing, mining of diamonds, copper, nickel, coal,
asbestos, and manganese
Electric power: 8,000 kw. capacity (1972); 16 million kw.-hr. produced (1972),
23 kw.-hr. per capita
Exports: $47 million (FY71/72); cattle, animal products, minerals
Imports: $88 million (FY71/72); foodstuffs, vehicles, textiles
39
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major trade partners: South Africa and U.K.
Monetary conversion rate: 1 SA Rand=US$1.42 (par value; Botswana uses the
South African Rand), 0.70 SA Rand=US$1 ‘
Fiscal year: 1 April - 31 March
GNP: $50 billion (at average official exchange rate, 1972), $510 per capita;
20% gross investment, 83% consumption, -3% net foreign balance (est. 1972);
real growth rate 1972, 10.4%
4]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Agriculture: main products -- coffee, rice, beef, corn, milk, Sugarcane, soybeans;
tak self-sufficient; caloric intake, 2,900 calories per day per capita
1962
Fishing: catch 650,000 metric tons (1971); exports (f.0.b.) $26.7 million, imports
(f.o.b.) $27.5 million (1971)
Major industries: textiles and other consumer goods, cement, lumber, steel,
motor vehicles, other metalworking industries
Crude steel: 7.0 million metric tons capacity (1972 est.); 6.5 million metric
tons produced (1972); 65 kilograms per capita (1972)
Electric power: 13.9 million kw. capacity (1972); 53.3 billion kw.-hr. produced
(1972), 600 kw.-hr. per capita
Exports: $3,987 million (f.0.b., 1972); coffee, manufactures, iron ore, cotton,
soybeans, sugar, wood, cocoa, beef
Imports: $4,225 million (f.0.b., 1972); machinery, chemicals, pharmaceuticals,
petroleum, wheat
Major trade partners: exports -- U.S. 24%, West Germany 8%, Italy 7%,
Netherlands 6%, Japan 5%, U.K. 4%; imports -- U.S. 29%, West Germany 11%,
Japan 7%, U.K. 6%, Italy 4% (1972)
Aid: economic -- extensions from U.S. (FY46-72) -- loans $3,483.4 million,
grants $636.0 million; from international organizations (FY46-72) $2,628.2
million; from other Western countries (1960-71) -- $617.0 million; from
Communist countries (1954-71) $330.6 million; drawings (February 1973)
$189 million
Monetary conversion rate: 6.16 cruzeiros=US$1 (September 1973, changes frequently)
Fiscal year: calendar year
GDP: $31 million (1970) $195 per capita
Agriculture: largely dominated by coconut production with subsistence crops
of yams, taro, bananas; self-sufficient in rice
Electric power: 12 million kw.-hr. produced (1973), 72 kw.-hr. per capita
Exports: $10 million (1971); copra, timber, cocoa
Imports: $15 million (1971)
Major trade partners: exports -- Japan, Australia; imports -- Australia, U.K.
Monetary conversion rate: 0.67 Australian dollar=US$1
GNP: $177 million (1971 est.), $1,430 per capita, average annual growth rate
(1969-71) 6%
Agriculture: main crops -- rubber, rice, pepper, must import most food
Major industry: crude petroleum
Exports: $115 million (f.o.b. 1971); 96% crude petroleum
Imports: $163 million (c.i.f. 1971); 47% machinery and transport equipment,
30% manufactured goods, 8% food
Major trade partners: exports of crude petroleum go to Sarawak for refining
and reexport; imports from Japan 30%, U.S. 24%, U.K. 15%, Singapore 9%
Monetary conversion rate: 2.54 Brunei dollars=US$1
Fiscal year: calendar year
45
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GNP: $13.9 billion, 1972 (at 1971 prices), $1,620 per capita; 1972 growth rate
6.3%
Agriculture: mainly self-sufficient; main crops--grain, vegetables; no food
shortages; caloric intake, 3,000 calories per day per capita (1969/70)
Fishing: catch 97,000 metric tons (1971)
Major industries: agricultural processing, machinery, textiles and clothing,
mining, ore processing, timber
Shortages: some raw materials, metal products
47
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Crude steel: 2.2 million metric tons produced (1972), 260 kg. per capita
Exports: $2,603 million (f.o.b., 1972); in 1971, 35% machinery, equipment, and
transportation equipment; 12% fuels, minerals, raw materials, metals, and
other industrial material; 4% agricultural raw materials; 37% foodstuffs i
and animals; 12% industrial consumer goods
Imports: $2,543 million (f.o.b., 1972); in 1971, 46% machinery, equipment, and
transportation equipment; 35% fuels, minerals, raw materials, metals, other
materials; 9% agricultural raw materials; 3% foodstuffs and animals; 6%
industrial consumer goods
Major trade partners: $5,146 million in 1972; 19% with non-Communist countries;
81% with Communist countries
Monetary conversion rate: (commercial) 0.98 leva, (noncommercial) 1.65 leva=US$1;
old commercial rates: 1.09 leva=US$1 in 1972; 1.17 leva=US$1 prior to 1972
Fiscal year: calendar year; economic data reported for calendar years except for
caloric intake, which is reported for consumption year 1 July - 30 June
Note: foreign trade figures were converted at the 1972 rate
GDP: $2 billion (FY72), $70 per capita; real growth rate 3% (FY72)
Agriculture: main crops -- paddy, sugarcane, peanuts; almost 100% self-sufficient;
most rice grown in deltaic land
Fishing: catch 443,000 metric tons, $80 million (1971)
Major industries: agricultural processing; textiles and footwear, wood and
wood products; petroleum refinin
Exports: $116 million (f.o.b., 1972); rice, teak
49
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Imports: $128 million (c.i.f., 1972) machinery and transportation equipment,
textiles, other manufactured goods
Major trade partners: exports -- India, Western Europe, U.K., Japan; imports --
Japan, Western Europe, India, U.K.
Monetary conversion rate: 4.86 kyat=US$1 (official)
Fiscal year: 1 October - 30 September
GNP: about $204.7 million (1971 est.), $60 per capita; estimated real GDP
growth 1%
Agriculture: major cash crops -- coffee, cotton; main food crops -- manioc,
yams, corn, sorghums, bananas, haricot beans; not self-sufficient
Industries: light consumer goods such as beverages, shoes, soap
Electric power: 13,100 kw. capacity (1972); 26 million kw.-hr. produced (1972),
7 kw.-hr. per capita
Exports: $20.7 million (f.o.b., 1971); coffee, cotton, hides, skins
Imports: $25.9 million (c.i.f., 1971); textiles, foodstuffs, transport equipment,
petroleum products
Major trade partners: U.S., Belgium, Congo; much trade unrecorded
Aid: $17.7 million (1970) includes Belgium $7.4 million, U.N. $3.1 million, EDF
$2.9 million; France $2.0 million (1970); U.S. $9.7 million FY61-72
Budget: FY72 -- revenue $25.4 million, expenditure $26.8 million (est.)
Monetary conversion rate: 87.5 Burundi francs=US$1 (official)
Fiscal year: calendar year
5]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GNP: $950 million (1971), $140 per capita (1971 prices; no growth rate available)
Agriculture: Mainly subsistence except for rubber plantations; main crops --
rice, rubber, corn; largely self-sufficient prior to the war; food shortages
-- rice, dairy products, sugar, flour
Major industries: rice milling, fishing, wood and wood products, textiles
Shortages: fossil fuels
Exports: $6.9 million (f.0.b., 1972); rubber, corn, kapok
Imports: $71.1 million (f.o.b., 1972); machinery and equipment, chemical products,
metals and metal products, petroleum products, foods, transport equipment
53
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major trade partners: (1971) exports -- South Vietnam, Hong Kong, Singapore;
2% with Conmunist countries; imports -- U.S., Japan, France; negligible with
Communist countries
Monetary conversion rate: adjustable; about 275 riels=US$1 (October 1973) 7
Fiscal year: calendar year
GDP: $1,196 million (1971 est.), per capita about $190; real growth rate about 7%
per annum
Agriculture: commercial and food crops -- cocoa, coffee, timber, cotton, rubber,
bananas, peanuts, palm oi] and palm kernels; root starches, livestock, millet,
sorghum, and rice
Fishing: imports 6,137 metric tons, $2.5 million (1972); exports 1,718 metric
tons (largely shrimp), $2.7 million
Major industries: small aluminum plant, food processing and light consumer goods
industries, sawmills
55
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Electric power: 262,400 kw. capacity (1972); 1.1 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $218 million (f.0.b., 1972) cocoa and coffee about 55%; other exports
include timber, aluminum, cotton, natural rubber, bananas, peanuts, tobacco,
and tea
Imports: $299 million (c.i.f., 1972) consumer goods, machinery, transport equipment,
alumina for refining, petroleum products, food and beverages; about 2.2% from
Communist countries ;
Major trade partners: about 70% of total trade with France and other EC countries; ;
about 12% of total trade with U.S.
Budget: FY74 budget balanced at $350 million
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
as of February 1973, floating since February 1973
Fiscal year: 1 July - 30 June
GDP: $281 million (1972 est.), about $170 per capita
Agriculture: commercial -- cotton, coffee, peanuts, sesame, wood; main food
crops -- manioc, corn, peanuts, rice, potatoes, beef; requires wheat, flour,
rice, beef, and sugar imports
Major industries: sawmills, cotton textile mills, brewery, diamond mining and
splitting
Electric power: 16,850 kw. capacity (1972); 50 million kw.-hr. produced (1972),
30 kw.-hr. per capita
Exports: $45 million (f.o.b., 1971); diamonds (43%), coffee, cotton, lumber
Imports: $46 million (c.i.f., 1971); textiles, petroleum products, machinery
and electrical equipment, motor vehicles and equipment, chemicals and
pharmaceuticals
59
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Aid: economic -- U.S. (FY61-72) $7.9 million; (1972 est. disbursements) EC $6.4
million, IDA $3.9 million, U.S. $2.3 million, U.N. $1.2 million
Major trade partner: France; preferential tariff applied to EC countries and i
franc zone; U.S.
Budget: 1971 ordinary budget -- receipt $45.2 million, expenditure $45.1 million
Monetary conversion rate: 255.785 Conmunaute Financiere Africaine francs=US$1
as of February 1973, floating since February 1973 (official)
Fiscal year: calendar year
GDP: about $241 million (1967), about $70 per capita; estimated real annual growth
rate 2.5% (1963-68)
Agriculture: commercial -- cotton, gum arabic, livestock, fish; food crops --
peanuts, millet, sorghum, rice, dates, manioc, wheat; imports food
Fishing: catch 120,000 metric tons (1971) $14 million; exports $300,000 (1969)
Major industries: agricultural and livestock processing plants (cotton textile
mill, slaughterhouses, brewery), natron
61
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Electric power: 22,000 kw. capacity (1972); 54 million kw.-hr. produced (1972) ,
14 kw.-hr. per capita
Exports: $28.0 million (f.o.b., 1971); cotton 67.5%
Imports: $62.0 million (c.i.f., 1971); cement, petroleum, foodstuffs, machinery,
textiles, and motor vehicles; $1.3 million from Communist countries (1967)
Major trade partners: France (about 40% in 1969) and UDEAC countries; preferential
tariffs to EC and franc zone countries
Aid: major source France, $469 million, 1961-69; EDF $393 million (1965-70);
U.S. (FY62-72) $10.9 million; U.S.S.R. $2.2 million (1968); military aid ?
(1954-68) -- $5.4 million, from France $4.1 million, remainder from West ;
Germany and Israel, more than $10 million annually (est.) in French military
aid (1969-71)
Budget: 1972 ordinary budget (est.) -- $57 million
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
as of February 1973, floating since February 1973 (official)
Fiscal year: calendar year','9f37ed64029cd6f1bc4aea07704216d785b555755585b636f617adb0417c1d19','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c2d8eae4346d44d88de0c402bb90c9362667eae1096620dd21aabf75873fc87',1974,'LY','Libya','economy',28,'GNP: $36.8 billion in 1972 (at 1971 prices), $2,540 per capita; 1972 real growth
rate 3.6%
Agriculture: diversified agriculture; main crops -- wheat, rye, potatoes, sugar
beets; net food importer -- meat, wheat, vegetable oils, fresh fruits and
vegetables; caloric intake, 3,100 calories per day per capita (1967)
Major industries: machinery, food processing, metallurgy, textiles, chemicals
Shortages: ores, crude oil, grain
83
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Crude steel: 12.7 million metric tons produced (1972), 880 kg. per capita
Exports: $5,123 million (f.o.b., 1972); 50% machinery, equipment; 28% fuels,
raw materials; 4% foods, food products, and live animals; 18% consumer goods, ¥
excluding foods (1971)
Imports: $4,662 million (f.o.b., 1972); 33% machinery, equipment; 44% fuels. raw
materials; 15% foods, food products, and live animals; 8% consumer goods,
excluding foods (1971)
Major trade partners: $9,785 million (1972); 70% Communist countries, 30% with West
Monetary conversion rate: commercial 5.2 crowns=US$1, noncommercial 10.7 j
crowns=US$1, tourist rate 13.3 crowns=US$1; old commercial rates: 6.63
crowns=US$1 in 1972; prior to 1972, 7.2 crowns=US$1
Fiscal year: calendar year
Note: foreign trade figures were converted at the 1972 rate
sa $230 ae (1971 est.) $80 per capita; real growth rate, 6.5% per annum
1967-71
Agriculture: major cash crop is oil palms; peanuts, cotton, coffee, sheanuts,
tobacco also produced commercially; main food crops -- corn, cassava, yams,
sorghum and millet; livestock, fish
Fishing: catch 32,900 metric tons (1971); exports 122.2 metric tons, imports
4,000 metric tons
Major industries: palm oil and palm kernel oi] processing
Electric power: 11,810 kw. capacity (1972); 50 million kw.-hr. produced (1972),
18 kw.-hr. per capita
Exports: about $55 million (f.o.b., 1971); palm products (34%); other
agricultural products
Imports: $100 million (c.i.f., 1971); clothing and other consumer goods,
cement, lumber, fuels, foodstuffs, machinery, and transport equipment
85
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major trade partners: France, EC, franc zone; preferential tariffs to EC and
franc zone countries
Aid:
economic (1970) -- France, $8 million; EC, $4.2 million; U.N., $2 million;
West Germany, $1 million; Taiwan, $1 million; U.S., (FY60-72) $13.7 million
Budget: 1972 est. -- receipts $50.2 million, current expenditures $42.3,
investment expenditures $9.4 million
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
francs; 255.785 CFA francs=US$1 as of February 1973 (currency floating *
since February 1973)
Fiscal year: calendar year
GNP: $22.4 billion (1972), $4,510 per capita; 61% private consumption, 21%
investment, 20% government, -2% net foreign balance (1971); 1972 growth 4%,
constant prices
Agriculture: highly intensive, specializes in dairying and animal husbandry;
main crops -- cereals, root crops; food shortages -- oilseeds, grain,
feedstuffs; caloric intake, 3,180 calories per day per capita (1968-69)
Fishing: catch 1,400,900 metric tons (1971), $141 million; exports $159 million,
imports $37.2 million
Major industries: food processing, machinery and equipment, textiles and clothing, ‘
chemical products, electronics, transport equipment, metal products, brick
and mortar, furniture and other wood products
Shortages: most industrial raw materials and fuels
Crude steel: 470,000 metric tons produced (1971), 90 kg. per capita
Electric power: 5,118,000 kw. capacity (1972); 19.4 billion kw.-hr. produced
(1972), 3,060 kw.-hr. per capita
Exports: $4,416 million (f.o.b., 1972); principal items -- meat, dairy products,
industrial machinery and equipment, textiles and clothing, chemical products,
transport equipment, fish, furs, and furniture
Imports: $5,069 million (c.i.f., 1972); principal items -- industrial machinery,
transport equipment, petroleum, textile fibers and yarns, iron and steel
products, chemicals, grain and feedstuffs, wood and paper
Major trade partners: U.K. 16%, West Germany 16%, Sweden 16%, U.S. 8%, Norway 6%;
EC 28%; EFTA 46%; Communist countries 4% (1971)
Aid:
economic -- U.S., $324.2 million authorized FY46-72 IBRD, $85.0 million
through 1972, none since 1964; net official economic aid given to less
developed areas and multilateral agencies, $250.5 million (1960-70), $58.3
million (1969), $63.2 million (1970) $80 million (1971 provisional)
Military: U.S., $117.3 million (FY49-72)
Monetary conversion rate: 1 Kroner=US$0.1755 (September 28, 1973, floating)
Fiscal year: 1 April - 31 March *
GNP: $23.0 billion (1972 est. at 197] prices), $1,110 per capita; 1972 real growth
rate approx. 3.7%
Agriculture: diversified agriculture with many small private holdings and large 7
agricultural combines; main crops -- corn, wheat, tobacco, sugar beets, and
sunflowers; generally a net exporter of foodstuffs and live animals; self-
sufficient in food except for tropical products, cotton, wool, and vegetable
meal feeds; caloric intake, 3,210 calories per day per capita (1967)
Major industries: metalluray, machinery and equipment, textiles, wood
processing, food processing
Shortages: fuels, steel, textile fibers, chemicals
Crude steel: 2.6 million metric tons produced (1972), 32.8 kg. per capita
Electric power: 8,114,000 kw. capacity (1972); 33.1 billion kw.-hr. produced
(1972), 1,590 kw.-hr. per capita
Exports: $2,135 million (f.o.b., 1972); 18% foodstuffs and tobacco; 15% raw
materials, fuels, and chemicals; 32% machinery and equipment; 43% other
manufactures
Imports: $3,081 million (c.i.f., 1972); 10% foodstuffs and tobacco; 27.8% raw
materials, fuels, chemicals; 31% machinery and equipment; 31% other
manufactures
Major trade partners: $5,216 million (1972); 70% non-Communist countries (35%
EC, 6% U.S., 30% other non-Communist countries), 30% Communist countries
Aid: postwar credits extended mainly by the U.S. (about $3 billion, including grants
and $700 million in military aid); Western Europe (over $950 million); IBRD
($585 million); IMF (over $400 million); Communist countries extended credits
totaling $464 million in 1956 ($125 million drawing balance suspended in 1958)
and $576 million during 1962-70 and $540 million in 1972; Yugoslavia has y
extended credits totaling about $600 million to 27 less developed countries
of Africa, Asia, and Latin America
Monetary conversion rate: 17.0 new dinars=US$1
Fiscal year: same as calendar year (all data refer to calendar year or to middle %
or end of calendar year as indicated)
GDP: $2.3 billion (1972 provisional est.), $100 per capita; real growth rate
6.3% p.a. 1968-72
Agriculture: main cash crops -- coffee, palm oil, rubber; main food crops --
manioc, bananas, root crops, corn; some provinces self-sufficient
Fishing: catch 146,000 metric tons (1971); imports $18 million (1972 est.)
Major industries: mining, mineral processing, light industries
Electric power: 861,380 kw. capacity (1972); 3.5 billion kw.-hr. produced
(1972), 126 kw.-hr. per capita
Exports: $690 million (f.o.b., 1972); copper, cobalt, diamonds, other minerals,
coffee, palm oil
387
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Imports: $694 million (c.i.f., 1972); consumer goods, foodstut''fs, mining and
other machinery, transport equipment, fuels
Major trade partners: Belgium, U.S., and West Germany
Aid: economic -- U.S. (FY61-71) $460 million; (1971 estimated disbursements)
Belgium, $31.4 million; France, $6.6 million; other bilateral aid $5.4 million;
U.N., $9.4 million; EC, $18.9 million;
military -- U.S., $43.2 million (FY62-72)
Budget: 1972 -- revenue $598 million, current expenditure $547 million, investment
expenditure $143 million
Monetary conversion rate: 1 zaire=US$2
Fiscal year: calendar year
GNP: $1.8 billion (1972 est.), $410 per capita; real growth rate 11% between 1965
and 1970
} Agriculture: main crops -- corn, tobacco, cotton; net importer of all major
agricultural products
Fishing: catch 48,400 metric tons, $4.2 million (1970); imports $5.3 million (1970)
Major industries: copper mining and processing
Electric power: 788,200 kw. capacity (1972); 2,128 billion kw.-hr. produced (1972),
: 484 kw.-hr. per capita
* Exports: $758 million (f.0.b. 1972); copper, zinc, cobalt, lead, tobacco
389
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Imports: $718 million (c.i.f., 1972); consumer goods, machinery, transport
equipment, foodstuffs, fuels
Major trade partners: U.K., South Africa, Japan, Western Europe
Aid:
economic -- China $200 million credit for Tanzam railroad (1970); (1964-67)
U.K. $63 million; IBRD $99 million (1965-70); U.S. $68 million (FY53-72) ;
U.S.S.R. $6 million; Eastern Europe $50 million;
military -- $9 million (1964-69), mainly U.K. and Canada
Budget: 1972 est. -- revenue $410.5 million, current expenditure $435.4 million,
investment expenditure $192.1 million
Monetary conversion rate: 1 Zambia kwacha=US$1.555 (official), 0.643 Zambia
kwacha=US$1
Fiscal year: calendar year','c2580bbe8ef0d61af7d82b8d9c6973fa0ab92f3eb79660cbb88a337c843f08e0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92f21f594a622cc5547708e55e117e481c256c0dcf1a02114f33b6b73ea97c26',1974,'CO','Colombia','economy',35,'GDP: $2.1 billion (1972), $380 per capita; 79% private consumption, 8% government
consumption, 14% domestic investment, -1% net foreign balance; real growth
rate 1972, 6.1%
Agriculture: main products -- coffee, cotton, corn, beans, sugarcane, bananas,
livestock; caloric intake, 2,200 calories per day per capita (1967)
Fishing: catch 5,000 metric tons (1970); exports $1.6 million (1970), imports
$0.5 million (1970)
143
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major industries: food processing, textiles and clothing, furniture, chemicals,
nonmetallic minerals, metals
Electric power: 212,000 kw. capacity (1972); 830 million kw.-hr. produced
(1972), 150 kw.-hr. per capita ™
Exports: $338 million (f.o.b., 1972); coffee, cotton, meat, bananas, sugar,
textiles, tires
Imports: $337 million (c.i.f., 1972); manufactured products, machinery, trans-
portation equipment, chemicals, fuels
Major trade partners: exports (1972) -- U.S. 30%, CACM 30%, West Germany 10%, *
Japan 7%; imports (1972) -- U.S. 32%, CACM 21%, West Germany 9%, Japan 9%
Aid:
economic -- from U.S. (FY46-72), $191.1 million loans, $185.4 million grants;
from international organizations (FY46-72) | $146.8 million; from other
western countries (1960-71) $12.3 million; |military -- assistance from
U.S. (FY53-72), $24.9 million
Central government budget (1973): total appropriations $291.8 million
Monetary conversion rate: 1 quetzal=US$1 (official)
Fiscal year: calendar year
GDP: about $275 million (1965), $80 per capita
Agriculture: cash crops -- coffee, bananas, palm products, peanuts, and pine-
apples; staple food crops -- cassava, rice, millet, corn, sweet potatoes;
livestock raised in some areas
Major industries: alumina, light manufacturing and processing industries,
bauxite
Electric power: 99,700 kw. capacity (1972); 310 million kw.-hr. produced (1972),
77 kw.-hr. per capita
Exports: export receipts, $51 million (FY71); alumina, bauxite, coffee,
pineapples, bananas, palm kernels
Imports: $80 million (FY71); petroleum products, metals, machinery and
transport equipment, foodstuffs, textiles
145
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major trade partners: Communist countries, Western Europe (including France),
U.S
Budget: FY72 ordinary budget (est.) -- $113 million
Monetary conversion rate: 22.7 syli=US$1 (October 1972)
Fiscal year: 1 October ~ 30 September
|
av aes million (1972 provisional), $360 per capita; real growth rate 1972 est.
Agriculture: main crops -- sugarcane, rice, other food crops; food shortages --
wheat flour, potatoes, processed meat, dairy products; caloric intake, 2,180
calories per day per capita (1967)
Fishing: catch 18,140 metric tons (1971), $10 million (1972); exports $4.1
million (1971), imports $1.2 million (1971)
Major industries: bauxite mining, alumina production, sugar and rice milling
147
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Electric power: 112,000 kw. capacity (1972); 340 million kw.-hr. produced
(1972), 460 kw.-hr. per capita
Exports: $140 million (f.o.b., 1972 provisional); bauxite, sugar, alumina, rice
shrimp, molasses, timber, diamonds, rum.
Imports: $141 million (c.i.f., 1972 provisional); manufactures, machinery, food,
petroleum
Major trade partners: exports -- U.S. 26.5%, U.K. 24.9%, CARIFTA 17.2%, Canada
10.8%; imports -- U.S. 24.4%, U.K. 31.1%, CARIFTA 15.1%, Canada 5.5% (1971)
Aid: economic -- from U.S. (FY53-72), $56.3 million loans, $24.7 million grants;
from U.K. (CY60-70), $73.9 millions from PRC (1972), $26.0 million extended;
from international organizations (FY46-72), $32.7 million
Monetary conversion rate: Floating with pound, 1 pound=G$5.21
Fiscal year: calendar year
GDP: $487 million (1972), $100 per capita; real growth rate 1972 5.1%
Agriculture: main crops -- coffee, sugarcane, rice, corn, sorghum, pulses;
caloric intake, 1,850 calories per day per capita
Major industries: sugar refining, textiles, flour milling, cement manufacturing,
bauxite mining, tourism, light assembly industries
Electric power: 62,000 kw. capacity (1971 est.); 120 million kw.-hr produced
(1971 est.), 24 kw.-hr. per capita
Exports: $43 million (f.0.b., FY72); coffee, light industrial products, bauxite,
sugar, essential oils, sisal
149
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Imports: $70 million (f.o.b., FY72); consumer durables, foodstuffs,
industrial equipment, petroleum products, construction materials
Major trade partners: U.S. 52% (FY71) ry
Aid:
economic -- from U.S., $34.5 million loans, $93 million grants (FY46-72);
international organizations, $31.2 million (FY46-72); from other Western
countries (1960-71) $2.4 million;
military -- U.S., $4.2 million (FY53-72)
Monetary conversion rate: 5 gourdes=US$1 *
Fiscal year: 1 October - 30 September
GNP: $785 million (1972 prel.), $280 per capita; 74% private consumption, 12%
government consumption, 15% domestic investment ; -1% net foreign balance
(1972); real growth rate 1972, 4.3%
Agriculture: main crops -- bananas, coffee, corn, beans, cotton, sugarcane,
tobacco; caloric intake, 2,300 calories per day per capita (1964-65)
Fishing: exports $1.7 million (1972); imports $0.5 million (1970)
Major industries: agricultural processing, textiles, clothing, wood products
Electric power: 155,500 kw. capacity (1972) ;| 350 million kw.-hr. produced
(1972), 130 kw.-hr. per capita |
Exports: $191.4 million (f.o.b., 1972 prel.)|; bananas, coffee, corn, cotton,
lumber, minerals, beef
Imports: $196.4 million (c.i.f., 1972 prel.)|; manufactured products, machinery,
transportation equipment, chemicals, fuels
Major trade partners: exports -- U.S. 55%, West Germany 13%, CACM 3%; imports
-- U.S, 43%, CACM 11%, West Germany 5%, Japan 8% (1972)
Aid:
economic -- extensions from U.S. (FY46-72), $65.0 million loans, $65.2
million grants; from international organizations (FY46-72), $175.1 million;
from ather Western countries (1960-71), $7.0 million;
military -- assistance from U.S. (FY46-71), $9.7 million
Monetary conversion rate: 2 lempiras=US$1 (official)
Fiscal year: calendar year
GNP: $4.1 billion 1972 (est.), $1,000 per capita (est.)
Agriculture: agriculture occupies a minor position in the economy; main crops --
rice, vegetables, dairy products; less than 20% self-sufficient; food
shortages -- rice, wheat
Major industries: textiles and clothing, tourism, plastics, electronics, light
metal products, food processing
Shortages: industrial raw materials, water, food
153
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
|
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $3.5 billion (f.o.b., 1972), including $735 million reexports; principal
Products clothing, plastic articles, textiles, electrical goods, wigs,
Footwear, light metal manufactures 4
Imports: $3.9 billion (e.4sf.5 1972)
Major trade partners: 1972 exports -- U.S. 40%, U.K. 14%, West Germany 10%; imports
~- Japan 23%, China 18%, U.S. 12%
Monetary conversion rate: HK$5.085=US$1
Fiscal year: 1 April - 31 March
GNP: $17.7 billion in 1972 (at 1971 prices), $1,700 per capita; 1972 growth
rate 2.9%
Agriculture: normally self-sufficient; main crops -- corn, wheat, potatoes,
sugar beets, wine grapes; caloric intake 3,140 calories per day
per capita (1970)
Major industries: mining, metallurgy, engineering industries, processed foods,
textiles, chemicals Tespecialiy pharmaceuticals)
Shortages: metallic ores (except bauxite), copper, high grade coal, forest
products
Crude steel: 3.27 million metric tons produced (1972), 310 kg. per capita
155
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $3,292 million (f.0.b., 1972); 27% machinery, 22% industrial consumer
goods, 27% raw materials and semimanufactures, 23% food and raw materials
for the food industry, energy sources 1% (distribution for 1972)
Imports: $3,154 million (1972); 24% machinery, 9% industrial consumer goods,
50% raw materials and semimanufactures, 10% food and raw materials for the
food industry, energy sorces 8% (distribution for 1972)
Major trade partners: $6,446 million (1972); 68% with Communist countries, 32%
with non-Communist countries
Monetary conversion rate: 9.15 forints=US$1 (commercial)
forints=US$1 (noncommercial); old commercial rates: 1
1972; 11.74 forints=US$1 prior to 1972
Fiscal year: same as calendar year; economic data reported for calendar years
NOTE: Foreign trade figures were converted at the 1972 rate
; 23.4
0.81 forints=US$1 in
aia a million (at market prices, 1971), $930 per capita; real growth rate
1971) 8.5%
Agriculture: bananas, sugarcane, and pineapples
Major industries: agricultural processing, particularly sugar milling and rum
distillation; cement, oil refining and tourism
Electric power: 31,900 kw. capacity 11972) ; 128 million kw.-hrs. produced (1972),
400 kw.-hrs. per capita
223
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $42 million (f.o.b., 1972), bananas, sugar, rum, pineapples
Imports: $173 million (c.i.f., 1972), foodstuffs, clothing and other consumer
goods, raw materials and supplies, and petroleum
Major trading partners: exports -- France 82%, Italy 9%, other 9%; imports -- *
See say United States 6%, Netherlands Antilles 3%, Netherlands 3%, other
18% (1968
Monetary conversion rate: 5.2632 francs=US$1 (1972)
Fiscal year: calendar year
GDP: about $190 million (1970), about $160 per capita
Agriculture: most Mauritanians are nomads or subsistence farmers; main crops
-- livestock, small grains, dates; cash crops -- livestock, gum arabic
Fishing: catch, traditional river fishing, 15,000 metric tons (1969), traditional
sea fishing, 2,750 metric tons (valued at $437,000); fish supplied to processing
plants by foreign fishing fleets from France, Spain, Canary Islands using
Mauritanian waters; exports 22,100 metric tons, $8 million (1970)
Major industries: mining of iron ore, salt fishing, exploitation of copper
resources planned
Electric power: 38,000 kw. capacity (1972); 78 million kw.-hr. produced (1972),
64 kw.-hr. per capita
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $99 million (f.o.b., 1972); iron ore, fish, gum arabic
Imports: $89 million (c.i.f., 1972); sugar, cloth, tea, and fuels
Major trade partners: (trade figures not complete because Mauritania has a form
of customs union with Senegal and much local trade unreported) France and >
other EC members, U.K., and U.S. are maid overseas partners :
Budget: 1971 est. -- receipts $33.4 million, current expenditures $33.4 million,
investment expenditures $3.5 million
Monetary conversion rate: 255.785 CFA francs=US$1 as of February 1973
(currency floating since February 1973) (official); since June 1973, 46.04
ouguiya=US$1 ¥
Fiscal year: calendar year
GNP: $222 million (1972 est.), $260 per capita
Agriculture: sugar crop is major economic asset; about 40% of land area is planted
to sugar; tea production rising slowly; most food imported -- rice is the
staple food -- and since cultivation is already intense and expansion of ~
cultivable areas is unlikely, heavy reliance on food imports except sugar
and tea will continue
Shortage: land
Industries: mainly confined to processing sugarcane, tea; some small-scale,
simple manufactures; tobacco fiber; some fishing; tourism, diamond cutting,
weaving and textiles, electronics
Electric power: 61,340 kw. capacity (1972); 174 million kw.-hr. produced (1972),
200 kw.-hr. per capita
Exports: $106 million (f.o.b., 1972); mainly sugar, tea, molasses
Imports: $120 million (1972); foodstuffs 30%, manufactured goods about 25%
Major trade partners: all EC-nine countries and U.S. have preferential treatment,
U.K. buys over 50% of Mauritius'' sugar export at heavily subsidized prices;
small amount of sugar exported to Canada, U.S., and Italy; imports from U.K.
and EC primarily, also from South Africa, Australia, and Burma; some minor
trade with China
Monetary conversion rate: 5.37 Mauritian rupees=US$1 (floating with pound
sterling as of 12 February 1973)
Fiscal year: 1 July - 30 June
GNP: 55% tourism; 25%-30% industry (small and primarily tourist oriented); 10%-15%
registration fees and sales of postage stamps; about 4% traceable to the Monte
Carlo casino
a ae a chemicals, food processing, precision instruments, glassmaking,
printing
Electric power: 8,000 kw. capacity (1972); 70 million kw.-hr. supplied by France
(1972), 3,000 kw.-hr. per capita
Trade: full customs integration with France, which collects and rebates Monacan
trade duties
Monetary conversion rate: 1 franc=US$0.2362 (as of September 28, 1973, floating)
Agriculture: self-sufficient in animal products; main crops -- wheat, oats,
barley
Industries: processing of animal products and building materials; mining
Exports: animal and dairy products, fluorspar, woolen textiles, leather shoes,
glass, and paper
Imports: machinery and equipment, petroleum, cloth, coal, and building materials,
sugar, and tea
Major trade partners: nearly all trade with Communist countries (approx. 80%
with U.S.S.R.); total turnover about $330 million (1971)
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 3.31 tugriks=US$1 (arbitrarily established)
Fiscal year: calendar year
233
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GNP: $4.4 billion (1972 est.), about $280 per capita; average annual real growth
4.4% during 1960-72
Agriculture: cereal farming and livestock raising predominate; main crops --
wheat, barley, citrus fruit, wine, vegetables, olives; some fishing 4
Fishing: catch 229,000 metric tons, $18.7 milion (1971); exports $37.9
million (1971)
Major sectors: mining and mineral processing (phosphates, smaller quantities
of iron, manganese, lead, zinc, and other minerals), food processing, textiles,
construction and tourism
Electric power: 858,000 kw. capacity (1972); 2.3 billion kw.-hr. produced (1972),
140 kw.-hr. per capita
Exports: $633 million (f.o.b., 1972); agricultural goods 54%, phosphates 23%,
other 23%
Imports: $766 million (c.i.f., 1972); food 24%, raw material and semi-finished
goods 38%, equipment 22%, consumer goods 16%
Major trade partners: exports -- France 36%,) West Germany 9%, Italy 5%, U.K. 5%,
U.S. 2%; imports -- France 31%, U.S. 14%, West Germany 8%, Italy 6% (1971)
Monetary conversion rate: 4.2 dirhams=US$1 (selling rate mid-1973)
Fiscal year: calendar year
GNP: $250 million (1967), $1,170 per capita; real growth rate 1967, 3.6%
Agriculture: little production
Major industries: petroleum refining on Curacao and Aruba; tourism on Curacao,
Aruba, and St. Martin; phosphate mining on Curacao ~
Electric power: 295,000 kw. capacity (1973) 1.4 billion kw.-hr. produced (1972),
5,550 kw.-hr. per capita
Exports: $654 million (f.0.b., 1970 est.); petroleum products, phosphate
Imports: $767 million (c.i.f., 1970 est.); crude petroleum, food manufactures
Major trade partners: exports -- U.S. 43%, EC 16%, Latin America 13%, U.K. 10%,
Canada 7%; imports -- Venezuela 72%, U.S. 10%, Netherlands 4% (1968) iad
Monetary conversion rate: 1.79 Netherlands Antillean florins (NAF)=US$1 (official)
Fiscal year: calendar year
GNP: $193 million, $1,800 per capita (1971 est.)
Agriculture: large areas devoted to cattle grazing; major products -- coffee and
vegetables; 60% self sufficient in beef; must import grains and vegetables
Industry: mining of nickel
Exports: $212 million (f.o.b., 1971) 98% nickel
Imports: $248 million (c.i.f., 1971) machinery, transport equipment, food
247
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
|
|
ECONOMY (cont''d):
Major trade partners: (1971) exports -- Fra
imports -~ France (48%), Australia (14%)
Monetary conversion rate: 95 CFP francs=US$
Agriculture: export crops of copra, cocoa, coffee, some livestock and fish
production; subsistence crops of copra, taro, yams
Exports: $16 million (1971); copra, frozen fish
Imports: $23 million (1971)
Monetary conversion rate: | pound=US$2.50 (official currency), 0.67 Australian
$=US$1, 70 Colonial Franc Pacifique (CFP)=US$1
GDP: $1,002 million (current prices, 1972), $510 percapita; 73%
private consumption, 10% government consumption, 19% domestic investment, -2%
net foreign balance (1970); real growth fate 1972, 5.1%
Agriculture: main crops -- cotton, coffee, sugarcane, rice, corn, beans, cattle;
caloric intake, 2,300 calories per day per capita (1966)
Fishing: catch 9,800 metric tons (1970); $9.6 million (1970); exports $6.1
million (1971)
Major industries: food processing, chemicals, metal products, textiles and clothing
Electric power: 175,000 kw. capacity (1972 est.); 660 million kw.-hr. produced
(1972 est.), 340 kw.-hr. per capita
Exports: $240 million (f.0.b., 1972 est.); cotton, meat, coffee, Sugar, chemical
products
Imports: $218 million (c.i.f., 1972 est.); food and non-food agricultural products,
chemicals and pharmaceticals, transportation equipment, machinery, construction
materials, clothing, fuel
Major trade partners: exports -- U.S. 30%, Japan 21%, CACM 22%, West Germany 7%;
imports -- U.S. 31%, CACM 28%, Japan 8%, West Germany 8% (1972)
Aid:
economic -- extensions from U.S. (U.S. FY46-72) $117.0 million loans, $69.2
million grants; international organizations (U.S. FY46-72) $172.9 million;
military -- from U.S. (U.S. FY46-72), $14.4 million
Monetary conversion rate: 7 cordobas=US$1 (official)
Fiscal year: calendar year
GDP: $514 million (1971 est.), $120 per capita
Agriculture: commercial -- peanuts, cotton, livestock; main food crops --
millet, sorghum, niebe beans, vegetables
Major industries: cement plant, brick factory, rice miil, small cotton gins, oil
presses, Slaughterhouse, and a few other small light industries; uranium
production began in 1971
Electric power: 58,000 kw. capacity (1972); 52 million kw.-hr. produced (1972),
12 kw.-hr. per capita
Exports: $54 million (f.0.b., 1972); about 60% peanuts and related products,
rest largely livestock, hides, skins; exports badly understated because much
regional trade not recorded
Imports: $66 million (c.i.f.; 1972); fuels, machinery, transport equip-
ment, foodstuffs, consumer goods (largely for European residents}; sizable
imports unrecorded
255
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major trade partners: France (over 50%), other EC countries, Nigeria, UDEAC
countries, U.S.3; preferential tariff to EC and franc zone countries
Aid:
economic -- France (1960 to mid-1967) $68 million; EC (1961-72) $92.7 million;
U.S. (FY61-72) $20.5 million; West Germany, Israel, Republic of China, and U.N.
have also extended aid;
military -- $2.8 million (1954-68)
Budget: 1970 -- revenues $61.6 million (1972), current (1972) expenditures
(inetudes extra budgetary transactions) $46.1] million, investment expenditures a
15.6 million
bear conversion rate: 255.785 CFA=US$1 as of February 1973 (floating since
then
Fiscal year: 1 October - 30 September
GDP: $6.9 billion (1972), $120 per capita; 9% growth rate 1972
Agriculture: main crops -- peanuts, cotton, cocoa, rubber, yams, cassava,
sorghum, palm kernels, millet, corn, rice; livestock; almost self-sufficient
Fishing: catch 156,000 metric tons (1970); imports $3.7 million (1971)
: Major industries: processing industries -- oi] palm, peanut, cotton, rubber,
petroleum, wood, hides, skins; manufacturing industries -~ textiles, cement,
building materials, food products, footwear, chemical, printing, ceramics;
mining -- crude oil, natural gas, coal, tin, columbite
257
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Electric power: 1,111,000 kw. capacity (1972); 1.8 billion kw.-hr. produced
(1972), 36 kw.-hr. per capita
Exports: $2.1 billion (f.0.b., 1972); oi], peanuts, palm products, cocoa, rubber,
cotton, timber, tin $
Imports: $1.5 billion (c.i.f., 1972); machinery and transport equipment, manu-
factured goods, chemicals
Major trade partners: U.K., EC, U.S.
Budget: FY74 est. -- current revenue $2.14 billion, current expenditure $1.86
billion, capital expenditure $115 million
Monetary conversion rate: 1 Naira=US$1.52 (official) i
Fiscal year: 1 April - 317 March
GNP: $17.5 billion (1972), $4,440 per capita; 50.3% consumption; 33.0% investment;
13.7% government; net foreign balance 3.0%; 1972 growth rate 4.0%, in
constant prices
Agriculture: animal husbandry predominates; main crops -- feed grains, potatoes,
fruits, vegetables; 40% self-sufficient; food shortages -- food grains, sugar;
caloric intake, 2,940 calories per day per capita (1969-70)
Fishing: catch 2.9 million metric tons (1972); exports $325 million
Major industries: food processing, wood pulp, paper products, metals, machinery,
chemicals, shipbuilding
Shortages: feed and bread grains, coal, petroleum and petroleum products, cotton,
wool
Crude steel: 916,000 metric tons produced (1972), 230 kilograms per capita
Electric power: 14,120,000 kw. capacity (1972); 67.9 billion kw.-hr. produced
(1972), 15,000 kw.-hr. per capita
Exports: $3,246 million (f.o.b., 1972); principal items -- fish and fish
products, metal and metal products, pulp and paper, chemicals, ships
Imports: $4,332 million (c.i.f., 1972); principal items -- ships, machinery,
fuels, foodstuffs ;
Major trade partners: 18.2% Sweden, 14.6% U.K., 14.7% West Germany, 6.4% U.S.,
6.8% Denmark; 25.6% EC; 45.8% EFTA; 3.7% Communist countries (1971)
Aid:
economic -~ U.S., $440.9 million authorized (1946-72), $48.7 million in 1971,
$37.4 million in 1972; IBRD, $145 million authorized through 1972,
none since 1964; net official economic aid delivered to less developed
areas and multilateral agencies, $134.2 million (1960-69); $36.8 million
(1970); $42.4 million (1971)
military -~ U.S., $914.4 million authorized (1946-72), none since 1967
Monetary conversion rate: 1 kroner=US$0.1815 (September 28, 1973, floating)
Fiscal year: calendar year
COMMUNICATIONS: 4
Railroads: 2,662 mi.; State (NSB) operates 2,636 mi. standard gage, 2,589 mi.
single track, 1,516 mi. electrified, 47 mi. double track; 10 mi. standard
gage electrified private.y owned; 16 mi. meter (3''3 3/8") gage electrified
privately owned
Highways: 44,180 mi.; 7,135 mi. paved, 37,045 mi. crushed stone and gravel
Inland waterways: 980 mi.; 5'' draft vessels maximum
Pipelines: refined products, 33 mi.
Ports: 9 major, 69 minor
Civil air: 49 major transport aircraft
Airfields: 93 total, 87 usable; 41 with permanent-surface runways; 11 with
runways 8,000-11,999 ft., 14 with runways 4,000-7,999 ft.; 24 seaplane
stations
Telecomunications: high-quality domestic and international telephone, telegraph,
and telex service; 1.3 million telephones; 2.1 million radiobroadcast receivers;''
980,000 TV receivers; 36 AM, 234 FM, and ‘430 TV stations; 5 coaxial submarine
cables
DEFENSE FORCES:
Military manpower: males 15-49, 915,000; 740,000 fit for military service;
average number reaching military age (20) annually, 32,000
260
A PL eT aa nm | a BAP TO OTN Hm HIT HF See AT Peon NT NaN MN ee TT ie ame ame He ee £8 FOOTE HEN TRE
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 32B OMAN','d4b8a885eb3ea2ad53485515344d3fdf58de05b5450956abce6cf9e37342c8c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('856179e608731d3040ee8facd42990f4a4136bfc82bd9681a49e1a04f74c85f0',1974,'CO','Colombia','economy',36,'“TURKEY
LAND:
About 82,000 sq. mi.; negligible amount forested,
remainder desert, waste, or urban
Land boundaries: 860 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,300 mi.
GNP: $300 million (1972 est.), $660 per capita
Agriculture: based on subsistence farming (fruits, dates, cereals, cattle, camels,
fish) and trade
Major industries: petroleum discovery in 1964; production began in 1967; production
1972 equaled 280,000 b.p.d.; pipeline capacity 400,000 b.p.d.; revenue for 1972
$142 million
Electric power: 24,000 kw. capacity (1972); 70 million kw.-hr. produced (1972),
100 kw.-hr. per capita
Exports: $240 million (1972 est.); most of which is petroleum; non-oil exports
$1 million
Imports: $179 million (1972)
Major trade partners: U.K., Gulf states, India, Australia, China, Japan
Aid: multilateral annual average 1967-69 $350,000
Monetary conversion rate: 1 Riyal Omani=US$2.90 (as of October 1973)
Fiscal year: calendar year
GDP: $5.7 billion (FY73) at exchange rate of 9.9 rupees=US$1 prevailing June 1973,
less than $100 per capita; real growth (FY73) 5.8%
Agriculture: extensive irrigation; main crops -- wheat and cotton; largely
self-sufficient; foodgrain shortage due to increased consumption level
Fishing: catch 172,800 metric tons (1970 est.)
Major industries: cotton textiles, food processing, tobacco, engineering, chemicals,
natural gas
Exports: $766 million (f.o.b., FY73); cotton (raw and manufactured)
Imports: $775 million (c.i.f., FY73) machinery, transport equipment, chemicals Si
Major trade partners: U.S., U.K., Japan, West Germany
Monetary conversion rate: 9.9 rupees=US$1 (since February 1973)
Fiscal year: 1 July - 30 June |
GDP: $1.322 million (1972), $870 per capita; 72% private consumption, 11%
overnment consumption, 26% gross fixed investment, -9% net foreign balance
11970) ; real growth rate 1971, 7.6%
Agriculture: main crops -- bananas, rice, corn, coffee, Sugarcane; self-sufficient
in most basic foods; 2,450 calories per day per capita (1969)
Fishing: catch 62,400 metric tons, $1] million (1971); exports $13.3 million (1971);
imports $2.0 million (1971)
Major industries: food processing, metal products, construction materials,
petroleum products, clothing ;
Electric power (including Canal Zone); 378,000 kw. capacity (1972); 1.3 billion
kw.-hr. produced (1972), 650 kw.-hr. per capita
Exports: $140 million (f.o.b., 1972 est.); bananas, petroleum products, shrimp,
sugar, coffee |
Imports: $440 million (f.0.b., 1972 est.); manufactures, transportation equipment,
crude petroleum, foodstuffs, chemicals
Major trade partners: exports -- U.S. 38%, Canal Zone 32%, Germany 20%;
imports -- U.S, 33%, Venezuela 15% (1972 est.)
Aid:
economic -- from U.S. (FY46-72), $210.6 million loans, $15.6 million grants;
from international organizations (FY46-72), $155.5 million; from other Western
countries (1960-71), $58.9 million;
military -- assistance from U.S. (FY46-72), $5.5 million
Monetary conversion rate: 1 balboa=US$1 (official)
Fiscal year: calendar year
GDP: $15.2 million (1969), $260 per capita
Agriculture: main crops -- sugar on St. Christopher, cotton on Nevis
Major industries: sugar processing, salt extraction
Electric power: 11,000 kw. capacity (1972); 38 million kw.-hr. produced
(1972), 526 kw.-hr. per capita
Exports: $4.2 million (f.o.b., 1971); sugar, molasses, cotton, salt, copra
Imports: $15.8 million (c.i.f., 1971); foodstuffs, fuel, manufactures
Major trade partners: U.K. 45%, Canada 14%, U.S. 12% (1966)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1
297
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GNP: $20 million (1970 est.), $200 per capita
Agriculture: main crops «- bananas, arrowroot, coconut
Major industries: food processing
Electric power: 6,300 kw. capacity (1971); 18.9 million kw.-hr. produced (1971
est.), 235 kw.-hr. per capita
Exports: $3.7 million (f.o.b., 1968); bananas, arrowroot, copra, cotton
Imports: $1.0 million (c.i.f., 1968); fertilizer, flour, transportation
equipment, lumber, textiles
Major trade partners: U.K. 39%, U.S. 10%, Canada 10% (1967)
Monetary conversion rate: 1.92 East Caribbean dollars=US$1, now floating with
pound sterling
Principal economic activities of San Marino are farming, livestock raising, light
manufacturing, and tourism; the government''s total budget for FY7] was about
$12 million, with the largest share of revenue derived from the sale of
postage stamps throughout the world and from payments by the Italian Ba
government in exchange for Italy''s monopoly in retailing tobacco, gasoline,
and a few other goods; main problem is finding an additional $3 million to
finance badly needed water and electric power systems expansions
Agriculture: principal crops are wheat (average annual output about 4,400 metric
tons/year) and grapes (average annual output about 700 metric tons/year); Z
other grains, fruits, vegetables, and animal feedstuffs are also grown ;
livestock population numbers roughly 6,000 cows, oxen, and sheep; cheese
and hides are most important livestock products
Electric power: obtained from Italy
Manufacturing: consists mainly of cotton textile production at Serravalle, brick
and tile production at Dogane, cement production at Acquaviva, Dogane, and
Fiorentino, and pottery production at Borgo Maggiore; some tanned hides,
paper, candy, baked goods, Moscato wine, and gold and silver souvenirs are
also produced
Foreign transactions: dominated by tourism; in summer months 20,000 to 30,000
foreigners visit San Marino every day; a number of hotels and restaurants
have been built in recent years to accommodate them; remittances from
Sanmarinese abroad also represent an important net foreign inflow; conmodity
trade consists primarily of exchanging building stone, lime, wood, chestnuts,
wheat, wine, baked goods, hides, and ceramics for a wide variety of consumer
manufactures
GNP: $4.5 billion (FY72 est.), $800 per capita
Agriculture: dates, grains, livestock; not self-sufficient in food
Major industries: petroleum production 5.8 million barrels per day (1972 est.);
payments to Saudi Arabian Government, $2,100 million (est.) in 1971; cement
production and small steel-rolling mill and oil refinery; several other
light industries, including factories producing detergents, plastic products,
furniture, etc.; PETROMIN, a semipublic agency associated with the Ministry
of Petroleum, has recently completed a major fertilizer plant
Electric power: 290,000 kw. capacity (1972); 1 billion kw.-hr. produced (1972),
180 kw.-hr. per capita
Exports: $5,481 million (f.o.b., 1972); 99% petroleum and petroleum products
Imports: $1,460 million (c.i.f., 1972); manufactured goods, transportation equip-
ment, construction materials, and processed food products
Major trade partners: exports -- U.S., Western Europe, Japan; imports -- U.S.,
Japan, West Germany
Monetary conversion rate: 1 Saudi riyal=US$0.27 as of February 1973 (IMF par value,
freely convertible)
305
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Fiscal year: follows Islamic year; the 1970-71 Saudi fiscal year covers the
period 2 September 1970 through 20 August 1971
‘e
a $1.2 billion (1972 est.); $290 per capita; real growth rate less than 1%
1966-71)
Agriculture: main crops -- peanuts, millet, sorghum, manioc, rice; peanuts ms
primary cash crop; production of food crops increasing but still insufficient
for domestic requirements
Fishing: catch 240,000 metric tons, $48 million, (1971); exports $12 million
(1971), imports (not available)
Major industries: fishing, agricultural processing plants, light manufacturing,
mining is
Electric power: 134,200 kw. capacity (1972); 354 million kw.~hr. produced (1972),
88 kw.-hr. per capita
Exports: $216 million (f.0.b., 1972); approx. 35% peanuts and peanut products;
phosphate rock; canned fish |
Imports: $280 million (c.i.f., 1971); food, consumer goods, machinery, transport
equipment
Major trade partners: France, EC (other than France), and franc zone
Aid: economic -- France (1966-70) $115 million; U.S. (1961-72) $42.8 million;
U.S.S.R. $6.7 million loan negotiated; EC (1961-72) $40.7 million;
military -- U.S. (FY61-72) $2.8 million
Budget: 1972 est. -- receipts $215 million, current expenditure $193 million,
investment expenditure $19.8 million |
Monetary conversion rate: 1 Communaute Financiere Africaine franc=0.02 French
jae 255.785 CFA francs=US$1 as of February 1973 (floating since February
1973
Fiscal year: 1 July - 30 June
Agriculture: islands depend largely on coconut production and export of copra;
cinnamon, vanilla, and patchouli (used for perfumes) are other cash crops;
food crops -- small quantities of sweet potatoes, cassava, sugarcane, and
bananas; islands not self-sufficient in foodstuffs and the bulk of the
supply must be imported
Major industries: processing of coconut and vanilla, fishing, small-scale
manufacture of consumer goods, coir rope factory, tea factory
Electric power: 3,500 kw. capacity (1972); 9 million kw.-hr. produced (1972),
171 kw.~hr. per capita
Exports: $2.1 million (f.0.b., 1970); cinnamon (bark and oi1) and vanilla account
for almost 50% of the total, copra accounts for about 40%, the remainder
consisting of patchouli, fish, and guano
Imports: $10.1 million (c.i.f., 1970); food, tobacco, and beverages account for
about 40% of imports, manufactured goods about 25%, machinery and transport
equipment, petroleum products, textiles
Major trade partners: exports -- India, U.S.3; imports -- U.K., Burma, India,
South Africa, Kenya, Australia
309
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Aid: $1.2 million in aid in both 1965 and 1966 from U.K.
Budget: FY73 -- revenues $9 million, expenditures 10 million (approx.)
Monetary conversion rate: 5.4 Seychelles rupees=US$1
Fiscal year: calendar year it
GDP: $425 million (FY70), approx. $170 per capita; real growth rate 1970, 2%-3%
Agriculture: main crops -- palm kernels, coffee, cocoa, rice, yams, millet, ginger,
cassava; much of cultivated land devoted to subsistence farming; food crops
insufficient for domestic consumption
Fishing: catch 30,600 metric tons, $4.3 million, imports $2.7 million (1971)
311
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major industries: mining -- diamonds, iron ore, bauxite, rutile; manufacturing
~- beverages, textiles, cigarettes, construction goods; 1 oil refinery
Electric power: 57,000 kw. capacity (1972); 154 million kw.-hr. produced (1972),
58 kw.-hr. per capita
Exports: $118 million (f.0.b., 1972); 60% diamonds; iron ore, palm kernels, cocoa,
coffee
Imports: $121 million (c.i.f., 1972); machinery and transportation equipment,
manufactured goods, foodstuffs, petroleum products
Major trade partners: U.K., EC, Japan, U.S., Conmunist countries
Monetary conversion rate: 1 leone=US$1.30 (official), as of December 1971,
floating with pound sterling since then; in July 1973, effective rate
1 leone=US$1.26
Fiscal year: 1 July - 30 June (since 1 July 1966)
GNP: about $100 per capita
Agriculture: animal husbandry, cardamon, foodgrains, tea, and oranges
Industry: food processing and handweaving
Foreign trade: conducted and regulated by India
Exports: cardamon and preserved fruits
Imports: consumer goods
Major trade partner: India
Aid: India (1955-66) $19.8 million committed and drawn; India (1967-72) $14.3
million committed (excludes $17.3 million spent on the development of
military roads)
Monetary conversion rate: 7.5 Indian rupees=US$1 (official rate); now floating
with U.K. pound
Fiscal year: 1 April stated year - 31 March
le $2.8 ee (1972), $1,310 per capita; 13% average annual real growth
1965-71
Agriculture: occupies a position of minor importance in the economy, self-sufficien
in pork, poultry, and eggs, must import much of its other food requirements;
major crops -- rubber, copra, fruit and vegetables
Fishing: catch 14,700 metric tons (1972), imports -- 47,000 metric tons (1972)
Major industries: rubber processing and rubber products, processed food and
beverages, electronics, ship repair, entrepot trade
Exports: $2.4 billion (f.o.b., 1972); 60% reexports; petroleum products, rubber,
manufactured goods
315
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Imports: $3.75 billion (c.i.f., 1972); 25% goods reexported; major retained imports
~- capital equipment, manufactured goods, petroleum
Major trade partners: exports -- Malaysia, Indonesia, U.S., Japan, U.K.3;
imports -- Japan, Malaysia, U.S., U.K. :
Aid: U.K. -- (1960-September 1969) $254 million disbursed; (1969-73) $120
million extended; IBRD -- (1963-June 1972) $124 million committed, $61
million disbursed
Monetary conversion rate: 2.54 Singapore dollars=US$1
Fiscal year: | April - 31 March P
GDP: $137 million (1968 est.), about $50 per capita
Agriculture: mainly a pastoral country; main crops -- bananas, livestock,
sugarcane, cotton, cereals
Major industries: a few small industries, including a sugar refinery, tuna
and beef canneries, iron rod plant
Electric power: 9,000 kw. capacity (1972); 38 million kw.-hr. produced (1972),
12 kw.-hr. per capita
Exports: $43 million (f.0.b., 1972); bananas, livestock, hides, skins
Imports: $73 million (c.i.f., 1972); textiles, cereals, transport equipment
Major trade partners: Italy and U.K.; Arab countries; $6.9 million imports from
Communist countries (1970 est.)
Monetary conversion rate: 6.233 Somali shillings=US$1 (official)
Fiscal year: 1 January - 31 December
317
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GNP: $21.1 billion (1972), $940 per capita; real growth rate 3.1% (1972)
Agriculture: main crops -- corn, wool, dairy products, wheat, sugarcane, tobacco,
citrus fruits; self-sufficient in foodstuffs
Fishing: catch 481,000 metric tons (1972)
Major industries: mining, automobile assembly, metal working, machinery,
textiles, iron and steel, chemical, fertilizer, fishing
Electric power: 11,635,000 kw. capacity (1972); 63.993 billion kw.-hr. produced
(1972), 2,750 kw.-hr. per capita
Exports: $3.1 billion (f.o.b., 1972 excluding gold); wool, diamonds, corn,
uranium, sugar, fruit, hides, skins, metals, metallic ores, asbestos, fish
products; gold output $1.6 billion (1972)
Imports: $4.0 billion (f.o0.b., 1972); motor vehicles, machinery, metals,
petroleum products, textiles, chemicals
Major trade partners: U.K. and other Commonwealth nations, U.S., West Germany,','f40717d8ba89906efac9eac0304cfd4c5713760e5f30558c886bede41853a050','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4c41dd8ab87e3794a05017bca705a8f5350778b70162a2150b866b11fa544e5',1974,'GL','Greenland','economy',40,'GNP: $748 million (1972), $3,600 per capita; 65.3% consumption, 32.5%
investment, 9.8% government, -7.6% net foreign balance (1971); 1972 growth
rate 6.0%, constant prices
Agriculture: cattle, sheep, dairying, hay, potatoes, turnips; food shortages --
grains, sugar, vegetable and other fibers; caloric intake, 2,900 calories
per day per capita (1964-66)
157
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d): |
Fishing: catch 722,597 metric tons; exports $142 million (1972)
Major industries: fish processing, aluminum smelting, diatomite production
Shortages: grain, fuel, wood, minerals, vegetable fibers
Electric power: 454,000 kw. capacity (1972); 1.8 billion kw.-hr. produced
(1972), 7,700 kw.-hr. per capita
Exports: $191 million (f.0.b., 1972); fish and fish products, animal products,
aluminum, diatomite
Imports: $234 million (c.i.f., 1972); machinery and transportation equipment,
petroleum, foodstuffs, textiles
Major trade partners: (1972) Exports: EFTA 36%, EC 14%, U.S. 30%, U.S.S.R. 7%
Imports: EFTA 43%, EC 29%, U.S. 8%, U.S.S.R. 6%
Aid: economic -- U.S. authorized (1949-72) $89.2 million, $0.8 million in 1971,
$1.2 million in 1972; IBRD $30 million through December 1972
Monetary conversion rate: 1 kronur#US$0.0115 (spot rate on 31 July 1973)
Fiscal year: calendar year
GNP: $56 billion in current prices est. (year!ending 31 March 1973), less than $100
per capita; real growth (FY72), -3% est. |
Agriculture: main crops -- rice, other cereals, pulses, oilseeds, cotton, jute,
sugarcane, tobacco, tea, and coffee; must jmport foodgrains; caloric intake
is low and diet is deficient in protein
Fishing: catch 1.9 million metric tons (FY71-72); exports $52 million (FY71-72),
imports $100,000
Major industries: textiles, food processing
Crude steel: 6.6 million metric tons produced. (FY72)
Exports: $2.5 billion (f.0.b., FY72); tea, jute manufactures, iron ore, cotton
textiles, leather and leather products
Imports: $2.3 est. billion (c.i.f., FY72); machinery and transport equipment,
petroleum, iron and steel, grains and flou 2
Major trade partners: U.S., U.K., U.S.S.R. an Eastern Europe, Japan
Monetary conversion rate: 7.5 rupees=US$1 (effective April 1973)
Fiscal year: 1 April, stated year - 31 March |
COMMUNICATIONS: Pa
Railroads: 37,281 mi.; 16,072 mi. meter (3''3 3/8") gage, 18,299 mi. broad gage, 7
2,781 mi. (2''6" and 2''0") narrow gage government owned; 129 mi. 2''6" and
2''0" gage privately owned; 6,933 mi. double track; 2,303 mi. electrified
Highways: 643,028 mi.; 106,854 mi. paved, 95,054 gravel or crushed stone, 184,631
improved earth, 256,489 mi. unimproved earth
Inland waterways: 8,750 mi.; 1,600 mi. navigable by river steamers
Ports: 7 major, 75 minor
Civil air: 115 major transport aircraft
Airfields: 622 total, 357 usable; 186 with permanent-surface runways; 2 with
runway over 12,000 ft., 49 with runways 8,000-11,999 ft., 128 with runways
4,000-7,999 ft.; 4 seaplane stations
Telecommunications: fair domestic telephone service where available; telegraph
facilities widespread; AM broadcast adequate; TV limited to Bombay, New Delhi,
and Srinagar; international radio communications adequate; 1,351,200 telephones;
13 million radio and 21,000 est. TV sets; about 270 AM stations at 75 locations,
3 TV stations, one earth satellite station; submarine cables extend to Malaysia, 4
Sri Lanka, and Aden
DEFENSE FORCES:
Military manpower: males 15-49, 138,974,000; 79,105,000 fit for military service;
about 6,194,000 reach military age (17) annually ‘
160
anime itil inamiariaieaastaiiaahjnieelh RATE NT EARNS ED RORY Ol ON NNT OMEN
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIS 100 INDONESIA
ND: ~ maLaysia% : Se ae
736,000 sq. mi.; 12% small holdings and estates, 64% for- ee @ OY ge
ests, 24% inland water , waste, urban, and other ag, MR
Land boundaries: 1,700 mi. ey oiler ae
WATER: 5
Limits of territorial waters (claimed): under an archipelago So nus TRALIA
theory, claim is 12 n. mi., measured seaward from
straight baselines connecting the outermost islands
Coastline: 34,000 mi.
GDP: $9.6 billion (1972 est.), less than $100 per capita; real average annual
growth (1965-70) 3.5% (est.)
Agriculture: subsistence food production, and smallholder and plantation
production for export; main crops -- rice, rubber, copra, other tropical
products; substantially self-sufficient; food shortage -- rice
Fishing: catch 1.2 million tons (1971); exports $4.5 million (1970), imports $0.3
million (1970)
Major industries: processing agricultural products and petroleum, textiles,
mining
Exports: $1,549 million (f.o.b., 1972); rubber, tin, copra, tea, coffee, tobacco,
palm oi1; petroleum, $1,134 million (1972)
Imports: $1,458 million (f.0.b., 1972); rice, other foodstuffs, textiles, chemicals,
iron and steel products, machinery, transport equipment, consumer durables
Major trade partners: exports (1971) -- 15%,U.S., 43% Japan, 12% Singapore, 5%
West Germany; imports -- 15% U.S., 33% Japan, 10% West Germany, 6% Singapore
Monetary conversion rate: 415 rupiah=US$1
Fiscal year: 1 April - 31 March
GNP: $17.4 billion (1973), $560 per capita; real GNP growth, *
Iranian FY72-73, 13.3%
Agriculture: wheat, barley, rice, sugar beetis, cotton, dates, raisins, tea,
tobacco, sheep, and goats
Electric power: 2,851,000 kw. capacity (1972); 10.170 billion kw.-hr. produced
(1972), 330 kw.-hr. per capita
Exports: $447 million (non-oil, f.o.b. Iranian FY72/73); 89% petroleum; also
carpets, raw cotton, fruits, and nuts, hide and leather items, ores; Communist
countries (primarily U.S.S.R.) took about 31% of non-oi] exports
Imports: $2,556 million (c.i.f., FY72/73); machinery, iron and steel products,
chemicals, pharmaceuticals, electrical equipment; Communist countries
supplied about 7% of commodity imports
Major trade partners: exports -- U.S., Japan, West Germany, U.S.S.R. and other
Communist countries; imports -- U.S., West Germany, U.K., Japan, U.S.S.R.
Budget: FY73-74 -- revenues $5.6 billion, expenditures $7.2 billion
Monetary conversion rate: 68.17 rials=US$1
Fiscal year: 2] March - 20 March
GNP: $3.8 billion (1972 est.), $380 per capita
Agriculture: dates, wheat, barley, rice, livestock; largely self-sufficient
in food
Major industry: crude petroleum (fourth largest producer in Middle East)
Electric power: 908,000 kw. capacity (1972); 3.904 billion kw.-hr. produced (1972),
385 kw.-hr. per capita
Exports: $1,312 million (f.o.b., 1972), including oi1; non-oi1, $79 million
Imports: $793 million (c.i.f., 1972); 24% from Communist countries (1972)
Major trade partners: exports -- U.S. 2%, Italy 22%, France 19%, Netherlands 6%,
U.K. 4%; imports -- U.S. 4%, U.K. 9%, U.S.S.R. 7%, Czechoslovakia 7%, France 6%
165
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d); |
Monetary conversion rate: 1 Iraqi dinar=US$3) 38 (end of July 1973)
Fiscal year: 1 April - 31 March
GNP: $5 billion (1972), $1,670 per capita; 67% consumption, 22% investment, 14%
government; -3% net export of goods and services; 1972 real growth rate 3%
Agriculture: about 2/3 of agricultural area used for permanent hay and pasture;
main products -- livestock and dairy products, barley, potatoes, sugar beets,
wheat; 85% self-sufficient; food shortages -- grains, fruits, vegetables;
caloric intake 3,510 calories per day per capita (1970)
Fishing: catch 74,000 tons, $13.2 million (1970); exports of fish and fish products
$13.3 million (1971), imports of fish and fish products $4.4 million (1971)
167
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major industries: food products, brewing, textiles and clothing, machinery and
transportation equipment
Shortages: coal, petroleum, timber and woodpulp, steel and nonferrous metals,
fertilizers, cereals and animal feeds, textile fibers and textiles a”
Crude steel: 67,000 metric tons produced in /1968, 20 kilograms per capita
Electric power: 1,678,500 kw. capacity (1972); 6.2 billion kw.-hr. produced
(1972), 2,100 kw.-hr. per capita
Exports: $1,605 million (f.0.b., 1972); live animals, meat, textile products,
clothing, machinery, dairy products, chemicals
Imports: $2,108 million (c.i.f., 1972); machinery, chemicals, textiles,
transportation equipment, petroleum, metal manufactures, cereals
Major trade partners: 13.9% EC, 5.4% West Germany, 60.9% EFTA, 56.2% U.K.,
9.7% U.S., 1.3% Communist countries (1971)
Aid: economic -- U.S., $187.8 million authorized (FY49-72), no activity (FY55-66),
$41.3 million authorized (FY67-72), $12.6 million authorized in FY69, none
authorized in FY70-72; IBRD $73.3 million authorized (FY64-72) $28 million
authorized (FY72)
Monetary conversion rate: 1 Irish pound=US$2.414 (as of September 28, 1973,
floating)
Fiscal year: 1 April - 31 March
GNP: $122.3 billion (1972), $2,250 per capita; 63.6% consumption, 20.9% investment,
13.7% government, net foreign balance 1.8% (1971 provisional); 1972 growth
rate 3.2%, 1963 constant prices
Agriculture: important producer of fruits and vegetables; main crops -- cereals,
potatoes, olives; 95% self-sufficient; food shortages -- fats, meat, fish,
and eggs; caloric intake, 3,100 calories per capita (1970)
Fishing: catch 391,200 metric tons (1971), $251.8 million (1971); exports $22
million (1972), imports $132 million (1972)
Major industries: machinery and transportation equipment, iron and steel,
chemicals, food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 19.7 million metric tons produded (1972), 360 kilograms per capita
Electric power: 37,000,000 kw. capacity (1972); 133 billion kw.-hr. produced
(1972), 2,300 kw.-hr. per capita
Exports: $18.5 billion (f.0.b., 1972); principal items -- machinery and
transport equipment, textiles, foodstuffs, chemicals, footwear
Imports: $19.3 billion (c.i.f., 1972); principal items -- machinery and transport
equipment, foodstuffs, ferrous and nonferrous metals, wool, cotton, petroleum
Major trade partners: (1972) 22% West Germany, 9% U.S., 15% France, 4% U.K.,
4% Belgium-Luxembourg, 5% Netherlands, 3% Switzerland; 45% EC of Six;
12% EFTA; 5% U.S.S.R. and Communist countries of Eastern Europe Fe
Aid: ;
economic -- U.S., $3,986.6 million (FY46-72), $22.3 million authorized FY72;
IBRD, $398 million authorized through FY72, none since FY65; International
Finance Corporation, $1 million authorized through FY72, none since FY60;
military -- U.S., $2,479.5 million (FY46-72) , $62 million authorized in
FY68 (Export-Import Bank credits), none since 1968
Monetary conversion rate: smithsontan rate as of December 1971, 581.5 lira=US$1;
spot rate as of 28 September 1973, 563.38 lira=US$1
Fiscal year: calendar year
GDP: $1.6 billion (1971), $360 per capita (1971); average annual growth
rate 1960-70, 8.3%
Agriculture: commercial -- coffee, wood, cocoa, bananas, pineapples, palm oi1;
food crops -- corn, millet, yams, rice; other commodities -- cotton, rubber,
tobacco, fish; self-sufficient in most foodstuffs, but rice, sugar, and meat
imported
Fishing: catch 62,600 metric tons (1971); $14.7 million, exports $2.6 million
(1970), imports $5.2 million (1971)
Major industries: food and lumber processing, oil refinery, automobile assembly
plant, textiles, soap, flour mill, matches, three small shipyards, fertilizer
plant, and battery factory
175
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/3
ECONOMY (cont''d):
Electric power: 238,900 kw. capacity (1972)
157 kw.-hr. per capita
Exports: $553 million (f.0.b., 1972); coffee,
bananas, pineapples, palm oil |
Imports: $453 million (c.i.f., 1972); consume
fuels 10%, manufactured goods and semi-fin
Major trade partners: France and other EC cou
countries about 1%
Aid:
economic -- France (1960-69) $312 million:
commitments; U.S. (FY61-72), $110 million}
including $18.5 million comitted; no Commu
military -- non-Communist countries, $7.3
Budget: 1972 est. -- revenues $369.1 million
investment expenditures $136.4 million
Monetary conversion rate: 1 Communaute Finane
francs; 255.785 CFA francs=US$1 as of Febr
February 1973)
Fiscal year: calendar year
7
GNP: $1,284 million (1972 est.), $670 per capita; real growth rate 1972, 0.5% est.
Agriculture: main crops -- sugarcane, citrus fruits, bananas, pimento, coconuts,
coffee, cocoa
Major industries: bauxite, textiles, food processing, light manufactures, tourism
Electric power: 556,000 kw. capacity (1971) 5 1.6 billion kw.-hr. produced
(1971), 860 kw.-hr. per capita
V7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $379 million (f.o0.b., 1972); alumina, bauxite, sugar, bananas, citrus
fruits and fruit products, rum, cocoa
Imports: $542 million (c.i.f., 1972); machinery, transportation and electrical
equipment, food, fuels, fertilizer
Major trade partners: exports -- U.S. 45%, U.K. 19%, Canada 8%, Norway 9%;
imports -- U.S. 40%, U.K. 20%, Canada 8% (1971)
Aid:
economic -- from U.S. (FY56-72), $80.2 million in loans; $47 million grants;
from international organizations (Fv46-72) , $94.8 million; from other Western
countries (1960-71), $90.2 million;
military -- assistance from U.S. (FY63-72), $1.1 million
Monetary conversion rate: 1 Jamaican dollar=US$1.10
Fiscal year: 1 April - 31 March
GNP: $705 million (1972 at marketprices), $290 per capita
Agriculture: main crops -- wheat, fruits, vegetables, olive oil; not self-
sufficient in many foodstuffs
Major industries: phosphate mining, petroleum refining, and cement production &
Electric power: 46,260 kw. capacity (1972); 131 million kw.-hr. produced (1972),
54 kw.-hr. per capita
Exports: $48 million (f.0.b., 1972); major items -- fruits and vegetables,
phosphate rock; Communist share 5% of total (1971)
Imports: $274 million (c.i.f., 1972); major items -- petroleum products, textiles,
capital goods, motor vehicles, foodstuffs; Communist share 17% of total (1971)
Aid:
economic -- U.S., $676 million economic assistance (FY49-72), of which $39
million loans, $642 million grants; technical assistance
military -- $195 million total from U.S. (July 1949-March 1972) including
$120 million in MAP grants
Monetary conversion rate: 1 Jordanian dinarsUS$3.10, freely convertible; 0.322
Jordanian dinar=US$1
Fiscal year: calendar year
GDP: $1,574 million at 1967 prices (1972), $130 per capita; 7% real growth (1972)
Agriculture: main cash crops -- coffee, sisal, tea, pyrethrum, cotton, livestock;
food crops -- corn, wheat, rice, cassava; largely self-sufficient in food
Fishing: $4.2 million (1970)
Major industries: small-scale consumer goods (plastic, furniture, batteries,
textiles, soap, agricultural processing, cigarettes, flour), oil refining,
cement
Electric power: 217,000 kw. capacity (1972); 875 million kw.-hr. produced (1972),
70 kw.-hr. per capita
183
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d): |
Exports: $339 million (f.o.b., 1972); coffee,| tea, livestock products, pyrethrum,
soda ash, wattle-bark tanning extract
Imports: $518 million (c.i.f., 1972); machinery, transport equipment, crude oil,
paper and paper products, iron and steel products, and textiles
Major trade partners: U.K. and EC, also Uganda and Tanzania, which are part of
East African Economic Community
Budget: FY73 current expenditure $372 million
Monetary conversion rate: 1 Kenya shilling=US$0.14 (official}; 6.90 Kenya
shill ings=US$1 t
Fiscal year: 1 July - 30 June
GNP: roughly $300 per capita (1972)
Agriculture: main crops -- rice, corn, vegetables; food shortages -- meat,
cooking oi1s; production of foodstuffs adequate for domestic needs at low
levels of consumption
Major industries: machine building, electric power, chemicals, mining, metallurgy,
textiles, food processing
Shortages: heavy machinery and equipment, bituminous and coking coal, petroleum,
rubber
Exports: minerals, chemical and metallurgical products
Imports: machinery and equipment, petroleum, foodstuffs, coking coal
Major trade partners: total trade turnover almost $1 billion (1972); about one-
fourth with non-Communist countries, three-fourths with Communist countries
(almost one-half with the U.S.S.R.)
Aid:
economic and military aid from the U.S.S.R. and China
Monetary conversion rate: 2.37 won=US$1 (arbitrarily established) as of early 1972
Fiscal year: calendar year
185
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GNP: $9.8 billion (1972), $300 per capita; real growth 7.1% (1972) ..
Agriculture: 46% of the population live on the land, but agriculture, forestry
and fishery constitute 26% of GNP; main crops -- rice, barley, wheat ; not
self-sufficient; food shortages -- barley, wheat, dairy products, rice, corn
Fishing: catch 1,343,000 metric tons, $262 million (1972 est.)
Major industries: textiles and clothing, food processing, chemical fertilizers,
chemicals, plywood, coal
Shortages: base metals, fertilizer, petroleum, lumber and certain food grains
Exports: $1.6 billion (f.o.b., 1972); clothing and textiles, veneer and plywood,
wigs, fish products, electrical products, iron and steel scrap
Imports: $2.5 billion (c.i.f., 1972)
Major trade partners: 1972 exports ~-- U.S. 47%, Japan 22%; imports -- Japan
39%, U.S, 28%
Aid: |
economic -- U.S. (FY46-72), $5.6 billion committed; Japan (1965-71), $730
million extended; |
military -- U.S. (FY46-72), $5.7 billion committed
Monetary conversion rate: 393 won=US$1 (floating-rate average value in 1972),
rate fixed at 400 won=US$1 by end of 1972 |
Fiscal year: calendar year
Agriculture: virtually none, dependent on imports for food; approx. 75% of
potable water must be distilled or imported
Major industries: crude petroleum production averaging 3.3 million b.p.d.
(includes Kuwait''s share of neutral zone) (1972) : government revenues from
taxes and royalties on production, refining, and consumption $1,700 million
in 1972; refinery capacity est. at 504,000 bbls. per day (1970); other major
industries include fishing, processing of building materials, fertilizers,
chemicals, and flour
Electric power: 1,070,800 kw. capacity (1972); 3.2 billion kw.-hr. produced
(1972), 3,280 kw.-hr. per capita
Exports: $1,785 million (FY71-72)., of which petroleum accounted for about 98%;
nonpetroleum exports are mostly reexports, $137 million (f.o.b., FY71-72)
Imports: $819 million (FY71-72); major suppliers -- U.S., Japan, U.K., West','bf73419510dd39954c534f3b301d05bbfff63bdc7b0f5561a91b69e3c86ee19f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91720cba973ae019f524c5d39a6095cf69e34e3a03f1bc36212fd53c883b0028',1974,'DE','Germany','economy',42,'Monetary conversion rate: 1 Kuwaiti dinar=US$3.38 (October 1973)
Fiscal year: 1 April - 31 March
189
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ont
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GNP: $205 million, $70 per capita (1971 est.)
Agriculture: main crops -- rice (overwhelmingly dominant), corn, coffee, cotton
and tobacco; largely self-sufficient; food shortages {due in part to
distribution deficiencies) including rice
Fishing: catch data unavailable; imports fish and fish products 200 tons,
$128,000 (1970)
Major industries: tin mining, timber
Shortages: capital equipment, petroleum, transportation system
Electric power: 54,500 kw. capacity (1973); 240,000 kw.-hr. produced (1973),
76 kw.-hr. per capita
Exports: $2.6 million (f.o.b., 1972); tin concentrates; forest products, coffee,
undeclared exports of opium significant but value unknown
191
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Imports: $44 million (c.i.f., 1972); rice and other foodstuffs, petroleum
products, machinery, transportation equipment, textiles
Major trade partners: imports from Thailand, Japan, U.S., France, U.K., Indonesia,
Hong Kong; exports to Malaysia and Thailand; trade with Communist countries
insignificant; Laos a major transit point in world gold trade; value of 1972
gold imports $2.4 million
Monetary conversion rate: 600 kip=US$] for most transactions
Fiscal year: 1 July - 30 June
GNP: $2.0 billion (1972 est.) (current prices), $670 per capita (C)
Agriculture: fruits, wheat, corn, barley, potatoes, tobacco, olives, onions; not
self-sufficient in food
Major industries: service industries, food processing, textiles, cement, oi]
refining, chemicals, some metal fabricating, tourism
Electric power: 560,900 kw. capacity (1972); 1.5 billion kw.-hr. produced
(1972), 500 kw.-hr. per capita
Major trade partners: exports $270 million (f.0.b., 1971); most to Arab
countries; imports $818 million (c.i.f., 1971); chiefly from EC, U.K., and re
Arab countries; trade deficit covered by large net receipts from invisibles :
(particularly tourism and transportation) and private capital inflow
Monetary conversion rate: 1 Lebanese pound=US$0.41 as of March 1973
Fiscal year: calendar year
GNP: $90 million (1968), about $100 per capita
Agriculture: exceedingly primitive, mostly subsistence farming and livestock;
principal crops are corn, wheat, pulses, sorghum, barley
Major industries: none
Electric power: 2,820 kw. capacity (1972); 6 million kw.-hr. produced (1972),
6 kw.-hr. per capita
Exports: labor to South Africa (remittances $15 million in 1969); $5 million
(f.o.b., 1970), wool, mohair, wheat, cattle, diamonds, peas, beans, corn,
hides, skins
Imports: $32 million (f.0.b., 1970); mainly corn, building materials, clothing,
vehicles, machinery, POL
195
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major trade partner: South Africa
Aid: economic aid; U.K. $9.4 million (plan FY71-75); other $17.5 million (plan
FY71-75); U.S. $13.4 million authorized; no military aid =
Monetary conversion rate: Lesotho uses the South African rand; 1 SA rand=US$1.42
(par value); .7046 SA rand=US$1
Fiscal year: 7 April - 31 March
GDP: $459.6 million (1972 est.), 5.0% cuir growth rate, $280 per capita
Agriculture: rubber, oi] palm, cassava, coffee, rice; imports of rice, wheat,
and meat are necessary for basic diet
Fishing: catch 22,500 metric tons, $6.1 million (1969) ,
Industry: rubber processing, food processing, construction materials, furniture,
palm oil processing, mining (iron ore, diamonds), 10,000 b/d oil refinery
Electric power: 225,200 kw. capacity (1972); 788 million kw.-hr. produced (1972),
483 kw.-hr. per capita
Exports: $244 million (f.0.b., 1972); iron ore, diamonds, rubber, palm
kernels, coffee, cocoa
Imports: $179 million (c.i.f., 1972); machinery, transportation equipment,
foodstuffs, manufactured goods
Major trade partners: U.S., West Germany, Japan, U.K,
Aid:
economic -- (FY46-72) U.S., $269.2 million;
military -- (FY53-72) U.S., $11.3 million; other aid sources include IBRD,
U.N., IMF, and West Germany
Monetary conversion rate: Liberia uses U.S. Icurrency
Fiscal year: calendar year
GDP: $4.8 billion (FY72), $2,400 per capita, little real per capita change
since 1969
Agriculture: main crops -- wheat, barley, olives, dates, citrus fruits, peanuts;
not self-sufficient in food
Major industries: petroleum production averaged 2.2 million b.p.d. (1972); oi]
revenues for 1972 about $1.6 billion; food processing, textiles, handicrafts
199
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Electric power: 280,000 kw. capacity (1972); 640 million kw.-hr. produced (1972),
310 kw.-hr. per capita
Exports: $2,798 million (1971 at present conversion rate); over 99% petroleum *
Imports: $678 million (1971 at present conversion rate)
Major trade partners: imports -- Italy, West Germany, U.S.; exports -- Italy,
West Germany, U.K., France
Aid: economic -- no Communist country assistance; U.S. aid extended $212.5
million (FY49-72)
military -- arms obtained by cash purchase; chief suppliers France, U.S.S.R., »
Czechoslovakia; U.S. suspended since September 1969
Monetary conversion rate: 1 Libyan pound=US$3.04 (April 1973)
Fiscal year: 1 April - 31 March
Despite its small size and sparse natural resources, Liechtenstein has a
prosperous economy based primarily on small-scale light industry and farming.
Textiles, ceramics, precision instruments, pharmaceuticals, and canned foods
are the principal manufactures produced, almost entirely for export. Live-
stock raising and dairying are the main sources of farm income; cereals and
potatoes are the most important farm crops. The Liechtenstein economy is
tied closely to that of Switzerland in a virtual customs union. No national
accounts data are available.
Major trade partners: exports (1972) -- $138.6 million; 34% Switzerland, 35% EC,
48% EFTA
Electric power: 22,600 kw. capacity (1972); 55 million kw.-hr. produced (1972),
1,800 kw.-hr. per capita; power is exchanged with Switzerland, but net
exports average 35 million kw.-hr. yearly
GNP: $1,525 million (1972), $4,460 per capita; 60% consumption, 12% investment,
30% government, -2% net exports of goods and services; 1972 growth rate
2% at constant prices
Agriculture: mixed farming; main crops -- grains, potatoes, fodder beets; food
shortages -- sugar, bread grains, fats; caloric intake, 3,150 calories per
day per capita (1968-69)
Major industries: iron and steel, food processing, chemicals, metal products and
engineering, tires
Crude steel: 5.5 million metric tons produced (1972), about 16,100 kg. per capita
Electric power: 1,204,000 kw. capacity (1972); 2.3 billion kw.-hr. produced »
(1972), 6,920 kw.-hr. per capita
Exports: $967 million (f.o.b., 1971)
Imports: $898 million (c.i.f., 1971)
Major trade partners: Luxembourg and Belgium form an economic and customs union
and report their foreign trade jointly (see Belgium); Luxembourg''s principal
exports are iron and steel products; principal imports are coal and consumer
products; most foreign trade is with Germany, Belgium, and other EC countries
Aid: foreign aid to Luxembourg is included in aid to Belgiurn
Monetary conversion rate: 1 franc=US$0.0272 {as of September 28, 1973, floating);
under the BLEU agreement, the Luxembourg franc is equal to the Belgian franc
which circulates freely in Luxembourg
Fiscal year: calendar year
“es
Agriculture: main crops -- rice, vegetables; food shortages -- rice, vegetables,
meat; depends mostly on imports for food requirements
Major industries: textiles, fireworks
Exports: $50 million (f.o.b., 1971); textiles and clothing, foodstuffs, fireworks
Imports: $77 million (f.0.b., 1971)
Major trade partners: exports -- Portuguese colonies 21%, Hong Kong 16%, West
Germany 17%; imports -- Hong Kong 65%, China 27% (1971)
Monetary conversion rate: 5.486 patacas=US$1 (June 1972)
Fiscal year: calendar year
205
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GDP: $420 million (1972), $90 per capita; real growth rate 7.7% (1972)
Agriculture: cash crops -- tea, tobacco, peanuts, cotton, tung; subsistence
crops -- corn, sorghum, millet, pulses, root crops, fruit, vegetables, rice
Electric power: 49,100 kw. capacity (1972); 174 million kw.-hr. produced (1972);
36 kw.-hr. per capita
Major industries: agricultural processing (tea, tobacco, sugar), sawmilling,
cement, consumer goods
Exports: $81 million (f.o.b., 1972); tobacco, tea, groundnuts, cotton
Imports: $130 million (c.i.f., 1972); manufactured goods, machinery and
transport equipment, food, fuels
Major trade partners: exports -- U.K., Zambia, Rhodesia, U.S.; imports -- U.K.;
Rhodesia, South Africa
Aid:
economic -- U.K. provides both budgetary and development support, about
$96 million (1966-71); U.S. aid commitments, $29.6 million (1956-72);
military -- U.K., $0.9 million (1954-68)
209
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Budget: FY74 current expenditure $75 million
Monetary conversion rate: 1 Malawi kwacha=US$1.26 (as of July 1973, floating
with pound sterling)
Fiscal year: 1 April - 31 March
GNP:
Malaysia: $4.1 billion (1971), $380 per capita; average annual real growth
(1966-71) 4%
Agriculture:
West Malaysia: mixed plantation and subsistence; main crops -- rubber, rice,
oil palm; 25% of rice requirements imported
Sabah: mainly subsistence; main crops -~- rubber, coconut, rice; food deficit
-- rice
Sarawak: main crops -- rubber, pepper; food deficit -- rice
Fishing: catch 390,000 tons, $114 million; exports $22 million, imports $7 million
Major industries:
West Malaysia: rubber and oil palm processing and manufacturing, tin mining
and smelting, logging and processing timber, light consumer goods
Sabah: logging
Sarawak: agriculture processing, petroleum refining, logging
Exports: $1,893 million (f.0.b., 1972); 29% rubber, 18% tin, 17% timber (West
Malaysia)
Imports: $2,057 million (c.i.f. 1972) (West Malaysia)
Major trade partners: exports -- 22% Singapore, 18% Japan, 13% U.S.3
imports -- 20% Japan, 15% U.K., 8% Singapore
213
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Aid:
economic -- U.K. (1946-69) $260 million disbursed; Japan (1966-68) $50
million extended; IBRD (1959 - July 1972) $317 million (committed); U.S, ;
(1954-72) $107 million; ,
military -~ U.S. (FY65-72) $30 million committed
Monetary conversion rate:
Malaysia: 2.49 Malaysian dollars=US$1 (May 1973)
Fiscal year: calendar year
GNP: under $100 per capita
Agriculture: crops -- coconut and millet; shortages -- rice, wheat
Fishing: catch 32,000 tons (1970)
Major industries: fishing; some coconut processing
Exports: $2.4 million (f.o.b., 1968); fish
Imports: $2 million (c.i.f., 1968)
Major trade partner: Sri Lanka
Aid: U.K. (1960-65), $1.4 million drawn; Sri Lanka (1967), $1 million committed
Monetary conversion rate: 6.39 rupees=US$1
Fiscal year: calendar year
GDP: about $380 million (1972), per capita $70
Agriculture: main crops -- millet, sorghum, rice, corn, peanuts; cash crops --
peanuts, cotton, livestock
Fishing: catch 90,000 metric tons (1971) exports $670,000 (1971)
Major industries: small local consumer goods and processing
Electric power: 22,480 kw. capacity (1972); 52 million kw.-hr. produced (1972),
10 kw.-hr. per capita
Exports: $29.1 million (f.o.b., 1972); livestock, peanuts, dried fish, cotton,
skins
Imports: $61.1 million (c.i.f., 1972); textiles, vehicles, petroleum products,
machinery, and sugar
Major trade partners: mostly with franc zone and Western Europe; also with U.S.S.R.,','7ffa11a665e2b812091b7a99cebc35e18c909561b0014bfcae960febb4bd95f6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('562e6ebb2a3911843f9d377fc53011341a73748d99f73690b983cc182a1fe5d1',1974,'CN','China','economy',46,'219
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Budget: 1971 est. -~ receipts $44.9 million, current expenditures $43.6
million, investment expenditures $5.2 million
Monetary conversion rate: since December 1971, 511.57 Mali francs=US$1
Fiscal year: calendar year
GNP: $302 million (1971 current prices), $920 per capita; 71% private
consumption, 29% gross investment; 1971 growth rate 3% in current prices
Agriculture: overall, 20% self-sufficient; adequate supplies of vegetables, poultry,
milk and pork products; shortages in beef, grain, animal fodder, and fruits at
various seasons; main products -- potatoes, cauliflowers, grapes, wheat,
barley, tomatoes, citrus, cut flowers, green peppers, hogs, poultry, eggs;
2,680 calories per day per capita
Major industries: ship repair yard, building industry, food manufacturing,
textiles, tourism
Shortages: most consumer and industrial needs (fuels and raw materials) must be
imported
Electric power: 115,000 kw. capacity (1972); 312 million kw.-hr. produced (1972),
910 kw.-hr. per capita
221
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $67 million (1972); textiles, scrap metal, wine, agricultural
products, and footwear
Imports: $175 million (1972)
Major trade partners: U.K. 44%, Italy 15.7%; EFTA 48%; EC 28.2%; Communist
countries 2.5%; North and Central America 3.8% (1971)
Aid: economic -- U.S., $19.5 million (FY49-72), of which $0.3 million authorized
in 1968, $1.7 million authorized 1969; $0.1 million authorized in 1970; and
$0.7 million authorized in 1971, and $10.5 million in 1972; U.K. Financial
Agreement (loans and grants) 1964-74, $140 million; IBRD $6 million through
1971, none since 1964; U.N. Special Fund $2.1 million through 1971; U.N.
Technical Assistance $1.3 million through 1970, of which $0.1 million in 1970
Monetary conversion rate: 1 Maltese Pound=US$2.67 (Smithsonian Agreement) ,
December 1971; the Maltese pound began floating in June 1972, with the rate
being determined between that of sterling land that of the currencies of
Malta''s major trading partners; average market rate, 1972: 2 Maltese
pounds=US$2.52, July 1973: 1 Maltese pound=US$2.87
Fiscal year: 1 April - 31 March','fd9934f7ab37cdb0a98a99492a9ed0b018b8041fddba5ff2bfdfb05420fa5de8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d2a2c00eb560cd55d2a8bc206073ab1b83bbe92f798748089dcd5d3c29854ee',1974,'ZM','Zambia','economy',50,'GNP: $2.1 billion (1972 est.), about $250 per capita
Agriculture: cash crops -- raw cotton, cashew nuts, sugar, tea, copra, sisal;
other crops -- corn, wheat, peanuts, potatoes, beans, sorghum, and cassava;
self-sufficient in food except for wheat which must be imported
Major industries: food processing (chiefly sugar, tea, wheat, flour, cashew
kernels); chemicals (vegetable oi], oilcakes, soap, paints); petroleum
products; beverages; textiles; nonmetallic mineral products (cement, glass,
asbestos, cement products); tobacco
237
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Electric power: 232,000 kw. capacity (1972); 563 million kw.-hr. produced (1972),
64 kw.-hr. per capita
Exports: $160 million (f.0.b., 1971); cashew nuts, cotton, sugar, mineral products, .
timber products, tea, copra, petroleum products :
Imports: $335 million (c.i.f., 1971); machinery and electrical equipment, cotton
textiles, vehicles, petroleum products, wine, iron and steel
Major trade partners: over one-third of foreign trade with Portugal; South Africa,
U.S., U.K., West Germany
Aid: from Portugal only «
Monetary conversion rate: 27.25 escudos=US$1 (approximate realigned rate)
until February 1973, since then -- 25.5 escudos=US$]1
Fiscal year: calendar year','5f17c1830a703f5d786fb25b9ad8656859af35b3016ef5e4c89182dc9a748579','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4092dfa96f6fc393662a0078a43345dd81d077731fde25a6e9cf369becd25d9',1974,'AU','Australia','economy',55,'GNP: $28 million (1970), $4,000 per capita (est.)
Agriculture: negligible; almost completely dependent on imports for food, water
Major industries: mining of phosphates, about 2 million tons per year (1966)
Exports: $17 million (f.o.b., 1968), consisting entirely of phosphates
Imports: $5 million (c.i.f., 1968)
Major trade partners: Australia, New Zealand, and United Kingdom
Monetary conversion rate: 1 Australian dollar=US$1.4167 (official)
Fiscal year: 1 July - 30 June
GDP: $1 billion (1970), less than $100 per capita
Agriculture: over 90% of population engaged in agriculture; main crops -~- rice,
corn, wheat, sugarcane, oilseeds; largely self-sufficient
Major industries: small rice, jute, sugar, and oilseed mills; match, cigarette,
and brick factories
24]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $56 million (FY69); rice and other food products, jute, timber
Imports: $74 million (FY69); manufactured consumer goods, food grains and
food products
Major trade partner: over 90% India 4
Monetary conversion rate: 10.56 Nepalese rupees=US$1
Fiscal year: 15 July - 14 duly
GNP: $52.5 billion (1972), $3,940 per capita; 57% consumption, 20% investment,
21% government; 2% foreign balance; 1972 growth rate 3.9%, in constant prices
Agriculture: animal husbandry predominates; main crops -- horticultural crops,
grains, potatoes, sugar beets; food shortages -- grains, fats, oils; caloric -
intake, 3,186 calories per day per capita (1970-71)
Fishing: catch 331,682 metric tons, $137 million (1972); exports 19,200 metric
tons, imports 83,750 metric tons (1972)
Major industries: food processing, metal and engineering products, electrical and
electronic machinery and equipment, chemicals, and petroleum products
Shortages: crude petroleum, raw cotton, base metals and ores, pulp, pulpwood,
lumber, feedgrains, and oilseeds
Crude steel: 5.6 million metric tons produced (1972), 419 kilograms per capita
Electric power: 10,885,000 kw. capacity (1972); 49.6 billion kw.-hr. produced
(1972), 3,400 kw.-hr. per capita
Exports: $16,782 million (f.0.b., 1972); foodstuffs, machinery, transportation
equipment, consumer manufactures, chemicals, petroleum products, textiles
Imports: $17,421 million (c.i.f., 1972); mchnaey. transportation equipment,
consumer manufactures, crude petroleum, foodstuffs, chemicals, raw cotton,
base metals and ores, pulp
Major trade partners: (1972) 60% EC, 31% W. Germany, 15% Belgium-Luxembourg,
6% U.S.
Aid:
economic ~- U.S., $1,350 million authorized (FY46-72); IBRD, $236 million
authorized (FY46-72), none since 1958;
military -- U.S., $1,255 million authorized (FY49-72), none since FY65; net
official aid delivered to less developed areas and multilateral agencies -- »
$1,458 million (FY62-72), $315 million (1972)
Monetary conversion rate: 2.532 guilders=US$1 (September 28, 1973, floating)
Fiscal year: calendar year
GNP: $550 million (FY70 estimate), $230 per capita; real average annual growth
rate (1960-69) 7.5%
Agriculture: main crops -- coconuts, coffee, cocoa, tea
Major industries: sawmilling and timber processing, copper mining (Bougainville)
Exports: $117.2 million (f.o.b., FY71); principal products -- coconut products,
coffee beans, cocoa beans, timber
Imports: $292.8 million (f.o.b., FY71)
267
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major trade partners: Australia, U.K., Japan,
Aid: economic -- Australia (FY46-69) $909 million extended; World Bank group
(1968-September 1969) -- $7.5 million committed
military -- U.S. $28.7 million extended
Monetary conversion rate: Australian $1=US$1 .4875
Fiscal year: 1 July - 30 June
. GNP: $609 million (1972), $260 per capita; 88% consumption; 16% gross domestic
: investment; -4% net foreign balance (1972); real growth rate 1972 est., 5.8%
Agriculture: main crops -- oilseeds, cotton, wheat, manioc, sweet potatoes,
tobacco, corn, rice, Sugarcane; self-sufficient in most foods; caloric
intake, 2,580 calories per day per capita (1963-64); protein intake,
70 grams per day per capita (20 grams of animal origin)
x Major industries: meat packing, oilseed crushing, milling, brewing, textiles,
light consumer goods, cement
Electric power: 159,000 kw. capacity (1971); 257 million kw.-hr. produced
(1971), 104 kw.-hr. per capita
269
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $86.0 million (f.0.b., 1972); meat, timber, oilseeds, tobacco, cotton,
quebracho extract, hides, yerba mate, coffee
Imports: $69.8 million (f.o.b., 1972); foodstuffs, machinery, transport equipment, Py
engines, consumer durables, fuels and lubricants, textiles, chemicals
Major trade partners: U.S. 15%, Argentina 14%, West Germany 13%, U.K. 9%
Aid:
economic ~- extensions from U.S. (FY46-72), $88.2 million loans, $71.6 million
grants; from international organizations (FY46-72), $189.4 million; from other
Western countries (1960-70), $21.9 million a
military -- assistance from U.S. (FY57-72), $15.9 million
Monetary conversion rate: 126 guaranies=US$1 (official rate)
Fiscal year: calendar year
GNP: $7.6 billion (at official exchange rate, 1972), $530 per capita; 73%
private consumption, 10% public consumption, 12% gross investment (1972); 5%
net foreign balance; real growth rate 1972 5.2%
Agriculture: main crops -- wheat, potatoes, beans, barley, coffee, cotton,
sugarcane; imports wheat, meat, lard and oils, rice, corn; caloric intake,
2,300 calories per day per capita (1964)
271
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
a?
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d)
Fishing: catch 4.7 million metric tons (1972); exports $322.0 million (1972), of
which $286.4 million fishmeal, $32.6 million fish oi1, and $3.1 million
canned and frozen fish; imports $0.3 million (1969)
Major industries: mining of metals, petroleum, fishing, textiles and clothing,
food processing, cement, auto assembly, steel, ship-building, metal
fabrication
Electric power: 1,815,000 kw. capacity (1972) ; 6.2 billion kw.-hr. produced
(1972), 423 kw.-hr. per capita
Exports: $930 million (f.o.b., 1972); fish and fish products, copper, silver,
iron, cotton, sugar, lead, zinc, petroleum, coffee
Imports: $832 million (f.o.b., 1972); foodstuffs, machinery, transport equipment,
dron and steel semimanufactures, chemicals, pharmaceuticals
Major trade partners: exports -- U.S. 33%, Western Europe 42%, Japan 14%, Latin
America 6%; imports -- U.S. 32%, Western Europe 33%, Latin America 172,
Japan 6% (1970)
Aid:
economic -- extensions from U.S. (FY46-72), $513.3 million loans, $206.4
million grants; from international organizations (FY46-70), $494.3 million;
from other Western countries (1960-72), $136.1 million; Communist countries
(1954-72) $150.5 million;
military -- assistance from U.S. (FY49-71), $141.3 million
Monetary conversion rate: 38.70 soles=US$1 (trade); 43.38 soles=US$1 (non-trade)
Fiscal year: calendar year
GNP: $8.5 billion (1972), $220 per capita
Agriculture: main crops ~- rice, corn, coconut, sugarcane, abaca, tobacco
Fishing: catch 1 million metric tons, $651 million (1971)
Major industries: agricultural processing, textiles, chemicals and chemical
products
Exports: $1,105 million (f.o.b., 1972); copra, sugar, logs and lumber, coconut
oil, copper concentrates, abaca
Imports: $1,366 million (c.i.f., 1972) ;
Major trade partners: (1972) exports -- 41% U.S., 33% Japan; imports -- 25%
U.S., 30% Japan ‘
Aid:
economic -~ U.S. (FY46-71), $1.6 billion committed; Japan (reparations) ,
$550 million extended in 1956, $337 million drawn through July 1969; IBRD
(1953-71), $239 million committed; IBRD (FY53-72), $268 million
military -- U.S. (FY46-72), $673 million committed
Monetary conversion rate: 6.78 pesos=US$1
Fiscal year: | July - 30 June
GNP: $54.6 billion in 1972 at 1971 prices, $1,650 per capita; 1972 growth rate
7%
Agriculture: self-sufficient for minimum requirements; main crops -- grain,
sugar beets, oilseeds, potatoes, exporter of livestock products and sugar;
importer of grains; 3,200 calories per day per capita (1970)
Fishing: catch 520,400 metric tons (1972)
275
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major industries: chemistry, food processing, transportation equipment, machine
building, iron and steel, textiles, and shipbuilding
Crude steel: 13.5 million metric tons produced (1972), about 410 kg. per capita
Exports: $4,927 million (f.0.b., 1972); 42% machinery and equipment, 34% fuels,
raw materials, and semimanufactures, 15% agricultural and food products,
9% light industrial products
Imports: $5,329 million (f.0.b., 1972); 43% machinery and equipment; 38% fuels,
raw materials, and semimanufactures; 12% agricultural and food products;
7% light industrial products
Major trade partners: $10,256 million (1972); 62% with Conmunist countries, 38%
with West
Monetary conversion rate: 3.32 zlotys=US$1 (conmercial); 19.92 zlotys=US$1
(noncommercial); old commercial rates 4,00 zlotys=US$1 prior to 1972, 3.68
zlotys=US$1 in 1972
Fiscal year: same as calendar year; economic data are reported for calendar
years except for caloric intake which i$ reported for the consumption year,
1 July - 30 June
Note: foreign trade figures were converted! at the 1972 rate
GNP: continental Portugal -- $9,770 million (1972), $1,130 per capita; 75.6%
consumption, 16.9% investment, 14.7% government, -7.2 net exports of goods
and services (1971), growth rate 6.8% (1972) in constant prices
Agriculture: generally underdeveloped; main crops -- grains, potatoes, olives,
grapes for wine; food shortages -- sugar, wheat; caloric intake, 2,730
calories per day per capita (1969)
Fishing: catch 365,000 metric tons, $96.8 million (1970); exports $57.6 million,
imports $65.6 million (1972) ‘
Major industries: cotton textiles, cork pracessing, fish canning, petroleum
refining, pulp and paper, chemical fertilizer
Shortages: coal, petroleum, cotton, steel |
Crude steel: 0.42 million metric tons produced (1972), 50 kg. per capita (1972)
Electric power: 2,900,000 kw. capacity (1972); 8.8 billion kw.-hr. produced
(1972), 900 kw.-hr. per capita
Exports: $1,287 million (f.0.b. 1972); principal items -- cotton textiles, cork
and cork products, canned fish, wine, timber and timber products, resin
Imports: $2,186 million (c.i.f., 1972); principal items -- petroleum, cotton,
industrial machinery, iron and steel, chemicals
Major trade partners: (1972) 17.8% U.K., 11% West Germany, 5.8% France, 10.0%
U.S., 6.9% Angola, 4.1% Mozambique; 46.4% EC-nine; 0.8% Communist countries
Aid:
economic -- U.S., $227.8 million (1949-72), $30.4 million authorized FY72;
IBRD, $57.5 million authorized (1964-66), none since 1966; net official
aid to less developed areas and multilateral agencies $578 million (1961-70),
$79.5 million (1969), $57.1 million (1970);
military -- U.S., $344.0 million authorized (1949-72)
Monetary conversion rate: 1 escudo=US$0.0435 (as of September 28, 1973, floating)
Fiscal year: calendar year
GNP: less than $100 per capita
Agriculture: principal crops -- corn, rice, rubber, coffee, copra
Exports: $3.3 million (f.o.b., 1970); 89% coffee, 6% copra
Imports: $7.2 million (c.i.f., 1970); textiles, beer and wine, petroleum
Major trade partners: Portugal and its possessions, Far Eastern countries
283
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Monetary conversion rate: Portuguese escudo known in Timor as pataca; 28.75
patacas=US$1
Fiscal year: calendar year
GDP: $15 million (FY71), $160 per capita
Agriculture: largely dominated by coconut production with subsistence crops of
taro, yams, sweet potatoes, and bread fruit
Exports: $2.5 million (f.o.b., 1971); copra, coconut products 65%, bananas 17%
Imports: $7.1 million (c.i.f., 1971)
Major trade partners: (1971) exports -- 31% New Zealand, 20% U.K., 12%
Netherlands; imports -- 34% New Zealand, 20% Australia, 15% U.K., 12% Fiji
Monetary conversion rate: 0.82 Tonga dollar=US$1 (1972)
Fiscal year: 1 July-30 June
GDP: $885 million (1971), $920 per capita; real growth rate 1971, 3.1% est.
Agriculture: main crops -- sugarcane, cocoa, coffee, rice, citrus, bananas;
largely dependent upon imports of food
Fishing: catch 3,977 metric tons (1972); exports $1.0 million (1971),. imports
$2.6 million (1971)
Major industries: petroleum, tourism, food processing, cement
Electric power: 290,000 kw. capacity (1971); 1.2 billion kw.-hr. produced (1971),
1,190 kw.-hr. per capita
Exports: $551 million (f.0.b., 1972); petroleum and petroleum products ($281 rd
million, sugar, cocoa
Imports: $756 million (c.i.f., 1972); crude petroleum ($339 million), machinery,
transportation equipment, manufactured goods, food
Major trade partners: (excludes trade under petroleum agreement) exports -- U.S.
33%, U.K. 14%, CARIFTA 23%; imports -- U.S. 33%, U.K. 25%, CARIFTA 10% (1971)
Aid: economic -- from U.S. (FY56-72) $31.2 million loans, $40.6 million grants;
from international organizations (FY53-72), $74.4 million
Monetary conversion rate: floating with pound sterling; on August 22, 1973,
TT$1.94=U.S.$1
Fiscal year: calendar year
GNP: $2.1 billion (1972 est.), $390 per capita; 10.6% average annual growth rate
1970-72
Agriculture: cereal farming and livestock herding predominate; main crops --
wheat, barley, olives, fruits (especially citrus), viticulture, vegetables,
dates
Major sectors: tourism, mining, food processing, textiles and leather, light
manufacturing, construction materials, chemical fertilizers, petroleum
Electric power: 300,000 kw. capacity (1972); 869 million kw.-hr. produced (1972),
155 kw.-hr. per capita
353
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Exports: $303 million (f.0.b., 1972); 28% petroleum, 14% phosphates, 28% olive
oi], 30% other
Imports: $460 million (c.i.f., 1972); 36% raw materials, 23% machinery and :
equipment, 14% consumer goods, 19% food and beverages, 3% energy, 5% other
Major trade partners: exports -- France 19%, Italy 19%, West Germany 13%, Libya
10%; imports -- France 36%, U.S. 15%, Italy 9%, West Germany 7% (1971)
Monetary conversion rate: 0.44 dinar=US$1 (1973 par value)
Fiscal year: calendar year
GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives, i
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years, 2,760 calories per day per capita (1964-66)
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2,800,000 kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $848.6 million (f.o.b., 1972); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,537.1 million (c.i.f., 1972); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -~ West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Monetary conversion rate: 14 Turkish liras=US$1 (official rate as of July 1973)
Fiscal year: 1 March - 28 February
GDP: $1,039 million (1971) at 1966 prices, $100 per capita; 1.7% real growth
between 1970 and 1971
Agriculture: main cash crops -~ coffee, cotton; other cash crops -~ Sugar,
tobacco, fish, tea, livestock; self-sufficient in food
Fishing: catch 137,000 metric tons (1970), $26.2 million (1971)
Major industries: agricultural processing (textiles, sugar, coffee, plywood,
beer), cement, copper smelter, corrugated iron sheet, shoes, fertilizer
Electric power: 170,700 kw. capacity (1972); 817 million kw.-hr. produced
(1972), 78 kw.-hr. per capita
Exports: $261 million (f.0.b., 1971); coffee, cotton, copper, tea; $13.4 million
to Communist countries (1971)
Imports: $250 million (c.i.f., 1971); petroleum products, machinery, cotton
ae metals, transport equipment; $8.3 million from Communist countries
1971
Major trade partners: U.K., U.S., Kenya (Uganda, Kenya, and Tanzania form
East African Economic Community)
357
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Monetary conversion rate: 6.90
Fiscal year: 1 July - 30 June
Uganda shillingssUS$1; 1 Uganda shill ing=US$0.14
Agriculture: principal food crops -- grain (especially wheat), potatoes; main
industrial crops -- sugar beets, cotton, sunflowers, and flax; degree of
self-sufficiency depends on fluctuations in crop yields; given normal yields,
U.S.S.R. is self-sufficient; caloric intake, 3,000-3,200 calories per day
per capita in recent years
359
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Fishing: catch 8,255,000 metric tons (1972); exports 242,200 metric tons (1972),
imports 20,600 metric tons (1972)
Major industries: diversified, highly developed capital goods industries; consumer
goods industries comparatively Tess developed
Shortages: natural rubber, bauxite and alumina, tantalum, tin, and tungsten
Crude steel: 136 million metric ton capacity as of 1 January 1973; 126 million
metric tons produced in 1972, 510 kilograms per capita
Exports: fuels (particularly petroleum and derivatives), metals, agricultural
products (timber, grain) and a wide variety of manufactured goods (primarily 7
capital goods); $15,409 million (f.o.b. 1972)
Imports: specialized and complex machinery and equipment, textile fibers, consumer
manufactures, and any significant shortages in domestic production (for example,
wheat imported following poor domestic harvests); $16,097 million (f.o.b., 1972)
Major trade partners: $31.5 billion (1972); trade 65% with Communist countries,
22% with industrialized West, and 13% with less developed countries
Official monetary conversion rate: 0.715 rubles=US$1; 1 ruble=US$1.3986
(October 1973)
Fiscal year: calendar year
Agriculture: food imported, but some dates, alfalfa, vegetables, fruit, tobacco
raised
Major industries: fishing, trading, oft production; oi1 production began in Abu
Dhabi in 1962, and in 1972 reached 1,050,000 bbls. per day; oil revenues
accruing to Abu Dhabi estimated $600 million in 1972; Dubai has best port
and is commercial center -- oi] was discovered in commercial quantities in
1966; production began in 1969, 1972 production 153,000 B.P.D.; oil revenues
for 1971 estimated at $50 million; small fishing, some boat building, handi-
crafts, animal husbandry, pearlin throughout area
Electric power: 44,100 kw. capacity 11972) ; 110 million kw.-hr. produced (1972),
615 kw.-hr. per capita
Exports: crude petroleum, pearls, fish; non-oil Abu Dhabi $610 million (1972)
and Dubai $41 million total (1972 rev.)
Imports: food, consumer and capital goods; Abu Dhabi $174 million and Dubai $249
million total (1972)
Major trade partners: Japan, U.K., India, U.S.
36]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Aid: multilateral annual average (1967-69) $1.17 million
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.25; Abu Dhabi, 1 Bahrain
dinar=US$2.52 (as of October 1973)
GDP: $325 million (1971 est.), $60 per capita
Agriculture: cash crops -- peanuts, shea nuts, sesame, cotton; food crops --
sorghum, millet, corn, rice; livestock; largely self-sufficient
Fishing: catch 5,000 metric tons (1971)
365
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Major industries: agricultural processing plants, brewery, bottling, and brick
plants; a few other light industries
Electric power: 15,530 kw. capacity (1972); 53 million kw.-hr. produced (1972),
9 kw.-hr. per capita .
Exports: $24 million (f.0.b., 1972); livestock (on the hoof), peanuts, shea
nut products, cotton, sesame
Imports: $72 million (c.i.f., 1972); textiles, food, and other consumer goods,
transport equipment, machinery, fuels
Major trade partners: volume understated because much regional trade is unrecorded; ~
Ivory Coast and Ghana; overseas trade mainly with France and other EC countries;
preferential tariff to EC and franc zone countries
Aid:
economic -- France (1964-September 1970) $46 million; EC (1960-72) $75.1
million; U.S.S.R., Ghana, West Germany, and Israel have also extended aid;
U.S. (FY61-72) $21.9 million; international organizations (1960-72) $26.9
million;
military -- France, $3.7 million (1964-70); U.S., $0.1 million (1962-72)
Budget: 1970 -- current revenue $41 million current expenditure $34 million,
investment expenditure $4 million
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
as of February 1973, floating since then
Fiscal year: calendar year','3db3b39f3b20ed9597ca706bc079be8ac43e174183ffbf83b73173b035567a3d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76eebac078463b2b4ec8f49577aee5b72e3d255aca0f41119264aa8d9bf0f180',1974,'JP','Japan','economy',58,'Aid: no substantial military or economic aid
Budget: FY74 -- revenue $6.4 billion, expenditures $6.8 billion
Monetary conversion rate: 1 SA Rand=US$1.42 (par value), 0.7046 SA Rand=US$1
Fiscal year: 1 April - 31 March
Agriculture: livestock raising (cattle and sheep) predominates, subsistence
crops (millet, sorghum, corn, and some wheat) are raised but most food
must be imported
Fishing: catch 567,600 metric tons (1972) (processed mostly in South African =
enclave of Walvis Bay)
Major industries: meatpacking, fish processing, copper, lead, and diamond
mining, dairy products
Electric power: 155,200 kw. capacity (1972); 543 million kw.-hr. produced (1972),
690 kw.-hr. per capita
Aid: South Africa is only major donor
Monetary conversion rate: 1 South African Rand=US$1.42 (par value); 0.7046 SA
Rand=US$1
Fiscal year: 1 April - 31 March
GNP: $50.6 billion; $1,470 per capita (1972); 66.8% consumption, 22.2% investment,
11.0% government; 1972 real growth rate 7.5%, in 1964 constant prices
Agriculture: main crops -- cereals, oranges, grapes for wine, potatoes, olives,
sugar beets; virtually self-sufficient in good crop years; caloric intake,
2,750 (1969-70) calories per day per capita
Fishing: catch 1.5 million tons, $455 ee (1970); exports $93.3 million (1971
fish and fish products); imports $43.1 |million (1971 fish and fish products) m
Major industries: food processing, textiles and apparel (including footwear),
metal manufacturing, chemicals, shipbuilding, automobiles
Shortages: crude petroleum
Crude steel: 9.5 million metric tons produced, 275 kilograms per capita (1972)
Electric power: 21,886,370 kw. capacity (1972); 68.4 billion kw.-hr. produced
(1972), 1,960 kw.-hr. per capita
Exports: $3,791 million (f.0.b., 1972); principal items -- oranges and other
fruits, iron and steel products, textiles, wines, mercury, “ships, canned
fruits, vegetables . my
Imports: $6,732 million (f.o.b., 1972); principal items -- maohinery and
transportation equipment, petroleum and petroleum products, grains, cotton,
iron and steel
Major trade partners: (1972) 16.0% U.S., 12.1% West Germany, 10.4% France,
8.0% U.K., 5.8% Italy, 3.5% Netherlands; 43.3% EC; 10.0% rest of Europe;
8.6% Latin America; 1.8% Eastern European countries and U.S.5.R.
Aid:
economic -- U.S., $2,070.2 million authorized (FY46-72), IBRD, $376.8 million
authorized (FY64-72), $50.0 million authorized (FY72); military -- U.S.,
$843.2 million authorized (FY53-72)
Monetary conversion rate: 1 peseta=US$0.0172
Fiscal year: calendar year
Agriculture: practically none; some barley is grown in nondrought years; fruit
and vegetables in the few oases; food imports are essential; camels, sheep,
and goats are kept by the nomadic natives; cash economy exists largely for
the garrison forces
Major industries: confined to fishing and handicrafts; exploitation of huge
phosphate deposit is planned
Shortages: water
Electric power: 522 kw. capacity (1972); 0.8 million kw.-hr. produced (1972),
10 kw.-hr. per capita
Exports: $445,600 (1968); dried fish, goatskins
Imports: $1,443,000 (1968); fuel for fishing fleet, foodstuffs
Major trade partners: monetary trade largely with Spain and Spanish possessions
Aid: small amounts from Spain
Monetary conversion rate: 58.03 pesetas=US$1 (official), set February 1973
baer oe billion (1972 current prices), $170 per capita; real growth rate 2.5%
1972
Agriculture: agriculture accounts for about 35% of GNP; main crops -- rice,
rubber, tea, coconuts; 60% self-sufficient in food; food shortages -- rice,
wheat, sugar, fish
Fishing: catch 190,000 metric tons, $64 million (1970); exports $1.4 million,
imports $13.1 million (1972)
Major industries: processing of rubber, tea, and other agricultural commodities;
consumer goods manufacture
Exports: $310.7 million (f.0.b., 1972); tea, rubber, coconut products
Imports: $327.2 million (c.i.f., 1972), machinery and equipment, sugar, flour,
rice, textiles, and clothing
Major trade partners: (1972) exports -- U.K. 14.1%, China 8.2%, Pakistan 8.0%,
U.S. 7.2% U.S.S.R. 1.8%; imports -- U.K. 10.4%, Pakistan 4.1%, China 4.9%,
India 7.0%, U.S. 7.6%, USSR 1.0% “*
Monetary conversion rate: 6.405 rupees=US$1 (effective September 1973)
Fiscal year: 1 January - 30 December (starting 1973)
GDP: $1.6 billion (1969 provisional), under $100 per capita; 8% growth at
current prices 1968-69
Agriculture: main crops -- sorghum, millet, wheat, sesame, peanuts, beans,
barley; not self-sufficient in food production; main cash crops -- cotton,
gum arabic
Major industries: cotton ginning, textiles, brewery, cement, edible oils, soap,
distilling, shoes, pharmaceuticals
Electric power: 197,000 kw. capacity (1972); 590 million kw.-hr. produced (1972),
35 kw.-hr. per capita
Exports: $313 million (f.0.b., FY71); cotton (63%), gum arabic, peanuts,
sesame; $102 million exports to Communist countries (FY71)
Imports: $316 million (c.i.f., FY71); textiles, petroleum products, vehicles,
tea, wheat; $75 million imports from Communist countries (FY71)
Major trade partners: U.K., West Germany, Italy, India, U.S.S.R., China
Monetary conversion rate: 1 Sudanese pound=US$2.87 (official); 0.348 Sudanese
pound=US$1
Fiscal year: 1 July - 30 June
GNP: $308 million (1971); $740 per capita; real growth rate 1971 est., 4%
Agriculture: main crops -- rice, sugarcane, bananas; self-sufficient in major
staple (rice); caloric intake 2,350 calories per day per capita (1968)
Major industries: bauxite mining, alumina and aluminum production, lumbering, »
food processing
Electric power: 220,000 kw. capacity (1972); 1.4 billion kw.-hr. production
(1972), 3,350 kw.-hr. per capita
Exports: $154 million (f.o.b., 1971); bauxite, alumina, aluminum, wood and
wood products, rice
Imports: $113 million (c.i.f., 1971); capital equipment, petroleum, iron and
steel, cotton, flour, meat, dairy products
Major trade partners: exports -- U.S. 39%, Canada 2%, Netherlands 14%; imports
-- U.S. 35%, Netherlands 22%, Europe 18% (1971)
Aid: economic -- extensions from U.S. (FY53-72), $5.0 million loans, $4.7 million
grants; from international organizations (FY49-72), $44.1 million
Monetary conversion rate: 1.79 Surinam guilders (S. #1.) 4US$1 (27 December 1971)
Fiscal year: calendar year
GDP: apne $80 million (1969), about $200 per capita; real growth rate about
8% (1967
Agriculture: main crops -- maize, cotton, rice, sugar, and citrus fruits
Major industry: mining
Electric power: 67,800 kw. capacity (1972); 220 million kw.-hr. produced (1972),
500 kw.-hr. per capita :
Exports: $80.5 million (f.0.b., 1971); iron ore, asbestos, sugar, wood and forest
products, citrus, meat products, cotton
335
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Imports: $67.9 million (f.0.b., 1971); food products, manufactured goods, machinery,
fertilizer, fuel
Major trade partners: Japan, U.K., South Africa
Aid: economic aid -- U.K. $14.7 million (budgeted, 1971-73), others approximately
$1.3 million; no military aid
Budget: FY71 -- revenue $22 million, recurrent expenditure $20.1 million,
development expenditure $3.5 million
Monetary conversion rate: 1 South African Rand=US$1.42 (par value); Swaziland
uses the South African Rand; 0.7046 SA Rand=US$1
Fiscal year: | April - 31 March ¢
GNP: $54.1 billion, $6,650 per capita (1972); 53.5% consumption, 22.1% investment,
23.3% government; 1.1% net exports of goods and services (1971); 1972 growth
rate 2.1% in constant prices
337
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Agriculture: animal husbandry predominates with milk and dairy products
accounting for 40% of farm income; main crops -- grains, sugar beets,
potatoes; 80% self-sufficient; food shortages -- oils and fats, tropical
products; caloric intake, 2,880 calories per day per capita (1967-68)
Fishing: catch 208,900 metric tons, exports $18 million, imports $105 million
Major industries: iron and steel, precision equipment (bearings, radio and
telephone parts, armaments) , shipbuilding, wood pulp and Paper products,
processed foods, textiles, chemicals
Shortages: coal, petroleum, textile fibers, potash, salt -
Crude steel: 5.2 million metric tons produced (1972), 640 kilograms per capita :
Electric power: 17,559,000 kw. capacity (1972); 70.7 billion kw.-hr. produced
(1972), 8,200 kw.-hr. per capita
Exports: $8,749 million (f.0.b., 1972); machinery, motor vehicles
and ships, wood pulp, paper products, iron and steel products, metal ores
and scrap, chemicals
Imports: $8,062 million (c.i.f., 1972); machinery, motor vehicles, petroleum and
petroleum products, textile yarn and fabrics, iron and steel, chemicals, food,
and live animals
Major trade partners: (1971) West Germany 15.0%, U.K. 13.8%, U.S. 7.2%, Norway
8.3%, Denmark 9.0%; EFTA 42.4%; EC 29.7%; Communist countries 4.8%
Aid: economic -- U.S., $231.1 million authorized (FY46-72); $18.5 million in 1971;
$24.7 million in 1972; net official aid to less developed countries and multi-
lateral agencies, $662.4 million (1960-70), $159 million in 1971, $198 million
in 1972
Monetary conversion rate: 1 kronor=US$0. 2385 (spot rate September 28, 1973)
Fiscal year: 1 July - 30 June
GNP: $38.1 billion (1972), $5,980 per capita (1972); 57% consumption, 30%
investment, 11% government, net foreign balance 2% (1972); 1972 growth rate
4.7%, constant prices
339
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Agriculture: dairy farming predominates; less than 50% self-sufficient; food
shortages -- fish, refined sugar, fats and oils (other than butter), grains,
eggs, fruits, vegetables, meat; caloric intake, 3,190 calories per day per ‘
capita (1969-70)
Major industries: machinery, chemicals, watches, textiles, precision instruments
Shortages: practically all important raw materials except hydroelectric energy
Crude steel: 532,000 metric tons produced (1971), 70 kg. per capita
Electric power: 11,216,000 kw. capacity (1972); 39.3 billion kw.-hr. produced
(1972), 5,200 kw.-hr. per capita pe
Exports: $6.8 billion (f.o.b., 1972); principal items -- machinery and equip-
ment, chemicals, precision instruments, textiles, foodstuffs
Imports: $8.5 billion (c.i.f., 1972); principal items -- machinery and trans-
portation equipment, metals and metal products, foodstuffs, chemicals,
textile fibers and yarns
Major trade partners: West Germany 23%, France 11%, U.S. 8%, Austria 5%, Italy
9%, U.K. 8%; EC 50%; EFTA 20%; Communist countries 3% (1972)
Aid: economic -- authorized, U.S. $47 million through FY72; net official economic
aid delivered to less developed areas and multilateral agencies $194 million
(FY62-72), $67 million in FY72
Monetary conversion rate: 3.03 Swiss francs=US$1 (September 1973, floating)
Fiscal year: calendar year
GDP: $2.1 billion (1972), $310 per capita; real GDP growth rate 14% 1972 est.
Agriculture: main crops -- cotton, wheat, barley and tobacco; sheep and goat
raising; self-sufficient in most foods in years of good weather
Major industries: textiles, petroleum (119,000 BPD. production, refining
capacity 54,000 bbIs. per day, 1971) food processing, beverages, tobacco
341
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Electric power: 360,000 kw. capacity (1972); 838 million kw.-hr. produced
(1972), 120 kw.-hr. per capita
Exports: $254 million (f.0.b., 1972); cotton, fruits and vegetables, grain, ;
wool, and livestock
Imports: $477 million (c.i.f., 1972 est.); machinery and metal products,
textiles, fuels, foodstuffs
Major trade partners: exports -- U.S.S.R., Italy, and Lebanon; imports -- Lebanon,
West Germany, Italy, U.S.S.R., Japan, and France
Budget: 1972 est. -- revenues $415 million, expenditures $565 million ~
Monetary conversion rate: 3.82 Syrian pounds=US$1 (controlled rate) used
throughout; changed to 3.85 Syrian pounds=US$1 in February 1973; 4.04 Syrian
pounds=US$1 (free rate July 1973)
Fiscal year: calendar year
Mainland:
GDP: $1,138 million at 1966 prices (1971), about $80 per capita; growth rate in
constant 1966 prices for 1970-71 4.5%
Agriculture: main crops -- cotton, coffee, sisal on mainland; largely self-
sufficient in food
Fishing: catch 195,000 metric tons, $15.7 million (1970); exports $1.7 million,
imports $724,000 (1971)
Major industries: primarily agricultural processing (Sugar, beer, cigarettes,
sisal twine), diamond mine, oi] refinery, shoes, cement, textiles, wood
products
Electric power: 124,000 kw. capacity (1972); 460 million kw.-hr. produced (1972),
34 kw.-hr. per capita
Exports: $320 million (f.0.b., 1972); coffee, cotton, sisal, cashew nuts, meat,
diamonds, cloves, tobacco, tea
Imports: $406 million (c.i.f., 1972); manufactured goods, machinery and transport
equipment, cotton piece goods, crude oil, foodstuffs (meinly for Zanzibar)
Major trade partners: exports -- China, U.K., Hong Kong, Irdia, Kenya, U.S.;
imports -- U.K., China, Kenya, West Germany, U.S., Japan
Monetary conversion rate: 1 Tanzanian shilling=US$0.14; 6.90 Tanzanian
shillings=US$1
Fiscal year: 1 July - 30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops -- cloves, coconuts
Industries: agricultural processing
Electric power: see Tanganyika (above)
Exports: $12.6 million (1968); cloves and clove products, coconut products
Imports: $5.6 million (1968); mainly foodstuffs and consumer goods
Major trade partners: imports -- China, Japan, and mainland Tanzania;
exports -- Singapore, China, Hong Kong, Indonesia, India, Pakistan
Aid: U.K. principal source of aid until 1964; China is currently major source
Exchange rate: 1 Tanzanian shilling=US$0.14; 7.143 Tanzanian shillings=US$1
Fiscal year: 1 July - 30 June
GDP: $7.4 billion (1972 est. in current prices), $200 per capita; estimated 4%
real growth in 1972
Agriculture: world''s largest rice exporter in 1972; main crops -- rice, rubber,
corn; almost 100% self-sufficient in food
Fishing: catch 1.6 million metric tons, exports, 32,000 tons, $22 million (1971)
Major industries: agricultural processing, textiles, wood and wood products,
cement, tin mining; world''s fourth largest tin producer
Shortages: fuel sources, including coal and petroleum
Electric power: 1,975,000 kw. capacity (1973) ; 6,300,000 kw.-hr. produced
(1973), 170 kw.-hr. per capita
Exports: $1,063 million (f.o.b., 1972); rice, corn, rubber, tin, cassava, kenaf
345
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (cont''d):
Imports: $1,484 million (c.i.f., 1972); excluding U.S. military imports;
machinery and transport equipment, textiles, fuels and lubricants, base
metals, chemicals
Major trade partners: exports -- Japan, U.S., Singapore, Hong Kong, Netherlands,
Malaysia; imports -- Japan, U.S., West Germany, U.K.; about 1% or less trade
with Communist countries
Monetary conversion rate: 20.0 baht=US$1
Fiscal year: 1 October - 30 September
GDP: $290 million (1971), about $140 per capita; estimated real growth 1966-70,
5.3% average annual rate
Agriculture: main cash crops -- coffee, cocoa; major food crops -- yams, cassava,
corn, beans, rice, fish; must import some foodstuffs
Major industries: phosphate mining, agricultural processing, handicrafts,
textiles, beverages
Electric power: 18,750 kw. capacity (1972); 42 million kw.-hr. produced (1972),
20 kw.-hr. per capita
347
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
ECONOMY (Cont''d):
Exports: $50 million (f.0.b., 1972); phosphates, cocoa, coffee, palm kernels,
and cassava
Imports: $85 million (c.i.f., 1972); consumer goods, fuels, machinery, tobacco,
foodstuffs
Major trade partners: mostly with France and other EC countries
Aid: (1970 disbursements) France $2.3 million, West Germany $2.0 million, U.S.
$1.0 million (FY59-72 total commitments $19.5 million), EC $3.5 million,
U.N. $1.0 million, others $1.1 million
Budget: 1972 -- revenue $48.1 million, current expenditure $41.8 million,
investment expenditure $6.3 million
Monetary conversion rate: 1 Conmunaute Financiere Africaine franc=0.02 French
francs; 255.785 CFA francs=US$1 as of February 1973 (since then currency
floating)
Fiscal year: calendar year','3fd128b923b74edf9df7c8535a2de492bf5f23d900efb75a8599dfd2606cae01','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9aaa885f63824f4441d9a732892d6c52c82ae9e0e05de10247f41950e335b45',1974,'SA','Saudi Arabia','economy',62,'Aid:
economic -- $398 million credits extended through August 1972, $170 million
drawn through 1970; major donors include U.S.S.R.> China, U.S.> West
5 Germany, Saudi Arabias
: military -- $77 million from U.S.S.R.3 $30 million from Eastern Europe;
$7 million western military aid through 1971
Monetary conversion rate: 1 Yemeni rial=US$0.22 as of October 1973
Fiscal year: 1 July - 30 June
383
A
pproved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600','b25b81487ab897eeb18b5925f02179a9a1c58159b75d21e1233962962a8708a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38ff1d2cb33e437e2ba2081a81cfbb117f424f08881a519b4bb01514171babe5',1974,'US','United States','economy',67,'GNP: $1,152 billion (1972); 63% consumption, 15% private investment, 22% government ;
$5,510 per capita; 1972 growth rate 6.4% (constant 1958 dollars)
Fishing: catch 2.8 million metric tons (1971); imports $914 million (1971); exports
$136 million (1971)
Crude steel: 121 million metric tons produced (1972), 580 kg. per capita
Electric power: 339,606,340 kw. capacity (1972); 1.8 trillion kw.-hr. produced
(1972), 8,310 kw.-hr. per capita est.
Exports: $49.2 billion (f.0.b.; 1972); machinery and transport equipment,
chemicals, cereals, mineral fuels
Imports: $58.9 billion (c.i.f., 1972); transport equipment, machinery, mineral
fuels, steel, nonferrous metals, metal ores
Major trade partners: (1970) Canada 24%, EC 18%, Japan 13%, U.K. 6%
Official deve lopment assistance (aid): obligations and loan authorizations (1971),
economic $4,811 million, military $4,436 million
Fiscal year: 1 July - 30 June
391
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010','5914146692b42fde625909ad3ce79ea2375184b571ae61e06ee1eaf146fde545','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfab176b611470e95843763e36dad51b165da9a8da024d1156d8da740c750c60',1974,'','','economy',4,'GNP: $1.1 billion (FY72), well below $100 per capita; real growth rate
¥ about 4-5% in FY72
Agriculture: agriculture and animal husbandry account for over 50% of GNP and
occupy nearly 80% of the labor force; main crops -- wheat and other grains,
cotton, fruits, nuts; largely self-sufficient; food shortages -- wheat,
sugar, tea
P Major industries: cottage industries, food processing, textiles, cement, coal
mining
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $81.8 million (f.o.b., FY72); fruits and nuts, natural gas, karakul,
cotton, carpets and rugs, wool
Imports: $127.1 million (c.i.f., FY72); wheat, textiles, chemicals, tea,
petroleum, transportation equipment
Major trade partners: exports -- U.S.S.R., India, U.K., Pakistan; imports --
U.S.S.R., Japan, India, U.S.
Monetary conversion rate: 45 Afghanis=US$1 (official); 60 Afghanis=US$1
(August 1973)
Fiscal year: 21 March - 20 March
GNP: $1.2 billion in 1972 (at 1972 prices), $530 per capita
Agriculture: food deficit area; main crops -- corn, wheat, tobacco, sugar beets,
cotton; food shortages -- wheat; caloric intake, 2,100 calories per day per
capita (1961/62)
Major industries: agricultural processing, textiles and clothing, lumber, and
extractive industries
Shortages: spare parts, machinery and equipment, wheat
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $91 million (1970 est.); 1964 trade -- 55% minerals, metals, fuels;
17% agricultural materials (except foods); 23% foodstuffs (including
cigarettes); 5% consumer goods
Imports: $159 million (1970 est.); 1964 trade -- 50% machinery, equipment, and
spare parts; 16% minerals, metals, fuels, construction materials; 7%
fertilizers, other chemicals, rubber; 4% agricultural materials (except
foodstuffs); 16% foodstuffs; 7% consumer goods
Monetary conversion rate: 5 Teks=US$1 (commercial); 12.5 leks=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year
1 July - 30 June','21e459d674352347019859cb5e862fcd99eaaaefe6c2417eb4f46643873c309b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7e875f012f92273de48df59445256b443b9bac24b352fefadbe7eeba251522c',1974,'DZ','Algeria','economy',9,'GNP: $6.3 billion (est. 1972), $410 per capita, average annual increase
since 1968 (current prices), 11%
Agriculture: main crops -- wheat, barley, grapes, citrus fruits
Major industries: petroleum, light industries, natural gas, mining, petrochemical
and steel plants under construction
Electric power: 1,770,000 kw. capacity (1972); 2.7 billion kw.-hr. produced
(1972), 178 kw.-hr. per capita
Exports: $1,473 million (f.o.b., 1972); crude petroleum 75%, other items -- wine,
citrus fruit, iron ore, vegetables; to France 24%, West Germany 24%, Benelux
9%, Italy 8%, U.S.S.R. 7%
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Imports: $1,760 million (c.i.f., 1972); major items -- capital goods 37%,
semi-finished goods 27%, foodstuffs 13%; from France 38%, West Germany 9%,
Italy 9%, U.S. 8%
Monetary conversion rate: 4.547 dinars=US$1 in 1972, and 4.093 dinars=US$1
through January 1974
Fiscal year: calendar year
GNP: $5.5 billion (1972), $1,880 per capita; 64.8% consumption, 23.9% investment,
15.0% government; -3.7% net export of goods and services; 1972 real growth rate 3%
Agriculture: about 2/3 of agricultural area used for permanent hay and pasture;
main products -- livestock and dairy products, barley, potatoes, sugar beets,
wheat; 85% self-sufficient; food shortages -- grains, fruits, vegetables;
caloric intake 3,510 calories per day per capita (1970)
Fishing: catch 89,500 metric tons; exports of fish and fish products $13.3 million
(1971), imports of fish and fish products $4.4 million (1971)
167
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major industries: food products, brewing, textiles and clothing, machinery and
transportation equipment
Shortages: coal, petroleum, timber and woodpulp, steel and nonferrous metals,
fertilizers, cereals and animal feeds, textile fibers and textiles
Crude steel: 77,000 metric tons produced in 1972, 30 kilograms per capita
Electric power: 1,797,500 kw. capacity (1973); 7.2 billion kw.-hr. produced
(1973), 2,150 kw.-hr. per capita
Exports: $2,135 million (f.o.b., 1973); live animals, meat, textile products,
clothing, machinery, dairy products, chemicals
Imports: $2,736 million (c.i.f., 1973); machinery, chemicals, textiles,
transportation equipment, petroleum, metal manufactures, cereals
Major trade partners: 72.5% EC-nine (U.K. 55.4%, West Germany 6.3%);
8.4% U.S.; 1.3% Communist countries (1972)
Aid: economic ~- U.S., $187.8 million authorized (FY49-72), no activity (FY55-66),
$4.3 million authorized (FY67-72), $12.6 million authorized in FY69, none
authorized in FY70-72; IBRD $72.5 million authorized (FY64-72) $28 million
authorized (FY72)
Monetary conversion rate: 1 Irish pound=US$2.453 (1973 average)
Fiscal year: 1 April - 31 March','7df2ad26d4cfa7bcb55f4afdb1e79e779eb4705dd15a62bbc21660b12101c7f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9560fc6fcd9cfe993c4a6ea2f94408b6c6d02f7e21971171e68e2a15fb41fa59',1974,'AD','Andorra','economy',13,'Agriculture: sheep raising; small quantities of tobacco, rye, wheat, barley,
oats, and some vegetables (only 25% of land can be used for agriculture
Major industries: tourism ($1 million annually), one cigarette factory (annual
output $1 million), handicrafts, smuggling (tobacco to France; manufactured
items, including automobiles and cameras, to Spain)
Shortages: food
Electric power: 25,000 kw. capacity (1973); 100 million kw.-hr. produced (1973),
370 kw.-hr. per capita; power is mainly exported to Spain and France
Major trade partners: Spain, France','757b7264e29d4b30b3e20241d7001be2af0905d64e15022e0be9344ceb89bebb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ab176001081183a722e16683fac5672ae16a4a65fc196c963f19cb77c2384d2',1974,'AO','Angola','economy',17,'GNP: $1.2 billion (1972 est.), about $210 per capita, 6.1% real growth (1970-72)
Agriculture: cash crops -- coffee, sisal, corn, cotton, sugar, manioc, and
tobacco; food crops -- cassava, corn, vegetables, plantains, bananas, and
other local foodstuffs; largely self-sufficient in food
Fishing: catch 368,000 metric tons, $8.4 million (1970); exports $18.7 million;
imports $5.5 million (1971)
Major industries: mining (oi1, iron, diamonds), fish processing, brewing, tobacco,
sugar processing, cement, food processing plants, building construction
Electric power: 443,000 kw. capacity (1973); 865 million kw.-hr. produced
(1973), 145 kw.-hr. per capita
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $650 million (est. f.o.b., 1973); coffee, oi], diamonds, sisal, fish and
fish products, iron ore, 011, timber, and corn
Imports: $500 million (est. c.i.f., 1973); capital equipment (machinery and
electrical equipment), wines, bulk iron and ironwork, steel and metals,
vehicles and spare parts, textiles and clothing, medicines
Major trade partners: main partner Portugal, followed by West Germany, U.S.,
U.K., Japan
Aid: Portugal only donor
Budget: balanced at $453.3 million (1973)
Monetary conversion rate: 25.96 escudos=US$1 as of December 1973 (floating since
February 1973)
Fiscal year: calendar year','0c02ab7b63c953fb6812c2ac6bb2de8b3f88536a3fab37c02a57b828326a01d8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8748cae0cdac5ebba38ee849dfb4677e13014882ffd1ea2fb150eb9381384809',1974,'BR','Brazil','economy',22,'GDP: $27.6 million (at market prices, 1970), $430 per capita
Agriculture: main crops -- sugar, cotton
Major industries: oi] refining, tourism
Shortages: electric power
Electric power: 22,440 kw. capacity (1972); 45 million kw.-hr. produced (1972),
540 kw.-hr. per capita
Exports: $2.9 million (f.o.b., 1968); sugar, molasses, cotton
Imports: $20.0 million (c.i.f., 1968); food, clothing, oi1, wood
Major trade partners: U.K. 30%, U.S. 25%, Commonwealth Caribbean countries
18% (1966)
Aid: economic -- U.S. (FY46-71), $1.5 million in loans
Monetary conversion rate: 2.08 East Caribbean dollars=US$1 (February 1974), now
floating with pound sterling
1]
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GNP: $1.17 billion (in 1972 dollars, 1973) $240 per capita; 78% private
consumption, 11% public consumption, 13% gross domestic investment, -2%
net foreign balance (1970); real growth rate 1973, 6.0%
Agriculture: main crops -- potatoes, corn, rice, sugarcane, yucca, bananas;
imports significant quantities of foodstuffs including lard, vegetable oils,
and wheat; caloric intake, 1,800 calories per day per capita (1971)
Major industries: mining, smelting, petroleum refining, food processing, textiles,
and clothing
Electric power: 270,000 kw. capacity (1972); 870 million kw.-hr. produced
(1972), 180 kw.-hr. per capita
Exports: $306.7 million (f.o.b., 1973); tin, petroleum, lead, zinc, silver,
tungsten, antimony, bismuth, gold, coffee, sugar, cotton
Imports: $266.7 million (f.o.b., 1973 est.); foodstuffs, chemicals, capital goods,
pharmaceuticals
Major trade partners: exports -- U.K. 46%, U.S. 39%, WWest Germany 5%, Argentina 2%;
imports -- U.S. 41%, West Germany 12%, Japan 11%, Argentina 6% (1970)
Aid:
economic -- extensions from U.S. (FY46-73) $283.5 million in loans, $304.4
million in grants; from international organizations (FY46-73), $273.6
million; from other Western countries (1960-72), $53.3 million; Communist
countries (1970-71), $60.2 million; military -- assistance from U.S. (FY52-72),
$31.7 million
Monetary conversion rate: 20 pesos=US$1
Fiscal year: calendar year
GNP: $60 billion (1973), $590 per capita; 22% gross investment, 80% consumption,
-2% net foreign balance (1973); real growth rate 1973, 11.4%
4)
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Agriculture: main products -- coffee, rice, beef, corn, milk, sugarcane, soybeans;
nearly self-sufficient; caloric intake, 2,900 calories per day per capita (1962)
Fishing: catch 650,000 metric tons (1971); exports (f.o.b.) $26.7 million, imports
(f.0.b.) $27.5 million (1971)
Major industries: textiles and other consumer goods, cement, lumber, steel,
motor vehicles, other metalworking industries
Crude steel: 8.0 million metric tons capacity (1973 est.); 7.15 million metric
tons produced (1973); 70 kilograms per capita (1973)
Electric power: 15.8 million kw. capacity (1973 est.); 65.8 billion kw.-hr. produced
(1973), 880 kw.-hr. per capita
Exports: $6,198 million (f.0.b., 1973); coffee, manufactures, iron ore, cotton,
soybeans, sugar, wood, cocoa, beef, shoes
Imports: $6,016 million (c.i.f., 1973); machinery, chemicals, pharmaceuticals,
petroleum, wheat
Major trade partners: exports -- U.S. 24%, West Germany 8%, Italy 7%,
Netherlands 6%, Japan 5%, U.K. 4%; imports -- U.S. 29%, West Germany 11%,
Japan 7%, U.K. 6%, Italy 4% (1972)
Aid: economic -- extensions from U.S. (FY46-72) -- loans $3, 483.4 million,
grants $636.0 million; from international organizations (FY46-72) $2,628.2
million; from other Western countries (1960-71) -- $617.0 million; from
Communist countries (1959-72) $330.6 million; drawings (February 1973)
$110 million
Monetary conversion rate: 6.455 cruzeiros=US$1 (April 1974, changes frequently)
Fiscal year: calendar year
GDP: $31 million (1970) $195 per capita
Agriculture: largely dominated by coconut production with subsistence crops
of yams, taro, bananas; self-sufficient in rice
Electric power: 12 million kw.-hr. produced (1973), 72 kw.-hr. per capita
Exports: $10 million (1971); copra, timber, cocoa
Imports: $15 million (1971)
Major trade partners: exports -- Japan, Australia; imports -- Australia, U.K.
Monetary conversion rate: 0.67 Australian dollar=US$1
GNP: $177 million (1971 est.), $1,430 per capita, average annual growth rate
(1969-71) 6%
Agriculture: main crops -- rubber, rice, pepper, must import most food
Major industry: crude petroleum
Exports: $167 million (f.o.b. 1972); 96% crude petroleum
Imports: $107 million (c.i.f. 1972); 47% machinery and transport equipment,
30% manufactured goods, 8% food
Major trade partners: exports of crude petroleum go to Sarawak for refining
and reexport; imports from Japan 30%, U.S. 24%, U.K. 15%, Singapore 9%
Monetary conversion rate: 2.54 Brunei dollars=US$1
Fiscal year: calendar year
45
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
LAND:
286,000 sq. mis; 2% cultivated, 7% other arable, 15%
permanent pasture, grazing, 29% forest, 47% barren
mountains, deserts, and cities
Land boundaries: 3,930 mi.
Agriculture: food crops -~ rice, manioc, potatoes, fruits, vegetables; export
crops -- essential oils for perfumes (mainly ylang-ylang), vanilla, copra,
sisal
Exports: $6.1 million (1971) perfume oils, vanilla, copra, sisal
Imports: $11.1 million (1971) foodstuffs, cement, fuels, chemicals, textiles
Major trade partners: France, Malagasy Republic, Italy, Kenya, Tanzania and U.S.
Electric power: est. 1,000 kw. capacity (1973); est. 2 million kw.-hr. produced
(1973); 7 kw.-hr. per capita
Aid: French aid in 1971 was about $2.7 million, or about 50% of the island''s
entire budget
Monetary conversion rate: 255.785 Communaute Financiere Africaine (CFA) francs=US$1
as of February 1973 (floating since February 1973)
Government budget: Colony -- revenues, $1.0 million (FY68); expenditures,
$1.1 million (FY68)
Agriculture: Colony -- predominantly sheep farming; dependencies -- whaling
and sealing
Major industries: Colony -- wool processing; dependencies -- whale and seal
processing
Electric power: 1,000 kw. capacity (1972); 2.5 million kw.-hr. produced (1972),
1,085 kw.-hr. per capita
Exports: Colony -- $2.28 million (1969); wool, hides and skins, and other;
dependencies -- no exports in 1968 or 1969
Imports: Colony -- $1.22 million (1969); food, clothing, fuels, and machinery;
dependencies -- $8,368 (1969); mineral fuels and lubricants, food,
and machinery
Major trade partners: nearly all exports to the U.K., 77% of imports from the
U.K.3 dependencies -- exports to the Netherlands (63%) and Japan (37%),
imports from Curacao, Japan, and the U.K.
Monetary conversion rate: 1 Falkland Island pound=US$2.60
GNP: $257 million (1972), $340 per capita; real growth rate 1972 est.
~2 5%
Agriculture: main crops -- sugarcane, rice, other food crops; food shortages --
wheat flour, potatoes, processed meat, dairy products; caloric intake, 2,180
calories per day per capita (1967)
Fishing: catch 18,140 metric tons (1971), $10 million (1972); exports $4.8
million (1972), imports $1.2 million (1971)
Major industries: bauxite mining, alumina production, sugar and rice milling
147
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Electric power: 115,000 kw. capacity {1971}; 340 million kw.-hr. produced
(1971), 460 kw.-hr. per capita
Exports: $142 million (f.0.b., 1972); bauxite, sugar, alumina, rice shrimp,
molasses, timber, diamonds, rum
Imports: $146 million (c.i.f., 1972); manufactures, machinery, food, petroleum
Major trade partners: exports -- U.S. 22%, U.K. 28%, CARIFTA 23%, Canada 34;
imports -- U.S. 24%, U.K. 31%, CARIFTA 17%, Canada 5% (1972)
Aid: economic -- from U.S. (FY53-72), $56.3 million loans, $24.7 million grants;
from U.K. (CY60-70), $73.9 million; from China (1972), $26.0 million extended;
from international organizations (FY46-72), $32.7 million
Monetary conversion rate: floating with pound, 1 pound=G$5 .21
Fiscal year: calendar year
GDP: $487 million (1972), $100 per capita; real growth rate 1972 5.1%
Agriculture: main crops -- coffee, sugarcane, rice, corn, sorghum, pulses;
caloric intake, 1,850 calories per day per capita
Major industries: sugar refining, textiles, flour milling, cement manufacturing,
bauxite mining, tourism, light assembly industries
Electric power: 64,440 kw. capacity (1973 est.); 162 million kw.-hr produced
(1973), 33 kw.-hr. per capita
Exports: $43 million (f.o.b., FY72); coffee, light industrial products, bauxite,
sugar, essential oils, sisal
149
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Imports: $70 million (f.o.b., FY72); consumer durables. foodstuffs,
industrial equipment, petroleum products, construction materials
oe trade partners: U.S, 52% (FY71)
id:
economic -- from U.S., $34.5 million loans, $93 million grants (FY46-72);
international organizations, $31.2 million (FY46-72); from other Western
countries (1960-71) $2.4 million;
military -- U.S., $4.2 million (FY53-72)
Monetary conversion rate: 5 gourdes=US$1
Fiscal year: 1 October - 30 September
GNP: $785 million (1972 prel.), $280 per capita; 74% private consumption, 12%
government consumption, 15% domestic investment; -1% net foreign balance
(1972); real growth rate 1972, 4.3%
Agriculture: main crops -- bananas, coffee, corn, beans, cotton, sugarcane,
tobacco; caloric intake, 2,300 calories per day per capita (1964-65)
15]
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Fishing: exports $1.7 million (1972); imports $0.5 million (1970)
Major industries: agricultural processing, textiles, clothing, wood products
Electric power: 156,000 kw, capacity (1972); 370 million kw.-hr. produced
(1972), 130 kw.-hr. per capita
Exports: $206 million (f.0.b., 1972); bananas, coffee, corn, cotton, lumber,
minerals, beef
Imports: $193 million (c.i.f., 1972); manufactured products, machinery,
transportation equipment. chemicals, fuels
Major trade partners: exports -- U.S. 55%, West Germany 13%, CACM 3%; imports
-- U.S. 43%, CACM 11%, Japan 8%, West Germany 5% (1972)
Aid:
economic -- extensions from U.S. (FY46-72), $65.0 million loans, $65.2
million grants; from international organizations (F¥46-72), $175.1 million;
from other Western countries (1960-71), $7.0 million;
military -- assistance from U.S. (FY46-71), $9.7 million
Monetary conversion rate: 2 lempiras=US$1 (official)
Fiscal year: calendar year —
GNP: $988 million (1973), $4,680 per capita; 62.6% consumption, 31.5%
investment, 10.4% government, -4.5% net foreign balance (1973); 1973 growth
rate 5.1%, constant prices
Agriculture: cattle, sheep, dairying, hay, potatoes, turnips; food shortages -~-
grains, sugar, vegetable and other fibers; caloric intake, 2,900 alories
per day per capita (1964-66)
157
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Fishing: catch 880,000 metric tons; exports $205 million est. (1973)
Major industries: fish processing, aluminum smelting, diatomite production
Shortages: grain, fuel, wood, minerals, vegetable fibers
Electric power: 454,000 kw. capacity (1972) 1.8 billion kw.-hr. produced
(1972), 7,700 kw.-hr. per capita
Exports: $291 million (f.0.b., 1973); fish and fish products, animal products,
aluminum, diatomite
Imports: $359 million (c.i.f., 1973); machinery and transportation equipment,
petroleum, foodstuffs, textiles
Major trade partners: (1972) Exports: EFTA 36%, U.S. 30%, EC 14%, U.S.S.R. 7%
Imports: EFTA 43%, EC 29%, U.S. 8%, U.S.S.R. 6%
Aid: economic -- U.S. authorized (1949-73) $90.1 million, $1.2 million in FY72,
$0.9 million (1973 prelim. ); IBRD $30 million through September 1973
Budget: (1973 est.) expenditures $260 million, revenues $303 million
Monetary conversion rate: 1 kronur=US$0.0115 (spot rate on 31 July 1973)
Fiscal year: calendar year
GNP: $328 million (at market prices, 1971), $930 per capita; real growth rate
(1971) 8.5%
Agriculture: bananas, sugarcane, and pineapples
Major industries: agricultural processing, particularly sugar milling and rum
distillation; cement, oi1 refining and tourism
Electric power: 32,000 kw. capacity (1972); 128 million kw.-hrs. produced (1972),
360 kw.-hrs. per capita
223
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $42 million (f.0.b., 1972), bananas, sugar, rum, pineapples
Imports: $173 million (c.i.f., 1972), foodstuffs, clothing and other consumer
goods, raw materials and supplies, and petroleum
Major trading partners: exports -- France 82%, Italy 9%, other 9%; imports --
a aay United States 6%, Netherlands Antilles 3%, Netherlands 3%, other
18% (1968
Monetary conversion rate: 4,708 French francs=US$1 (1973)
Fiscal year: calendar year
GDP: about $230 million (1972), average annual increase in current prices about
5.0% (1968-72), about $190 per capita
Agriculture: most Mauritanians are nomads or subsistence farmers; main products
-- livestock, small grains, dates; cash crop -- gum arabic; livestock
Fishing: catch, traditional river fishing, 15,000 metric tons (1969), traditional
sea fishing, 2,750 metric tons (valued at $437,000); fish supplied to processing
plants by foreign fishing fleets from France, Spain, Canary Islands using
Mauritanian waters; exports 22,100 metric tons, $8 million (1970)
Major industries: mining of iron ore, salt fishing, exploitation of copper
resources planned
Electric power: 38,000 kw. capacity (1973); 78 million kw.-hr. produced (1973),
64 kw.-hr. per capita
225
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $99 million (f.0.b., 1972); iron ore, fish, gum arabic
Imports: $89 million (c.i.f., 1972); sugar, cloth, tea, and fuels
Major trade partners: (trade figures not complete because Mauritania has a form
of customs union with Senegal and much local trade unreported) France and
other EC members, U.K., and U.S. are main overseas partners
Budget: 1974 est. -- receipts $67.9 million, current expenditures $67.4 million,
investment expenditures $7.2 million
Monetary conversion rate: 255.785 CFA francs=US$1 as of February 1973
(currency floating since February 1973) (official); since June 1973, 46.04
ouguiya=US$1
Fiscal year: calendar year
GNP: $224 million (July 1972-June 1973), $260 per capita
Agriculture: sugar crop is major economic asset; about 40% of land area is planted
to sugar; tea production rising slowly; most food imported -- rice is the
staple food -- and since cultivation is already intense and expansion of
cultivable areas is unlikely, heavy reliance on food imports except sugar
and tea will continue
Shortage: land
Industries: mainly confined to processing sugarcane, tea; some small-scale,
simple manufactures; tobacco fiber; some fishing; tourism, diamond cutting,
weaving and textiles, electronics
Electric power: 61,340 kw. capacity (1973); 174 million kw.-hr. produced (1973),
200 kw.-hr. per capita
Exports: $106 million (f.o.b., 1972); mainly sugar, tea, molasses
Imports: $120 million (c.i.f., 1972); foodstuffs 30%, manufactured goods about 25%
Major trade partners: all EC-nine countries and U.S. have preferential treatment,
U.K. buys over 50% of Mauritius! sugar export at heavily subsidized prices;
small amount of sugar exported to Canada, U.S., and Italy; imports from U.K.
and EC primarily, also from South Africa, Australia, and Burma; some minor
trade with China
Monetary conversion rate: 5.74 Mauritian rupees=US$1 in December 1973 (floating
with pound sterling)
Fiscal year: 1 July - 30 June
GNP: $250 million (1967), $1,170 per capita; real growth rate 1967, 3.6%
Agriculture: little production
Major industries: petroleum refining on Curacao and Aruba; tourism on Curacao,
Aruba, and St. Martin; phosphate mining on Curacao
Electric power: 295,000 kw. capacity (1972); 1.4 billion kw.-hr. produced (1972),
5,550 kw.-hr. per capita
Exports: $724 million (f.o.b., 1971); petroleum products, phosphate
Imports: $1,024 million (c.i.f., 1971); crude petroleum, food manufactures
Major trade partners: exports -- U.S. 43%, EC 16%, Latin America 13%, U.K. 10%,
Canada 7%; imports -~ Venezuela 72%, U.S. 10%, Netherlands 4% (1968)
Monetary conversion rate: 1.79 Netherlands Antillean florins (NAF)=US$1, official
Fiscal year: calendar year
GNP: $8.0 billion (1973, in 1972 dollars), $570 per capita; 73%
private consumption, 10% public consumption, 12% gross investment (1972), 5%
net foreign balance; real growth rate 1973 5.6%
Agriculture: main crops -- wheat, potatoes, beans, barley, coffee, cotton,
sugarcane; imports wheat, meat, lard and oils, rice, corn; caloric intake,
2,300 calories per day per capita (1964)
271
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Fishing: catch 1.7 million metric tons (1973); exports $136.0 million (1973)
Major industries: mining of metals, petroleum, fishing, textiles and clothing,
food processing, cement, auto assembly, steel, ship-building, metal
fabrication
Electric power: 1,815,000 kw. capacity (1972); 6.2 billion kw.-hr. produced
(1972), 428 kw.-hr. per capita
Exports: $1,118 million (f.o.b., 1973); fish and fish products, copper, silver,
iron, cotton, sugar, lead, zinc, petroleum, coffee
Imports: $1,029 million (1973); foodstuffs, machinery, transport equipment,
iron and steel semimanufactures, chemicals, pharmaceuticals
Major trade partners: exports -- U.S. 33%, Western Europe 30.2%, Japan 14%,
Communist Bloc countries, 10.2%, Latin America 7%; imports -- U.S. 29%,
Western Europe 34%, Latin America 15%, Japan 8% (1972)
Aid:
economic -- extensions from U.S. (FY46-72), $513.3 million loans, $206.4
million grants; from international organizations (FY46-70), $494.3 million;
from other Western countries (1960-72), $136.1 million; Communist countries
(1969-73) $234.7 million;
military -- assistance from U.S, (FY49-72), $142.4 million; from Communist
countries (1973), $14 million
Monetary conversion rate: 38.70 soles=US$1 (trade); 43.38 soles=US$1 (non-trade)
Fiscal year: calendar year
GDP: $33.2 million (1971 est.), $290 per capita; real growth rate 1971, 5.8%
Agriculture: main crops -- bananas, copra, sugar, cocoa, spices
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electrice_power: 11,800 kw. capacity (1971); 26 million kw.-hr. produced (1971
est.); Q kw.-hr. per capita
Exports: $4.4 million (f.o.b., 1970); sugar, bananas, cocoa
Imports: $27.3 million (c.i.f., 1970); foodstuffs, machinery and equipment,
fertilizers, petroleum products
Major trade partners: U.K. 49%, Canada 9%, U.S. 8% (1964)
Monetary conversion rate: 2.08 East Caribbean dollars=US$1 (February 1974, now
floating with pound sterling
297
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GDP: $20 million (1971 est.), $200 per capita; 6.9% growth in 1971
Agriculture: main crops -- bananas, arrowroot, coconut
Major industries: food processing
Electric power: 4,700 kw. capacity (1971); 15 million kw.-hr. produced (1971
est.), 160 kw.-hr. per capita
Exports: $3.7 million (f.0.b., 1969); bananas, arrowroot, copra, cotton
Imports: $12 million (c.i.f., 1969); fertilizer, flour, transportation
equipment, lumber, textiles
Major trade partners: U.K. 39%, U.S. 10%, Canada 10% (1967)
Monetary conversion rate: 2.08 East Caribbean dollars=US$1 (February1974), now
floating with pound sterling
Principal economic activities of San Marino are farming, livestock raising, light
manufacturing, and tourism; the government''s total budget for FY71 was about
$12 million, with the largest share of revenue derived from the sale of
postage stamps throughout the world and from payments by the Italian
government in exchange for Italy''s monopoly in retailing tobacco, gasoline,
and a few other goods; main problem is finding an additional $3 million to
finance badly needed water and electric power systems expansions
Agriculture: principal crops are wheat (average annual output about 4,400 metric
tons/year) and grapes (average annual output about 700 metric tons/year);
other grains, fruits, vegetables, and animal feedstuffs are also grown;
livestock population numbers roughly 6,000 cows, oxen, and sheep; cheese
and hides are most important livestock products
Electric power: obtained from Italy, 1973
Manufacturing: consists mainly of cotton textile production at Serravalle, brick
and tile production at Dogane, cement production at Acquaviva, Dogane, and
Fiorentino, and pottery production at Borgo Maggiore; some tanned hides,
paper, candy, baked goods, Moscato wine, and gold and silver souvenirs are
also produced
Foreign transactions: dominated by tourism; in summer months 20,000 to 30, 000
foreigners visit San Marino every day; a number of hotels and restaurants
have been built in recent years to accommodate them; remittances from
Sanmarinese abroad also represent an important net foreign inflow; conmodity
trade consists primarily of exchanging building stone, lime, wood, chestnuts,
wheat, wine, baked goods, hides, and ceramics for a wide variety of consumer
manufactures
GNP: $308 million (1971); $740 per capita; real growth rate 1971 est., 4%
Agriculture: main crops -- rice, sugarcane, bananas; self-sufficient in major
staple (rice); caloric intake 2,350 calories per day per capita (1968)
Major industries: bauxite mining, alumina and aluminum production, lumbering,
food processing
Electric power: 225,000 kw. capacity (1972); 1.4 billion kw.-hr. production
(1972), 3,700 kw.-hr. per capita
Exports: $177.6 million (f.0.b., 1972); bauxite, alumina, aluminum, wood and
wood products, rice
Imports: $198 million (c.i.f., 1972); capital equipment, petroleum, iron and
steel, cotton, flour, meat, dairy products
Major trade partners: exports -- U.S. 39%, Canada 2%, Netherlands 14%; imports
~- U.S. 35%, Netherlands 22%, Europe 18% (1971)
Aid: economic -- extensions from U.S. (FY53-72), $5.0 million loans, $4.7 million
grants; from international organizations (FY49-72), $44.1 million
Monetary conversion rate: 1.79 Surinam guilders (S. f1.)=US$1 (27 December 1971)
Fiscal year: calendar year
GDP: approx. $114 million (FY71), about $260 per capita; growth rate in current
prices as much as 14.5% (FY68-71)
Agriculture: main crops -- maize, cotton, rice, sugar, and citrus fruits
Major industry: mining
Electric power: 67,800 kw. capacity (1973); 220 million kw.-hr. produced (1973),
500 kw.-hr. per capita
Exports: $93 million (f.o.b., 1972); iron ore, asbestos, sugar, wood and forest
products, citrus, meat products, cotton
333
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Imports: $76 million (f.o.b., 1972); food products, manufactured goods, machinery,
fertilizer, fuel
Major trade partners: Japan, U.K., South Africa
Aid: economic aid -- U.K. $14.7 million (budgeted, 1971-73), U.S. $5.8 million
(FY61-72), others approximately $1.3 million; no military aid
Budget: FY71 -- revenue $22 million, recurrent expenditure $20.1 million,
development expenditure $3.5 million
Monetary conversion rate: 1 South African Rand=US$1.42 (par value); Swaziland
uses the South African Rand; 0.7046 SA Rand=US$1
Fiscal year: 1 April - 31 March
GNP: $2.42 billion (at 1972 prices, 1973); $810 per capita; 74% privat','01ef8452ef17169051c75e6404f85eb72827685c09880a8a379b3a4e330ef101','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02433f2a1906924b93bf72fd27248187d6490216a6d2eb79a6f00863a7495dc8',1974,'BR','Brazil','economy',23,'e
consumption, 12% public consumption, 14% gross investment (1969); real growth
rate 1973, 1%
Agriculture: large areas devoted to extensive livestock grazing (17 million
sheep, 9 million cattle); main crops -- wheat, rice, corn; self-sufficient
in most basic foodstuffs; caloric intake, 3,000 calories per day per capita,
with high protein content
Major industries: meat processing, wool and hides, textiles, footwear, cement,
petroleum refining
Crude steel: 24,000 metric tons produced (1966), 10 kilograms per capita
Electric power: 576,000 kw. capacity (1972); 2.4 billion kw.-hr. produced
(1972), 855 kw.-hr. per capita
Exports: $319 million (f.o0.b., 1973); beef, wool, hides
Imports: $294 million (c.i.f., 1973); fuels, metals, machinery, transportation
equipment
Major trade partners: exports -- EC 34%, U.K. 14%, U.S. 7%, LAFTA 15%;
imports -- LAFTA 30%, U.S. 14%, U.K. 6%, EC 19% (1969)
Aid:
economic -- extensions from U.S. (FY46-72), loans $123.2 million, grants
$26.0 millions; from international organizations (FY46-72), $242.8 million;
from other western countries (1960-71), $14.2 million; from Communist countries
(1966-73) $46.4 million;
military -- U.S. (FY46-72), $58.7 million ;
Monetary conversion rate: (buying) 1,073 pesos=US$1; (selling) 1,084 pesos=US$1;
financial -- floating (1,250 pesos=US$1 on April 30, 1974)
Fiscal year: calendar year
The Vatican City, seat of the Holy See, is supported financially by contributions
(known as Peter''s pence) from Roman Catholics throughout the world; some
income derived from sale of Vatican postage stamps and tourist mementos,
fees for admission to Vatican museums, and sale of publications; industrial
activity consists solely of printing and production of a small amount of
mosaics and staff uniforms
The banking and financial activities of the Vatican are worldwide; the Institute
for Religious Agencies carries out fiscal operations and invests and transfers
funds of Roman Catholic religious communities throughout the world; the
Cardinal''s Commission controls the administration of ordinary assets of the
Holy See and a Special Administration manages the Holy See''s capital assets
Electric power: obtained from Rome city grid; standby diesel powerplant with
2,100 kw. capacity
367
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GNP: $14.0 billion (1973 est. in 1972 prices), $1,240 per capita; 56% private
consumption, 15% public consumption, 29% gross investment (1972), real growth
rate 1973 est. 9%
Agriculture: main crops -- cotton, sugarcane, corn, coffee, rice; self-sufficient
in rice and chicken, imports wheat (U.5.) and meat (Colombia); caloric intake
2,600 calories per day per capita (1972)
Fishing: catch 138,900 metric tons, $28.7 million (1971); exports $10.1 million
(1970), imports $5.6 million (1970)
Major industries: petroleum, iron-ore mining, construction, food processing,
textiles
Crude steel: 923,000 metric tons produced (1970), 90 kilograms per capita
Electric power: 3.18 million kw. capacity (1971); 13.4 billion kw.-hr. produced
(1971), 1,230 kw.-hr. per capita
Exports: $5,259 million (f.o.b., 1973 est.); petroleum $2,783 million (1971), iron
ore, coffee
Imports: $2,894 million (f.0.b., 1973 est.); industrial machinery and equipment,
chemicals, manufactures, wheat
Major trade partners: imports --''U.S, 44%, West Germany 11%, Japan 9%; exports --
U.S. 41%, Canada 13%, Aruba 12%, Argentina 9%
Aid:
economic -- extensions from U.S. (FY46-72), $388.0 million loans; $66.7
million grants; from international organizations (FY46-72), $672.7 million;
from Communist countries (1954-73), $10 million;
military -- assistance from U.S. (FY46-72), $122.4 million
Monetary conversion rate: 4.30 bolivares=US$1 (selling rate)
Fiscal year: calendar year \\
Agriculture: mainly subsistence; main crops -- rice, corn, sweet potatoes,
manioc, sugarcane; food shortages -- rice, meat, sugar; caloric intake,
1,700-2,200 calories per day per capita
Major industries: food processing, textiles, machine building, mining, cement
Shortages: petroleum, complex machinery and equipment, fertilizer, foodstuffs
Monetary conversion rate (nominal): 3.0 dong=US$1 (1972)
Fiscal year: calendar year
GNP: $2.3 billion (1972 est.), $120 per capita; no real growth estimated for 1972;
5% to 7% real decline estimated for 1973
Agriculture: main crops -- rice, rubber, fruits and vegetables, copra; major food
imports -- rice, wheat, dairy products, sugar
Fishing: catch 677,000 metric tons (1972); growing trade in fish and fish products
Major industries: manufacturing on smal] scale, mainly light manufacturing and
processing of local agricultural and forest products; factories produce
textiles, beer, cigarettes, glass, tires, sugar, paper, cement, soft drinks
Shortages: capital goods
Electric power: 883,000 kw. capacity (1973); 1,900,000,000 kw.-hr. produced (1973),
95 kw.-hr. per capita
Exports: $60 million (f.o.b., 1973); major commodities -- rubber, fish and fish
products, forestry products, scrap metal
Imports: $716 million (c.i.f., 1973); major commodities -- machinery and trans-
portation equipment, rice, textile fabrics and yarn, petroleum products, base
metals and manufactures
Major trade partners: exports -- France, U.K., West Germany, Japan; imports --
U.S., Japan, Taiwan; no trade with Communist countries
Aid:
economic -- U.S. (including P.L. 480), $414 million (FY69), $477 million
(FY70), $576 million (FY71, $475 million (FY72), $500 million (FY73); numerous
other non-Conmunist countries providing assistance;
military -- U.S., $1,432 million (FY70), $1,526 million (FY71), $1,985 million
(FY72), $2,270 million (FY73)
Monetary conversion rate: in January 1974 a unified, flexible exchange rate for
all imports and exports was instituted which as of 24 March, was 605 piasters=
US$1; exporters now receive a subsidy of 40 to 78 piasters per US$1, depending
on the commodity; importers of US-~financed goods receive a rebate of 60
piasters per US$]
Fiscal year: calendar year','c03d3eafb1ec77d812a7199108d6e00e90307490ae9a56257d5dba877de9cbae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd9820f15f8543f9f1ae3eafa9cdb0563c65b3e08e2a90ddae9099db34dd50cf',1974,'AR','Argentina','economy',27,'GDP: $33.5 billion (at average theoretical parity exchange rate, 1973) $1,370
per capita; 73% consumption, 24% investment, 1.0% net foreign balance
(1973); real growth rate 1973, 4.8%
Agriculture: main products -- cereals, oilseeds, livestock products; Argentina
is a major world exporter of temperate zone foodstuffs
Fishing: catch 290,000 metric tons (1971), $20.2 million; exports $25 million
(1973), imports $3.6 million (1970)
Major industries: food processing (especially meatpacking), motor vehicles,
consumer durables, textiles, chemicals, printing, and metallurgy
Crude steel: 2.5 million metric tons produced (1973)
Electric power: 7,262,000 kw. capacity (1972); 28.5 billion kw.-hr.
produced (1973), 1,174 kw.-hr. per capita
Exports: $3.05 billion (f.o.b., 1973) -- meat, wheat, corn, wool, hides, oil-
seeds .
Imports: $2.09 billion (c.i.f., 1973) -- machinery, fuel and lubricating oils, =
iron and steel, intermediate industrial products
Major trade partners (1972): exports -- EC 48%, LAFTA 26%, U.S. 10%, Japan 3%;
imports -- EC 33%, LAFTA 20%, U.S. 20%, Japan 8%
Aid: economic -- extensions from U.S. (FY46-72), $847.3 million in loans; $17.9
million in grants; from international organizations (FY46-72), $1,248.2
million; from other Western countries (1960-66), $315.5 millions from
Communist countries (1954-73) $54.7 million (drawn, $40.0 million);
military -- assistance from U.S. (FY46-72), $162.4 million
Monetary conversion rate: commercial -- 5.00 pesos=US$1; financial -- floating,
9.98 pesos=US$1, parallel market 12.40 pesos=US$1 (March 1974)
Fiscal year: calendar year
iS
WATER:
Limits of territorial waters (claimed): 3 n. mi. (fishing
200 n. mi.)
Coastline: 4,000 mi,','338e8903e06779b5fa7585f96257c7531ad81ad8efae0e34c9476f34bcd31e18','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a25fb0d4a9f46617db46280bbdedce851edb58f605c49462c855ff3311af334',1974,'AT','Austria','economy',31,'GNP: $28.1 billion (1973), $3,760 per capita (1972); 55.1% consumption, 31.4%
investment, 4.4% government, -0.4% net foreign balance, -0.5% net errors and
omissions (1972); 1973 growth rate 5.7% constant prices
Agriculture: livestock, cereals, potatoes, sugar beets; 84% self-sufficients
caloric intake 3,230 calortes per day per capita (1969-70)
19
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major industries: foods, iron and steel, machinery, textiles, chemicals,
electrical, paper and pulp
a a 4.6 million metric tons produced (1973), 610 kilograms per capita
1973
Electric power: 9,500,000 kw. capacity (1972); 31.2 billion kw.-hr produced
(1973), 4,174 kw.-hr. per capita
Exports: $5.2 billion (f.0.b., 1973); iron and steel products, machinery and
equipment, lumber, textiles and clothing, paper products, chemicals
Imports: $7.1 billion (c.i.f., 1973); machinery and equipment, chemicals,
textiles, coal, petroleum, foodstuffs
Major trade partners: (1973) West Germany 38%, Italy 10%, Switzerland 10%,
U.K. 7%, U.S. 4%; EC 67%; EFTA 17%; Communist countries 11%
Aid:
economic -- authorized - U.S. $1,188.2 million through FY73; IBRD $106.3
million through FY73, none since FY62;
military -- U.S., $147.3 million (FY52-73); net official economic aid delivered
to less developed areas and multilateral agencies -- $205 million (FY62-72),
$17 million in FY72
Budget: expenditures, $7,340 million; receipts, $6,546 million; deficit, $794
million (1973)
Monetary conversion rate: 19.54 shillings=US$1, average 1973 (floating rate)
Fiscal year: calendar year','3293770979ee24bd9ca6ef39c5fbe64ff20af071a7f53da4e1a1f9d6a7d3a88c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa2272c55da62a9030399a4136501fd1f191657f754a223556639d700159cc0c',1974,'BS','Bahamas','economy',35,'GNP: $390 million (at market prices, 1970 est.), $1,920 per capita
Agriculture: main crops -- fruits, vegetables
Major industries: tourism, cement, oil refining, lumber, salt production
Electric power: 228,000 kw. capacity (1972); 538 million kw.-hr. produced
(1972), 3,100 kw.-hr. per capita
Exports: $342 illion (f.0.b., 1972); fuel oil, cement, rum, pulpwood, fruits,
and vegetables
Imports: $487 million (c.i.f., 1972); foodstuffs, manufactured goods, crude of]
Major trade partners: exports -- U.S. 65%, U.K. 9%, Canada 12%; imports -- U.S.
49%, U.K. 25%, Venezuela 6%, Italy 5%, Canada 3%, (1972)
Aid: economic -- authorizations from U.S. (FY56-72) -- $23.7 million in loans,
$0.3 million in grants
Monetary conversion rate: 1 Bahamian dollar (B$)=US$1
Fiscal year: calendar year
GNP: $200 million (1973 est.), $870 per capita, dominated by of] industry;
crude oi] production in 1974 estimated at the rate of approx. 70,000 bbls.
per day; refinery produced about 90 million bbls. in 1971; government oi]
revenues for 1974 are estimated at $165 million including refinery income and
Saudi Arabia''s payment for the Abu Saf''an field production
Agriculture: produces dates, alfalfa, vegetables; dairy and poultry farming;
fishing; not self-sufficient in food
Major industries: petroleum refining, boatbuilding, shrimp fishing, and
sailmaking on a small scale; major development projects include aluminum
smelter, flourmill, and ISA town
Electric power: 108,000 kw. capacity (1972); 270 million kw.-hr. produced (1972),
1,180 kw.-hr. per capita
ae (ey exports $55 million 1972 rev.; total exports $280 million
1972 (est.
Imports: inciuding oi1, $34 million (1972 est.)
Major trade partners: U.K., Japan, U.S., EC
Aid: economic -- multilateral Western $360,000 (annual average 1967-69)
Monetary conversion rate: 1 Bahrain dinar=US$2.52 {since January 1973)
Fiscal year: calendar year
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMMUN ICAT IONS:
Highways: 120 mi. bituminous surfaced; undetermined mileage of natural surface
tracks
Ports: 1 major
Piplines: crude oi1, 35 mi.; refined products, 10 mi.; natural gas, 20 mi.
Civil air: 5 major: transport aircraft (all registered in the U.K.)
Airfields: 5 total, 2 usable; 1 with permanent-surface runway; 1 with runway over
12,000 ft; 1 seaplane station
Telecomunications: excellent international telecommunications; limited
domestic services; 14,800 telephones; 80,000 radio receivers; 10,000 TV sets;
1 AM radiobroadcast station; satellite earth station; tropospheric scatter
Bahrain to Qatar and United Arab Emirates
DEFENSE FORCES:
Military manpower: males 15-49, 62,000; fit for military service 34,000
24
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','c085f71f72ed41a3b999d6153d9ac76ae0b8933fa2efee98d88533affb2826cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95c69a44ce71547b091a64ac99ad582dceaa8b7e2066d297512ccc1cb357113e',1974,'BD','Bangladesh','economy',36,'PEOPLE''S REPUBLIC
OF GHINA
LAND:
55,000 sq. mi.; 66% arable (including cultivated and
fallow), 18% not available for cultivation,
16% forested
Land boundaries: 1,575 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastiine: 360 mi.
GNP: $5.0 billion FY72 est. (1970 prices), less than $100 per capita; real
growth (FY72 est.) -7%
Agriculture: large subsistence farming, heavily dependent on monsoon rainfall;
main crops are jute and rice; shortages -- rice, wheat, and cotton
*Does not take account of refugees who entered India from Bangladesh during 1971, most
of whom presumably have returned.
25
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Fishing: catch 273 thousand etric tons, $115 million (1969 est.)
Maior industries: jute manufactures, food processing and cotton textiles
Exports: $297 million (f.o.b., 1972); raw and manufactured jute, tea, paper and
paperboard, hides and skins
Imports: $694 million (c.i.f. 1972); chemicals, machinery and other manufactured
products, transport equipment, foodgrains, fuels, oils and fats
Major trade partners: West Pakistan (until December 1971), U.S., U.K. Japan,
India (since December 1971)
Aid: Bangladesh received roughly one-third of the estimated $8 billion in total
economic aid received by Pakistan between 1950 and 1971; since independence
(17 December 1971-1 January 1973), economic aid: total $1.3 billion extended,
$634 million drawn; US $347 million extended; U.5.S.R. $136 million extended;
Eastern Europe $36 million extended
Monetary conversion rate: 7.5 takas=US$1 (effective April 1973)
Fiscal year: 1 July - 30 June','cf767c92351fc04277d48c872f025cb93a7c52d79539804ca65e53d3b25a6e54','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb4401f648630e02911df58968db922c37b4bb99d3bb185111b5f5e1b073e07c',1974,'BB','Barbados','economy',42,'GDP: $185.6 million (1972), $780 per capita; real growth rate 1972, 0.6% (est. )
Agriculture: main products -- sugar, subsistence foods
Major industries: tourism, sugar milling, manufacturing, edible oils and fats
Electric power: 48,000 kw. capacity (1972); 164 million kw.-hr. produced
(1972), 580 kw.-hr. per capita
Exports: $44 million (f.0.b., 1972); sugar, molasses, rum
Imports: $142 million (c.i.f., 1972); foodstuffs, lumber, machinery,
manufactured goods
Major trade partners: exports -- U.K. 32%, U.S. 13%, CARIFTA 27%, other 22%3
imports -- U.K. 30%, U.S, 18%, Canada 10%, CARIFTA 12%, other 27% (1971)
Aid: economic =~ U.S. (FY67-72), $0.7 million in grants; from international
organizations (FY63-72), $1.8 million
Monetary converston rate: 2.08 Barbados dollars=US$1 (February 1974}, now floating
with pound sterling
Fiscal year: 1 April - 31 March
27
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','ef4f1e474a97f80edb50534253d0ddfbe755e7a3f142edd1430d8d3965723f49','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8eb33e5c5db3ba17d47b54a51ef42af6a4151df53f510e2d64743bb8628f0cc3',1974,'BE','Belgium','economy',46,'GNP: $46.1 billion (1973), $4,730 per capita (1973); 1972 -- 60% consumption,
24% investment, 14% government, 2% net foreign balance; 1973 real GNP
growth rate 5.7%
Agriculture: livestock production predominates; main crops -- grains, beets,
potatoes; 80% self-sufficient in food; caloric intake, 3,230 calories per
day per capita (1969-70)
Fishing: catch 59,000 metric tons, $25,120,000 (1972); exports $29.0 million (1972)
imports $110.6 million (1972)
Major industries: engineering and metal products, processed food and beverages,
chemicals, basic metals, textiles, and pe troleum
Shortages: iron ore, nonferrous minerals, petroleum
Crude steel: capacity 17.2 million metric tons (1972); 15.5 million metric tons
produced (1973); 1,590 (1973 est.) kilograms per capita
Electric power: 8,710,000 capacity (1973); 39.4 billion kw. -hr. produced (1973),
3,400 kw.-hr. per capita
Exports: $22.3 billion (f.o.b., 1973) motor vehicles, finished or semi finished
precious stones, textile products
Imports: $21.8 billion (c.i.f., 1973), nonelectrical machinery, motor vehicles,
textiles, chemicals
Major trade partners: (Belgium-Luxembourg Economic Union, 1972) EC-nine 73%
(West Germany 25%, France 20%, Netherlands 18%, U.K. 5%, Italy 4%); U.S. 6%,
Communist countries 2%
Aid:
economic -- received - U.S., $983.8 million authorized (FY46-73); $12.5 million
in FY73; IBRD, $200.8 miltion (1949-73)
military -- received - $1,260.8 million authorized (FY46-73); net official
economic aid to less developed areas and multilateral agencies -- $1,092
million (FY60-70), $231 million in 1972
Ordinary budget, 1973: revenue $9.2 billion, expenditures $9.2 billion
Monetary conversion rate (trade conversion factor, 1973): 1 franc=US$0.025/7
(as of 28 September 1973 floating)
Fiscal year: calendar year
~ GDP: $72.8 million (1972 est.), $570 per capita; 78% private consumption, 17%
public consumption, 36% domestic investment, -31% net foreign balance
(1968); real growth rate 1971 3.5%
Agriculture: main products -- sugar, citrus fruits, corn, rice, beans, livestock
products; net importer of food; caloric intake, 2,500 calories per day per
capita
Major industries: timber and forest products, food processing, furniture, rum,
soap
’ Electric power: 6,400 kw. capacity (1973); 26.2 million kw.-hr. produced (1973),
210 kw.-hr. per capita
Exports: $19.0 million (f.0.b., 1971 est.); sugar, lumber, citrus fruits, fish
3]
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Imports: $35.4 million (c.i.f., 1970); vehicles, petroleum, food, textiles,
machinery
Major trade partners: exports -- U.S. 30%, U.K. 24%, Mexico 22%, Canada 13%;
imports -- U.S. 34%, U.K. 25%, Jamaica 7% (1970)
Aid: economic -- U.S. (FY46-72), $6.3 million, grants; from international
organizations (1946-72), $1.7 million
Monetary conversion rate: $BH1.54=US$1 (official)
Fiscal year: calendar year','4367174ae1284bb908b9cef6806539b636750c220c383a21a4f1388ca0f8e60b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e809f16780520d3146bde6ed2b68b0ab46b279d211a133840dfcba270a56d4b9',1974,'BM','Bermuda','economy',50,'GNP: $190 million (at market prices, 1970), $3,580 per capita
Agriculture: main products -- bananas, vegetables, Easter lilies, dairy products,
citrus fruits
Major industries: tourism, finance, ship repair, small boat building
Electric power: 66,340 kw. capacity (1971); 226 million kw.-hr. produced (1971),
4,245 kw.-hr. per capita
Exports: $93.0 million (f.o0.b., 1971); mostly reexports of drugs and bunker fuel
Imports: $111 million (f.0.b., 1971); fuel, foodstuffs, machinery
Major trade partners: U.S. 45%, U.K. 22%, Canada 9% (1971)
Monetary conversion rate: 1 Bermuda dol lar=US$1
Fiscal year: 1 April-3] March','0f2a7d3c4d02c93a69d4770a86535353bb7a53ee2bb54f6f36342e9d24ec393d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96ab34793d08f64b3baa80349b716b97436834cfda9d103f0b4eaa1371046461',1974,'BT','Bhutan','economy',54,'GNP: under $100 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Exports: about $1 million annually; rice, dolomite, and handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic -~ India (FY61-72) $180 million
Monetary conversion rate: 7,5 Indian rupees=US$1 (official rate); now floating
= with U.K. pound
Fiscal year: 1 April - 317 March','e41fe0e40c3bf6c4570069842788b252ffec19f1767f6e93600f694a67a83fb6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eada355bad51938c5949bea2523cb08f2d5d402048da8dd3b95a1981583bcfd8',1974,'BW','Botswana','economy',59,'GDP: $142.6 million (April 1971-March 1972), about $210 per capita, growth in
current prices about 25% annually (FY‘s 1968-72)
Agriculture: principal crops are corn and sorghum; livestock raised and exported
Major industries: livestock processing, mining of diamonds, copper, nickel, coal,
asbestos, and manganese
Electric power: 8,000 kw. capacity (1973); 29 million kw.-hr. produced (1973),
44 kw.-hr. per capita
Exports: $47 million (FY71/72); cattle, animal products, minerals
Imports: $88 million (FY71/72); foodstuffs, vehicles, textiles
39
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major trade partners: South Africa and U.K.
Budget: balanced at $127.5 million in FY 1974
Monetary conversion rate: 1 SA Rand=US$1.42 (par value; Botswana uses the
South African Rand), 0.70 SA Rand=US$1
Fiscal year: 1 April - 31 March','bdd82d46ef28b47c80bd7055f1cedb9e48157899d9c5eba7ba9e3801673c4fec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c159418d4e0295f6e1c0080ed77c084c0bfea150d9c93b22f57c6d267905beb',1974,'BG','Bulgaria','economy',60,'LAND:
42,800 sq. mi.; 41% arable, 11% other agricultural,
33% forested, 15% other
Land boundaries: 1,170 mi.
TURKEY
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 220 mi.
GNP: $15.7 billion, 1973 (at 1972 prices), $1,810 per capita; 1973 growth rate
6.3%
Agriculture: mainly self-sufficient; main crops--grain, vegetables; no food
shortages; caloric intake, 3,000 calories per day per capita (1969/70)
Fishing: catch 103,000 metric tons (1972)
Major industries: agricultural processing, machinery, textiles and clothing,
mining, ore processing, timber
Shortages: meat and dairy products; metal products; fodder
47
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
BURMA
LAND:
262,000 sq. mi.3 28% arable, of which 12% is cultivated,
62% forest, 10% urban and other (1969)
Land boundaries: 3,630 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,900 mi.
GDP: $2.3 billion (FY73), $80 per capita; real growth rate 3% (FY72)
Agriculture: main crops -- paddy, sugarcane, peanuts; almost 100% self-sufficient;
most rice grown in deltaic land
Fishing: catch 443,000 metric tons, $80 million (1971)
Major industries: agricultural processing; textiles and footwear, wood and
wood products; petroleum refining
Exports: $118 million (f.0.b., 1972); rice, teak
49
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','7b0a3bceea2c01d71cc6c74447e70081a21a87549ff55e6355cc963269d808b8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f122fac78424390f4c54d8ac931e055a51777e1e43fe3fd355778ee65585c34',1974,'BI','Burundi','economy',63,'LAND:
11,000 sq. mi.; about 37% arable (about 66% cultivated),
23% pasture, 10% scrub and forest, 30% other
Land boundaries: 605 mi.
GNP: about $204.7 million (1971 est.), $60 per capita; estimated real GDP
growth 1%
Agriculture: major cash crops -- coffee, cotton; main food crops -- manioc,
yams, corn, sorghums, bananas, haricot beans; not self-sufficient
Industries: light consumer goods such as beverages, shoes, soap
Electric power: 13,100 kw. capacity (1973); 26 million kw.-hr. produced (1973),
7 kw.-hr. per capita
Exports: $29 million (f.o.
Imports: $35 million (c.i.
petroleum products
Major trade partners: U.S., Belgium, Congo; much trade unrecorded
Aid: $17.7 million (1970) includes Belgium $7.4 million, U.N. $3.1 million, EDF
$2.9 millions France $2.0 million (1970); U.S. $9.7 million FY61-72
Budget: FY72 -- revenue $32.8 million, expenditure $29.9 million
Monetary conversion rate: 78.75 Burundi francs=US$1 (official)
Fiscal year: calendar year
b., 1972); coffee, cotton, hides, skins
f., 1972); textiles, foodstuffs, transport equipment,
51
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','5263823503a9e7715729873a4e942cf90a1cf025702211060fbc0c714336ceb3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50ba54c842e6cdb8a5ed16e330daf846cfe2f74832733488b430683cb91db025',1974,'KH','Cambodia','economy',66,'LAND:
70,000 sq. mi.; 16% cultivated, 74% forested, 10% built-on
area, wasteland, and other
Land boundaries: 1,515 mi.
I. tie
BN ae a
WATER: |
Limits of territorial waters (claimed): 12 n. mi.
Coastline: about 275 mi.
a IIUIONESIA.- i
GNP: $950 million (1971), $140 per capita (1971 prices; no growth rate available)
Agriculture: Mainly subsistence except for rubber plantations; main crops --
rice, rubber, corn; largely self-sufficient prior to the war; food shortages
-- rice, dairy products, sugar, flour
Major industries: rice milling, fishing, wood and wood products, textiles
Shortages: fossil fuels
Exports: $6.9 million (f.o.b., 1972); rubber, food stuffs, kapok
Imports: $71.1 million (f.0.b., 1972); machinery and equipment, chemical products,
metals and metal products, petroleum products, foods, transport equipment
53
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','3b275be48d5937b13947867a685ea26613267fa70973a8e85ca98157d6467df7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20798ac8839117c48d1d61dd9e557c1d6ff4ad36fedc60791efce41ec9dbee49',1974,'CM','Cameroon','economy',69,'LAND:
183,400 sq. mi.; 4% cultivated, 18% grazing, 13% fallow,
50% forest, 15% other
Land boundaries: 2,830 mi.
WATER:
Limits of territorial waters (claimed): 18 n. mi.
Coastline: 250 mi.
GDP: $1,196 million (1971 est.), per capita about $190; real growth rate about 7%
per annum
Agriculture: commercial and food crops -- cocoa, coffee, timber, cotton, rubber,
bananas, peanuts, palm oi] and palm kernels; root starches, livestock, millet,
sorghum, and rice
Fishing: imports 6,137 metric tons, $2.5 million (1972); exports 1,718 metric
tons (largely shrimp), $2.7 million
Major industries: small aluminum plant, food processing and light consumer goods
industries, sawmills
55
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
STAT
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
~@&
©
Pod
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','51142aebee8d186bcb1cb0614a6f5ddbb07b62c82c8443bdb9447c14b90513ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8871254bbda7c083c668e8370c6866249bbdf3424efa3533b21253dd41e39a01',1974,'CF','Central African Republic','economy',72,'LAND:
242,000 sq. mi.s; 10%-15% cultivated, 5% dense forests,
80%-85% grazing, fallow, vacant arable land, urban,
was te
Land boundaries: 3,095 mi.
GDP: $281 million (1972 est.), about $170 per capita
Agriculture: commercial -- cotton, coffee, peanuts, sesame, wood; main food
crops -- manioc, corn, peanuts, rice, potatoes, beef; requires wheat, flour,
rice, beef, and sugar imports
Major industries: sawmills, cotton textile mills, brewery, diamond mining and
splittin
Electric sane 16,850 kw. capacity (1973); 50 million kw.-hr. produced (1973),
30 kw.-hr. per capita
Exports: $45 million (f.0.b., 1971); diamonds (43%), coffee, cotton, lumber
Imports: $46 million (c.i.f., 1971); textiles, petroleum products, machinery
and electrical equipment, motor vehicles and equipment, chemicals and
pharmaceuticals
59
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','ec0402bec5e83ab06f57278186009680a9767c4b3423156bb9d03c1c82e60b63','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba1db0d384309ce6d573aac2eae60407a0a34a36eb8f0064bc70ed880992a92e',1974,'TD','Chad','economy',75,'LAND:
496,000 sq. mi.; 17% arable, 35% pastureland, 2% forest
and scrub, 46% other uses and waste
Land boundaries: 3,720 mi.
GDP: about $241 million (1967), about $70 per capita; estimated real annual growth
rate 2.5% (1963-68)
Agriculture: commercial -- cotton, gum arabic, livestock, fish; food crops --
peanuts, millet, sorghum, rice, dates, manioc, wheat; imports food
Fishing: catch 120,000 metric tons (1971) $14 millions; exports $300,000 (1969)
Major industries: agricultural and livestock processing plants {cotton textile
mill, slaughterhouses, brewery), natron
61
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','73fac754638d69d74da0130a64e4612a3e193bc6e766e7aa0e864f49161e800b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59ed70d7185e45f4a04ccb34b42c240c46390218fe079a581ab57f99a8505eb3',1974,'CG','Congo','economy',81,'GDP: about $277 million (1970 est.), $310 per capita, real growth rate
about 4% per year
Agriculture: cash crops -- sugarcane, wood, coffee, cocoa, palm kernels, peanuts,
tobacco; food crops -- root crops, rice, corn, bananas, manioc, fish
Fishing: catch 13,800 metric tons (1971); imports $3.3 million (1969)
Major industries: sawmills, brewery, cigarettes, sugar mill, soap
Electric power: 43,600 kw. capacity (1973); 88 million kw.-hr. produced (1973),
re 91 kw.-hr. per capita
73
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','42f8233ed9471c0b5fd79dc9d00038027ab8ac54906535938b79beda8ac7742a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f03c80aedb22845ca4bc9278953914e1af60ca21d38a9de9cc720c9f301a2607',1974,'CK','Cook Islands','economy',82,'bs.
a LAND: .
About 93 sq. mi. :
WATER:
Limits of territorial waters: 3 .n. mi.
Coastline: about 75 mi. ou
PEOPLE: le
Population: 21,000, official estimate for 1 July 1972
Ethnic divisions: 81.3% Polynesian (full blood), 7.7%
Polynesian and European, 7.7% Polynesian and other,
2.4% European, 0.9% other
Religion: Christian, majority of populace members of
Cook Islands Christian Church
Agriculture: export crops include copra, citrus fruits, pineapple, tomatoes, and
bananas, with subsistence crops of yams and taro
Industry: fruit processing
Exports: $3.0 million (1970); fruit juice, clothing, citrus fruits
Imports: $6.5 million (1970)
Major trade partners: (1970) exports -- 98% New Zealand, imports -- 76% New
Zealand, 7% Japan
Monetary conversion rate: 0.68 NZ$=US$1','7ab78945c6a3a0926189f2e2d3318a11601d875f7cb78f843756be8600c95e4b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6502061aa310bc1c5b6dd89beb85cc3d6595939109101ca1dbc7558c0339db0',1974,'CR','Costa Rica','economy',87,'GNP: $1,130 million (1972 est.), $620 per capita; real growth rate 1972, 4.9% (est.)
Agriculture: main products ~- bananas, coffee, sugarcane, rice, corn, cocoa,
livestock products; caloric intake, 2,610 calories per day per capita (1966)
Fishing: catch 8,400 metric tons, $4.8 million (1971); exports, $1.8 million
(1970), imports $0.5 million (1970)
77
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major industries: food processing, textiles and clothing, construction
materials, fertilizer
Electric power: 250,000 kw. capacity (1973); 1.2 billion kw.-hr. produced
(1973), 640 kw.-hr. per capita
Exports: $281 million (f.o.b., 1972 prel.); coffee, bananas, sugar, beef,
fertilizers, cacao
Imports: $374 million (c.i.f., 1972 prel.); manufactured products, machinery,
transportation equipment, chemicals, fuels, foodstuffs
Major trade partners: exports -- 41% U.S., 21% CACM, 9% West Germany, 3% Japan;
imports -- 32% U.S., 22% CACM, 8% West Germany, 11% Japan (1971)
Aid:
economic -- extensions from U.S. (FY46-72), $121.1 million loans, $98.8
million grants; from international organizations (FY46-72), $191.8 million:
from other Western countries (1960-71), $7.7 million;
military -- assistance from U.S. (FY60-72) $1.9 million
Monetary conversion rate: 6.62 colones=US$1 (official buying rate); 6.65
colones=US$1 (official selling rate)
Fiscal year: calendar year','96d467deb35620aa2f0cc5a712d6e8db8e82ca70829227833969718a16666e77','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6b6a14b40c8340e8216345413dd9273a7dcd6c07ba0494ecc972f84055fb3e1',1974,'CU','Cuba','economy',91,'GDP: $4.7 billion (1972 est. at 1972 prices), $540 per capita; 60% private
consumption, 20% public consumption, 20% gross investment; real growth
rate 1972, -2%
Agriculture: main crops -- sugar, tobacco, coffee, rice, potatoes, tubers,
citrus fruits
Fishing: catch 150,229 metric tons (1973); exports $42.5 million (1973), imports
$11.9 million (1971)
Major industries: sugar milling, petroleum refining, food and tobacco processing,
textiles, chemicals, paper and wood products, metals
Shortages: spare parts for transportation and industrial machinery, consumer goods
Crude steel: 0.35 million metric tons capacity (planned); 220,600 metric tons
produced (1973); 20 kg. per capita
Electric power: 1,137,000 kw. capacity (1972); 5.9 billion kw.-hr. produced
(1973), 660 kw.-hr. per capita
Exports: $1,345 million (f.0.b., 1973 est.); sugar, nickel, tobacco
Imports: $1,530 million (c.i.f., 1973 est.}; capital goods, industrial raw
materials, food, petroleum
79
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major trade partners: exports -- U.S.S.R. 42%, China 4%, other Conmunist
countries 15%, Japan 17%; imports -- U.S.S.R. 61%, China 5%, other
Communist countries 13% (1973 est.)
Monetary conversion rate: 1 peso=US$1.21 (nominal)
Fiscal year: calendar year','28f3b4a4bfd0f2d0b2cec6a5800cc29e7cc278c6778688cdacc82eeb1d4dc869','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edca70c8707b5dd974ab2a2aef5755be11ef882019ec6ad12bdbc1e038a8f561',1974,'CY','Cyprus','economy',95,'GNP: $835.6 million (1972), $1,300 per capita; 1972 real growth rate 5%
Agriculture: main crops -- vine products, citrus, potatoes, other vegetables;
food shortages -- grain, dairy products, meat, fish; caloric intake, 2,460
calories per day per capita (1964-66)
Major industries: mining (cupreous and iron pyrites, asbestos), manufactures
principally for local consumption -- food, beverages, footwear
Shortages: water, petroleum
Electric power: 204,000 kw. capacity (1973); 716 million kw.-hr. produced (1973),
980 kw.-hr. per capita
Exports: $180 million (f.o.b., 1973 -- converted at average trade conversion
factor of 1 Cyprus pound=US$2.85); principal items -- copper, pyrites, citrus,
raisins, and other agricultural products
Imports: $449 million (c.i.f., 1973 -- converted at average trade conversion factor
of 1 Cyprus pound=US$2.85); principal items -- manufactured goods, machinery
and transport equipment, petroleum products, foods
Major trade partners: (1973) imports -- U.K. 25%, West Germany 9%, Italy 8%,
France 7%, U.S. 7%; exports -- U.K. 42%, West Germany 7%, Netherlands 4%,
U.S.S.R. 4%
Aid: economic -- U.S., $32.4 million authorized FY46-72; IBRD, $63.1 million
(FY46-73); U.N. Technical Assistance, $1.7 million (FY46-72); U.N. Special
Fund, $9.9 million (FY46-72)
Monetary conversion rate: 1 Cyprus pound=US$2.61 (December 1971 through January
1973), 1 Cyprus pound=US$2.895 (trade conversion factor as of December 1973)
Fiscal year: calendar year
GNP: $39.5 billion in 1973 (at 1972 prices), $2,710 per capita; 1973 real growth
rate 4.2%
Agriculture: diversified agriculture; main crops -~ wheat, rye, potatoes, sugar
beets; net food importer -- meat, wheat, vegetable oils, fresh fruits and
vegetables; caloric intake, 3,100 calories per day per capita (1967)
Major industries: machinery, food processing, metallurgy, textiles, chemicals
Shortages: ores, crude oil, grain
83
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Crude steel: 13.2 million metric tons produced (1973), 910 kg. per capita
Exports: $6,479 million (f.o.b., 1973); 49% machinery, equipment; 28% fuels,
raw materials; 4% foods, food products, and live animals; 19% consumer goods,
excluding foods (1972)
Imports: $6,303 million (f.0.b., 1973); 34% machinery, equipment; 45% fuels, raw
materials; 13% foods, food products, and live animals; 8% consumer goods,
excluding foods (1972)
Major trade partners: $12,783 million (1973): 68% Communist countries, 32% with West
Monetary conversion rate: noncommercial 11.88 crowns=US$1, commercial 5.68
crowns=US$1 in 1973; in 1972, 7.2 crowns=US$1
Fiscal year: calendar year
Note: foreign trade figures were converted at the 1973 rate
oe $272 aaa (1972 est.) $90 per capita; real growth rate, 4.6% per annum
1967-71
Agriculture: major cash crop is oi] palms; peanuts, cotton, coffee, sheanuts, and
tobacco also produced commercially; main food crops -- corn, cassava, yams,
sorghum and millet; livestock, fish
Fishing: catch 32,900 metric tons (1971); exports 122.2 metric tons, imports
4,000 metric tons
Major industries: palm oil and palm kernel oi1 processing
Electric power: 11,310 kw. capacity (1973); 50 million kw.-hr. produced (1973),
18 kw.-hr. per capita
Exports: about $47 million (f.o.b., 1971); palm products (34%); other
agricultural products
Imports: $85 million (c.i.f., 1971); clothing and other consumer goods,
cement, lumber, fuels, foodstuffs, machinery, and transport equipment
85
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major trade partners: France, EC, franc zone; preferential tariffs to EC and
franc zone countries
Aid:
economic (1970) -- France, $8 million; EC, $4.2 million; U.N., $2 million;
West Germany, $1 million; Taiwan, $1 million; U.S., (FY60-72) $13.7 million;
China, (1973) $44 million
Budget: 1974 est. -- receipts $48 million, expenditures $52.2
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1 as
of February 1973, floating since February 1973
Fiscal year: calendar year','5bd1b156f691e43d6b816660f561b287a45d71a01a9a34e783ae06c5a622637e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae4bc778a49f0aeb69f87b6e6ffd019b815688da78d69b31382e72b39ec531f7',1974,'DK','Denmark','economy',99,'GNP: $20.9 billion (1972), $4,210 per capita; 58% private consumption, 20%
investment, 22% government; 1972 growth rate 4%, constant prices
Agriculture: highly intensive, specializes in dairying and animal husbandry;
main crops -- cereals, root crops; food shortages -- oilseeds, grain,
feedstuffs; caloric intake, 3,180 calories per day per capita (1968-69)
Fishing: catch 1,408,000 metric tons (1972), exports $159 million, imports $37.2
million (1971)
Major industries: food processing, machinery and equipment, textiles and clothing,
chemical products, electronics, transport equipment, metal products, brick
and mortar, furniture and other wood products
Shortages: most industrial raw materials and fuels
Crude steel: 498,000 metric tons produced (1972), 100 kg. per capita
Electric power: 5,590,000 kw. capacity (1973); 17.6 billion kw.-hr. produced
(1973), 2,850 kw.-hr. per capita
Exports: $6,247 million (f.o.b., 1972); principal items -- meat, dairy products,
industrial machinery and equipment, textiles and clothing, chemical products,
transport equipment, fish, furs, and furniture
Imports: $7,681 million (c.i.f., 1973); principal items -- industrial machinery,
transport equipment, petroleum, textile fibers and yarns, iron and steel
products, chemicals, grain and feedstuffs, wood and paper
Major trade partners: EC-nine 48.1% (U.K. 17.0% West Germany 17.1%);
Sweden 17.2%; U.S. 8.2%; Communist countries 3.7% (1972}
Aid:
economic -- U.S., $342.7 million authorized FY46-73 IBRD, $85.0 million
through 1973, none since 1963; net official economic aid given to Tess
developed areas and multilateral agencies, $250.5 million (1960-70), $58.3
million (1969), $63.2 million (1970), $80 million (1971 provisional)
Military: U.S., $626.3 million (FY49-72)
Budget: (FY72) expenditures $8,595 million, revenues $9,325 million
Monetary conversion rate: 1 Kroner=US$0.1659, 1973, average exchange rate
Fiscal year: 1 April - 31 March','ef8f61e04d2b747c8710ce6ad003d952b9755c7000b87b89d662ac686ec29637','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c2ed7ca685dd08bdad378e818c56e4a80a36e225ca3e56022079a76e9f7625a',1974,'CO','Colombia','economy',103,'GDP: $21.0 million (1971 est.), $270 per capita; 8.8% increase in 1971 -- including
price changes
Agricultural products: bananas, citrus, coconuts, cocoa
Major industries: agricultural processing, tourism
Electric power: 5,420 kw. capacity (1971); 15 million kw.-hr, produced
(1971 est.), 220 kw.-hr. per capita
Exports: $6.1 million (f.0.b., 1970); bananas, lime juice and oi1, cocoa,
reexports
Imports: $16.3 million (c.i.f., 1970); foodstuffs, manufactured articles
Major trade partners: U.K. 53%, Commonwealth Caribbean countries 15%, Canada
10%, U.S. 7% (1963)
Monetary conversion rate: 2.08 East Caribbean dollars=US$1 (February 1974), now
floating with pound sterling
GDP: $21 million (at marketprices, 1970) $200 per capita; 3.2% increase in 1970
(including price changes)
Agriculture: main crops -- cocoa, spices, bananas
Fishing: 1,700 metric tons, $806,000 (1971)
Electric power: 7,000 kw. capacity (1971); 15.2 million kw.-hr. produced
(1971), 140 kw.-hr. per capita
Exports: $5.2 million (f.0.b., 1972 est.); cocoa beans, bananas, nutmeg, mace
Imports: $20.5 million (c.i.f., 1972 est.); textiles, flour, clothing,
miscellaneous manufactured goods
Major trade partners: U.K. 37%, U.S. 9%, Canada 9% (1966)
Monetary conversion rate: 2.08 East Caribbean dollars=US$1 (February 1974), now
floating with pound sterling
139
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','4a6507c9e70faf8fa4636e8f3fe81d0dfef27708753eb33bb66a7968406ea203','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('637762585c5febe5f102fa483c64f0dd7acfcf82b333d5b058d6dde1e58b79b1',1974,'DO','Dominican Republic','economy',108,'GNP: $2.3 billion (1973), $520 per capita; real growth rate 1973, 7.0%
Agriculture: main crops -- sugarcane, coffee, cocoa, tobacco, rice, corn; self-
sufficient in rice; caloric intake, 2,200 calories per day per capita (1966)
Major industries: sugar processing, nickel mining, bauxite mining, peanut
processing, textiles, cement
9]
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Electric power: 257,000 kw. capacity (1971); 1 billion kw.-hr. produced
(1971), 250 kw.-hr. per capita
Exports: $348 million (f.0.b., 1972); sugar, nickel, tobacco, coffee, cocoa,
bauxite
Imports: $338 million (c.i.f., 1972); foodstuffs, petroleum, industrial raw
materials, capital equipment
ei ie partners: exports -- U.S. 67%, EC 17% (1972); imports -- U.S. 54%
1972
Aid:
economic -- from U.S. (FY46-72), $217.2 million in grants, $279.5 million
in loans; from international organizations (FY46-72), $103.3 million; from
other western countries (1960-71), $11.7 million
military -- assistance from U.S. (FY53-72), $31.0 million
Monetary conversion rate: 1 peso=US$1
Fiscal year: calendar year','5a0b17a7fd26e4fb3f40eebef034b55c5fc70b1a7cf531dfbea9cc898fff1229','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65fb9473eed4ecec2531ac16974b498f5d4109a26e6532298a74a90ab52be5f5',1974,'EC','Ecuador','economy',112,'GNP: $2.0 billion (1972), $310 per capita; 66% private consumption, 14% public
consumption, 20% gross investment (1972 eet real growth rate 1972, 10%
Agriculture: main crops -- bananas, coffee, cocoa, sugarcane, cotton, corn,
potatoes, rice; caloric intake, 1,970 calories per day per capita (1970)
93
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Fishing: catch 99,700 metric tons (1971); exports $18 million (1971), imports
negligible
Major industries: food processing, textiles, chemicals, fishing, petroleum
Electric power: 238,000 kw. capacity (1971); 1 billion kw.-hr. produced
(1971), 170 kw.-hr. per capita
Exports: $311 million (f.o.b., 1972); bananas, petroleum, coffee, cocoa;
sugar, fish products
Imports: $329 million (c.i.f., 1972); agricultural and industrial machinery,
wheat, petroleum products, chemical products, transportation and communication
equipment
Major trade partners: exports --~ U.S. 39%, EC 20%, Japan 17%; imports -- U.S.
34%, EC 21%, Japan 12% (1971)
Aid:
economic -- extensions from U.S. (FY46-72), $211.7 million Toans, $110.0
million grants; from international organizations (FY46-72), $236.1 million;
from Communist countries (1967-73), $15.4 million loans:
military -- assistance from U.S. (FY49-72), $63.9 million
Monetary conversion rate: 25.25 sucres=US$1 (official selling rate)
Fiscal year: calendar year','e4adc38a8723acfbf4294923c16d234e65e6518a3cd193f992e18c54e2a6edd4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b71c3f2c7c589ba8b23626374799f158952a1848f89cc20de9f1be5b03ded9e5',1974,'EG','Egypt','economy',116,'Agriculture: main cash crop -- cotton; other crops -- rice, onions, beans, wheat,
corn, barley; not self-sufficient in food, but agriculture a net earner of
foreign exchange
Major industries: textiles, food processing, chemicals, petroleum, construction,
cement
Electric power: 4,555,000 kw. capacity (1972); 8 billion kw.-hr. produced
(1972), 330 kw.-hr. per capita
95
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Aid:
economic -- Conmunist countries, $2.1 billion in credits through 1973; U.S.,
$1,017 million in credits and grants through FY72 (diplomatic relations and aid
suspended June 1967); sizable credits from international agencies, West Germany,
Italy; large grants from Libya since 1969; $250 million annual subsidy from
Arab states while canal is closed;
military -- Communist countries, about $3.5 billion through 1973
Monetary conversion rate: 1 Egyptian pound=US$2.54 (selling rate); 0.394 Egyptian
pound=US$1 (selling rate)
Fiscal year: calendar year, beginning in 1973','69499e6a0541aa0f822ccde242c97852cbfcc75dd74fe3fb9c20f54c861ee2a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79898a8520d3bd344f21a278522905d1a9f7bb151ede9e862ee7d06f640bd930',1974,'SV','El Salvador','economy',120,'GNP: $1.2 billion (current prices, 1973 est.), $320 per capita; 76% private
consumption, 11% government consumption, 13% domestic investment (1973 est.)s
real growth rate 1973 est., 4.0%
Agriculture: main crops -- coffee, cotton, corn, sugar, rice, beans; caloric
intake, 2,000 calories per day per capita (1963-64)
Fishing: catch 16,200 metric tons (1971); exports $6.0 million (1971), imports
$0.5 million (1972)
Major industries: food processing, textiles, clothing, petroleum products
Electric power: 220,000 kw. capacity (1972); 840 million kw.-hr. produced
(1972), 220 kw.-hr. per capita
Exports: $306 million (f.0.b., 1973 est.); coffee, cotton, sugar, chemicals,
textiles and clothing, other manufactures
Imports: $331 million (c.i.f., 1973 est.); machinery, automotive vehicles,
petroleum, foodstuffs
Major trade partners: exports -- U.S. 23%, CACM 35%, EC 23%, Japan
13%; imports -- U.S. 28%, CACM 25%, EC 16%, Japan 11% (1972)
Aid:
economic -- from U.S. (FY46-72), $90.6 million loans, $63.4 million grants;
from international organizations (FY46-72), $127.2 million; from other Western
countries (1960-71) $9.8 million;
military -- assistance from U.S. (FY53-72), $7.4 million
Monetary conversion rate: 2.5 colones=US$1 (official)
Fiscal year: calendar year','43c5f99bc4844014828c17392d6ebbfec1c7ce6cd540cbaf59c0ff5e4d4b62a7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd2ce3cca15b58b8e0b0f9b3c478902c13f8a8d810edea64dd8f4f45c208cd74',1974,'GQ','Equatorial Guinea','economy',124,'GDP: $63.7 million (1970 est.); $220 per capita
Agriculture: major cash crops -- Rio Muni, timber, coffee; Fernando Po, cocoa;
main food products -- rice, yams, cassava, bananas, oi] palm nuts, manioc, and
lives tock
Fishing: catch 4,000 metric tons (1970); exports $86,000 (1970)
Major industries: fishing, sawmilling
Electric power: 2,800 kw. capacity (1973); 9 million kw.-hr. produced (1973),
about 30 kw.-hr. per capita
Exports: $24.9 million (1970); cocoa, coffee, and wood
Imports: $21.0 million (1970); foodstuffs, chemicals and chemical products,
textiles
Major trade partner: Spain
Aid: Spain, $14.0 million (1969); Libya, $1 million (1971)
99
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Budget: 1970 budget receipts $14.7 million, expenditures $10 million, capital
expenditures $10 million
Monetary conversion rate: 64.47 Guinean pesetas=US$1 (official)','6a3f0481062015d3843e056dd2cb9fd90826054fe7f80520ac593ab8473d88fc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('667552f9fa3e588fa4d9f0f0c5a453fc095131f37725a11d2d24a8f15b54dba2',1974,'ET','Ethiopia','economy',128,'GDP: $2,050 million (1971), $80 per capita; average annual real growth rate
4% (FY67-71)
Agriculture: main crops -- coffee, teff, durra, barley, wheat, corn, sugarcane,
cotton, pulses, oilseeds; livestock
Major industries: cement, sugar refining, cotton textiles, food processing,
oil refinery
Electric power: 306,000 kw. capacity (1972); 673 million kw.-hr. produced
(1972), 25 kw.-hr. per capita
Exports: $168 million (f.o.b., 1972); coffee 55.8%, hides and skins 8.2%,
oilseeds, oilcakes, and nuts 10.2%, cereals 7.4%; $4.6 million to Conmunist
countries (1971)
Imports: $189 million (c.i.f., 1972); metals, machinery and vehicles 47.1%,
petroleum and chemicals 17%, foodstuffs, live animals, and beverages 7.3%;
$9.7 million from Communist countries (1970)
Major trade partners: imports -- Italy, Japan, West Germany, and U.S.;
exports -- U.S., West Germany, Italy, Saudi Arabia, Japan
Monetary conversion rate: 2.07 Ethiopian dollars=US$1 (official since 1973)
Fiscal year: 8 July - 7 July
GDP: $78.7 million (1970), about $2,020 per capita
Agriculture: sheep and cattle grazing
Fishing: catch 179,300 tons (1972)
Major industry: fishing
Electric power: 28,000 kw. capacity (1973); 76 million kw.-hr. produced (1973),
1,750 kw.-hr. per capita
Exports: $37.6 million (f.o.b., 1971); fish and fish products
Imports: $40.6 million (c.i.f., 1971); machinery and transport equipment, pet-
roleum and petroleum products, food products
Major trade partners: (1971) Denmark 47%, EC-six 12%, U.K. 9%, U.S. 8%, Norway 7%,
Sweden 4%
Budget: (FY72) expenditures $22.1 million, revenues $22.4 million
Monetary conversion rate: 1 Danish Kroner=US$0.1659 (1973 average)
Fiscal year: 1 April - 31 March
103
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','1b27c14eb9f918de50e92e6a5976b264ac814d56e99da557d6dfb53e2e639426','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d37332e1e4b4f0b71ba5be927f788684e7506d6d4fd1246d5568394831b027db',1974,'AU','Australia','economy',133,'GNP: $270 million (1972), $490 per capita; 6% average annual growth rate (1969-72)
Agriculture: main crops -- sugar, coconut products, bananas, rice; major
deficiency, grains
Major industries: tourism, sugar processing
Exports: $78 million (f.o.b., 1972 excluding reexports); sugar, copra, copper
Imports: $158 million (c.i.f., 1972); machinery, manufactured goods, food
Major trade partners: U.K., Australia, U.S., Japan, New Zealand
Aid: disbursed 1968 -- Australia $1.5 million, U.S. $600,000, U.K. $4.2 million
Monetary conversion rate: 0.77 Fijian dollar=US$1 (September 1973)
Fiscal year: calendar year
GDP: $10.9 billion (1972), less than $100 per capita; real average annual growth
(1965-70) 5.1%
Agriculture: subsistence food production, and smallholder and plantation
production for export; main crops -- rice, rubber, copra, other tropical
products; substantially self-sufficient; food shortage -- rice
Fishing: catch 1.26 million tons (1972); exports $4.5 million (1970), imports $0.3
million (1970)
Major industries: processing agricultural products and petroleum, textiles,
mining
Exports: $1,778 million (f.o.b., 1972); rubber, tin, copra, tea, coffee, tobacco,
palm oi1; petroleum, $1,134 million (510 million bbls.) (1972)
Imports: $1,458 million (f.o.b., 1972); rice, other foodstuffs, textiles, chemicals,
iron and steel products, machinery, transport equipment, consumer durables
Major trade partners: exports (1972) -- 15% U.S., 50% Japan, 8% Singapore, 4%
Netherlands; imports -- 15% U.S., 35% Japan, 8% West Germany, 6% Singapore
Budget: (1973-74) expenditures $2.1 billion; 60% current, 40% development
expenditures
Monetary conversion rate: 415 rupiah=US$1
Fiscal year: 1 April - 31 March
GNP: $22.5 billion (1973), $720 per capita; real GNP growth, 14%
Agriculture: wheat, barley, rice, sugar beets, cotton, dates, raisins, tea,
tobacco, sheep, and goats
Electric power: 2,851,000 kw. capacity (1972); 10.2 billion kw.-hr. produced
(1972), 330 kw.-hr. per capita
Exports: $4,151 million (non-oil, f.o.b. Iranian FY72/73); 88% petroleum; also
carpets, raw cotton, fruits, and nuts, hide and leather items, ores; Communist
countries (primarily U.S.S.R.) took about 41% of non-oil exports
Imports: $2,840 million (c.i.f., FY72/73); machinery, fron and steel products,
chemicals, pharmaceuticals, electrical equipment; Communist countries
supplied about 7% of commodity imports
Major trade partners: exports -- U.S., Japan, West Germany, U.S.S.R. and other
Communist countries; imports -- U.S., West Germany, U.K., Japan, U.S.S.R.
Budget: (FY73-74) $16.1 billion
Monetary conversion rate: 68.17 rials=US$1
Fiscal year: 21 March - 20 March
GNP: $5.8 billion (1973 est.), $560 per capita
Agriculture: dates, wheat, barley, rice, livestock; largely self-sufficient
in food
Major industry: crude petroleum (fourth largest producer in Middle East); 1.9
million b/d (1973); petroleum revenues projected for 1974, $6.4 billion
Electric power: 958,000 kw. capacity (1973); 4.1 billion kw.-hr. produced (1973),
393 kw.-hr. per capita
Exports: $1,392 million (1972 est.); net receipts from oi1, $1,317 million; non-oil,
$75 million est.
Imports: $800 million (1973 est.); 24% from Communist countries (1972)
165
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major trade partners: exports -- U.S. 2%, Italy 22%, France 19%, Netherlands 6%,
U.K. 4%; imports -- U.S. 4%, U.K. 9%, U.S.S.R. 7%, Czechoslovakia 7%,
France 6%
Monetary conversion rate: 1 Iraqi dinar=US$3.38 (end of July 1973)
Fiscal year: 1 April - 31 March
Agriculture: livestock raising predominates; main crops -- wheat, oats, barley
Industries: processing of animal products; building materials; mining
Exports: beef for slaughter meat products, wool, fluorspar, other minerals
uae machinery and equipment, petroleum, clothing, building materials, sugar,
and tea
Major trade partners: nearly all trade with Communist countries (approx. 80%
with U.S.S.R.); total turnover over $400 million (1972)
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 3.31 tugriks=US$1 (arbitrarily established)
Fiscal year: calendar year
233
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GNP: $1 billion (1972 estimate), $380 per capita; real average annual growth
rate (1960-69) 7.5%
Agriculture: main crops -- coconuts, coffee, cocoa, tea
Major industries: sawmilling and timber processing, copper mining (Bougainville)
Exports: $260 million (f.0.b., FY72); principal products -- copper, coconut
products, coffee beans, timber
Imports: $400 million (f.o.b., FY72)
267
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major trade partners: Australia, U.K., Japan
Aid: economic -- Australia (FY46-69) $909 million extended; World Bank group
(1968-September 1969) -- $7.5 million committed
military -- U.S. $28.7 million extended
Monetary conversion rate: Australian $1=US$1. 4875
Fiscal year: 1 July - 30 June
GNP: less than $100 per capita
Agriculture: principal crops -- corn, rice, rubber, coffee, copra
Exports: $5.3 million (f.o.b., 1971); 90% coffee, 6% copra
Imports: $8.5 million (c.i.f., 1971); textiles, beer and wine, petroleum
Major trade partners: 25.7% EC; 16.9% Portugal; 15.3% Portuguese possessions
Budget: 1971 -- receipts 279 million escudos, expenditures 249 escudos, deficit
30 million escudos
283
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Monetary conversion rate: Portuguese escudo known in Timor as pataca; 28.75
patacas=US$]
Fiscal year: calendar year','459f31cdb417a4100cabb7512a80c33f1e80a9d8bbb440ae75116069b63f7b2b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cd90dea54dd0353681443bfd37721557d92f4afce4c167c85caab8522a5806d',1974,'FI','Finland','economy',136,'GNP: $14.3 billion (1972), $3,050 per capita; 53% consumption, 26.2%
investment, 21.9% government, -1.1% net exports of goods and services; 1972
growth rate 4.8%, constant prices
Agriculture: animal husbandry, especially dairying, predominates; forestry
important secondary occupation for rural population; main crops -- cereals,
sugar beets, potatoes; 85% self-sufficient; shortages -- food and fodder
grains; caloric intake 2,940 calories per day per capita (1970-71)
Major industries: include metal manufacturing and shipbuilding, forestry and
wood processing (pulp, paper), copper refining
Shortages: fossil fuels; industrial raw materials, except wood, and iron ore
Crude steel: 1.4 million metric tons produced (1972), 300 kilograms per capita
Electric power: 6,000,000 kw. capacity (1973); 24.3 billion kw.-hr. produced
(1973), 5,700 kw.-hr. per capita
Exports: $3,715 million (f.o.b., 1973); timber, paper and pulp, ships, machinery,
iron and steel, clothing and footwear
Imports: $4,221 million (c.i.f., 1973); foodstuffs, petroleum and petroleum
products, chemicals, transport equipment, iron and steel, machinery, textile
yarn and fabrics
Major trade partners (1973): 46% EC-nine (15% West Germany, 15% U.K.); 18% Sweden;
12% U.S.S.R.; 5% U.S.
Aid: U.S, $182 million authorized FY46-72, $22.1 million in FY71, none in 1972, 1.5
million (prelim.) in 1973; IBRD -- $296.8 million authorized through 1946-72,
$33 million in 1971; Finnish foreign aid programs have amounted to $23 million
1961-69, $15,000 in 1970
Budget: (1973) expenditures $4.4 billion, revenues 4.2 billion
Monetary conversion rate: new markka (Fmk) 1=US$0.2543 (average daily exchange
rate 1973)
Fiscal year: calendar year','3c0b6b210aad8e3af11e437546b329b889cfde006e31f2d8848ece7312eab44d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21c9e3917bd89f6e60c146b243c7380b3b19f9a66fef57333139d388e754ebdd',1974,'FR','France','economy',140,'GNP: $254.9 billion (1973 est.), $4,880 per capita; 60% consumption, 27% investment
(including government), 12% government consumption; 1% net foreign balance (1972);
1973 real growth rate 6.1% (est.)
Agriculture: Western Europe''s foremost producer; main products -- beef, cereals,
sugar beets, potatoes, wine grapes; self-sufficient for most temperate zone
foodstuffs; food shortages -- fats and oils, tropical produce; caloric intake,
3,270 calories per day per capita (1969-70)
Fishing: catch 657,800 metric tons, $380 million (1972); exports $64 million,
imports $300 million (1972)
Major industries: steel, machinery and equipment, textiles and clothing,
chemicals, food processing, metallurgy
Shortages: crude oil, textile fibers, most nonferrous ores, coking coal, fats
and oils
Crude steel: 25.3 million metric tons produced (1973), 480 kilograms per capita
Electric power: 43,200,000 kw. capacity (1973); 174.5 billion kw.-hr. produced
(1973) 2,900 kw.-hr. per capita
Exports: $36.0 billion (f.o.b., 1973); principal items -- textiles and clothing,
iron and steel products, machinery and transportation equipment, foodstuffs
and agricultural products, alcoholic beverages
Imports: $37.5 billion (c.i.f. 1973); principal items -- machinery and
equipment, crude petroleum, iron and steel products, textile fibers, coal
and coke, foodstuffs, alcoholic beverages
Major trade partners: (1972) West Germany 24%; Belgium-Luxembourg 12%; Italy 12%;
Netherlands 6%; U.K. 6%; U.S. 7%; Eastern Europe 3%; U.S.S.R. 1%; franc zone 8%
Aid:
economic (received) -- U.S., $5,397 million authorized (FY46-73), $4]
million in FY73 (prelim.);
military -- U.S., $4,355 million authorized (FY46-72); net official economic
aid to less developed areas and multilateral agencies -- $8,400 million
(FY60-70), $1,125 million in 1971, $1,337 million in 1972
Budget: (1973) expenditures 204.1 billion francs, revenues 204.5 billion francs,
surplus 0.4 billion francs
Monetary conversion rate: 1 franc=US$0.2253 (1973 average)
Fiscal year: calendar year
GNP: $1,635 million (1973), $4,720 per capita; 1973 growth rate 7.2% at constant
prices; 60% consumption, 12% investment, 30% government, -2% net exports of
goods and services (1972)
Agriculture: mixed farming; main crops -- grains, potatoes, fodder beets; food
shortages -- sugar, bread grains, fats; caloric intake, 3,150 calories per
day per capita (1968-69)
Major industries: iron and steel, food processing, chemicals, metal products and
engineering, tires
Crude steel: 5.9 million metric tons produced (1973), 17,100 kg. per capita
Electric power: 1,210,000 kw. capacity (1973); 2.3 billion kw.-hr. produced
(1973), 6,930 kw.-hr. per capita
Exports: $999 million (f.0.b., 1972)
Imports: $959 million (c.i.f., 1972)
Major trade partners: Luxembourg and Belgium form an economic and customs union
and report their foreign trade jointly (see Belgium); Luxembourg''s principal
exports are iron and steel products; principal imports are coal and consumer
products; most foreign trade is with Germany, Belgium, and other EC countries
Aid: foreign aid to Luxembourg is included in aid to Belgium
Be cere expenditures $5.1 million, revenues $5.5 million, surplus $0.4
million
Monetary conversion rate: 1973 average 1 franc=US$0.0257 floating; under the BLEU
agreement, the Luxembourg franc is equal to the Belgian franc which circulates
freely in Luxembourg
Fiscal year: calendar year','e48aa761f600854b92ceec3c60d54aa77aca3c9954f40ee77e207947a23e7111','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17bf2a614b2684b80b65abeabe589eebdd1fa2d5c9a29443d4b5b7578a701361',1974,'GF','French Guiana','economy',144,'GNP: $40 million (at market prices, 1970), $800 per capita
Agriculture: main crops -- rice, corn, manioc, cocoa, bananas, sugarcane
Fishing: catch 900 metric tons, $378,000; shrimp exports $3.9 million;
imports $2.3 million (1969)
Major industries: timber, rum, gold mining, production of rosewood essence, and
~ space center
Electric power: 18,560 kw. capacity (1971); 55 million kw.-hr. produced (1971),
1,060 kw.-hr. per capita
Exports: $2.7 million (f.o.b. 1971); shrimp, timber, rum, rosewood essence
Imports: $39.8 million (c.i.f., 1971); food (grains, processed meat), other
consumer goods, producer goods and petroleum
Major trade partners: exports -- U.S. 78%, France 11%, Martinique 5%; imports --
France 49%, U.S. 10%, Trinidad and Tobago 3% (1969)
115
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Monetary conversion rate: 4.708 French francs=US$1 (1973)
Fiscal year: calendar year','7b99a33c3f3ce929de053a36a72697c6a809df3f91c89879ac5798250f9694a4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc1a7184abc2761e48c2aabd14f112f12b9e6ae5141020e3b024c22dbd768e07',1974,'PF','French Polynesia','economy',148,'GDP: $265 million (1970), $2,200 per capita
Agriculture: coconut main crop
Major industries: maintenance of French nuclear test base, tourism
Exports: $20 million (1970); principal products - coconut products (79%),
mother-of-pearl (14%}
Imports: $160 million (1971)
Major trade partners: imports - 59% France, 14% U.S.3 exports - 86% France
Monetary conversion rate: 70 CFP=US$1
Gross territorial product: $68 million (1970)
Agriculture: livestock; desert conditions limit commercial crops to about 15
acres, including fruits and vegetables
Industry: ship repairs
Electric power: 18,000 kw. capacity (1973); 20 million kw.-hr. produced (1973),
160 kw.-hr. per capita
Imports: $54 million (1972), almost all domestically needed goods
Exports: $27 million (1972), hides and skins
5, Aid: $2.4 million in 1967 from France
Monetary conversion rate: 177.72 Djibouti francs=US$1
Fiscal year: probably same as that for France (calendar year)
119
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','f30dfff1be5f0ac6949fbdcbe08efc8186c65971ed6809313f362537b0a4a6ce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b00e09590d40b30c8767fd9e7f5d81114ee8441ca5137464f2395a12e2c17e24',1974,'GA','Gabon','economy',152,'GDP: $407 million (1972, est.), $790 per capita; real GDP growth 8.5%
Agriculture: commercial -- cocoa, coffee, wood, palm oil, rice; main food crops
~- bananas, manioc, peanuts, root crops; imports food
Fishing: catch 4,000 metric tons (1970); exports $600,000 (1970)
Major industries: sawmills, petroleum refinery, natural gas, agricultural
processing; mining of increasing importance; major minerals -- manganese,
uranium, gold, and tron
Electric power: 34,200 kw. capacity (1973); 134 million kw.-hr. produced (1973),
255 kw.-hr. per capita
121
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $217.5 million (f.0.b., 1972); wood and wood products 40%; minerals
(manganese, uranium concentrates, gold, crude oil) 60% (1970)
Imports: $137.2 million (c.i.f., 1972) excluding UDEAC trade; mining, roadbuilding
machinery, electrical equipment, transport vehicles, foodstuffs, textiles *
Major trade partners: France, U.S., West Germany; and Curacao; preferential
tariffs to EC and franc zone
Budget: 1971 -- receipts $93.9 million, current expenditures $72.8 million,
investment expenditures $20.9 million
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1 as ‘és
of February 1973, (floating since February 1973)
Fiscal year: calendar year','dd8e7da9ce975f2dddc8988a63630105b4892fe81a9ef0eabe22df0c46d40040','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32fba99d5f01d31248669b52e41c44f76b422b8bf1b5b97ff62ca31d6e338530',1974,'GM','Gambia','economy',156,'GDP: $64 million (FY72 est.), about $160 per capita
Agriculture: main crops -- peanuts, rice, palm kernels
Fishing: catch 6,000 metric tons (1971); exports $108,000 (1971}
Major industry: peanut processing
Electric power: 7,100 kw. capacity (1973); 17 million kw.-hr. produced (1973),
44 kw.-hr. per capita
Exports: $17.2 million (FY72); peanuts and peanut products 90% to 95%, palm
kernels
Imports: $17.8 million (FY72); textiles, foodstuffs, tobacco, machinery,
petroleum products
Major trade partners: exports -- U.K. and France; imports -- U.K. and Japan
Aid: economic -- U.K. (1968-71) about $8 million commitment
Budget: (FY73 est.) expenditures $11 million, receipts $11.5 million
123
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Monetary conversion rate: floating with sterling since June 1972; new fixed
relationship as of March 1973 was 1 pound sterling=4 Gambian Dalasis
Fiscal year: 1 July - 30 June
GNP: $48.8 billion in 1973 (1972 prices), $2,860 per capita, 1973 growth rate
4.7%
Agriculture: food deficit area; main crops -- potatoes, rye, wheat, barley, oats,
industrial crops; shortages in grain, vegetables, vegetable oi], beef; caloric
intake, 3,000 calories per day per capita (1970-71)
Fish catch: 323,000 metric tons (1972)
Major industries: metal fabrication, chemicals, light industry, brown coal,
uranium, and shipbuilding
Shortages: coking coal, coke, crude 011, rolled steel products, nonferrous metals
Crude steel: 5.67 million metric tons produced (1972), approx. 330 kg. per capita
Electric power: 14,772,000 kw. capacity (1973); 76.9 billion kw.-hr. produced
(1973), 4,530 kw.-hr. per capita
Exports: $6,298 million (f.o.b. delivering country, 1972)
Imports: $6,014 million (f.o.b. delivering country, 1972)
Major trade partners: $12,312 million (1972); 38% U.S.S.R., 34% other
Communist countries, 29% non-Communist countries
Monetary conversion rate: 2.6 DME=US$1 (1973 rate; for 1972, 3.8 DME=US$1; prior
to 1972, 4.2 DME=US$1)
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for the consumption year
1] July ~ 30 June
NOTE: prelim. 1973 trade turnover, $19,100 million (converted at 2.8 DME=US$1)','00b05772d3c8e1b54f3178fa6b71f1c22dc99842a8659dc96f8b5d33c123e438','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6653648b28035fdebac95aee2f786bc3c3f2baab5adb6b6d8a84ced0fca76959',1974,'GH','Ghana','economy',160,'GDP: $2.6 billion (1971) at current prices, about $290 per capita; real growth
rate about 3.6%
Agriculture: main crop -- cocoa; other crops include root crops, corn, sorghum
as and millet, peanuts; not self-sufficient, but can become so
Fishing: catch 220,000 metric tons (1971), $35 million, imports $9.3 million
Major industries: mining, lumbering, light manufacturing, fishing, aluminum
Electric power: 893,000 kw. capacity (1972); 3.49 billion kw.-hr. produced
(1972), 380 kw.-hr. per capita
*
129
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $570 million (f.0.b., 1972); cocoa (about 75%), wood, gold, diamonds,
manganese, bauxite, and aluminum (aluminum regularly excluded from balance
of payments data)
Imports: $396 million (c.i.f., 1972); textiles and other manufactured goods,
food, fuels, transport equipment
Major trade partners: U.K., EC, and U.S.
Budget: FY71 (Provisional) -- expenditure $319 million, capital expenditure
$102 million
Monetary conversion rate: 1 Cedi=US$0.87 (official, March 1973); fixed in terms
of SDR''s
Fiscal year: 1 July - 30 June','133cb774151d6744d32d8862c0f95bf2fc064f2e9ae9277023a0d61d7b1b73fa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e19ec0e837f00e7546fb70a1d23ba4b7911515104a735095eaf840b1fef71aa',1974,'GI','Gibraltar','economy',163,'Economic activity in Gibraltar centers on commerce and large British naval and
air bases; nearly all trade in the well-developed port is transit trade and
port serves also as important supply depot for fuel, water, and ships'' wares;
recently built dockyards and machine shops provide maintenance and repair
services to 3,500-4,000 vessels that call at Gibraltar each year.
U.K. military establishments and civil government employ nearly half the insured
labor force; local industry is confined to manufacture of tobacco, roasted
coffee, ice, mineral waters, candy, and canned fish; some factories for
manufacture of clothing are being developed; a small segment of local
population makes its livelihood by fishing; in recent years tourism has
increased in importance.
13]
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Electric power: 17,000 kw. capacity (1972); 47 million kw.-hr. produced (1972),
1,500 kw.-hr. per capita
Exports: $2.9 million (f.o.b., 1971); principally reexports of tobacco,
petroleum, and wine; principally to the EC (31%) and the U.K. (16%)
Imports: $23.1 million; principally from the EC (21%) and the UK (49%)
Major trade partners: U.K., Morocco, Portugal, Netherlands
Monetary conversion rate: 1 Gibraltar pound=US$2.414 (as of September 28, 1973,
floating)
GNP: $8.5 million (1968), $155 per capita
Agriculture: subsistence crops of copra, vegetables, supplemented by domestic
fishing
Industry: phosphate production, expected to cease in 1976
Exports: $8 million (1969 est.); 75% phosphate, copra
Imports: $3 million (1969 est.); foodstuffs, fuel
Monetary conversion rate: 0.67 Australian $=US$1','433fc5576dc7fe7abe47f5d445deafbe0a99fb17c179fdd0047d92f57d3d137c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4ae45579a96d7c1e088cb7cf55f5c5efcd2a78f2a455167d5bf20760cc398b9',1974,'GR','Greece','economy',168,'GNP: $15.9 billion (1973), $1,780 per capita; 66.4% consumption, 28.8% investment;
12.7% government; net foreign balance 7.9%; 1972 growth rate 26.8%, current
market prices
Agriculture: subject to droughts; main crops -- wheat, olives, tobacco, cotton;
nearly self-sufficient; food shortages -- livestock products; caloric intake,
2,960 calories per day per capita (1963)
Major industries: food processing, tobacco, chemicals, textiles, petroleum
refining, aluminum processing
Shortages: petroleum, minerals, feed grains
Crude steel: 900,000 metric tons produced (1973), 100 kg. per capita
Electric power: 3,200,000 kw. capacity (1973); 13.5 billion kw.-hr. produced
(1973), 1,400 kw.-hr. per capita
Exports: $1,230 million (f.o.b., 1973); principal items -- tobacco, cotton, fruits,
textiles
Imports: $4,047 million (c.i.f., 1973); principal items -- machinery and
automotive equipment, manufactured consumer goods, petroleum and petroleum
products, chemicals, meat and live animals
Major trade partners: (1972) -- 50% EC, 13% sterling area, 17% U.S.,
10% CEMA countries
Aid:
economic (authorized) -- U.S., $1,992.2 million (FY46-73); International
Finance Corporation, $36 million through FY72; U.N. Technical Assistance,
$4.3 million through FY72; U.N. Special Fund, $63.1 million through 1972;
IBRD, $119.8 million (FY68-73), $24 million in 1972; Consortium, $40
million in 1966; EC (FY64-72) $69.2 million; U.S.S.R. $7.7 million (1954-73)
military -- U.S., $2,339.0 million (1946-73)
Budget: (1973) expenditures $3,389 million, revenues $2,718 million
Monetary conversion rate: 1 drachma=US$0.033
Fiscal year: calendar year','9f9760b83d12a1cde8bc667c2c086dbfe00a438de00de1ed1cb561cb542d8dba','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79dad57aa68237b8835e2f3833da40f73731ad5c93fba7879860acb898c79102',1974,'GL','Greenland','economy',172,'GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep grazing; garden produce
Fishing: catch 38,400 tons, $6.3 million; exports $16.0 million (1971)
Major industries: mining, slaughtering, fishing, sealing
Electric power: 49,400 kw. capacity (1971); 86 million kw.-hr. produced (1971),
1,650 kw.-hr. per capita
Exports: $18.8 million (f.o.b., 1970); fish and fish products, nonmetallic minerals
Imports: $61.0 million (f.0.b., 1971); machinery and transport equipment,
petroleum and petroleum products, food products
Major trade partners: (1970) Denmark 91%, U.S. 3%, Venezuela 3%
Monetary conversion rate: 1 Danish Kroner=US$0.1659, (1973 average)
Fiscal year: 1 April - 31 March','c1602935cce1b01d1e210835c256bf26cc4d7a45078039c03b9209bad4abfb3a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a421f5e60b0922c6da4d8322e68c881d8def12c681c232b0e5c940d2dd698fb5',1974,'GP','Guadeloupe','economy',177,'GDP: $302 million (1971), $880 per capita; real growth rate (1971) 5.9%
Agriculture: main crops, sugarcane and bananas
Major industries: agricultural processing, sugar milling and rum distillation
Electric power: 24,000 kw. capacity (1971); 110 million kw-hr. produced
(1971), 318 kw.-hr. per capita
Exports: $40 million (f.o.b., 1972), Sugar, bananas, rum
Imports: $152 million (c.i.f., 1972), foodstuffs, clothing and other consumer
goods, raw materials and supplies, and petroleum
Major trade partners: exports -- France 71%, U.S. 17%, Germany 7%, other
5%; imports -- France 70%, U.S. 9%, Germany 3%, Netherlands Antilles 3%,
Netherlands 3%, other 12% (1968)
141
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Monetary conversion rate: 4.708 French francs=US$1 (1972)
Fiscal year: calendar year','330039dc84f5b67e48cf3f4b715281b718f25d1920d38e8e24346f594811d940','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf4657997c910d4ebd12da0ff36a9fb42f927dc7e04ced2e3702d8b3361104e5',1974,'GN','Guinea','economy',183,'GDP: about $275 million (1965), $80 per capita
Agriculture: cash crops -- coffee, bananas, palm products, peanuts, and pine-
apples; staple food crops -- cassava, rice, millet, corn, sweet potatoes;
livestock raised in some areas
Major industries: alumina, light manufacturing and processing industries,
bauxite
Electric power: 99,700 kw. capacity (1972); 310 million kw.-hr. produced (1972),
77 kw.-hr. per capita
Exports: export receipts, $51 million (FY71); alumina, bauxite, coffee,
pineapples, bananas, palm kernels
Imports: $80 million (FY71); petroleum products, metals, machinery and
transport equipment, foodstuffs, textiles
145
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major trade partners: Communist countries, Western Europe (including France),
U.S
Budget: FY72 ordinary budget (est.) -- $113 million
Monetary conversion rate: 22.7 syli=US$1 (October 1972)
Fiscal year: 1 October - 30 September','c3f09f5e6e3993c8082dc653605eff04b1d4a5dd7034c90c1aaf38cacb065778','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('214943dbf85a24df5c5db4152bfc6753cb195f0c74f7849d50534a9008f78b9d',1974,'HK','Hong Kong','economy',190,'GNP: $4.8 billion 1973 (est.), $1,160 per capita (est.)
Agriculture: agriculture occupies a minor position in the economy; main products --
rice, vegetables, dairy products; less than 20% self-sufficient; food
shortages -- rice, wheat
Major industries: textiles and clothing, tourism, plastics, electronics, light
metal products, food processing
Shortages: industrial raw materials, water, food
153
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $5.1 billion (f.o.b., 1973), including $1.3 billion reexports; principal
products clothing, plastic articles, textiles, electrical goods, wigs,
footwear, Tight metal manufactures
Imports: $5.7 billion (c.i.f., 1973)
Major trade partners: 1972 exports -- U.S. 40%, U.K. 14%, West Germany 10%; imports
-- Japan 23%, China 18%, U.S. 12%
Monetary conversion rate: HK$5.085=US$1
Fiscal year: 1 April - 31 March','1dbc2c5b1e2a2521b00c3570f29f05c4bcd3a2c789a4767a51a7553ec2387cc9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('695a42cec58077e170453fbcd42aa82766f73c9368b0a4a8f3fe48134fb58e30',1974,'HU','Hungary','economy',194,'GNP: $19.2 billion in 1973 (at 1972 prices), $1,840 per capita; 1973 growth
rate 4.9%
Agriculture: normally self-sufficient; main crops -- corn, wheat, potatoes,
sugar beets, wine grapes; caloric intake 3,140 calories per day
per capita (1970)
Major industries: mining, metallurgy, engineering industries, processed foods,
textiles, chemicals Vaspecially pharmaceuticals)
Shortages: metallic ores (except bauxite), copper, high grade coal, forest
products
* Crude steel: 3.33 million metric tons produced (1973), 320 kg. per capita
155
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $4,594 million (f.o.b., 1973); 27% machinery, 20% industrial consumer
goods, 28% raw materials and semimanufactures, 24% food and raw materials
for the food industry, energy sources 1% (distribution for 1973)
Imports: $4,076 million (1973); 21% machinery, 10% industrial consumer goods,
51% raw materials and semimanufactures, 10% food and raw materials for the
food industry, energy sorces 8% (distribution for 1973)
Major trade partners: $8,670 million (1973); 66% with Communist countries, 34%
with non-Communist countries
Monetary conversion rate: 9.15 forints=US$1 (commercial); 23.4
forints=US$1 (noncommercial); old commercial rates: 10.81 forints=US$1 in
1972; 11.74 forints=US$1 prior to 1972
Fiscal year: same as calendar year; economic data reported for calendar years
NOTE: Foreign trade figures were converted at the 1973 rate','0b4900dca859a283bdd1bcd81967f97e23c2d183d55d4de7d71ce1e1e7569f0d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fbc3c548d75627bc253925bab2dc80e2ed6840c25030c700c232bcb67096f58',1974,'IN','India','economy',198,'GNP: $59 billion in current prices est. (year ending 37 March 1973), $100 per
capita; real growth (FY73), 6% est.
Agriculture: main crops -- rice, other cereals, pulses, oilseeds, cotton, jute,
sugarcane, tobacco, tea, and coffee; must import foodgrains; caloric intake
is low and diet is deficient in protein
Fishing: catch 1.9 million metric tons (FY71-72); exports $52 million (FY71-72),
imports $100,000
Major industries: textiles, food processing
Crude steel: 6 million metric tons produced (FY73)
Exports: $3.0 billion est. (f.o.b., FY72); tea, jute manufactures, iron ore, cotton
textiles, leather and leather products
Imports: $3.2 billion est. (c.i.f., FY73); machinery and transport equipment,
petroleum, iron and steel, grains and flour
Major trade partners: U.S., U.K., U.S.S.R. and Eastern Europe, Japan
Monetary conversion rate: 7.5 rupees=US$1 (effective April 1973)
Fiscal year: 1 April, stated year - 31 March','a6591b2b369a7a013420bf508a3d962cbf5756340a696152fec94d99ad06bd6a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7ef3e3d4635ec49c345ccd702017797db7f7793dbb10c712d9d3d94137712a5',1974,'IT','Italy','economy',204,'GNP: $125 billion (1973), $2,290 per capita; 65.6% private consumption, 21.8%
gross investment, 14.3% government, net foreign balance -1.7% (1973 provisional);
1972 growth rate 3.2%, 1973 growth rate 5.1%, 1963 constant prices
Agriculture: important producer of fruits and vegetables; main crops -- cereals,
potatoes, olives; 95% self-sufficient; food shortages -- fats, meat, fish,
and eggs; caloric intake, 3,100 calories per capita (1970)
Fishing: catch 391,200 metric tons (1971), $251.8 million (1971); exports $22
million (1972), imports $132 million (1972)
Major industries: machinery and transportation equipment, iron and steel,
chemicals, food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 19.7 million metric tons produced (1972), 360 kilograms per capita
Electric power: 37,000,000 kw. capacity (1972); 133 billion kw.-hr. produced
(1972), 2,430 kw.-hr. per capita
Exports: $20.0 billion (f.o.b., 1973); principal items -- machinery and
transport equipment, textiles, foodstuffs, chemicals, footwear
Imports: $25.1 billion (c.i.f.. 1973); principal items -- machinery and transport
equipment, foodstuffs, ferrous and nonferrous metals, wool, cotton, petroleum
Major trade partners: (1972) 46% EC-six (22% West Germany, 15% France, 5%
Netherlands, 4% Belgium-Luxembourg); 3% Switzerland; 9% U.S.; 5% U.S.S.R. and
other Communist countries of Eastern Europe
Aid:
economic -- U.S., $4,064.8 million (FY46-73), $78.2 million authorized FY73;
IBRD, $400 million authorized through FY72, none since FY65; International
Finance Corporation, $1 million authorized through FY72, none since FY60;
military -- U.S., $2,491.1 million (FY46-73}, $11.6 million (prelim. )
authorized in FY73
Monetary conversion rate: smithsonian rate as of December 1971, 581.5 lira=US$1;
average of Friday closing rates in 1974 to April -- 647 lira=Us $2
Fiscal year: calendar year
GDP: $1.8 billion (1972), $360 per capita (1971); average annual growth
rate 1960-70, 8.3%
Agriculture: commercial -- coffee, wood, cocoa, bananas, pineapples, palm oil;
food crops -- corn, millet, yams, rice; other commodities -- cotton, rubber,
tobacco, fish; self-sufficient in most foodstuffs, but rice, sugar, and meat
imported
Fishing: catch 62,600 metric tons (1971); $14.7 million, exports $2.6 million
(1970), imports $5.2 million (1971)
Major industries: food and lumber processing, oi] refinery, automobile assembly
plant, textiles, soap, flour mill, matches, three small shipyards, fertilizer
plant, and battery factory
175
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Electric power: 238,900 kw. capacity (1972); 788 million kw.-hr. produced (1972),
157 kw.-hr. per capita
Exports: $553 million (f.0.b., 1972); coffee, tropical woods, cocoa, 80% of total;
bananas, pineapples, palm oil
Imports: $454 million (c.i.f., 1972); consumer goods about 40%, raw materials and
fuels 10%, manufactured goods and semi-finished products, about 50%
Major trade partners: France and other EC countries about 65%, U.S. 13%, Communist
countries about 1%
Aid:
economic -- France (1960-69) $312 million; EC $123 million, including 1971
commitments; U.S. (FY61-72), $110 million; others (1960-71), $76 million,
including $18.5 million comitted; no Communist aid programs
military -- non-Communist countries, $7.3 million (1954-67)
Budget: 1972 est. -- revenues $369.1 million, current expenditures $280.3 million,
investment expenditures $136.4 million
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
as of February 1973, floating since February 1973
Fiscal year: calendar year','b860ed3ac5166905fe8d163de8193ad20b3675a477ff3671356e27835ef0d109','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3eaa77ed4593da4089a1c182a911e2ca4c2f622f1952d6d47e088923713ee01d',1974,'JM','Jamaica','economy',207,'GNP: $1,356 million (1972), $700 per capita; real growth rate 1972, 6% est.
Agriculture: main crops -- sugarcane, citrus fruits, bananas, pimento, coconuts,
coffee, cocoa
» Major industries: bauxite, textiles, food processing, light manufactures, tourism
Electric power: 556,000 kw. capacity (19719; 1.6 billion kw.-hr. produced
(1971), 860 kw.-hr. per capita
77
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $386 million (f.o.b., 1973); alumina, bauxite, sugar, bananas, citrus
fruits and fruit products, rum, cocoa
Imports: $621 million (c.i.f., 1973); machinery, transportation and electrical
equipment, food, fuels, fertilizer
Major trade partners: exports -- U.S. 44%, U.K. 22%, Canada 5%, Norway 11%;
imports -- U.S. 37%, U.K. 19%, Canada 7% (1972)
Aid:
economic -- from U.S. (FY56-72), $80.2 million in loans; $47 million grants;
from international organizations (FY46-72), $94.8 million; from other Western
countries (1960-71), $90.2 million;
military -- assistance from U.S. (FY63-72), $1.1 million
Monetary conversion rate: 1 Jamaican dollar=US$1.10
Fiscal year: 1 April - 31 March','dc55dca3d150709eb4bb2a587712e7d58d0f5afcd2377350b7669f55a8ddc6a0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad47b19b3e137f603a3a1028a841203943c52c2b499319a0899f84a54257b397',1974,'JO','Jordan','economy',211,'GNP: $800 million (1973 est.), $320 per capita
Agriculture: main crops -- wheat, fruits, vegetables, clive oil; not self-
sufficient in many foodstuffs
Major industries: phosphate mining, petroleum refining, and cement production
Electric power: 46,300 kw. capacity (1973); 158 million kw.-hr. produced (1973),
62 kw.-hr. per capita
Exports: $53 million (f.o.b., 1973); major items -- fruits and vegetables,
phosphate rock; Communist share 5% of total (1971)
Imports: $233 million (c.i.f., 1973); major items -- petroleum products, textiles,
‘ capital goods, motor vehicles, foodstuffs; Communist share 17% of total (1971)
id:
economic -- U.S., $676 million economic assistance (FY49-72), of which $34
million loans, $642 million grants;
military -- $195 million total from U.S. (FY49-72) including $120 million in
MAP grants
Monetary conversion rate: 1 Jordanian dinar=US$3,12, freely convertible; 0.321
Jordanian dinar=US$1
Fiscal year: calendar year','588b1e396264d1c944a00abdd94dce0fa609215642357ae3a2bd827aab3f5b6f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7f660c2e6ee0ef77f84db0c8eba8d20320ee490aeab8a5fdf3ecd5085fef0b8',1974,'KE','Kenya','economy',215,'GDP: $1,574 million at 1967 prices (1972), $130 per capita; 7% real growth (1972)
Agriculture: main cash crops -- coffee, sisal, tea, pyrethrum, cotton, lives tock ;
food crops -- corn, wheat, rice, cassava; largely self-sufficient in food
Fishing: $4.2 million (1970)
Major industries: small-scale consumer goods (plastic, furniture, batteries,
textiles, soap, agricultural processing, cigarettes, flour), oi] refining,
cement
Electric power: 217,000 kw. capacity (1972); 875 million kw.-hr. produced (1972),
70 kw.-hr. per capita
183
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Exports:
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
cont''d):
$339 million (f.0.b., 1972); coffee, tea, livestock products, pyrethrum,
soda ash, wattle-bark tanning extract
Imports: $518 million (c.i.f., 1972); machinery, transport equipment, crude oil,
paper and paper products, iron and steel products, and textiles
Major trade partners: U.K. and EC, also Uganda and Tanzania, which are part of
East African Economic Community
Budge
t: FY73 current expenditure $372 million
Monetary conversion rate: 1 Kenya shilling=US$0.14 (official); 6.90 Kenya
shillings=US$1
Fiscal year: 1 July - 30 June
GNP: $5.3 billion (1972), $40 per capita
Agriculture: main crops -- rice, corn, vegetables; food shortages -- meat,
cooking oils; production of foodstuffs adequate for domestic needs at low
levels of consumption
Major industries: machine building, electric power, chemicals, mining, metallurgy,
textiles, food processing
Shortages: heavy machinery and equipment, bituminous and coking coal, petroleum,
rubber
Exports: $400 million; minerals, chemical and metallurgical products (1972)
Inports: $640 million; machinery and equipment, petroleum, foodstuffs, coking
coal (1972)
Major trade partners: total trade turnover $1 billion (1972); about one-fourth
with non-Communist countries, three-fourths with Communist countries (almost
one-half with the U.S.S.R.)
185
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Aid:
economic and military aid from the U.S.5.R. and China
Monetary conversion rate: 2.15 won=US$1 (arbitrarily established)
Fiscal year: calendar year
GNP: $12.3 billion (1973), $370 per capita; real growth 16.9% (1973)
Agriculture: 45% of the population live on the land, but agriculture, forestry
and fishery constitute 23% of GNP; main crops -- rice, barley, wheat; not
self-sufficient; food shortages -- barley, wheat, dairy products, rice, corn
Fishing: catch 1,343,000 metric tons, $262 million (1972 est.)
Major industries: textiles and clothing, food processing, chemical fertilizers,
chemicals, plywood, coal
Shortages: base metals, fertilizer, petroleum, lumber and certain food grains
Exports: $3.2 billion (f.0.b., 1973); clothing and textiles, veneer and plywood,
wigs, fish products, electrical products, iron and steel scrap
Imports: $3.9 billion (c.i.f., 1973)
Major trade partners: exports -- U.S. 31%, dapan 40%; imports -- Japan 38%,
U.S. 30% (1973)
Aid:
economic -- U.S. (FY46-73), $5.9 billion committed; Japan (1965-71), $730
million extended;
military -- U.S. (FY46-72), $5.7 billion committed
Monetary conversion rate: rate fixed at 400 won=US$1 since end of 1972
Fiscal year: calendar year
GNP: $4.4 billion (1973 est.), $4,380 per capita est.
Agriculture: virtually none, dependent on imports for food; approx. 75% of
potable water must be distilled or imported
Major industries: crude petroleum production averaging 2.9 million b/d (includes
Kuwait''s share of neutral zone) (1973); government revenues from taxes and
royalties on production, refining, and consumption $7.3 billion est. for
1974; refinery capacity 504,000 b/d est, (1970); other major industries
include fishing, processing of building materials, fertilizers, chemicals,
and flour
Electric power: 1,070,800 kw. capacity (1972); 3.2 billion kw.-hr. produced
(1972), 3,280 kw.-hr. per capita
Exports: $1,785 million (FY71-72), of which petroleum accounted for about 98%;
nonpetroleum exports are mostly reexports, $137 million (f.0.b., FY71-72)
Imports: $819 million (FY71-72); major suppliers -- U.S., Japan, U.K., West','938f03241ae5851cd23d3543d8b101d738ae9c348b0a62e01e468f2a354f91d9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('564629d0b07dc5e72f66da6beb1a1136358d8d89b5e2c6fdfd320ed2853a205a',1974,'DE','Germany','economy',216,'189
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Budget: (FY74-75) $26 million
Monetary conversion rate: 1 Kuwaiti dinar=US$3.38 (October 1973)
Fiscal year: 1 April - 31 March
GNP: $220 million, $70 per capita (1972 est.)
Agriculture: main crops -- rice (overwhelmingly dominant), corn, coffee, cotton
and tobacco; largely self-sufficient; food shortages (due in part to
distribution deficiencies) including rice
Fishing: catch data unavailable; imports fish and fish products 200 tons,
$128,000 (1970)
191
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major industries: tin mining, timber
Shortages: capital equipment, petroleum, transportation system
Electric power: 54,500 kw. capacity (1973); 240,000,000 kw.-hr. produced (1973),
75 kw.-hr. per capita
Exports: $2.6 million (f.o0.b., 1972); tin concentrates; forest products, coffee,
undeclared exports of opium significant but value unknown
Imports: $44 million (c.i.f., 1972); rice and other foodstuffs, petroleum
products, machinery, transportation equipment, textiles
Major trade partners: imports from Thailand, Japan, U.S., France, U.K., Indonesia,
Hong Kong; exports to Malaysia and Thailand; trade with Communist countries
insignificant; Laos a major transit point in world gold trade; vatue
of 1972 gold imports $2.4 million
Monetary conversion rate: 840 kip=US$1 for most transactions
Fiscal year: 1] July - 30 June
COMMUN ICAT IONS :
Highways: about 9,600 mi. (including Conmunist-held areas); 800 mi. bituminous
or bituminous treated, 3,100 mi. gravel, crushed stone, or improved earth;
5,700 mi. unimproved earth and often impassable during rainy season
mid-May to mid-September
Inland waterways: about 2,850 mi., primarily Mekong and tributaries; 1,800
additional miles are sectionally navigable by craft drawing less than 1.5 ft.
Ports (river): 5 major, 4 minor
Airfieids: 414 total, 127 usable; 7 with permanent-surface runways; 12 with
runways 4,000-7,999 ft., 1 with runway 8,000-11,999 ft.
DEFENSE FORCES:
Military manpower: males 15-49, 769,000; 410,000 fit for military service;
average number currently reaching usual military age (18) annually, 34,000;
no conscription age specified
192
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','5204e65ec8c584855b25a3a423f900f68eb703f3affdf5c1259d95ccb8f238b8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ad0cca7642c63a828894b3ea3b25a164fb36eaf4b64eead2910eaa77f7285fe',1974,'LB','Lebanon','economy',220,'LAND:
= 4,000 sq. mi.; 27% agricultural land, 64% desert, waste,
or urban, 9% forested
Land boundaries: 285 mi.
WATER:
Limits of territorial waters (claimed): no specific laims
* (fishing, 6 n. mi.)
Coastline: 140 mi.
Agriculture: fruits, wheat, corn, barley, potatoes, tobacco, olives, onions; not
self-sufficient in food
Major industries: service industries, food processing, textiles, cement, oi]
refining, chemicals, some metal fabricating, tourism
Electric power: 560,900 kw. capacity (1972); 1.5 billion kw.-hr. produced
(1972), 500 kw.-hr. per capita
Major trade partners: exports $355 million (f.o.b., 1972); most to Arab
countries; imports $850 million (c.i.f., 1972); chiefly from EC, U.K., and
Arab countries; trade deficit covered by large net receipts from invisibles
(particularly tourism and transportation) and private capital inflow
Monetary conversion rate: 1 Lebanese pound=US$0.44 as of April 1974
Fiscal year: calendar year','6a7d271b15413561386392d3f70f50492ac9c923f869607edf4980f3ebbf4edb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de21f1e63e0f12f06c3cbd946aa71f50231095003baf9a97ddf472c4d9893506',1974,'LS','Lesotho','economy',227,'GNP: $90 million (FY71 est.), about $100 per capita; growth rate (incurrent
prices), 6% annually (FY67-71 est.)
Agriculture; exceedingly primitive, mostly subsistence farming and livestock;
principal crops are corn, wheat, pulses, sorghum, barley
Major industries: none
Electric power: 2,820 kw. capacity (1973); 6 million kw.-hr. produced (1973),
6 kw.-hr. per capita
Exports: labor to South Africa (remittances $11 million est. in FY72); $6 million
(f.0.b., FY73), wool, mohair, wheat, cattle, diamonds, peas, beans, corn,
hides, skins
Imports: $55 million (f.o.b., FY73); mainly corn, building materials, clothing,
vehicles, machinery, POL
195
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major trade partner: South Africa
Aid: economic aid; U.K. $9.4 million (plan FY71-75); other $17.5 million (plan
FY71-75); U.S. $13.4 million authorized; no military aid
Budget: (FY74) expenditures $31 million, revenues $29 million
Monetary conversion rate: Lesotho uses the South African rand; 1 SA rand=US$1.42
(par value); .7046 SA rand=US$1
Fiscal year: 1 April - 31 March','e65a8a08da12eb30a5fa333de7864a946d057806737e2e9596a0a4cb207d3857','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8755ca3fae643e60448aab0685742758483f74a911e048d750e24067fadca57f',1974,'LR','Liberia','economy',231,'GDP: $459.6 million (1972 est.), 5.0% current annual growth rate, $280 per capita
Agriculture: rubber, oi] palm, cassava, coffee, rice; imports of rice, wheat,
and meat are necessary for basic diet
Fishing: catch 22,500 metric tons, $6.1 million (1969)
Industry: rubber processing, food processing, construction materials, furniture,
palm oi1 processing, mining (iron ore, diamonds), 10,000 b/d oi] refinery
Electric power: 225,200 kw. capacity (1972); 788 million kw.-hr. produced (1972),
483 kw.-hr. per capita
Exports: $244 million (f.0.b., 1972); iron ore, diamonds, rubber, palm
kernels, coffee, cocoa
Imports: $179 million (c.i.f., 1972); machinery, transportation equipment,
foodstuffs, manufactured goods
Major trade partners: U.S., West Germany, Japan, U.K.
Aid:
economic -- (FY46-72) U.S., $296.2 million;
military -- (FY53-72) U.S., $11.3 million; other aid sources include IBRD,
U.N., IMF, and West Germany
Budget: (FY73) expenditures $88 million, revenues $91 million
Monetary conversion rate: Liberia uses U.S. currency
Fiscal year: calendar year','0884aefa10c8db21d1b342d73a7052c76dd8f8415ce29502ac16e3559181562e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f10d3620376c7ca913d011066bc67d16791be167ae0e1e4b951c7098f62825ca',1974,'LY','Libya','economy',235,'GDP: $4.8 billion (FY72), $2,400 per capita, little real per capita change
v since 1969
Agriculture: main crops -- wheat, barley, olives, dates, citrus fruits, peanuts;
not self-sufficient in food
199
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major industries: petroleum production averaged 2.2 million b.p.d. (1972);
oil revenues for 1972 about $1.6 billion; food processing, textiles, handicrafts
Electric power: 280,000 kw. capacity (1972); 640 million kw.-hr. produced (1972),
310 kw.-hr. per capita
Exports: $2,938 million (1972); over 99% petroleum
Imports: $1,104 million (1972, c.i.f.)
Major trade partners: imports -- Italy, West Germany, U.S.; exports -- Italy,
West Germany, U.K., France
Aid: economic -- no Communist country assistance; U.S. aid extended $212.5
million (FY49-72)
military -- arms obtained by cash purchase; chief suppliers France, U.S.S.R.,
Czechoslovakia; U.S. suspended since September 1969
Monetary conversion rate: 1 Libyan pound=US$3.38, February 1973
Fiscal year: 1 April - 31 March','00789c9861b286f974430cc73036e4135255e4767c9da4dd1a99fb1ee28b1b3c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8b7d2156fa8d3329cc045ee548fb46afe61ee528e4b8615d5db8e18f3294205',1974,'LI','Liechtenstein','economy',239,'Despite its smal] size and sparse natural resources, Liechtenstein has a
prosperous economy based primarily on small-scale light industry and farming.
Textiles, ceramics, precision instruments, pharmaceuticals, and canned foods
are the principal manufactures produced, almost entirely for export. Live-
stock raising and dairying are the main sources of farm income; cereals and
potatoes are the most important farm crops. The Liechtenstein economy is
tied closely to that of Switzerland in a virtual customs union. No national
accounts data are available.
Major trade partners: exports (1972) -- $138.6 million; 34% Switzerland, 35% EC,
48% EFTA
Electric power: 22,600 kw. capacity (1972); 55 million kw.-hr. produced (1972),
1,800 kw.-hr. per capita; power is exchanged with Switzerland, but net
* exports average 35 million kw.-hr. yearly','27bd48af590d5eb3ce758bca50502b98a1c0da456187d7919fc8722c2b4df9af','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('384df15e42f74947db0372ecb066b2e7e6a1ea1ca60e516f649fd24c0567a375',1974,'MO','Macao','economy',244,'Agriculture: main crops -- rice, vegetables; food shortages -- rice, vegetables,
meat; depends mostly on imports for food requirements
Major industries: textiles, fireworks
Exports: $50 million (f.0.b., 1971); textiles and clothing, foodstuffs, fireworks
Imports: $77 million (f.0.b., 1971)
Major trade partners: exports -- Portuguese colonies 21%, Hong Kong 16%, West
Germany 17%; imports -- Hong Kong 65%, China 27% (1971)
Monetary conversion rate: 5.486 patacas=US$1 (June 1972)
Fiscal year: calendar year
205
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','60946619d2bcd78f1da1f4da7a8005feb73d95f2b476290ae2937f41c696565c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df64d1c84bf77844fd6efa4ee3c919b11ea3bf7c988cc3eab16c5917958df41b',1974,'MG','Madagascar','economy',248,'GDP: $970 million (1971), about $140 per capita; a real increase of 4.5% between
1967 and 1971
Agriculture: cash crops -- coffee, vanilla, sugar, tobacco, sisal, rice, cloves,
raphia; food crops -- rice, cassava, cereals, potatoes, corn, beans, bananas,
coconuts, and peanuts; animal husbandry widespread; self-sufficient in food-
stuffs, but some milk and cereals imported
Fishing: catch 48,000 metric tons (1971); exports $4.4 million (1971), imports
$800,000 (1971)
Major industries: agricultural processing (meat canneries, soap factories,
brewery, tanneries, sugar refining), light consumer goods industries
(textiles, glassware), cement plant, auto assembly plant, paper mill, oi]
refinery
Electric power: 58,000 kw. capacity (1973); 213 million kw.-hr. produced (1973),
30 kw.-hr. per capita
Exports: $164 million (f.o.b., 1972); coffee 26%, rice 5%, vanilla 9%, sugar
3%, petroleum products 4%, cloves 14%, mineral products (graphite, mica, and
chromite) 4%; agricultural and livestock products account for about 85% of
export earnings
Imports: $202 million (c.i.f., 1972); consumer goods 30%, foodstuffs 14%, primary
products (crude oi], fertilizers, metal products) 28%, capital goods 28% (1971)
Major trade partners: France (in 1971 accounted for 34% of exports and 56% of
imports); U.S., preferential tariffs to EC and franc zone countries; trade
with Communist countries remains a minute part of total trade
Budget: (FY73) revenues $222 million, expenditure, $330 million
Monetary conversion rate: 255.78 Malagasy francs=US$1 (as of February 1973,
floating since then); member of French franc zone
Fiscal year: calendar year','f98af9a3f50b7b9d48796b2f0e342137a74dbd92e1d2bfa9e1bae60fb590a73b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85d904e1eb4070613eb7fd1558952e4f454a15c94cbe3e981d9f95de0273c617',1974,'MW','Malawi','economy',252,'GDP: $420 million (1972), $90 per capita; real growth rate 7.7% (1972)
Agriculture: cash crops -- tea, tobacco, peanuts, cotton, tung; subsistence
crops -- com, sorghum, millet, pulses, root crops, fruit, vegetables, rice
Electric power: 65,000 kw. capacity (1973); 228 million kw.-hr. produced (1973);
47 kw.-hr. per capita
Major industries: agricultural processing (tea, tobacco, sugar), sawmilling,
cement, consumer goods
Exports: $81 million (f.0.b., 1972); tobacco, tea, groundnuts, cotton
Imports: $130 million (c.i.f., 1972); manufactured goods, machinery and
transport equipment, food, fuels
Major trade partners: exports -- U.K., Zambia, Rhodesia, U.S.; imports -- U.K.,
Rhodesia, South Africa
Aid:
economic -- U.K. provides both budgetary and development support, about
$96 million (1966-71); U.S. aid commitments, $29.6 million (FY56-72);
military -- U.K., $0.9 million (1954-68)
209
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Budget: FY74 current expenditure $75 million
Monetary conversion rate: 1 Malawi kwacha=US$1.26 (as of November 1973, floating
with the average value of the pound sterling and the U.S. dollar)
Fiscal year: 1 April - 31 March','8e8a3bb88b3941a9908bdd0382065570c24febe8c31d7e3597390513f60ae962','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9182fc118f665c1326fd766134c3c912c8404a84784a12cb5f91cf409b05063d',1974,'MY','Malaysia','economy',256,'- GNP:
Malaysia: $6.6 billion (1973), $600 per capita; average annual real growth
(1968-73) 5.6%
Agriculture:
West Malaysia: mixed plantation and subsistence; main crops -- rubber, rice,
oi] palm; 25% of rice requirements imported
Sabah: mainly subsistence; main crops -- rubber, timber, coconut, rice; food
deficit -- rice
Sarawak: main crops -- rubber, timber, pepper; food deficit -- rice
Fishing: catch 390,000 tons, $114 million; exports $22 million, imports $7 million
Major industries:
West Malaysia: rubber and oi] palm processing and manufacturing, light
manufacturing industry, tin mining and smelting, logging and processing
timber
Sabah: logging
< Sarawak: agriculture processing, petroleum production and refining, logging
Exports: $2,741 million (f.0.b., 1973}; 27% rubber, 19% tin, 18% timber
Imports: $2,287 million (c.i.f. 1973)
Major trade partners: exports -- 22% Singapore, 18% Japan, 13% U.S.;
imports -- 20% Japan, 15% U.K., 8% Singapore
213
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Aid:
economic -- U.K. (1946-69) $260 million disbursed; Japan (1966-68) $50
million extended; IBRD (1959 - July 1972) $317 million (committed); U.S.
(1954-72) $107 million;
military -- U.S. (FY65-72) $30 million committed
Monetary conversion rate:
Malaysia: 2.4 Malaysian dollars=US$1 (December 1973)
Fiscal year: calendar year','86080f81b15c7571e0dc9fa9cc69b90416f3693d24cfe243c76e32accaa90110','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b28bef3702cdc30031b74c34c815cf807faa0394d2c8984a3bff956cc1425635',1974,'MV','Maldives','economy',260,'GNP: under $100 per capita
Agriculture: crops -- coconut and millet; shortages -- rice, wheat
Fishing: catch 32,000 tons (1970)
Major industries: fishing; some coconut processing
Electric power: 2,500 kw. capacity (1973); 9 million kw.-hr. produced (1973),
76 kw.-hr. per capita
Exports: $2.4 million (f.0.b., 1968); fish
Imports: $2 million (c.i.f., 1968)
Major trade partner: Sri Lanka
Aid: U.K. (1960-65), $1.4 million drawn; Sri Lanka (1967), $1 million committed
Monetary conversion rate: 6.39 rupees=US$1
Fiscal year: calendar year','926c5f203d716ef7d0213e8b5d60785996c55f3e47094f770956d20a61792c75','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5056f67464500557a441280f886ade26eb1cf4ab67f59884e181b6b8e11f7934',1974,'ML','Mali','economy',264,'GDP: about $380 million (1972), $70 per capita; annual growth rate 5% (1969-72)
Agriculture: main crops -- millet, sorghum, rice, corn, peanuts; cash crops --
peanuts, cotton, livestock
Fishing: catch 90,000 metric tons (1971) exports $670,000 (1971)
Major industries: small local consumer goods and processing
Electric power: 22,716 kw. capacity (1973); 52 million kw.-hr. produced (1973),
10 kw.-hr. per capita
Exports: $29.1 million (f.0.b., 1972); livestock, peanuts, dried fish, cotton,
skins
Imports: $61.1 million (c.i.f., 1972); textiles, vehicles, petroleum products,
machinery, and sugar
Major trade partners: mostly with franc zone and Western Europe; also with U.S.S.R.,','f71b167e6433a03e84c08ebd363b207aa11b34e61bf689f2688e2d278d9d533e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b16e10f2d072a45b91c7a5be784e9a47c1834425640d95fcb268974529fa3ee2',1974,'CN','China','economy',265,'219
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Budget: 1971 est. -- receipts $44.9 million, current expenditures $43.6
million, investment expenditures $5.2 million
Monetary conversion rate: 470.85 Mali francs=US$1, December 1973
Fiscal year: calendar year','ebef5ee8d5a7bcaa8260b6a31dec1c4e6ddc2d23dc6721a39041b502b5408b2d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acc7da8278ec5a0c4718bddbd25a78abd47e8712bcadad2f0415885400e70494',1974,'MT','Malta','economy',270,'GNP: $339 million (1971 constant prices), $1,030 per capita; 71% private
consumption, 29% gross investment; 1973 real growth rate, 10.6%
Agriculture: overall, 20% self-sufficient; adequate supplies of vegetables, poultry,
milk and pork products; shortages in beef, grain, animal fodder, and fruits at
various seasons; main products -- potatoes, cauliflowers, grapes, wheat,
barley, tomatoes, citrus, cut flowers, green peppers, hogs, poultry, eggs;
2,680 calories per day per capita
Major industries: ship repair yard, building industry, food manufacturing,
textiles, tourism
Shortages: most consumer and industrial needs (fuels and raw materials) must be
imported
Electric power: 115,000 kw. capacity (1972); 312 million kw.-hr. produced (1972),
910 kw.-hr. per capita
221
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $98 million (f.0.b., 1973); textiles, scrap metal, wine, agricultural
products, and footwear
Imports: $240 million (c.i.f., 1973)
Major trade partners: U.K. 44%, Italy 15.7%; EFTA 48%; EC 28.2%; Communist
countries 2.5%; North and Central America 3.8% (1971)
Aid: economic -- U.S., $34 million (FY49-73), of which $0.1 million authorized in
1970, $0.2 million authorized in 1971, $10.5 million in 1972, and $14.9 million
in 1973; Agreement (loans and grants) (1964-74), $140 million; U.N. Special
Fund, $2.2 million through FY72; U.N. Technical Assistance, $1.4 million
through FY72; China, $45 million (1972)
Monetary conversion rate: 1 Maltese Pound=US$2.67 (Smithsonian Agreement),
December 1971; the Maltese pound began floating in June 1972, with the rate
being determined between that of sterling and that of the currencies of
Malta''s major trading partners; average trade conversion factor, December 1973:
1 Maltese pound=US$2.603
Fiscal year: 1 April - 31 March','82823a2e262833b03da89ab2fcd2fc689c485cae7410df67d561e212691f17aa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abbe49283e502799abe8b969a11a9d5c38f97524beea25dcc4292707b8ca6411',1974,'MC','Monaco','economy',274,'GNP: 55% tourism; 25%-30% industry (small and primarily tourist oriented); 10%-15%
registration fees and sales of postage stamps; about 4% traceable to the Monte
Carlo casino
Major industries: chemicals, food processing, precision instruments, glassmaking,
printing
Electric power: 8,000 kw. capacity (1973); 80 million kw.-hr. supplied by France
(1973), 2,000 kw.~hr. per capita
Trade: full customs integration with France, which collects and rebates Monacan
trade duties
Monetary conversion rate: 1 franc=US$0.2253','05eae350a927caac32873b00d95a0dda606ba7b86c2f8114840f560e402c71bc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d28899082c3a9d3bacc1373bbd7e636583dc976cd3ffc2f1bdc60d0e3d34d60',1974,'MA','Morocco','economy',280,'GNP: $5 billion (1973 est. in 1972 prices), about $310 per capita; average annual
real growth 4% during 1970-73
Agriculture: cereal farming and livestock raising predominate; main products --
wheat, barley, citrus fruit, wine, vegetables, olives; some fishing
Fishing: catch 229,000 metric tons, $18.7 million (1971); exports $37.9
million (1971)
Major sectors: mining and mineral processing (phosphates, smaller quantities
of iron, manganese, lead, zinc, and other minerals), food processing, textiles,
construction and tourism
Electric power: 858,000 kw. capacity (1972); 2.3 billion kw.-hr. produced (1972),
140 kw.-hr. per capita
Exports: $894 million (f.o.b., 1973); agricultural goods 56%, phosphates 23%.
other 21%
Imports: $1,015 million (f.0.b., 1973); food 24%, raw material and semi-finished
goods 42%, equipment 20%, consumer goods 14%
Major trade partners: exports -- France 32%, West Germany 8%, Italy 8%, Benelux 7%,
U.K. 2%; imports -- France 31%, U.S. 8%, West Germany 7%, Italy 6% (1972)
Monetary conversion rate: 4.2 dirhams=US$1, trade rate January 1974
Fiscal year: calendar year','14e5f18a529dfec84be3151c513fa5ca7f1bb94a941173b33e6f191e32c44228','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77f1f2b66b12b449d15b5a0e5e45b37850ff9b659830153839f709df9cd953a0',1974,'ZM','Zambia','economy',281,'GNP: $2.3 billion (1972), about $250 per capita; average annual growth rate
(current prices, 5.8% 1970-72)
Agriculture: cash crops -- raw cotton, cashew nuts, Sugar, tea, copra, sisal;
other crops -- corn, wheat, peanuts, potatoes, beans, sorghum, and cassava;
self-sufficient in food except for wheat which must be imported
Major industries: food processing (chiefly sugar, tea, wheat, flour, cashew
kernels); chemicals (vegetable oi1, oilcakes, soap, paints); petroleum
products; beverages; textiles; nonmetallic mineral products (cement, glass,
asbestos, cement products); tobacco
237
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Electric power: 232,000 kw. capacity (1972); 563 million kw.-hr. produced (1972),
64 kw.-hr. per capita
Exports: $180 million (f.o.b., 1972); cashew nuts, cotton, sugar, mineral products,
timber products, tea, copra, petroleum products
Imports: $336 million (c.i.f., 1972); machinery and electrical equipment, cotton
textiles, vehicles, petroleum products, wine, iron and steel
Major trade partners: over one-third of foreign trade with Portugal; South Africa,
U.S., U.K., West Germany
Aid: from Portugal only
Budget: (FY73) balanced at $429 million
Monetary conversion rate: 27.25 escudos=US$1 (approximate realigned rate)
until February 1973, floating since then
Fiscal year: calendar year
GNP: $1.8 billion (1972 est.), $410 per capita; real growth rate 11% between 1965
and 1970
Agriculture: main crops -- corn, tobacco, cotton; net importer of all major
agricultural products
Fishing: catch 48,400 metric tons, $4.2 million (1970); imports $5.3 million (1970)
Major industries: copper mining and processing
Electric power: 788,200 kw. capacity (1972); 2.2 billion kw.-hr. produced (1972),
484 kw.-hr. per capita
Exports: $758 million (f.o.b. 1972); copper, zinc, cobalt, lead, tobacco
387
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Imports: $718 million (c.i.f., 1972); consumer goods, machinery, transport
equipment, foodstuffs, fuels
Major trade partners: U.K., South Africa, Japan, Western Europe
Aid:
economic -- China $228 million (1967-73); (1964-67) U.K. $63 million; IBRD $99
million (1965-70); U.S. $68 million (FY53-72); U.S.S.R. $6 million; Eastern
Europe $50 million
military -- $9 million (1964-69), mainly U.K. and Canada
Budget: 1974 -- revenue $779.5 million, current expenditure $680.1 million,
investment expenditure $246.9 million
Monetary conversion rate: 1 Zambia kwacha=US$1.555 (official), 0.643 Zambia
kwacha=US$1
Fiscal year: calendar year','420a3ecabaa1a88569a576e7f15bb530e7df20a04d09d4329cd1b2ffc1dc1c26','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8f9801159ba5ade0393a70162fd78449ef8a78ca3c1deba7a9b690daee5e459',1974,'NR','Nauru','economy',286,'GNP: $28 million (1970), $4,000 per capita (est.)
Agriculture: negligible; almost completely dependent on imports for food, water
Major industries: mining of phosphates, about 2 million tons per year (1966)
Exports: $17 million (f.0.b., 1968), consisting entirely of phosphates
Imports: $5 million (c.i.f., 1968)
Major trade partners: Australia, New Zealand, and United Kingdom
Monetary conversion rate: 1 Australian dollar=US$1.4875 (official)
Fiscal year: 1 July - 30 June','452e8ea2613d84483347a80fbb55c73ec9179307c51f336b84e37225e2f5bebe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('202109658161385f31691b7c9991686afcc4d98ee7ff2357e44375edcf43eb97',1974,'NP','Nepal','economy',290,'GDP: $920 million (FY72 at FY71 prices), less than $100 per capita, annual growth
rate 2% in recent years
Agriculture: over 90% of population engaged in agriculture; main crops -- rice,
corn, wheat, sugarcane, oilseeds; largely self-sufficient
Major industries: small rice, jute, sugar, and oilseed mills; match, cigarette,
and brick factories
241
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $35 million (FY72); rice and other food products, jute, timber
Imports: $73 million (FY72); manufactured consumer goods, food grains and
food products
Major trade partner: over 90% India
Monetary conversion rate: 10.2 Nepalese rupees=US$1
Fiscal year: 15 July - 14 July','e8fa8d699edd6839227f5d169785508b418b33ea3f923971e0f7eb2dd42562c2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7aaf038c9d0746032c6b97c265ba140e3e2634a53ff3779411075376ec74b66',1974,'NL','Netherlands','economy',294,'GNP: $55.1 billion (1973), $4,090 per capita; 57% consumption, 20% investment,
21% government; 2% foreign balance; 1973 growth rate 5%, in constant prices
Agriculture: animal husbandry predominates; main crops -- horticultural crops,
grains, potatoes, sugar beets; food shortages -- grains, fats, oils; calori
intake, 3,186 calories per day per capita (1970-71)
Fishing: catch 324,000 metric tons est., $158 million (1973); exports 19,200 metric
tons, imports 83,750 metric tons (1972)
Major industries: food processing, metal and engineering products, electrical and
electronic machinery and equipment, chemicals, and petroleum products
Shortages: crude petroleum, raw cotton, base metals and ores, pulp, pulpwood,
lumber, feedgrains, and oilseeds
Crude steel: 5.7 million metric tons produced (1973), 420 kilograms per capita
Electric power: 10,900,000 kw. capacity (1972); 49.6 billion kw.-hr. produced
(1972), 3,400 kw.-hr. per capita
Exports: $16782 million (f.o.b., 1972); foodstuffs, machinery, transportation
equipment, consumer manufactures, chemicals, petroleum products, textiles
Imports: $17,421 million (c.i.f., 1972); machinery, transportation equipment,
consumer manufactures, crude petroleum, foodstuffs, chemicals, raw cotton,
base metals and ores, pulp
Major trade partners: (1972) 60% EC, 31% W. Germany, 15% Belgium-Luxembourg,
6% U.S.
Aid:
economic -~- U.S., $1,359 million authorized (FY46-73); IBRD, $244 million
authorized (FY46-73), none since 1958;
military -- U.S., $1,255 million authorized (FY49-73), none since FY65; net
official aid delivered to less developed areas and multilateral agencies --
$1,458 million (FY62-72), $315 million (1972)
Budget: (1974 projected) revenues $14.2 billion, expenditures $15.2 billion,
deficit $1.0 billion
Monetary conversion rate: 2.781 guilders=US$1, average 1973, floating
Fiscal year: calendar year','a22055f2cc573ec2b256c5f51a3a956dd9bd72d1b30cefecb3b0e8004cbd6195','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04f3418914c26672962f6c4b2de9828fd205508819c03fdeafb5e724b9eddaaa',1974,'NC','New Caledonia','economy',298,'GNP: $193 million, $1,800 per capita (1971 est.)
Agriculture: large areas devoted to cattle grazing; major products -- coffee and
vegetables; 60% self sufficient in beef; must import grains and vegetables
Industry: mining of nickel
Exports: $212 million (f.o.b., 1971} 98% nickel
Imports: $248 million (c.i.f., 1971) machinery, transport equipment, food
247
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major trade partners: (1971) exports -- France (42%), Japan (47%), U.S. (9%);
imports -~- France (48%), Australia (14%)
Monetary conversion rate: 70 CFP francs=US $1
Agriculture: export crops of copra, cocoa, coffee, some livestock and fish
production; subsistence crops of copra, taro, yams
Exports: $16 million (1971); copra, frozen fish
Imports: $23 million (1971)
Monetary conversion rate: 1 pound=US$2.50 (official currency), 0.67 Australian
$=US$1, 70 Colonial Franc Pacifique (CFP)=US$1','0abee6755b9dc8cc508fbc8c239d3a2620ad1fa5a651ad88ab63f6f7c2918919','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd334579a907b9e7225927ed451509efc1a7c9eb450083e1c9599eb09e8479e0',1974,'NI','Nicaragua','economy',302,'GDP: $1,030 million (current prices, 1972), $520 per capita; 73% private
consumption, 10% government consumption, 19% domestic investment, -2% net
foreign balance (1970); real growth rate 1973 est. 3%
Agriculture: main crops -- cotton, coffee, sugarcane, rice, corn, beans, cattle;
caloric intake, 2,300 calories per day per capita (1966)
Fishing: catch 9,800 metric tons (1970); $9.6 million (1970); exports $6.}
million (1971)
Major industries: food processing, chemicals, metal products, textiles and clothing
Electric power: 175,000 kw. capacity (1972); 660 million kw.-hr. produced
(1972 est.), 340 kw.-hr. per capita
Exports: $276 million (f.o.b., 1973 prelim.); cotton, meat, coffee, sugar, chemical
products
Imports: $325 million (c.i.f., 1973 prelim.); food and non-food agricultural
products, chemicals and pharmaceuticals, transportation equipment, machinery,
construction materials, clothing, fuel
Major trade partners: exports -- U.S. 30%, Japan 21%, CACM 22%, West Germany 7%;
imports -- U.S. 31%, CACM 28%, Japan 8%, West Germany 8% (1972)
Aid:
economic -- extensions from U.S. (U.S. FY46-72) $117.0 million loans, $69.2
million grants; international organizations (U.S. FY46-72) $172.9 million;
military -- from U.S. (U.S. FY46-72), $15.1 million
Monetary conversion rate: 7 cordobas=US$1 (official)
Fiscal year: calendar year','32f9d9f33d075170318fbb1ddbf548bc1cdcc8961913dc28d05cc3034bfbf95e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f2e91356db9a8551a7b223587571995b1044b36d856920f9fa6a5ef49876c2b',1974,'NE','Niger','economy',306,'GDP: $514 million (1971 est.}, $120 per capita
Agriculture: commercial -- peanuts, cotton, livestock; main food crops --
millet, sorghum, niebe beans, vegetables
Major industries: cement plant, brick factory, rice mil1, small cotton gins, oi]
presses, slaughterhouse, and a few other small light industries; uranium
production began in 1971
Electric power: 61,200 kw. capacity (1973); 55 million kw.-hr. produced (1973),
13 kw.-hr. per capita
Exports: $54 million (f.o.b., 1972); about 60% peanuts and related products,
rest largely livestock, hides, skins; exports badly understated because much
regional trade not recorded
Imports: $66 million (c.i.f., 1972); fuels, machinery, transport equip-
ment, foodstuffs, consumer goods (largely for European residents); sizable
imports unrecorded
255
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major trade partners: France (over 50%), other EC countries, Nigeria, UDEAC
countries, U.S.; preferential tariff to EC and franc zone countries
Aid:
economic -- France (1960 to mid-1967) $68 million; EC (1961-72) $92.7 million;
U.S. (FY61-72) $20.5 million; West Germany, Israel, Republic of China, and U.N.
have also extended aid;
military -- $2.8 million (1954-68)
Budget: (1970) revenues $61.6 million (1972); current (1972) expenditures (includes
extra budgetary transactions) $46.1 million; investment expenditures $15.6
million
Monetary conversion rate: 255.785 Conmunaute Financiere Africaine=US$1 as of
February 1973, floating since February 1973
Fiscal year: 1 October - 30 September','379ffe2489bd4e66c85812f20fc420f43f9f80917e848034bac26f1540e36c41','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('379bb20fdf4d525113b65165167b670fe934e9b2d51d568e35a2e45fd7ed6a8a',1974,'NG','Nigeria','economy',310,'GDP: $7.1 billion (1972), $120 per capita; 9% growth rate 1972
Agriculture: main crops -- peanuts, cotton, cocoa, rubber, yams, cassava,
sorghum, palm kernels, millet, corn, rice; livestock; almost self-sufficient
Fishing: catch 156,000 metric tons (1970); imports $3.7 million (1971)
Major industries: mining -- crude oi1, natural gas, coal, tin, columbite;
processing industries -- oi] palm, peanut, cotton, rubber, petroleum, wood,
hides, skins; manufacturing industries -- textiles, cement, building materials,
food products, footwear, chemical, printing, ceramics
257
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Electric power: 1,111,000 kw. capacity (1972); 1.8 billion kw.-hr. produced
(1972), 36 kw.-hr. per capita
Exports: $3.3 billion (f.o.b., 1973); oi] (85%), peanuts, palm products, cocoa,
rubber, cotton, timber, tin
Imports: $1.8 billion (c.i.f., 1973); machinery and transport equipment, manu-
factured goods, chemicals
Major trade partners: U.K., EC, U.S.
Budget: FY74 est. -- current revenue $2.14 billion, current expenditure $1.86
billion, capital expenditure $115 million
Monetary conversion rate: 1 Naira=US$1.52 (official)
Fiscal year: 1 April - 31 March','a669af122f578284b39d3b56615f8cc8fe842faed42e7641f1afb7be6577aabe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cd9f0facd2825a5a3f63c122b15a81723b90a1734896bcd1bc3fbc377b1d1fe',1974,'NO','Norway','economy',314,'GNP: $14.4 billion (1972), $3,650 per capita; 55.3% private consumption; 28.8%
investment; 16.6% government; net foreign balance -0.7%; 1972 growth rate 4.0%,
in constant prices
Agriculture: animal husbandry predominates; main crops -- feed grains, potatoes,
fruits, vegetables; 40% self-sufficient; food shortages -- food grains, sugar;
caloric intake, 2,940 calories per day per capita (1969-70)
Fishing: catch 2,885,000 metric tons (1972); exports $325 million
Major industries: food processing, wood pulp, paper products, metals, machinery,
chemicals, shipbuilding
Shortages: feed and bread grains, coal, cotton, wool
Crude steel: 963,000 metric tons produced (1973), 240 kilograms per capita
Electric power: 14,120,000 kw. capacity (1972); 67.5 billion kw.-hr. produced
(1972), 15,000 kw.-hr. per capita
Exports: $4,761 million (f.0.b., 1973); principal items -- fish and fish
products, metal and metal products, pulp and paper, chemicals, ships
Imports: $6,634 million (c.i.f., 1973); principal items -- ships, machinery,
fuels, foodstuffs
Major trade partners: EC 46.2% (U.K, 13.6%, West Germany 12.7%, Denmark 6.9%);
Sweden 16.4%; U.S. 5.8%; communist countries 2.9% (1973)
Aid:
economic -- U.S., $482.4 million authorized (FY46-73), $39.7 million in 1973;
IBRD, $145 million authorized through 1973, none since 1964; net official
economic aid delivered to less developed areas and multilateral agencies,
$134.2 million (1960-69); $36.8 million (1970); $42.4 million (1971)
military -- U.S., $914.4 million authorized (FY46-73), none since 1967
Budget: (1973) revenues $4,440 million, expenditures $4,382 million
Monetary conversion rate: 1 kroner=US$0.1725, 1973 average
Fiscal year: calendar year','0d796184d40ec01cc847076360db534a1a8d24108f57a1f47e4b88165a2d5e44','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e68570f87d170d440a34c196dddd9c0e2e8f179a3d10e907040dba04f85c4196',1974,'OM','Oman','economy',318,'GNP: $500 million (1973 est.), $1,060 per capita est.
Agriculture: based on subsistence farming (fruits, dates, cereals, cattle, camels,
fish) and trade
Major industries: petroleum discovery in 1964; production began in 1967; production
1973 equaled 293,000 b/d; pipeline capacity 400,000 b/d; revenue for 1974 est.
at $687 million
Electric power: 24,000 kw. capacity (1972); 70 million kw.-hr. produced (1972),
100 kw.-hr. per capita
Exports: $240 million (1972 est.); most of which is petroleum; non-oil exports
$1.8 million
Imports: $118 million (1973)
Major trade partners: U.K., Gulf states, India, Australia, China, Japan
Aid: multilateral annual average 1967-69 $350,000
Monetary conversion rate: 1 Riyal Omani=US$2.90 (as of October 1973)
Fiscal year: calendar year
GDP: $5.7 billion (FY73) at exchange rate of 9.9 rupees=US$1 prevailing June 1973,
less than $100 per capita; real growth 5.8% (FY73)
Agriculture: extensive irrigation; main crops -- wheat and cotton; largely
self-sufficient; foodgrain shortage due to increased consumption level
Fishing: catch 172,800 metric tons (1970 est.)
Major industries: cotton textiles, food processing, tobacco, engineering, chemicals,
natural gas
Exports: $766 million (f.0.b., FY73); cotton (raw and manufactured)
Imports: $775 million (c.i.f., FY73) machinery, transport equipment, chemicals
Major trade partners: U.S., U.K., Japan, West Germany
Monetary conversion rate: 9.9 rupees=US$1 (since February 1973)
Fiscal year: J] July - 30 June','36945bc9e0628d3a58cb00a32da818064831b111cf45466c89781c20103a0d5b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34f7ee17dbdac588bc2580e8e5e179936d9ab69dd1f53b384259623e9fe27671',1974,'PA','Panama','economy',322,'GDP: $1,408 million (1973 est.), $900 per capita; 72% private consumption, 11%
government consumption, 26% gross fixed investment, -9% net foreign balance
(1970); real growth rate 1973, 6.5% (prelim.)
Agriculture: main crops -- bananas, rice, corn, coffee, sugarcane; self-sufficient
in most basic foods; 2,450 calories per day per capita 11969)
Fishing: catch 62,400 metric tons, $11 million (1971); exports $13.3 million (1971);
imports $2.0 million (1971)
Major industries: food processing, metal products, construction materials,
petroleum products, clothing
Electric power (including Canal Zone: 378,000 kw. capacity (1972); 1.3 billion
kw.-hr. produced (1972), 710 kw.-hr. per capita
Exports: $132 million (f.0.b., 1973 prelim. ); bananas, petroleum products, shrimp,
sugar, meat, coffee
Imports: $473 million (f.o.b., 1973 prelim. ); manufactures, transportation equipment,
crude petroleum, chemicals, foodstuffs
Major trade partners: exports -- U.S. 38%, Canal Zone 32%, West Germany 20%;
imports -- U.S. 33%, Venezuela 15% (1972 est.)
Aid:
economic -- from U.S. (FY46-72), $210.6 million loans, $125.6 million grants;
from international organizations (FY46-72), $55.5 million; from other Western
countries (1960-71), $28.9 million;
military -- assistance from U.S. (FY46-72), $5.8 million
Monetary conversion rate: 1 balboa=US$1 (official}
Fiscal year: calendar year','68db9351aa21ea2e6a33b3e957069592983b58cbb5a7a9c3c18649797250c62f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e846f8e6e51040602edffdd5735481ff16119dc1decd840b55587aab00f13dd',1974,'PY','Paraguay','economy',327,'GNP: $644.3 million (1973, in 1972 dollars), $270 per capita; 88% consumption; 16%
gross domestic investment; -4% net foreign balance (1972); real growth rate 1973
est., 5.8%
Agriculture: main crops -- oilseeds, cotton, wheat, manioc, sweet potatoes,
tobacco, corn, rice, sugarcane; self-sufficient in most foods; caloric
intake, 2,580 calories per day per capita (1963-64); protein intake,
70 grams per day per capita (20 grams of animal origin)
Major industries: meat packing, oilseed crushing, milling, brewing, textiles,
light consumer goods, cement
Electric power: 159,000 kw. capacity (1971); 257 million kw.-hr. produced
(1971), 104 kw.-hr. per capita
269
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $127 million (f.o.b., 1973); meat, timber, oilseeds, tobacco, cotton,
quebracho extract, hides, yerba mate, coffee
Imports: $122 million (c.i.f., 1973); foodstuffs, machinery, transport equipment,
fuels and lubricants, textiles, chemicals
Major trade partners: U.S. 15%, Argentina 14%, West Germany 13%, U.K. 9%
Aid:
economic -- extensions from U.S. (FY46-72), $87.2 million loans, $62.8 million
grants; from international organizations (FY46-72), $189.3 million; from other
Western countries (1960-70), $21.9 million
military -- assistance from U.S. (FY57-72), $15.5 million
Monetary conversion rate: 126 guaranies=US$1 (official rate)
Fiscal year: calendar year','5a761d760f2aa47421975a709787aba6f8d77b80dfda09b4c1f9819e164dbb90','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19d81814db8ee5b18512e8dca6a46a858599e0870d4d4f22bb2004b55a2bed86',1974,'PH','Philippines','economy',331,'GNP: $9.0 billion (1973), $225 per capita
Agriculture: main crops -- rice, corn, coconut, sugarcane, bananas abaca, tobacco
Fishing: catch 1.2 million metric tons, (1973)
Major industries: agricultural processing, textiles, chemicals and chemical
products
Exports: $1,683 million (f.0.b., 1973); copra, sugar, logs and lumber, coconut
oil, copper concentrates, abaca
Imports: $1,408 million (c.i.f., 1973)
Major trade partners: (1972) exports -- 37% U.S., 37% Japan; imports -- 27%
U.S., 33% Japan
Aid:
economic -- U.S. (FY46-72), $1.8 billion committed; Japan (reparations),
$550 million extended in 1956, $337 million drawn through July 1969; IBRD
(1953-71), $239 million committed; IBRD (FY53-72), $268 million
military -- U.S. (FY46-72), $673 million conmitted
Monetary conversion rate: 6.78 pesos=US$1
Fiscal year: 1 July - 30 June','7880ace7a968448f34644701ec2d2f04f4817f14d67882c568df4ad691bf0c46','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62a48ac59cfab7ffa64b67a42d2154420cf40048b2d48acb477fc77b60afccce',1974,'PL','Poland','economy',335,'GNP: $60.8 billion in 1973 at 1972 prices, $1,830 per capita; 1973 growth rate
7.6%
Agriculture: self-sufficient for minimum requirements; main crops -- grain,
sugar beets, oilseeds, potatoes, exporter of livestock products and sugar;
importer of grains; 3,200 calories per day per capita (1970)
Fishing: catch 549,000 metric tons (1972)
275
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major industries: chemistry, food processing, transportation equipment, machine
building, iron and steel, textiles, and shipbuilding
Crude steel: 14.1 million metric tons produced (1973), about 420 kg. per capita
Exports: $6,432 million (f.o.b., 1973); 42% machinery and equipment, 34% fuels,
raw materials, and semimanufactures, 15% agricultural and food products,
9% light industrial products
Imports: $7,862 million (f.o.b., 1973); 45% machinery and equipment; 37% fuels,
raw materials, and semimanufactures; 13% agricultural and food products;
5% light industrial products
Major trade partners: $14,295 million (1973); 56% with Communist countries, 44%
with West
Monetary conversion rate: 3.32 zlotys=US$? (commercial); 19.92 zlotys=US $1
(noncommercial); old commercial rates 4.00 zlotys=US$1 prior to 1972, 3.68
zlotys=US$1 in 1972
Fiscal year: same as calendar year; economic data are reported for calendar
years except for caloric intake which is reported for the consumption year,
1 July - 30 June
Note: foreign trade figures were converted at the 1973 rate
GNP: continental Portugal -- $9,770 million (1972), $1,130 per capita; 75.6%
consumption, 16.9% investment, 14.7% government, -7.2 net exports of goods
and services (1971), growth rate 6.8% (1972) in constant prices
Agriculture: generally underdeveloped; main crops -- grains, potatoes, olives,
grapes for wine; food shortages -- sugar, wheat; caloric intake, 2,730
calories per day per capita (1969)
Fishing: catch 349,000 metric tons, $96 million (1971); exports $51 million,
imports $61 million (4972)
Major industries: cotton textiles, cork processing, fish canning, petroleum
refining, pulp and paper, chemical fertilizer
Shortages: coal, petroleum, cotton, steel
Crude steel: 0.42 million metric tons produced (1972), 50 kg. per capita (1972)
Electric power: 3,129,000 kw. capacity (1973) 9.0 billion kw.-hr. produced
(1973), 950 kw.-hr. per capita
Exports: $1,820 million (f.0.b. 1973); principal items -- cotton textiles, cork
and cork products, canned fish, wine, timber and timber products, resin
Imports: $2,980 million (c.i.f., 1973); principal items -- petroleum, cotton,
industrial machinery, iron and steel, chemicals
Major trade partners: (1973) 16.1% U.K., 11.9% West Germany, 8.8% U.S., 6.3%
Angola, 6% France, 5% Norway, 4% Spain, 0.8% E Europe; 44.1% EC-nine
Aid:
economic -- U.S... $227.8 million (FY1949-72), $30.4 million authorized FY72;
IBRD, $57.5 million authorized (1964-66), none since 1966; net official
aid to less developed areas and multilateral agencies $578 million (1961-70),
$79.5 million (1969), $57.1 million (1970);
military -- U.S., $344.0 million authorized (FY1949-72)
Budget: 1973--receipts 52 billion escudos, expenditures 59.8 billion escudos,
deficit 7.8 billion escudos
Monetary conversion rate: 1 escudo=US$0.0407 (1973 average)
Fiscal year: calendar year
GNP: $107 million (1969, in 1963 constant prices), $200 per capita
Agriculture: main crops -- palm oi1, root crops, rice, coconuts, peanuts
Electric power: 1,200 kw. capacity (1973); 3 million kw.-hr. produced (1973),
6 kw.-hr. per capita
Exports: $3.6 million (f.o.b., 1969); principally peanuts, coconuts
281
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Imports: $23.3 million (c.i.f., 1969); manufactured goods, fuels, transport
equipment, rice
Major trade partners: mostly Portugal, also immediate neighbors
Aid: Portugal, small amounts
Monetary conversion rate: 25.5 escudos=US$1, (fixed, February 1973)
Fiscal year: probably is the calendar year','fafe2cf748f0d270ca4355f89841cb8e156950cdfb67f672928bd7d1924beb8f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7df4b3664eae1c0f42cce04dbfc94d275dc6dce8be66a2865986cde6fef500bc',1974,'QA','Qatar','economy',339,'GNP: $500 million (1973) $3,330 per capita
Agriculture: farming and grazing on small scale; commercial fishing increasing
in importance; most food imported; rice and dates staple diet
Major industries: oi] production and refining; crude oil production from onshore
and offshore averaged 550,000 bbls. per day in 1973; oi] revenues $1.5
billion in 1974, representing 91% of government/royal family income; major
development projects include $7 million harbor at Ad Dawhah, fertilizer plant,
2 desalting plants, refrigerated storage for fishing, and a cement plant
Electric power: capacity 80,000 kw. (1972); 200 million kw.-hr. produced (1972),
1,400 kw.-hr. per capita
Exports: crude oi] dominates; non-oi7 exports $22 million (1972)
Imports: $192 million in 1972
Aid: multilateral annual average $170,000 (1967-69)
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.25 (as of October 1973)
Fiscal year: 1 April - 31 March
Agriculture: cash crops -~ almost entirely sugarcane, small amounts of vanilla
and perfume plants; food crops -- tropical fruit and vegetables, manioc,
bananas, corn, market garden produce, also some tea, tobacco, and coffee;
food crop inadequate, most food needs imported
Major industries: 12 sugar processing mills, rum distilling plants, cigarette
factory, 2 tea plants, fruit juice plant, canning factory, a slaughterhouse,
and a number of small shops producing handicraft items
Electric power: 54,400 kw. capacity (1973); 108 million kw.-hr. produced (1973),
246 kw.-hr. per capita
Exports: $50 million (f.o.b., 1972); 90% sugar, 4% perfume essences, 5% rum and
molasses, 1% vanilla and tea
Imports: $196 million (c.i.f., 1972); manufactured goods, food, beverages,
and tobacco, machinery and transportation equipment, raw materials and
petroleum products
287
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major trade partners: France (in 1970 supplied 62% of Reunion''s imports, purchased
76% of its exports); Mauritius (supplied 12% of imports)
Monetary conversion rate: 255.785 Conmunaute Financiere Africaine francs=US$1 as
of February 1973 (floating since February 1973)
Fiscal year: probably calendar year
GDP: $1,918 million (1972), $340 per capita; real growth rate 6% (1965-71)
Agriculture: main crops -- tobacco, corn, sugar, cotton; livestock; self-
sufficient in foodstuffs except wheat
Major industries: mining and steel, textiles
Electric power: 1,323,000 kw. capacity (1972); 7.94 billion kw.-hr. produced
(1972), 1,350 kw.-hr. per capita
Exports: $490 million (f.o.b., 1972), including net gold sales and reexports;
tobacco, asbestos, copper, meat, chrome, gold, nickel, clothing, sugar
Imports: $408 million (c.i.f., 1972); machinery, petroleum products,
wheat, transport equipment
Major trade partners: South Africa, Portugal, and Portuguese territories
Aid: no substantial military or economic aid
Budget: FY1974 -- revenues $434 million, expenditures $461 million, deficit $27
million
Monetary conversion rate: 1 Rhodesian dollar=US$1.40; 0.714 Rhodesian dollar=US$1
Fiscal year: 1 duly - 30 June','86afcc0adfa3136568ffa524b5e7e988daf13ede487e5849fbf414fc9081d573','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12a7854041debe61763a542fcbce752e0329d43bb5f6a4d512c600f9f2b76c24',1974,'RO','Romania','economy',342,'GNP: $34.1 billion in 1973 (at 1972 prices), $1,630 per capita; 1973 growth rate
8.3%
Agriculture: net exporter; main crops -~ corn, wheat, oilseed; livestock -~
cattle, hogs, sheep; caloric intake, 3,000 calories per day per capita (1967-68)
Fish catch: 75,000 metric tons (1971)
Major industries: machinery, metals, fuels, chemicals, textiles, food processing,
timber processing
Shortages: iron ore, coking coal, metallurgical coke, cotton fibers, natural
rubber
Crude steel: 8.2 million metric tons produced (1973), 390 kg. per capita
29]
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $3,783 million (f.o.b., 1973); 25% machinery and equipment; 36% fuels,
ae De tee semifinished products; 20% foodstuffs; and 19% consumer goods
1972
Imports: $3,458 million (mixture f.o.b. and c.i.f., 1973); 46% machinery and
equipment; 44% fuels, raw materials, semi finished products; 5% foodstuffs;
and 5% consumer goods (1972)
Major trade partners: 7,241 million in 1973; 48% non-Communist countries, 52%
Communist countries (1971)
Monetary conversion rate: 4.97 lei=US$1 (commercial) 14.4 lei=US$1 (tourist);
old commercial rates: in 1972, 5.53 lei=US$1, prior to 1972 6.00 lei=US$1
Fiscal year: same as calendar year; economic data reported for calendar years
except for caloric intake, which is reported for consumption year, 1 duly -
30 June
Note: foreign trade data converted at 1973 rate','b62b0885db6550b5384e9faf098fc2df377d9beeff4fa2b487dea8b798e2beca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('229e0e6f6a97e789a370dcc896223aef31762784b964be5d8497e5b2292f43a2',1974,'RW','Rwanda','economy',346,'GDP: $240 million (1971}, $60 per capita
Agriculture: cash crops -- mainly coffee, tea, cotton, some pyrethrum; main
food crops -- bananas, cassava; stock raising; self-sufficiency increasing
but country still imports some foodstuffs
Major industries: mining of cassiterite (tin ore), agricultural processing, and
light consumer goods
Electric power: 21,460 kw. capacity (1973); 100 million kw.-hr. produced (1973),
28 kw.-hr. per capita
Exports: $18.9 million (f.o.b., 1972); mainly coffee, tea, pyrethrum, cassiterite
Imports: $34.7 million (c.i.f., 1972); textiles, foodstuffs, machines, equipment
Major trade partners: U.S., Belgium, Zaire
Aid: U.S., FY62-72, $8.0 million; Belgium, France, West Germany, and Canada,
FY64-67, $33.4 million obligated
Budget: balanced at $25.8 million (FY1973)
Monetary conversion rate: 92.84 Rwanda francs=US$1 (official) since January 1974
Fiscal year: calendar year
293
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GDP: $15.2 million (1969), $260 per capita
Agriculture: main crops -- sugar on St. Christopher, cotton on Nevis
Major industries: sugar processing, salt extraction
Electric power: 6,400 kw. capacity (1972); 17 million kw.-hr. produced
(1972), 525 kw.-hr. per capita
Exports: $4.2 million (f.0.b., 1971); sugar, molasses, cotton, salt, copra
Imports: $15.8 million (c.i.f., 1971); foodstuffs, fuel, manufactures
Major trade partners: U.K. 45%, Canada 14%, U.S. 12% (1966)
Monetary conversion rate: 2.08 East Caribbean dollars=US$1 (February 1974); now
floating with pound sterling
295
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','34711a3f7f575efd59b3f7d2193bca7cc51426067ec03a5f2698b2ddc49686ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12c171cae9530c32ee09ab8f7f6062e8b46e65f16959ef1ea60331fce4395a47',1974,'SA','Saudi Arabia','economy',350,'GNP: $8.8 billion (1973 est.), $1,530 per capita
Agriculture: dates, grains, livestock; not self-sufficient in food
Major industries: petroleum production 8.4 million barrels per day (current);
payments to Saudi Arabian Government, 21 billion (1974 est.) cement production
and small steel-rolling mill and oil refinery; several other light industries,
including factories producing detergents, plastic products, furniture, etc.;
PETROMIN, a semipublic agency associated with the Ministry of Petroleum, has
recently completed a major fertilizer plant
Electric power: 316,600 kw. capacity (1973); 1.1 billion kw.-hr. produced (1973),
189 kw.-hr. per capita
Exports: $5.5 billion (f.0.b., 1973 est.); 99% petroleum and petroleum products
Imports: $2.1 billion (c.i.f., 1973 est.); manufactured goods, transportation
equipment, construction materials, and processed food products
Major trade partners: exports -- U.S., Western Europe, Japan; imports -- U.S.,
Japan, West Germany
Monetary conversion rate: 1 Saudi riyal=US$0.28 as of August 1973 (IMF par value,
freely convertible)
303
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Fiscal year: follows Islamic year; the 1973-74 Saudi fiscal year covers the
period 30 July 1973 through 1 July 1974
Aid:
economic -- $398 million credits extended through August 1972, $170 million
drawn through 1970; major donors include U.S.S.R., China, U.S., West
Germany, Saudi Arabia;
military -- $77 million from U.S.S.R.; $30 million from Eastern Europe;
$7 million western military aid through 197]
Budget: (1973/74 est.) $62 million
Monetary conversion rate: 1 Yemeni rial=US$0.22 as of October 1973
Fiscal year: 1 July - 30 June
381
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GNP: $24.8 billion (1973 est. at 1972 prices), $1,180 per capita; 1973 real growth
rate approx. 3.7%
Agriculture: diversified agriculture with many small private holdings and large
agricultural combines; main crops -- corn, wheat, tobacco, sugar beets, and
sunflowers; generally a net exporter of foodstuffs and live animals; self-
sufficient in food except for tropical products, cotton, wool, and vegetable
meal feeds; caloric intake, 3,210 calories per day per capita (1967)
Major industries: metallurgy, machinery and equipment, textiles, wood
processing, food processing
Shortages: fuels, steel, textile fibers, chemicals
Crude steel: 2.7 million metric tons produced (1973), 130 kg. per capita
Electric power: 8,200,000 kw. capacity (1972); 35.1 billion kw.-hr. produced
(1973), 1,665 kw.-hr. per capita
Exports: $2,852 million (f.0.b., 1973); 16% foodstuffs and tobacco; 17% raw
materials, fuels, and chemicals; 25% machinery and equipment; 29% other
manufactures
Imports: $4,511 million (c.i.f., 1973); 12% foodstuffs and tobacco; 29% raw
materials, fuels, chemicals; 31% machinery and equipment; 28% other
manufactures
Major trade partners: $7,363 million (1973); 71% non-Communist countries (39%
EC, 7% U.S., 25% other non-Communist countries), 29% Communist countries
Aid: postwar credits extended mainly by the U.S. (about $2.4 billion, including
grants and $700 million in military aid); Western Europe (over $950 million),
IBRD ($660 million); IMF {over $400 million); Communist countries extended
credits totaling $464 million in 1956 ($125 million drawing balance suspended
in 1958) and $576 million during 1962-70 and $540 million in 1972; Yugoslavia
has extended credits totaling about $600 million to 27 less developed countries
of Africa, Asia, and Latin America
Monetary conversion rate: 17.0 new dinars=US$1
Fiscal year: same as calendar year (al] data refer to calendar year or to middle
or end of calendar year as indicated)
GDP: $2.3 billion (1972 provisional est.), $100 per capita; real growth rate
6.3% p.a. 1968-72
Agriculture: main cash crops -- coffee, palm oil, rubber; main food crops --
manioc, bananas, root crops, corn; some provinces self-sufficient
Fishing: catch 146,000 metric tons (1971); imports $18 million (1972 est.)
Major industries: mining, mineral processing, light industries
Electric power: 861,380 kw. capacity (1972); 3.5 billion kw.-hr. produced
(1972), 126 kw.-hr. per capita
Exports: $690 million (f.o.b., 1972); copper, cobalt, diamonds, other minerals,
coffee, palm o71
385
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Imports: $643 million (c.i.f., 1972); consumer goods, foodstuffs, mining and
other machinery, transport equipment, fuels
Major trade partners: Belgium, U.S., and West Germany
Aid:
economic -- U.S. (FY61-72) $452 million; (1971 estimated disbursements)
Belgium, $31.4 million; France, $6.6 million; other bilateral aid $5.4 million;
U.N., $9.4 millions EC, $18.9 million; China (1973) $100 million
military -- U.S., $43.2 million (FY62-72)
Budget: 1972--- revenue $598 million, current expenditure $547 million, investment
expenditure $143 million
Monetary conversion rate: 1 zaire=US$2
Fiscal year: calendar year','8d0adfceb32311c648a10e1dc49e7456c8acdb04fa81a1090052055ae471567a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f2e555e5a5156d7eeca22bf10711eec548c12731cffa804a2c1d3bad7adbf20',1974,'SN','Senegal','economy',354,'GDP: $1.2 oe (1972 est.); $290 per capita; real growth rate less than 1%
(1966-71
Agriculture: main crops -- peanuts, millet, sorghum, manioc, rice; peanuts
primary cash crop; production of food crops increasing but still insufficient
for domestic requirements
Fishing: catch 240,000 metric tons, $48 million, (1971); exports $12 million
(1971), imports (not available)
Major industries: fishing, agricultural processing plants, light manufacturing,
mining
Electric power: 134,200 kw. capacity (1973); 354 million kw. -hr. produced (1973),
88 kw.-hr. per capita
Exports: $215 million (f.0.b., 1972); approx. 35% peanuts and peanut products;
phosphate rock; canned fish
Imports: $279 million (c.i.f., 1972); food, consumer goods, machinery, transport
equipment
Major trade partners: France, EC (other than France), and franc zone
Aid: economic -- France (1966-70) $115 million; China (1973) $49.1 million;
U.S. (FY1961-72) $42.8 million; U.S.S.R. $7.1 million; EC (1961-72) $40.7 millions
military -- U.S. (FY61-72) $2.8 million
Budget: 1972 est. -- receipts $215 million, current expenditure $193 million,
investment expenditure $19.8 million
Monetary conversion rate: francs; 255.785 Communaute Financiere Africaine
francs=US$1 as of February 1973, floating since February 1973
Fiscal year: 1 July - 30 dune','1ae47a8543b00b6475e40eff0122ea6e7a7ab9291eb7d92fc4c23ac2785f69c4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7290572ebec48253cc3a723f9a893e4a7afc84a178be71ebbfddb29bacf85820',1974,'SC','Seychelles','economy',358,'Agriculture: islands depend largely on coconut production and export of copra;
cinnamon, vanilla, and patchouli (used for perfumes) are other cash crops;
food crops -- small quantities of sweet potatoes, cassava, Sugarcane, and
bananas; islands not self-sufficient in foodstutfs and the bulk of the
supply must be imported
Major industries: processing of coconut and vanilla, fishing, small-scale
manufacture of consumer goods, coir rope factory, tea factory
Electric power: 3,500 kw. capacity (1973); 9 million kw.-hr. produced (1973),
171 kw.-hr. per capita
Exports: $2.1 million (f.0.b., 1970); cinnamon (bark and oi1) and vanilla account
for almost 50% of the total, copra accounts for about 40%, the remainder
consisting of patchouli, fish, and guano
Imports: $10.1 million (c.i.f., 1970); food, tobacco, and beverages account for
about 40% of imports, manufactured goods about 25%, machinery and transport
equipment, petroleum products, textiles
Major trade partners: exports -- India, U.S.5 imports -- U.K., Burma, India,
South Africa, Kenya, Australia
307
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Aid: $1.2 million in aid in both 1965 and 1966 from U.K.; US (FY53-72) $0.4 million
Budget: FY73 -- revenues $9 million, expenditures 10 million (approx. )
Monetary conversion rate: 5.4 Seychelles rupees=US$1
Fiscal year: calendar year','f2e2385342e41823dbeb73a97778a794e67335c15a84ed70a294d389233aa94d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2ae4b9e22e2c79caa8657f23c49e270975c906fd6b5dbc41b17068f0bd410a3',1974,'SL','Sierra Leone','economy',362,'GDP: $435 million (FY71), approx. $170 per capita; real growth rate 1970, 2%-3%
Agriculture: main crops -~ palm kernels, coffee, cocoa, rice, yams, millet, ginger,
cassava; much of cultivated land devoted to subsistence farming; food crops
insufficient for domestic consumption
Fishing: catch 30,600 metric tons, $4.3 million, imports $2.7 million (1971)
309
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major industries: mining -~ diamonds, iron ore, bauxite, rutile; manufacturing
-- beverages, textiles, cigarettes, construction goods; 1 oi] refinery
Electric power: 57,000 kw. capacity (1973); 208 million kw.-hr. produced (1973),
77 kw.-hr. per capita
Exports: $118 million (f.0.b., 1972); 60% diamonds; iron ore, palm kernels, cocoa,
coffee
Imports: $121 million (c.i.f., 1972); machinery and transportation equipment,
manufactured goods, foodstuffs, petroleum products
Major trade partners: U.K., EC, Japan, U.S., Communist countries
Monetary conversion rate: 1 leone=US$1. 30 (official), as of December 1971;
floating with pound sterling since then
Fiscal year: 1 July - 30 June (since 7 July 1966)
GNP: about $100 per capita
Agriculture: animal husbandry, cardamon, foodgrains, tea, and oranges
Industry: food processing and handweaving
Foreign trade: conducted and regulated by India
Exports: cardamon and preserved fruits
Imports: consumer goods
Major trade partner: India
Aid: India (1955-66) $19.8 million committed and drawn; India (1967-72) $14.3
million committed (excludes $17.3 million spent on the development of
military roads)
Monetary conversion rate: 7.5 Indian rupees=US$1 (official rate); now floating
with U.K. pound
Fiscal year: 1 April stated year - 31 March','afaa0da1c70ed35bd2f9761ab4fadfd1e466d70ebc4f3d18d31d8bd8385c21ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b22bbd27f80154d21664105ecc70f3a9eb3e6291b6ff3bea014c6066c9604595',1974,'SG','Singapore','economy',366,'a $4.0 ay hae (1973), $1,800 per capita; 12% average annual real growth
1966-73
Agriculture: occupies a position of minor importance in the economy, self-sufficient
in pork, poultry, and eggs, must import much of its other food requirements;
major crops -- rubber, copra, fruit and vegetables
Fishing: catch 14,700 metric tons (1972), imports -- 47,000 metric tons (1972)
Major industries: petroleum refining, rubber processing and rubber products,
processed food, and beverages, electronics, ship repair, entrepot trade
Exports: $3.58 billion (f.o.b., 1973); 60% reexports; petroleum products, rubber,
manufactured goods
313
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
SOMALTA
LAND:
246,000 sq. mni.; 13% arable (0.3% cultivated), 32%
grazing, 14% scrub and forest, 41% mainly desert,
urban, or other
Land boundaries: 1,406 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,880 mi.
GDP: $210 million (1963 est.), about $70 per capita
Agriculture: mainly a pastoral country; main crops -- bananas,
sugarcane, cotton, cereals; livestock
Major industries: a few small industries, including a sugar refinery, tuna
and beef canneries, iron rod plant
Electric power: 9,000 kw. capacity (1973); 38 million kw.-hr. produced (1973),
12 kw.-hr. per capita
Exports: $43 million (f.a.b., 1972); bananas, livestock, hides, skins
Imports: $73 million (c.i.f., 1972); textiles, cereals, transport equipment
Major trade partners: Italy and U.K.3 Arab countries; $6.9 million imports from
Communist countries (1970 est.)
315
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','4f42053b4b7f9dc522b01d9018ef17070cd037f18bc87d30dcd23fe9bb9b6381','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bea8fcabe84568f7ddb6bcf06519c34e6c699ee67f8682f706f377d3d9a3b7b',1974,'ZA','South Africa','economy',367,'LAND:
472,000 sq. mi. (includes enclave of Walvis Bay,
434 sq. mi.); 12% cultivable, 2% forested, 86%
desert, waste, or urban
Land boundaries: 1,270 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,790 mi.','04463d72d3318d3c4878a9a7dc222dfb4665038c74febd42b41c9beaf99dcab2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82bba5ca7d9d8c82ee9c97d0edd2f9c1287b6d7cfe14dcd34af720dbeb487cd4',1974,'ES','Spain','economy',373,'Agriculture: practically none; some barley is grown in nondrought years; fruit
and vegetables in the few oases; food imports are essential; camels, sheep,
and goats are kept by the nomadic natives; cash economy exists largely for
the garrison forces
Major industries: confined to fishing and handicrafts; exploitation of huge
phosphate deposit is planned
Shortages: water ;
Electric power: 3,450 kw. capacity (1973); 8.4 million kw.-hr. produced (1973),
110 kw.-hr. per capita
Exports: $445,600 (1968); dried fish, goatskins
Imports: $1,443,000 (1968); fuel for fishing fleet, foodstuffs
Major trade partners: monetary trade largely with Spain and Spanish possessions
Aid: small amounts from Spain
Monetary conversion rate: 58.03 pesetas=US$1 (official), set February 1973
on eA billion in 1973 (1972 prices), $160 per capita; real growth rate 3.5%
1973
Agriculture: agriculture accounts for about 35% of GNP; main crops -- rice,
rubber, tea, coconuts; 60% self-sufficient in food; food shortages -- rice,
wheat, sugar, fish
Fishing: catch 190,000 metric tons, $64 million (1970); exports $1.4 million,
imports $13.1 million (1972)
Major industries: processing of rubber, tea, and other agricultural commodities;
consumer goods manufacture
Exports: $310.7 million (f.o.b., 1972); tea, rubber, coconut products
Imports: $327.2 million (c.i.f., 1972), machinery and equipment, sugar, flour,
rice, textiles, and clothing
Major trade partners: (1972) exports -- U.K. 14.1%, China 8.2%, Pakistan 8.0%,
U.S. 7.2% U.S.S.R. 1.8%; imports -- U.K. 10.4%, China 4.9%, India 7.0%,
U.S. 7.6%, USSR 1.0%
Monetary conversion rate: 6.7 rupees=US$1 (effective December 1973)
Fiscal year: 1 January ~ 31 December (starting 1973)','4069710a244a86b94d6a0f5f4b8150f381487e71728aae40910a1088ee5425fd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50110240ebfc7e718c3c878fb8d2c49bb9d482253aaeda8ebe21d0a59cb542e0',1974,'SD','Sudan','economy',377,'GDP: $1.6 billion (1972), under $100 per capita; 8% growth at current prices 1968-69
Agriculture: main crops -- sorghum, millet, wheat, sesame, peanuts, beans,
barley; not self-sufficient in food production; main cash crops -- cotton,
gum arabic
Major industries: cotton ginning, textiles, brewery, cement, edible oils, soap,
distilling, shoes, pharmaceuticals
Electric power: 197,000 kw. capacity (1972); 590 million kw.-hr. produced (1972),
35 kw.-hr. per capita
Exports: $357 million (f.0.b., 1972); cotton (63%), gum arabic, peanuts,
sesame; $102 million exports to Communist countries (FY71)
Imports: $321 million (c.i.f., FY72); textiles, petroleum products, vehicles,
tea, wheat; $75 million imports from Communist countries (FY71)
Major trade partners: U.K., West Germany, Italy, India, U.S.S.R., China
Monetary conversion rate: 1 Sudanese pound=US$2.87 (official); 0.348 Sudanese
pound=US $1
Fiscal year: 1 July - 30 June','9ba1dcdd51af0363d5254b40165c733f13c3252db23e794d7b4d7f57e9d09702','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6d136390be8a30d1422523371011cebf845a50fa5753771a95afce602c9c89c',1974,'SE','Sweden','economy',381,'GNP: $50.4 billion, $6,190 per capita (1973); 53.5% consumption, 22.1% investment,
23.3% government; 1.1% net exports of goods and services (1971); 1973 growth
rate 2.9% in constant prices
335
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Agriculture: animal husbandry predominates with milk and dairy products
accounting for 40% of farm income; main crops -- grains, sugar beets,
potatoes; 80% self-sufficient; food shortages -- oils and fats, tropical
products; caloric intake, 2,880 calories per day per capita (1967-68)
Fishing: catch 208,900 metric tons, exports $18 million, imports $105 million
Major industries: iron and steel, precision equipment (bearings, radio and
telephone parts, armaments}, shipbuilding, wood pulp and paper products,
processed foods, textiles, chemicals
Shortages: coal, petroleum, textile fibers, potash, salt
Crude steel: 5.2 million metric tons produced (1972), 640 kilograms per capita
Electric power: 17,559,000 kw. capacity (1972); 70.7 billion kw.-hr. produced
(1972), 8,200 kw.-hr. per capita
Exports: $12,189 million (f.0.b., 1973}; machinery, motor vehicles and ships,
wood pulp, paper products, iron and steel products, metal ores and scrap,
chemicals
Imports: $10,643 million (c.i.f., 1973); machinery, motor vehicles, petroleum and
petroleum products, textile yarn and fabrics, iron and steel, chemicals, food,
and live animals
Major trade partners: (1973) West Germany 15.0%, U.K. 14%, U.S. 6%, Norway
8%, Denmark 9%; EC-9 53%; U.S.S.R. and Eastern Europe 5%
Aid: economic’ -- U.S., $308.6 million authorized (FY46-73); $77.5 million in 1972
prelim.; $24.7 million in 1972; net official aid to less developed countries and
multilateral agencies, $662.4 million (1960-70), $159 million in 1971, $198
million in 1972 ;
Monetary conversion rate: 1 kronor=US$0.2295 average daily exchange rate, 1973
Fiscal year: 1 July - 30 June
Budget: 1972/73 -- revenues $13.1 billion, expenditures 14.3 billion','1c86507c046f378526ed06ecaef3eb3c39cd996cce6afb6eaaff5a902fb2411d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f5539013cce81ab7e7899c3efe92fc22935eb51f5af5dea61681fe72dc74966',1974,'CH','Switzerland','economy',384,'GNP: $41.6 billion (1973), $6,490 per capita (1973); 57% consumption, 30%
investment, 11% government, net foreign balance 2% (1973); 1973 growth rate
4.3%, constant prices
337
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d): :
Agriculture: dairy farming predominates; less than 50% self-sufficient; food
Shortages -- fish, refined sugar, fats and oils (other than butter), grains,
eggs, fruits, vegetables, meat; caloric intake, 3,190 calories per day per
capita (1969-70)
Major industries: machinery, chemicals, watches, textiles, precision instruments
Shortages: practically al] important raw materials except hydroelectric energy
Crude steel: 542,000 metric tons produced (1972), 80 kg. per capita
Electric power: 11,400,000 kw. capacity (1973); 33.7 billion kw.-hr. produced
(1973), 5,250 kw.-hr. per capita
Exports: $9.5 billion (f.0.b., 1973); principal items -- machinery and equip-
ment, chemicals, precision instruments, textiles, foodstuffs
Imports: $11.6 billion (c.i.f., 1973); principal items -- machinery and trans-
portation equipment, metals and metal products, foodstuffs, chemicals,
textile fibers and yarns
Major trade partners: West Germany 23%, France 12%, U.S. 7%, Austria 5%, Italy
9%, U.K. 7%; EC 58%; EFTA 11%; Communist countries 3% (1973)
Aid: economic -- authorized, U.S. $63 million through FY73; net official economic
aid delivered to less developed areas and multilateral agencies $194 million
(FY62-72), $67 million in FY72
Budget: receipts, $9,083 million, expenditures $9,803 million, deficit $720
million (1973)
Monetary conversion rate: 3.15 Swiss francs=US$1 (average 1973, floating)
Fiscal year: calendar year
GDP: $1.9 billion, est. (1973), $280 per capita; real GDP growth rate -8% 1973 est.
Agriculture: main crops -- cotton, wheat, barley and tobacco; Sheep and goat
raising; self-sufficient in most foods in years of good weather
Major industries: textiles, petroleum (est. 50,000 b/d production, refining
capacity was 54,000 b/d per day, but reduced by war damage) food processing,
beverages, tobacco
339
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Electric power: 277,500 kw. capacity (1974); 690 million kw.-hr. produced
(1973), 100 kw.-hr. per capita
Exports: $353 million (f.o.b., 1972); cotton, fruits and vegetables, grain,
wool, and livestock
Imports: $616 million (c.i.f., 1973 est.); machinery and metal products,
textiles, fuels, foodstuffs
Major trade partners: exports -- U.S.S.R., Italy, and Lebanon; imports -- Lebanon,
West Germany, Italy, U.S.S.R., Japan, and France
Budget: 1974 ast. -- revenues $415 million, expenditures $565 million
Monetary conversion rate: 3.80 Syrian pounds=US$1 (controlled rate) used
throughout; changed to 3.90 Syrian pounds=US$1 in January 1974
Fiscal year: calendar year
Mainland:
GDP: $1,138 million at 1966 prices (1971), about $80 per capita; growth rate in
constant 1966 prices for 1970-71 4.5%
Agriculture: main crops -- cotton, coffee, sisal on mainland; largely self-
sufficient in food
Fishing: catch 195,000 metric tons, $15.7 million (1970); exports $1.7 million,
imports $724,000 (1971)
Majer industries: primarily agricultural processing (sugar, beer, cigarettes,
sisal twine), diamond mine, oi] refinery, shoes, cement, textiles, wood
products
Electric power: 124,000 kw. capacity (1972); 460 million kw.-hr. produced (1972),
34 kw.-hr. per capita
Exports: $320 million (f.o.b., 1972); coffee, cotton, sisal, cashew nuts, meat,
diamonds, cloves, tobacco, tea
Imports: $406 million (c.i.f., 1972); manufactured goods, machinery and transport
equipment, cotton piece goods, crude oil, foodstuffs (mainly for Zanzibar)
Major trade partners: exports -- China, U.K., Hong Kong, India, Kenya, U.S.3
imports -- U.K., China, Kenya, West Germany, U.S., Japan
Monetary conversion rate: 1 Tanzanian shilling=US$0.14; 6.90 Tanzanian
shill ings=US$1
Fiscal year: 1 July - 30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops -- cloves, coconuts
Industries: agricultural processing
Electric power: see Tanganyika (above )
Exports: $12.6 million (1968); cloves and clove products, coconut products
Imports: $5.6 million (1968); mainly foodstuffs and consumer goods
Major trade partners: imports -- China, Japan, and mainland Tanzania;
exports -- Singapore, China, Hong Kong, Indonesia, India, Pakistan
Aid: U.K. principal source of aid until 1964; China is currently major source
Exchange rate: 1 Tanzanian shilling=US$0.14; 7.143 Tanzanian shillings=US$1
Fiscal year: 1 July - 30 June
GDP: $9.4 billion (1973 est. in current prices), $250 per capita; estimated 8%
real growth in 1973 (7% real growth, 1967-72)
Agriculture: world''s second largest rice exporter in 1973; main crops -- rice,
rubber, corn; almost 100% self-sufficient in food
Fishing: catch 1.6 million metric tons, exports, 32,000 tons, $22 million (1971)
Major industries: agricultural processing, textiles, wood and wood products,
cement, tin mining; world''s fourth largest tin producer
Shortages: fuel sources, including coal and petroleum
Electric power: 1,975,000 kw. capacity (1973); 6,570,000 kw.-hr. produced
(1973), 171 kw.-hr. per capita
Exports: $1,600 million (f.o.b., 1973); rice, corn, rubber, tin, cassava, kenaf
343
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Imports: $2,100 million (c.i.f., 1973}; excluding U.S. military imports;
machinery and transport equipment, textiles, fuels and lubricants, base
metals, chemicals
Major trade partners: exports -- Japan, U.S., Singapore, Hong Kong, Nethertands,
Malaysia; imports -- Japan, U.S., West Germany, U.K.; about 1% or less trade
with Communist countries
Budget: receipts $1,267 million, expenditures $1,526 million, deficit $259
million; 20% est. for defense
Monetary conversion rate: 20.0 baht=US$1
Fiscal year: 1 October - 30 September','c38d64638a19813f89fe7004a0eecd84f12ffea73167e2a907abc13195c15bd5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f80655d08b2c74f747400e1db43463fd3969d29d693a286e9196e16da1d9ffb',1974,'TG','Togo','economy',389,'GDP: $290 million (1971), about $140 per capita; estimated real growth 1966-70,
5.3% average annual rate
Agriculture: main cash crops -- coffee, cocoa; major food crops -- yams, cassava,
corn, beans, rice, fish; must import some foodstuffs
Major industries: phosphate mining, agricultural processing, handicrafts,
textiles, beverages
Electric power: 24,300 kw. capacity (1973); 74.4’ million kw.-hr. produced (1973),
34 kw.-hr. per capita
345
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (Cont''d):
Exports: $50 million (f.0.b., 1972); phosphates, cocoa, coffee, palm kernels,
and cassava
Imports: $85 million (c.i.f., 1972); consumer goods, fuels, machinery, tobacco,
foodstuffs
Major trade partners: mostly with France and other EC countries
Aid: (1970 disbursements) France $2.3 million, West Germany $2.0 million, U.S.
$1.0 million (FY59-72 total commitments $19.5 million), EC $3.5 million,
U.N. $1.0 million, others $1.1 million
Budget: 1974 est. revenues and expenditures, $69 million
Monetary conversion rate: Conmunaute Financiere Africaine 255.785 francs=US$1 as
of February 1973; floating since February 1973
Fiscal year: calendar year','87a96c731b41f12097e70867aeebfe60d089175887e0c3d12116a8596085680b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d73cb40b3033f2d99d6f8db7c86ee143dbe83d2922e0257865eaaa2b2d446bf9',1974,'TO','Tonga','economy',393,'GDP: $15 million (FY71), $160 per capita
Agriculture: largely dominated by coconut production with subsistence crops of
taro, yams, sweet potatoes, and bread fruit
Exports: $2.5 million (f.o.b., 1971); copra, coconut products 65%, bananas 17%
Imports: $7.1 million (c.i.f., 1971)
Major trade partners: (1971) exports -- 31% New Zealand, 20% U.K., 12%
Netherlands; imports -- 34% New Zealand, 20% Australia, 15% U.K., 12% Fiji
Monetary conversion rate: 0.82 Tonga dollar=US$1 (1972)
Fiscal year: 1 July-30 June','8661dfe36ae0ff15de09304ac1077b87441ded41d5ff94ab3312b7052b693edf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94dbdd9080284f27933402a59eee41b8a230834934d605e291dbd81c1b1db01b',1974,'TT','Trinidad and Tobago','economy',397,'GDP: $925 million (1971), $960 per capita; real growth rate 1971, 8.0% est.
Agriculture: main crops -- sugarcane, cocoa, coffee, rice, citrus, bananas;
largely dependent upon imports of food
Fishing: catch 3,977 metric tons (1972); exports $1.0 million (1971), imports
$2.6 million (1971)
Major industries: petroleum, tourism, food processing, cement
Electric power: 290,000 kw. capacity (1972); 1.3 billion kw.-hr. produced (1972),
1,390 kw.-hr. per capita
Exports: $554 million (f.o.b., 1972); petroleum and petroleum products ($281
million, sugar, cocoa
Imports: $742 million (c.i.f., 1972); crude petroleum ($339 million), machinery,
fabricated metals, transportation equipment, manufactured goods, food
Major trade partners: (excludes trade under petroleum agreement) exports -- U.S.
37%, U.K. 11%, CARIFTA 21%; imports -- U.S. 34%, U.K. 23%, CARIFTA 10% (1972)
Aid: economic -- from U.S. (FY56-72) $31.2 million loans, $40.6 million grants;
from international organizations (FY53-72), $74.4 million
Monetary conversion rate: floating with pound sterling; in February 1974,
TT$2.08=U.S.$1
Fiscal year: calendar year
GNP: $2.1 billion (1972 est.), $390 per capita; 10.6% average annual growth rate
1970-72
Agriculture: cereal farming and livestock herding predominate; main crops --
wheat, barley, olives, fruits (especially citrus), viticulture, vegetables,
dates ;
Major sectors: tourism, mining, food processing, textiles and leather, light
manufacturing, construction materials, chemical fertilizers, petroleum
Electric power: 300,000 kw. capacity (1972); 869 million kw.-hr. produced (1972),
155 kw.-hr. per capita
351
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Exports: $31] million (f.0.b., 1972); 28% petroleum, 14% phosphates, 28% olive
oil, 30% other
Imports: $460 million (c.i.f., 1972); 36% raw materials, 23% machinery and
equipment, 14% consumer goods, 19% food and beverages, 3% energy, 5% other
Major trade partners: exports -- France 19%, Italy 19%, West Germany 13%, Libya
10%; imports -- France 36%, U.S. 15%, Italy 9%, West Germany 7% (1971)
Monetary conversion rate: 0.435 dinar=US$1 (trade rate, January 1974)
Fiscal year: calendar year
GNP: $19.7 billion (1973), about $520 per capita; 6.3% average annual real
growth 1973, 7.6% average annual real growth 1972
Agriculture: main products -- cotton, tobacco, cereals, sugar beets, fruits, nuts,
and livestock products; self-sufficient in food in average years, 2,900 calories
per day per capita (1972)
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: 1.12 million tons produced (1971), 30 kilograms per capita
Electric power: 2,800,000 kw. capacity (1972); 11.1 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $1,318 million (f.0.b., 1973); cotton, tobacco, fruits, nuts, metals,
livestock products, textiles and clothing
Imports: $2,091 million (c.i.f., 1973); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 21%, U.S. 12%, Switzerland 9%,
Italy 6%; imports -- West Germany 19%, U.S. 12%, U.K. 11%, Italy 11%
Budget: (FY73) revenues $4,112 million, expenditures $4,448 million, deficit
$336 million
Monetary conversion rate: 14 Turkish liras=US$1 (average 1973)
Fiscal year: 1 March - 28 February','f907254609456c6f8973426e440a69df45f68d98f838c695d5bca14d9babc412','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae4a8efab727450b5c9d73a78850bbf4b6d655dd362f82e49a5723a6adb81e3d',1974,'UG','Uganda','economy',401,'GDP: $1,053 million (1973) at 1966 prices, $100 per capita; 1% real growth
between 1972 and 1973
Agriculture: main cash crops -- coffee, cotton; other cash crops -- Sugar,
tobacco, tea, fish, livestock; self-sufficient in food
Fishing: catch 137,000 metric tons (1970), $26.2 million (1971)
Major industries: agricultural processing (textiles, sugar, coffee, plywood,
beer), cement, copper smelter, corrugated iron sheet, shoes, fertilizer
Electric power: 170,700 kw. capacity (1972); 817 million kw.-hr. produced
(1972), 78 kw.-hr. per capita
Exports: $293 million (f.o.b., 1972); coffee, cotton, copper, tea; $13.4 million
to Communist countries (1971)
Imports: $250 million (c.i.f., 1971); petroleum products, machinery, cotton
‘ane metals, transport equipment; $8.3 million from Communist countries
1971
Major trade partners: U.K., U.S., Kenya (Uganda, Kenya, and Tanzania form
East African Economic Community)
355
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Monetary conversion rate: 6.90 Uganda shillings=US$1; 1 Uganda shilling=US$0.14
. Fiscal year: 1 July - 30 June
Agriculture: principal food crops -- grain (especially wheat), potatoes; main
industrial crops -- sugar beets, cotton, sunflowers, and flax; degree of
self-sufficiency depends on fluctuations in crop yields; given normal yields,
U.S.S.R. is self-sufficient; caloric intake, 3,000-3,200 calories per day
per capita in recent years
357
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Fishing: catch 8,209,000 metric tons (1972); exports 242,200 metric tons (1972),
imports 20,600 metric tons (1972)
Major industries: diversified, highly developed capital goods industries; consumer
goods industries comparatively less developed
Shortages: natural rubber, bauxite and alumina, tantalum, tin, and tungsten
Crude steel: 136 million metric ton capacity as of 1 January 1973; 126 million
metric tons produced in 1973, 520 kilograms per capita
Exports: fuels (particularly petroleum and derivatives), metals, agricultural
products (timber, grain) and a wide variety of manufactured goods (primarily
capital goods); $21,300 million (f.0.b. 1973)
Imports: specialized and complex machinery and equipment, textile fibers, consumer
manufactures, and any significant shortages in domestic production (for example,
wheat imported following poor domestic harvests); $20,925 million (f.o.b., 1973)
Major trade partners: $42.3 billion (1973); trade 58% with Communist countries,
27% with industrialized West, and 15% with less developed countries
Official monetary conversion rate: 0.715 rubles=US$1; 1 ruble=US$1. 3986
(October 1973)
Fiscal year: calendar year','51fb2a52c02e9189856c96f2964ea36ef9b117c56a28d944f47a0692fd917550','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7503321ede1f5c2f084171507ff0340b7493c1be20b9beda2d98b3901a69ddfc',1974,'AE','United Arab Emirates','economy',405,'Agriculture: food imported, but some dates, alfalfa, vegetables, fruit, tobacco
raised
Electric power: 46,800 kw. capacity (1973); 117 million kw.-hr. produced (1973),
659 kw.~-hr. per capita
Exports: crude petroleum, pearls, fish; non-oil Abu Dhabi $610 million (1972)
and Dubai $41 million total (1972 rev.)
Imports: food, consumer and capital goods; Abu Dhabi $174 million and Dubai $249
million total (1972)
Major trade partners: Japan, U.K., India, U.S.
Aid: multilateral annual average (1967-69) $1.17 million
Budget: (1974) $215 million; Abu Dhabi (1974) $1.5 billion; Dubai (1973) $151
million
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.25; Abu Dhabi, 1 Bahrain
dinar=US$2.52 (as of October 1973)
359
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOP: $325 million (1971 est.), $60 per capita
Agriculture: cash crops -- peanuts, shea nuts, sesame, cotton; food crops -~-
sorghum, millet, corn, rice; livestock; largely self-sufficient
Fishing: catch 5,000 metric tons (1971)
Major industries: agricultural processing plants, brewery, bottling, and brick
plants; a few other light industries
Electric power: 15,530 kw. capacity (1973); 53 million kw.-hr. produced (1973),
9 kw.-hr. per capita
Exports: $24 million (f.0.b., 1972); livestock (on the hoof), peanuts, shea
nut products, cotton, sesame ~
Imports: $72 million (c.i.f., 1972); textiles, food, and other consumer goods,
transport equipment, machinery, fuels
363
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major trade partners: volume understated because much regional trade is unrecorded;
Ivory Coast and Ghana; overseas trade mainly with France and other EC countries:
preferential tariff to EC and franc zone countries
Aid: i
economic -- France (1964-September 1970) $46 million; EC (1960-72) $75.1
million; U.S.S.R., Ghana, West Germany, and Israel have also extended aid;
U.S. (FY61-72) $21.9 million; international organizations (1960-72) $26.9
million;
_ military -- France, $3.7 million (1964-70); U.S., $0.1 million (1962-72)
Budget: (1973) balanced at $49.8 million
Monetary conversion rate: 255.785 Communaute Financiere Africaine francs=US$1
as of February 1973, floating since February 1973
Fiscal year: calendar year','311bbd4e54815ba4028ce3cc8f56d9301b98395b12e0c6322e7ece2ac479103c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cebe2696dcfbf1ec4a35d7398e7bca9487a821579cc4e7a0a4636adfb20b7bd8',1974,'WF','Wallis and Futuna','economy',409,'Agriculture: dominated by coconut production with subsistence crops of yams, taro,
bananas
Trade: exports consist almost entirely of copra; imports are largely foodstuffs
and some equipment associated with development programs
Monetary conversion rate: 70 Colonial Franc Pacifique (CFP )=US$1
GNP: $38 million (1971), $260 per capita
Agriculture: cocoa, bananas, copra; staple foods include coconut, bananas, taro,
and yams
Exports: $6.3 million (1971); copra, cocoa, bananas
Imports: $12.8 million (1971); machinery and equipment, manufactured goods, food
Major trade partners: exports -- New Zealand, West Germany, the Netherlands;
imports -- New Zealand, Australia, US
Aid: New Zealand, $2.5 million conmitted; U.S., $2 million extended (FY67-70)
Monetary conversion rate: WS Tala=US$1.65 (August 1973), 0.61 WS Tala=US$]
Major industries: timber, tourism
377
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GNP: $100 million (1973 est.), $60 per capita
Agriculture (all outside Aden): cotton is main cash crop; cereals, dates, kat
(qat), coffee, and livestock are raised and there is a growing fishing
industry; large amount of food must be imported (particularly for Aden);
cotton, hides, skins, dried and salted fish are exported
Major industries: petroleum refinery (production 150,000 b/d) mid 1971; capacity
178,000 b/d at Little Aden operates on imported crude; oi1 exploration activity
Electric power: 128,000 kw. capacity (1972); 448 million kw.-hr. produced (1972),
290 kw.-hr. per capita
Exports: $130 million (FY71-72)
Imports: $196 million (FY71-72)
Major trade partners: Yemen, East Africa, but some cement and sugar imported from
Communist countries; crude oi] imported from Persian Gulf, exported mainly to
U.K. and Japan
*Excluding the islands of Perim and Kamaran for which no data are available
379
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Monetary conversion rate: 1S. Yemeni dinar=US$2.90
Fiscal year: 1 April - 31 March
GNP: $300 million (1973 est.), $50 per capita
Agriculture: sorghum and millet, gat (a mild narcotic), cotton, coffee, fruits
and vegetables; largely self-sufficient in food
Major industries: cotton textiles and leather goods produced on a small scale;
nandicraft and some fishing; smal? aluminum products factory
Electric power: 4,000 kw. capactiy (1973); 14 million kw.-hr. produced (1973),
2 kw.~hr. per capita
Major trade partners: China, Yemen (Aden), U.S.S.R., Japan, U.K., Australia,','2cdd8dc6e715b7a740cd947260a19c40eb08deb046c634ea7b9837c05d717280','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6222a7ef9a45530c2472efa2429c97b155a6e4f269f110a237d20ea30f64545e',1974,'US','United States','economy',415,'GNP: $1,289 billion (1973); 62% consumption, 16% private investment, 21% government;
$6,130 per capita; 1973 growth rate 5.9% (constant 1958 dollars)
Fishing: catch 2.8 million metric tons (1971); imports $914 million (1971); exports
$136 million (1971)
Crude steel: 121 million metric tons produced (1972), 580 kg. per capita
Electric power: 451,000,000 kw. capacity (1973); 1.8 trillion kw.-hr. produced
(1973), 8,400 kw.-hr. per capita est.
Exports: $70.8 billion (f.0.b., 1973); machinery and transport equipment,
chemicals, cereals, mineral fuels
Imports: $73.2 billion (c.i.f., 1973); transport equipment, machinery, mineral
fuels, steel, nonferrous metals, metal ores
Major trade partners: (1973) Canada 23%, Japan 13%, West Germany 6%, U.K. 5%
Official development assistance (aid): obligations and loan authorizations (FY72),
economic $5.4 billion, military $4.6 billion
Fiscal year: 1 July - 30 June
389
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','57ba6962027c6301d2a048265b94d6e74f4150f896fc9dd30eb2df36b1132bc5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

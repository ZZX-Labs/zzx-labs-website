SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b3cbbeee8611f0fd16be09b94f2111f2d5ca93bab30ffa18931e551f5365174',1974,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal
systems; constitution adopted 1961, judicial review of
legislative acts by Constitutional Court; legal education at
Universities of Ankara and Istanbul; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Republic Day, 29 October
Branches: President elected by parliament, Prime Minis-
ter appointed by President from members of parliament,
Prime Minister is effective executive, cabinet, selected by
Prime Minister and approved by President, must command
majority support in lower house; parliament bicameral
under constitution promulgated in 1961; National Assembly
has 450 members serving 4 years; Senate has 150 elected
members, one-third elected every 2 years, 15 appointed by
the President to 6-year terms (one-third appointed every 2
years), and 19 life members; highest court for ordinary
criminal and civil cases is Court of Cassation, which hears
appeals directly from criminal, commercial, basic, and peace
courts
Government leaders: President Fahri Koruturk; Prime
Minister Bulent Ecevit
Suffrage: universal over age 21
Elections: National Assembly and Senate (1/3 of seats),
Republican People’s Party won a plurality in June 1977;
Presidential (1980)
Political parties and leaders: Justice Party (JP),
Suleyman Demirel; Republican People’s Party (RPP), Bulent
Ecevit; National Salvation Party (NSP), Necmettin Erbakan;
~SEGREL
Democratic Party (DP), Ferruh Bozbeyli; Republican
Reliance Party (RRP), Turhan Feyzioglu; Nationalist Action
Party (NAP), Alpaslan Turkes; Unity Party (UP), Mustafa
Timisi; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced
resignation of Demirel government in March 1971 and
remains an influential force in national affairs
Member of: ASSIMER, CENTO, Council of Europe, EC
(associate member), ECOSOC, FAO, GATT, IAEA, IBRD,
IGAC, ICAO, IDA, IEA, IFC, 1HO, ILO, IMCO, IMF,
1OOC, 1PU, ITC, ITU, NATO, OECD, Regional Coopcra-
tion for Development, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG, WTO','2767abfc309d869870d586c4b894db2fbcbbefba5816fbf276efac70f3bc04af','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7985e2aa7a2bddc6275bd6a35fc91e26917c786200bd5703f0c467dd6a89499',1974,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
_ Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Fahri Koruturk, Prime Minister Naim Talu
Suffrage: universal over age 21
mar erhse National Assembly and Senate (1/3 of seats) (October 1973); Presidential
1980
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
Peopic''s Party (RPP), Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Repiblican Reliance Party (RRP), Turhan Feyzioglu; National Action Party
(NAP), Alparslan Turkes; Nation Party (NP), Osman Bolukbasi; Unity Party (UP),
Mustafa Timisi; Communist Party 1]]lega]
Communists: strength and support negligible
Other political or pressure groups: military forced resignation of Demirel
government in March 1971 and remains an influential force in government
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECD, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO
345
Approved for Release: 2018/04/27 C06726998
Approved for Release: 2018/04/27 C06726998','ab13b7d52498cd92944d61b57e729cf5486b777d25f34bb9dbaa98cdf50e7cd0','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18237c7fdd8719c4b7a79013a99fb0ea43f48492415e2ab023532cd1357bc543',1974,'','','government',3,'Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and ci vil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts :
Government leaders: President Fahri Koruturk, Prime Minister Naim Talu
Suffrage: universal over age 21
ey ais National Assembly and Senate (1/3 of seats) (October 1973); Presidential
0
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party (RPP), Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Republican Reliance Party (RRP), Turhan Feyzioglu; National Action Party
(NAP), Alparslan Turkes; Nation Party (NP), Osman Bolukbasi; Unity Party (UP),
Mustafa Timisi; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced resignation of Demirel
government in March 1971 and remains an influenti a? force in government
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO. IMCO, IMF, ITU, NATO, OECD, Regional
rather has Development, Seabeds Committee (observer), U.N., UNESCO,
447
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
Sere','49099b5e9c45b3b5d46175efa1d3065c75b0f852d14bdef354a8a20e1a861556','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c91b514af6fd35dc945b8fc8449fdd56ea5a605911c5da01bf52e9de29a68272',1974,'','','government',3,'Legal name: Republic of Afghanistan
Type: republic
Capital: Kabul
Political subdivisions: 28 provinces with centrally appointed governors
Legal system: based on Islamic law; constitution nullified July 1973; independent
judiciary also abolished and powers transferred to the Council of Justice,
chaired by Minister of Justice; legal education at University of Kabul;
has not accepted compulsory ICJ jurisdiction
Branches: Parliament abolished July 1973; all powers of the par Liaiient and the
monarchy transferred to the Pres,ident’
Government leaders: President Mohammad Daud who also serves as ain minister,
foreign minister, and defense minister; Naim Khan, Daud''s brother ahd
personal adviser; young, mostly unidentified, military officers serving
on the ruling Central Committee
Suffrage: universal over age 20
Elections: promised but no date set
Political parties and leaders: no political parties permitted
Communists: there are 2 pro-Moscow Communist groups, with about 350-500 active
members; several other groups, further to left, with several hundred members
and sympathizers
Other political or pressure groups: with the mullahs and the military supporting
the new government, no known organized opposition
Member of: ADB, Colombo Plan, FAO, FUND, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO,
IMF, ITU, U.N. UNESCO, UPU, WHO, WMO
Legal name: People''s Republic of Albania
Type: Communist state
Capital: Tirane
Political subdivisons: 27 rethet (districts), including capital, 200 localities,
2,600 villages
Legal system: based on Soviet law; constitution adopted 1950; judicial review
of legislative acts only in the Presidium of the People''s Assembly, which
is not a true court; legal education at State University of Tirane; has not
accepted compulsory ICJ jurisdiction
Branches: People''s Assembly, Council of Ministers, judiciary
Government leaders: Chairman of Council of Ministers, Mehmet Shehu; President,
Presidium of the People''s Assembly, Haxhi Lleshi
Suffrage: universal and compulsory over age 18
Elections: national elections theoretically held every 4 years; last elections
September 1970
Political parties and leaders: Albanian Workers Party only; First Secretary,
Enver Hoxha
Voting strength (1970 election); 99.9% Communist
Communists: 75,637 party members (1970)
Member of: CEMA, IAEA, ILO, ITU, U.N., UNESCO, UPU, WHO, WMO; has not participated
in CEMA since rift with U.S.S.R. in 1961; officially withdrew from Warsaw
Pact 13 September 1968
Legal name: Democratic and Popular Republic of Algeria
Type: republic
Capital: Algiers
Political subdivisions: 15 Wilayas (departments or provinces)
Legal system: based on French and Islamic law, with socialist principles;
constitution adopted by referendum 1963 but suspended since June 1965;
judicial review of legislative acts in ad hoc Constitutional Council composed
of various public officials, including several Supreme Court justices; Supreme
Court divided into 4 chambers; legal education at Universities of Algiers,
Oran and Constantine; has not accepted compulsory ICJ jurisdiction
Branches: executive dominant, unicameral legislature has not met since June
1965 coup d''etat but waS.''never formally suspended, judiciary
Government leader: Houari Bouniediene, President of Council of the Revolution
and President of the Council of Ministers, overthrew elected President
Ahmed Ben Bella 19 June 1965
Suffrage: universal over age 19
Elections: presidential 15 September 1963; departmental assemblies 25 May 1969;
local councils 14 February 1971
Political parties and leaders: National Liberation Front (FLN)
Voting strength (1963 election): 100% FLN
Communists: 400 (est.); Communist Party illegal (banned 1962)
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, ILO, IMCO, IMF, ITU, OAU,
OPEC, U.N., UNESCO, UPU, WHO
Legal name: The Valleys of Andorra
Capital: Andorra
Political subdivisions: 6 districts -- Andorra la Vella, Sant Julia de Loria,
Encamp, Canillo, La Massana, and Ordino
Type: unique coprincipality under formal sovereignty of President of France and
Spanish Bishop of Seo de Urgel, who are represented locally by officials
called veguers
Legal system: based on French and Spanish civil codes; Plan of Reform adopted
1866 serves as constitution; no judicial review of legislative acts; has
not accepted compulsory ICJ jurisdiction
Branches: legislature (General Council) of 24 members with one-half elected
every 2 years for 4-year term; executive -- syndic and a deputy sub-syndic
chosen by General Council for 3-year terms; judiciary chosen by coprinces
who appoint 2 civil judges, a judge of appeals, and 2 Batles (court
prosecutors)
Suffrage: males of 21 or over who are third generation Andorrans vote for
General Council members; same right granted to women in April 1970
Elections: half of General Council chosen every 2 years, last election December
1973
Political parties and leaders: no political parties but only partisans for
particular independent candidates for the General Council, on the basis of
competence, personality and orientation toward Spain or France; various small
pressure groups developed in 1972
Communists: none known
Legal name: State of Angola
Type: overseas state of Portugal
Capital: Luanda
Political subdivisions: 16 administrative districts including the coastal
exclave of Cabinda
Legal system: Portuguese civil codes and customary law; legal education
obtained in Portugal
Branches: Governor General appointed by Ministry of Overseas in Lisbon is
executive officer responsible for internal administration; he also has
prescribed legislative functions which he shares with Legislative Assembly
of directly and indirectly elected members; all action in state may be
vetoed by Minister of Overseas; independent judiciary
Government leader: Governor General Fernado Santos e Castro
Suffrage: all adults able to read and write Portuguese and in full possession
of political and civil rights
Elections: Legislative Assembly elections held every 4 years; last held March 1973
Political parties and leaders: only legal group is Portuguese National Popular
Action (ANP), formerly the National Union (UN), headed by Gustavo Neto Miranda
Other political or pressure groups: principal opposition groups which are
carrying out insurgency are Revolutionary Government of Angola in exile
(GRAE), led by Holden Roberto; Popular Movement for the Liberation of Angola
(MPLA), led by Agostinho Neto; and National Union for the Total Independence
of Angola (UNITAY, led by Jonas Savimbi
Communists: none known
Legal name: State of Antigua
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: St. Johns
Political subdivisions: 6 parishes, 2 dependencies (Barbuda, Redonda)
Legal system: based on English law; British Caribbean Court of Appeal has
exclusive original jurisdiction and an appellate jurisdiction, consists of
Chief Justice and 5 justices
Branches: legislative, 21-member popularly elected House of Representatives;
executive, prime minister and cabinet
Government leaders: Prime Minister George Herbert Walter; Governor Wilfred
Ebenezer Jacobs
Suffrage: universal suffrage age 21 and over
Elections: every 5 years; last general election 11 February 1971; last by-election
August 1968
Political parties and leaders: Antigua Labor Party (ALP), Vere C. Bird;
Progressive Labor Movement (PLM), George Herbert Walter; Antigua People''s
Party (APP), J. Rowan Henry
Voting strength: 1971 election -- House of Representative seats -- ALP 4, PLM 13
Communists: none known
Other political or pressure groups: Afro-Caribbean Movement (ACM), a small black
nationalist group led by Timothy Hector; Antigua Freedom Fighters (AFF), a
smal] black radical group, leaders unknown
Member of: has been invited to join CARICOM (CARIFTA replacement )','155f739083dec54e9d1d342d7cfababc599d0c892b2f360a12cf775210b97413','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f02286b88a3ed96913cff804b5c6b8ee7e99e785d7d61a152b5afdaeda423a90',1974,'BR','Brazil','government',11,'Legal name: Argentine Republic
Type: republic; elected government took over 25 May 1973 from military regime
in control since coup in June 1966; it resigned on 13 July and new election
was held on 23 September bringing Peron back to power
Capital: Buenos Aires ;
Political subdivisions: 22 provinces, 1 district (Federal Capital), and 1 territory
Legal system: based on Spanish and French civil codes; constitution adopted
1853 partially superseded in 1966 by the Statute of the Revolution which
takes precedence over the constitution when the two are in conflict,
further changes may be made by new government; judicial review of
legislative acts; legal education at University of Buenos Aires and other
public and private universities; has not accepted compulsory ICJ jurisdiction
Branches: presidency; national judiciary; legislature dismissed after June
1966 coup was reopened when new government was inaugurated on 25 May
Government leader: President, Juan Peron
Suffrage: universal and compulsory age 18 and over
Elections: general elections held on 11 March 1973; congressional and
gubernatorial runoffs were held on 15 April; next election in 4 years
Political parties: Justicialistas, the official Peronist party; Radical Civic
Union, moderate leftist and nationalist, Ricardo Balbin; Federal Popular
Alliance, Francisco Manrique; Movement of Integration and Development (MID),
small left of center party, former President Frondizi; New Force, conservative
business party, organized by Alvaro Alsogaray for the 1973 elections;
Intransigent Party, formerly the Intransigent Radicals (UCRI), smal]
nationalist party, Oscar Alende; Union Popular, neo-Peronist or Peronism
without Peron, generally more moderate than orthodox Peronism, Rodol fo
Tecera del Franco; Popular Conservative Party, not conservative but a member
of Peron''s Civic Front, Vicente Solano Lima; smaller parties include the
Revolutionary Christian Party and the Popular Christian party (both are
factions of the Christian Democratic Party), the Progressive Democrats,
the Socialist Party, and the Democratic Socialist Party; several provincial
parties not organized on a national basis
13
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
a"
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Voting strength: Justicialista Front, 61%; Radicals (former People''s Radical
Civic Union, UCRP), 24%; Federal Popular Alliance, 12%; others, 3%
Communists: some 60,000 members in various party organizations, including a small
nucleus of activists
Other political or pressure groups: Argentine armed forces, Peronist-dominated
labor movement, National Meeting of the Argentines (loose grouping of
Communist and leftist politicians), General Economic Confederation
(Peronist-leaning association of small businessmen) Argentine Industrial Union
(manufacturers'' association), Argentine Rural Society (large landowners ''
association), business organizations, students, and the Catholic Church
Member of: FAO, IADB, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, LAFTA,
OAS, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO, Non-Aligned Nations Group
Legal name: Republic of Austria
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states (Laender) including the capital
Legal system: civil law system with Roman law origin; constitution adopted 1920,
repromulgated in 1945; judicial review of legislative acts by a Constitutional
Court; separate administrative and civil/penal supreme courts; legal education
at Universities of Vienna, Graz, Innsbruck, Salzburg, and Linz; has not
accepted compulsory ICJ jurisdiction
Branches: bicameral Parliament, directly elected President whose functions are
largely representational, independent federal judiciary
Government leaders: Chancellor Bruno Kreisky; President Franz Jonas
Suffrage: universal over age 19; compulsory for presidential elections
Elections: presidential, every 6 years (next 1977); parliamentary, every 4
years (next 1975)
Political parties and leadérs: Socialist Party of Austria (SPOe), Bruno Kreisky,
Chairman; Austrian People''s Party (OeVP), Karl Schleinzer, Chairman; Liberal
Party (FP0e), Friedrich Péter, Chairman; Communist Party, Franz Muhri, Chairman
Voting strength (1971 election): 50.2% SPOe, 43.0% OevP, 5.4% FPOe, 0.4% dissident
Socialist, 1.4% Communist
Communists: membership 26,000; activists 7,000-8,000; 60,705 votes in 1971 election
Other political or pressure groups: Federal Chamber of Commerce and Industry;
Austrian Trade Union Federation (primarily socialist); three composite leagues
of the Austrian People''s Party (OeVP) representing business, labor, and farmers;
the OeVP-oriented League of Austrian Industrialists; Roman Catholic Church,
including its chief lay organization, Catholic Action
Member of: Council of Europe, ECE, EFTA, IAEA, ICAO, OECD, Seabeds Committee, U.N.,
UNESCO, WHO
Legal name: Commonwealth of the Bahama Islands
Type: independent commonwealth since July 1973, recognizing Elizabeth II as
chief of state
Capital: Nassau (New Providence Island)
Legal system: based on English law
Branches: bicameral legislature (appointed Senate, elected House); executive
(Prime Minister and cabinet); judiciary
Government leaders: Prime Minister Lynden 0. Pindling
Suffrage: universal over age 18
Elections: House of Assembly (9 September 1972) ;
Political parties and leaders: Progressive Liberal Party (PLP), predominantly
Negro, Lynden 0. Pindling; Free National Movement (FNM) formed by a merger
of United Bahamian Party (UBP) and Free Progressive Liberal Party (Free PLP),
Kendall Isaacs
Voting strength (1972 election): PLP 29 seats, FNM 9 seats
Communists: none known
Legal name: People''s Republic of Bangladesh
Type: independent republic since December 1971
Capital: Dacca
Political subdivisions: 19 districts, 413 thanas (counties), 4,053 unions (village
groupings)
Legal system: based on English common law; constitution adopted December 1972
Branches: parliamentary government; constitution provides for unicameral
legislature, strong prime minister; independent judiciary
Government leader: Prime Minister Sheikh Mujibur Rahman
Suffrage: universal over age 18
Elections: First Parliament (House of the Nation) elected in March 1973;
elections to be held at least every 5 years
Political parties and leaders: Awami League, Sheikh Mujibur Rahman, President;
National Awami Party/Bhashani, Maulana Bhashani, President; National Awami
Party/Muzaffar, Muzaffar Ahmed, President; National Socialist Party
(Jatiyo Samjtantrik Dal), Abdur Rab, General Secretary, and M.A. Jalil,
President; Communist Party of Bangladesh, Moni Singh, leader, and Abdus
Salam, General Secretary; East Bengal Communist Party/Marxist-Leninist,
Mohammed Toaha, leader; Bangladesh National League, Ataur Rahman Khan,
leader; Communist Party of Bangladesh/Leninist, Amal Sen, General Secretary;
East Bengal Communist Party, Tara Mia, Secretary of the Central Commi ttee ;
other small radical leftist groups some calling themselves Communists
Voting strength: (1973 election) 73.1% Awami League; 8.6% NAP/M; 6.5% JSD;
5.4% NAP/B; 6.4% independents and others
Communists: no information available on membership or degree of popular support
Other political or pressure groups: student groups, bands of former guerrillas
Member of: Afro-Asian People''s Solidarity Organization, Commonwealth, IBRD, IDA,
IMF, ILO, IPU, UNCTAD, UNESCO, WHO
*Does not take account of refugees who entered India from Bangladesh during 1971,
most of whom presumably have returned. This figure is based on data reported by
Pakistan''s Central Statistical Office prior to the separation of Bangladesh from
Pakistan. Other estimates by U.S. demographers indicate a population in the range of
70 to 80 million. The latter estimates are based on underenumeration in the 1961
census and a higher growth rate than that implied by the Pakistani data.
25
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Barbados
Type: independent state since November 1966, recognizing Elizabeth II as chief
of state
Capital: Bridgetown
Political subdivisions: 11 parishes
Legal system: English common law; constitution came into effect upon
independence in 1966; no judicial review of legislative acts; has not
accepted compulsory ICJ jurisdiction
Branches: legislature consisting of a 21-member appointed Senate and a
24-member elected House of Assembly; cabinet headed by Prime Minister
Government leader: Prime Minister Errol Barrow
Suffrage: universal over age 18
Elections: House of Assembly members have terms no longer than 5 years;
last general election held 9 September 1971
Political parties and leaders: Democratic Labor Party (DLP), Errol Barrow;
Barbados Labor Party (BLP), J. M. G. "Tom" Adams
Voting strength (1971 election): Democratic Labor Party (DLP), 57.5%; Barbados
Labor Party, 42.5%; Independent, negligible; House of Assembly seats -- DLP
18, BLP 6
Communists: none
Other political or pressure groups: People''s Progressive Movement (PPM), a
small black-nationalist group led by Calvin Alleyne
Member of: CARIFTA, Commonwealth, ICAO, IMF, OAS, Seabeds Committee (observer).
U.N
Legal name: Republic of Chile
Type: republic
Capital: Santiago
Political subdivisions: 25 provinces
Legal system: based on Code 1857 derived from Spanish law and subsequent codes
influenced by French and Austrian law; constitution adopted 1925, amended
since then, currently being revised; judicial review of legislative acts in
the Supreme Court; legal education at University of Chile, Catholic University,
and several others; has not accepted compulsory ICJ jursidiction
Branches: president currently replaced by 4-man Military-Police Junta; bicameral
legislature currently dissolved; independent judiciary
Government leader: Junta President, Gen. Augusto PINOCHET Ugarte; other Junta
members, Adm. Jose Toribio MERINO Castro, Gen. Gustavo LEIGH Gusman, Gen.
Cezar MENDOZA Duran
Suffrage: universal (except enlisted military and police) and compulsory at
age 18
Elections: next scheduled presidential election (1976)
Political parties and leaders: Christian Democratic Party (PDC), Patricio Aylwin;
National Party (PN), Sergio Onofre Jarpa; Popular Unity coalition parties
(outlawed) -- Communist Party (PCCh), Luis Corvalan; Socialist Party (PS),
Carlos Altamirano; Radical Party (PR); Christian Left (IC); United Popular
Action Movement (MAPU); Independent Popular Action (API)
Voting strength (1970 presidential election): 36.6% Popular Unity coalition, 35.3%
conservative independent, 28.1% Christian Democrat; (1973 Congressional
election) 44% Popular Unity coalition, 56% Democratic Confederation (PDC and PN)
Communists: 140,000; sympathizers, 140,000
Other political or pressure groups: organized labor; business organizations;
landowners! associations (SNA -- Sociedad Nacional de Agricultura);
extremist, Movement of Revolutionary Left (MIR); rightist, Patria y Libertad
(PyL)
Member of: ECOSOC, IADB, IAEA, IBRD, ICAO, IDB, IHB, IMF, LAFTA and Andean Sub-
Regional Group (created in May 1969 within LAFTA), OAS, Seabeds Committee,
U.N.
63
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: People''s Republic of China
Type: Communist state; real authority lies with communist party''s political bureau;
the National People''s Congress, in theory the highest organ of government, in
reality merely rubber stamps the party''s programs; the State Council is the
actual governing organism
Capital: Peking
Political subdivisions: 21 provinces, 3 centrally governed municipalities, and
5 autonomous regions
Legal system: before 1966, a complex amalgam of custom and statute, largely
criminal; little ostensible development of uniform code of administrative
and civil law; highest judicial organ is Supreme People''s Court although
legal activity centered in parallel network of Public Security organs; laws
and legal procedure clearly subordinated to priorities of party policy; whole
system largely suspended during Cultural Revolution, but gradually being
revived
Branches: prior to 1966 control was exercised by Chinese Communist Party, through
State Council, which supervised more than 50 ministries, commissions, bureaus,
etc., all technically under the standing committee of the National People''s
Congress; this system broke down under "Cultural Revolution" pressures and
is currently in process of being reconsolidated and streamlined
Government leader: Premier of State Council, Chou En-lai; Chairman, People''s
Republic of China (chief of state, a ceremonial post currently vacant; party
elder Tung Pi-wu is "acting" chairman); both subordinate to central committee
of CCP, under Chairman Mao Tse-tung
Suffrage: universal over age 18, though this is academic
Elections: no meaningful elections
Political parties and leaders: Chinese Communist Party (CCP), headed by Mao
Tse-tung; Mao is Chairman of political bureau, real locus of power in China,
and also Chairman of Central Committee; a new central committee was formed at
the 10th Party Congress held in August 1973
65
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Voting strength: 100% Communist for practical purposes; ‘no political nonconformity
permitted
Communists: about 28 million party members in 1973
Other political or pressure groups: army (PLA) is a major force; many soldiers are ''
still performing a wide range of civil political-administrative duties acquired
during the Cultural Revolution, although the policy now is to reduce their
influence in political administrative affairs; veteran civilian officials, in
eclipse since the Cultural Revolution, are gradually being reinstated; mass
organizations, such as the trade unions and the youth league, are being rebuilt
Member of: U.N., Red Cross, other international bodies t
Legal name: Republic of China
Type: republic; one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 4 cities, 1 special municipality (Taipei)
Legal system: based on civil law system; constitution adopted 1947, amended 1960
to permit Chiang Kai-shek to be reelected, and amended 1972 to permit president
to restructure certain government organs; accepts compulsory ICJ jurisdiction,
with reservations
Branches: 5 independent branches (executive, legislative, judicial, plus traditional
Chinese functions of examination and control), dominated by executive branch;
President and Vice President elected by National Assembly
Government leaders: President Chiang Kai-shek; Vice President, Yen
Chia-kan; Premier Chiang Ching-kuo
Suffrage: universal over age 20
Elections: national level -- legislative yuan every 3 years but no general election
held since 1948 election on mainland (partial election for Taiwan province
representatives December 1969 and December 1972); local level -- provincial
assembly, county and municipal executives every 4 years; county and municipal
assemblies every 4 years
Political parties and leaders: Kuomintang, or National Party, led by Director
General Chiang Kai-shek, has no real opposition; 2 insignificant parties
are Democratic Socialist Party, Young China Party
Voting strength (1972 provincial assembly election): 58 seats Kuomintang,
13 seats independents
Other political or pressure groups: none
Member of: expelled from U.N. General Assembly and Security Council on 25 October
1971 and withdrew on same date from other charter-designated subsidiary organs;
attempting to retain membership in international financial institutions
67
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Republic of Colombia
Type: republic; executive branch dominates government structure
Capital: Bogota
Political subdivisions: 22 departments, 4 territorial districts, 4 special
districts, 1 federal district
Legal system: based on Spanish law; religious courts regulate marriage and
divorce; constitution decreed in 1886, amendments codified in 1946; judicial
review of legislative acts in the Supreme Court; accepts compulsory ICJ
jurisdiction, with reservations
Branches: President, bicameral legislature, judiciary
Government leader: President Misael Pastrana
Suffrage: universal over age 21
Elections: every fourth year; last presidential and congressional elections
April 1970; municipal and departmental elections, April 1972
Political parties and leaders: Liberal Party, Alfonso Lopez Michelsen;
Conservative Party, Alvaro Gomez Hurtado; National Popular Alliance (ANAPO) ,
General Gustavo Rojas Pinilla, Maria Eugenia Rojas de Moreno
Voting strength: 1970 presidential election -- Misael Pastrana 1.61 million
votes, General Gustavo Rojas Pinilla 1.54 million votes, Belisario Betancur
Cuartas .46 million votes, Evardisto Sourdis .3 million votes; 1972 municipal
council and departmental assembly elections -- three major parties; combined
Liberal Party, 1,383,708; Combined Conservative Party, 917,699; ANAPO, 559,821;
abstention by approximately 70% of eligible voters
Communists: 3,000-5 ,000
Other political or pressure groups: Communist Party (PCC), Gilberto Vieira White;
PCC/ML, Chinese Line Communist Party, led by Pedro Lupo Leon Arboleda Roldan
Member of: FAO, IADB, IAEA, IBRD, ICAO, IFC, IHB, ILO, IMF, ITU, LAFTA and
Andean Sub-Regional Group (created in May 1969 within LAFTA), OAS, U.N.,
UNESCO, UPU, WHO, WMO
69
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Overseas Territory of the Comoro Islands
Type: overseas territory of France
Capital: Moroni
Political subdivisions: 4 prefectures, 4 district councils
Legal system: French and Muslim law
Branches: High Commissioner appointed by French government; assisted by elected
Chamber of Deputies of 39 members, and an 8-man Council of Ministers,
President elected by Chamber of Deputies
Government leader: Ahmed Abdallah, President of Council of Ministers
» Suffrage: universal adult
Elections: at discretion of Council of Ministers, on advice of President; must
be held before expiration of 5-year electoral mandate
Political parties and leaders: Comoran Democratic Union, Mohammed Dahlani;
Democratic Assembly of Comoros People, Said Mohamed Jaffar; Comoros Socialist
Party; Umma, Prince Said Ibrahim; Mahorais Movement, Marcel Henry
Voting strength: in elections for Chamber of Deputies in 1972, independence
coalition of CDU and DACP won 34 seats, Mahorais Movement won 4
Communists: information not available
Legal name: People''s Republic of the Congo
Type: republic; military regime established September 1968
Capital: Brazzaville
Political subdivisions: 9 regions divided into districts
Legal system: based on French civil law system and customary law; constitution
adopted 1963 and 1969
Branches: President, Council of State; National Assembly; judiciary presumably
still functions according to provisions of 1963 constitution; all policy made
by Congolese Workers Party Central Conmittee and Politburo
Government leader: President, Major Marien Ngouabi
Suffrage: universal over age 18
Elections: last legislative elections June 1973
Political parties and leaders: Congolese Workers Party (PCT) is only legal party;
President, Marien Ngouabi
Communists: unknown number of Communists and sympathizers
Other political or pressure groups: Union of Congolese Socialist Youth (UJSC),
Congolese Trade Union Congress (CSC), Revolutionary Union of Congolese
Union (URFC), General Union of Congolese Pupils and Students (UGEEC)
Member of: ACCT, AFDB, Conference of East and Central African States, EAMA, ECA,
IBRD, FAO, ICAO, ILO, IMF, ITU, OAU, UDEAC, UNESCO, UPU, WHO, WMO
Legal name: Cook Islands
Type: self-governing in “free association" with New Zealand; Cook Islands
government fully responsible for internal affairs and has right at any time
to move to full independence by unilateral action; New Zealand retains
responsibility for external affairs, in consultation with Cook Islands
Capital: Rarotonga
Branches: New Zealand Governor General appoints High Commissioner of Cook Islands,
who represents the Queen and the New Zealand government; High Commissioner
appoints the Premier; Legislative Assembly of 22 members, popularly elected;
House of Arikis (chiefs), 15 members, appointed by High Commissioner, an
advisory body only
Government leader: Premier Albert Henry
Suffrage: universal adult
Elections: every 4 years, latest in 1972
Political parties and leaders: Cook Islands Party, Albert Henry; Democratic
Party, Dr. Thomas Davis
Voting strength (1972): Cook Islands Party, 15 seats; Democratic Party, 7 seats
Legal name: Republic of Costa Rica
Type: unitary republic
Capital: San Jose
Political subdivisions: 7 provinces
Legal system: based on Spanish civil law system; constitution adopted 1949;
judicial review of legislative acts in the Supreme Court; legal education
at University of Costa Rica; has not accepted compulsory ICJ jurisdiction
Branches: President, unicameral legislature, Supreme Court elected by legislature
Government leader: President Jose Figueres
Suffrage: universal and compulsory age 18 and over
Elections: every 4 years; next, February 1974
Political parties and leaders: National Liberation Party (PLN), Daniel Oduber,
Jose Figueres; National Unification (UN), Fernando Trejos Escalante,
Francisco Calderon, Longino Soto Pacheco; National Independent Party (PNI),
Jorge Gonzalez Marten; Democratic Renovation Party (PRD), Rodrigo Carazo;
Christian Democratic Party (PDC), Jorge Monge Zamora; Socialist Action Party
(PASO), Marcial Aguiluz; Popular Vanguard Party (PVP, Communist, illegal),
Manuel Mora
Voting strength (1970 election): National Unification (coalition of PUN, PR, and
PURA), 41.1%; PLN, 55%; PFN, 1.7%; PDC, 0.9%; PASO, 1.3%
Communists: 3,200 members, 10,000 sympathizers
Other political or pressure groups: Costa Rican Confederation of Democratic
Workers (CCTD), General Confederation of Workers (CGT), Chamber
of Coffee Growers, National Association for Economic Development (ANFE)
Member of: CACM, IADB, IAEA, ICAO, OAS, U.N.
Legal name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: 6 provinces
Legal system: based on Spanish and American law, with large elements of
Communist legal theory; Fundamental Law of 1959 replaced constitution
of 1940; legal education at Universities of Havana, Oriente, and Las Villas;
does not accept compulsory ICd jurisdiction
Branches: executive; no legislature; controlled judiciary
Government leader: Premier Fidel Castro Ruz
Political parties and leaders: Cuban Communist Party (PCC), First Secretary
Fidel Castro Ruz, Second Secretary Raul Castro Ruz
Communists: approx. 155,000 party members
Member of: CEMA, ECLA, FAO, GATT, IADB (nonparticipant), IAEA, ICAO, IMB, ILO,
IMCO, International Rice Commission, International Sugar Council, International
Wheat Agreement, ITU, OAS (nonparticipant) , Permanent Court of Arbitration,
Postal Union of the Americas and Spain, Seabeds Committee (observer), U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Republic of Cyprus
Type: republic since March 1961; separate de facto Greek Cypriot, and Turkish
Cypriot governments have evolved since outbreak of communal strife in 1963
Capital: Nicosia
Political subdivisions: 6 administrative districts
Legal system: based on common Taw, with civil law modifications; constitution
came into force upon independence in 1960, but has often been in abeyance
since then; has not accepted compulsory ICJ jurisdiction
Branches: currently a rump government consisting basically of Greek Cypriot parts
of bodies provided for by constitution; headed by President of the Republic
and comprised of Council of Ministers, House of Representati','248ad4ff5fab4fcef7a97e00f0577b214099bbddcf7ecd41b03a6f8313ed2580','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('857dea014336b65465127fdff2b9e59e4462d873d52cd11a681870db2e8a4225',1974,'BR','Brazil','government',12,'ves, and
Supreme Court
Government leaders: President, Archbishop Makarios II] (Greek); Vice President,
Rauf Denktash (Turk)
Suffrage: universal age 21 and over
Elections: held every 5 years; 1965 elections suspended; 1968 elections only for
President and Vice President; 1970 parliamentary elections demonstrate
notable increase in strength of Communist Party (AKEL); 1972 elections
only for President and Vice President
Political parties and leaders: Reform Party of the Working People (AKEL)
(Communist Party), Ezekias Papaioannou; Unified Party tur), Glafkos Clerides;
Progressive Movement (PM) (pro-Makarios), Andreas Azinas; Democratic
National Party (DEK), Takis Evdokas; United Democratic Union of the Center
(EDEK), Vassos Lyssarides; Turkish National Union Party (TNUP), Rauf Denktash
Voting strength: (1968 presidential and vice presidential elections) Greek
Cypriot President Makarios 90%; Turkish Cypriot Vice President Fazil Kucuk
unopposed; (1970 parliamentary elections) 39% of Greek Cypriot vote for
Reform Party of the Working People, 21% of the Greek Cypriot vote for the
Progressive Movement, 9% of the Greek Cypriot vote for the Democratic National
Party as well as 9% for the United Democratic Union of the Center, 4% of the
Greek Cypriot vote for independents, 76% of the Greek Cypriot electorate
voted; 80% of the Turkish Cypriot community voted and overwhelmingly elected
15 of Rauf Denktash''s supporters to the Turk Cypriot House contingent in a
separate election; 1972 elections - Makarios unopposed and Rauf Denktash
unopposed
Communists: 12,000; sympathizers estimated to number 60,000
81
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Other political or pressure groups: United Democratic Youth Organization (EDON)
(Communist-controlled); Pan Cyprian Confederation of Labor (PEO
(Communist-controlled) ; Cyprus Confederation of Labor (SEK) (pro-U.s.);
Cyprus Turkish Federation of Trade Unions (KTBIF)
Member of: Commonwealth, Council of Europe, FAQ, IAEA, IBRD, ICAO, IDA, IFC,
ILO, IMF, ITU, U.N., UNESCO, UPU, WHO
Legal name: State of Dominica
Type: dependent territory with full internal autonomy as a British “Associated
State"
Capital: Roseau
Political subdivisions: 10 parishes
Legal system: based on English common law; three local magistrate courts and
the British Caribbean Court of Appeals
Branches: legislature, 11 member popularly elected House of Assembly; executive,
cabinet headed by Premier .
Government leaders: Premier Edward 0. LeBlanc; U.K. Governor Sir Louis Cools-Lartigue
Suffrage: universal adult suffrage over age 18
Elections: every 5 years; most recent October 1970
Political parties and leaders: Dominica Labor Party (DLP), Edward 0. LeBlanc;
Dominica Freedom Party (DFP), Miss M. Eugenia Charles
Voting strength: House of Assembly seats -- DFP 2 seats, DLP 8 seats, indepen-
dent 1 seat
Communists: negligible
Member of: has been invited to join CARICOM (CARIFTA replacement)
Legal name: Dominican Republic
Type: republic
Capital: Santo Domingo
Political subdivisions: 26 provinces and the National District
Legal system: based on French civil codes; 1966 constitution
Branches: President popularly elected for a 4-year term; bicameral legislature
consisting of Senate (27 seats) and Chamber of Deputies (74 seats) elected
for 4-year terms; members of Supreme Court elected by Senate
Government leader: President Joaquin Balaguer
Suffrage: universal and compulsory, over age 18 or married, except members of the
armed forces and police, who cannot vote
Elections: national, May 1974
Political parties and leaders: Reformist Party (PR), Joaquin Balaguer; Dominican
Revolutionary Party (PRD), Juan Bosch Gavino; Democratic Quisqueyan
Party (PQD), Elias Wessin y Wessin; Revolutionary Social Christian Party
(PRSC), Alfonso Moreno Martinez; Movement for National Conciliation (MNC),
Jaime Manuel Fernandez Gonzalez; Anti-reelection Movement of Democratic
Integration (MIDA) Francisco Augusto Lora; National Civic Union (UCN), Pedro
Guillermo Urraca; Fourteenth of June Revolutionary Movement (MR-104), split
into several factions, illegal; Dominican Communist Party (PCD), central
committee, illegal; Dominican Popular Movement (MPD), Rafael Taveras Rosario,
illegal; Communist Party of the Dominican Republic (PCRD), Luis Montas
Gonzalez, illegal; Popular Socialist Party (PSP), illegal
Voting strength (1970 election): 57% PR, (abstained) PRD, 5% PRSC, 14% PQD, 3%
MCN, 21% MIDA
Communists: an estimated 1,500 to 1,800 members in six different factions;
effectiveness limited by ideological differences and organizational
inadequacies
Member of: GATT, IADB, IAEA, ICAO, THB, OAS, U.N.
Legal name: Republic of Ecuador
Type: republic; under military regime since February 1972
Capital: Quito
Political subdivisions: 19 provinces and 1 territory (Galapagos Islands)
Legal system: based on civil law system; modified 1945 constitution re-instituted
in February 1972, legal education at 4 state and 2 private universities; has
not accepted compulsory ICJ jurisdiction
Branches: President and government council assumed power February 1972; government
decisions announced by decree over the president''s signature; judiciary system
supervised by Supreme Court; six special tribunals established in July 1972
Government leader: President, General Guillermo Rodriguez Lara
Suffrage: universal for literates over age 18
Elections: none scheduled
Political parties and leaders: National Velasquista Front, personalistic, Jose
Maria Velasco Ibarra (in exile); Radical Liberal Party, Ignacio Hidalgo
Villavicencio; Social Christian Party, generally conservative, Camilo Ponce;
Conservative Party, Galo Pico Mantilla; Concentration of Popular Forces, populist,
Assad Bucaram; National Revolutionary Party, leftist, Carlos Julio Arosemena
Voting strength: in June 1968 national elections, Velasquistas, a center-left
coalition, and a rightist coalition each got approximately one-third
Communists: 500 members plus an estimated 2,500 sympathizers; Marxist-Leninist
Communist Party, 250; pro-Castro Revolutionary Socialist Party, 450
Member of: ECOSOC, IADB, IAEA, ICAO, LAFTA and Andean Sub-Regional Group
(formed in May 1969 within LAFTA), OAS, Seabeds Committee (observer), U.N.
Legal name: Arab Republic of Egypt
Type: republic; under presidential rule since June 1956
Capital: Cairo
Political subdivisions: 25 governorates
Legal system: based on English common law, Islamic law, and Napoleonic codes;
interim constitution of 1964; judicial review of limited nature in Supreme
Court, also in Council of State which oversees validity of administrative
decisions; legal education at Cairo University; accepts compulsory [Cd
jurisdiction, with reservations
Branches: executive power vested in President, who appoints cabinet; People''s
Assembly has little actual power (serves mainly for discussion and automa-
tic approval); independent judiciary administered by Minister of Justice
Government leader: President Anwar Sadat
Suffrage: universal over age 18 ,
Elections: elections to People''s Assembly every 5 years (most recent October
1971); presidential elections avery 6 years
Political parties and leaders: political parties banned except for the government-
sponsored sociopolitical grouping, Arab Socialist Union (ASU)
Communists: approximately 500, party members
Member of: AAPSO, Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, IMB, ILO, IMCO,
IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO, WPC
Legal name: Republic of El] Salvador
Type: republic
Capital: San Salvador
Political subdivisions: 14 departments
Legal system: based on Spanish law, with traces of common law; constitution
adopted 1962; judicial review of legislative acts in the Supreme Court;
legal education at University of El Salvador; accepts compulsory ICJ
jurisdiction, with reservations
Branches: traditionally dominant executive, fairly independent unicameral
legislature, Supreme Court
Government leader: President Arturo Armando Molina
Suffrage: universal over age 18
Elections: legislative elections every 2 years; presidential elections every 5
years; presidential elections March 1977, legislative and municipal elections
March 1974
Political parties and leaders: National Conciliation Party (PCN), President
Arturo A. Molina, Dr. Enrique Mayorga Rivas, Rafael Rodriguez
Gonzalez; Christian Democratic Party (PDC), Juan Ramirez Rauda, Dr. Pablo
Mauricio Alvergue, Roberto Lara Velado; Dr. Abraham Rodriguez, Jose Napoleon
Duarte; Revolutionary Party (PR -- formerly Renovating Action Party), not
legally recognized, Shafick Handal, Dr. Fabio Castillo Figueroa, Julio Ernesto
Contreras; Salvadoran Popular Party (PPS), Benjamin Wilfredo Navarrete,
Roberto Quinonez Meza, Dr. Jose Antonio Guzman; Communist Party of El Salvador
(PCES), illegal, Jorge Shafick Handal; National Revolutionary Movement (MNR),
Dr. Guillermo Manuel Ungo; National Democratic Union Party (PUDN), Francisco
Roberto Lima, Julio Ernesto Contreras, Julio Castro Belloso; Independent
Democratic United Front (FUDI), Gen. Jose A. Medrano, Raul Salaverria
Voting strength: February 1972 presidential election -- PCN 43.4%, PDC, PUDN,
and MNR coalition, 42.1%; FUDI, 12.3%; PPS 2.2%; March 1972 legislative
election -- PCN, 39 seats; PDC, MNR, and PUDN coalition, 8 seats; PPS 4 seats;
FUDI, 1 seat
Communists: 100 to 200 active members; sympathizers, 5,000
Other political or pressure groups: the military; the "14" prominent families;
General Confederation of Trade Unions (CGS); Unifying Federation of Salvadoran
97
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Other political or pressure groups (cont''d):
Trade Unions (FUSS), Communist dominated; Federation of Construction and
Transport Workers Unions (FESINCONSTRANS), independent; Catholic Church;
Salvadoran National Association of Educators (ANDES)
Member of: Central American Common Market, IADB, IAEA, OAS, ODECA, Seabeds
Committee, U.N.
Legal name: Republic of Equatorial Guinea
Type: republic, one-party presidential regime since 1968
Capital: Malabo, Province Francisco Macias Nguema
Political aa 2 provinces (Province Francisco Macias Nguema and
Rio Muni
Legal system: based on Spanish civil law system and customary law, new constitution
adopted July 1973; has not accepted compulsory ICJ jurisdiction
Branches: there are legislative and judicial branches but president exercises
virtually unlimited power
Government leader: President for life, Francisco Macias Nguema
Suffrage: universal age 21 and over
Elections: national and provincial elections held September 1968
Political parties and leaders: National Unity Party of Workers (PUNT) is the sole
legal party, led by President Macias
Communists: no significant number of Communists or sympathizers
Member of: Conference of East and Central African States, ECA, IBRD, IMF, OAU, U.N.
Legal name: Empire of Ethiopia
Type: constitutional monarchy, but in effect an absolute monarchy
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred to as governorates-general )
Legal system: complex structure with civil, Islamic, common and customary law
influences; constitution adopted 1955; no specific constitutional provision
for review by courts but all legislation inconsistent with the constitution
is declared null and void; legal education at Haile Selassie I University;
has not accepted compulsory ICJ jurisdiction
Branches: Emperor is all-powerful, with advisory cabinet and Prime Minister;
legislature composed of elected Chamber of Deputies and appointed Senate;
judiciary at higher levels based on Western pattern, at Tower levels on
traditional pattern, without jury system in either
Government leader: Emperor Haile Selassie I
Suffrage: universal over age 21
Elections: lower house of Parliament election in June 1973
Political parties and leaders: only amorphous reform groups especially among
younger, better educated Ethiopians
Communists: none
Other political or pressure groups: some dissident ethnic groups, most important
of which is Eritrean’ Liberation Front, separatist group operating in
northeastern Ethiopia
Member of: ECA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UPU,
WHO, WMO
Legal name: The Faeroe Islands
Type: self-governing province within the Kingdom of Denmark; 2 representatives
in Danish parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, 1 town
Legal system: based on Danish law; Home Rule Act enacted 1948
Branches: legislative authority rests jointly with Crown, acting through appointed
High Commissioner, and provincial parliament (Lagting) in matters of strictly
Faeroese concern; executive power vested in Crown, acting through High
Commissioner, but exercised by provincial cabinet responsible to provincial
parliament
Government leaders: Queen Margrethe II; Prime Minister, Atli Dam; Danish
Governor, Leif Groth
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years; next election 1975
Political parties and leaders: Peoples, Hakun Djurhuus; Republican, Erlendur
Patursson; Home Rule, Samuel Petersen; Progressive, Kjartan Mohr; Social
Democratic, Atli Dam; Union, Kristian Djurhuus
Voting strength (1970 election): Peoples 20.0%, Republican 20.0%, Home Rule
5.6%, Progressive 3.5%, Social Democratic 27.2%, Union 21.7%
Communists: insignificant number
Member of: Nordic Council]
Legal name: Colony of the Falkland Islands
Type: British crown colony
Capital: Stanley
Political subdivisions: local government is confined to capital
Legal system: English common law
Branches: Governor, Executive Council, Legislative Council
Government leader: Governor and Commander in Chief Sir Cosmo Haskard {also
High Commissioner for British Antarctic Colony)
Suffrage: universal
Legal name: Dominion of Fiji
Type: independent state within Commonwealth; Elizabeth II recognized as head
of state
Capital: Suva
Political subdivisions: 14 provinces
Legal system: based on British
Branches: executive -- Prime Minister; legislative -- 52-member House of
Representatives; Alliance Party 33 seats, National Federation Party 19 seats
Government leader: Prime Minister Ratu Sir Kamisese Mara
Suffrage: universal adult
Elections: every 5 years unless House dissolves earlier, last held March-April 1972
Political parties: Alliance, primarily Fijian, headed by Ratu Mara; National
Federation, primarily Indian, headed by S. M. Koya
Communists: few, no figures available
Member of: Commonwealth, U.N.
Legal name: Republic of Finland
Type: republic
Capital: Helsinki
Political subdivisions: 12 provinces; 443 communes, 78 towns
Legal system: civil law system based on Swedish Taw; constitution adopted 1919;
Supreme Court may request legislation interpreting or modifying laws; legal
education at Universities of Helsinki and Turku; accepts compulsory ICd
jurisdiction, with reservations
Branches: legislative authority rests jointly with President and parliament
(Eduskunta); executive power vested in President and exercised through
cabinet responsible to parliament; Supreme Court, 4 superior courts,
193 lower courts
Government leader: President Urho K. Kekkonen; Prime Minister Kalevi Sorsa
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1976); presidential, every
6 years (extra ordinary parliamentary legislation extended President
Kekkonen''s term, which normally expires in 1974, to 1978)
Political parties and leaders: Social Democratic, Rafael Paasio; Center,
Johannes Virolainen; Peoples Democratic League (Communist front), Ele
Alenius; Conservative, Harri Holker; Liberal, Pekka Tarjanne; Swedish Peoples
Party, Kristan Gestrin; Rural, Veikko Vennamo; Finnish People''s Unity Party,
Eino Haikala; Communist, Aarne Saarinen
Voting strength (1972 election): 25.8% Social Democratic, 17.5% Conservative,
17.1% People''s Democratic League, 16.5% Center, 9.2% Rural, 5.3% Swedish
Peoples, 5.1% Liberals, 2.5% Christian Peoples, 1.0% other
Communists: 47,000; an additional 65,000 persons belong to Peoples
Democratic League; a further number of sympathizers, as indicated by
421,000 votes cast for Peoples Democratic League in 1970 elections
Member of: EC (draft free trade agreement) EFTA (associate), FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, Nordic Council, OECD, Seabeds
Committee (observer), U.N., UNESCO, UPU, WHO, WMO
109
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: French Republic
Type: republic, with president having wide powers
Capital: Paris
Political subdivisions: 95 metropolitan departments, 21 regional economic
districts
Legal system: civil law system with indigenous concepts; new constitution
adopted 1958, amended concerning election of President in 1962; judicial
review of administrative but not legislative acts; legal education at over
25 schools of law; accepts ICJ jurisdiction with reservations
Branches: presidentially appointed Prime Minister heads Council] of Ministers,
which is formally responsible to National Assembly; bicameral legislature
-- National Assembly (490 members), Senate (283 members) restricted to a
delaying action; judiciary independent in principle
Government leader: President Georges Pompidou
Suffrage: universal over age 21; not compulsory
Elections: National Assembly -- every 5 years, last election March 1973, direct
universal suffrage, 2 ballots; Senate -- indirect collegiate system for 9
years, renewable by one-third every 3 years; President -- direct, universal
suffrage every 7 years, 2 ballots, last election June 1969
Political parties and leaders: Union of Democrats for the Republic (UDR);
Independent Republicans (IR), Valery Giscard d''Estaing; Communist (PCF),
George Marchais; Progress and Modern Democracy (PDM), Jacques Duhamel;
Left Radical Party, Robert Fabre; Movement for Reform, coalition of Center
Democratic Party, Jean Lecanuet and Radical Socialists, Jean Jacques
Servan-Sahreiber; Socialist Party, Francois Mitterrand; Unified Socialist
Party (PSU)
Voting strength (first ballot, 1973 election): 23.9% UDR, 6.9% IR, 21.3% PCF,
20.4% Federation of Democratic and Socialist Left (grouping of parties of
left), 12.4% Center, 15.1% other
Communists: 250,000-300,000 (est.); Communist voters, 5 million average
Other political or pressure groups: Communist-controlled labor union
(Confederation Generale du Travail) nearly 1,500,000 members (est.),
National Council of French Employers (Conseil National du Patronat
Francais -- CNPF or Patronat)
111
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Member of: Council of Europe, EC, FAO, IAEA, IBRD, ICAO, IHB, ILO, IMCO, IMF, ITU,
NATO (signatory), OECD, Seabeds Committee, SEATO, South Pacific Commission,
U.N., UNESCO, UPU, WEU, WHO, WMO
Legal name: Overseas Department of French Guiana
Type: overseas department of France; represented by one deputy in French National
Assembly and one senator in French Senate
Capital: Cayenne
Political subdivisions: 2 arrondissements, 19 communes each with a locally elected
municipal council
Legal system: French legal system; highest court is Court of Appeal based in
Martinique with jurisdiction over Martinique, Guadeloupe, and French Guiana
Branches: executive: prefect appointed by Paris; legislative: popularly elected
16-member General Council; judicial, under jurisdiction of French judicial
system
Government leader: Prefect Jean Delaunay
Suffrage: universal over age 21
Elections: General Council elections coincide with those for the French National
Assembly, normally every 5 years; last election March 1973; local elections
last held September 1973
Political parties and leaders: Parti Socialiste Guyanais (PSG), Leopold Heder,
Senator; Union du Peuple Guyanaise (UPG), weak, leftist allied with, but
also reported to have been absorbed by, the PSG; Union of Democrats for the
Republic (UDR), Hector Rivierez, delegate to French National Assembly
Communists: no organized Communist party; UPG includes Communist sympathizers
but has little measurable following
Legal name: Territory of French Polynesia
Type: overseas territory of France, administered by French Ministry for
Overseas Territories
Capital: Papeete
Political subdivisions: 5 districts
Legal system: based on French, lower and higher courts
Branches: 30-member Territorial Assembly, popularly elected; 5-member Council of
Government, elected by Assembly; popular election of one deputy to National
Assembly in Paris, also one Senator
Government leader: Pierre Angeli, Governor, appointed by French government
Suffrage: universal adult
Elections: every 5 years
Political parties and leaders: Pupu Here Ai''a, Senator Pouvanna a Oopa, John
Teariki; Te E''a Api, Francis Sanford; Union Tahitienne-Union pour la
Defense de la Republique, Te Autahoera''a
17
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
NIs 55C FRENCH TERRITORY OF THE AFARS AND ISSAS
y) LAND:
9,000 sq. mi.; 89% desert wasteland, 10% permanent pasture,
and less than 1% cultivated
Land boundaries: 321 mi.
WATER:
p Limits of territorial waters (claimed): 12 n. mi.
Coastline: 195 mi. (includes offshore islands)
Legal name: Overseas Territory of Afars and Issas
Type: overseas territory of France; represented by one deputy in French National
Assembly and by one senator in French Senate
Capital: Djibouti
Legal system: based on French civil law system, traditional practices and
Islamic law
Branches: President of Council of Government; 8-member Council of Government
appointed by 32-member Chamber of Deputies (Chamber to be increased to 40
members in November 1973); ultimate political authority exercised by
Paris-appointed President of the Council of Government, sometimes referred
to as Prime Minister
. Government leader: Ali Aref Bourhan
Suffrage: universal
Elections: Chamber of Deputies election held March 1973; election for 8 new
seats held November 1973
Political parties and leaders: Rassemblement Democratique Afar, Ali Aref Bourhan;
Union Democratique Afar; Union Populaire Africaine; Union Democratique
Issa, Oman Farah I1tireh; African People''s League, Hassan Gouled
Communists: possibly a few sympathizers
Legal name: Gabonese Republic
Type: republic; one-party presidential regime since 1964
Capital: Libreville
Political subdivisions: 9 regions, 6 communes, 4,500 villages
Legal system: based on French civil law system and customary law; constitution
adopted 1961; judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; legal education at Centre of Higher and Legal Studies
at Libreville; compulsory ICd jurisdiction not accepted
Branches: power centralized in President, elected by universal suffrage for
7-year term; unicameral 70-member National Assembly has limited powers;
judiciary
Government leader: President Omar Bongo
Suffrage: universal over age 21
Elections: Presidential and parliamentary elections last held February 1973
Political parties and leaders: Gabonese Democratic Party (PDG) led by President
Bongo is only legal party
Communists: no organized party; probably some Communist sympathizers
Member of: ACCT, AFDB, EAMA, Conference of East and Central African States, FAO,
IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM, UDEAC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of The Gambia
Type: republic; independent since February 1965
Capital: Banjul
Political subdivisions: Banjul and 5 divisions
Legal system: based on English common Jaw and customary law; constitution came
into force upon independence in 1965, new republican constitution adopted in
April 1970; accepts compulsory I','a6a733ccb7915aeb73127d5f19c8ce7c44016b05be84234785433e9a878167b8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dc596233cb26d733bc8f629ca4ce2b2419a0023af402c0091b5a333f11e860f',1974,'BR','Brazil','government',13,'CJ jurisdiction, with reservations
Branches: cabinet of 10 members; 41-member House of Representatives, in which
4 seats are reserved for chiefs, 4 are appointed, 32 are filled by election
for 5-year terms, a Speaker is elected by the House, and the Attorney
General is an ex-officio member; independent judiciary
Government leader: Dawda K. Jawara, President
Political parties and leaders: People''s Progressive Party (PPP), Secretary
General Dawda K. Jawara and United Party (UP), John Forster
Suffrage: universal adult
Elections: general elections held March 1972; PPP won 28 seats, UP won 3, and one
independent elected
Communists: insignificant number
Member of: Commonwealth, ECA, OAU, U.N.
Legal name: German Democratic Republic
Type: Communist state
Capital: East Berlin (not officially recognized by U.S., U.K., and France, which
together with the U.S.S.R. have special rights and responsibilities in Berlin)
Political subdivisions: (excluding East Berlin) 14 districts (Bezirke), 218
counties (Kreise), 8,777 communities (Gemeinden)
Legal system: Civil law system modified by Communist legal theory; new constitution
adopted 1968 by approx. 95% of the voters in national "referendum;" court
system parallels administrative divisions; no judicial review of legislative
acts; legal education at Universities of Berlin, Leipzig, Halle and Jena;
has not accepted compulsory ICJ jurisdiction; more stringent penal code
adopted 1968
Branches: legislative -- Volkskammer (elected directly); executive -- Chairman
of Council of State, Chairman of Council of Ministers, Cabinet (elected by
Volkskammer); judiciary -- Supreme Court; entire structure dominated by
Socialist Unity (Communist) Party
Government leaders: Chairman, Council of State, Willi Stoph (Head of State);
Chairman, Council of Ministers, Horst Sindermann (Head of Government)
Suffrage: all citizens age 18 and over
Elections: national and local alternating every 2 years; prepared by an electoral
commission of the National Front; ballot supposed to be secret and voters
permitted to strike names off ballot; more candidates than offices available;
parliamentary elections held 14 November 1971; local elections, 22 March 1970
Political parties and leaders: Socialist Unity (Communist) Party (SED), headed
by First Secretary Erich Honecker, dominates the regime; 4 token parties
(Christian Democratic Union, National Democratic Party, Liberal Democratic
Party, and Democratic Peasants'' Party) and an amalgam of special interest
organizations participate with the SED in National Front
Voting strength: 1971 parliamentary elections: 98.33% voted the regime slate; 1970
local elections: 99.85% voted the regime slate
Communists: 1.9 million party members
Other special interest groups: Free German Youth, Free German Trade Union
Federation, Democratic Women''s Federation of Germany, German Cultural
Federation (all Communist dominated)
Member of: CEMA, IPU, U.N., Warsaw Pact
125
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Republic of Ghana
Type: republic; independent since March 1957; Military regime since January 1972
Capital: Accra
Political subdivisions: 8 administrative regions and separate Greater Accra
Area; regions subdivided into 58 districts and 267 local administrative districts
Legal system: based on English common law and customary law; constitution
suspended January 1972; legal education at University of Ghana (Legon) ;
has not accepted compulsory ICJ jurisdiction
Branches: executive and legislative authority vested in National Redemption
Council (NRC); independent judiciary
Government leaders: chief of state, chairman of NRC Colonel I.K. Acheampong
Suffrage: universal over 21 under previous constitution, now suspended
Elections: no elections since 1969; none scheduled
Political parties and leaders: parties banned by military junta which took
power 13 January 1972
Communists: a small number of Communists and sympathizers
Member of: AFDB, Commonwealth, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU,
OAU, U.N., UNESCO, UPU, WHO, WMO
Legal name: Gilbert and Ellice Islands Colony
Type: British crown colony with large measure of self-government
Capital: Tarawa
Political subdivisions: 4 districts
Branches: 10-member Executive Council advises Governor; 33-member Legislative
Council
Government leader: Governor Sir John Field
Political parties and leaders: Gilbertese National Party, Christian Democratic
Party
Legal name: Colony of Gibraltar
Type: U.K. colony
Capital: none
Legal system: English law; constitutional talks in July 1968; new system
effected in 1969 after electoral enquiry
Branches: parliamentary system comprised of the Gibraltar House of the Assembly
(15 elected members and 3 ex officio members), the Council of Ministers
headed by the Chief Minister, and the Gibraltar Council; the Governor is
appointed by the Crown
Government leaders: Governor and Commander in Chief, Adm. of the Fleet Sir
Vary] Begg; Chief Minister, Maj. Robert Peliza; Deputy Chief Minister,
Peter Isola
Suffrage: all adult Gibraltarians, plus other U.K. subjects resident 6 months
or more
Elections: every 5 years; last held in July 1969
Political parties and leaders: Association for Advancement of Civil Rights
(AACR), Sir Joshua Hassan; Labor, Sir Joshua Hassan; Independents, Peter
Isola; Integrationists (IWBP), Maj. Robert Peliza
Voting strength: In 1969, the AACR won 7 seats in the Assembly, the IWBP won 5,
the Independents won 3; a coalition between the latter two parties was formed
Communists: none known
Other political or pressure groups: the Housewives Association; the Chamber
of Commerce
Legal name: Hellenic Republic
Type: presidential republic; power in hands of ex-military leaders since April
1967 but there is a civilian Prime Minister and a civilian cabinet
Capital: Athens
Political subdivisions: 52 departments (nomoi) constitute basic political units;
as a result of decentralization measures promulgated August 1971, these nomoi
have now been grouped into seven geographical areas which are called Regional
Administrations, each of which is headed by an Undersecretary of Interior
(Regional Administrator); while each nomos ultimately reports to and is
administered by the central government, the attempt of the decentralization
program is for each nomos and Regional Administration to administer its own
programs and to solve its own problems on a local basis to the greatest degree
possible
Legal system: 1968 Constitution abolished November 1973 with new Constitution
promised sometime in the future
Branches: military junta combines legislative executive and judicial functions;
rules by decree
Government leaders: President General Phaidon Gizikis; Prime Minister Adamandios
Androutsopoulos; Military Police Chief Brig. Gen. Dimitrios Ioannidis is
strong man of the regime
Suffrage: universal age 21 and over
Elections: suspended indefinitely
Political parties and leaders: political activities suppressed; party leadership
and organization in disarray
Communists: 12% of electorate in February 1964; hard-core elements imprisoned;
Communist Party (KKE) outlawed since 1947
Member of: EC (associate member), FAQ, FUND, IAEA, IBRD, ICAO, IDA, IFC, IHB,
ILO, IMCO, ITU, NATO, OECD, U.N., UNESCO, UPU, WHO, WMO
135
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Greenland
Type: province of Kingdom of Denmark; 2 representatives in Danish parliament;
separate Minister for Greenland in the Danish cabinet
Capital: Godthaab (administrative center)
Political subdivisions: 3 counties, 19 communes
Legal system: Danish law; transformed from colony to province in 1953
Branches: legislative authority rests jointly with Crown and Danish parliament;
executive power vested in Crown, acting through provincial governor
responsible to Minister for Greenland; local affairs handled by provincial
council (Landsrad) subject to approval of provincial governor; 19 lower courts
Government leader: Queen Margrethe II; Governor N.0. Christensen
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years (next 1975)
Political parties: Inuit (advocating close ties with Denmark); Sukaq (moderate
socialist, advocating more distinct Greenland identity)
Legal name: State of Grenada
Type: dependent territory with full internal autonomy as a British “Associated
State"
Capital: St. Georges
Political subdivisions: 6 parishes
Legal system: based on English common law
Branches: legislative branch consists of 10-member elected House of Representatives
and 9-member Senate appointed by the Governor; executive branch is cabinet
led by Premier
Government leaders: Premier Eric Matthew Gairy; U.K. Governor Dame Hilda Bynoe
Suffrage: universal adult suffrage
Elections: every 5 years; most recent election 28 February 1972
Political parties and leaders: Grenada United Labor Party (GULP), Eric Matthew
Gairy; Grenada National Party (GNP), Herbert A. Blaize
Voting strength (1972 election): GULP 58.7%, GNP 41.3%; Legislative Council
seats, GULP 13, GNP 2
Communists: negligible
Member of: plans to join CARICOM (CARIFTA replacement) after independence
February 7, 1974
Legal name: Overseas Department of Guadeloupe
Type: overseas department of France; represented by 3 deputies in the French
National Assembly and 2 Senators in the Senate
Capital: Basse-Terre
Political subdivisions: 3 arrondissements; 34 communes, each with a locally
elected municipal council
Legal system: French legal system; highest court is a court of appeal based
in Martinique with jurisdiction over Guadeloupe, French Guiana, and Martinique
Branches: executive, Prefect appointed by Paris; legislative, popularly elected
General Council of 36 members; judicial, under jurisdiction of French judicial
system
Government leader: Prefect Pierre Brunon
Suffrage: universal over age 2]
Elections: General Council elections coincide with those for the French National
Assembly, normally every 5 years; last General Council election took place
in March 1973; local election last held September 1973
Political parties and leaders: Union of Guadeloupean Democrats for the Republic
(UDG), Gabriel Lisette; Communist Party of Guadeloupe (PCG) Henri Bangou;
Socialist Party (MSG), leader unknown; Progressive Party of Guadeloupe (PPG),
Henri Rodes; Independent Republicans; Federation of the Left
Voting strength: MSG, 1 seat in French, National Assembly; UDG, 2 seats;
(1973 election)
Communists: 3,000 est.
oe haa or pressure groups: Group of National Organization of Guadeloupe
GONG
Legal name: Commonwealth of Puerto Rico
Type: commonwealth voluntarily associated with U.S.
Capital: San Juan
Political subdivisions: 77 municipalities
Legal system: based on civil codes; constitution came into effect 1952, U.S.
Constitution also applies; local courts and U.S. federal court; legal
education at University of Puerto Rico Law School
Branches: elected Governor and bicameral legislature; 9-judge Supreme Court
appointed by Governor
Government leader: Governor Rafael Hernandez Colon
Elections: every 4 years, last election November 1972; plebescite held July
1967 on question of opting for statehood, continued commonwealth status, or
full independence; 60.4% for commonwealth status, 39.0% for statehood, 0.6%
for independence
Suffrage: universal over age 18
Political parties and leaders: Popular Democratic Party (PPD), Luis Negron Lopez;
Republican Statehood Party (PER); New Progressive Party (PPN), Luis A. Ferre;
Christian Action Party (PAC), CathoJic Church; Independence Party (PI);
People''s Party (formed August 1968) , Roberto Sanchez *
Voting strength (1972 election): 30% PPN, 52.8% PPD; distribution of, house
seats -- PPN 39, PPD 12; distribution of Senate seats -- PPD 20. PPN 7
Communists: pro-Communist Puerto Rican Socialist Party, Juan Mari Bras
Legal name: State of Qatar
Type: traditional monarchy; independence declared in 197]
Capital: Ad Dawhah
Legal system: discretionary system of law controlled by the ruler, although new
civil codes are being implemented; Islamic law is significant in personal
matters; a constitution was promulgated in 1970
Government leader: Amir Khalifa ibn Hamad Al-Thant
Suffrage: no specific provisions for suffrage laid down
Elections: constitution calls for elections for part of State Advisory Council,
semi-legislative body, but none have been held
Political parties and pressure groups: none; a few small clandestine organizations
are active
Branches: Council of Ministers
Member of: Arab League, U.N.
Legal name: Overseas Department of Reunion
Type: overseas department of France; represented in French Parliament by three
Deputies and two Senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a Prefect appointed by the French Minister
of Interior, assisted by a Secretary-General and an elected 36-man General
Council
Government leader: Prefect Paul Cousseran
Suffrage: universal adult
Elections: last municipal elections in 1971; parliamentary election March 1973
Political parties and leaders: Reunion Communist Party (RCP) led by Paul Verges,
only organized political movement on island; other political candidates
affiliated with metropolitan French parties, which do not maintain permanent
organizations on Reunion
Voting strength (parliamentary election 1973): Union of Democrats for the Republic
elected, one senator and two deputies; Centrist Union, one deputy; one Senator
independent
Communists: Communist Party small -- probably only 15-20 hard-line Communists --
but has support among sugarcane cutters and in Le Port district
Legal name: Colony of Southern Rhodesia
Type: self-proclaimed independent state since 1965 (not recognized by U.S.);
provisional settlement with U.K. in November 1971 cancelled by U.K. in
May 1972 in response to Pearce Commission''s conclusion that its terms were
unacceptable to the majority of black Rhodesians
Capital: Salisbury
Political subdivisions: 11 magisterial districts
Legal system: Smith government implemented a republican constitution on 2 March
1970 which institutionalized white rule
Branches: President Dupont is ceremonial head of state; executive council
(cabinet) lead by Prime Minister Smith; National Assembly gives highly
disproportionate representation to white minority -- 50 white constituency
seats and 16 black constituency seats
Government leaders: Prime Minister Ian Smith and President Clifford Dupont
Suffrage: franchise is based on income, property holdings, and education; there
are separate rolls for Africans and non-Africans
Elections: must be held every 5 years
Political parties and leaders: Rhodesian Front, Prime Minister Smith; Centre
Party, Pat Bashford; Rhodesian Party, Allan Savory; African National Council,
Abel Muzorewa
Voting strength (1970 elections): Rhodesian Front won all 50 white constituency
seats in Parliament
Communists: negligible
Other pressure groups and leaders: African nationalist organizations banned
from political activity -- Zimbabwe African People''s Union, Joshua Nkomo;
Zimbabwe African National Union, Ndabaningi Sithole; these leaders detained
by government; exiled leaders in Lusaka, Zambia, are Jasopo Moyo (ZAPU) and
Herbert Chitepo (ZANU); Front for the Liberation of Zimbabwe (FROLIZI),
James Chikerema
Member of: no international bodies
291
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 39 counties and 46 municipalities, including Bucharest
Legal system: mixture of civil law system and Communist legal theory which
increasingly reflects Romanian traditions; constitution adopted 1965; legal
education at University of Bucharest and two other law schools; has not
accepted compulsory ICd jurisdiction
Branches: Council of Ministers; the Grand National Assembly, under which is
Office of Prosecutor General and Supreme Court; Council of State is a
collective head of state
Government leaders: Ion Gheorghe Maurer, President of the Council of Ministers,
head of government; Nicolae Ceausescu, President of Council of State, titular
head of state
Suffrage: universal over age 18, compulsory
Elections: elections in Romania held every 4 years for the local people''s
councils and every 5 years for Grand National Assembly deputies
Political parties and leaders: Communist Party of Romania only functioning party,
Nicolae Ceausescu, General Secretary
Voting strength (1969 election): overall participation reached 99.96%; of those
registered to vote (13,577,143), 99.75% voted for party candidates
Communists: 2,220,000 party members (April 1972)
Member of: CEMA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, Seabeds Committee, U.N.,
UNESCO, UPU, Warsaw Pact, WHO, WMO, GATT
Legal name: Republic of Rwanda
Type: republic, military government since July 1973; no constitution
Capital: Kigali
Political subdivisions: 10 prefectures, subdivided into 141 communes
Legal system: based on German and Belgian civil law systems and customary law;
constitution adopted 1962; judicial review of legislative acts in the
Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: President, military council, and 13-member cabinet
Government leader: General Jwenal Habyarimana, Head of State
Suffrage: universal and compulsory over age 18
Elections: last legislative election September 1969
Political parties and leaders: Party of the Hutu Emancipation Movement
(PARMEHUTU), dominates at all levels
Communists: no communist party; U.S.S.R. and People''s Republic of China have
diplomatic missions in Rwanda
Member of AFDB, EAMA, IBRD, ICAO, ILO, IMF, ITU, OCAM, OAU, U.N., UNESCO, WHO,
WMO
Legal name: State of St. Lucia
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Castries
Political subdivisions: 16 parishes
Legal system: based on English common law; constitution of 1960; highest judicial
body is Court of Appeal of Leeward and Windward Islands
Branches: legislative, 10-member popularly elected House of Assembly; executive,
cabinet headed by prime minister
Government leaders: Premier John Compton; U.K. Governor Ira Simmons (acting)
Suffrage: universal adult suffrage
Elections: every 5 years; most recent April 1969
Political parties and leaders: United Worker''s Party (UWP), John Compton; St.
Lucia Labor Party (SLP), Kenneth Foster; Saint Lucia Labour Action movement
(SLAM), George Odlum, St. Lucia Labor Party United Front (LPUF) led by
George Charles
Voting strength (1969 election): UWP won 6 of the 10 elected seats in House of
Assembly; SLP won 3 seats; LPUF won 1 seat
Communists: negligible
Member of: has been invited to join CARICOM (CARIFTA replacement)
Legal name: Oriental Republic of Uruguay
Type: republic, government under strong military influence
Capital: Montevideo
Political subdivisions: 19 departments with limited autonomy
Legal system: based on Spanish civil law system; new constitution implemented
1967;. judicial review of legislative acts in Supreme Court, legal education
at University of the Republic at Montevideo; accepts compulsory ICJ
jurisdiction
Branches: executive, headed by President; since 1973 the military has had
considerable influence in policymaking; bicameral legislature (closed
indefinitely by presidential decree in June 1973); national judiciary headed
by Supreme Court
Government leader: President Juan Maria Bordaberry
Suffrage: universal over age 18
Elections: every 5 years; next in 1976
Political parties and leaders: National (Blanco) Party, President of Party
Directorate Homero Murdoch, main factions include Martin Echegoyen''s "Alianza"
faction, List 400 (Washington Beltran), Rocha Movement (Carlos Julio Pereyra
Orthodox Herreristas (Alberto Heber Usher), and Por La Patria (Wilson Ferreira
Aldunate, in self-imposed exile in Argentina); Colorado Party, main factions
include Colorado and Batllista Union Cian Maria Bordaberry), List 15 (Jorge
Batlle), List 315 (Amilcar Vasconcellos); Broad Front (Frente Amplio), leftwing
coalition of Leftist Liberation Front (FIDEL), Communist Front and dissident
factions from both the Blanco and Colorado parties, and including FIDEL, the
Christian Democrats, and other splinter groups
Voting strength (1971 elections): 40.8% Colorado, 40.1% Blanco, 18.6% Frente Amplio,
0.5% Radical Christian Union
Communists: 35 ,000-40,000 including Communist youth group (6,000-8 ,000)
Other political or pressure groups: Communist Party (PCU), Rodney Arismendi;
Christian Democratic Party (PDC); Socialist Party of Uruguay (PSU); Revolu-
tionary Movement of Uruguay (MRO) pro-Cuban Communist Party; National
Liberation Movement of Uruguay (MRO) pro-Cuban Communist Party; National
Liberation Movement (MLN-Tupamaros ) Marxist Revolutionary terrorist group
Member of: IADB, IAEA, IBRD, ICAO, ILO, IMF, LAFTA, OAS, U.N.
367
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes St. Peter''s, the Vatican Palace
and Museum and neighboring buildings covering more than 13 acres; 13
buildings in Rome, although outside the boundaries, enjoy extraterritorial
rights
Legal system: Canon law; constitutional laws of 1929 serve some of the functions
of a constitution
Branches: the Pope possesses full executive, legislative, and judicial powers;
he delegates these powers to the governor of Vatican City, who is subject
to pontifical appointment and recall; high Vatican offices include the
Secretariat of State, the College of Cardinals (chief papal advisers), the
Roman Curia (which carries on the central administration of the Roman
Catholic Church) the Presidence of the Prefecture for the Economy, and
the synod of bishops (created in 1965)
Government leader: Supreme Pontiff, Paul VI, (Giovanni Battista Montini, born
26 September 1897, elected Pope 21 June 1963)
Suffrage: limited to cardinals less than 80 in age
Elections: Supreme Pontiff elected for life by College of Cardinals
Communists: none known
Other political or pressure groups: none (exclusive of influence exercised
by other church officers in universal Roman Catholic Church)
Member: IAEA
Legal name: Republic of Venezuela
Type: republic
Capital: Caracas
Political subdivisions: 20 states, 1 federal district, 2 federal territories
Legal system: based on Spanish civil law system with influence of U.S. law;
constitution promulgated 1961; judicial review of legislative acts in
Cassation Court only; dual court system, state and federal; legal education
at Central University of Venezuela; has not accepted compulsory ICJ
jurisdiction
Branches: executive (President), bicameral legislature, judiciary
Government leader: President Carlos Andres Perez
Suffrage: universal and compulsory over age 18
Elections: every 5 years; last held 9 December 1973
Political parties and leaders: Accion Democratica (AD), Carlos Andres Perez, and
Gonzalo Barrios; Social Christian Party (COPEI), Rafael Caldera, and Lorenzo
Fernandez; People''s Electoral Movement (MEP), Jesus Angel Paz Galarraga;
Cruzada Civica Nacionalista (CCN), Marcos Perez Jimenez, leader; Union
Republicana Democratica (URD), Jovito Villalba; Partido Comunista de
Venezuela (PCV), Secretary-General Jesus Faria; Fuerza Democratica Popular
(FDP), Jorge Dager; Frente Nacional Democratico (FND), Pedro Segnini La Cruz;
Movement to Socialism (MAS), Teodoro Petkoff, and Pompey Marquez
Voting strength (1973 election): 49% AD, 37% COPEI, 5% New Force (MEP & PCV),
4% MAS, 3% URD, 2% others
Communists: minuscule in numbers and effectiveness
Other political or pressure groups: APEL (a conservative business group); PRO
VENEZUELA (leftist, nation','c04b61a3e8e26e60618f4fa9d17d25a1cc70c9ba5c21666d8dbf5f1b02bb83d8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cda4f6d986d3b30e56d141874c32eed55bbe617b42071f7f9393858350af61e',1974,'BR','Brazil','government',14,'alist economic group); DESARROLLISTAS (group of
wealthy, independent businessmen led by former finance minister Pedro Tinoco
and historian Guillermo Moron)
Member of: Andean Pact, CARIFTA, FAO, IADB, IAEA, IBRD, ICAO, IDB, IFC, ILO, ITU,
OAS, OPEC, Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO
371
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Democratic Republic of Viet-Nam
Type: Communist state
Capital: Hanoi
Political subdivisions: 2 autonomous regions (of 3 and 5 provinces, respectively),
17 other provinces, 2 centrally governed municipalities, ] special zone
Legal system: based on Communist legal theory and French civil law system;
constitution enacted 1960
Branches: constitution provides for a National Assembly and highly centralized
executive nominally subordinate to it
Party and government leaders: Le Duan, First Secretary; Ton Duc Thang, President
of DRV; Pham Van Dong, Premier; Truong Chinh, Chairman, Standing Committee
of National Assembly; Vo Nguyen Giap, Minister of National Defense
Suffrage: over age 18
Elections: pro forma elections held for national and local assemblies
Political parties: ruled by Lao Dong Party with no organized opposition;
membership approximately 900,000 (about 4% of population)
Member of: no international bodies
Legal name: Republic of Viet-Nam
Type: republic
Capital: Saigon
Political subdivisions: 4 regions (corresponding to 4 military regions), 1 special
region (corresponding to Capital Special Zone), divided into 44 provinces and
11 autonomous municipalities
Legal system: based on French civil law system; Jegal education at Universities
of Saigon and Hue
Branches: constitution provides for modified presidential system with executive,
legislative, and judicial branches
Government leaders: President Nguyen Van Thieu; Vice President Tran Van Huong;
Prime Minister Tran Thien Khiem
Elections: next presidential election scheduled for 1975
Suffrage: all citizens 18 and older are eligible to register to vote
Political parties and leaders: under a December 1972 law, President Thieu''s
Democracy Party is the only fully qualified legal party; two new independent
coalitions, the Catholic based Freedom Party and the Social Democratic
Alliance will have provisional status until early 1974
Communists: The People''s Revolutionary Party operates through and within the
National Front for the Liberation of South Vietnam (NLF) and the Alliance of
National, Democratic, and Peace Forces (ANDPF), and the Provisional Revolu-
tionary Government (PRG) designed to rival the legal government
Other political or pressures groups: religious groups often have more influence
than parties; the An Quang Buddhists are the most important opposition group;
Catholic groups range from progovernment to opposition; the independent Hoa
Hao and Cao Dai politico-religious sects exert strong influence in local areas
Member of: Colombo Plan, FAO, IAEA, ICAQ, ILO, IMCO, ITU, U.N. (certain specialized
U.N. agencies and maintains observer team), UNESCO, UPU, WHO, WMO
375
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Territory of the Wallis and Futuna Islands
Type: overseas territory of France
Capital: Matu Utu
Political subdivisions: 3 districts
Branches: territorial assembly of 20 members; popular election of one deputy to
National Assembly in Paris, and one Senator
Government leader: Superior Administrator Jacques de Agostini
Suffrage: universal adult
Elections: every 5 years
Legal name: The Independent State of Western Samoa
Type: constitutional monarchy under native chief; special treaty relationship
with New Zealand
Capital: Apia
Legal system: based on English common law and local customs; constitution came
into effect upon independence in 1962; judicial review of legislative acts
with respect to fundamental rights of the citizen; has not accepted
compulsory ICJ jurisdiction
Branches: Head of State and Executive Council; Legislative Assembly; Supreme
Court, Court of Appeal, Land and Titles Court, village courts
Government leaders: Head of State, Malietoa Tanumafili II; Prime Minister,
Fiame Mata''afa
Suffrage: 45 Samoan members of Legislative Assembly are elected by holders of
matai (heads of family) titles (about 5,000); 2 European members are elected
by universal adult suffrage
Elections: held triennially, last in February 1973
Political parties and leaders: no clearly defined political party structure
Communists: unknown
Member of: ADB, Commonwealth, ECAFE, WHO
Legal name: People''s Democratic Republic of Yemen
Type: republic; power centered in ruling National Front Party
Capital: Aden; Madinat ash Sha''b, administrative capital
Political subdivisions: 6 provinces
Legal system: based on Islamic law (for personal matters) and English common
law (for commercial matters); highest judicial organ, Federal High Court,
interprets constitution and determines disputes between states
Branches: Presidential Council; cabinet; Supreme People''s Council
Government leaders: Chairman of Presidential Council, Salim Rubay Ali; Prime
Minister Ali Nasir Muhammed al-Hasani; NF Secretary General Abd Al-Fattah
Ismail
Suffrage: granted by constitution to all citizens 18 and over
Elections: elections for legislative body, Supreme People''s Council, called for
in constitution; none have been held
Political parties and leaders: National Front (NF), only legal party
Communists: few known
Member of: U.N.
Legal name: Yemen Arab Republic
Type: republic
Capital: San‘a‘
Political subdivisions: 8 provinces
Legal system: based on Turkish law, Islamic law, and local customary law; first
constitution promulgated December 1970; has not accepted compulsory 1cJ
jurisdiction
Branches: President, Prime Minister, Republican Council, Consultative Council
Government leaders: President Abd al-Rahman Tryani; Prime Minister Abdullah
al-Hajri
Communists: few known
Political parties or pressure groups: some pro-lraqi Baathists, other smal]
~ clandestine groups supported by Yemen (Aden
Member of: Arab League. FAO, ICAO, ITU, U.N., UNESCO, UPU, WHO','d4f48ef741d7a899c29219ad9d2431c530fca78de0ce3b05bb4895a966a06e70','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fc57700b4bddea995d48f01d93aa7251984bf729fa8bab3c946198c2598c6a0',1974,'DZ','Algeria','government',20,'Legal name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: 9 provinces
Legal system: civil Jaw system influenced by English constitutional theory;
constitution adopted 1831, since amended; judicial review of legislative
acts; legal education at 4 law schools; accepts compulsory ICJ jurisdiction,
with reservations
Branches: executive branch consists of King and cabinet; cabinet responsible to
bicameral parliament; independent judiciary; coalition governments are usual
Government leader: Head of State, King Baudouin; Prime Minister Edmond Leburton
Suffrage: universal over age 21
Elections: held 7 November 1971 (held at least once every 4 years)
Political parties and leaders: Social Christian, Charles-Ferdinand Nothomb and
Wilfred Martens, co-presidents ; Socialist, Andre Cools and Joris Van
Eynde, co-presidents; Liberty and Progress, Senator P, Descamps, party
president; Francophone Democratic Front-Walloon Rally (Wal Toon nationalist),
Jean Duvieusart, party president; Volksunie (Flemish Nationalist), Wim
Jorrisen, party president; Communist, Marc Drumeaux, president of political
bureau
Voting strength (1971 election): 67 seats Social Christian, 61 seats Socialist,
34 seats Liberty and Progress, 21 seats Volksunie, 21 seats Francophone
Democratic Front-Walloon Rally, 5 seats Communist
Communists: 12,000 members; pro-Peking splinter groups, 400
Other political or pressure groups: Christian and Socialist Trade Unions; the
Federation of Belgium Industries; numerous other associations representing
bankers, manufacturers, middle-class artisans, and the legal and medical
professions; two major organizations represent the cultural interests of
Flanders and Wallonia
Member of: Benelux, BLEU (Belgium-Luxembourg Economoc Union), Council of Europe,
ECE, ECOSOC, EC, EMA, FAO, IAEA, ICAO, IMF, NATO, OECD, Seabeds Committee,
U.N., UNESCO, WEU, WHO ;
29
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Province of Guinea
Type: overseas province of Portugal
Capital: Bissau
Political subdivisions: 9 municipalities, 3 circumscriptions (predominantly
indigenous population)
Legal system: based on Portuguese law
Branches: Governor General appointed by Ministry of Overseas has wide local
authority; he is assisted by an appointed Secretary-General and a 9-man
consultative Council; a 17-member Legislative Assembly, 12 of whose members
are elected by various groups, represents economic and tribal interests of
province; Minister of Overseas can nullify any provincial legislation or
Governor''s decision; judiciary based on Portuguese system
Government leader: Governor General and military commander is Gen. Jose Manuel
Bettencourt de Rodrigues
Suffrage: limited to those satisfying fairly rigid economic and cultural
requirements
Elections: Legislative Assembly elections held every 4 years in March, last
held in 1973
Political parties and leaders: National Popular Action (ANP) of Portugal only
legal party sends one representative to National Assembly in Lisbon; opposition
parties (illegal) include Partido Africano da Independencia da Guinee e Cabo
Verde (PAIGC), led by Aristide Pereira, a Conmunist-supported nationalist party
which is chief political force conducting current rebellion against Portuguese
rule and which operates mainly from Republic of Guinea and the Republic of
Senegal; Front de Lutte pour 1''Independence Nationale de la Guinee (FLING),
a largely dormant, loose coalition of Senegal-based nationalist elements
opposed both to the Portuguese and the PAIGC, leadership fragmented;
other nationalist factions
Communists: none known','60b98e8c3f6e034a6ee7c7eca3ea9876a3a36ede821c141f127959102b495304','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b41afa1f1f2a7197eb9f1477c96c531985bb465b84464a34a1d2e0ae985ebc26',1974,'PE','Peru','government',23,'Legal name: Belize
Type: former British crown colony; obtained full internal self-government in
January 1964
Capital: Belize City; seat of government in Belmopan
Legal system: English law; constitution came into force in 1964, although
country remains a British colony
Branches: 18-member elected National Assembly and 8-member Senate {either house
may choose its speaker or president, respectively, from outside its
elected membership); cabinet; judiciary
Government leader: Premier George Price
Suffrage: universal adult (probably 21)
Elections: within 5 years of last general election held 5 December 1969
Political parties and leaders: People''s United Party (PUP), George Price;
National Independence Party (NIP), Philip Goldson; People''s Development
Movement (PDM) Dean Lindo; United Black Association for Development (UBAD) ,
Evan Hyde
Voting strength (1969 election): 57.6% PUP, 39.8% NIP, 2.6% void ballots
Communists: none identified
Other political or pressure groups: Christian Workers! Union (CWU) which is
connected with PUP
Legal name: Colony of Bermuda
Type: British crown colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English law
Branches: elected House of Assembly; appointed Legislative Council; Executive
Council (cabinet)
Government leaders: Governor Sir Edwin Leather; Government Leader (equivalent
to Prime Minister) Sir Edward Richards
Suffrage: universal over age 21
Elections: at least once every 5 years; last general election, June 1972
Political parties and leaders: United Bermuda Party (UBP), Sir Henry Tucker;
Progressive Labor Party (PLP), Walter N.H. Robinson
Voting strength (1972 elections): UBP 61.2%, PLP 38.8%; House of Assembly seats
-- UBP 30, PLP 10
Communists: negligible
Other political or pressure groups: Bermuda Industrial Union (BIU)
Legal name: Kingdom of Bhutan
Type: monarchy; special treaty relationship with India
Capital: Thimphu
Political subdivisions: 4 regions (east, central, west, south), further
divided into 15-18 subdivisions
Legal system: based on Indian law and English common law; in 1964 the
King assumed full power -- no constitution existed beforehand; a supreme
court hears appeals from district administrators; has not accepted
compulsory ICJ jurisdiction
Branches: appointed minister and indirectly elected assembly consisting of
village elders, monastic representatives, and all district and senior
government administrators (electoral reform provides for direct elections
in near future)
Government leader: King Jigme Singhi Wangchuk
Suffrage: each family has one vote
Elections: popular elections on village level held every 3 years
Political parties: all parties illegal
Communists: no overt Communist presence
Other political or pressure groups: Buddhist clergy
Member of: Colombo Plan, UPU, U.N.
Legal name: Republic of Bolivia
Type: republic; de facto military-civilian coalition government
Capital: La Paz (seat of government); Sucre (judicial capital)
Political subdivisions: 9 departments with limited autonomy
Legal system: based on Spanish law and Code Napoleon; constitution adopted 1967;
constitution in force except where contrary to dispositions dictated by
governments since 1969; legal education at University of San
Andres and several others; has not accepted compulsory ICJ jurisdiction
Branches: executive; congress of two chambers (Senate and Chamber of Deputies),
congress disbanded after 26 September 1969 ouster of President Siles;
judiciary
Government leaders: President Hugo Banzer Suarez
Suffrage: universal and compulsory at age 18 if married, 21 if single
Elections: scheduled for 2 June 1974
Political parties and leaders: Nationalist Revolutionary Movement (MNR)
Victor Paz Estenssoro; Bolivian Socialist Falange (FSB) Mario
Gutierrez; other political parties, although numerous, exert little
influence; activist groups include the Nationalist Leftist Revolutionary
Party (PRIN) Juan Lechin Oquendo (in exile), Socialist Party (PS) Marcelo
Quiroga and Alberto Baily (in exile), and Leftist Revolutionary Movement (MIR)
Pablo Ramos Sanchez (in exile); more moderate parties include the Authentic
Revolutionary Party (PRA) Walter Guevara Arze, Popular Christian Movement
(MPC) Hugo Bozo, Leftist Revolutionary Party (PIR) Ricardo Anaya, Social
Democratic Party (PSD) Hugo Sandoval, and Christian Democratic Party (PDC)
Benjamin Miguel
Voting strength (1966 elections): Frente de la Revolucion Boliviana (a coalition
composed of the MPC, PIR, PRA, PSD, and two interest groups, the campesinos
and Chaco War Veterans) 61%, FSB 12%, MNR 10%, other 17%
Communists: three parties; PCB/Soviet led by Jorge Kolle Cueto, about 1,500
members; PCB/Chinese led by Oscar Zamora, 500 members (est.); POR (Trotskyist),
about 200 members divided between three factions led by Hugo Gonzalez Moscoso,
Guillermo Lora Escobar, and Amadeo Arze
Member of: IAEA, IADB, ICAO, International Tin Council, LAFTA and Andean
Sub-Regional Group (created in May 1969 within LAFTA), OAS, U.N.
37
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Republic of Botswana
Type: parliamentary republic since; independent member of commonwealth since 1966
Capital: Gaborone
Political subdivisions: 12 administrative districts
Legal system: based on Roman-Dutch law and local customary law; constitution
came into effect 1966; judicial review limited to matters of interpretation;
legal education at University of Botswana, Lesotho and Swaziland (2 1/2 years)
and University of Edinburgh (2 years); has not accepted compulsory ICJ
jurisdiction
Branches: executive -- President appoints and is the chief minister in the
cabinet which is responsible to Legislative Assembly; legislative --
Legislative Assembly with 31 popularly elected members and 4 members elected
by the 31 representatives, House of Chiefs with deliberative powers only;
judicial -- local courts administer customary law, High Court and
subordinate courts have criminal jurisdiction over all residents, Court of
Appeal has appellate jurisdiction
Government leader: President Seretse Khama
Suffrage: universal, age 21 and over
Elections: general elections held 18 October 1969
Political parties and leaders: Botswana Democratic Party (BDP), Seretse Khama;
Bechuanaland People''s Party (BPP), Philip Matante; Botswana Independence
Party (BIP), Motsamai Mpho; Botswana National Front (BNF), Kenneth Koma
Voting strength: (October 1969 election) 68% BDP (24 seats); 13.5% BPP (3 seats);
12% BNF (3 seats); 6% BIP (1 seat)
Communists: no Known Communist organization; Koma of BNF has long history of
Communist contacts
Member of: AFDB, Commonwealth, FAO, OAU, U.N., WMO
Legal name: Federative Republic of Brazil
Type: federal republic; military-backed presidential regime since April 1964
Capital: Brasilia
Political subdivisions: 22 states, 4 territories, federal district (Brasilia)
Legal system: based on Latin codes; dual system of courts, state and federal;
constitution adopted 1967 and extensively amended in 1969; has not accepted
compulsory ICd jurisdiction
Branches: strong executive with very broad powers; bicameral legislature
(powers of the two bodies have been sharply reduced); 11-man Supreme Court
Government leader: President Emilio Garrastazu Medici
Suffrage: compulsory over age 18, except illiterates and those stripped of their
political rights; approximately 30 million registered voters in October 1970
Elections: President Medici''s successor will be chosen by a 505-member electoral
college, composed of the members of Congress and delegates selected from the
state legislatures, on 15 January 1974 and will take office in March; will
really be only ratification of a choice made by Medici and tdp military chiefs
Voting strength: (November 1970 congressional elections): 46% ARENA, 25% MDB,
28.5% blank and void
Political parties and leaders: National Renewal Alliance (ARENA), pro-government
Petronio Portella, president; Brazilian Democratic Movement (MDB), opposition,
Ulisses Guimaraes, president
Communists: less than 13,000; 100,000 sympathizers (est. )
Other political or pressure groups: excepting the military, the Catholic Church
is the only active nationwide pressure group, however, divisions within the
Church often prevent it from speaking with one voice; labor and student
groups have almost no influence on the government
Member of: FAO, GATT, IADB, IAEA, IBRD, ICAO, IHB, ILO, IMCO, IMF, ITU, LAFTA,
OAS, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: British Solomon Islands Protectorate
Type: British protectorate administered as crown colony
Capital: Honiara
Political subdivisions: 4 administrative districts
Legal system: a High Court plus Magistrates Courts, also a system of native
courts throughout the islands
Branches: executive authority in High Commissioner; a legislative Governing
Council of 24 elected members
Government leader: High Commissioner M. C. Luddington
Suffrage: Universal age 21 and over
Elections: every 4 years, latest May-June 1973
Political parties and leaders: United Solomon Islands Party, Benedict Kinika,
Chairman
Legal name: State of Brunei
Type: British protectorate; constitutional sultanate
Capital: Bandar Seri Begawan
Political subdivisions: 4 administrative districts
Legal ees based on Islamic law; constitution promulgated by the Sultan in
195
Branches: chief of state is Sultan (advised by appointed Privy Council) who
appoints Executive Council and Legislative Council
Government leader: Sultan Hassanal Bolkiah
Suffrage: universal age 21 and over; 3-tiered system of indirect elections;
popular vote cast for lowest level (district councilors)
Elections: last elections -- March 1965; further elections postponed indefinitely
Political parties and leaders: antigovernment People''s Independence Front
(Baker), Pengiran Dato Ali, chairman
Communists: information not available
Legal name: People''s Republic of Bulgaria
Type: Communist state
Capital: Sofiya
Political subdivisions: 28 okrugs (districts), including capital city of Sofia
Legal system: based on civil law system, with Soviet law influence; new
constitution adopted in 1971; judicial review of legislative acts in the
State Council; legal education at University of Sofiya; has not accepted
compulsory ICJ jurisdiction
Branches: legislative (National Assembly), Council of Ministers, judiciary
Government leaders: Todor Zhivkov, Chairman, State Council (chief of state);
Stanko Todorov, Chairman, Council of Ministers (premier)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every 4 years for National Assembly; last elections
held on 27 June 1971; 99.8% of the electorate voted
Political parties and leaders: Bulgarian Communist Party, Todor Zhivkov, First
Secretary; Bulgarian National Agrarian Union, a puppet party, Georgi Traykov,
secretary
Communists: 699,000 party members (April 1971)
Mass organizations and front groups: Fatherland Front, Dimitrov Communist Youth
League, Central Council of Trade Unions, National Committee for Defense of
Peace, Union of Fighters Against Fascism and Capitalism, Committee of
Bulgarian Women, All-National Committee for Bulgarian-Soviet Friendship
Member of: CEMA, GATT, IAEA, ICAO, ILO, IMCO, ITU, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO, Warsaw Pact, International Organization of Journalists,
International Medical Association, International Radio and Television
Organization
Legal name: Union of Burma
Type: military dictatorship since suspension of constitution in 1962
Capital: Rangoon
Political subdivisions: Burma proper, 4 other constituent states and 1 special
division for the ethnic minorities; subdivided into divisions, districts,
muncipalities, townships, and villages
Legal system: based on English common law and incorporates Buddhist, Hindu,
and Islamic relgious law; constitution of 1947 superseded by acts of the
new Revolutionary Government, which seized power in 1962; legal education
at Universities of Rangoon and Mandalay; has not accepted compulsory ICJ
jurisdiction
Branches: Revolutionary Council rules through a Council of Ministers
Government leader: Chairman of Revolutionary Council and Prime Minister, Gen.
U. Ne Win
Suffrage: universal over age 18 under suspended constitution
Elections: none held under present regime
Political parties and leaders: government-sponsored Burmese Socialist Program
Party only legal party
Communists: 5,000
Other political or pressure groups: United National Liberation Front; Kachin
Independence Army; Shan State Army; Karen Nationalist Union
Member of: Colombo Plan, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF,
ITU, Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Burundi
Type: republic; military government since November 1966; no constitution
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into 18 arrondissements and 78
communes
Legal system: based on German and French civil codes and customary law; has not
accepted compulsory ICd jurisdiction
Branches: presidential cabinet with Council of Ministers; no legislature
Government leader: President Michel Micombero
Elections: last legislative election May 1965
Political parties and leaders: National Party of Unity and Progress (UPRONA),
a predominantly Tutsi party, was declared sole legitimate party in 1966
Communists: no Communist party; resumed diplomatic relations with The People''s
Republic of China in October 1971 following a six-year suspension; U.S.S.R.
and North Korea have diplomatic missions in Burundi
Member of: AFDB, EAMA, ECA, IBRD, ICAO, ILO, IMO, OAU, U.N., UNESCO, WHO, WMO
Legal name: Khmer Republic
Type: new constitution provides for strong presidential system; 4-man "High
Political Council" to rule by decree indefinitely
Capital: Phnom Penh
Political subdivisions: 24 provinces with centrally appointed governors,
3 independent municipalities
Legal system: based on French civil law system; constitution adopted 1947 and
amended 1960; no judicial review of legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
Branches: 126-man national assembly and 40-man senate, popularly elected, in
"suspension"
Government leader: President Lon Nol
Suffrage: universal over age 18, with major exception of Buddhist clergy
Elections: president elected for 5 year term in June 1972; senate for 6 year term
and assembly for 4 year term in September 1972
Political parties and leaders: Social Republican Party, Hang Thun Hak; Republican
Party, Sirik Matak; Democratic Party, Chau Sau
Communists: party strength unknown; Communist combat troops estimated between
45 000-55 ,000
Other political or pressure groups: none
Member of: ADB, Colombo Plan, IAEA, IBRD, ICAO, IMF, WHO; U.N.
Legal name: United Republic of Cameroon
Type: unitary republic; one-party presidential regime
Capital: Yaounde
Political subdivisions: 7 provinces divided into 39 departments
Legal system: based on French civil law system, with common law influence; new
unitary constitution adopted 1972; judicial review in Supreme Court, when a
question of constitutionality is referred to it by the President of the
Republic; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative, and judicial
Government leader: President Ahmadou Ahidjo
Suffrage: universal over age 2]
Elections: presidential elections held 28 March 1970; parliamentary elections
last held 18 May 1973
Political parties and leaders: single party, Cameroonian National Union (UNC),
President Ahmadou Ahidjo
Communists: no Communist Party or significant number of sympathizers
Other political or pressure groups: Cameroon People’s Union (UPC), an illegal
terrorist group now reduced to scattered acts of banditry with its factional
leaders in exile
Member of: ACCT, AFBD, EAMA, ECA, FAO, GATT, IAEA, IBRD, ICAO, ILO, IMCO, IMF,
ITU, Lake Chad Basin Commission, Niger River Commission, OAU, Seabeds
Committee, UDEAC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Central African Republic
Type: republic; constitution abrogated following military coup in January 1966
Capital: Bangui
Political subdivisions: 14 prefectures, 47 subprefectures
Legal system: based on French, Islamic, and tribal law; in 1966 the Chief of
State assumed all power and abrogated the existing constitution; has not
accepted compulsory ICJ jurisdiction
Branches: Gen. Bokassa heads government and rules by decree; assisted by
cabinet called Council of Ministers; judiciary, including Supreme Court,
court of appeals, criminal court, and numerous lower courts
Government leader: President for life Jean-Bedel Bokassa
Suffrage: universal over age 2]
Elections: none have been held under Bokassa regime
Political parties and leaders: Black African Social Evolution Movement (MESAN) ,
ruling party under former regime, still in existence but plays little role,
led by President Jean-Bedel Bokassa
Communists: no Communist Party, or significant number of sympathizers
Member of: ACCT, AFDB, Conference of East and Central African States, EAMA, ECA,
FAO, GATT, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM, UDEAC, U.N., UNESCO, UPU,
WHO, WMO
Legal name: Republic of Chad
Type: republic; one-party presidential regime since 1962
Capital: Ndjamena
Political subdivisions: 14 prefectures
Legal system: based on French civil law system and Chadian customary law;
constitution adopted 1962; judicial review of legislative acts in theory a
power of the Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: President, who has sweeping powers, elected by universal adult suffrage
to 7-year term; separate popularly elected unicameral National Assembly
of 105 deputies with 5-year term; independent judiciary
Government leader: President Ngarta Tombalbaye
Suffrage: universal over age 20
Elections: presidential elections held June 1969, parliamentary elections last
held December 1969
Political parties and leaders: National Movement for Cultural and Social
Revolution (MNRCS), only legal party, led by Ngarta Tombalbaye
Communists: no front organizations or underground party; probably a few
Communists and some sympathizers .
Other political or pressure groups: lightly armed Muslim rebel bands have been
opposing the government since October 1965 in east-central and since August
1969 in northern Chad
Member of: ACCT, AFDB, Conference of East and Central African States, EAMA, ECA,
FAO, GATT, ICAO, IBRD, IDA, ILO, IMF, ITU, Lake Chad Basin Commission,
Niger River Commission, OAU, UEAC, U.N., UNESCO, UPU, WHO, WMO','6f5bfd2e2fd350188d10dd1e30ab4a48186fc3335eba37cf168cb9234e3298e0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34d7c27de07188509f6f91d6a204bf5466c864f77fc1700878b57095c8be0ddb',1974,'LY','Libya','government',27,'Legal name: Czechoslovak Socialist Republic
Type: Communist state
Capital: Prague
Political subdivisions: 2 separate autonomous republics (Czech Socialist
Republic and Slovak Socialist Republic); 7 regions (kraj) in Czech lands,
three regions in Slovakia; national capitals of Prague and Bratislava have
regional status
Legal system: civil law system based on German codes, modified by Communist
legal theory; revised constitution adopted 1960 amended in 1968 and 1970;
no judicial review of legislative acts; legal education at Universita
Komenskeho School of Law; has not accepted compulsory ICJ jurisdiction
Branches: executive --- President (elected by Federal Assembly), cabinet
(appointed by President); legislative -- Federal Assembly (elected directly),
Czech and Slovak National Councils (also elected directly) legislate on
limited area of Czech and Slovak affairs; judiciary -- Supreme Court
(elected by Federal Assembly); entire governmental structure dominated
by Communist Party
Government leaders: President Ludvik Svoboda (reelected March 1973),
Premier Lubomir Strougal
Suffrage: universal over age 18
Elections: governmental bodies every 5 years; President every 5 years, (last
election, November 1971)
Dominant political party and leader: Communist Party of Czechoslovakia (KSC),
Gustav Husak, General Secretary; Communist Party of Slovakia (KSS) has status
of "provincial KSC organization"
Voting strength (1971 election): 99.81% Communist-sponsored single slate
Communists: 1.2 million party members
Other political groups: puppet parties -- Czechoslovak Socialist Party,
Czechoslovak People''s Party, Slovak Freedom Party, Slovak Revival Party
Member of: CEMA, GATT, IAEA, ICAO, Seabeds Committee, U.N., Warsaw Pact
Legal name: Republic of Dahomey
Type: republic, under military rule since October 1972
Capital: Porto-Novo (official), Cotonou (de facto)
Political subdivisions: 6 departments, 30 arrondissements
Legal system: based on French civil Jaw and customary law; legal education
generally obtained in France; has not accepted compulsory ICJ jurisdiction
Branches: military government took over on 26 October 1972; 67-member National
Revolutionary Council formed September 1973 to advise President
Government leader: Lt. Col. Mathieu Kerekou, President and Minister of National
Defense
Suffrage: universal for adults whenever elections or referendums are held
Elections: current government has held no elections and none are scheduled
Political parties: none
Communists: no Communist party; some sympathizers
Member of: ACCT, AFDB, ECA, EAMA, Entente, FAO, ICAO, ILO, ITU, Niger
River Commission, OAU, OCAM, U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Denmark
Type: constitutional monarchy
Capital: Copenhagen
Political subdivisions: 14 counties, 277 communes, 88 towns
Legal system: civil law system; constitution adopted 1953; judicial review of
legislative acts; legal education at Universities of Copenhagen and Arhus;
accepts compulsory ICd jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament
(Folketing); executive power vested in Crown but exercised by cabinet
responsible to parliament; Supreme Court, 2 superior courts, 106 lower courts
Government leaders: Queen Margrethe II; Anker Jorgensen heads caretaker admini-
stration pending formation of new government
Suffrage: universal, but not compulsory, over age 21
Elections: on call of prime minister but at least every four years (last election
4 December 1973)
Political parties and leaders: Social Democratic, Anker Jorgensen; Moderate
Liberal, Poul Hartling; Conservative, Erik Haunstrup Clemmensen; Radical
Liberal, Asqer Baunsbak-Jensen; Socialist Peoples, Sigurd Omann; Communist,
Knud Jespersen; Left Socialist, a triumvirate consisting of Ernst Dahl, Leif
Sondergaard Andersen, and Niels Finn Christiansen; Center Democratic, Erhard
Jakobsen; Progressive, Mogens Glistrup; Christian People''s, Jens Miller;
Justice, Ib Christiansen
Voting strength (1973 election): 22.6% Social Democratic, 14.0% Progressive,
10.8% Moderate Liberals, 9.9% Radical Liberal, 8.1% Conservative, 6.8% Center
Democratic, 5.2% Socialist Peoples, 3.6% Christian Peoples, 3.2% Communist,
2.5% Justice, 13.3% other
Communists: 5,000; a number of sympathizers, as indicated by 39,344 Communist
votes cast in 1971 elections
Member of: Council of Europe, EC, FAQ, GATT, IAEA, IBRD, ICAO, IDA, IFC, IMB,
ILO, IMCO, IMF, ITU, NATO, Nordic Council, OECD, Seabeds Committee (observer),
U.N., UNESCO, UPU, WHO, WMO
87
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Socialist Federal Republic of Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
Political subdivisions: 6 republics with 2 autonomous provinces (within the
Republic of Serbia)
Legal system: mixture of civil law system and Communist legal theory; constitution
adopted 1963 and amended in 1967, 1968, and 1971 (a new constitution will be
adopted and implemented in early 1974); in early stage of development is a
system of judicial review of legislative acts in Constitutional Court (a
quasi-judicial body); legal education at several law schools; has not accepted
compulsory ICd jurisdiction
Branches: parliament (Federal Assembly) constitutionally supreme; executive
includes cabinet (Federal Executive Counci1]) and the federal administration;
independent judiciary; the State Pesidency is a collective policymaking body
based on proportional representation of all the republics and provinces, Tito
presides as President of the Republic
Government leader: Josip Broz Tito, President of Republic and President of
League of Communists of Yugoslavia
Suffrage: universal over age 18
Elections: Federal Assembly elected every 4 years
Political parties and leaders: League of Communists of Yugoslavia (LCY) only;
leaders are President Tito and influential presidium members Edvard Kardelj,
Veljko Vlahovic, Mijalko Todorovic, Vladimir Bakaric, and Stane Dolanc
Voting strength: Voter participation in national elections has declined, as
follows -- 1963, 95.5%; 1965, 93.6%; 1967, 89%; 1969, 88%
Communists: 1,009,953 party members (1972)
Other political or pressure groups: Socialist Alliance of Working People of
Yugoslavia (SAWPY), the major mass front organization for the LCY;
Confederation of Trade Unions of Yugoslavia (CTUY), Union of Youth of
Yugoslavia (UYY), Federation of Yugoslav War Veterans (SUBNOR)
385
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Member of: CEMA (observer but participates in certain commissions), EC (5-year
non-preferential trade agreement signed in May 1973), FAO, GATT, IAEA, IBRD,
ICAO, IHB, ILO, IMCO, IMF, ITU, OECD (participant in some activities), Seabeds :
Committee, U.N., UNESCO, UPU, WHO, WMO -
Legal name: Republic of Zaire (until October 1971 known as Democratic Republic
of the Congo)
Type: republic; constitution establishes strong presidential system
Capital: Kinshasa
Political subdivisions: 8 regions and federal district of Kinshasa
Legal system: based on Belgian civil law system and tribal law; new constitution
promulgated 1967; legal education at National University of Zaire; has not
accepted compulsory ICJ jurisdiction
Branches: president elected 1970 for seven-year term; National Legislative
Council of 420 members elected for five-year term; the official party is
the supreme political institution
Government leaders: Lt. Gen Mobutu Sese Seko, President
Suffrage: universal and compulsory over age 18
Elections: presidential and legislative elections in October and November 1970
Political parties and leaders: Mouvement Populaire de la Revolution (MPR), only
legal party, organized from above with actual grassroots popularity not
clearly definable
Voting strength: MPR slate polled 96.3% of vote in 1970 elections
Communists: no Communist Party; U.S.S.R. and People''s Republic of China have
diplomatic missions in Zaire
Member of: AFDB, EAMA, FAO, IAEA, ICAO, IHB, ILO, ITU, OAU, UDEAC, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Republic of Zambia
Type: republic since October 1964
Capital: Lusaka
Political subdivisions: 8 provinces
Legal system: based on English common law and customary law; new constitution
adopted September 1973; judicial review of legislative acts in an ad hoc
constitutional council; legal education at University of Zambia in Lusaka; has
( not accepted compulsory ICJ jurisdiction
Branches: modified presidential system; unicameral legislature; judiciary
Government leader: President Kenneth Kaunda; prime minister to be appointed by
President under new 1 party system
Suffrage: universal adult
Elections: last general election December 1968; new election December 1973
Political parties and leaders: United National Independence Party (UNIP),
Kenneth Kaunda; former opposition party banned in December 1972 when
1 party state proclaimed
Voting strength (1968 election): UNIP had 73% of vote, but 30 of its candidates
were unopposed; strength probably would have been over 80% if these seats
had been contested; adopted single party system of government in 1972
Communists: no Communist Party, but sympathizers of socialism in upper levels
of government, UNIP, and labor unions
Member of: AFDB, Commonwealth, FAQ, IAEA, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU,
U.N., UNESCO, UPU, WHO, WMO','4e2830e5ebf0ccaade0077bc19a02c3b0a7ffe58631f4f09e1b435b6a6a14833','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b901dc059523de75f606ccdfff8509ddcb6df9f09d66abf8dae2de0e13c0941',1974,'CO','Colombia','government',32,'Legal name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions: 22 departments
Legal system: civil law system; constitution came into effect 1966; judicial
review of legislative acts; legal education at University of San Carlos of
Guatemala; has not accepted compulsory ICJ jurisdiction
Branches: traditionally dominant executive; elected unicameral legislature;
7-member (minimum) Supreme Court
Government leader: President Carlos Arana
Suffrage: universal over age 18, compulsory for literates, optional for illiterates
Elections: next elections (President and Congress) March 3, 1974
Political parties and leaders: Democratic Institutional Party (PID}, Donaldo
Alvarez Ruiz; Revolutionary Party (PR), Carlos Sagastume Perez (Sec. Gen.);
National Liberation Movement (MLN), Mario Sandoval Alarcon; Guatemalan
Christian Democratic Party (DCG), Danilo Barillas Rodriguez, Rene de Leon
Schlotter
Voting strength: for President -- MLN-PID 251,135 (40%), PR 202,241 (32.5%), DCG
125,948 (20%) null, 7.5%; for congressional seats -- PR 16, MLN-PID 34, DCG 5
Communists: communist party outlawed; underground membership estimated at 750
Other political or pressure groups: outlawed (Communist) Guatemalan Labor Party
(PGT), Bernardo Alvarado; United Democratic Revolutionary Front (FURD) Manuel
Colom Argueta
Member of: CACM, IADB, IAEA, ICAO, IHB, OAS, ODECA, U.N.
Legal name: Republic of Guinea
Type: republic; under one-party presidential regime
Capital: Conakry
Political subdivisions: 29 administrative regions, 209 arrondissements, about
8,000 local entities at village level
Legal system: based on French civil Jaw system, customary law, and presidential
decree; constitution adopted 1958; no constitutional provision for judicial
review of legislative acts; has not accepted compulsory ICJ jurisdiction
Branches: executive branch dominant, with power concentrated in President''s
hands and a small group who are both ministers and members of the party''s
politburo; unicameral National Assembly and judiciary have little independence
Government teader: President Ahmed Sekou Toure, who has been designated
"The Supreme Leader of the Revolution"
Suffrage: universal over age 18
Elections: approximate schedule -- 5 years parliamentary, latest in 1968;
7 years Presidential, latest in 1968
Political parties and leaders: only party is Democratic Party of Guinea (PDG) ,
headed by Sekou Toure
Communists: no Communist party, although there are some sympathizers
Member of: AFDB, ECA, FAO, ICAO, ILO, ITU, Niger River Commission, OAU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Cooperative Republic of Guyana
Type: republic within Commonwealth
Capital: Georgetown
Political subdivisions: 9 administrative districts
Legal system: based on English common law with certain admixtures of Roman-
Dutch law; has not accepted compulsory ICd jurisdiction
Branches: Council of Ministers presided over by Prime Minister; 53-member
unicameral legislative National Assembly (elected); Supreme Court
Government leader: Prime Minister L.F.S. Burnham
Suffrage: universal over age 18 as of constitutional amendment August 1973
Elections: last held in July 1973; next election must be called within 5 years
Political parties and leaders: People''s Progressive Party (PPP), Cheddi Jagan;
People''s National Congress (PNC), L.F.S. Burnham; United Force (UF),
Feilden Singh
Voting strength (1973 election): 70.2% PNC, 26.2% PPP, 3.6% other
Communists: unknown; top echelons of PPP and PYO (Progressive Youth Organization,
militant wing of the PPP) include many Communists, but rank and file is
non-Communist
Other political or pressure groups: Liberator Party (LP), Guyana National
Liberation Front (GNLF), People''s Democratic Movement (PDM), African Society
for Cultural Relations with Independent Africa (ASCRIA) , Afro-Asian-American
Association (AAAA)
Member of: CARICOM, FAO, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAS (observer),
Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Haiti
Type: republic under the 14-year dictatorship of Francois Duvalier who was
succeeded upon his death on 21 April 1971 by his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: 5 departments (despite constitutional provision for 9)
Legal system: based on Roman civil law system; constitution adopted 1964 and
amended 1971; legal education at State University in Port-au-Prince and private
law colleges in Cap-Haitien, Les Cayes, Gonaives, and Jeremie; accepts
compulsory ICU jurisdiction
Branches: lifetime President, unicameral 58-member legislature of very limited
powers, judiciary appointed by President
Government leader: President-for-life Jean-Claude Duvalier
Suffrage: universal over age 18
Elections: constitution as amended in 1971 provides for lifetime president to be
designated by his predecessor and ratified by electorate in plebiscite; last
legislative elections, which are held every 6 years, held February 1973
Political parties: National Unity Party, only legal party; United Haitian
Communist Party (PUCH), illegal (Communist)
Voting strength (1967 legislative elections): 100% National Unity Party
(havalier)
Communists: strength unknown; party leaders believed in exile
Other political or pressure groups: none
Member of: GATT, IADB, IAEA, ICAO, IMF, IBRD, OAS, U.N.
Legal name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Political subdivisions: 18 departments
Legal system: based on Roman and Spanish civil law; some influence of English
common law; constitution adopted 1965; judicial review of legislative acts
in Supreme Court; legal education at University of Honduras in Tegucigalpa;
accepts compulsory ICJ jurisdiction, with reservations
Branches: constitution provides for elected President, unicameral legislature,
and national judicial branch
Government leader: General Oswaldo Lopez Arellano
Suffrage: universal and compulsory over age 18
Elections: next general election February 1977
Political parties and leaders: all parties, even legal ones, are dormant at
present; Liberal Party (PLH), Carlos Roberto Reina Idiaguez, Andres Alvarado
Puerto, Jorge Bueso Arias, Modesto Rodas Alvarado, and Max Velasquez, President
of Central Executive Council; National Party (PNH), Alejandro Lopez Cantarero,
Ricardo Zuniga Augustinus, General Oswaldo Lopez Arellano, Mario Rivera Lopez,
Martin Aquero, Manuel Acosta Bonilla; Popular Progressive Party (PPP-
uninscribed), Gonzalo Carias Castillo; Orthodox Republican Party (PRO-
uninscribed), Roque Jacinto Rivera; National Innovation and Unity Party (PINU),
non-communist, (uninscribed), Miguel Andonie Fernandez; Workers Party of
Honduras (PTH), illegal, Rogue Ochoa; Communist Party of Honduras/Soviet
(PCH/S-outlawed), Dionisio Ramos Bejarano; Communist Party of Honduras/China
(PCH/C-outlawed), Agapito Robledo Castro
Voting strength (1971 elections): Nationalist Party (PNH) 306,028; Liberal
Party (PLH) 276,777
Communists: about 800; 2,000 sympathizers
Other political or pressure groups: National Association of Honduran Campesinos
(ANACH); Council of Honduran Private Enterprise (COHEP); Confederation of
Honduran Workers (CTH)
Member of: IADB, ICAO, ILO, OAS, CACM, U.N.
151
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Colony of Hong Kong
Capital: Victoria
Type: U.K. crown colony
Political subdivisions: Hong Kong, Kowloon, and New Territories
Legal system: English common law
Branches: Governor assisted by advisory Executive Council; he legislates with
advice and consent of Legislative Council; Urban Council which alone includes
elected representatives, responsible for health, recreation, and resettlement;
independent judiciary
Government leader: C.M. MacLehose, Governor and Commander in Chief
Suffrage: limited to 200,000 to 300,000 professional or skilled persons
Elections: every 2 years to select one-half of elected membership of Urban
Council; other Urban Council members appointed by the Governor
Political parties and leaders: Civic Association, Hu Pai-fu; Reform Club, B. A.
Bernacchi; Socialist Democratic Party, Sun Po-kong; Hong Kong Labour Party,
Tang Hon-tsai
Voting strength: (elected Urban Council members) Civic Association 4, Reform
Club 3, and 1 independent
Communists: an estimated 2,000 hard core cadres affiliated with Communist Party
of China
Other political or pressure groups: Federation of Trade Unions (Communist
controlled), Hong Kong and Kowloon Trade Union Council (Nationalist Chinese
dominated), Hong Kong General Chamber of Commerce, Chinese General Chamber
of Commerce (Communist controlled), Federation of Hong Kong Industries,
Chinese Manufacturers’ Association of Hong Kong
Legal name: Hungarian People''s Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 megyes (counties), 5 autonomous cities in county
status, 97 jaras (districts)
Legal system: based on Communist legal theory, with both civil law system (civil
code of 1960) and common law elements; constitution adopted 1949 amended 1972;
Supreme Court renders decisions of principle that sometimes have the effect of
declaring legislative acts unconstitutional; legal education at Lorand Eotvos
Tudomanyegyetem School of Law in Budapest and 2 other schools of law; has not
accepted compulsory ICJ jurisdiction
Branches: executive -- Presidential Council (elected by Parliament); legislative
-- Parliament (elected by direct suffrage); judicial -- Supreme Court
(elected by Parliament)
Government leaders: Jeno Fock, Chairman, Council of Ministers; Pal Losonczi,
President, Presidential Council
Suffrage: universal over age 18
Elections: every 4 years; national and local elections are held separately, two
years apart
Political parties and leaders: Hungarian Socialist (Communist) Workers Party
(sole party); Janos Kadar is First Secretary of Central Committee
Voting strength (1971 election): 7,260,856 (98%) for Communist-approved candidates;
76,725 (1.4%) invalid and negative votes; total eligible electorate about
7.3 million
Communists: about 693,000 party members (June 1971)
Member of: CEMA, FAO, IAEA, ICAO, ILO, ITU, UNESCO, U.N., UPU, Warsaw Pact, WHO
Legal name: Overseas Department of Martinique
Type: overseas department of France; represented by 3 deputies in the French
National Assembly and 2 Senators in the Senate
Capital: Fort-de-France
Political subdivisions: 2 arrondissements; 34 communes, each with a locally
elected municipal council
Legal system: French legal system; highest court is a court of appeal based
in Martinique with jurisdiction over Guadeloupe, French Guiana, and Martinique
Branches: executive, prefect appointed by Paris; legislative, popularly elected
council of 36 members; judicial, under jurisdiction of French judicial system
Government leader: Prefect Jean Terrade
Suffrage: universal over age 21
Elections: General Council elections coincide with those for the French National
Assembly, normally every five years; last General Council election took place
in March 1973; last local election held September 1973
Political parties and leaders: Union of Democrats for the Republic (UDR), Emile
Maurice; Progressive Party of Martinique (PPM), Aime Cesaire; Communist
Party of Martinique (PCM), Armand Nicolas; Democratic Union of Martinique
(UDM), Leon-Laurent Valere; Socialist Party, leader unknown; Federation of the
Left, leader unknown
Voting strength: UDR, 2 seats in French National Assembly; PPM, 1 seat (1973
election)
Communists: 1,000 estimated
Other political or pressure groups: Proletarian Action Group (GAP)
Legal name: Islamic Republic of Mauritania
Type: republic; one-party presidential rule since 1960
Capital: Nouakchott
Political subdivisions: 8 regions and a capital district
Legal system: based on French civil law system and Islamic law; constitution
adopted 1961; judicial review of legislative acts in the Supreme Court;
has not accepted compulsory ICJ jurisdiction
Branches: president; unicameral National Assembly of 50 elected members ;
separate judiciary (appointed by president)
Government leader: President Moktar Ould Daddah
Suffrage: universal for adults
Elections: presidential and parliamentary election every 5 years; most recent
August 1971
Political parties and leaders: Mauritanian People''s Party is only legal party,
Secretary General Moktar Ould Daddah
Communists: no Communist Party, but there is a scattering of Maoist sympathizers
Member of: ACCT, CEAO, EAMA, FAO, ICAO, ILO, IMCO, ITU, OAU, Organization
for the Development of the Senegal River Valley (OMVS), Seabeds Committee,
U.N., UNESCO, WHO, WMO
Legal name: Mauritius
Type: independent state since 1968, recognizing Elizabeth II as chief of state
Capital: Port Louis
Political subdivisions: 5 "organized municipalities" and various island
dependencies
Legal system: based on French civil law system with elements of English conmon
law in certain areas; constitution adopted 6 March 1968
Branches: executive power exercised by Prime Minister and 21-man Council of
Ministers; unicameral legislature (National Assembly) with 62 members elected
by direct suffrage, 8 specially elected, and one nominated
Government leader: Prime Minister Dr. Seewoosagur Ramgoolam
Suffrage: universal over age 21
Elections: last held in August 1967; next scheduled in 1972 postponed at least
A years by constitutional amendment
Political parties and leaders: a loose government coalition consisting of Labor
Party (S. Ramgoolam), Muslim Committee of Action (A. R. Mohamed), and Parti
Mauricien Social Democrate (G. Duval); Independent Forward Bloc (S.
Bissoondoyal); Mauritius Democratic Union (M. Lesage); a few independents;
Mouvement Militant Mauritian (P. Berenger)
Voting strength: Muslim Committee of Action, 4 seats; Independent Forward Bloc,
6 seats; Mauritius Labor Party, 33 seats; Mauritius Democratic Union, 5 seats;
Parti Mauricien Social Democrate, 19 seats; 4 seats vacant
Communists: may be 2,000 sympathizers; several Communist organizations; Mauritius
Lenin Youth Organization, Mauritius Women''s Committee, Mauritius Communist
Party, Mauritius People''s Progressive Party, Mauritius Young Communist League,
Mauritius Liberation Front, Chinese Middle School Friendly Association,
Mauritius/USSR Friendship Society
Other political or pressure groups: Tamil United Party, Mauritius Workers Party
Member of: ACCT, ICAQ, Commonwealth, OAU, OCAM, U.N.
227
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Political subdivisions: 4 sections
Legal system: based on French law; new constitution adopted 1962; has not
accepted compulsory ICJ jurisdiction
Branches: National Council (18 members); Communal Council (15 members, headed
by a mayor)
Government leader: Prince Rainier III
Suffrage: universal
Elections: National Council every 5 years; most recent 1968
Political parties and leaders: National Union of Independents, National Democratic
Entente (1965)
Voting strength: figures for 1968 election not available; (1958) 61% National
Union of Independents, 39% National Democratic Entente
Communists: not available
Member of: IAEA, IHB, ITU, U.N., UNESCO, UPU, WHO
Legal name: Mongolian People''s Republic
Type: Communist state
Capital: Ulaanbaatar
Political subdivisions: 18 provinces and 2 autonomous municipalities (Ulaanbaatar
and Darhan)
Legal system: blend of Russian, Chinese, and Turkish systems of law; constitution
adopted 1940; no constitutional provision for judicial review of legislative
acts; legal education at Ulaanbaatar State University; has not accepted
compulsory ICJ jurisdiction
Branches: constitution provides for a Great People''s Hural (national assembly)
and a highly centralized administration
Party and government leader: Y. Tsedenbal, First Secretary of the MPRP and
Chairman of the Council of Ministers
Suffrage: universal; age 18 and over
Elections: national assembly elections held every 4 years; last elections held
in June 1973
Political party: Mongolian People''s Revolutionary (Communist) Party (MPRP);
estimated membership, 58,000 (claimed 1972)
Member of: CEMA, ECAFE, IAEA, U.N., WHO
Legal name: Kingdom of Morocco
Type: constitutional monarchy (constitution adopted 1972)
Capital: Rabat
Political subdivisions: 22 provinces and 2 prefectures
Legal system: based on Islamic Jaw and French and Spanish civil law system;
judicial review of legislative acts in Constitutional Chamber of Supreme
Court; modern legal education at branches of Mohamed V University in Rabat
and Casablanca and Karaouine University in Fes; has not accepted compulsory
ICJ jurisdiction
Branches: constitution provides for Prime Minister and ministers named by and
responsible to King; King has paramount executive powers; unicameral
legislature (two thirds to be directly elected; one third indirectly);
judiciary independent of other branches
Government leaders: King Hassan II; Prime Minister Ahmed Osman
Suffrage: universal over age 20
Elections: last parliamentary elections held 21 and 28 August 1970 for Council
of Representatives which was dissolved in March 1972; elections for new
parliament created by Constitution adopted 15 March 1972 have not been held
Political parties and leaders: Istiqlal Party, Allal el-Fassi; Popular Movement
(MP), Mahjoubi Aherdan; Constitutional and Democratic Popular Movement
(MPCD), Dr. Abdelkrim Khatib; National Union of Popular Forces (UNFP), split
into competitive factions under Abdallah Ibrahim and Mahjoub Ben Seddik of
Casablanca-based faction and Abderrahim Bouabid of Rabat-based faction (Rabat
faction of UNFP was suspended in April 1973); Democratic Constitutional Party
(PDC), Mohamed Hassan Ouazzani; Party for Liberation and Socialism (PLS),
established in June 1968 and banned September 1969, is front for Moroccan
Communist Party (MCP), which was proscribed in 1959, Ali Yata; Istiqlal and
the UNFP formed a National Front in July 1970 to oppose the new constitution,
boycotted the parliamentary elections and the 1972 constitutional referendum
Voting strength: August 1970 elections were nonpolitical; 1 March 1972
constitutional referendum tallied 98.7% for new constitution, 1.25% opposed
and National Front abstained from voting
Communists: 300 est.
235
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Member of: Arab League, EC (association until 1974), FAO, IAEA, IBRD, ICAO, IDA,
ILO, IMC, IMCO, IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO
Legal name: State of Mozambique
Type: overseas state of Portugal
Capital: Lourenco Marques
Political subdivisions: 10 districts administered by district governors;
municipalities governed by appointed official
Legal system: based on Portuguese civil law system and customary law
Branches: Governor General appointed by Lisbon is chief executive officer for
internal administration; he also has certain legislative powers which he
exercises with Legislative Assembly; all action in state may be vetoed
by Minister of Overseas in Lisbon; judiciary is constitutionally independent
Government leader: Governor General Manuel Pimentel dos Santos
Suffrage: all adults able to read and write Portuguese and in full possession of
political and civil rights
Elections: Legislative Assembly elections held every 4 years; last held March 1973
Political parties and leaders: National Popular Action (ANP), formerly the
National Union (UN), state president Jorge Morais Barbosa; no legal opposition
political parties
Communists: none known
Other political or pressure groups: the Mozambique Liberation Front (FRELIMO), led
by Moises Samora Machel, operates from Tanzania and Zambia; less significant
Mozambique Revolutionary Committee (COREMO), led by Paulo Gumane, based in
Legal name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands, enjoying complete domestic
autonomy
Capital: Willemstad; Curacao, center of government
Political subdivisions: 4 island territories -- Aruba, Bonaire, Curacao, and the
Windward Islands -- St. Eustatius, southern part of St. Martin (northern
part is French), Saba
Legal system: based on civil law system, with some English common law influence;
Dutch Country Statute of 1955 serves as constitution
Branches: executive power, under nominal head of Governor (appointed by the
Crown), exercised by 8-member Council of Ministers or Cabinet; legislative
power rests with 22-member Legislative Council; independent court system
under control of Chief Justice of Supreme Court of Justice (administrative
functions under Minister of Justice); each island territory has island
council] headed by Lieutenant Governor for local administration
Government leaders: currently under caretaker government Jed by Juan Evertsz
Suffrage: universal age 18 and over
Elections: held every 4 years, last held August 1973
Political parties and leaders: the Democratic Party (DP); Antilles Social Progress
Movement (MASA) led by Ciro Kroon; the Aruba Patriotic Party (PPA) led by S.d.
Trompe; the National People''s Party (NVP), S.D. Abbad; the Aruba People''s Party
(AVP) led by Dominico Guzman Croes; the National Aruban Union Party/ Independent
Aruban Party (UNA/PIA) led by A. Werleman/M. Croes; Bonaire Democratic Party
led by L.A. Abraham; Windward Island Democratic Party led by A. C. Wathey;
Social Progressive Action Party, S. R. Goeloe; Antillean Reform Union (URA),
Roberto Suriel; Curacao Independent Party (COP), Peter Vander Hoven; Radical
Peoples Party (PRP), Max de Castro; Workers! Party (Frente Obrero); People''s
Electoral Movement (MEP), separatist party
Voting strength (1973 general election): DP/PPA, 8 seats; NVP, 5 seats; Frente
Obrero, 3 seats, MEP, 5 seats; labor coalition, 1 seat
Communists: no Communist Party
Member of: EC (associate), WHO
245
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Overseas Territory of New Caledonia
Type: French overseas territory; represented in French parliament by one deputy
and one Senator
Capital: Noumea
Political subdivisions: 4 islands or island group dependencies -- Isle of Pines,
Loyalty Islands, Huon Islands, Island of New Caledonia
Legal system: French law
Branches: administered by Governor, who is also High Commissioner for France in
the Pacific; responsible to French Ministry for Overseas France and Governing
Council; Assemblee Territoriale
Government leader: Jean Risterucci, Governor and French High Commissioner
Suffrage: restricted (1957 election roll listed 32,370 males and females over
21 years of age, of whom 18,964 were classed as indigenous inhabitants)
Elections: Assembly elections in 1972
Political parties: Union Caledonienne, Entente Democratique et sociale, Union
Multiraciale, Mouvement Liberal Caledonien, Union Democratique, Mouvement
Populaire Caledonien
Voting strength (1972 election): Union Caledonianne, 12 seats; Entente Sociale
et Democratique, 6 seats; Union Multiraciale, 5 seats; Mouvement Liberal
Caledonien, 5 seats; Union Democratique, 4 seats; Mouvement Populaire
Caledonien, 2 seats; Caledonie Francaise, 1 seat
Communists: number unknown; Union Caledonienne strongly leftist; some politically
active Communists were deported during 1950''s; small number of North Vietnamese
Other political parties and pressure groups: several lesser parties
Legal name: New Hebrides Condominium
Type: Anglo-French condominium
Capital: Vila
Political subdivisions: 4 administrative districts
Legal system: 3 sets of courts; one each for French and British subjects, one for
New Hebrides native affairs
Branches: Advisory Council of 30 members with no real legislative powers, majority
elected
Government leader: two resident commissioners, one French, one British
Political parties and le','93ade4f677c77cb351027785d63a2e059103a49eb6b8a9fa7a5742f7acd34c22','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afed5745055d3140cb9115f5dffeedb84da6129d214793baca7c1edd1c28af0c',1974,'CO','Colombia','government',33,'aders: New Hebrides National Party, founded 1971,
president Adain Garae
Legal name: Republic of Nicaragua
Type: republic
Capital: Managua
Political subdivisions: 1 national district and 16 departments
‘ Legal system: based on Spanish civil law system; constitution adopted in 1950,
now being revised; judicial review of legislative acts in the Supreme Court;
legal education at Universidad Nacional de Nicaragua and Universidad
Centroamericana; accepts compulsory ICJ jurisdiction
Branches: President from 1 May 1972 to 1 December 1974 replaced by a triumvirate,
bicameral legislature, judiciary elected by legislature, and Supreme Electoral
Tribunal (4th branch)
Government leaders: Triumvirate members -- Roberto Martinez, Alfonso Lovo Cordero
and Edmundo Paguaga
Suffrage: universal over age 18 if married or literate, otherwise 21
Elections: every 6 years; however, due to agreement between liberal and conservative
parties, next elections will be held 1 September 1974; municipal elections
every 3 years
Political parties and leaders: Nationalist Liberal Party (PLN), Anastasio Somoza,
Ramiro Sacasa; Traditionalist Conservative Party (PCT), Edmundo Paguaga and
Fernando Aguero Rocha; Independent Liberal Party (PLI), not legal, Roberto
Robelo, Juan Manuel Gutierrez; Social Christian Party (PSC), not legal,
Ignacio Zelaya, Manolo Morales Peralta (President) and Roberto Ferrey
(Secretary General); National Conservative Action (ANC), not legal, Pedro
J. Chamorro
oe eee (1972 elections): PLN 534,171 votes (75.4%), PCT 174,897 votes
24 .6%
Communists: Communist movement split into hard-line Nicaraguan Socialist Party
(PSN) illegal, 60 members; soft-line Nicaraguan Communist Party (PCN) illegal,
40 members, and small pro-Castro Sandinist National Liberation Front (FSLN)
50 to 60 activist; about 1,000 sympathizers
. Other political or pressure groups: wealthy families; businessmen
Member of: CACM, FAQ, GATT, IADB, IAEA, ICAO, ICd, ILO, INTELSAT, ITU, OAS,
ODECA, Seabeds Committee (observer) U.N., UNESCO, UNICEF, UPU, WHO, WMO
253
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Republic of Niger
Type: republic; one-party rule established 1960
Capital: Niamey
Political subdivisions: 7 departments, 32 arrondissements
Legal system: based on French civil law system and customary law; constitution
adopted 1960; judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: President selected for 5 years by direct universal suffrage; unicameral,
60-member National Assembly elected for 5 years; judiciary constitutionally
independent of executive and legislature
Government leader: President Diori Hamani
Suffrage: universal over age 21
Elections: presidential and parliamentary elections in 1970; about 99% of voters
approved unopposed official candidates
Political parties and leaders: Parti Progressiste Nigerien (PPN), led by Diori
Haman i
Communists: no Communist party; some sympathizers in outlawed Sawaba party
Member of: ACCT, AFDB, CEAO, EAMA, ECA, Entente, FAQ, GATT, IBRD, ICAO, ILO, IMF,
ITU, Lake Chad Basin Commission, Niger River Commission, OAU, OCAM, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: The Federal Republic of Nigeria
Type: federal republic since 1963; under military rule since January 1966
Capital: Lagos
4 Political subdivisions: 12 states, 11 headed by a military governor, | by a
civilian administrator
Legal system: based on English common law, tribal law, and Islamic law; new
constitution to be prepared; accepts compulsory ICJ jurisdiction with
reservations
a Branches: Federal Military Government; decrees issued by Supreme Military Council,
advised by largely civilian Federal Executive Council; effective
administrative power held by senior civil servants
Government leader: Gen. Yakubu Gowon, Head of Federal Military Government and
Commander in Chief of Nigerian Armed Forces
Suffrage: universal adult suffrage (except for women in former Northern Region)
Elections: expected to be held by 1976
Political parties and leaders: political parties and politically active tribal
societies were dissolved by-decree on 24 May 1966; some sub rosa political
activity continues
Communists: the banned Socialist Workers and Farmers Party and the Nigerian Trade
Union Congress have a limited political following, no influence on government
Member of: AFDB8, Commonwealth, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU,
Lake Chad Basin Commission, Niger River Commission, OAU, OPEC, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 20 counties, 404 communes, 47 towns
Legal system: mixture of customary law, civil law system, and common law traditions;
constitution adopted 1814, modified 1884; Supreme Court renders advisory
opinions to legislature when asked; legal education at University of Oslo;
accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament (Storting);
executive power vested in Crown but exercised by cabinet responsible to
parliament; Supreme Court, 5 superior courts, 104 lower courts
Government leaders: King Olav V; Prime Minister Trygve Bratteli
Suffrage: universal, but not compulsory, over age 20
Elections: held every 4 years (next in September 1977)
Political parties and leaders: Anti-Tax Party, Anders Lange; Conservative, Kare
Willoch; Christian People''s, Lars Korvald; Center, John Austrheim; Liberal,
Hallvard Eika; New Liberal People''s, Helge Seip; Labor, Trygve Bratteli;
Democratic Socialist, Berit As; Socialist People''s, Finn Gustavsen; Communist,
Reidar Larsen
Voting strength (1973 election): 5.0% Anti-Tax; 7.3% Conservative; 11.8% Christian
Peoples; 6.8% Center; 3.4% Liberal; 2.3% New Liberal People''s; 35.5% Labor;
11.2% Socialist Electoral Alliance (includes Democratic Socialist, Socialist
People''s, and Communist parties); 1.0% Communist
Communists: 2,000; a number of sympathizers as indicated by the 22,500 Communist
votes cast in the 1969 election
Member of: Council of Europe, EC (Free Trade Agreement), EFTA, FAQ, GATT, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, Nordic Council, OECD,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
259
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Sultanate of Oman
Type: absolute monarchy; nomi
Capital: Muscat
Legal system: based on English common law and Islamic law; no constitution;
ultimate appeal to the Sultan; has not accepted compulsory ICJ jurisdiction
Government leader: Sultan Qabus ibn Sa''id Al Bu Sa''id
Other political or pressure groups: none
Member of: Arab League, U.N.
nally independent but under strong U.K. influence
Legal name: Islamic Republic of Pakistan
Type: parliamentary, federal republic; constitution adopted April 1973, effective
August 1973, provides for bi-cameral legislature; strong prime minister
Capital: Islamabad
Political subdivisions: 4 provinces -- Punjab, Sind, Baluchistan, and Northwest
Frontier -- with the capital territory of Islamabad and certain tribal areas
centrally administered; Pakistan claims that Azad Kashmir is independent
pending a settlement of the dispute with India, but it is in fact under
Pakistani contro]
Legal system: based on English common law; accepts compulsory ICJ jurisdiction,
with reservations
Government leaders: President Fazal Elahi; Prime Minister Z. A. Bhutto
Suffrage: universal over age 21
Elections: elections for National Assembly based on one-man/one-vote formula,
and for provincial assemblies were held in December 1970; with independence
of Bangladesh, National Assembly consists of 144 West Pakistanis and 2 East
Pakistanis
Political parties and leaders: Pakistan People''s Party (PPP), Z.A. Bhutto;
United Muslim League (UML), Shaukat Hayat Khan and Pir of Pigaro; National
Awami Party (NAP), Abdul Wali Khan; All Pakistan Muslim League (QML), Abdul
Qaiyum Khan; Markazi Jamiat-ul-Ulema-i-Pakistan (MJUP), Khamaja Qamar-u-Din
Sialvi; Jamiat-ul-Ulema-i-Islam (JUI), Mufti Mahmud
Communists: 750; 3,000-5,000 sympathizers
Other political or pressure groups: military remains potentially strong
political force
Member of: ADB, CENTO, Colombo Plan, FAQ, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO,
IMCO, IMF, ITU, RCD, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
*This figure is based on official estimates, but a recent series of population estimates
and projections by the Pakistan Central Statistical Office indicates the population may
be as high as 64 million. Presumably the latter figure is based on underenumeration in
the 1961 census and a higher growth rate than that implied by the official estimates.
263
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Republic of Panama
Type: republic
Capital: Panama
Political subdivisions: 9 provinces, 1 Indian reservation
Legal system: based on civil law system; constitution adopted in 1972; judicial
review of legislative acts in the Supreme Court; legal education at
University of Panama; accepts compulsory ICJ jurisdiction, with reservations
Branches: popularly elected unicameral legislature which elects the President;
presidentially appointed Supreme Court
Government leaders: Demetrio Lakas is Constitutional President and Chief of
State, but subordinate to Gen. Omar Torrijos, the National Guard Commandant
who was given special powers for 6 years by the assembly in 1972
Suffrage: universal and compulsory over age 21
Elections: elections for assembly of representatives of the corregimientos
August 1972; next election August 1978
Political parties and leaders: political parties suspended pending revision of
electoral code; Communist Party illegal but allowed to operate
Voting strength (1968 election): 55% Arnulfo Arias Madrid (National Union
Coalition), 42% David Samudio (People''s Alliance), 3% Antonio Gonzalez
Revilla (Christian Democratic Party); no parties were active in the 1972
elections
Communists: 100 active and several hundred inactive members People''s Party (PdP);
Communist; 1,000 sympathizers; National Liberation Movement (MLN) and
Vanguard of National Action (VAN) currently inactive as pro-Castro
organizations, 40-60 members
Other political or pressure groups: National Council of Private Enterprise (CONEP)
Member of: IADB, IAEA, ICAO, OAS, U.N.
265
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: State of St. Christopher-Nevis-Anguilla
Type: dependent territory with full internal autonomy as a British "Associated
State"; Anguilla formally seceded in May 1967 but has not been recognized
as an independent state by any government; in July 1968 a legislative
council headed by Ronald Webster was elected to govern Anguilla; in March
1969 the U.K. sent troops to Anguilla, placing the island again under
colonial rule; in 1971, Anguilla reverted to its former colonial relationship
with the U.K. although nominally remaining part of the Associated state of
St. Christopher-Nevis-Anguilla
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law; constitution of 1960; highest judicial
organ is Court of Appeal of Leeward and Windward Islands
Branches: legislative, 10-member popularly elected House of Assembly; executive,
cabinet headed by prime minister
Government leaders: Premier, Robert L. Bradshaw; U.K. Acting Governor, M. P. Allen
Suffrage: universal adult suffrage
Elections: at least every 5 years; most recent 10 May 1971
Political parties and leaders: St. Christopher-Nevis-Anguilla Labor Party, Robert
L. Bradshaw; People''s Action Movement (PAM), William Herbert; Nevis Reformation
Party (NRP), Ivor Stevens
Voting strength (1971 election): St. Christopher-Nevis-Anguilla Labor Party won
7 seats in the House of Assembly, PAM won 2, 1 seat remains open for Anguilla
which did not participate in the election
Communists: none known
Member of: has been invited to join CARICOM (CARIFTA replacement)
Legal name: State of St. Vincent
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Kingstown
Legal system: based on English common law; constitution of 1960; highest
judicial body is Court of Appeal of Leeward and Windward Islands
Government leader: Premier James F. Mitchell; Governor General (U.K.) Sir Rupert
G. John
Suffrage: universal adult suffrage (18 years old and over)
Elections: every 5 years; most recent 7 April 1972
Political parties and leaders: People''s Political Party (PPP), Ebenezer Joshua;
St. Vincent Labor Party (LP), R. Milton Cato
Voting strength (1972 election): LP 6 seats, PPP 6 seats, independent 1 seat in
the Legislative
Communists: negligible
Member of: has stated intention to join CARICOM (CARIFTA replacement)
Legal name: Republic of San Marino
Type: republic (dates from 4th century A.D.); in 1862 the Kingdom of Italy
concluded a treaty guaranteeing the independence of San Marino; although
legally sovereign, San Marino is vulnerable to pressure from the Italian
Capital: San Marino
Political subdivisions: San Marino is divided into 9 sections: Guaita, Fratta,
Serravalle, Domagnano, Acquaviva, Fiorentino, Montegiardino, Faetano,
Chiesanuova
Legal system: based on civil law system with Italian law influences; electoral
law of 1926 serves some of the functions of a constitution; has not accepted
compulsory ICJ jurisdiction
Branches: the Grand and General Council is the legislative body elected by popular
vote; its 60 members serve 5-year terms; Council in turn elects two Captains-
Regent who exercise executive power for term of 6 months, the Council of
State whose members head government administrative departments and the Council
of Twelve, the supreme judicial body; actual executive power is wielded by
the Secretary of State for Foreign Affairs and the Secretary of State for
Internal Affairs
Government leaders: Secretary of State for Foreign Affairs Gian Luigi Berti
(Christian Democratic party); Secretary of State for Internal Affairs
Giuseppe Lonferini (Christian Democratic party); Secretary for finance Remy
Giacomini (Socialist)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General Council required at least every
5 years; next elections 1974
Political parties and leaders: Christian Democratic party (DCS), Gian Luigi Berti;
Social Democratic Party (PSDSM), Alvaro Casali; Socialist Party (PSS), Remy
Giacomini; Communist Party (PCS), Umberto Barulli
Voting strength (1969 election): 45% DCS, 25% PCS, 18.3% PSDIS, 11.7% PSS
Communists: approx. 300 members (number of sympathizers cannot be determined) ;
PSS, in government with Christian Democrats since March 1973, formed a
government with the PCS from the end of World War II to 1957
Other political parties or pressure groups: political parties influenced by
policies of their counterparts in Italy, the two Socialist parties are
not united
Member of: ICJ, International Institute for Unification of Private Law,
International Relief Union, IRC, UPU
303
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Kingdom of Saudi Arabia
Type: monarchy
Capital: Riyadh; foreign ministry and foreign diplomatic representatives located
in Juddah
Political subdivisions: 18 amirates
Legal system: largely based on Islamic law, several secular codes have been
introduced; commercial disputes handled by special committees; has not
accepted compulsory ICJ jurisdiction
Branches: King Faysal (Al Saud, Faysal ibn Abd al-Aziz) rules in consultation
with ruling family, Council of Ministers, and religious leaders
Government leader: King Faysal
Communists: negligible
Member of: Arab League, FAQ, IAEA, IATA, IBRD, ICAO, IDA, IFC, IMF, ITU, OAPEC,
OPEC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Senegal
Type: republic; only one legal party since 1966
Capital: Dakar
Political subdivisions: 7 regions, each subdivided into 18 departments, 90
districts, and 34 communes
Legal system: based on French civil law system; constitution adopted 1960,
revised 1963 and 1970; judicial review of legislative acts in Supreme
Court (which also audits the government''s accounting office); legal
education at University of Dakar; has not accepted compulsory ICJ jurisdiction
Branches: Government dominated by President who is assisted by Prime Minister,
appointed by President and subject to dismissal by President or censure by
National Assembly; 80-member National Assembly, elected for 5 years
(effective 1973); President elected for 5-year term (effective 1973) by
universal suffrage; judiciary headed by Supreme Court, with members appointed
by President
Government leaders: Leopold Sedar Senghor, President; Abdou Diouf, Prime Minister
Suffrage: universal adult
Elections: uncontested presidential and legislative elections held February
1973 for 5-year term
Political parties and leaders: Union Progressiste Senegalaise (UPS), ruling
party led by President Leopold Senghor, has absorbed all major opposition
parties; illegal parties include Communist-backed Parti Africain
de 1''Independence (PAI) and Parti Communiste Senegalais (PCS), a splinter
group
Communists: a few Communists and sympathizers ; PAI is pro-Moscow; PCS is
pro-Peking
Other political or pressure groups: labor unions are controlled by party;
students and teachers occasionally strike
Member of: ACCT, AFDB, CEAO, EAMA, ECA, FAQ, IAEA, IBRD, ICAO, ILO, IMCO, IMF,
ITU, OCAM, OMVS, U.N., UNESCO, UPU, WHO, WMO
307
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Colony of the Seychelles
Type: British crown colony
Capital: Victoria, Mahe Island
Legal system: based on English common law, French civil law system, and
customary law
Branches: Governor, Council of Ministers, Legislative Assembly
Government leader: Governor Sir Bruce Greatbatch
Suffrage: universal adult
Elections: November 1970, held every 5 years
Political parties and leaders: Seychelles Democratic Party (SDP), James R.
Mancham, President; Seychelles Peoples United Party (SPUP), France Albert
Rene, President
Voting strength: SDP won 10 seats in Legislative Assembly with 52.8% popular
yote in 1970 election; SPUP won 5 seats with 47.2% of votes
Communists: negligible
Other political or pressure groups: trade unions which are appendages of
political parties
Legal name: Republic of Sierra Leone
Type: republic under presidential regime since April 1971
Capital: Freetown
Political subdivisions: 3 provinces; divided into 12 districts with 146 chief-
doms, where paramount chief and council of elders constitute basic unit of
government; plus western area, which comprises Freetown and other coastal
areas of the former colony
Legal system: based on English law and customary laws indigenous to local
tribes; constitution adopted April 1971; highest court of appeal is the
Sierra Leone Court of Appeals; has not accepted compulsory ICd jurisdiction
Branches: executive authority exercised by President; parliament consists of 97
members, 85 of whom are elected representatives and 12 paramount chiefs
representing tribal councils in provincial districts; independent judiciary
Government leader: Siaka Stevens, President, heads APC government composed
of members of his political party
Suffrage: universal over age 2]
Elections: the maximum life of an elected parliament is 5 years, but it may be
dissolved earlier by the President; parliamentary election held in May 1973;
President is elected by parliament for 5 year term; next presidential election
Political parties and leaders: All People''s Congress (APC), headed by Stevens;
Sierra Leone People''s Party (SLPP) is the opposition party
Communists: no party, although there are a few Communists and a slightly larger
number of sympathizers
Member of: AFDB, Commonwealth, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Sikkim
Type: autonomous protectorate of India ruled by a hereditary maharaja as
titular ruler; tied to India by 1950 treaty and brought under further
control by 1973 agreement; ruler controls only palace affairs; external
relations, defense, and communications are India''s exclusive responsibility
Political subdivisions: none known
Legal system: constitution in preparation
Branches: Executive Council appointed from elected legislature with Indian
chief executive as head of administration
vee leader: Maharaja Paldem Thondup Namgyal, known as the Chogyal of
Sikkim
Suffrage: universal suffrage
Elections: to be held every 4 years beginning in 1973
Political parties and leaders: Sikkim National Congress Party; Sikkim National
Party; Sikkim State Congress/Janta Congress
Communists: no overt presence
Legal name: Republic of Singapore
Type: republic within Commonwealth since separation from Malaysia in August 1965
Capital: Singapore
Legal system: based on English common law; constitution based on preindependence
State of Singapore constitution; legal education at University of Singapore;
has not accepted compulsory ICJ jurisdiction
Branches: ceremonial President; executive power exercised by Prime Minister and
cabinet responsible to unitary legislature
Government leaders: President, Dr. Benjamin Sheares; Prime Minister, Lee Kuan Yew
Suffrage: universal over age 20; voting compulsory
Elections: normally every 5 years
Political parties and leaders: government -- People''s Action Party (PAP), Lee
Kuan Yew; opposition -- Barisan Sosialis Party (BSP), Dr. Lee Siew Choh;
Workers'' Party, J.B. Jeyaretnam; Communist Party illegal
Voting strength (1972 election): PAP won all 65 seats in parliament and received
70% of vote; remaining 30% to four opposition parties
Communists: 200-500; Barisan Sosialis Party infiltrated by Communists
Member of: ADB, ASEAN, Colombo Plan, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Somali Democratic Republic
Type: republic; under military rule since October 1969
Capital: Mogadiscio
Political subdivisions: 11 regions, 56 districts
Organization: the junta has assumed all authority, calling itself the Supreme
Revolutionary Council, membership of which consists of 18 army and 3 police
officers; the Council has abrogated the constitution, dissolved the parliament,
and banned political parties
Government leader: President of the Supreme Revolutionary Council, Gen. Mohamed
Siad Barre
Communists: possibly some Communist sympathizers in the government hierarchy
Member of: AFDB, EAMA, FAO, IBRD, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UNICEF,
UPU, WHO
Legal name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative, Cape Town; judicial, Bloemfontein
Political subdivisions: 4 provinces, each headed by centrally appointed
administrator; provincial councils, elected by white electorate, retain
limited powers
Legal system: based on Roman-Dutch law and English common law; constitution
enacted 1961, changing the Union of South Africa into a Republic; possibility
of judicial review of Acts of Parliament concerning dual official languages;
accepts compulsory ICd jurisdiction, with reservations
Branches: President as formal chief of state; Prime Minister as head of
government; Cabinet responsible to bicameral legislature; lower house
elected directly by white electorate; upper house indirectly elected and
appointed; judiciary maintains substantial independence of government
influence
Government leader: Prime Minister Balthazar J. Vorster
Suffrage: general suffrage limited to whites over 18 (17 in Natal Province)
Elections: must be held at least every 5 years;','e5f837a101845cd9d17d33a84c49c40c76fcbe7bb22b69d079b8689ff34de4f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0b8bb1999726322bca6dc5a44380997f450ccfc8a716fffbc22143dd9e11b3c',1974,'CO','Colombia','government',34,'last elections April 1970
Political parties and leaders: National Party, B. J. Vorster, P. W. Botha,
C. Mulder, M. C. Botha, Jan De Klerk; United Party, Sir De Villiers graaff;
Progressive Party, Colin Eglin, Helen Suzman; Herstigte Nasionale party,
Albert Hertzog, Jaap Marais
Voting strength ti970 general elections): of 166 legislative seats, National
Party 118, United Party 47, Progressive Party ]
Communists: small Communist Party illegal since 1950; party in exile maintains
headquarters in London; Dr. Yasuf Dadoo, Michael Harmel, Joe Slovo
Other political groups: (insurgent groups in exile) African National Congress
(ANC), Oliver Tambo; Pan-Africanist Congress (PAC), leadership in dispute
Member of: IAEA, IBRD, ICAO, IHB, IMF, ITU, Seabeds Committee (observer), U.N.,
UPU, WHO, WMO
319
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7','1a0db37bb52e072eb8f2631347cb0095b1c5b86b14ad478f43e7dac281237177','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('675de634dcd6dc8ac61d8f737e6aaf7942ed341e31c203bb06af70b2d1d1a3a6',1974,'GL','Greenland','government',39,'Legal name: Republic of Iceland
Type: republic
Capital: Reykjavik
Political subdivisions: 23 rural districts, 215 parishes, 14 incorporated towns
Legal system: civil law system based on Danish law; constitution adopted 1944;
legal education at University of Iceland; does not accept compulsory
ICU jurisdiction
Branches: legislative authority rests jointly with President and parliament
(Althing); executive power vested in President but exercised by cabinet
responsible to parliament; Supreme Court and 29 lower courts
Government leaders: President Kristjan Eldjarn; Prime Minister Olafur Johannesson
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1975); presidential, every
4 years (next in 1976)
Political parties and leaders: Independence (conservative), Geir Hallgrimsson;
Progressive, Olafur Johannesson; Social Democratic, Gylfi Gislason; People''s
Alliance (Communist front), Ragnar Arnalds; Organization of Liberals and
Leftists, Hannibal Valdimarsson
Voting strength (1971 election): 36.2% Independence, 25.2% Progressive, 10.4%
Social Democratic, 17.1% People''s Alliance, organization of leftists and liberals
8.9%
Communists: 1,000; a number of sympathizers, as indicated by 18,055 votes cast
for Labor Alliance in 1971 election
Member of: Council of Europe, EC (free trade agreement pending resolution of fishing
limits issue), EFTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO,
IMF, ITU, NATO, Nordic Council, OECD, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO
Legal name: Republic of India
Type: federal republic
Capital: New DeThi
Political subdivisions: 21 states, 9 union territories, 1 protectorate (Sikkim)
Legal system: based on English common law; constitution adopted 1950; judicial
review of legislative acts; accepts compulsory ICJ jurisdiction, with
reservations
Branches: parliamentary government, national and state; independent judiciary
Government leader: Prime Minister Indira Gandhi
Suffrage: universal over age 21
Elections: national and state elections ordinarily held every 5 years; may be
postponed in emergency and may be held more frequently if government loses
confidence vote; next general election to be held by March 1976; 16 states
and two union territories held state elections in March 1972; remaining states
to be polled over next several years
Political parties and leaders: Indian National Congress split into two factions
in 1969, largest faction (the Ruling Congress) loyal to Prime Minister Gandhi
led by S.D. Sharma, and smaller faction tthe Organization Congress) led by
Ashoka Mehta; Communist Party of India (CPI), S. A. Dange, chairman; Communist
Party of India/Marxist (CPI/M), P. Sundarayya, general secretary; Communist
*Does not take account of refugees who entered India from Bangladesh during 1971, most
of whom presumably have returned
159
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
|
GOVERNMENT (cont''d):
Party of India/Marxist-Leninist (CPI/ML), L.K. Advani, chairman; Swatantra,
P. Mody, chairman; Bharatiya Jana Sangh, A. B. Vajpayee, president; The
Socialist Party, Kappori Thakur, chairman; Dravida Munnetra Kazhagam (DMK),
N. Karunanidhi, president
Voting strength (1971 election): 43.7% Ruling iCongress, 10.5% Organization Congress,
7.4% Bharatiya Jana Sangh, 3.1% Swatantra, |4.8% CPI, 5.2% CPI/M, 3.5% Socialist
Parties, 3.7% DMK, 18.1% other
Communists: 70,000 members of CPI (est.), 70,000 members of CP1/M; Communist
sympathizers, 13 million ta
Other political or pressure groups: Anna Dravida Munnetra Kazhagam (ADMK), M.G.
Ramachandran, president, opposing DMK in Tamil Nadu; splintered Akali Dal
representing Sikh religious community in the Punjab; various separatist groups
seeking reorganization of states; numerous|"senas" or militant/chauvinistic
organizations, including Shiv Sena in Bombay
Member of: ADB, Colombo Plan, Commonwealth, FAQ, IAEA, ICAO, IDA, IFC, IHB, ILO,
IMCO, IMF, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
w
Legal name: Republic of Indonesia
Type: republic
Capital: Jakarta :
Political subdivisions: 26 first-level administrative subdivisions or provinces
which are further subdivided into 281 second-level areas
Legal system: based on Roman-Dutch law, substantially modified by indigenous
concepts; constitution of 1945 is legal basis of government; legal education
at University of Indonesia, Jakarta; has not accepted compulsory ICJ
jurisdiction
Branches: executive headed by President who is chief of state and head of
cabinet; cabinet selected by President; unicameral legislature (Parliament) ,
of 460 members (100 appointed, 360 elected); second and larger body (Congress)
of 920 members and includes the legislature and 460 other members {chosen by
several processes, but not directly elected) elects President and Vice
President, and theoretically determines national policy
Government leader: President Suharto (elected by Congress March 1973)
Suffrage: universal over age 17 and married persons regardless of age
Political parties and leaders: Golkar (quasi-official "party" based on functional
groups), Amir Moertono; Indonesian Democratic Party (federation of former
Nationalist and Christian parties), Mohammed Isnaeni; Unity Development
Party (federation of former Islamic parties), Idham Chalid
Voting strength (1971 election): Golkar 236 seats, Indonesian Democratic 30,
Unity Development 94
Communists: Communist Party (PKI) was officially banned in March 1966; current
strength est. at 1,000, with less than 10% engaged in organized activity; pre-
October 1965 hard-core membership has been estimated at 1.5 million
Member of: ADB, ASEAN, FAO, IAEA, ICAO, IHB, ILO, IMF, U.N., UNESCO
161
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Empire of Iran
Type: constitutional monarchy, controlled by the Shah
Capital: Tehran
Political subdivisions: 20 provinces and 4 chief-governorates, subdivided
into districts, sub-districts, counties, and villages
Legal system: based largely on French law, with elements drawn from other
continental systems; personal law based on Islamic practice generally with
residual traces of Roman law; constitution adopted 1906 and constitutional
law of 1907; High Court of Appeal may judge disputes relating to government
departments acting according to law; legal education at University of Teheran;
has not accepted compulsory ICU jurisdiction
Branches: executive power rests in Shah who appoints a Prime Minister; Prime
Minister must be approved by Tower house (Majlis); while Cabinet theoretically
responsibility of Prime Minister, Shah usually exerts strong influence over
its selection; bicameral legislature; Majlis has 268 members elected to
4-year terms, and Senate 60 members serving 4-year terms; half of Senate
members appointed by Shah, other half elected; no provision for judicial
review of constitutionality of legislative acts
Government leaders: Shah Mohammad Reza Pahlavi and Prime Minister Amir
Abas Hoveyda
Suffrage: universal over age 20
Elections: Majlis every 4 years; Senate every 4 years; latest national elections
July 1971, district and municipal elections in October 1972
Political parties and leaders: New Iran Party, Manuchehr Kalali; Mardom (Peoples)
Party, Nasser Ameri; Iranians Party, Dr. Fazlollah Sadr; Pan Iranist Party,
Mohsen Pezeshkpur
Voting strength (1971 election): Majlis -- New Iran Party, 230 seats; Mardom
Party, 37 seats; Iranians Party, 1 seat; Senate -- New Iran Party, 28 seats;
Mardom Party, 2 seats; plus 30 seats appointed by the Shah; all candidates
government approved
Communists: 1,000-2,000 (hard-core, est.); sympathizers (15,000-20,000 est.);
mostly pro-U.S.S.R. but pro-Chinese faction developing
163
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Other political or pressure groups: Tudeh Party (Communist, illegal); National
Front (coalition of neutralist urban elements virtually discredited because
a a a to Shah''s reform program); |Confederation of Iranian Students a
illegal
Member of: CENTO, Colombo Plan, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO,
IMF, ITU, OPEC, RCD, U.N., UNESCO, UPU, HO, WMO
Legal name: Republic of Iraq
Type: republic; one-party military regime established in July 1968; National
Front Government consisting of Ba''ath Party, Iraq Communist Party el. al. in
process of being formed
Capital: Baghdad
Political subdivisions: 16 provinces under centrally appointed officials
Legal system: based on Islamic law in special religious courts, civil law system
elsewhere; provisional constitution adopted in 1968; judicial review was
suspended; legal education at University of Baghdad; has not accepted
compulsory ICJ jurisdiction
Branches: "moderate" wing of Ba''th Party of Iraq has been in power since 1968 coup
Government leaders: President Ahmad Hasan al-Bakr; Deputy Chairman of the
Revolutionary Command Council Saddam Husayn ''Abd-al-Majid al-Tikriti
Suffrage: no elective bodies exist
Elections: no national elections since overthrow of monarchy in 1958
Communists: Communist Party allowed token representation in cabinet
Political or pressure groups: political parties banned, major opposition to
regime is from leftwing of the Ba''th Party, Communist Party and Nasirist
groups, disaffected members of the regime and army officers
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OPEC,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law, substantially modified by indigenous
concepts; constitution adopted 1937; judicial review of legislative acts in
Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: elected President; bicameral parliament reflecting proportional and
vocational representation; judiciary appointed by President on advice of
Government leaders: Taoiseach (Prime Minister) Liam Cosgrave (Fine Gael);
Tanaiste (Deputy Prime Minister) Brendan Corish (Labor)
Suffrage: universal over age 18
Elections: Dail (lower house) elected every 5 years -- last election February
1973; President elected for 7-year term -- last election May 1973
Political parties and leaders: Fianna Fail, John (Jack) Lynch; Labor Party,
Brendan Corish; Fine Gael, Liam Cosgrave; Communist Party of Ireland,
Michael O''Riordan
Voting strength: (1973 election) Fianna Fail 46% (69 seats), Fine Gael 35% (54
seats), Labor Party 14% (19 seats), other 5%; Independents hold 2 seats
Communists: approximately 300
Member of: Council of Europe, EC, FAO, IBRD, ICAO, ILO, IMCO, IMF, ITU, OECD, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution provides for establishment of 20 regions;
5 (Sicilia, Sardegna, Trentino-Alto Adige, Friuli-Venezia Giulia, and Valle
d''Aosta) have been functioning for some time and the remaining 15 regions
were instituted on 1 April 1972; 94 provinces
Legal system: based on civil law system, with ecclesiastical law influence;
constitution came into effect 1 January 1948; judicial review under certain
conditions in Constitutional Court; has not accepted compulsory ICJ3 jurisdiction
Branches: executive -- President empowered to dissolve Parliament and call national
election; he is also Commander of the Armed Forces and presides over the
Supreme Defense Council; otherwise, authority to govern invested in Council
of Ministers; legislative power invested in bicameral, popularly elected
Parliament; Italy has an independent judicial establishment
Government leaders: President Giovanni Leone; Premier Mariano Rumor
Suffrage: universal over age 21 (except in Senatorial elections where minimum
age of voter is 25)
Elections: national elections for Parliament held every 5 years (most recent,
May 1972); provincial and municipal elections held every 5 years with some
out of phase; regional elections every 5 years
Political parties and leaders: Christian Democratic Party (DC), Amintore Fanfani
(party secretary), Mariano Rumor, Aldo Moro, Emilio Colombo; Communist Party
(PCI), Luigi Longo, Enrico Berlinguer; Italian Socialist Party (PSI), Pietro
Nenni (ex-party secretary), Giacomo Mancini, Francesco De Martino; Italian
Social Democratic Party (PSDI), Flavio Orlandi Liberal Party (PLI), Giovanni
Malagodi; Italian Social Movement (MSI), Giorgio Almirante; Republican Party
(PRIN, Ugo La Malfa
Voting strength (1972 election): 38.8% DC, 27.2% PCI, 9.6% PSI, 3.9% PLI, 8.7%
MSI, 2.9% PRI, 5.1% PSDI, 3.8% other
171
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Communists: 1,580,000 (as of 1 October 1972) members; number of sympathizers
cannot be determined
Other political or pressure groups: the Vatican; three major trade union
confederations (CGIL -- Communist dominated, CISL -- Christian Democratic, >»
and UIL -- Social Democratic and Republican); Italian manufacturers
association (Confindustria); organized farm groups
Member of: ECSC, EC, FAQ, IBRD, ICAO, IAEA, IHB, ILO, IMCO, IMF, ITU, NATO, OECD
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Ivory Coast
Type: republic, one-party presidential regime established 1960
Capital: Abidjan
Political subdivisions: 24 departments subdivided into 127 subprefectures
Legal system: based on French civil law system and customary law; constitution
adopted 1960, amended 1963; judicial review in the Constitutional Chamber
of the Supreme Court; legal education at Abidjan School of Law; has not
accepted compulsory ICJ jurisdiction
Branches: President has sweeping powers, unicameral legislature, separate judiciary
Government leader: President Felix Houphouet-Boigny
Suffrage: universal over age 21
Elections: uncontested Presidential and legislative elections held in November
1970 for 5-year term
Political parties and leaders: Parti Democratique de la Cote d''Ivoire (PDCI),
(only party); official party leader is Secretary General Philippe Yace, but
Houphouet-Boigny is in contro]
Communists: no Communist party; possibly some sympathizers
Member of: ACCT, AFDB, CEAO, EAMA, ECA, Entente, FAO, IAEA, IBRD, ICAQ, ILO, IMCO,
IMF, ITU, Niger River Commission, OAU, OCAM, U.N., UNESCO, UPU, WHO, WMO
Legal name: Jamaica
Type: independent state within Commonwealth since August 1962, recognizing
Elizabeth II as head of state
Capital: Kingston
Political subdivisions: 12 parishes and the Kingston-St. Andrew corporate area
Legal system: based on English common law; has not accepted compulsory ICd
jurisdiction
Branches: cabinet headed by Prime Minister; 53-member elected House of Represent-
atives; 21-member Senate (13 nominated by the Prime Minister, 8 by opposition
leader); judiciary follows British tradition under a Chief Justice
Government leader: Prime Minister Michael Manley
Suffrage: universal, age 21 and over
Elections: at discretion of Governor-General upon advice of Prime Minister but
within 5 years; latest held 29 February 1972
Political parties and leaders: Jamaica Labor Party (JLP), Sir Alexander
Bustamante, Hugh Shearer; People''s National Party (PNP), Michael Manley
Voting strength (1972 general elections): 56.55% PNP, 43.21% JLP, 0.24% other
Communists: a few hundred Marxist and Communist sympathizers
Other political or pressure groups: New World Group (Caribbean regionalists,
nationalists, and leftist intellectual fraternity); Rastafarians (Negro
religious/racial cultists, pan-Africanists); New Creation International
Peacemakers Tabernacle (leftist group)
Member of: CARICOM, FAQ, GATT, IAEA, IBRD, ICAO, IFC, ILO, IMF, OAS, Pan
American Health Organization, Seabeds Committee (observer), U.N.
Legal name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital: ‘Amman
Political subdivisions: 8 districts (3 are under Israeli occupation) under
centrally appointed officials
Legal system: based on Islamic law and French codes; constitution adopted 1952;
judicial review of legislative acts in a specially provided High Tribunal;
has not accepted compulsory ICJ jurisdiction
Branches: King holds balance of power; Prime Minister exercises executive authority
in name of King; Cabinet appointed by King and responsible to parliament;
bicameral parliament with Chamber of Deputies last chosen by national elections
in April 1967, Senate last appointed by King in September 1971; each house
contains equal representation from East and West Jordan; present parliament
subservient to executive as a result of rigged elections (April 1967) 3
secular court system based on differing legal systems of the former
Transjordan and Palestine; law Western in concept and structure; Sharia
(religious) courts for Muslims, and religious community council] courts for
non-Muslim communities; desert police carry out quasi-judicial functions
in desert areas
Government leader: King Husayn ibn Talal al-Hashimi
Suffrage: all citizens over age 20
Political parties and leaders: political party activity illegal since 1957;
Palestine Liberation Organization and Fatah, Yasir Arafat; various smaller
fedayeen groups; Ba''th Party of Jordan, Dr. Mun‘if Razzaz; National
Socialist Party, Sulayman al-Nabulusi; Muslim Brethren
181
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
|
|
GOVERNMENT (cont''d):
Communists: party actively repressed, ee membership less than 100
Member of: Arab League, FAO, IAEA, TATA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
a
Legal name: Republic of Kenya
Type: republic within Commonwealth since December 1963
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi Area
Legal system: based on English common law, tribal law and Islamic law;
constitution enacted 1963; judicial review in Supreme Court; legal education
at University Kenya School of Law in Nairobi; accepts compulsory ICd
jurisdiction, with reservations
Branches: President and Cabinet responsible to unicameral legislature (National
Assembly) of 170 seats, 158 directly elected by constituencies and 12
appointed by the President; Assembly must be reelected at least every
5 years; High Court, with Chief Justice and at least 11 justices, has
unlimited original jurisdiction to hear and determine any civil or criminal
proceeding; provision for systems of courts of appeal with ultimate appeal
to East African Court of Appeals
Government leader: President Jomo Kenyatta
Suffrage: universal over age 21
Elections: general election (December 1969) elected present National Assembly;
next elections promised for 1974
Political party and leaders: Kenya Africa National Union (KANU), president,
Jomo Kenyatta; next party election scheduled for 1974
Voting strength: KANU holds all seats in the National Assembly
Communists: may be a few Communists and sympathizers
Other political or pressure groups: Tabor unions
Member of: EAC, IAEA, ICAO, OAU, Seabeds Committee, U.N.
Legal name: Democratic People''s Republic of Korea
Type: Communist state; one-man rule
Capital: P''yongyang
Political subdivisions: 9 provinces, 3 special cities (P''yongyang, Hamhung,
Ch''ongjin), and 1 special district (Kaesong)
Legal system: based on German civil law system with Japanese influences and
Communist legal theory; constitution adopted 1948; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
Branches: Supreme Peoples Assembly theoretically supervises Legislative and
Judicial function
Government and party leaders: Kim I1-song, President and General Secretary
of the Korean Labor Party; Kim I], Premier
Suffrage: Universal at age 17
Elections: election to SPA every 4 years, but this constitutional provision not
necessarily followed -- last election December 1972
Political party: Korean Labor (Communist) Party; claimed membership of about
1.6 million, or about 12% of population
Member of: IPU, U.N. (observer status only), UNCTAD, WHO
Legal name: Republic of Korea
Type: republic; power centralized in a strong executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities; heads centrally appointed
Legal system: combines elements of continental European civil law systems,
Anglo-American law, and Chinese classical thought; constitution approved
1972; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative (unicameral), judiciary, National Conference
of Unification
Government leaders: President Pak Chong-hui; Prime Minister Kim Chong-pil
Suffrage: universal over age 20
Elections: presidential every 6 years indirectly by the National Conference of
Unification, last election December 1972; two-thirds of the 219-member
National Assembly is elected directly for the same period within six
months of the presidential election, remaining third nominated by the
President and elected by the National Conference for a three-year term;
last election February 1973, Revitalization Group - 73 seats, Democratic
Republican Party - 73 seats, New Democratic Party - 52 seats, Democratic
Unification Party - 2 seats, Independents - 19 seats
Political parties and leaders: pro-government -- Revitalization Group (appointed)
(Chairman, Pak Tu-Chin) and Democratic Republican Party (Acting Chairman,
Yi Hyo-sang); New Democratic Party (Chairman, Yu Chin-san); Democratic
Unification (Chairman, Yang I1-tong)
Voting strength: popular vote 11,896,484; DRP 38.8%, NDP 32.8%, DUP 10.2%,
Independent 18.1%, 0.1% invalid
Communists: Communist activity banned by government; an estimated 37,000-50,000
former members and supporters
Other political or pressure groups: Federation of Korean Trade Unions; Korean
Veterans! Association; large potentially volatile student population
concentrated in Seoul
187
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d): :
Member of: ADB, Asian Parliamentary Union, Asiian People''s Anti-Conmunist League
(APACL), ASPAC, Colombo Plan, ECAFE, FAO, GATT, Geneva Conventions of 1949
for the protection of war victims, IAEA, IBRD, ICAO, IDA, IFC, IHB, IMCO, IMF, :
INTELSAT, Inter-Parliamentary Union, INTERPOL, ITU, UNESCO, U.N. Special Fund,
UPU, WHO, WMO, World Anti-Communist League (WACL); does not hold U.N.
membership
Legal name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Al Kuwayt
Political subdivisions: 3 governorates, 10 voting constituencies
Legal system: civil law system with Islamic law significant in personal matters;
constitution took effect 1963, judicial review of legislative acts not yet
determined; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers; National Assembly
Government leader: Emir Sabah al-Salim Al Sabah
Suffrage: native born and naturalized males age 21 or over
Elections: held every 4 years for National Assembly; last held January 1971
Political parties and leaders: political parties prohibited, some smal]
clandestine groups are active
Communists: insignificant
Other political or pressure groups: none
Member of: Arab League, FAQ, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, ITU,
OPEC, OAPEC, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','cb33779801358532070bb7ef5ce7fb1a9fdd0c8f36f26e9299472f9a55513ed3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe9aef37820a36ba45f40e52333ecf1c7047c838176e7f6a690dac7230b31d88',1974,'DE','Germany','government',45,'Legal name: Kingdom of Laos
Type: constitutional monarchy
Capital: Vientiane (Luang Prabang royal capital)
Political subdivisions: 16 provinces subdivided into districts, cantons, and
villages
Legal system: based on civil law system; constitution of 1947 has not accepted
compulsory ICJ jurisdiction
Branches: King, 59-member National Assembly, 12-member King''s Council; according
to 1973 peace agreement, the new provisional coalition government will be
composed of Communists, non-Communists, and two individuals acceptable to both
Government leaders: King Savang Vatthana; Premier Souvanna Phouma
Suffrage: universal over age 18
Elections: National Assembly designated by King; general election last held
January 1972
Political parties and leaders: Neo Lao Hak Sat, Conmunist-front organization
which includes the Lao People''s Revolutionary Party (Communist), only
party active
Communists: Lao People''s Revolutionary Party (clandestine) membership unknown
Other political or pressure groups: non-Communist political groups are
informal and associated with regional family and military leaders;
Royal Armed Forces (FAR) leaders, Commander in Chief Bounpone Makthepharack,
and Generals Kouprasith Abhay, Phasouk Somly, Vang Pao, Soutchay Vongsavanh,
and Ret. Gen. Quan Rathikoun
Member of: Colombo Plan, ECAFE, ICAO, IMF, Mekong Committee, SEAMES, U.N., UNCTAD
Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law, and civil law system; consti-
tution mandated in 1920; no judicial review of legislative acts; legal
education at University of Lebanon; has not accepted compulsory ICJ
jurisdiction
Branches: power lies with President elected by parliament (Chamber of Deputies);
Cabinet appointed by President, approved by parliament; independent secular
courts on French pattern; religious courts for matters of marriage, divorce,
inheritance, etc.; by custom, President is a Maronite Christian, Prime
Minister a Sunni Muslim, and president of parliament a Shia Muslim; each of
9 religious communities represented in parliament in proportion to national
numerical strength
Government leader: President Sulayman Franjiyah
Suffrage: compulsory for all males over 21; authorized for women over 21 with
elementary education
Elections: for Chamber of Deputies, held every 4 years or within 3 months of
dissolution of Chamber; held April 1972
Political parties and leaders: political party activity is organized along
sectarian lines; numerous political groupings exist, consisting of individual
political figures and followers motivated by religious, clan, and economic
considerations; political stability dependent on maintenance of balance
between religious communities
Communists: one of largest Communist parties in Middle East; legalized in 1970;
members and sympathizers estimated at 6,000
Other political or pressure groups: Palestinian guerrilla organizations
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
193
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Kingdom of Lesotho
Type: constitutional monarchy under King Moshoeshoe II; independent member of
commonwealth since 1966
Capital: Maseru
Political subdivisions: 9 administrative districts
Legal system: based on English common law and Roman-Dutch law; constitution came
into effect 1966; judicial review of legislative acts in High Court and
Court of Appeal; legal education at University of Botswana, Lesotho, and
Swaziland (located in Lesotho); has not accepted compulsory ICU jurisdiction
Branches: executive, divided between a largely ceremonial King and a Prime
Minister who leads cabinet of at least 7 members; Prime Minister dismissed
bicameral legislature in early 1970 and subsequently has ruled by decree; Prime
Minister convened Interim National Assembly in April 1973 in order to devise
new constitution; judicial -- 63 Lesotho courts administer customary law for
Africans, High Court and subordinate courts have criminal jurisdiction over
all residents, Court of Appeal at Maseru has appellate jurisdiction
Government leader: Prime Minister Chief Leabua Jonathan
Suffrage: universal for adults
Elections: elections held in January 1970; nullified allegedly because of election
irregularities; subsequent elections promised at unspecified date
Political parties and leaders: Basutoland Congress Party (BCP), Ntsu Mokhele;
National Party (BNP), Chief Leabua Jonathan
Voting strength: in 1970 elections for National Assembly, BNP won 32 seats;
BCP, 22 seats; minor parties, 4 seats
Communists: Communist Party of Lesotho banned in early 1970
Member of: Commonwealth, FAO, ILO, ITU, U.N., UNESCO, UPU, WHO
Legal name: Republic of Liberia
Type: republic; dominated by strong executive
Capital: Monrovia
Political subdivisions: country divided into 9 counties; President appoints all
officials of significance
Legal system: based on U.S. constitutional theory; recent codes drawn up by
Cornell University; constitution adopted 1847; amended 1907, 1926, 1934,
and 1955; no constitutional provision for judicial review of legislative
acts; legal education at Louis Arthur Grimes School of Law, University of
Liberia; accepts compulsory ICJ jurisdiction, with reservations
Branches: President, elected by popular vote initially for 8-year term and
eligible for successive 4-year terms, controls through appointive powers and
authority over national expenditures; 2-house legislature elected by popular
vote; judiciary consisting of Supreme Court and variety of lower courts
Government leader: President William R. Tolbert
Suffrage: universal 18 years and over
Elections: members of House of Representatives elected for 4-year terms, most
recently in May 1971; Senate members elected for 6-year terms, one-half
elected in May 1971; President Tolbert, constitutional successor to President
Tubman who died in July 1971, is eligible to complete the four year term to
which Tubman was elected in May 1971; next scheduled presidential election May
1975
Political parties and leaders: True Whig Party, in power since 1878, only
political party; President Tolbert is leader
Voting strength: 1971 elections uncontested; True Whig Party won all but a
handful of votes
Communists: no Communist Party and only a few sympathizers
Member of: AFDB, ECA, FAO, IAEA, IBRD, ICAQ, ILO, IMCO, IMF, ITU, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WHO
197
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Libyan Arab Republic
Type: republic; under military control following ouster of king on 1 September
1969; provisional constitution promulgated December 1969; loosely confederated
with Egypt and Syria in Confederation of Arab Republics (CAR) on 1 September 1971
Capital: Tripoli (defacto)
Political subdivisions: 10 administrative provinces closely controlled by
central government; district commissioners appointed by Revolutionary
Command Council]
Legal system: based on Italian civil law system and Islamic law; separate religious
courts; no constitutional provision for judicial review of legislative acts;
legal education at Law School, at University of Libya at Banghazi; has not
accepted compulsory ICJ jurisdiction
Branches: paramount political power and authority rests with the 11-man
Revolutionary Command Council (RCC); cabinet of 13 ministers; Parliament has
been dissolved
Government leaders: Revolutionary Command Council Chairman Colonel Mu''ammar
Qadhafi
Suffrage: universal
Elections: parliamentary elections last held in May 1965; election for CAR assembly
in March 1972
Political parties and leaders: Libyan Arab Socialist Union, RCC member Major Hawad,
Secretary General; Mu-ammar Qadhafi, President
Communists: no organized party, negligible membership
Other political or pressure groups: various Arab nationalist movements and the
Arab Socialist Resurrection (Ba''th) Party with small, almost negligible
memberships may be functioning clandestinely
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
OPEC, OAPEC, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Principality of Liechtenstein
Type: hereditary constitutional monarchy
Capital: Yaduz
Political subdivisions: 11 districts ’
Legal system: based on Swiss law; constitution adopted 1921; judicial review of
legislative acts in a special Constitutional Court; accepts compulsory ICJ
jurisdiction, with reservations
Branches: unicameral Parliament, hereditary Prince, independent judiciary
Government leaders: Head of State, Prince Franz Joseph II; Chief of Government,
Dr. Alfred Hilbe
Suffrage: males age 20 and over
Elections: every 4 years; next elections 1974
Political parties and leaders: Fatherland Union Party (VU), Dr. Alfred Hilbe;
Progressive Citizens Party (PCP), Dr. Gerard Batliner
Voting strength (1970 election): 50.5% VU, 49.5% PCP
Communists: none
Member of: IAEA, IPU, ITU; considering U.N. membership; under a 1923 treaty,
Switzerland handles Liechtenstein''s post and telegraph systems, customs, and
foreign relations
Legal name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for administrative purposes has 3
districts (Luxembourg, Diekirch, Grevenmacher) and 12 cantons
Legal system: based on civil law system; constitution adopted 1868; judicial
review of legislative acts in the Cassation Court only; accepts compulsory
IcJ jurisdiction
Branches: parliamentary democracy; seven ministers comprise Council of Government
headed by President, which constitutes the executive; it is responsible to
the unicameral legislature, the Chamber of Deputies; the Council of State,
appointed for indefinite term, exercises some powers of an upper house;
judicial power exercised by independent courts
Government leaders: Grand Duke Jean, Head of State; Pierre Werner, Minister of
State and President of the Government as well as Minister of Treasury
Suffrage: universal and compulsory over age 21
Elections: every 5 years for entire Chamber of Deputies; latest elections Dec-
ember 1968; next election, early 1974
Political parties and leaders: Christian Social Union, Pierre Werner and Nic Mosar
(Party President); Socialist, Antone Wehenkel (Party President); Social
Democrat, Henry Cravatte (Party President); Democratic, Gaston Thorn (Party
President and Foreign Minister); Communist, Dominique Urbany
Voting strength (1968 election, approx.): 32% Socialist, 35% Christian Socialist,
15% Communist, 17% Democratic, 1% other; it should be noted that these are
percentages of votes cast rather than voters, since Luxembourg has a weighted
proportional representation system in which voters in most populous areas
have largest multiple votes
Communists: 439 party members (1971)
Other political or pressure groups: group of steel industries representing iron
and steel industry, Centrale Paysanne representing agricultural producers;
Christian and Socialist labor unions, Federation of Industrialists; Artisans
and Shopkeepers Federation
Member of: Benelux, BLEU (Belgium-Luxembourg Economic Union), Council of Europe,
EC, FAO, IAEA, IBRD, ICAO, IFC, ILO, IMF, NATO, OECD, U.N., UPU, WEU, WHO, WMO
203
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Province of Macao
Type: overseas province of Portugal
Capital: Lisbon (Portugal)
Political subdivisions: municipality of Macao, and 2 islands
Legal system: Portuguese civil law system
Branches: Governor, who dominates legislative and executive branches, assisted
by Legislative Council with unknown number of appointed and 8 elected
members; the Urban Council with 3 governor-appointed and 4 elected members;
all high-ranking officials appointive under provisions of revised Organic
Overseas Law; new organic law to have come into effect in January 1973 to
replace legislative council with a legislative assembly
Government leader: Brigadier Jose Manuel Nobre De Carvalho, Governor
Suffrage: restricted to Portuguese citizens
Elections: conducted every 4 years; last held December 1972
Political parties and leaders: Portuguese National Union (Uniao Nacional) only
legal party, as in Portugal; Governor is leading political figure
Communists: numbers unknown
Other political or pressure groups: wealthy Macanese and Chinese representing
local interests, wealthy pro-Communist merchants representing China''s
interests; in January 1967 Macao Government acceded to Chinese demands which
gave Chinese veto power over administration of the enclave
Legal name: Malagasy Republic
Type: republic; military-civilian government established May 1972; given 9-year
mandate in popular referendum October 1972
Capital: Tananarive
Political subdivisions: 6 provinces
Legal system: based on French civil law system and traditional Malagasy law;
constitution of 1959 modified in October 1972 by law establishing
provisional government institutions; legal education at National School of
Law, University of Madagascar; has not accepted compulsory ICJ jurisdiction
Branches: executive -- Gen. Ramanantsoa heads government assisted by cabinet
called Council of Ministers; National Popular Development Council
created to replace the legislature in October 1972; regular courts are
patterned after French system, and a High Council of Institutions reviews
all legislation to determine its constitutional validity
Government leader: General Gabriel Ramanantsoa
Suffrage: universal for adults
Elections: government in October 1972 postponed all political elections
indefinitely
Political parties and leaders: Parti Social Democrate (PSD), led by Philibert
Tsiranana; Congress Party for the Independence of Madagascar (AKFM), led by
Richard Andriamanjato; National Movement for the Independence of Madagascar
(MONIMA), led by Monja Jaona; parties are permitted to exist but are barred
from positions of political authority because of postponement of elections
Voting strength: number of registered voters (1972) -- 3.5 million; (1972
presidential election) President Tsiranana, running unopposed, received
99.7% of votes cast; in 1970 National Assembly elections, PSD candidates
won 94%; AKFM 3%
207
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Communists: Communist party of virtually no importance; small and vocal group
of Communists has gained strong position in leadership of AKFM, the rank and
file of which is non-Communist i
Other political or pressure groups: Joint Struggle Committee (KIM), association ;
of students, teachers, workers, and unemployed youth
Member of: ACCT, EAMA, FAO, IAEA, ICAO, ILO, IMCO, ITU, OAU, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO
ECONOMY: s
GDP: $970 million (1971), about $140 per capita; a real increase of 4.5% between
1967 and 1971
Agriculture: cash crops -- coffee, vanilla, sugar, tobacco, sisal, rice, cloves,
raphia; food crops -- rice, cassava, cereals, potatoes, corn, beans, bananas,
coconuts, and peanuts; animal husbandry widespread; self-sufficient in food-
stuffs, but some milk and cereals imported
Fishing: catch 48,000 metric tons (1971); exports $4.4 million (1971), imports
$800,000 (1971)
Major industries: agricultural processing (meat canneries, soap factories,
brewery, tanneries, sugar refining), light consumer goods industries
(textiles, glassware), cement plant, auto assembly plant, paper mill, oi1
refinery
Electric power: 58,000 kw. capacity (1972); 213 million kw.-hr. produced (1972),
30 kw.-hr. per capita
Exports: $147.3 million (f.o.b., 1971); coffee 26%, rice 5%, vanilla 9%, sugar
3%, petroleum products 4%, cloves 14%, mineral products (graphite, mica, and
chromite) 4%; agricultural and livestock products account for about 85% of
export earnings
Imports: $213.9 million (f.0.b., 1971); consumer goods 30%, foodstuffs 14%, primary
products (crude oil, fertilizers, metal products) 28%, capital goods 28% (1971)
Major trade partners: France (in 1971 accounted for 34% of exports and 56% of
imports); U.S., preferential tariffs to EC and franc zone countries; trade £
with Communist countries remains a minute part of total trade
Budget: FY73 -- revenue $222 million, expenditure $330 million
Monetary conversion rate: 255.78 Malagasy francs=US$1 (as of February 1973,
floating since then); member of French franc zone
Fiscal year: calendar year »
Legal name: Republic of Malawi
Type: republic since July 1966; independent member of Commonwealth since July 1964
Capital: Zomba
Political subdivisions: 3 administrative regions and 23 districts
Legal system: based on English common law and customary law; constitution
adopted 1964; judicial review of legislative acts in the Supreme Court of
Appeal; has not accepted compulsory ICdJ jurisdiction
Branches: strong presidential system with cabinet appointed by President; uni-
cameral National Assembly of 60 elected and 15 nominated members; High
Court with Chief Justice and at least 2 justices
Government leader: Life President H. Kamuzu Banda
Suffrage: universal adult
Elections: scheduled for April 1971 but not held since MCP candidates were unopposed
Political parties and leaders: Malawi Congress Party (MCP), Dr. H. Kamuzu Banda
Communists: no Communist Party; may be a few Communist sympathizers
Member of: AFDB, FAO, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU, U.N., UNESCO,
WHO, WMO
Legal name: Malaysia
Type:
Malaysia: constitutional monarchy nominally headed by Paramount Ruler (King);
a bicameral Parliament consisting of a 58-member Senate and a 144-member
House of Representatives
West Malaysian states: hereditary rulers in all but Penang and Malacca where
Governors appointed by Malaystan Government; powers of state governments
limited by federal constitution
Sabah: self-governing state within Malaysia in which it holds 16 seats in
House of Representatives; foreign affairs, defense, internal security,
and other powers delegated to federal government
Sarawak: self-governing state within Malaysia in which it holds 24 seats in
House of Representatives; foreign affairs, defense, and internal security,
and other powers are delegated to federal government
Capital:
West Malaysia: Kuala Lumpur
Sabah: Kota Kinabalu (formerly Jessel ton)
Sarawak: Kuching
Political subdivisions: 13 states (including Sabah and Sarawak)
Legal system: based on English common law; constitution came into force 1963; a
judicial review of legislative acts in the Supreme Court at request of
Supreme Head of the Federation; has not accepted compulsory ICJ jurisdiction
Branches: 9 state rulers alternate as Paramount Ruler for 5-year terms; locus of
executive power vested in Prime Minister and cabinet, who are responsible
to bicameral parliament; following communal rioting in May 1969, govern-
ment imposed state of emergency and Suspended constitutional rights of all
parliamentary bodies; parliamentary democracy resumed in February 1971
West Malaysia: executive branches of 11 states vary in detail but are Similar
in design; a Chief Minister, appointed by hereditary ruler or Governor,
heads an executive council (cabinet) which is responsible to an elected,
unicameral legislature
Sarawak and Sabah: executive branch headed by Governor appointed by central
government, largely ceremonial role; executive power exercised by Chief
Minister who heads parliamentary cabinet responsible to unicameral
legislature; judiciary part of Malaysian judicial system
Government leader: Head of State, Tun Abdul Razak
Suffrage: universal over age 20
Elections: minimum of every 5 years, last elections 1969
Political parties and leaders:
West Malaysia: Alliance Party consisting of United Malays National Organiza-
tion (UMNO), Tun Abdul Razak; Malaysian Chinese Association (MCA), Tan k
Siew Sin; and Malaysian Indian Congress: (MIC), V.T. Sambanthan; major
opposition parties -- Pan Malayan Islamic Party (PMIP), Dato Asri bin Haji
212
Ds SER rr HR rR er Es mre rr 657115511117 = meme
Approved For Release 2004/08/31 : CIA-RDP79-01051A0006000
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Political parties and leaders (cont''d):
West Malaysia (cont''d):
Muda (acting); Democratic Action Party (DAP); Gerakan Rakyat Malaysia (GRM) ;
minor opposition parties -- Party Rakyat (PR), People''s Progressive Party
(PPP), Labor Party of Malaya (LPM) Partai Keadilan Masharakyat (KEMAS) ,
United Malaysian Chinese Organization (UMCO); Communist Party illegal
Sabah: United Sabah National Organization (USNO), Tun Mustapha bin Dato
Harun; Sabah Chinese Association (SCA), Khoo Siak Chiew; no organized
opposition
Sarawak: coalition composed of Sarawak Alliance and Sarawak United Peoples
Party (SUPP), Ong Kee Hui; Opposition Sarawak National Party (SNAP), Stephen
Ningkan
Voting strength:
West Malaysia: (1969 election) Alliance Party controls 9 of 11 state
legislatures, won estimated 49% of total vote; Pan-Malaysian Islamic
Party polled 24%; Democratic Action Party polled 12%; Gerakan 7%
Sabah: (October 1971 Assembly Elections) Alliance unopposed, opposition
candidates disqualified
Sarawak: (1970 elections) Alliance 24 seats, SNAP 12 seats, SUPP 11 seats;
SUPP has joined the Alliance to form a coalition state government
Communists:
West Malaysia: approx. 1,500 armed insurgents on Thailand side of Thai/
Malaysia border; approx. 300 on Malaysian side
Sarawak: 960 armed insurgents in Sarawak; armed element of SCO in Indonesian
West Borneo estimated at 300
Sabah: insignificant
Member of: ADB, ASEAN, ASPAC, Commonwealth, FAO, GATT, IAEA, IBRD, ICAO, IFC,
ILO, IMF, ITU, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Maldives
Type: republic
Capital: Male
Political subdivisions: 19 administrative districts corresponding to atolls
Legal system: based on Islamic law with admixtures of English common law primari-
ly in commercial matters; has not accepted compulsory ICJ jurisdiction
Branches: popularly elected unicameral national legislature (Majlis) (members
elected for 5-year terms); elected President, chief executive; appointed
Chief Justice responsible for administration of Islamic law
Government leaders: President Ibrahim Nasir; Prime Minister/External Affairs
Minister Ahmed Zaki
Suffrage: universal over age 2]
Political parties and leaders: no organized political parties; country governed
by the Didi clan for the past eight centuries
Communists: negligible number
Member of: Colombo Plan, U.N.
Legal name: Republic of Mali
Type: republic; under military regime since November 1968
Capital: Bamako
Political subdivisions: 6 administrative regions; 42 administrative districts
(cercles), arrondissements, villages; all subordinate to central government
Legal system: based on French civil law system and customary law; constitution
adopted 1960, amended 1961; judicial review of legislative acts in Constitu-
tional Section of Court of State; has not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by Military Committee of National
Liberation (MCNL) composed of 11 army officers; under MCNL functional
cabinet composed of civilians and army officers; judiciary
Government leaders: Col. Moussa Traore, president of MCNL, Chief of State and
head of government
Suffrage: universal over age 2]
Political parties and leaders: political activity proscribed by military government
Elections: MCNL promises elections at unspecified date
Communists: a few Communists and some sympathizers
Member of: ACCT, AFDB, CEAO, ECA, FAO, IAEA, ICAO, ILO, IMF, ITU, Niger
River Commission, OAU, OMVS, U.N., UNESCO, UPU, WHO, WMO','a051fe8c00f1568ddc2b85bd9b27722f8dbf466b4aee9898850ccda6caf372cb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1917d927892266df17faec1732a0985be2d105d13ac53433fc8e49d1e09042d',1974,'CN','China','government',49,'Legal name: Malta
Type: parliamentary democracy, independent state within the Commonwealth since
September 1964
Capital: Valletta
Political subdivisions: 2 main populated islands, Malta and Gozo, divided into
10 electoral districts (divisions)
Legal system: based on English common law; constitution adopted 1961, came into
force 1964; has accepted compulsory ICU jurisdication, with reservations
Branches: executive, consisting of prime minister and cabinet; legislative,
comprising 55-member House of Representatives; independent judiciary
Government leader: Prime Minister Dom Mintoff
Suffrage: universal over age 21; registration required
Elections: at the discretion of the Prime Minister, but must be held before the
expiration of a 5-year electoral mandate; last election June 197]
Political parties and leaders: Nationalist Party, Georgio Borg Olivier; Malta
Labor Party, Dom Mintoff
ae i (1971 election): Labor, 28 seats (50.8%); Nationalist, 27 seats
48.1%
Communists: less than 100 (est.)
Member of: Commonwealth, Council of Europe, FAO, GATT, ICAO, ILO, IMF, Seabeds
Committee, TDB, U.N., UNESCO, WHO','01d6fdc5fcb0a0f47134319e3e8f6b54ed281c0b35019f319af9051a4cd986e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e0cef7f5d2d5734fa09dd16c0265ea9742f294291031d8ce9a132899053bde6',1974,'AU','Australia','government',53,'Legal name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se; government offices in Uaboe District
Political subdivisions: 14 districts
Branches: President elected from and by Parliament for an unfixed term; popularly
elected unicameral legislature, the Parliament; Cabinet to assist the
President, four members, appointed by President from Parliament members
Government leader: President Hammer De Roburt
Suffrage: universal adult
Elections: last held in January 1971
Political parties and leaders: there are no political parties; De Roburt is only
significant political figure
Member of: no present plans to join U.N.; enjoys "special membership" in
Commonwealth; South Pacific Commission, INTERPOL, ECAFE
Legal name: Kingdom of Nepal
Type: constitutional monarchy; King Birendra exercises autocratic control over
multitiered panchayat system of government
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and English common law; legal
education at Nepal Law College in Kathmandu; has not accepted compulsory
IcJ jurisdiction
Branches: Council of Ministers appointed by the King; indirectly elected
National Panchayat (Assembly)
Government leader: King Birendra Bir Bikram Shah Deva; Prime Minister Nagendra
Prasad Rijal ''
Suffrage: universal over age 21
Elections: village and town councils (panchayats) elected by universal suffrage;
district, zonal, and National Panchayat members indirectly elected, most
for 6-year terms; 15 National Panchayat members elected from five class
organizations (women, workers, youth, and ex-servicemen), four directly
elected by all voters possessing a B.A. or its equivalent, and 16 are
appointed by the King
Political parties and leaders: all political parties outlawed
Communists: the combined membership of the two wings of the Communist Party
of Nepal (CPN) may be on the order of 6,500, the majority (perhaps 5,000)
in the pro-Chinese wing; the CPN continues to operate more or less openly,
but internal dissension has greatly hindered its effectiveness
Other political or pressure groups: proscribed Nepali Congress Party led by
B.P. Koirala from exile in India
Member of: ADB, FAO, IBRD, ICAO, IDA, ILO, IMF, ITU, U.N., UNESCO, UPU, WHO
Legal name: Kingdom of the Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government resides at The Hague
« Political subdivisions: 11 provinces governed by centrally appointed commissioners
of Queen
Legal system: civil law system incorporating French penal theory; constitution
of 1815 frequently amended, reissued 1947; judicial review in the Supreme
Court of legislation of lower order than Acts of Parliament; legal education
a at six law schools; accepts compulsory ICJ jurisdiction, with reservations
Branches: executive, (Queen and Cabinet of Ministers), which is responsible to
bicameral states general (parliament); independent judiciary
Government leader: Head of State, Queen Juliana; Johannesden Uy], Prime Minister
Suffrage: universal over age 2]
Elections: must be held at least every 4 years for lower house (most recent
November 1972), and every 3 years for upper house (most recent April 1971)
Political parties and leaders: Catholic People''s Party (KVP), Dr. D. de Zeeuw,
Antirevolutionary (ARP), A. Veerman; Labor (PvdA), Andre van der Louw; Liberal
(VVD), Mrs. H. van Sommeren-Downer; Christian Historical Union (CHU), J. W.
Vanhulst; Democrats ''66 (D-66), Mrs. Ruby E. Vander Scheer van Essen;
Communist (CPN), Henk Hoekstra; Pacifist Socialist (PSP), P. A. Burggraff;
Political Reformed (SGP), H. G. Abma; Reformed Political Union (GVP), G.
Venrink; Radical Party (PPR), Dolf Coppes; Democratic Socialist''70 (DS-70),
Jonkheer M. L. de Braew; Farmers’ Party (BP), Hendrik Koekoek; Roman Catholic
Party (RKPN), leader unknown
Voting strength (1972 election): 17.7% KVP, 14.4% VVD, 8.8% ARP, 4,8% CHU, 27.4%
PvdA, 4.2% D-66, 4.1% DS-70, 4.5% CPN, 1.5% PSP, 4.8% PRP, 2.2% SGP, 1.8% GVP,
1.9% BP, .9% RKP
Communists: 9,000 members; 329,973 votes in 1972 election
Other political or pressure groups: great multinational firms; Socialist, Catholic,
° and Protestant trade unions; Federation of Catholic and Protestant Employers
Associations; the non-demoninational Federation of Netherlands Enterprises
243
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Member of: Benelux, Council of Europe, ECE, ECSC, EC, EMA, FURATOM, FAO, IAEA,
IBRD, ICAO, IHB, IMF, NATO, OECD, Seabeds Committee (observer), U.N., UNESCO,
WEU, WHO
Legal name: Papua New Guinea
Type: Australian dependent territory with full internal autonomy (to become
independent in mid-1974)
Capital: Port Moresby
Political subdivisions: 18 administrative districts (12 in New Guinea, 6 in Papua);
New Guinea (including Bismarck archipelago and Bougainville) is a U.N. Trust
Territory
Legal system: based on English common law
Branches: executive -- Executtve Council; legislature =- House of Assembly (100
members); judiciary -- court system consists of Supreme Court of Papua New
Guinea and various inferior courts (District Courts, Local Courts, Children''s
Courts, Wardens'' Courts); Supreme Court decisions may be appealed to High
Court of Australia
Government leader: Chief Minister, Michael Somare
Suffrage: universal adult suffrage
Elections: preferential-type elections for House of Assembly every 4 years
Political parties: Pangu Party is principal political group; 5 or 6 other
small parties and numerous independents
Voting strength (1972 election): Pangu Party and allies won 52 seats, United
Party 42 seats, Independence 6 seats
Communists: no significant strength
Legal name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncion
Political subdivisions: 16 departments and the national capital, 154 municipalities
Legal system: based on Argentine codes, Roman law, and French codes; constitution
promulgated 1967; judicial review of legislative acts in Supreme Court; legal
education at National University of Asuncion and Catholic University of Our
Lady of the Assumption; does not accept compulsory ICJ jurisdiction
Branches: President heads executive; bicameral legislature; judiciary headed
a by Supreme Court
Government leader: President (General) Alfredo Stroessner
Suffrage: universal; compulsory between ages of 18-60
Elections: President and Congress elected together every 5 years; last election
held in February 1973
~ Political parties and leaders: Colorado Party, Juan Ramon Chavez; Liberal
Party (Levi-Liberal Party), Carlos Levi Ruffinelli; Febrerista Party, Manuel
Benitez; Radical Liberal Party (regular Liberal Party), Justo Pastor Benitez;
Christian Democratic Party (not officially inscribed), Dr. Hermogenes Rojas
Silva
Voting strength (February 1973 general election): 84% Colorado Party, 13% Radical
Liberal Party, 3% Liberal Party, Febrerista Party boycotted elections
Communists: Oscar Creydt faction and Miguel Angel Soler faction (both i1legal);
perhaps a few thousand party members and sympathizers in Paraguay, very
few are hard core; party in exile is small and deeply divided
Other political or pressure groups: Popular Colorado Movement (MoPoCo) led by
Epifanio Mendez Fleitas, in exile
Member of: FAO, IADB, IAEA, IBRD, ICAO, IMF, LAFTA, OAS, U.N., WHO
Legal name: Republic of Peru
Type: republic; under military regime since October 1968
Capital: Lima
Political subdivisions: 23 departments with limited autonomy plus constitutional
Province of Callao
Legal system: based on civil law system; military government rules by decree;
legal education at the National Universities in Lima, Trujillo, Arequipa,
and Cuzco; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative, judicial; congress disbanded after 3 October
1968 ouster of President Fernando Belaunde Terry
Government leader: President, General Juan Velasco Alvarado
Suffrage: obligatory for citizens (defined as adult men and women and married
persons over age 18) until age 60
Elections: none scheduled
Political parties and leaders: Christian Democratic Party (PDC), Luis Gomez
Sanchez, supports the government; opposition parties include Popular Action
Party (AP), Fernando Belaunde Terry (in exile); American Popular Revolutionary
Alliance Party (APRA), Victor Raul Haya de la Torre; and Popular
Christian Party (PPC), Luis Bedoya Reyes
Voting strength (1963 election): 39% AP-PDC, 34% APRA, 25% UNO, 1% Communist,
1% other
Communists: pro-Soviet (PCP/S) 2,000; pro-Chinese (2 factions) under 500
Other political or pressure groups: government-sponsored social mobilization
system (SINAMOS)
Member of: GATT, IADB, IAEA, ICAO, LAFTA and Andean Sub-Regional Group (created
in May 1969 within LAFTA), OAS, Seabeds Committee, U.N.
Legal name: Republic of the Philippines
Type: republic
Capital: Quezon
Political subdivisions: 70 provinces
Legal system: based on Spanish, Islamic, and Anglo-American law; parliamentary
constitution passed 1973; judicial review of legislative acts in the
Supreme Court; legal education at University of the Philippines, Ateneo
de Manila University, and 71 other law schools; accepts compulsory
ICJ jurisdiction, with reservations; currently being ruled under martial law
Branches: new constitution (currently suspended) provides for unicameral National
Assembly, and a strong executive branch under a prime minister; judicial
branch headed by Supreme Court with descending authority in a Court of
Appeals, courts of First Instance in various provinces, municipal courts in
chartered cities, and justices of the peace in towns and municipalities;
these justices have considerably more authority than do justices of the
peace in the U.S.
Government leader: President Ferdinand E. Marcos
Suffrage: universal over age 18
Elections: elections suspended for the indefinite future
Political parties and leaders: Liberal Party, Gerardo M. Roxas; Nacionalista
oy Gil J. Puyat (political parties currently in limbo because of martial
law
Communists: about 1,300 armed insurgents
Member of: ADB, ASEAN, ASPAC, Colombo Plan, ECAFE, IAEA, ICAO, IHB, Seabeds
Committee (observer), SEATO, U.N., UNESCO, UNICEF, WHO
273
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Polish People''s Republic (PRL)
Type: Communist state
Capital: Warsaw
Political subdivisions: 17 provinces, 5 city provinces, 391 districts
Legal system: mixture of Continental (Napoleonic) civil law and Communist legal
theory; constitution adopted 1952; court system parallels administrative
divisions with Supreme Court, composed of 104 justices, at apex; no
judicial review of legislative acts; legal education at 7 law schools; has
not accepted compulsory ICd jurisdiction
Branches: legislative, executive, judicial system dominated by parallel
Communist party apparatus
Government leader: Piotr Jaroszewicz, Premier; Henryk Jablonski, chairman
of Council of State (President)
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government every 4 years
Dominant political party and leader: Polish United Workers! Party (PZPR)
(Communist), Edward Gierek, First Secretary
Voting strength (1972 election): 97% voted for Communist-approved single slate
Communists: 2,270,000 party members (December 1971)
Other political or pressure groups: National Unity Front (FIN), including United
Peasant Party (ZSL), Democratic Party (SD), progovernment pseudo-Catholic
Pax Association and Christian Social Association, Catholic independent Znak
group; powerful Roman Catholic Church, Stefan Cardinal Wyszynski, Primate
Member of: CEMA, GATT, ICAO, IHB, Indochina Truce Commission, Korea Truce
Commission, Seabeds Committee, U.N. and all specialized agencies except IMF
and IBRD, Warsaw Pact, Vietnam ICCS (International Commission for Control
and Supervision)
Legal name: Republic of Portugal
Type: republic, with single legal party controlled by a Prime Minister
Capital: Lisbon
Political subdivisions: 18 districts in mainland Portugal and 4 "autonomous
districts" in Azores and Madeira Islands; 7 overseas provinces in Africa
and Asia, plus the state of Portuguese India whose 1961 occupation by
India is not recognized by Lisbon; Angota and Mozambique designated states
of Portugal in 1972
Legal system: civil law system; constitution adopted 1933, frequently amended
since; no judicial review of legislative acts; legal education at Universities
of Lisbon and Coimbra; accepts compulsory ICJ jurisdiction, with reservations
Branches: executive with President overshadowed by Prime Minister and Council of
Ministers; legislative with National Assembly dominated by executive and a
Corporative Chamber, the latter consultative and advisory; and judicial
controlled by executive branch
Government leader: Prime Minister Marcello Caetano, appointed September 1968
Suffrage: all citizens over age 21 who are literate and have not been deprived
of their civil rights
Elections: National Assembly, direct but government-controlled, held every 4 years,
latest in October 1973; local direct parish board elections held every 4 years,
next in 1975; President, by government-controlled electoral college every
7 years, latest in July 1972
Political parties and leaders: government-controlled National Popular Action
(ANP) -- formerly called National Union -- only legally recognized political
organization; insignificant Monarchist Cause group is tolerated by regime;
various opposition groups include -- Communist Party (PCP) whose secretary,
277
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Political parties and leaders (cont''d):
Alvaro Cunhal, is in exile; a dissident Communist exile group, Patriotic
Front of National Liberation (FPLN); and several small non-Communist groups
such as the moribund Democratic Social Action (ADS); Portuguese Socialist s
Action (ASP) leader Mario Soares (in erile) extremist opposition group,
League of Revolutionary Union and Action (LUAR) has been dormant since 1970,
with leader, Herminio de Palma Inacio in:exile abroad; Armed Revolutionary
Action (ARA) is radical and violence-prone group which appeared in October
1970, and has claimed credit for various sabotage acts and has ties with the
Portuguese Communist Party; self-styled Revolutionary Brigades with Maoist
orientation involved in various bombings since 1971; ASP and PCP formed
Democratic Electoral Commission (CDE) to run candidates in 1973 National
Assembly election
Voting strength (1973 election): ANP won all 150 seats in National Assembly after
opposition candidates withdrew to protect election restrictions
Communists: 2,000-7,000 est.; sympathizers cannot be determined
Other political or pressure groups: Portuguese Legion, Portuguese Youth,
Association for the Study of Economic and Social Development (SEDES)
authorized in October 1970 as a discussion group with political overtones
Member of: FAO, IAEA, IBRD, ICAO (restricted membership), LHB, ILO, IMF, ITU,
NATO, OECD, Seabeds Committee (observer), U.N., UPU, WHO, WMO
Legal name: Province of Timor
Type: overseas province of Portugal
Capital: Dili
Political subdivisions: 12 administrative townships
Legal system: based on Portuguese law
Branches: Governor appointed by overseas Minister in Lisbon, has wide local
authority; he is advised by a 12-member Consultative Council; a 21-member
Legislative Assembly (10 directly elected and 11 indirectly chosen) can pass
laws in restricted fields; Overseas Minister can veto any provincial legis-
lation or governor''s decision; judiciary based on Portuguese system
Government leader: Governor, Colonel Fernando Alves Aldea Gsainted 1972)
Suffrage: Portuguese citizen for 5 years, 21 years old
Elections: Provincial Legislative Assembly elections every 4 years, last in March
1973; National Assembly in Lisbon elections every 4 years, last in October 1973
Political parties and leaders: single party only, the National Popular Action
on Timor
Voting strength: limited to Portuguese on Timor and small group of Timorese
who fulfill requirement
Communists: prior to 1 October 1965, infiltration by Indonesian Communist Party
from Indonesian Timor, especially in the Oe-Cusse enclave
Legal name: Kingdom of Tonga
Type: constitutional monarchy
Capital: Nukualofa
Political subdivisions: 3 main island groups (Tongatapu, Haapi, Vavau)
Legal system: based on English Taw
Branches: Executive (King and Privy Council); Legislative (Legislative Assembly
composed of 7 nobles elected by their peers, 7 elected representatives of
the people, 7 Ministers of the Crown; the King appoints one of the 7 nobles
to be the speaker); Judiciary (Supreme Court, magistrate courts, Land Court)
Government leaders: King Taufa''ahau Tupou IV; Premier, Prince Tu''ipelehake
(younger brother of the King)
Suffrage: granted to all literate adults over 21 years of age who pay taxes
Elections: held triennially
Communists: none known
Member of: Commonwealth
Legal name: Trinidad and Tobago
Type: independent state since August 1962; recognizes Elizabeth II as chief
of state
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards, Tobago is 30th)
Legal system: based on English common law; constitution came into effect
1962; judicial review of legislative acts in the Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: legislative branch consists of 36-member elected House of
Representatives and 24-member Senate (13 nominated by Prime Minister,
4 by opposition leader, 7 at discretion of Governor General); executive is
cabinet led by the Prime Minister; judiciary is Supreme Court
Government leader: Prime Minister, Dr. Eric Williams
Suffrage: universal over age 21
Elections: last election 24 May 1971, PNM won all seats
Political parties and leaders: People''s National Movement (PNM), Dr. Eric
Williams; Democratic Labor Party (DLP), Alloy Lequay and Vernon Jamadar;
United National Independence Party, (UNIP) James Millette; Democratic Action
Congress (DAC), Arthur Napoleon Raymond Robinson
Voting strength (1971 election): 32.9% of registered voters cast ballots, 83.7%
PNM, 16.3% other
Communists: not significant
Other political pressure groups: Tapia House Group {headed by Lloyd Best) ;
National Youth Congress (NYC); Oilfield Workers Trade Union (OWTU), pro-
Marxist leadership; National Joint Action Committee (NJAC), antigovernment,
extremist organization, National Union of Freedom Fighters (NUFF), smal]
anti-government guerrilla organization; United Revolutionary Organization (URO) ,
Marxist-led amalgam
Member of: CARICOM, Commonwealth, GATT, IBRD, ICAO, IDB, IMF, OAS, Seabeds
Committee, U.N.
35]
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Republic of Tunisia
Type: republic
Capital: Tunis
Political subdivisions: 14 governorates (provinces )
Legal system: based on French civil law system and Islamic law; constitution
patterned on Turkish and U.S. constitutions adopted 1959; some judicial
review of legislative acts in the Supreme Court in joint session; legal
education at Institute of Higher Studies and Ecole Superieure de Droit of the
University of Tunis; has not accepted compulsory ICJ jurisdiction
Branches: executive dominant; unicameral legislative largely advisory; judicial,
patterned on French system and Koranic law
Government leader: President Habib Bourguiba; Prime Minister Hedi Nouira
Suffrage: universal over age 21
Elections: national elections held every 5 years; last elections 2 November 1969
Political party and leader: Destourian Socialist Party, Habib Bourguiba
Voting strength (1969 election): 100% Destourian Socialist Party
Communists: 100 est.; a few sympathizers; Tunisian Communist Party proscribed in
1962
Member of: Arab League, EC (association until 1974), FAO, IAEA, IBRD, ICAO, IDA,
IFC, ILO, IMCO, IMF, ITU, OAU, Seabeds Committee (observer), U.N.; UNESCO, UPU,
WHO, WMO
Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Fahri Koruturk, Naim Talu heads caretaker admini-
stration pending formation of new government
Suffrage: universal over age 21
Elections: National Assembly and Senate (1/3 of seats), Republican People''s
Party won a plurality October 1973; Presidential (1980)
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party (RPP), Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Republican Reliance Party (RRP), Turhan Feyzioglu; National Action Party
(NAP), Alparslan Turkes; Nation Party (NP), Osman Bolukbasi; Unity Party (UP),
Mustafa Timisi; Communist Party illegal; National Salvation Party (NSP),
Necmettin Erbakan
Communists: strength and support negligible
Other political or pressure groups: military forced resignation of Demirel
government in March 1971 and remains an influential force in government
355
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECD, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO $
Legal name: Republic of Uganda
Type: republic independent since October 1962
Capital: Kampala
Political subdivisions: 10 provinces and 34 districts
Legal system: based on English common law and customary law; constitution
adopted 1967; present government has abrogated some parts of constitution;
judicial review of legislative acts; legal education at Makerere University,
Kampala; accepts compulsory ICJ jurisdiction, with reservations
Branches: Gen. Amin rules by decree; assisted by Council of Ministers and Defense
Council, a group of military officers
Government leader: Gen. Idi Amin, President
Suffrage: universal adult
Elections: none scheduled by military government
Political party and leader: Uganda People''s Congress (UPC), principal party
before 1971 coup, not banned but inactive
Communists: possibly a few sympathizers
Member of: AFDB, Commonwealth, EAC, IAEA, ICAO, ILO, OAU, U.N., UNESCO, WHO
Legal name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow
Political subdivisions: 15 union republics, 20 autonomous republics, 6 krays,
116 oblasts, and 8 autonomous oblasts
Legal system: civil law system as modified by Communist legal theory; constitution
adopted 1936; no judicial review of legislative acts; legal education at 18
universities and 4 law institutes; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers (executive), Supreme Soviet (legislative), Supreme
Court of U.S.S.R. (judic','9732736aafdfa7bcce80e5e55ebbb20443024625218781d27c09eaff78b1b75c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bff48f9a6c4572d696156ec9f9c39a2497555d6d2487bbc1b645a6c33f944c5a',1974,'AU','Australia','government',54,'ial)
Government leaders: Leonid I. Brezhnev, General Secretary of the Central Committee
of the Communist Party; Aleksey N. Kosygin, Chairman of the Council of
Ministers; Nikolay V. Podgornyy, Chairman of the Presidium of the U.S.S.R.
Supreme Soviet
Suffrage: universal over age 18; direct, equal
Elections: to Supreme Soviet every 4 years; 1,517 deputies elected in 1970;
72.3% party members
Political parties and leaders: Communist Party of the Soviet Union (CPSU) only
party permitted
Voting strength (1970 election): 153,237,112 persons over 18; claimed 99.96%
voted
Communists: nearly 14,700,000 party members
Other political or pressure groups: Komsomol, trade unions, and other organi-
zations which facilitate Communist control
Member of: CEMA, Geneva Disarmament Conference, IAEA, ICAO, ILO, IMCO, ITU, U.N.,
UNESCO, UPU, Warsaw Pact, WHO, WMO, Universal Copyright Convention
Legal name: United Arab Emirates (composed of former Trucial States)
Type: federation; constitution signed December 1971, which delegated specified
powers to the United Arab Emirates central government and reserved other
powers to member sheikhdoms
Capital: Abu Zaby
Legal system: secular codes are being introduced by the U.A.E. government and
in several member sheikhdoms; Islamic law remains very influential
Branches: Supreme Council of Rulers (7 members), from which a President and Vice
President are elected; Prime Minister and Council of Ministers; National
Consultative Council; federal Supreme Court
Government leaders: Sheikh Zayid of Abu Dhabi, President; Sheikh Rashid of Dubai,
Vice President; Sheikh Maktum of Dubai, Prime Minister
Suffrage: none
Elections: none
Member states: Abu Dhabi; Ajman; Dubai; Fujairah; Ras al Khaimah; Sharjah; Umm
al Qaiwain
Member of: Arab League, U.N.
Political or pressure groups: none; a few small clandestine groups are active
Legal name: Republic of Upper Volta
Type: republic; transitional military regime in power since January 1966, will
rule until 1974
Capital: Ouagadougou
Political subdivisions: 5 departments consisting of 44 cercles
Legal system: based on French civil law system and customary law; constitution
adopted 1970; judicial review of legislative acts in Supreme Court; has not
accepted compulsory ICd jurisdiction
Branches: President is an army officer; 57-man National Assembly was elected in
December 1970; 4 year transition period will follow during which President
will rule over 16-man cabinet, one-third of which will be military; separate
judiciary
Government leader: Gen. Sangoule Lamizana, president
Suffrage: universal for adults
Elections: National Assembly elections held in late December 1970; RDA-UDV holds
38 seats, PRA 12, MLN 5, Independent 2
Political parties and leaders: 7 legally recognized parties; Voltan Democratic
Union-African Democratic Rally (UDV-RDA), Gerard Kango Ouedraogo; African
Regroupment Party (PRA), D. Pale Welte Issa; Movement for National Liberation
(MLN), Joseph Kizerbo; People''s Action Group (GAP), Nohoun Sigue; Union for
the New Voltaic Republic (UNR), Blaise Bassoleth, Party of National Regroupment
(PRN), Francois Bassolet; Party of Voltan Workers (PTV), George Kabore;
National Union of Independents (UNI), Kassoum Kargougou
Communists: no Communist party; some sympathizers
Other political or pressure groups: labor organizations are badly splintered,
students and teachers occasionally strike
Member of: ACCT, AFDB, EAMA, CEAO, ECA, ENTENTE, FAO, ICAO, ILO, ITU, Niger River
Commission, OAU, OCAM, U.N., UNESCO, WHO, WMO','1f41248159fdbb6e6325f101fc1c964733689478134e6d8c8a383157614a24ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76af020b0cf8e7fee13d70c1f418636e34dd9fd66a2a01349105389174c34297',1974,'JP','Japan','government',61,'Legal name: Territory of South-West Africa
Type: administered as part of Republic of South Africa, since a League of nations
mandate in 1920; U.N. formally ended South Africa''s mandate, and status now
in dispute
Capital: Windhoek
Political subdivisions: 10 tribal homelands, mostly in northern sector, and zone
open to white settlement with administrative subdivisions similar to a pro-
vince of South Africa
Legal system: based on Roman-Dutch law and customary law
Branches: administrator, appointee of South African Government, has jurisdiction
over zone of white settlement with white-elected Legislative Assembly handling
some local matters; white residents also elect representatives in South African
Parliament; tribal homelands are under South African Department of Bantu
Administration and Development with tribal chiefs exercising limited autonomy;
popularly elected legislative councils for Ovamboland and Kavangoland estab-
lished in August 1973
Government leader: B.J. van der Walt, Administrator
Suffrage: limited to white adults
Elections: last general election, 1970
Political parties and leaders: white parties -- National Party (NP), led in
South-West Africa by A. H. du Plessis; United National South-West Party
(UNSWP), J. P. Niehaus; nonwhite parties -- South-West Africa People''s
Organization (SWAPO), almost exclusively based on Ovambo tribe led by Sam
Nujoma, in exile; South-West Africa National Union (SWANU), primarily based
on Herero tribe, leaders in exile; National Unity Democratic Organization
(NUDO), primarily based on Herero tribe led by Clements Kapuuo
Voting strength: NP (1970 election) won all 10 seats in Republic legislature
and all 18 seats in South-West Africa Legislative Assembly
Communists: no Communist Party, but some influence by South African Communists
and other Communists on South-West African Bantu outside territory
321
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Other political or pressure groups: National Convention, an alliance of 10 non-
white parties arid other groups that oppose separate development for tribal
homelands 7
Fs Legal name: (The) Spanish State
Type: nominally a monarchy, but without a king; actually an authoritarian regime
under Generalissimo Franco with Prince Juan Carlos designated to succeed him
as chief of state and become king
Capital: Madrid
< Political subdivisions: metropolitan Spain, including the Canaries and Balearics,
. divided into 50 provinces with governors appointed by the central government;
also 1 province and 5 places of sovereignty (presidios) in Africa; Ifni
province ceded by Spain to Morocco in June 1969; 2 former provinces com-
prising Equatorial Guinea were granted independence in October 1968
Legal system: civil law system, with regional applications of customary law;
7 basic laws including Organic Law of the State of January 1967 serve as
a constitution; legal education at 14 schools of Jaw; does not accept
compulsory ICJ jurisdiction
Branches: executive, with chief of government dominating all branches of
government through his appointive powers and authority to legislate by
decree; legislative with unicameral Cortes dominated by executive; judicial,
independent in principal but generally limited to interpretation of laws
Government leader: Generalissimo Francisco Franco -- Chief of State, commander
in Chief of the armed forces, and head of the National Movement (formerly
called the Falange)
Suffrage: universal in national referendums, over age 21
Elections: only two types of direct election other than referendum provided:
representatives to municipal councils for which only heads of households
vote (latest election November 1973) and, under new constitutional law of
1967, 104 members of the Cortes elected by heads of households and married
rs women for a 4-year term (last election September 1971)
323
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Political parties and leaders: National Movement only legally recognized party,
headed by Franco; Torcuato Fernandez Miranda, minister~secretary general of
the movement; various semiclandestine opposition groups include -- Christian
Democratic factions under Jose Maria Gil Robles and Joaquin Ruiz Gimenez;
the Socialists are split into the "old guard" under exiled Secretary General,
Rodolfo Llopis, the "Young Turks" and the "Internal Socialists" under Enrique
Tierno Galvan; the Anarchists; Republicans; Monarchists; smaller regional and
national splinter groups; the Communist Party, whose secretary general,
Santiago Carrillo Sotares, is in exile and is challenged by a small dissident .
pro-Soviet faction led by exiled Enrique Lister Forjan; and some small pro-
Chinese Communist groups which appear and disappear under varying names
Voting strength: 561 seats, but somewhat fewer members as some hold more than one
seat -- 19% representing the family elected directly; 45% representing
municipalities, syndicates, and professions elected indirectly under close
regime control; and 36% are appointed by regime or are ex officio
Communists: (inside and outside Spain, est.) 5,000; sympathizers up to 20,000
Other political or pressure groups: the state-controlled organization of
syndicates, comprising representatives of management and labor, an illegal
labor group called the Workers'' Commissions, the Catholic Church, business
and land owning interests, Opus Dei, Catholic Action, university students
Member of: FAQ, IAEA, IBRD, ICAO, ILO, IHB, IMF, ITU, OECD, Seabeds Committee
(observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Province of Sahara
Type: province of Spain, subordinate to Ministry of the Presidency
Capital: El Aaiun
Political subdivisions: two regions -- Rio de Oro and Saguia e] Hamra
Legal system: based on Spanish civil law system and customary law
Branches: Provincial Council; 80 members, of whom half are elected natives
Government leader: Governor General responsible to Directorate General of the
Promotion of the Sahara (a division of the Ministry of the Presidency),
Br. Gen. Fernando de Santiago y Diaz de Mendivil
Suffrage: heads of families only
Elections: 40 members of Provincial Council, August 1967; half of municipal
councillors May 1969
Political party: National Movement
Communists: party proscribed; Communist sympathizers, few (if any)
Other political or pressure groups: none
Legal name: Republic of Sri Lanka
Type: independent state since 1948
Capital: Colombo
Political subdivisions: 9 provinces, 22 administrative districts, and four
categories of semiautonomous elected local governments
Legal system: a highly complex mixture of English common law, Roman-Dutch,
Muslim and customary law; new constitution 22 May 1972; no judicial review
of legislative acts; legal education at Sri Lanka Law College and University
of Sri Lanka, Peradeniya; has not accepted compulsory ICJ jurisdiction
Branches: unitary parliamentary form of government; unicameral legislature
and independent judiciary
Government leader: Prime Minister Sirimavo Bandaranaike
Suffrage: universal over age 18, but most Indian Tamils, who comprise 10.6% of
population, are not enfranchised
Elections: national elections, ordinarily held every 6 years; must be held more
frequently if government loses confidence vote; last election held May 1970,
but new constitution postpones deadline for next election until May 1977
Political parties and leaders: Sri Lanka Freedom Party, Sirimavo Ratwatte Dias
Bandaranaike, President; Lanka Sama Samaja Party (Trotskyite), N. M. Perera,
President; Tamil United Front, S. J. V. Chelvanayakam, leader; United national
Party, J. R. Jayewardene, General Secretary; Communist Party/Moscow, S. A.
Wickremasinghe, General Secretary; Communist Party/Peking, N. Shanmugathasan,
General Secretary; Mahajana Eksath Peramuna (People''s United Front), M. B.
Ratnayaka, President
Voting strength (1970 election): 37% Sri Lanka Freedom Party, 38% United
National Party, 9% Lanka Sama Samaja Party, 3.5% Communist Party/Moscow,
5% Federal Party, minor parties and independents accounted for remainder
Communists: approximately 169,000 voted for the Communist Party in the May 1970
general election; Communist Party/Moscow approximately 2,000, Communist
Party/Peking 532 (1968 est.)
329
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Other political or pressure groups: Buddhist clergy, Sinhalese Buddhist lay
groups; far-left violent revolutionary groups; labor unions
Member of: ADB, Colombo Plan, Commonwealth, FAQ, TAEA, IBRD, ICAO, IDA, IFC, ILO,
IMCO, IMF, ITU, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO .
Legal name: Democratic Republic of the Sudan
Type: republic under military control since coup in May 1969
Capital: Khartoum
Political subdivisions: 9 provinces, provincial and local administrations
controlled by central government; limited regional autonomy in 3 southern
provinces
Legal system: based on English common law and Islamic law; some separate
religious courts; permanet constitution promulgated April 1973; Revolutionary
Command Council established in 1969 dissolved in October 1971 with the in-
stallation of Ja''far al-Numayrias president and chief executive; Numayri has
reorganized government through a series of Republican decrees; legal education
at University of Khartoum and Khartoum extension of Cairo University at
Khartoum; accepts compulsory ICJ jurisdiction, with reservations
Government leader: President and Prime Minister Ja''far al-Numayri
Suffrage: universal adult
Elections: parliamentary elections, first after 6 years of military rule held
in April and May 1965 in 6 northern provinces; latest elections in April
1968; presidential plebescite held in September 1971 elections to constituent
assembly held in September-October 1972; elections for southern regional
assembly scheduled for November 1973
Political parties and leaders: all parliamentary political parties outlawed since
May 1969; the ban on the Sudan Communist Party was not enforced until after
abortive coup in July 1971; the government''s mass political organization, the
Sudan Socialist Union, was formed in January 1972
Voting strength: not tabulated by party
Communists: party decimated following July 1971 coup and counter-coup, several
top leaders including Secretary-General Mahjub executed; actual hard-core
membership down to lowest point in years; party control over labor unions,
professional groups and university student groups ended; Communists purged
from government; party is being reorganized underground under leadership of
Secretary-General Muhammad Nujud, 35,000 CP members
331
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
GOVERNMENT (cont''d):
Other political or pressure groups: Ansar Muslim sect, at odds with the military
regime since the May coup, defeated in fighting in spring 1970; Sudan Opposition
Front, composed of former political party elements and other disgruntled
conservative interests, operates in exile
Member of: AFDB, Arab League, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
Seabeds Committee, U.N., UPU, WMO
Legal name: Surinam
Type: territory within Kingdom of the Netherlands, enjoying complete domestic
autonomy
Capital: Paramaribo
Political subdivisions: 9 districts, each headed by district commissioner
responsible to Minister of Internal Affairs
Legal system: Dutch civil law system; country statute of 1955 serves as
constitution
Branches: Council of Ministers headed by a Minister-President, which constitutes
the Cabinet; 39-member legislative council (Staten) popularly elected for
4-year term; court system administered by Attorney-General under Minister
of Justice and Police
Government leader: Minister-President, Jules Sedney (defeated in November 1973
election; continues to serve until successor is designated)
Suffrage: universal over age 23
Elections: every 4 years or earlier upon request of Minister-President; latest
held November 1973 won by National Party Combination (NPK), a creole-based
election coalition in which the National Party of Surinam (NPS) is the
largest party
Political parties and leaders: National Party of Surinam (NPS), Hendrick A. E.
Arron; United Hindustani Party (VHP), J. Lachmon; Progressive National Party
(PNP), Frank E. Essed; Surinam Democratic Party (SDP), B. F. J. Oostburg;
United Indonesian People''s Party (SRI), F. Karsowidijojo; Javanese Farmers''
Party (KTPI), H. I. Soemita; Nationalist Republic Party (PNR), Edward Bruma
(principal leftist party); United Peoples Party (VVP), led by apolitical or
Chinese businessmen
Voting strength (1973 prelim.): NPK 22 seats, VHP 17
Communists: no overt Communist Party; PNP believed to have Communist sympathizers
Member of: EC (associate), WHO
333
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Kingdom of Swaziland
Type: monarchy, under King Sobhuza II; independent member of
Commonwealth since September 1968
Capital: Mbabane (administrative), Lobamba (royal and legislative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-Dutch law in statutory courts, Swazi
traditional law and custom in traditional courts; legal education at University
of Botswana, Lesotho, and Swaziland (located in Lesotho); has not accepted
compulsory ICJ jurisdiction
Branches: in April 1973 King abolished the constitution, dismissed parliament, and
assumed personal rule; he intends ruling under a King-in-Council arrangement
with the cabinet being retained as an advisory council; former members of
parliament continue to receive their salaries and new constitution probably
will be drawn up later
Government leader: Head of State and government King Sobhuza II; Prime Minister
Makhosini Diamini
Suffrage: universal for adults
Elections: first elections for Legislative Council held in June 1964; latest for
House of Assembly in May 1972
Political parties and leaders: Imbokodvo, the traditionalist party, controlled
by King Sobhuza II; the opposition Ngwane National Liberatory Congress
(NNLC), Ted by Dr. Ambrose Zwane, has been dissolved
Voting strength: in 1972 elections, Imbokodvo won 21 seats, NNLC won 3 seats in
the House of Assembly
Communists: no Communist Party
Member of: AFDB, OAU, U.N.
Legal name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 provinces, 624 communes, 224 towns
Legal system: civil law system influenced by customary law; Acts of 1809, 1810,
1866, and 1949 serve as constitution; legal education at Universities of
Lund, Stockholm, and Uppsala; accepts compulsory ICJ jurisdiction, with
reservations
Branches: legislative authority rests jointly with Crown and parliament
(Riksdag); executive power vested in Crown but exercised by cabinet
responsible to parliament; Supreme Court, 6 superior courts, 108 lower courts
Government leaders: King Carl XVI Gustaf; Prime Minister Olof Palme
Suffrage: universal, but not compulsory, over age 20
Elections: every 3 years (next in September 1976)
Political parties and leaders: Moderate Coalition (conservative), Gosta Bohman;
Center, Thorbjorn Falldin; Liberal, Gunnar Helen; Social Democratic, Olof
Palme; Communist, Car]-Henrik Hermansson; Communist League of Marxists-Leninists
(KFML), Gunnar Bylin
Voting strength (1973 election): 14.3% Moderate Coalition, 25.0% Center, 9.4%
Liberal, 43.7% Social Democratic, 5.3% Conmunist, 2.3% other
Communists: 17,000; a number of sympathizers as indicated by the 274,929
Communist votes cast in 1973 elections; an additional 8,014 votes cast for
Maoist KFML
Member of: Council of Europe, EC (Free Trade Agreement) , EFTA, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFC, IMB, ILO, IMCO, IMF, ITU, Nordic Council, OECD,
Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Swiss Confederation
Type: federal republic
Capital: Bern
Political subdivisions: 22 cantons (3 divided into half cantons)
Legal system: civil law system influenced by customary law; constitution adopted
1874, amended since; judicial review of legislative acts, except with
respect to Federal decrees of general obligatory character; legal education
at Universities of Bern, Geneva and Lausanne, and four other university
schools of law; accepts compulsory ICJ jurisdiction, with reservations
Branches: bicameral parliament has legislative authority; federal council
(Bundesrat) has executive authority; justice left chiefly to cantons
Government leader: Roger Bonvin (1-year term as president begins on January 1973),
President
Suffrage: universal over age 20
Elections: held every 4 years; next elections 1975
Political parties and leaders: Social Democratic Party (SPS), Arthur Schmid,
president; Radical Democratic Party (FDP), Henri Schmitt, president;
Christian Conservative People''s Party (CVP), Franz Josef Kurmann, president;
Farmer, Artisan, and Middle Class Party (BGB), Hans Conzett, president;
Communist Party (PdA), Jean Vincent, leading Secretariat member; Republican
Movement (REP)-National Action (N.A.), James Schwarzenbach
Voting strength (1971 election): 49 seats FDP, 44 seats CVP, 46 seats SPS, 23
seats BGB, 5 seats PdA, 4 seats N.A., 7 seats REP, 22 seats others
Communists: 3,500; 50,831 votes in 1971 election
Member of: Council of Europe, EFTA, FAO, IAEA, ICAO, OECD, U.N. (permanent
observer), WHO, WMO
Legal name: Syrian Arab Republic
Type: republic; under left-wing military regime since March 1963
Capital: Damascus
Political subdivisions: 13 provinces and city of Damascus administered as
separate unit
Legal system: based on Islamic law and civil law system; special religious courts;
constitution promulgated in 1973; legal education at Damascus University and
University of Aleppo; has not accepted compulsory ICJ jurisdiction
Branches: executive powers vested in President and Council of Ministers; legis-
lative power rests in the People''s Assembly (election pending) ;
seat of power is the Ba''th Party Regional (Syrian) Command
Government leaders: President Hafiz Al-Asad
Suffrage: universal at age 18
Elections: no electoral laws being drafted; last elections in December 1961;
presidential referendum in 1971; local councils elected in March 1972,
assembly elections pending
Political parties and leaders: ruling party is the Arab Socialist Resurrectionist
(Ba''th) party; a "national front" cabinet formed in March 1972, dominated by
Ba''thists, includes independents and members of the Syrian Arab Socialist
Party (ASP), Arab Socialist Union (ASU), and Syrian Communist Party (SCP)
Communists: mostly sympathizers, numbering 10,000 to 13,000
Other political or pressure groups: non-Ba''th parties have little effective
political influence; Communist Party ineffective, greatest threat to Ba''thist
regime lies in factionalism in Ba''th Party itself; conservative religious
leaders
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: United Republic of Tanzania
Type: republic; single parties dominate both on the mainland and on Zanzibar
Capital: Dar es Salaam
Political subdivisions: 22 regions -- 18 on mainland, 4 on Zanzibar islands
Legal system: based on English common law, Islamic law, customary law, and German
civil law system; interim constitution adopted 1965, judicial review of
legislative acts limited to matters of interpretation; legal education at
University College, Dar es Salaam; has not accepted compulsory ICd jurisdiction
Branches: President Julius Nyerere has full executive authority on the mainland;
National Asssembly dominated by Nyerere and the Tanganyika African National
Union (TANU), consists of 120 elected members, 18 ex officio members, and up
to 25 appointed members from mainland, and 3 ex officio members and up to 52
appointed members from Zanzibar; First Vice President Aboud Jumbe and the
Revolutionary Council still run Zanzibar despite the efforts of Nyerere to
integrate the islands into the political system of the mainland
Government leader: President Julius Nyerere
Suffrage: universal adult
Political party and leaders: Tanganyika African National Union (TANU), only main-
land political party, dominated by Nyerere with Prime Minister and Second
Vice President Rashidi Kawawa as his top lieutenant; Afro-Shirazi Party, the
only party in Zanzibar, is supposed to merge with TANU eventually
Voting strength (October 1970 national elections): 5 million registered voters;
Nyerere received 95% of 3.6 million votes cast
Communists: a few Communists and sympathizers
Member of: AFDB, Commonwealth, EAC, FAO, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU,
OAU, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
343
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Legal name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions: 71 centrally controlled provinces
Legal system: based on civil law system, with influences of common law; new
constitution promulgated in 1968, suspended 17 November 1971; provisional
constitution promulgated December 1972; legal education at Thammasat
University; has not accepted compulsory ICJ jurisdiction
Branches: King is head of state with nominal powers; Prime Minister heads a
22-man cabinet; National Assembly unicameral and appointed by executive
branch; judiciary relatively independent except in important political
subversive cases
Government leaders: King Phumiphon Adundet; Sanya Thammasak, Prime Minister;
Sukit Nimmanhemin, Deputy Prime Minister
Suffrage: universal
Elections: expected within 3-6 months
Political parties and leaders: dissolved under the revolutionary order 17
November 1971 but may be reestablished at time of new elections
Communists: strength of illegal Communist Party is about 1,000; Thai Communist
insurgents throughout Thailand total about 5,500
Other political or pressure groups: none
Member of: ADB, ASA, ASEAN, ASPAC, Colombo Plan, ECAFE, FAO, IAEA, ICAO, IDA,
IFC, IHB, ILO, ITU, Seabeds Committee, SEAMES, SEATO, U.N., UNESCO, UNICEF,
UPU, WHO, WMO
Legal name: Togolese Republic
Type: republic; under military rule since January 1967
Capital: Lome
Political subdivisions: 19 circumscriptions
Legal system: based on French civil law and customary practice; no constitution;
has not accepted compulsory ICJ jurisdiction
Branches: military government, with civilian participation in the cabinet, took
over on 14 April 1967, replacing provisional government created after
January coup; no legislature; separate judiciary including State Security
Court established 1970
Government leader: Maj. Gen. Etienne Eyadema, President
Suffrage: universal adult
Elections: presidential referendum of January 1972 elected Etienne Eyadema for
indefinite period
Political parties: single party formed by President Eyadema in September 1969,
Rassemblement du Peuple Togolais, structure and staffing of party closely
controlled by government
Communists: no Communist Party; possibly some sympathizers
Member of: ACCT, AFDB, EAMA, ECA, ENTENTE, FAQ, IBRD, ICAQ, ILO, IMF, ITU,
OAU, OCAM, U.N., UNESCO, UPU, WHO, WMO','2ad961a8e1e7611c2e33b2071992a0f7a1e32fd5f8b70d4774ab9d28eb65568e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8745b92fec83326e131c799ba36e5542fe9dbe5666b400159b79e0af164c433',1974,'US','United States','government',66,'Legal name: United States of America
Legal system: based on English common law; dual system of courts, state and
federal; constitution adopted 1789; judicial review of legislative acts;
accepts compulsory ICJ jurisdiction, with reservations
Voting strength (1972 presidential election): Republican Party (Nixon) 5
45 ,767 ,000; Democratic Party (McGovern) 28,358,000; minor parties, 1,121,000
Communists: Party membership » 10,000-11 ,000 (est.); General Secretary, Gus Hall
Member of: ADB, ANZUS, CENTO, Colombo Plan, FAO, GATT, IAEA, IBRD, ICAO, IDA,
IDB, IFC, ILO, IMCO, IMF, ITU, NATO, OAS, OECD, SEATO, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO','6b8cdb81b51feb543bbca6a9b591452559baf7e5b983cc334f78e33d4701011a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba0bfdbcbdaa5336ef2a6ed519576fde90b6ee157d76c57cc5c665ed7e7234a8',1974,'','','government',3,'Legal name: Republic of Afghanistan
Type: republic
Capital: Kabul
» Political subdivisions: 28 provinces with centrally appointed governors
Legal system: based on Islamic law; constitution nullified July 1973; independent
judiciary also abolished and powers transferred to the Council of Justice,
chaired by Minister of Justice; legal education at University of Kabul;
has not accepted compulsory ICJ jurisdiction
2 Branches: Parliament abolished July 1973; all powers of the parliament and the
monarchy transferred to the President
Government leaders: President Mohammad Daud who also serves as prime minister,
foreign minister, and defense minister; Naim Khan, Daud''s brother and
personal adviser; young, mostly unidentified, military officers serving
on the ruling Central Committee
Suffrage: universal over age 20
Elections: promised but no date set
Political parties and leaders: no political parties permitted
Communists: there are 2 pro-Moscow Communist groups, with about 350-500 active
members; several other groups, further to left, with several hundred members
and sympathizers
Other political or pressure groups: with the mullahs and the military supporting
the new government, no known organized opposition
Member of: ADB, Colombo Plan, FAO, FUND, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO,
IMF, ITU, U.N., UNESCO, UPU, WHO, WMO
Legal name: People''s Republic of Albania
Type: Communist state
Capital: Tirane
Political subdivisons: 27 rethet (districts), including capital, 200 localities,
2,600 villages
Legal system: based on Soviet law; constitution adopted 1950; judicial review
of legislative acts only in the Presidium of the People''s Assembly, which
is not a true court; legal education at State University of Tirane; has not
accepted compulsory ICJ jurisdiction
Branches: People''s Assembly, Council of Ministers, judiciary
Government leaders: Chairman of Council of Ministers, Mehmet Shehu; President,
Presidium of the People''s Assembly, Haxhi Lleshi
Suffrage: universal and compulsory over age 18
Elections: national elections theoretically held every 4 years; last elections
December 1973
Political parties and leaders: Albanian Workers Party only; First Secretary,
Enver Hoxha
Voting strength (1973 election); 99.9% Communist
Communists: 75,637 party members (1970)
Member of: CEMA, IAEA, ILO, ITU, U.N., UNESCO, UPU, WHO, WMO; has not participated
in CEMA since rift with U.S.S.R. in 1961; officially withdrew from Warsaw Pact
13 September 1968','d698efdc0982ac3d846762d5badb7236ccdc062c1a557cfc3263b21f678db459','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af90f693c5c942d97d3e17db7f85c7da2c469fca3fce4e49dd8197e6a335abd6',1974,'DZ','Algeria','government',8,'Legal name: Democratic and Popular Republic of Algeria
Type: republic
Capital: Algiers
Political subdivisions: 15 Wilayas (departments or provinces)
Legal system: based on French and Islamic law, with socialist principles;
constitution adopted by referendum 1963 but suspended since June 1965;
judicial review of legislative acts in ad hoc Constitutional Council composed
of various public officials, including several Supreme Court justices; Supreme
Court divided into 4 chambers; legal education at Universities of Algiers,
Oran and Constantine; has not accepted compulsory ICJ jurisdiction
Branches: executive dominant, unicameral legislature has not met since June
1965 coup d''etat but was never formally suspended, judiciary
Government leader: Houari Boumediene, President of Council of the Revolution
and President of the Council of Ministers, overthrew elected President
Ahmed Ben Bella 19 June 1965
Suffrage: universal over age 19
Elections: presidential 15 September 1963; departmental assemblies 25 May 1969;
local councils 14 February 1971
Political parties and leaders: National Liberation Front (FLN)
Voting strength (1963 election): 100% FLN
Communists: 400 (est.); Communist Party illegal (banned 1962)
Member of: Arab League, FAQ, IAEA, IBRD, ICAO, IDA, ILO, IMCO, IMF, ITU, OAU,
OPEC, U.N., UNESCO, UPU, WHO
Legal name: Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law, substantially modified by indigenous
concepts; constitution adopted 1937; judicial review of legislative acts in
Supreme Courts; has not accepted compulsory ICJ jurisdiction
Branches: elected President; bicameral parliament reflecting proportional and
vocational representation; judiciary appointed by President on advice of
Government leaders: (President) Erskine Childers, Taoiseach (Prime Minister)
Liam Cosgrave; Tanaiste (Deputy Prime Minister) Brendan Corish
Suffrage: universal over age 18
Elections: Dail (lower house) elected every 5 years -- last election February
1973; President elected for 7-year term -- last election May 1973
Political parties and leaders: Fianna Fail, John (Jack) Lynch; Labor Party,
Brendan Corish; Fine Gael, Liam Cosgrave; Communist Party of Ireland,
Michael O''Riordan
Yoting strength: (1973 election) Fianna Fail 46% (69 seats), Fine Gael 35% (54
seats), Labor Party 14% (19 seats), other 5%; Independents hold 2 seats
Communists: approximately 300
Member of: Council of Europe, EC, FAO, IBRD, ICAO. ILO, IMCO, IMF, ITU, OECD, U.N.,
UNESCO, UPU, WHO, WMO','a2aec89b127ae9bd939fcb9d0023b368e5804fddebd6a665ccfa2aa2ee157730','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99656d736f424413ff4d44b9c7bc4c8a2b2482d64926cc218a68ddb08ce7936a',1974,'AD','Andorra','government',12,'Legal name: The Valleys of Andorra
Type: unique coprincipality under formal sovereignty of President of France and
Spanish Bishop of Seo de Urgel, who are represented locally by officials
called veguers
Capital: Andorra
Political subdivisions: 6 districts -- Andorra la Vella, Sant Julia de Loria,
Encamp, Canillo, La Massana, and Ordino
Legal system: based on French and Spanish civil codes; Plan of Reform adopted
1866 serves as constitution; no judicial review of legislative acts; has
not accepted compulsory ICJ jurisdiction
Branches: legislature (General Council) of 24 members with one-half elected
every 2 years for 4-year term; executive -- syndic and a deputy sub~-syndic
chosen by General Council for 3-year terms; judiciary chosen by coprinces
who appoint 2 civil judges, a judge of appeals, and 2 Batles (court
prosecutors }
Suffrage: males of 21 or over who are third generation Andorrans vote for
General Council members; same right granted to women in April 1970
Elections: half of General Council chosen every 2 years, last election December
1973
Political parties and leaders: no political parties but only partisans for
particular independent candidates for the General Council, on the basis of
competence, personality and orientation toward Spain or France; various smal]
pressure groups developed in 1972
Communists: none known','5ad97023a74a23c2cfbc06819717f02a164a6a0b00e214c25d3fbdc71d39551f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01e3c1a7914c995b75583612e952210d6bf10f33d22c6aa3482ae1b1593142f7',1974,'AO','Angola','government',16,'Legal name: State of Angola
Type: overseas state of Portugal
Capital: Luanda
Political subdivisions: 16 administrative districts including the coastal
exclave of Cabinda
Legal system: Portuguese civil codes and customary law; legal education
obtained in Portugal
Branches: Governor General appointed by Ministry of Overseas in Lisbon is
executive officer responsible for internal administration; he also has
prescribed legislative functions which he shares with Legislative Assembly
of directly and indirectly elected members; all action in state may be
vetoed by Minister of Overseas; independent judiciary
Government leader: Governor General Fernando Santos e Castro
Suffrage: all adults able to read and write Portuguese and in full possession
of political and civil rights
Elections: Legislative Assembly elections held every 4 years; last held March 1973
Political parties and leaders: only legal group is Portuguese National Popular
Action (ANP), formerly the National Union (UN), headed by Gustavo Neto Miranda
Other political or pressure groups: principal opposition groups which are
carrying out insurgency are Revolutionary Government of Angola in exile
(GRAE), led by Holden Roberto; Popular Movement for the Liberation of Angola
(MPLA), Ted by Agostinho Neto; and National Union for the Total Independence
of Angola (UNITA), led by Jonas Savimbi
Communists: none known','bc23979876900c2243189492c81f867453fd1f6b43f987bdf1941f7fc70cd994','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc4d905b8c8c6297b00eba0bd50b622c537bfd57cb571617440f223d0cdaa566',1974,'BR','Brazil','government',20,'Legal name: State of Antigua
Type: dependent territory with full internal autonomy as a British “Associated
State"
Capital: St. Johns
Political subdivisions: 6 parishes, 2 dependencies (Barbuda, Redonda)
Legal system: based on English laws; British Caribbean Court of Appeal has
exclusive original jurisdiction and an appellate jurisdiction, consists of
Chief Justice and 5 justices
Branches: legislative, 21-member popularly elected House of Representatives;
executive, prime minister and cabinet
Government leaders: Prime Minister George Herbert Walter; Governor Wilfred
Ebenezer Jacobs
Suffrage: universal suffrage age 21 and over
Elections: every 5 years; last general election 11 February 1971; last by-election
August 1968
Political parties and leaders: Antigua Labor Party (ALP), Vere C. Bird;
Progressive Labor Movement (PLM), George Herbert Walter; Antigua People''s
Party (APP), J. Rowan Henry
Voting strength: 1971 election -- House of Representative seats -- ALP 4, PLM 13
Communists: none known
Other political or pressure groups: Afro-Caribbean Movement (ACM), a small black
nationalist group led by Timothy Hector; Antigua Freedom Fighters (AFF). a
small black radical group, leaders unknown
Member of: has been invited to join CARICOM
Legal name: Republic of Bolivia
Type: republic; de facto military-civilian coalition government
Capital: La Paz (seat of government); Sucre (judicial capital)
Political subdivisions: 9 departments with limited autonomy
Legal system: based on Spanish law and Code Napoleon; constitution adopted 1967;
constitution in force except where contrary to dispositions dictated by
governments since 1969; legal education at University of San Andres and
several others; has not accepted compulsory ICJ jurisdiction
Branches: executive; congress of two chambers (Senate and Chamber of Deputies),
congress disbanded after 26 September 1969 ouster of President Siles;
judiciary
Government leaders: President Hugo Banzer Suarez
Suffrage: universal and compulsory at age 18 if married, 21 if single
Elections: postponed indefinitely
Political parties and leaders: Nationalist Revolutionary Movement (MNR) Ciro
Humboldt and Victor Paz Estenssoro (in exile); Bolivian Socialist Falange (FSB)
Mario Gutierrez; other political parties, although numerous, exert little
influence; activist groups include the Nationalist Leftist Revolutionary Party
(PRIN) Juan Lechin Oquendo (in exile), Socialist Party (PS) Marcelo Quiroga and
Alberto Baily (in exile), and Leftist Revolutionary Movement (MIR) Pablo Ramos
Sanchez (in exile); more moderate parties include the Authentic Revolutionary
Party (PRA) Walter Guevara Arze, Popular Christian Movement (MPC) Hugo Bozo,
Leftist Revolutionary Party (PIR) Ricardo Anaya, Social Democratic Party (PSD)
Hugo Sandoval, and Christian Democratic Party (PDC) Benjamin Miguel
Voting strength (1966 elections): Frente de la Revolucion Boliviana (a coalition
composed of the MPC, PIR, PRA, PSD, and two interest groups, the campesinos
and Chaco War Veterans) 61%, FSB 12%, MNR 10%, other 17%
Communists: three parties; PCB/Soviet led by Jorge Kolle Cueto, about 1,500
members; PCB/Chinese led by Oscar Zamora, 500 members (est.); POR (Trotskyist),
about 200 members divided between three factions led by Hugo Gonzalez Moscoso,
Guillermo Lora Escobar, and Amadeo Arze
Member of: IAEA, IADB, ICAO, International Tin Council, LAFTA and Andean
Sub-Regional Group (created in May 1969 within LAFTA), OAS, U.N.
37
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: Federative Republic of Brazil
Type: federal republic; military-backed presidential regime since April 1964
Capital: Brasilia
“ Political subdivisions: 22 states, 4 territories, federal district (Brasilia)
Legal system: based on Latin codes; dual system of courts, state and federal;
constitution adopted 1967 and extensively amended in 1969; has not accepted
compulsory ICJ jurisdiction
Branches: strong executive with very broad powers; bicameral legislature
‘s (powers of the two bodies have been sharply reduced); 11~man Supreme Court
Government leader: President Ernesto Geisel
Suffrage: compulsory over age 18, except illiterates and those stripped of their
political rights; approximately 30 million registered voters in October 1970
Elections: President Medici''s successor was chosen by a 505-member electoral
college, composed of the members of Congress and delegates selected from the
state legislatures, on 15 January 1974 and took office on 15 March 1974;
Geisel was the choice of Medici and top military chiefs
Voting strength: (November 1970 congressional elections): 46% ARENA, 25% MDB,
28.5% blank and void
Political parties and leaders: National Renewal Alliance (ARENA), pro-government
Petronio Portella, president; Brazilian Democratic Movement (MDB), opposition,
Ulisses Guimaraes, president
See less than 6,000, with less than 3,000 militants; 100,000 sympathizers
est.
Other political or pressure groups: excepting the military, the Catholic Church
is the only active nationwide pressure group, however, divisions within the
Church often prevent it from speaking with one voice; labor and student
groups have almost no influence on the government
: Member of: FAQ, GATT, IADB, IAEA, IBRD, ICAO, IHB, ILO, IMCO, IMF, ITU, LAFTA,
OAS, Seabeds Committee, U.N., UNESCO, UPU. WHO, WMO
Legal name: British Solomon Islands Protectorate
Type: British protectorate administered as crown colony
Capital: Honiara
Political subdivisions: 4 administrative districts
Legal system: a High Court plus Magistrates Courts, also a system of native
courts throughout the islands
Branches: executive authority in High Commissioner; a legislative Governing
Council] of 24 elected members
Government leader: High Commissioner M. C. Luddington
Suffrage: Universal age 21 and over
Elections: every 4 years, latest May-June 1973
Political parties and leaders: United Solomon Islands Party, Benedict Kinika,
Chairman
Legal name: State of Brunei
Type: British protectorate; constitutional sultanate
Capital: Bandar Seri Begawan
Political subdivisions: 4 administrative districts
Legal system: based on Islamic law; constitution promulgated by the Sultan in
Branches: chief of state is Sultan (advised by appointed Privy Council) who
appoints Executive Council and Legislative Council
Government leader: Sultan Hassanal Bolkiah
Suffrage: universal age 21 and over; 3-tiered system of indirect elections;
popular vote cast for lowest level (district councilors)
Elections: last elections -- March 1965; further elections postponed indefinitely
Political parties and leaders: antigovernment People''s Independence Front
(Baker), Pengiran Dato Ali, chairman
Communists: information not available
LAND:
440,000 sq. mi.; settled area 28% consisting of cropland
and fallow 5%, pastures 14%, woodland, swamps, and
water 6%, urban and other 3%; unsettled area 72% --
mostly forest and savannah 3
Land boundaries: 3,750 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,500 mi.
Legal name: Republic of Colombia
Type: republic; executive branch dominates government structure
Capital: Bogota
Political subdivisions: 22 departments, 4 territorial districts, 4 special
districts, 1 federal district
Legal system: based on Spanish laws religious courts regulate marriage and
divorce; constitution decreed in 1886, amendments codified in 1946; judicial
review of legislative acts in the Supreme Court; accepts compulsory ICd
jurisdiction, with reservations
Branches: President, bicameral legislature, judiciary
Government leader: President Misael Pastrana, leaves office 7 August 1974
Suffrage: universal over age 21
Elections: every fourth year; last presidential and congressional elections
April 1974; municipal and departmental elections, April 1972
Political parties and leaders: Liberal Party, President-elect Alfonso Lopez
Michelsen; Conservative Party, Alvaro Gomez Hurtado; National Popular Alliance
(ANAPO), General Gustavo Rojas Pinilla, Maria Eugenia Rojas de Moreno
Voting strength: 1974 presidential election--Alfonso Lopez Michelsen 55%,
Alvaro Gomez Hurtado 32%, Maria Eujenia Rojas de Moreno 9.5%; 1974 congressional
election--Senate: Liberal Party 59%, Combined Conservative Party 34%, ANAPO 6.2%;
Chamber of Deputies: Liberal Party 56%, Combined Conservative Party 31%, ANAPO
9.5%; abstention by approximately 50% of eligible voters
Communists: 3,000-5,000
Other political or pressure groups: Communist Party (PCC), Gilberto Vieira White;
PCC/ML, Chinese Line Communist Party, led by Pedro Lupo Leon Arboleda Roldan
Member of: FAO, IADB, IAEA, IBRD, ICAO, IFC, IHB, ILO. IMF. ITU, LAFTA and
Andean Sub-Regional Group (created in May 1969 within LAFTA), OAS, U.N.,
UNESCO, UPU, WHO, WMO
69
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
COMORO ISLANDS
LAND:
838 sq. mi.; 4 main islands; forests 16%, pasture 7%,»
cultivable area 48%, non-cultivable area 29%
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 211 mi.
Legal name: Overseas Territory of the Comoro Islands
Type: overseas territory of France
Capital: Moroni
Political subdivisions: 4 prefectures, 4 district councils
Legal system: French and Muslim law
Branches: High Commissioner appointed by French government; assisted by elected
Chamber of Deputies of 39 members, and an 8-man Council of Ministers,
President elected by Chamber of Deputies
Government leader: Ahmed Abdallah, President of Council of Ministers
Suffrage: universal adult
Elections: at discretion of Council of Ministers, on advice of President; must
be held before expiration of 5-year electoral mandate
Political parties and leaders: Comoran Democratic Union, Mohammed Dahlani;
Democratic Assembly of Comoros People, Said Mohamed Jaffar; Comoros Socialist
Party; Unma, Prince Said Ibrahim; Mahorais Movement, Marcel Henry
Voting strength: in elections for Chamber of Deputies in 1972, independence
coalition of CDU and DACP won 34 seats, Mahorais Movement won 4
Communists: information not available
Legal name: Colony of the Falkland Islands
Type: British crown colony
Capital: Stanley
Political subdivisions: local government is confined to capital
Legal system: English common law
Branches: Governor, Executive Council, Legislative Council
Government leader: Governor and Commander in Chief Sir Cosmo Haskard (also
High Commissioner for British Antarctic Colony)
Suffrage: universal
Legal name: Cooperative Republic of Guyana
Type: republic within Commonwealth
Capital: Georgetown
Political subdivisions: 9 administrative districts
Legal system: based on English common law with certain admixtures of Roman-
Dutch law; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers presided over by Prime Minister; 53-member
unicameral legislative National Assembly (elected); Supreme Court
Government leader: Prime Minister L.F.S. Burnham
Suffrage: universal over age 18 as of constitutional amendment August 1973
Elections: last held in July 1973; next election must be called within 5 years
Political parties and leaders: People''s Progressive Party (PPP), Cheddi Jagan;
People''s National Congress (PNC), L.F.S. Burnham; United Force (UF),
Feilden Singh
Voting strength (1973 election): 70.2% PNC, 26.2% PPP, 3.6% other
Communists: unknown; top echelons of PPP and PYO (Progressive Youth Organization,
militant wing of the PPP) include many Conmunists, but rank and file is
non-Communist
Other political or pressure groups: Liberator Party (LP}, Guyana National
Liberation Front (GNLF), People''s Democratic Movement (PDM), African Society
for Cultural Relations with Independent Africa (ASCRIA), Afro-Asian-American
Association (AAAA)
Member of: CARICOM, FAQ, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAS (observer),
Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Haiti
Type: republic under the 14-year dictatorship of Francois Duvalier who was
succeeded upon his death on 21 April 1971 by his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: 5 departments (despite constitutional provision for 9)
Legal system: based on Roman civil law system; constitution adopted 1964 and
amended 1971; legal education at State University in Port-au-Prince and private
law colleges in Cap-Haitien, Les Cayes, Gonaives, and Jeremie; accepts
compulsory [CJ jurisdiction
Branches: lifetime President, unicameral 58-member legislature of very limited
powers, judiciary appointed by President
Government leader: President-for-life Jean-Claude Duvalier
Suffrage: universal over age 18
Elections: constitution as amended in 1971 provides for lifetime president to be
designated by his predecessor and ratified by electorate in plebiscite;
legislative elections, which are held every 6 years, last held February 1973
Political parties: National Unity Party, only legal party; United Haitian
Communist Party (PUCH), illegal (Communist)
Voting strength (1967 legislative elections): 100% National Unity Party
(Duvalier)
Communists: strength unknown; party leaders believed in exile
Other political or pressure groups: none
Member of: GATT, IADB, IAEA, ICAO, IMF, IBRD, OAS, U.N.
Legal name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Political subdivisions: 18 departments
Legal system: based on Roman and Spanish civil law; some influence of English
common law; constitution adopted 1965; judicial review of legislative acts
in Supreme Court; legal education at University of Honduras in Tegucigalpa;
accepts compulsory ICJ jurisdiction, with reservations
Branches: constitution provides for elected President, unicameral legislature,
and national judicial branch
Government leader: General Oswaldo Lopez Arellano
Suffrage: universal and compulsory over age 18
Elections: next general election February 1977
Political parties and leaders: all partfes, even legal ones, are dormant at
present; Liberal Party (PLH), Modesto Rodas Alvarado, Carlos Roberto Reina
Idiaguez, Jorge Bueso Arias; National Party (PNH), Alejandro Lopez Cantarero,
Ricardo Zuniga Augustinus; Mario Rivera Lopez, Martin Aquero; Popular
Progressive Party (PPP-uninscribed), Gonzalo Carias Castillo; National
Innovation and Unity Party (PINU), non-conmunist, (uninscribed), Miguel
Andonie Fernandez; Workers Party of Honduras (PTH), illegal, Rogue Ochoa;
Communist Party of Honduras/Soviet (PCH/S-outlawed), Dionisio Ramos Bejarano;
Communist Party of Honduras/China (PCH/C-outlawed), Agapito Robledo Castro
Voting strength (1971 elections): National Party (PNH) 306,028; Liberal Party
(PLH) 276,777
Communists: about 800; 2,000 sympathizers
Other political or pressure groups: National Association of Honduran Campesinos
(ANACH); Council of Honduran Private Enterprise (COHEP); Confederation of
Honduran Workers (CTH)
Member of: CACM, IADB, ICAO, ILO, OAS, U.N.
Legal name: Republic of Iceland
Type: republic
Capital: Reykjavik
Political subdivisions: 23 rural districts, 215 parishes, 14 incorporated towns
Legal system: civil law system based on Danish law; constitution adopted 1944;
legal education at University of Iceland; does not accept compulsory
ICJ jurisdiction
Branches: legislative authority rests jointly with President and parliament
(Althing); executive power vested in President but exercised by cabinet
responsible to parliament; Supreme Court and 29 lower courts
Government leaders: President Kristjan Eldjarn; Prime Minister Olafur Johannesson
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1975); presidential, every
4 years (next in 1976)
Political parties and leaders: Independence (conservative), Geir Hallgrimsson;
Progressive, Olafur Johannesson; Social Democratic, Gylfi Gislason;, People''s
Alliance (Communist front), Ragnar Arnalds; Organization of Liberals and
Leftists, Hannibal Valdimarsson
Voting strength (1971 election): 36.2% Independence, 25.2% Progressive, 10.4%
Social Democratic, 17.1% People''s Alliance, organization of leftists and
liberals 8.9%
Communists: 1,000; a number of sympathizers, as indicated by 18,055 votes cast
for Labor Alliance in 1971 election
Member of: Council] of Europe, EC (free trade agreement pending resolution of fishing
limits issue), FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU,
NATO, Nordic Council, OECD, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Overseas Department of Martinique
Type: overseas department of France; represented by 3 deputies in the French
National Assembly and 2 Senators in the Senate
Capital: Fort-de-France
Political subdivisions: 2 arrondissements; 34 communes, each with a locally
elected municipal council
Legal system: French legal system; highest court is a court of appeal based
in Martinique with jurisdiction over Guadeloupe, French Guiana, and Martinique
Branches: executive, prefect appointed by Paris; legislative, popularly elected
council of 36 members; judicial, under jurisdiction of French judicial system
Government leader: Prefect Jean Terrade
Suffrage: universal over age 21
Elections: General Council elections coincide with those for the French National
Assembly, normally every five years; last General Council election took place
in March 1973; last local election held September 1973
Political parties and leaders: Union of Democrats for the Republic (UDR), Emile
Maurice; Progressive Party of Martinique (PPM), Aime Cesaire; Communist
Party of Martinique (PCM), Armand Nicolas; Democratic Union of Martinique
(UDM), Leon-Laurent Valere; Socialist Party, leader unknown; Federation of the
Left, leader unknown
Voting strength: UDR, 2 seats in French National Assembly; PPM, 1 seat (1973
election)
Communists: 1,000 estimated
Other political or pressure groups: Proletarian Action Group (GAP)
Legal name: Islamic Republic of Mauritania
Type: republics one-party presidential rule since 1960
Capital: Nouakchott
Political subdivisions: 8 regions and a capital district
Legal system: based on French civil law system and Islamic law; constitution
adopted 1961; judicial review of legislative acts in the Supreme Court;
has not accepted compulsory ICJ jurisdiction
Branches: president; unicameral National Assembly of 50 elected members;
separate judiciary (appointed by president)
Government leader: President Moktar Ould Daddah
Suffrage: universal for adults
Elections: presidential and parliamentary election every 5 years; most recent
August 1971
Political parties and leaders: Mauritanian People''s Party is only legal party,
Secretary General Moktar Ould Daddah
Communists: no Communist Party, but there is a scattering of Maoist sympathizers
Member of: ACCT, CEAO, EAMA, FAO, ICAQ, [LO, IMCO, ITU, OAU, Organization
for the Development of the Senegal River Valley (OMVS), Seabeds Committee,
U.N., UNESCO, WHO, WMO, Arab League
Legal name: Mauritius
Type: independent state since 1968, recognizing Elizabeth II as chief of state
Capital: Port Louis
Political subdivisions: 5 “organized minicipalities" and various island
dependencies
Legal system: based on French civil law system with elements of English common
law in certain areas; constitution adopted 6 March 1968
Branches: executive power exercised by Prime Minister and 21 -man Council of
Ministers; unicameral legislature (National Assembly) with 62 members elected
by direct suffrage, 8 specially elected, and one nominated
Government leader: Prime Minister Dr. Seewoosagur Ramgoolam
Suffrage: universal over age 21
Elections: last held in August 1967; next scheduled in 1972 postponed at least
4 years by constitutional amendment
Political parties and leaders: a loose government coalition consisting of Labor
Party (S. Ramgoolam) and Muslim Committee of Action (A. R. Mohamed); Parti
Oauricien Social Democrate (G. Duval); Independent Forward Bloc (S.
Bissoondoyal); Mauritius Democratic Union (M. Lesage); Mouvement Militant
Mauritian (P. Berenger)
Voting strength: Muslim Conmittee of Action, 4 seats; Independent Forward Bloc,
6 seats; Mauritius Labor Party, 33 seats; Mauritius Democratic Union, 5 seats;
Parti Mauricien Social Democrate, 19 seats; 4 seats vacant
Communists: may be 2,000 sympathizers; several Communist organizations; Mauritius
Lenin Youth Organization, Mauritius Women''s Committee, Mauritius Communist
Party, Mauritius People''s Progressive Party, Mauritius Young Communist League,
Mauritius Liberation Front, Chinese Middle School Friendly Association,
Mauritius/USSR Friendship Society
Other political or pressure groups: Tamil United Party, Mauritius Workers Party
Member of: ACCT, ICAO, Commonwealth, OAU, OCAM, U.N.
227
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands, enjoying complete domestic
autonomy
Capital: Willemstad; Curacao, center of government
Political subdivisions: 4 island territories -- Aruba, Bonaire, Curacao, and the
Windward Islands -- St. Eustatius, southern part of St. Martin (northern
part is French), Saba
Legal system: based on civil law system, with some English common law influence;
Dutch Country Statute of 1955 serves as constitution
Branches: executive power, under nominal head of Governor (appointed by the
Crown), exercised by 8-member Council of Ministers or Cabinet; legislative
power rests with 22-member Legislative Council; independent court system
under control of Chief Justice of Supreme Court of Justice (administrative
functions under Minister of Justice); each island territory has island
council headed by Lieutenant Governor for local administration
Government leaders: Minister-President Juan Evertsz
Suffrage: universal age 18 and over
Elections: held every 4 years, last held August 1973
Political parties and leaders: the Democratic Party (DP); Antilles Social Progress
Movement (MASA) led by Ciro Kroon; the Aruba Patriotic Party (PPA) led by S.J.
Trompe; the National People''s Party (NVP), S.D. Abbad; the Aruba People''s Party
(AVP) led by Dominico Guzman Croes; the National Aruban Union Party/ Independent
Aruban Party (UNA/PIA) led by A. Werleman/M. Croes; Bonaire Democratic Party
led by L.A. Abraham; Windward Island Democratic Party led by A. C. Watheys
Social Progressive Action Party, S. R. Goeloe; Antillean Reform Union (URA),
Roberto Suriel; Curacao Independent Party (COP), Peter Vander Hoven; Radical
Peoples Party (PRP), Max de Castro; Workers'' Party (Frente Obrero}; People''s
Electoral Movement (MEP), separatist party
Voting strength (1973 general election): DP/PPA, 8 seats; NVP, 5 seats; Frente
Obrero, 3 seats, MEP, 5 seats; labor coalition, 1 seat
Communists: no Communist Party
Member of: EC (associate), WHO
245
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: Republic of Peru
Type: republic; under military regime since October 1968
Capital: Lima
Political subdivisions: 23 departments with limited autonomy plus constitutional
Province of Callao
Legal system: based on civil law system; military government rules by decree;
Tegal education at the National Universities in Lima, Trujillo, Arequipa,
and Cuzco; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative, judicial; congress disbanded after 3 October
1968 ouster of President Fernando Belaunde Terry
Government leader: President, General (ret.) Juan Velasco Alvarado
Suffrage: obligatory for citizens (defined as adult men and women and married
persons over age 18) until age 60
Elections: none scheduled
Political parties and leaders: Christian Democratic Party (PDC), Carlos Quiroga
Gutierrez, supports the government; opposition parties include Popular Action
Party (AP), Fernando Belaunde Terry (in exile); American Popular Revolutionary
Alliance (APRA), Victor Raul Haya de la Torre; and Pop','c9f93a777d29389f4a2a1a16b85547d6a9484ca8b42d2adf11f603acd1bc1198','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06cae29bd3a6ea6bce5e7cddcc1460364ee8f4396159f8eacf41620b2afb447b',1974,'BR','Brazil','government',21,'ular Christian Party (PPC),
Luis Bedoya Reyes
Voting strength (1963 election): 39% AP-PDC, 34% APRA, 25% UNO, 1% Communist,
1% other
Communists: pro-Soviet (PCP/S) 2,000; pro-Chinese (2 factions) under 500
Other political or pressure groups: government-sponsored social mobilization
system (SINAMOS)
Member of: GATT, IADB, IAEA, ICAO, LAFTA and Andean Pact, OAS, Seabeds Committee, U.N.
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Castries
Political subdivisions: 16 parishes
Legal system: based on English common law; constitution of 1960; highest judicial
body is Court of Appeal of Leeward and Windward Islands
Branches: legislative, 10-member popularly elected House of Assembly; executive,
cabinet headed by prime minister
Government leaders: Premier John Compton; U.K. Governor Ira Simmons (acting)
Suffrage: universal adult suffrage
Elections: every 5 years; most recent April 1969
Political parties and leaders: United Worker''s Party (UWP), John Compton; St.
Lucia Labor Party (SLP), Kenneth Foster; Saint Lucia Labour Action movement
(SLAM), George Odlum, St. Lucia Labor Party United Front (LPUF) Ted by
George Charles
Voting strength (1969 election): UWP won 6 of the 10 elected seats in House of
Assembly; SLP won 3 seats; LPUF won 1 seat
Comunists: negligible
Member of: CARICOM
Legal name: State of St. Vincent
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Kingstown
Legal system: based on English common law; constitution of 1960; highest
judicial body is Court of Appeal of Leeward and Windward Islands
Government leader: Premier James F. Mitchell; Governor General (U.K.) Sir Rupert
G. John
Suffrage: universal adult suffrage (18 years old and over)
Elections: every 5 years; most recent 7 April 1972
Political parties and leaders: People''s Political Party (PPP), Ebenezer Joshua;
St. Vincent Labor Party (LP), R. Milton Cato
Voting strength (1972 election): LP 6 seats, PPP 6 seats, independent 1 seat in
the Legislative
Comunists: negligible
Member of: CARICOM
Legal name: Republic of San Marino
Type: republic (dates from 4th century A.D.); in 1862 the Kingdom of Italy
concluded a treaty guaranteeing the independence of San Marino; although
legally sovereign, San Marino is vulnerable to pressure from the Italian
Capital: San Marino
Political subdivisions: San Marino is divided into 9 sections: Guaita, Fratta,
Serravalle, Domagnano, Acquaviva, Fiorentino, Montegiardino, Faetano,
Chiesanuova
Legal system: based on civil law system with Italian law influences; electoral
4 law of 1926 serves some of the functions of a constitution; has not accepted
compulsory ICd jurisdiction
Branches: the Grand and General Council is the legislative body elected by popular
vote; its 60 members serve 5-year terms; Council in turn elects two Captains-
Regent who exercise executive power for term of 6 months, the Council of
7 State whose members head government administrative departments and the Counci]
of Twelve, the supreme judicial body; actual executive power is wielded by
the Secretary of State for Foreign Affairs and the Secretary of State for
Internal Affairs
Government leaders: Secretary of State for Foreign Affairs Gian Luigi Berti
(Christian Democratic party); Secretary of State for Internal Affairs
Giuseppe Lonferini (Christian Democratic party); Secretary for finance Remy
Giacomini (Socialist)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General Council required at least every
5 years; next elections 1974
Political parties and leaders: Christian Democratic party (DCS), Gian Luigi Berti;
Social Democratic Party (PSDSM), Alvaro Casali; Socialist Party (PSS), Remy
Giacomini; Communist Party (PCS), Umberto Barulli
Voting strength (1969 election): 45% DCS, 25% PCS, 18.3% PSDIS, 11.7% PSS
Communists: approx. 300 members (number of sympathizers cannot be determined);
PSS, in government with Christian Democrats since March 1973, formed a
government with the PCS from the end of World War ITI to 1957
Other political parties or pressure groups: political parties influenced by
policies of their counterparts in Italy, the two Socialist parties are
not united
Member of: ICJ, International Institute for Unification of Private Law,
International Relief Union, IRC, UPU
301
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: Surinam
Type: territory within Kingdom of the Netherlands, enjoying complete domestic
autonomy
Capital: Paramaribo
Political subdivisions: 9 districts, each headed by district commissioner
responsible to Minister of Internal Affairs
Legal system: Dutch civil law system; country statute of 1955 serves as
constitution
Branches: Council of Ministers headed by a Minister-President, which constitutes
the Cabinet; 39-member legislative council (Staten) popularly elected for
4-year term; court system administered by Attorney-General under Minister
of Justice and Police
Government leader: Minister-President, Hendrick A. E. Arron
Suffrage: universal over age 23
Elections: every 4 years or earlier upon request of Minister-President; latest
held November 1973 won by National Party Combination (NPK), a creole-based
election coalition in which the National Party of Surinam (NPS) is the
largest party
Political parties and leaders: National Party of Surinam (NPS), Hendrick A. E.
Arron; Nationalist Republic Party (PNR), Edward Bruma (principal leftist
party); United Hindustani Party (VHP), J. Lachmon; Progressive National Party
(PNP), Frank E. Essed; Surinam Democratic Party (SDP), B. F. J. Qostburg;
United Indonesian People''s Party (SRI), F. Karsowidijojo; Javanese Farmers’
Party (KTPI), H. I. Soemita; United Peoples Party (VVP}, led by apolitical or
Chinese businessmen
Voting strength (1973): NPK 22 seats, VHP 17
Communists: no overt Communist Party; PNP has some Communist sympathizers
Member of: EC (associate), WHO
331
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: Kingdom of Swaziland
Type: monarchy, under King Sobhuza I]; independent member of
Commonwealth since September 1968
Capital: Mbabane (administrative), Lobamba (royal and legislative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-Dutch law in statutory courts, Swazi
traditional law and custom in traditional courts; legal education at University
of Botswana, Lesotho, and Swaziland (located in Lesotho); has not accepted
compulsory ICd jurisdiction
Branches: in April 1973 King abolished the constitution, dismissed parliament, and
assumed personal rule; he intends ruling under a King-in-Council arrangement
with the cabinet being retained as an advisory council; former members of
parliament continue to receive their salaries and new constitution probably
will be drawn up later
Government leader: Head of State and government King Sobhuza II; Prime Minister
Makhosini Dlamini
Suffrage: universal for adults
Elections: first elections for Legislative Council held in June 1964; latest for
House of Assembly in May 1972
Political parties and leaders: Imbokodvo, the traditionalist party, controlled
by King Sobhuza II; the opposition Ngwane National Liberatory Congress
{NNLC), led by Dr. Ambrose Zwane, has been dissolved
Voting strength: in 1972 elections, Imbokodvo won 21 seats, NNLC won 3 seats in
the House of Assembly
Communists: no Communist Party
Member of: AFDB, OAU, U.N.
Legal name: Oriental Republic of Uruguay
Type: republic, government under strong military influence
Capital: Montevideo
Political subdivisions: 19 departments with limited autonomy
Legal system: based on Spanish civil law system; new constitution implemented
1967; judicial review of legislative acts in Supreme Court, legal education
at University of the Republic at Montevideo; accepts compulsory ICJ
jurisdiction
Branches: executive, headed by President; since 1973 the military has had
considerable influence in policymaking; bicameral legislature (closed
indefinitely by presidential decree in June 1973); national judiciary headed
by Supreme Court
Government leader: President Juan Maria Bordaberry
Suffrage: universal over age 18
Elections: every 5 years; next in 1976
Political parties and leaders: National (Blanco) Party, President of Party
Directorate Homero Murdoch, main factions include Martin Echegoyen''s “Alianza”
faction, List 400 (Washington Beltran), Rocha Movement (Carlos Julio Pereyra),
Orthodox Herreristas (Alberto Heber Usher), and Por La Patria (Wilson Ferreira
Aldunate, in self-imposed exile in Argentina); Colorado Party, main factions
include Colorado and Batllista Union (Juan Maria Bordaberry), List 15 (Jorge
Batlle), LList 315 (Amilcar Vasconcellos); Broad Front (Frente Amplio), leftwing
coalition of Leftist Liberation Front (FIDEL)}, Communist Front and dissident
factions from both the Blanco and Colorado parties, and including FIDEL, the
Christian Democrats, and other splinter groups
Voting strength (1971 elections): 40.8% Colorado, 40.1% Blanco, 18.6% Frente Amplio,
0.5% Radical Christian Union
Communists: 35,000-40,000 including Communist youth group (6,000-8,000)
Other political or pressure groups: Communist Party (PCU), Rodney Arismendi;
Christian Democratic Party (PDC); Socialist Party of Uruguay (PSU); Revolu-
tionary Movement of Uruguay (MRO) pro-Cuban Conmunist Party; National
Liberation Movement of Uruguay (MRO) pro-Cuban Communist Party; National
Liberation Movement (MLN-Tupamaros) Marxist Revolutionary terrorist group
Member of: IADB, IAEA, IBRD, ICAO, ILO, IMF, LAFTA, OAS, U.N.
365
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes St. Peter''s, the Vatican Palace
and Museum and neighboring buildings covering more than 13 acres; 13
buildings in Rome, although outside the boundaries, enjoy extraterritorial
rights
Legal system: Canon law; constitutional laws of 1929 serve some of the functions
of a constitution
Branches: the Pope possesses full executive, legislative, and judicial powers;
he delegates these powers to the governor of Vatican City, who is subject
to pontifical appointment and recall; high Vatican offices include the
Secretariat of State, the College of Cardinals (chief papal advisers), the
Roman Curia (which carries on the central administration of the Roman
Catholic Church) the Presidence of the Prefecture for the Economy, and
the synod of bishops (created in 1965)
Government leader: Supreme Pontiff, Paul VI, (Giovanni Battista Montini, born
26 September 1897, elected Pope 21 June 1963)
Suffrage: limited to cardinals less than 80 in age
Elections: Supreme Pontiff elected for life by College of Cardinals
Conmunists: none known
Other political or pressure groups: none (exclusive of influence exercised
by other church officers in universal Roman Catholic Church)
Member: IAEA
Legal name: Republic of Venezuela
Type: republic
Capital: Caracas
Political subdivisions: 20 states, 1 federal district, 2 federal territories
Legal system: based on Spanish civil law system with influence of U.S. law;
constitution promulgated 1961; judicial review of legislative acts in
Cassation Court only; dual court system, state and federal; legal education
at Central University of Venezuela; has not accepted compulsory ICJ
jurisdiction
Branches: executive (President), bicameral legislature, judiciary
Government leader: President Carlos Andres Perez
Suffrage: universal and compulsory over age 18
Elections: every 5 years; last held 9 December 1973
Political parties and leaders: Accion Democratica (AD), Carlos Andres Perez, and
Gonzalo Barrios; Social Christian Party (COPEI), Rafael Caldera, and Lorenzo
Fernandez; People''s Electoral Movement (MEP), Jesus Angel Paz Galarraga;
Cruzada Civica Nacionalista (CCN), Marcos Perez Jimenez, leader; Union
Republicana Democratica (URD), Jovito Villalba; Partido Comunista de
Venezuela (PCV), Secretary-General Jesus Faria; Fuerza Democratica Popular
(FDP), Jorge Dager; Frente Nacional Democratico (FND), Pedro Segnini La Cruz;
Movement to Socialism (MAS), Teodoro Petkoff, and Pompey Marquez
Voting strength (1973 election): 49% AD, 37% COPEI, 5% New Force (MEP & PCV),
4% MAS, 3% URD, 2% others
Communists: minuscule in numbers and effectiveness
Other political or pressure groups: APEL (a conservative business group); PRO
VENEZUELA (leftist, nationalist economic group); DESARROLLISTAS (group of
wealthy, independent businessmen led by former finance minister Pedro Tinoco
and historian Guillermo Moron)
Member of: Andean Pact, FAO, IADB, IAEA, IBRD, ICAO, IDB, IFC, ILO, ITU,
OAS, OPEC, Seabeds Conmittee (observer), U.N., UNESCO, UPU, WHO, WMO
369
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: Democratic Republic of Viet-Nam
Type: Communist state
Capital: Hanoi
Political subdivisions: 2 autonomous regions (of 3 and 5 provinces, respectively),
17 other provinces, 2 centrally governed municipalities, 1 special zone
Legal system: based on Communist legal theory and French civil law system;
constitution enacted 1960
Branches: constitution provides for a National Assembly and highly centralized
executive nominally subordinate to it
Party and government leaders: Ton Duc Thang, President of DRV; Le Duan, First
Secretary; Truong Chinh, Chairman, Standing Committee of National Assembly;
Pham Van Dong, Premier; Vo Nguyen Giap, Minister of National Defense
Suffrage: over age 18
Elections: pro forma elections held for national and local assemblies
Political parties: ruled by Lao Dong Party (Communist) with membership of
approximately 900,000; minor subordinate parties
Member of: no international bodies
Legal name: Republic of Viet-Nam
Type: republic
Capital: Saigon
Political subdivisions: 4 regions (corresponding to 4 military regions), 1 special
region (corresponding to Capital Special Zone), divided into 44 provinces and
11 autonomous municipalities
Legal system: based on French civil law system; legal education at Universities
of Saigon and Hue
Branches: constitution provides for modified presidential system with executive,
legislative, and judicial branches
Government leaders: President Nguyen Van Thieu; Vice President Tran Van Huong;
Prime Minister Tran Thien Kniem
Elections: next presidential election scheduled for 1975
Suffrage: all citizens 18 and older are eligible to register to vote
Political parties and leaders: under a December 1972 law, President Thieu''s
Democracy Party is the only fully qualified legal party; a new independent
coalition, the Social Democratic Alliance will have provisional status until
early 1975
Communists: The People''s Revolutionary Party operates through and within he
National Front for the Liberation of South Vietnam (NLF) and the Alliance of
National, Democratic, and Peace Forces (ANDPF), and the Provisional Revolu-
tionary Government (PRG) designed to rival the legal government
Other political or pressures groups: religious groups often have more influence
than parties; the An Quang Buddhists are the most important opposition group;
Catholic groups range from progovernment to opposition; the independent Hoa
Hao and Cao Dai politico-religious sects exert strong influence in local areas
Member of: Colombo Plan, FAO, IAEA, ICAO, ILO, IMCO, ITU, U.N. (certain special ized
U.N. agencies and maintains observer team), UNESCO, UPU, WHO, WMO
373
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','24051875fdd4571e8549916e02969b4fdf65867adbe8a8a218f8e56c97a8b454','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('546b3f7cdbe960060ec03ecd9b3cb98dd9ac4b27843255b5a35dadba889d6257',1974,'AR','Argentina','government',26,'Legal name: Argentine Republic
Type: republic; elected government took over 25 May 1973 from military regime
in control since coup in June 1966; it resigned on 13 July and new election
was held on 23 September bringing Peron back to power
Capital: Buenos Aires
Political subdivisions: 22 provinces, 1 district (Federal Capital), and 1 territory
Legal system: based on Spanish and French civil codes; constitution adopted
1853 partially superseded in 1966 by the Statute of the Revolution which
takes precedence over the constitution when the two are in conflict,
further changes may be made by new government; judicial review of
legislative acts; legal education at University of Buenos Aires and other
public and private universities; has not accepted compulsory ICJ jurisdiction
Branches: presidency; national judiciary; legislature dismissed after June
1966 coup was reopened when new government was inaugurated on 25 May
Government leader: President, Juan Peron
Suffrage: universal and compulsory age 18 and over
Elections: general elections held on 11 March 1973; congressional and
gubernatorial runoffs were held on 15 April; next election in 4 years
Political parties: Justicialistas, the official Peronist party; Radical Civic
Union, moderate leftist and nationalist, Ricardo Balbin; Federal Popular
Alliance, Francisco Manrique; Movement of Integration and Development (MID),
small left of center party, former President Frondizi; New Force, conservative
business party, organized by Alvaro Alsogaray for the 1973 elections;
Intransigent Party, formerly the Intransigent Radicals (UCRI), small
nationalist party, Oscar Alende; Union Popular, neo-Peronist or Peronism
without Peron, generally more moderate than orthodox Peronism, Rodolfo
Tecera del Franco; Popular Conservative Party, not conservative but a member
of Peron''s Civic Front, Vicente Solano Lima; smaller parties include the
Revolutionary Christian Party and the Popular Christian party (both are
factions of the Christian Democratic Party), the Progressive Democrats,
the Socialist Party, and the Democratic Socialist Party; several provincial
parties not organized on a national basis
13
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Voting strength: Justicialista Front, 61%; Radicals (former People''s Radical
Civic Union, UCRP), 24%; Federal Popular Alliance, 12%; others, 3%
Communists: some 60,000 members in various party organizations, including a small 7
nucleus of activists
Other political or pressure groups: Argentine armed forces, Peronist-dominated
labor movement, National Meeting of the Argentines (loose grouping of
Communist and leftist politicians), General Economic Confederation
(Peronist-leaning association of small businessmen) Argentine Industrial Union
(manufacturers'' association), Argentine Rural Society (large landowners! >
association), business organizations, students, and the Catholic Church
Member of: FAO, IADB, IAEA, IBRD, ICAO. IDA, IFC, IHB, ILO, IMCO, IMF, ITU, LAFTA,
OAS, Seabeds Committee, U.N.., UNESCO, UPU, WHO. WMO, Non-Aligned Nations Group
Legal name: Republic of Chile
Type: republic
Capital: Santiago
Political subdivisions: 25 provinces
Legal system: based on Code 1857 derived from Spanish Taw and subsequent codes |
influenced by French and Austrian law; constitution adopted 1925, amended
Since then, currently being revised; judicial review of legislative acts in
the Supreme Court; legal education at University of Chile, Catholic University,
and several others; has not accepted compulsory ICJ jurisdiction
Branches: president currently replaced by 4-man Military-Police Junta; bicameral
legislature currently dissolved; independent judiciary
Government leader: Junta President, Gen, Augusto PINOCHET Ugarte; other Junta
members, Adm. Jose Toribio MERINO Castro, Gen. Gustavo LEIGH Gusman, Gen.
Cezar MENDOZA Duran
Suffrage: universal (except enlisted military and police) and compulsory at
age 18
Elections: next scheduled presidential election, 1976
Political parties and leaders: Christian Democratic Party (PDC), Patricio Aylwin;
National Party (PN), Sergio Onofre Jarpa; Popular Unity coalition parties
(outlawed) -- Communist Party (PCCh), Luis Corvalan; Socialist Party (PS),
Carlos Altamirano; Radical Party (PR); Christian Left (IC); United Popular
Action Movement (MAPU); Independent Popular Action (API)
Voting strength (1970 presidential election): 36.6% Popular Unity coalition, 35.3%
conservative independent, 28.1% Christian Democrat; (1973 Congressional election)
44% Popular Unity coalition, 56% Democratic Confederation (PDC and PN)
Communists: 200,000
Other political or pressure groups: organized labor; business organizations;
landowners'' associations (SNA ~- Sociedad Nacional de Agricultura}; extreme
ae Movement of Revolutionary Left (MIR); rightist, Patria y Libertad
PyL
Member of: ECOSOC, IADB, IAEA, IBRD, ICAO, IDB, IHB, IMF, LAFTA and Andean Sub-
Regional Group (created in May 1969 within LAFTA), OAS, Seabeds Committee,
U.N.
63
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
CHINA, PEOPLE''S REPUBLIC OF
LAND:
3.7 million sq. mi.; 11% cultivated, sown area extended by
multicropping, 78% desert, waste, or urban (32% of
this area consists largely of denuded wasteland,
plains, rolling hills, and basins from which about 3%
could be reclaimed), 8% forested; 2%-3% inland water
Land boundaries: 15,000 mi.
WATER:
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 9,000 mi.
AUSTRALIA,
Legal name: People''s Republic of China
Type: Communist state; real authority lies with communist party''s political bureau;
the National People''s Congress, in theory the highest organ of government, in
reality merely rubber stamps the party''s programs; the State Council is the
actual governing organism
Capital: Peking
Political subdivisions: 21 provinces, 3 centrally governed municipalities, and
5 autonomous regions
Legal system: before 1966, a complex amalgam of custom and statute, largely
criminal; little ostensible development of uniform code of administrative
and civil law; highest judicial organ is Supreme People''s Court although
Tegal activity centered in parallel network of Public Security organs; laws
and legal procedure clearly subordinated to priorities of party policy; whole
system largely suspended during Cultural Revolution, but gradually being
revived
Branches: prior to 1966 control was exercised by Chinese Communist Party, through
State Council, which supervised more than 50 ministries, commissions, bureaus,
etc., all technically under the standing committee of the National People''s
Congress; this system broke down under "Cultural Revolution" pressures and
is currently in process of being reconsolidated and streamlined
Government leader: Premier of State Council, Chou En-lai; Chairman, People''s
Republic of China (chief of state, a ceremonial post currently vacant; party
elder Tung Pi-wu is "acting" chairman); both subordinate to central committee
of CCP, under Chairman Mao Tse-tung
Suffrage: universal over age 18, though this is academic
Elections: no meaningful elections
Political parties and leaders: Chinese Communist Party (CCP), headed by Mao
Tse-tung; Mao is Chairman of political bureau, real locus of power in China,
and also Chairman of Central Committee; a new central committee was formed at
the 10th Party Congress held in August 1973
65
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
PEOPLE''S REP
OF CHINA
CHINA, REPUBLIC OF
LAND:
14,000 sq. mi. (Taiwan and Pescadores); 24% cultivated,
6% pasture, 55% forested, 15% other (urban, industrial,
denuded, water area)
WATER:
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 615 mi. Taiwan, 285 mi. offshore islands
Legal name: Republic of China
Type: republic; one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 4 cities, 1 special municipality (Taipei)
Legal system: based on civil law system; constitution adopted 1947, amended 1960
to permit Chiang Kai-shek to be reelected, and amended 1972 to permit president
to restructure certain government organs; accepts compulsory ICJ jurisdiction,
with reservations
Branches: 5 independent branches (executive, legislative, judicial, plus traditional
Chinese functions of examination and control), dominated by executive branch;
President and Vice President elected by National Assembly
Government leaders: President Chiang Kai-shek; Vice President, Yen
Chia-kan; Premier Chiang Ching-kuo
Suffrage: universal over age 20
Elections: national level -- legislative yuan every 3 years but no general election
held since 1948 election on mainland (partial election for Taiwan province
representatives December 1969 and December 1972); local level -- provincial
assembly, county and municipal executives every 4 years; county and municipal
assemblies every 4 years
Political parties and leaders: Kuomintang, or National Party, led by Director
General Chiang Kai-shek, has no real opposition; 2 insignificant parties
are Democratic Socialist Party, Young China Party
Voting strength (1972 provincial assembly election): 58 seats Kuomintang,
13 seats independents
Other political or pressure groups: none
Member of: expelled from U.N. General Assembly. and Security Council on 25 October
1971 and withdrew on same date from other charter-designated subsidiary organs;
attempting to retain membership in international financial institutions
67
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','04810e1820eefe22cc7409c0b6a59b04bbf941721247432bde6443f52d52ee50','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d2d0f2bc2963dc0a73e875e299146ed0e0c9c0eacfae413e1b4bafb566c80ab',1974,'AT','Austria','government',30,'Legal name: Republic of Austria
Type: federal republic
Capital: Vienna .
Political subdivisions: 9 states (Laender) including the capital
Legal system: civil law system with Roman Taw origins constitution adopted 1920,
repromulgated in 1945; judicial review of legislative acts by a Constitutional
Court; separate administrative and civil/penal supreme courts; legal education
at Universities of Vienna, Graz, Innsbruck, Salzburg, and Linz; has not
accepted compulsory ICd jurisdiction
Branches: bicameral Parliament, directly elected President whose functions are
largely representational, independent federal judiciary
Government leaders: Chancellor Bruno Kreisky; office of federal president currently
vacant (elections scheduled for 23 June 1974)
Suffrage: universal over age 19; compulsory for presidential elections
Elections: presidential, every 6 years (next 1980); parliamentary, every 4
years (next 1975)
Political parties and leaders: Socialist Party of Austria (SP0e}, Bruno Kreisky,
Chairman; Austrian People''s Party (OeVP), Karl Schleinzer, Chairman; Liberal
Party (FP0e), Friedrich Peter, Chairman; Communist Party, Franz Muhri, Chairman
Voting strength (1971 election): 50.2% SPOe, 43.0% OeVP, 5.4% FPOe, 0.4% dissident
Socialist, 1.4% Communist
Communists: membership 26,000; activists 7,000-8,000; 60,705 votes in 1971 election
Other political or pressure groups: Federal Chamber of Commerce and Industry;
Austrian Trade Union Federation (primarily socialist); three composite leagues
of the Austrian People''s Party (OeVP) representing business, labor, and farmers;
the OeVP-oriented League of Austrian Industrialists; Roman Catholic Church,
including its chief lay organization, Catholic Action
Member of: Council of Europe, ECE, EFTA, IAEA, ICAO. OECD, Seabeds Committee, U.N.
UNESCO. WHO','774302d648bb0dda536f5f12e6de91a0ca9ef393a7eb8232f7b3c8b31d49d235','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1101f8c6e3b6bf430f6838013c96fbd3a34244ac7e4696b4926585cf08b315b',1974,'BS','Bahamas','government',34,'Legal name: Commonwealth of the Bahamas
Type: independent commonwealth since July 1973, recognizing Elizabeth II as
chief of state
Capital: Nassau (New Providence Island)
Legal system: based on English law
Branches: bicameral legislature (appointed Senate, elected House); executive
(Prime Minister and cabinet); judiciary
Government leaders: Prime Minister Lynden 0. Pindling
Suffrage: universal over age 18
Elections: House of Assembly (9 September 1972)
Political parties and leaders: Progressive Liberal Party (PLP), predominantly
Negro, Lynden 0. Pindling; Free National Movement (FNM) formed by a merger
of United Bahamian Party (UBP) and Free Progressive Liberal Party (Free PLP),
Kendall Isaacs
Voting strength (1972 election): PLP 29 seats, FNM 9 seats
Communists: none known
Legal name: State of Bahrain
Type: traditional monarchy; independence declared in 197]
Capital: Al Manamah
v
EGYPT: BAHRAIN Y pak,
Legal system: based on Islamic law and English common law; constitution will take
effect December 1973
Government leader: Emir ''Isa ibn Salman Al-Khalifah
Suffrage: granted to all native-born or naturalized males 20 and over
Elections: elections for new national assembly will be held December 1973
Political parties and pressure groups: political parties prohibited; no significant
pressure groups although numerous small clandestine groups are active
Communists: few known
Member of: Arab League, U.N.','d5a08643017999e3eccb24e5c3693c5e02af033f574408ecb231a7297e625e4f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae0fc3acf93d3bfee08dff08c10a6fbc0cf405a136b09059baa81ad3eed20ba6',1974,'BD','Bangladesh','government',38,'Legal name: People''s Republic of Bangladesh
Type: independent republic since December 1971
Capital: Dacca
Political subdivisions: 19 districts, 413 thanas (counties), 4,053 unions (village
groupings )
Legal system: based on English conmon law; constitution adopted December 1972
Branches: parliamentary government; constitution provides for unicameral
legislature, strong prime minister; independent judiciary
Government leader: Prime Minister Sheikh Mujibur Rahman
Suffrage: universal over age 18
Elections: First Parliament (House of the Nation) elected in March 1973;
elections to be held at least every 5 years
Political parties and leaders: Awami League, Sheikh Mujibur Rahman, President;
National Awami Party/Bhashani, Maulana Bhashani, President; National Awami
Party/Muzaffar, Muzaffar Ahmed, President; National Socialist Party
(Jatiyo Samjtantrik Dal), Abdur Rab, General Secretary, and M.A. Jalil,
President; Communist Party of Bangladesh, Moni Singh, leader, and Abdus
Salam, General Secretary; Bangladesh National League, Ataur Rahman Khan,
leader; various communist party splinter groups and other small radical
leftist groups some calling themselves Communists
Voting strength: (1973 election) 73.1% Awami League; 8.6% NAP/M; 6.5% JSD;
5.4% NAP/B; 6.4% independents and others
Communists: no information available on membership or degree of popular support
Other political or pressure groups: student groups, bands of former guerrillas
Member of: Afro-Asian People''s Solidarity Organization, Colombo Plan, Commonwealth,
ECAFE, IBRD, IDA, IMF, ILO, IPU, UNCTAD, UNESCO, WHO','e3b32d0863274de5e23c056578097f364cc29a1d232ecf051f2fcfc130c8f9ed','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95f2b1c6cb04808778271ca6dbc93407b9bbd9db8e450839edb59284029b66a0',1974,'BB','Barbados','government',41,'Legal name: Barbados
Type: independent state since November 1966, recognizing Elizabeth II as chief
of state
Capital: Bridgetown
Political subdivisions: 11 parishes
Legal system: English common laws constitution came into effect upon
independence in 1966; no judicial review of legislative acts; has not
accepted compulsory ICJ jurisdiction
Branches: legislature consisting of a 21-member appointed Senate and a
24-member elected House of Assembly; cabinet headed by Prime Minister
Government leader: Prime Minister Errol Barrow
Suffrage: universal over age 18
Elections: House of Assembly members have terms no longer than 5 years;
last general election held 9 September 1971]
Political parties and leaders: Democratic Labor Party (DLP), Errol Barrow;
Barbados Labor Party (BLP), J. M. G. "Tom" Adams
Voting strength (1971 election): Democratic Labor Party (DLP), 57.5%; Barbados
Labor Party, 42.5%; Independent, negligible; House of Assembly seats -- DLP
18, BLP 6
Communists: none
Other political or pressure groups: People''s Progressive Movement (PPM), a
smal] black-nationalist group led by Calvin Alleyne
Member of: CARICOM, Commonwealth, ICAO, IMF, OAS, Seabeds Committee (observer),
U.N.','17477acbe4fd235440b0c202611cd435e8a724d75bf9055b801bd70b962d9959','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f638b91cc5e1dbca476968f69df427aa0d36133360d28b9d417816b6b4244eb6',1974,'BE','Belgium','government',45,'Legal name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: 9 provinces
Legal system: civil law system influenced by English constitutional theory;
constitution adopted 1831, since amended; judicial review of legislative
acts; legal education at 4 law schools; accepts compulsory ICJ jurisdiction,
with reservations
Branches: executive branch consists of King and cabinet; cabinet responsible to
bicameral parliament; independent judiciary; coalition governments are usual
Government leader: Head of State, King Baudouin; Prime Minister Leo Tindemans
Suffrage: universal over age 21
Elections: held 10 March 1974 (held at least once every 4 years)
Political parties and leaders: Social Christian, Charles-Ferdinand Nothomb and
Wilfred Martens, co-presidents; Socialist, Andre Cools and Joris Van Eynde,
co-presidents; Liberty and Progress, Senator P. Deschamps, national president;
Liberal Democratic and Pluralist Party, Rolland Gillet, party president;
Francophone Democratic Front-Walloon Rally (Walloon nationalist), Leo Defosset
national president; Volksunie (Flemish Nationalist), Hugo Schlitz, party
president; Communist, Louis Van Gent, president of political bureau
Voting strength (1974 election): 72 seats Social Christian, 59 seats Socialist,
30 seats Liberty and Progress, 22 seats Volksunie, 22 seats Francophone
Democratic Front-Walloon Rally, 4 seats Communist
Communists: 12,000 members; pro-Peking splinter groups, 400
Other political or pressure groups: Christian and Socialist Trade Unions; the
Federation of Belgium Industries; numerous other associations representing
bankers, manufacturers, middle-class artisans, and the legal and medical
professions; two major organizations represent the cultural interests of
Flanders and Wallonia
Member of: Benelux, BLEU (Bel gium-Luxembourg Economoc Union), Council of Europe,
ECE, ECOSOC, EC, EMA, FAO, IAEA, ICAO, IMF, NATO, OECD. Seabeds Conmittee,
U.N., UNESCO, WEU. WHO
29
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: Belize
Type: former British crown colony; obtained full internal self-government in
January 1964
Capital: Belize City; seat of government in Be ]mopan
Legal system: English law; constitution came into force in 1964, although
country remains a British colony
Branches: 18-member elected National Assembly and 8-member Senate (either house
> may choose its speaker or president, respectively, from outside its elected
membership); cabinet; judiciary
Government leader: Premier George Price
Suffrage: universal adult (probably 21)
Elections: before 1 December 1974
Political parties and leaders: People''s United Party (PUP), George Price;
National Independence Party (NIP), Philip Goldson; People''s Development
Movement (PDM), Dean Lindo; United Black Association for Development (UBAD),
Evan Hyde; Liberal Party (LP)
Voting strength (1969 election): 57.6% PUP, 39.8% NIP, 2.6% void ballots
Communists: none identified
Other political or pressure groups: Christian Workers'' Union (CWU) which is
connected with PUP
Member of: CARICOM','61a69225b8f946fe23c6b78c14fcd53467f316b04996640174c960e3ce714562','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa8d6217e23289e97ce89d2a2c1a86eb95962375c9f0aa85b74afe0e1ec529d3',1974,'BM','Bermuda','government',49,'Legal name: Colony of Bermuda
Type: British crown colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English jaw
Branches: elected House of Assembly; appointed Legislative Council; Executive
Council (cabinet)
Government leaders: Governor Sir Edwin Leather; Government Leader (equivalent
to Prime Minister) Sir Edward Richards
Suffrage: universal over age 21
Elections: at least once every 5 years; last general election, June 1972
Political parties and leaders: United Bermuda Party (UBP), Sir Henry Tucker;
Progressive Labor Party (PLP}, Walter N.H. Robinson
Voting strength (1972 elections}: UBP 61.2%, PLP 38.8%; House of Assembly seats
-- UBP 30, PLP 10
Communists: negligible
Other political or pressure groups: Bermuda Industrial Union (BIU)','4f6c17d924e77317fda467cff8c48b4a372f939da769b58be94a552b6328ecfb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e92423f9689ba369a1c03b772295a3624cc159c351cb4e275004ed4b4fab274',1974,'BT','Bhutan','government',53,'Legal name: Kingdom of Bhutan
Type: monarchy; special treaty relationship with India
Capital: Thimphu
Political subdivisions: 4 regions (east, central, west, south), further
divided into 15-18 subdivisions
Legal system: based on Indian law and English common law: in 1964 the
~ King assumed full power -- no constitution existed beforehand; a supreme
court hears appeals from district administrators; has not accepted
compulsory ICJ jurisdiction
Branches: appointed minister and indirectly elected assembly consisting of
village elders, monastic representatives, and all district and senior
government administrators (electoral reform provides for direct elections
in near future)
Government Teader: King Jigme Singhi Wangchuk
Suffrage: each family has one vote
Elections: popular elections on village level held every 3 years
Political parties: all parties illegal
Communists: no overt Communist presence
Other political or pressure groups: Buddhist clergy
Member of: oolombo Plan, UPU, U.N.','9d71b47482fe6d3ddd03bd3c2cab870abf7dbd72aeacd66102d6e8da6fce1bc5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f91e193b3e892fd3d39dd5a417f992c2acb3f4db9efbd16b27caee86e269ccbd',1974,'BW','Botswana','government',58,'Legal name: Republic of Botswana
Type: parliamentary republic since; independent member of commonwealth since 1966
Capital: Gaborone
Political subdivisions: 12 administrative districts
Legal system: based on Roman-Dutch law and local customary law; constitution
came into effect 1966; judicial review limited to matters of interpretation;
legal education at University of Botswana, Lesotho and Swaziland (2 1/2 years )
and University of Edinburgh (2 years); has not accepted compulsory ICJ
jurisdiction
Branches: executive -- President appoints and is the chief minister in the
cabinet which is responsible to Legislative Assembly; legislative --
Legislative Assembly with 31 popularly elected members and 4 members elected
by the 31 representatives, House of Chiefs with deliberative powers only;
judicial -- local courts administer customary law, High Court and
subordinate courts have criminal jurisdiction over all residents, Court of
Appeal has appellate jurisdiction
Government leader: President Seretse Khama
Suffrage: universal, age 21 and over
Elections: general elections held 18 October 1969
Political parties and leaders: Botswana Democratic Party (BDP), Seretse Khama;
Bechuanaland People''s Party (BPP), Philip Matante; Botswana Independence
Party (BIP), Motsamai Mpho; Botswana National Front (BNF), Kenneth Koma
Voting strength: (October 1969 election) 68% BDP (24 seats); 13.5% BPP (3 seats};
12% BNF (3 seats); 6% BIP (1 seat)
Communists: no known Communist organization; Koma of BNF has long history of
Communist contacts
Member of: AFDB, Commonwealth, FAQ, OAU, U.N., WMO','c90a989b553554b4c708cde33910f93795621e978a34a23ed705892d65a4a97c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b50a607ccf2e34047e4a9b131196519f99a0e56a47bee56cb52bd4e3fdceb72',1974,'BG','Bulgaria','government',62,'Legal name: People''s Republic of Bulgaria
Type: Communist state
Capital: Sofiya
Political subdivisions: 28 okrugs (districts), including capital city of Sofia
Legal system: based on civil law system, with Soviet Jaw influence; new
constitution adopted in 1971; judicial review of legislative acts in the
State Council; legal education at University of Sofiya; has not accepted
compulsory ICd jurisdiction
Branches: legislative (National Assembly), Council of Ministers, judiciary
Government leaders: Todor Zhivkov, Chairman, State Council (chief of state);
Stanko Todorov, Chairman, Council of Ministers (premier)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every 4 years for National Assembly; last elections
held on 27 June 1971; 99.8% of the electorate voted
Political parties and leaders: Bulgarian Communist Party. Todor Zhivkov, First
Secretary; Bulgarian National Agrarian Union, a puppet partys Georgi Traykov,
secretary
Communists: 699,000 party members (April 1971)
Mass organizations and front groups: Fatherland Front, Dimitrov Communist Youth
League, Central Council of Trade Unions, National Committee for Defense of
Peace, Union of Fighters Against Fascism and Capitalism, Committee of
Bulgarian Women, All-National Committee for Bulgarian-Soviet Friendship
Member of: CEMA, GATT, IAEA, ICAO, ILQ, IMCO, ITU, Seabeds Committee, U.N..
UNESCO, UPU, WHO, WMO, Warsaw Pact, International Organization of Journalists,
International Medical Association, International Radio and Television
Organization
Legal name: Socialist Republic of the Union of Burma
Type: republic under new 1974 constitution
Capital: Rangoon
Political subdivisions: seven divisions and seven constituent states; subdivided
into townships, villages, and wards
Legal system: People''s Justice system and People''s Courts instituted under 1974
constitution; legal education at Universities of Rangoon and Mandalay; has not
accepted compulsory ICd jurisdiction
Branches: State Council rules through a Council of Ministers; People''s Assembly
has legislative power
Government leader: Chairman of State Council and President, Gen. U. Ne Win
Suffrage: universal over age 18
Elections: People''s Assembly and local People''s Councils elected in 1974
Political parties and leaders: government-sponsored Burmese Socialist Program
Party only legal party
Communists: estimated 5,000-8,000
Other political or pressure groups: Parliamentary Democracy Party; Kachin
Independence Army; Shan State Army; Karen Nationalist Union
Member of: Colombo Plan, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF,
ITU, Seabeds Committee (observer), U.N., UNESCO, UPU. WHO, WMO','3f37e352b5a09ddb8e4bdfc2fff34f77af25f82509fa4cb0d7d4b53a403f7626','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b780afeb4567ada6b58c9dc5157433ef67ce6f466e20bce7fe1d279fcf856a0e',1974,'BI','Burundi','government',65,'Legal name: Republic of Burund{
Type: republic; military government since November 1966; no constitution
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into 18 arrondissements and 78
communes
Legal system: based on German and French civil codes and customary law; has not
accepted compulsory ICJ jurisdiction
Branches: presidential cabinet with Council of Ministers; no legislature
Government leader: President Michel Micombero
Elections: last legislative election May 1965
Political parties and leaders: National Party of Unity and Progress (UPRONA),
a predominantly Tutsi party, was declared sole legitimate party in 1966
Communists: no Communist party; resumed diplomatic relations with The People''s
Republic of China in October 1971 following a six-year suspension; U.S.S.R.
and North Korea have diplomatic missions in Burundi
Member of: AFDB, EAMA, ECA, IBRD, [CAQ, ILO, IMO, OAU, U.N., UNESCO, WHO, WMO','c1777023650c1082b1b3849418cb1883fdc82e3b034c288410a2b23be08ecfb1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1a9b67c6212b0cb53cad774e6cc1d42e372477e75803899a7b261dfab14ce0b',1974,'KH','Cambodia','government',68,'Legal name: Khmer Republic
Type: new constitution provides for strong presidential system; 4-man "Executive
Council" is chief policymaking body
Capital: Phnom Penh
Political subdivisions: 24 provinces with centrally appointed governors,
3 independent municipalities
Legal system: based on French civil law system; constitution adopted 1947 and
amended 1960; no judicial review of legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
Branches: 126-man national assembly and 40-man senate, popularly elected
Government leader: President Lon No}
Suffrage: universal over age 18, with major exception of Buddhist clergy
Elections: president elected for 5 year term in June 1972; senate for 6 year term
and assembly for 4 year term in September 1972
Political parties and leaders: Social Republican Party, Pan Sothi; Republican
Party, Sirik Matak; Democratic Party, Chau Sau
Communists: party strength unknown; Communist combat troops estimated between
46,000-56 ,000
Other political or pressure groups: none
Member of: ADB, Colombo Plan, IAEA, IBRD, ICAO, IMF, WHO, U.N.','97bf25742eb95add8fd0684acd5f0d54e2cadd7f5df4f0274ff034a819a7e2da','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bad80310b126dd786dabefecc5369bb78b0b0c77e43eefd9d603758364e98b8d',1974,'CM','Cameroon','government',71,'Legal name: United Republic of Cameroon
Type: unitary republic; one-party presidential regime
Capital: Yaounde
Political subdivisions: 7 provinces divided into 39 departments
Legal system: based on French civil law system, with common Taw influence; new
unitary constitution adopted 1972; judicial review in Supreme Court, when a
question of constitutionality is referred to it by the President of the
Republics; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative, and judicial
Government leader: President Ahmadou Ahidjo
Suffrage: universal over age 21
Elections: presidential elections held 28 March 1970; parliamentary elections
last held 18 May 1973
Political parties and leaders: single party, Cameroonian National Union (UNC).
President Ahmadou Ahidjo
Communists: no Communist Party or significant number of sympathizers
Other political or pressure groups: Cameroon People''s Union (UPC), an illegal
terrorist group now reduced to scattered acts of banditry with its factional
leaders in exile
Member of: ACCT, AFBD, EAMA, ECA, FAO, GATT, IAEA, IBRD, ICAO, ILO, IMCO, IMF,
ITU, Lake Chad Basin Commission, Niger River Commission, OAU, Seabeds
Committee, UDEAC, U.N., UNESCO, UPU, WHO, WMO','553027ca5bebdd52f850647e2fee16792a9cc663ec64223fd731ae88e8543ac7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34124a96d7f96cff50181ed1d5497aa0310131c23d324c97146bb809c12771d1',1974,'CF','Central African Republic','government',74,'Legal name: Central African Republic
Type: republic; constitution abrogated following military coup in January 1966
Capital: Bangui
Political subdivisions: 14 prefectures, 47 subprefectures
Legal system: based on French, Islamic, and tribal law; in 1966 the Chief of
State assumed all power and abrogated the existing constitution; has not
accepted compulsory ICJ jurisdiction
Branches: Gen. Bokassa heads government and rules by decree; assisted by
cabinet called Council of Ministers; judiciary, including Supreme Court,
court of appeals, criminal court, and numerous lower courts
Government leader: President for life Jean-Bedel Bokassa
Suffrage: universal over age 21
Elections: none have been held under Bokassa regime
Political parties and leaders: Black African Social Evolution Movement (MESAN),
ruling party under former regime, still in existence but plays little role,
led by President Jean-Bedel Bokassa
Communists: no Communist Party or significant number of sympathizers
Member of: ACCT, AFDB, Conference of East and Central African States, EAMA, ECA,
FAQ, GATT, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM, UDEAC, U.N., UNESCO, UPU,
WHO, WMO','30c5c81dfe542ba25893cc4d23dcd4a08f9c33601e0529a637a288c6cc420528','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3dcb2fecefd97c2f0ee003999c97d38d06563b97a1e3ad2caa62b41ca7287cfa',1974,'TD','Chad','government',77,'Legal name: Republic of Chad
Type: republic; one-party presidential regime since 1962
Capital: N''Djamena
Political subdivisions: 14 prefectures
Legal system: based on French civil law system and Chadian customary Taw;
constitution adopted 1962; judicial review of legislative acts in theory a
power of the Supreme Court; has not accepted compulsory ICd jurisdiction
Branches: President, who has sweeping powers, elected by universal adult suffrage
to 7-year term; separate popularly elected unicameral National Assembly
of 105 deputies with 5-year term; independent judiciary
Government leader: President N''Garta Tombalbaye
Suffrage: universal over age 20
Elections: presidential elections held June 1969, parliamentary elections last
held December 1969
Political parties and leaders: National Movement for Cultural and Social
Revolution (MNRCS), only legal party, led by N''Garta Tombalbaye
Communists: no front organizations or underground party; probably a few
Communists and some sympathizers
Other political or pressure groups: lightly armed Muslim rebel bands have been
opposing the government since October 1965 in east-central and since August
1969 in northern Chad
Member of: ACCT, AFDB, Conference of East and Central African States, EAMA, ECA,
FAO, GATT, ICAO, IBRD, IDA, ILO, IMF, ITU, Lake Chad Basin Commission,
OAU, UEAC, U.N. UNESCO, UPU, WHO. WMO','dd248ad38b08bbabb18ff4dec34cf9ebe21de524010ff0a17afd2cff7a558406','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('893a8e058149241ffdd296848854025163112c78a2713cf88d8dceb70ce38dc7',1974,'CG','Congo','government',80,'= Legal name: People''s Republic of the Congo
Type: republic; military regime established September 1968
Capital: Brazzaville
Political subdivisions: 9 regions divided into districts
Legal system: based on French civil law system and customary law; constitution
¥ adopted 1963 and 1969
Branches: President, Prime Minister, Council of State; National Assembly; judiciary
presumably still functions according to provisions of 1963 constitution; all
policy made by Congolese Workers Party Central Committee and Politburo
Government leaders: President, Major Marien Ngouabi; Prime Minister Henri Lopes
Suffrage: universal over age 18
Elections: last legisiative elections June 1973
Political parties and leaders: Congolese Workers Party (PCT) is only legal party;
President, Marien Ngouabi
Communists: unknown number of Communists and sympathizers
Other political or pressure groups: Union of Congolese Socialist Youth (UJSC),
Congolese Trade Union Congress (CSC), Revolutionary Union of Congolese
Union (URFC), General Union of Congolese Pupils and Students (UGEEC)
Member of: ACCT, AFDB, Conference of East and Central African States, EAMA, ECA,
IBRD, FAO, ICAO, ILO, IMF, ITU, OAU, UDEAC, UNESCO, UPU, WHO, WMO','bf21414d4b463a6b1cdf68e876800b2aeb6009bfb0012e57e26389db8644daa0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a2e579e2c44d628fc0cd64a09492db71a06688cd0d67fa9b3ca36e2994e0fef',1974,'CK','Cook Islands','government',83,'Legal name: Cook Islands
Type: self-governing in "free association” with New Zealand; Cook Islands
government fully responsible for internal affairs and has right at any time
to move to full independence by unilateral action; New Zealand retains
responsibility for external affairs, in consultation with Cook Islands
Capital: Rarotonga
Branches: New Zealand Governor General appoints High Commissioner of Cook Islands,
who represents the Queen and the New Zealand government; High Commissioner
appoints the Premier; Legislative Assembly of 22 members, popularly elected;
House of Arikis (chiefs), 15 members, appointed by High Commissioner, an
advisory body only
Government leader: Premier Albert Henry
Suffrage: universal adult
Elections: every 4 years, latest in 1972
, Political parties and leaders: Cook Islands Party, Albert Henrys Democratic
Party, Dr. Thomas Davis
Voting strength (1972): Cook Islands Party, 15 seats; Democratic Party, 7 seats','71a2417a1019912e7e4ac4af3c1f4a6b090b5bdb470049f3867fcd77bc3537f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82353302c95ff9fbcb4d04b53124aefc7baa5e52a5b64c1116b98225cdb3f7e9',1974,'CR','Costa Rica','government',86,'Legal name: Republic of Costa Rica
Type: unitary republic
Capital: San Jose
Political subdivisions: 7 provinces
Legal system: based on Spanish civil law system; constitution adopted 1949;
judicial review of legislative acts in the Supreme Court; legal education
at University of Costa Rica; has not accepted compulsory ICJ jurisdiction
Branches: President, unicameral legislature, Supreme Court elected by legislature
Government leader: President Daniel Oduber
Suffrage: universal and compulsory age 18 and over
Elections: every 4 years; next, February 1978
Political parties and leaders: National Liberation Party (PLN), Daniel Oduber,
Jose Figueres; National Unification (UN), Francisco Calderon Guardia, Guillermo
Villalobos Arce; National Independent Party (PNI), Jorge Gonzalez Marten; Democratic
Renovation Party (PRD), Rodrigo Carazo; Christian Democratic Party (PDC), Jorge
Monge Zamora; Socialist Action Party (PASO), Marcial Aguiluz; Popular Vanguard
Party (PVP, Communist, illegal), Manuel Mora
Voting strength (1974 election): National Unification (coalition of PUN, PR, and
PURA), 30.4%--16 seats; PLN, 43.5%--27 seats; PNI, 11%--6 seats; PRD, 9%--3 seats;
PASO, 2.3%--2 seats
Conmunists: 3,200 members, 10,000 sympathizers
Other political or pressure groups: Costa Rican Confederation of Democratic
Workers (CCTD), General Confederation of Workers (CGT). Chamber
of Coffee Growers, National Association for Economic Development (ANFE)
Member of: CACM, IADB, IAEA, ICAO, OAS, U.N.','748ee20a3655853af3ba35d0373ccdd7b903bcd7a41b18f6af59b9709c96c0c3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7575419eabb0b381820de08c6c7f2be0ea80882bf687f0930ed8b97458348c00',1974,'CU','Cuba','government',90,'Legal name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: 6 provinces
Legal system: based on Spanish and American law, with large elements of
Communist legal theory; Fundamental Law of 1959 replaced constitution
of 1940; legal education at Universities of Havana, Oriente, and Las Villas;
does not accept compulsory ICJ jurisdiction
Branches: executive; no legislature; controlled judiciary
Government leader: Prime Minister Fidel Castro Ruz
Political parties and leaders: Cuban Conmunist Party (PCC), First Secretary
Fidel Castro Ruz, Second Secretary Raul Castro Ruz
Communists: approx. 155,000 party members
Member of: CEMA, ECLA, FAO, GATT, IADB (nonparticipant), IAEA, ICAO, IHB, ILO,
IMCO, International Rice Commission, International Sugar Council, International
Wheat Agreement, ITU, OAS (nonparticipant), Permanent Court of Arbitration,
Postal Union of the Americas and Spain, Seabeds Committee (observer), U.N.,
UNESCO, UPU, WHO, WMO','1585a31bdc794389d35e2af890726018677b3cf90e1bf1ce35ab541f664f3217','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cbccd510b6641893f75b92014f4c1549ccf965f6011dd6e0a9f46d7447e222a',1974,'CY','Cyprus','government',94,'Legal name: Republic of Cyprus
Type: republic since March 1961; separate de facto Greek Cypriot, and Turkish
Cypriot governments have evolved since outbreak of communal strife in 1963
Capital: Nicosia
Political subdivisions: 6 administrative districts
Legal system: based on common law, with civil law modifications; constitution
came into force upon independence in 1960, but has often been in abeyance
since then; has not accepted compulsory Icd jurisdiction
Branches: currently a rump government consisting basically of Greek Cypriot parts
¥ of bodies provided for by constitution; headed by President of the Republic
and comprised of Council of Ministers, House of Representatives, and
Supreme Court
Government leaders: President, Archbishop Makarios III (Greek); Vice President,
Rauf Denktash (Turk)
Suffrage: universal age 21 and over
Elections: held every 5 years; 1965 elections suspended; 1968 elections only for
President and Vice President; 1970 parliamentary elections demonstrate notable
increase in voting strength of Communist Party (AKEL); 1972 elections only for
President and Vice President
Political parties and leaders: Reform Party of the Working People (AKEL)
(Conmunist Party), Ezekias Papaioannou; Unified Party (UP), Glafkos Clerides;
Progressive Movement (PM) (pro-Makarios), Andreas Azinas; Democratic
National Party (DEK), Takis Evdokas; United Democratic Union of the Center
(EDEK), Vassos Lyssarides; Turkish National Union Party (TNUP), Rauf Denktash
Voting strength: (1968 presidential and vice presidential elections) Greek
Cypriot President Makarios 90%; Turkish Cypriot Vice President Fazil Kucuk
unopposed; (1970 parliamentary elections) 39% of Greek Cypriot vote for
Reform Party of the Working People, 21% of the Greek Cypriot vote for the
Progressive Movement, 9% of the Greek Cypriot vote for the Democratic National
Party as well as 9% for the United Democratic Union of the Center, 4% of the
Greek Cypriot vote for independents, 76% of the Greek Cypriot electorate
voted; 80% of the Turkish Cypriot community voted and overwhelmingly elected
15 of Rauf Denktash''s supporters to the Turk Cypriot House contingent ina
ry separate election; 1972 elections - Makarios unopposed and Rauf Denk tash
unopposed
Communists: 12,000; sympathizers estimated to number 60,000
81
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Other political or pressure groups: United Democratic Youth Organization (EDON)
(Communist-control led); Pan Cyprian Confederation of Labor (PEO)
(Communist-controlled); Cyprus Confederation of Labor (SEK) ({pro-U.S.);
Cyprus Turkish Federation of Trade Unions (KTBIF)
Member of: Commonwealth, Council of Europe, FAQ, IAEA, IBRD, ICAO, IDA, IFC,
ILO, IMF, ITU, U.N., UNESCO, UPU, WHO
Legal name: Czechoslovak Socialist Republic
Type: Communist state
Capital: Prague
Political subdivisions: 2 separate autonomous republics (Czech Socialist
Republic and Slovak Socialist Republic); 7 regions (kraj) in Czech lands,
three regions in Slovakia; national capitals of Prague and Bratislava have
regional status
Legal system: civil law system based on German codes, modified by Communist
legal theory; revised constitution adopted 1960 amended in 1968 and 1970;
no judicial review of legislative acts; legal education at Universita
Komenskeho School of Law; has not accepted compulsory ICJ jurisdiction
Branches: executive --- President (elected by Federal Assembly), cabinet
(appointed by President); legislative -- Federal Assembly {elected directly),
Czech and Slovak National Councils (also elected directly) legislate on
limited area of Czech and Slovak affairs; judiciary -~ Supreme Court
(elected by Federal Assembly); entire governmental structure dominated
by Communist Party
Government leaders: President Ludvik Svoboda (reelected March 1973),
Premier Lubomir Strougal
Suffrage: universal over age 18
Elections: governmental bodies every 5 years (last election, November 1971);
President every 5 years
Dominant political party and leader: Communist Party of Czechoslovakia (KSC),
Gustav Husak, General Secretary; Communist Party of Slovakia (KSS) has status
of "provincial KSC organization"
Voting strength (1971 election): 99.81% Communist~sponsored single slate
Comunists: 1.2 million party members
Other political groups: puppet parties -- Czechoslovak Socialist Party,
Czechoslovak People''s Party, Slovak Freedom Party, Slovak Revival Party
Member of: CEMA, GATT, IAEA, ICAO, Seabeds Committee, U.N., Warsaw Pact
Legal name: Republic of Dahomey
Type: republic, under military rule since 26 October 1972
Capital: Porto-Novo (official), Cotonou (de facto)
Political subdivisions: 6 provinces, 46 districts
Legal system: based on French civil law and customary law; legal education
generally obtained in France; has not accepted compulsory ICJ jurisdiction
Branches: executive and legislative power vested in 12-man military revolutionary
government headed by a president; National Revolutionary Council of 67 soldiers
and civilians advises the government
Government leader: Lt. Col. Mathieu Kerekou, President and Minister of National
Defense and Planning
Suffrage: universal for adults whenever elections or referendums are held
Elections: current government has held no elections and none are scheduled
Political parties: none
Communists: no Communist party; some sympathizers
Member of: ACCT, AFDB, ECA, EAMA, Entente, FAQ, ICAO, ILO, ITU, Niger
River Commission, OAU, OCAM, U.N., UNESCO, UPU, WHO, WMO','c561481e77ad4712e16adeebaa57e881181c388c19515d60c8b1ac7b7182414b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97d0d19e839e27d50d3b8148b11f42e63d6e6256cf159f6e6f4a422f1eab8688',1974,'DK','Denmark','government',98,'Legal name: Kingdom of Denmark
Type: constitutional monarchy
Capital: Copenhagen
Political subdivisions: 14 counties, 277 communes, 88 towns
Legal system: civil law system; constitution adopted 1953; judicial review of
legislative acts; legal education at Universities of Copenhagen and Arhus;
accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament
(Folketing); executive power vested in Crown but exercised by cabinet
responsible to parliament; Supreme Court, 2 superior courts, 106 lower courts
Government leaders: Queen Margrethe II; Prime Minister, Poul Hartling
Suffrage: universal, but not compulsory, over age 21
Elections: on call of prime minister but at least every four years (last election
4 December 1973)
Political parties and leaders: Social Democratic, Anker Jorgensen; Moderate
Liberal, Poul Hartling; Conservative, Erik Haunstrup Clemmensen; Radical
Liberal, Asqer Baunsbak-Jensen; Socialist Peoples, Sigurd Omann; Communist,
Knud Jespersen; Left Socialist, a triumvirate consisting of Ernst Dahl, Leif
Sondergaard Andersen, and Niels Finn Christiansen; Center Democratic, Erhard
Jakobsen; Progressive, Mogens Glistrup; Christian People''s, Jens Miller;
Justice, Ib Christiansen
Voting strength (1973 election): 22.6% Social Democratic, 14.0% Progressive,
10.8% Moderate Liberals, 9.9% Radical Liberal, 8.1% Conservative, 6.8% Center
Democratic, 5.2% Socialist Peoples, 3.6% Christian Peoples, 3.2% Communist,
2.5% Justice, 13.3% other
Communists: 5,000; a number of sympathizers, as indicated by 39,344 Communist
votes cast in 1971 elections
Member of: Council of Europe, EC, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IMB,
ILO, IMCO, IMF, ITU, NATO, Nordic Council], OECD, Seabeds Committee (observer),
U.N., UNESCO, UPU, WHO, WMO
87
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','14ff8e5196c422ec919823b8ac0b2c41a696a08410d572c2203d70cfd50bca5a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9a6e05a2c5d97e5f3261fbec0fc35f405f163b421e796f34046731dcce772ac',1974,'CO','Colombia','government',102,'Legal name: State of Dominica
Type: dependent territory with full internal autonomy as a British "Associated
State"
Capital: Roseau
Political subdivisions: 10 parishes
Legal system: based on English common law; three local magistrate courts and
the British Caribbean Court of Appeals
Branches: legislature, 11 member popularly elected House of Assembly; executive,
cabinet headed by Premier
Government leaders: Premier Edward 0. LeBlanc; U.K. Governor Sir Louis Cools-Lartigue
Suffrage: universal adult suffrage over age 18
Elections: every 5 years; most recent October 1970
Political parties and leaders: Dominica Labor Party (DLP), Edward 0. LeBlanc;
Dominica Freedom Party (DFP), Miss M. Eugenia Charles
Voting strength: House of Assembly seats -- DFP 2 seats, DLP 8 seats, indepen-
dent 1 seat
Communists: negligible
Member of: CARICOM
Legal name: State of Grenada
Type: independent state since February 1974, recognizes Elizabeth II as Chief
of State
Capital: St. Georges
Political subdivisions: 6 parishes
Legal system: based on English common law
Branches: legislative branch consists of 10-member elected House of Representatives
and 13-member Senate appointed by the Governor; executive branch is cabinet led
by Premier
Government leaders: Premier Eric Matthew Gairy; U.K. Governor General Leo de Gale
Suffrage: universal adult suffrage
Elections: every 5 years; most recent election 28 February 1972
Political parties and leaders: Grenada United Labor Party (GULP), Eric Matthew
Gairy; Grenada National Party (GNP), Herbert A, Blaize
Voting strength (1972 election): GULP 58.7%, GNP 41.3%; Legislative Council
seats, GULP 14, GNP 1
Communists: negligible
Member of: CARICOM','6e76685809b3d9d30dfe7b4d7268a879ac9ea8bea30611ce055bb72a4aaab68d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65d6f218f881f678c4e76be3bda992ff2b65cca56c01a28bd046e317b7c0cd66',1974,'DO','Dominican Republic','government',107,'Legal name: Dominican Republic
Type: republic
Capital: Santo Domingo
Political subdivisions: 26 provinces and the National District
Legal system: based on French civil codes; 1966 constitution
Branches: President popularly elected for a 4-year term; bicameral legislature
consisting of Senate (27 seats) and Chamber of Deputies (74 seats) elected
for 4-year terms; members of Supreme Court elected by Senate
Government leader: President Joaquin Balaguer
Suffrage: universal and compulsory, over age 18 or married, except members of the
armed forces and police, who cannot vote
Elections: national, May 1974
Political parties and leaders: Reformist Party (PR), Joaquin Balaguer; Dominican
Revolutionary Party (PRD), Francisco Pena Gomez; Democratic Quisqueyan
Party (PQD), Elias Wessin y Wessin; Revolutionary Social Christian Party
(PRSC), Alfonso Moreno Martinez; Movement for National Conciliation (MNC),
Jaime Manuel Fernandez Gonzalez; Anti-reelection Movement of Democratic
Integration (MIDA) Francisco Augusto Lora; National Civic Union (UCN), Pedro
Guillermo Urraca; Fourteenth of June Revolutionary Movement (MR-1J4), split
into several factions, 11]egal; Dominican Communist Party (PCD), central
committee, illegal; Dominican Popular Movement (MPD), Rafael Taveras Rosario,
illegal; Communist Party of the Dominican Republic (PCRD), Luis Montas
Gonzalez, illegal; Popular Socialist Party (PSP), illegal
Voting strength (1970 election): 57% PR, (abstained) PRD, 5% PRSC, 14% PQD, 3%
MCN, 21% MIDA
Communists: an estimated 1,500 to 1,800 members in six different factions;
effectiveness limited by ideological differences and organizational
inadequacies
Member of: CARICOM, GATT, IADB, IAEA, ICAO, IHB, OAS, U.N.','ac99331b4ff0119bd9471a16aa720a606ebbb44d5d3c263c4a92178c71026c11','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc5e2eae6670f73d35c2ef34f03a6b3064316a0324a0c021c773f4f8d5b372f1',1974,'EC','Ecuador','government',111,'Legal name: Republic of Ecuador
Type: republic; under military regime since February 1972
Capital: Quito
Political subdivisions: 19 provinces and 1 territory (Galapagos Islands)
Legal system: based on civil law system; modified 1945 constitution re-instituted
in February 1972; legal education at 4 state and 2 private universities; has
not accepted compulsory ICJ jurisdiction
Branches: President and government council assumed power February 1972; government
decisions announced by decree over the president''s signature; judiciary system
supervised by Supreme Court; six special tribunals established in July 1972
Government leader: President, General Guillermo Rodriguez Lara
Suffrage: universal for literates over age 18
Elections: none scheduled
Political parties and leaders: National Velasquista Front, personalistic, Jose
Maria Velasco Ibarra (in exile): Radical Liberal Party, Ignacio Hidalgo
Villavicencio; Social Christian Party, generally conservative, Camilo Ponce;
Conservative Party, Galo Pico Mantilla; Concentration of Popular Forces, populist,
Assad Bucaram; National Revolutionary Party, leftist, Carlos Julio Arosemena
Voting strength: in June 1968 national elections, Velasquistas, a center-left
coalition, and a rightist coalition each got approximately one-third
Communists: Communist Party of Ecuador (PCE, pro-Moscow, Pedro Saad - secretary-
general), 500 members plus an estimated 2,500 sympathizers; Communist Party of
Ecuador (pro-Peking), 250 members; Revolutionary Soctalist Party (pro-Castro),
450 members
Member of: ECOSOC, IADB, IAEA, ICAO, LAFTA and Andean Sub-Regional Group
(formed in May 1969 within LAFTA), OAS, Seabeds Committee (observer), U.N.','460220d426c2a73f96cd7b031d8fc682131dcf63442fac68f2c1c20a03acee1e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95e5d62bc59b481d6c2f7647526989de311d534d27e56bc82c37d6483e123503',1974,'EG','Egypt','government',115,'Legal name: Arab Republic of Egypt
Type: republic; under presidential rule since dune 1956
Capital: Cairo
Political subdivisions: 25 governorates
Legal system: based on English common law, Islamic law, and Napoleonic codes;
permanent constitution written in 1971; judicial review of limited nature in
Supreme Court, also in Council of State which oversees validity of administrative
decisions; legal education at Cairo University; accepts compulsory ICJ
jurisdiction, with reservations
Branches: executive power vested in President, who appoints cabinet; People''s
Assembly has little actual power (serves mainly for discussion and automa-
tic approval); independent judiciary administered by Minister of Justice
Government Teader: President Anwar Sadat
Suffrage: universal over age 18
Elections: elections to People''s Assembly every 5 years (most recent October
1971); presidential elections every 6 years (next scheduled in 1976)
Political parties and leaders: political parties banned except for the government-
sponsored sociopolitical grouping, Arab Socialist Union (ASU)
Communists: approximately 500, party members
Member of: AAPSO, Arab League, FAQ, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO,
IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO, WPC','818ca129f569add4dc435e450596af5126c8fe25c50d0feb4b5553780e6cc18d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3ce5cc53d7eae9e15475b926eb5d628f4cd6203d4a417252c70f10c07aa4835',1974,'SV','El Salvador','government',119,'Legal name: Republic of El Salvador
Type: republic
- Capital: San Salvador
Political subdivisions: 14 departments
Legal system: based on Spanish law, with traces of common law; constitution
adopted 1962; judicial review of legislative acts in the Supreme Court;
legal education at University of El Salvador; accepts compulsory ICd
jurisdiction, with reservations
Branches: traditionally dominant executive, fairly independent unicameral
legislature, Supreme Court
Government leader: President Arturo Armando Molina
Suffrage: universal over age 18
Elections: legislative elections every 2 years; presidential elections every 5
years; presidential elections March 1977, legislative and municipal elections
March 1976
Political parties and leaders: National Conciliation Party (PCN), President
Arturo A. Molina, Dr. Enrique Mayorga Rivas Christian Democratic Party (PDC),
Juan Ramirez Rauda, Dr. Pablo Mauricio Alvergue, Roberto Lara Velado; Dr.
Abraham Rodriguez, Jose Napoleon Duarte; Salvadoran Popular Party (PPS), Benjamin
Wilfredo Navarrete, Roberto Quinonez Meza, Dr. Jose Antonio Guzman; Communist
Party of E1 Salvador (PCES), illegal, Jorge Shafick Handal; National
Revolutionary Movement (MNR), Dr. Guillermo Manuel Ungo; National Democratic
Union Party (PUDN), Jorge Shafisk Handal, Francisco Roberto Lima, Julio Ernesto
Contreras, Julio Castro Belloso; Independent Democratic United Front (FUDI),
Gen. Jose A. Medrano, Raul Salaverria
Voting strength: February 1972 presidential election -- PCN 43.4%, PDC, PUDN,
» and MNR coalition, 42.1%; FUDI, 12.3%; PPS 2.2%; March 1974 legislative
election -- PCN, 36 seats; PDC, MNR, and PUDN coalition, 15 seats: FUDI, 1]
seat (unofficial returns)
Communists: 100 to 200 active members; sympathizers, 5,000
Other political or pressure groups: the military; the "14" prominent families;
General Confederation of Trade Unions (CGS); Unifying Federation of Salvadoran
97
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Other political or pressure groups (cont''d):
Trade Unions (FUSS), Communist dominated; Federation of Construction and
Transport Workers Unions (FESINCONSTRANS), independent; Catholic Churchs
Salvadoran National Association of Educators (ANDES)
Member of: Central American Common Market, IADB, IAEA, OAS, ODECA, Seabeds
Committee, U.N.','30bb75697c8f7085d09dc1623c903799282958e3f01aad60d2cf9e0ca0e0f807','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a74ff9298d0ddedaedccb6551ab24fe8372e2819010f4bc869c56ddf40b5c04d',1974,'GQ','Equatorial Guinea','government',123,'Legal name: Republic of Equatorial Guinea
Type: republic, one-party presidential regime since 1968
Capital: Malabo, Province Francisco Macias Nguema
Political subdivisions: 2 provinces (Province Francisco Macias Nguema and
Rio Muni)
Legal system: based on Spanish civil law system and customary law, new constitution
adopted July 1973; has not accepted compulsory ICJ jurisdiction
Branches: there are legislative and judicial branches but president exercises
virtually unlimited power
Government leader: President for life, Francisco Macias Nguema
Suffrage: universal age 21 and over
Elections: parliamentary elections held December 1973
Political parties and leaders: National Unity Party of Workers (PUNT) is the sole
legal party, led by President Mactas
Communists: no significant number of Communists or sympathizers
Member of: Conference of East and Central African States, ECA, IBRD, IMF, OAU, U.N.','69a0284d77623aa7681b044fbe66e07f8c3e6477fa4bea6c41986afc0717318b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9cfa7cad1db228ed6dfd54bec8a47a4e81991367a0950dfb74e9b6976611990',1974,'ET','Ethiopia','government',127,'Legal name: Empire of Ethiopia
Type: monarchy, in which once absolute powers of Emperor were weakened in aftermath
of a military revolt in early 1974
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred to as governorates-general)
Legal system: complex structure with civil, Islamic, common and customary law
influences; constitution adopted 1955; constitutional review committee estab-
lished early 1974 to recommend changes (due in late 1974) that are expected to
enhance powers of cabinet at expense of Emperor; no specific constitutional
provision for review by courts but all legislation inconsistent with the
constitution is declared null and void; legal education at Haile Selassie 1
University; has not accepted compulsory [CJ jurisdiction
Branches: Emperor Haile Selassie reigns but is no longer all-powerful although he
wields some influence because he is viewed as a symbol of national unity and
still commands the loyalty of many Ethiopians; cabinet and Prime Minister
exercise authority in Emperor''s name, but hold office at suffrance of
unorganized group of military reformists; legislature composed of elected
Chamber of Deputies and appointed Senate; judiciary at higher levels based
on Western pattern, at lower levels on traditional pattern, without jury
system in either
Government leader: Emperor Haile Selassie I
Suffrage: universal over age 21
Elections: lower house of Parliament election in June 1973
Political parties and leaders: only amorphous reform groups especially among
younger, better educated Ethiopians
Communists: none
Other political or pressure groups: some dissident ethnic groups, most important
of which is Eritrean Liberation Front, separatist group operating in
northeastern Ethiopia
Member of: ECA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, U.N., UNESCO, UPU,
WHO, WMO
101
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: The Faeroe Islands
Type: self-governing province within the Kingdom of Denmark; 2 representatives
in Danish parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, 17 town
Legal system: based on Danish law; Home Rule Act enacted 1948
Branches: legislative authority rests jointly with Crown, acting through appointed
High Commissioner, and provincial parliament (Lagting) in matters of strictly
Faeroese concern; executive power vested in Crown, acting through High
Commissioner, but exercised by provincial cabinet responsible to provincial
parliament
Government leaders: Queen Margrethe II; Prime Minister, Atli Dam; Danish
Governor, Leif Groth
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years; next election 1975
Political parties and leaders: Peoples, Hakun Djurhuus; Republican, Erlendur
Patursson; Home Rule, Samuel Petersen; Progressive, Kjartan Mohr; Social
Democratic, Atli Dam; Union, Kristian Djurhuus
Voting strength (1970 election): Peoples 20.0%, Republican 20.0%, Home Rule
5.6%, Progressive 3.5%, Social Democratic 27.2%, Union 21.7%
Communists: insignificant number
Member of: Nordic Council','1d11dba4848ad343521d42ec86dbf8453b10eb31bbc80cff1e4427217e84c09f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aab8849d4593faad6eeb6cc616b1665e86bc2d1f9656c39689f7699c3650e492',1974,'AU','Australia','government',132,'Legal name: Dominion of Fiji
Type: independent state within Commonwealth; Elizabeth II recognized as head
of state
Capital: Suva
Political subdivisions: 14 provinces
Legal system: based on British
Branches: executive -- Prime Minister; legislative -- 52-member House of
Representatives; Alliance Party 33 seats, National Federation Party 19 seats
Government leader: Prime Minister Ratu Sir Kamisese Mara
Suffrage: universal adult
Elections: every 5 years unless House dissolves earlier, last held March-April 1972
Political parties: Alliance, primarily Fijian, headed by Ratu Mara; National
Federation, primarily Indian, headed by S. M. Koya
Communists: few, no figures available
Member of: Commonwealth, U.N.
Legal name: Republic of Indonesia
Type: republic
Capital: Jakarta
Political subdivisions: 26 first-level administrative subdivisions or provinces
which are further subdivided into 281 second-level areas
Legal system: based on Roman-Dutch law, substantially modified by indigenous
concepts; constitution of 1945 is legal basis of government; Tegal education
at University of Indonesia, Jakarta; has not accepted compulsory ICJ
jurisdiction
Branches: executive headed by President who is chief of state and head of
cabinet; cabinet selected by President; unicameral legislature (Parliament),
of 460 members (100 appointed, 360 elected); second and larger body (Congress)
of 920 members and includes the legislature and 460 other members (chosen by
several processes, but not directly elected) elects President and Vice
President, and theoretically determines national policy
Government leader: President Suharto (elected by Congress March 1973)
Suffrage: universal over age 17 and married persons regardless of age
Political parties and leaders: Golkar (quasi-official "party" based on functional
groups), Amir Moertono; Indonesian Democratic Party (federation of former
Nationalist and Christian parties), Mohanmed Isnaeni; Unity Development
Party (federation of former Islamic parties), Idham Chalid
Voting strength (1971 election): Golkar 236 seats, Indonesian Democratic 30,
Unity Development 94
Communists: Communist Party (PKI) was officially banned in March 1966; current
strength est. at 1,000, with less than 10% engaged in oraanized activity; pre-
October 1965 hard-core membership has been estimated at 1.5 million
Member of: ADB, ASEAN, ECAFE, FAO, IAEA, ICAO, IHB, ILO, IMF, OPEC, U.N.
UNESCO
161
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: Empire of Iran
Type: constitutional monarchy, controlled by the Shah
Capital: Tehran
Political subdivisions: 20 provinces and 4 chief-governorates, subdivided
into districts, sub-districts, counties, and villages
Legal system: based largely on French law, with elements drawn from other
continental systems; personal law based on Islamic practice generally with
residual traces of Roman law; constitution adopted 1906 and constitutional
law of 1907; High Court of Appeal may judge disputes relating to government
departments acting according to law; legal education at University of Teheran;
has not accepted compulsory [CJ jurisdiction
Branches: executive power rests in Shah who appoints a Prime Minister; Prime
Minister must be approved by lower house (Majlis); while Cabinet theoretically
responsibility of Prime Minister, Shah usually exerts strong influence over
its selection; bicameral legislature; Majlis has 268 members elected to
4-year terms, and Senate 60 members serving 4-year terms; half of Senate
members appointed by Shah, other half elected; no provision for judicial
review of constitutionality of legislative acts
Government leaders: Shah Mohammad Reza Pahlavi and Prime Minister Amir
Abas Hoveyda
Suffrage: universal over age 20
Elections: Majlis every 4 years; Senate every 4 years; latest national elections
July 1971, district and municipal elections in October 1972
Political parties and leaders: New Iran Party, Manuchehr Kalalis Mardom (Peoples)
~ Party, Nasser Ameri; Iranians Party, Dr. Fazlollah Sadr; Pan Iranist Party,
Mohsen Pezeshkpur
Voting strength (1971 election): Majlis -- New Iran Party, 230 seats; Mardom
Party, 37 seats; Iranians Party, 1 seat; Senate -- New Iran Party, 28 seats;
Mardom Party, 2 seats; plus 30 seats appointed by the Shah; all candidates
government approved
‘ Communists: 1,000-2,000 (hard-core, est.); sympathizers (15,000-20, 000 est.);
mostly pro-U.S.S.R. but pro-Chinese faction developing
163
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Other political or pressure groups: Tudeh Party (Communist, illegal); National
Front (coalition of neutralist urban elements virtually discredited because
a eee to Shah''s reform program); Confederation of Iranian Students
illegal
Member of: CENTO, Colombo Plan, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO. IMCO,
IMF, ITU, OPEC, RCD, U.N., UNESCO, UPU. WHO, WMO
Legal name: Republic of Iraq
Type: republic; National Front Government consisting of Ba''ath Party (BPI), and
Iraq Communist Party (CPI) formed in July 1973 (Kurds invited to join National
Front government but have refused pending solution of Kurdish autonomy issue)
Capital: Baghdad
Political subdivisions: 16 provinces under centrally appointed officials
Legal system: based on Islamic law in special religious courts, civil law system
elsewhere; provisional constitution adopted in 1968; judicial review was
suspended; legal education at University of Baghdad; has not accepted
compulsory [Cd jurisdiction
Branches: Ba''th Party of Iraq has been in Power since 1968 coup
Government leaders: President Ahmad Hasan al-Bakr; Deputy Chairman of the
Revolutionary Command Council Saddam Husayn ''Abd-al-Majid al-Tikriti
Suffrage: no elective bodies exist
Elections: no national elections since overthrow of monarchy in 1958
Communists: Communist Party allowed token representation in cabinet
Political or pressure groups: political parties banned, major opposition to
regime is from disaffected members of the regime and army officers
Member of: Arab League, FAQ, IAEA, IBRD. ICAO, IDA, IFC, ILO, IMF, ITU, OPEC,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Mongolian People''s Republic
Type: Communist state
Capital: Ulaanbaatar
Political subdivisions: 18 provinces and 2 autonomous municipalities (Ulaanbaatar
and Darhan)
Legal system: blend of Russian, Chinese, and Turkish systems of law; constitution
adopted 1940; no constitutional provision for judicial review of legislative
acts; legal education at Ulaanbaatar State University; has not accepted
compulsory ICJ jurisdiction
Branches: constitution provides for a Great People''s Hural (national assembly)
and a highly centralized administration
Party and government leader: Y. Tsedenbal, First Secretary of the MPRP and
Chairman of the Council of Ministers
Suffrage: universal; age 18 and over
Elections: national assembly elections held every 4 years; last elections held
in June 1973
Political party: Mongolian Peopte''s Revolutionary (Communist) Party (MPRP);
estimated membership, 58,000 (claimed 1972)
Member of: CEMA, ECAFE, IAEA, U.N., WHO
Legal name: Papua New Guinea
Type: dependent territory under Administrator appointed by Australia
Capital: Port Moresby
Political subdivisions: 18 administrative districts (12 in New Guinea, 6 in Papua);
New Guinea (including Bismarck archipelago and Bougainville) is a U.N. Trust
Terri tory
Legal system: based on English common law; highest judicial organ is High Court
of Australia
Branches: executive -- Administrator and Executive Council; legislature --
House of Assembly (94 members, including 10 appointed); judiciary -- court
system consists of Supreme Court of Papua New Guinea and various inferior
courts (District Courts, Local Courts, Children''s Courts, Wardens'' Courts);
Supreme Court decisions may be appealed to High Court of Australia
Government leader: Administrator, L. W. Johnson; Chief Minister, Michael Somare
Suffrage: universal adult suffrage
Elections: preferential-type elections for 100-member House of Assembly every
4 years
Political parties: Pangu Party is principal political group; 5 or 6 other
small parties and numerous independents
Voting strength (1972 election): Pangu Party and allies won 52 seats, United
Party 42 seats, Independence 6 seats
Communists: no significant strength
Legal name: Province of Timor
Type: overseas province of Portugal
Capital: Dili
Political subdivisions: 12 administrative townships
Legal system: based on Portuguese law
Branches: Governor appointed by overseas Minister in Lisbon, has wide local
authority; he is advised by a 12-member Consultative Council; a 21-member
Legislative Assembly (10 directly elected and 11 indirectly chosen) can pass
laws in restricted fields; Overseas Minister can veto any provincial legis-
lation or governor''s decision; judiciary based on Portuguese system
Government leader: Governor, Colonel Fernando Alves Aldea (appointed 1972)
Suffrage: Portuguese citizen for 5 years, 21 years old
Elections: Provincial Legislative Assembly elections every 4 years, last in March
1973; National Assembly in Lisbon elections every 4 years, last in October 1973
Political parties and leaders: single party only, the National Popular Action
on Timor
Voting strength: limited to Portuguese on Timor and small group of Timorese
who fulfill requirement
Communists: prior to 1 October 1965, ‘infiltration by Indonesian Communist Party
from Indonesian Timor, especially in the Oe-Cusse enclave','468972b8c7846d33905fb1ecb2d5699a50ba04b519d7fc24cbbcdda7ed5596d9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f89c3f517388a5baf84e7149fbe962256b698df45a080300041d1704eba524c',1974,'FI','Finland','government',135,'Legal name: Republic of Finland
Type: republic
Capital: Helsinki
- Political subdivisions: 12 provinces; 443 communes, 78 towns
Legal system: civil law system based on Swedish laws; constitution adopted 1919;
Supreme Court may request legislation interpreting or modifying laws; legal
education at Universities of Helsinki and Turku; accepts compulsory ICJ
jurisdiction, with reservations
Branches: legislative authority rests jointly with President and parliament
(Eduskunta); executive power vested in President and exercised through
cabinet responsible to parliament; Supreme Court, 4 superior courts,
193 lower courts
Government leader: President Urho K. Kekkonen; Prime Minister Kalevi Sorsa
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1976); presidential, every
6 years (extra ordinary parliamentary legislation extended President
Kekkonen''s term, which normally expires in 1974, to 1978)
Political parties and leaders: Social Democratic, Rafael Paasio; Center,
Johannes Virolainen; Peoples Democratic League (Communist front), Ele
Alenius; Conservative, Harri Holker; Liberal, Pekka Tarjanne; Swedish Peoples
Party, Kristan Gestrin; Rural, Veikko Vennamo; Finnish Peopie''s Unity Party,
Eino Haikala; Communist, Aarne Saarinen
Voting strength (1972 election): 25.8% Social Democratic, 17.5% Conservative,
17.1% People''s Democratic League, 16.5% Center, 9.2% Rural, 5.3% Swedish
Peoples, 5.1% Liberals, 2.5% Christian Peoples, 1.0% other
Communists: 47,000; an additional 65,000 persons belong to Peoples
Democratic League; a further number of sympathizers, as indicated by
421,000 votes cast for Peoples Democratic League in 1970 elections
Member of: CEMA (special cooperation agreement), EC (free trade agreement), FAO,
GATT, IAEA, IBRD, ICAQ, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, Nordic Council, GECD,
Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO
109
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','b61efa63809d48815ea9aa6951dde3f422ef0249fd947911569431ddc1035214','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99b8da10b27e0c2c0f163b1065a1ae12a9c8462a36ae0ab3c5132aaa1223784c',1974,'FR','France','government',139,'Legal name: French Republic
Type: republic, with president having wide powers
Capital: Paris
Political subdivisions: 95 metropolitan departments, 21 regional economic
districts
Legal system: civil law system with indigenous concepts; new constitution
adopted 1958, amended concerning election of President in 1962; judicial
review of administrative but not legislative acts; legal education at over
25 schools of law
Branches: presidentially appointed Prime Minister heads Council of Ministers,
which is formally responsible to National Assembly; bicameral legislature
-- National Assembly (490 members), Senate (283 members) restricted to a
delaying action; judiciary independent in principle
Government leader: President Valery Giscard d''Estaing
Suffrage: universal over age 21; not compulsory
Elections: National Assembly -- every 5 years, last election March 1973, direct
universal suffrage, 2 ballots; Senate -- indirect collegiate system for 9
years, renewable by one-third every 3 years; President -- direct, universal
suffrage every 7 years, 2 ballots, last election May 1974
Political parties and leaders: Union of Democrats for the Republic (UDR);
Independent Republicans (IR), Valery Giscard d''Estaing; Communist (PCF),
George Marchais; Progress and Modern Democracy (PDM), Jacques Duhamel;
Left Radical Party, Robert Fabre; Movement for Reform, coalition of Center
Democratic Party, Jean Lecanuet and Radical Socialists, Jean Jacques
Servan-Shreiber; Socialist Party, Francois Mitterrand; Unified Socialist
Party (PSU), Michel Rocard
Voting strength (first ballot, 1974 election): 43.2% Communist Socialist Alliance,
32.6% IR, 15.1% UDR, 9.1% other
Communists: 250,000-300,000 (est.); Communist voters, 5 million average
Other political or pressure groups: Communist-controlled labor union
(Confederation Generale du Travail) nearly 1,500,000 members (est.),
National Council of French Employers (Conseil National du Patronat
Francais -- CNPF or Patronat)
11
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Member of: Council of Europe, EC, FAO, IAEA, IBRD, ICAO, IHB, ILO, IMCO, IMF, ITU,
NATO (signatory), OECD, Seabeds Committee, SEATO, South Pacific Commission,
U.N., UNESCO, UPU, WEU, WHO, WMO
Legal name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for administrative purposes has 3
districts (Luxembourg, Diekirch, Grevenmacher) and 12 cantons
Legal system: based on civil law system; constitution adopted 1868; judicial
review of legislative acts in the Cassation Court only; accepts compulsory
ICJ jurisdiction
Branches: parliamentary democracy; seven ministers comprise Council of Government
headed by President, which constitutes the executive; it is responsible to
the unicameral legislature, the Chamber of Deputies; the Council of State,
appointed for indefinite term, exercises some powers of an upper house;
judicial power exercised by independent courts
Government leaders: Grand Duke Jean, Head of State; Gaston Thorn, President
Suffrage: universal and compulsory over age 18
Elections: every 5 years for entire Chamber of Deputies; latest elections May 1974
Political parties and leaders: Christian Social Union, Pierre Werner and Nic Mosar
(Party President); Socialist, Antone Wehenkel (Party President); Social
Democrat, Henry Cravatte (Party President); Democratic, Gaston Thorn (Party
President and Foreign Minister); Communist, Dominique Urbany
Voting strength in Chamber of Deputies (1974): Christian Socialist, 18; Socialist
Workers, 17; Democrats, 14; Social Democrats, 5; Communists, 5
Communists: 439 party members (1971)
Other political or pressure groups: group of steel industries representing iron
and steel industry, Centrale Paysanne representing agricultural producers;
Christian and Socialist labor unions, Federation of Industrialists; Artisans
and Shopkeepers Federation
Member of: Benelux, BLEU (Belgium-Luxembourg Economic Union), Council of Europe,
EC, FAQ, IAEA, IBRD, ICAO, IFC, ILO, IMF, NATO, OECD, U.N., UPU, WEU, WHO, WMO
203
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','47371fd1fceb624430a63ea450df23a2d3176670b0f7b1c10616f93a48bc8207','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07b4c0fbfcb47a371a3dfca15dd4f42aa11bdec77c514f6da10e5fe0fd59f032',1974,'GF','French Guiana','government',143,'Legal name: Overseas Department of French Guiana
Type: overseas department of France; represented by one deputy in French National
Assembly and one senator in French Senate
Capital: Cayenne
is Political subdivisions: 2 arrondissements, 19 communes each with a locally elected
municipal council
Legal system: French legal system; highest court is Court of Appeal based in
Martinique with jurisdiction over Martinique, Guadeloupe, and French Guiana
Branches: executive: prefect appointed by Paris; legislative: popularly elected
16-member General Council; judicial, under jurisdiction of French judicial
system
Government leader: Prefect Herve Bourseiller
Suffrage: universal over age 21
Elections: General Council elections coincide with those for the French National
Assembly, normally every 5 years; last election March 1973; local elections
last held September 1973
Political parties and leaders: Parti Socialiste Guyanais (PSG), Leopold Heder,
Senator; Union du Peuple Guyanaise (UPG), weak leftist allied with, but
also reported, to have been absorbed by the PSG; Union of Democrats for the
Republic (UDR), Hector Rivierez, delegate to French National Assembly
Communists: Communist party membership negligible :','9395b8aa0e99c6826f20601be3aca0c8c7891f9c8f9dcbb40827456de8611091','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d9fa735e079644b7f59c57a20bdb22731ba3c949144857d46aac6fe2246142c',1974,'PF','French Polynesia','government',147,'Legal name: Territory of French Polynesia
Type: overseas territory of France, administered by French Ministry for
Overseas Territories
Capital: Papeete
Political subdivisions: 5 districts
Legal system: based on French; lower and higher courts
Branches: 30-member Territorial Assembly, popularly elected; 5-member Council of
Government, elected by Assembly; popular election of one deputy to National
Assembly in Paris, also one Senator
Government leader: Pierre Angeli, Governor, appointed by French government
Suffrage: universal adult
Elections: every 5 years
Political parties and leaders: Pupu Here Ai''a, Senator Pouvanna a Oopa, John
Teariki; Te E''a Api, Francis Sanford; Union Tahitienne-Union pour la
Defense de 1a Republique, Te Autahoera''a
Legal name: Overseas Territory of Afars and Issas
Type: overseas territory of France; represented by one deputy in French National
Assembly and by one senator in French Senate
Capital: Djibouti
Legal system: based on French civil law system, traditional practices and
Islamic Taw
Branches: President of Council of Government; 8-member Council of Government
appointed by 40-member Chamber of Deputies; ultimate political authority
exercised by Paris-appointed President of the Council of Government, sometimes
* referred to as Prime Minister
Government leader: Ali Aref Bourhan
Suffrage: universal
Elections: Chamber of Deputies election held November 1973
Political parties and leaders: Rassemblement Democratique Afar, Ali Aref Bourhan;
Union Democratique Afar; Union Populaire Africaine; Union Democratique
Issa, Oman Farah Iltireh; African People''s League, Hassan Gouled
Communists: possibly a few sympathizers','d2d2fb99d13c1a81e8b03d144942fbbb8c40fb32af0dfa7122c5d66fc0ae7398','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6082deb577bcc91055459260d8797597ea2a0bed4eb738f7d650e650e2641166',1974,'GA','Gabon','government',151,'Legal name: Gabonese Republic
Type: republic; one-party presidential regime since 1964
Capital: Libreville
Political subdivisions: 9 regions, 6 communes, 4,500 villages
Legal system: based on French civil law system and customary law; constitution
adopted 1961; judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; legal education at Center of Higher and Legal Studies
at Libreville; compulsory ICJ jurisdiction not accepted
Branches: power centralized in President, elected by universal suffrage for
7-year term; unicameral 70-member National Assembly has limited powers ;
judiciary
Government leader: President Omar Bongo
Suffrage: universal over age 2]
Elections: Presidential and parliamentary elections last held February 1973
Political parties and leaders: Gabonese Democratic Party (PDG) led by President
Bongo is only legal party
Communists: no organized party; probably some Communist sympathizers
Member of: ACCT, AFDB, Conference of East and Central African States, EAMA, FAO,
IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU, OCAM, UDEAC, U.N., UNESCO, UPU, WHO, WMO','0525c656551d074ff390595f11a93511dcfc4c6b11b1a4618cea5a741b533937','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97b547caea251c748e64fe0bdc70cf7606cde2883393c77f244bd017ea4155d7',1974,'GM','Gambia','government',155,'Legal name: Republic of The Gambia
Type: republic; independent since February 1965
Capital: Banjul
Political subdivisions: Banjul and 5 divisions
Legal system: based on English common law and customary law; constitution came
into force upon independence in 1965, new republican constitution adopted in
April 1970; accepts compulsory ICd jurisdiction, with reservations
Branches: cabinet of 10 members; 41-member House of Representatives, in which
4 seats are reserved for chiefs, 4 are appointed, 32 are filled by election
for 5-year terms, a Speaker is elected by the House, and the Attorney
General is an ex-officio member; independent judiciary
Government leader: Dawda K. Jawara, President
Political parties and leaders: People''s Progressive Party (PPP), Secretary
General Dawda K. Jawara, and United Party (UP), John Forster
Suffrage: universal adult
Elections: general elections held March 1972; PPP 28 seats, UP 3 seats, ]
independent seat
Communists: insignificant number
Member of: Commonwealth, ECA, OAU, U.N.
Legal name: German Democratic Republic
Type: Communist state
Capital: East Berlin (not officially recognized by U.S., U.K., and France, which
together with the U.S.S.R. have special rights and responsibilities in Berlin)
Political subdivisions: (excluding East Berlin) 14 districts (Bezirke), 218
counties (Kreise), 8,777 communities (Gemeinden)
Legal system: Civil law system modified by Communist legal theory; new constitution
adopted 1968 by approx. 95% of the voters in national "referendum;" court
system parallels administrative divisions; no judicial review of legislative
acts; legal education at Universities of Berlin, Leipzig, Halle and Jena;
has not accepted compulsory ICJ jurisdiction; more stringent penal code
adopted 1968
Branches: legislative -- Volkskammer (elected directly); executive -- Chairman
of Council of State, Chairman of Council of Ministers, Cabinet (approved by
Volkskammer); judiciary -- Supreme Court; entire structure dominated by
Socialist Unity (Communist) Party
Government leaders: Chairman, Council of State, Willi Stoph (Head of State);
Chairman, Council of Ministers, Horst Sindermann (Head of Government)
Suffrage: all citizens age 18 and over
Elections: national and local alternating every 2 years; prepared by an electoral
commission of the National Front; ballot supposed to be secret and voters
permitted to strike names off ballot; more candidates than offices available;
parliamentary elections held 14 November 1971; local elections, 22 March 1970
Political parties and leaders: Socialist Unity (Communist) Party (SED), headed
by First Secretary Erich Honecker, dominates the regime; 4 token parties
(Christian Democratic Union, National Democratic Party, Liberal Democratic
Party, and Democratic Peasants'' Party) and an amalgam of special interest
organizations participate with the SED in National Front
Voting strength: 1971 parliamentary elections: 98.33% voted the regime slate; 1970
local elections: 99.85% voted the regime slate
Communists: 1.9 million party members
Other special interest groups: Free German Youth, Free German Trade Union
Federation, Democratic Women''s Federation of Germany, German Cultural
Federation (a11 Communist dominated)
Member of: CEMA, IPU, U.N., Warsaw Pact
125
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','02d6d69c4145e56084e5f2d982d84eb8ee30822ab78708248b345f9d26dbaed9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7025a5939c7d331d4a0e7f00c76343d26734426d6a13db046935ebfa0a680e0f',1974,'GH','Ghana','government',159,'Legal name: Republic of Ghana
Type: republic; independent since March 1957; Military regime since January 1972
Capital: Accra
Political subdivisions: 8 administrative regions and separate Greater Accra
s Area; regions subdivided into 58 districts and 267 local administrative districts
Legal system: based on English common law and customary law; constitution
suspended January 1972; legal education at University of Ghana (Legon);
has not accepted compulsory ICJ jurisdiction
Branches: executive and legislative authority vested in National Redemption
Council (NRC); independent judiciary
Government leaders: chief of state, chairman of NRC Colonel I.K. Acheampong
Suffrage: universal over 21 under previous constitution, now suspended
Elections: no elections since 1969; none scheduled
Political parties and leaders: parties banned by military junta which took
power 13 January 1972
Communists: a small number of Communists and sympathizers
Member of: AFDB, Commonwealth, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU,
OAU, U.N., UNESCO, UPU, WHO, WMO','1caab044bf89b136b5863e66aad31d444a3c480b8bd3428ca60861f1082867ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6122b4cc42c0213154c29f25c55df8b987f9143720462cf55cc4a5c544c0ad5',1974,'GI','Gibraltar','government',162,'Legal name: Colony of Gibraltar
Type: U.K. colony
Capital: none
Legal system: English law; constitutional talks in July 1968; new system
effected in 1969 after electoral enquiry
Branches: parliamentary system comprised of the Gibraltar House of the Assembly
(15 elected members and 3 ex officio members), the Council of Ministers
headed by the Chief Minister, and the Gibraltar Council; the Governor is
appointed by the Crown
Government leaders: Governor and Conmander in Chief, Adm, of the Fleet Sir
Varyl Begg; Chief Minister, Maj. Robert Peliza; Deputy Chief Minister,
Peter Isola
Suffrage: all adult Gibraltarians, plus other U.K. subjects resident 6 months
or more
Elections: every 5 years; last held in July 1969
Political parties and leaders: Association for Advancement of Civil Rights
(AACR), Sir Joshua Hassan; Labor, Sir Joshua Hassan; Independents, Peter
Isola; Integrationists (INBP), Maj. Robert Peliza
Voting strength: (1969) AACR 7 seats, IWBP 5 seats, Independents 3 seats; a
coalition between the latter two parties was formed
Communists: none known
Other political or pressure groups: the Housewives Association; the Chamber
of Commerce
Legal name: Gilbert and Ellice Islands Colony
Type: British crown colony with large measure of self-government
Capital: Tarawa
Political subdivisions: 4 districts
Branches: 10-member Executive Council advises Governor; 33-member Legislative
Council
Government leader: Governor John H. Smith
Political parties and leaders: Gilbertese National Party, Christian Democratic
Party','317459685f1d776697e421f506a6df4d2f51f4b719b447c9e820ac152ac4b8ce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('935d1f325051d29e822b4407577195099d82fdfe70a5b515837f4393bd5b0d9d',1974,'GR','Greece','government',167,'Legal name: Hellenic Republic
Type: presidential republic; power in hands of ex-military leaders since Aprii
1967 but there is a civilian Prime Minister and a civilian cabinet
Capital: Athens
Political subdivisions: 52 departments (nomoi} constitute basic administrative
units for country; each nomos headed by officials appointed by central
government and policy and programs tend to be formulated by central ministries;
degree of flexibility each nomos may have in altering or avoiding programs
imposed by Athens depends upon tradition (Thessaloniki and other areas
exercise considerable traditional autonomy in local administrative decisions)
and influence which prominent local leaders and citizens may exercise vis-a-vis
key figures in central government; Government installed November 25, 1973,
scrapped decentralization and regionalization goals of former Papadopoulos
regime.
Legal system: 1968 Constitution amended substantially in July 1973 and subsequently
entire constitution suspended November 1973 with promise of further major
revisions in future before its re-institution
Branches: military junta combines legislative executive and judicial functions;
rules by decree :
Government leaders: President General Phaidon Gizikis; Prime Minister Adamandios
Androutsopoulos; Military Police Chief Brig. Gen. Dimitrios Ioannidis js
strong man of the regime
Suffrage: universal age 21 and over
Elections: suspended indefinitely
Political parties and leaders: political activities suppressed; party leadership
and organization in disarray
Communists: 12% of electorate in February 1964; hard-core elements imprisoned;
Communist Party (KKE) outlawed since 1947
Member of: EC (associate member), FAO, FUND, IAEA, IBRD, ICAO, IDA, IFC, IHB,
ILO, IMCO, ITU, NATO, OECD, U.N., UNESCO, UPU, WHO, WMO
135
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','4b4633349e34661be28f7cb18779a261a1c5ce628038c1609871acdac8e3003f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90dd8e04c3be50a88b839a9695d7ae69980783477d5b5cda96837ebb59692594',1974,'GL','Greenland','government',171,'Legal name: Greenland
Type: province of Kingdom of Denmark; 2 representatives in Danish parliament;
separate Minister for Greenland in the Danish cabinet
Capital: Godthaab (administrative center)
Political subdivisions: 3 counties, 19 communes
Legal system: Danish law; transformed from colony to province in 1953
Branches: legislative authority rests jointly with Crown and Danish parliament;
executive power vested in Crown, acting through provincial governor
responsible to Minister for Greenland; local affairs handled by provincial
council (Landsrad) subject to approval of provincial governor; 19 lower courts
Government leader: Queen Margrethe II; Governor N.O. Christensen
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years (next 1975)
Political parties: Inuit (advocating close ties with Denmark); Sukaq (moderate
socialist, advocating more distinct Greenland identity)','9e48321bea8828f5a2c83e5c70b33ba83e337fe60e4e5037c8dd2f0229a41c62','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a56922f394fcd4543d60a0a56a1091d4f753d2c2c4010df23400731260d7318',1974,'GP','Guadeloupe','government',176,'Legal name: Overseas Department of Guadeloupe
Type: overseas department of France; represented by 3 deputies in the French
National Assembly and 2 Senators in the Senate
Capital: Basse-Terre
Political subdivisions: 3 arrondissements; 34 communes, each with a locally
elected municipal council]
Legal system: French legal system; highest court is a court of appeal based
in Martinique with jurisdiction over Guadeloupe, French Guiana, and Martinique
Branches: executive, Prefect appointed by Paris; legislative, popularly elected .
General Council of 36 members; judicial, under jurisdiction of French judicial
system
Government leader: Prefect Pierre Brunon
Suffrage: universal over age 21
Elections: General Council elections coincide with those for the French National
Assembly, normally every 5 years; last General Council election took place
in March 1973; local election last held September 1973
Political parties and leaders: Union of Guadeloupean Democrats for the Republic
(UDG), Gabriel Lisette; Communist Party of Guadeloupe (PCG) Henri Bangou;
Socialist Party (MSG), leader unknown; Progressive Party of Guadeloupe (PPG),
Henri Rodes; Independent Republicans; Federation of the Left
Voting strength: MSG, 1 seat in French National Assembly; UDG, 2 seats;
(1973 election)
Communists: 3,000 est.
urs Te or pressure groups: Group of National Organization of Guadeloupe
GONG','ccb6282531f6323d05a8b04a30a9e16f0f5452768501e49ab832a6cafb05316b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68878273d88c32ab794d9aad91142785d5a1a9bcf6bcd2a9b97439c30fc6edb1',1974,'GT','Guatemala','government',179,'Legal name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions: 22 departments
Legal system: civil law system; constitution came into effect 1966; judicial
review of legislative acts; legal education at University of San Carlos of
Guatemala; has not accepted compulsory ICJ jurisdiction
Branches: traditionally dominant executive; elected unicameral legislature;
7-menber (minimum) Supreme Court
Government leader: President Carlos Arana; Kjell Laugerud assumes presidency on
July 1, 1974
Suffrage: universal over age 18, compulsory for literates, optional for illiterates
Elections: next elections tPrasidant and Congress) 1978
Political parties and leaders: Democratic Institutional Party (PID), Donaldo
Alvarez Ruiz; Revolutionary Party (PR), Carlos Sagastume Perez (Sec. Gen.);
National Liberation Movement (MLN), Mario Sandoval Alarcon; Guatemalan
Christian Democratic Party (DCG), Danilo Barillas Rodriguez, Rene de Leon
Schlotter
Voting strength: for President -- MLN-PID 298,953 (44.6%), DCG 228,067 (34.0%),
PR 143,111 (21.4%); for congressional seats -- MLN-PID 36, DCG 15, PR 10
Communists: communist party outlawed; underground membership estimated at 750
Other political or pressure groups: outlawed (Communist) Guatemalan Labor Party
(PGT), Bernardo Alvarado; United Democratic Revolutionary Front (FURD) Manuel
Colom Argueta
Member of: CACM, IADB, IAEA, ICAQ, IHB, OAS, ODECA, U.N,
ICONOMY :
GDP: $2,250 million (1973 est.), $390 per capita; 79% private consumption, 8%
government consumption, 14% domestic investment, -1% net foreign balance; real
growth rate 1973, 7%
Agriculture: main products -- coffee, cotton, corn, beans, sugarcane, bananas,
livestock; caloric intake, 2,200 calories per day per capita (1967)
Fishing: catch 5,000 metric tons (1970); exports $1.6 million (1970), imports
$0.5 million (1970)
143
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
ECONOMY (cont''d):
Major industries: food processing, textiles and clothing, furniture, chemicals,
nonmetallic minerals, metals
Electric power: 212,000 kw. capacity (1971); 830 million kw.-hr. produced
(1971), 150 kw.-hr. per capita
Exports: $446 million (f.0.b., 1973 prelim.); coffee, cotton, meat, bananas, sugar,
textiles, tires
Imports: $421 million (c.i.f., 1973 prelim.); manufactured products, machinery,
transportation equipment, chemicals, fuels
Major trade partners: exports (1972) -- U.S. 30%, CACM 30%, West Germany 10%,
Japan 7%; imports (1972) -- U.S. 32%, CACM 21%, West Germany 9%, Japan 9%
Aid:
economic -- from U.S. (FY46-72), $191.1 million loans, $185.4 million grants;
from international organizations (FY46-72), $146.8 million; from other
western countries (1960-71), $12.3 millions military -- assistance from
U.S. (FY53-72), $26.9 million
Central government budget (1973): total appropriations $291.8 million
Monetary conversion rate: 1 quetzal=US$1 (official)
Fiscal year: calendar year','b45fe874f356f13b3fb4212e557e13384dfbd911ecc4ca91e1f75194b919fc12','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6413f1f952d1fbdc6b7da9d04f60f5c3b24d92113fe610ab318674317cba8e7a',1974,'GN','Guinea','government',182,'Legal name: Republic of Guinea
Type: republic; under one-party presidential regime
Capital: Conakry
Political subdivisions: 29 administrative regions, 209 arrondissements, about
8,000 local entities at village level
Legal system: based on French civil law system, customary law, and presidential
decree; constitution adopted 1958; no constitutional provision for judicial
review of legislative acts; has not accepted compulsory ICJ jurisdiction
Branches: executive branch dominant, with power concentrated in President''s
hands and a small group who are both ministers and members of the party''s
politburo; unicameral National Assembly and judiciary have little independence
Government leader: President Ahmed Sekou Toure, who has been designated
"The Supreme Leader of the Revolution"
Suffrage: universal over age 18
Elections: approximate schedule -- 5 years parliamentary, latest in 1968;
7 years Presidential, latest in 1968
Political parties and leaders: only party is Democratic Party of Guinea (PDG),
headed by Sekou Toure
Communists: no Communist party, although there are some sympathizers
Member of: AFDB, ECA, FAO, ICAO, ILO, ITU, Niger River Commission, OAU, U.N.,
UNESCO, UPU, WHO, WMO','803fb0f3601931f40c73592930c0a7f21c69692e82ea2868f6e667d74fe882e2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cfad864a211364a51589d7c28349111661a4bf4c037d3b20224326f10290356',1974,'HK','Hong Kong','government',189,'Legal name: Colony of Hong Kong
Type: U.K. crown colony
Capital: Victoria
Political subdivisions: Hong Kong, Kowloon, and New Territories
Legal system: English common law
Branches: Governor assisted by advisory Executive Council; he legislates with
advice and consent of Legislative Council; Urban Council which alone includes
elected representatives, responsible for health, recreation, and resettlement;
independent judiciary
Government leader: C.M. MacLehose, Governor and Commander in Chief
Suffrage: limited to 200,000 to 300,000 professional or skilled persons
Elections: every 2 years to select one-half of elected membership of Urban
Council; other Urban Council members appointed by the Governor
Political parties and leaders: Civic Association, Hu Pai-fu; Reform Club, B. A.
Bernacchi; Socialist Democratic Party, Sun Po-kong; Hong Kong Labour Party,
Tang Hon-tsai
Voting strength: (elected Urban Council members) Civic Association 4, Reform
Club 3, and 1 independent
Communists: an estimated 2,000 hard core cadres affiliated with Communist Party
of China
Other political or pressure groups: Federation of Trade Unions (Communist
controlled), Hong Kong and Kowloon Trade Union Council (Nationalist Chinese
dominated), Hong Kong General Chamber of Commerce, Chinese General Chamber
of Conmerce (Communist controlled), Federation of Hong Kong Industries,
Chinese Manufacturers! Association of Hong Kong','2aba7a953b84f99015c60c157a7c66e1aa8d2e102690277d1965aea4592cb61f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edbd06eef33f95c63cf4f4020c831ff78affe9944796d8fb1fefbd0639803e89',1974,'HU','Hungary','government',193,'Legal name: Hungarian People''s Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 megyes (counties), 5 autonomous cities in county
status, 97 jaras (districts)
Legal system: based on Communist Tegal theory, with both civil law system (civil
code of 1960) and common law elements; constitution adopted 1949 amended 1972;
Supreme Court renders decisions of principle that sometimes have the effect of
= declaring legislative acts unconstitutional; legal education at Lorand Eotvos
Tudomanyegyetem School of Law in Budapest and 2 other schools of Taw; has not
accepted compulsory ICJ jurisdiction
Branches: executive -- Presidential Council (elected by Parliament); legislative
-- Parliament (elected by direct suffrage); judicial -- Supreme Court
i (elected by Parliament)
Government leaders: Jeno Fock, Chairman, Council of Ministers; Pal Losonczi,
President, Presidential Council
Suffrage: universal over age 18
Elections: every 4 years; national and local elections are held separately, two
years apart
Political parties and leaders: Hungarian Socialist (Communist) Workers Party
(sole party); Janos Kadar is First Secretary of Central Committee
Voting strength (1971 election): 7,260,856 (98%) for Communist-approved candidates;
76,725 (1.4%) invalid and negative votes; total eligible electorate about
7.3 million
Communists: about 693,000 party members (June 1971)
Member of: CEMA, FAQ, IAEA, ICAQ, ILO, ITU, UNESCO, U.N., UPU, Warsaw Pact, WHO','cbbdc148fc0c32c303c7d644e77d796891c9cae943e30ba4476484f695aaa4e8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('927c9ffab76f9aef692296a9f21de52834f28cc6939915cb2b4378f3d4afb05e',1974,'IN','India','government',197,'Legal name: Republic of India
Type: federal republic
Capital: New Delhi
Political subdivisions: 21 states, 9 union territories, 1 protectorate (Sikkim)
Legal system: based on English common law; constitution adopted 1950; judicial
review of legislative acts; accepts compulsory [CJ jurisdiction, with
reservations
Branches: parliamentary government, national and state; independent judiciary
Government leader: Prime Minister Indira Gandhi
Suffrage: universal over age 21
Elections: national and state elections ordinarily held every 5 years; may be
postponed in emergency and may be held more frequently if government loses
confidence vote; next general election to be held by March 1976; 16 states
held state elections in 1972; 4 states in 1974
Political parties and leaders: Indian National Congress split into two factions
in 1969, largest faction (the Ruling Congress) loyal to Prime Minister Gandhi
led by S.D. Sharma, and smaller faction (the Organization Congress) led by
Ashoka Mehta; Communist Party of India (CPI), S. A. Dange, chairman; Communist
Party of India/Marxist (CPI/M), P. Sundarayya, general secretary; Communist
Party of India/Marxist-Leninist (CPI/ML), L.K. Advani, chairman; Swatantra,
P. Mody, chairman; Bharatiya Jana Sangh, A. B. Vajpayee, president; The
Socialist Party, Kappori Thakur, chairman; Dravida Munnetra Kazhagam (DMK),
N. Karunanidhi, president; Samyukta Socialist Party, Raj Narain, chairman
Voting strength (1971 election): 43.7% Ruling Congress, 10.5% Organization Congress,
7.4% Bharatiya Jana Sangh, 3.1% Swatantra, 4.8% CPI, 5.2% CPI/M, 3.5% Socialist
Parties, 3.7% DMK, 18.1% other
159
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Communists: 70,000 members of CPI (est.), 70,000 members of CPI/M; Communist
sympathizers, 13 million
Other political or pressure groups: Anna Dravida Munnetra Kazhagam (ADMK), M.G.
Ramachandran, president, opposing DMK in Tami] Nadu; splintered Akali Dal
representing Sikh religious community in the Punjab; various separatist groups
seeking reorganization of states; numerous "senas" or militant/chauvinistic
organizations, including Shiv Sena in Bombay, and the Anand Marg
Member of: ADB, Colombo Pian, Commonwealth, FAQ, IAEA, ICAO, IDA, IFC, IHB, ILO,
IMCO, IMF, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','6e606df7673294856a12f51d74c3283fef267b018331a6730a0a754ae7406de4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('306821119e24f3659a97d5d1e482ae34f6b1c8c8b3bce637988ca4d959026c9d',1974,'IT','Italy','government',203,'Legal name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution Provides for establishment of 20 regions;
5 (Sicilia, Sardegna, Trentino-Alto Adige, Friuli-Venezia Giulia, and Valle
d''Aosta) have been functioning for some time and the remaining 15 regions
were instituted on 7 April 1972: 94 provinces
Legal system: based on civil law system, with ecclesiastical law influence;
constitution came into effect 7 January 1948; judicial review under certain
conditions in Constitutional Court; has not accepted compulsory ICJ jurisdiction
Branches: executive -~ President empowered to dissolve Parliament and call national
election; he is also Commander of the Armed Forces and presides over the
Supreme Defense Council; otherwise, authority to govern invested in Council
of Ministers; legislative power invested in bicameral, popularly elected
Parliament; Italy has an independent judicial establishment
Government leaders: President Giovanni Leone; Premier Mariano Rumor
Suffrage: universal over age 21 (except in Senatorial elections where minimum
age of voter is 25)
Elections: national elections for Parliament held every 5 years (most recent,
May 1972); provincial and municipal elections held every 5 years with some
out of phase; regional elections every 5 years (due 1975)
Political parties and leaders: Christian Democratic Party (DC), Amintore Fanfani
(party secretary), Mariano Rumor, Aldo Moro, Emilio Colombo; Communist Party
(PCI), Luigi Longo, Enrico Berlinguer; Italian Socialist Party (PST), Francesco
De Martino, party secretary, Pietro Nenni, Giacomo Mancini, Mario Tanassi,
Giuseppe Saragat; Italian Social Democratic Party (PSDI), Flavio Orlandi
Liberal Party (PL1), Giovanni Malagodi; Italian Social Movement (MST), Giorgio
Almirante; Republican Party (PRI), Ugo La Malfa
Voting strength (1972 election): 38.8% DC, 27.2% PCI, 9.6% PSI, 3.9% PLI, 8.7%
MST, 2.9% PRI, 5.1% PSDI, 3.8% other
171
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Communists: 1,613,525 members; (as of 20 August 1973); number of sympathizers
cannot be determined
Other political or pressure groups: the Vatican; three major trade union
confederations (CGIL -- Communist dominated, CISL -- Christian Democratic,
and UIL -- Social Democratic and Republican); Italian manufacturers
association (Confindustria); organized farm groups
Member of: ECSC, EC, FAO. IAEA, IBRD, ICAO. IHB, ILO, IMCO, IMF, ITU, NATO, OECD
Seabeds Committee, U.N., UNESCO, UPU, WHO. WMO
Legal name: Republic of Ivory Coast
Type: republic, one-party presidential regime established 1960
Capital: Abidjan
Political subdivisions: 24 departments subdivided into 127 subprefectures
Legal system: based on French civil law system and customary Taw; constitution
adopted 1960, amended 1963; judicial review in the Constitutional Chamber
of the Supreme Court; legal education at Abidjan School of Law; has not
accepted compulsory ICJ jurisdiction
Branches: President has sweeping powers, unicameral legislature, separate judiciary
Government leader: President Felix Houphouet-Boi gny
Suffrage: universal over age 21
Elections: uncontested Presidential and legislative elections held in November
1970 for 5-year term
Political parties and leaders: Parti Democratique de la Cote d''Ivoire (PDCI),
(only party}; official party leader is Secretary General Philippe Yace, but
Houphouet-Boigny is in control
Communists: no Communist party; possibly some sympathizers
Member of: ACCT, AFDB, CEAO, EAMA, ECA, Entente, FAO. IAEA, IBRD, ICAQ, ILO. IMCO,
IMF, ITU, Niger River Commission, OAU, OCAM, U.N. UNESCO, UPU, WHO, WMO','d21830c39923d4184ff221fc200f53962aed30ddd28a7352c2d1fd95cc4cba36','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53e297920796ac44b31415211f5f32b5aa382cf8a7178c7b4261debe142367d6',1974,'JM','Jamaica','government',206,'Legal name: Jamaica
Type: independent state within Commonwealth since August 1962, recognizing
Elizabeth II as head of state
Capital: Kingston
Political subdivisions: 12 parishes and the Kingston-St. Andrew corporate area
> Legal system: based on English common law; has not accepted compulsory ICdJ
jurisdiction
Branches: cabinet headed by Prime Minister; 53-member elected House of Represent-
atives; 21-member Senate (13 nominated by the Prime Minister, 8 by opposition
leader); judiciary follows British tradition under a Chief Justice
Government leader: Prime Minister Michael Manley
Suffrage: universal, age 18 and over
Elections: at discretion of Governor-General upon advice of Prime Minister but
within 5 years; latest held 29 February 1972
Political parties and leaders: Jamaica Labor Party (JLP), Sir Alexander
Bustamante, Hugh Shearer; People''s National Party (PNP), Michael Manley
Voting strength (1972 general elections): 56.55% PNP, 43.21% JLP, 0.24% other
Communists: a few hundred Marxist and Communist sympathizers
Other political or pressure groups: New World Group (Caribbean regionalists,
nationalists, and leftist intellectual fraternity); Rastafarians (Negro
religious/racial cultists, pan-Africanists); New Creation International
Peacemakers Tabernacle (leftist group)
Member of: CARICOM, FAO, GATT, IAEA, IBRD, ICAO, IFC, ILO, IMF, OAS, Pan
= American Health Organization, Seabeds Committee (observer), U.N.','d87c543bc984ea8d1c6ad831dfc5569b5f194fcf74fa5b34154ff3072401ccc9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc040ce5e4ae106ea2233fa99c92a4a40a00d3a578eb999f4f6a99dd207cd2f0',1974,'JO','Jordan','government',210,'Legal name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital: ‘Amman
Political subdivisions: 8 districts (3 are under Israeli occupation) under
centrally appointed officials
Legal system: based on Islamic law and French codes; constitution adopted 1952;
judicial review of legislative acts in a specially provided High Tribunal;
has not accepted compulsory ICJ jurisdiction
Branches: King holds balance of power; Prime Minister exercises executive authority
in name of King; Cabinet appointed by King and responsible to parliament;
bicameral parliament with Chamber of Deputies last chosen by national elections
in April 1967, Senate last appointed by King in September 1971; each house
contains equal representation from East and West Jordan; present parliament
subservient to executive as a result af rigged elections (April 1967);
secular court system based on differing legal systems of the former
Transjordan and Palestine; law Western in concept and structure; Sharia
(religious) courts for Muslims, and religious community council courts for
ad non-Muslim communities; desert police carry out quasi-judicial functions
in desert areas
Government leader: King Husayn ibn Talal al-Hashimi
Suffrage: all citizens over age 20
Political parties and leaders: political party activity illegal since 1957;
Palestine Liberation Organization and Fatah, Yasir Arafat; various smaller
fedayeen groups; Ba''th Party of Jordan, Dr. Mun''if Razzaz; National
Socialist Party, Sulayman al-Nabulusi; Muslim Brethren
181
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Communists: party actively repressed, active membership less than 100
Member of: Arab League, FAO, IAEA, IATA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO','2b46ebaf4662fbf0e329687832f687be556a7b60467a6be1f78d262d51740618','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7471bd0bb96f9f17360c905ed708b5e9f2a09946db88452947fc4654edd756e1',1974,'KE','Kenya','government',214,'Legal name: Republic of Kenya
Type: republic within Commonwealth since December 1963
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi Area
Legal system: based on English common law, tribal law and Islamic law;
constitution enacted 1963; judicial review in Supreme Court; legal education
at University Kenya School of Law in Nairobi; accepts compulsory ICdJ
jurisdiction, with reservations
Branches: President and Cabinet responsible to unicameral legislature (National
Assembly) of 170 seats, 158 directly elected by constituencies and 12
appointed by the President; Assembly must be reelected at least every
5 years; High Court, with Chief Justice and at least 11 justices, has
unlimited original jurisdiction to hear and determine any civil or criminal
proceedings provision for systems of courts of appeal with ultimate appeal
to East African Court of Appeals
Government leader: President Jomo Kenyatta
Suffrage: universal over age 21
Elections: general election (December 1969) elected present National Assembly;
next elections promised for 1974
Political party and leaders: Kenya Africa National Union (KANU), president,
Jomo Kenyatta; next party election scheduled for 1974 ;
Voting strength: KANU holds all seats in the National Assembly
Communists: may be a few Communists and sympathizers
Other political or pressure groups: labor unions
Member of: EAC, IAEA, ICAO, OAU, Seabeds Committee, U.N.
Legal name: Democratic People''s Republic of Korea
Type: Communist state; one-man rule
Capital: P''yongyang
Political subdivisions: 9 provinces, 3 special cities (P''yongyang, Hamhung,
Ch''ongjin}, and 1 special district (Kaesong)
Legal system: based on German civil law system with Japanese influences and
Communist legal theory; constitution adopted 1948; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
Branches: Supreme Peoples Assembly theoretically supervises Legislative and
Judicial function
Government and party leaders: Kim I]-song, President and General Secretary
of the Korean Labor Party; Kim I1, Premier
Suffrage: Universal at age 17
Elections: election to SPA every 4 years, but this constitutional provision not
necessarily followed -- last election December 1972
Political party: Korean Labor (Communist) Party; claimed membership of about
1.6 million, or about 12% of population
Member of: IPU, U.N. (observer status only), UNCTAD, WHO
Legal name: Republic of Korea
Type: republic; power centralized in a strong executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities; heads centrally appointed
Legal system: combines elements of continental European civil law systems,
Anglo-American law, and Chinese classical thought; constitution approved
1972; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative (unicameral), judiciary, National Conference
of Unification
Government leaders: President Pak Chong-hui; Prime Minister Kim Chong-pi 1
Suffrage: universal over age 20
Elections: presidential every 6 years indirectly by the National Conference of
Unification, last election December 1972; two-thirds of the 219-member
National Assembly is elected directly for the same period within six
months of the presidential election, remaining third nominated by the
President and elected by the National Conference for a three-year term;
last election February 1973, Revitalization Group - 73 seats, Democratic
Republican Party - 73 seats, New Democratic Party - 52 seats, Democratic
Unification Party - 2 seats, Independents - 19 seats
Political parties and leaders: pro-government -- Revitalization Group (appointed)
(Chairman, Pak Tu-Chin) and Democratic Republican Party (Acting Chairman,
Yi Hyo-sang); New Democratic Party (Chairman, vacant); Democratic Unification
(Chairman, Yang I1-tong)
Voting strength: (1973 election) popular vote 11,896,484; DRP 38.8%, NDP 32.8%,
DUP 10.2%, Independent 18.1%, 0.1% invalid
Communists: Communist activity banned by government; an estimated 37,000-50,000
former members and supporters
Veterans'' Association; large potentially volatile student population
concentrated in Seoul
187
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Other political or pressure groups: Federation of Korean Trade Unions; Korean
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Member of: ADB, Asian Parliamentary Union, Asian People''s Anti-Communist League
(APACL), ASPAC, Colombo Plan, ECAFE, FAQ, GATT, Geneva Conventions of 1949
for the protection of war victims, IAEA, IBRD, ICAO, IDA, IFC, IHB, IMCO, IMF,
INTELSAT, Inter-Parliamentary Union, INTERPOL, ITU, UNESCO, U.N. Special Fund,
UPU, WHO, WMO, World Anti-Communist League (WACL); official observer at U.N.,
does not hold U.N. membership
Legal name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Al Kuwayt
Political subdivisions: 3 governorates, 10 voting constituencies
Legal system: civil law system with Islamic law significant in personal matters;
constitution took effect 1963, judicial review of legislative acts not yet
determined; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers; National Assembly
Government leader: Emir Sabah al-Salim Al Sabah
Suffrage: native born and naturalized males age 21 or over
Elections: held every 4 years for National Assembly; scheduled for January 1975
Political parties and leaders: political parties prohibited, some small
clandestine groups are active
Communists: insignificant
Other political or pressure groups: hone
Member of: Arab League, FAQ, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, ITU,
OPEC, OAPEC, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','60c4d774d2a2b9dfd1d77932660ee905c5051c7ea513e89e35f9e7ad9c326038','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ba8cf91f61fed14d93940f095202bf5afd1950fca2e274ad9acfecfb30652e9',1974,'DE','Germany','government',219,'Legal name: Kingdom of Laos
Type: constitutional monarchy
Capital: Vientiane (Luang Prabang royal capital)
Political subdivistons: 16 provinces subdivided into districts, cantons, and
villages
Legal system: based on civil law system; constitution of 1947 has not accepted
compulsory ICJ jurisdiction
Branches: King, 12-member King''s Council; 24 member cabinet provided for by new
provisional coalition government formed on April 5, 1974; (new 42-member Joint
National Political Council] is equa] with and independent of the government) ;
most of the cabinet and council seats are evenly divided between Communists and
non-communists with remainder occupied by neutralist politicians (the "Qualified
Group") acceptable to both Lao sides. The 59-member cabinet of the former
government has no legislative role to play in the new coalition government
Government leaders: King Savang Vatthana; Premier Souvanna Phouma; Council
Chairman, Prince Souphanouvang
Suffrage: universal over age 18
Elections: The 1973 Lao Accords specify that general elections for new National
Assembly and permanent government of national union should be held as soon as
possible after the formation of the provisional coalition government
Political parties and leaders: Neo Lao Hak Sat, Communist-front organization
which includes the Lao People''s Revolutionary Party (Communist), only
party active
Communists: Lao People''s Revolutionary Party (clandestine) membership unknown
Other political or pressure groups: non-Communist political groups are
informal and associated with regional family and military leaders;
Royal Armed Forces (FAR) leaders, Commander in Chief Bounpone
Makthepharack, and Generals Kouprasith Abhay, Phasouk Somly, Vang Pao,
Soutchay Vongsavanh, and Ret. Gen. Ouan Rathikoun
Member of: Colombo Plan, ECAFE, ICAO, IMF, Mekong Committee, SEAMES, U.N., UNCTAD','1c2feae00c207b4e3327213a84347f061b16010f869da48b782c016a58f047a3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd16c31aa394b36c8fbc50a9ab234a0c6c0c3f91549854abd39b17598c0dc143',1974,'LB','Lebanon','government',222,'Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law, and civil law system; consti-
tution mandated in 1920; no judicial review of legislative acts; legal
education at University of Lebanon; has not accepted compulsory ICJ
+ jurisdiction
Branches: power lies with President elected by parliament (Chamber of Deputies);
Cabinet appointed by President, approved by parliament; independent secular
courts on French pattern; religious courts for matters of marriage, divorce,
inheritance, etc.; by custom, President is a Maronite Christian, Prime
Minister a Sunni Muslim, and president of parliament a Shia Muslim; each of
9 religious communities represented in parliament in proportion to national
numerical strength
Government leader: President Sulayman Franjiyah
Suffrage: compulsory for all males over 21; authorized for women over 21 with
elementary education
Elections: for Chamber of Deputies, held every 4 years or within 3 months of
dissolution of Chamber; held April 1972
Political parties and leaders: political party activity is organized along
sectarian lines; numerous political groupings exist, consisting of individual
political figures and followers motivated by religious, clan, and economic
considerations; political stability dependent on maintenance of balance
between religious communities
¢ Communists: one of largest Communist parties in Middle East; legalized in 1970;
members and sympathizers estimated at 6,000
Other political or pressure groups: Palestinian guerrilla organizations
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
193
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','f500c9af9cdb9f7641f9aa61a45ec407c9ca54bd603bd194fc6358d53b18c534','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb87c3fb416acb6147bb5e0db97bde8c0f5ba9124f5bf4427be3c7ab96d0326f',1974,'LS','Lesotho','government',226,'Legal name: Kingdom of Lesotho
Type: constitutional monarchy under King Moshoeshoe II; independent member of
commonwealth since 1966
Capital: Maseru
Political subdivisions: 9 administrative districts
Legal system: based on English common law and Roman-Dutch law; constitution came
into effect 1966; judicial review of legislative acts in High Court and
Court of Appeal; legal education at University of Botswana, Lesotho, and
Swaziland (located in Lesotho); has not accepted compulsory ICJ jurisdiction
Branches: executive, divided between a largely ceremonial King and a Prime
Minister who leads cabinet of at least 7 members; Prime Minister dismissed
bicameral legislature in early 1970 and subsequently has ruled by decree; Prime
Minister convened Interim National Assembly in April 1973 in order to devise
new constitution; judictfal -- 63 Lesotho courts administer customary law for
Africans, High Court and subordinate courts have criminal jurisdiction over
all residents, Court of Appeal at Maseru has appellate jurisdiction
Government leader: Prime Minister Chief Leabua Jonathan
Suffrage: universal for adults
Elections: elections held in January 1970; nullified allegedly because of election
irregularities; subsequent elections promised at unspecified date
Political parties and leaders: Basutoland Congress Party (BCP), Ntsu Mokhele;
National Party (BNP), Chief Leabua Jonathan
Voting strength: in 1970 elections for National Assembly, BNP won 32 seats;
BCP, 22 seats; minor parties, 4 seats
Communists: Communist Party of Lesotho banned in early 1970
Member of: Comnonwealth, FAO, ILO, ITU, U.N., UNESCO, UPU, WHO','941a25351cd54d327c139c270fe8c2153fb25afe0e537e32c101020b2e1d317f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c3b60a00682151ab0493ef7b7d86900f49b2598d689b95ed49220f29b3415fb',1974,'LR','Liberia','government',230,'Legal name: Republic of Liberia
* Type: republic; dominated by strong executive
Capital: Monrovia
Political subdivisions: country divided into 9 counties; President appoints all
officials of significance
Legal system: based on U.S. constitutional theory; recent codes drawn up by
“ Cornell University; constitution adopted 1847; amended 1907, 1926, 1934,
and 1955; no constitutional provision for judicial review of legislative
acts; legal education at Louis Arthur Grimes School of Law, University of
Liberia; accepts compulsory ICJ jurisdiction, with reservations
Branches: President, elected by popular vote initially for 8-year term and
eligible for successive 4-year terms, controls through appointive powers and
authority over national expenditures; 2-house legislature elected by popular
vote; judiciary consisting of Supreme Court and variety of lower courts
Government leader: President William R. Tolbert
Suffrage: universal 18 years and over
Elections: members of House of Representatives elected for 4-year terms, most
recently in May 1971; Senate members elected for 6-year terms, one-half
elected in May 1971; President Tolbert, constitutional successor to President
Tubman who died in July 1971, is eligible to complete the four year term to
which Tubman was elected in May 1971; next scheduled presidential election May
1975
Political parties and leaders: True Whig Party, in power since 1878, only
political party; President Tolbert is leader
rm Voting strength: 1971 elections uncontested; True Whig Party won all but a
handful of votes
Communists: no Communist Party and only a few sympathizers
Member of: AFDB, ECA, FAO, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WHO
197
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','876d6bfe3f74197cfef04fa8d6d3aad9f535567aa51730ede1da0d9e24905cd3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a1e803aca61e5b13b66a68419cbfe21338f3a159582c7b5cc09f51bc588fb36',1974,'LY','Libya','government',234,'Legal name: Libyan Arab Republic
Type: republic; under military control following ouster of king on 1 September
1969; provisional constitution promulgated December 1969; loosely confederated
with Egypt and Syria in Confederation of Arab Republics (CAR) on 1 September 1971
Capital: Tripoli (defacto)
Political subdivisions: 10 administrative provinces closely controlled by
central government; district commissioners appointed by Revolutionary
= Command Council
Legal system: based on Italian civil law system and Islamic law; separate religious
courts; no constitutional provision for judicial review of legislative acts;
legal education at Law School, at University of Libya at Banghazi; has not
accepted compulsory ICJ jurisdiction
Branches: paramount political power and authority rests with the 11-man
Revolutionary Command Council (RCC); cabinet of 13 ministers; Parliament has
been dissolved
Government leaders: Revolutionary Command Council Chairman Colone? Mu''ammar
Qadhafi; Prime Minister, Major Abdal-Salam Jalud
Suffrage: universal
Elections: parliamentary elections last held in May 1965; election for CAR assembly
in March 1972
Political parties and leaders: Libyan Arab Socialist Union, RCC member Major Hawad,
Secretary General; Mu''ammar Qadhafi, President
Communists: no organized party, negligible membership
Other political or pressure groups: various Arab nationalist movements and the
Arab Socialist Resurrection (Ba''th) Party with small, almost negligible
* memberships may be functioning clandestinely
Member of: Arab League, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
OPEC, OAPEC, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','6027176e1c4d91845819c32ca5098fe291f6989e53b6c3f163a9406b77f350cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45ad8ed2eeb06abbe4ece2961c0d5a64b267466fba196aa396e5e399d1cb4eb4',1974,'LI','Liechtenstein','government',238,'Legal name: Principality of Liechtenstein
Type: hereditary constitutional monarchy
Capital: Vaduz
Political subdivisions: 1] districts
Legal system: based on Swiss law; constitution adopted 1921; judicial review of
legislative acts in a special Constitutional Court; accepts compulsory ICJ
jurisdiction, with reservations
Branches: unicameral Parliament, hereditary Prince, independent judiciary
Government leaders: Head of State, Prince Franz Joseph II; Chief of Government,
Dr. Walter Kieber
Suffrage: males age 20 and over
Elections: every 4 years; next elections 1974
Political parties and leaders: Fatherland Union Party (VU), Dr. Alfred Hilbe;
Progressive Citizens Party (FBP), Dr. Gerard Batliner
Voting strength (1974 election): FBP over 50%
ea Communists: none
Member of: IAEA, IPU, ITU; considering U.N. membership; under a 1923 treaty,
Switzerland handles Liechtenstein''s post and telegraph systems, customs, and
foreign relations','65ed4eeb5a40ac77f7812223eaafd269d32510823d62fae405648d1291216ece','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54146bddd72ae2d7668553198d2316760ab26a0c16332f03d418198aa0b1e3a8',1974,'MO','Macao','government',243,'Legal name: Province of Macao
Type: overseas province of Portugal
Capital: Lisbon (Portugal)
Political subdivisions: municipality of Macao, and 2 islands
Legal system: Portuguese civil law system
Branches: Governor, who dominates legislative and executive branches, assisted
by Legislative Council] with unknown number of appointed and 8 elected
members; the Urban Council with 3 governor-appointed and 4 elected members;
all high-ranking officials appointive under provisions of revised Organic
Overseas Law; new organic law to have come into effect in January 1973 to
replace legislative council with a legislative assembly
Government leader: Brigadier Jose Manuel Nobre De Carvalho, Governor
Suffrage: restricted to Portuguese citizens
Elections: conducted every 4 years; last held December 1972
Political parties and leaders: Portuguese National Union (Uniao Nacional) only
legal party, as in Portugal; Governor is leading political figure
Communists: numbers unknown
Other political or pressure groups: wealthy Macanese and Chinese representing
local interests, wealthy pro-Communist merchants representing China''s
interests; in January 1967 Macao Government acceded to Chinese demands which
gave Chinese veto power over administration of the enclave','96736e3bcb2f292753047c8d9605ce37edf847d750fb9e669d665ab146a84cf8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5682b8b36f99cb13e94983cc89f1d25dc118cfb0c9014e115ca087d35199e6e0',1974,'MG','Madagascar','government',247,'Legal name: Malagasy Republic
Type: republic; military-civilian government established May 1972; given 5-year
mandate in popular referendum October 1972
* Capital: Tananarive
Political subdivisions: 6 provinces
Legal system: based on French civil law system and traditional Malagasy laws
constitution of 1959 modified in October 1972 by law establishing
provisional government institutions; legal education at National School of
Law, University of Madagascar; has not accepted compulsory ICd jurisdiction
Branches: executive -- Gen. Ramanantsoa heads government assisted by cabinet
called Council of Ministers; National Popular Development Council
created to replace the legislature in October 1972; regular courts are
patterned after French system, and a High Council of Institutions reviews
all legislation to determine its constitutional validity
Government leader: General Gabriel Ramanantsoa
Suffrage: universal for adults
Elections: government in October 1972 postponed all political elections
indefinitely
Political parties and leaders: Parti Social Democrate (PSD), led by Philibert
Tsiranana; Congress Party for the Independence of Madagascar (AKFM), led by
Richard Andriamanjato; National Movement for the Independence of Madagascar
. (MONIMA), Ted by Monja Jaona; parties are permitted to exist but are barred
from positions of political authority because of postponement of elections
Voting strength: number of registered voters (1972) -- 3.5 millions (1972
presidential election) President Tsiranana, running unopposed, received
99.7% of votes cast; in 1970 National Assembly elections, PSD candidates
won 94%; AKFM 3%
207
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Communists: Communist party of virtually no importance; smal] and vocal group
of Conmunists has gained strong position in leadership of AKFM, the rank and
file of which is non-Communist
Other political or pressure groups: Joint Struggle Committee (KIM), association
of students, teachers, workers, and unemployed youth
Member of: ACCT, EAMA, FAO, IAEA, ICAO, ILO, IMCO, ITU, OAU, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO','7835428877c1433a64fc19401a44e5e8d7b94236a3d7fe6723709193ff8d72f8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca8c3c026708a819fe6178962855dc8a6f6d7f2bc7ab109203e0778916c93b64',1974,'MW','Malawi','government',251,'Legal name: Republic of Malawi
Type: republic since July 1966; independent member of Commonwealth since July 1964
Capital: Zomba
Political subdivisions: 3 administrative regions and 23 districts
Legal system: based on English common Taw and customary law; constitution
adopted 1964; judicial review of legislative acts in the Supreme Court of
Appeal; has not accepted compulsory ICd jurisdiction
Branches: strong presidential system with cabinet appointed by President; uni-
cameral National Assembly of 60 elected and 15 nominated members; High
Court with Chief Justice and at least 2 justices
Government leader: Life President H. Kamuzu Banda
Suffrage: universal adult
Elections: scheduled for Apri] 1971 but not held since MCP candidates were unopposed
Political parties and leaders: Malawi Congress Party (MCP), Dr. H. Kamuzu Banda
Communists: no Communist Party; may be a few Communist sympathizers
Member of: AFDB, FAO, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU, U.N., UNESCO,
WHO, WMO','b86355130886a6648a619627e957f47bf34eca89ba7142d87fb79fc420a24969','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('112f26719f21d7e2dfa80c784d1da57ec157e3df4cd67ed23ea8a5c096b06658',1974,'MY','Malaysia','government',255,'Legal name: Malaysia
Type:
Malaysia: constitutional monarchy nominally headed by Paramount Ruler (King);
a bicameral Parliament consisting of a 58-member Senate and a 144-member
House of Representatives
West Malaysian states: hereditary rulers in al? but Penang and Malacca where
Governors appointed by Malaysian Government; powers of state governments
limited by federal constitution
Sabah: self-governing state within Malaysia in which it holds 16 seats in
House of Representatives ; foreign affairs, defense, internal security,
and other powers delegated to federal government
Sarawak: self-governing state within Malaysia in which it holds 24 seats in
House of Representatives; foreign affairs, defense, and internal security,
and other powers are delegated to federal government
Capital:
West Malaysia: Kuala Lumpur
Sabah: Kota Kinabalu (formerly Jesselton)
Sarawak: Kuching
Political subdivisions: 13 states (including Sabah and Sarawak )
Legal system: based on English common law; constitution came into force 1963;
judicial review of legislative acts in the Supreme Court at request of
Supreme Head of the Federation; has not accepted compulsory 1CJ jurisdiction
Branches: 9 state rulers alternate as Paramount Ruler for 5-year terms; locus of
executive power vested in Prime Minister and cabinet, who are responsible
to bicameral parliament; following communal rioting in May 1969, govern-
ment imposed state of emergency and suspended constitutional rights of al]
parliamentary bodies; parliamentary democracy resumed in February 1971
West Malaysia: executive branches of 11 states vary in detail but are similar
in design; a Chief Minister, appointed by hereditary ruler or Governor,
heads an executive council (cabinet) which is responsible to an elected,
unicameral legislature
Sarawak and Sabah: executive branch headed by Governor appointed by central
government, largely ceremonial role; executive power exercised by Chief
Minister who heads parliamentary cabinet responsible to unicameral
legislature; judiciary part of Malaysian judicial system
Government leader: Head of State, Tun Abdul Razak
Suffrage: universal over age 20
Elections: minimum of every 5 years, Jast elections 1969
Political parties and leaders:
West Malaysia: Alliance Party consisting of United Malays National Organiza-
tion (UMNO), Tun Abdul Razak; Malaysian Chinese Association (MCA), Lee Sen
Choon; and Malaysian Indian Congress (MIC), V.T. Sambanthan; major opposition
parties -- Pan Malayan Islamic Party (PMIP), Dato Asri bin Haji
212
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Political parties and leaders (cont''d):
West Malaysia (cont''d):
a Muda (acting); Democratic Action Party (DAP); Gerakan Rakyat Malaysia (GRM);
minor opposition parties -- Party Rakyat (PR), People''s Progressive Party
(PPP), Labor Party of Malaya (LPM) Partai Keadilan Masharakyat (KEMAS),
United Malaysian Chinese Organization (UMCO); Conmunist Party illegal
Sabah: United Sabah National Organization (USNO), Tun Mustapha bin Dato
Harun; Sabah Chinese Association (SCA), Khoo Siak Chiews no organized
> opposition
Sarawak: coalition, Sarawak Alliance composed of the Pekaka/Bumipatra Party,
the United Peoples Party (SUPP), Ong Kee Hui and Sarawak Chinese Association;
opposition, Sarawak National Party (SNAP), Stephen Ningkan
Voting strength:
West Malaysia: (1969 election) Alliance Party controls 9 of 11 state
legislatures, won estimated 49% of total vote; Pan-Malaysian Islamic
Party polled 24%; Democratic Action Party polled 12%; Gerakan 7%
Sabah: (October 1971 Assembly Elections) Alliance unopposed, opposition
candidates disqualified
Sarawak: (1970 elections) Alliance 24 seats, SNAP 12 seats, SUPP 11 seats;
SUPP has joined the Alliance to form a coalition state government
Communists:
West Malaysia: approx. 1,500 armed insurgents on Thailand side of Thai/
Malaysia border; approx. 300 on Malaysian side
Sarawak: 960 armed insurgents in Sarawak; armed element of SCO in Indonesian
West Borneo estimated at 300
Sabah: insignificant
Member of: ADB, ASEAN, ASPAC, Commonwealth, FAO, GATT, IAEA, IBRD, ICAO, IFC,
ILO, IMF, ITU, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','955275b8cb0377e0e95b3b95c874e3aa6af0fcb050791176a170dbbed6557e14','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b64c063e9dae5e74ef6ab98fa88b43e31c136db32b6d6283b6f405f3fed17af',1974,'MV','Maldives','government',259,'Legal name: Republic of Maldives
Type: republic
Capital: Male
Political subdivisions: 19 administrative districts corresponding to atolls
Legal system: based on Islamic law with admixtures of English common law primari-
ly in commercial matters; has not accepted compulsory ICU jurisdiction
Branches: popularly elected unicameral national legislature (Majlis) (members
elected for 5-year terms); elected President, chief executive; appointed
Chief Justice responsible for administration of Islamic law
Government leaders: President Ibrahim Nasir; Prime Minister/External Affairs
Minister Ahmed Zaki
Suffrage: universal over age 2]
Political parties and leaders: no organized political parties; country governed
by the Didi clan for the past eight centuries
Communists: negligible number
Member of: Colombo Plan, U.N.','aa9213662aa5768ff811159c03cd583cebc526cfd66949b2492d80fd8309594f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d182ea46d240e26ee5d7e634c077e6341e602728eb8eceb3808b2a487bad572',1974,'ML','Mali','government',263,'Legal name: Republic of Mali
Type: republic; under military regime since November 1968
Capital: Bamako
Political subdivisions: 6 administrative regions; 42 administrative districts
(cercles), arrondissements, villages; all subordinate to central government
Legal system: based on French civil law system and customary law; constitution
adopted 1960, amended 1961; judicial review of legislative acts in Constitu-
tional Section of Court of State; has not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by Military Committee of National
Liberation (MCNL) composed of 11 army officers; under MCNL functional
cabinet composed of civilians and army officers; judiciary
Government leaders: Col. Moussa Traore, president of MCNL, Chief of State and
head of government
Suffrage: universal over age 21
Political parties and leaders: political activity proscribed by military government
Elections: MCNL promises elections at unspecified date
Communists: a few Communists and some sympathizers
Member of: ACCT, AFDB, CEAQ, ECA, FAQ, IAEA, ICAO, ILO, IMF, ITU, Niger
River Commission, OAU, OMVS, U.N., UNESCO, UPU, WHO, WMO','ee568c01ca124820cd161f44975acd0b3784f5102ac9be2d2bea7cdf5c7653a9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('290065deac8f59907c3ce0fa628cb3b2796789adff9dba7f4ee7545039d85d1a',1974,'MT','Malta','government',269,'Legal name: Malta
Type: parliamentary democracy, independent state within the Commonwealth since
September 1964
Capital: Valletta
Political subdivisions: 2 main populated islands, Malta and Gozo, divided into
10 electoral districts (divisions)
Legal system: based on English common law; constitution adopted 1961, came into
force 1964; has accepted compulsory ICJ jurisdication, with reservations
Branches: executive, consisting of prime minister and cabinet; legislative,
comprising 55-member House of Representatives; independent judiciary
Government leader: Prime Minister Dom Mintoff
Suffrage: universal over age 21; registration required
Elections: at the discretion of the Prime Minister, but must be held before the
expiration of a 5-year electoral mandate; last election June 197]
Political parties and leaders: Nationalist Party, Georgio Borg Olivier; Malta
Labor Party, Dom Mintoff
mete ie (1971 election): Labor, 29 seats (52.7%); Nationalist, 26 seats
47.2%
Conmunists: less than 100 (est. )
Member of: Commonwealth, Council of Europe, FAO, GATT, ICAO, ILO, IMF, Seabeds
Committee, TDB, U.N., UNESCO, WHO','b2b28eb028dd0f48dfffa9c54354fd8509978254c1041e423783817def36574d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e270bfd06faa6a1545b33bda5fe3705ddb1142fc1b1b2f460844f51d6180e531',1974,'MC','Monaco','government',273,'Legal name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Political subdivisions: 4 sections
Legal system: based on French law; new constitution adopted 1962; has not
accepted compulsory ICJ jurisdiction
Branches: National Council (18 members}; Communal Council (15 members, headed
by a mayor)
Government leader: Prince Rainier III
Suffrage: universal
Elections: National Council every 5 years; most recent 1973
Political parties and leaders: National Democratic Entente, Democratic Union
Movement, Monagasgue Actionist (1973)
Voting strength: figures for 1973 election not available; National Democratic
Entente, 16 seats; Democratic Union Movement and Monagasque Actionist, 1 seat
each
Member of: IAEA, IHB, ITU, U.N., UNESCO, UPU, WHO','8cfa0a81da80946ad398c86f2320d3411d12a79f667c9d74c1d0ea4ecdedf9bd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b7c4a08fa1aebc9a2bb3d44c712ae623f069f7764c9dcb7fab99d7fc310c000',1974,'MA','Morocco','government',279,'Legal name: Kingdom of Morocco
Type: constitutional monarchy (
Capital: Rabat
Political subdivisions: 23 provinces and 2 prefectures
Legal system: based on Islamic law and French and Spanish civil law system;
judicial review of legislative acts in Constitutional Chamber of Supreme
Court; modern legal education at branches of Mohamed V University in Rabat
and Casablanca and Karaouine University in Fes; has not accepted compulsory
ICJ jurisdiction
Branches: constitution
responsible to King;
legislature in abeyan
constitution adopted 1972)
provides for Prime Minister and ministers named by and
King has paramount executive powers; unicameral
ce until elections are held (two-thirds to be directly
elected, one third indirectly); judiciary independent of other branches
Government leaders: King Hassan II; Prime Minister Ahmed Osman
Suffrage: universal over age 20
Elections: last parliamentary elections held 21 and 28 August 1970 for Council
of Representatives which was dissolved in March 1972; elections for new
parliament created by Constitution adopted 15 March 1972 have not been held
Political parties and leaders: Istiqlal Party, Allal el-Fassi; Popular Movement
(MP), Mahjoubi Aherdan; Constitutional and Democratic Popular Movement
(MPCD), Dr. Abdetkrim Khatib; National Union of Popular Forces (UNFP), split
into competitive factions under Abdallah Ibrahim and Mahjoub Ben Seddik of
Casablanca-based faction and Abderrahim Bouabid of Rabat-based faction (Rabat
faction of UNFP was suspended in April 1973); Democratic Constitutional Party
Voting strength: August 1970 elections were n
Communists:
(PDC), Mohamed Hassan Ouazzani: Party for
established in June 1968 and banned Septen
Communist Party (MCP), which was proscribe
the UNFP formed a National Front in July 1
boycotted the parliamentary elections and
constitutional referendum tallied 98.7% fo
and National Front abstained from voting
300 est.
235
Approved For Release 2008/07/18 : CIA-RDP79-
Liberation and Socialism (PLS),
ber 1969, is front for Moroccan
d in 1959, Ali Yata; Istiqlal and
970 to oppose the new consti tution,
the 1972 constitutional referendum
onpolitical; 1 March 1972
r new constitution, 1.25% opposed
01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Member of: Arab League, EC (association until 1974), FAO, IAEA, IBRD. ICAO, IDA,
ILO, IMC, IMCO, IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO
Legal name: State of Mozambique
Type: overseas state of Portugal
Capital: Lourenco Marques
Political subdivisions: 10 districts administered by district governors;
municipalities governed by appointed official
Legal system: based on Portuguese civil law system and customary Taw
Branches: Governor General appointed by Lisbon is chief executive officer for
internal administration; he also has certain legislative powers which he
exercises with Legislative Assembly; all action in state may be vetoed
by Minister of Overseas in Lisbon; judiciary is constitutionally independent
Government leader: Governor General Manuel Pimentel dos Santos
Suffrage: all adults able to read and write Portuguese and in full possession of
political and civil rights
Elections: Legislative Assembly elections held every 4 years; last held March 1973
Political parties and leaders: National Popular Action (ANP), formerly the
National Union (UN), state president Jorge Morais Barbosa; no legal opposition
political parties
Communists: none known
Other political or pressure groups: the Mozambique Liberation Front (FRELIMO), led
by Moises Samora Machel, operates from Tanzania and Zambia; less significant
Mozambique Revolutionary Committee (COREMO), led by Paulo Gumane, based in','9b9b45f129a928a304b648dd30fc7d6ded04b844dd9334152bfc24ed264e31ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6014e8ca6f5acbedd0ed304eff441ec4da93a6e834d03ad6f5fc26b59b19e3d7',1974,'NR','Nauru','government',285,'Legal name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se; government offices in Uaboe District
Political subdivisions: 14 districts
Branches: President elected from and by Parliament for an unfixed term; popularly
elected unicameral legislature, the Parliament; Cabinet to assist the
President, four members, appointed by President from Parliament members
Government leader: President Hammer De Roburt
Suffrage: universal adult
Elections: last held in January 1971
Political parties and leaders: there are no political parties; De Roburt is only
significant political figure
Member of: no present plans to join U.N.; enjoys "special membership” in
Commonwealth; South Pacific Commission, INTERPOL, ECAFE','3760d1197ba0ffd5dd2b121913ceb2999e96f99e57ec0eef789d33d735fac3e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a73f72faf8409a4073aeaea2b5e3004d628e849a56693b070b6f32f06d52dbaf',1974,'NP','Nepal','government',289,'Legal name: Kingdom of Nepal
Type: constitutional monarchy; King Birendra exercises autocratic control over
multitiered panchayat system of government
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and English common law; legal
education at Nepal Law College in Kathmandu; has not accepted compulsory
ICJ jurisdiction
Branches: Council of Ministers appointed by the King; indirectly elected
National Panchayat (Assembly)
Government leader: King Birendra Bir Bikram Shah Deva; Prime Minister Nagendra
Prasad Rijal
Suffrage: universal over age 21
Elections: village and town councils (panchayats) elected by universal suffrage;
district, zonal, and National Panchayat members indirectly elected, most
for 6-year terms; 15 National Panchayat members elected from five class
organizations (women, workers, youth, and ex-servicemen), four directly
elected by all voters possessing a B.A. or its equivalent, and 16 are
appointed by the King
Political parties and leaders: all political parties outlawed
Communists: the combined membership of the two wings of the Conmunist Party
of Nepal (CPN) may be on the order of 6,500, the majority (perhaps 5,000)
in the pro-Chinese wing; the CPN continues to operate more or less openly,
but internal dissension has greatly hindered its effectiveness
Other political or pressure groups: proscribed Nepali Congress Party led by
B.P. Koirala from exile in India
Member of: ADB, FAO, IBRD, ICAQ, IDA, ILO, IMF, ITU, U.N., UNESCO, UPU, WHO','d5f8629ff23ce50257be2e20d878631efb77cf5a6701d83854ede23e7721fcd5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed18336bdeeca3707d43b3e7545066c34ad0f8591e046c9c6b38c4f8975466ea',1974,'NL','Netherlands','government',293,'Legal name: Kingdom of the Netherlands
” Type: constitutional monarchy
Capital: Amsterdam, but government resides at The Hague
Political subdivisions: 11 provinces governed by centrally appointed commissioners
of Queen
Legal system: civil law system incorporating French penal theory; constitution
. of 1815 frequently amended, reissued 1947; judicial review in the Supreme
Court of legislation of lower order than Acts of Parliament; legal education
at six law schools; accepts compulsory ICJ jurisdiction, with reservations
Branches: executive, (Queen and Cabinet of Ministers), which is responsible to
bicameral states general (parliament); independent judiciary
Government leader: Head of State, Queen Juliana; Johannesden Uyl, Prime Minister
Suffrage: universal over age 2]
clections: must be held at least every 4 years for lower house (most recent
November 1972), and every 3 years for upper house (most recent March 1974)
Political parties and leaders: Catholic People''s Party (KVP), Dr. D. de Zeeuw;
Antirevolutionary (ARP), A. Veerman; Labor (PvdA), Andre van der Louw; Libera]
(VVD), Mrs. H. van Sonmeren-Downer; Christian Historical Union (CHU), Otto
W. A. Barou Van Verschuer; Democrats ''66 (D-66), Jan ter Brink; Communist (CPN),
Henk Hoekstra; Pacifist Socialist (PSP), P. A. Buragraff; Political Reformed
(SGP), H. G. Abmas Reformed Political Union (GVP), G. Veurink; Radical Party
(PPR), Marcel Van Dam; Democratic Socialist''70 (DS-70), Fred L. Polak; Farmers’
Party (BP), Hendrik Koekoek; Roman Catholic Party (RKPN), leader unknown:
Voting strength (1972 election): 17.7% KVP, 14.4% VVD, 8.8% ARP, 4.8% CHU, 27.4%
PvdA, 4.2% D-66, 4.1% DS-70, 4.5% CPN, 1.5% PSP, 4.8% PRP, 2.2% SGP, 1.8% GVP,
1.9% BP, .9% RKP
Communists: 9,000 members; 329,973 votes in 1972 election
Other political or pressure groups: great multinational firms; Socialist, Catholic,
and Protestant trade unions; Federation of Catholic and Protestant Employers
Associations; the non-demoninational Federation of Netherlands Enterprises
243
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Member of: Benelux, Council] of Europe, ECE, ECSC, EC, EMA, EURATOM, FAO, IAEA,
IBRD, ICAO, IHB, IMF, NATO, OECD, Seabeds Committee (observer), U.N., UNESCO,
WEU, WHO','f282966acd2caeefc94e7c3bb0153b106e606e4e3dedeecc4a398433185fc18b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15ec5340d9da25a70ccee6b7a810bbc5548ab067eeed86523cbc5e22d6c48a61',1974,'NC','New Caledonia','government',297,'Legal name: Overseas Territory of New Caledonia
Type: French overseas territory; represented in French parliament by one deputy
and one Senator
Capital: Noumea
Political subdivisions: 4 islands or island group dependencies -- Isle of Pines,
Loyalty Islands, Huon Islands, Island of New Caledonia
Legal system: French law
Branches: administered by Governor, who is also High Commissioner for France in
the Pacific; responsible to French Ministry for Overseas France and Governing
Council; Assemblee Territoriale
Government leader: Jean Risterucci, Governor and French High Commi ss ioner
Suffrage: restricted (1957 election roll listed 32,370 males and females over
21 years of age, of whom 18,964 were classed as indigenous inhabitants)
Elections: Assembly elections in 1972
Political parties: Union Caledonienne, Entente Democratique et sociale, Union
Multiraciale, Mouvement Liberal Caledonien, Union Democratigue, Mouvement
Populaire Caledonien
Voting strength (1972 election): Union Caledonienne, 12 seats; Entente Sociale
et Democratique, 6 seats; Union Multiraciale, 5 seats; Mouvement Liberal
Caledonien, 5 seats; Union Democratique, 4 seats; Mouvement Populaire
Caledonien, 2 seats; Caledonie Francaise, 1 seat
Comunists: number unknown; Union Caledonienne strongly leftist; some politically
active Communists were deported during 1950''s; small number of North Vietnamese
Other political parties and pressure groups: several lesser parties
Legal name: New Hebrides Condominium
Type: Anglo-French condominium
Capital: Vila
Political subdivisions: 4 administrative districts
Legal system: 3 sets of courts; one each for French and British subjects, one for
New Hebrides native affairs
Branches: Advisory Council of 30 members with no real legislative powers, majority
elected
Government leader: two resident commissioners, one French, one British
Political parties and leaders: New Hebrides National Party, founded 1971,
chairman, Walter Lini','dc858dce9d438b1e006e0495482bb98c32908d08d038d706180a4daf9b09f4bd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31b50e9b62f710665cc07b7433bef4d3a01572fbf40aabd9d58c07301b62dbbc',1974,'NI','Nicaragua','government',301,'Legal name: Republic of Nicaragua
Type: republic
Capital: Managua
Political subdivisions: 1 national district and 16 departments
Legal system: based on Spanish civil law system; constitution adopted in 1950,
now being revised; judicial review of legislative acts in the Supreme Court;
legal education at Universidad Nacional de Nicaragua and Universidad
Centroamericana; accepts compulsory ICJ jurisdiction
Branches: President from 1 May 1972 to 1 December 1974 replaced by a triumvirate,
bicameral legislature, judiciary elected by legislature, and Supreme Electoral
Tribunal (4th branch)
Government leaders: Triumvirate members -- Roberto Martinez, Alfonso Lovo Cordero
and Edmundo Paguaga
Suffrage: universal over age 18 if married or literate, otherwise 21
Elections: every 6 years; however, due to agreement between liberal and conservative
parties, next elections will be held 1? September 1974; municipal elections every
3 years
Political parties and leaders: Nationalist Liberal Party (PLN), Anastasio Somoza,
Ramiro Sacasa; Nicaraguan Conservative Party (PCN), Edmundo Paguaga and
Fernando Aguero Rocha; Independent Liberal Party (PLI}, not legal, Roberto
Robelo, Juan Manuel Gutierrez; Social Christian Party (PSC), not legal,
Ignacio Zelaya, Manolo Morales Peralta (President) and Roberto Ferrey
(Secretary General); National Conservative Action (ANC), not Tegal. Pedro
J, Chamorro
ae a (1972 elections): PLN 534,171 votes (75.4%), PCN 174,897 votes
24.6%
Communists: Communist movement split into hard-line Nicaraguan Socialist Party
(PSN) illegal, 60 members; soft-line Nicaraguan Communist Party (PCN) illegal,
40 members, and small pro-Castro Sandinist National Liberation Front (FSLN)
activist, 50-60 members; about 1,000 sympathizers
Other political or pressure groups: wealthy families; businessmen
Member of: CACM, FAQ, GATT, IADB, IAEA, ICAQ, ICJ, ILO, INTELSAT, ITU, OAS,
ODECA, Seabeds Committee (observer) U.N., UNESCO, UNICEF, UPU, WHO, WMO
253
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','28ecaeb71688389526b5b74fb354bb7bcefd8fc5657ad2eb2ede1883b5de6d5d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91c71c2c2c93a995af32d0b8a77148cac11ab6ef1cbc83232b7ecccbecdaf8a6',1974,'NE','Niger','government',305,'Legal name: Republic of Niger
Type: republic; military regime in power since April 1974
Capital: Niamey
Political subdivisions: 7 departments, 32 arrondissements
Legal system: based on French civil law system and customary law; constitution
adopted 1960, suspended 1974; judicial review of legislative acts in Consti-
tutional Chamber of the Supreme Court; has not accepted compulsory ICJ
jurisdiction
Branches: executive authority exercised by Provisional Supreme Military Council
(SMC) composed of 12 army officers
Government leader: President Lt. Col. Kountche Seyni
Suffrage: universal over age 21
Elections: political activity banned
Political parties and leaders: political parties banned
Communists: no Communist party; some sympathizers in outlawed Sawaba party
Member of: ACCT, AFDB, CEAQ, EAMA, ECA, Entente, FAO, GATT, IBRD, ICAO, ILO, IMF,
ITU, Lake Chad Basin Commission, Niger River Commission, OAU, OCAM, U.N.,
UNESCO, UPU, WHO, WMO','be37a6fd0c0aab11fdbe428f13891b89799be4b376d95fe81129a98d59cfb284','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82349d61edf729d6c272b1a9036e71ddb21ac5e35c089142a0413fd373a7c900',1974,'NG','Nigeria','government',309,'Legal name: The Federal Republic of Nigeria
Type: federal republic since 1963; under military rule since January 1966
Capital: Lagos
Political subdivisions: 12 states, 11 headed by a military governor, 1 by a
civilian administrator
Legal system: based on English common law, tribal law, and Islamic law; new
constitution to be prepared; accepts compulsory ICJ jurisdiction with
reservations
Branches: Federal Military Government; decrees issued by Supreme Military Council,
advised by largely civilian Federal Executive Council; effective
administrative power held by senior civil servants
Government leader: Gen. Yakubu Gowon, Head of Federal Military Government and
Commander in Chief of Nigerian Armed Forces
Suffrage: universal adult suffrage (except for women in former Northern Region)
Elections: expected to be held by 1976
Political parties and leaders: political parties and politically active tribal
societies were dissolved by decree on 24 May 1966; some sub rosa political
activity continues
Communists: the banned Socialist Workers and Farmers Party and the Nigerian Trade
Union Congress have a limited political following, no influence on government
Member of: AFDB, Commonwealth, ECA, FAQ, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU,
Lake Chad Basin Commission, Niger River Commission, OAU, OPEC, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO','48c53cfcb15722abfda7bbc304c5472fa0ce0733c2900b22162d42fc9498050e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46ac1abfa9260dc30ad13aae10454088a28b52c9dd048a1817d4cdc5dd49e0a8',1974,'NO','Norway','government',313,'Legal name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 20 counties, 404 communes, 47 towns
Legal system: mixture of customary law, civil law system, and common law traditions;
constitution adopted 1814, modified 1884; Supreme Court renders advisory
opinions to legislature when asked; legal education at University of Oslo;
accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with Crown and parliament (Storting);
executive power vested in Crown but exercised by cabinet responsible to
parliament; Supreme Court, 5 superior courts, 104 lower courts
Government leaders: King Olav V; Prime Minister Trygve Bratteli
Suffrage: universal, but not compulsory, over age 20
Elections: held every 4 years (next in September 1977)
Political parties and leaders: Anti-Tax Party, Anders Lange; Conservative, Kare
Willoch; Christian People''s, Lars Korvald; Center, John Austrheim; Liberal,
Hallvard Eika; New Liberal People''s, Helge Seip; Labor, Trygve Bratteli;
Democratic Socialist, Berit As; Socialist People''s, Finn Gustavsen; Communist,
Reidar Larsen
Voting strength (1973 election): 5.0% Anti-Tax; 7.3% Conservative; 11.8% Christian
Peoples; 6.8% Center; 3.4% Liberal; 2.3% New Liberal People''s; 35.5% Labor;
11.2% Socialist Electoral Alliance (includes Democratic Socialist, Socialist
People''s, and Communist parties); 1.0% Communist
Communists: 2,000; a number of sympathizers as indicated by the 22,500 Comnunist
votes cast in the 1969 election
Member of: Council of Europe, EC (Free Trade Agreement), FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, Nordic Council, OECD,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
259
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','da7b1e2c2a4cb1a642d88d09b9e30914a735f153b7f85f58f0f360903f9c3350','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d73536f952079eb82807d411e34b073aa8bff2d2f302a262f33ab621f9520e5',1974,'OM','Oman','government',317,'Legal name: Sultanate of Oman
Type: absolute monarchy; nominally independent but under strong U.K. influence
Capital: Muscat
Legal system: based on English common law and Isiamic law; no constitution;
ultimate appeal to the Sultan; has not accepted compulsory ICJ jurisdiction
Government leader: Sultan Qabus ibn Sa''id Al Bu Sa''id
Other political or pressure groups: none
Member of: Arab League, U.N.
Legal name: Islamic Republic of Pakistan
Type: parliamentary, federal republic; constitution adopted April 1973, effective
August 1973, provides for bi-cameral legislature; strong prime minister
Capital: Islamabad
Political subdivisions: 4 provinces -- Punjab, Sind, Baluchistan, and Northwest
Frontier -- with the capital territory of Islamabad and certain tribal areas
centrally administered; Pakistan claims that Azad Kashmir is independent
pending a settlement of the dispute with India, but it is in fact under
Pakistani control
Legal system: based on English common law; accepts compulsory ICd jurisdiction,
with reservations
Government leaders: President Fazal Elahi; Prime Minister Z. A. Bhutto
Suffrage: universal over age 21
Elections: elections for National Assembly based on one-man/one-vote formula,
and for provincial assemblies were held in December 1970; with independence
of Bangladesh, National Assembly consists of 144 West Pakistanis and 2 East
Pakistanis
Political parties and leaders: Pakistan People''s Party (PPP), Z.A. Bhutto;
United Muslim League (UML), Shaukat Hayat Khan and Pir of Pigaro; National
Awami Party (NAP), Abdul Wali Khan; All Pakistan Muslim League (QML), Abdul
Qaiyum Khan; Markazi Jamiat-ul-Ulema-i-Pakistan (MJUP), Khamaja Qamar-u-Din
Sialvi; Jamiat-ul-Ulema-i-Islam (JUI), Mufti Mahmud
Communists: 750; 3,000-5,000 sympathizers
Other political or pressure groups: military remains potentially strong
political force
Member of: ADB, CENTO, Colombo Plan, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO,
IMCO, IMF, ITU, RCD, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
263
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','43fa5a35da79151afe5cb4c6abab3e6e777426a2a7205488d9ad3ff3a0fd4f83','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8560d485008a35336e160a26e3ad09281f004c0b11e3c7a79358a959730089e5',1974,'PA','Panama','government',321,'Legal name: Republic of Panama
Type: republic
Capital: Panama
Political subdivisions: 9 provinces, 1 intendancy
Legal system: based on civil law system; constitution adopted in 1972; judicial
review of legislative acts in the Supreme Court; legal education at
University of Panama; accepts compulsory ICJ jurisdiction, with reservations
Branches: popularly elected unicameral legislature which elects the President;
presidentially appointed Supreme Court
Government leaders: Demetrio Lakas is Constitutional President and Chief of
State, but subordinate to Gen. Omar Torrijos, the National Guard Commandant
who was given special powers for 6 years by the Constitutional Assembly in 1972
Suffrage: universal and compulsory over age 21
Elections: elections for assembly of representatives of the corregimientos
August 1972; next election August 1978
Political parties and leaders: political parties suspended pending revision of
electoral code; Communist Party illegal but allowed to operate
Voting strength (1968 election): 55% Arnulfo Arias Madrid (National Union
Coalition), 42% David Samudio (People''s Alliance), 3% Antonio Gonzalez
Revilla (Christian Democratic Party); no parties were active in the 1972
elections
Communists: 100 active and several hundred inactive members People''s Party (PdP);
Communist; 1,000 sympathizers; National Liberation Movement (MLN) and
Vanguard of National Action (VAN) inactive as pro-Castro organizations,
40-60 members
Other political or pressure groups: National Council of Private Enterprise (CONEP)
Member of: IADB, IAEA, ICAO, OAS, U.N.
265
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','0a0450650ad929543a00adc97dd95899fa2fbe75ada9d8f945ae020f5a6dffe2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abd0ea82b1a5b7f9ba8e84dbe90aef8e7ef5cb5b87789561a9e5f0bc28ebe8a7',1974,'PY','Paraguay','government',326,'Legal name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncion
Political subdivisions: 16 departments and the national capital, 154 municipalities
Legal system: based on Argentine codes, Roman Jaw, and French codes; constitution
promulgated 1967; judicial review of legislative acts in Supreme Court; legal
education at National University of Asuncion and Catholic University of Our
Lady of the Assumption; does not accept compulsory ICd jurisdiction
Branches: President heads executive; bicameral legislature; judiciary headed
by Supreme Court
Government leader: President (General) Alfredo Stroessner
Suffrage: universal; compulsory between ages of 18-60
Elections: President and Congress elected together every 5 years; Jast election
held in February 1973
Political parties and leaders: Colorado Party, Juan Ramon Chavez; Liberal
Party (Levi-Liberal Party), Carlos Levi Ruffinellis Febrerista Party, Manuel
Benitez; Radical Liberal Party (regular Liberal Party), Justo Pastor Benitez;
Christian Democratic Party (not officially inscribed), Dr. Hermogenes Rojas
Silva
Voting strength (February 1973 general election): 84% Colorado Party, 13% Radical
Liberal Party, 3% Liberal Party, Febrerista Party boycotted elections
Communists: Oscar Creydt faction and Miguel Angel Soler faction (both 111egal) ;
pernaps a few thousand party members and sympathizers in Paraguay, very
few are hard core; party in exile is small and deeply divided
Other political or pressure groups: Popular Colorado Movement (MoPoCo) led by
Epifanio Mendez Fleitas, in exile
Member of: FAQ, IADB, IAEA, IBRD, ICAO, IMF, LAFTA, OAS, U.N., WHO','501b04538612dd37055b156cae5252bb809067f7dc6bc969121e4244b4bc92de','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59cb69abacfd3506bdcce375810a99f1393da83d741fd81dbb606d4f0bc01588',1974,'PH','Philippines','government',330,'Legal name: Republic of the Philippines
Type: republic
Capital: Quezon
Political subdivisions: 70 provinces
Legal system: based on Spanish, Islamic, and Anglo-American law; parliamentary
constitution passed 1973; judicial review of legislative acts in the
Supreme Court; Tegal education at University of the Philippines, Ateneo
de Manila University, and 71 other law schools; accepts compulsory
ICJ jurisdiction, with reservations; currently being ruled under martial Taw
Branches: new constitution (currently suspended) provides for unicameral National
Assembly, and a strong executive branch under a prime minister; judicial
branch headed by Supreme Court with descending authority in a Court of
Appeals, courts of First Instance in various provinces, municipal courts in
chartered cities, and justices of the peace in towns and municipalities;
these justices have considerably more authority than do justices of the
peace in the U.S.
Government leader: President Ferdinand E. Marcos
Suffrage: universal over age 18
Elections: elections suspended for the indefinite future
Political parties and leaders: Liberal Party, Gerardo M. Roxas; Nacionalista
ee Gil J. Puyat (political parties currently in limbo because of martial
law
Communists: about 1,300 armed insurgents
Member of: ADB, ASEAN, ASPAC, Colombo Plan, ECAFE. IAEA, ICAO, IHB, Seabeds
Committee (observer), SEATO, U.N., UNESCO, UNICEF, WHO
273
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','42dfaaeeb1c87d96796a218796c0f5911999b9192d6dbc0a2ed59851bd30d228','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e798355fd287236ee68fa0b5ddeaac9007cb914762fa17e5bf99bef8807c2ab0',1974,'PL','Poland','government',334,'Legal name: Polish People''s Republic (PRL)
Type: Communist state
Capital: Warsaw
“ Political subdivisions: 17 provinces, 5 city provinces, 391 districts
Legal system: mixture of Continental (Napoleonic) civil law and Conmunist legal
theory; constitution adopted 1952; court system parallels administrative
divisions with Supreme Court, composed of 104 justices, at apex; no
judicial review of legislative acts; legal education at 7 law schools; has
not accepted compulsory ICdJ jurisdiction
Branches: legislative, executive, judicial system dominated by parallel
Communist party apparatus
Government leader: Piotr Jaroszewicz, Premier; Henryk Jablonski, chairman
of Council of State (President)
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government every 4 years
Dominant political party and leader: Polish United Workers'' Party (PZPR)
(Communist), Edward Gierek, First Secretary
Voting strength (1972 election): 97% voted for Communist-approved single slate
Communists: 2,320,000 party members (January 1974)
Other political or pressure groups: National Unity Front (FUN), including United
Peasant Party (ZSL), Democratic Party (SD), progovernment pseudo-Catholic
Pax Association and Christian Social Association, Catholic independent Znak
group; powerful Roman Catholic Church, Stefan Cardinal Wyszynski, Primate
Member of: CEMA, GATT, ICAO, IHB, Indochina Truce Commission, Korea Truce
Commission, Seabeds Committee, U.N. and all specialized agencies except IMF
and IBRD, Warsaw Pact, Vietnam ICCS (International Commission for Control
and Supervision)
Legal name: Republic of Portugal
Type: republic, provisional government formed May 1974, after military coup
resulted in overthrow of the old regime
Capital: Lisbon
Political subdivisions: 18 districts in mainland Portugal and 4 "autonomous
districts" in Azores and Madeira Islands; 7 overseas provinces in Africa
and Asia, plus the state of Portuguese India whose 196] occupation by
India is not recognized by Lisbon; Anaola and Mozambique designated states
of Portugal in 1972
Legal system: civil law system; constitution adopted 1933, frequently amended
since; no judicial review of legislative acts; legal education at Universities
of Lisbon and Coimbra; accepts compulsory ICJ jurisdiction, with reservations
Branches: executive with President overshadowed by Prime Minister and Council of
Ministers; legislative with National Assembly dominated by executive and a
Corporative Chamber, the latter consultative and advisory; and judicial
controlled by executive branch
Government leaders: President Antonio de Spinola; Prime Minister, Palma Carlos,
appointed May 1974
suffrage: all citizens over age 21 who are literate and have not been deprived
of their civil rights
Elections: National Assembly, new free elections promised by March 1975;
local direct parish board elections held every 4 years, next in 1975;
President, by government-controlled electoral college every 7 years, latest
in July 1972
Political parties and leaders: numerous political parties are being organized--
the Communist Party (PCP) whose secretary, is Alvaro Cunhal, and the
277
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Political parties and leaders (cont''d):
Portuguese Socialist Action (ASP), led by leader Mario Soares, are
the best organized
Voting strength (1973 election): former government''s National Action Party won
all 150 seats in National Assembly after opposition candidates withdrew
to protests election restrictions
Communists: 2,000-7,000 est.; sympathizers cannot be determined
Other political or pressure groups: Association for the Study of Economic and
Social Development (SEDES) authorized in October 1970 as a discussion group
with political overtones
Member of: FAO, IAEA, IBRD, ICAO (restricted membership), IHB, ILO, IMF, ITU,
NATO, OECD, Seabeds Committee (observer), U.N., UPU, WHO, WMO
Legal name: Province of Guinea
Type: overseas province of Portugal
Capital: Bissau
Political subdivisions: 9 municipalities, 3 circumscriptions (predominantly
indigenous population)
Legal system: based on Portuguese law
Branches: Governor General appointed by Ministry of Overseas has wide local
authority; he is assisted by an appointed Secretary-General and a 9-man
consultative Council; a 17-member Legislative Assembly, 12 of whose members
are elected by various groups, represents economic and tribal interests of
province; Minister of Overseas can nullify any provincial legislation or
Governor''s decision; judiciary based on Portuguese system
Government leader: Governor General and military commander is Gen. Jose Manuel
Bettencourt de Rodrigues
Suffrage: limited to those satisfying fairly rigid economic and cultural
requirements
Elections: Legislative Assembly elections held every 4 years in March, last
held in 1973
Political parties and leaders: National Popular Action (ANP) of Portugal only
legal party sends one representative to National Assembly in Lisbon; opposition
parties (i]legal) include Partido Africano da Independencia da Guinee e Cabo
Verde (PAIGC), led by Aristide Pereira, a Communist-supported nationalist party
which is chief political force conducting current rebellion against Portuguese
rule and which operates mainly from Republic of Guinea and the Republic of
Senegal; Front de Lutte pour 1''Independence Nationale de la Guinee (FLING),
a largely dormant, loose coalition of Senegal-based nationalist elements
opposed both to the Portuguese and the PAIGC, leadership fragmented;
other nationalist factions
Communists: none known','b2d5f6a1b71648be3ee4000434bcc8f23cfd279d1826d0e4c916dd89f7f796ef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fbc6c84e638c9bf99253467c7d03b0d5cf0d09bd010700d638210a6a4cbdee0',1974,'QA','Qatar','government',338,'Legal name: State of Qatar
Type: traditional monarchy; independence declared in 1971
Capital: Ad Dawhah
Legal system: discretionary system of law controlled by the ruler, although new
civil codes are being implemented; Islamic law is significant in personal
matters; a constitution was promulgated in 1970
Government leader: Amir Khalifa ibn Hamad Al-Thani
Suffrage: no specific provisions for suffrage laid down
Elections: constitution calls for elections for part of State Advisory Council,
semi-legislative body, but none have been held
Political parties and pressure groups: none; a few small clandestine organizations
are active
Branches: Council of Ministers
Member of: Arab League, U.N.
Legal name: Overseas Department of Reunion
Type: overseas department of France; represented in French Parliament by three
Deputies and two Senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a Prefect appointed by the French Minister
of Interior, assisted by a Secretary-General and an elected 36-man General
Council
Government leader: Prefect Paul Cousseran
Suffrage: universal adult
Elections: last municipal elections in 1971; parliamentary election March 1973
Political parties and leaders: Reunion Communist Party (RCP) led by Paul Verges,
only organized political movement on island; other political candidates
affiliated with metropolitan French parties, which do not maintain permanent
organizations on Reunion
Voting strength (parliamentary election 1973): Union of Democrats for the Republic
elected, one senator and two deputies; Centrist Union, one deputy; one Senator
independent
Communists: Communist Party small -- probably only 15-20 hard-line Communists --
but has support among sugarcane cutters and in Le Port district
Legal name: Colony of Southern Rhodesia
Type: self-proclaimed independent state since 1965 (not recognized by U.S.);
provisional settlement with U.K. in November 1971 cancelled by U.K. in
May 1972 in response to Pearce Commission''s conclusion that its terms were
unacceptable to the majority of black Rhodesians
Capital: Salisbury
Political subdivisions: 1] magisterial districts
Legal system: Smith government implemented a republican constitution on 2 March
1970 which institutionalized white rule
Branches: President Dupont is ceremonial head of state; executive council
(cabinet) lead by Prime Minister Smith; National Assembly gives highly
disproportionate representation to white minority -- 50 white constituency
seats and 16 black constituency seats
Government leaders: Prime Minister Ian Smith and President Clifford Dupont
Suffrage: franchise is based on income, property holdings, and education; there
are separate rolls for Africans and non-Africans
Elections: must be held every 5 years
Political parties and leaders: Rhodesian Front, Prime Minister Smith; Rhodesian
Party, Allan Savory; Rhodesia National Party, Leonard Idensohn; African
National Council, Abel Muzorewa; African Progressive Party, Chad Chipunza
Voting strength (1970 elections): Rhodesian Front won all 50 white constituency
seats in Parliament
Communists: negligible
Other pressure groups and leaders: African nationalist organizations banned
from political activity -- Zimbabwe African People''s Union, Joshua Nkomo;
Zimbabwe African National Union, Ndaban‘ngi Sithole; these leaders detained
by government; exiled leaders in Lusaka, Zambia, are Jasopo Moyo (ZAPU) and
Herbert Chitepo (ZANU); Front for the Liberation of Zimbabwe (FROLIZI),
James Chikerema
Member of: no international bodies
289
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','1426e99e632905d390e8ebaa39c8faf4f95826f88f0fe8d1ff64e27dce50cdb4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c23bb72a7c0562b51eb5571c32cede7abd1afdce6d572521574eb5fa2517de61',1974,'RO','Romania','government',341,'Legal name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 39 counties and 46 municipalities, including Bucharest
that has administrative status equal to a country
Legal system: mixture of civil law system and Communist legal theory which
increasingly reflects Romanian traditions; constitution adopted 1965; legal
education at University of Bucharest and two other law schools; has not
accepted compulsory ICJ jurisdiction
Branches: Presidency; Council of Ministers; the Grand National Assembly, under
which is Office of Prosecutor General and Supreme Court; Council of State
Government leaders: Manea Manescu, President of the Council of Ministers, head of
government; Nicolae Ceausescu, President of the Socialist Republic, head of
state
Suffrage: universal over age 18, compulsory
Elections: elections in Romania held every 4 years for the local people''s
councils and every 5 years for Grand National Assembly deputies
Political parties and leaders: Communist Party of Romania only functioning party,
'' Nicolae Ceausescu, General Secretary
Voting strength (1969 election): overall participation reached 99.96%; of those
registered to vote (13,577,143), 99.75% voted for party candidates
Communists: 2,366,000 party members (November 1973)
Member of: CEMA, FAO, IAEA, IBRD, ICAO, ILO, IMF, ITU, Seabeds Committee, U.N.,
UNESCO, UPU, Warsaw Pact, WHO, WMO, GATT','ab99b2cae4a639f63d75beaf0c00b456e49812545d1cb549cd412026fb604392','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1daa9f8f8bde609113d41d1cc7d13c5c0555f5fd656dbe4b98bbcb61fe857d28',1974,'RW','Rwanda','government',345,'Legal name: Republic of Rwanda
Type: republic, military government since July 1973; no constitution
Capital: Kigali
Political subdivisions: 10 prefectures, subdivided into 141 communes
Legal system: based on German and Belgian civil law systems and customary law;
constitution adopted 1962; judicial review of legislative acts in the
Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: President, Committee for Peace and National Unity (composed of high
military command), and 13-member cabinet
Government leader: General Juvenal Habyarimana, Head of State
Suffrage: none
Elections: last legislative election September 1969; none allowed by present
Political parties and leaders: none; all political activity banned and elections
cancelled by military government after its duly 5, 1973 coup
Communists: no communist party; U.S.S.R. and People''s Republic of China have
diplomatic missions in Rwanda
Member of AFDB, EAMA, IBRD, ICAO, ILO, IMF, ITU, OCAM, OAU, U.N., UNESCO, WHO,
WMO
Legal name: State of St. Christopher-Nevis-Anguilla
Type: dependent territory with full internal autonomy as a British "Associated
State"; Anguilla formally seceded in May 1967 but has not been recognized
as an independent state by any government; in July 1968 a legislative
council headed by Ronald Webster was elected to govern Anguilla; in March
1969 the U.K. sent troops to Anguilla, placing the island again under
colonial rule; in 1971, Anguilla reverted to its former colonial relationship
with the U.K. although nominally remaining part of the Associated state of
St. Christopher-Nevis-Anguilla
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law; constitution of 1960; highest judicial
organ is Court of Appeal of Leeward and Windward Islands
Branches: legislative, 10-member popularly elected House of Assembly; executive,
cabinet headed by prime minister
Government leaders: Premier, Robert L. Bradshaw; U.K. Acting Governor, M. P. Allen
Suffrage: universal adult suffrage
Elections: at least every 5 years; most recent 10 May 1971
Political parties and leaders: St. Christopher-Nevis-Anguilla Labor Party, Robert
L. Bradshaw; People''s Action Movement (PAM), William Herbert; Nevis Reformation
Party (NRP), Ivor Stevens
Voting strength (1971 election): St. Christopher-Nevis-Angquilla Labor Party won
7 seats in the House of Assembly, PAM won 2, 1 seat remains open for Anguilla
which did not participate in the election
Communists: none known
Member of: has been invited to join CARICOM
Legal name: State of St. Lucia','4d8828cc8dd6b97669d11f49072a810b5461f2974f149f15ea65330dffad0d50','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ec5f3a7ac742562a5bf2707221fc2881aa21f66fb77cd7cfb661eece574a60e',1974,'SA','Saudi Arabia','government',349,'Legal name: Kingdom of Saudi Arabia
Type: monarchy
Capital: Riyadh; foreign ministry and foreign diplomatic representatives located
in Jiddah
Political subdivisions: 18 amirates
Legal system: largely based on Islamic law, several secular codes have been
introduced; commercial disputes handled by special committees; has not
accepted compulsory ICJ jurisdiction
Branches: King Faysal (Al Saud, Faysal ibn Abd al-Aziz) rules in consultation
with ruling family, Council of Ministers, and religious leaders
Government leader: King Faysal
Communists: negligible
Member of: Arab League, FAO, IAEA, IATA, IBRD, ICAO, IDA, IFC, IMF. ITU, OAPEC,
OPEC. U.N., UNESCO, UPU, WHO, WMO
Legal name: Socialist Federal Republic of Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
Political subdivisions: 6 republics with 2 autonomous provinces (within the
Republic of Serbia)
Legal system: mixture of civil law system and Communist legal theory; constitution
adopted 1963 and amended in 1967, 1968, and 1971 (a new constitution will be
adopted and implemented in early 1974); in early stage of development is a
system of judicial review of legislative acts in Constitutional Court (a
quasi-judicial body}; legal education at several law schools; has not accepted
compulsory ICd jurisdiction
Branches: parliament (Federal Assembly) constitutionally supreme; executive
includes cabinet (Federal Executive Council) and the federal administration;
independent judiciary; the State Pesidency is a collective policymaking body
based on proportional representation of all the republics an’ provinces, Tito
presides as President of the Republic
Government leader: Josip Broz Tito, President of Republic and President of
League of Communists of Yugoslavia
Suffrage: universal over age 18
Elections: Federal Assembly elected every 4 years by a complicated, indirect
system of voting
Political parties and leaders: League of Communists of Yugoslavia (LCY) only;
leaders are President Tito and influential presidium members Edvard Kardelj,
Veljko Viahovic, Mijalko Todorovic, Vladimir Bakaric, and Stane Dolanc
Voting strength: Voter participation in national elections has declined, as
follows -- 1963, 95.5%; 1965, 93.6%; 1967, 89%; 1969, 88%
Communists: 1,076,711 party members (1973)
Other political or pressure groups: Socialist Alliance of Working People of
Yugoslavia (SAWPY), the major mass front organization for the LCY;
Confederation of Trade Unions of Yugoslavia (CTUY), Union of Youth of
Yugoslavia (UYY), Federation of Yugoslav War Veterans (SUBNOR)
383
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Member of: CEMA (observer but participates in certain commissions), EC (5-year
non-preferential trade agreement signed in May 1973), FAO, GATT, IAEA, IBRD,
ICAQ, IHB, ILO, IMCO, IMF, ITU, OECD (participant in some activities), Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Zaire (until October 1971 known as Democratic Republic
of the Congo)
Type: republic; constitution establishes strong presidential system
Capital: Kinshasa
Political subdivisions: 8 regions and federal district of Kinshasa
Legal system: based on Belgian civil law system and tribal law; new constitution
promulgated 1967; legal education at National University of Zaire; has not
accepted compulsory ICJ jurisdiction
Branches: president elected 1970 for seven-year term; National Legislative
Council of 420 members elected for five-year term; the official party is
the supreme political institution
Government leaders: Lt. Gen Mobutu Sese Seko, President
Suffrage: universal and compulsory over age 18
Elections: presidential and legislative elections in October and November 1970
Political parties and leaders: Mouvement Populaire de la Revolution (MPR), only
legal party, organized from above with actual grassroots popularity not
clearly definable
Voting strength: MPR slate polled 96.3% of vote in 1970 elections
Communists: no Communist Party; U.S.S.R. and People''s Republic of China have
diplomatic missions in Zaire
Member of: AFDB, EAMA, FAQ, IAEA, ICAQ, IHB, ILO, ITU, OAU, UDEAC, U.N., UNESCO,
UPU, WHO, WMO','477ecc5aebfac90a6a792e7241039b83e18cf7290ef3be207e76379eb3c50e7d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('765387ef7f4a3dc1ef75ee477826309c34e8650bb74077e2052b353ec0462109',1974,'SN','Senegal','government',353,'Legal name: Republic of Senegal
Type: republic; only one legal party since 1966
Capital: Dakar
Political subdivisions: 7 regions, each subdivided into 18 departments, 90
National Assembly; 80-member National Assembly, elected for 5 years
(effective 1973); President elected for 5-year term (effective 1973) by
universal suffrage; Judiciary headed by Supreme Court, with members appointed
by President
Government leaders: Leopold Sedar Senghor, President; Abdou Diouf, Prime Minister
Suffrage: universal adult
Elections: uncontested presidential and legislative elections held February
1973 for 5-year term
Political parties and leaders: Union Progressiste Senegalaise (UPS), ruling
party led by President Leopold Senghor, has absorbed all major opposition
parties; illegal parties include Communist-backed Parti Africain
de 1''Independence (PAI) and Parti Communiste Senegalais (PCS), a splinter
group
Communists: a few Communists and sympathizers; PAI is pro-Moscow; PCS is
pro-Peking
Other political or pressure groups: labor unions are controlled by party;
students and teachers occasionally strike
Member of: ACCT, AFDB, CEAO, EAMA, ECA, FAO, IAEA, IBRD, ICAO. ILO, IMCO, IMF,
ITU, OCAM, OMVS, U.N., UNESCO, UPU, WHO, WMO
305
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','d586d438d2e347fa47bc39a15588e369f7ff425ce877b93d455f51b08e24898d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdc0d637937395521c69d4caaeecdb9fb631c5171647752ef82828acca38dd2f',1974,'SC','Seychelles','government',357,'Legal name: Colony of the Seychelles
Type: British crown colony
Capital: Victoria, Mahe Island
Legal system: based on English common law, French civil law system, and
‘ customary Taw
Branches: Governor, Council of Ministers, Legislative Assembly
Government leader: Governor Sir Bruce Greatbatch
Suffrage: universal adult
Elections: April 1974, held every 5 years
7 Political parties and leaders: Seychelles Democratic Party (SDP), James R.
Mancham, President; Seychelles Peoples United Party (SPUP), France Albert
Rene, President
Voting strength: SDP won 3 seats in Legislative Assembly with 52.4% popular
vote in 1974 election; SPUP won 2 seats with 47.6% of vo tes
Communists: negligible
Other political or pressure groups: trade unions which are appendages of
political parties','09855dca28c7b580b96cd0bafea10f3fe7d94662e342a7c3d66f038edc77db23','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6b4ab8804ff931c15c1310d16457804817b139ea443796a49034de47e7fb1b4',1974,'SL','Sierra Leone','government',361,'Legal name: Republic of Sierra Leone
Type: republic under presidential regime since April 1971
Capital: Freetown
Political subdivisions: 3 provinces; divided into 12 districts with 146 chief -
doms, where paramount chief and council of elders constitute basic unit of
government; plus western area, which comprises Freetown and other coastal
areas of the former colony
Legal system: based on English law and customary laws indigenous to local
tribes; constitution adopted April 1971; highest court of appeal is the
Sierra Leone Court of Appeals; has not accepted compulsory CJ jurisdiction
Branches: executive authority exercised by President; parliament consists of 97
members, 85 of whom are elected representatives and 12 paramount chiefs
representing tribal councils in provincial districts; independent judiciary
Government leader: Siaka Stevens, President, heads APC government composed
of members of his political party
Suffrage: universal over age 21
Elections: the maximum life of an elected parliament is 5 years, but it may be
dissolved earlier by the President; parliamentary election held in May 1973;
President is elected by parliament for 5 year term; next presidential election
1976
Political parties and leaders: All People''s Congress (APC), headed by Stevens;
Sierra Leone People''s Party (SLPP) is the opposition party
Communists: no party, although there are a few Conmunists and a slightly larger
number of sympathizers .
Member of: AFDB, Commonwealth, ECA, FAQ, IAEA, IBRD, ICAO, ILO, IMF, ITU, OAU,
Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Sikkim
Type: autonomous protectorate of India ruled by a hereditary maharaja as
titular ruler; tied to India by 1950 treaty and brought under further
control by 1973 agreement; ruler controls only palace affairs; external
relations, defense, and communications are India''s exclusive responsibility
Political subdivisions: none known
Legal system: constitution in preparation
Branches: Executive Council] appointed from elected legislature with Indian
chief executive as head of administration
Government leader: Maharaja Paldem Thondup Namgyal, known as the Chogyal of
Sikkim
Suffrage: universal suffrage
Elections: to be held every 4 years beginning in April 1974
Political parties and leaders: Sikkim National Congress Party; Sikkim National
Party; Sikkim State Congress/Janta Congress
Communists: no overt presence','1fc56c7447df2430a5a6cf8ae5e9e4040bf78ae802d756c56a49e52d782af80e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28aa195b059f5bbe261fb72418d8dbf09e2072abc6ef6f6f45b856b4f8b643e9',1974,'SG','Singapore','government',365,'Legal name: Republic of Singapore
Type: republic within Commonwealth since separation from Malaysia in August 1965
Capital: Singapore
Legal system: based on English common law; constitution based on preindependence
State of Singapore constitution; legal education at University of Singapore;
has not accepted compulsory ICJ jurisdiction
Branches: ceremonial President; executive power exercised by Prime Minister and
cabinet responsible to unitary legislature
Government leaders: President, Dr. Benjamin Sheares; Prime Minister, Lee Kuan Yew
Suffrage: universal over age 20; voting compulsory
Elections: normally every 5 years
Political parties and leaders: government -- People''s Action Party (PAP), Lee
Kuan Yew; opposition -- Barisan Sosialis Party (BSP). Dr. Lee Siew Choh;
Workers'' Party, J.B. Jeyaretnam; Communist Party illegal
Voting strength (1972 election): PAP won all 65 seats in parliament and received
70% of vote; remaining 30% to four opposition parties
Communists: 200-500; Barisan Sosialis Party infiltrated by Communists
Member of: ADB, ASEAN, Colombo Plan, IAEA, IBRD, ICAO, ILO, IMCO, IMF, ITU,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Somali Democratic Republic
Type: republic; under military rule since October 1969
Capital: Mogadiscio
Political subdivisions: 11 regions, 56 districts
Organization: the junta has assumed all authority, calling itself the Supreme
Revolutionary Council, membership of which consists of 18 army and 3 police
officers; the Council has abrogated the constitution, dissolved the parliament,
and banned political parties
Government leader: President of the Supreme Revolutionary Council, Gen. Mohamed
Siad Barre
Communists: possibly some Communist sympathizers in the government hierarchy
Member of: AFDB, EAMA, FAQ, IBRD, ICAO, ILO. IMF, ITU, OAU. U.N. , UNESCO, UNICEF,
UPU, WHO','2845d281df7e5d5dba24447a6fb68763923f94af1768acbaf0a98c725307bb61','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afe14adf06e27b9226024345541f17fbe8261a19dd0e37ffa0c7272d2bcf4032',1974,'ZA','South Africa','government',369,'Legal name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative, Cape Town; judicial, Bloemfontein
Political subdivisions: 4 provinces, each headed by centrally appointed
administrator; provincial councils, elected by white electorate, retain
limited powers
Legal system: based on Roman-Dutch law and English common law; constitution
enacted 1961, changing the Union of South Africa into a Republic; possibility
of judicial review of Acts of Parliament concerning dual official languages;
accepts compulsory ICJ jurisdiction, with reservations
Branches: President as formal chief of state; Prime Minister as head of
government; Cabinet responsible to bicameral legislature; Tower house
elected directly by white electorate; upper house indirectly elected and
appointed; judiciary maintains substantial independence of government
influence
Government leader: Prime Minister Johannes J. Vorster
Suffrage: general suffrage limited to whites over 18 (17 in Natal Province)
Elections: must be held at least every 5 years; last elections April 1974
Political parties and leaders: National Party, B. J. Vorster, P. W. Botha,
C. Mulder, M. C. Botha, Jan De Klerk; United Party, Sir De Villiers graaff;
Progressive Party, Colin Eglin, Helen Suzman; Herstigte Nasionale party,
Albert Hertzog
Voting strength (1974 general elections): of 166 legislative seats, National
Party 122, United Party 41, Progressive Party 6
Communists: small Communist Party illegal since 1950; party in exile maintains
headquarters in London; Dr. Yasuf Dadoo, Michael Harmel, Joe Slovo
Other political groups: (insurgent groups in exile) African National Congress (ANC),
Oliver Tambo; Pan-Africanist Congress (PAC), leadership in dispute
Member of: IAEA, IBRD, ICAO, IHB, IMF, ITU, Seabeds Committee (observer), U.N.,
UPU, WHO, WMO
317
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
SOUTH-WEST AFRICA
LAND:
318,000 sq. mi.; mostly desert except for interior
plateau and area along northern border
Land boundaries: 2,360 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 925 mi.
Legal name: Territory of South-West Africa
Type: administered as part of Republic of South Africa, since a League of nations
mandate in 1920; U.N. formally ended South Africa''s mandate, and status now
in dispute
Capital: Windhoek
Political subdivisions: 10 tribal homelands, mostly in northern sector, and zone
open to white settlement with administrative subdivisions similar to a pro-
vince of South Africa
Legal system: based on Roman-Dutch Jaw and customary law
Branches: administrator, appointee of South African Government, has jurisdiction
over zone of white settlement with white-elected Legislative Assembly handling
some local matters; white residents also elect representatives in South African
Parliament; tribal homelands are under South African Department of Bantu
Administration and Development with tribal chiefs exercising limited autonomy;
popularly elected legislative councils for Ovamboland and Kavangoland estab-
lished in August 1973
Government leader: B.J. van der Walt, Administrator
Suffrage: limited to white adults
Elections: last general election, 1970
Political parties and leaders: white parties -- National Party (NP), led in
South-West Africa by A. H. du Plessis; United National South-West Party
(UNSWP), J. P. Niehaus; nonwhite parties -- South-West Africa People''s
Organization (SWAPO), almost exclusively based on Ovambo tribe led by Sam
Nujoma, in exile; South-West Africa National Union (SWANU), primarily based
on Herero tribe, leaders in exile; National Unity Democratic Organization
(NUDO), primarily based on Herero tribe led by Clements Kapuuo
Voting strength: NP (1970 election) won all 10 seats in Republic legislature
and all 18 seats in South-West Africa Legislative Assembly
Communists: no Communist Party, but some influence by South African Communists
and other Communists on South-West African Bantu outside territory
319
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8','cbe7a0c3db9e13a41c05a908204350607c68b26f8e0a7cadaacf4ca8381a282c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f40b7aee9d2b7c383de1aad4b141839d75d775421fd2a379f1f4132e2bfa036',1974,'ES','Spain','government',370,'LAND:
195,000 sq. mi., including Canary (2,900 sq. mi.) and
Balearic Islands (1,940 sq. mi.); 41% arable and
Tand under permanent crops, 27% meadow and pasture,
22% forest, 10% urban or other
Land boundaries: 1,180 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 3,085 mi. (includes Balearic Islands, 420 mi.,
and Canary Islands, 720 mi.)
Legal name: (The) Spanish State
Type: nominally a monarchy, but without a king; actually an authoritarian regime
under Generalissimo Franco with Prince Juan Carlos designated to succeed him
as chief of state and become king
Capital: Madrid
Political subdivisions: metropolitan Spain, including the Canaries and Balearics,
divided into 50 provinces with governors appointed by the central government,
also 1 province and 5 places of sovereignty (presidios) in Africa; Ifni
province ceded by Spain to Morocco in June 1969; 2 former provinces com-
prising Equatorial Guinea were granted independence in October 1968
Legal system: civil law system, with regional applications of customary law;
7 basic laws including Organic Law of the State of January 1967 serve as
a constitution; legal education at 14 schools of law; does not accept
compulsory ICJ jurisdiction
Branches: executive, with chief of government dominating all branches of
government through his appointive powers and authority to legislate by
decree; legislative with unicameral Cortes dominated by executive; judicial,
independent in principal but generally limited to interpretation of laws
Government leader: Generalissimo Francisco Franco -- Chief of State, commander
in Chief of the armed forces, and head of the National Movement (formerly
called the Falange}
Suffrage: universal in national referendums, over age 21
Elections: only two types of direct election other than referendum provided:
representatives to municipal councils for which only heads of households
vote (latest election November 1973) and, under new constitutional law of
1967, 104 members of the Cortes elected by heads of households and married
women for a 4-year term (last election September 1971)
321
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: Province of Sahara
Type: province of Spain, subordinate to Ministry of the Presidency
Capital: E1 Aaiun
Political subdivisions: two regions -- Rio de Oro and Saguia el Hamra
Legal system: based on Spanish civil law system and customary law
Branches: Governor General, responsible to Directorate General of the Promotion
of the Sahara (a division of the Ministry of the Presidency, administers;
General Assembly, elected by the natives, can submit proposals to Spanish
Government leader: Governor General (Brig. Gen.) Fernando de Santiago y Diaz
de Mendivil
Suffrage: heads of families only
Elections: 40 members of General Assembly, February 1973; 2 deputies to Spanish
Cortes, November 1971
Political party: National Movement
Communists: party proscribed; Communist sympathizers, few (if any)
Other political or pressure groups: various smal] "Liberation Movements "
Legal name: Republic of Sri Lanka
Type: independent state since 1948
Capital: Colombo
Political subdivisions: 9 provinces, 22 administrative districts, and four
categories of semiautonomous elected local governments
Legal system: a highly complex mixture of English common Taw, Roman-Dutch,
Muslim and customary law; new constitution 22 May 1972; no judicial review
of legislative acts; legal education at Sri Lanka Law College and University
of Sri Lanka, Peradeniya; has not accepted compulsory ICJ jurisdiction
Branches: unitary parliamentary form of government; unicameral legislature
and independent judiciary
Government leader: Prime Minister Sirimavo Bandaranaike
Suffrage: universal over age 18, but most Indian Tamils, who comprise 10.6% of
population, are not enfranchised
Elections: national elections, ordinarily held every 6 years; must be held more
frequently if government loses confidence vote; last election held May 1970,
but new constitution postpones deadline for next election until May 1977
Political parties and leaders: Sri Lanka Freedom Party, Sirimavo Ratwatte Dias
Bandaranaike, President; Lanka Sama Samaja Party (Trotskyite), N. M. Perera,
President; Tamil United Front, S. J. V. Chelvanayakam, leader; United national
Party, J. R. Jayewardene, leader of "hardline" faction, Pieter Keuneman, leader
of "softline" faction; Communist Party/Moscow, S. A. Wickremasinghe, General
Secretary; Communist Party/Peking, N. Shanmugathasan, General Secretary;
Mahajana Eksath Peramuna (People''s United Front), M. B. Ratnayaka, President
Voting strength (1970 election): 37% Sri Lanka Freedom Party, 38% United
National Party, 9% Lanka Sama Samaja Party, 3.5% Communist Party/Moscow,
5% Federal Party, minor parties and independents accounted for remainder
Communists: approximately 169,000 voted for the Communist Party in the May 1970
general election; Communist Party/Moscow approximately 2,000, Communist
Party/Peking 532 (1968 est.)
327
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Other political or pressure groups: Buddhist clergy, Sinhalese Buddhist lay
groups; far-left violent revolutionary groups; labor unions
Member of: ADB, Colombo Plan, Commonwealth, FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMCO, IMF, ITU, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO','78c1efc570bfe5532a3ba0cb3536028e2e90e1047931aa4f03251cc1093f7017','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1219f00703e21143ffc0e441471ba97b3e0f085aa2ceaed2277efabd6f49f57f',1974,'SD','Sudan','government',376,'Legal name: Democratic Republic of the Sudan
Type: republic under military control since coup in May 1969
Capital: Khartoum
Political subdivisions: 9 provinces, provincial and local administrations
controlled by central government; limited regional autonomy in 3 southern
provinces
Legal system: based on English common law and Islamic law; some separate
religious courts; permanent constitution promulgated April 1973; Revolutionary
Command Council established in 1969 dissolved in October 1971 with the in-
stallation of Ja''far al-Numayri as president and chief executive; Numayri has
reorganized government through a sertes of Republican decrees; legal education
at University of Khartoum and Khartoum extension of Cairo University at
Khartoum; accepts compulsory [CJ jurisdiction, with reservations
Government leader: President and Prime Minister Ja''far al-Numayri
Suffrage: universal adult
Elections: most recent parliamentary elections held in April 1968; presidential
plebescite held in September 1971; elections to constituent assembly held in
September-October 1972; elections for southern regional assembly held in
November 1973; elections for first national assembly under Numayri scheduled
for 1974
Political parties and leaders: all parliamentary political parties outlawed since
May 1969; the ban on the Sudan Communist Party was not enforced until after
abortive coup in July 1971; the government''s mass political organization, the
Sudan Socialist Union, was formed in January 1972
Voting strength: not tabulated by party
Communists: party decimated following July 1971 coup and counter-coup, several
top leaders including Secretary-General Mahjub executed; actual hard-core
membership down to lowest point in years; party control over labor unions,
professional groups and university student groups ended; Communists purged
329
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
from government; party is being reorganized underground under leadership of
Secretary -General Muhammad Nujud, 3,500 CP members
Other political or pressure groups: Muslim Brotherhood; Ansar Muslim sect, at odds
with the military regime since the May coup, defeated in fighting in spring 1970;
Sudan Opposition Front, composed of former political party elements and other
disgruntled conservative interests, operates in exile
Member of: AFDB, Arab League, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
Seabeds Committee, U.N., UPU, WMO','1a3f62b95882393803c19950c3404fdb981dec91be79491a578a24e0a6ed6797','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73f505b58796c3e6f554155dee1f6f0bd529f440f5e19e8a601831bb5f04976f',1974,'SE','Sweden','government',380,'Legal name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 provinces, 624 communes, 224 towns
Legal system: civil law system influenced by customary law; Acts of 1809, 1810,
1866, and 1949 serve as constitution; legal education at Universities of
Lund, Stockholm, and Uppsala; accepts compulsory ICJ jurisdiction, with
reservations
Branches: legislative authority rests with parliament (Riksdag); executive power
vested in cabinet, responsible to parliament; Supreme Court, 6 superior courts,
108 lower courts
Government leaders: King Carl XVI Gustaf; Prime Minister Olof Palme
Suffrage: universal, but not compulsory, over age 20
Elections: every 3 years (next in September 1976)
Political parties and leaders: Moderate Coalition (conservative), Gosta Bohman;
Center, Thorbjorn Falldin; Liberal, Gunnar Helen; Social Democratic, Olof
Palme; Communist, Carl-Henrik Hermansson; Communist League of Marxists-Leninists
(KFML), Gunnar Bylin
Voting strength (1973 election): 14.3% Moderate Coalition, 25.0% Center, 9.4%
Liberal, 43.7% Social Democratic, 5.3% Communist, 2.3% other ;
Communists: 17,000; a number of sympathizers as indicated by the 274,929
Communist votes cast in 1973 elections; an additional 8,014 votes cast for
Maoist KFML
Member of: Council of Europe, EC (Free Trade Agreement), EFTA, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, Nordic Council, OECD,
Seabeds Committee (observer), U.N., UNESCO, UPU, WHO, WMO','27977b96324ad52fde61c996e672011acbc20d4010e52679d8d7fc9df5364a9f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78db7470a70e8c02167ffa0bdf2d93422ca27078d8842b76fb931cc9148e2c10',1974,'CH','Switzerland','government',383,'Legal name: Swiss Confederation
Type: federal republic
Capital: Bern
Political subdivisions: 22 cantons (3 divided into half cantons)
Legal system: civil law system influenced by customary law; constitution adopted
1874, amended since; judicial review of legislative acts, except with
respect to Federal decrees of general obligatory character; legal education
at Universities of Bern, Geneva and Lausanne, and four other university
schools of law; accepts compulsory ICJ jurisdiction, with reservations
Branches: bicameral parliament has legislative authority; federal council
(Bundesrat) has executive authority; justice left chiefly to cantons
Government leader: Ernst Brugger (1-year term as president began on January 1974),
President ;
Suffrage: universal over age 20
Elections: held every 4 years; next elections 1975
Political parties and leaders: Social Democratic Party (SPS), Arthur Schmid,
president; Radical Democratic Party (FDP), Henri Schmitt, president;
Christian Conservative People''s Party (CVP), Franz Josef Kurmann, president;
Farmer, Artisan, and Middle Class Party (BGB), Hans Conzett, president;
Communist Party (PdA), Jean Vincent, leading Secretariat member; Republican
Movement (REP)-National Action (N.A.), James Schwarzenbach
Voting strength (1971 election): 49 seats FDP, 44 seats CVP, 46 seats SPS, 23
seats BGB, 5 seats PdA, 4 seats N.A., 7 seats REP, 22 seats others
Communists: 3,500; 50,831 votes in 1971 election
Member of: Council of Europe, EFTA, FAQ, IAEA, ICAO, OECD, U.N. (permanent
observer), WHO, WMO
Legal name: Syrian Arab Republic
Type: republic; under left-wing military regime since March 1963
Capital: Damascus
Political subdivisions: 13 provinces and city of Damascus administered as
separate unit :
Legal system: based on Islamic law and civil law system; special religious courts;
constitution promulgated in 1973; legal education at Damascus University and
University of Aleppo; has not accepted compulsory ICJ jurisdiction
Branches: executive powers vested in President and Council of Ministers; legis-
lative power rests in the People''s Assembly (election pending);
seat of power is the Ba''th Party Regional (Syrian) Command
Government leaders: President Hafiz Al-Asad
Suffrage: universal at age 18
Elections: no electoral laws being drafted; last elections in December 1961;
presidential referendum in 1971; local councils elected in March 1972,
assembly elections pending
Political parties and leaders: ruling party is the Arab Socialist Resurrectionist
(Ba''th) party; a "national front" cabinet formed in March 1972, dominated by
Ba''thists, includes independents and members of the Syrian Arab Socialist
Party (ASP), Arab Socialist Union (ASU), and Syrian Communist Party (SCP)
Communists: mostly sympathizers, numbering 10,000 to 13,000
Other political or pressure groups: non-Ba''th parties have little effective
political influence; Communist Party ineffective; greatest threat to Ba''thist
regime lies in factionalism in Ba''th Party itself; conservative religious
leaders
Member of: Arab League, FAQ, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: United Republic of Tanzania
Type: republic; single parties dominate both on the mainiand and on Zanzibar
Capital: Dar es Salaam
Political subdivisions: 22 regions -- 18 on mainland, 4 on Zanzibar islands
Legal system: based on English common law, Islamic law, customary law, and German
civil law system; interim constitution adopted 1965; judicial review of
legislative acts limited to matters of interpretation: Tegal education at
University College, Dar es Salaam; has not accepted compulsory ICJ jurisdiction
Branches: President Julius Nyerere has full executive authority on the mainiand;
National Asssembly dominated by Nyerere and the Tanganyika African National
Union (TANU), consists of 120 elected members, 18 ex officio members, and up
to 25 appointed members from mainland, and 3 ex officio members and up to 52
appointed members from Zanzibar; First Vice President Aboud Jumbe and the
Revolutionary Council still run Zanzibar despite the efforts of Nyerere to
integrate the islands into the political system of the mainland
Government leader: President Julius Nyerere
Suffrage: universal adult
Political party and leaders: Tanganyika African National Union (TANU), only main-
land political party, dominated by Nyerere with Prime Minister and Second
Vice President Rashidi Kawawa as his top lieutenant; Afro-Shirazi Party, the
only party in Zanzibar, is supposed to merge with TANU eventually
Voting strength (October 1970 national elections): 5 million registered voters;
Nyerere received 95% of 3.6 million votes cast
Communists: a few Communists and sympathizers
Member of: AFDB, Commonwealth, EAC, FAQ, GATT, IBRD, ICAO, IFC, ILO, IMF, ITU,
OAU, Seabeds Committee, U.N., UNESCO, UPU, WHO, WMO
34]
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions: 71 centrally controlled provinces
Legal system: based on civil law system, with influences of common law; provisional
constitution promulgated December 1972; new draft currently in review by interim
National Assembly; legal education at Thammasat University; has not accepted
compulsory ICJd jurisdiction
Branches: King is head of state with nominal powers; Prime Minister heads a
22-man cabinet; National Assembly unicameral] and appointed by executive
branch; judiciary relatively independent except in important political
subversive cases
Government leaders: King Phumiphon Adundet; Sanya Thammasak, Prime Minister;
Sukit Nimmanhemin, Deputy Prime Minister
Suffrage: universal
Elections: expected within 3-6 months
Political parties and leaders: dissolved under the revolutionary order 17
November 1971 but will be reestablished in time for new elections
Communists: strength of illegal Communist Party is about 1,000; Thai Communist
insurgents throughout Thailand total about 7,000
Other political or pressure groups: none
Member of: ADB, ASA, ASEAN, ASPAC, Colombo Plan, ECAFE, FAO, IAEA, ICAO, IDA,
IFC, IHB, ILO, ITU, Seabeds Committee, SEAMES, SEATO, U.N., UNESCO, UNICEF,
UPU, WHO, WMO','779cbc9df908a187b1ca8f532988534c74738c6fe5cc2f2fb0222f3bb915327f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c78ff3c9447e9c95a68f2df8db650845625d255ce049073d4e96d1f89fc9c87d',1974,'TG','Togo','government',388,'Legal name: Togolese Republic
Type: republic; under military rule since January 1967
Capital: Lome
Political subdivisions: 19 circumscriptions
Legal system: based on French civil law and customary practice; no constitution;
has not accepted compulsory ICJ jurisdiction
Branches: military government, with civilian-dominated cabinet, took over on
14 April 1967, replacing provisional government created after January coup; no
legislature; separate judiciary including State Security Court established 1970
Government leader: Maj. Gen. Etienne Eyadema, President
Suffrage: universal adult
Elections: presidential referendum of January 1972 elected Etienne Eyadema for
indefinite period
Political parties: single party formed by President Eyadema in September 1969,
Rassemblement du Peuple Togolais, structure and staffing of party closely
controlled by government
Communists: no Communist Party; possibly some sympathizers
Member of: ACCT, AFDB, EAMA, ECA, ENTENTE, FAO, IBRD, ICAO, ILO, IMF, ITU,
OAU, OCAM, U.N., UNESCO, UPU, WHO, WMO','d92e62286fb808bb9a36fa0f809b43d18a1f55a305f1adca3174aa8e22f463ce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d426fe930e74409139c6cd78f61eeaa68264a92f837bbc08f753e285bcd7c277',1974,'TO','Tonga','government',392,'Legal name: Kingdom of Tonga
Type: constitutional monarchy
Capital: Nukualofa
Political subdivisions: 3 main island groups (Tongatapu, Haapi. Vavau)
Legal system: based on English law
Branches: Executive (King and Privy Council); Legislative (Legislative Assembly
composed of 7 nobles elected by their peers, 7 elected representatives of
the people, 7 Ministers of the Crown; the King appoints one of the 7 nobles
to be the speaker); Judiciary (Supreme Court, magistrate courts, Land Court)
Government leaders: King Taufa''ahau Tupou IV; Premier, Prince Tu''ipelehake
(younger brother of the King)
Suffrage: granted to all literate adults over 21 years of age who pay taxes
Elections: held triennially
Communists: none known
Member of: Commonwealth','4f48bcc445745c303d03b8e69aaa6222833121995748efea4bd39fe23d8e7955','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40344835be5c22d850b59585d08038c91cc076d3f881d9cf08e6ac661ce179c3',1974,'TT','Trinidad and Tobago','government',396,'Legal name: Trinidad and Tobago
Type: independent state since August 1962; recognizes Elizabeth II as chief
of state ;
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards, Tobago is 30th)
Legal system: based on English common law; constitution came into effect
1962; judicial review of legislative acts in the Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: legislative branch consists of 36-member elected House of
Representatives and 24-member Senate (13 nominated by Prime Minister,
4 by opposition leader, 7 at discretion of Governor General); executive is
cabinet led by the Prime Minister; judiciary is Supreme Court
Government leader: Prime Minister, Dr. Eric Williams
Suffrage: universal over age 21
Elections: last election 24 May 1971, PNM won all seats
Political parties and leaders: People''s National Movement (PNM), Dr. Eric
Williams; Democratic Labor Party (DLP), Alloy Lequay and Vernon Jamadar;
United National Independence Party, (UNIP) James Millette; Democratic Action
Congress (DAC), Arthur Napoleon Raymond Robinson
Voting strength (1971 election): 32.9% of registered voters cast ballots, 83.7%
PNM, 16.3% other
Communists: not significant
Other political pressure groups: Tapia House Group (headed by Lloyd Best);
National Youth Congress (NYC); Oilfield Workers Trade Union (OWTU), pro-
Marxist leadership; National Joint Action Committee (NJAC), antigovernment,
extremist organization, National Union of Freedom Fighters (NUFF), small
anti-government guerrilla organization; United Revolutionary Organization (URO),
Marxist-led amalgam
Member of: CARICOM, Commonwealth, GATT, IBRD, ICAO, IDB, IMF, OAS, Seabeds
Committee, U.N., International Coffee Agreement
349
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Legal name: Republic of Tunisia
Type: republic
Capital: Tunis
Political subdivisions: 17 governorates (provinces)
Legal system: based on French civil law system and Isiamic law; constitution
patterned on Turkish and U.S. constitutions adopted 1959; some judicial
review of legislative acts in the Supreme Court in joint session; legal
education at Institute of Higher Studies and Ecole Superieure de Droit of the
University of Tunis; has not accepted compulsory ICJ jurisdiction
Branches: executive dominant; unicameral legislative largely advisory; judicial,
patterned on French system and Koranic law
Government leader: President Habib Bourguiba; Prime Minister Hedi Nouira
Suffrage: universal over age 21
Elections: national elections held every 5 years; last elections 2 November 1969
Political party and leader: Destourian Socialist Party, Habib Bourguiba
Voting strength (1969 election): 100% Destourian Socialist Party
Communists: 100 est.; a few sympathizers; Tunisian Communist Party proscribed in
1962
Member of: Arab League, EC (association until 1974), FAO, IAEA, IBRD, ICAO, IDA,
IFC, ILO, IMCO, IMF, ITU, OAU, Seabeds Committee (observer), U.N., UNESCO, UPU,
WHO, WMO
Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal systems, with remnants of
Islamic law; constitution adopted 1961; judicial review of legislative acts
by Constitutional Court; legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime Minister appointed by President
from members of parliament; Prime Minister is effective executive; cabinet,
selected by Prime Minister and approved by President, must command majority
support in lower house; parliament bicameral under constitution promulgated
in 1961; National Assembly has 450 members serving 4 years; Senate has
150 elected members, one-third elected every 2 years, 15 appointed by the
President to 6-year terms (one-third appointed every 2 years), and 18 life
members; highest court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal, commercial, basic,
and peace courts
Government leaders: President Fahri Koruturk; Prime Minister Bulent Ecevit heads
RPP/NSP coalition government
Suffrage: universal over age 21
Elections: National Assembly and Senate (1/3 of seats), Republican People''s
Party won a plurality October 1973; Presidential (1980)
Political parties and leaders: Justice Party (JP), Suleyman Demirel; Republican
People''s Party (RPP), Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Republican Reliance Party (RRP), Turhan Feyzioglu; National Action Party
(NAP), Alparslan Turkes; Nation Party (NP); Unity Party (UP), Mustafa Timisi;
Communist Party i1legal; National Salvation Party (NSP), Necmettin Erbakan
Communists: strength and support negligible
Other political or pressure groups: military forced resignation of Demirel
government in March 1971 and remains an influential force in government
353
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
GOVERNMENT (cont''d):
Member of: CENTO, Council of Europe, EC (associate member), ECOSOC, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHB, ILO, IMCO, IMF, ITU, NATO, OECD, Regional
Cooperation for Development, Seabeds Committee (observer), U.N., UNESCO,
UPU, WHO, WMO','7f2615d41bac6786e4838a7c9058ed38d3bcddb76653e68855c5e076b00ab5c4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('390423a295291fa084085dcb237e0483a106cbf178355ee567fcbc36292989e0',1974,'UG','Uganda','government',400,'Legal name: Republic of Uganda
Type: republic independent since October 1962
Capital: Kampala
Political subdivisions: 10 provinces and 34 districts
Legal system: based on English common law and customary law; constitution
adopted 1967; present government has abrogated some parts of constitution;
judicial review of legislative acts; legal education at Makerere University,
Kampala; accepts compulsory ICJ jurisdiction, with reservations
Branches: Gen. Amin rules by decree; assisted by Council of Ministers and Defense
Council], a group of military officers
Government leader: Gen. Idi Amin, President
Suffrage: universal adult
Elections: none scheduled by military government
Political party and leader: Uganda People''s Congress (UPC), principal party
before 1971 coup, not banned but inactive
Communists: possibly a few sympathizers
Member of: AFDB, Commonwealth, EAC, IAEA, ICAO, ILO, OAU, U.N., UNESCO, WHO
Legal name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow
Political subdivisions: 15 union republics, 20 autonomous republics, 6 krays,
120 oblasts, and 8 autonomous oblasts
Legal system: civil law system as modified by Communist legal theory; constitution
adopted 1936; no judicial review of legislative acts; legal education at 18
universities and 4 law institutes; has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers (executive), Supreme Soviet (legislative), Supreme
Court of U.S.S.R. (judicial)
Government leaders: Leonid I. Brezhnev, General Secretary of the Central Committee
of the Communist Party; Aleksey N. Kosygin, Chairman of he Council of
Ministers; Nikolay V. Podgornyy, Chairman of the Presidium of the U.S.S.R.
Supreme Soviet
Suffrage: universal over age 18; direct, equal
Elections: to Supreme Soviet every 4 years; 1,517 deputies elected in 1970;
72.3% party members
Political parties and leaders: Communist Party of the Soviet Union (CPSU) only
party permitted
Voting strength (1970 election): 153,237,112 persons over 18; claimed 99.96%
voted
Communists: nearly 14,700,000 party members
Other political or pressure groups: Komsomol, trade unions, and other organi-
zations which facilitate Communist control
Member of: CEMA, Geneva Disarmament Conference, IAEA, ICAO, ILO, IMCO, ITU, U.N.,
UNESCO, UPU, Warsaw Pact, WHO, WMO, Universal Copyright Convention','b05790fac156779c8ca221f5a17d050f29b6343057e4a5466f56e22ed35aa7f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfc8d717f07c5dcb27935bcce101da7d44d219a81052493d3f60596575bf4cc5',1974,'AE','United Arab Emirates','government',404,'Legal name: United Arab Emirates (composed of former Trucial States)
Type: federation; constitution signed December 1971, which delegated specified
powers to the United Arab Emirates central government and reserved other
powers to member sheikhdoms
Capital: Abu Zaby
Legal system: secular codes are being introduced by the U.A,.E. government and
in several member sheikhdoms; Islamic law remains very influential
Branches: Supreme Council] of Rulers (7 members), from which a President and Vice
President are elected; Prime Minister and Council of Ministers; National
Consultative Council; federal Supreme Court
Government leaders: Sheikh Zayid of Abu Dhabi, President; Sheikh Rashid of Dubai,
Vice President; Sheikh Maktum of Dubai, Prime Minister
Suffrage: none
Elections: none
Member states: Abu Dhabi; Ajman; Dubai; Fujairah; Ras al Khaimah; Sharjah; Unm
al Qaiwain
Member of: Arab League, U.N.
Political or pressure groups: none; a few small clandestine groups are active
Legal name: Republic of Upper Volta
Type: republic; military regime in power since January 1966
Capital: Ouagadougou
Political subdivisions: 5 departments consisting of 44 cercles
Legal system: based on French civil law system and customary law; constitution
adopted 1970, suspended February 1974; judicial review of legislative acts in
Supreme Court; has not accepted compulsory ICJ jurisdiction
Branches: President is an army officer; 57-man National Assembly was elected in
December 1970, suspended February 1974
Government leader: Gen, Sangoule Lamizana, president and Prime Minister
Suffrage: universal for adults
Elections: all political activity has been banned
Political parties and leaders: political parties banned February 1974
Communists: no Communist party; some sympathizers
Other political or pressure groups: labor organizations are badly splintered,
students and teachers occasionally strike
Member of: ACCT, AFDB, CEAO, EAMA, ECA, ENTENTE, FAO, ICAO, ILO, ITU, Niger River
Commission, OAU, OCAM, U.N., UNESCO, WHO, WMO','3b5ff346f0f101486b72456c820477cd19c9db6972e87bd1f139e11f40e37a59','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9806aa58f4e816c75bf5ab1831a0237e068fea133386473df7c00d4cf6d9a086',1974,'WF','Wallis and Futuna','government',408,'Legal name: Territory of the Wallis and Futuna Islands
Type: overseas territory of France
Capital: Matu Utu
Political subdivisions: 3 districts
Branches: territorial assembly of 20 members; popular election of one deputy to
National Assembly in Paris, and one Senator
Government leader: Superior Administrator Jacques de Agostini
Suffrage: universal adult
Elections: every 5 years
Legal name: The Independent State of Western Samoa
Type: constitutional monarchy under native chief; special treaty relationship
with New Zealand
Capital: Apia
Legal system: based on English common law and local customs; constitution came
into effect upon independence in 1962; judicial review of legislative acts
with respect to fundamental rights of the citizens; has not accepted
compulsory ICJ jurisdiction
Branches: Head of State and Executive Council; Legislative Assembly; Supreme
Court, Court of Appeal, Land and Titles Court, village courts
Government leaders: Head of State, Malietoa Tanumafili II; Prime Minister,
Fiame Mata''afa
Suffrage: 45 Samoan members of Legislative Assembly are elected by holders of
matai (heads of family) titles (about 5,000); 2 European members are elected
by universal adult suffrage
Elections: held triennially, last in February 1973
Political parties and leaders: no clearly defined political party structure
Communists: unknown
Member of: ADB, Commonwealth, ECAFE, WHO
Legal name: People''s Democratic Republic of Yemen
Type: republic; power centered in ruling National Front Party
Capital: Aden; Madinat ash Sha''b, administrative capital
Political subdivisions: 6 provinces
Legal system: based on Islamic law (for personal matters) and English common
law (for commercial matters); highest judicial organ, Federal High Court,
interprets constitution and determines disputes between states
Branches: Presidential Council; cabinet; Supreme People''s Council
Government leaders: Chairman of Presidential Council, Salim Rubay Ali; Prime
Minister Ali Nasir Muhammed al-Hasani; NF Secretary General Abd Al-Fattah
Ismail
Suffrage: granted by constitution to all citizens 18 and over
Elections: elections for legislative body, Supreme People''s Council, called for
in constitution; none have been held
Political parties and leaders: National Front (NF), only legal party
Communists: few known
Member of: U.N,
Legal name: Yemen Arab Republic
Type: republic; military regime assumed power in June 1974
Capital: San''a''
Political subdivisions: 8 provinces
Legal system: based on Turkish law, Islamic law, and local customary law; first
constitution promulgated December 1970, suspended June 1974; has not accepted
compulsory ICJ jurisdiction
Branches: Military Command Council, Prime Minister
Government leaders: Head of Military Command Council, Col. Ibrahim Hamdi; Prime
Minister Muhsin al Ayni
Communists: few known
Political parties or pressure groups: Yemeni Union, a small inactive government
party formed in February 1973; some pro-Iraqi Baathists, other small
clandestine groups supported by Yemen (Aden)
Member of: Arab League, FAO, ICAO, ITU, U.N., UNESCO, UPU, WHO','b2a9eaa4edb1ac2496b67c91e496d6a60c660950c134982f6249c8e724e53e2d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e2f75e2fb06c274b972ab9f00d2273dc362d4e7394535d203dfcc808a7ac4f1',1974,'ZM','Zambia','government',411,'Legal name: Republic of Zambia
Type: republic since October 1964
Capital: Lusaka
Political subdivisions: 8 provinces
Legal system: based on English common law and customary law; new constitution
adopted September 1973; judicial review of legislative acts in an ad hoc
constitutional council; legal education at University of Zambia in Lusaka; has
not accepted compulsory ICd jurisdiction
Branches: modified presidential system; unicameral legislature; judiciary
Government leader: President Kenneth Kaunda; prime minister to be appointed by
President under new 1 party system
Suffrage: universal adult
Elections: last general election December 1973
Political parties and leaders: United National Independence Party (UNIP),
Kenneth Kaunda; former opposition party banned in December 1972 when
1 party state proclaimed
Voting strength (1973 election): in first presidential and parliamentary elections
under single-party system, 43% of eligible voters went to polls; Kaunda was
only candidate for President; National Assembly seats were contested by members
of UNIP
Communists: no Communist Party, but sympathizers of socialism in upper levels
of government, UNIP, and labor unions
Member of: AFDB, Commonwealth, FAO, IAEA, IBRD, ICAO, IFC, ILO, IMF, ITU, OAU,
U.N., UNESCO, UPU, WHO, WMO','c928f01e84b255c711658e3280150d758b0cf36a45b1e0cc00c0c8e552303eb5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3afab36b78f79fbd00d6bb413a3a1d936c0561190aac34401acc6ea4283c9f3d',1974,'US','United States','government',414,'Legal name: United States of America
Legal system: based on English conmon law; dual system of courts, state and
federal; constitution adopted 1789; judicial review of legislative acts;
accepts compulsory ICJ jurisdiction, with reservations
Voting strength (1972 presidential election): Republican Party (Nixon),
45,767,000; Democratic Party (McGovern), 28,358,000; minor parties, 1,121,000
Communists: Party membership, 10,000-11,000 (est.); General Secretary, Gus Hall
Member of: ADB, ANZUS, CENTO, Colombo Plan, FAQ, GATT, IAEA, IBRD, ICAO, IDA,
IDB, IFC, ILO, IMCO, IMF, ITU, NATO, OAS, OECD, SEATO, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO','654e17c50298189c9383049cf63a04f0287c13a860f35e046d0ecc395b9c4cfb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

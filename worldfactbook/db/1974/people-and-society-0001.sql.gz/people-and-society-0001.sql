SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('646977c6fda3d6062e450bf53f4b6667cf16f9909d0019317908ff48a3a1952a',1974,'','','people-and-society',2,'Population: 43,767,000 (January 1979), average annual
growth’ rate 2.6% (current)
Nationality: noun—Turk(s); adiective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 16.4 million; 61% agriculture, 13% industry,
25% service; substantial shortage of skilled labor; ample
unskilled Jabor (1978)
Organized labor: 12% of labor force','22268bb44b86a205c3b4ea61403dc1dc6cd510e8f55b8a6eaab3eacf86bd965b','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2c0132c99c80ac98eed46ee3fab4973a6d99b1d480553bb4f7fa0901c06d830',1974,'','','people-and-society',2,'Population: 38,198,000, average annual growth rate 2.6%
(10/65-10/70)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force','49fded7edad1505d176731698caed4da46556420727747bae87bb3d1dba995fc','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d9664ee225df07a51fd7701cc26b0dce7b1630814d2c2e495d424e9ce8fa54f',1974,'','','people-and-society',2,'Population: 38,198,000, average annual growth rate 2.6%
(10/65-10/70)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force','49fded7edad1505d176731698caed4da46556420727747bae87bb3d1dba995fc','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed937167ac0d85c728d411c01cd666df976f4f27114ee601f7ad7cecaae42802',1974,'','','people-and-society',2,'Population: 18,504,000, average annual growth rate
2.3% (7/70-7/71)
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9% Uzbeks,
9% Hazaras, minor ethnic groups include Chahar,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11%
Turkic languages (primarily Uzbeki and Turkmeni), 10% 30 minor languages
(primarily Baluchi and Pashai); much bilingualism
Literacy: under 10%
Labor force: about 4.3 million (official est.); 75%-80% agriculture and animal
husbandry, 20%-25% commerce, small industry, services; massive shortage of
skilled labor
Organized labor: none
11,100 sq. mi.; 19% arable, 24% other agricultural, 43%
forested, 14% other
Land boundaries: 445 mi.
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 225 mi. (including Sazan Island)
Population: 2,334,000, average annual growth rate 2.8%
(current)
Ethnic divisions: 96% Albanian, remaining 4% are Greeks,
Viachs, Gypsies, and Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10% Roman Catholic (observances
prohibited; Albania claims to be the world''s first atheist state)
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics available, but probably
greatly improved
Labor force: 911,000 (1969); 60.5% agriculture, 17.9% industry, 21.6% other
nonagricul tural
Population: 15,994,000, average annual growth rate 3.1%
(7/68-7/72)
Ethnic divisions: 99% Arab-Berbers, less than 1% Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 2.8 million; 47% agriculture, 8% industry, 24% other (military,
police, civil service, transportation workers, teachers, merchants,
construction workers); 40% of urban Tabor unemployed
Organized labor: 17% of labor force claimed; General Union of Algerian
Workers (UGTA) is the only labor organization and is subordinate to the
National Liberation Front
Population: 19,000 (official estimate for 1 July 1969)
Ethnic divisions: Catalan stock; 30% Andorrans, 61%
Spanish, 6% French, 3% other tere
Religion: virtually all Roman Catholic ALGERIA
Language: Catalan, many also speak some French and
Castilian
Labor force: unorganized; largely shepherds and farmers
Population: 5,955,000, average annual growth rate 1.6%
(12/60-12/70)
Ethnic divisions: 93.6% African, 5% Europeans, 1.4% mulatto (1960)
Religion: about 84% animist, 12% Roman Catholic, 4% Protestant
Language: Portuguese (official), many native dialects
Literacy: 10%-15%
Labor force: 2.6 million economically active (1964); 531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)
Population: 77,000, average annual growth rate 2.6%
(4/60-4/70)
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other Protestant sects and some
Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000','902a138c6cf16deeecd5b71337251f11493f387f9e1a9df2e44c85cd2ce5ddd5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b51cca4d1356d680a815768c9a0d4257035aa6a5b0b3502bbf9fd59b6ca91e33',1974,'BR','Brazil','people-and-society',9,'Population: 24,471,000, average annual growth rate 1.5%
(7/70-7/72)
Ethnic divisions: approximately 85% white, 15% mestizo, Indian, or other
nonwhite groups
Religion: 90% nominally Roman Catholic (less.than 20% practicing), 2% Protestant,
2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 9.5 million; 19% agriculture, 25% manufacturing, 20% services,
11% commerce, 6% transport and communications, 19% other
Organized labor: 25% of labor force (est.)
Population: 7,482,000, average annual growth rate 0.1%
(1/72-1/73)
Ethnic divisions: 98.1% German, 0.7% Croatian, 0.3% Slovene,
0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8% none or
other
Language: German
Literacy: 98%
Labor force: 2,614,600 (1972); 18% agriculture and forestry, 49% industry and
crafts, 18% trade and communications, 7% professions, 6% public service,
2% other; 2.4% registered unemployed; an estimated 200,000 Austrians are
employed in other European countries; foreign laborers in Austria number
more than 200,000 (1972); unemployment 2.1% (1972)
Organized labor: about 2/3 of wage and salary workers (1971)
Population: 192,000, average annual growth rate 2.5%
(4/70-7/72)
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: mainly Church of England; some Protestant, Greek Orthodox, and
Roman Catholic
Language: English
Labor force: 60,000 (1963); 25% organized
Population: 234,000, average annual growth rate 2.8%
(2/65-4/71)
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani, and »
Indian, 3% other
Religion: Muslim
Language: Arabic
Literacy: about 30% (1965)
Labor force: 53,274 (1965)
GOV ERNMENT :
Legal name: State of Bahrain
Type: traditional monarchy; independence declared in 1971
Capital: Al Manamah
Legal system: based on Islamic law and English common law; constitution will take
effect December 1973
Government leader: Emir ‘Isa ibn Salman Al-Khalifah
Suffrage: granted to all native-born or naturalized males 20 and over
Elections: elections for new national assembly will be held December 1973
Political parties and pressure groups: political parties prohibited; no significant
pressure groups although numerous small clandestine groups are active
Communists: few known
Member of: Arab League, U.N.
Population: 64,794,000*, average annual growth rate 1.9%
(7/69-7/70)
Ethnic divisions: predominantly Bengali; fewer than 1
million "Biharis" and fewer than 1 million tribals
Religion: about 83% Muslim, 16% Hindu; less than 1% Buddhist and other
Language: Bengali
Literacy: about 20%
Labor force: about 25 million; majority are unemployed or part-time employees;
over 80% of labor force is in agriculture
Population: 241,000 (official estimate for 1 January 1973) DS
Ethnic divisions: 80% African, 15% mixed, 5% European
Religion: Anglican, Roman Catholic, Methodist, and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1973 est.) wage and salary earners
Organized labor: 32%
Population: 9,640,000, average annual growth rate 1.7%
(current)
Ethnic divisions: 85%-90% chileno (mixture of European and Indian stock),
3% Indian, 7% European, Asiatic, and other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 89%
Labor force: 3.3 million (1973); 19% agricultural, 28% industry and construction,
29% services, 14% commerce, 5% mining, 5% other (1973)
Organized labor: 25% of labor force (1973)
Population: 909,215,000, average annual growth rate 2.4% (current)
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur, Hui, Yi, Tibetan, Miao,
Manchu, Mongol, Pu-I, Korean, and numerous lesser nationalities
Religion: most people, even before 1949, have been pragmatic and eclectic,
not seriously religious; most important elements of religion are Confucian-
ism, Taoism, Buddhism, ancestor worship; about 2%-3% Muslim, 1% Christian
Language: Chinese (Mandarin mainly; also Cantonese, Wu, Fukienese, Amoy, Hsiang,
Kan, Hakka dialects), and minority languages (see ethnic divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85% agriculture, 15% other; shortage of
skilled labor (managerial, technical, mechanics, etc.); surplus of unskilled
labor
Population: 15,589,000 (excluding the population of
Quemoy and Matsu Islands and foreigners), average
annual growth rate 2% (1/72-1/73)
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese, 2% aborigines
Religion: 93% mixture of Buddhism, Confucianism, and Taoism; 4.5% Christian;
2.5% other
Language: Chinese, Japanese, English
Literacy: about 90%
Labor force: 4.9 million; 33% primary industry (agriculture), 32.1% secondary
industry (including manufacturing, mining, construction), 34.9% tertiary
industry (including commerce and services) 1972
Organized labor: about 12% of 1972 labor force (government controlled)
Population: 24,403,000, average annual growth rate 3.2%
(current)
Ethnic divisions: 58% mestizo, 20% caucasian, 14% mulatto, 4% Negro, 3% mixed
Negro-Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture, 13% manufacturing, 18% services,
9% commerce, 13% other (1964)
Organized labor: 13% of labor force (1968)
Population: 296,000, average annual growth rate 2.7%
(9/66-9/70)
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor Force: mainly agricultural
Organized labor: information not available
Population: 1,001,000, average annual growth rate 2%
(current)
Ethnic divisions: about 15 ethnic groups divided into some 75 tribes, almost all
Bantu; most important ethnic groups are Kongo (48%) in south, Teke (17%) in
center, M''Bochi (12%) and Sangha (20%) in north; about 8,500 Europeans,
mostly French
Religion: about half animist, half nominally Christian, less than 1% Muslim
Language: French official, many African languages with Lingala and Kikongo
most widely used
Literacy: about 20%
Labor force: about 40% of population economically active, most engaged in
subsistence agriculture; 79,100 wage earners; 40,000-60,000 unemployed
Organized labor: 16% of total labor force (1965 est.)
Population: 21,000, official estimate for 1 July 1972
Ethnic divisions: 81.3% Polynesian (full blood), 7.7%
Polynesian and European, 7.7% Polynesian and other,
2.4% European, 0.9% other
Religion: Christian, majority of populace members of
Cook Islands Christian Church
Population: 1,927,000, average annual growth rate 3%
(7/70-7/72)
Ethnic divisions: 98% white (including mestizo), 2% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 85%
Labor force: 530,000 (1970); 46.3% agriculture; 13.2% manufacturing; 11% commerce;
8% construction, transportation, and communications; 21.5% other; shortage
of skilled labor (1968)
Organized labor: about 6% of labor force
Population: 9,000,000, average annual growth rate 1.7%
(current)
Ethnic divisions: 51% mulatto, 37% white, 11% Negro,
1% Chinese
Religion: at least 85% nominally Roman Catholic before Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.36 million; 34% agriculture, 17% industry, 6% construction, 6%
transportation, 29% services, 8% unemployed and underemployed
Organized labor: 46% of total force
Population: 660,000, average annual growth rate 1.4%
(1/71-1/73)
Ethnic divisions: 78% Greek; 18% Turkish; 4% British,
Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Armenian Orthodox and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Labor force: 267,000 (1970 est.), 38% agriculture, 23% industry, 9% commerce ;
2% mining, 28% other; 3,130 registered unemployed (December 1968)
Organized labor: 24% of labor force
Population: 14,608,000, average annual growth rate 0.6%
(current)
Ethnic divisions: 65.0% Czechs, 29.2% Slovaks, 4.0% Magyars,
0.6% Germans, 0.5% Poles, 0.4% Ukrainians, 0.3% others
(Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant, 2% Orthodox,
1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.1 million; 18% agriculture, 37% industry, 11% services, 34%
construction, communications and others
Population: 75,000, average annual growth rate 1.6%
(4/60-4/70)
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist
Language: English; French patois
Literacy: about 80%
Labor force: est. at 23,000 in 1960; about 50% in agriculture
Organized labor: 25% of the labor force
Population: 4,497,000, average annual growth rate 2.9%
(7/69-7/71)
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 35% to 40% of adult population
Labor force: 1.3 million; 73% agriculture, 8% industry, 19% services and other
Organized labor: 12% of Jabor force
Population: 6,839,000 (excluding nomadic Indian tribes),
average annual growth rate 3.4% (7/71-7/72)
Ethnic divisions: 40% mestizo, 40% Indian, 10% white, 5% Negro, 5% Oriental and
other
Religion: 95% Roman Catholic (majority nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture, 13% manufacturing, 4%
construction, 7% commerce, 4% public administration, 16% other services and
activities
Organized labor: less than 15% of labor force
Population: 36,018,000, average annual growth rate 2.2% (7/71-7/72)
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek, Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt and other
Language: Arabic official, English and French widely understood by educated
classes
Literacy: around 40%
Labor force: 8 to 12 million; 45% to 50% agriculture, 10% industry, 10% trade
and finance, 30% services and other; serious shortage of skilled labor
Organized labor: 1 to 3 million
Population: 3,867,000, average annual growth rate 3.5%
(5/61-6/71)
Ethnic divisions: 84%-88% mestizo; Indian and white minorities, 6%-8% each
Religion: predominantly Roman Catholic, probably 97%-98%
Language: Spanish
Literacy: 50% of population 10 years of age and over (1973 est.)
Labor force: 1,395,000 (est. 1973); 57% agriculture, 14% services, 14%
manufacturing, 6% commerce, 9% other; shortage of skilled labor and large
pool of unskilled labor, but manpower training programs improving situation
shy weg 3.5% of total labor force; 6.6% of nonagricultural labor force
1972 est.
Population: 310,000, average annual growth rate 1.8%
(7/68-7/69); Rio Muni, 220,000, average annual growth
rate 1.5% (7/68-7/69); Fernando Po, 90,000, average
annual growth rate 2.6% (7/68-7/69)
Ethnic divisions: indigenous population of Province Francisco Macias Nguema
primarily Bubi, some Fernandinos; of Rio Muni primarily Fang; some 300-400
Nigerians, mostly on Fernando Po; less than 1,000 Europeans, primarily Spanish
Religion: natives all nominally Christian and predominantly Roman Catholic; some
pagan practices retained
Language: Spanish official language of government and business; also pidgin
English, Fang
Literacy: 12% (est.)
Labor force: most Equatorial Guineans involved in subsistence agriculture
Population: 26,866,000, average annual growth rate 2.5%
(1/70-1/71)
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%, Sidamo 9%, Shankella 6%,
Somali 6%, Afar 4%, Gurage 2%, other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Muslims, 15%-20% animist, 5% other
Language: Amharic official; many local languages and dialects; English major
foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10% government, military,
and quasi-government
Organized labor: 60,000 registered labor union members
Population: 40,000, average annual growth rate 0.9%
(4/66-11/70)
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faeroese (derived from Old Norse), Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufacturing, transportation,
and commerce
Population: 2,000 (official est. for 1 July 1971)
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); over 95% (est.) in agriculture, mostly sheepherding
Population: 556,000, average annual growth rate 1.9%
(7/71-7/72)
Ethnic divisions: 42% Fijian, 50% Indian, 8% European,
Chinese and others
Religion: Fijians mainly Christian, Indians are Hindu with a Muslim minority
Language: English and Fijian (official), Hindustani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no breakdown on remainder
Organized labor: about 50% of labor force organized into 22 unions; unions
organized along lines of work, breakdown by ethnic origin causes further
fragmentation
Population: 4,654,000, average annual growth rate 0.4%
(1/72-1/73)
Ethnic divisions: homogeneous white population, smal]
Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox, 1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and Russian-speaking minorities
Literacy: 99%
Labor force: 2.3 million; 28.1% agriculture, forestry, and fishing, 24.2% mining
and manufacturing, 9.0% construction, 13.7% commerce, 6.6% transportation and
communications, 16.5% services; 2.8% unemployed
Organized labor: 60% of labor force
Population: 54,000, average annual growth rate 2.9%
(7/68-7/70)
Ethnic divisions: 95% Negro or mulatto, 5% caucasian, 10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%, construction 21%, agricul ture
18%, industry 8%, transportation 4%; information on unemployment unavailable
Organized labor: 7% of labor force
Population: 125,000 (official estimate for 1 July 1967)
Ethnic divisions: 59,350 Somalis (large number of the
Somalis are temporary immigrants from Somalia -- not
citizens of territory), 53,650 Afars, 6,000 Arabs, 7,000 French (inclusive
of French military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at port
Organized labor: some 3,000 railway workers organized
Population: 530,000, average annual growth rate 1.7%
(7/66-7/70)
Ethnic divisions: about 40 Bantu tribes, including 4
major tribal groupings (Fang, Eshira, Mbede, Okande); about 21,000 expatriate
Africans and Europeans, including 14,000 French
Religion: 55% to 75% Christian, less than 1% Muslim, remainder animist
Language: French official language and medium of instruction in schools; Fang
is a major vernacular language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are wage earners in the modern sector
Organized labor: less than 30% of wage labor force
Population: 396,000, average annual growth rate 2.2%
(7/66-7/%1)
Ethnic divisions: over 99% Africans (Malinke 40.8%, Fulani 13.5%, Wolof 12.9%,
remainder, made up of several smaller groups), fewer than 1% Europeans and
Lebanese» é
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Malinke and Wolof most widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in subsistence farming; about
15,000 are wage earners (government, trade, services)
Organized labor: 25% to 30% of wage labor force at most
Population: 16,981,000 (including East Berlin), average
annual growth rate -0.2% (current)
Ethnic divisions: 99.7% German, .3% Slavic and other
Religion: 53% Protestant, 8% Roman Catholic, 39% unaffiliated or other; less than
5% of Protestants and about 25% of Roman Catholics actively participate
Language: German, small Sorb (West Slavic) minority
Literacy: 99%
Labor force: 8.2 million; 34.1% industry; 4.7% handicrafts; 6.8% construction;
11.9% agriculture; 6.8% transport and communications; 10.1% commerce; 16.8%
services; 2.5% other
Organized labor: 87.7% of total labor force
Population: 9,450,000, average annual growth rate 2.6%
(7/71-7/72)
Ethnic divisions: 99.8% Negroid African (major tribes Ashanti, Fante, Ewe),
0.2% European and other
Religion: 45% animists, 43% Christian, 12% Muslim
Language: English official; African languages include Akan 44%, Mole-Dagbani 16%,
Ewe 13%, and Ga-Adangbe 8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing, 16.8% industry, 15.2%
sales and clerical, 4.1% services, transportation, and communications,
2.9% professional; 400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor force
Population: 60,000, average annual growth rate 1.9%
(7/63-7/70)
Ethnic divisions: 83.9% Micronesian, 13.9% Polynesian,
0.9% European, 0.1% Chinese, 1.2% mixed and other races
Religion: mainly Christian; 55% Protestants, 42% Catholics
Literacy: less than 50%
Population: 27,000 (official estimate for 1 July 1971
Ethnic divisions: mostly Italian, English, Maltese,
Portuguese and Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages; Italian, Portuguese, and
Russian also spoken; English used in the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian laborers
Organized labor: over 6,000
) MOROCCO ALGERIA
Population: 8,969,000, average annual growth rate 0.4%
(3/61-3/71)
Ethnic divisions: 96% Greek, 2% Turkish, 1% Albanian, 1% other
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total about 82%
Labor force: 3,866,000 (1969 est.); 50% agriculture, 15% industry, 9% trade,
26% other; unemployment and underemployment, 20% total in all fields;
shortage of skilled labor in nonagricultural sectors aggravated by large-
scale emigration
Organized labor: 10% of labor force
Population: 51,000, average annual growth rate 3.3%
(1/66-1/71)
Ethnic divisions: 86% Greenlander (Eskimos and Greenland-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep breeding
Population: 97,000, average annual growth rate 0.6%
(4/60-4/70)
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects; Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 27,314 (1960); 40% agriculture, 30% unemployed or underemployed
Organized labor: 33% of labor force
Population: 2,861,000, average annual growth rate 1.2%
(7/71-7/72)
Ethnic divisions: 80% white, 20% mixed (with Indian and
Negro elements)
Religion: predominantly Roman Catholic
Language: Spanish, English
Literacy: 88%
Labor force: 827,000; 9% agriculture, 17% manufacturing, 17% commerce, 14%
government services, 32% other, 11% unemployed
Organized labor: 45% of labor force
Population: 482,000, average annual growth rate 2.2%
(7/69-7/72)
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal unemployment
Population: 5,976,000, average annual growth rate 3.4%
(1/72-1/73)
Ethnic divisions: 96% African, 3% European, less than
1% Coloreds and Asians
Religion: 51% syncretic (part Christian, part animist),
24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and Sindebele also widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including some migrants from Zambia and
Malawi), 108,000 Europeans, Asians, and coloreds (people of mixed heritage) ;
35% agriculture, 25% mining, manufacturing, construction, 40% transport and
services
Organized labor: about one-third of European wage earners are unionized, but
only a small minority of Africans (1966)
Population: 4,071,000, average annual growth rate 2.9%
(7/71-7/72)
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa (Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French official; Kiswahili
language of African commerce, Kinyarwanda language
of interior and used in National Assembly
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy
Population: 107,000, average annual growth rate 1.6%
(4/60-4/70)
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 38,000 (1969); 50% agriculture
Organized labor: 20% of labor force
Population: 2,009,000, average annual growth rate 1.2%
(7/71-7/72)
Ethnic divisions: 85%-90% white, 5% Negro, 5%-10% mestizo
Religion: 66% Roman Catholic (less than half adult population attends church
regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed in important sectors --
25% government; 34% industry; 10% service; 13% other; 8% agriculture, forestry;
fishing and mining; no shortage of skilled labor
Organized labor: about 25% of labor force (largely Communist influenced)
Population: 1,000 (official estimate for 1 July 1964)
Ethnic divisions: primarily Italians but also many
other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees divided
into 3 categories -- executives, officeworkers,
and salaried employees
Organized labor: none
Population: 11,530,000 (excluding Indian jungle population
estimated at 32,000 in 1961), average annual growth
rate 3.4% (11/71-7/72)
Ethnic divisions: 67% mestizo, 21% white, 10% Negro, 2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 74% (claimed, 1970 est.)
Labor force: 3 million (1969); 24% agriculture, 6% construction, 17% manufacturing,
6% transportation, 18% commerce, 25% services, 4% petroleum, utilities, and
other
Organized labor: 45% of labor force
Population: 19,988,000, average annual growth rate 1.4%
(current)
Ethnic divisions: 85%-90% predominantly Vietnamese; ethnic
minorities include Muong, Thai, Meo, and Man
Religion: Confucianism, Buddhism, Taoism, Catholicism
Language: closely corresponds to the breakdown of ethnic groups
Literacy: claimed to be 95% (1964)
Labor force: (1 January 1970) 9.6 million, not including military; about 70%
agriculture and 10% industry
Population: 20,058,000, average annual growth rate 2.6%
(7/70-7/71)
Ethnic divisions: 87.7% Vietnamese, 6% Chinese, 3.2% mountain tribesmen, 2.9%
Khmer, 2% Cham
Religion: 70% Buddhist (at least 5% Hoa Hao), 5% Cao Dai, and 10% Catholic; others |
include animist, and small numbers of Protestant, Muslim and Hindu; most
Buddhists are of Mahayana school or practice combination of Buddhism, Taoism,
and Confucianism
Language: Vietnamese, French, Chinese, English, Khmer, tribal languages
Pencthiee and Malayo-Polynesian), Cham (Malayo-Polynesian dialect)
Labor force: civilian work force 5.8 million (not including armed forces);
67% agriculture, fishing, and forestry; 17% industry and commerce; 3%
domestic and personal services; 1% employed by U.S.; 5% government; 7%
unemp]oyed
Organized labor: unknown
Population: 9,000, official estimate for 1 July 1970
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic
Population: 152,000, average annual growth rate 1.8%
(11/66-11/71)
Ethnic divisions: Polynesians, about 12,000 Euronesians (persons of European
and Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of population associated with the London
Missionary Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all children from 7-15 years)
Labor force: agriculture 19,148; mining and manufacturing 1,716 (1961)
Organized labor: unorganized
Populat','c88337ea9acb17f940a679577d319f3251ec511011d3aa7370b88266e689fe10','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51a7b8f66f5e13ddfb5c00faa4a10c60e34d271fd58c74ad851295c7ba2e6150',1974,'BR','Brazil','people-and-society',10,'ion: 1,576,000*, average annual growth rate 2.7%
(current)
Ethnic divisions: almost all Arabs; a few Indians, Somalis, and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 6,296,000, average annual growth rate 2.6%
(7/71-7/72)
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.
Labor force: almost entirely agriculture and herding','af350e56ff83ac702940d18cb33e0928356b67de66b9e100d7dc7225d37ffb3c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a05c2d8ee2ab416a588138d452c8672fd22f33535699be5a6f875942144c60d8',1974,'DZ','Algeria','people-and-society',19,'Population: 9,753,000, average annual growth rate 0.3%
(current)
Ethnic divisions: 55% Flemings, 33% Walloons, 12% mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch); divided along ethnic lines
Literacy: 97%
Labor force: 4.0 million; approximately 95% is found in the following sectors:
32% manufacturing, 24% services, 16% commerce, banking, and insurance, 8%
construction, 7% transportation and communication, 5% agriculture, forestry,
and fishing, 1.5% mining, .8% public utilities and sanitary services; 3.1%
unemployed (1971)
Organized labor: 48% of labor force (1969)
Population: 490,000, average annual growth rate 0.2%
(7/68-7/69)
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes); less than 1% European
and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese official, numerous African languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in subsistence agriculture','388adcf9c89b1fcc8cefb80b3518d644f06c72b78d1e506c9edb2dbcdacc0e4b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f30816f94737daa997abb2e79f522391865e3e0ab8be403fd5722fa754e596e',1974,'PE','Peru','people-and-society',22,'Population: 133,000, average annual growth rate 2.9%
(4/60-4/70)
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican, Seventh-day Adventist, Methodist,
Baptist, Jehovah''s Witnesses, Mennonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 34,500; 39% agriculture, 14% manufacturing, 8% commerce, 12%
construction and transport, 20% services, 7% other; shortage of skilled
labor and all types of technical personnel; over 15% are unemp] oyed
Organized labor: 8% of labor force
Population: 56,000, average annual growth rate 2.1%
(10/60-10/70)
Ethnic divisions: approximately 63% African, 37% white
Religion: 47.5% Church of England, 10.2% Catholic, 38.2% other Protestant, 4.2%
other
Language: English
Literacy: virtually 100%
Labor force: 24,700 (1970)
Population: 904,000, average annual growth rate 2.3%
(current)
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese,
15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25% Buddhist-influenced
Hinduism
Language: Bhotias speak various Tibetan dialects, most
widely spoken dialect is Druk-ke, the official language; Nepalese speak
various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry; massive lack of skilled
labor
Population: 5,076,000, average annual growth rate 2.5%
(current
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic; active protestant
minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.5 million (1972); 69.1% agriculture, 3.3% mining, 9.6% services
and utilities, 8% manufacturing, 10% other
Organized labor: 150-200,000, concentrated in mining, industry, construction,
and transportation
Population: 654,000, average annual growth rate 2.4%
(current)
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% European
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 32% in Tswana;
less than 1% secondary school graduates
Labor force: 385,000; most are engaged in cattle raising and subsistence
agriculture; about 51,000 in internal cash economy, another 60,000 spend
at least 6 to 9 months per year as wage earners in South Africa (1971)
Organized labor: eight trade unions organized with a total membership of
approximately 9,000 (1972 est.)
Population: 103,173,000, average annual growth rate 2.9%
(7/71-7/72)
Ethnic divisions: 60% white, 30% mixed, 8% Negro, and 2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: 67% of the population 15 years or older (1970)
Labor force: about 30 million in 1970 (est.); 44.2% agriculture, livestock,
forestry, and fishing, 17.8% industry, 15.3% services, transportation, and
communication, 8.9% commerce, 4.8% social activities, 3.9% public administra-
tion, 5.1% other
Organized labor: about 50% of labor force; only about 1.5 million pay dues
Population: 177,000, average annual growth rate 2.5%
(7/66-7/71)
Ethnic divisions: 93.0% Melanesians, 4.0% Polynesians,
1.5% Micronesians, 0.3% Chinese, 0.8% Europeans,
0.4% others
Religion: almost all at least nominally Christian; Roman Catholic, Anglican, and
Methodist churches dominant
Literacy: 60%
Population: 151,000, average annual growth rate 4.5%
(8/60-8/71)
Ethnic divisions: 52% Malays, 28% Chinese, 15% indigenous
tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8% Christian; 32% other (Buddhist
and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture, 32.8% industry, manufacturing, and
construction, 33.8% trade, transport, services, 2.9% other
Organized labor: 8.4% of labor force
Population: 29,809,000, average annual growth rate 2.2%
(7/69-7/70)
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2% Kachin,
2% Chin, 2% Chinese, 3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their own languages
Literacy: 60% (official claim)
Labor force: 10 million; 67% agriculture, 13% industry, 20% services, commerce,
and transportation
Organized labor: no figure available; old labor organizations have been
disbanded, and government is forming one central labor organization
Population: 3,799,000, average annual growth rate 2%
(7/70-7/71)
Ethnic divisions: Africans -- 86% Hutu (Bantu), 13% Tutsi
(Hamitic), 1% Twa (Pigmy); non-Africans include (late EE oe
1968) 3,000 Europeans, 1,000 Asians ay yey
Religion: over 60% Christian (50% Catholic, 10% Protestant) ;
rest mostly animist plus small number of Muslims
Language: Kirundi and French official
Literacy: about 55% in Kirundi, 10% in Swahili, or 6% in French
Labor force: 1,865,471 (1970 est.)
Organized labor: sole group is the Union of Burundi Workers (UTB), membership
about 30,000, affiliated with government party
Population: 6,200,000, average annual growth rate 1.7%
(7/69-7/70)
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroon Highlanders, 19% Equatorial Bantu, 8% Northwestern
Bantu, 10% Fulani, 7% Eastern Nigritic, 11% Kirdi, 13% other African, less
than 1% non-African
Religion: about one-half animist, one-third Christian; rest Muslim
Language: English and French official, 24 major African language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence agriculture and herding;
200,000 wage earners (maximum) including 22,000 government employees, 63,000
paid agricultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force
Population: 1,729,000, average annual growth rate 2.2%
(7/67-7/71)
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and linguistic
characteristics; Banda (32%) and Baya-Mandjia (29%) are
largest single groups; 6,500 Europeans, of whom 6,000
are French and majority of the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 27% animist, 5% Muslim; animistic
beliefs and practices strongly influence the Christian majority
Language: French official; Sangho, the lingua franca and unofficial national
language
Literacy: estimated at 5%-10%
Labor force: about half the population economically active, 80% of whom are in
agriculture; approximately 64,000 salaried workers
Organized labor: 1% of labor force
Population: 3,908,000, average annual growth rate 2%
(7/71-7/72)
Ethnic divisions: over 240 tribes representing 12 major
ethnic groups -- Muslims (Arabs, Toubou, Fulani,
Kotoko, Hausa, Kanembou, Baguirmi, Boulala, and
Wadai) in the north and center and non-Muslims (Sara,
Mayo~Kebbi, and Chari) in the south; some 150,000
nonindigenous, 5,000 of them French
Religion: about half Muslim, 5% Christian, remainder animist
Language: French official; Chadian Arabic is lingua franca in north, Sara and
Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically active group, of which 90%
are engaged in unpaid subsistence farming, herding, and fishing; 47,000
wage earners in industry and civil service
Organized labor: about 20% of wage labor force','149857ae1f073f91a9240d95a9bed970e88263121739835761399c1e8bd630b6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22cc617ad05dadd6450ec6be2d3382cf12ff4c356a0f6d3132193243fe1c1185',1974,'LY','Libya','people-and-society',26,'Saunt:
EGYPRUARABIA “Sch,
Population: 2,980,000, average annual growth rate 2.7%
(8/68-8/72)
Ethnic divisions: 99% Africans (42 ethnic groups, most important being Fon, Adja,
Yoruba, Bariba}, 5,500 Europeans
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most common vernaculars in south,
at least 6 major tribal languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture; 15% civil service,
artisans, and industry
Organized labor: approximately 75% of wage earners, divided among two major
and several minor unions
Population: 5,032,000, average annual growth rate 0.4%
(current
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant and Roman Catholic, 1%
other
Language: Danish; small German-speaking minority
Literacy: 99%
Labor force: 2.4 million; 14.5% agriculture, forestry, fishing, 29.4% mining and
manufacturing, 8.1% construction, 15.0% commerce, 6.6% transportation and
communications, 23.6% services, 0.2% other; 3.7% unemployed
Organized labor: 65% of labor force
Population: 21,069,000, average annual growth rate 1%
(current)
Ethnic divisions: 39% Serb, 22.1% Croat, 9.2% Slovene, 5.8% Macedonian, 2.5%
Montenegrin, 6.4% Albanian, 3% Hungarian, 9% other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic, 12% Muslim, 3% other, 12%
none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Albanian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 13.5 million (1970); 49.6% agriculture, 16% mining and manufacturing,
34.4% other nonagricultural activities; reported unemployment averaged 8% of
registered labor force (social sector) in 1967
Population: 23,882,000, average annual growth rate 3%
(7/70-7/72)
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes ~~ Mongo, Luba, Kongo (all Bantu),
and the Mangbetu-Azande (Hamitic) make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo, and Chiluba are all
classified as official languages
Literacy: 5% fluent in French, about 35% have an acquaintance with French
Labor force: about 8 million, but only about 13% in wage structure
Population: 4,682,000, average annual growth rate 2.4%
(6/63-8/69)
Ethnic divisions: 98.7% African, 1.1% European, .2% other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000 Africans, 27,000 non-Africans;
15% mining, 9% agriculture, 9% domestic service, 19% construction, 9% commerce,
10% manufacturing, 23% government and miscellaneous services, 6% transport
Organized labor: 100,000 wage earners, primarily in industrial sector, are
unionized (early 1968)','0041472787487627a703b544cbffc1522f7ee24868f5b686284f0dc2a7fb0cdf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09e640b39b8530b6dfec7da4551ebe6d066263d6106526e7e45e30384d0d4664',1974,'CO','Colombia','people-and-society',37,'Population: 4,174,000, average annual growth rate 2.6%
(7/66-7/67)
Ethnic divisions: 99% African (3 major tribes - Fulani,
Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less than 1%
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written language
Labor force: 1.8 million, of whom less than 10% are wage earners; most of
population engages in subsistence agriculture
Organized labor: virtually 100% of wage labor force loosely affiliated with the
National Confederation of Guinean Workers, which is closely tied to the PDG
Population: 782,000, average annual growth rate 2.5%
(4/60-4/70)
Ethnic divisions: 51% East Indians, 43% Negro and Negro
mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1% other
Language: English
Literacy: 86%
Labor force: 201,000; about 25% agriculture, 14% manufacturing, 16% services,
11% commerce, 3% mining and quarrying, 10% other; 21% unemployed
Organized labor: 34% of labor force
Population: 4,903,000, average annual growth rate 2.1%
(current)
Ethnic divisions: over 90% Negro, nearly 10% mulatto,
few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of which an overwhelming
majority also practice Voodoo)
Language: French (official) spoken by only 10% of population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.6 million (est. January 1968); 86% agriculture, 12% industry,
2% unemployed; shortage of skilled labor; unskilled labor abundant
Organized labor: less than 1% of labor force
Population: 2,798,000, average annual growth rate 2.7%
(7/68-7/72)
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 57.4% of persons 10 years of age and over (est. 1970)
Labor force: approx. 900,000 (est. mid-1972); 66% agriculture, 12% services, 8%
manufacturing, 5% commerce, 6% unemployed, 3% unspecified
Organized Tabor: 7% to 10% of labor force (mid-1972)
Population: 4,186,000, average annual growth rate 1.8%
(7/68-7/72)
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local religions
Language: Chinese, English
Literacy: 75%
Labor force (1971 est.): 1.58 million; 43% manufacturing, 20% services, 11%
construction, mining, quarrying and utilities, 13% commerce, 4% agriculture,
forestry, fisheries, and hunting, 7% communications, 2% other; under-
employment is a serious problem
Organized labor: 12% of 1969 labor force
Population: 10,444,000, average annual growth rate 0.3% Sac ae
(current) - 7
Ethnic divisions: 93.3% Magyar, 2.5% German, 2.4% Gypsy, avs) Bashy RAN
0.7% Jews, 1.1% other ve ee |
Religion: 67.5% Roman Catholic, 20.0% Calvinist, 5.0%
Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5.0 million (1 January 1971); 26% agriculture, 44% industry and
building, 30% other nonagricul tural
Population: 1,164,000, average annual growth rate 1.1%
(7/66-7/70)
Ethnic divisions: 70% Moor, 30% Negro
Religion: nearly 100% Muslim
Language: French and Arabic official
Literacy: under 5%
Labor force: about 18,000 wage earners (1973); remainder of population in
farming and herding
Organized labor: 18,000 union members claimed by single union, Mauritanian
Workers’ Union
Population: 881,000, average annual growth rate 1.4%
(1/71-1/72)
Ethnic divisions: Indians 67%, Creoles 29%, Chinese 3.5%, English and French 0.5%
Religion: 51% Hindu, 33% Christian (mostly Catholic with a few Anglican
Protestants), 16% Muslim
Language: English official language; Hindi, Chinese, French Creole
Literacy: estimated 60% for those over 21, and 90% for those of school age
Labor force: 175,000; 50% agriculture, 6% industry; 20% government services;
14% are unemployed, under-employed, or self-employed, 10% other
Organized labor: about 35% of labor force
Population: 24,000 (official estimate for 1 July 1972)
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
Literacy: almost complete
Labor force: not available
Organized labor: not available
Population: 1,379,000, average annual growth rate 3%
(current)
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese, 2% a Sulavinge, AUSTRALIA
Russian, 2% other
Religion: predominantly Tibetan Buddhist, about 4% Muslim,
limited religious activity because of Communist regime
Languages: Khalkha Mongol used by over 90% of population; minor languages
include Turkic, Russian, and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the population is in the labor
force, including a large percentage of Mongol#an; women; acute shortage of
both skilled and unskilled labor (ss reliable information available)
Population: 16,498,000, average annual growth rate 2.9%
(current)
Ethnic divisions: 99.1% Arab-Berber, .2% Jewish, .7% non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2% Jewish
Language: Arabic (official); several Berber dialects; French is language of much
business, government, diplomacy, and postprimary education
Literacy: 20%
Labor force: almost 5.9 million (1970 est.) 69% agriculture, military, police,
civil service, transportation, mines, teachers, merchants, construction
workers, 10% industry and mining, 10% commerce and government
Organized labor: about 5% of the labor force, mainly in the Union of Moroccan
Workers (UMT)
Population: 8,792,000, average annual growth rate 2.2%
(9/60-12/70)
Ethnic divisions: 97% African, 3% European, Asian, and Mulatto
Religion: 65.6% animist, 21.5% Christian, 10.5% Muslim, 2.4% other
Language: Portuguese (official); many tribal dialects
Literacy: 7%-10% (est.)
Labor force: {1963 est.) 610,000; 50,000 non-African wage earners, 560,000
African wage earners in Mozambique; 290,000 additional African wage earners
temporarily working in Rhodesia and South Africa; unemployment serious
problem; most native Africans provide unskilled labor or remain in
subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970); 75% are white
Population: 234,000, average annual growth rate 1.6% BRAZIL
(1/71-1/73)
Ethnic divisions: 85% largely mixed Negro stock except on
Aruba where 12% Negro and approx. 55% mixed Carib
Indian and European; rest European with some Chinese,
especially on Aruba
Religion: predominantly Roman Catholic; sizable Protestant, smaller Jewish
minorities
Language: officially Dutch; predominantly English; colloquial "“oapiamento,''" a
Spanish-Portuguese-Dutch-English mixture
Literacy: 75%-80%
Labor force: 66,000; 1% agriculture, 21% industry, 21% unemployed, 8%
construction, 41% government and services, 8% other
Organized labor: approx. 15% of labor force
Population: 114,000, average annual growth rate 2.6%
(5/63-3/69)
Ethnic divisions: Melanesian-Polynesian admixture, over
28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese laborers were imported for
plantations and mines in pre-World War II period; immigrant labor now
coming from Wallis Islands, New Hebrides, and French Polynesia
Organized labor: unorganized
Population: 89,000, average annual growth rate 2.3%
(7/66-7/71)
Ethnic divisions: 92% indigenous Melanesian, 3% European,
remainder Vietnamese, Chinese, and various Pacific
Islanders
Religion: most at least nominally Christian
Literacy: probably 10%-20%
Population: 2,088,000, average annual growth rate 3.3%
(4/71-7/72)
Ethnic divisions: 75% mestizo, 15% white, 10% Negro, Indian or mulatto
Religion: 95% Roman Catholic
Language: Spanish (official); smal] English-speaking minority on Atlantic coast
Literacy: 50% of population 10 years of age and over
Labor force: 650,000 (est. 1972); 60% agriculture, 12% manufacturing, 14%
services, 14% other; shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: about 2% of labor force
Population: 4,377,000, average annual growth rate 2.6%
(7/68-7/72)
Ethnic divisions: main Negroid groups 75% (of which, Hausa
50%, Djerma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a
very few Christians
Language: French official, many African languages; Hausa used for trade
Literacy: about 5%
Labor force: 26,000 wage earners; bulk of population engaged in subsistence
agriculture and animal husbandry
Organized labor: negligible
Population: 60,441,000, average annual growth rate
2.8% (current)
Ethnic divisions: 250 tribal groups, of which most important are Hausa-Fulani
(north), Ibo and Yoruba (south); these 3 tribes total over 60% of population;
about 27,000 non-Africans
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25% ‘
Language: Euglish official; Hausa, Yoruba, and Ibo also widely used
Labor force: approx. 22.5 million; abodt 41% of total population; roughly
1.3 million wage earners, of whom 560,000 work in modern enterprises
Organized labor: about 530,000 wage earners, approx. 2.4% of total labor force,
belong to some 700 unions
Population: 3,977,000, average annual growth rate 0.7% (current)
Ethnic divisions: homogeneous white population, small Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant and Roman Catholic, 1%
other
Language: Norwegian, small Lapp and Finnish-speaking minorities
Literacy: 99%
Labor force: 1.6 million; 19.5% agriculture, forestry, fishing, 27.0% mining and
manufacturing, 9.5% construction, 13.3% commerce, 11.9% transportation and
communication, 17.7% services; 1.0% unemployed
Organized labor: 60% of labor force
Population: 476,000, average annual growth rate 2.9%
(current)
Ethnic divisions: almost entirely Arab with small groups
of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low
Population: 58,060,000* (excluding Junagardh, Manavadar, Gilgit, Baltistan, and
the disputed area of Jammu-Kashmir), average annual growth rate 2.4% (7/69-7/70)
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages -- 7% Urdu, 64% Punjabi, 12%
Sindhi, 8% Pushtu, 9% other; English is lingua franca
Literacy: about 14%
Labor force: 12.7 million (est. 1961); 60% agriculture, 16% industry, 7% commerce,
15% service, 2% unemployed
Organized labor: 5% of labor force
Population: 1,594,000, average annual growth rate 3.1% (7/70-7/71)
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7% Indian and other
Religion: over 90% Roman Catholic, remainder mainly Protestant
Language: Spanish; about 14% speak English as native tongue; many Panamanians
bilingual
Literacy: 80% of population 10 years of age and over
Labor force: 468,000 (1969 est.); 40% agriculture, 19.9% services, 11% commerce,
12% manufacturing, 6% construction, 5% transportation and communications, 26%
other (1969 Be 5.6% Canal Zone; national average of 7%-8% unemployed; 25%
to 30% of unemployed in Panama and Colon; shortage of skilled labor but an
oversupply of unskilled labor
Organized labor: 5% of labor ‘force
Population: 18,000 (official estimate for 30 June 1972)
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of
io LIBYA
Sanmarinese Workers (affiliated with ICFTU) has about
1,800 members; Communist-dominated Camera del Lavoro, about 1,060 members
Population: 5,844,000, average annual growth rate 2.8%
(current
Ethnic divisions: 90% Arab, 10% Afro-Asian (est.)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 25% of population; 40% agriculture and herding, 12% construction,
12% service, 12% government, 11% commerce, 13% other
Population: 4,167,000, average annual growth rate 2.2%
(7/67-7/69)
Ethnic divisions: 36% Wolof, 17.5% Fulani, 16.5% Serer, 9% Tukulor, 9% Dyola,
6.5% Malinke, 4.5% other African, 1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly Roman Catholic)
Language: French official, but regular use limited to literate minority; most
Senegalese speak own tribal language; use of Wolof vernacular spreading --
now spoken to some degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence agricultural workers; about 125,000
wage earners
Organized labor: majority of wage-labor force represented by unions; however,
dues-paying membership very limited
Population: 56,000, average annual growth rate 2%
(7/69-7/70)
Ethnic divisions: Seychellois (admixture of Asians, Africans, Europeans )
Religion: 90% Roman Catholic
Language: English official; Creole most widely spoken
Literacy: limited
Labor force: 22,000 agriculture
Organized labor: 3 major trade unions
Population: 2,687,000, average annual growth rate 1.5%
(7/71-7/72)
Ethnic divisions: over 99% native African, rest European and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to literate minority;
principal vernaculars are Mende in south and Temne in north; "Krio," a
form of pidgin English, is also widely spoken
Literacy: about 10%
Labor force: about 1.5 million; most of population engages in subsistence
agriculture; only small minority, some 70,000, earn wages
Organized labor: 35% of wage earners
Population: 218,000, average annual growth rate 2.3%
(3/61-4/71)
Ethnic divisions: 75% Nepalese; 25% Bhotias, Lepchas, and
a few tribal groups
Religion: Tibetan or Lamaist Buddhism (the state religion)
33.3%; Nepalese majority are primarily Hindu
Language: English, official; Nepali, lingua franca; Bhotias
and Lepchas speak Tibeto-Burman dialects
Literacy: probably less than 15%
Labor force: predominantly agricul tural; minimal skilled
labor
Population: 2,204,000, average annual growth rate 1.8%
(7/71-7/72)
Ethnic divisions: 76.2% Chinese, 15% Malay, 7% Indians
and Pakistani, 3% other
Religion: majority of Chinese are Buddhists or atheists; Malays nearly al? Muslim;
minorities include Christians, Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay, Tamil, and English are
official languages
Literacy: 70% (1970)
Labor force: 474,718; 0.5% agriculture, forestry, and fishing, 0.4% mining and
quarrying, 32.2% manufacturing, 30.4% services, 5.2% construction, 21.5%
commerce, 9.8% transport, storage, and communications; 6% other
Organized labor: 24% of labor force
Population: 3,045,000, average annual growth rate 2.3%
(7/65-7/72)
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000 Arabs, 3,000 Europeans,
800 Asians
Religion: almost entirely Muslim
Language: Somali (written form recently instituted by government) ; Arabic, Italian,
English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled laborers; 70% pastoral
nomads, 30% agriculturists, government employees, traders, fishermen,
handicraftsmen, other
Organized labor: law providing for government-controlled labor union promulgated
in June 1971, but union so far not established
Population: 23,905,000, average annual growth rate 2.6%
(7/71-7/72)
Ethnic divisions: 17.8% white, 69.9% African, 9.4% Colored, 2.9% Asian
Religion: primarily Christian except Asian and African; 60% of Africans are
animists
Language: Afrikaans and English official, Africans have many vernacular languages
Literacy: almost all white population literate; government estimates 35% of
Africans literate
Labor force: 8.7 million (total of economically active, 1970); 53% agriculture,
8% manufacturing, 7% mining, 5% commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is unionized (mostly white
workers); nonwhites have no bargaining power','fa34fdfea9af34da489953a6717a4b97f2fb1ecf0bdcb2d9f18fc42383fba07e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8db774027dd5ff396ed5484312c87d5ea70d7c1bbaecf567da8f8a80d93008fb',1974,'GL','Greenland','people-and-society',41,'Population: 581,488,000* (including the Indian-held part of disputed Jammu-
Kashmir), average annual growth rate 2.1% (7/71-7/72)
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.6% Christian, 0.7% Buddhist,
0.7% other
Language: 24 languages spoken by a million or more persons each; numerous
other languages and dialects, for the most part mutually unintelligible;
Hindi is the national language and primary tongue of 30% of the people;
English enjoys "associate" status but is the most important language for
national, political, and commercial communication; Hindustani, a popular
variant of Hindi/Urdu, is spoken widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29% (1971 census)
Labor force: about 184 million; 70% agriculture, more than 10% unemployed and
underemployed; shortage of skilled labor is significant and unemployment is
rising
Organized labor: about 2.5% of total labor force
Population: 126,381 ,000 (including West Irian), average
annual growth rate 2.5% (current)
Ethnic divisions: 45% Javanese, 14% Sundanese, 7.5% Madurese, 7.5% Coastal Malays,
26% other
Religion: 90% Muslim, 4% Christian, 2% Buddhist, 2% Hindu, 2% other
Language: Indonesian (modified form of Malay) official; English, and Dutch
leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 41 million; 70% agriculture, 15% industry, 15% miscellaneous and
unemployed
Organized labor: 10% of labor force
Population: 31,740,000, average annual growth rate 3%
(1/71-1/72)
Ethnic divisions: 63% Ethnic Persians, 3% Kurds, 13% other Iranian, 18% Turkic,
3% Arab and other Semitic, 1% other
Religion: 93%.Shia Muslim; 5% Sunni Muslim; 2% Zoroastrians, Jews, Christians
and Baha''is
Language: Farsi (Persian), Turki, Kurdish, Arabic
Literacy: about 33% of those 10 years of age and older (1972 est.)
Labor force: 7.5 million; 47% agriculture, 53% industry, commerce and services;
shortage of skilled labor substantial
Organized labor: 1.1% of labor force
Population: 10,475,000, average annual growth rate 3.3%
(10/70-10/71)
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7% Assyrians, 2.4% Turkomans,
7.7% other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry, 6.7% government,
16.8% other; rural underemployment high, but not serious because low
subsistence levels make it easy to care for unemployed; severe shortage
of technically trained personnel
Organized labor: 11% of labor force
Population: 3,043,000 average annual growth rate 0.6%
(4/66-4/71)
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 2% other
Language: English and Gaelic official; English is generally spoken
Literacy: 98%-99%
Labor force: about 1,130,000; 28% agriculture, forestry, fishing; 19% manufac-
turing; 15% commerce; 6% construction; 5% transportation; 4% government;
18% other
Organized labor: 36% of labor force
Population: 55,007,000, average annual growth rate 0.7%
(1/66-1/73)
Ethnic divisions: primarily Italian but population includes small clusters of
German-, French-, and Slovene-Italians in the north and of Albanian-Italians
in the south
Religion: almost 100% nominally Roman Catholic (de facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region (e.g., Bolzano) are
predominantly German speaking; significant French-speaking minority in Valle
d''Aosta Region; Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5%-7% of population illiterate (1972); illiteracy varies widely by region
Labor force: 19,019,000 (April 1972); 17.7% agriculture, 42.5% industry,
36.5% other, 3.3% unemployed; underemployment, particularly in southern
Italy, remains widespread; 1.5 million Italians employed in other Western
European countries
Organized labor: 20% (est.) of labor force
Population: 5,177,000 (resident African population only),
average annual growth rate 3.3% (1/66-1/71)
Ethnic divisions: 7 major indigenous ethnic groups; no single tribe more than
20% of population; most important are Agni, Baoule, Krou, Senoufou, Mandingo;
approx. 1 million foreign Africans, mostly Voltaics; about 33,000 non-Africans
(25,000 French)
Religion: 66% animist, 22% Muslim, 12% Christian
Language: French official, over 60 native dialects, Dioula most widely spoken
Literacy: about 20%
Labor force: over 85% of population engaged in agriculture, forestry, livestock
raising; about 11% of labor force are wage earners, nearly half in agricul-
ture, remainder in government, industry, commerce, and professions
Organized labor: 20% of wage labor force
Population: 2,556 ,000 (including West Bank and East Jerusalem), average annual
growth rate 3.1% (current
Ethnic divisions: 98% Arab, 1% Circassian, 1% Armenian
Religion: 95% Sunni Muslim, 5% Christian
Language: Arabic official, English widely understood among upper and middle
classes
Literacy: about 40% in East Jordan; somewhat less than 50% in West Jordan
Labor force: 564,000; 33% unemp]oyed
Organized labor: 5% of labor force
Population: 12,688,000, average annual growth rate 3.4%
(7/71-7/72)
Ethnic divisions: 97% native African (including Bantu, Nilotic, Hamitic and
Nilo-Hamitic); 2% Asian; 1% European, Arab and others
Religion: 56% Christian, 36% animist, 7% Muslim, 1% Hindu
Language: English and Swahili official; each tribe has own language
Literacy: 27%
Labor force: 2.5 million; about 977,000, (39%) in monetary economy (1967)
Organized labor: about 215,000
Population: 15,760,000, average annual growth rate 3.1%
(current)
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 47.7% agriculture, 52.3% non-agricultural; shortage of
skilled and unskilled labor
Population: 33,290,000, average annual growth rate 1.8%
(7/71-7/72)
Ethnic divisions: homogeneous; small Chinese minority
(approx. 20,000)
Religion: strong Confucian tradition; pervasive folk religion (Shamanism);
vigorous Christian minority (5.5% of population); Buddhism (including
estimated 20,000 members of Soka Gakkai); Chondokyo (religion of the heavenly
way), eclectic religion with nationalist overtones founded in 19th century,
claims about 1.5 million adherents
Language: Korean
Literacy: about 90%
Labor force: about 10.2 million (1971); 46.2% agriculture, fishing, forestry,
32.3% services, 14% mining and manufacturing, 3% construction, 4.5% unemployed
Organized labor: about 10% of nonagricultural labor force
Population: 1,055,000, average annual growth rate 10%
(7/71-7/72)
Ethnic divisions: 87% Arabs, 12% Iranians, Indians, and Pakistani, 1% other
Religion: 95% Muslim, 5% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign language
Literacy: about 55% (1968)
Labor force: 250,000 (1969); 9% manufacturing, 16% construction, 45% services,
13% commerce
Organized labor: labor unions, first authorized in 1964, formed in oi] industry
and among government personnel','84467f13bb3039dd59152ee2cf389b9f9daa31aae99a6b64b26ad9e9056abcce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55a2fc4db930bcb4cd160159f93f9096b070b05dc7249a459da1a23d71ff5c93',1974,'DE','Germany','people-and-society',44,'Population: 3,219,000, average annual growth rate 2.4%
(7/71-7/72)
Ethnic divisions: 47% Lao; 14% Tribal Tai; 25% Phoutheung
(Kha); 14% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant foreign
Janguage also used in administration
Literacy: about 12%
Labor force: about 1,268,000; 80%-90% agriculture; 159,286 engaged in
manufacturing and services; 11,864 government employees
Organized labor: only civil servants are organized
Population: 3,102,000 (including Lebanese nationals living
outside the country who are on the population register,
but excluding registered Palestinian refugees numbering
182,000 on 3] December 1971), average annual growth rate 3.1% (current)
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1% other (official estimates) ;
Muslims believed to constitute slight majority
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically active; 49% agriculture, 11% industry,
14% commerce, 26% other; moderate unemployment
Organized labor: about 55,000
Population: 982,000, average annual growth rate 1.8%
(4/71-4/72)
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800 Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in
subsistence agriculture; 150,000 to 250,000 spend 6 months to many years
as wage earners in South Africa
Organized labor: negligible
Population: 1,705,000, average annual growth rate 3.3%
(current)
Ethnic divisions: 5% coastal descendants of immigrant
Negroes; 95% indigenous Negroid African tribes including Gola, Kissi, Vai,
Kpelle, Kru, and Mandingo
Religion: probably more Muslims than Christians; 70%-80% animist
Language: English official; 28 tribal languages or dialects, pidgin English used
by about 20%
Literacy: about 24% over age 5
Labor force: 500,000, of which 150,000 are in modern economy; about 2,000 non-
African foreigners hold about 95% of the top level management and
engineering jobs
Organized labor: 2% of labor force
Population: 2,201,000, average annual growth rate 3.7% (7/71-7/72)
Ethnic divisions: 97% Berber and Arab with some Negro stock; some Greeks, Maltese,
Jews, Italians, Egyptians
Religion: 97% Muslim
Language: Arabic; Italian and English widely understood in major cities
Literacy: 35%
Labor force: 485,000; between ages 15-64, 405,000-430,000; 61% of labor force
in agriculture (1964)
Population: 23,000, average annual growth rate 2.5%
(12/60-12/70)
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly from
Austria and Italy); 59% industry, 20% trade and
commerce, 13% professional and other, 8% agriculture
Population: 352,000, average annual growth rate 0.7%
(7/66-7/72)
Ethnic divisions: 83% Luxembourger, including an estimated
5% of Italian descent; remainder French, German,
Belgian, etc.
Religion: 97% Roman Catholic, remaining 3% Protestant
and Jewish
Language: Luxembourgish, German, French; most educated Luxembourgers also speak
English
Literacy: 98%
Labor force: (1970) 144,000; 11% agriculture (including forestry and fishing),
47% industry, 42% services, no significant unemployment; 30% of labor force
is foreign, comprising workers from neighboring areas of Belgium, France,
and West Germany, as well as Italy and Portugal
Organized labor: 45% of labor force
bas 249,000 (official estimate for 15 December
970
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about one-half are Chinese
Language: Chinese 98%, Portuguese 2%
Literacy: almost 100% among Portuguese and Macanese; no data on Chinese
population
Labor force: 5% agriculture, 30% manufacturing, 3% construction, 1% utilities,
27% commerce, 8% transportation and communications, 26% services (1960 data)
Population: 7,303,000, average annual growth rate 2.3%
(7/69-7/70)
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting
of Merina (1,643,000) and related Betsileo (760,000), on the one hand, and
coastal tribes with mixed Negroid, Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include Betsimisaraka 94] ,000, Tsimihety 442,000,
Sakalava 375,000, Antaisaka 415,000; there are also 38,000 French, 66 ,000
other
Religion: more than half animist; about 41% Christian, 7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are nonsalaried family workers
engaged in subsistence agriculture; of 175,000 wage and salary earners,
26% agriculture, 17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscellaneous
Organized labor: 4% of labor force
Population: 4,843,000, average annual growth rate 2.5%
(7/71-7/72)
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is second
African language
Literacy: 6% of population over 21 years old
Labor force: 180,000 wage earners employed in Malawi (1971); 6,000 Europeans
permanently employed; 300,000 Malawians live and work in Rhodesia, South
Africa, and, Zambia; 30% agriculture, 11% construction, 10% commerce, 13%
manufacturing, 10% administration, 26% miscellaneous services
Organized labor: small minority of wage earners are unionized
Population: 11,401,000 average annual growth rate 2.7% (current)
West Malaysia: 9,591,000, average annual growth rate 2.6% (6/57-8/70)
Sabah: 741,000, average annual growth rate 3.7% (8/60-8/70)
Sarawak: 1,069,000, average annual growth rate 2.7% (6/60-8/70)
Ethnic divisions:
Malaysia: 44% Malay, 36% Chinese, 8% tribal, 10% Indian and Pakistani,
2% other
West Malaysia; 50.1% Malay, 36.9% Chinese, 11% Indian and Pakistani,
2% other
Sabah: 23.1% Chinese, 67.3% indigenous tribes, 9.6% other
Sarawak: 31.5% Chinese, 50% indigenous tribes, 17.5% Malay, 1% other
Religion:
West Malaysia: Malays nearly all Muslim, Chinese predominantly Buddhists,
Indians predominantly Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist, 16% Christian, 35%
tribal religion, 2% other
Language:
West Malaysia: Malay (official); English, Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dialects, Mandarin and Hakka dialects
predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal languages
Literacy:
West Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 3.45 million (1967)
West Malaysia: 2.9 million; 55% agriculture, forestry, and fishing, 11%
manufacturing and construction, 34% trade, transport, and services
Sabah: 213,000 (1967); 80% agriculture, forestry, and fishing, 6% manu-
facturing and construction, 13% trade and transportation, 1% other
211
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
Approved For Release 2004/08/31 : CIA-RDP79-01051A000600010004-7
PEOPLE (cont''d):
Sarawak: 341,000 (1967); 80% agriculture, forestry, and fishing, 6% manu-
facturing and construction, 13% trade, transportation, and services,
1% other
Organized Tabor: 370,000 (official 1967 eg$t.) about 10.5% of total labor force; J
28% of wage labor force; unemployment about 8% of total
labor force, but higher in urban areas.
Population: 116,000, average annual growth rate 2% (current)
Ethnic divisions: admixtures of Sinhalese, Dravidian, Arab and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the male population
Population: 5,433,000, average annual growth rate 2.2%
(7/71-7/72)
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African languages,
of which Mande group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried, 50,000 of whom are employed by the
government; most of population engaged in agriculture and animal husbandry
Organized Tabor: UNTM, which claimed all eligible employees, dissolved; thirteen
national unions currently directed by a government controlled Coordination
Committee of Mali Trade Unions (CCSM)','15f1527bc6c6c3c4a4331e36411ebd777fe5f628f4b33a2b9abbd742c81dead0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7ab9bf2660c19b9097289670cbea717fcdbdcfe9e73a204c8c4c3afd9b3e94d',1974,'CN','China','people-and-society',48,'Population: 317,000 (official estimate for 31 March 1973)
Ethnic divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in 1946
Labor force: 111,000; 33% services, 20% government, 21% manufacturing, 7%
agriculture, 6% unemployed
Organized labor: approximately 35% of labor force','4e3a43376b6e6538673141f2971810bfa8b432ab8457e1b260e57e8998a5456b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('788f61ce50a50aeced6ad7ff27f6aaf8208ff712f2edfa0ad95c79bdedda8c6c',1974,'AU','Australia','people-and-society',52,'Population: 7,000 (official estimate for 30 June 1969)
Ethnic divisions: 2,921 Nauruans, 1,167 Chinese, 428
Europeans, 1,532 other Pacific Islanders
Religion: Christian (2/3 Protestant, 1/3 Catholic)
Language: Nauruan, a distinct Pacific Island tongue; English, the language of
school instruction, spoken and understood by nearly all
Literacy: nearly universal
Population: 12,171,000, average annual growth rate 2.1%
(6/61-6/71)
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%),
representing considerable intermixture of Indo-Aryan
and Mongolian racial strains; country divided among
many quasi-tribal communities
Religion: only official Hindu Kingdom in world, although no sharp distinction
between many Hindu and Buddhist groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided into numerous dialects;
Nepali official language and lingua franca for much of the country; same
script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5% industry; great lack of skilled
labor
Population: 13,531,000, average annual growth rate 1.1%
(current)
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 41% Protestant, 40% Roman Catholic, 19% unaffiliated
Language: .Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24% services, 16% commerce, 10%
agriculture, 9% construction, 7% transportation and communications, 4%
other; 1.05% registered unemployed; no shortage of skilled Tabor but shortage
of semi-skilled labor; 129,000 unfilled vacancies reported by employers in
January, 1971
Organized labor: 33% of labor force
Population: 2,695,000, average annual growth rate 2.7%
(7/66-7/71)
Ethnic divisions: predominantly Melanesian and Papuan, some Negrito, Micronesian,
and Polynesian types
Religion: over one-half of population nominally Christian (490,000 Catholic,
320,000 Lutheran, other Protestant sects); remainder animist
Language: 700 indigenous languages; pidgin English and 2 or 3 native languages
are linguae francae for over one-half of population; English spoken by
1% to 2% of population
Literacy: 1%; in English, 0.1%
Labor force: no available figures; mostly subsistence farmers
. Population: 2,418,000, average annual growth rate 2.6%
(10/62-7/72)
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 800,000 (1971 est.); 55% agriculture, forestry, fishing; 8% transport
and other services; 19% manufacturing and construction; 13% commerce and
professions; 5% miscellaneous (est. 1962)
Organized labor: about 5% of labor force
J RRGENTINA—
Population: 14,200,000 (excluding Indian jungle population
which was estimated at 101,000 in 1961), average annual
growth rate 2.9% (7/61-6/72)
Ethnic divisions: 46% Indian; 38% mestizo (white-Indian); 15% white; 14% Negro,
Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 4.4 million (1973); 46% agriculture, 17% services, 14% manufacturing,
9% trade, 4% construction, 4% transportation, 2% mining, 4% other
Organized labor: 25% of labor force
Population: 40,788,000, average annual growth rate 3% (7/71-7/72)
Ethnic divisions: 91.5% Filipino (Malay) . 4% Moros (Malay), 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4% Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national language of the Philippine
Republic; English is the language of school instruction and government
business
Literacy: about 83%
Labor force: 11 million; 60% agriculture, forestry, fishing, 12% manufacturing,
10.5% commerce, 10.5% government and services (business, recreation, domestic,
personal), 3.5% transport, storage, communication, 3% construction; 0.5% other
Population: 33,508,000, average annual growth rate 0.9%
(current)
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians, 0.5% Belorussians, less than
0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75% practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26% industry, 36% other non-
agricultural
Population: metropolitan Portugal 8,524,000, average annual growth rate 0%
te Cape Verde Islands 299,000, average annual growth rate 3.1% (12/60-
12/70
Ethnic divisions: homogeneous Mediterranean stock in mainland, Azores, Madeira
Islands; small, but growing number of black workers principally from the
Cape Verde Islands
Religion: 97% Roman Catholic, 1% Protestant sects, 2% other
Language: Portuguese
Literacy: 65% (a figure considered very high by some sources)
Labor force: 3.3 million (1970); 32% agriculture, 34% industry, 34% services;
unemployment virtually nil, but some underemployment widespread
Organized labor: 33.4% of labor force in syndicates subject to varying degrees
of government control
Population: 642,000, average annual growth rate 1.7%
(12/60-12/70)
Ethnic divisions: 95% indigenous Timorese belonging to the Malay racial group;
9 ethnic divisions, each speaking a distinct dialect of Malay structure;
approx. 4,600 Chinese and 10,000 halfcastes
Religion: 17% Christian (almost equally divided between Catholic and
Protestant), remainder practice animism
Language: an estimated 9-15 dialects, of Malay origin but mutually unintelligible;
75% of the population speaks the Tetum dialect
Literacy: rate of literacy is unknown, but is very low; in 1971 total school
enrollment was 35,000 out of total school-age population of 80,000; 5% of
natives can speak Portuguese
Labor force: 90% engaged in primitive village subsistence economy, 10% engaged
as town laborers and domestics
Population: 95,000, average annual growth rate 3%
(7/67-7/71)
‘Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children between ages of 6-14
Labor force: agriculture 10,303, mining 599
Organized labor: unorganized
Population: 993,000, average annual growth rate 1.3%
(4/60-4-70)
Ethnic divisions: 43% Negro, 36% East Indian, 16% mixed, 2% white, 3% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23% Hindu, 6% Muslim, 13%
unknown
Language: English
Literacy: 80%
Labor force: about 361,000 (1971 est.), about 20.4% agriculture, 18.3% mining,
quarrying, and manufacturing, 15.8% commerce; 14.6% construction and utilities;
6.9% transportation and communications; 20.8% services, 3,270 other (1965)
Organized labor: 28% of labor force
Population: 5,561,000, average annual growth rate 2.2% (7/66-7/72)
Ethnic divisions: 98% Arab, 1% European, less than 1% Jewish
Religion: 98% Muslim, 1% Christian, less than 1% Hebrew
Language: Arabic (official), Arabic and French (commerce)
Literacy: about 30%
Labor force: 1.5 million; 70% agriculture, 10% manufacturing and construction,
20% other; 25% underemployed; shortage of skilled labor
Organized labor: 10% of labor force; General Union of Tunisian Workers (UGTT) ;
subordinate to Destourian Socialist Party
Population: 38,692,000, average annual growth rate 2.6%
(10/65-10/70)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force
Population: 10,991,000, average annual growth rate 3.4%
(current)
Ethnic divisions: 98.7% African, 1.3% European, Asian,
Arab
Religion: about 60% nominally Christian, 5%-10% Muslim, rest
pagan
Language: English official; Luganda and Swahili widely used; other Bantu and
Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which 256,799 in paid labor, remaining
in subsistence activities
Organized labor: 123,284 union members
Population: 251,087,000, average annual growth rate 1%
(current)
Ethnic divisions: 74% Slavic, 26% among some 170 ethnic groups
Religion: 70% atheist, 18% Russian Orthodox, 9% Muslim, 3% other
Language: more than 200 languages and dialects (at least 18 with more than 1
million speakers); 76% Slavic group, 8% other Indo-European, 11% Altaic,
3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 127 million (1973), 28% agriculture, 72% industry and other
non-agricultural fields, unemployed not reported, shortage of skilled labor
reported, no shortage of unskilled labor
Population: 179,000 (census of 15 March - 16 April 1968)
Ethnic divisions: Arabs 72%; others include Iranians,
Pakistanis, and Indians
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 20% est. (1968)
Labor force: 77,000 (1968)
Population: 5,772,000, average annual growth rate 2%
(7/69-7/70)
Ethnic divisions: more than 50 tribes; principal tribe
is Mossi (about 2.5 million); other important groups
are Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to Sudanic family, spoken
by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active population engaged in animal
husbandry, subsistence farming, and related agricultural pursuits; about
30,000“are wage earners; about 20% of male labor force migrates annually to
neighboring countries for seasonal emp] oyment
Organized labor: 3 primary and severa] sma11 specialized unions','7f94551108b12a2c2f68d97b74737369339542fe188b1232ca7c9327e9777cdd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ba7e971779dd0ae33a239fbb63a21aab27753919667304a1ebc2138deb67eed',1974,'JP','Japan','people-and-society',60,'Population: 800,000, average annual growth rate 1.9%
(7/60-7/65)
Ethnic divisions: 14% white, 81% Africans, 5% Colored
(mulattoes); almost half the Africans belong to Ovambo tribe; Damara tribe
has almost 45,000 members; Herero, Okavango, Nama tribes have about 30,000
members each
Religion: whites predominantly Christian, nonwhites either animist or Christian
Language: Afrikaans principal language of about 70% of white population, German
of 22%, and English of 8%; several African languages
Literacy: high for white population; low for nonwhite
Labor force: 203,300 (total of economically active, 1970); 68% agriculture, 15%
railroads, 13% mining, 4% fishing
Organized labor: no trade unions, although some white wage earners belong to
South African unions
Population: 35,041,000 (including the Balearic and Canary Islands; also including
Alhucemas, Ceuta, Chafarinas, Melilla, and Penon de Velez de la Gomera),
average annual growth rate 1.1% (current)
Ethnic divisions: homogeneous composite of Mediterranean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great majority; but 17% speak Catalan,
7% Galician, and 2% Basque
Literacy: about 90%
Labor force (1973): 12.7 million; 25% agriculture, 36% industry, 39% services;
registered unemployment is 1.5% of labor force
Organized labor: 90% of labor force in compulsory government-control led
syndicates
Population: 76,000 (preliminary total from the census of
31 December 1970)
Ethnic divisions: 51.2% Arab, Berber, and Negro nomads;
48.8% Spanish
Religion: 51% Muslim, 49% Catholic
Language: Spanish (official), local Arabic or Hassania
Literacy: among Spanish, probably nearly 100%; among nomads, perhaps 5%
Labor force: 12,000; 50% agriculture, 50% other
Organized labor: none
Population: 13,357,000, average annual growth rate 2.2%
(7/63-10/71)
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor, 2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6% Muslim, 1% other
Language: Sinhala official, spoken by about 70% of population; Tamil spoken by
about 22%; English commonly used in government and spoken by about 10% of the
population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed; employed persons -- 53.4% agriculture,
14.8% mining and manufacturing, 12.4% trade and transport, 19.4% services
and other
Organized labor: 43% of labor force, over 50% of which employed on tea, rubber,
and coconut estates
Population: 17,112,000, average annual growth rate 2.5%
(7/71-7/72)
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23% pagan, 4% Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects of Nilotic, Nilo-Hamitic,
and Sudanic languages, English; program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15% industry, commerce, services,
etc.; labor shortages exist for almost all categories of employment
Population: 455,000, average annual growth rate 3.5%
(7/64-7/70)
Ethnic divisions: 35.5% Creole (Negro and mixed), 34.7% Hindustani (East Indian),
14.9% Javanese, 8.5% Bush Negro, 2.2% Amerindian, 1.6% Chinese, 1.3% Europeans,
1.3% other and unknown
Religion: Muslim, Hindu, Moravian, Roman Catholic, other -- in order of size
(% figures unknown)
Language: Dutch official; English widely spoken; Taki-Taki (Surinam Creole)
is native language of Creoles and lingua franca; Hindi; Japanese
Literacy: 70% to 75%
Labor force: 100,000 (1973); 20% agriculture, 7% mining, 12% industry and
construction, 10% trade, banking and transport, government, 3% other; 25%
unemployed employees, 13% other
Organized labor: approx. 33% of labor force
Population: 467,000, average annual growth rate 3.1%
(current)
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and Swati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence agriculture; 55-60,000
wage earners, many only intermittently, with 31% agriculture, 11% government ,
11% manufacturing, 12% mining and forestry, 35% other (1968 est.); 7,900
employed in South African mines (1969)
Organized labor: about 15% of wage earners are unionized
Population: 8,143,000, average annual growth rate 0.2%
(1/72-1/73)
Ethnic divisions: homogeneous white population; small Lappish minority
Religion: 92% Evangelical Lutheran, 7% other Protestant, Roman Catholic, Eastern
Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking minorities
Literacy: 99%
Labor force: 3.9 million; 11.8% agriculture, forestry, fishing; 33.5% mining
and manufacturing; 9.6% construction; 15.5% commerce; 7.2% transportation
and communications; 20.9% services; 3.2% unemployed
Organized labor: 80% of labor force
Population: 6,460,000, average annual growth rate 0.9%
(1/72-1/73) : MQROCCO
Ethnic divisions: total population -- 69% German, 19% ALGERIA
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals ~- 74% German, 20% French, 4% Italian,
1% Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals -- 74% German, 20% French, 4% Italian, 1% Romansch,
1% other; total population -- 69% German, 19% French, 10% Italian, 1%
Romansch, 1% other
Literacy: 98%
Labor force:’''3.0 million, about one-fifth foreign workers, mostly Italian;
16% agriculture and forestry, 47% industry and crafts, 20% trade and
transportazion, 5% professions, 2% in publiic service, 10% domestic and
other; no significant unemployment shortage of both skilled and
unskilled labor -- 6,537 unfilled vacancies in April 1972
Organized labor: 20% of labor force
Population: 6,990,000, average annual growth rate 3.3% (7/71-7/72)
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians, and other
Religion: 70.5% Sunni Muslim, 16.3% other Muslim sects, 13.2% Christians of
various sects
Language: Arabic, Kurdish, Armenian; French and English widely understood
Literacy: about 40%
Labor force: 2 million; 67% agriculture, 12% industry (including construction) ,
21% miscellaneous services; majority unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 14,558,000, average annual growth rate 2.7% (7/71-7/72)
Ethnic divisions: 99% native Africans consisting of well over 100 tribes; 1%
Asian, European, and Arab
Religion: Tanganyika -- 40% animist, 30% Christian, 30% Muslim; Zanzibar --
almost all Muslim
Language: Swahili English and official English primary language of commerce,
administration and higher education; Swahili widely understood and generally
used for communication between ethnic groups; first language of most people
is one of the local languages
Literacy: 15%-20%
Labor force: under 400,000 in paid employment, over 90% in agriculture
Organized labor: 15% of labor force
Population: 38,438,000, average annual growth rate 3.2%
(current)
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70%
Labor force: 88% agriculture, 9% commerce, 3% industry
Population: 2,152,000, average annual growth rate 2.6%
(7/66-7/70)
Ethnic divisions: some 40 tribes; largest and most
important are Ewe in south and Cabrais in north; under 1% European and
Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of commerce; major African languages
are Ewe and Mina in south and Dagoma, Tim, and Cabrais in north
Literacy: 5% to 10%
Labor force: over 90% of population engaged in subsistence agriculture; about
30,000 wage earners, evenly divided between public and private sectors
Organized labor: less than half of wage earners divided among 2 major and several
minor unions','e9151f22195a4a87daab363555df7e96bd45915594a1d70d6c8f1ca1ab9fe8dc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58a3b96e557d0e8d61b487f333e8b13314db36c0aae141a4653cf14c8736d56b',1974,'US','United States','people-and-society',65,'Population: 211,228,000, average annual growth rate 0.7% (current)
Ethnic divisions: 87.2% white, 11.3% negro, 1.4% other
Religion: total membership in religious bodies, 128,470,000; Protestant
69,424,000, Roman Catholic 47,873,000, Jewish 5,780,000, other religions
5,393,000
Language: English, predominantly
Literacy: almost complete
Labor force: 86 million (1972)
Organized labor: 28.8% of total','95f98ec3e148b9d64c4a7e3b277aa9a1faecaa68b42e32657eebd135199bdd7e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000600010004-7','txt','ff88d6da86c572ae65cd4fdf5d5c6c27b67fe3dcea38c0539cb800dc7f873738','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000600010004-7/cia-rdp79-01051a000600010004-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e350b6a9fcdd856e4306398d303a25b88703b4b61aecca91699ec0584977065c',1974,'','','people-and-society',5,'Population: 2,387,000, average annual growth rate 2.8%
(current)
Ethnic divisions: 96% Albanian, remaining 4% are Greeks,
Vlachs, Gypsies, and Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10% Roman Catholic (observances
prohibited; Albania claims to be the world''s first atheist state)
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics available, but probably
greatly improved
Labor force: 911,000 (1969); 60.5% agriculture, 17.9% industry, 21.6% other
nonagricultural','f7c540b1d5745a0430f68d68731ca595ecbcbcdc5d8921ed6c6b74a809ad48f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75e4dfa78cf279ddba5b41f22dc0bc2f6904f1d9247ff93d26a555f96019048b',1974,'DZ','Algeria','people-and-society',7,'Population: 16,271,000, average annual growth rate 3.2%
(7/68-7/73)
Ethnic divisions: 99% Arab-Berbers, less than 1% Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 2.8 million; 47% agriculture, 8% industry, 24% other (military,
police, civil service, transportation workers, teachers, merchants,
construction workers); 40% of urban labor unemployed
Organized labor: 17% of labor force claimed; General Union of Algerian
Workers (UGTA) is the only labor organization and is subordinate to the
National Liberation Front
Population: 3,052,000 average annual growth rate 0.6%
(7/62-7/72)
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 2% other
Language: English and Gaelic official; English is generally spoken
Literacy: 98%-99%
Labor force: about 1,130,000; 28% agriculture, forestry, fishing; 19% manufac-
turing; 15% commerce; 6% construction; 5% transportation; 4% government;
18% other
Organized labor: 36% of labor force','0b672aba5a6482871d5f605ff2fc204714d51db667136957c25e5d0976c75303','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5fc90575d7fa4c28b3a0ddbe403b2f921ee9801cea34f54d813547302f5fdfd',1974,'AD','Andorra','people-and-society',11,'Population: 19,000 (official estimate for 1 July 1969)
Ethnic divisions: Catalan stock; 30% Andorrans, 61%
Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic ALGERIA
Language: Catalan, many also speak some French and é
Castilian
Labor force: unorganized; largely shepherds and farmers','0dcdd14929e98c8bd036db233838024323e526251ade286ff2a8513f5a6f9aa1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3b6c6daa28cb7335fbc4aedd5ce94cf693c7a5ff2019e49c2bb7661e5e89494',1974,'AO','Angola','people-and-society',15,'Population: 6,003,000, average annual growth rate 1.6%
(12/60-12/70)
Ethnic divisions: 93.6% African, 5% Europeans, 1.4% mulatto (1960)
Religion: about 84% animist, 12% Roman Catholic, 4% Protestant
Language: Portuguese (official), many native dialects
Literacy: 10%-15%
Labor force: 2.6 million economically active (1964); 531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)','09b86802a28b0f03c1ad5cf39a04580f0af8becd68ea2f6bcc0607b30970daf3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67ef8c1e32f32e7cdccdc4b6e22fbaeba705adbfe8e1d773daf811b2b907e373',1974,'AR','Argentina','people-and-society',25,'Population: 24,656,000, average annual growth rate 1.5%
(7/70-7/72)
Ethnic divisions: approximately 85% white, 15% mestizo, Indian, or other
nonwhite groups
Religion: 90% nominally Roman Catholic (less than 20% practicing), 2% Protestant,
2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 9.5 million; 19% agriculture, 25% manufacturing, 20% services,
11% commerce, 6% transport and communications, 19% other
Organized labor: 25% of labor force (est.)
Population: 9,708,000, average annual growth rate 2.0%
(current)
Ethnic divisions: 85%-90% chileno (mixture of European and Indian stock), 3%
Indian, 7% European, Asfastic, and other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 89%
Labor force: 3.3 million (1973); 19% agricultural, 28% industry and construction,
29% services, 14% commerce, 5% mining, 5% other (1973)
Organized labor: 25% of labor force (1973)
Population: 920,066,000, average annual growth rate 2.4% (current)
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur, Hui, Yi, Tibetan, Miao,
Manchu, Mongol, Pu-I, Korean, and numerous lesser nationalities
Religion: most people, even before 1949, have been pragmatic and eclectic,
not seriously religious; most important elements of religion are Confucian -
ism, Taoism, Buddhism, ancestor worship; about 2%-3% Muslim, 1% Christian
Language: Chinese (Mandarin mainly; also Cantonese, Wu, Fukienese, Amoy, Hsiang,
Kan, Hakka dialects), and minority languages (see ethnic divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85% agriculture, 15% other; shortage of
skilled labor (managerial, technical, mechanics, etc.); surplus of unskilled
labor
Population: 15,723,000 (excluding the population of
Quemoy and Matsu Islands and foreigners), average
annual growth rate 1.9% (7/72-7/73)
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese, 2% aborigines
Religion: 93% mixture of Buddhism, Confucianism, and Taoism; 4.5% Christian;
2.5% other
Language: Chinese Mandarin (official language), also Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 4.9 million; 33% primary industry (agriculture), 32.1% secondary
industry (including manufacturing, mining, construction), 34.9% tertiary
industry (including commerce and services) 1972
Organized labor: about 12% of 1972 labor force (government controlled)','c122de8f67f12cf7f435b75c0bc5249519bc76e86680d95321a19b2fda0aa7d3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('513b5ddb57746de2bf4030c6a73dc5e4d8d96fc703b4bd6ca43cd6aa63c6840f',1974,'AT','Austria','people-and-society',29,'Population: 7,490,000, average annual growth rate 0.1%
(1/72~1/73)
Ethnic divisions: 98.1% German, 0.7% Croatian, 0.3% Slovene, ALGERIA
0.9% other :
Religion: 85% Roman Catholic, 7% Protestant, 8% none or
other
Language: German
Literacy: 98%
Labor force: 2,614,600 (1972); 18% agriculture and forestry, 49% industry and
crafts, 18% trade and communications, 7% professions, 6% public service,
2% other; 2.4% registered unemployed; an estimated 200,000 Austrians are
employed in other European countries; foreign laborers in Austria number
more than 200,000 (1972); unemployment 2.1% (1972)
Organized labor: about 2/3 of wage and salary workers (1971)','38b1033604d6ee9a9e7cf3990cdbd12a15d8020678ad30947473f4e5cf4f56dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c793d40df9b2819237c3304f20909bf64c5f9860b0ec4ce16597ec28a15915ff',1974,'BS','Bahamas','people-and-society',33,'Population: 194,000, average annual growth rate 2.5%
(4/70-7/72)
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: mainly Church of England; some Protestant, Greek Orthodox, and
Roman Catholic
Language: English
Labor force: 60,000 (1963); 25% organized
Pepulation: 237,000, average-annual growth rate 2.8%
(2/65-4/71)
Ethnic divisions: 90% Arab, 7% Tranian, Pakistani, and
Indian, 3% other
Religion: Muslim
Language: Arabic
Literacy: about 30% (1965)
Labor force: 53,274 (1965)','d1ce4bdd56c7bded7fa4035c3d0b783a01e2780eb93bbfe25f02bd6b64635e6f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccbf46d598b38b22e34ee2c5d3f5e0bc9ed73dff6fb9dd96319269564f015911',1974,'BD','Bangladesh','people-and-society',37,'Population: 78,496,000*, average annual growth rate 2.7%
(current)
Ethnic divisions: predominantly Bengali; fewer than 1
million "Biharis" and fewer than 1 million tribals
Religion: about 83% Muslim, 16% Hindus less than 1% Buddhist and other
Language: Bengali
Literacy: about 20%
Labor force; about 25 million; majority are unemployed or part-time employees;
‘over 80% of labor force is in agriculture','28df1ed21230b5748c3eebc596d9a7001beffd7c0a9bfefda9b671ff0193e562','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9446764376c41c823eea11099aa4d76d0881fa1fd86fcf0e91dfd27e2386fd46',1974,'BE','Belgium','people-and-society',44,'Population: 9,766,000, average annual growth rate 0.2%
(current)
Ethnic divisions: 55% Flemings, 33% Walloons, 12% mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch), German, in small area of eastern Belgium;
divided along ethnic lines
Literacy: 97%
Labor force: 4.0 million; approximately 95% is found in the following sectors:
32% manufacturing, 24% services, 16% commerce, banking, and insurance, 8%
construction, 7% transportation and communication, 5% agriculture, forestry,
and fishing, 1.5% mining, .8% public utilities and sanitary services; 4.1%
unemployed, early 1974
Organized labor: 48% of labor force (1969)
Population: 135,000, average annual growth rate 2. Qe
(4/60-4/70)
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerindian, 8% other
Religion: 50% Roman Catholics Anglican, Seventh-day Adventist, Methodist,
Baptist, Jehovah''s Witnesses, Mennonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 34,500; 39% agriculture, 14% manufacturing, 8% commerce, 12%
construction and transport, 20% services, 7% other; shortage of skilled
labor and all types of technical personnel; over 15% are unemp loyed
Organized labor: 8% of labor force','230adc2b2ada37fb1350555f1db7de25f2912958b4da899dcce5be36dd805b69','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad8128c6920fa86b9caaab2d47f9a58e3d216097873018d8ce4d88ac0fffca30',1974,'BM','Bermuda','people-and-society',48,'Population: 56,000, average annual growth rate 2.1%
(10/60-10/70)
Ethnic divisions: approximately 63% African, 37% white
Religion: 47.5% Church of England, 10.2% Catholic, 38.2% other Protestant, 4.2%
other
Language: English
Literacy: virtually 100%
Labor force: 24,700 (1970)','f10d937fadc5edd4a8e9af55648a601202fcfec110b68df0d75e745a76b0530b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa67f82097dc36955ecefdc51186fc198447f868bb84f4b800ea749bcdf01baf',1974,'BT','Bhutan','people-and-society',52,'a Population: 1,148,000, average annual growth rate 2,3%
(current)
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese,
15% indigenous or migrant tribes
Religfon: 75% Lamaistic Buddhism, 25% Buddhist-influenced
Hinduism
Language: Bhotias speak various Tibetan dialects, most
widely spoken dialect is Druk-ke, the official language; Nepalese speak
various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry; massive lack of skilled
labor','ae59bb9970abc522ae16c4514198d0700beab9813370777148ef31f8c54d1911','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9d1cb9a8d8370cb14dcfb6130346001176abc158ed60d6cc070e7a2a4338007',1974,'BR','Brazil','people-and-society',55,'Population: 5,140,000, average annual growth rate 2.5%
(current)
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic; active protestant
minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.5 million (1972); 69.1% agriculture, 3.3% mining, 9.6% services
and utilities, 8% manufacturing, 10% other
Organized labor: 150-200,000, concentrated in mining, industry, construction,
and transportation
Population: 105,911,000, average annual growth rate 2.8%
(current)
Ethnic divisions: 60% white, 30% mixed, 8% Negro, and 2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: 67% of the population 15 years or older (1970)
Labor force: about 30 million in 1970 (est.); 44.2% agriculture, livestock,
forestry, and fishing, 17.8% industry, 15.3% services, transportation, and
communication, 8.9% commerce, 4.8% social activities, 3.9% public administra-
tion, 5.1% other
Organized labor: about 50% of labor force; only about 1.5 million pay dues
Population: 184,000, average annual growth rate 2.9%
(7/68-7/72)
Ethnic divisions: 93.0% Melanesians, 4.0% Polynesians,
1.5% Micronesians, 0.3% Chinese, 0.8% Europeans,
0.4% others
Religion: almost all at least nominally Christian; Roman Catholic, Anglican, and
Methodist churches dominant
Literacy: 60%
Population: 155,000, average annual growth rate 4.5%
(8/60-8/71)
Ethnic divisions: 52% Malays, 28% Chinese, 15% indigenous
tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8% Christians 32% other (Buddhist
and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture, 32.8% industry, manufacturing, and
construction, 33.8% trade, transport, services, 2.9% other
Organized labor: 8.4% of labor force
Population: 24,788,000, average annual growth rate 3.2%
(current)
Ethnic divisions: 58% mestizo, 20% caucasian, 14% mulatto, 4% Negro, 3% mixed
Negro-Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture, 13% manufacturing, 18% services,
9% commerce, 13% other (1964)
Organized labor: 13% of labor force (1968)
Population: 284,000, average annual growth rate 2.0%
(9/66 -9/72)
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor Force: mainly agricultural
Population: 2,000 (official est. for 1 July 1971)
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); over 95% (est.) in agriculture, mostly sheepherding
Population: 792,000, average annual growth rate 2.5%
(4/60-4/70)
Ethnic divisions: 51% East Indians, 43% Negro and Negro
mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1% other
Language: English
Literacy: 86%
Labor force: 201,000; about 25% agriculture, 14% manufacturing, 16% services,
11% commerce, 3% mining and quarrying, 10% other; 21% unemployed
Organized labor: 34% of labor force
Population: 4,953,000, average annual growth rate 2.1%
(current)
Ethnic divisions: over 90% Negro, nearly 10% mulatto,
few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of which an overwhelming
majority also practice Voodoo)
Language: French (official) spoken by only 10% of population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.6 million (est. January 1968); 86% agriculture, 12% industry,
2% unemployed; shortage of skilled labor; unskilled labor abundant
Organized labor: less than 1% of labor force
Population: 215,000, average annual growth rate 1.1%
(12/66-12/72)
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant and Roman Catholic, 2%
no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 85,000; 22.6% agriculture and fishing; 25.6% mining and manufacturing;
10.7% construction; 12.8% commerce; 7.8% transportation and communications;
15.2% services; and 5.7% other; unemployment is insignificant
Organized labor: 60% of labor force
Population: 351,000, average annual growth rate 1.0%
(7/70-7/72)
Ethnic divisions: 90% African and African-Caucasian-Indian
mixture, less than 5% East Indian Lebanese, Chinese,
5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public services, 11% construction
and public works, 10% commerce and banking, 10% services, 9% industry, 17%
other
Organized labor: 11% of labor force
Population: 1,288,000, average annual growth rate 2.5%
(current )
Ethnic divisions: 70% Moor, 30% Negro
Religion: nearly 100% Muslim
Language: French and Arabic official
Literacy: about 10%
Labor force: about 18,000 wage earners (1973); remainder of population in
farming and herding
Organized labor: 18,000 union members claimed by single union, Mauritanian
Workers'' Union
Population: 872,000, average annual growth rate 1.2%
(1/72-1/73)
Ethnic divisions: Indians 67%, Creoles 29%, Chinese 3.5%, English and French 0.5%
Religion: 51% Hindu, 33% Christian (mostly Catholic with a few Anglican
Protestants), 16% Muslim
Language: English official language; Hindi, Chinese, French Creole
Literacy: estimated 60% for those over 21, and 90% for those of school age
Labor force: 175,000; 50% agriculture, 6% industry; 20% government services;
14% are unemployed, under-employed, or self-employed, 10% other
Organized labor: about 35% of labor force
Population: 14,401,000 (excluding Indian jungle population
which was estimated at 101,000 in 1961), average annual
growth rate 2.9% (7/61-6/72)
Ethnic divisions: 46% Indian; 38% mestizo (white-Indian); 15% white; 1% Negro,
Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 4.4 million (1973); 46% agriculture, 17% services, 14% manufacturing,
9% trade, 4% construction, 4% transportation, 2% mining, 4% other
Organized labor: 25% of labor force
‘ Population: 19,000 (official estimate for 30 June 1973) mieveia
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of
Sanmarinese Workers (affiliated with ICFTU) has about
1,800 members; Conmunist-dominated Camera del Lavoro, about 1,000 members
Population: 463,000, average annual growth rate 3.5%
(7/64-7/70)
Ethnic divisions: 35.5% Creole (Negro and mixed), 34.7% Hindustani (East Indian),
14.9% Javanese, 8.5% Bush Negro, 2.2% Amerindian, 1.6% Chinese, 1.3% Europeans,
1.3% other and unknown
Religion: Muslim, Hindu, Moravian, Roman Catholic, other ~-- in order of size
(% figures unknown)
Language: Dutch official; English widely spoken; Taki-Taki (Surinam Creole)
is native language of Creoles and lingua franca; Hindi; Japanese
Literacy: 70% to 75%
Labor force: 100,000 (1973); 20% agriculture, 7% mining, 12% industry and
construction, 10% trade, banking and transport, government, 3% other; 25%
unemployed employees, 13% other
Organized labor: approx. 33% of labor force
Population: 474,000, average annual growth rate 3.1%
(current)
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and Swati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence agriculture; 55~-60,000
wage earners, many only intermittently, with 31% agriculture, 11% government,
11% manufacturing, 12% mining and forestry, 35% other (1968 est.); 7,900
employed in South African mines (1969)
Organized Tabor: about 15% of wage earners are unionized
Population: 3,027,000, average annual rowth rate 1.2%
(7/71-7/72)
Ethnic divisions: 85%-90% white, 5% Negro, 5%-10% mestizo
Religion: 66% Roman Catholic (less than half adult population attends church
regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed in important sectors --
25% government; 34% industry; 10% service; 13% other; 8% agriculture, forestry,
fishing and mining; no shortage of skilled labor
Organized labor: about 25% of labor force (largely Communist influenced)
Population: 1,000 (official estimate for 1 July 1964)
Ethnic divisions: primarily Italians but also many
other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees divided
into 3 categories -- executives, officeworkers,
and salaried employees
Organized labor: none
Population: 11,645,000 (excluding Indian jungle population
estimated at 32,000 in 1961}, average annual growth
rate 3.0% (current )
Ethnic divisions: 67% mestizo, 21% white, 10% Negro, 2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 74% (claimed, 1970 est.)
Labor force: 3 million (1969); 24% agriculture, 6% construction, 17% manufacturing,
pee etenereallo, 18% commerce, 25% services, 4% petroleum, utilities, and
other
Organized labor: 45% of labor force
Population: 20,131,000, average annual growth rate 1.4%
(current)
Ethnic divisions: 85%-90% predominantly Vietnamese; ethnic
minorities include Muong, Thai, Meo, and Man
Religion: Confucianism, Buddhism, Taoism, Catholicism
Language: closely corresponds to the breakdown of ethnic groups
Literacy: claimed to be 95% (1964)
Labor force: (1 January 1970) 9.6 million, not including military; about 70%
agriculture and 10% industry
Population: 20,315,000, average annual growth rate 2.6%
(7/65-7/71)
Ethnic divisions: 87.7% Vietnamese, 6% Chinese, 3.2% mountain tribesmen, 2.9%
Khmer, 2% Cham
Religion: 70% Buddhist (at least 5% Hoa Hao), 5% Cao Dai, and 10% Catholic; others
include animist, and small numbers of Protestant, Muslim and Hindu; most
Buddhists are of Mahayana school or practice combination of Buddhism, Taoism,
and Confucianism
Language: Vietnamese, French, Chinese, English, Khmer, tribal languages
Mon-Khmer and Malayo-Polynesian}, Cham (Malayo-Polynesian dialect.)
Labor force: civilian work force 5.8 million (not including armed forces);
67% agriculture, fishing, and forestry; 15% industry and commerce; 3%
domestic and personal services; 5% government; 10% unemployed
Organized labor: 500,000
—"','1e2b1bdb45ff9b9760eb42dfaf4d85b070939514f8c10c036c4dd9a8e5765a7c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ff568ed65a866960f27115bfa7a8c7ad7932cd8ece8d59f3bd6fc96690fe0da',1974,'BW','Botswana','people-and-society',57,'Population: 661,000, average annual growth rate 2.4%
(current)
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% European
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 32% in Tswana;
less than 1% secondary school graduates
Labor force: 385,000; most are engaged in cattle raising and subsistence
agriculture; about 57,000 in internal cash economy, another 60,000 spend
at least 6 to 9 months per year as wage earners in South Africa (1971)
Organized labor: eight trade unions organized with a total membership of
approximately 9,000 (1972 est.)','8b0b4345845f40e3f7910f424b11abf42abebf7efc6b4454543bad84a37cc60e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61f4294e3434d42015750f345d17805778f66faff38f340e80b549c9c37652d8',1974,'BG','Bulgaria','people-and-society',61,'Population: 8,712,000, average annual growth rate 0.7%
(current)
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsies, 2.5% Macedonians, 0.3% Armenians, 0.2% Russians, 0.6% other
Religion: regime promotes atheism; religious background of population is 85%
Bulgarian Orthodox, 13% Muslim, 0.8% Jewish, 0.7% Roman Catholic, 0.5%
Protestant, Gregorian-Armenian and other
Language: Bulgarian; secondary languages closely correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 4.4 million (July 1970); 38% agriculture, 33% industry, 29% other
Population: 29,698,000, average annual growth rate 2.2%
(7/68-7/70)
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2% Kachin,
2% Chin, 2% Chinese, 3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their own languages
Literacy: 70% (official claim)
Labor force: 10 million; 67% agriculture, 13% industry, 20% services, commerce,
and transportation
Organized labor: no figure available; old labor organizations have been
disbanded, and government is forming one central labor organization','4bf1939b373a9b3a6b22460721543dca4615af069b32c9ddad779b5eb55a8035','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0b938df515adaf5218cfde7901df088064a7f9fca7d7ca5d0fd4baff9b40bf2',1974,'BI','Burundi','people-and-society',64,'Population: 3,837,000, average annual growth rate 2%
(7/70-7/71)
Ethnic divisions: Africans -- 86% Hutu (Bantu), 13% Tutsi
(Hamitic), 1% Twa (Piamy}; non-Africans include (late
1968) 3,000 Europeans, 1,000 Asians
Religion: over 60% Christian (50% Catholic, 10% Protestant);
rest mostly animist plus small number of Muslims
Language: Kirundi and French official
Literacy: about 55% in Kirundi, 10% in Swahili, or 6% in French
Labor force: 1,865,471 (1970 est.)
Organized labor: sole group is the Union of Burundi Workers (UTB), membership
about 30,000, affiliated with government party','905f04dcde5ce81b93cc34ebeb48b180cf63b2babe549a74d9cfd7bc3ff6810b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79dfc579b78650f022b60c057a92ea59635114d805a9971d1fd446c5777f41ec',1974,'KH','Cambodia','people-and-society',67,'Population: 7,470,000, average annual growth rate 2.2%
(7/68-7/69)
Ethnic divisions: 89% Khmer (Cambodian), 3% Vietnamese,
5% Chinese, 3% other minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian
Literacy: 55% (est.)
Labor force: 2.56 million; 80.9% agriculture, 5.5% sales, 4.7% manufacturing,
transport, communications, 3.9% professional, administrative, clerical,
3.5% defense; 1.5% unemployed
Organized labor: .5% of labor force','c8dc9426548d5ef775f6754c0e2fc41035566fb0d9e2a7a4b8f398dc74ef0599','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f05e4b78059d2809bc38e1cad32c813c82ef79b396e1436b6bbe5aa9c4b5844',1974,'CM','Cameroon','people-and-society',70,'Population: 6,254,000, average annual growth rate 1.7%
(7/69-7/70)
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroon Highlanders, 19% Equatorial Bantu, 8% Northwestern
Bantu, 10% Fulani, 7% Eastern Nigritic, 11% Kirdi, 13% other African, less
than 1% non-African
Religion: about one-half animist, one-third Christian; rest Muslim
Language: Engtish and French official, 24 major African language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence agriculture and herding;
200,000 wage earners (maximum) including 22,000 government employees, 63,000
paid agricultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force','606a259dd1e0c5e3a306ef21734f862735df312771b18d699c960bd0c797e2e0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('288eb03cc2fa041b8c4e833afd38c47b79ffaad18029824c0344bcd9174e136f',1974,'CF','Central African Republic','people-and-society',73,'Population: 1,748,000, average annual growth rate 2.2%
(7/67-7/71)
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and linguistic
characteristics; Banda (32%) and Baya-Mandjia (29%) are
largest single groups; 6,500 Europeans, of whom 6,000
are French and majority of the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 27% animist, 5% Muslim; animistic
beliefs and practices strongly influence the Christian majority
Language: French official; Sangho, the lingua franca and unofficial national
language
Literacy: estimated at 5%-10%
Labor force: about half the population economically active, 80% of whom are in
agriculture; approximately 64,000 salaried workers
Organized labor: 1% of labor force','2a42a15adabc13f8c1c0e4efc20ffe2afa6d9867f7728edf94167b24ac2cd0a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bc5ef79fc6479953c09f5481d017cb338c91858f3ef915da06d29f6050a02e2',1974,'TD','Chad','people-and-society',76,'Population: 3,948,000, average annual growth rate 2%
(7/71-7/72)
Ethnic divisions: over 240 tribes representing 12 major
ethnic groups -- Muslims (Arabs, Toubou, Fulani,
Kotoko, Hausa, Kanembou, Baguirmi, Boulala, and
Wadai) in the north and center and non-Muslims (Sara,
Mayo-Kebbi, and Chari) in the south; some 150,000
nonindigenous, 5,000 of them French
Religion: about half Muslim, 5% Christian, remainder animist
Language: French official; Chadian Arabic is lingua franca in north, Sara and
Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically active group, of which 90%
are engaged in unpaid subsistence farming, herding, and fishing; 47,000
wage earners in industry and civil service
Organized labor: about 20% of wage labor force','60319a2e060a73652ccc0d699024f8bb189ab047cd798b7dccab468cef5dba0c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3eb838a736045307f2aa56d8e80448404c7b6173e3925be708322370e2c23fb7',1974,'CG','Congo','people-and-society',79,'Population: 1,029,000, average annual growth rate 2.5%
(current)
Ethnic divisions: about 15 ethnic groups divided into some 75 tribes, almost all
Bantu; most important ethnic groups are Kongo (48%) in south, Teke (17%) in
center, M''Bochi (12%) and Sangha (20%) in north; about 8,500 Europeans,
mostly French
Religion: about half animist, half nominally Christian, less than 1% Muslim
Language: French official, many African Janguages with Lingala and Kikongo
most widely used
Literacy: about 20%
Labor force: about 40% of population economically active, most engaged in
subsistence agriculture; 79, 100 wage earners; 40,000~-60,000 unemployed
Organized labor: 16% of total labor force (1965 est.)','29b0f682da7f42408c791885431356c16a55a60e02eec378871c2b2b20775479','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84f7777b5f4594defec5485c63b02e32887916ccece2b3b5c2210ed2548d17df',1974,'CU','Cuba','people-and-society',89,'Population: 9,121,000, average annual growth rate 2.1%
(current)
Ethnic divisions: 51% mulatto, 37% white, 11% Negro,
1% Chinese
Religion; at least 85% nominally Roman Catholic before Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.36 million; 34% agriculture, 17% industry, 6% construction, 6%
transportation, 29% services, 8% unemployed and underemployed
Organized labor: 46% of total force','84bbd5c25948b17b48e24be1be71d0913e00a95395859462efbef25298f3a9eb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca9ab4e9a6380fd9337b5b32da9aaa3a291856df0cf805e96049a9305061ee93',1974,'CY','Cyprus','people-and-society',93,'Population: 669,000, average annual growth rate 1.6%
(7/71-7/73)
Ethnic divisions: 78% Greek; 18% Turkishs 4% British,
Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Armenian Orthodox and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Labor force: 267,000 (1970 est.), 38% agriculture, 23% industry, 9% commerce,
2% mining, 28% other; 3,130 registered unemployed (December 1968)
Organized labor: 24% of labor force
Population: 14,688,000, average annual growth rate 0.7%
(current)
Ethnic divisions: 65.0% Czechs, 29.2% Slovaks, 4.0% Magyars,
0.6% Germans, 0.5% Poles, 0.4% Ukrainians, 0.3% others
(Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant, 2% Orthodox,
1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.1 million; 18% agriculture, 37% industry, 11% services, 34%
construction, communications and others
ve SAUDID SE
GYPE araaia
othe
Population: 3,020,000, average annual growth rate 2.7%
(8/68-8/72)
Ethnic divisions: 99% Africans (42 ethnic groups, most important being Fon, Adja,
Yoruba, Bariba), 5,500 Europeans
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most common vernaculars in south,
at Teast 6 major tribal languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture; 15% civil service,
artisans, and industry
Organized labor: approximately 75% of wage earners, divided among two major
and several minor unions','4b2cc7fbd2c8cd7d40b4411ef255dc308080d2386f00efb5a3234352b3809176','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea3120b2588b9dcfdf5e2b4307f07012cfe3f8aecb9d5e43c23bf205aa6f32cc',1974,'DK','Denmark','people-and-society',97,'Population: 5,043,000, average annual growth rate 0.4%
(current)
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant and Roman Catholic, 1%
other
Language: Danish; small German-speaking minority
Literacy: 99%
Labor force: 2.4 million; 14.5% agriculture, forestry, fishing, 29.4% mining and
manufacturing, 8.1% construction, 15.0% commerce, 6.6% transportation and
communications, 23.6% services, 0.2% other; 3.7% unemployed
Organized labor: 65% of labor force','5498f5f74a0a9e4bd1e1f6c1333708f9051669ac38464107245a96892b8749fc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c13471356151066fcaa6cb7753abfec29f8fbb48bc38ff2e61c5f2e2e9005b7d',1974,'CO','Colombia','people-and-society',101,'Population: 75,000, average annual growth rate 1.6%
(4/60-4/70)
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist
Language: English; French patois
Literacy: about 80%
Labor force: est. at 23,000 in 1960; about 50% in agriculture
Organized labor: 25% of the labor force
Population: 97,000, average annual growth rate 0.6%
(4/60-4/70)
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects; Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 27,314 (1960); 40% agriculture, 30% unemployed or underemployed
Organized labor: 33% of labor force','b2d2edb6f90ec3986a246d02f28b4b69c986683095f1fd69650bc55b64072e07','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c792d35037a60c8fa65f7118f200033d27fa59a719571d005e35d44f4bf75ae',1974,'DO','Dominican Republic','people-and-society',106,'Population: 4,562,000, average annual growth rate 2.9%
(7/69-7/71)
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 35% to 40% of adult population
Labor force: 1.3 million; 73% agriculture, 8% industry, 19% services and other
Organized labor: 12% of labor force','5a600e27f81139a0b5567f83aa2b6de8b9cecee4f3b6b5db2bcee09021eb7f23','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61756e4deb99229f4eea1cada353f2f8bb647d31e40c1d2de17183a9c842b03b',1974,'EC','Ecuador','people-and-society',110,'Population: 6,951,000 (excluding nomadic Indian tribes),
average annual growth rate 3.4% (7/72-7/73)
as divisions: 40% mestizo, 40% Indian, 10% white, 5% Negro, 5% Oriental and
other
Religion: 95% Roman Catholic (majority nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture, 13% manufacturing, 4%
construction, 7% commerce, 4% public administration, 16% other services and
activities
Organized labor: less than 15% of labor force','8372762678d72e292459f084cbfa6944a4fb20bd389e8d0034decf2eb2325d69','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c547abcc49de257abeb1e9af71aadc2ab1138de2014770f2436885b901c840',1974,'EG','Egypt','people-and-society',114,'Population: 36,418,000, average annual growth rate 2.2% (7/70-7/72)
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek, Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt and other
Language: Arabic official, English and French widely understood by educated
classes
Literacy: around 40%
Labor force: 8 to 12 million; 45% to 50% agriculture, 10% industry, 10% trade
and finance, 30% services and other; serious shortage of skilled labor
Organized labor: 1 to 3 million','a30c0eabc0db4ca24025a72d94363a31ce503eea63759359dce46abc2a864b79','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('447a979325955f7a92b82eb5536957709fcb044073fd4b298e68a8abdc5dbf3b',1974,'SV','El Salvador','people-and-society',118,'Population: 3,920,000, average annual growth rate 3.5%
(5/61-6/71)
Ethnic divisions: 84%-88% mestizo; Indian and white minorities, 6%-8% each
Religion: predominantly Roman Catholic, probably 97%-98%
Language: Spanish
Literacy: 50% of population 10 years of age and over (1973 est.)
Labor force: 1,395,000 (est. 1973); 57% agriculture, 14% services, 14%
manufacturing, 6% commerce, 9% other; shortage of skilled labor and large
pool of unskilled labor, but manpower training programs improving situation
ee oe 3.5% of total labor force; 6.6% of nonagricultural labor force
1972 est.','cef9928444a0daf4b86c914ea98b2b6bfd0da00d205d95015e9152184885acc3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b16d0a8a30e914768bb4b0ae18e260bdaa65abfdbca3848414e51643dc779e5',1974,'GQ','Equatorial Guinea','people-and-society',122,'Population: 312,000, average annual growth rate 1.8%
(7/68-7/69); Rio Muni, 221,000, average annual growth
rate 1.5% (7/68-7/69); Fernando Po, 91,000, average
annual growth rate 2.6% (7/68-7/69)
Ethnic divisions: indigenous population of Province Francisco Macias Nguema
primarily Bubi, some Fernandinos; of Rio Muni primarily Fang; some 300-400
Nigerians, mostly on Fernando Po; Jess than 1,000 Europeans, primarily Spanish
Religion: natives all nominally Christian and predominantly Roman Catholic; some
pagan practices retained
Language: Spanish official language of government and business; also pidgin
English, Fang
Literacy: 12% (est.)
Labor force: most Equatorial Guineans involved in subsistence agriculture','430716e279f155cfb692e0ee0d746e07c29c5d1ee9dbc2ffe76ed13c36382aa2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3da28e0fff80eec702e4408f4aa9ea13ba6b797da18bb577c9b8c2231456344f',1974,'ET','Ethiopia','people-and-society',126,'Population: 27,279,000, average annual growth rate 2.6%
(7/68-7/72)
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%, Sidamo 9%, Shankella 6%,
Somali 6%, Afar 4%, Gurage 2%, other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Muslims, 15%-20% animist, 5% other
Language: Amharic official; many local languages and dialects; English major
foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10% government. military,
and quasi-government
Organized labor: 60,000 registered labor union members
Population: 40,000, average annual growth rate 0.9%
(4/66-11/70)
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faeroese (derived from Old Norse), Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufacturing, transportation,
and commerce','783ff7e22fe1e1a1935ad474197cd242f7d9b1d3a62f719edb198e56e761ccc6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bea06a912b62ee11390aac7602f7d8dd5f36acfd93345f0b7493fd16e7cc816d',1974,'AU','Australia','people-and-society',131,'Population: 561,000, average annual growth rate 1.8%
(7/72-7/73)
Ethnic divisions: 42% Fijian, 50% Indian, 8% European,
Chinese and others
Religion: Fijians mainly Christian, Indians are Hindu with a Muslim minority
Language: English and Fijian (official), Hindustani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no breakdown on remainder
Organized labor: about 50% of labor force organized into 22 unions; unions
organized along lines of work, breakdown by ethnic origin causes further
fragmentation
Population; 127,175,000 (including West Irian), average
annual growth rate 2.3% (7/67-7/72)
Ethnic divisions: 45% Javanese, 14% Sundanese, 7.5% Madurese, 7.5% Coastal Malays,
26% other
Religion: 90% Muslim, 4% Christian, 2% Buddhist, 2% Hindu, 2% other
Language: Indonesian (modified form of Malay) official; English, and Dutch
leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 41 millions 70% agriculture, 15% industry, 15% miscellaneous and
unemployed
Organized labor: 10% of labor force
Population: 32,222,000, average annual growth rate 3%
(1/71-1/72)
Ethnic divisions: 63% Ethnic Persians, 3% Kurds, 13% other Iranian, 18% Turkic,
3% Arab and other Semitic, 1% other
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2% Zoroastrians, Jews, Christians
and Baha''is
Language: Farsi (Persian), Turki, Kurdish, Arabic
Literacy: about 33% of those 10 years of age and older (1972 est.)
Labor force: 7.5 million; 47% agriculture, 53% industry, commerce and services;
shortage of skilled labor substantial
Organized labor: 1.1% of labor force
Population: 10,663,000, average annual growth rate 3.4%
(10/72-10/73)
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7% Assyrians, 2.4% Turkomans,
7.7% other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry, 6.7% government,
16.8% other; rural underemployment high, but not serious because low
subsistence levels make it easy to care for unemployed; severe shortage
of technically trained personnel
Organized labor: 11% of labor force
Population: 2,728,000, average annual growth rate 2.8%
(7/66-7/72)
Ethnic divisions: predominantly Melanesian and Papuan, some Negrito, Micronesian,
and Polynesian types
Religion: over one-half of population nominally Christian (490,000 Catholic,
320,000 Lutheran, other Protestant sects); remainder animist
Language: 700 indigenous languages; pidgin English and 2 or 3 native languages
are linguae francae for over one-half of population; English spoken by
1% to 2% of population
Literacy: 1%; in English, 0.1%
Labor force: no available figures; mostly subsistence farmers
Population: 648,000, average annual growth rate 1.7%
(12/60+-12/70}
Ethnic divisions: 95% indigenous Timorese belonging to the Malay racial group;
9 ethnic divisions, each speaking a distinct dialect of Malay structure;
approx. 4,600 Chinese and 10,000 halfcastes
Religion: 17% Christian (almost equally divided between Catholic and
Protestant), remainder practice animism
Language: an estimated 9-15 dialects, of Malay origin but mutually unintelligible;
75% of the population speaks the Tetum dialect
Literacy: rate of literacy is unknown, but is very low; in 1971 total school
enrol Iment was 35,000 out of total school-age population of 80,000; 5% of
natives can speak Portuguese
Labor force: 90% engaged in primitive village subsistence economy, 10% engaged
as town laborers and domestics','486c7ab46f34d34207d50115ac4a56668c50be505080f7ab79a857afcc7732db','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e83969fa97798f3fd59bb851dd869ddfa8b5abbdda99ef980685b9d7575886a6',1974,'FR','France','people-and-society',138,'Population: 52,638,000, average annual growth rate 0.9%
(7/68-7/73)
Ethnic divisions: 45% Celtic; remainder Latin, Germanic,
Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1% Muslim (North African
workers), 11% unaffiliated
Language: French (100% of population); rapidly declining regional patois --
Provencal, Breton, Germanic, Corsican, Catalan, Basque, Flemish
Literacy: 97%
Labor force: 21,200,000 (1972 est.); 47% services, 39% industry, 12% agriculture,
2% unemployed
Organized labor: 17% of labor force, 23.4% of salaried labor force
Population: 352,000, average annual growth rate 0.6%
(1/66-1/73)
Ethnic divisions: 83% Luxembourger, including an estimated
5% of Italian descent; remainder French, German,
Belgian, etc.
Religion: 97% Roman Catholic, remaining 3% Protestant
and Jewish
Language: Luxembourgish, German, French; most educated Luxembourgers also speak
English
Literacy: 98% :
Labor force: (1972) 151,400; 10% agriculture (including forestry and fishing),
48% industry, 42% services, no significant unemployment; 27% of labor force
is foreign, comprising workers from neighboring areas of Belgium, France,
and West Germany, as well as Italy and Portugal
Organized labor: 45% of labor force','97445a186326baac647eea131c931f1945eac9316c6a572016b98b4effa3acf5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba8f76a86bd3b6a1e1d0346ddb780e384c5c49f23035ea1e01d0077439fc5989',1974,'GF','French Guiana','people-and-society',142,'Population: 54,000, average annual growth rate 2.7%
(7/68-7/71)
Ethnic divisions: 95% Negro or mulatto, 5% caucasian, 10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%, construction 21%, agriculture
18%, industry 8%, transportation 4%; information on unemployment unavailable
Organized labor; 7% of labor force','7527e6594c751cec9c73f7bddde50bbb7a1bdcf4117a601ef70517f0a8d31c67','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7c5a2fb32ac074297849066d93db75ba2b2ab813bdfea727ae813fd204947b3',1974,'PF','French Polynesia','people-and-society',146,'Population: 137,000, average annual growth rate 4.2%
(11/62-2/71)
Ethnic divisions: 78% Polynesian, 12% Chinese, 6% local
French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 32% Catholic
Population: 125,000 (official estimate for 1 July 1967)
Ethnic divisions: 59,350 Somalis (large number of the
Somalis are temporary immigrants from Somalia, not
citizens of territory), 53,650 Afars, 6,000 Arabs, 7,000 French (inclusive
of French military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely used
Literacy: about 5%
Labor force: a smal] number of semiskilled laborers at port
Organized labor: some 3,000 railway workers organized','2e6db174bd65ef1bbdcd665a95b2bd858337cce01d0023aa050fef3741131a65','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7d60ef88426f00f21cad408916bb3bb2ecaf36d6f143929d6056a58b2ca2476',1974,'GA','Gabon','people-and-society',150,'Population: 534,000, average annual growth rate 1.7%
(7/66-7/70)
Ethnic divisions: about 40 Bantu tribes, including 4
major tribal groupings (Fang, Eshira, Mbede, Okande); about 21,000 expatriate
Africans and Europeans, including 14,000 French
Religion: 55% to 75% Christian, less than 1% Muslim, remainder animist
Language: French official language and medium of instruction in schools; Fang
is a major vernacular language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are wage earners in the modern sector
Organized labor: less than 30% of wage labor force','6468d49d1e5f77c101cf18dcac7ad0640444effaf0c4194a67d9b624e80e84c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0bda5f6a1899dcf082abe8335cf667269e4e8589e762f830df3c6783817e210',1974,'GM','Gambia','people-and-society',154,'Population: 507,000, average annual growth rate 2.2%
(7/66-7/72)
Ethnic divisions: over 99% Africans (Malinke 40.8%, Fulani 13.5%, Wolof 12.9%,
remainder made up of several smaller groups), fewer than 1% Europeans and
Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Malinke and Wolof most widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in subsistence farming; about
15,000 are wage earners (government. trade, services )
Organized labor: 25% to 30% of wage labor force at most
Population: 16,916,000 (including East Berlin), average
annual growth rate -0.4% (current)
Ethnic divisions: 99.7% German, .3% Slavic and other
Religion: 53% Protestant, 8% Roman Catholic, 39% unaffiliated or other; less than
5% of Protestants and about 25% of Roman Catholics actively participate
Language: German, small Sorb (West Slavic) minority
Literacy: 99% j
Labor force: 8.2 million; 34.1% industry; 4.7% handicrafts; 6.8% construction;
11.9% agriculture; 6.8% transport and communications: 10.1% commerce; 16.8%
services; 2,5% other
Organized labor: 87.7% of total labor force','9e7f6f0c5e0f54e1d22c9a1e68ad3515d7be30e6031a52a652aa6c46f7065ed1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e52c5373a0ee2b3016a751d8fec3f7393488032b15fa3548422e1dd65dd032a',1974,'GH','Ghana','people-and-society',158,'Population: 9,563,000, average annual growth rate 2.6%
(7/71-7/72)}
Ethnic divisions: 99.8% Negroid African (major tribes Ashanti, Fante, Ewe),
0.2% European and other
Religion: 45% animists, 43% Christian, 12% Muslim
Language: English official; African languages include Akan 44%, Mole-Dagbani 16%,
Ewe 13%, and Ga-Adangbe 8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing, 16.8% industry, 15.2%
sales and clerical, 4.1% services, transportation, and communications,
2.9% professional; 400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor force','969159017bff79c5e96ade78960620f8f640d4cb7deee7e2a5c096611017311e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c735673553d6b7d28b41092aaa4380e6fa33c247e6df3a2b3560ab36b675c198',1974,'GI','Gibraltar','people-and-society',164,'Population: 60,000, average annual growth rate 1.9%
(7/63-7/70)
Ethnic divisions: 83.9% Micronesian, 13.9% Polynesian,
0.9% European, 0.1% Chinese, 1.2% mixed and other races
Religion: mainly Christian; 55% Protestants, 42% Catholics
Literacy: less than 50%','dd29a42e57e2925dc3eb05cb03bea7f3a1b154e4787c5a426430f5dea3a66c4a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80787ecfb36fe96f282cf0e79186818156a1ce4881b95b8c1707012e60cd53b5',1974,'GR','Greece','people-and-society',166,'Population: 8,995,000, average annual growth rate 0.4%
(3/61-3/71)
Ethnic divisions: 96% Greek, 2% Turkish, 1% Albanian, 1% other
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total about 82%
Labor force: 3,866,000 (1969 est.); 50% agriculture, 15% industry, 9% trade,
26% other; unemployment and underemployment, 20% total in all fields;
shortage of skilled labor in nonagricultural sectors aggravated by large-
scale emigration
Organized labor: 10% of labor force','8b4e3447cb23501a0e8b4e10942e717e65968c2e162bccf1cffc3e9ec1dd51e2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02c50f415cc5132643bb8e62494595c9a045824a3aad8ceb263afc0a820bb844',1974,'GL','Greenland','people-and-society',170,'Population: 52,000, average annual growth rate 3.0%
(1/71-1/72)
Ethnic divisions: 86% Greenlander (Eskimos and Greenland-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep breeding','d5995a3282fee5fb7ccdb97fe2075e998cb7fccf60586f16d7792690cffc4231','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0e0de40267bfeda711920dd5e66a9c45eac74a5c901e6405ec0f0a2fa1f8e3f',1974,'GP','Guadeloupe','people-and-society',175,'Population: 347,000, average annual growth rate 1.5%
(7/69-7/71)
Ethnic divisions: 90% Negro or Mulatto, less than 5% East
Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force','6e98345d7dd4626695386551fe3d084a6e5385d2b5ca89b0640894d8a3ab642c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d21a76bb0c2d209593fc63e9da8a91d0d5a95d8eaa0f9dd3df600029b85de575',1974,'GN','Guinea','people-and-society',181,'Population: 4,311,000, average annual grow rate 2.5%
(current)
Ethnic divisions: 99% African (3 major tribes - Fulani,
Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less than 1%
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written language
Labor force: 1.8 million, of whom less than 10% are wage earners; most of
population engages in subsistence agriculture
Organized labor: virtually 100% of wage labor force loosely affiliated with the
National Confederation of Guinean Workers, which is closely tied to the PDG','1f980b49b1f2da2218e1149742ce8b3a4155b82772c22111c7260db51a000b1e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3ac84c3b68f98a8d582407b9ffcdf6bb5dea23439074eabceb2d03a0be055cc',1974,'HN','Honduras','people-and-society',186,'Population: 2,835,000, average annual growth rate 2.7%
(7/68-7/72)
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 57.4% of persons 10 years of age and over (est. 1970)
Labor force: approx. 900,000 (est. mid-1972); 66% agriculture, 12% services, 8%
manufacturing, 5% commerce, 6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-1972)','f25e34f49ac36aba4887e0abfc058f1f4a13cacbf4e441b2ac81062dedd8bac1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('452872a27b22494a3606ab28624c4c64f037578ee7e037a80980cf98aca8f608',1974,'HK','Hong Kong','people-and-society',188,'Population: 4,229,000, average annual growth rate 1.7%
(7/70-7/73)
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local religions
Language: Chinese, English
Literacy: 75%
Labor force (1971 est.): 1.58 million; 43% manufacturing, 20% services, 11%
construction, mining, quarrying and utilities, 13% commerce, 4% agriculture,
forestry, fisheries, and hunting, 7% communications, 2% other; under-
employment is a serious problem
Organized labor: 12% of 1969 labor force','fcfa94f59e8d08eedef08ab23ee454e71c78cc30663f8b20b096da07ea4cd9d2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee2b86dd71e1946c8ff3eb28fca5102062b5484be5ed578a1928c4309f3587bf',1974,'HU','Hungary','people-and-society',192,'« Population: 10,451,000, average annual growth rate 0.3%
(current)
Ethnic divisions: 93.3% Magyar, 2.5% German, 2.4% Gypsy,
0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20.0% Calvinist, 5.0%
Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5 million (1 January 1971); 26% agriculture, 44% industry and
building, 30% other nonagricultural','754130f33666111dbd0a4e856d860fb62746bad37342ba3538a736b4d8f03c80','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e828326f1ba5d3e673e40b30e2dea8b72dafd732c9b40eb3b1c5e549613ea7d2',1974,'IN','India','people-and-society',196,'Population: 588,733,000 (including the Indian-held part of disputed Jammu-Kashmir),
average annual growth rate 2.2% (7/65-7/72)
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.6% Christian, 0.7% Buddhist,
0.7% other
Language: 24 languages spoken by a million or more persons each; numerous
other languages and dialects, for the most part mutually unintelligible;
Hindi is the national language and primary tongue of 30% of the people;
English enjoys "associate" status but is the most important language for
national, political, and commercial communication; Hindustani, a popular
variant of Hindi/Urdu, is spoken widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29% (1971 census)
Labor force: about 184 million; 70% agriculture, more than 10% unemployed and
underemployed; shortage of skilled labor is significant and unemployment is
rising
Organized labor: about 2.5% of total labor force','41cc0b16d3957696322455c714ee6509bd4097a8266d823c4c238b0185533b1e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d924c69fd98e5021c6f7c91982322da4956f084351c20c60f9d354292aa3619',1974,'IT','Italy','people-and-society',202,'Population: 55,254,000, average annual growth rate 0.7%
(1/66-1/73)
Ethnic divisions: primarfly Italian but population includes small clusters of
German-, French-, and Slovene-Italians in the north and of Albanian-Italians
in the south
Religion: almost 100% nominally Roman Catholic (de facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region (e.9., Bolzano) are
predominantly German speaking; significant French-speaking minority in Valle
d''Aosta Region; Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5%-7% of population illiterate (1972); illiteracy varies widely by region
Labor force: 19,019,000 (April 1972); 17.7% agriculture, 42.5% industry, 36.5%
other, 3.3% unemployed; underemployment, particularly in southern Italy,
remains widespread; 1.5 mtllion Italians employed in other Western European
countries
Organized labor: 20% (est.) of labor force
Population: 5,262,000 (resident African population only),
average annual growth rate 3.3% (1/66~1/71)
Ethnic divisions: 7 major indigenous ethnic groups; no single tribe more than
20% of population; most important are Agni, Baoule, Krou, Senoufou, Mandingo;
approx. 1 million foreign Africans, mostly Voltaics; about 33,000 non-Africans
(25,000 French)
Religion: 66% animist, 22% Muslim, 12% Christian
Language: French official, over 60 native dialects, Dioula most widely spoken
Literacy: about 20%
Labor force: over 85% of population engaged in agriculture, forestry, livestock
raising; about 11% of labor force are wage earners, nearly half in agricul -
ture, remainder in government, industry, commerce, and professions
Organized labor: 20% of wage labor force','bd2c951fbb238f0ea913cc9b954dcc8a5a63960793c8fcec26d2a25ba87dff77','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3a3e9062d0e2eb1b56c84804957461cfe08a775d694e4da32c805aa76e65824',1974,'JO','Jordan','people-and-society',209,'Population: 2,,611,000 (including West Bank and East Jerusalem), average annual
growth rate 3.6% (11/72-11/73)
Ethnic divisions: 98% Arab, 1% Circassian, 1% Armenian
Religion: 95% Sunni Muslim, 5% Christian
° Language: Arabic official, English widely understood among upper and middle
classes
Literacy: about 40% in East Jordan; somewhat less than 50% in West Jordan
Labor force: 564,000; 33% unemployed
Organized labor: 5% of labor force','70ce0ea3911a526aa805c3912c3a662b9ad37fa303b87c096ed9e1a99f05f20f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0672c4e492231eeee5a528310cc32f07ef38a5548481db637fdd1037163bb13',1974,'KE','Kenya','people-and-society',213,'Population: 12,911,000, average annual growth rate 3.4%
(7/72-7/73)
Ethnic divisions: 97% native African (including Bantu, Nilotic, Hamitic and
Nilo-Hamitic); 2% Asian; 1% European, Arab and others
Religion: 56% Christian, 36% animist, 7% Muslim, 1% Hindu
Language: English and Swahili official; each tribe has own language
Literacy: 27%
Labor force: 2.5 millions about 977,000, (39%) in monetary economy (1967)
Organized labor: about 215,000
Population: 16,005,000, average annual growth rate 3.1%
(current)
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 47.7% agriculture, 52.3% non-agricultural; shortage of
skilled and unskilled labor
Population: 33,451,000, average annual growth rate 1.7%
(7/71-7/72)
Ethnic divisions: homogeneous; small Chinese minority
(approx. 20,000)
Religion: strong Confucian tradition; pervasive folk religion (Shamanism);
vigorous Christian minority (5.5% of population); Buddhism (including
estimated 20,000 members of Soka Gakkai)
3 Chondokyo (religion of the heavenly
way), eclectic religion with nationalist overtones founded in 19th century,
claims about 1.5 million adherents
Language: Korean
Literacy: about 90%
Labor force: about 10.2 million (1971); 46.2% agriculture, fishing, forestry,
32.3% services, 14% mining and manufacturing, 3% construction, 4.5% unemployed
Organized labor: about 10% of nonagricultural labor force
Population: 930,000, average annual growth rate 5.4%
(7/72-7/73)
Ethnic divisions: 87% Arabs, 12% Iranians, Indians, and Pakistani, 1% other
Religion: 95% Muslim, 5% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign language
Literacy: about 55% 71968)
Labor force: 250,000 (1969); 9% manufacturing, 16% construction, 45% services,
13% commerce
Organized labor: labor unions, first authorized in 1964, formed in of] industry
and among government personnel','d2c2cc06bc7bf9d03123215ffb7324b7589386393451b530dc3e984b42cc1226','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5823cbf296ca066f89d9e12cc848732f9b51939cc4b5a53a9ad3a6a67cbfb71d',1974,'DE','Germany','people-and-society',218,'Population: 3,257,000, average annual growth rate 2.4%
(7/71-7/72)
Ethnic divisions: 47% Lao; 14% Tribal Tai; 25% Phoutheung
(Kha); 14% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant foreign
language also used in administration
Literacy: about 12%
Labor force: about 1,268,000; 80%-90% agriculture; 159,286 engaged in
manufacturing and services; 11,864 government employees
Organized labor: only civil servants are organized','5e92c9e1a8de55b7797c4a392237192351068fe2e279cdb0c50d6c5bac822aa0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af8de148c27d4237d8eced76e73eeb3cb9dfbac910b6f1508b9edbb807f20e6f',1974,'LB','Lebanon','people-and-society',221,'Population: 3,149,000 (including Lebanese nationals living
outside the country who are on the population register,
but excluding registered Palestinian refugees numbering
188,000 on 30 June 1973), average annual growth rate 3.1% (current)
Ethnic divistons: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1% other (official astimates);
Muslims believed to constitute slight majority
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically active; 49% agriculture, 11% industry,
14% commerce, 26% other; moderate unemployment
Organized Tabor: about 65,000','ca04026d28801935b7516c86d5320514328bd93ba4d451df8b6dc2b42ba890f6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07b24eea1be8538c629d6a0470b7c91845f9525fe4e6cc3ad3289d1c4d5970b1',1974,'LS','Lesotho','people-and-society',225,'Population: 1,016,000, average annual growth rate 2,3%
(7/72-773)
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800 Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in
subsistence agriculture; 150,000 to 250,000 spend 6 months to many years
as wage earners in South Africa
Organized labor: negligible','0ec94403f86693b7324a4e396eb9288e62644a0de2a95f69c832534d22ee4aa1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('260b097ac723f39fbd264986285c4654e723c7db1414aa37a8c0d03d7ef21b3d',1974,'LR','Liberia','people-and-society',229,'Population: 1,712,000, average annual growth rate 2.9%
(current)
Ethnic divisions: 5% coastal descendants of immigrant
Negroes; 95% indigenous Negroid African tribes including Gola, Kissi, Vat,
Kpelle, Kru, and Mandingo
Religion: probably more Muslims than Christians; 70%-80% animist
Language: English official; 28 tribal languages or dialects, pidgin English used
by about 20%
Literacy: about 24% over age 5
Labor force: 500,000, of which 150,000 are in modern economy; about 2,000 non-
African foreigners hold about 95% of the top level management and
engineering jobs
Organized labor: 2% of labor force','988cfea407498c7aabd65caa98de10c663a8c30d6115250d92f01bea1852aeb1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9564fb5a1ff4e45d499629aa9aab1bda1013fb18a12be1e56627ebd808e530f9',1974,'LY','Libya','people-and-society',233,'Population: 2,241,000, average annual growth rate 3.7% (7/72-7/73)
Ethnic divisions: 97% Berber and Arab with some Negro stock; some Greeks, Maltese,
Jews, Italians, Egyptians
Religion: 97% Muslim
Language: Arabic; Italian and English widely understood in major cities
Literacy: 35%
Labor force: 485,000; between ages 15-64, 405,000-430,000; 61% of labor force
in agriculture (1964)','f54ac348b4698519e3fadd74801c0e3af0510b60ee194e95cf1ba8233cd22fa7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('114fde60ef2605f3cf8437f65b56773c49e24c11777b1819ce5e657aa294d69c',1974,'LI','Liechtenstein','people-and-society',237,'Population: 23,000, average annual growth rate 2.5%
* (12/60-12/70)
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly from
Austria and Italy); 59% industry, 20% trade and
commerce, 13% professional and other, 8% agriculture','79da6f3b1b658baf1979b65f465f0ffab4b62cc16d79d4fb34e9eb314d188825','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dadc0aeb5149cb7f2e26da957dfc30f34d045f8f574a4e54ebb8394d45a3fe5',1974,'MO','Macao','people-and-society',242,'Population: 249,000 (census of 15 December 1970)
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about one-half are Chinese
Language: Chinese 98%, Portuguese 2%
Literacy: almost 100% among Portuguese and Macanese; no data on Chinese
population
Labor force: 5% agriculture, 30% manufacturing, 3% construction, 1% utilities,
27% commerce, 8% transportation and communications, 26% services (1960 data)','1721552cce97298f446b41807e36758bf5676916272797f73f622f211bf64e9f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5255582032b9a84775c0268b15976e146fdb54adfa24be544842e7e6c08cd025',1974,'MG','Madagascar','people-and-society',246,'Population: 7,385,000, average annual growth rate 2.3%
(7/69-7/70)
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting
of Merina (1,643,000) and related Betsileo (760,000), on the one hand, and
coastal tribes with mixed Negroid, Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include Betsimisaraka 941,000, Tsimihety 442,000,
Sakalava 375,000, Antaisaka 415,000; there are also 38,000 French, 66,000
other
Religion: more than half animist; about 41% Christian, 7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are nonsalaried family workers
engaged in subsistence agriculture; of 175,000 wage and salary earners,
26% agriculture, 17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscellaneous
Organized labor: 4% of labor force','f6111a24ed5342d7faa57e5d0b9219f9066e009ca0b3004a8bd2534799f9c1e4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6c39d0734a6f33457c42d54b9f248a9b213d92228eb2399f25ccb7d176cda01',1974,'MW','Malawi','people-and-society',250,'Population: 4,903,000, average annual growth rate 2.5%
(7/71-7/72)
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is second
African language
Literacy: 6% of population over 27 years old
Labor force: 180,000 wage earners employed in Malawi (1971); 6,000 Europeans
permanently employed; 300,000 Malawians live and work in Rhodesia, South
Africa, and Zambia; 30% agriculture, 11% construction, 10% commerce, 13%
manufacturing, 10% administration, 26% miscellaneous services
Organized labor: small minority of wage earners are unionized','8436a299ddd248eb370aa82aec440a8dc9d8eec27b520d714ed979990ab97211','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21a0b12faa3d6e739216f22ca0f2785f0bfbbbd70c82f5d7bf63edd2f67ab040',1974,'MY','Malaysia','people-and-society',254,'Population: 11,551,000 average annual growth rate 2.7% (current)
West Malaysia: 9,714,000, average annual growth rate 2.6% (6/57-8/70)
Sabah: 754,000, average annual growth rate 3.7% (8/60-8/70)
Sarawak: 7,083,000, average annual growth rate 2.7% (6/60-8/70)
Ethnic divisions:
Malaysia: 44% Malay, 36% Chinese, 9% tribal, 10% Indian and Pakistani,
2% other
West Malaysia: 50.1% Malay, 36.9% Chinese, 11% Indian and Pakistani,
% other
Sabah: 23.1% Chinese, 67.3% indigenous tribes, 9.6% other
Sarawak: 31.5% Chinese, 50% indigenous tribes, 17.5% Malay, 1% other
Religion:
West Malaysia: Malays nearly all Muslim, Chinese predominantly Buddhists,
Indians predominantly Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist. and Confucianist, 16% Christian, 35%
tribal religion, 2% other
Language:
West Malaysia: Malay (official); English, Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dialects, Mandarin and Hakka dialects
predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal languages
Literacy:
’ West Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 3.45 million (1967)
West Malaysia: 2.9 millions; 55% agriculture, forestry, and Fishing, 11%
manufacturing and construction, 34% trade, transport, and services
Sabah: 213,000 (1967); 80% agriculture, forestry, and fishing, 6% manu-
facturing and construction, 13% trade and transportation, 1% other
21]
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
Approved For Release 2008/07/18 : CIA-RDP79-01051A000700010002-8
PEOPLE (cont''d):
Sarawak: 341,000 (1967); 80% agriculture, forestry, and fishing, 6% manu-
facturing and construction, 13% trade, transportation, and services,
1% other
Organized labor: 370,000 (official 1967 est.) about 10.5% of total labor force;
28% of wage labor force; unemployment about 8% of total
labor force, but higher in urban areas','08a6c18898bec81713b31a669d34f3ed8fb04317b50de183931a5418a4fb3302','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a697c972303509bd4f08b47d627a584d84f3ba566a80955233a0f36c8d99059',1974,'MV','Maldives','people-and-society',258,'Population: 117,000, average annual growth rate 2% (current)
Ethnic divisions: admixtures of Sinhalese, Dravidian, Arab and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the male population','e11343631f61e50d63a36840570b805b44ea11c3c01c360b0a7fb42cf0f8620e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de06903713ac19f9859d1f7defdb1aaee2bb4156e69649761f7fc96aa2f9d38c',1974,'ML','Mali','people-and-society',262,'Population: 5,498,000, average annual growth rate 2.3%
(7/72-7/73)
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French offictal; several African languages ,
of which Mande group most widespread
Literacy: under 5% F
Labor force: approximately 100,000 salaried, 50,000 of whom are employed by the
government; most of population engaged in agriculture and animal husbandry
Organized labor: UNTM, which claimed all eligible employees, dissolved; thirteen
national unions currently directed by a government controlled Coordination
Committee of Mali Trade Unions (CCSM)','f3e39b98e3b0fa20226448a043617aa495eef1c9cb8d13c2b62d340c1d4b2750','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0242111761b68d7b0b2bc5b8577d5042bdaf50b9fe5668bf8470fbff198cb736',1974,'MT','Malta','people-and-society',268,'Population: 319,000 (official estimate for 30 September 1973)
Ethnic divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in 1946
Labor force: 111,000; 33% services, 20% government, 21% manufacturing, 7%
agriculture, 6% unemployed
Organized labor: approximately 35% of labor force','141d287d6fdb2a17d1fe863e1765704a80e3d3d3cfcd61498df136b582df52de','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85e802d66272d2db162deb545f54cb284dc75505e1045d1644eeb7f6cb049e03',1974,'MC','Monaco','people-and-society',272,'Population: 24,000 (official estimate for 1 July 1972)
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
Literacy: almost complete','902050e2661f8b31fd422cf135ac024f2c96cbb46b78c52c3221bfea2e2ca654','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('186fe7257616514d7a2227b7b20d61939d3287b174aaa5439ad2edd59b9018bf',1974,'MN','Mongolia','people-and-society',276,'Population: 1,400,000, average annual growth rate 3%
(current)
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese, 2%
Russian, 2% other
Religion: predominantly Tibetan Buddhist, about 4% Muslim,
limited religious activity because of Communist regime
Languages: Khalkha Mongol used by over 90% of population; minor languages
include Turkic, Russian, and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the population is in the labor
force, including a large percentage of Mongolian womens; acute shortage of
both skilled and unskilled labor {no reliable information available)','cbf213af619359c72c5cd2d0f535a5d7c18a75a190a0c0c962997bbf1985fb29','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b151158a653aea3331d145d5b8ef5209d68b8fd4a4dcb9c2ce6da814156bf671',1974,'MA','Morocco','people-and-society',278,'Population:
(current)
Ethnic divisions: 99.1% Arab-Berber, .2% Jewish, .7% non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2% Jewish
Language: Arabic (official); several Berber dialects;
business, government, diplomacy, and postprimary ed
Literacy: 20%
Labor force: 6.3 million (1971 est.)
civil service, transportation,
workers, 10%
Organized Jabor:
Workers (UMT)
16,731,000, average annual growth rate 2,9%
French is language of much
ucation
69% agriculture, military, police,
mines, teachers, merchants, construction
industry and mining, 10% commerce and government
about 5% of the labor force, mainly in the Union of Moroccan
Population: 8,887,000, average annual growth rate 2.2%
(9/60-12/70)
Ethnic divisions: 97% African, 3% European, Asian, and Mulatto
Religion: 65.6% animist, 21.5% Christian, 10.5% Muslim, 2.4% other
Language: Portuguese (official); many tribal dialects
Literacy: 7%-10% (est.)
Labor force: {1963 est.) 610,000; 50,000 non-African wage earners, 560,000
African wage earners in Mozambique; 290,000 additional African wage earners
temporarily working in Rhodesia and South Africa; unemployment serious
problem; most native Africans provide unskilled labor or remain in
subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970); 75% are white','1532277beed256f5866249bb767b8cf922edd4177e0c56c72da8fb84edbb88bf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78ce32ac6e3c4c4b6792d18b6ed8fe8ac8b800d1f453ab7db3baadee51d49406',1974,'NR','Nauru','people-and-society',284,'Population: 7,000 (official estimate for 30 June 1969)
Ethnic divisions: 2,921 Nauruans, 1,167 Chinese, 428
Europeans, 1,532 other Pacific Islanders
Religion: Christian (2/3 Protestant, 1/3 Catholic)
Language: Nauruan, a distinct Pacific Island tongue; English, the language of
school instruction, spoken and understood by nearly all
Literacy: nearly universal','6d63eac3676a74f143d0c1b303834669d5885fcbdd08a56096dcfc82f624ab6e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9059636523c0c5818f89f9ff70da45a1408929f2a0c2962350374d83df51fda3',1974,'NP','Nepal','people-and-society',288,'Population: 12,296,000, average annual growth rate 2.1%
(6/61-6/71)
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%),
representing considerable intermixture of Indo-Aryan
and Mongolian racial strains; country divided among
many quasi-tribal conmuni ties
Religion: only official Hindu Kingdom in world, although no sharp distinction
between many Hindu and Buddhist groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided into numerous dialects;
Nepali official language and lingua franca for much of the country; same
script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5% industry; great lack of skilled
labor','715bb6d8a63ef6347a16a5851d4c3255c0d86008a99ddb03045376a58d2c843f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8a85df1dc2a2c39e338ab5d88b9f66c004f540c25c0c7bf8086da3388fb24d7',1974,'NL','Netherlands','people-and-society',292,'Population: 13,523,000, average annual growth rate 0.6%
(current)
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 41% Protestant, 40% Roman Catholic, 19% unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24% services, 16% commerce, 10%
agriculture, 9% construction, 7% transportation and communications, 4%
other; average unemployment rate 3% (Jan.-Aug. 1973); no shortage of skilled
labor but shortage of semi-skilled labor; 129,000 unfilled vacancies reported
by employers in January 1971
Organized labor: 33% of labor force
Population: 236,000, average annual growth rate 1.6%
(1/71-1/73)
Ethnic divisions: 85% largely mixed Negro stock except on
Aruba where 12% Negro and approx. 55% mixed Carib
Indian and European; rest European with some Chinese,
especially on Aruba
Religion: predominantly Roman Catholic; sizable Protestant, smaller Jewish
minorities
Language: officially Dutch; predominantly English; colloquial "papiamento," a
Spanish~Portuguese-Dutch-English mixture
Literacy: 75%-80%
Labor force: 66,000; 1% agriculture, 21% industry, 21% unemployed, 8%
construction, 41% government and services, 8% other
Organized labor: approx. 15% of labor force','359dd48c4a68a369d6104d78824a711f4d6249f66f1f145a38614360b1dfbb88','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb7b499e3cf66e940a99ffe35d11173c149144c1cbb08353306ff4ded6417b74',1974,'NC','New Caledonia','people-and-society',296,'Population: 126,000, average annual growth rate 3.6%
(7/70-7/72)
Ethnic divisions: Melanesian-Polynesian admixture, over
28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese laborers were imported for
plantations and mines in pre-World War IT period; immigrant labor now
coming from Wallis Islands, New Hebrides, and French Polynesia
Organized labor: unorganized
Population: 90,000, average annual growth rate 2.3%
(7/66-7/71)
Ethnic divisions: 92% indigenous Melanesian, 3% European,
remainder Vietnamese, Chinese, and various Pacific
Islanders
Religion: most at least nominally Christian
Literacy: probably 10%-20%','fc9497db00c1d0f34c77b928b0d17d47a6dde86a091679c4d801efc060d28f4d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd38d74a4cc94a1588eaad7d1b38bc7b4dd71d5e143b5c18643f1e8663a58d07',1974,'NI','Nicaragua','people-and-society',300,'Population: 2,123,000, average annual growth rate 3.3%
(4/71-7/72)
Ethnic divisions: 75% mestizo, 15% white, 10% Negro, Indian or mulatto
Religion: 95% Roman Catholic
Language: Spanish (official); small English-speaking minority on Atlantic coast
Literacy: 50% of population 10 years of age and over
Labor force: 620,000 (1974 est.); 50% agriculture, 12% manufacturing, 14%
services, 24% other; shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: about 2.5% of labor force','190a9710063d22e8ad12933ab68ffce44d5e847c33bdd9ccdfeab9616c7557d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('899039da9965c1774f497a6b9ea5c4a8aa89eaca057ba6604c2521e198149cef',1974,'NE','Niger','people-and-society',304,'Population: 4,397,000, average annual growth rate 2.2%
(7/72-7/73)
Ethnic divisions: main Negroid groups 75% (of which, Hausa
50%, Djerma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a
very few Christians
Language: French official, many African languages; Hausa used for trade
Literacy: about 5%
Labor force: 26,000 wage earners; bulk of population engaged in subsistence
agriculture and animal husbandry
Organized labor: negligible','1b0fb43e9206fc4377da93ad349ff34f075ad88132f3ffc7d38eb4f8482e3aa1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a27a2075447589b9aed00a94d639a6f98ac985a23f6d92783e6c3bc4600726e3',1974,'NG','Nigeria','people-and-society',308,'Population: 61,275,000, average annual growth rate
2.8% (current)
Ethnic divisions: 250 tribal groups, of which most important are Hausa-Fulani
(north), Ibo and Yoruba eouthye these 3 tribes total over 60% of population;
about 27,000 non-Africans
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est, 25%
Language: English official; Hausa, Yoruba, and Ibo also widely used
Labor force: approx. 22.5 million; about 41% of total population; roughly
1.3 million wage earners, of whom 560,000 work in modern enterprises
Organized labor: about 530,000 wage earners, approx. 2.4% of total labor force,
belong to some 700 unions','1b27c7a429bd81e9f0a4edb6de025564230d520802ecfccc4b9337f86fc06801','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('711db000cbd3bd9d9e83e0f85a99a4642f5cd3946b1e3c65a046bb2567875648',1974,'NO','Norway','people-and-society',312,'Population: 3,990,000, average annual growth rate 0.7% (7/72-7/73)
Ethnic divisions: homogeneous white population, small Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant and Roman Catholic, 1%
other
Language: Norwegian, small Lapp and Finnish-speaking minorities
Literacy: 99%
Labor force: 1.6 million; 19.5% agriculture, forestry, fishing, 27.0% mining and
manufacturing, 9.5% construction, 13.3% commerce, 11.9% transportation and
communication, 17.7% services; 1.0% unemployed
Organized labor: 60% of labor force','6fbe63f101eba2844726f1b0c543f9ca2e661b79746291ba0ec3093861b3c4d5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('219752bd18cb34c40ecfd29266bd075b511ab97b782d2b0ebf3527f4400fabe1',1974,'OM','Oman','people-and-society',316,'Population: 483,000, average annual growth rate 2.9%
(current)
Ethnic divisions: almost entirely Arab with small groups
of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low
Population: 68,119,000 (excluding Junagardh, Manavadar, Gilgit, Baltistan, and
the disputed area of Jammu-Kashmir), average annual growth rate 2.7% (current}
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages -- 7% Urdu, 64% Punjabi, 12%
Sindhi, 8% Pushtu, 9% other; English is lingua franca
Literacy: about 14%
Labor force: 12.7 million (est. 1961); 60% agriculture, 16% industry, 7% commerce,
15% service, 2% unemployed
Organized labor: 5% of labor force','98016ae4ea81b4374be38113fded9ef663cd8b1cbc4c04b53968b043d002431d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4153325f761f12fa21af30ba179dfaac8fcf62577869ca99d09d8592503df154',1974,'PA','Panama','people-and-society',320,'Population: 1,618,000, average annual growth rate 3.1% (7/70-7/71)
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7% Indian and other
Religion: over 90% Roman Catholic, remainder mainly Protestant
Language: Spanish; about 14% speak English as native tongue; many Panamanians
bilingual
Literacy: 82% of population 10 years of age and over
Labor force: 482,200 (1972 est.); 39.5% commerce, finance and services; 33.9%
agriculture, hunting and fishing; 9.7% manufacturing and mining; 6.8%
construction; 5% Canal Zone; 3.9% transportation and communications; 1.2%
utilities; national average of 6.8% unemployed; shortage of skilled labor
but an oversupply of unskilled labor
Organized labor: 8.4% of labor force (1972 est.)','9e921cf2f570b892719219731ed7282ab1bd6d8edb9a0dc9d112feffce7d6209','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c56bcd6d3b368d302fddf21a666fc932db016e653fdb48ed4ffd0c30da441096',1974,'PY','Paraguay','people-and-society',325,'Population: 2,481,000, average annual growth rate 2.7%
(10/62-7/72)
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 800,000 (1971 est.)}; 55% agriculture, forestry, fishing; 8% transport
and other services; 19% manufacturing and construction; 13% commerce and
professions; 5% miscellaneous (est. 1962)
Organized labor: about 5% of labor force','4ea847d94ba1459e6a04ca4130cb56ef8cbf2af3d3a50311c301853dc9af30a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('178582cc084e5234da9d635ff436ce711d469b325d22fe3f36b57c7263a61840',1974,'PH','Philippines','people-and-society',329,'Population: 41,449,000, average annual growth rate 3% (7/67-7/72)
Ethnic divisions: 91.5% Filipino (Malay), 4% Moros (Malay), 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4% Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national language of the Philippine
Republic; English is the language of school instruction and government
business
Literacy: about 83%
Labor force: 11 million; 60% agriculture, forestry, fishing, 12% manufacturing,
10.5% conmerce, 10.5% government and services (business, recreation, domestic,
personal), 3.5% transport, storage, communication, 3% construction; 0.5% other','e26c2471470eb9b1bc1936f446685805af04e510530e0682be67d533f0557101','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cda7e1257e98801ce13dba3e407f302148e909309f46749305b18288dc27d88a',1974,'PL','Poland','people-and-society',333,'Population: 33,653,000, average annual growth rate 0.8%
(current)
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians, 0.5% Belorussians, less than
0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75% practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26% industry, 36% other non-
agricultural
Population: metropolitan Portugal 8,550,000, average annual growth rate -0.2%
(7/70-7/72); Cape Verde Islands 304,000, average annual growth rate 3.1%
(12/60-12/70)
Ethnic divisions: homogeneous Mediterranean stock in mainland, Azores, Madeira
Islands; small, but growing number of black workers principally from the
Cape Verde Islands
Religion: 97% Roman Catholic, 1% Protestant sects, 2% other
Language: Portuguese
Literacy: 65% (a figure considered very high by some sources)
Labor force: 3.3 million (1970); 32% agriculture, 34% industry, 34% services;
unemployment virtually nil, but some underemployment widespread
Organized labor: 33.4% of labor force in syndicates subject to varying degrees
of government control
Population: 491,000, average annual growth rate 0.2%
(7/68-7/69)
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes); less than 1% European
and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese official, numerous African languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in subsistence agriculture','520bc47ee8afdc635826fc99e5ca8dcd24aa3d30c51170ceaabc73a99b150e01','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6e298649b98298727c679cccd1e9852c855f9256be2135b004a17e4eedb6da9',1974,'QA','Qatar','people-and-society',337,'Population: 167,000, average annual growth rate 10.8%
(7/64-7/69)
Ethnic divisions: 56% Arab; 23% Iranian; 14% Pakistani;
7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: 48,000 (1969)
Population: 487,000, average annual growth rate 2.2%
(7/69-7/72)
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal unemployment
Population: 6,108,000, average annual growth rate 3.5%
(7/68-7 /73)
Ethnic divisions: 96% African, 3% European, less than
1% Coloreds and Asians
Religion: 51% syncretic (part Christian, part animist),
24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and Sindebele also widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including some migrants from Zambia and
Malawi), 108,000 Europeans, Asians, and coloreds (people of mixed heritage);
35% agriculture, 25% mining, manufacturing, construction, 40% transport and
services
Organized labor: about one-third of European wage earners are unionized, but
only a small minority of Africans (1966)','a62a9f98c471881213c3c7f7a0abeda87cb2cf255de6e90aacdc203abd0a2ff1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('255966f0b2d8ace5e1531e8ab21cc903cd4150b7297b3fddd72d7389ca0fde9e',1974,'RW','Rwanda','people-and-society',344,'Population: 4,121,000, average annual growth rate 2.8%
(7/71-7/72)
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa (Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French officials Kiswahili used
in commercial centers
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy
Population: 67,000, average annual growth rate 1.2%
(4/60-4/70)
Ethnic divisions: mainly of African Negro descent
Religion: Church of England, other Protestant sects,
Roman Catholic
Language: English
Literacy: about 80%
Labor force: 19,616 (1960 est.)
Organized labor: 6,700
Population: 108,000, average annual growth rate 1.6%
(4/60~-4/70)
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 38,000 (1969); 50% agriculture
Organized labor: 20% of labor force','16f0877c762ac9c054b2d3d519f9630a237c0452b79716c0e0feba81b3d4e4ac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01603950c3a4b8b4c45514abe7deb009e012b81b5d434c847f563d216fe52838',1974,'SA','Saudi Arabia','people-and-society',348,'Population: 5,924,000, average annual growth rate 2.8%
(current
Ethnic divisions: 90% Arab, 10% Afro-Asian (est.)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 25% of population; 40% agriculture and herding, 12% construction,
12% service, 12% government, 11% commerce, 13% other
Population: 21,140,000, average annual growth rate 1%
(current)
Ethnic divisions: 39% Serb, 22.1% Croat, 9.2% Slovene, 5.8% Macedonian, 2.5%
Montenegrin, 6.4% Albanian, 3% Hungarian, 9% other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic, 12% Muslim, 3% other, 12%
none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Albanian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 13.5 million (1970); 49.6% agriculture, 16% mining and manufacturing,
34.4% other nonagricultural activities; reported unemployment averaged 8% of
registered labor force (social sector) in 1967
Population: 24,166,000, average annual growth rate 2.8%
(current)
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes -- Mongo, Luba, Kongo (all Bantu),
and the Mangbetu-Azande (Hamitic) make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo, and Chiluba are all
classified as official languages
Literacy: 5% fluent in French, about 35% have an acquaintance with French
Labor force: about 8 million, but only about 13% in wage structure','e14aacd3ad011edd243bbd94738f6b3e600bdeee669ede29f0befb536d3270b0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c98feeacfaa75bbb1e57ce434caefd6eff808e03b510d0612c1f622851ae8e77',1974,'SN','Senegal','people-and-society',352,'Population: 4,212,000, average annual growth rate 2.2%
(7/67-7/69)
Ethnic divisions: 36% Wolof, 17.5% Fulani, 16.5% Serer, 9% Tukulor, 9% Dyola,
6.5% Malinke, 4.5% other African, 1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly Roman Catholic)
Language: French official, but regular use limited to literate minoritys; most
Senegalese speak own tribal language; use of Wolof vernacular spreading --
now spoken to some degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence agricultural workers; about 125,000
wage earners
Organized labor: majority of wage-labor force represented by unions; however,
dues -paying membership very limited','965534340a258eba46bfbef4a621a93afaaa430178f83cfbf4589cebfc879ae2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c64570ae473e6d8e1e1b4522e7d86ab82faa13b69c421e8ac00a831b6b85b70',1974,'SC','Seychelles','people-and-society',356,'Population: 58,000, average annual growth rate 2.4%
(7/68-7/72)
Ethnic divisions: Seychellois (admixture of Asians, Africans, Europeans)
Religion: 90% Roman Catholic
Language: English official; Creole most widely spoken
Literacy: limited
Labor force: 22,000 agriculture
Organized labor: 3 major trade unions','f6a1af0269cb33f813a280fcf9469c5d1a0d8180981e8b6143fdf3c828177595','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7173cc59de9c05529cbf50277cd757fe31163056d27dc1dea88ece9f9b91840',1974,'SL','Sierra Leone','people-and-society',360,'Population: 2,707,000, average annual growth rate 1.5%
(7/71-7/72)
Ethnic divisions: over 99% native African, rest European and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to literate minority;
principal vernaculars are Mende in south and Temne in north; "Krio," a
form of pidgin English, is also widely spoken
Literacy: about 10%
Labor force: about 1.5 million; most of population engages in subsistence
agriculture; only small minority, some 70,000, earn wages
Organized labor: 35% of wage earners
Population: 221,000, average annual growth rate 2.3%
(3/61-4/71)
Ethnic divisions: 75% Nepalese; 25% Bhotias, Lepchas, and
a few tribal groups
Religion: Tibetan or Lamaist Buddhism (the state religion)
33.3%; Nepalese majority are primarily Hindu
Language: English, official; Nepali, lingua franca; Bhotias
and Lepchas speak Tibeto-Burman dialects
Literacy: probably less than 15%
Labor force: predominantly agricultural; minimal skilled
labor','1390f42ed89247d7b5a40ec4e4943bcd1084e3ba80d7558c4404e34d48adef38','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78a88b28830de9e59cfa732814fec8590f0868d420d9f68a8aa3ddd00fd2c9ff',1974,'SG','Singapore','people-and-society',364,'Population: 2,223,000, average annual growth rate 1.8%
(7/72-7/73)
Ethnic divisions: 76.2% Chinese, 15% Malay, 7% Indians
and Pakistani, 3% other
Religion: majority of Chinese are Buddhists or atheists; Malays nearly all Muslim;
minorities include Christians, Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay, Tamil, and English are
official languages
Literacy: 70% (1970)
Labor force: 474,718; 0.5% agriculture, forestry, and fishing, 0.4% mining and
quarrying, 32.2% manufacturing, 30.4% services, 5.2% construction, 21.5%
commerce, 9.8% transport, storage, and conmunications, 6% other
Organized labor: 24% of labor force
Population: 3,081,000, average annual growth rate 2.3%
(7/65-7/72)
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000 Arabs, 3,000 Europeans,
800 Asians
Religion: almost entirely Muslim
Language: Somali (written form recently instituted by government); Arabic, Italian,
English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled laborers; 70% pastoral
nomads, 30% agriculturists, government employees, traders, fishermen,
handicraftsmen, other
Organized labor: law providing for government-controlled labor union promulgated
in June 1971, but union so far not established','a4b1e140d488a58fd0270cedfc1f14ef85b54c70ea06a04b1169dc29ac6e75ca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('365a82d74eed62a8060862324b02b09538b5f916d425b1aeb2a15ef297bf2519',1974,'ZA','South Africa','people-and-society',368,'Population: 24,216,000, average annual growth rate 2.6%
(7/71-7/72)
Ethnic divisions: 17.8% white, 69.9% African, 9.4% Colored, 2.9% Asian
Religion: primarily Christian except Asian and African; 60% of Africans are
animists
Language: Afrikaans and English official, Africans have many vernacular languages
Literacy: almost all white population literate; government estimates 35% of
Africans literate
Labor force: 8.7 million (total of economically active, 1970); 53% agriculture,
8% manufacturing, 7% mining, 5% commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is unionized (mostly white
workers); nonwhites have no bargaining power
Population: 808,000, average annual growth rate 1.9%
{7/60-7/65)
Ethnic divisions: 14% white, 81% Africans, 5% Colored
(mulattoes); almost half the Africans belong to Ovambo tribe; Damara tribe
has almost 45,000 members; Herero, Okavango, Nama tribes have about 30,000
members each
Religion: whites predominantly Christian, nonwhites either animist or Christian
Language: Afrikaans principal language of about 70% of white population, German
of 22%, and English of 8%; several African languages
Literacy: high for white population; low for nonwhite
Labor force: 203,300 (total of economically active, 1970}; 68% agriculture, 15%
railroads, 13% mining, 4% fishing
Organized labor: no trade unions, although some white wage earners belong to
South African unions','2cdba6c852f52cf398f7811865ca3d6073f02007df35bf38ea836b631c52787e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24d0a2cc670ab4f0447eaa34c3f38c48d94a5d5b5e627db018a30d8059fdbbc6',1974,'ES','Spain','people-and-society',371,'Population: 35,225,000 (including the Balearic and Canary Islands; also including
Alhucemas, Ceuta, Chafarinas, Melilla, and Penon de Velez de la Gomera),
average annual growth rate 1.1% (current)
Ethnic divisions: homogeneous composite of Mediterranean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great majority; but 17% speak Catalan,
7% Galician, and 2% Basque
Literacy: about 90%
Labor force (1973): 12.7 million; 25% agriculture, 36% industry, 39% services;
registered unemployment is 1.5% of labor force
Organized labor: 90% of labor force in compulsory government-controlled
syndicates
Population: 102,000 (official estimate for 1 July 1973)
Ethnic divisions: 51.2% Arab, Berber, and Negro nomads;
48.8% Spanish
Religion: 51% Muslim, 49% Catholic
Language: Spanish (official), local Arabic or Hassania
Literacy: among Spanish, probably nearly 100%; among nomads, perhaps 5%
Labor force: 12,000; 50% agriculture, 50% other
Organized labor: none
Population: 13,505,000, average annual growth rate 2.2%
(7/63-10/71)
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor, 2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6% Muslim, 1% other
Language: Sinhala official, spoken by about 70% of population; Tamil spoken by
about 22%; English commonly used in government and spoken by about 10% of the
population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed; employed persons -- 53.4% agriculture,
14.8% mining and manufacturing, 12.4% trade and transport, 19.4% services
and other
Organized labor: 43% of labor force, over 50% of which employed on tea, rubber,
and coconut estates','e9254c0a0acda2e32923cff5b1f2b11ecc89455d337dc3315889a75ba6dd5352','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49d7d64c3f9206a03996ab23ca0bb47f444c6140383d8b70609cfcb66cbea5c3',1974,'SD','Sudan','people-and-society',375,'Population: 17,323,000, average annual growth rate 2.5%
(7/72-7/73)
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other
Religion: 73% Sunni Mustims in north, 23% pagan, 4% Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects of Nilotic, Nilo-Hamitic,
and Sudanic languages, English; program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15% industry, commerce, services,
etc.; labor shortages exist for almost all categories of employment','f281e3569a1d7bef6da3d423a51b3ba59bc4f49bafd05a7dd8ca394700035bd2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae2e7642d1ad54f83f50aab29f8852c219d1437f83b59d50ab7029b65691394e',1974,'SE','Sweden','people-and-society',379,'Population: 8,173,000, average annual growth rate 0.4%
(current)
Ethnic divisions: homogeneous white population; small Lappish minority
Religion: 92% Evangelical Lutheran, 7% other Protestant, Roman Catholic, Eastern
Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking minorities
Literacy: 99%
Labor force: 3.9 million; 11.8% agriculture, forestry, fishing; 33.5% mining
and manufacturing; 9.6% construction; 15.5% commerce; 7.2% transportation
and communications; 20.9% services; 3.2% unemployed
Organized labor: 80% of labor force','ddb7b4090e695ebe10ce4d479a984ad3f158b3130dee5e55407aa5ba8b88b0cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('378f328c8ffd32c460c45b1933992d153a28e05cc69a168f6ca93cc9705680cc',1974,'CH','Switzerland','people-and-society',385,'Population: 7,104,000, average annual growth rate 3.3% (7/71-7/73)
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians, and other
Religion: 70.5% Sunni Muslim, 16.3% other Muslim sects, 13.2% Christians of
various sects
Language: Arabic, Kurdish, Armenian; French and English widely understood
Literacy: about 40%
Labor force: 2 million; 67% agriculture, 12% industry (including construction),
21% miscellaneous services; majority unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 14,758,000, average annual growth rate 2.7% (7/72-7/73)
Ethnic divisions: 99% native Africans consisting of well over 100 tribes; 1%
Asian, European, and Arab
Religion: Tanganyika -- 40% animist, 30% Christian, 30% Muslim; Zanzibar --
almost all Muslim
Language: Swahili English and official English primary language of commerce,
administration and higher education; Swahili widely understood and general ly
used for communication between ethnic groups; first language of most people
is one of the local languages
Literacy: 15%-20%
Labor force: under 400,000 in paid employment, over 90% in agriculture
Organized labor: 15% of labor force','e99d02ae1753b1ef1835adcee5d96373be66c48fd6e81398068210feb76bec95','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c35354192f38b6683f611ebeca5fa0a0123d3baa355adc55ededa64004a3bd5',1974,'TG','Togo','people-and-society',387,'Population: 2,160,000, average annual growth rate 2.3%
(7/70-7/73)
Ethnic divisions: some 40 tribes; largest and most
important are Ewe in south and Cabrais in north; under 1% European and
Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of commerce; major African languages
are Ewe and Mina in south and Dagoma, Tim, and Cabrais in north
Literacy: 5% to 10%
Labor force: over 90% of population engaged in subsistence agriculture; about
30,000 wage earners, evenly divided between public and private sectors
Organized labor: less than half of wage earners divided among 2 major and several
minor unions','c3887b42cccb1c5fc79d0243511f60707a8ecf1800689bbbdc551b8db2b565f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f7136bf8053fb4577a50f6865e0459ebdc7d620c5c1449382c0204c8a384c6f',1974,'TO','Tonga','people-and-society',391,'Population: 96,000, average annual growth 2.9%
(7/67-7/72)
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized','50fc2412008f174b833ce8bbfc340fbceebade7896de9186df29559a0a167bb7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbe4e0d99aef22840a46465d2a4b4fbb08f02d7ce392ac8dabf17e49ed49655d',1974,'TT','Trinidad and Tobago','people-and-society',395,'Population: 1,000,000, average annual growth rate 1.3%
(4/60-4-70)
Ethnic divisions: 43% Negro, 40% East Indian, 14% mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23% Hindu, 6% Muslim, 13%
unknown ;
Language: English
Literacy: 80%
Labor force: about 361,000 (1971 est.), about 20.4% agriculture, 18.3% mining,
quarrying, and manufacturing, 15.8% commerce; 14.6% construction and utilities;
6.9% transportation and communications; 20.8% services, 3,270 other (1965)
Organized labor: 28% of labor force
Population: 5,643,000, average annual growth rate 2.4% (7/70-7/73)
Ethnic divisions: 98% Arab, 1% European, less than 1% Jewish
Religion: 98% Muslim, 1% Christian, less than 1% Jewish
Language: Arabic (official), Arabic and French (commerce)
Literacy: about 30%
Labor force: 1.5 million; 70% agriculture, 10% manufacturing and construction,
20% other; 25% underemployed; shortage of skilled labor
Organized labor: 10% of labor force; General Union of Tunisian Workers (UGTT),
subordinate to Destourian Socialist Party
Population: 39,083,000, average annual growth rate 2.6%
(7/71-7/72)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force','9eb43062dd81cdfbc5eaf0c7431b8b24d476a58f5d895cf8cce83e9299b49124','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbc20d62e9729adeb11aa7fa56dd06811eb2fac0f900615f7954a3b0d77c6e8b',1974,'UG','Uganda','people-and-society',399,'Population: 11,172,000, average annual growth rate 3.4%
(current)
Ethnic divisions: 98.7% African, 1.3% European, Asian,
Arab
Religion: about 60% nominally Christian, 5%-10% Muslim, rest
pagan
Language: English official; Luganda and Swahili widely used; other Bantu and
Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which 256,799 in paid labor, remaining
in subsistence activities
Organized labor: 123,284 union members
Population: 252,193,000, average annual growth rate 1%
(current)
Ethnic divisions: 74% Slavic, 26% among some 170 ethnic groups
Religion: 70% atheist, 18% Russian Orthodox, 9% Muslim, 3% other
Language: more than 200 languages and dialects (at least 18 with more than 1
million speakers); 76% Slavic group, 8% other Indo-European, 11% Altaic,
3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 132 million (1974), 26% agriculture, 74% industry and other
non-agricultural fields, unemployed not reported, shortage of skilled labor
reported, no shortage of unskilled labor','51b27cd359202ded485b71346f709e17ef3c01887e3588c02f83d5cf2467f1c7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34e426d1b5b4dfd466d33286f03099042f8e17a02fcc5a8691f4594f67034d32',1974,'AE','United Arab Emirates','people-and-society',403,'Population: 179,000 (census of 15 March - 16 April 1968)
Ethnic divisions: Arabs 72%; others include Iranians,
Pakistanis, and Indians
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 20% est. (1968)
Labor force: 77,000 (1968)
Population: 5,830,000, average annual growth rate 2%
(7/69-7/70)
Ethnic divisions: more than 50 tribes; principal tribe
is Mossi (about 2.5 million); other important groups
are Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to Sudanic family. spoken
by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active population engaged in animal
husbandry, subsistence farming, and related agricultural pursuits; about
30,000 are wage earners; about 20% of male labor force migrates annually to
neighboring countries for seasonal employment
Organized labor: 3 primary and several small specialized unions','7522bde394717ebdce3f64f8d0f53be9e1dd24aa5c7cdbd0c3941c01c2530a3f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf5302a410b5a15b6090b0ea39539153422d2ec6f899c32d4c079498dede687f',1974,'WF','Wallis and Futuna','people-and-society',407,'Population: 10,000, official estimate for 1 July 1972
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic
Population: 153,000, average annual growth rate 1.8%
(11/66-11/71)
Ethnic divisions: Polynesians, about 12,000 Euronesians (persons of European
and Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of population associated with the London
Missionary Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all children from 7-15 years)
Labor force: agriculture 19,148; mining and manufacturing 1,716 (1961)
Organized labor: unorganized
Population: 1,597,000*, average annual growth rate 2.7%
(current)
Ethnic divisions: almost all Arabs; a few Indians, Somalis, and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est. )
Population: 6,376,000, average annual growth rate 2.6%
(7/71-7/72)
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.}
Labor force: almost entirely agriculture and herding','ff811313f63ec22124c3c0b41eef7176f1587407a22230ac963b24de761fa5f4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b19574bd60896315fbe03a828f6371533c3eccaad5c396d271ee0106a40465d5',1974,'ZM','Zambia','people-and-society',410,'Population: 4,758,000, average annual growth rate 2.7%
(7/72-7/73)
Ethnic divisions: 98.7% African, 1.1% European, .2% other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000 Africans, 27,000 non-Africans;
15% mining, 9% agriculture, 9% domestic service, 19% construction, 9% commerce,
10% manufacturing, 23% government and miscellaneous services, 6% transport
Organized labor: 100,000 wage earners, primarily in industrial sector, are
unionized (early 1968)','31eb8078cbf5d8a6ab0c40b546bcd5b9fa722cf0eace16d51990784aa05fc651','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a570e4fce2f7c7e75a825e6a73f7e4fed17c270ce6e9e1e0658609cf784fdac8',1974,'US','United States','people-and-society',413,'Population: 211,881,000, average annual growth rate 0.8% (current)
Ethnic divisions: 87.2 white, 11.3 negro, 1,4 other
Religion: total membership in religious bodies, 128,470,000; Protestant
69,424,000, Roman Catholic 47,873,000, Jewish 5,780,000, other religions
5,393,000
Language: English, predominantly
Literacy: almost complete
Labor force: 86 million (1972)
Organized labor: 28.8% of total','ca6fcdc384159a355e0983dd21e76e4256578c4108ebe47585f03efffa163514','internet-archive','cia-readingroom-document-cia-rdp79-01051a000700010002-8','txt','bead1c47402f9c2779db688551f5164a3bb2c91534494331d34ed81752dbf517','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000700010002-8/cia-rdp79-01051a000700010002-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

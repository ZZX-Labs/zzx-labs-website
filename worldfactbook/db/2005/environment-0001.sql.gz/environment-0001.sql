SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d31de9e8b114ab9f58e550998651304c2d729562a42afed4e7e7f757bc72f7a',2005,'EH','Western Sahara','environment',24,'soil degradation - damage to the land''s productive capacity because of
poor agricultural practices such as the excessive use of pesticides or
fertilizers, soil compaction from heavy equipment, or erosion of
topsoil, eventually resulting in reduced ability to produce
agricultural products.
soil erosion - the removal of soil by the action of water or wind,
compounded by poor agricultural practices, deforestation, overgrazing,
and desertification.
ultraviolet (UV) radiation - a portion of the electromagnetic energy
emitted by the sun and naturally filtered in the upper atmosphere by
the ozone layer; UV radiation can be harmful to living organisms and
has been linked to increasing rates of skin cancer in humans.
water-born diseases - those in which bacteria survive in, and are
transmitted through, water; always a serious threat in areas with an
untreated water supply.
Environment - international agreements
This entry separates country participation in international
environmental agreements into two levels - party to and signed, but not
ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
Environmental agreements
This information is presented in Appendix C: Selected International
Environmental Agreements, which includes the name, abbreviation, date
opened for signature, date entered into force, objective, and parties
by category.
Ethnic groups
This entry provides an ordered listing of ethnic groups starting with
the largest and normally includes the percent of total population.
Exchange rates
This entry provides the official value of a country''s monetary unit at
a given date or over a given period of time, as expressed in units of
local currency per US dollar and as determined by international market
forces or official fiat.
Executive branch
This entry includes several subfields. Chief of state includes the name
and title of the titular leader of the country who represents the state
at official and ceremonial functions but may not be involved with the
day-to-day activities of the government. Head of government includes
the name and title of the top administrative leader who is designated
to manage the day-to-day activities of the government. For example, in
the UK, the monarch is the chief of state, and the prime minister is
the head of government. In the US, the president is both the chief of
state and the head of government. Cabinet includes the official name
for this body of high-ranking advisers and the method for selection of
members. Elections includes the nature of election process or accession
to power, date of the last election, and date of the next election.
Election results includes the percent of vote for each candidate in the
last election.
Exports
This entry provides the total US dollar amount of merchandise exports
on an f.o.b. (free on board) basis. These figures are calculated on an
exchange rate basis, i.e., not in purchasing power parity (PPP) terms.
Exports - commodities
This entry provides a rank ordering of exported products starting with
the most important; it sometimes includes the percent of total dollar
value.
Exports - partners
This entry provides a rank ordering of trading partners starting with
the most important; it sometimes includes the percent of total dollar
value.
Fiscal year
This entry identifies the beginning and ending months for a country''s
accounting period of 12 months, which often is the calendar year but
which may begin in any month. All yearly references are for the
calendar year (CY) unless indicated as a noncalendar fiscal year (FY).
Flag description
This entry provides a written flag description produced from actual
flags or the best information available at the time the entry was
written. The flags of independent states are used by their dependencies
unless there is an officially recognized local flag. Some disputed and
other areas do not have flags.
Flag graphic
Most versions of the Factbook include a color flag at the beginning of
the country profile. The flag graphics were produced from actual flags
or the best information available at the time of preparation. The flags
of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not
have flags.
GDP (purchasing power parity)
This entry gives the gross domestic product (GDP) or value of all final
goods and services produced within a nation in a given year. GDP dollar
estimates in the Factbook are derived from purchasing power parity
(PPP) calculations. See the note on GDP methodology for more
information.
GDP - composition by sector
This entry gives the percentage contribution of agriculture, industry,
and services to total GDP. The distribution will total less than 100
percent if the data are incomplete.
GDP - per capita
This entry shows GDP on a purchasing power parity basis divided by
population as of 1 July for the same year.
GDP - real growth rate
This entry gives GDP growth on an annual basis adjusted for inflation
and expressed as a percent.
GDP methodology
In the Economy category, GDP dollar estimates for all countries are
derived from purchasing power parity (PPP) calculations rather than
from conversions at official currency exchange rates. The PPP method
involves the use of standardized international dollar price weights,
which are applied to the quantities of final goods and services
produced in a given economy. The data derived from the PPP method
provide the best available starting point for comparisons of economic
strength and well-being between countries. The division of a GDP
estimate in domestic currency by the corresponding PPP estimate in
dollars gives the PPP conversion rate. Whereas PPP estimates for OECD
countries are quite reliable, PPP estimates for developing countries
are often rough approximations. Most of the GDP estimates are based on
extrapolation of PPP numbers published by the UN International
Comparison Program (UNICP) and by Professors Robert Summers and Alan
Heston of the University of Pennsylvania and their colleagues. In
contrast, the currency exchange rate method involves a variety of
international and domestic financial forces that often have little
relation to domestic output. In developing countries with weak
currencies the exchange rate estimate of GDP in dollars is typically
one-fourth to one-half the PPP estimate. Furthermore, exchange rates
may suddenly go up or down by 10% or more because of market forces or
official fiat whereas real output has remained unchanged. On 12 January
1994, for example, the 14 countries of the African Financial Community
(whose currencies are tied to the French franc) devalued their
currencies by 50%. This move, of course, did not cut the real output of
these countries by half. One important caution: the proportion of, say,
defense expenditures as a percentage of GDP in local currency accounts
may differ substantially from the proportion when GDP accounts are
expressed in PPP terms, as, for example, when an observer tries to
estimate the dollar level of Russian or Japanese military expenditures.
Note: the numbers for GDP and other economic data cannot be chained
together from successive volumes of the Factbook because of changes in
the US dollar measuring rod, revisions of data by statistical agencies,
use of new or different sources of information, and changes in national
statistical methods and practices.
GNP
Gross national product (GNP) is the value of all final goods and
services produced within a nation in a given year, plus income earned
by its citizens abroad, minus income earned by foreigners from domestic
production. The Factbook, following current practice, uses GDP rather
than GNP to measure national production. However, the user must realize
that in certain countries net remittances from citizens working abroad
may be important to national well-being.
GWP
This entry gives the gross world product (GWP) or aggregate value of
all final goods and services produced worldwide in a given year.
Geographic coordinates
This entry includes rounded latitude and longitude figures for the
purpose of finding the approximate geographic center of an entity and
is based on the Gazetteer of Conventional Names, Third Edition, August
1988, US Board on Geographic Names and on other sources.
Geographic names
This information is presented in Appendix F: Cross-Reference List of
Geographic Names. It includes a listing of various alternate names,
former names, local names, and regional names referenced to one or more
related Factbook entries. Spellings are normally, but not always, those
approved by the US Board on Geographic Names (BGN). Alternate names and
additional information are included in parentheses.
Western Sahara depends on pastoral nomadism, fishing,
and phosphate mining as the principal sources of income for the
population. The territory lacks sufficient rainfall for sustainable
agricultural production, and most of the food for the urban
population must be imported. All trade and other economic activities
are controlled by the Moroccan Government. Moroccan energy interests
in 2001 signed contracts to explore for oil off the coast of Western
Sahara, which has angered the Polisario. Incomes and standards of
living in Western Sahara are substantially below the Moroccan level.
World
Global output rose by 4.9% in 2004, led by China (9.1%),
Russia (6.7%), and India (6.2%). The other 14 successor nations of
the USSR and the other old Warsaw Pact nations again experienced
widely divergent growth rates; the three Baltic nations continued as
strong performers, in the 7% range of growth. Growth results posted
by the major industrial countries varied from a small gain in Italy
(1.3%) to a strong gain by the United States (4.4%). The developing
nations also varied in their growth results, with many countries
facing population increases that erode gains in output. Externally,
the nation-state, as a bedrock economic-political institution, is
steadily losing control over international flows of people, goods,
funds, and technology. Internally, the central government often
finds its control over resources slipping as separatist regional
movements - typically based on ethnicity - gain momentum, e.g., in
many of the successor states of the former Soviet Union, in the
former Yugoslavia, in India, in Iraq, in Indonesia, and in Canada.
Externally, the central government is losing decisionmaking powers
to international bodies, notably the European Union. In Western
Europe, governments face the difficult political problem of
channeling resources away from welfare programs in order to increase
investment and strengthen incentives to seek employment. The
addition of 75 million people each year to an already overcrowded
globe is exacerbating the problems of pollution, desertification,
underemployment, epidemics, and famine. Because of their own
internal problems and priorities, the industrialized countries
devote insufficient resources to deal effectively with the poorer
areas of the world, which, at least from an economic point of view,
are becoming further marginalized. The introduction of the euro as
the common currency of much of Western Europe in January 1999, while
paving the way for an integrated economic powerhouse, poses economic
risks because of varying levels of income and cultural and political
differences among the participating nations. The terrorist attacks
on the US on 11 September 2001 accentuate a further growing risk to
global prosperity, illustrated, for example, by the reallocation of
resources away from investment to anti-terrorist programs. The
opening of war in March 2003 between a US-led coalition and Iraq
added new uncertainties to global economic prospects. After the
coalition victory, the complex political difficulties and the high
economic cost of establishing domestic order in Iraq became major
global problems that continued into 2005.','9d307868aae7c11b5d913aa797b1d7f7264865f944b29ff9e3a03a8d50c3ad7d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39948e022e33911df5a57de045e0d6136188577c49fcf1a9a93f6cbaa38f58d7',2005,'UA','Ukraine','environment',182,'GDP (purchasing power parity):
$171.5 billion (2004 est.)
GDP - real growth rate:
8.1% (2004 est.)
GDP - per capita:
purchasing power parity - $7,700 (2004 est.)
GDP - composition by sector:
agriculture: 13.1%
industry: 33.7%
services: 53.2% (2004 est.)
Labor force:
9.66 million (2004 est.)
Labor force - by occupation:
agriculture 31.6%, industry 30.7%, services 37.7% (2004)
Unemployment rate:
6.3% (2004 est.)
Population below poverty line:
28.9% (2002)
Household income or consumption by percentage share:
lowest 10%: 2.4%
highest 10%: 27.6% (2003)
Distribution of family income - Gini index:
28.8 (2003)
Inflation rate (consumer prices):
9.6% (2004 est.)
Investment (gross fixed):
23.3% of GDP (2004 est.)
Budget:
revenues: $22.1 billion
expenditures: $23.2 billion, including capital expenditures of $2.2
billion (2004 est.)
Public debt:
23.6% of GDP (2004 est.)
Agriculture - products:
wheat, corn, barley, sugar beets, sunflower seed, potatoes, grapes;
eggs, sheep
Industries:
textiles and footwear, light machinery and auto assembly, mining,
timber, construction materials, metallurgy, chemicals, food
processing, petroleum refining
Industrial production growth rate:
4% (2004 est.)
Electricity - production:
56.53 billion kWh (2003)
Electricity - production by source:
fossil fuel: 62.5%
hydro: 27.6%
nuclear: 9.9%
other: 0% (2001)
Electricity - consumption:
57.5 billion kWh (2003)
Electricity - exports:
3.046 billion kWh (2003)
Electricity - imports:
962 million kWh (2003)
Oil - production:
128,000 bbl/day (2004 est.)
Oil - consumption:
253,800 bbl/day (2003 est.)
Oil - exports:
NA
Oil - imports:
NA
Oil - proved reserves:
1.055 billion bbl (1 January 2002)
Natural gas - production:
12.6 billion cu m (2003 est.)
Natural gas - consumption:
18.5 billion cu m (2003 est.)
Natural gas - exports:
0 cu m (2001 est.)
Natural gas - imports:
5.4 billion cu m (2001 est.)
Natural gas - proved reserves:
111.1 billion cu m (1 January 2002)
Current account balance:
$-3.631 billion (2004 est.)
Exports:
$23.54 billion f.o.b. (2004 est.)
Exports - commodities:
textiles and footwear, metals and metal products, machinery and
equipment, minerals and fuels, chemicals, agricultural products
Exports - partners:
Italy 21.4%, Germany 15%, France 8.5%, Turkey 7%, UK 6.6% (2004)
Imports:
$28.43 billion f.o.b. (2004 est.)
Imports - commodities:
machinery and equipment, fuels and minerals, chemicals, textile and
products, basic metals, agricultural products
Imports - partners:
Italy 17.2%, Germany 14.9%, France 7.1%, Russia 6.8%, Turkey 4.2%
(2004)
Reserves of foreign exchange and gold:
$16.21 billion (2004)
Debt - external:
$24.59 billion (2004 est.)
Currency (code):
leu (ROL)
Currency code:
ROL
Exchange rates:
lei per US dollar - 32,637 (2004), 33,200 (2003), 33,055 (2002),
29,061 (2001), 21,709 (2000)
Fiscal year:
calendar year
Communications Romania
Telephones - main lines in use:
4.3 million (2003)
Telephones - mobile cellular:
6.9 million (2003)
Telephone system:
general assessment: poor domestic service, but improving
domestic: 90% of telephone network is automatic; trunk network is
mostly microwave radio relay, with some fiber-optic cable; about
one-third of exchange capacity is digital; roughly 3,300 villages
have no service
international: country code - 40; satellite earth station - 1
Intelsat; new digital, international, direct-dial exchanges operate
in Bucharest; note - Romania is an active participant in several
international telecommunication network projects (1999)
Radio broadcast stations:
AM 40, FM 202, shortwave 3 (1998)
Radios:
7.2 million (1997)
Television broadcast stations:
48 (plus 392 repeaters) (1995)
Televisions:
5.25 million (1997)
Internet country code:
.ro
Internet hosts:
50,807 (2004)
Internet Service Providers (ISPs):
38 (2000)
Internet users:
4 million (2003)
Transportation Romania
Railways:
total: 11,385 km (3,888 km electrified)
standard gauge: 10,898 km 1.435-m gauge
broad gauge: 60 km 1.524-m gauge
narrow gauge: 427 km 0.760-m gauge (2004)
Highways:
total: 198,755 km
paved: 100,173 km (including 113 km of expressways)
unpaved: 98,582 km (2002)
Waterways:
1,731 km (2004)
Pipelines:
gas 3,508 km; oil 2,427 km (2004)
Ports and harbors:
Braila, Constanta, Galati, Tulcea
Merchant marine:
total: 34 ships (1,000 GRT or over) 395,350 GRT/510,232 DWT
by type: bulk carrier 5, cargo 20, passenger 1, passenger/cargo 2,
petroleum tanker 2, roll on/roll off 4
foreign-owned: 2 (Italy 2)
registered in other countries: 39 (2005)
Airports:
61 (2004 est.)
Airports - with paved runways:
total: 25
over 3,047 m: 4
2,438 to 3,047 m: 9
1,524 to 2,437 m: 12 (2004 est.)
Airports - with unpaved runways:
total: 36
1,524 to 2,437 m: 2
914 to 1,523 m: 10
under 914 m: 24 (2004 est.)
Heliports:
1 (2004 est.)
Military Romania
Military branches:
Land Forces, Naval Forces, Air and Air Defense Forces (AMR),
Special Operations, Civil Defense (2005)
Military service age and obligation:
20 years of age for compulsory military service, 18 in wartime;
conscript service obligation - 12 months; 18 years of age for
voluntary military service (2004)
Manpower available for military service:
males age 20-49: 5,061,984 (2005 est.)
Manpower fit for military service:
males age 20-49: 3,932,579 (2005 est.)
Manpower reaching military service age annually:
males: 172,093 (2005 est.)
Military expenditures - dollar figure:
$985 million (2002)
Military expenditures - percent of GDP:
2.47% (2002)
Transnational Issues Romania
Disputes - international:
Romania and Ukraine have taken their dispute over
Ukrainian-administered Zmiyinyy (Snake) Island and Black Sea
maritime boundary to the ICJ for adjudication; Romania also opposes
Ukraine''s reopening of a navigation canal from the Danube border
through Ukraine to the Black Sea; Hungary amended the status law
extending special social and cultural benefits to ethnic Hungarians
in Romania, to which Romania had objected
Illicit drugs:
major transshipment point for Southwest Asian heroin transiting the
Balkan route and small amounts of Latin American cocaine bound for
Western Europe; although not a significant financial center, role as
a narcotics conduit leaves it vulnerable to laundering which occurs
via the banking system, currency exchange houses, and casinos
This page was last updated on 20 October, 2005
======================================================================
@Russia
Introduction Russia
Geography - note:
vegetation scanty
People Saint Pierre and Miquelon
Population:
7,012 (July 2005 est.)
Age structure:
0-14 years: 24% (male 861/female 825)
15-64 years: 65.3% (male 2,330/female 2,251)
65 years and over: 10.6% (male 335/female 410) (2005 est.)
Median age:
total: 33.7 years
male: 33.39 years
female: 33.96 years (2005 est.)
Population growth rate:
0.21% (2005 est.)
Birth rate:
13.83 births/1,000 population (2005 est.)
Death rate:
6.7 deaths/1,000 population (2005 est.)
Net migration rate:
-4.99 migrant(s)/1,000 population (2005 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1.01 male(s)/female (2005 est.)
Infant mortality rate:
total: 7.54 deaths/1,000 live births
male: 8.66 deaths/1,000 live births
female: 6.38 deaths/1,000 live births (2005 est.)
Life expectancy at birth:
total population: 78.46 years
male: 76.13 years
female: 80.9 years (2005 est.)
Total fertility rate:
2.03 children born/woman (2005 est.)
HIV/AIDS - adult prevalence rate:
NA%
HIV/AIDS - people living with HIV/AIDS:
NA
HIV/AIDS - deaths:
NA
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups:
Basques and Bretons (French fishermen)
Religions:
Roman Catholic 99%
Languages:
French (official)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)
Government Saint Pierre and Miquelon
Country name:
conventional long form: Territorial Collectivity of Saint Pierre
and Miquelon
conventional short form: Saint Pierre and Miquelon
local long form: Departement de Saint-Pierre et Miquelon
local short form: Saint-Pierre et Miquelon
Dependency status:
self-governing territorial collectivity of France
Government type:
NA
Capital:
Saint-Pierre
Administrative divisions:
none (territorial collectivity of France); note - there are no
first-order administrative divisions as defined by the US
Government, but there are two communes - Saint Pierre, Miquelon at
the second order
Independence:
none (territorial collectivity of France; has been under French
control since 1763)
National holiday:
Bastille Day, 14 July (1789)
Constitution:
4 October 1958 (French Constitution)
Legal system:
French law with special adaptations for local conditions, such as
housing and taxation
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Jacques CHIRAC of France (since 17 May
1995), represented by Prefect Albert DUPUY (since 10 January 2005)
head of government: President of the General Council Marc
PLANTAGENEST (since NA)
cabinet: NA
elections: French president elected by popular vote for a five-year
term; election last held, first round - 21 April 2002, second round
- 5 May 2002 (next to be held NA 2007); prefect appointed by the
French president on the advice of the French Ministry of Interior;
president of the General Council is elected by the members of the
council
Legislative branch:
unicameral General Council or Conseil General (19 seats - 15 from
Saint Pierre and 4 from Miquelon; members are elected by popular
vote to serve six-year terms)
elections: elections last held 19 and 26 March 2000 (next to be held
NA April 2006)
election results: percent of vote by party - NA%; seats by party -
PS 12, PRG 2, UDF-RPR 5
note: Saint Pierre and Miquelon elect 1 seat to the French Senate;
elections last held NA September 1995 (next to be held NA September
2004); results - percent of vote by party - NA%; seats by party -
RPR 1; Saint Pierre and Miquelon also elects 1 seat to the French
National Assembly; elections last held, first round - 9 June 2002,
second round - 16 June 2002 (next to be held NA 2007); results -
percent of vote by party - NA%; seats by party - UDF 1
Judicial branch:
Superior Tribunal of Appeals or Tribunal Superieur d''Appel
Political parties and leaders:
Left Radical Party or PRG [leader NA]; Rassemblement pour la
Republique or RPR (now UMP) [leader NA]; Socialist Party or PS
[leader NA]; Union pour la Democratie Francaise or UDF [leader NA]
Political pressure groups and leaders:
NA
International organization participation:
UPU, WFTU
Diplomatic representation in the US:
none (territorial collectivity of France)
Diplomatic representation from the US:
none (territorial collectivity of France)
Flag description:
a yellow sailing ship facing the hoist side rides on a dark blue
background with yellow wavy lines under the ship; on the hoist side,
a vertical band is divided into three parts: the top part (called
ikkurina) is red with a green diagonal cross extending to the
corners overlaid by a white cross dividing the rectangle into four
sections; the middle part has a white background with an ermine
pattern; the third part has a red background with two stylized
yellow lions outlined in black, one above the other; these three
heraldic arms represent settlement by colonists from the Basque
Country (top), Brittany, and Normandy; the flag of France is used
for official occasions
Economy Saint Pierre and Miquelon
Economy - overview:
The inhabitants have traditionally earned their livelihood by
fishing and by servicing fishing fleets operating off the coast of
Newfoundland. The economy has been declining, however, because of
disputes with Canada over fishing quotas and a steady decline in the
number of ships stopping at Saint Pierre. In 1992, an arbitration
panel awarded the islands an exclusive economic zone of 12,348 sq km
to settle a longstanding territorial dispute with Canada, although
it represents only 25% of what France had sought. The islands are
heavily subsidized by France to the great betterment of living
standards. The government hopes an expansion of tourism will boost
economic prospects. Recent test drilling for oil may pave the way
for development of the energy sector.
GDP (purchasing power parity):
$48.3 million - supplemented by annual payments from France of
about $60 million (2003 est.)
GDP - real growth rate:
NA%
GDP - per capita:
purchasing power parity - $7,000 (2001 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Labor force:
3,261 (1999)
Labor force - by occupation:
fishing 18%, industry (mainly fish-processing) 41%, services 41%
(1996 est.)
Unemployment rate:
9.8% (1997)
Population below poverty line:
NA%
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices):
2.1% (1991-96 average)
Budget:
revenues: $70 million
expenditures: $60 million, including capital expenditures of $24
million (1996 est.)
Agriculture - products:
vegetables; poultry, cattle, sheep, pigs; fish
Industries:
fish processing and supply base for fishing fleets; tourism
Industrial production growth rate:
NA%
Electricity - production:
43.08 million kWh (2002)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
Electricity - consumption:
40.06 million kWh (2002)
Electricity - exports:
0 kWh (2002)
Electricity - imports:
0 kWh (2002)
Oil - production:
0 bbl/day (2001 est.)
Oil - consumption:
600 bbl/day (2001 est.)
Oil - exports:
NA
Oil - imports:
NA
Exports:
$10 million f.o.b. (2002)
Exports - commodities:
fish and fish products, soybeans, animal feed, mollusks and
crustaceans, fox and mink pelts
Exports - partners:
Belgium 41.3%, US 19.9%, Spain 14.9%, France 10%, Germany 4.1%
(2004)
Imports:
$106 million f.o.b. (2002)
Imports - commodities:
meat, clothing, fuel, electrical equipment, machinery, building
materials
Imports - partners:
France 37.6%, Canada 25.3%, Ireland 25.2%, Italy 5.1% (2004)
Debt - external:
$NA
Economic aid - recipient:
approximately $60 million in annual grants from France
Currency (code):
euro (EUR)
Currency code:
EUR
Exchange rates:
euros per US dollar - 0.8054 (2004), 0.886 (2003), 1.0626 (2002),
1.1175 (2001), 1.0854 (2000)
Fiscal year:
calendar year
Communications Saint Pierre and Miquelon
Telephones - main lines in use:
4,800 (2002)
Telephones - mobile cellular:
0 (1994)
Telephone system:
general assessment: adequate
domestic: NA
international: country code - 508; radiotelephone communication with
most countries in the world; 1 earth station in French domestic
satellite system
Radio broadcast stations:
AM 1, FM 4, shortwave 0 (1998)
Radios:
4,000 (1997)
Television broadcast stations:
0 (there are, however, two repeaters which rebroadcast programs
from France, Canada, and the US) (1997)
Televisions:
4,000 (1997)
Internet country code:
.pm
Internet Service Providers (ISPs):
1 (2000)
Internet users:
NA
Transportation Saint Pierre and Miquelon
Highways:
total: 114 km
paved: 69 km
unpaved: 45 km
Ports and harbors:
Saint-Pierre
Airports:
2 (2004 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
Military Saint Pierre and Miquelon
Military - note:
defense is the responsibility of France
Transnational Issues Saint Pierre and Miquelon
Disputes - international:
none
This page was last updated on 20 October, 2005
======================================================================
@Saint Vincent and the Grenadines
Introduction Saint Vincent and the Grenadines
After Russia, the Ukrainian republic was far and away the
most important economic component of the former Soviet Union,
producing about four times the output of the next-ranking republic.
Its fertile black soil generated more than one-fourth of Soviet
agricultural output, and its farms provided substantial quantities
of meat, milk, grain, and vegetables to other republics. Likewise,
its diversified heavy industry supplied the unique equipment (for
example, large diameter pipes) and raw materials to industrial and
mining sites (vertical drilling apparatus) in other regions of the
former USSR. Ukraine depends on imports of energy, especially
natural gas, to meet some 85% of its annual energy requirements.
Shortly after independence in December 1991, the Ukrainian
Government liberalized most prices and erected a legal framework for
privatization, but widespread resistance to reform within the
government and the legislature soon stalled reform efforts and led
to some backtracking. Output by 1999 had fallen to less than 40% of
the 1991 level. Loose monetary policies pushed inflation to
hyperinflationary levels in late 1993. Ukraine''s dependence on
Russia for energy supplies and the lack of significant structural
reform have made the Ukrainian economy vulnerable to external
shocks. Ukrainian government officials have taken some steps to
reform the country''s Byzantine tax code, such as the implementation
of lower tax rates aimed at bringing more economic activity out of
Ukraine''s large shadow economy, but more improvements are needed,
including closing tax loopholes and eliminating tax privileges and
exemptions. Reforms in the more politically sensitive areas of
structural reform and land privatization are still lagging. Outside
institutions - particularly the IMF - have encouraged Ukraine to
quicken the pace and scope of reforms. GDP in 2000 showed strong
export-based growth of 6% - the first growth since independence -
and industrial production grew 12.9%. The economy continued to
expand in 2001 as real GDP rose 9% and industrial output grew by
over 14%. Growth of 4.6% in 2002 was more moderate, in part a
reflection of faltering growth in the developed world. In general,
growth has been undergirded by strong domestic demand, low
inflation, and solid consumer and investor confidence. Growth was a
sturdy 9.3% in 2003 and a remarkable 12% in 2004, despite a loss of
momentum in needed economic reforms.
gas 20,069 km; oil 4,540 km; refined products 4,169 km (2004)','a9cfeb131be018ce02ebc32c2fe490dfd8ca67a6f0b121abf531c3e910740621','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6ac9a9cefcaf0e3dfe2e6ec48020d2f09927cb4069f4f297d6556bd7fc2a1ec',2005,'RO','Romania','environment',811,'Russia
Russia ended 2004 with its sixth straight year of growth,
averaging 6.5% annually since the financial crisis of 1998. Although
high oil prices and a relatively cheap ruble are important drivers
of this economic rebound, since 2000 investment and consumer-driven
demand have played a noticeably increasing role. Real fixed capital
investments have averaged gains greater than 10% over the last five
years, and real personal incomes have realized average increases
over 12%. Russia has also improved its international financial
position since the 1998 financial crisis, with its foreign debt
declining from 90% of GDP to around 28%. Strong oil export earnings
have allowed Russia to increase its foreign reserves from only $12
billion to some $120 billion at yearend 2004. These achievements,
along with a renewed government effort to advance structural
reforms, have raised business and investor confidence in Russia''s
economic prospects. Nevertheless, serious problems persist. Economic
growth slowed down in the second half of 2004 and the Russian
government forecasts growth of only 4.5% to 6.2% for 2005. Oil,
natural gas, metals, and timber account for more than 80% of
exports, leaving the country vulnerable to swings in world prices.
Russia''s manufacturing base is dilapidated and must be replaced or
modernized if the country is to achieve broad-based economic growth.
Other problems include a weak banking system, a poor business
climate that discourages both domestic and foreign investors,
corruption, and widespread lack of trust in institutions. In
addition, a string of investigations launched against a major
Russian oil company, culminating with the arrest of its CEO in the
fall of 2003, have raised concerns by some observers that President
PUTIN is granting more influence to forces within his government
that desire to reassert state control over the economy.
gas 3,508 km; oil 2,427 km (2004)
Russia
condensate 122 km; gas 150,007 km; oil 75,539 km; refined
products 13,771 km (2004)','42b0662f61e54fa6065017705ba97f6ef549e528abd63829eb101e440c26a5fc','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('704724c3f4a6c4ac1df5a148d121514a46f2ffa034019db9deb844f8bd919589',2005,'RW','Rwanda','environment',812,'Rwanda is a poor rural country with about 90% of the
population engaged in (mainly subsistence) agriculture. It is the
most densely populated country in Africa; landlocked with few
natural resources and minimal industry. Primary foreign exchange
earners are coffee and tea. The 1994 genocide decimated Rwanda''s
fragile economic base, severely impoverished the population,
particularly women, and eroded the country''s ability to attract
private and external investment. However, Rwanda has made
substantial progress in stabilizing and rehabilitating its economy
to pre-1994 levels, although poverty levels are higher now. GDP has
rebounded and inflation has been curbed. Export earnings, however,
have been hindered by low beverage prices, depriving the country of
much needed hard currency. Despite Rwanda''s fertile ecosystem, food
production often does not keep pace with population growth,
requiring food imports. Rwanda continues to receive substantial aid
money and was approved for IMF-World Bank Heavily Indebted Poor
Country (HIPC) initiative debt relief in late 2000. Kigali''s high
defense expenditures have caused tension between the government and
international donors and lending agencies. An energy shortage and
instability in neighboring states may slow growth in 2005, while the
lack of adequate transportation linkages to other countries
continues to handicap export growth.
Saint Helena
The economy depends largely on financial assistance
from the UK, which amounted to about $5 million in 1997 or almost
one-half of annual budgetary revenues. The local population earns
income from fishing, raising livestock, and sales of handicrafts.
Because there are few jobs, 25% of the work force has left to seek
employment on Ascension Island, on the Falklands, and in the UK.','3d1ffdbc6e68539cf504944f0e12d0ca8fb399a901951e724f4cd67c369cc5e3','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7769114cbc8158a67a7cd536a8707062fa0bf775628651ea3ded2ce82a9c423d',2005,'KN','Saint Kitts and Nevis','environment',813,'Sugar was the traditional mainstay of the
Saint Kitts economy until the 1970s. Although the crop still
dominates the agricultural sector, activities such as tourism,
export-oriented manufacturing, and offshore banking have assumed
larger roles in the economy. Tourism revenues are now the chief
source of the islands'' foreign exchange. The opening of a 470-room
resort in February 2003 was expected to bring in much-needed revenue.','95dbd72a263a1ab8cea669d06ccc8ba44bb9228a76b0e9598beb6befd17cbecd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('811b053c7921cacce2f4e1734565f29ad82aad8549a4cd603befe9b8795f74f9',2005,'LC','Saint Lucia','environment',814,'Changes in the EU import preference regime and the
increased competition from Latin American bananas have made economic
diversification increasingly important in Saint Lucia. The island
nation has been able to attract foreign business and investment,
especially in its offshore banking and tourism industries. The
manufacturing sector is the most diverse in the Eastern Caribbean
area, and the government is trying to revitalize the banana
industry. Economic fundamentals remain solid, even though
unemployment needs to be cut.','e2a678b09632e25c9decb8db44173cfe2bdd4abbea255803d8e0fda3fd7000f7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6c721d8bd2a289cb26945e0c526e7f7c6095071cf802a40e650854d178bccd4',2005,'PM','Saint Pierre and Miquelon','environment',815,'The inhabitants have traditionally earned
their livelihood by fishing and by servicing fishing fleets
operating off the coast of Newfoundland. The economy has been
declining, however, because of disputes with Canada over fishing
quotas and a steady decline in the number of ships stopping at Saint
Pierre. In 1992, an arbitration panel awarded the islands an
exclusive economic zone of 12,348 sq km to settle a longstanding
territorial dispute with Canada, although it represents only 25% of
what France had sought. The islands are heavily subsidized by France
to the great betterment of living standards. The government hopes an
expansion of tourism will boost economic prospects. Recent test
drilling for oil may pave the way for development of the energy
sector.','c8d0d708ea515044afb30e94412d79a7f82e62067c1f77f07e75b26f16ef297e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d38b170ad8e28fddef733b1a17dfbef07e1c33f4f7367c17746ae3a241b94d1',2005,'VC','Saint Vincent and the Grenadines','environment',816,'Economic growth in this
lower-middle-income country hinges upon seasonal variations in the
agricultural and tourism sectors. Tropical storms wiped out
substantial portions of crops in 1994, 1995, and 2002, and tourism
in the Eastern Caribbean has suffered low arrivals following 11
September 2001. Saint Vincent is home to a small offshore banking
sector and has moved to adopt international regulatory standards.
Saint Vincent is also a large producer of marijuana and is being
used as a transshipment point for illegal narcotics from South
America.','45ce7eefc6ef8c0a082d72c0c99c7fec8971a422b5f9cecc010151ffab46cc2e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ec5f156233142b136936986e5adff14a1550f23f21a21a4946e62456d373621',2005,'WS','Samoa','environment',817,'The economy of Samoa has traditionally been dependent on
development aid, family remittances from overseas, agriculture, and
fishing. The country is vulnerable to devastating storms.
Agriculture employs two-thirds of the labor force, and furnishes 90%
of exports, featuring coconut cream, coconut oil, and copra. The
manufacturing sector mainly processes agricultural products. The
decline of fish stocks in the area is a continuing problem. Tourism
is an expanding sector, accounting for 25% of GDP; about 88,000
tourists visited the islands in 2001. One factory in the Foreign
Trade Zone employs 3,000 people to make automobile electrical
harnesses for an assembly plant in Australia. The Samoan Government
has called for deregulation of the financial sector, encouragement
of investment, and continued fiscal discipline, meantime protecting
the environment. Observers point to the flexibility of the labor
market as a basic strength for future economic advances. Foreign
reserves are in a relatively healthy state, the external debt is
stable, and inflation is low.','d7cebec79dd856b9badfa4ef49cd13a0754b2545cf8ece584652fcb88d5f9761','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bc2969365f81a54f88cad8f42c246ae9ed847af00816f2d0ec9d5ea9e9c53ca',2005,'SM','San Marino','environment',818,'The tourist sector contributes over 50% of GDP. In 2000
more than 3 million tourists visited San Marino. The key industries
are banking, wearing apparel, electronics, and ceramics. Main
agricultural products are wine and cheeses. The per capita level of
output and standard of living are comparable to those of the most
prosperous regions of Italy, which supplies much of its food.','28149495dc5a6aa10f08ce74db9513160b829fc391267b629453927be5a72bbb','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('199db4b6752447c2a8ab74cea7c3e796a52438aa5f943378b19a340c76bd02c5',2005,'ST','Sao Tome and Principe','environment',819,'This small poor island economy has become
increasingly dependent on cocoa since independence in 1975. Cocoa
production has substantially declined in recent years because of
drought and mismanagement, but strengthening prices helped boost
export earnings in 2003. Sao Tome has to import all fuels, most
manufactured goods, consumer goods, and a substantial amount of
food. Over the years, it has had difficulty servicing its external
debt and has relied heavily on concessional aid and debt
rescheduling. Sao Tome benefited from $200 million in debt relief in
December 2000 under the Highly Indebted Poor Countries (HIPC)
program, but lacking a formal poverty reduction program with the
IMF, it has not benefited from subsequent HIPC debt reductions. Sao
Tome''s external debt stands at over $300 million. Considerable
potential exists for development of a tourist industry, and the
government has taken steps to expand facilities in recent years. The
government also has attempted to reduce price controls and
subsidies. Sao Tome is optimistic about the development of petroleum
resources in its territorial waters in the oil-rich Gulf of Guinea.
The first production license was sold to a consortium led by
US-based oil firms. Much of the 2005 budget is dependent upon the
sale of additional production licenses.','4e1e673c856b1382bcd934d8fe06848bb8f2c376fbe93107f7fa324150d9d4ea','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b56627209983ea8adce798810ff1a17caa3a39e6652589c18398c41651592d6',2005,'SA','Saudi Arabia','environment',820,'This is an oil-based economy with strong government
controls over major economic activities. Saudi Arabia possesses 25%
of the world''s proven petroleum reserves, ranks as the largest
exporter of petroleum, and plays a leading role in OPEC. The
petroleum sector accounts for roughly 75% of budget revenues, 45% of
GDP, and 90% of export earnings. About 40% of GDP comes from the
private sector. Roughly five and a half million foreign workers play
an important role in the Saudi economy, for example, in the oil and
service sectors. The government in 1999 announced plans to begin
privatizing the electricity companies, which follows the ongoing
privatization of the telecommunications company. The government is
encouraging private sector growth to lessen the kingdom''s dependence
on oil and increase employment opportunities for the swelling Saudi
population. Priorities for government spending in the short term
include additional funds for education and for the water and sewage
systems. Economic reforms proceed cautiously because of deep-rooted
political and social conservatism.
condensate 212 km; gas 1,780 km; liquid petroleum gas
1,191 km; oil 5,068 km; refined products 1,162 km (2004)','9c58295ee9d82435401aae935ac852c748dc29b6a076d3e6b27ab3ab3415b140','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f5a0d09590fe57160b01310f92d9c26c4e882d9f0278e1b0a85cc9a4968ce49',2005,'SN','Senegal','environment',821,'In January 1994, Senegal undertook a bold and ambitious
economic reform program with the support of the international donor
community. This reform began with a 50% devaluation of Senegal''s
currency, the CFA franc, which was linked at a fixed rate to the
French franc. Government price controls and subsidies have been
steadily dismantled. After seeing its economy contract by 2.1% in
1993, Senegal made an important turnaround, thanks to the reform
program, with real growth in GDP averaging 5% annually during
1995-2003. Annual inflation had been pushed down to the low single
digits. As a member of the West African Economic and Monetary Union
(WAEMU), Senegal is working toward greater regional integration with
a unified external tariff and a more stable monetary policy. Senegal
still relies heavily upon outside donor assistance, however. Under
the IMF''s Highly Indebted Poor Countries debt relief program,
Senegal will benefit from eradication of two-thirds of its
bilateral, multilateral, and private sector debt.
Serbia and Montenegro
MILOSEVIC-era mismanagement of the economy, an
extended period of economic sanctions, and the damage to
Yugoslavia''s infrastructure and industry during the NATO airstrikes
in 1999 left the economy only half the size it was in 1990. After
the ousting of former Federal Yugoslav President MILOSEVIC in
October 2000, the Democratic Opposition of Serbia (DOS) coalition
government implemented stabilization measures and embarked on an
aggressive market reform program. After renewing its membership in
the IMF in December 2000, a down-sized Yugoslavia continued to
reintegrate into the international community by rejoining the World
Bank (IBRD) and the European Bank for Reconstruction and Development
(EBRD). A World Bank-European Commission sponsored Donors''
Conference held in June 2001 raised $1.3 billion for economic
restructuring. An agreement rescheduling the country''s $4.5 billion
Paris Club government debts was concluded in November 2001 - it
wrote off 66% of the debt - and the London Club of private creditors
forgave $1.7 billion of debt, just over half the total owed, in July
2004. The smaller republic of Montenegro severed its economy from
federal control and from Serbia during the MILOSEVIC era and
continues to maintain its own central bank, uses the euro instead of
the Yugoslav dinar as official currency, collects customs tariffs,
and manages its own budget. Kosovo''s economy continues to transition
to a market-based system, and is largely dependent on the
international community and the diaspora for financial and technical
assistance. The euro and the Yugoslav dinar are both accepted
currencies in Kosovo. While maintaining ultimate oversight, UNMIK
continues to work with the European Union and Kosovo''s local
provisional government to accelerate economic growth, lower
unemployment, and attract foreign investment to help Kosovo
integrate into regional economic structures. The complexity of
Serbia and Montenegro political relationships, slow progress in
privatization, legal uncertainty over property rights, scarcity of
foreign-investment and a substantial foreign trade deficit are
holding back the economy. Arrangements with the IMF, especially
requirements for fiscal discipline, are an important element in
policy formation. Severe unemployment remains a key political
economic problem for this entire region.
gas 564 km (2004)
Serbia and Montenegro
gas 3,177 km; oil 393 km (2004)','bc66d1cf92682086b9ecfbebde31048dad28563b01e2c164cc0d263d1551bdbc','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('228bef625db481e9f37bfc27da673b1424bc15aff14f8d0fed689febb1ebb1be',2005,'SC','Seychelles','environment',822,'Since independence in 1976, per capita output in this
Indian Ocean archipelago has expanded to roughly seven times the old
near-subsistence level. Growth has been led by the tourist sector,
which employs about 30% of the labor force and provides more than
70% of hard currency earnings, and by tuna fishing. In recent years
the government has encouraged foreign investment in order to upgrade
hotels and other services. At the same time, the government has
moved to reduce the dependence on tourism by promoting the
development of farming, fishing, and small-scale manufacturing. A
sharp drop illustrated the vulnerability of the tourist sector in
1991-92 due largely to the Gulf war, and once again following the 11
September 2001 terrorist attacks on the US. Growth slowed in
1998-2002, and fell in 2003, due to sluggish tourist and tuna
sectors, but resumed in 2004, erasing a persistent budget deficit.
Tight controls on exchange rates and the scarcity of foreign
exchange have impaired short-term economic prospects. The black
market value of the Seychelles rupee is half the official exchange
rate; without a devaluation of the currency the tourist sector may
remain sluggish as vacationers seek cheaper destinations such as
Comoros, Mauritius, and Madagascar.','af2301aaa36abc4b2f16dadb5f10a72c07d35a47565fb00f33a4db1dc331865a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('666c656528a2435748e58905b1286061a7ff8c7a73273cdf85e74d6309ad55a6',2005,'SL','Sierra Leone','environment',823,'Sierra Leone is an extremely poor African nation with
tremendous inequality in income distribution. While it possesses
substantial mineral, agricultural, and fishery resources, its
economic and social infrastructure is not well developed, and
serious social disorders continue to hamper economic development.
About two-thirds of the working-age population engages in
subsistence agriculture. Manufacturing consists mainly of the
processing of raw materials and of light manufacturing for the
domestic market. Plans to reopen bauxite and rutile mines shut down
during an 11 year civil war have not been implemented due to lack of
foreign investment. Alluvial diamond mining remains the major source
of hard currency earnings. The fate of the economy depends upon the
maintenance of domestic peace and the continued receipt of
substantial aid from abroad, which is essential to offset the severe
trade imbalance and supplement government revenues. International
financial institutions contributed over $600 million in development
aid and budgetary support in 2003.','cdf9e5029c4dee77c63833278c1a4cfeecaea8b27cf68c9b5eea897643e285f4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f71dd3d1aabd35d991ffba8f3a2a1549aacc842b0b40f84613f8c7eaf795f226',2005,'SG','Singapore','environment',824,'Singapore, a highly developed and successful free market
economy, enjoys a remarkably open and corruption-free environment,
stable prices, and a per capita GDP equal to that of the Big 4 West
European countries. The economy depends heavily on exports,
particularly in electronics and manufacturing. It was hard hit in
2001-03 by the global recession, by the slump in the technology
sector, and by an outbreak of Severe Acute Respiratory Syndrome in
2003, which curbed tourism and consumer spending. The government
hopes to establish a new growth path that will be less vulnerable to
the external business cycle and will continue efforts to establish
Singapore as Southeast Asia''s financial and high-tech hub. Fiscal
stimulus, low interest rates, a surge in exports, and internal
flexibility led to vigorous growth in 2004, with real GDP rising by
8 percent, by far the economy''s best performance since 2000.
gas 139 km (2004)','075d7a8e512b133e26d16bacdcabc8038ac328d8bdd6d77d6871e5c3f5efd5fd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1efcbc48d2e49bf74975bdb6dfa0f378c911b60b1ca2b9afbe86959467751c7c',2005,'SK','Slovakia','environment',825,'Slovakia has mastered much of the difficult transition from
a centrally planned economy to a modern market economy. The DZURINDA
government made excellent progress during 2001-04 in macroeconomic
stabilization and structural reform. Major privatizations are nearly
complete, the banking sector is almost completely in foreign hands,
and the government has helped facilitate a foreign investment boom
with business-friendly policies, such as labor market liberalization
and a 19% flat tax. Slovakia''s economic growth exceeded expectations
in 2001-04, despite the general European slowdown. Unemployment, at
an unacceptable 15% in 2003-04, remains the economy''s Achilles heel.
Slovakia joined the EU on 1 May 2004.
gas 6,769 km; oil 449 km (2004)','a029408a02f26a44925e65001464ece3784314dcd889b7c45d4aadc83349b4a7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58a6356174e9105de6b0cf5e4ca0a58a88f41e349d6f24843b09f7fa23cdc4a5',2005,'SI','Slovenia','environment',826,'Slovenia, with its historical ties to Western Europe,
enjoys a GDP per capita substantially higher than that of the other
transitioning economies of Central Europe. In March 2004, Slovenia
became the first transition country to graduate from borrower status
to donor partner at the World Bank. Privatization of the economy
proceeded at an accelerated pace in 2002-04. Despite lackluster
performance in Europe in 2001-04, Slovenia maintained moderate
growth. Structural reforms to improve the business environment have
allowed for greater foreign participation in Slovenia''s economy and
have helped to lower unemployment. Further measures to curb
inflation are still needed. Corruption and the high degree of
coordination between government, business, and central bank policy
were issues of concern in the run-up to Slovenia''s 1 May 2004
accession to the European Union. In mid-2004 Slovenia agreed to
adopt the euro by 2007 and, therefore, must keep its debt levels,
budget deficits, interest rates, and inflation levels within the
EU''s Maastrict criteria.
gas 2,526 km; oil 11 km (2004)','b612567b0be7cc5f1c3a42b305ea36a98228a9077c25e8c10827283a1b5eb914','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3c3ff5a80f6db3153a1447a856239355b7c3b6fe412506e4d94d208ba809841',2005,'SB','Solomon Islands','environment',827,'The bulk of the population depends on agriculture,
fishing, and forestry for at least part of their livelihood. Most
manufactured goods and petroleum products must be imported. The
islands are rich in undeveloped mineral resources such as lead,
zinc, nickel, and gold. Prior to the arrival of the Regional
Assistance Mission to the Solomon Islands (RAMSI), severe ethnic
violence, the closing of key businesses, and an empty government
treasury culminated in economic collapse. RAMSI has enabled a return
to law and order, a new period of economic stability, and modest
growth as the economy rebuilds.','209799e070c116c58cceb24eeb19bd21cad15fd45926a790dc69ba2b5616080c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67f7df1994a4658f71ebe8d8e3a34d686e87edb731ab978fae50568d182f50c0',2005,'SO','Somalia','environment',828,'Somalia''s economic fortunes are driven by its deep political
divisions. The northwestern area has declared its independence as
the "Republic of Somaliland"; the northeastern region of Puntland is
a semi-autonomous state; and the remaining southern portion is
riddled with the struggles of rival factions. Economic life
continues, in part because much activity is local and relatively
easily protected. Agriculture is the most important sector, with
livestock normally accounting for about 40% of GDP and about 65% of
export earnings, but Saudi Arabia''s recent ban on Somali livestock,
because of Rift Valley Fever concerns, has severely hampered the
sector. Nomads and semi-nomads, who are dependent upon livestock for
their livelihood, make up a large portion of the population.
Livestock, hides, fish, charcoal, and bananas are Somalia''s
principal exports, while sugar, sorghum, corn, qat, and machined
goods are the principal imports. Somalia''s small industrial sector,
based on the processing of agricultural products, has largely been
looted and sold as scrap metal. Despite the seeming anarchy,
Somalia''s service sector has managed to survive and grow.
Telecommunication firms provide wireless services in most major
cities and offer the lowest international call rates on the
continent. In the absence of a formal banking sector, money exchange
services have sprouted throughout the country, handling between $500
million and $1 billion in remittances annually. Mogadishu''s main
market offers a variety of goods from food to the newest electronic
gadgets. Hotels continue to operate, and militias provide security.
The ongoing civil disturbances and clan rivalries, however, have
interfered with any broad-based economic development and
international aid arrangements. In 2004 Somalia''s overdue financial
obligations to the IMF continued to grow. Statistics on Somalia''s
GDP, growth, per capita income, and inflation should be viewed
skeptically. In late December 2004, a major tsunami took an
estimated 150 lives and caused destruction of properity in coastal
areas.','e967b8a604893b9244c6105f8c00e9f663aade350f5be107a54960fdac182b3f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2073d58c4d6d729c7928aa6c726edbf53c662513a084d4d2ba42bbdb5016335c',2005,'ZA','South Africa','environment',829,'South Africa is a middle-income, emerging market with
an abundant supply of natural resources; well-developed financial,
legal, communications, energy, and transport sectors; a stock
exchange that ranks among the 10 largest in the world; and a modern
infrastructure supporting an efficient distribution of goods to
major urban centers throughout the region. However, growth has not
been strong enough to lower South Africa''s high unemployment rate;
and daunting economic problems remain from the apartheid era,
especially poverty and lack of economic empowerment among the
disadvantaged groups. South African economic policy is fiscally
conservative, but pragmatic, focusing on targeting inflation and
liberalizing trade as means to increase job growth and household
income.
condensate 100 km; gas 1,052 km; oil 847 km; refined
products 1,354 km (2004)','c4150412519abcf7a911eab349846a9d03a62fb3d7be3c8cb4b815290cd3bd46','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0eaf8728b4b9f58cee2557aa0c1d62985216fffc2040122e03f73e0d88855c17',2005,'GS','South Georgia and the South Sandwich Islands','environment',830,'Some fishing takes
place in adjacent waters. There is a potential source of income from
harvesting finfish and krill. The islands receive income from
postage stamps produced in the UK, sale of fishing licenses, and
harbor and landing fees from tourist vessels. Tourism from
specialized cruise ships is increasing rapidly.
Southern Ocean
Fisheries in 2000-01 (1 July to 30 June) landed
112,934 metric tons, of which 87% was krill and 11% Patagonian
toothfish. International agreements were adopted in late 1999 to
reduce illegal, unreported, and unregulated fishing, which in the
2000-01 season landed, by one estimate, 8,376 metric tons of
Patagonian and antarctic toothfish. In the 2000-01 antarctic summer
12,248 tourists, most of them seaborne, visited the Southern Ocean
and Antarctica, compared to 14,762 the previous year.','78d24bc76eaaa40103d1a01bd80b00a4967982e4d02eb2c046569667497147a5','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('766e43b328c5127e648e6fc92452cb39d8d6ce2a8990d1d4c67325213e898b0c',2005,'ES','Spain','environment',831,'The Spanish economy boomed from 1986 to 1990, averaging five
percent annual growth. After a European-wide recession in the early
1990s, the Spanish economy resumed moderate growth starting in 1994.
Spain''s mixed capitalist economy supports a GDP that on a per capita
basis is 80% that of the four leading West European economies. The
center-right government of former President AZNAR successfully
worked to gain admission to the first group of countries launching
the European single currency (the euro) on 1 January 1999. The AZNAR
administration continued to advocate liberalization, privatization,
and deregulation of the economy and introduced some tax reforms to
that end. Unemployment fell steadily under the AZNAR administration
but remains high at 10.4%. Growth of 2.5% in 2003 and 2.6% in 2004
was satisfactory given the background of a faltering European
economy. The socialist president, RODRIGUEZ ZAPATERO, has initiated
economic and social reforms that are generally popular among the
masses of people but that are anathema to religious and other
conservative elements. Adjusting to the monetary and other economic
policies of an integrated Europe, reducing unemployment, and
absorbing widespread social changes will pose challenges to Spain
over the next few years.
Spratly Islands
Economic activity is limited to commercial fishing.
The proximity to nearby oil- and gas-producing sedimentary basins
suggests the potential for oil and gas deposits, but the region is
largely unexplored; there are no reliable estimates of potential
reserves; commercial exploitation has yet to be developed.
gas 7,306 km; oil 730 km; refined products 3,512 km (2004)','8ebd9574285ebea5e3089ae5910bf59260fff798df28bc621962a09828b2d338','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99172265378dc6167ee7ad294dcb4e43e96c9ea8b9c5e43ab388be7f833f5de7',2005,'LK','Sri Lanka','environment',832,'In 1977, Colombo abandoned statist economic policies and
its import substitution trade policy for market-oriented policies
and export-oriented trade. Sri Lanka''s most dynamic sectors now are
food processing, textiles and apparel, food and beverages,
telecommunications, and insurance and banking. In 2003, plantation
crops made up only 15% of exports (compared with 93% in 1970), while
textiles and garments accounted for 63%. GDP grew at an average
annual rate of 5.5% in the early 1990s until a drought and a
deteriorating security situation lowered growth to 3.8% in 1996. The
economy rebounded in 1997-2000 with average growth of 5.3%, but 2001
saw the first contraction in the country''s history, -1.4%, due to a
combination of power shortages, severe budgetary problems, the
global slowdown, and continuing civil strife. Growth recovered to
4.0% in 2002 and to 5.2% in both 2003 and 2004. About 800,000 Sri
Lankans work abroad, 90% in the Middle East. They send home about $1
billion a year. The struggle by the Tamil Tigers of the north and
east for a largely independent homeland continues to cast a shadow
over the economy. In late December 2004, a major tsunami took about
31,000 lives, left more than 6,300 missing and 443,000 displaced,
and destroyed an estimated $1.5 billion worth of property.','a6ed83f99acf08de1d4e1d09d60b1f9beaef296dfce8a18a05d1b6739fba9bce','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ecd057c91b7e0ee19e02349e2d1be042eed44ffafa28bd6415a4cc3eabb6df4',2005,'SD','Sudan','environment',833,'Sudan has turned around a struggling economy with sound
economic policies and infrastructure investments, but it still faces
formidable economic problems, starting from its low level of per
capita output. From 1997 to date, Sudan has been implementing IMF
macroeconomic reforms. In 1999, Sudan began exporting crude oil and
in the last quarter of 1999 recorded its first trade surplus, which,
along with monetary policy, has stabilized the exchange rate.
Increased oil production, revived light industry, and expanded
export processing zones helped sustain GDP growth at 6.4% in 2004.
Agriculture production remains Sudan''s most important sector,
employing 80% of the work force, contributing 39% of GDP, and
accounting for most of GDP growth, but most farms remain rain-fed
and susceptible to drought. Chronic instability - including the
long-standing civil war between the Muslim north and the
Christian/pagan south, adverse weather, and weak world agricultural
prices - ensure that much of the population will remain at or below
the poverty line for years.
gas 156 km; oil 2,365 km; refined products 810 km (2004)','8dc03c1994dc76eb3ee6c4ec9ebba26aedc0582aee2ef71099427566572c1c91','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e1dc5de958adef278b7d1d14707512e3221dbefeea5171a7cfedbc255611ca2',2005,'SR','Suriname','environment',834,'The economy is dominated by the alumina industry, which
accounts for more than 15% of GDP and 70% of export earnings.
Suriname''s economic prospects for the medium term will depend on
continued commitment to responsible monetary and fiscal policies and
to the introduction of structural reforms to liberalize markets and
promote competition. The government of Ronald VENETIAAN has begun an
austerity program, raised taxes, and attempted to control spending.
While - in 2002 - President VENETIAAN agreed to a large pay raise
for civil servants, threatening his earlier gains in stabilizing the
economy, he has not repeated this promise in the run-up to the May
2005 elections. The Dutch Government has agreed to restart the aid
flow, which will allow Suriname to access international development
financing, but plans to phase out funds over the next five years.
The short-term economic outlook depends on the government''s ability
to control inflation and on the development of projects in the
bauxite and gold mining sectors. Prospects for local onshore oil
production are good, as a drilling program is underway. Offshore oil
drilling was given a boost in 2004 when the State Oil Company
(Staatsolie) signed exploration agreements with Repsol and Mearsk.
Svalbard
Coal mining is the major economic activity on Svalbard. The
treaty of 9 February 1920 gives the 41 signatories equal rights to
exploit mineral deposits, subject to Norwegian regulation. Although
US, UK, Dutch, and Swedish coal companies have mined in the past,
the only companies still mining are Norwegian and Russian. The
settlements on Svalbard are essentially company towns. The Norwegian
state-owned coal company employs nearly 60% of the Norwegian
population on the island, runs many of the local services, and
provides most of the local infrastructure. There is also some
hunting of seal, reindeer, and fox.
Swaziland
In this small, landlocked economy, subsistence agriculture
occupies more than 80% of the population. The manufacturing sector
has diversified since the mid-1980s. Sugar and wood pulp remain
important foreign exchange earners. Mining has declined in
importance in recent years with only coal and quarry stone mines
remaining active. Surrounded by South Africa, except for a short
border with Mozambique, Swaziland is heavily dependent on South
Africa from which it receives about nine-tenths of its imports and
to which it sends nearly three-quarters of its exports. Customs
duties from the Southern African Customs Union and worker
remittances from South Africa substantially supplement domestically
earned income. The government is trying to improve the atmosphere
for foreign investment. Overgrazing, soil depletion, drought, and
sometimes floods persist as problems for the future. More than
one-fourth of the population needed emergency food aid in 2004
because of drought, and more than one-third of the adult population
was infected by HIV/AIDS.
oil 51 km (2004)','4dd6fd202d60a83e09dee9cfc5e7c40892f558a960c0b35deca3be1e83d55756','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60603132050c38c279c6b5dc61258f543388f9e5d329c34c1cf9de5abff61f6a',2005,'SE','Sweden','environment',835,'Aided by peace and neutrality for the whole 20th century,
Sweden has achieved an enviable standard of living under a mixed
system of high-tech capitalism and extensive welfare benefits. It
has a modern distribution system, excellent internal and external
communications, and a skilled labor force. Timber, hydropower, and
iron ore constitute the resource base of an economy heavily oriented
toward foreign trade. Privately owned firms account for about 90% of
industrial output, of which the engineering sector accounts for 50%
of output and exports. Agriculture accounts for only 2% of GDP and
2% of the jobs. The government''s commitment to fiscal discipline
resulted in a substantial budgetary surplus in 2001, which was cut
by more than half in 2002, due to the global economic slowdown,
declining revenue, and increased spending. The Swedish central bank
(the Riksbank) focuses on price stability with its inflation target
of 2%. Growth remained sluggish in 2003, but picked up in 2004.
Presumably because of generous sicktime benefits, Swedish workers
report in sick more often than other Europeans. On 14 September
2003, Swedish voters turned down entry into the euro system,
concerned about the impact on democracy and sovereignty.
gas 798 km (2004)','a42789e0959f330d07db91b58daa2e55dc74788f63dfe6f51955a1bbf72eab3f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76d01837b4d17c9f393dfec54aea673531dfdc7cd2e6278c2fdf253212621a79',2005,'CH','Switzerland','environment',836,'Switzerland is a peaceful, prosperous, and stable modern
market economy with low unemployment, a highly skilled labor force,
and a per capita GDP larger than that of the big Western European
economies. The Swiss in recent years have brought their economic
practices largely into conformity with the EU''s to enhance their
international competitiveness. Switzerland remains a safe haven for
investors, because it has maintained a degree of bank secrecy and
has kept up the franc''s long-term external value. Reflecting the
anemic economic conditions of Europe, GDP growth dropped in 2001 to
about 0.8%, to 0.2% in 2002, and to -0.3% in 2003, with a small rise
to 1.8% in 2004. Even so, unemployment has remained at less than
half the EU average.
Syria
Real GDP growth rose to 2.3 percent in 2004, a slight increase
from 2003 when the predominantly statist economy suffered from
disruptions caused by the war in Iraq and other developments in the
region. Annual real GDP growth has averaged 2.3 percent for the last
seven years. The Government of Syria has implemented modest economic
reforms in the last few years, including cutting interest rates,
opening private banks, consolidating some of the multiple exchange
rates, and raising prices on some subsidized foodstuffs.
Nevertheless, the economy remains highly controlled by the
government. Long run economic constraints include declining oil
production and exports and pressure on water supplies caused by
rapid population growth, industrial expansion, and increased water
pollution.
Taiwan
Taiwan has a dynamic capitalist economy with gradually
decreasing guidance of investment and foreign trade by government
authorities. In keeping with this trend, some large government-owned
banks and industrial firms are being privatized. Exports have
provided the primary impetus for industrialization. The trade
surplus is substantial, and foreign reserves are the world''s third
largest. Agriculture contributes less than 2% to GDP, down from 32%
in 1952. Taiwan is a major investor throughout Southeast Asia. China
has overtaken the US to become Taiwan''s largest export market.
Because of its conservative financial approach and its
entrepreneurial strengths, Taiwan suffered little compared with many
of its neighbors from the Asian financial crisis in 1998. The global
economic downturn, combined with problems in policy coordination by
the administration and bad debts in the banking system, pushed
Taiwan into recession in 2001, the first year of negative growth
ever recorded. Unemployment also reached record levels. Output
recovered moderately in 2002 in the face of continued global
slowdown, fragile consumer confidence, and bad bank loans; and the
essentially vibrant economy pushed ahead in 2003-04. Growing
economic ties with China are a dominant long-term factor, e.g.,
exports to China of parts and equipment for the assembly of goods
for export to developed countries.
gas 1,831 km; oil 94 km; refined products 7 km (2004)
Syria
gas 2,300 km; oil 2,183 km (2004)
Taiwan
condensate 25 km; gas 435 km (2004)','2ce3f6780ceb6b2b2ef734b2893c48b2c30e69434bd2567af2b6f8d2a63438aa','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('353153ac92ec540734871e645e18311eba40919238dc03d952b4feccb69f5eba',2005,'TJ','Tajikistan','environment',837,'Tajikistan has one of the lowest per capita GDPs among
the 15 former Soviet republics. Only 5% to 6% of the land area is
arable. Cotton is the most important crop. Mineral resources, varied
but limited in amount, include silver, gold, uranium, and tungsten.
Industry consists only of a large aluminum plant, hydropower
facilities, and small obsolete factories mostly in light industry
and food processing. The civil war (1992-97) severely damaged the
already weak economic infrastructure and caused a sharp decline in
industrial and agricultural production. Even though 60% of its
people continue to live in abject poverty, Tajikistan has
experienced steady economic growth since 1997. Continued
privatization of medium and large state-owned enterprises will
further increase productivity. Tajikistan''s economic situation,
however, remains fragile due to uneven implementation of structural
reforms, weak governance, widespread unemployment, and the external
debt burden. A debt restructuring agreement was reached with Russia
in December 2002, including an interest rate of 4%, a 3-year grace
period, and a US $49.8 million credit to the Central Bank of
Tajikistan.
Tanzania
Tanzania is one of the poorest countries in the world. The
economy depends heavily on agriculture, which accounts for almost
half of GDP, provides 85% of exports, and employs 80% of the work
force. Topography and climatic conditions, however, limit cultivated
crops to only 4% of the land area. Industry traditionally featured
the processing of agricultural products and light consumer goods.
The World Bank, the International Monetary Fund, and bilateral
donors have provided funds to rehabilitate Tanzania''s out-of-date
economic infrastructure and to alleviate poverty. Growth in
1991-2002 featured a pickup in industrial production and a
substantial increase in output of minerals, led by gold. Recent
banking reforms have helped increase private sector growth and
investment. Continued donor assistance and solid macroeconomic
policies supported real GDP growth of nearly 6% in 2004.
gas 541 km; oil 38 km (2004)
Tanzania
gas 29 km; oil 866 km (2004)','31fca8d60ebc1aba23bab017381b96b0fceb404c15d47ee78fc9988a96718e96','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5db9e5b33c111b59ac258264145fe5efa696d0c23451145a1fe09e9e54490a6d',2005,'TH','Thailand','environment',838,'Thailand has a well developed infrastructure, a
free-enterprise economy, and welcomes foreign investment. Thailand
has fully recovered from the 1997-98 Asian Financial Crisis and was
one of East Asia''s best performers in 2002-04. Increased consumption
and investment spending and strong export growth pushed GDP growth
up to 6.9% in 2003 and 6.1% in 2004 despite a sluggish global
economy. The highly popular government''s expansionist policy,
including major support of village economic development, has raised
concerns about fiscal discipline and the health of financial
institutions. Bangkok has pursued preferential trade agreements with
a variety of partners in an effort to boost exports and maintain
high growth, and in 2004 began negotiations on a Free Trade
Agreement with the US. In late December 2004, a major tsunami took
8,500 lives in Thailand and caused massive destruction of property
in the southern provinces of Krabi, Phangnga, and Phuket.
gas 3,112 km; refined products 265 km (2004)','adfbd005712734223a45863508114be90ee60cf96ff3c58eee19ef077d50753c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93f4fbaae9e64645b93f3121e7d418c96155a6d0f03fa5bef513510dca04adbb',2005,'TG','Togo','environment',839,'This small sub-Saharan economy is heavily dependent on both
commercial and subsistence agriculture, which provides employment
for 65% of the labor force. Some basic foodstuffs must still be
imported. Cocoa, coffee, and cotton generate about 40% of export
earnings, with cotton being the most important cash crop. Togo is
the world''s fourth-largest producer of phosphate, but production
fell an estimated 22% in 2002 due to power shortages and the cost of
developing new deposits. The government''s decade-long effort,
supported by the World Bank and the IMF, to implement economic
reform measures, encourage foreign investment, and bring revenues in
line with expenditures has moved slowly. Progress depends on
following through on privatization, increased openness in government
financial operations, progress toward legislative elections, and
continued support from foreign donors.','ce94b760fc57f0a0294cb69933d304275b6d39b40dfa2d195964dc36f79646e6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ed8a905f3ffc350232b7eef2ce0bcf45c7f4e69d498a4e3c1d2ac96fc9b8e66',2005,'TK','Tokelau','environment',840,'Tokelau''s small size (three villages), isolation, and lack
of resources greatly restrain economic development and confine
agriculture to the subsistence level. The people rely heavily on aid
from New Zealand - about $4 million annually - to maintain public
services, with annual aid being substantially greater than GDP. The
principal sources of revenue come from sales of copra, postage
stamps, souvenir coins, and handicrafts. Money is also remitted to
families from relatives in New Zealand.','67305297609ce5384df29d9eed7b4d5b81d4c3e8b9b06276f0070cb2c02d0c6a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b25f71fbe1eaed963873503c37254cb77ec276395760050507296fc210be7f6a',2005,'TO','Tonga','environment',841,'Tonga, a small, open, South Pacific island economy, has a
narrow export base in agricultural goods. Squash, coconuts, bananas,
and vanilla beans are the main crops, and agricultural exports make
up two-thirds of total exports. The country must import a high
proportion of its food, mainly from New Zealand. Tourism is the
second largest source of hard currency earnings following
remittances. The country remains dependent on external aid and
remittances from Tongan communities overseas to offset its trade
deficit. The government is emphasizing the development of the
private sector, especially the encouragement of investment, and is
committing increased funds for health and education. Tonga has a
reasonably sound basic infrastructure and well-developed social
services. High unemployment among the young, a continuing upturn in
inflation, and rising civil service expenditures are major issues
facing the government.','2c50b13333a6972ba5b3666af4846917c76302b9c913b63b33c8454eb2d83a96','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46c4675352206dee336f4093cfeaa28c4f8c29796b10aa14939193a54be5cc57',2005,'TT','Trinidad and Tobago','environment',842,'Trinidad and Tobago, the leading Caribbean
producer of oil and gas, has earned a reputation as an excellent
investment site for international businesses. Tourism is a growing
sector, although not proportionately as important as in many other
Caribbean islands. The economy benefits from low inflation and a
growing trade surplus. Prospects for growth in 2004 are good as
prices for oil, petrochemicals, and liquified natural gas are
expected to remain high, and foreign direct investment continues to
grow to support expanded capacity in the energy sector. The
government is coping with a rise in violent crime.
Tromelin Island
no economic activity
condensate 253 km; gas 1,117 km; oil 478 km
(2004)','918750329c9cf863412ddc1a2408101c33b8d5f119448d5728ca70361f5b2251','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d002619598ff840b0a84e7d290881de67dd1576bcecf9365cc4ddae418b51b5f',2005,'TN','Tunisia','environment',843,'Tunisia has a diverse economy, with important agricultural,
mining, energy, tourism, and manufacturing sectors. Governmental
control of economic affairs while still heavy has gradually lessened
over the past decade with increasing privatization, simplification
of the tax structure, and a prudent approach to debt. Progressive
social policies also have helped raise living conditions in Tunisia
relative to the region. Real growth slowed to a 15-year low of 1.9%
in 2002 because of agricultural drought and lackluster tourism.
Better rains in 2003 and 2004, however, helped push GDP growth above
5% for these years. Tourism also recovered after the end of combat
operations in Iraq. Tunisia is gradually removing barriers to trade
with the European Union. Broader privatization, further
liberalization of the investment code to increase foreign
investment, improvements in government efficiency, and reduction of
the trade deficit are among the challenges ahead.
Turkey
Turkey''s dynamic economy is a complex mix of modern industry
and commerce along with a traditional agriculture sector that in
2004 still accounted for more than 35% of employment. It has a
strong and rapidly growing private sector, yet the state still plays
a major role in basic industry, banking, transport, and
communication. The largest industrial sector is textiles and
clothing, which accounts for one-third of industrial employment; it
faces stiff competition in international markets with the end of the
global quota system. However, other sectors, notably the automotive
and electronics industries, are rising in importance within Turkey''s
export mix. In recent years the economic situation has been marked
by erratic economic growth and serious imbalances. Real GNP growth
has exceeded 6% in many years, but this strong expansion has been
interrupted by sharp declines in output in 1994, 1999, and 2001.
Inflation, in recent years in the high double-digit range, fell to
9.3% by 2004 - a 30-year low. Despite these strong economic gains in
2002-04, which were largely due to renewed investor interest in
emerging markets, IMF backing, and tighter fiscal policy, the
economy is still plagued with high debt and deficits. The public
sector fiscal deficit exceeds 6% of GDP - due in large part to the
huge burden of interest payments, which accounted for more than 40%
of central government spending in 2004, and to populist spending.
Foreign direct investment (FDI) in Turkey remains low - averaging
less than $1 billion annually, but further economic and judicial
reforms and prospective EU membership are expected to boost FDI. A
major political and economic issue over the next decade is whether
or not Turkey will become a member of the EU.
gas 3,059 km; oil 1,203 km; refined products 345 km (2004)
Turkey
gas 3,177 km; oil 3,562 km (2004)','07442bd1e59e5307c87e1ff89804d5aee1e5583ff8d7982a34eda31acfeab582','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4aaaecd093e1bdfa0de73f56e93bdd347ccb01a72e1a7615c1164203c0c44b53',2005,'TM','Turkmenistan','environment',844,'Turkmenistan is largely desert country with intensive
agriculture in irrigated oases and large gas and oil resources.
One-half of its irrigated land is planted in cotton; formerly it was
the world''s tenth-largest producer. Poor harvests in recent years
have led to a nearly 46% decline in cotton exports. With an
authoritarian ex-Communist regime in power and a tribally based
social structure, Turkmenistan has taken a cautious approach to
economic reform, hoping to use gas and cotton sales to sustain its
inefficient economy. Privatization goals remain limited. In
1998-2004, Turkmenistan suffered from the continued lack of adequate
export routes for natural gas and from obligations on extensive
short-term external debt. At the same time, however, total exports
rose by perhaps 30% in 2003 and 19% in 2004, largely because of
higher international oil and gas prices. Overall prospects in the
near future are discouraging because of widespread internal poverty,
the burden of foreign debt, the government''s irrational use of oil
and gas revenues, and its unwillingness to adopt market-oriented
reforms. Turkmenistan''s economic statistics are state secrets, and
GDP and other figures are subject to wide margins of error. In
particular, the rate of GDP growth is uncertain.
gas 6,549 km; oil 1,395 km (2004)','057d4f7af048091cb35f53e4f48f6d1d269c0f759cd69ae6791ac4c0e1b62c29','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bba67e41ddc99455a77428bce4cdba95e7451183b05c720a8ba41e08600d05e8',2005,'TC','Turks and Caicos Islands','environment',845,'The Turks and Caicos economy is based on
tourism, fishing, and offshore financial services. Most capital
goods and food for domestic consumption are imported. The US is the
leading source of tourists, accounting for more than half of the
annual 93,000 visitors in the late 1990s. Major sources of
government revenue also include fees from offshore financial
activities and customs receipts.','c753e0cc0b8d7fde756ba9a762649c79d2b12399c9f9bcd17689b489d82a5c54','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cac73d2477d80313b9775a4b733405b824de434bb00bbbf590257dc0e2e6b9d',2005,'TV','Tuvalu','environment',846,'Tuvalu consists of a densely populated, scattered group of
nine coral atolls with poor soil. The country has no known mineral
resources and few exports. Subsistence farming and fishing are the
primary economic activities. Fewer than 1,000 tourists, on average,
visit Tuvalu annually. Government revenues largely come from the
sale of stamps and coins and worker remittances. About 1,000
Tuvaluans work in Nauru in the phosphate mining industry. Nauru has
begun repatriating Tuvaluans, however, as phosphate resources
decline. Substantial income is received annually from an
international trust fund established in 1987 by Australia, NZ, and
the UK and supported also by Japan and South Korea. Thanks to wise
investments and conservative withdrawals, this fund has grown from
an initial $17 million to over $35 million in 1999. The US
government is also a major revenue source for Tuvalu because of
payments from a 1988 treaty on fisheries. In an effort to reduce its
dependence on foreign aid, the government is pursuing public sector
reforms, including privatization of some government functions and
personnel cuts of up to 7%. In 1998, Tuvalu began deriving revenue
from use of its area code for "900" lines and in 2000, from the
lease of its ".tv" Internet domain name. Royalties from these new
technology sources could increase substantially over the next
decade. With merchandise exports only a fraction of merchandise
imports, continued reliance must be placed on fishing and
telecommunications license fees, remittances from overseas workers,
official transfers, and income from overseas investments.','7cdb66ebe896c8e01138370e59025d18d8b9a3257969975f9f4d0ac54611a69e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adc3e529cd8a65dd2ae6f119ab13bcb8342b9f0715c434ee0eb938465a9bc550',2005,'UG','Uganda','environment',847,'Uganda has substantial natural resources, including fertile
soils, regular rainfall, and sizable mineral deposits of copper and
cobalt. Agriculture is the most important sector of the economy,
employing over 80% of the work force. Coffee accounts for the bulk
of export revenues. Since 1986, the government - with the support of
foreign countries and international agencies - has acted to
rehabilitate and stabilize the economy by undertaking currency
reform, raising producer prices on export crops, increasing prices
of petroleum products, and improving civil service wages. The policy
changes are especially aimed at dampening inflation and boosting
production and export earnings. During 1990-2001, the economy turned
in a solid performance based on continued investment in the
rehabilitation of infrastructure, improved incentives for production
and exports, reduced inflation, gradually improved domestic
security, and the return of exiled Indian-Ugandan entrepreneurs.
Corruption within the government and slippage in the government''s
determination to press reforms raise doubts about the continuation
of strong growth. In 2000, Uganda qualified for enhanced Highly
Indebted Poor Countries (HIPC) debt relief worth $1.3 billion and
Paris Club debt relief worth $145 million. These amounts combined
with the original HIPC debt relief added up to about $2 billion.
Growth for 2001-02 was solid despite continued decline in the price
of coffee, Uganda''s principal export. Solid growth in 2003-04
reflected an upturn in Uganda''s export markets.','fac4b1e513789da77d25fb929f18547079f55dbf107944f87a1b2d6a75850073','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a9dd49fd8c9ca80a2f5b5158662edeba1ddba7593fb85b4d07ef79f7bbb9f3f',2005,'AE','United Arab Emirates','environment',848,'The UAE has an open economy with a high per
capita income and a sizable annual trade surplus. Its wealth is
based on oil and gas output (about 30% of GDP), and the fortunes of
the economy fluctuate with the prices of those commodities. Since
the discovery of oil in the UAE more than 30 years ago, the UAE has
undergone a profound transformation from an impoverished region of
small desert principalities to a modern state with a high standard
of living. At present levels of production, oil and gas reserves
should last for more than 100 years. The government has increased
spending on job creation and infrastructure expansion and is opening
up its utilities to greater private sector involvement. In April
2004, the UAE signed a Trade and Investment Framework Agreement
(TIFA) with Washington and in November 2004 agreed to undertake
negotiations toward a Free Trade Agreement (FTA) with the US.
condensate 469 km; gas 2,655 km; liquid
petroleum gas 300 km; oil 2,936 km; oil/gas/water 5 km (2004)','74a05af9ce671ceb800a6d09972ecfffcd95660369882dc65c842f45d26ea38c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba50aa1ac4ca8757fa71c1a37d38fbf681daa87a163b43a108dedddd2d5bada3',2005,'GB','United Kingdom','environment',849,'The UK, a leading trading power and financial center,
is one of the quartet of trillion dollar economies of Western
Europe. Over the past two decades the government has greatly reduced
public ownership and contained the growth of social welfare
programs. Agriculture is intensive, highly mechanized, and efficient
by European standards, producing about 60% of food needs with less
than 2% of the labor force. The UK has large coal, natural gas, and
oil reserves; primary energy production accounts for 10% of GDP, one
of the highest shares of any industrial nation. Services,
particularly banking, insurance, and business services, account by
far for the largest proportion of GDP while industry continues to
decline in importance. GDP growth slipped in 2001-03 as the global
downturn, the high value of the pound, and the bursting of the "new
economy" bubble hurt manufacturing and exports. Output recovered in
2004, to 3.2% growth. The economy is one of the strongest in Europe;
inflation, interest rates, and unemployment remain low. The
relatively good economic performance has complicated the BLAIR
government''s efforts to make a case for Britain to join the European
Economic and Monetary Union (EMU). Critics point out that the
economy is doing well outside of EMU, and they cite public opinion
polls that continue to show a majority of Britons opposed to the
euro. Meantime, the government has been speeding up the improvement
of education, transport, and health services, at a cost in higher
taxes.
condensate 370 km; gas 21,446 km; liquid petroleum
gas 59 km; oil 6,420 km; oil/gas/water 63 km; refined products 4,474
km (2004)','6ad53b772d339e5389f7e732f217c83cd25c094fcbca6211c00c45c093186cd8','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63148fd400cc139df2fb7e1243233da3c4b7711c72ddab98dd53d349610e839f',2005,'US','United States','environment',850,'The US has the largest and most technologically
powerful economy in the world, with a per capita GDP of $40,100. In
this market-oriented economy, private individuals and business firms
make most of the decisions, and the federal and state governments
buy needed goods and services predominantly in the private
marketplace. US business firms enjoy considerably greater
flexibility than their counterparts in Western Europe and Japan in
decisions to expand capital plant, to lay off surplus workers, and
to develop new products. At the same time, they face higher barriers
to entry in their rivals'' home markets than the barriers to entry of
foreign firms in US markets. US firms are at or near the forefront
in technological advances, especially in computers and in medical,
aerospace, and military equipment; their advantage has narrowed
since the end of World War II. The onrush of technology largely
explains the gradual development of a "two-tier labor market" in
which those at the bottom lack the education and the
professional/technical skills of those at the top and, more and
more, fail to get comparable pay raises, health insurance coverage,
and other benefits. Since 1975, practically all the gains in
household income have gone to the top 20% of households. The
response to the terrorist attacks of 11 September 2001 showed the
remarkable resilience of the economy. The war in March/April 2003
between a US-led coalition and Iraq, and the subsequent occupation
of Iraq, required major shifts in national resources to the
military. The rise in GDP in 2004 was undergirded by substantial
gains in labor productivity. The economy suffered from a sharp
increase in energy prices in the second half of 2004. Long-term
problems include inadequate investment in economic infrastructure,
rapidly rising medical and pension costs of an aging population,
sizable trade and budget deficits, and stagnation of family income
in the lower economic groups.
petroleum products 244,620 km; natural gas 548,665 km
(2003)','0b9c13689eede5dca8ae26cbf2038f678471633596d442327f539e7475b7c2c5','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('919905dc8b130e32f7de4f52c9a65821754df416a1d2d1c9f28935f1407f28a8',2005,'UY','Uruguay','environment',851,'Uruguay''s well-to-do economy is characterized by an
export-oriented agricultural sector, a well-educated workforce, and
high levels of social spending. After averaging growth of 5%
annually during 1996-98, in 1999-2002 the economy suffered a major
downturn, stemming largely from the spillover effects of the
economic problems of its large neighbors, Argentina and Brazil. For
instance, in 2001-02 massive withdrawals by Argentina of dollars
deposited in Uruguayan banks led to a plunge in the Uruguyan peso
and a massive rise in unemployment. Total GDP in these four years
dropped by nearly 20%, with 2002 the worst year due to the serious
banking crisis. Unemployment rose to nearly 20% in 2002, inflation
surged, and the burden of external debt doubled. Cooperation with
the IMF limited the damage. The debt swap with private creditors
carried out in 2003, which extended the maturity dates on nearly
half of Uruguay''s $11.3 billion in public debt, substantially
alleviated the country''s amortization burden in the coming years and
restored public confidence. The economy grew about 10% in 2004 as a
result of high commodity prices for Uruguayan exports, the weakness
of the dollar against the euro, growth in the region, low
international interest rates, and greater export competitiveness.
gas 192 km (2004)','63b4ec5e6940057d8069257365347feb2d50bc5a824902ab8b2495b217f6803e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e5f27c66348d89dd38d5cb728a3748e2fe74fa368d44a78f25c105e6aef94a4',2005,'UZ','Uzbekistan','environment',852,'Uzbekistan is a dry, landlocked country of which 11%
consists of intensely cultivated, irrigated river valleys. More than
60% of its population lives in densely populated rural communities.
Uzbekistan is now the world''s second-largest cotton exporter, a
large producer of gold and oil, and a regionally significant
producer of chemicals and machinery. Following independence in
December 1991, the government sought to prop up its Soviet-style
command economy with subsidies and tight controls on production and
prices. Uzbekistan responded to the negative external conditions
generated by the Asian and Russian financial crises by emphasizing
import substitute industrialization and by tightening export and
currency controls within its already largely closed economy. The
government, while aware of the need to improve the investment
climate, sponsors measures that often increase, not decrease, the
government''s control over business decisions. A sharp increase in
the inequality of income distribution has hurt the lower ranks of
society since independence. In 2003, the government accepted the
obligations of Article VIII under the International Monetary Fund
(IMF), providing for full currency convertibility. However, strict
currency controls and tightening of borders have lessened the
effects of convertibility and have also led to some shortages that
have further stifled economic activity.
gas 9,149 km; oil 869 km; refined products 33 km (2004)
Venezuela
extra heavy crude 992 km; gas 5,262 km; oil 7,360 km;
refined products 1,681 km; unknown (oil/water) 141 km (2004)
Vietnam
condensate/gas 432 km; gas 210 km; oil 3 km; refined
products 206 km (2004)','b0590386b3f907400c620a162a77ac27c84e2ff298e6604c8360f24f0636c475','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d404ff53288ef57d67fed667aada574179c3d6370e90abe8ff408751a486f04e',2005,'VU','Vanuatu','environment',853,'This South Pacific island economy is based primarily on
small-scale agriculture, which provides a living for 65% of the
population. Fishing, offshore financial services, and tourism, with
about 50,000 visitors in 2004, are other mainstays of the economy.
Mineral deposits are negligible; the country has no known petroleum
deposits. A small light industry sector caters to the local market.
Tax revenues come mainly from import duties. Economic development is
hindered by dependence on relatively few commodity exports,
vulnerability to natural disasters, and long distances from main
markets and between constituent islands. GDP growth rose less than
3% on average in the 1990s. In response to foreign concerns, the
government has promised to tighten regulation of its offshore
financial center. In mid-2002 the government stepped up efforts to
boost tourism. Agriculture, especially livestock farming, is a
second target for growth. Australia and New Zealand are the main
suppliers of tourists and foreign aid.
Venezuela
Venezuela continues to be highly dependent on the
petroleum sector, accounting for roughly one-third of GDP, around
80% of export earnings, and over half of government operating
revenues. A disastrous two-month national oil strike from December
2002 to February 2003, temporarily halted economic activity. The
economy remained in depression in 2003, declining by 9.2% after an
8.9% fall in 2002. Despite continued domestic instability, output
recovered strongly in 2004, aided by high oil prices. Both inflation
and unemployment remain fundamental problems.
Vietnam
Vietnam is a densely-populated, developing country that in
the last 30 years has had to recover from the ravages of war, the
loss of financial support from the old Soviet Bloc, and the
rigidities of a centrally planned economy. Substantial progress was
achieved from 1986 to 1997 in moving forward from an extremely low
level of development and significantly reducing poverty. Growth
averaged around 9% per year from 1993 to 1997. The 1997 Asian
financial crisis highlighted the problems in the Vietnamese economy
and temporarily allowed opponents of reform to slow progress towards
a market oriented economy. GDP growth of 8.5% in 1997 fell to 6% in
1998 and 5% in 1999. Growth then rose to 7% in 2000-04 even against
the background of global recession. Since 2001, however, Vietnamese
authorities have reaffirmed their commitment to economic
liberalization and international integration. They have moved to
implement the structural reforms needed to modernize the economy and
to produce more competitive, export-driven industries. However,
equitization of state-owned enterprises and reduction in the
proportion of non-performing loans has fallen behind schedule.
Vietnam''s membership in the ASEAN Free Trade Area (AFTA) and entry
into force of the US-Vietnam Bilateral Trade in December 2001 have
led to even more rapid changes in Vietnam''s trade and economic
regime. Vietnam''s exports to the US doubled in 2002 and again in
2003. Vietnam is working toward accession to the WTO in 2005. Among
other benefits, accession will allow Vietnam to take advantage of
the phase out of the Agreement on Textiles and Clothing, which
eliminated quotas on textiles and clothing for WTO partners on 1
January 2005. Vietnam is working to promote job creation to keep up
with the country''s high population growth rate. However, in 2004,
high levels of inflation prompted Vietnamese authorities to tighten
monetary and fiscal policies.
Virgin Islands
Tourism is the primary economic activity, accounting
for 80% of GDP and employment. The islands normally host 2 million
visitors a year. The manufacturing sector consists of petroleum
refining, textiles, electronics, pharmaceuticals, and watch
assembly. The agricultural sector is small, with most food being
imported. International business and financial services are a small
but growing component of the economy. One of the world''s largest
petroleum refineries is at Saint Croix. The islands are subject to
substantial damage from storms. The government is working to improve
fiscal discipline, to support construction projects in the private
sector, to expand tourist facilities, to reduce crime, and to
protect the environment.
Wake Island
Economic activity is limited to providing services to
contractors located on the island. All food and manufactured goods
must be imported.','eda949594a5088bd36ebd31e1ecbb56d7585f26fb6afc101b55e6385d47922a7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd5cd600ffcd3e96d61470882492ba29f65eb0a3ca06a7e31f8b7299b4437674',2005,'WF','Wallis and Futuna','environment',854,'The economy is limited to traditional subsistence
agriculture, with about 80% labor force earnings from agriculture
(coconuts and vegetables), livestock (mostly pigs), and fishing.
About 4% of the population is employed in government. Revenues come
from French Government subsidies, licensing of fishing rights to
Japan and South Korea, import taxes, and remittances from expatriate
workers in New Caledonia.
West Bank
The West Bank - the larger of the two areas under the
Palestine Authority - has experienced a general decline in economic
growth and a degradation in economic conditions made worse since the
second intifadah began in September 2000. The downturn has been
largely the result of the Israeli closure policies - the imposition
of border closures in response to security incidents in Israel -
which disrupted labor and commodity market relationships. In 2001,
and even more severely in 2002, Israeli military measures in
Palestine Authority areas resulted in the destruction of much
capital plant, the disruption of administrative structure, and
widespread business closures. Including the Gaza Strip, the UN
estimates that more than 100,000 Palestinians out of the 125,000 who
used to work in Israeli settlements, or in joint industrial zones,
have lost their jobs. International aid of $2 billion to the West
Bank and Gaza strip in 2004 prevented the complete collapse of the
economy and allowed some reforms in the government''s financial
operations. Meanwhile, unemployment has continued at more than half
the labor force. ARAFAT''s death in 2004 leaves open more political
options that could affect the economy.','76e0a88a8b16f4b7085e7181b254fce2d9da31f2c4a709f1514db3289e3d2f0b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c725ec52040d21aac1805a0b8af01330758cd1704d2edf4b20e8858ed986596',2005,'YE','Yemen','environment',855,'Yemen, one of the poorest countries in the Arab world, has
reported strong growth since 2000, but its economic fortunes depend
mostly on oil. Yemen has embarked on an IMF-supported structural
adjustment program designed to modernize and streamline the economy,
which has led to substantial foreign debt relief and restructuring.
Yemen has worked to maintain tight control over spending and to
implement additional components of the IMF program, but a high
population growth rate and internal political dissension complicate
the government''s task. Plans include a diversification of the
economy, encouragement of tourism, and more efficient use of scarce
water resources.
gas 88 km; oil 1,174 km (2004)','05065d9d6c4c4388bae0679800cdb95419c2cb11b85f07f08c2ffb0e69d2126b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9be045642f7a866e9a4cc70e0e6e34fbe1205834f0ae01cdf34655ed4613ab33',2005,'ZM','Zambia','environment',856,'Despite progress in privatization and budgetary reform,
Zambia''s economic growth remains somewhat below the 5% to 7% needed
to reduce poverty significantly. Privatization of government-owned
copper mines relieved the government from covering mammoth losses
generated by the industry and greatly improved the chances for
copper mining to return to profitability and spur economic growth.
Copper output increased in 2004 and is expected to increase again in
2005, due to higher copper prices and the opening of new mines. The
maize harvest was again good in 2004, helping boost GDP and
agricultural exports. Cooperation continues with international
bodies on programs to reduce poverty, including a new lending
arrangement with the IMF in the second quarter, 2004. A tighter
monetary policy will help cut inflation, but Zambia still has a
serious problem with fiscal discipline.
oil 771 km (2004)','1f36127806c654e73b6cf0af266f66b225c2a3103ab1c3feaa897fc4a3cb67ca','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae22965a3477d7e7a29934f6e92485b3ac1f3bb3216221fd3387d534e801a7b5',2005,'ZW','Zimbabwe','environment',857,'The government of Zimbabwe faces a wide variety of
difficult economic problems as it struggles with an unsustainable
fiscal deficit, an overvalued exchange rate, soaring inflation, and
bare shelves. Its 1998-2002 involvement in the war in the Democratic
Republic of the Congo, for example, drained hundreds of millions of
dollars from the economy. Badly needed support from the IMF has been
suspended because of the country''s failure to meet budgetary goals.
Inflation rose from an annual rate of 32% in 1998 to 133% at the end
of 2004, while the exchange rate fell from 24 Zimbabwean dollars per
US dollar to 6,200 in the same time period. The government''s land
reform program, characterized by chaos and violence, has badly
damaged the commercial farming sector, the traditional source of
exports and foreign exchange and the provider of 400,000 jobs.
This page was last updated on 20 October, 2005
======================================================================
@2117 Pipelines (km)
refined products 261 km (2004)
This page was last updated on 20 October, 2005
======================================================================
@2118 Political parties and leaders','cd44ed07a80c2b7a4c58f0e95cf50ce49109273cd59e2e515556eafa0288595f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('474becb2766c882840c46c3a7751655f2dc21684aaa64a08020f3c60c3c0a30e',2005,'AF','Afghanistan','environment',858,'gas 387 km (2004)
note - includes only political parties approved by the
Ministry of Justice: Afghan Millat [Anwarul Haq AHADI]; De
Afghanistan De Solay Ghorzang Gond [Shahnawaz TANAI]; De Afghanistan
De Solay Mili Islami Gond [Shah Mahmood Polal ZAI]; Harakat-e-Islami
Afghanistan [Mohammad Asif MOHSINEE];
Hezb-e-Aarman-e-Mardum-e-Afghanistan [Iihaj Saraj-u-din ZAFAREE];
Hezb-e-Aazadee Afghanistan [Abdul MALIK]; Hezb-e-Adalat-e-Islami
Afghanistan [Mohammad Kabeer MARZBAN]; Hezb-e-Afghanistan-e-Wahid
[Mohammad Wasil RAHEEMEE]; Hezb-e-Afghan Watan Islami Gond [leader
NA]; Hezb-e-Congra-e-Mili Afghanistan [Latif PEDRAM];
Hezb-e-Falah-e-Mardum-e-Afghanistan [Mohammad ZAREEF];
Hezb-e-Libral-e-Aazadee Khwa-e-Mardum-e-Afghanistan [Ajmal SOHAIL];
Hezb-e-Hambastagee Mili Jawanan-e-Afghanistan [Mohammad Jamil
KARZAI]; Hezb-e-Hamnbatagee-e-Afghanistan [Abdul Khaleq NEMAT];
Hezb-e-Harakat-e-Mili Wahdat-e-Afghanistan [Mohammad Nadir AATASH];
Hezb-e-Harak-e-Islami Mardum-e-Afghanistan [Ilhaj Said Hssain
ANWARY]; Hezb-e-Ifazat Az Uqoq-e-Bashar Wa Inkishaf-e-Afghanistan
[Baryalai NASRATEE]; Hezb-e-Istiqlal-e-Afghanistan [Dr. Gh. Farooq
NIJZRABEE]; Hezb-e-Jamhoree Khwahan [Sibghatullah SANJAR];
Hezb-e-Kar Wa Tawsiha-e-Afghanistan [Zulfiar OMID]; Hezb-e-Mili
Afghanistan [Abdul Rasheed AARYAN]; Hezb-e-Mili
Wahdat-e-Aqwam-e-Islami Afghanistan [Mohammad Shah KHOGYANEE];
Hezb-e-Nuhzhat-e-Mili Afghanistan [Ahmad Wali MASOUD];
Hezb-e-Paiwand-e-Mili Afghanistan [Said Mansoor NADIRI];
Hezb-e-Rastakhaiz-e-Islami Mardum-e-Afghanistan [Said ZAHIR];
Hezb-e-Refah-e-Mardum-e-Afghanistan [Mia Gul WASEEQ];
Hezb-e-Risalat-e-Mardum-e-Afghanistan [Noor Aqa ROEEN];
Hezb-e-Sahadat-e-Mardum-e-Afghanistan [Mohammad Zubair PAIROZ];
Hezb-e-Sahadat-e-Mili Wa Islami Afghanistan [Mohammad Usman
SALIGZADA]; Hezb-e-Sulh-e-Mili Islami Aqwam-e-Afghanistan [Abdul
Qahir SHARYATEE]; Hezb-e-Sulh Wa Wahdat-e-Mili Afghanistan [Abdul
Qadir IMAMEE]; Hezb-e-Tafahum-e-Wa Democracy Afghanistan [Ahamad
SHAHEEN]; Hezb-e-Wahdat-e-Islami Afghanistan [Mohammad Karim
KHALILI]; Hezb-e-Wahdat-e-Islami Mardum-e-Afghanistan [Ustad
Mohammad MOHAQQEQ]; Hezb-e-Wahdat-e-Mili Afghanistan [Abdul Rasheed
Jalili]; Jamahat-ul-Dahwat ilal Qurhan-wa-Sunat-ul-Afghanistan
[Mawlawee Samiullah NAJEEBEE]; Jombesh-e Milli [Abdul Rashid
DOSTAM]; Mahaz-e-Mili Islami Afghanistan [Said Ahmad GAILANEE];
Majmah-e-Mili Fahaleen-e-Sulh-e-Afghanistan [Shams ul Haq Noor
SHAMS]; Nuhzat-e-Aazadee Wa democracy Afghanistan [Abdul Raqeeb
Jawid KUHISTANEE]; Nuhzat-e-Hambastagee Mili Afghanistan [Peer Said
Ishaq GAILANEE]; Sazman-e-Islami Afghanistan-e-Jawan [Siad Jawad
HUSSAINEE]; Tahreek Wahdat-e-Mili [Sultan Mahmood DHAZI] (30 Sep
2004)','8ec8c78b2a888ec9098958d46d3f1725bf28b4b69cd189c614a379330e2ecdea','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44b85c8c3ed89463b0125db81e8a09a294cbc62bc3abe58e102288447e431684',2005,'AL','Albania','environment',859,'gas 339 km; oil 207 km (2004)
Agrarian Environmentalist Party or PAA [Lufter XHUVELI];
Christian Democratic Party or PDK [Nikolle LESI]; Communist Party of
Albania or PKSH [Hysni MILLOSHI]; Democratic Alliance Party or PAD
[Neritan CEKA]; Democratic Party or PD [Sali BERISHA]; Legality
Movement Party or PLL [Ekrem SPAHIU]; Liberal Union Party or PBL
[Arjan STAROVA]; National Front Party (Balli Kombetar) or PBK
[Adriatik ALIMADHI]; New Democratic Party or PDR [Genc POLLO]; Party
of National Unity or PUK [Idajet BEQIRI]; Renewed Democratic Party
or PDR [Dashamir SHEHI]; Republican Party or PR [Fatmir MEDIU];
Social Democracy Party or PDS [Paskal MILO]; Social Democratic Party
or PSD [Skender GJINUSHI]; Socialist Movement for Integration or LSI
[Ilir META]; Socialist Party or PS (formerly the Albanian Party of
Labor) [Fatos NANO]; Union for Human Rights Party or PBDNJ [Vangjel
DULE]','2c18061562a80f3b068793e1a2ec501c68db0a607b6404cae125606ae2938984','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3ac12e5b456adbb2483db1744fa68fa7d9487d67003d83c04250d938a8464f9',2005,'DZ','Algeria','environment',860,'condensate 1,344 km; gas 85,946 km; liquid petroleum gas
2,213 km; oil 6,496 km (2004)
Algerian National Front or FNA [Moussa TOUATI]; Democratic
National Rally or RND [Ahmed OUYAHIA, chairman]; Islamic Salvation
Front or FIS (outlawed April 1992) [Ali BELHADJ and Dr. Abassi
MADANI, Rabeh KEBIR (self-exiled in Germany)]; National Entente
Movement or MEN [Ali BOUKHAZNA]; National Liberation Front or FLN
[Abdelaziz BELKHADEM, secretary general (also serves as Foreign
Minister)]; National Reform Movement or Islah (formerly MRN)
[Abdellah DJABALLAH]; National Renewal Party or PRA [Yacine
TERKMANE]; Progressive Republican Party [Khadir DRISS]; Rally for
Culture and Democracy or RCD [Said SAADI, secretary general];
Renaissance Movement or EnNahda Movement [Fatah RABEI]; Socialist
Forces Front or FFS [Hocine Ait AHMED, secretary general
(self-exiled in Switzerland)]; Social Liberal Party or PSL [Ahmed
KHELIL]; Society of Peace Movement or MSP [Boujerra SOLTANI];
Workers Party or PT [Louisa HANOUN]
note: a law banning political parties based on religion was enacted
in March 1997','9e90475be69c978bee8a3308473370820ab046a56a1f69743de46d33b899fff2','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c3b37584e13f844b52a378a06ddf6e09a2b5b640c0d5453b1a90269c3e6526b',2005,'AO','Angola','environment',861,'gas 214 km; liquid natural gas 14 km; liquid petroleum gas 30
km; oil 837 km; refined products 56 km (2004)
Liberal Democratic Party or PLD [Analia de Victoria PEREIRA];
National Front for the Liberation of Angola or FNLA [disputed
leadership: Lucas NGONDA, Holden ROBERTO]; National Union for the
Total Independence of Angola or UNITA [Isaias SAMAKUVA], largest
opposition party has engaged in years of armed resistance; Popular
Movement for the Liberation of Angola or MPLA [Jose Eduardo DOS
SANTOS], ruling party in power since 1975; Social Renewal Party or
PRS [disputed leadership: Eduardo KUANGANA, Antonio MUACHICUNGO]
note: about a dozen minor parties participated in the 1992 elections
but only won a few seats and have little influence in the National
Assembly','fa27940c1a3ea812e557e9fdfac7059e020e9c1a3a458e63592adea5b50bde1f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08232746cc1fcf7642479069299aa472336adfd9da4b6ecbad8d34ecb4b67347',2005,'AR','Argentina','environment',862,'gas 27,166 km; liquid petroleum gas 41 km; oil 3,668 km;
refined products 2,945 km; unknown (oil/water) 13 km (2004)
Action for the Republic or AR [Domingo CAVALLO];
Alternative for a Republic of Equals or ARI [Elisa CARRIO]; Federal
Recreate Movement or RECREAR [Ricardo LOPEZ MURPHY]; Front for a
Country in Solidarity or Frepaso (a four-party coalition) [Dario
Pedro ALESSANDRO]; Interbloque Federal or IF (a broad coalition of
approximately 12 parties including RECREAR) [leader NA];
Justicialist Party or PJ (Peronist umbrella political organization)
[leader NA]; Radical Civic Union or UCR [Angel ROZAS]; Socialist
Party or PS [Ruben GIUSTINIANI]; Union For All [Patricia BULLRICH];
several provincial parties','f6cc0bbd6f71a898cca93ad00a2bcece53591e43d5e2b0dd58eac60306c0a9b0','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ade6469aed18da76c622a8798aeacc2466bc74804a9cb84b308db6187db1cdd',2005,'AM','Armenia','environment',863,'gas 1,871 km (2004)
Agro-Industrial Party [Vladimir BADALIAN]; Armenia Party
[Myasnik MALKHASYAN]; Armenian National Movement or ANM [Alex
ARZUMANYAN, chairman]; Armenian Ramkavar Liberal Party or HRAK
[Harutyun MIRZAKHANYAN, chairman]; Armenian Revolutionary Federation
("Dashnak" Party) or ARF [Vahan HOVHANISSIAN]; Democratic Party
[Aram SARKISYAN]; Justice Bloc (comprised of the Democratic Party,
National Democratic Party, National Democratic Union, and the
People''s Party) [Stepan DEMIRCHYAN]; National Democratic Party
[Shavarsh KOCHARIAN]; National Democratic Union or NDU [Vazgen
MANUKIAN]; National Unity Party [Artashes GEGAMIAN, chairman];
People''s Party of Armenia [Stepan DEMIRCHYAN]; Republic Party
[Albert BAZEYAN and Aram SARKISYAN, chairmen]; Republican Party or
RPA [Andranik MARKARYAN]; Rule of Law Party [Artur BAGDASARIAN,
chairman]; Union of Constitutional Rights [Hrant KHACHATURYAN];
United Labor Party [Gurgen ARSENIAN]','0a452bdee52ccb1dd7040b6bca35b52c3226c855257a2fb0ac1c1384d05212aa','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ceb0c23ff7abf2548000327d7fe094d81869897314829708e497d317874b67f',2005,'AU','Australia','environment',864,'condensate/gas 492 km; gas 28,680 km; liquid petroleum gas
240 km; oil 4,773 km; oil/gas/water 110 km (2004)
Australian Democrats [Lyn ALLISON]; Australian Labor Party
[Kim BEAZLEY]; Australian Progressive Alliance [Meg LEES];
Australian Greens [Bob BROWN]; Liberal Party [John Winston HOWARD];
The Nationals [Mark VAILE]; One Nation Party [Len HARRIS]; Family
First Party [Steve FIELDING]','93436cab0d3b2d8b191051d5270707ff257284d51698b0f6a9bbbbcbc2dcfda8','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e8d98a9a8d3ddbe723fca6d4a0516ce69fa863ab701a20581f574b4a8989d4c',2005,'AT','Austria','environment',865,'gas 2,722 km; oil 663 km; refined products 149 km (2004)
Alliance for the Future of Austria or BZOe [Joerg HAIDER];
Austrian People''s Party or OeVP [Wolfgang SCHUESSEL]; Freedom Party
of Austria or FPOe [Heinz Christian STRACHE]; Social Democratic
Party of Austria or SPOe [Alfred GUSENBAUER]; The Greens [Alexander
VAN DER BELLEN]','56f2b6441a81b9d1cb6f84703de5e3f0d43534bf0a733e7730224c6a82aebcd9','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('547b5ba38619c0af8f46dca0b18683309468ce6e8534eb7eea04305da300e903',2005,'AZ','Azerbaijan','environment',866,'gas 4,451 km; oil 1,518 km (2004)
Azerbaijan Popular Front or APF [Ali KARIMLI, leader of
"Reform" faction; Mirmahmud MIRALI-OGLU, leader of "Classic"
faction]; Civic Solidarity Party or CSP [Sabir RUSTAMKHANLY]; Civic
Union Party [Ayaz MUTALIBOV]; Communist Party of Azerbaijan or CPA
[Ramiz AHMADOV]; Compatriot Party [Mais SAFARLI]; Democratic Party
for Azerbaijan or DPA [Rasul QULIYEV, chairman]; Justice Party
[Ilyas ISMAILOV]; Liberal Party of Azerbaijan [Lala Shovkat
HACIYEVA]; Musavat [Isa GAMBAR, chairman]; New Azerbaijan Party or
NAP [vacant]; Party for National Independence of Azerbaijan or PNIA
[Etibar MAMMADLI, chairman]; Social Democratic Party of Azerbaijan
or SDP [Araz ALIZADE and Ayaz MUTALIBOV]
note: opposition parties regularly factionalize and form new parties
Bahamas, The
Free National Movement or FNM [Tommy TURNQUEST];
Progressive Liberal Party or PLP [Perry CHRISTIE]','3cd85cbde78498c7550aa2e9097dc8738eca2209cc63f10c596b6265ce7d0daf','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d9d4f7a1d92e8d4490de6891460eadfa6c18724ed730d85516064981f736bc8',2005,'BH','Bahrain','environment',867,'gas 20 km; oil 53 km (2004)
political parties prohibited but politically oriented
societies are allowed','f34ca2c75bf8195500f929960e24b957e20311d540b670c17f9d54a4fb380966','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74d624752d889e32382fdfe5ae0201adf4257e504ad5764b8824a14e6a4e25e7',2005,'BD','Bangladesh','environment',868,'gas 2,012 km (2004)
Awami League or AL [Sheikh HASINA]; Bangladesh Communist
Party or BCP [Saifuddin Ahmed MANIK]; Bangladesh Nationalist Party
or BNP [Khaleda ZIA, chairperson]; Islami Oikya Jote or IOJ [Mufti
Fazlul Haq AMINI]; Jamaat-e-Islami or JI [Motiur Rahman NIZAMI];
Jatiya Party or JP (Ershad faction) [Hussain Mohammad ERSHAD];
Jatiya Party (Manzur faction) [Naziur Rahman MANZUR]','4d25b94efc045b06baad1f3f1988a0f01272dd3dafe578fd778ee0f6ee134898','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4271b8289dd8c33846654126c56528a498a8b4b4930de87daa522ed582d3a0b9',2005,'BY','Belarus','environment',869,'gas 5,223 km; oil 2,443 km; refined products 1,686 km (2004)
Pro-government parties: Agrarian Party or AP [leader NA];
Belarusian Communist Party or KPB [leader NA]; Belarusian Patriotic
Movement (Belarusian Patriotic Party) or BPR [Anatoliy BARANKEVICH,
chairman]; Liberal Democratic Party of Belarus [Sergei GAYDUKEVICH];
Social-Sports Party [leader NA]; Opposition parties: Belarusian
Popular Front or BNF [Vintsuk VYACHORKA]; Belarusian Social-Democrat
Party Narodnaya Gromada or BSDP NG [Nikolay STATKEVICH, chairman];
Belarusian Social-Democratic Party Hromada [Stanislav SHUSHKEVICH,
chairman]; United Civic Party or UCP [Anatol LEBEDKO]; Party of
Communists Belarusian or PKB [Sergei KALYAKIN, chairman]; Women''s
Party "Nadezhda" [Valentina MATUSEVICH, chairperson]
note: the opposition Belarusian Party of Labor [Aleksandr
BUKHVOSTOV] was liquidated in August 2004, but remains active','b6a9b37367b7256bb7b4f5a1e06e5ed411e09e2c8ea0d62ef7605a43a5562287','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('545d051565291a5cb62da0966f5fa93cac2813fada562766419423702b597b60',2005,'BE','Belgium','environment',870,'gas 1,485 km; oil 158 km; refined products 535 km (2004)
Bolivia
gas 4,860 km; liquid petroleum gas 47 km; oil 2,457 km;
refined products 1,589 km; unknown (oil/water) 247 km (2004)
Flemish parties: Christian Democrats and Flemish or CD & V
[Jo VANDEURZEN]; Flemish Liberal Democrats or VLD [Bart SOMERS];
GROEN! (formerly AGALEV, Flemish Greens) [Vera DUA]; New Flemish
Alliance or NVA [Bart DE WEVER]; Socialist Party.Alternative or SP.A
[Caroline GENNEZ]; Spirit [Geert LAMBERT] (new party now associated
with SP.A); Vlaams Belang (Flemish Interest) or VB [Frank VANHECKE]
Francophone parties: Ecolo (Francophone Greens) [Jean-Michel JAVAUX,
Evelyne HUYTEBROECK, Claude BROUIR]; Humanist and Democratic Center
of CDH [Joelle MILQUET]; National Front or FN [Daniel FERET];
Reformist Movement or MR [Didier REYNDERS]; Socialist Party or PS
[Elio DI RUPO]; other minor parties','b0cbc9ace621a0bdde0c22c9d20c39bd22685a84ee8d8fd1eaeb306ab89d5dcd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6720c67fa338fc9a6045e9d792c5872d68b2c3cca62e3bcee63b18fa55dd6351',2005,'BR','Brazil','environment',871,'condensate/gas 244 km; gas 10,739 km; liquid petroleum gas
341 km; oil 5,212 km; refined products 4,755 km (2004)
Brunei
gas 665 km; oil 439 km (2004)
Brazilian Democratic Movement Party or PMDB [Federal Deputy
Michel TEMER]; Brazilian Labor Party or PTB [Federal Deputy Roberto
JEFFERSON]; Brazilian Social Democracy Party or PSDB [Senator
Eduardo AZAREDO]; Brazilian Socialist Party or PSB [Federal Deputy
Miguel ARRAES]; Communist Party of Brazil or PCdoB [Renato RABELO];
Democratic Labor Party or PDT [Carlos LUPI]; Democratic Socialist
Party or PSD [Pedro Miguel SANTANA LOPES]; Green Party or PV [Jose
Luiz de Franca PENNA]; Liberal Front Party or PFL [Senator Jorge
BORNHAUSEN]; Liberal Party or PL [Federal Deputy Valdemar COSTA
Neto]; National Order Reconstruction Party or PRONA [Federal Deputy
Dr. Eneas CARNEIRO]; Popular Socialist Party or PPS [Federal Deputy
Roberto FREIRE]; Progressive Party or PP [Federal Deputy Pedro
CORREA]; Social Christian Party or PSC [Vitor Jorge ABDALA NOSSEIS];
Worker''s Party or PT [Jose GENOINO]
British Virgin Islands
Concerned Citizens Movement or CCM [Ethlyn
SMITH]; National Democratic Party or NDP [Orlando SMITH]; United
Party or UP [Gregory MADURO]; Virgin Islands Party or VIP [Ralph T.
O''NEAL]
Brunei
National Development Party (NDP) [Yassin AFFENDI]; National
Unity Party of Brunei (PPKB) [leader NA]; People''s Awareness Party
(PAKAR) [leader NA]
note: parties are small and inactive (2005)','a46bfe8847ddac6888d61a480cbe5cb1c43cca7f12679eebb039836df655232d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb71eb11551c295edbfda1b6767630acd3dfeae0b706ca8fcd702c5c0efd6e9d',2005,'BG','Bulgaria','environment',872,'gas 2,425 km; oil 339 km; refined products 156 km (2004)
Burma
gas 2,056 km; oil 558 km (2004)
Attack National Union [Volen Siderov]; ATAKA (Attack
Coalition) (coalition of parties headed by the Attack National
Union); Bulgarian Agrarian National Union-People''s Union or BANU
[Anastasia MOZER]; Bulgarian People''s Union or BPU (coalition of
UFD, IMRO, and BANU); Bulgarian Socialist Party or BSP [Sergei
STANISHEV]; Coalition for Bulgaria or CfB (coalition of parties
dominated by BSP) [Sergei STANISHEV]; Democrats for a Strong
Bulgaria or DSB [Ivan KOSTOV]; Internal Macedonian Revolutionary
Organization or IMRO [Krasimir KARAKACHANOV]; Movement for Rights
and Freedoms or MRF [Ahmed DOGAN]; National Movement for Simeon II
or NMS2 [Simeon SAXE-COBURG-GOTHA]; New Time [Emil KOSHLUKOV]; Union
of Democratic Forces or UDF [Nadezhda MIKHAYLOVA]; Union of Free
Democrats or UFD [Stefan SOFIYANSKI]; United Democratic Forces or
UtDF (a coalition of center-right parties dominated by UDF)','859c3ddc037c072ac77db13e1ee278714d3841ac4ce67920e8d5a3edfb94c9d3','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b7e067c31d8d0e12833388ab97b05bef4a17c73be2e58f128124cab71748b15',2005,'CM','Cameroon','environment',873,'gas 90 km; liquid petroleum gas 9 km; oil 1,120 km (2004)
Cameroonian Democratic Union or UDC [Adamou NDAM NJOYA];
Democratic Rally of the Cameroon People or RDCP [Paul BIYA];
Movement for the Defense of the Republic or MDR [Dakole DAISSALA];
Movement for the Liberation and Development of Cameroon or MLDC
[leader Marcel YONDO]; Movement for the Youth of Cameroon or MYC
[Dieudonne TINA]; National Union for Democracy and Progress or UNDP
[Maigari BELLO BOUBA]; Social Democratic Front or SDF [John FRU
NDI]; Union of Cameroonian Populations or UPC [Augustin Frederic
KODOCK]','dc78efa718fb3637ecb75b0869194a3c8128c208356305dbed864bcdd28d72a4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d034de17de522b571936d18c84a5265d4477b6fec9ae957ed779d2e87d1ad1f3',2005,'CA','Canada','environment',874,'crude and refined oil 23,564 km; liquid petroleum gas 74,980
km (2003)
Bloc Quebecois [Gilles DUCEPPE]; Conservative Party of Canada
(a merger of the Canadian Alliance and the Progressive Conservative
Party) [Stephen HARPER]; Green Party [Jim HARRIS]; Liberal Party
[Paul MARTIN]; New Democratic Party [Jack LAYTON]
Cape Verde
African Party for Independence of Cape Verde or PAICV
[Jose Maria Pereira NEVES, chairman]; Democratic Alliance for Change
or ADM [Dr. Eurico MONTEIRO] (a coalition of PCD, PTS, and UCID);
Democratic Christian Party or PDC [Manuel RODRIGUES, chairman];
Democratic Renovation Party or PRD [Jacinto SANTOS, president];
Movement for Democracy or MPD [Agostinho LOPES, president]; Party
for Democratic Convergence or PCD [Dr. Eurico MONTEIRO, president];
Party of Work and Solidarity or PTS [Isaias RODRIGUES, president];
Social Democratic Party or PSD [Joao ALEM, president]','52b3fdf234f60da6749fc6ecfbff550adef0dcc1eb50a857b361b16877847703','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9360b2f153bf91c63de09b5f9c17b668411f075cca067f2156dd51a319396df9',2005,'TD','Chad','environment',875,'oil 205 km (2004)
Federation Action for the Republic or FAR [Ngarlejy YORONGAR];
National Rally for Development and Progress or RNDP [Mamadou BISSO];
National Union for Democracy and Renewal or UNDR [Saleh KEBZABO];
Patriotic Salvation Movement or MPS [Mahamat Saleh AHMAT, chairman];
Rally for Democracy and Progress or RDP [Lol Mahamat CHOUA]; Union
for Renewal and Democracy or URD [Gen. Wadal Abdelkader KAMOUGUE];
Viva Rally for Development and Progress or Viva RNDP [Delwa Kassire
COUMAKOYE]','ab44f76f42076c143df6e526e042ea11e4272bae0fba4352605d18cd77c67aec','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a2112f5fe72d522c0b37bf3a493b308765c3aab3edbb6828d12b54af386624f',2005,'CL','Chile','environment',876,'gas 2,583 km; gas/lpg 42 km; liquid petroleum gas 539 km; oil
1,003 km; refined products 757 km (2004)
Alliance for Chile ("Alianza") or APC (including National
Renewal or RN [Sebastian PINERA] and Independent Democratic Union or
UDI [Pablo LONGUEIRA]); Coalition of Parties for Democracy
("Concertacion") or CPD (including Christian Democratic Party or PDC
[Adolfo ZALDIVAR], Socialist Party or PS [Gonzalo MARTNER], Party
for Democracy or PPD [Victor BARRUETO], Radical Social Democratic
Party or PRSD [Orlando CANTUARIAS]); Communist Party or PC [Gladys
MARIN]','670a96c5ec20618e81cd84704d8dbff023013dd1af4951ec8668af05a33afc44','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc57f446c372efe35fdc4cf460353944e45cf0f4a5049adea4f6efceedc62c3a',2005,'CN','China','environment',877,'gas 15,890 km; oil 14,478 km; refined products 3,280 km (2004)
Chinese Communist Party or CCP [HU Jintao, General Secretary
of the Central Committee]; eight registered small parties controlled
by CCP','5127ece6d4cad0813b036505646dcdb5ad0650e10b7b6d5e04256fda74268127','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0207b3af0451d74d04b853933f0718408408bf1a520cabab26f845b5b044e35e',2005,'CO','Colombia','environment',878,'gas 4,360 km; oil 6,134 km; refined products 3,140 km (2004)
Congo, Democratic Republic of the
gas 54 km; oil 71 km (2004)
Congo, Republic of the
gas 53 km; oil 646 km (2004)
Colombian Communist Party or PCC [Jaime CAICEDO];
Conservative Party or PSC [Carlos HOLGUIN Sardi]; Democratic Pole or
PDI [Samuel MORENO Rojas]; Liberal Party or PL [Juan Fernando CRISTO]
note: Colombia has about 60 formally recognized political parties,
most of which do not have a presence in either house of Congress','3f4564bf5730e15c078be800519b40777b3b3b001de09453152fe0d06dd4135b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6588d466db4e901b4ff3f90e5d60801d993604fa8b29ed2ceae05a7cc68dc978',2005,'CR','Costa Rica','environment',879,'refined products 242 km (2004)
Cote d''Ivoire
condensate 107 km; gas 223 km; oil 104 km (2004)
Authentic Member from Heredia [Jose SALAS]; Citizen
Action Party or PAC [Otton SOLIS]; Costa Rican Renovation Party or
PRC [Justo OROZCO]; Democratic Force Party or PFD [Juan Carlos
CHAVES Mora]; Democratic National Alliance [Emilia RODRIGUEZ];
General Union Party or PUGEN [Carlos Alberto FERNANDEZ Vega];
Homeland First [Juan Jose VARGAS]; Independent Worker Party or PIO
[Jose Alberto CUBERO Carmona]; Libertarian Movement Party or PML
[Otto GUEVARA Guth]; National Christian Alliance Party or ANC
[Victor GONZALEZ]; National Integration Party or PIN [Walter MUNOZ
Cespedes]; National Liberation Party or PLN [Francisco Antonio
PACHECO]; National Patriotic Party or PPN [Daniel Enrique REYNOLDS
Vargas]; National Rescue Party or PRN [Carlos VARGAS Solano];
Patriotic Union [Humberto ARCE]; Popular Vanguard [Trino BARRANTES
Araya]; Social Christian Unity Party or PUSC [Lorena VASQUEZ Badilla]
Cote d''Ivoire
Citizen''s Democratic Union or UDCY [Eg Theodore MEL];
Democratic Party of Cote d''Ivoire-African Democratic Rally or
PDCI-RDA [Henri Konan BEDIE]; Ivorian Popular Front or FPI [Laurent
GBAGBO]; Ivorian Worker''s Party or PIT [Francis WODIE]; Rally of the
Republicans or RDR [Alassane OUATTARA]; Union for Democracy and
Peace or UDPCI [Paul Akoto YAO]; over 20 smaller parties','f3fb3eaee9e92cd5cfe64eef95ef980f6e5acfd4f9c36dc8b6e952c788cf23c9','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('148beadde3108c872dbaa48aed120c77f9834a6bb725ba732bf020bdf0af301d',2005,'HR','Croatia','environment',880,'gas 1,340 km; oil 583 km (2004)
Croatian Bloc or HB [Ivic PASALIC]; Croatian Christian
Democratic Union or HKDU [Anto KOVACEVIC]; Croatian Democratic Union
or HDZ [Ivo SANADER]; Croatian Party of Rights or HSP [Anto DJAPIC];
Croatian Peasant Party or HSS [Zlatko TOMCIC]; Croatian Pensioner
Party or HSU [Vladimir JORDAN]; Croatian People''s Party or HNS
[Vesna PUSIC] (in 2005 party merged with Libra to become Croatian
People''s Party-Liberal Democrats or NS-LD [Vesna PUSIC]); Croatian
Social Liberal Party or HSLS [Ivan CEHOK]; Croatian True Revival
Party or HIP [Miroslav TUDJMAN]; Democratic Centre or DC [Vesna
SKARE-OZBOLT]; Independent Democratic Serb Party or SDSS [Vojislav
STANIMIROVIC]; Istrian Democratic Assembly or IDS [Ivan JAKOVCIC];
Liberal Party or LS [Zlatko BENASIC]; Party of Liberal Democrats or
Libra [Jozo RADOS] (in 2005 merged with HNS); Social Democratic
Party of Croatia or SDP [Ivica RACAN]','5e790a414dcd92dee5d76a4e03644726b7a8234e8e8478c5dc3e3ba5a03b63b2','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c84343593869486c928548b4c8bfcbdc8a47a78356edf55b9a8a7b8ab6f24cb',2005,'CU','Cuba','environment',881,'gas 49 km; oil 230 km (2004)
Czech Republic
gas 7,020 km; oil 547 km; refined products 94 km
(2004)
only party - Cuban Communist Party or PCC [Fidel CASTRO Ruz,
first secretary]','2273e76421d0198d51a2699a2b5b627d0b64ca7138138ac06e8793b32b61efd2','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df6b73564fdff8d13bc357c2a17e2034504bb2388f511af51392a75d1208dfae',2005,'DK','Denmark','environment',882,'condensate 12 km; gas 3,892 km; oil 455 km; oil/gas/water 2
km; unknown (oil/water) 64 km (2004)
Center Democratic Party [Mimi JAKOBSEN]; Christian Democrats
(was Christian People''s Party) [Marianne KARLSMOSE]; Conservative
Party (sometimes known as Conservative People''s Party) [Bendt
BENDTSEN]; Danish People''s Party [Pia KJAERSGAARD]; Liberal Party
[Anders Fogh RASMUSSEN]; Social Democratic Party [Helle
THORNING-SCHMIDT]; Social Liberal Party (sometimes called the
Radical Left) [Marianne JELVED, leader; Soren BALD, chairman];
Socialist People''s Party [Villy SOEVNDAL]; Red-Green Unity List
(bloc includes Left Socialist Party, Communist Party of Denmark,
Socialist Workers'' Party) [collective leadership]','5014f9eeafac554c9a761435407c8e57a1c610b5e91db7d134d265f53e03fd39','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ec165234f39391c9a9b98601601a357612849798bb1f0cf5f676408838df7f4',2005,'EC','Ecuador','environment',883,'extra heavy crude 578 km; gas 71 km; oil 1,386 km; refined
products 1,185 km (2004)
Concentration of Popular Forces or CFP [Averroes BUCARAM];
Democratic Left or ID [Guillermo LANDAZURI]; National Action
Institutional Renewal Party or PRIAN [Alvaro NOBOA]; Pachakutik
Movement [Gilberto TALAHUA]; Patriotic Society Party or PSP [Lucio
GUTIERREZ Borbua]; Popular Democracy or DP [Dr. Juan Manuel
FUERTES]; Popular Democratic Movement or MPD [Gustavo TERAN Acosta];
Radical Alfarista Front or FRA [Fabian ALARCON, director]; Roldosist
Party or PRE [Abdala BUCARAM Ortiz, director]; Social Christian
Party or PSC [Leon FEBRES CORDERO]; Socialist Party - Broad Front or
PS-FA [Victor GRANDA]','580096183dbd2873589925cec70e452876fb205f56cfd9e5b3135f1959aa1ae1','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89e6d81486c8bc5c2ee5d8cc09d57f9db964044afb81e29975e15adc0a4d4672',2005,'EG','Egypt','environment',884,'condensate 289 km; condensate/gas 94 km; gas 6,115 km; liquid
petroleum gas 852 km; oil 5,032 km; oil/gas/water 36 km; refined
products 246 km (2004)
Al-Ahrar Party [Helmi SALEM]; Nasserist Arab Democratic Party
or Nasserists [Dia'' al-din DAWUD]; National Democratic Party or NDP
[Mohammed Hosni MUBARAK (governing party)]; National Progressive
Unionist Grouping or Tagammu [Rifaat EL-SAID]; New Wafd Party or NWP
[No''man GOMAA]
note: formation of political parties must be approved by the','3b33f4665acbc8ba68c93eb6225adb4f819c9f9113e5583b68644fedf524cc85','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('debf673731a5620da1c6d314969ea5ac77ba3c5bcf18e81fa1373d4b0dec50f0',2005,'DE','Germany','environment',885,'condensate 325 km; gas 25,293 km; oil 3,540 km; refined
products 3,827 km (2004)','0a65f7245dbb1b5df7e30aa3923dbcfd2cdfef9a80a22e0ef408a7062c752d3c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eacb49abbcdf507349d4bae324d2b46cb816fedc09db8dc5d4ce817d787f5951',2005,'IN','India','environment',886,'gas 6,171 km; liquid petroleum gas 1,195 km; oil 5,613 km;
refined products 5,567 km (2004)','943c24f8db1177d544a59757392913f28ccb119139f11419e0b070a1b09004bd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0474e86872691ce3be6fa435c5da0d3b18fe64ced9ba6a0f47283a6bc684ef7f',2005,'ID','Indonesia','environment',887,'condensate 850 km; condensate/gas 128 km; gas 8,506 km;
oil 7,472 km; oil/gas/water 66 km; refined products 1,329 km (2004)
Iran
condensate/gas 212 km; gas 16,998 km; liquid petroleum gas 570
km; oil 8,256 km; refined products 7,808 km (2004)','d1700577ace21c138dbc25bf9db5b1df99387e78109adee5b204955d225eb7da','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e602c270ad590998edb6d382bbac58aeb9596fc275a063231dd2c798005815c',2005,'KZ','Kazakhstan','environment',888,'condensate 18 km; gas 10,370 km; oil 10,158 km; refined
products 1,187 km (2004)','41f05c3d9f2c5cc33956dc845053a5096d01bc5f8199419918773bfe6748494f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a17650d7de575c5c42c858ed879d34adaffd3dd17b3887920a5da91a71b8bd8',2005,'KE','Kenya','environment',889,'refined products 752 km (2004)
Korea, North
oil 154 km (2004)
Korea, South
gas 1,433 km; refined products 827 km (2004)','0839bc1617c810ae6244f43f855795c890d1f88a30fc85b0fb1210fe36e8c3a0','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6301282d43c491a637d77241ba073139c419c58b8d21d9f817c9f5ecfb86fbd',2005,'MX','Mexico','environment',890,'crude oil 28,200 km; petroleum products 10,150 km; natural
gas 13,254 km; petrochemical 1,400 km (2003)
Moldova
gas 606 km (2004)','0d25f02b46fbbfbf9c34a99169bfe4e8668331e997ae5fcc018f5d37c0b0289b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04e851a5b112b005a3a77cc2fe4e1ce4233c1ba12b616ed6b5432863ccda48e5',2005,'NZ','New Zealand','environment',891,'gas 2,213 km; liquid petroleum gas 79 km; oil 160 km;
refined products 304 km (2004)','a2007d341b75bb9ace7ceb37d03f17c6c057accf675ef6080e4548cd64428d43','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9836b8097cc220e4ab6da77917a6ee665b2f9c7c2ef57f2307e661d39d291ec2',2005,'NO','Norway','environment',892,'condensate 411 km; gas 6,199 km; oil 2,213 km; oil/gas/water
746 km; unknown (oil/water) 38 km (2004)','6843cf162f6e04f4459d2d6f581bca9e0a9d5c570b4fb38abb547e46306eb671','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f9fa207391dbdb32455d67adbe9a6d46de2e5f773e9a8f4032f628ac449ed1c',2005,'QA','Qatar','environment',893,'condensate 319 km; condensate/gas 209 km; gas 1,024 km; liquid
petroleum gas 87 km; oil 702 km; oil/gas/water 41 km (2004)','b34a4000eca7c638e37150a938c4bba324eb7bd193505d6a3f2abd1cedf250fa','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('657fd761e1be13554c1325e7d56b39e00d5c0dbe6fceb59f84e50792b51699b9',2005,'AD','Andorra','environment',894,'Andorran Democratic Center Party or CDA (formerly Democratic
Party or PD) [leader NA]; Liberal Party of Andorra or PLA (formerly
Liberal Union or UL) [Albert PINTAT]; Social Democratic Party or PS
(formerly part of National Democratic Group or AND) [Mariona
GONZALEZ REOLIT]','44e6697f6a461d990c5b2c2e04ca46be0aa0cdaca9e4da22733ce7b2772d4b3d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a707b1dd35a297d12ecf08157c1de8d5647f6a2c4bac7c422f21f83ebc83e29e',2005,'AI','Anguilla','environment',895,'Anguilla United Movement or AUM [Hubert HUGHES]; The
Anguilla United Front or AUF [Osbourne FLEMING, Victor BANKS], a
coalition of the Anguilla Democratic Party or ADP and the Anguilla
National Alliance or ANA; Anguilla Progressive Party or APP [Roy
ROGERS]; Anguilla Strategic Alternative or ANSA [Edison BAIRD]','c8fad5fba9bfcc7c075b8d47f8aae830a5845219418c6d8b93acca38a639e98f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('185235a53b189164d77424fe5f30d445bfbf8702506d4c8abeaf617955da2117',2005,'AG','Antigua and Barbuda','environment',896,'Antigua Labor Party or ALP [Lester Bryant BIRD];
Barbuda People''s Movement or BPM [Thomas H. FRANK]; United
Progressive Party or UPP [Baldwin SPENCER] (a coalition of three
opposition parties - United National Democratic Party or UNDP,
Antigua Caribbean Liberation Movement or ACLM, and Progressive Labor
Movement or PLM)','d46e878adc8c6c880bd72c900a48b5a176598b0c9c78b1a5ff51d3af0b9455d4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1aa7f3fa0e31676a7f32365d015faebf9661262878a4d4b49d352bad4372ef00',2005,'AW','Aruba','environment',897,'Aliansa/Aruban Social Movement or MSA [Robert WEVER]; Aruban
Liberal Organization or OLA [Glenbert CROES]; Aruban Patriotic
Movement or MPA [Monica ARENDS-KOCK]; Aruban Patriotic Party or PPA
[Benny NISBET]; Aruban People''s Party or AVP [Mike EMAN]; People''s
Electoral Movement Party or MEP [Nelson O. ODUBER]; Real Democracy
or PDR [Andin BIKKER]; RED [Rudy LAMPE]; Workers Political Platform
or PTT [Gregorio WOLFF]','82465de97fc0821b75b0c92a078cdaac39e080cbaf3c3aafbeacd2d6e2d610cc','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6894dc9d035ba7f6b89497185a8109afe4388d20a2c9c6ab51186b9ef1a5d00c',2005,'BB','Barbados','environment',898,'Barbados Labor Party or BLP [Owen ARTHUR]; Democratic Labor
Party or DLP [Clyde Mascoll]','08445392fc2feb263e83949fa7544a5de92eac0710239fc47d9c6cea45d05ee8','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('271376aecd77a316e6a2de26f8cb0bc8229c00a03365814adda9c6c290f3a69a',2005,'BZ','Belize','environment',899,'People''s United Party or PUP [Said MUSA]; United Democratic
Party or UDP [Dean BARROW, party leader; Douglas SINGH, party
chairman]','d475c36d0bec5ad554d5be8d3cbbef7f5972c512e19bfa996138d65321825315','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59cc7081bf470622b107a1b9c68b7b04a977988e72df76026ecd5d049948f328',2005,'BJ','Benin','environment',900,'African Congress for Renewal or DUNYA [Saka SALEY]; African
Movement for Democracy and Progress or MADEP [Sefou FAGBOHOUN];
Alliance of the Social Democratic Party or PSD [Bruno AMOUSSOU];
Coalition of Democratic Forces [Gatien HOUNGBEDJI]; Democratic
Renewal Party or PRD [Adrien HOUNGBEDJI]; Front for Renewal and
Development or FARD-ALAFIA [Jerome Sakia KINA]; Impulse for Progress
and Democracy or IPD [Bertin BORNA]; Key Force or FC [leader NA];
Presidential Movement (UBF, MADEP, FC, IDP, and four small parties);
Renaissance Party du Benin or PRB [Nicephore SOGLO]; The Star
Alliance (Alliance E''toile) [Sacca LAFIA]; Union of Tomorrow''s Benin
or UBF [Bruno AMOUSSOU]
note: approximately 20 additional minor parties','ecf673cc924326a19155fc95501d8a944b56c554136cc02aa5e1521a5274aa3d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('535769414ec97e6b0dca3affe5e40b5e5c426a7cbe32194adabad20d264ffd47',2005,'BM','Bermuda','environment',901,'Progressive Labor Party or PLP [William Alexander SCOTT];
United Bermuda Party or UBP [Grant GIBBONS]','828faef3de6f59c0d3bc049569c61cb1b1f61416c48ab279daaaae25eaef8a3e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b89c4ff6a949bfaa839834ea58e347c65f10ec33df546edf87e88f1c2541cf7f',2005,'BT','Bhutan','environment',902,'no legal parties
Bolivia
Bolivian Socialist Falange or FSB [Romel PANTOJA]; Civic
Solidarity Union or UCS [Johnny FERNANDEZ]; Free Bolivia Movement or
MBL [Franz BARRIOS]; Marshal of Ayacucho Institutional Vanguard or
VIMA [Freddy ZABALA]; Movement of the Revolutionary Left or MIR
[Jaime PAZ Zamora]; Movement Toward Socialism or MAS [Evo MORALES];
Movement Without Fear or MSM [Juan DEL GRANADO]; Nationalist
Democratic Action or ADN [Jorge Fernando QUIROGA Ramirez];
Nationalist Revolutionary Movement or MNR [leader NA]; New
Republican Force or NFR [Manfred REYES-VILLA]; Pachakuti Indigenous
Movement or MIP [Felipe QUISPE]; Socialist Party or PS [Jeres
JUSTINIANO]','d9dbd4c8248f73b86d5c93cfa384a75ae45e151468fce842b2ab735fd735debd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77992970c0e8c3723f1fa4cb8626a4639d0629f6d4f82d93771e002d66c78dda',2005,'BA','Bosnia and Herzegovina','environment',903,'Alliance of Independent Social Democrats or
SNSD [Milorad DODIK]; Bosnian Party or BOSS [Mirnes AJANOVIC]; Civic
Democratic Party or GDS [Ibrahim SPAHIC]; Croatian Democratic Union
of Bosnia and Herzegovina or HDZ-BH [Barisa COLAK]; Croat Christian
Democratic Union of Bosnia and Herzegovina or HKDU [Mijo
IVANIC-LONIC]; Croat Party of Rights or HSP [Zdravko HRISTIC]; Croat
Peasants Party or HSS [Marko TADIC]; Democratic National Union or
DNZ [Fikret ABDIC]; Liberal Democratic Party or LDS [Rasim KADIC];
New Croat Initiative or NHI [Kresimir ZUBAK]; Party for Bosnia and
Herzegovina or SBiH [Safet HALILOVIC]; Party of Democratic Action or
SDA [Sulejman TIHIC]; Party of Democratic Progress or PDP [Mladen
IVANIC]; Serb Democratic Party or SDS [Dragan CAVIC - acting]; Serb
Radical Party of the Republika Srpska or SRS-RS [Milanko MIHAJLICA];
Serb Radical Party-Dr. Vojislav Seselj or SRS-VS [Radislav
KANJERIC]; Social Democratic Party of BIH or SDP [Zlatko
LAGUMDZIJA]; Social Democratic Union or SDU [Miro LAZOVIC];
Socialist Party of Republika Srpska or SPRS [Petar DJOKIC]','e6fc3fe241fc7edb138abe33b3ba456db57cada198c54200d0e997f21c656291','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('222e00de91812fa4f977b0497a671164bd225d025b795f156e345727d0ddb949',2005,'BW','Botswana','environment',904,'Botswana Democratic Party or BDP [Festus G. MOGAE];
Botswana National Front or BNF [Otswoletse MOUPO]; Botswana Congress
Party or BCP [Otlaadisa KOOSALETSE]; Botswana Alliance Movement or
BAM [Ephraim Lepetu SETSHWAELO]
note: a number of minor parties joined forces in 1999 to form the
BAM but did not capture any parliamentary seats; the BAM parties
are: the United Action Party [Ephraim Lepetu SETSHWAELO]; the
Independence Freedom Party or IFP [Motsamai MPHO]; and the Botswana
Progressive Union [D. K. KWELE]','0bcbd0a46d2b36593fcb38aec8048c64e8cfb45c7f6312af85451c49f7dc83b2','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3ce2f92096bc9609b351b269aff3d859282fcbe05aadeb69939ec660a2cbc5b',2005,'BF','Burkina Faso','environment',905,'African Democratic Rally-Alliance for Democracy and
Federation or RDA-ADF [Herman YAMEOGO]; Confederation for Federation
and Democracy or CFD [Amadou Diemdioda DICKO]; Congress for
Democracy and Progress or CDP [Roch Marc-Christian KABORE]; Movement
for Tolerance and Progress or MTP [Nayabtigungou Congo KABORE];
Party for African Independence or PAI [Philippe OUEDRAOGO]; Party
for Democracy and Progress or PDP [Joseph KI-ZERBO]; Socialist Party
or PS [leader NA]; Union of Greens for the Development of Burkina
Faso or UVDB [Ram OVEDRAGO]
Burma
National League for Democracy or NLD [AUNG SHWE, chairman,
AUNG SAN SUU KYI, general secretary]; National Unity Party or NUP
(pro-government) [THA KYAW]; Shan Nationalities League for Democracy
or SNLD [KHUN HTUN OO]; and other smaller parties','4ca177fca7c369a727ec77bbbbfdbabbab564cf001b6f4310097557a3024f2e5','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7a1e6c65112f10e9375002d2459bd49eab1a0ec432035ee4d4d9bf8c7148ba6',2005,'BI','Burundi','environment',906,'the three national, mainstream, governing parties are: Unity
for National Progress or UPRONA [Jean-Baptiste MANWANGARI, secretary
general]; Burundi Democratic Front or FRODEBU [Jean MINANI,
president]; National Council for the Defense of Democracy, Front for
the Defense of Democracy of CNDD-FDD [Pierre NKURUNZIZA, president]
note: a multiparty system was introduced after 1998, included are:
National Resistance Movement for the Rehabilitation of the Citizen
or MRC-Rurenzangemero [Epitace BANYAGANAKANDI]; Party for National
Redress or PARENA [Jean-Baptiste BAGAZA]','997e8965512681aaa59df85ac4abcefbab7bd46a7905f81faa60cc37c786feb6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a81cda24bd7a8c6a0fcf36994a2c36befed871ecc6f7ee1e0f8c287f36d8731',2005,'KH','Cambodia','environment',907,'Cambodian Pracheachon Party (Cambodian People''s Party) or
CPP [CHEA SIM]; National United Front for an Independent, Neutral,
Peaceful, and Cooperative Cambodia or FUNCINPEC [Prince NORODOM
Ranariddh]; Sam Rangsi Party or SRP [SAM RANGSI]','56803a850a3419a83c89189ddbcfa2fd92f59d36b601d66db6268b902c44d95e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80cef6ea04bdf1cbbd9d51c705cf5c7141a64bd24ba079bf99953f55b1dc2342',2005,'KY','Cayman Islands','environment',908,'no national teams (loose groupings of political
organizations) were formed for the 2000 elections; United Democratic
Party or UDP [leader McKeeva BUSH]; People''s Progressive Movement or
PPM [leader Kurt TIBBETTS]','41bf24149e84bf5ebde0d2d3032ab46c7403ee5352b2ba2509a9c1b006d5a7f1','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecae9fc3ac25defa3efd109361392ef390fe06fb8e219372e66ab169a6558f3a',2005,'CF','Central African Republic','environment',909,'Alliance for Democracy and Progress or ADP
[Jacques MBOLIEDAS]; Central African Democratic Assembly or RDC
[Andre KOLINGBA]; Civic Forum or FC [Gen. Timothee MALENDOMA];
Democratic Forum for Modernity or FODEM [Charles MASSI]; Liberal
Democratic Party or PLD [Nestor KOMBO-NAGUEMON]; Movement for
Democracy and Development or MDD [David DACKO]; Movement for the
Liberation of the Central African People or MLPC [the party of
deposed president, Ange-Felix PATASSE]; Patriotic Front for Progress
or FPP [Abel GOUMBA]; People''s Union for the Republic or UPR [Pierre
Sammy MAKFOY]; National Unity Party or PUN [Jean-Paul NGOUPANDE];
Social Democratic Party or PSD [Enoch LAKOUE]','234d58c297548f8d3d36d81607cc7b4861bc1d8d9e9d007ad2eccd69606dccba','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5a91bdf9e550239295664171509338d53d8cdc76a469bed202f9ec91e480f64',2005,'KM','Comoros','environment',910,'Forces pour l''Action Republicaine or FAR [Col. Abdourazak
ABDULHAMID]; Forum pour la Redressement National or FRN (alliance of
12 parties); Front Democratique or FD [Moustoifa Said CHEIKH]; Front
National pour la Justice or FNJ (Islamic party in opposition) [Ahmed
RACHID]; Movement des Citoyens pour la Republique or MCR [Mahamoud
MRADABI]; Mouvement Populaire Anjouanais or MPA (Anjouan separatist
movement) [leader NA]; Mouvement pour la Democratie et le Progress
or MDP-NGDC [Abbas DJOUSSOUF]; Movement pour le Socialisme et la
Democratie or MSD (splinter group of FD) [Abdou SOEFOU]; Parti
Comorien pour la Democratie et le Progress or PCDP [Ali MROUDJAE];
Rassemblement National pour le Development or RND (party of the
government) [Omar TAMOU, Abdoulhamid AFFRAITANE]
Congo, Democratic Republic of the
Democratic Social Christian Party
or PDSC [Andre BO-BOLIKO]; Forces for Renovation for Union and
Solidarity or FONUS [Joseph OLENGHANKOY]; National Congolese
Lumumbist Movement or MNC [Francois LUMUMBA]; Popular Movement of
the Revolution or MPR (three factions: MPR-Fait Prive [Catherine
NZUZI wa Mbombo]; MPR/Vunduawe [Felix VUNDUAWE]; MPR/Mananga
[MANANGA Dintoka Mpholo]); Unified Lumumbast Party or PALU [Antoine
GIZENGA]; Union for Democracy and Social Progress or UDPS [Etienne
TSHISEKEDI wa Mulumba]; Union of Federalists and Independent
Republicans or UFERI (two factions: UFERI [Lokambo OMOKOKO];
UFERI/OR [Adolph Kishwe MAYA])
Congo, Republic of the
the most important of the many parties are
the Democratic and Patriotic Forces or FDP (an alliance of
Convention for Alternative Democracy, Congolese Labor Party or PCT,
Liberal Republican Party, National Union for Democracy and Progress,
Patriotic Union for the National Reconstruction, and Union for the
National Renewal) [Denis SASSOU-NGUESSO, president]; Congolese
Movement for Democracy and Integral Development or MCDDI [Michel
MAMPOUYA]; Pan-African Union for Social Development or UPADS [Martin
MBERI]; Rally for Democracy and Social Progress or RDPS [Jean-Pierre
Thystere TCHICAYA, president]; Rally for Democracy and the Republic
or RDR [Raymond Damasge NGOLLO]; Union for Democracy and Republic or
UDR [leader NA]; Union of Democratic Forces or UFD [Sebastian EBAO]','7debceefc20315451c449c806dff04be83f0e893323b32bbfb8f39564d2fcea9','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99ebabce81a5bd746f444499ee359a995e81fccd390865c61d9c446c97b3d166',2005,'CK','Cook Islands','environment',911,'Cook Islands People''s Party or CIP [Geoffrey HENRY];
Democratic Alliance Party or DAP [Terepai MAOATE]; New Alliance
Party or NAP [Norman GEORGE]; Cook Islands National Party or CIN
[Teariki HEATHER]; Demo Party Tumu [Robert WOONTON]','8ae7c3b152e82636642bb117119019909289521cae4c30ff5da1e43977ba97e8','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83953682a0944c3576d4159e6c1cdf5440b7aea07c533f91ee188e62ce58959b',2005,'CY','Cyprus','environment',912,'Republic of Cyprus: Democratic Party or DIKO [Tassos
PAPADOPOULOS]; Democratic Rally or DISY [Nikos ANASTASIADHIS];
Fighting Democratic Movement or ADIK [Dinos MIKHAILIDIS]; Green
Party of Cyprus [George PERDIKIS]; New Horizons [Nikolaus KOUTSOU];
Restorative Party of the Working People or AKEL (Communist Party)
[Dimitrios CHRISTOFIAS]; Social Democrats Movement or KISOS
(formerly United Democratic Union of Cyprus or EDEK) [Yiannakis
OMIROU]; United Democrats Movement or EDE [George VASSILIOU]; north
Cyprus: Democratic Party or DP [Serder DENKTASH]; National Birth
Party or UDP [Enver EMIN]; National Unity Party or UBP [Dervis
EROGLU]; Our Party or BP [Okyay SADIKOGLU]; Patriotic Unity Movement
or YBH [Alpay DURDURAN]; Peace and Democratic Movement [Mustafa
AKINCI]; Republican Turkish Party or CTP [Mehmet ALI TALAT]
Czech Republic
Caucus SNK [Josef ZOSER]; Christian and Democratic
Union-Czechoslovak People''s Party or KDU-CSL [Miroslav KALOUSEK,
chairman]; Civic Democratic Alliance or ODA [Jirina NOVAKOVA,
chairman]; Civic Democratic Party or ODS [Mirek TOPOLANEK,
chairman]; Communist Party of Bohemia and Moravia or KSCM [Miroslav
GREBENICEK, chairman]; Communist Party of Czechoslovakia or KSC
[Miroslav STEPAN, chairman]; Czech National Social Party of CSNS
[Jaroslav ROVNY, chairman]; Czech Social Democratic Party or CSSD
[Stanislav GROSS, acting chairman]; European Democrats [Jan KASL];
Freedom Union-Democratic Union or US-DEU [Hana Marvanova,
chairwoman]; Open Democracy [Sona PAUKRTOVA, chairwoman]','75efa1e9094e14480cddad1a8ad06867cecd53170bfdc3416635ae677551e4fc','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93c92b85a88cb966f7c7b54c8fe810b9eebde59ab3469ba9f7add932453dd929',2005,'DJ','Djibouti','environment',913,'Democratic National Party or PND [ADEN Robleh Awaleh];
Democratic Renewal Party or PRD [Abdillahi HAMARITEH]; Djibouti
Development Party or PDD [Mohamed Daoud CHEHEM]; Front pour la
Restauration de l''Unite Democratique or FRUD [Ali Mohamed DAOUD];
People''s Progress Assembly or RPP (governing party) [Ismail Omar
GUELLEH]; Peoples Social Democratic Party or PPSD [Moumin Bahdon
FARAH]; Republican Alliance for Democracy or ARD [Ahmed Dini AHMED];
Union for Democracy and Justice or UDJ [leader NA]','f866138e4c70b75aaff3f3f8403eda2a21c575a3f3d9a3c1955ef24bb134bf39','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08f84f798eaa30ba89d8f7652a7613ea51bc4a0783d619b28db08fe916f7033a',2005,'DM','Dominica','environment',914,'Dominica Freedom Party or DFP [Charles SAVARIN]; Dominica
Labor Party or DLP [Roosevelt SKERRIT]; United Workers Party or UWP
[Edison JAMES]','7ec4e27f2869b855580688163c0bdb1b948007f5391b068a56574de6da3d5c4b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3dc3c33b6630840f12726df5fb17e1aa405188fa2ad6f43e6d985317b09b6fbf',2005,'DO','Dominican Republic','environment',915,'Dominican Liberation Party or PLD [Leonel
FERNANDEZ Reyna]; Dominican Revolutionary Party or PRD [Vicente
Sanchez BARET]; Social Christian Reformist Party or PRSC [Enrique
ATUN]
East Timor
Associacao Social-Democrata Timorense or ASDT [Francisco
Xavier do AMARAL]; Christian Democratic Party of Timor or PDC
[Antonio XIMENES]; Christian Democratic Union of Timor or UDC
[Vicente da Silva GUTERRES]; Democratic Party or PD [Fernando de
ARAUJO]; Liberal Party or PL [leader NA]; Maubere Democratic Party
or PDM [leader NA]; People''s Party of Timor or PPT [Jacob XAVIER];
Revolutionary Front of Independent East Timor or FRETILIN [Lu OLO];
Social Democrat Party of East Timor or PSD [Mario CARRASCALAO];
Socialist Party of Timor or PST [leader Avelino COELHO]; Sons of the
Mountain Warriors (also known as Association of Timorese Heroes) or
KOTA [Clementino dos Reis AMARAL]; Timor Democratic Union or UDT
[Joao CARRASCALAO]; Timor Labor Party or PTT [Paulo Freitas DA
SILVA]; Timorese Nationalist Party or PNT [Abilio ARAUJO]; Timorese
Popular Democratic Association or APODETI [Frederico Almeida-Santos
DA COSTA]','be5f00b118ef32a7597b214eaa08e8f67e8cf6b775e57ea209d2d113e038c091','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

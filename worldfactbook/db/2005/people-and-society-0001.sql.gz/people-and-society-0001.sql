SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('720ba33deeed15b789dec508e73a0b002b552031b180610a8ab8a40c8d7151f7',2005,'ZW','Zimbabwe','people-and-society',3,'Population
Birth rate
Death rate
Infant mortality rate
Life expectancy at birth - total
Total fertility rate
HIV/AIDS - adult prevalence rate
HIV/AIDS - people living with HIV/AIDS
HIV/AIDS - deaths
Economy Zimbabwe
Economy - overview:
The government of Zimbabwe faces a wide variety of difficult
economic problems as it struggles with an unsustainable fiscal
deficit, an overvalued exchange rate, soaring inflation, and bare
shelves. Its 1998-2002 involvement in the war in the Democratic
Republic of the Congo, for example, drained hundreds of millions of
dollars from the economy. Badly needed support from the IMF has been
suspended because of the country''s failure to meet budgetary goals.
Inflation rose from an annual rate of 32% in 1998 to 133% at the end
of 2004, while the exchange rate fell from 24 Zimbabwean dollars per
US dollar to 6,200 in the same time period. The government''s land
reform program, characterized by chaos and violence, has badly
damaged the commercial farming sector, the traditional source of
exports and foreign exchange and the provider of 400,000 jobs.
GDP (purchasing power parity):
$24.37 billion (2004 est.)
GDP - real growth rate:
-8.2% (2004 est.)
GDP - per capita:
purchasing power parity - $1,900 (2004 est.)
GDP - composition by sector:
agriculture: 18.1%
industry: 24.3%
services: 57.7% (2004 est.)
Labor force:
4.23 million (2004 est.)
Labor force - by occupation:
agriculture 66%, industry 10%, services 24% (1996)
Unemployment rate:
70% (2002 est.)
Population below poverty line:
70% (2002 est.)
Household income or consumption by percentage share:
lowest 10%: 1.97%
highest 10%: 40.42% (1995)
Distribution of family income - Gini index:
50.1 (1995)
Inflation rate (consumer prices):
133% (2004 est.)
Investment (gross fixed):
9.9% of GDP (2004 est.)
Budget:
revenues: $1.325 billion
expenditures: $1.593 billion, including capital expenditures of NA
(2004 est.)
Public debt:
52.3% of GDP (2004 est.)
Agriculture - products:
corn, cotton, tobacco, wheat, coffee, sugarcane, peanuts; sheep,
goats, pigs
Industries:
mining (coal, gold, platinum, copper, nickel, tin, clay, numerous
metallic and nonmetallic ores), steel, wood products, cement,
chemicals, fertilizer, clothing and footwear, foodstuffs, beverages
Industrial production growth rate:
-7.8% (2004 est.)
Electricity - production:
8.839 billion kWh (2002)
Electricity - production by source:
fossil fuel: 47%
hydro: 53%
nuclear: 0%
other: 0% (2001)
Electricity - consumption:
11.22 billion kWh (2002)
Electricity - exports:
0 kWh (2002)
Electricity - imports:
3 billion kWh (2002)
Oil - production:
0 bbl/day (2001 est.)
Oil - consumption:
23,000 bbl/day (2001 est.)
Oil - exports:
NA
Oil - imports:
NA
Current account balance:
$-230.3 million (2004 est.)
Exports:
$1.409 billion f.o.b. (2004 est.)
Exports - commodities:
cotton, tobacco, gold, ferroalloys, textiles/clothing
Exports - partners:
South Africa 31.5%, Switzerland 7.4%, UK 7.3%, China 6.1%, Germany
4.3% (2004)
Imports:
$1.599 billion f.o.b. (2004 est.)
Imports - commodities:
machinery and transport equipment, other manufactures, chemicals,
fuels
Imports - partners:
South Africa 46.9%, Botswana 3.6%, UK 3.4% (2004)
Reserves of foreign exchange and gold:
$57 million (2004 est.)
Debt - external:
$4.086 billion (2004 est.)
Economic aid - recipient:
$178 million; note - the EU and the US provide food aid on
humanitarian grounds (2000 est.)
Currency (code):
Zimbabwean dollar (ZWD)
Currency code:
ZWD
Exchange rates:
Zimbabwean dollars per US dollar - 4,303.28 (2004), 697.424 (2003),
55.036 (2002), 55.052 (2001), 44.418 (2000)
note: these are official exchange rates, non-official rates vary
significantly
Fiscal year:
calendar year
Communications Zimbabwe
Telephones - main lines in use:
300,900 (2003)
Telephones - mobile cellular:
379,100 (2003)
Telephone system:
general assessment: system was once one of the best in Africa, but
now suffers from poor maintenance; more than 100,000 outstanding
requests for connection despite an equally large number of installed
but unused main lines
domestic: consists of microwave radio relay links, open-wire lines,
radiotelephone communication stations, fixed wireless local loop
installations, and a substantial mobile cellular network; Internet
connection is available in Harare and planned for all major towns
and for some of the smaller ones
international: country code - 263; satellite earth stations - 2
Intelsat; two international digital gateway exchanges (in Harare and
Gweru)
Radio broadcast stations:
AM 7, FM 20 (plus 17 repeater stations), shortwave 1 (1998)
Radios:
1.14 million (1997)
Television broadcast stations:
16 (1997)
Televisions:
370,000 (1997)
Internet country code:
.zw
Internet hosts:
4,501 (2003)
Internet Service Providers (ISPs):
6 (2000)
Internet users:
500,000 (2002)
Transportation Zimbabwe
Railways:
total: 3,077 km
narrow gauge: 3,077 km 1.067-m gauge (313 km electrified) (2004)
Highways:
total: 18,338 km
paved: 8,692 km
unpaved: 9,646 km (1999 est.)
Waterways:
on Lake Kariba, length small (2003)
Pipelines:
refined products 261 km (2004)
Ports and harbors:
Binga, Kariba
Airports:
404 (2004 est.)
Airports - with paved runways:
total: 17
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2004 est.)
Airports - with unpaved runways:
total: 387
1,524 to 2,437 m: 5
914 to 1,523 m: 186
under 914 m: 196 (2004 est.)
Military Zimbabwe
Military branches:
Zimbabwe Defense Forces (ZDF): Zimbabwe National Army, Air Force of
Zimbabwe (AFZ), Zimbabwe Republic Police (2005)
Military service age and obligation:
18 years of age (est.) (2004)
Manpower available for military service:
males age 18-49: 2,840,053 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,148,590 (2005 est.)
Military expenditures - dollar figure:
$217 million (2004)
Military expenditures - percent of GDP:
4.3% (2004)
Transnational Issues Zimbabwe
Disputes - international:
Botswana has built electric fences and South Africa has placed
military along the border to stem the flow of thousands of
Zimbabweans fleeing to find work and escape political persecution;
Namibia has supported and in 2004 Zimbabwe dropped objections to
plans between Botswana and Zambia to build a bridge over the Zambezi
River, thereby de facto recognizing a short, but not clearly
delimited Botswana-Zambia boundary in the river
Refugees and internally displaced persons:
IDPs: 100,000-150,000 (MUGABE-led political violence, human rights
violations, land reform, and economic collapse) (2004)
Illicit drugs:
transit point for African cannabis and South Asian heroin, mandrax,
and methamphetamines destined for the South African and European
markets
This page was last updated on 20 October, 2005
======================================================================
@2001 GDP (purchasing power parity)
$24.37 billion (2004 est.)
This page was last updated on 20 October, 2005
======================================================================
@2002 Population growth rate (%)
0.51% (2005 est.)
This page was last updated on 20 October, 2005
======================================================================
@2003 GDP - real growth rate (%)
-8.2% (2004 est.)
This page was last updated on 20 October, 2005
======================================================================
@2004 GDP - per capita
purchasing power parity - $1,900 (2004 est.)
This page was last updated on 20 October, 2005
======================================================================
@2006 Dependency status
Akrotiri
overseas territory of UK; administered by an administrator
who is also the Commander, British Forces Cyprus','5f8f67a75b0bcf5d098d5d0a2f7133ab8695e3fb44d729cbcae04cfef02a72ae','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d93ca56f88786cc03f022ebbe879718d5b04fe8ed0c9df7228fcde218681297',2005,'EH','Western Sahara','people-and-society',34,'This category includes the entries dealing with the characteristics of
the people and their society.
People - note
This entry includes miscellaneous demographic information of
significance not included elsewhere.
Personal Names - Capitalization
The Factbook capitalizes the surname or family name of individuals for
the convenience of our users who are faced with a world of different
cultures and naming conventions. The need for capitalization, bold
type, underlining, italics, or some other indicator of the individual''s
surname is apparent in the following examples: MAO Zedong, Fidel CASTRO
Ruz, George W. BUSH, and TUNKU SALAHUDDIN Abdul Aziz Shah ibni Al-
Marhum Sultan Hisammuddin Alam Shah. By knowing the surname, a short
form without all capital letters can be used with confidence as in
President Castro, Chairman Mao, President Bush, or Sultan Tunku
Salahuddin. The same system of capitalization is extended to the names
of leaders with surnames that are not commonly used such as Queen
ELIZABETH II.
Personal Names - Spelling
The romanization of personal names in the Factbook normally follows the
same transliteration system used by the US Board on Geographic Names
for spelling place names. At times, however, a foreign leader expressly
indicates a preference for, or the media or official documents
regularly use, a romanized spelling that differs from the
transliteration derived from the US Government standard. In such cases,
the Factbook uses the alternative spelling.
Personal Names - Titles
The Factbook capitalizes any valid title (or short form of it)
immediately preceding a person''s name. A title standing alone is not
capitalized. Examples: President PUTIN and President BUSH are chiefs of
state. In Russia, the president is chief of state and the premier is
the head of the government, while in the US, the president is both
chief of state and head of government.
Petroleum
See entry for "oil."
Petroleum products
See entry for "oil."
Pipelines
This entry gives the lengths and types of pipelines for transporting
products like natural gas, crude oil, or petroleum products.
Political parties and leaders
This entry includes a listing of significant political organizations
and their leaders.
Political pressure groups and leaders
This entry includes a listing of organizations with leaders involved in
politics, but not standing for legislative election.
Population
This entry gives an estimate from the US Bureau of the Census based on
statistics from population censuses, vital statistics registration
systems, or sample surveys pertaining to the recent past and on
assumptions about future trends. The total population presents one
overall measure of the potential impact of the country on the world and
within its region. Note: starting with the 1993 Factbook, demographic
estimates for some countries (mostly African) have explicitly taken
into account the effects of the growing impact of the HIV/AIDS
epidemic. These countries are currently: The Bahamas, Benin, Botswana,
Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Central
African Republic, Democratic Republic of the Congo, Republic of the
Congo, Cote d''Ivoire, Ethiopia, Gabon, Ghana, Guyana, Haiti, Honduras,
Kenya, Lesotho, Malawi, Mozambique, Namibia, Nigeria, Rwanda, South
Africa, Swaziland, Tanzania, Thailand, Togo, Uganda, Zambia, and
Zimbabwe.
Population below poverty line
National estimates of the percentage of the population falling below
the poverty line are based on surveys of sub-groups, with the results
weighted by the number of people in each group. Definitions of poverty
vary considerably among nations. For example, rich nations generally
employ more generous standards of poverty than poor nations.
Population growth rate
The average annual percent change in the population, resulting from a
surplus (or deficit) of births over deaths and the balance of migrants
entering and leaving a country. The rate may be positive or negative.
The growth rate is a factor in determining how great a burden would be
imposed on a country by the changing needs of its people for
infrastructure (e.g., schools, hospitals, housing, roads), resources
(e.g., food, water, electricity), and jobs. Rapid population growth can
be seen as threatening by neighboring countries.
Ports and harbors
This entry lists the major ports and harbors selected on the basis of
overall importance to each country. This is determined by evaluating a
number of factors (e.g., dollar value of goods handled, gross tonnage,
facilities, military significance).
Public debt
This entry records the cumulatiive total of all government borrowings
less repayments that are denominated in a country''s home currency.
Public debt should not be confused with external debt, which reflects
the foreign currency liabilities of both the private and public sector
and must be financed out of foreign exchange earnings.
Radio broadcast stations
This entry includes the total number of AM, FM, and shortwave broadcast
stations.
Railways
This entry states the total route length of the railway network and of
its component parts by gauge: broad, standard, narrow, and dual. Other
gauges are listed under note.
Reference maps
This section includes world and regional maps.
Refugees and internally displaced persons
This entry includes those persons residing in a country as refugees or
internally displaced persons (IDPs). The definition of a refugee
according to a United Nations Convention is "a person who is outside
his/her country of nationality or habitual residence; has a well-
founded fear of persecution because of his/her race, religion,
nationality, membership in a particular social group or political
opinion; and is unable or unwilling to avail himself/herself of the
protection of that country, or to return there, for fear of
persecution." The UN established the Office of the UN High Commissioner
for Refugees (UNHCR) in 1950 to handle refugee matters worldwide. The
UN Relief and Works Agency for Palestine Refugees in the Near East
(UNRWA) has a different, operational definition for a Palestinian
refugee: "a person whose normal place of residence was Palestine during
the period 1 June 1946 to 15 May 1948 and who lost both home and means
of livelihood as a result of the 1948 conflict." However, UNHCR also
assists some 400,000 Palestinian refugees not covered under the UNRWA
definition. The term "internally displaced person" is not specifically
covered in the UN Convention; it is used to describe people who have
fled their homes for reasons similar to refugees, but who remain within
their own national territory and are subject to the laws of that state.
Religions
This entry is an ordered listing of religions by adherents starting
with the largest group and sometimes includes the percent of total
population.
Reserves of foreign exchange and gold
This entry gives the dollar value for the stock of all financial assets
that are available to the central monetary authority for use in meeting
a country''s balance of payments needs as of the end-date of the period
specified. This category includes not only foreign currency and gold,
but also a country''s holdings of Special Drawing Rights in the
International Monetary Fund, and its reserve position in the Fund.
Sex ratio
This entry includes the number of males for each female in five age
groups - at birth, under 15 years, 15-64 years, 65 years and over, and
for the total population. Sex ratio at birth has recently emerged as an
indicator of certain kinds of sex discrimination in some countries. For
instance, high sex ratios at birth in some Asian countries are now
attributed to sex-selective abortion and infanticide due to a strong
preference for sons. This will affect future marriage patterns and
fertility patterns. Eventually, it could cause unrest among young adult
males who are unable to find partners.
Suffrage
This entry gives the age at enfranchisement and whether the right to
vote is universal or restricted.
Telephone numbers
All telephone numbers in the Factbook consist of the country code in
brackets, the city or area code (where required) in parentheses, and
the local number. The one component that is not presented is the
international access code, which varies from country to country. For
example, an international direct dial telephone call placed from the US
to Madrid, Spain, would be as follows: 011 [34] (1) 577-xxxx, where 011
is the international access code for station-to-station calls; 01 is
for calls other than station-to-station calls, [34] is the country code
for Spain, (1) is the city code for Madrid, 577 is the local exchange,
and xxxx is the local telephone number. An international direct dial
telephone call placed from another country to the US would be as
follows: international access code + [1] (202) 939-xxxx, where [ 1] is
the country code for the US, (202) is the area code for Washington, DC,
939 is the local exchange, and xxxx is the local telephone number.
Telephone system
This entry includes a brief general assessment of the system with
details on the domestic and international components. The following
terms and abbreviations are used throughout the entry:
Africa ONE - a fiber-optic submarine cable link encircling the
continent of Africa.
Arabsat - Arab Satellite Communications Organization (Riyadh, Saudi
Arabia).
Autodin - Automatic Digital Network (US Department of Defense).
CB - citizen''s band mobile radio communications.
cellular telephone system - the telephones in this system are radio
transceivers, with each instrument having its own private radio
frequency and sufficient radiated power to reach the booster station in
its area (cell), from which the telephone signal is fed to a telephone
exchange.
Central American Microwave System - a trunk microwave radio relay
system that links the countries of Central America and Mexico with each
other.
coaxial cable - a multichannel communication cable consisting of a
central conducting wire, surrounded by and insulated from a cylindrical
conducting shell; a large number of telephone channels can be made
available within the insulated space by the use of a large number of
carrier frequencies.
Comsat - Communications Satellite Corporation (US).
DSN - Defense Switched Network (formerly Automatic Voice Network or
Autovon); basic general-purpose, switched voice network of the Defense
Communications System (US Department of Defense).
Eutelsat - European Telecommunications Satellite Organization (Paris).
fiber-optic cable - a multichannel communications cable using a thread
of optical glass fibers as a transmission medium in which the signal
(voice, video, etc.) is in the form of a coded pulse of light.
GSM - a global system for mobile (cellular) communications devised by
the Groupe Special Mobile of the pan-European standardization
organization, Conference Europeanne des Posts et Telecommunications
(CEPT) in 1982.
HF - high frequency; any radio frequency in the 3,000- to 30,000-kHz
range.
Inmarsat - International Maritime Satellite Organization (London);
provider of global mobile satellite communications for commercial,
distress, and safety applications at sea, in the air, and on land.
Intelsat - International Telecommunications Satellite Organization
(Washington, DC).
Intersputnik - International Organization of Space Communications
(Moscow); first established in the former Soviet Union and the East
European countries, it is now marketing its services worldwide with
earth stations in North America, Africa, and East Asia.
landline - communication wire or cable of any sort that is installed on
poles or buried in the ground.
Marecs - Maritime European Communications Satellite used in the
Inmarsat system on lease from the European Space Agency.
Marisat - satellites of the Comsat Corporation that participate in the
Inmarsat system.
Medarabtel - the Middle East Telecommunications Project of the
International Telecommunications Union (ITU) providing a modern
telecommunications network, primarily by microwave radio relay, linking
Algeria, Djibouti, Egypt, Jordan, Libya, Morocco, Saudi Arabia,
Somalia, Sudan, Syria, Tunisia, and Yemen; it was initially started in
Morocco in 1970 by the Arab Telecommunications Union (ATU) and was
known at that time as the Middle East Mediterranean Telecommunications
Network.
microwave radio relay - transmission of long distance telephone calls
and television programs by highly directional radio microwaves that are
received and sent on from one booster station to another on an optical
path.
NMT - Nordic Mobile Telephone; an analog cellular telephone system that
was developed jointly by the national telecommunications authorities of
the Nordic countries (Denmark, Finland, Iceland, Norway, and Sweden).
Orbita - a Russian television service; also the trade name of a packet-
switched digital telephone network.
radiotelephone communications - the two-way transmission and reception
of sounds by broadcast radio on authorized frequencies using telephone
handsets.
PanAmSat - PanAmSat Corporation (Greenwich, CT).
SAFE - South African Far East Cable
satellite communication system - a communication system consisting of
two or more earth stations and at least one satellite that provide long
distance transmission of voice, data, and television; the system
usually serves as a trunk connection between telephone exchanges; if
the earth stations are in the same country, it is a domestic system.
satellite earth station - a communications facility with a microwave
radio transmitting and receiving antenna and required receiving and
transmitting equipment for communicating with satellites.
satellite link - a radio connection between a satellite and an earth
station permitting communication between them, either one-way (down
link from satellite to earth station - television receive-only
transmission) or two-way (telephone channels).
SHF - super high frequency; any radio frequency in the 3,000- to
30,000-MHz range.
shortwave - radio frequencies (from 1.605 to 30 MHz) that fall above
the commercial broadcast band and are used for communication over long
distances.
Solidaridad - geosynchronous satellites in Mexico''s system of
international telecommunications in the Western Hemisphere.
Statsionar - Russia''s geostationary system for satellite
telecommunications.
submarine cable - a cable designed for service under water.
TAT - Trans-Atlantic Telephone; any of a number of high-capacity
submarine coaxial telephone cables linking Europe with North America.
telefax - facsimile service between subscriber stations via the public
switched telephone network or the international Datel network.
telegraph - a telecommunications system designed for unmodulated
electric impulse transmission.
telex - a communication service involving teletypewriters connected by
wire through automatic exchanges.
tropospheric scatter - a form of microwave radio transmission in which
the troposphere is used to scatter and reflect a fraction of the
incident radio waves back to earth; powerful, highly directional
antennas are used to transmit and receive the microwave signals;
reliable over-the-horizon communications are realized for distances up
to 600 miles in a single hop; additional hops can extend the range of
this system for very long distances.
trunk network - a network of switching centers, connected by
multichannel trunk lines.
UHF - ultra high frequency; any radio frequency in the 300- to 3,000-
MHz range.
VHF - very high frequency; any radio frequency in the 30- to 300-MHz
range.
Telephones - main lines in use
This entry gives the total number of main telephone lines in use.
Telephones - mobile cellular
This entry gives the total number of mobile cellular telephones in use.
Television broadcast stations
This entry gives the total number of separate broadcast stations plus
any repeater stations.
Terminology
Due to the highly structured nature of the Factbook database, some
collective generic terms have to be used. For example, the word Country
in the Country name entry refers to a wide variety of dependencies,
areas of special sovereignty, uninhabited islands, and other entities
in addition to the traditional countries or independent states.
Military is also used as an umbrella term for various civil defense,
security, and defense activities in many entries. The Independence
entry includes the usual colonial independence dates and former ruling
states as well as other significant nationhood dates such as the
traditional founding date or the date of unification, federation,
confederation, establishment, or state succession that are not strictly
independence dates. Dependent areas have the nature of their dependency
status noted in this same entry.
Terrain
This entry contains a brief description of the topography.
Total fertility rate
This entry gives a figure for the average number of children that would
be born per woman if all women lived to the end of their childbearing
years and bore children according to a given fertility rate at each
age. The total fertility rate (TFR) is a more direct measure of the
level of fertility than the crude birth rate, since it refers to births
per woman. This indicator shows the potential for population change in
the country. A rate of two children per woman is considered the
replacement rate for a population, resulting in relative stability in
terms of total numbers. Rates above two children indicate populations
growing in size and whose median age is declining. Higher rates may
also indicate difficulties for families, in some situations, to feed
and educate their children and for women to enter the labor force.
Rates below two children indicate populations decreasing in size and
growing older. Global fertility rates are in general decline and this
trend is most pronounced in industrialized countries, especially
Western Europe, where populations are projected to decline dramatically
over the next 50 years.
NA
World
GWP (gross world product) - purchasing power parity - $55.5
trillion (2004 est.)
NA
World
1.14% (2005 est.)
NA
World
4.9% (2004 est.)
purchasing power parity - NA
World
purchasing power parity - $8,800 (2004 est.)','7f8ffc86b0a8421084f4fa7b18ede8bd177487c8b2390bec8d6e8e0c602481a2','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('306ebae02de7f26bc0fc944eeb34bdf52ee176d8913bdae154897384d2c94b71',2005,'AR','Argentina','people-and-society',229,'Religions:
nominally Roman Catholic 96%, Protestant 2%, other 2%
Languages:
Spanish (official), numerous indigenous dialects
Literacy:
definition: age 15 and over can read and write
total population: 93.4%
male: 93.8%
female: 93.1% (2003 est.)
Government Venezuela
Country name:
conventional long form: Bolivarian Republic of Venezuela
conventional short form: Venezuela
local long form: Republica Bolivariana de Venezuela
local short form: Venezuela
Government type:
federal republic
Capital:
Caracas
Administrative divisions:
23 states (estados, singular - estado), 1 federal district*
(distrito federal), and 1 federal dependency** (dependencia
federal); Amazonas, Anzoategui, Apure, Aragua, Barinas, Bolivar,
Carabobo, Cojedes, Delta Amacuro, Dependencias Federales**, Distrito
Federal*, Falcon, Guarico, Lara, Merida, Miranda, Monagas, Nueva
Esparta, Portuguesa, Sucre, Tachira, Trujillo, Vargas, Yaracuy, Zulia
note: the federal dependency consists of 11 federally controlled
island groups with a total of 72 individual islands
Independence:
5 July 1811 (from Spain)
National holiday:
Independence Day, 5 July (1811)
Constitution:
30 December 1999
Legal system:
open, adversarial court system
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Hugo CHAVEZ Frias (since 3 February
1999); Vice President Jose Vicente RANGEL Vale (since 28 April
2002); note - the president is both the chief of state and head of
$483.5 billion (2004 est.)
0.98% (2005 est.)
8.3% (2004 est.)
purchasing power parity - $12,400 (2004 est.)
chief of mission: Ambassador Lino GUTIERREZ
embassy: Avenida Colombia 4300, C1425GMN Buenos Aires
mailing address: international mail: use street address; APO
address: Unit 4334, APO AA 34034
telephone: [54] (11) 5777-4533
FAX: [54] (11) 5777-4240','d6ec0f2d5c349bcda3729643c29d19ec2ab6041dc9c553f935950a58b73f647b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80f723cb234d27636252f5ed70b38ffe790e730a798c271566ae9b0b2334fce1',2005,'AF','Afghanistan','people-and-society',231,'$21.5 billion (2003 est.)
4.77%
note: this rate does not take into consideration the recent war and
its continuing impact (2005 est.)
7.5% (2004 est.)
purchasing power parity - $800 (2003 est.)
chief of mission: Ambassador Zalmay KHALILZAD
embassy: The Great Masood Road, Kabul
mailing address: 6180 Kabul Place, Dulles, VA 20189-6180
telephone: [00] (2) 230-0436
FAX: [0093] (2) 230-1364
Akrotiri
none (overseas territory of the UK)','eb20ac6f44261a4a3b9de9845d6e2ad5616f0c4e46dc53c75a25f161750a14eb','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d198fe26ac4d058522f0aa370af9f14220fee393d4079896f5bfa3b304d41e47',2005,'AL','Albania','people-and-society',232,'$17.46 billion (2004 est.)
0.52% (2005 est.)
5.6% (2004 est.)
purchasing power parity - $4,900 (2004 est.)
chief of mission: Ambassador Marcie B. RIES
embassy: Rruga Elbasanit, Labinoti #103, Tirana
mailing address: U. S. Department of State, 9510 Tirana Place,
Dulles, VA 20189-9510
telephone: [355] (4) 247285
FAX: [355] (4) 374957 and [355] (4) 232222','7eb49c1adfb36420bb2a238575738f74f17e022291433f793c82721db638255b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ca736b7d3ba926531f2c8696726e5a2b81da201839e5cc0a59cd1ccba282561',2005,'DZ','Algeria','people-and-society',233,'$212.3 billion (2004 est.)
1.22% (2005 est.)
6.1% (2004 est.)
purchasing power parity - $6,600 (2004 est.)
chief of mission: Ambassador Richard W. ERDMAN
embassy: 4 Chemin Cheikh Bachir El-Ibrahimi, Algiers
mailing address: B. P. 408, Alger-Gare, 16030 Algiers
telephone: [213] (21) 691-425/255/186
FAX: [213] (21) 69-39-79','cb91e04dd80cb9163c69b07357507bd350aacbfa7d5fbf9e4d153b4f3f9c131b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24bce073bfaceb191bb41d316f74556f01c387b41c8787f9a4888d48700ac5c8',2005,'AS','American Samoa','people-and-society',234,'$500 million (2000 est.)
-0.11% (2005 est.)
NA
purchasing power parity - $8,000 (2000 est.)
unincorporated and unorganized territory of the US;
administered by the Office of Insular Affairs, US Department of the
Interior
none (territory of the US)','0a2d6f9cefa5f758d4f8ff484065efbb0892f0b8f84d2c30416629d641a2c450','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec739fa16c1d654a1192ee84102083945612a3341bf50ed9cfad0261f9f5ec77',2005,'AD','Andorra','people-and-society',235,'$1.9 billion (2003 est.)
0.95% (2005 est.)
2% (2003 est.)
purchasing power parity - $26,800 (2003 est.)
the US does not have an embassy in Andorra; the US
Ambassador to Spain is accredited to Andorra; US interests in
Andorra are represented by the Consulate General''s office in
Barcelona (Spain); mailing address: Paseo Reina Elisenda, 23, 08034
Barcelona, Spain; telephone: [34] (93) 280-2227; FAX: [34] (93)
280-6175','e534b629cd53d13147bf1adc177b552d66f36677ac1273f654ff05798e7ebf6e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a1ae01887c71ddd7a13dde5f9daa1809065feadf8b74114165679ea7ab8dbe6',2005,'AO','Angola','people-and-society',236,'$23.17 billion (2004 est.)
1.9% (2005 est.)
11.7% (2004 est.)
purchasing power parity - $2,100 (2004 est.)
chief of mission: Ambassador Cynthia EFFIRD
embassy: number 32 Rua Houari Boumedienne (in the Miramar area of
Luanda), Luanda
mailing address: international mail: Caixa Postal 6468, Luanda;
pouch: American Embassy Luanda, Department of State, Washington, DC
20521-2550
telephone: [244] (2) 445-481, 447-028, 446-224
FAX: [244] (2) 446-924','53d099afa1ec9dec85b6a1dec844143580653283082525a0f3e3edb936834e57','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0173a77c4541390b95c89e9d2db8ef99bf9fa3edd1568aecc3573a2e0f7392ec',2005,'AI','Anguilla','people-and-society',237,'$112 million (2002 est.)
1.77% (2005 est.)
2.8% (2001 est.)
purchasing power parity - $7,500 (2002 est.)
overseas territory of the UK
none (overseas territory of the UK)','4a916e0216370a492e05bc9d6bd2ee90dfe6ee6df9bc3a7f231dadf6d3ae87d1','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15e8b6d1feb96564f06719ea3ae8a00192008f8f764c68b21aa86c88a37421d1',2005,'AG','Antigua and Barbuda','people-and-society',238,'$750 million (2002 est.)
0.57% (2005 est.)
3% (2002 est.)
purchasing power parity - $11,000 (2002 est.)
the US does not have an embassy in Antigua and
Barbuda (embassy closed 30 June 1994); the US Ambassador to Barbados
is accredited to Antigua and Barbuda','e075c5c881e07daa246a6c75fe21c06b63d9a33cffcd7dd8c5e942685d266680','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba0bc9fce72dff714cbdbb4dc91e0346a9f02887130a42cc7ff241eff7e5e6a0',2005,'AM','Armenia','people-and-society',239,'$13.65 billion (2004 est.)
-0.25% (2005 est.)
9% (2004 est.)
purchasing power parity - $4,600 (2004 est.)
chief of mission: Ambassador John M. EVANS
embassy: 18 Baghramyan Ave., Yerevan 375019
mailing address: American Embassy Yerevan, Department of State, 7020
Yerevan Place, Washington, DC 20521-7020
telephone: [374](1) 521-611, 520-791, 542-117, 542-132, 524-661,
527-001, 524-840
FAX: [374](1) 520-800','8e2a50bc698cb9aa77f345f6d045d17ed48da49a6b93838c0462a9d982448abe','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78c3b49fc9a3474105c566aec86f6f1e69843421f23e2f8b515ae828e11625b7',2005,'AW','Aruba','people-and-society',240,'$1.94 billion (2002 est.)
0.47% (2005 est.)
-1.5% (2002 est.)
purchasing power parity - $28,000 (2002 est.)
part of the Kingdom of the Netherlands; full autonomy in
internal affairs obtained in 1986 upon separation from the
Netherlands Antilles; Dutch Government responsible for defense and
foreign affairs
Ashmore and Cartier Islands
territory of Australia; administered by
the Australian Department of Transport and Regional Services
Baker Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
Bassas da India
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands
the US does not have an embassy in Aruba; the Consul General
to Netherlands Antilles is accredited to Aruba
Ashmore and Cartier Islands
none (territory of Australia)','ab9fdee2d1bcd18cfbfbd718d16090fc90fd7c2c65e5534e8d068474565f805d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e47567a4f0d14d296c8e44df0a0a95c61df9b95697563106ad7b929390e54a2a',2005,'AU','Australia','people-and-society',241,'$611.7 billion (2004 est.)
0.87% (2005 est.)
3.5% (2004 est.)
purchasing power parity - $30,700 (2004 est.)
chief of mission: William A. STANTON, Charge d''Affaires ad
interim
embassy: Moonah Place, Yarralumla, Canberra, Australian Capital
Territory 2600
mailing address: APO AP 96549
telephone: [61] (02) 6214-5600
FAX: [61] (02) 6214-5970
consulate(s) general: Melbourne, Perth, Sydney','a490f1f7141b1f6a45992146777eae169410150eb01b5ff698a15e252d191711','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3812242903f209cd9fe3daf32bfa9216d62b9854d6b35fd28a9fe29465e136aa',2005,'AT','Austria','people-and-society',242,'$255.9 billion (2004 est.)
0.11% (2005 est.)
1.9% (2004 est.)
purchasing power parity - $31,300 (2004 est.)
chief of mission: Ambassador William Lee LYONS BROWN, Jr.
embassy: Boltzmanngasse 16, A-1090, Vienna
mailing address: use embassy street address
telephone: [43] (1) 31339-0, 31375, 31335
FAX: [43] (1) 3100682','070f72776179d79ec2d303eddecbb6f805e5168cb9569b03ba8d269595f8b0df','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07f5839d539dddc5be3f15d7f0489b8501e5751118626f43bde2aed06b05a6b2',2005,'AZ','Azerbaijan','people-and-society',243,'$30.01 billion (2004 est.)
Bahamas, The
$5.295 billion (2004 est.)
0.59% (2005 est.)
Bahamas, The
0.67% (2005 est.)
9.8% (2004 est.)
Bahamas, The
3% (2004 est.)
purchasing power parity - $3,800 (2004 est.)
Bahamas, The
purchasing power parity - $17,700 (2004 est.)
chief of mission: Ambassador Reno L. HARNISH III
embassy: 83 Azadlyg Prospecti, Baku AZ1007
mailing address: American Embassy Baku, Department of State, 7050
Baku Place, Washington, DC 20521-7050
telephone: [9] (9412) 98-03-35, 36, 37
FAX: [9] (9412) 656-671
Bahamas, The
chief of mission: Ambassador John D. ROOD
embassy: 42 Queen Street, Nassau
mailing address: local or express mail address: P. O. Box N-8197,
Nassau; Department of State, 3370 Nassau Place, Washington, DC
20521-3370
telephone: [1] (242) 322-1181, 328-2206 (after hours)
FAX: [1] (242) 356-0222','5e2458c9b789d9a76aabae5b67534d03fa57d0126c35ef75c131eb1854c01ee0','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b18d69cf04f64e70897d0b906819e20e91cdc3488dbaedb6ed5cee34073ad76c',2005,'BH','Bahrain','people-and-society',244,'$13.01 billion (2004 est.)
1.51% (2005 est.)
5.6% (2004 est.)
purchasing power parity - $19,200 (2004 est.)
chief of mission: Ambassador William T. MONROE
embassy: Building #979, Road 3119 (next to Al-Ahli Sports Club),
Block 331, Zinj District, Manama
mailing address: American Embassy Manama, PSC 451, FPO AE
09834-5100; international mail: American Embassy, Box 26431, Manama
telephone: [973] 1724-2700
FAX: [973] 1725-6242 (consular)','d42c84a59fc0ca92601acfa5b7ce8e2862d5e9dd859681a899a6d86d4b7a4147','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0434d9cdb8aeb64ad90f8f51d4ecc83dcc684249d7144dd8f80d9ef25db7a2c0',2005,'BD','Bangladesh','people-and-society',245,'$275.7 billion (2004 est.)
2.09% (2005 est.)
4.9% (2004 est.)
purchasing power parity - $2,000 (2004 est.)
chief of mission: Ambassador Harry K. THOMAS, Jr.
embassy: Madani Avenue, Baridhara, Dhaka 1212
mailing address: G. P. O. Box 323, Dhaka 1000
telephone: [880] (2) 885-5500
FAX: [880] (2) 882-3744','dcfcefdc92bb7387919e8f4555474a30ed0a239a911acc2960d91ea8b215d52b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4cbb783c8090238f7c81ba85a5c10633ed77a1d3caa63e86ee8c55ac55d2e46',2005,'BB','Barbados','people-and-society',246,'$4.569 billion (2004 est.)
0.33% (2005 est.)
2.3% (2004 est.)
purchasing power parity - $16,400 (2004 est.)
chief of mission: Ambassador Mary E. KRAMER
embassy: Canadian Imperial Bank of Commerce Building, Broad Street,
Bridgetown; (courier) ALICO Building-Cheapside, Bridgetown
mailing address: P. O. Box 302, Bridgetown; CMR 1014, APO AA 34055
telephone: [1] (246) 436-4950
FAX: [1] (246) 429-5246, 429-3379','b583bb57dc85de5b448f4b19bf9a025495716d3ff8eed12f8b0101f40d3b5520','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5654ffafc8058399fcb2a5b064de5d6fe33d2128854318c0c98c5a82882563e1',2005,'BY','Belarus','people-and-society',247,'$70.5 billion (2004 est.)
-0.09% (2005 est.)
6.4% (2004 est.)
purchasing power parity - $6,800 (2004 est.)
chief of mission: Ambassador George A. KROL
embassy: 46 Starovilenskaya St., Minsk 220002
mailing address: PSC 78, Box B Minsk, APO 09723
telephone: [375] (17) 210-12-83, 217-7347, 217-7348
FAX: [375] (17) 234-7853','981bef8b8c2e1c05d92e59eae25f64011ad9817f5f6caa50dadf0aaaa18999c4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60c005641dee52d0af53dfd7a09b8f9ebf39aacd537a2877fa0c45ce50fac6ab',2005,'BE','Belgium','people-and-society',248,'$316.2 billion (2004 est.)
0.15% (2005 est.)
2.6% (2004 est.)
purchasing power parity - $30,600 (2004 est.)
chief of mission: Ambassador Tom C. KOROLOGOS
embassy: Regentlaan 27 Boulevard du Regent, B-1000 Brussels
mailing address: PSC 82, Box 002, APO AE 09710
telephone: [32] (2) 508-2111
FAX: [32] (2) 511-2725','699d0a651f3ba2078f7f1ada0ff9bc5e452d7f9f826aa9858928ac07198e634f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1167fcfad8c255ae7a8e6df5b022cceede266eec462552792d5e5b146c425f66',2005,'BZ','Belize','people-and-society',249,'$1.778 billion (2004 est.)
2.33% (2005 est.)
3.5% (2004 est.)
purchasing power parity - $6,500 (2004 est.)
chief of mission: Ambassador Russell F. FREEMAN
embassy: 29 Gabourel Lane, Belize City
mailing address: P. O. Box 286, Belize City
telephone: [501] 227-7161 through 7163
FAX: [501] 2-30802','7e0eef1efc2180e5185a2476dd6ad1c77891742f396215e75fd1d03f6658fefb','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcdcb88078ed59b6a8ec5ef97783d510fc991a85406052e8e13eaa950d568fa8',2005,'BJ','Benin','people-and-society',250,'$8.338 billion (2004 est.)
2.82% (2005 est.)
5% (2004 est.)
purchasing power parity - $1,200 (2004 est.)
chief of mission: Ambassador Wayne NEILL
embassy: Rue Caporal Bernard Anani, Cotonou
mailing address: 01 B. P. 2012, Cotonou
telephone: [229] 30-06-50
FAX: [229] 30-06-70','51abbbcabfeccee709fd03ed93b15aceb7bcc05798ea17101a0911f939982b7c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5019dbc844489046d3b78c348a56a48101766d9fa7ca96a1cff71181525a6221',2005,'BM','Bermuda','people-and-society',251,'$2.33 billion (2003 est.)
0.64% (2005 est.)
2% (2003 est.)
purchasing power parity - $36,000 (2003 est.)
overseas territory of the UK
chief of mission: Deputy Chief of Mission Antoinette BOECKER
consulate(s) general: Crown Hill, 16 Middle Road, Devonshire DVO3
mailing address: P. O. Box HM325, Hamilton HMBX; American Consulate
General Hamilton, Department of State, 5300 Hamilton Place,
Washington, DC 20520-5300
telephone: [1] (441) 295-1342
FAX: [1] (441) 295-1592, [1] (441) 296-9233','23f6400115be71b3bdef1945747b345521178474e0a4894d42c0cf97eacdd782','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa61e5f9329a540c0abd1e26b25c5e10698493d245ca3b2a40e7c6f1048e0bc4',2005,'BT','Bhutan','people-and-society',252,'$2.9 billion (2003 est.)
Bolivia
$22.33 billion (2004 est.)
2.11% (2005 est.)
Bolivia
1.49% (2005 est.)
5.3% (2003 est.)
Bolivia
3.7% (2004 est.)
purchasing power parity - $1,400 (2003 est.)
Bolivia
purchasing power parity - $2,600 (2004 est.)
the US and Bhutan have no formal diplomatic relations,
although informal contact is maintained between the Bhutanese and US
Embassy in New Delhi (India)
Bolivia
chief of mission: Ambassador David N. GREENLEE
embassy: Avenida Arce 2780, San Jorge, La Paz
mailing address: P. O. Box 425, La Paz; APO AA 34032
telephone: [591] (2) 2430120, 2430251
FAX: [591] (2) 2433900','4ecf4cd512ab682650253b4668d50b3f8f726f03fb716c96558765ce6fea3ce5','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69a86ad884a2588d72c6066dccdbae867773e7a8b7eebc5249ec64ccf6c86d5a',2005,'BA','Bosnia and Herzegovina','people-and-society',253,'$26.21 billion (2004 est.)
0.44% (2005 est.)
5% (2004 est.)
purchasing power parity - $6,500 (2004 est.)
chief of mission: Ambassador Douglas L.
McELHANEY
embassy: Alipasina 43, 71000 Sarajevo
mailing address: use street address
telephone: [387] (33) 445-700
FAX: [387] (33) 659-722
branch office(s): Banja Luka, Mostar','551e28e93d9e13bf61e3e56100889f0f78e5283d8d84036ddaa563bb5be73d34','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97c8c69bab27928351197d88b07a87381f02c2558e19d95b483b271d952d7f21',2005,'BW','Botswana','people-and-society',254,'$15.05 billion (2004 est.)
0% (2005 est.)
3.5% (2004 est.)
purchasing power parity - $9,200 (2004 est.)
chief of mission: Ambassador Joseph HUGGINS
embassy: address NA, Gaborone
mailing address: Embassy Enclave, P. O. Box 90, Gaborone
telephone: [267] 353982
FAX: [267] 312782','16460768de2e80815aeaa6f4e786be65cdad73bf1e771fcaac19e7f816d29fc6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fcad267e302495179d4b2bd777ec93a54f7c04e9be5c9c0d02e9c947b2067f7',2005,'BR','Brazil','people-and-society',255,'$1.492 trillion (2004 est.)
British Virgin Islands
$2.498 billion (2004 est.)
Brunei
$6.842 billion (2003 est.)
1.06% (2005 est.)
British Virgin Islands
2.06% (2005 est.)
Brunei
1.9% (2005 est.)
5.1% (2004 est.)
British Virgin Islands
1% (2002 est.)
Brunei
3.2% (2003 est.)
purchasing power parity - $8,100 (2004 est.)
British Virgin Islands
purchasing power parity - $38,500 (2004 est.)
Brunei
purchasing power parity - $23,600 (2003 est.)
chief of mission: Ambassador John DANILOVICH
embassy: Avenida das Nacoes, Quadra 801, Lote 3, Distrito Federal
Cep 70403-900, Brasilia
mailing address: Unit 3500, APO AA 34030
telephone: [55] (61) 312-7000
FAX: [55] (61) 225-9136
consulate(s) general: Rio de Janeiro, Sao Paulo
consulate(s): Recife','06a0eae63fc4b53e90c52ded698ff9f9a1d6ee5674e2407606798343495b49d7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('938e4f6016d83aa8f0cf75a77592af3487036a7136888f0682846c899c7bcbc6',2005,'BG','Bulgaria','people-and-society',256,'$61.63 billion (2004 est.)
-0.89% (2005 est.)
5.3% (2004 est.)
purchasing power parity - $8,200 (2004 est.)
chief of mission: Ambassador James William PARDEW
embassy: 16 Kozyak Street, Sofia 1407
mailing address: American Embassy Sofia, Department of State, 5740
Sofia Place, Washington, DC 20521-5740
telephone: [359] (2) 937-5100
FAX: [359] (2) 937-5230','c85fb379236de0acfa36f8c8c9ca5bb4a8fa4a52d32996bc9f0bef5d9fc020c4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7780313d4a1a79bc78ffea11b37eac993fdce71658ab886f26b1d82f57bb3f25',2005,'BF','Burkina Faso','people-and-society',257,'$15.74 billion (2004 est.)
Burma
$74.3 billion (2004 est.)
2.53% (2005 est.)
Burma
0.42% (2005 est.)
4.8% (2004 est.)
Burma
-1.3% (2004 est.)
purchasing power parity - $1,200 (2004 est.)
Burma
purchasing power parity - $1,700 (2004 est.)
chief of mission: Ambassador Anthony HOLMES
embassy: 602 Avenue Raoul Follereau, Koulouba, Secteur 4
mailing address: 01 B. P. 35, Ouagadougou 01; pouch mail - U. S.
Department of State, 2440 Ouagadougou Place, Washington, DC
20521-2440
telephone: [226] 306723
FAX: [226] 303890
Burma
chief of mission: Charge d''Affaires Carmen M. MARTINEZ
embassy: 581 Merchant Street, Rangoon (GPO 521)
mailing address: Box B, APO AP 96546
telephone: [95] (1) 379 880, 379 881
FAX: [95] (1) 256 018','09b3adbd5384185a7f4e05b7cf52592de79ed5ac22a1102579327c660c0373bc','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f9e35bbd90cdf985b7ada3a3a140016dc48c35d0063b08139ffd0702f8b9779',2005,'BI','Burundi','people-and-society',258,'$4.001 billion (2004 est.)
2.22% (2005 est.)
3% (2004 est.)
purchasing power parity - $600 (2004 est.)
chief of mission: Ambassador James Howard YELLIN
embassy: Avenue des Etats-Unis, Bujumbura
mailing address: B. P. 1720, Bujumbura
telephone: [257] 223454
FAX: [257] 222926','5aec4b558ad8b17005e0ffa31b6f260b4f153ad9a01a7e24089eafdb4b674aaf','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06d9364841a08b1a66f49b73dd36bbb7d39b1f56f3c32a1e6c159030b99f3db3',2005,'KH','Cambodia','people-and-society',259,'$26.99 billion (2004 est.)
1.81% (2005 est.)
5.4% (2004 est.)
purchasing power parity - $2,000 (2004 est.)
chief of mission: Ambassador Joseph A. MUSSOMELI
embassy: 27 EO Street 240, Phnom Penh
mailing address: Box P, APO AP 96546
telephone: [855] (23) 216-436/438
FAX: [855] (23) 216-437/811','64f2a7cb3855c807d03b5aa86c67de753b5563c1cc8f87fa175d81d29d106651','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21f5b8be120e6854e008883eb2eb9aceea2284d2606e31bf8eb97c2d6cd0273d',2005,'CM','Cameroon','people-and-society',260,'$30.17 billion (2004 est.)
1.93% (2005 est.)
4.9% (2004 est.)
purchasing power parity - $1,900 (2004 est.)
chief of mission: Ambassador George McDade STAPLES
embassy: Rue Nachtigal, Yaounde
mailing address: P. O. Box 817, Yaounde; pouch: American Embassy,
Department of State, Washington, DC 20521-2520
telephone: [237] 223-05-12, 222-25-89, 222-17-94, 223-40-14
FAX: [237] 223-07-53
branch office(s): Douala','417b1c1d53aa1902b817a13214b2d3c323725b9418fbc1a598186b2fbd75855d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4200604d0965d34dfa14496e1e11986dd5e1481f5e2e551b7a55ebbbc4ac19f5',2005,'CA','Canada','people-and-society',261,'$1.023 trillion (2004 est.)
Cape Verde
$600 million (2002 est.)
0.9% (2005 est.)
Cape Verde
0.67% (2005 est.)
2.4% (2004 est.)
Cape Verde
5% (2004 est.)
purchasing power parity - $31,500 (2004 est.)
Cape Verde
purchasing power parity - $1,400 (2002 est.)
chief of mission: Ambassador David H. WILKINS
embassy: 490 Sussex Drive, Ottawa, Ontario K1N 1G8
mailing address: P. O. Box 5000, Ogdensburgh, NY 13669-0430
telephone: [1] (613) 238-5335, 4470
FAX: [1] (613) 688-3082
consulate(s) general: Calgary, Halifax, Montreal, Quebec, Toronto,
Vancouver, Winnipeg
Cape Verde
chief of mission: Ambassador Donald C. JOHNSON
embassy: Rua Abilio m. Macedo 81, Praia
mailing address: C. P. 201, Praia
telephone: [238] 261 56 16, 261 56 17
FAX: [238] 261 13 55','ca78ce26be99d8855ab104f0d81c5a839d36b35e116a3581d6bb3f8f7aa77afd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45d2a980c36bd07997e5082c70107ee02378bc4f91b0faf1b9827eb3d45c1607',2005,'KY','Cayman Islands','people-and-society',262,'$1.391 billion (2004 est.)
2.64% (2005 est.)
1.7% (2002 est.)
purchasing power parity - $32,300 (2004 est.)
overseas territory of the UK
none (overseas territory of the UK)','a766f3745a7634c17d5746c8a2216dcc90e1e56717838ac6d8eb936967112a7c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2877079c76f0304f0349d44732c6540e1d175c2a866e58f9cd96fc6e7d98e0fd',2005,'CF','Central African Republic','people-and-society',263,'$4.248 billion (2004 est.)
1.49% (2005 est.)
0.5% (2004 est.)
purchasing power parity - $1,100 (2004 est.)
chief of mission: Charge d''Affaires James
PANOS
embassy: Avenue David Dacko, Bangui
mailing address: B. P. 924, Bangui
telephone: [236] 61 02 00
FAX: [236] 61 44 94
note: the embassy is currently operating with a minimal staff','c10b4ddaedd5da7f3a8fecb94f785430cf252e3e1485147ea0c012314b91a075','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69d89846450f8888ce933e859f96e11d134870ca8b7487ea167bfdc79073d983',2005,'TD','Chad','people-and-society',264,'$15.66 billion (2004 est.)
2.95% (2005 est.)
38% (2004 est.)
purchasing power parity - $1,600 (2004 est.)
chief of mission: Ambassador Marc WALL
embassy: Avenue Felix Eboue, N''Djamena
mailing address: B. P. 413, N''Djamena
telephone: [235] (51) 70-09
FAX: [235] (51) 56-54','c320d152da8273215a590396e2082bb9383a81d3670886e6de02fa23c01659a5','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d3dcca7db3b560ad1d97df667d39840a72dd84006cfed284b8f377e6f0a5180',2005,'CL','Chile','people-and-society',265,'$169.1 billion (2004 est.)
0.97% (2005 est.)
5.8% (2004 est.)
purchasing power parity - $10,700 (2004 est.)
chief of mission: Ambassador Craig A. KELLY
embassy: Avenida Andres Bello 2800, Las Condes, Santiago
mailing address: APO AA 34033
telephone: [56] (2) 232-2600
FAX: [56] (2) 330-3710','8e16feb70b539a674d90ab758f387486d7cbdfc5f82a11a6f9aa3f513f4e5791','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b081ed1fcf3dd2186706199d18264b5ab8711088740ab76742bd97586b452dbf',2005,'CN','China','people-and-society',266,'$7.262 trillion (2004 est.)
0.58% (2005 est.)
9.1% (official data) (2004 est.)
purchasing power parity - $5,600 (2004 est.)
chief of mission: Ambassador Clark T. RANDT, Jr.
embassy: Xiu Shui Bei Jie 3, 100600 Beijing
mailing address: PSC 461, Box 50, FPO AP 96521-0002
telephone: [86] (10) 6532-3831
FAX: [86] (10) 6532-6929
consulate(s) general: Chengdu, Guangzhou, Hong Kong, Shanghai,
Shenyang','d9d4760862400f685c80040abcbc3bff91e25d5afd0ec215da9d8a13612babc5','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdb9193c2059dd4ab66c902e8b5fb0478e340711bb4a93a91e4beb9cf56681d3',2005,'CX','Christmas Island','people-and-society',267,'NA
0% (2005 est.)
NA
territory of Australia; administered by the
Australian Department of Transport and Regional Services
Clipperton Island
possession of France; administered by France from
French Polynesia by a high commissioner of the Republic
none (territory of Australia)','2b490e13f5e1cb95b1a0895dbc13449e4fba29f0919da56943a5f29c7a6c9ada','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b83c15030ae6b6f502db66491e20a8653bcf0ccfe3a8d3bca788b6c8c731676c',2005,'CC','Cocos (Keeling) Islands','people-and-society',268,'NA
0% (2005 est.)
NA%
territory of Australia; administered from
Canberra by the Australian Department of Transport and Regional
Services
none (territory of Australia)','0cb6c915261f6bfb22da97283b4a0e168dcf4b02fc30efc9acac8abeeb9da514','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6444ea4c406e57ae624128b4d5410834bb0c26bbc966acaa5057273a6468a248',2005,'CO','Colombia','people-and-society',269,'$281.1 billion (2004 est.)
1.49% (2005 est.)
3.6% (2004 est.)
purchasing power parity - $6,600 (2004 est.)
chief of mission: Ambassador William B. WOOD
embassy: Calle 22D-BIS, numbers 47-51, Apartado Aereo 3831
mailing address: Carrera 45 #22D-45, Bogota, D.C., APO AA 34038
telephone: [57] (1) 315-0811
FAX: [57] (1) 315-2197','ef8be9a1589b07cb9b5147c089fe54f1f2845dc97ee995a534405b8ee1ccf8b4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abed619c7724ed2cd495057831f397bc9a7933d1e445ad04b01fc440f8795f70',2005,'KM','Comoros','people-and-society',270,'$441 million (2002 est.)
Congo, Democratic Republic of the
$42.74 billion (2004 est.)
Congo, Republic of the
$2.324 billion (2004 est.)
2.91% (2005 est.)
Congo, Democratic Republic of the
2.98% (2005 est.)
Congo, Republic of the
1.31% (2005 est.)
2% (2002 est.)
Congo, Democratic Republic of the
7.5% (2004 est.)
Congo, Republic of the
3.7% (2004 est.)
purchasing power parity - $700 (2002 est.)
Congo, Democratic Republic of the
purchasing power parity - $700
(2004 est.)
Congo, Republic of the
purchasing power parity - $800 (2004 est.)
the US does not have an embassy in Comoros; the ambassador
to Mauritius is accredited to Comoros
Congo, Democratic Republic of the
chief of mission: Ambassador
Aubrey HOOKS
embassy: 310 Avenue des Aviateurs, Kinshasa
mailing address: Unit 31550, APO AE 09828
telephone: [243] (88) 43608
FAX: [243] (88) 43467
Congo, Republic of the
chief of mission: Ambassador Roger A. MEECE
embassy: NA
mailing address: NA
telephone: [243] (88) 43608
note: the embassy is temporarily collocated with the US Embassy in
the Democratic Republic of the Congo (US Embassy Kinshasa, 310
Avenue des Aviateurs, Kinshasa)','85ea268d648a3d4b1bfe9ef07ab5359adc7a03673c72ee36e7a89a582ef9f09e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a5aadbd4e9d303bc38a10f8fc9d91bb43cd0337f76fe405f6fed940a99bb72c',2005,'CK','Cook Islands','people-and-society',271,'$105 million (2001 est.)
NA
7.1% (2001 est.)
purchasing power parity - $5,000 (2001 est.)
self-governing in free association with New Zealand;
Cook Islands is fully responsible for internal affairs; New Zealand
retains responsibility for external affairs and defense, in
consultation with the Cook Islands
Coral Sea Islands
territory of Australia; administered from Canberra
by the Department of the Environment, Sport, and Territories
Dhekelia
overseas territory of UK; administered by an administrator
who is also the Commander, British Forces Cyprus
Europa Island
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands
Falkland Islands (Islas Malvinas)
overseas territory of the UK; also
claimed by Argentina
none (self-governing in free association with New
Zealand)
Coral Sea Islands
none (territory of Australia)','0ae3e79d1996911b4a21b5306876bebc89fbc30ee393c6ac78b51ef92669d2ba','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6d4f0f0f37e3056dc8c91b1de10b2fb4d2df7620535f523b502161d658f3851',2005,'CR','Costa Rica','people-and-society',272,'$37.97 billion (2004 est.)
Cote d''Ivoire
$24.78 billion (2004 est.)
1.48% (2005 est.)
Cote d''Ivoire
2.06% (2005 est.)
3.9% (2004 est.)
Cote d''Ivoire
-1% (2004 est.)
purchasing power parity - $9,600 (2004 est.)
Cote d''Ivoire
purchasing power parity - $1,500 (2004 est.)
chief of mission: Ambassador (vacant); Charge d''Affaires
Douglas M. BARNES
embassy: Calle 120 Avenida O, Pavas, San Jose
mailing address: APO AA 34020
telephone: [506] 220-3939
FAX: [506] 519-2305
Cote d''Ivoire
chief of mission: Ambassador Aubrey HOOKS
embassy: 5 Rue Jesse Owens, Abidjan
mailing address: B. P. 1712, Abidjan 01
telephone: [225] 20 21 09 79
FAX: [225] 20 22 32 59','b0b28664fb75f87a773172370511ab5394ec7f26f1c1b65df9fb69c187a1ee4a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('971af5f7cdbad6537346ee7645596320cd6471101fa281033f5df1b13d70708c',2005,'HR','Croatia','people-and-society',273,'$50.33 billion (2004 est.)
-0.02% (2005 est.)
3.7% (2004 est.)
purchasing power parity - $11,200 (2004 est.)
chief of mission: Ambassador Ralph FRANK
embassy: 2 Thomas Jefferson, 10010 Zagreb
mailing address: use street address
telephone: [385] (1) 661-2200
FAX: [385] (1) 661-2373','952e418ebd9cec0f380d021c44917820c5976c97aac7dd179a3bb0abd93c0a56','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ee16eb68aeb9eeb440d09225e824b0c4ee14c5bda5dee9cf7229d38a7b443f8',2005,'CU','Cuba','people-and-society',274,'$33.92 billion (2004 est.)
0.33% (2005 est.)
3% (2004 est.)
purchasing power parity - $3,000 (2004 est.)
none; note - the US has an Interests Section in the Swiss
Embassy, headed by Principal Officer James C. CASON; address: USINT,
Swiss Embassy, Calzada between L and M Streets, Vedado, Havana;
telephone: [53] (7) 833-3551 through 3559 (operator assistance
required); FAX: [53] (7) 833-3700; protecting power in Cuba is','73303c669732f06c96a7993c0b1104d0aa7788e6e2cfc41111c1319d1ba7d337','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1c04f08a3a460fd35b73f2203efc72f7213a056bcec01ad05bff97fd10226b0',2005,'CY','Cyprus','people-and-society',275,'Republic of Cyprus: purchasing power parity - $15.71 billion
north Cyprus: purchasing power parity - $4.54 billion (2004 est.)
Czech Republic
$172.2 billion (2004 est.)
0.54% (2005 est.)
Czech Republic
-0.05% (2005 est.)
Republic of Cyprus: 3.2% north Cyprus: 2.6% (2004 est.)
Czech Republic
3.7% (2004 est.)
Republic of Cyprus: purchasing power parity - $20,300 (2004
est.); north Cyprus: purchasing power parity - $7,135 (2004 est.)
Czech Republic
purchasing power parity - $16,800 (2004 est.)
chief of mission: Ambassador Michael KLOSSON
embassy: corner of Metochiou and Ploutarchou Streets, Engomi, 2407
Nicosia
mailing address: P. O. Box 24536, 1385 Nikosia
telephone: [357] (22) 393939
FAX: [357] (22) 780944
Czech Republic
chief of mission: Ambassador William J. CABANISS
embassy: Trziste 15, 11801 Prague 1
mailing address: use embassy street address
telephone: [420] (2) 5753-0663
FAX: [420] (2) 5753-0583','1bc1497cd1d7cabac07b162840c79bab6547ed707167a39ff5c14c67b46490b6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('475c46cbc5a4d31f0946e0a547a77189df5593ec223e586a739d15608ef714e5',2005,'DK','Denmark','people-and-society',276,'$174.4 billion (2004 est.)
0.34% (2005 est.)
2.1% (2004 est.)
purchasing power parity - $32,200 (2004 est.)
chief of mission: Ambassador (vacant); Charge d''Affaires
Sally M. LIGHT
embassy: Dag Hammarskjolds Alle 24, 2100 Copenhagen
mailing address: PSC 73, APO AE 09716
telephone: [45] 35 55 31 44
FAX: [45] 35 43 02 23
Dhekelia
none (overseas territory of the UK)','fa000e5ca3c26da048d4d06e3647609d57da1bcfa9daedae6f92f889f5f2a7e4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('337c678cef60f389dab006bc88363e398467a2a08b6654883a50f1a39e95d661',2005,'DJ','Djibouti','people-and-society',277,'$619 million (2002 est.)
2.06% (2005 est.)
3.5% (2002 est.)
purchasing power parity - $1,300 (2002 est.)
chief of mission: Ambassador Marguerita RAGSDALE
embassy: Plateau du Serpent, Boulevard Marechal Joffre, Djibouti
mailing address: B. P. 185, Djibouti
telephone: [253] 35 39 95
FAX: [253] 35 39 40','e70160492f2366b4398420e8c6d73c4ab500152c2beb34d856a7361847c93f9e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f282c595f9fe65460dd09792476397527e4b71bd08cd48fe9b8e57c9d09e6d1',2005,'DM','Dominica','people-and-society',278,'$384 million (2003 est.)
-0.27% (2005 est.)
-1% (2003 est.)
purchasing power parity - $5,500 (2003 est.)
the US does not have an embassy in Dominica; the US
Ambassador to Barbados is accredited to Dominica','c6ffc77d426ca00cacb3d9faf710addc732f96b9398063f80dc4705da4a53a5a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35b0f7452b3e213de4d1b49c4938ad63b6d360d01e3f767af48686c172c8a4e1',2005,'DO','Dominican Republic','people-and-society',279,'$55.68 billion (2004 est.)
East Timor
$370 million (2004 est.)
1.29% (2005 est.)
East Timor
2.09% (2005 est.)
1.7% (2004 est.)
East Timor
1% (2004 est.)
purchasing power parity - $6,300 (2004 est.)
East Timor
purchasing power parity - $400 (2004 est.)
chief of mission: Ambassador Hans H. HERTELL
embassy: corner of Calle Cesar Nicolas Penson and Calle Leopoldo
Navarro, Santo Domingo
mailing address: Unit 5500, APO AA 34041-5500
telephone: [1] (809) 221-2171
FAX: [1] (809) 686-7437
East Timor
chief of mission: Ambassador Grover Joseph REES
embassy: Avenida de Portugal, Praia dos Conqueiros, Dili
mailing address: Department of State, 8250 Dili Place, Washington,
DC 20521-8250
telephone: (670) 332-4684
FAX: (670) 331-3206','d6f8e6a4780570e1867e68b79d67888c5e0cdc74f84dcd0699e8b59dcf896980','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e574a84f98e077ed468fe7207b699fcedff514b8126837af5ce62f6763ff1a65',2005,'EC','Ecuador','people-and-society',280,'$49.51 billion (2004 est.)
1.24% (2005 est.)
5.8% (2004 est.)
purchasing power parity - $3,700 (2004 est.)
chief of mission: Ambassador Kristie Anne KENNEY
embassy: Avenida 12 de Octubre y Avenida Patria, Quito
mailing address: APO AA 34039
telephone: [593] (2) 256-2890
FAX: [593] (2) 250-2052
consulate(s) general: Guayaquil','d546b5d930c5a17413c57ee2e341c586841a69aec079fdf53f582fc90fc8be21','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46e027ca66e3551952ea522234843d4f52f092853a3319e6c1e80722c17c6d1b',2005,'EG','Egypt','people-and-society',281,'$316.3 billion (2004 est.)
1.78% (2005 est.)
4.5% (2004 est.)
purchasing power parity - $4,200 (2004 est.)
chief of mission: Ambassador designate Francis J. RICCIARDONE,
Jr
embassy: 8 Kamal El Din Salah St., Garden City, Cairo
mailing address: Unit 64900, Box 15, APO AE 09839-4900
telephone: [20] (2) 797-3300
FAX: [20] (2) 797-3200','6850b1e0830ec1702de253667c3bc4de493691682695b5c3724e3987ce8aadfd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('616f14633d722733b08fd80e7619b77a4f864a0d0b91c476ce4ccc2b815e3b2d',2005,'SV','El Salvador','people-and-society',282,'$32.35 billion (2004 est.)
1.75% (2005 est.)
1.8% (2004 est.)
purchasing power parity - $4,900 (2004 est.)
chief of mission: Ambassador H. Douglas BARCLAY
embassy: Final Boulevard Santa Elena Sur, Antiguo Cuscatlan, La
Libertad, San Salvador
mailing address: Unit 3116, APO AA 34023
telephone: [503] 278-4444
FAX: [503] 278-5522','43c64c26a246c2d9087171b8b9825c1138d71091ff85530c8253653fddfc3a5e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33ed8522d5420a9734dc1c93e2266bccae169e99a99f0de1d39d40f6f17cfc6b',2005,'GQ','Equatorial Guinea','people-and-society',283,'$1.27 billion (2002 est.)
2.42% (2005 est.)
20% (2002 est.)
purchasing power parity - $2,700 (2002 est.)
the US does not have an embassy in Equatorial
Guinea (embassy closed September 1995); the US ambassador to
Cameroon is accredited to Equatorial Guinea; the US State Department
is considering opening a Consulate Agency in Malabo','edc6e7669ed18cecfdd15298a5880a3df55d681e336c29c4e4c836a3665de843','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52d2151e8639c3babb1b5996a8fb0056102f0beb7a0e89e326233a866ce3ef08',2005,'ER','Eritrea','people-and-society',284,'$4.154 billion (2004 est.)
2.51% (2005 est.)
2.5% (2004 est.)
purchasing power parity - $900 (2004 est.)
chief of mission: Ambassador Scott H. DELISI
embassy: Franklin D. Roosevelt Street, Asmara
mailing address: P. O. Box 211, Asmara
telephone: [291] (1) 120004
FAX: [291] (1) 127584','b23067cea1bb70132604b6d37a08d057f8e944045836c2412a4b27974b5ffc9c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28905f7d12ca68a0c6b24cca91fc15588ce088c860b408cd2f44f83add458ab7',2005,'EE','Estonia','people-and-society',285,'$19.23 billion (2004 est.)
-0.65% (2005 est.)
6% (2004 est.)
purchasing power parity - $14,300 (2004 est.)
chief of mission: Ambassador Aldona Zofia WOS
embassy: Kentmanni 20, 15099 Tallinn
mailing address: use embassy street address
telephone: [372] 668-8100
FAX: [372] 668-8134','4e1abf9296c4a99aec56b662e83ec082b5a1982fb8b0bf2d549f89fc0f250da3','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04f76936e4a9baf002ae4df570e380c4c251653a499b85c244ad3ea162c572b6',2005,'ET','Ethiopia','people-and-society',286,'$54.89 billion (2004 est.)
European Union
$11.65 trillion (2004 est.)
Falkland Islands (Islas Malvinas)
$75 million (2002 est.)
2.36% (2005 est.)
European Union
0.15% (July 2005 est.)
Falkland Islands (Islas Malvinas)
2.44% (2005 est.)
11.6% (2004 est.)
European Union
2.4% (2004 est.)
Falkland Islands (Islas Malvinas)
NA%
purchasing power parity - $800 (2004 est.)
European Union
purchasing power parity - $26,900 (2004 est.)
Falkland Islands (Islas Malvinas)
purchasing power parity - $25,000
(2002 est.)
chief of mission: Ambassador Aurelia A. BRAZEAL
embassy: Entoto Street, Addis Ababa
mailing address: P. O. Box 1014, Addis Ababa
telephone: [251] (1) 550666
FAX: [251] (1) 551328
European Union
chief of mission: Ambassador Rockwell SCHNABEL
embassy: 13 Zinnerstraat/Rue Zinner, B-1000 Brussels
mailing address: same as above
telephone: [32] (2) 508-2222
FAX: [32] (2) 512-5720
Falkland Islands (Islas Malvinas)
none (overseas territory of the
UK; also claimed by Argentina)','174219a123cfdbd876c56659f94ac946521fb5ff3f1c5ce5cc5f2409269a3c86','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b27bb90837362fcc33d56ab5bac2569ab74cef3fd04293f25e87608793f9225',2005,'FO','Faroe Islands','people-and-society',287,'$1 billion (2001 est.)
0.62% (2005 est.)
10% (2001 est.)
purchasing power parity - $22,000 (2001 est.)
part of the Kingdom of Denmark; self-governing
overseas administrative division of Denmark since 1948
none (self-governing overseas administrative division
of Denmark)','20133dd2ad1020e05efdc3ca423f42a8fe4a9703ea2790aacc14e722c8549db9','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a563a62442271d33721b15f822bb1608b4147420e9427b737760b66841168837',2005,'FJ','Fiji','people-and-society',288,'$5.173 billion (2004 est.)
1.4% (2005 est.)
3.6% (2004 est.)
purchasing power parity - $5,900 (2004 est.)
chief of mission: Ambassador David L. LYON
embassy: 31 Loftus Street, Suva
mailing address: P. O. Box 218, Suva
telephone: [679] 331-4466
FAX: [679] 330-0081','f25cc822e7a73ed0dc8383675c9e66d0e91c1b3f13c9932d05f07e249ed8ed2e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf865b1154d9040c045896a726dc99b97298881556704201e959c81746045ddb',2005,'FI','Finland','people-and-society',289,'$151.2 billion (2004 est.)
0.16% (2005 est.)
3% (2004 est.)
purchasing power parity - $29,000 (2004 est.)
chief of mission: Ambassador Earle I. MACK
embassy: Itainen Puistotie 14B, 00140 Helsinki
mailing address: APO AE 09723
telephone: [358] (9) 616250
FAX: [358] (9) 6162 5800','5acd28f0d85b786b2d631992aff2c4f090109b1d2f755809a1417de1992630e6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f00f525ac00f1f533e5852425251e26d79794b91b4029c85852b495dfe60b102',2005,'FR','France','people-and-society',290,'$1.737 trillion (2004 est.)
0.37% (2005 est.)
2.1% (2004 est.)
purchasing power parity - $28,700 (2004 est.)
chief of mission: Ambassador Howard H. LEACH
embassy: 2 Avenue Gabriel, 75008 Paris Cedex 08
mailing address: PSC 116, APO AE 09777
telephone: [33] (1) 43-12-22-22
FAX: [33] (1) 42 66 97 83
consulate(s) general: Marseille, Strasbourg','ccb9080e4e8b444796ea2370738cc8f3763bce555be4795e6715d1cc66ea3c3a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50cc83af8a23fea9c7d631bb14fb5d26affa09d8f5130c029d6e18d41eee26c9',2005,'GF','French Guiana','people-and-society',291,'$1.551 billion (2003 est.)
2.1% (2005 est.)
NA%
purchasing power parity - $8,300 (2003 est.)
overseas department of France
none (overseas department of France)','74043728af8e454547c0cbcdf3c2686105b583c0071a52d4d8860305ab1d5225','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e44ef11939cf537cf3afc866398deaa6a33ad7e2ad8eefa40e665b3e828b149f',2005,'PF','French Polynesia','people-and-society',292,'$4.58 billion (2003 est.)
1.52% (2005 est.)
NA% (2001 est.)
purchasing power parity - $17,500 (2003 est.)
overseas lands of France; overseas territory of
France from 1946-2004
French Southern and Antarctic Lands
overseas territory of France
since 1955; administered from Paris by Administrateur Superieur
Michel CHAMPON (since 20 December 2004), assisted by Secretary
General Jean-Yves HERMOSO (since NA)
none (overseas lands of France)
French Southern and Antarctic Lands
none (overseas territory of
France)','4b379dbaa3fbdc0a183bfe8d75b48698e31d6a0d9e4b81647c45056785b98eaa','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('766b5933ed9b04d694bcbba48fd4536ac7608f28a7f8f7620c4bb24fe1000657',2005,'GA','Gabon','people-and-society',293,'$7.966 billion (2004 est.)
Gambia, The
$2.799 billion (2004 est.)
Gaza Strip
$768 million (2003 est.)
2.45% (2005 est.)
Gambia, The
2.93% (2005 est.)
Gaza Strip
3.77% (2005 est.)
1.9% (2004 est.)
Gambia, The
6% (2004 est.)
Gaza Strip
4.5% (2003 est.)
purchasing power parity - $5,900 (2004 est.)
Gambia, The
purchasing power parity - $1,800 (2004 est.)
Gaza Strip
purchasing power parity - $600 (2003 est.)
chief of mission: Ambassador Barrie R. WALKLEY
embassy: Boulevard du Bord de Mer, Libreville
mailing address: Centre Ville, B. P. 4000, Libreville
telephone: [241] 76 20 03 through 76 20 04, after hours - 74 34 92
FAX: [241] 74 55 07
Gambia, The
chief of mission: Ambassador Joseph D. STAFFORD, III
embassy: Kairaba Avenue, Fajara, Banjul
mailing address: P. M. B. No. 19, Banjul
telephone: [220] 392856, 392858, 391971
FAX: [220] 392475','04b5275f7f03bb67aec16ef70c4877bca724d459dc99d2bf25ebf6b4e8a005d4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a622e6f7f2392e9042a0d0a455a14b1738f11c082837e22aa07e39fd0ded8a2',2005,'GE','Georgia','people-and-society',294,'$14.45 billion (2004 est.)
-0.35% (2005 est.)
9.5% (2004 est.)
purchasing power parity - $3,100 (2004 est.)
chief of mission: Ambassador Richard M. MILES
embassy: #25 Atoneli Street, T''bilisi 0105
mailing address: 7060 Tbilisi Place, Washington, DC 20521-7060
telephone: [995] (32) 989-967/68
FAX: [995] (32) 933-759','77afedc83cc8b9b033f62d99457b4cbeb0580da6c6f0f27696b30acb464af538','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c6d5f42ab4c4e77f7148f204b9403bc46be2828da3a230b6a23657550e4c1ae',2005,'DE','Germany','people-and-society',295,'$2.362 trillion (2004 est.)
0% (2005 est.)
1.7% (2004 est.)
purchasing power parity - $28,700 (2004 est.)
chief of mission: Ambassador Daniel R. COATS
embassy: Neustaedtische Kirchstrasse 4-5, 10117 Berlin; note - a new
embassy will be built near the Brandenburg Gate in Berlin; ground
was broken in October 2004 and completion is scheduled for 2008
mailing address: PSC 120, Box 1000, APO AE 09265
telephone: [49] (030) 8305-0
FAX: [49] (030) 8305-1215
consulate(s) general: Duesseldorf, Frankfurt am Main, Hamburg,
Leipzig, Munich','f232292ff87f1b4f83153aa71fc99e739397047a93a5686392ba3f406b517343','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd739cdee70f0e3ca6001dc0b78f174e799863b36df7a0b57d302a7473b39f8f',2005,'GH','Ghana','people-and-society',296,'$48.27 billion (2004 est.)
1.25% (2005 est.)
5.4% (2004 est.)
purchasing power parity - $2,300 (2004 est.)
chief of mission: Ambassador Mary Carlin YATES
embassy: 6th and 10th Lanes, 798/1 Osu, Accra
mailing address: P. O. Box 194, Accra
telephone: [233] (21) 775-347, 775-348
FAX: [233] (21) 701-813','186bea505f9bad47fb8f881746811d2e970bff7325f331ade15a8895de25b7ed','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c0619d8830b21d8057180cc69f6579372ef42379d9f27e4b5b07b851189a0ec',2005,'GI','Gibraltar','people-and-society',297,'$769 million (2000 est.)
0.17% (2005 est.)
NA%
purchasing power parity - $27,900 (2000 est.)
overseas territory of the UK
Glorioso Islands
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands
none (overseas territory of the UK)
Glorioso Islands
none (possession of France)','b1fa3658bee830b05818faa1caaaeb68c7a40a31882976fd4e169a9e872cec01','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98031114b15f8a98443d8ee036153ea1bcb329cd273bed16bfa9be116daec428',2005,'GR','Greece','people-and-society',298,'$226.4 billion (2004 est.)
0.19% (2005 est.)
3.7% (2004 est.)
purchasing power parity - $21,300 (2004 est.)
chief of mission: Ambassador Charles RIES
embassy: 91 Vasilissis Sophias Avenue, 10160 Athens
mailing address: PSC 108, APO AE 09842-0108
telephone: [30] (210) 721-2951
FAX: [30] (210) 645-6282
consulate(s) general: Thessaloniki','11bd40a8d46af50d6c663bb97c5ab144a436df1b5845649aa9cd49d96c2e1e70','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7ae9e639befcc8961c3389ba92849e1285e678080019e1da47bc9859480b56d',2005,'GL','Greenland','people-and-society',299,'$1.1 billion (2001 est.)
-0.02% (2005 est.)
1.8% (2001 est.)
purchasing power parity - $20,000 (2001 est.)
part of the Kingdom of Denmark; self-governing overseas
administrative division of Denmark since 1979
none (self-governing overseas administrative division of
Denmark)','08f7a6cb7a01b2111472c21a27e6557d9c99e09ead089a32b5f90df052323f5f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08714f8bea3e4e5da28f1cc6a3bfe859e840ccf04a9dfc77ba984c8adc6652df',2005,'GD','Grenada','people-and-society',300,'$440 million (2002 est.)
0.19% (2005 est.)
2.5% (2002 est.)
purchasing power parity - $5,000 (2002 est.)
chief of mission: the US Ambassador to Barbados is
accredited to Grenada
embassy: Lance-aux-Epines Stretch, Saint George''s
mailing address: P. O. Box 54, Saint George''s, Grenada, West Indies
telephone: [1] (473) 444-1173 through 1176
FAX: [1] (473) 444-4820','cf73474b4f5a5895700401d4d840d84192580b4dc559a26977004d87a78ea751','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8db439fa792793e9ad44758366719ec31678bff7e6b789f5c0b4deb30f7d4892',2005,'GP','Guadeloupe','people-and-society',301,'$3.513 billion (2003 est.)
0.92% (2005 est.)
NA%
purchasing power parity - $7,900 (2003 est.)
overseas department of France
none (overseas department of France)','0771350fc8840770ba1eff6806f3fbddacf151eb8c05bf81d07178048d18b34a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55e71eae9b57c8515918e740ec67b6cd28a90d3221d65a3f5170ec2287d911ba',2005,'GU','Guam','people-and-society',302,'$3.2 billion (2000 est.)
1.46% (2005 est.)
NA
purchasing power parity - $21,000 (2000 est.)
organized, unincorporated territory of the US with policy
relations between Guam and the US under the jurisdiction of the
Office of Insular Affairs, US Department of the Interior
none (territory of the US)','1e6f29520bd9735b8a2d4f36b78fbb2d3c6d2478333995ffa7fa8d2f0415305c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('886d3bf36cec961228df3b6f716c72046f1e1ac7eb90afdaf4b19d6444d7281d',2005,'GT','Guatemala','people-and-society',303,'$59.47 billion (2004 est.)
2.57% (2005 est.)
2.6% (2004 est.)
purchasing power parity - $4,200 (2004 est.)
chief of mission: Ambassador John R. HAMILTON
embassy: 7-01 Avenida Reforma, Zone 10, Guatemala City
mailing address: APO AA 34024
telephone: [502] 2331-1541/55
FAX: [502] 2334-8477','3115fc00ad0bad2093bbfd16962d682c28dfff788cebc6725141faeff4951cfb','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3c7a133d8e60defd85ca3cf6b9c3911cf0785a827bdb826f5000fa3d6583e92',2005,'GG','Guernsey','people-and-society',304,'$2.59 billion (2003 est.)
0.29% (2005 est.)
3% (2003 est.)
purchasing power parity - $40,000 (2003 est.)
British crown dependency
none (British crown dependency)','3dc89d4b40accc4a603523162a2ad1a2e68a87aa3f461684dd226fac530087cf','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa9a3b8eec39b7118d09672107cad6309919f8cb709f89a594bde3969a716b74',2005,'GN','Guinea','people-and-society',305,'$19.5 billion (2004 est.)
2.37% (2005 est.)
1% (2004 est.)
purchasing power parity - $2,100 (2004 est.)
chief of mission: Ambassador Jackson MCDONALD
embassy: Rue Ka 038, Conakry
mailing address: B. P. 603, Conakry
telephone: [224] 41 15 20, 41 15 21, 41 15 23
FAX: [224] 41 15 22','a0f6788c68d5cfda3c5218eabcef99ba6b8549411d3b70aa20f282357aebc55f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9827372d20f02503ae9f534a1daeaf865d67826db0da5e4a77d6a073f4732e28',2005,'GW','Guinea-Bissau','people-and-society',306,'$1.008 billion (2004 est.)
1.96% (2005 est.)
2.6% (2004 est.)
purchasing power parity - $700 (2004 est.)
the US Embassy suspended operations on 14 June 1998 in
the midst of violent conflict between forces loyal to then President
VIEIRA and military-led junta; US embassy Dakar is responsible for
covering Guinea-Bissau: telephone - [221] 823-4296; FAX - [221]
822-5903','d4bfb215181490b189eddd00d316665913bdca65295e7ac566a827dac3829080','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cb5eeddf26e5cee8e9e463188d13b716542aa76ccc048b57955f656e9dd6807',2005,'GY','Guyana','people-and-society',307,'$2.899 billion (2004 est.)
0.26% (2005 est.)
1.9% (2004 est.)
purchasing power parity - $3,800 (2004 est.)
chief of mission: Ambassador Roland BULLEN
embassy: 100 Young and Duke Streets, Kingston, Georgetown
mailing address: P. O. Box 10507, Georgetown
telephone: [592] 225-4900 through 4909
FAX: [592] 225-8497','e233ec66bcc0bd2f15019e194589cfc377ff84202f76001f112a153de9d00588','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bab753fb392a67c95953ca0032909e797e8283b57a87a7c53ad38bdc90a0cb26',2005,'HT','Haiti','people-and-society',308,'$12.05 billion (2004 est.)
2.26% (2005 est.)
Holy See (Vatican City)
0.01% (2005 est.)
-3.5% (2004 est.)
purchasing power parity - $1,500 (2004 est.)
chief of mission: Ambassador James B. FOLEY
embassy: 5 Harry S Truman Boulevard, Port-au-Prince
mailing address: P. O. Box 1761, Port-au-Prince
telephone: [509] 222-0354, 222-0269, 222-0200, 222-0327
FAX: [509] 223-1641 or 222-0200 ext 460','53a1bc3ff9ac4a7dfce3eb442c8a44b8d8f1d77177368b37ea92ec4e4af9b4e2','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c131c419da53a3fc6934b42855c71e4e296413416d40f3f7f0f8ffeb4788bcd',2005,'HN','Honduras','people-and-society',309,'$18.79 billion (2004 est.)
2.16% (2005 est.)
4.2% (2004 est.)
purchasing power parity - $2,800 (2004 est.)
chief of mission: Ambassador Larry Leon PALMER
embassy: Avenida La Paz, Apartado Postal No. 3453, Tegucigalpa
mailing address: American Embassy, APO AA 34022, Tegucigalpa
telephone: [504] 238-5114, 236-9320
FAX: [504] 236-9037','124c35ebe4a00a5befe3a2cb953a14b30911cc87c909cef8d602a0471de2ad79','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5db7dc06512051a095012205f1ad2edc59249617c39f5b273335859a6d17cd16',2005,'HK','Hong Kong','people-and-society',310,'$234.5 billion (2004 est.)
0.65% (2005 est.)
7.9% (2004 est.)
purchasing power parity - $34,200 (2004 est.)
special administrative region of China
Howland Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
Jan Mayen
territory of Norway; since August 1994, administered from
Oslo through the county governor (fylkesmann) of Nordland; however,
authority has been delegated to a station commander of the Norwegian
Defense Communication Service
Jarvis Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
chief of mission: Consul General James B. CUNNINGHAM
consulate(s) general: 26 Garden Road, Hong Kong
mailing address: PSC 461, Box 1, FPO AP 96521-0006
telephone: [852] 2523-9011
FAX: [852] 2524-0860','bcd4ef1ef687e5f71df86d201139772f2d27d8ff4fc4b2d0f1585dbe0283b6dd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80fac66dc8a29fa9b37dde170fcafc27343aa63d25ee416c63514b07aed37857',2005,'HU','Hungary','people-and-society',311,'$149.3 billion (2004 est.)
-0.26% (2005 est.)
3.9% (2004 est.)
purchasing power parity - $14,900 (2004 est.)
chief of mission: Ambassador George Herbert WALKER
embassy: Szabadsag ter 12, H-1054 Budapest
mailing address: pouch: American Embassy Budapest, 5270 Budapest
Place, Department of State, Washington, DC 20521-5270
telephone: [36] (1) 475-4400
FAX: [36] (1) 475-4764','0fe4e611132f17d5fcaa37e90f9ceebb7a952d24feb1c488193d7f1c6fa84bd4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b57a45fa7cd3840f04216a1a7ce1a9a581cb0ace14af03b8c8b3104cb796353a',2005,'IS','Iceland','people-and-society',312,'$9.373 billion (2004 est.)
0.91% (2005 est.)
1.8% (2004 est.)
purchasing power parity - $31,900 (2004 est.)
chief of mission: Ambassador James I. GADSDEN
embassy: Laufasvegur 21, 101 Reykjavik
mailing address: US Embassy, PSC 1003, Box 40, FPO AE 09728-0340
telephone: [354] 562-9100
FAX: [354] 562-9118','3f3470363bf9bb8b4fb5bf3aa79d1120b1f97d529d6eace410a4e100f27dd964','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57ae40cb06fb3bb2721d8e855644e98b1656764ef241daa5800c79e50a06ad49',2005,'IN','India','people-and-society',313,'$3.319 trillion (2004 est.)
1.4% (2005 est.)
6.2% (2004 est.)
purchasing power parity - $3,100 (2004 est.)
chief of mission: Ambassador David C. MULFORD
embassy: Shantipath, Chanakyapuri, New Delhi 110021
mailing address: use embassy street address
telephone: [91] (11) 2419-8000
FAX: [91] (11) 2419-0017
consulate(s) general: Chennai (Madras), Kolkata (Calcutta), Mumbai
(Bombay)','6cdd4d749cf0fd5e9f4c05e4007a7f70a971b16e02e53c8538c88a093c61c490','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db924f4d346ec4b91ae9e3b8015d2575126c712df9b981bbe095921b6405c56e',2005,'ID','Indonesia','people-and-society',314,'$827.4 billion (2004 est.)
Iran
$516.7 billion (2004 est.)
1.45% (2005 est.)
Iran
0.86% (2005 est.)
4.9% (2004 est.)
Iran
6.3% (2004 est.)
purchasing power parity - $3,500 (2004 est.)
Iran
purchasing power parity - $7,700 (2004 est.)
chief of mission: Ambassador B. Lynn PASCOE
embassy: Jalan 1 Medan Merdeka Selatan 3-5, Jakarta 10110
mailing address: Unit 8129, Box 1, FPO AP 96520
telephone: [62] (21) 3435-9000
FAX: [62] (21) 385-7189
consulate(s) general: Surabaya
Iran
none; note - protecting power in Iran is Switzerland','e8fab9a7cb34a4e3397df171a55e2b3b618906fa8527accf358e49cacb16a632','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5056ba0fa5ca4c5dfb5eab08b5e639f067aec561c0b36b03fa574f34fd4189ab',2005,'IQ','Iraq','people-and-society',315,'$54.4 billion (2004 est.)
2.7% (2005 est.)
52.3% (2004 est.)
purchasing power parity - $2,100 (2004 est.)
chief of mission: Ambassador (vacant); Charge d''Affaires James
F. JEFFREY
embassy: Baghdad
mailing address: APO AE 09316
telephone: 00-1-240-553-0584 ext. 4354; note - Consular Section
FAX: NA','47209cca86afab6e2d4a80130863f1e14c85cd669462e77b9844a0aa3f8b292a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d2c12884de0b2ffa8ee4d48dcfff95832458a7a69c7eded39f065358ec40337',2005,'IE','Ireland','people-and-society',316,'$126.4 billion (2004 est.)
1.16% (2005 est.)
5.1% (2004 est.)
purchasing power parity - $31,900 (2004 est.)
chief of mission: Ambassador James C. KENNY
embassy: 42 Elgin Road, Ballsbridge, Dublin 4
mailing address: use embassy street address
telephone: [353] (1) 668-8777
FAX: [353] (1) 668-9946','8dd89fbd3c2598862b5a6243885925ef06dfa9a1703f9170d1db33898af75a10','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a7fbfb1e2bca016f0fbe4c3d3e0d81038f832489f60871ab40b56585c717ccc',2005,'IL','Israel','people-and-society',317,'$129 billion (2004 est.)
1.2% (2005 est.)
3.9% (2004 est.)
purchasing power parity - $20,800 (2004 est.)
chief of mission: Ambassador Daniel C. KURTZER
embassy: 71 Hayarkon Street, Tel Aviv 63903
mailing address: PSC 98, Box 29, APO AE 09830
telephone: [972] (3) 519-7369/7453/7454/7457/7458/7551/7575
FAX: [972] (3) 516-4390
consulate(s) general: Jerusalem; note - an independent US mission,
established in 1928, whose members are not accredited to a foreign','506bd2677c8fef7da2ef1c04be8859b6dace1fa099d67d1fb752eebee2b9d69a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e10a75be0112a98bd9d4b48d234a289162b721a45cb559e3ca477e8b3db858da',2005,'IT','Italy','people-and-society',318,'$1.609 trillion (2004 est.)
0.07% (2005 est.)
1.3% (2004 est.)
purchasing power parity - $27,700 (2004 est.)','d00ce7b1d976a0594b87e44c5af1ee5582d516f884c89e6636c767acd7d592c0','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2597a15e23e98557cc563eb6a82d18f376694e1ddd6dc41902306f1f6c92e8ee',2005,'JM','Jamaica','people-and-society',319,'$11.13 billion (2004 est.)
0.71% (2005 est.)
1.9% (2004 est.)
purchasing power parity - $4,100 (2004 est.)','822ee14f356fd161d0a0ba5bb6e84c1c65e07c249c8eb2a32619f72600543b34','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a630310643505fd0eabad487be034533bab4212343282e66a49a8e9c66133643',2005,'JP','Japan','people-and-society',320,'$3.745 trillion (2004 est.)
0.05% (2005 est.)
2.9% (2004 est.)
purchasing power parity - $29,400 (2004 est.)','158e522a4366dd97322e843d9e176e3ca0c1a9a0b5b7e47271bcbc04f5bcecec','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deb41516520466decd92bc4c39253c8d1c483a160413ebebcdde83ffd2b46073',2005,'JE','Jersey','people-and-society',321,'$3.6 billion (2003 est.)
0.32% (2005 est.)
NA%
purchasing power parity - $40,000 (2003 est.)
British crown dependency
Johnston Atoll
unincorporated territory of the US; administered from
Honolulu, HI, by Pacific Air Forces, Hickam Air Force Base, and the
Fish and Wildlife Service of the US Department of the Interior as
part of the National Wildlife Refuge system
Juan de Nova Island
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands
Kingman Reef
unincorporated territory of the US; administered from
Washington, DC, by the US Fish and Wildlife Service of the
Department of the Interior
note: on 1 September 2000, the Department of the Interior accepted
restoration of its administrative jurisdiction over Kingman Reef
from the Department of the Navy; Executive Order 3223 signed 18
January 2001 established Kingman Reef National Wildlife Refuge to be
administered by the Director, US Fish and Wildlife Service; this
refuge is managed to protect the terrestrial and aquatic wildlife of
Kingman Reef out to the 12-nautical-mile territorial sea limit
Macau
special administrative region of China
Man, Isle of
British crown dependency','8845b75f297e0353b6803766bb16e402ce32c6fe06c05e4afe7cd80cfaed5865','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('949ea3f6ae3100ae1c568141c08ddbf753e18c08d766ce436d201d222d33239e',2005,'JO','Jordan','people-and-society',322,'$25.5 billion (2004 est.)
2.56% (2005 est.)
5.1% (2004 est.)
purchasing power parity - $4,500 (2004 est.)','30774b005cbb8159965359d915d5d7ff9ea85779576309dcbcafcbe24bfdf3e6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d65a18e218a186b41851495d6cc51b8f66f58b048ce8114fd6e230454fa59ea',2005,'KZ','Kazakhstan','people-and-society',323,'$118.4 billion (2004 est.)
0.3% (2005 est.)
9.1% (2004 est.)
purchasing power parity - $7,800 (2004 est.)','d5abd25d40156429717b3e8b76f7476eafd3014e59c10b873acab594adc6d489','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7d06fafb4b9f081d60cc5869b8b544e78f31f416e6e7464f68ea0f429d7720f',2005,'KE','Kenya','people-and-society',324,'$34.68 billion (2004 est.)
2.56% (2005 est.)
2.2% (2004 est.)
purchasing power parity - $1,100 (2004 est.)','b90cc82f2e14d86c8aacf2121a41cd9a9f705b2c96e2cf7b8bfb9decbd8faa15','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d8883458a2015f1e241a46d5203f5b2cc00384c4aab2b135bcd591c12d443e0',2005,'KI','Kiribati','people-and-society',325,'$79 million - supplemented by a nearly equal amount from
external sources (2001 est.)
Korea, North
$40 billion (2004 est.)
Korea, South
$925.1 billion (2004 est.)
2.25% (2005 est.)
Korea, North
0.9% (2005 est.)
Korea, South
0.38% (2005 est.)
1.5% (2001 est.)
Korea, North
1% (2004 est.)
Korea, South
4.6% (2004 est.)
purchasing power parity - $800 (2001 est.)
Korea, North
purchasing power parity - $1,700 (2004 est.)
Korea, South
purchasing power parity - $19,200 (2004 est.)','ff82fa183c228f4626fd7d594b6816a6f7d4f12f740656698bda98ab12a3884c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('798e3a5634f6c0d60172b19ad9792edf063f4aaae89a5fc360fbb46bdef916e0',2005,'KW','Kuwait','people-and-society',326,'$48 billion (2004 est.)
3.44%
note: this rate reflects a return to pre-Gulf crisis immigration of
expatriates (2005 est.)
6.8% (2004 est.)
purchasing power parity - $21,300 (2004 est.)','dd08b85f8f18c8d27482860f9e7b96d86f70a9890627f18d7762802be73a9d69','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('234a69e34c363d7113136c8c2e7c51347ec44956ca5f9d95ec16e1f5fbe5085e',2005,'KG','Kyrgyzstan','people-and-society',327,'$8.495 billion (2004 est.)
Laos
$11.28 billion (2004 est.)
1.29% (2005 est.)
Laos
2.42% (2005 est.)
6% (2004 est.)
Laos
6% (2004 est.)
purchasing power parity - $1,700 (2004 est.)
Laos
purchasing power parity - $1,900 (2004 est.)','638c4a6abc2bb9a3c165c3a0f3e369620379be82caed044d287a057d01fbf591','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b14c4de377afcaa19775a19c6895399c8f4ae06ec8dcd07a7dc7231e1c6ca060',2005,'LV','Latvia','people-and-society',328,'$26.53 billion (2004 est.)
-0.69% (2005 est.)
7.6% (2004 est.)
purchasing power parity - $11,500 (2004 est.)','6341824bbd50ca528f346c667f3cfc19fc9b1ecd5a301906fb1905cd2c6bf7f2','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bea29caf6f9216f18e11e795cff7cb397b8ecbaa353959b3d86c366d44f3313e',2005,'LB','Lebanon','people-and-society',329,'$18.83 billion (2004 est.)
1.26% (2005 est.)
4% (2004 est.)
purchasing power parity - $5,000 (2004 est.)','d2c14402aa2d6df34c645745a417e4fd7246d73480c75e667d2b2d941766cbf8','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ef8f078c5914fab137518936c593f8e8a3c76da7c06d78e1633c4caf9e84d60',2005,'LS','Lesotho','people-and-society',330,'$5.892 billion (2004 est.)
0.08% (2005 est.)
3.3% (2004 est.)
purchasing power parity - $3,200 (2004 est.)','3cc18c1544f2515ae8f6da88d2938e1af7d08c002f68c4fce971cff9b59d7f04','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe6ed812979807823b485659e2a9ce844b6d8d1748f8837385dde31154e43d32',2005,'LR','Liberia','people-and-society',331,'$2.903 billion (2004 est.)
2.64% (2005 est.)
21.8% (2004 est.)
purchasing power parity - $900 (2004 est.)','0487a87061bb499396cc76a8990006775ff6e3cb617ac7c712cd25395f11479d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4f32f584ed638051a3f6e1ed635a78e433cdb2c99275913504b08d65b79e5a2',2005,'LY','Libya','people-and-society',332,'$37.48 billion (2004 est.)
2.33% (2005 est.)
4.9% (2004 est.)
purchasing power parity - $6,700 (2004 est.)','78d11b3b610b2eef2205d6496773bc8dc05d4db45dadf28e1b71f63c4563ebc3','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a4911745cb24818e05b4525a3fe6733e33b0bb6b66a959c480bc894788adcfd',2005,'LI','Liechtenstein','people-and-society',333,'$825 million (1999 est.)
0.82% (2005 est.)
11% (1999 est.)
purchasing power parity - $25,000 (1999 est.)','ebdebac0c50ecb2dd217a62dbc243d28d7a13e8dce75a11ac8f34905f9a6808a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7a8fc9c1b92106bf862d04704e5ad9d3b81dc0ad4053364a6a7ee3f47fce5ce',2005,'LT','Lithuania','people-and-society',334,'$45.23 billion (2004 est.)
-0.3% (2005 est.)
6.6% (2004 est.)
purchasing power parity - $12,500 (2004 est.)','7019dc920d46687c027982dbc18e9e6a832a6b7a6ed0bd91e3ff6075df1ecafa','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5427874a2d49d1269bd130839787fa8d459c2377ab0a87d1fe4dc6f9d8633140',2005,'LU','Luxembourg','people-and-society',335,'$27.27 billion (2004 est.)
Macau
$9.1 billion (2003)
Macedonia
$14.4 billion (2004 est.)
1.25% (2005 est.)
Macau
0.87% (2005 est.)
Macedonia
0.26% (2005 est.)
2.3% (2004 est.)
Macau
15.6% (2003)
Macedonia
1.3% (2004 est.)
purchasing power parity - $58,900 (2004 est.)
Macau
purchasing power parity - $19,400 (2003)
Macedonia
purchasing power parity - $7,100 (2004 est.)','d2ad7b0a8890792e9d792b221c27d9770ee6c0547fa221db11a0e87dcac342a9','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0075e4fa08620dc9a5ba15400e80b5e40c9fac0e7a6e5b8cf590ee307650740e',2005,'MG','Madagascar','people-and-society',336,'$14.56 billion (2004 est.)
3.03% (2005 est.)
5.5% (2004 est.)
purchasing power parity - $800 (2004 est.)','1bebd016f80d7936dce4a677924b53ee6413c1f7453bd9f4ccccff3b098f2cee','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2822d9afebd91ac9653056946f986868581ca2af59b96477828448facb3697d',2005,'MW','Malawi','people-and-society',337,'$7.41 billion (2004 est.)
2.06% (2005 est.)
4% (2004 est.)
purchasing power parity - $600 (2004 est.)','7b1e17de81deb3261d7893e718505a51e7e15a079ee9fa49d17ee1cc16b6cdcf','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea2ce01f63d4944a338f15c4dd899fd9da7b4adf968ec21567b808fe75e0d444',2005,'MY','Malaysia','people-and-society',338,'$229.3 billion (2004 est.)
1.8% (2005 est.)
7.1% (2004 est.)
purchasing power parity - $9,700 (2004 est.)','97368d1693fb34cc7bbd8adf46705ce7a8a14b45f186f5bbfbb25453ea12a3a6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c50dd1c673d1c38a4fdfaecfc5896b8cd8dda8d562714f63454c50db5b429ac9',2005,'MV','Maldives','people-and-society',339,'$1.25 billion (2002 est.)
2.82% (2005 est.)
2.3% (2002 est.)
purchasing power parity - $3,900 (2002 est.)','653fc7ff78edc65684a038bc70c90d3adf00b1f7f7d4a2fa16c46295ac964975','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5529fa1bfb2851a55a36870a08b0a9f824ed941fb0ac10f8eb569af79ea33f0c',2005,'ML','Mali','people-and-society',340,'$11 billion (2004 est.)
2.74% (2005 est.)
4% (2004 est.)
purchasing power parity - $900 (2004 est.)','efd29c5d32c32c59968821bed9e92fdf5f95745d19adb579f1bb66390b5a79cb','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aeaf9a10af48d30d421530b741bcb69eea6090252e6f8c7e76882bd6e137424f',2005,'MT','Malta','people-and-society',341,'$7.223 billion (2004 est.)
Man, Isle of
$2.113 billion (2003 est.)
0.42% (2005 est.)
Man, Isle of
0.52% (2005 est.)
1% (2004 est.)
Man, Isle of
NA%
purchasing power parity - $18,200 (2004 est.)
Man, Isle of
purchasing power parity - $28,500 (2003 est.)','d4695b6ab38e5ad06a2bcff69aabe25fd7f89c16344433acc179c28c18919b6f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a176a077a5c302760da6e34c9b65eb34894d743c1b4c760ac5c7068edbf55b6',2005,'MH','Marshall Islands','people-and-society',342,'$115 million (2001 est.)
2.27% (2005 est.)
1% (2001 est.)
purchasing power parity - $1,600 (2001 est.)','b0f74de3716c686dc5862aa556762138d6aadbd8e2dd1517780c1a10bc13f7a5','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55da5993348e1c4207b067fa69cd47620fb8254f79b7c3ab85ce2b3c0bb4e086',2005,'MQ','Martinique','people-and-society',343,'$6.117 billion (2003 est.)
0.76% (2005 est.)
NA%
purchasing power parity - $14,400 (2003 est.)
overseas department of France','72540df3b78d00b9e18abf45383a68c0aa53000677ca7a529784ba23f0d53650','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab51fd1c0cacf01b9ec842c931fca135a3401555fdd5b53c76530f2e96a5aff0',2005,'MR','Mauritania','people-and-society',344,'$5.534 billion (2004 est.)
2.9% (2005 est.)
3% (2004 est.)
purchasing power parity - $1,800 (2004 est.)','6f6107e9f47187582acc1cae5119d69a0e5b058df48e6b36f63434743d8ff1cd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d753bd1d9c5b4691667721022a9c80505ea212db95ed1cf44b6656102f8c233b',2005,'MU','Mauritius','people-and-society',345,'$15.68 billion (2004 est.)
0.84% (2005 est.)
4.7% (2004 est.)
purchasing power parity - $12,800 (2004 est.)','8d00be515818b595fa5df8adef90c788c5f90769a75fda6027030ad3115c560e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fa17001ecd8c5729b65eb20c55395519d4382ac5b2c08d0d850ec810e6c56f8',2005,'YT','Mayotte','people-and-society',346,'$466.8 million (2003 est.)
3.93% (2005 est.)
NA%
purchasing power parity - $2,600 (2003 est.)
territorial collectivity of France
Midway Islands
unincorporated territory of the US; formerly
administered from Washington, DC, by the US Navy; on 31 October
1996, through a presidential executive order, the jurisdiction and
control of the atoll was transferred to the Fish and Wildlife
Service of the US Department of the Interior as part of the National
Wildlife Refuge system','e90b932102008cdd102d81aba7aa17cbf3b59f85a8d11ca4c698a85c2b26f110','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('465d16b29496e2790cd792a00e896a017ff2973e16c592891091d9e508993040',2005,'MX','Mexico','people-and-society',347,'$1.006 trillion (2004 est.)
1.17% (2005 est.)
4.1% (2004 est.)
purchasing power parity - $9,600 (2004 est.)','cb2479b25b32e256a5901f961d033962a8228a7134ef04b3caa181283e9b9825','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b71ddc2dc1ae67dce765696624dc915593d532be49847edb1bfaceeae04e721',2005,'FM','Micronesia, Federated States of','people-and-society',348,'$277 million
note: GDP is supplemented by grant aid, averaging perhaps $100
million annually (2002 est.)
Moldova
$8.581 billion (2004 est.)
-0.08% (2005 est.)
Moldova
0.22% (2005 est.)
1% (2002 est.)
Moldova
6.8% (2004 est.)
purchasing power parity - $2,000
(2002 est.)
Moldova
purchasing power parity - $1,900 (2004 est.)','2b3a7ca91d399f122c36151c49302151caceb0e7b8bff473b60de6dac78f22d9','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bc2284668c363234d85d1c19cdb30b2ee3613eb83b4966c201dff320089cda0',2005,'MC','Monaco','people-and-society',349,'$870 million (2000 est.)
0.43% (2005 est.)
0.9% (2000 est.)
purchasing power parity - $27,000 (2000 est.)','52ba3a2c5f18bcf85bf745c4aef45183ad932c2bd25ad3b220af3c737e1c5018','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d1b7a940c218fb09ebcdda2bad134298c14e64fd406d68c475e14e055a11a05',2005,'MN','Mongolia','people-and-society',350,'$5.332 billion (2004 est.)
1.45% (2005 est.)
10.6% according to official estimate (2004 est.)
purchasing power parity - $1,900 (2004 est.)','eace53997018f06d263831325f43e88e87a09fa2b5d711c1a847a4e8b71cbee2','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7a348885f5fbeab943bdc2dbb10ef2c6959b224b91b7fcabbebc107df3d787a',2005,'MS','Montserrat','people-and-society',351,'$29 million (2002 est.)
1.04% (2005 est.)
-1% (2002 est.)
purchasing power parity - $3,400 (2002 est.)
overseas territory of the UK
Navassa Island
unincorporated territory of the US; administered by
the Fish and Wildlife Service, US Department of the Interior, from
the Caribbean Islands National Wildlife Refuge in Boqueron, Puerto
Rico; in September 1996, the Coast Guard ceased operations and
maintenance of Navassa Island Light, a 46-meter-tall lighthouse on
the southern side of the island; there has also been a private claim
advanced against the island
Netherlands Antilles
an autonomous country within the Kingdom of the
Netherlands; full autonomy in internal affairs granted in 1954;
Dutch Government responsible for defense and foreign affairs','6366b6d96eb53fdd118160f7fc137626ae9296e033cbc4dbb44ccbb77aa2e11d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff594c7bc50cee1db9d1b57a3810f1211912f72e7f4e2f394d0950660a767315',2005,'MA','Morocco','people-and-society',352,'$134.6 billion (2004 est.)
1.57% (2005 est.)
4.4% (2004 est.)
purchasing power parity - $4,200 (2004 est.)','b1b47c0393d410c688c6ccfe681ccb6186158fbd751c2d5cf65872bd0170e62c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcd97c4c452da06b3de08b73b15386baaff9538650223408d797262288b6bc6a',2005,'MZ','Mozambique','people-and-society',353,'$23.38 billion (2004 est.)
1.48% (2005 est.)
8.2% (2004 est.)
purchasing power parity - $1,200 (2004 est.)','84ce34c6322af6c8a580f1ed6c58d8a49e82c474d3bbc96c08938865eff93bfc','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e00c8af346435c871a70db8a605546239820809ed4aa7ef01cf0af561bd2f223',2005,'NA','Namibia','people-and-society',354,'$14.76 billion (2004 est.)
0.73% (2005 est.)
4.8% (2004 est.)
purchasing power parity - $7,300 (2004 est.)','321864ecf2664cd67cefd793b75f9d5f1eaa9a9808cfe46f8489b0a548553029','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f78e7ef2c84c5ed8e28211a3f8e1d2dc00e3b9e151172c21ace9f64fabacd1ba',2005,'NR','Nauru','people-and-society',355,'$60 million (2001 est.)
1.83% (2005 est.)
NA
purchasing power parity - $5,000 (2001 est.)','e091309969bf0745d990e25304c9d4188abc114d1f87b0fdbcdbfe5d1ff858ab','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18efb8b4aed3ef0863029c191b0ec087ac9248a7d2bb22ee799a8ea5859602f4',2005,'NP','Nepal','people-and-society',356,'$39.53 billion (2004 est.)
2.2% (2005 est.)
3% (2004 est.)
purchasing power parity - $1,500 (2004 est.)','b41044bff3933d9e2e296fdf13d2448795ba199f7747461ed1e5f456d7d3e47c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e848bd7fb7123184ef67160f4a7d41bce164733b0b70c18f8bdd70ec4c157a26',2005,'NL','Netherlands','people-and-society',357,'$481.1 billion (2004 est.)
Netherlands Antilles
$2.45 billion (2003 est.)
0.53% (2005 est.)
Netherlands Antilles
0.82% (2005 est.)
1.2% (2004 est.)
Netherlands Antilles
0.5% (2003 est.)
purchasing power parity - $29,500 (2004 est.)
Netherlands Antilles
purchasing power parity - $11,400 (2003 est.)','566e9939874c55528962941cc919d636cad15fcc123e76fb5f6a6f539783813c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4612909fa47de0c6845481e7288d695305410eb8acac15499313c563d8e15aaf',2005,'NC','New Caledonia','people-and-society',358,'$3.158 billion (2003 est.)
1.28% (2005 est.)
NA%
purchasing power parity - $15,000 (2003 est.)
overseas territory of France since 1956','6cbdf21f529c97614e4f9163dd245e43dc814411f307fabb28b140ca79ae3b6e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d91257b69e8d8785f3804f75d0fd0c35915a1b94f47ac1c142dcc4a5de58d1f',2005,'NZ','New Zealand','people-and-society',359,'$92.51 billion (2004 est.)
1.02% (2005 est.)
4.8% (2004 est.)
purchasing power parity - $23,200 (2004 est.)','c275aec67cb92ab4585cb608fc85f030136d6f71692509bb397bc81aa42daa70','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31a18c67af07cf2d8be35bbe7365ebddca81020426403e1b3bf97f22a252e024',2005,'NI','Nicaragua','people-and-society',360,'$12.34 billion (2004 est.)
1.92% (2005 est.)
4% (2004 est.)
purchasing power parity - $2,300 (2004 est.)','b3785f17b074f74c23570d175524b19f4c252b54ca35430018b759a14018d2f1','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a5248c06ae567a12cdd488b2822963a7e8c4eda81b2923f6fbabea0e4bdbb15',2005,'NE','Niger','people-and-society',361,'$9.716 billion (2004 est.)
2.63% (2005 est.)
3.5% (2004 est.)
purchasing power parity - $900 (2004 est.)','c3b4639ad1b9f9f6107fa623a1c32560d2edd8ab58f3afb8a35c36457a2d3054','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df88701d0234827414d691db0fae4e0ec3b7d16d8d0548b96782a9d52a11b67c',2005,'NG','Nigeria','people-and-society',362,'$125.7 billion (2004 est.)
2.37% (2005 est.)
6.2% (2004 est.)
purchasing power parity - $1,000 (2004 est.)','6238c97078e02e5568bf7e6aff6b2770bd771b2a298b6e37eced3294c3891acd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('808bbbdbb75d2be3cd04b8a1cbae1fed838642963e785f32c20a2d66ab248675',2005,'NU','Niue','people-and-society',363,'$7.6 million (2000 est.)
0% (2005 est.)
-0.3% (2000 est.)
purchasing power parity - $3,600 (2000 est.)
self-governing in free association with New Zealand since 1974;
Niue fully responsible for internal affairs; New Zealand retains
responsibility for external affairs and defense; however, these
responsibilities confer no rights of control and are only exercised
at the request of the Government of Niue','459955fc030f5b3ba018eb1d76f8736f194769714db642b83250e32d42755f76','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbcdea1931fe0c43833300fd50c9e007ddc83825d431416338529a51a87a09de',2005,'NF','Norfolk Island','people-and-society',364,'NA
-0.01% (2005 est.)
NA
purchasing power parity - NA
territory of Australia; Canberra administers
Commonwealth responsibilities on Norfolk Island through the
Department of Environment, Sport, and Territories','ecf3bdf2dec4e0b82134bad74385ad647efdb554b3c66448eff1c414733d4ef4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('256bc7033be655b9756d4e5b7db17086b3c0830a873962980af3b7cc22761f7e',2005,'MP','Northern Mariana Islands','people-and-society',365,'$900 million
note: GDP estimate includes US subsidy (2000 est.)
2.61% (2005 est.)
NA
purchasing power parity - $12,500 (2000
est.)
commonwealth in political union with the
US; federal funds to the Commonwealth administered by the US
Department of the Interior, Office of Insular Affairs
Palmyra Atoll
incorporated territory of the US; privately owned, but
administered from Washington, DC, by the Fish and Wildlife Service
of the US Department of the Interior; the Office of Insular Affairs
of the US Department of the Interior continues to administer nine
excluded areas comprising certain tidal and submerged lands within
the 12 nm territorial sea or within the lagoon
Pitcairn Islands
overseas territory of the UK','9db2778bb07535fbe30d50688224769e0e4a1d5e530ae81bc2040c3c8a3ff6b5','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f70fdb4e26128d9d0769160b7b51a04e70884e56ff05a3a7c6dcc3fe6458adcd',2005,'NO','Norway','people-and-society',366,'$183 billion (2004 est.)
0.4% (2005 est.)
3.3% (2004 est.)
purchasing power parity - $40,000 (2004 est.)','3d8cc957baf58f3c3a8b8a54e2c25aee6e1bbb06bb18d3d31476c19ff9fd4238','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50fb379a6e3ba4aa9ca3826077e78786846ec408b05ad8e5073cb2443279b106',2005,'OM','Oman','people-and-society',367,'$38.09 billion (2004 est.)
3.32% (2005 est.)
1.2% (2004 est.)
purchasing power parity - $13,100 (2004 est.)','5d00e38ef55720ba189c08ee3ced3b43665a8350c8b6706b5a5f466b0db12c44','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb6f95ac5da0d0266c97fffe29e017222dce82978d4751bf269254360eaa4e9d',2005,'PK','Pakistan','people-and-society',368,'$347.3 billion (2004 est.)
2.03% (2005 est.)
6.1% (2004 est.)
purchasing power parity - $2,200 (2004 est.)','d26e488f153cb1c99d57a1814dd322f099c3c0af9a3872d2fea0ffba50f709d1','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00ba37da88b124426436b20096e0cdc085e4b14688db2d4de23e518ea9d4e73b',2005,'PW','Palau','people-and-society',369,'$174 million
note: GDP estimate includes US subsidy (2001 est.)
1.39% (2005 est.)
1% (2001 est.)
purchasing power parity - $9,000 (2001 est.)','6743bb926f1d1e04cf66ef667899a892bc2fe452c1200a25dd7edc60cf818107','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6de022d2bccbd86b0c1e199e10204a94e6a4bc6a90ffee9f2566a6c17fce9ae',2005,'PA','Panama','people-and-society',370,'$20.57 billion (2004 est.)
1.26% (2005 est.)
6% (2004 est.)
purchasing power parity - $6,900 (2004 est.)','ea51d77fb5d3c8c570026bd6013dd2744b71496fda6cfbffe06746b75025e79d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11ce21d9f920375c2e6a88aa7632eec016336a0d0b6cefcf994c0646e9cb0ee0',2005,'PG','Papua New Guinea','people-and-society',371,'$11.99 billion (2004 est.)
2.26% (2005 est.)
0.9% (2004 est.)
purchasing power parity - $2,200 (2004 est.)','80f721546f21c2a134c3b1c4369fca40ccb24775f145bea3b05b751e40041dd0','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6af2e87fd8e05edb74905973d20cfe6b21b88f2b10cce7c817360bf219333693',2005,'PY','Paraguay','people-and-society',372,'$29.93 billion (2004 est.)
2.48% (2005 est.)
2.8% (2004 est.)
purchasing power parity - $4,800 (2004 est.)','b7c8788b796390ac4185675525ac3f8a1e503adc0fbff49245a0678975650084','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3655ac0e2c527b5b76209964a63a6a35f7f549d58dbeeb475b564addcc46e9fa',2005,'PE','Peru','people-and-society',373,'$155.3 billion (2004 est.)
1.36% (2005 est.)
4.5% (2004 est.)
purchasing power parity - $5,600 (2004 est.)','1deb64ab8ccf45abdb68309d9cea88d6e9e2e0032f5e02ce082a249e66925dff','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23eed5df5c8bbd5eb9c565d4e1e96b30c01d955a9706b5094bb048e5b9aaf0c8',2005,'PH','Philippines','people-and-society',374,'$430.6 billion (2004 est.)
Pitcairn Islands
NA
1.84% (2005 est.)
Pitcairn Islands
-0.01% (2005 est.)
5.9% (2004 est.)
Pitcairn Islands
NA
purchasing power parity - $5,000 (2004 est.)
Pitcairn Islands
purchasing power parity - NA','6532f46bc22a148aba64a12ff93028db04634379a68766dd08237a5e769fdcda','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9614de59bffc74f8019327409049fe71440a4e231c24dd9cedb5c9dbfc6f1f4',2005,'PL','Poland','people-and-society',375,'$463 billion (2004 est.)
0.03% (2005 est.)
5.6% (2004 est.)
purchasing power parity - $12,000 (2004 est.)','76ba274208662398362c169e6d2d789ff32f9f6195c11a743688e1dec1e50e0c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eedd1078f0c98455517e7cdabaa43476611deea19f58dfbce47a8385aba7d4c',2005,'PT','Portugal','people-and-society',376,'$188.7 billion (2004 est.)
0.39% (2005 est.)
1.1% (2004 est.)
purchasing power parity - $17,900 (2004 est.)','5b0d7f2f565ad729ac02ba916b31ae91e7e0c21a1158a34b8af514897ed566fa','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e76e479034561ba114a339c2c4f1c22121c44cc5308989a1efb66efda2cb31f',2005,'PR','Puerto Rico','people-and-society',377,'$68.95 billion (2004 est.)
0.47% (2005 est.)
2.7% (2004 est.)
purchasing power parity - $17,700 (2004 est.)
commonwealth associated with the US
Reunion
overseas department of France
Saint Helena
overseas territory of the UK','07034964e8e7d25584fc0e5d753c724f635efc8cca64bc25c6ddea444b715ba4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44e2f02441e38add052395307faaa00478940c5e17c200d2944b9611815984fa',2005,'QA','Qatar','people-and-society',378,'$19.49 billion (2004 est.)
Reunion
$4.57 billion (2004 est.)
2.61% (2005 est.)
Reunion
1.38% (2005 est.)
8.7% (2004 est.)
Reunion
2.5% (2004 est.)
purchasing power parity - $23,200 (2004 est.)
Reunion
purchasing power parity - $6,000 (2004 est.)','84d737117606e15da8ecf7cf51867657ed47d2840a85ece5874a9b678197f132','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('219e4e3496214cd670704f7eaeae219e51544d43f4522ae14cb9d72c97a527cd',2005,'RO','Romania','people-and-society',379,'$171.5 billion (2004 est.)
Russia
$1.408 trillion (2004 est.)
-0.12% (2005 est.)
Russia
-0.37% (2005 est.)
8.1% (2004 est.)
Russia
6.7% (2004 est.)
purchasing power parity - $7,700 (2004 est.)
Russia
purchasing power parity - $9,800 (2004 est.)','029f8536333df692f1f28987a31d9c6b147ef49edc5ab4db504fcd7b80899479','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17052f9a2e8be6380250c5add067c87515b59a545e3a9e18c9844275bf707d46',2005,'RW','Rwanda','people-and-society',380,'$10.43 billion (2004 est.)
Saint Helena
$18 million (1998 est.)
2.43% (2005 est.)
Saint Helena
0.59% (2005 est.)
0.9% (2004 est.)
Saint Helena
NA
purchasing power parity - $1,300 (2004 est.)
Saint Helena
purchasing power parity - $2,500 (1998 est.)','6afb157b3735dc01e28fb19a136ff4266a30ab8b1ffa1ec730db254ec7ef00d8','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98b3bc5bf5d9464c3425cf1a64e2bc2e9dcf100d0e324246beec4e34333656d0',2005,'KN','Saint Kitts and Nevis','people-and-society',381,'$339 million (2002 est.)
0.38% (2005 est.)
-1.9% (2002 est.)
purchasing power parity - $8,800 (2002 est.)','2dc5f7e87850cc88894090f6b9ae52eec96dc02e4708bd5c2c0d777a2b71c09d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bca3e0f6d8869354930d9c2f7690c97888b811115a8afff965c0705847a76f39',2005,'LC','Saint Lucia','people-and-society',382,'$866 million (2002 est.)
1.28% (2005 est.)
3.3% (2002 est.)
purchasing power parity - $5,400 (2002 est.)','1ed31009173cd56485e9a6e0033c3a448e4ad7aa9e9dc7f5dd83407b02c65437','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed6fa743fa63c955d930a41519006d83b6a3cda743b7454b9506ee13d9b30dac',2005,'PM','Saint Pierre and Miquelon','people-and-society',383,'$48.3 million - supplemented by annual
payments from France of about $60 million (2003 est.)
0.21% (2005 est.)
NA%
purchasing power parity - $7,000 (2001
est.)
self-governing territorial collectivity of','033f3ecaae3609e3d6ded83f23405da00c0ec210d212d58f4716c277069464a1','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12354dc4e40f59e0abeaf646bdb00e5c890c037d390f2f624b7ebe734a7e7c92',2005,'VC','Saint Vincent and the Grenadines','people-and-society',384,'$342 million (2002 est.)
0.27% (2005 est.)
0.7% (2002 est.)
purchasing power parity - $2,900
(2002 est.)','2d79d38323e42a2b3eec7442f8fe56c698d1ade4a8f9a079c26162bd8f45653e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01467406f893b90ead78052ccefb5ac19f5ac718f77b7f3b43de3ee3243199b2',2005,'WS','Samoa','people-and-society',385,'$1 billion (2002 est.)
-0.23% (2005 est.)
5% (2002 est.)
purchasing power parity - $5,600 (2002 est.)','492ca387836968846c7852b2b061bb768d6fcf76f437fff0cdfa6859d7b31938','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94a695643776d43a60359e2a1ac27c439c9a9c688d258ebe2506b61d8530ed34',2005,'SM','San Marino','people-and-society',386,'$940 million (2001 est.)
1.3% (2005 est.)
7.5% (2001 est.)
purchasing power parity - $34,600 (2001 est.)','47e18e40d30058d27980fdf9538cfd386f1652393d44618130e2c148bf235929','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1471d3ab579a1c3de4f79f079496340113346682ebb08008e285a278ce8aa50',2005,'ST','Sao Tome and Principe','people-and-society',387,'$214 million (2003 est.)
3.16% (2005 est.)
6% (2004 est.)
purchasing power parity - $1,200 (2003 est.)','6249f57d9f68990df1948819378045861a8f88de18408b8d58314c368e4cac5e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0aef0d36a3135579a8881041729546c8c280ac110a8f291ae0625fbbcc26c780',2005,'SA','Saudi Arabia','people-and-society',388,'$310.2 billion (2004 est.)
2.31% (2005 est.)
5% (2004 est.)
purchasing power parity - $12,000 (2004 est.)','30e8c5198db874ad1c0553da23e7ed1de9a4b12d95539ca71f78b6da90b8b947','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1c80aa7fcfaaf94b96c2f370cd8e2f726cf7cc50cb3093cd25f696c4ca4b3d9',2005,'SN','Senegal','people-and-society',389,'$18.36 billion (2004 est.)
Serbia and Montenegro
$26.27 billion (2004 est.)
2.48% (2005 est.)
Serbia and Montenegro
0.03% (2005 est.)
3.2% (2004 est.)
Serbia and Montenegro
6.5% (2004 est.)
purchasing power parity - $1,700 (2004 est.)
Serbia and Montenegro
purchasing power parity - $2,400 (2004 est.)','6e102fd66c6207962d292aa8e19bfb6a6a45c7076edc1d3c3ea204bab190930e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bd84be9a226f97a70da436ccbabf7a14ee5aa5c4271b8347c0ce0eb99514e3c',2005,'SC','Seychelles','people-and-society',390,'$626 million (2002 est.)
0.43% (2005 est.)
1.5% (2004 est.)
purchasing power parity - $7,800 (2002 est.)','03cfae4add20045d7a7a794c9106889094e9dfe1dc6d22a376e3f9858bc0f4a7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6f1e72466fa2093d0c23a52b258bb921a6bb04c3bc78f122d2bb9fd447d2389',2005,'SL','Sierra Leone','people-and-society',391,'$3.335 billion (2004 est.)
2.22% (2005 est.)
6% (2004 est.)
purchasing power parity - $600 (2004 est.)','15c1d39e9ee0186c99742b2e8e279f03fc1937fcff72fc2088fab996082b7293','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88c20ae9fc9568a22699201a17fb1a31d971b2d039bc25480ecf0e40f5d95c50',2005,'SG','Singapore','people-and-society',392,'$120.9 billion (2004 est.)
1.56% (2005 est.)
8.1% (2004 est.)
purchasing power parity - $27,800 (2004 est.)','79511eb103848a248c29e40cfe06b9ce149f8b2e6696d230218f48ee58865d35','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6b69b997474b6416704649b25bebe17b679176d895ff99917341c0b510b7cb0',2005,'SK','Slovakia','people-and-society',393,'$78.89 billion (2004 est.)
0.15% (2005 est.)
5.3% (2004 est.)
purchasing power parity - $14,500 (2004 est.)','374da78bbb60d8ecaf80b3e0b1bb32ba2d989695cfe1c52a6b13fdd593657003','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3976ff6218615ad010032a298aba8bb2e12f62155ec55337ce0e6321856cbfd',2005,'SI','Slovenia','people-and-society',394,'$39.41 billion (2004 est.)
-0.03% (2005 est.)
3.9% (2004 est.)
purchasing power parity - $19,600 (2004 est.)','404d474bf44e28c4a55b366f0e86838df4ed686a9a171d7e643b212d8c3333e7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76a50f45fdb9e8b9990b6bc6545c47f0e23d6438c10fefb81df9dfaba163ff1d',2005,'SB','Solomon Islands','people-and-society',395,'$800 million (2002 est.)
2.68% (2005 est.)
5.8% (2003 est.)
purchasing power parity - $1,700 (2002 est.)','4422b0224ff6fd5cc8529b1a90b37d869813c9504050946bf8b1d7440c51ac71','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f972a4357bbda6aa2e0ead50b2fa2494612cc74d517bb1ff4f5c9fdea96e3d3b',2005,'SO','Somalia','people-and-society',396,'$4.597 billion (2004 est.)
3.38% (2005 est.)
2.8% (2004 est.)
purchasing power parity - $600 (2004 est.)','358f352b8ca58157581752b2aa54deddc9364c8ac9478f65a6ffa2f26e41635d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5190e761a07745440f6bc6b34e7a0c38b415018e46e8bdf81323e665637085dc',2005,'ZA','South Africa','people-and-society',397,'$491.4 billion (2004 est.)
-0.31% (2005 est.)
3.5% (2004 est.)
purchasing power parity - $11,100 (2004 est.)','a6041dd5ac920f20ed0d85c3ffac7051fd4ed8ef397a0dd550b65fc90289f118','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('538ba6a5b771874bead81fd9a4cd094ee00fb143dd202f75180f0b0d411863c1',2005,'ES','Spain','people-and-society',398,'$937.6 billion (2004 est.)
0.15% (2005 est.)
2.6% (2004 est.)
purchasing power parity - $23,300 (2004 est.)','3e8157128dfa9e4f8c28fba16f6ed06525142d1ee3bd2c7b8df02a6fed8dafde','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c43d679eb8efc22ab50cf437ff6cd87815ae55ea0f13c4f1f2ba5b951b690814',2005,'LK','Sri Lanka','people-and-society',399,'$80.58 billion (2004 est.)
0.79% (2005 est.)
5.2% (2004 est.)
purchasing power parity - $4,000 (2004 est.)','d8348d7db95283bbb27428b573ed67aefe6d85d247e18e724f45af4b2f7fb15a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72a01010dff7a8f39175429f6c0f2af197a24c3b5d856f35af7f708196effca1',2005,'SD','Sudan','people-and-society',400,'$76.19 billion (2004 est.)
2.6% (2005 est.)
6.4% (2004 est.)
purchasing power parity - $1,900 (2004 est.)','d04f9cb1da261209f3c06101403cded8f484f751a1d346a61b1cda8ec0e8052b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ef8608300eb2550dc3d28927b8c96938d045549e6128cddd5fbc95588a94a51',2005,'SR','Suriname','people-and-society',401,'$1.885 billion (2004 est.)
Svalbard
$NA
Swaziland
$6.018 billion (2004 est.)
0.25% (2005 est.)
Svalbard
-0.02% (2005 est.)
Swaziland
0.25% (2005 est.)
4.2% (2004 est.)
Svalbard
NA%
Swaziland
2.5% (2004 est.)
purchasing power parity - $4,300 (2004 est.)
Swaziland
purchasing power parity - $5,100 (2004 est.)','9537747da8f64c5cf81f2496ead1740a32dd7d794b219571e567f68a0f896f02','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07f07f2ca4370308da6efb3e81f6070a33afb1424da3c7be9e39a6e2e94c3479',2005,'SE','Sweden','people-and-society',402,'$255.4 billion (2004 est.)
0.17% (2005 est.)
3.6% (2004 est.)
purchasing power parity - $28,400 (2004 est.)','15b8716d479bb3a28aac0414a4ba16fd25f15f0fbfa2c0cdad6c377f76799e3c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a990507b0987c873e8eafca7d43bfe216ded49b097bf987473657a9c3eecdc9b',2005,'CH','Switzerland','people-and-society',403,'$251.9 billion (2004 est.)
Syria
$60.44 billion (2004 est.)
Taiwan
$576.2 billion (2004 est.)
0.49% (2005 est.)
Syria
2.34% (2005 est.)
Taiwan
0.63% (2005 est.)
1.8% (2004 est.)
Syria
2.3% (2004 est.)
Taiwan
6% (2004 est.)
purchasing power parity - $33,800 (2004 est.)
Syria
purchasing power parity - $3,400 (2004 est.)
Taiwan
purchasing power parity - $25,300 (2004 est.)','bbf2b638455e50533edb41e4ddd955bd5cf2d938055969e369dfdfeaaee4c06a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56512dffcc90f8771ad17b6fe95a8835af1ef61e98a173e565bd4e196df37e23',2005,'TJ','Tajikistan','people-and-society',404,'$7.95 billion (2004 est.)
Tanzania
$23.71 billion (2004 est.)
2.15% (2005 est.)
Tanzania
1.83% (2005 est.)
10.5% (2004 est.)
Tanzania
5.8% (2004 est.)
purchasing power parity - $1,100 (2004 est.)
Tanzania
purchasing power parity - $700 (2004 est.)','420df076d3ead26d4d10023ec3fbf8d0b9acfefa71874128110801ee7311514c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec18ceaa4ccc1bd48f0c565f49d63030ad39096e0002b6747b3f1b05552d8317',2005,'TH','Thailand','people-and-society',405,'$524.8 billion (2004 est.)
0.87% (2005 est.)
6.1% (2004 est.)
purchasing power parity - $8,100 (2004 est.)','08b3c725064f515a2802c56ef2cd363f4d9c69af5b927013b112fa15bb0f424d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14c1a819c580e158c821e9fee7776fd774a001b3328e1f3648e88d92e6b1e991',2005,'TG','Togo','people-and-society',406,'$8.684 billion (2004 est.)
2.17% (2005 est.)
3% (2004 est.)
purchasing power parity - $1,600 (2004 est.)','bb985f2c7805938dfb13d9b1e84aca713a6e8b88f68f42874f9a2b5a31458f52','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b900b6dc34fba5a47501dbcd57cb3a095c3c1376127f7a07818c80c3b780bf4',2005,'TK','Tokelau','people-and-society',407,'$1.5 million (1993 est.)
-0.01% (2005 est.)
NA
purchasing power parity - $1,000 (1993 est.)
self-administering territory of New Zealand; note -
Tokelauans are drafting a constitution and developing institutions
and patterns of self-government as Tokelau moves toward free
association with New Zealand
Tromelin Island
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands','9d360cea735943799a98e41873f529f9d18f16eb336afc49ec21b60acc581022','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9b83c65ddead9e468ba94e0f017b0aa978b25e7da6800f58f0e08c7736766ce',2005,'TO','Tonga','people-and-society',408,'$244 million (2002 est.)
1.98% (2005 est.)
1.5% (2002 est.)
purchasing power parity - $2,300 (2002 est.)','a822992267e94822e54d7fc24016c5826c5e407cfc537bb268e8f232e35e3105','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29ae80eccc8566ef60224c07d9452b2bfcd44415f574d80332ca969ffe5d62eb',2005,'TT','Trinidad and Tobago','people-and-society',409,'$11.48 billion (2004 est.)
-0.74% (2005 est.)
5.7% (2004 est.)
purchasing power parity - $10,500 (2004 est.)','6f216c7f9e8acd8cb60b0cabddce4243af1e860b28d1d3b9ca0a51ef3a86a391','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d30a3a95ba21b2f39f599f918a8a3c15b40fb5eb525b4d2572c0b4c3a84844f',2005,'TN','Tunisia','people-and-society',410,'$70.88 billion (2004 est.)
Turkey
$508.7 billion (2004 est.)
0.99% (2005 est.)
Turkey
1.09% (2005 est.)
5.1% (2004 est.)
Turkey
8.2% (2004 est.)
purchasing power parity - $7,100 (2004 est.)
Turkey
purchasing power parity - $7,400 (2004 est.)','fa7367566e8106ec3f459d872aa5cd843f9fdde4c137cc349e4d34497c503722','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d4a894b22edcdd8d9af209926caa6fa131e621191e34f345ca5ddd06cdab661',2005,'TM','Turkmenistan','people-and-society',411,'$27.6 billion (2004 est.)
1.81% (2005 est.)
IMF estimate: 7.5%
note: official government statistics show 21.4% growth, but these
estimates are notoriously unreliable (2004 est.)
purchasing power parity - $5,700 (2004 est.)','e4b5edf096de94d089fa9fbe61515f25f5076a20ac98e0cb51b3b2e77d4b23c6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66580a60c20ffc1e6b665e7b4c04c9b8e378b423e0d19358661f90bb24043f18',2005,'TC','Turks and Caicos Islands','people-and-society',412,'$216 million (2002 est.)
2.9% (2005 est.)
4.9% (2000 est.)
purchasing power parity - $11,500 (2002
est.)
overseas territory of the UK
Virgin Islands
organized, unincorporated territory of the US with
policy relations between the Virgin Islands and the US under the
jurisdiction of the Office of Insular Affairs, US Department of the
Interior
Wake Island
unincorporated territory of the US; administered from
Washington, DC, by the Department of the Interior; activities on the
island are conducted by the US Air Force','8c2c11871db8bb5a690116943759d92b00108568a958afc6d957b86d4e07feb6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd68a2b5083b66a0b4269b68abf37e29c5ba4c9e65c78892d306432bd1e3d0df',2005,'TV','Tuvalu','people-and-society',413,'$12.2 million (2000 est.)
1.47% (2005 est.)
3% (2000 est.)
purchasing power parity - $1,100 (2000 est.)','a0d04eed97735e7fd4f293bb38d95013833bdd1926e4099cd80aca66daa56544','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e908522496f90cfbe143bf113d4dde67a3fb2b2be3270fae59ca177587d559b3',2005,'UG','Uganda','people-and-society',414,'$39.39 billion (2004 est.)
3.31% (2005 est.)
5% (2004 est.)
purchasing power parity - $1,500 (2004 est.)','e2d785f05e224f44414441ae705713a38d067022eac5b807a6b87671b7a598b9','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('707bd16ecb9ec7500a88f4c44a78c20dff24a0ec0fb963d09c31d45b7a9e009a',2005,'UA','Ukraine','people-and-society',415,'$299.1 billion (2004 est.)
-0.63% (2005 est.)
12% (2004 est.)
purchasing power parity - $6,300 (2004 est.)','238bbb076781fa6693da80f243d39fb6aa446f4eaafe0ed65c8b0a4d37186df3','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1b4679fa3be5f41fbb8147b49459146a8da46802ee2e9c54064586f4366ea07',2005,'AE','United Arab Emirates','people-and-society',416,'$63.67 billion (2004 est.)
1.54% (2005 est.)
5.7% (2004 est.)
purchasing power parity - $25,200 (2004 est.)','9f02aead1adb0d5e65ed761c0397600b750e78a2ddb45a6ee3ac54aaf444518e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de76720cb5aa3422f7723a7d3cc80733cb612395e959f8be738d5b1b555f949a',2005,'GB','United Kingdom','people-and-society',417,'$1.782 trillion (2004 est.)
0.28% (2005 est.)
3.2% (2004 est.)
purchasing power parity - $29,600 (2004 est.)','5f9ceec470f378cfadac2173c6a3dc0418da060839f943fd0ef0fc2e113d8982','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('769150b67e9c2289cac25aa25752bb4dcd471a272b6760f7fe9d0e2487ceb7b5',2005,'US','United States','people-and-society',418,'$11.75 trillion (2004 est.)
0.92% (2005 est.)
4.4% (2004 est.)
purchasing power parity - $40,100 (2004 est.)','bde003a114a0894a7931e2990d0dad7dfb3b86c255b7953625dfc1d64a67d817','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb80c3ba000401a3caa023da94256a30630bed81a69c6daf3f64b114e1c6eab7',2005,'UY','Uruguay','people-and-society',419,'$49.27 billion (2004 est.)
0.47% (2005 est.)
10.2% (2004 est.)
purchasing power parity - $14,500 (2004 est.)','3576da5c36423ff0d67a5c71a6f6c9ab27050e4e1338abdfb1c25b8e5b266657','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0942d23e39173d6eb6ef6c853274494e196515fe8d8b4bb80b6137cbd8f526ac',2005,'UZ','Uzbekistan','people-and-society',420,'$47.59 billion (2004 est.)
1.67% (2005 est.)
4.4% (2004 est.)
purchasing power parity - $1,800 (2004 est.)','a84ea2f6eac9e278f18767f2405140512cf2f4c4514d1cfc1449e3077ab23c06','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45d446cd66207ab462c9b2f698e9efa4fb96adb2e3ac9d6eb72f6aa8526cced2',2005,'VU','Vanuatu','people-and-society',421,'$580 million (2003 est.)
Venezuela
$145.2 billion (2004 est.)
Vietnam
$227.2 billion (2004 est.)
Virgin Islands
$2.5 billion (2002 est.)
1.52% (2005 est.)
Venezuela
1.4% (2005 est.)
Vietnam
1.04% (2005 est.)
Virgin Islands
-0.07% (2005 est.)
1.1% (2003 est.)
Venezuela
16.8% (2004 est.)
Vietnam
7.7% (2004 est.)
Virgin Islands
2% (2002 est.)
purchasing power parity - $2,900 (2003 est.)
Venezuela
purchasing power parity - $5,800 (2004 est.)
Vietnam
purchasing power parity - $2,700 (2004 est.)
Virgin Islands
purchasing power parity - $17,200 (2002 est.)','651e937ed371111664a366a6cae10ed5b45a928ae83ca654d98bc307fe86a42e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d93ba83997cbe612f585cc72c2520c0bac0bcc48d2437257f80ef7c13e90293',2005,'WF','Wallis and Futuna','people-and-society',422,'$60 million (2004 est.)
West Bank
$1.8 billion (2003 est.)
NA%
West Bank
3.13% (2005 est.)
NA%
West Bank
6% (2003 est.)
purchasing power parity - $3,800 (2004 est.)
West Bank
purchasing power parity - $800 (2003 est.)
overseas territory of France
This page was last updated on 20 October, 2005
======================================================================
@2007 Diplomatic representation from the US','ca47fa0de2dd24e2c731b515321ae8c4df8ad89f9c9617bad4c3607af9f02e2a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5090a9649c1e6cbc21cceb9aa6ea5e0b09c76e82b2ef09a453e7d337418cab0f',2005,'YE','Yemen','people-and-society',423,'$16.25 billion (2004 est.)
3.45% (2005 est.)
1.9% (2004 est.)
purchasing power parity - $800 (2004 est.)','e8ca85d85874c5228e6dc08365e2637d913fa802f3a7183f1902fc3090f76ea3','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c0ea256ac60527e121d2e3eef30d6c975a19aecb9a40937f70d1977fbe1092d',2005,'ZM','Zambia','people-and-society',424,'$9.409 billion (2004 est.)
2.12% (2005 est.)
4.6% (2004 est.)
purchasing power parity - $900 (2004 est.)','5c5a06615b2a6638ce2b3cb97588d9c3e7fd348e228b93cf6ab0d7ee7ee263b0','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('864e85dd41da6e21995f95ac109413443f28075c5f4dd19dd68696bfea7c4b5c',2005,'BV','Bouvet Island','people-and-society',425,'territory of Norway; administered by the Polar
Department of the Ministry of Justice and Police from Oslo','a602d22c9c2afea39d62ac445c6985ef01fa76486b333f2b4b13ad104c4d49dd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78bb49bb53a9a2b6441622559ded5971d2847b086d7c0cc4815ca4bfad570dc8',2005,'IO','British Indian Ocean Territory','people-and-society',426,'overseas territory of the UK;
administered by a commissioner, resident in the Foreign and
Commonwealth Office in London
British Virgin Islands
overseas territory of the UK; internal
self-governing
none (overseas territory of the UK)
British Virgin Islands
none (overseas territory of the UK)
Brunei
chief of mission: Ambassador Emil SKODON
embassy: Third Floor, Teck Guan Plaza, Jalan Sultan, Bandar Seri
Begawan
mailing address: PSC 470 (BSB), FPO AP 96507
telephone: [673] (2) 229670
FAX: [673] (2) 225293','fffd247e20a154678c67e7b40a674d7a7b0b869029151aa297b355208e7320ce','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de8875ac49e04cd4999a8bc5123efac9e8d4ef6abaa3ec553710fd026795786e',2005,'HM','Heard Island and McDonald Islands','people-and-society',427,'territory of Australia;
administered from Canberra by the Australian Antarctic Division of
the Department of the Environment and Heritage
none (territory of Australia)
Holy See (Vatican City)
chief of mission: Ambassador (vacant)
embassy: Villa Domiziana, Via delle Terme Deciane 26, 00153 Rome
mailing address: PSC 59, Box 66, APO AE 09624
telephone: [39] (06) 4674-3428
FAX: [39] (06) 575-8346','c720d7cddca9e2694c18fc97b230290e0e3a68e885210f549960ab46dad3d734','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37ec11e919154d3d57340b6aa01cb1461c499dca9d810ee43ca07a4348274e2b',2005,'GS','South Georgia and the South Sandwich Islands','people-and-society',428,'overseas territory of
the UK, also claimed by Argentina; administered from the Falkland
Islands by a commissioner, who is concurrently governor of the
Falkland Islands, representing Queen ELIZABETH II; Grytviken,
formerly a whaling station on South Georgia, is a scientific base
Svalbard
territory of Norway; administered by the Polar Department
of the Ministry of Justice, through a governor (sysselmann) residing
in Longyearbyen, Spitsbergen; by treaty (9 February 1920)
sovereignty was awarded to Norway','7e971d51ab96a582acbf1aa2eb6d17adb08c5a590ed34379f74ebe4d95de64bc','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

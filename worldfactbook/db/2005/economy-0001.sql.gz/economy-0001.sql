SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d165dc0e0b207b19da621b5af2a6b3e870722fb3727659296834ff833cf7ee3',2005,'ZW','Zimbabwe','economy',4,'GDP (purchasing power parity)
GDP - real growth rate
GDP - per capita
Investment (gross fixed)
Inflation rate (consumer prices)
Labor force
Unemployment rate
Public debt
Industrial production growth rate
Electricity - production
Electricity - consumption
Oil - production
Oil - consumption
Oil - exports
Oil - imports
Oil - proved reserves
Natural Gas - production
Natural Gas - consumption
Natural Gas - exports
Natural Gas - imports
Natural Gas - proved reserves
Current account balance
Exports
Imports
Reserves of foreign exchange and gold
Debt - external
This category includes the entries dealing with the size, development,
and management of productive resources, i.e., land, labor, and capital.
Economy - overview
This entry briefly describes the type of economy, including the degree
of market orientation, the level of economic development, the most
important natural resources, and the unique areas of specialization. It
also characterizes major economic events and policy changes in the most
recent 12 months and may include a statement about one or two key
future macroeconomic trends.
Electricity - consumption
This entry consists of total electricity generated annually plus
imports and minus exports, expressed in kilowatt-hours. The discrepancy
between the amount of electricity generated and/or imported and the
amount consumed and/or exported is accounted for as loss in
transmission and distribution.
Electricity - exports
This entry is the total exported electricity in kilowatt-hours.
Electricity - imports
This entry is the total imported electricity in kilowatt-hours.
Electricity - production
This entry is the annual electricity generated expressed in kilowatt-
hours. The discrepancy between the amount of electricity generated
and/or imported and the amount consumed and/or exported is accounted
for as loss in transmission and distribution.
Elevation extremes
This entry includes both the highest point and the lowest point.
Entities
Some of the independent states, dependencies, areas of special
sovereignty, and governments included in this publication are not
independent, and others are not officially recognized by the US
Government. "Independent state" refers to a people politically
organized into a sovereign state with a definite territory.
"Dependencies" and "areas of special sovereignty" refer to a broad
category of political entities that are associated in some way with an
independent state. "Country" names used in the table of contents or for
page headings are usually the short-form names as approved by the US
Board on Geographic Names and may include independent states,
dependencies, and areas of special sovereignty, or other geographic
entities. There are a total of 271 separate geographic entities in The
World Factbook that may be categorized as follows:
INDEPENDENT STATES
192 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, East Timor,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia
and Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
OTHER
2 Taiwan, European Union
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia - Ashmore and Cartier Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald
Islands, Norfolk Island
2 China - Hong Kong, Macau
2 Denmark - Faroe Islands, Greenland
16 France - Bassas da India, Clipperton Island, Europa Island, French
Guiana, French Polynesia, French Southern and Antarctic Lands, Glorioso
Islands, Guadeloupe, Juan de Nova Island, Martinique, Mayotte, New
Caledonia, Reunion, Saint Pierre and Miquelon, Tromelin Island, Wallis
and Futuna
2 Netherlands - Aruba, Netherlands Antilles
3 New Zealand - Cook Islands, Niue, Tokelau
3 Norway - Bouvet Island, Jan Mayen, Svalbard
17 UK - Akrotiri, Anguilla, Bermuda, British Indian Ocean Territory,
British Virgin Islands, Cayman Islands, Dhekelia, Falkland Islands,
Gibraltar, Guernsey, Jersey, Isle of Man, Montserrat, Pitcairn Islands,
Saint Helena, South Georgia and the South Sandwich Islands, Turks and
Caicos Islands
14 US - American Samoa, Baker Island, Guam, Howland Island, Jarvis
Island, Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island,
Northern Mariana Islands, Palmyra Atoll, Puerto Rico, Virgin Islands,
Wake Island
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West Bank,
The UK annexed Southern Rhodesia from the South Africa
Company in 1923. A 1961 constitution was formulated that favored
whites in power. In 1965 the government unilaterally declared its
independence, but the UK did not recognize the act and demanded more
complete voting rights for the black African majority in the country
(then called Rhodesia). UN sanctions and a guerrilla uprising
finally led to free elections in 1979 and independence (as Zimbabwe)
in 1980. Robert MUGABE, the nation''s first prime minister, has been
the country''s only ruler (as president since 1987) and has dominated
the country''s political system since independence. His chaotic land
redistribution campaign begun in 2000 caused an exodus of white
farmers, crippled the economy, and ushered in widespread shortages
of basic commodities. Ignoring international condemnation, MUGABE
rigged the 2002 presidential election to ensure his reelection.
Opposition and labor groups launched general strikes in 2003 to
pressure MUGABE to retire early; security forces continued their
brutal repression of regime opponents.
This page was last updated on 20 October, 2005
======================================================================
@2030 Airports - with paved runways
total: 17
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2004 est.)
This page was last updated on 20 October, 2005
======================================================================
@2031 Airports - with unpaved runways
total: 387
1,524 to 2,437 m: 5
914 to 1,523 m: 186
under 914 m: 196 (2004 est.)
This page was last updated on 20 October, 2005
======================================================================
@2032 Environment - current issues
deforestation; soil erosion; land degradation; air and
water pollution; the black rhinoceros herd - once the largest
concentration of the species in the world - has been significantly
reduced by poaching; poor mining practices have led to toxic waste
and heavy metal pollution
This page was last updated on 20 October, 2005
======================================================================
@2033 Environment - international agreements
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
This page was last updated on 20 October, 2005
======================================================================
@2034 Military expenditures - percent of GDP (%)
4.3% (2004)
This page was last updated on 20 October, 2005
======================================================================
@2038 Electricity - production (kWh)
8.839 billion kWh (2002)
This page was last updated on 20 October, 2005
======================================================================
@2042 Electricity - consumption (kWh)
11.22 billion kWh (2002)
This page was last updated on 20 October, 2005
======================================================================
@2043 Electricity - imports (kWh)
3 billion kWh (2002)
This page was last updated on 20 October, 2005
======================================================================
@2044 Electricity - exports (kWh)
0 kWh (2002)
This page was last updated on 20 October, 2005
======================================================================
@2046 Population below poverty line (%)
70% (2002 est.)
This page was last updated on 20 October, 2005
======================================================================
@2047 Household income or consumption by percentage share (%)
lowest 10%: 1.97%
highest 10%: 40.42% (1995)
This page was last updated on 20 October, 2005
======================================================================
@2048 Labor force - by occupation (%)
agriculture 66%, industry 10%, services 24% (1996)
This page was last updated on 20 October, 2005
======================================================================
@2049 Exports - commodities
cotton, tobacco, gold, ferroalloys, textiles/clothing
This page was last updated on 20 October, 2005
======================================================================
@2050 Exports - partners (%)
South Africa 31.5%, Switzerland 7.4%, UK 7.3%, China 6.1%,
Germany 4.3% (2004)
This page was last updated on 20 October, 2005
======================================================================
@2051 Administrative divisions
8 provinces and 2 cities* with provincial status;
Bulawayo*, Harare*, Manicaland, Mashonaland Central, Mashonaland
East, Mashonaland West, Masvingo, Matabeleland North, Matabeleland
South, Midlands
This page was last updated on 20 October, 2005
======================================================================
@2052 Agriculture - products
corn, cotton, tobacco, wheat, coffee, sugarcane, peanuts;
sheep, goats, pigs
This page was last updated on 20 October, 2005
======================================================================
@2053 Airports
404 (2004 est.)
This page was last updated on 20 October, 2005
======================================================================
@2054 Birth rate (births/1,000 population)
29.74 births/1,000 population (2005 est.)
This page was last updated on 20 October, 2005
======================================================================
@2055 Military branches
Zimbabwe Defense Forces (ZDF): Zimbabwe National Army, Air
Force of Zimbabwe (AFZ), Zimbabwe Republic Police (2005)
This page was last updated on 20 October, 2005
======================================================================
@2056 Budget
revenues: $1.325 billion
expenditures: $1.593 billion, including capital expenditures of NA
(2004 est.)
This page was last updated on 20 October, 2005
======================================================================
@2057 Capital','4472d4a32d7a645c0b561b6763ec708b0f76497b62073002224a2814367173a2','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da8247f9e783f502e5e149d85f302eabf93908264fbefbd7ccec2cab0c209db7',2005,'EH','Western Sahara','economy',23,'OTHER ENTITIES
5 oceans - Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean,
Southern Ocean
1 World
271 total
Environment - current issues
This entry lists the most pressing and important environmental
problems. The following terms and abbreviations are used throughout the
entry:
acidification - the lowering of soil and water pH due to acid
precipitation and deposition usually through precipitation; this
process disrupts ecosystem nutrient flows and may kill freshwater fish
and plants dependent on more neutral or alkaline conditions (see acid
rain).
acid rain - characterized as containing harmful levels of sulfur
dioxide or nitrogen oxide; acid rain is damaging and potentially deadly
to the earth''s fragile ecosystems; acidity is measured using the pH
scale where 7 is neutral, values greater than 7 are considered
alkaline, and values below 5.6 are considered acid precipitation; note
- a pH of 2.4 (the acidity of vinegar) has been measured in rainfall in
New England.
aerosol - a collection of airborne particles dispersed in a gas, smoke,
or fog.
afforestation - converting a bare or agricultural space by planting
trees and plants; reforestation involves replanting trees on areas that
have been cut or destroyed by fire.
asbestos - a naturally occurring soft fibrous mineral commonly used in
fireproofing materials and considered to be highly carcinogenic in
particulate form.
biodiversity - also biological diversity; the relative number of
species, diverse in form and function, at the genetic, organism,
community, and ecosystem level; loss of biodiversity reduces an
ecosystem''s ability to recover from natural or man-induced disruption.
bio-indicators - a plant or animal species whose presence, abundance,
and health reveal the general condition of its habitat.
biomass - the total weight or volume of living matter in a given area
or volume.
carbon cycle - the term used to describe the exchange of carbon (in
various forms, e.g., as carbon dioxide) between the atmosphere, ocean,
terrestrial biosphere, and geological deposits.
catchments - assemblages used to capture and retain rainwater and
runoff; an important water management technique in areas with limited
freshwater resources, such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane) - a colorless, odorless
insecticide that has toxic effects on most animals; the use of DDT was
banned in the US in 1972.
defoliants - chemicals which cause plants to lose their leaves
artificially; often used in agricultural practices for weed control,
and may have detrimental impacts on human and ecosystem health.
deforestation - the destruction of vast areas of forest (e.g.,
unsustainable forestry practices, agricultural and range land clearing,
and the over exploitation of wood products for use as fuel) without
planting new growth.
desertification - the spread of desert-like conditions in arid or semi-
arid areas, due to overgrazing, loss of agriculturally productive
soils, or climate change.
dredging - the practice of deepening an existing waterway; also, a
technique used for collecting bottom-dwelling marine organisms (e.g.,
shellfish) or harvesting coral, often causing significant destruction
of reef and ocean-floor ecosystems.
drift-net fishing - done with a net, miles in extent, that is generally
anchored to a boat and left to float with the tide; often results in an
over harvesting and waste of large populations of non-commercial marine
species (by-catch) by its effect of "sweeping the ocean clean".
ecosystems - ecological units comprised of complex communities of
organisms and their specific environments.
effluents - waste materials, such as smoke, sewage, or industrial waste
which are released into the environment, subsequently polluting it.
endangered species - a species that is threatened with extinction
either by direct hunting or habitat destruction.
freshwater - water with very low soluble mineral content; sources
include lakes, streams, rivers, glaciers, and underground aquifers.
greenhouse gas - a gas that "traps" infrared radiation in the lower
atmosphere causing surface warming; water vapor, carbon dioxide,
nitrous oxide, methane, hydrofluorocarbons, and ozone are the primary
greenhouse gases in the Earth''s atmosphere.
groundwater - water sources found below the surface of the earth often
in naturally occurring reservoirs in permeable rock strata; the source
for wells and natural springs.
Highlands Water Project - a series of dams constructed jointly by
Lesotho and South Africa to redirect Lesotho''s abundant water supply
into a rapidly growing area in South Africa; while it is the largest
infrastructure project in southern Africa, it is also the most costly
and controversial; objections to the project include claims that it
forces people from their homes, submerges farmlands, and squanders
economic resources.
Inuit Circumpolar Conference (ICC) - represents the 145,000 Inuits of
Russia, Alaska, Canada, and Greenland in international environmental
issues; a General Assembly convenes every three years to determine the
focus of the ICC; the most current concerns are long-range transport of
pollutants, sustainable development, and climate change.
metallurgical plants - industries which specialize in the science,
technology, and processing of metals; these plants produce highly
concentrated and toxic wastes which can contribute to pollution of
ground water and air when not properly disposed.
noxious substances - injurious, very harmful to living beings.
overgrazing - the grazing of animals on plant material faster than it
can naturally regrow leading to the permanent loss of plant cover, a
common effect of too many animals grazing limited range land.
ozone shield - a layer of the atmosphere composed of ozone gas (O3)
that resides approximately 25 miles above the Earth''s surface and
absorbs solar ultraviolet radiation that can be harmful to living
organisms.
poaching - the illegal killing of animals or fish, a great concern with
respect to endangered or threatened species.
pollution - the contamination of a healthy environment by man-made
waste.
potable water - water that is drinkable, safe to be consumed.
salination - the process through which fresh (drinkable) water becomes
salt (undrinkable) water; hence, desalination is the reverse process;
also involves the accumulation of salts in topsoil caused by
evaporation of excessive irrigation water, a process that can
eventually render soil incapable of supporting crops.
siltation - occurs when water channels and reservoirs become clotted
with silt and mud, a side effect of deforestation and soil erosion.
slash-and-burn agriculture - a rotating cultivation technique in which
trees are cut down and burned in order to clear land for temporary
agriculture; the land is used until its productivity declines at which
point a new plot is selected and the process repeats; this practice is
sustainable while population levels are low and time is permitted for
regrowth of natural vegetation; conversely, where these conditions do
not exist, the practice can have disastrous consequences for the
Morocco virtually annexed the northern two-thirds of
Western Sahara (formerly Spanish Sahara) in 1976, and the rest of
the territory in 1979, following Mauritania''s withdrawal. A
guerrilla war with the Polisario Front contesting Rabat''s
sovereignty ended in a 1991 UN-brokered cease-fire; a UN-organized
referendum on final status has been repeatedly postponed.
World
Globally, the 20th century was marked by: (a) two devastating
world wars; (b) the Great Depression of the 1930s; (c) the end of
vast colonial empires; (d) rapid advances in science and technology,
from the first airplane flight at Kitty Hawk, North Carolina (US) to
the landing on the moon; (e) the Cold War between the Western
alliance and the Warsaw Pact nations; (f) a sharp rise in living
standards in North America, Europe, and Japan; (g) increased
concerns about the environment, including loss of forests, shortages
of energy and water, the decline in biological diversity, and air
pollution; (h) the onset of the AIDS epidemic; and (i) the ultimate
emergence of the US as the only world superpower. The planet''s
population continues to explode: from 1 billion in 1820, to 2
billion in 1930, 3 billion in 1960, 4 billion in 1974, 5 billion in
1988, and 6 billion in 2000. For the 21st century, the continued
exponential growth in science and technology raises both hopes
(e.g., advances in medicine) and fears (e.g., development of even
more lethal weapons of war).
total: 3
2,438 to 3,047 m: 3 (2004 est.)
total: 8
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 3 (2004 est.)
sparse water and lack of arable land
World
large areas subject to overpopulation, industrial disasters,
pollution (air, water, acid rain, toxic substances), loss of
vegetation (overgrazing, deforestation, desertification), loss of
wildlife, soil degradation, soil depletion, erosion
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
90 million kWh (2002)
World
15.29 trillion kWh (2002 est.)
83.7 million kWh (2002)
World
14.28 trillion kWh (2002 est.)
0 kWh (2002)
World
497.6 billion kWh (2002 est.)
0 kWh (2002)
World
500.8 billion kWh (2002 est.)
NA
lowest 10%: NA
highest 10%: NA
World
lowest 10%: NA %
highest 10%: NA %
animal husbandry and subsistence farming 50%
World
agriculture NA%, industry NA%, services NA%
phosphates 62%
World
the whole range of industrial and agricultural goods and
services
Morocco claims and administers Western Sahara, so
trade partners are included in overall Moroccan accounts
World
US 15.7%, Germany 7.7%, China 5.4%, France 5.1%, UK 5.1%,
Japan 4.5% (2004)
none (under de facto control of Morocco)
World
271 nations, dependent areas, and other entities
fruits and vegetables (grown in the few oases);
camels, sheep, goats (kept by nomads)
11 (2004 est.)
World
49,973 (2004)
NA births/1,000 population
World
20.15 births/1,000 population (2005 est.)
revenues: NA
expenditures: NA, including capital expenditures of NA','47e90ed77816faba29ca12faa0f7accc34ca87c28c4bc413353decb3c50a5622','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d67721ce68cb30771919a499becbd830d039ef2b5d9c0d7bd8057ef270562a19',2005,'TG','Togo','economy',75,'GDP (purchasing power parity):
$30.17 billion (2004 est.)
GDP - real growth rate:
4.9% (2004 est.)
GDP - per capita:
purchasing power parity - $1,900 (2004 est.)
GDP - composition by sector:
agriculture: 43.7%
industry: 20.1%
services: 36.2% (2004 est.)
Labor force:
6.68 million (2004 est.)
Labor force - by occupation:
agriculture 70%, industry and commerce 13%, other 17%
Unemployment rate:
30% (2001 est.)
Population below poverty line:
48% (2000 est.)
Household income or consumption by percentage share:
lowest 10%: 1.9%
highest 10%: 36.6% (1996)
Distribution of family income - Gini index:
47.7 (1996)
Inflation rate (consumer prices):
1% (2004 est.)
Investment (gross fixed):
16.1% of GDP (2004 est.)
Budget:
revenues: $2.493 billion
expenditures: $2.248 billion, including capital expenditures of NA
(2004 est.)
Public debt:
69.1% of GDP (2004 est.)
Agriculture - products:
coffee, cocoa, cotton, rubber, bananas, oilseed, grains, root
starches; livestock; timber
Industries:
petroleum production and refining, aluminum production, food
processing, light consumer goods, textiles, lumber, ship repair
Industrial production growth rate:
4.2% (1999 est.)
Electricity - production:
3.571 billion kWh (2002)
Electricity - production by source:
fossil fuel: 2.7%
hydro: 97.3%
nuclear: 0%
other: 0% (2001)
Electricity - consumption:
3.321 billion kWh (2002)
Electricity - exports:
0 kWh (2002)
Electricity - imports:
0 kWh (2002)
Oil - production:
94,000 bbl/day (2004 est.)
Oil - consumption:
22,000 bbl/day (2001 est.)
Oil - exports:
NA
Oil - imports:
NA
Oil - proved reserves:
80 million bbl (2004 est.)
Natural gas - production:
0 cu m (2001 est.)
Natural gas - consumption:
0 cu m (2001 est.)
Natural gas - exports:
0 cu m (2001 est.)
Natural gas - imports:
0 cu m (2001 est.)
Natural gas - proved reserves:
55.22 billion cu m (2004)
Current account balance:
$-149.1 million (2004 est.)
Exports:
$2.445 billion f.o.b. (2004 est.)
Exports - commodities:
crude oil and petroleum products, lumber, cocoa beans, aluminum,
coffee, cotton
Exports - partners:
Spain 15.2%, Italy 12.3%, UK 10.2%, France 9.2%, US 8.8%, South
Korea 7.1%, Netherlands 4.3% (2004)
Imports:
$1.979 billion f.o.b. (2004 est.)
Imports - commodities:
machinery, electrical equipment, transport equipment, fuel, food
Imports - partners:
France 28.2%, Nigeria 9.9%, Belgium 7.6%, US 4.9%, China 4.8%,
Germany 4.6%, Italy 4.1% (2004)
Reserves of foreign exchange and gold:
$687.5 million (2004 est.)
Debt - external:
$8.46 billion (2004 est.)
Economic aid - recipient:
on 23 January 2001, the Paris Club agreed to reduce Cameroon''s debt
of $1.3 billion by $900 million; debt relief now totals $1.26 billion
Currency (code):
Communaute Financiere Africaine franc (XAF); note - responsible
authority is the Bank of the Central African States
Currency code:
XAF
Exchange rates:
Communaute Financiere Africaine francs (XAF) per US dollar - 528.29
(2004), 581.2 (2003), 696.99 (2002), 733.04 (2001), 711.98 (2000)
Fiscal year:
1 July - 30 June
Communications Cameroon
Telephones - main lines in use:
110,900 (2002)
Telephones - mobile cellular:
1.077 million (2003)
Telephone system:
general assessment: available only to business and government
domestic: cable, microwave radio relay, and tropospheric scatter
international: country code - 237; satellite earth stations - 2
Intelsat (Atlantic Ocean); fiber optic submarine cable (SAT-3/WASC)
provides connectivity to Europe and Asia
Radio broadcast stations:
AM 2, FM 9, shortwave 3 (2002)
Radios:
2.27 million (1997)
Television broadcast stations:
1 (2002)
Televisions:
450,000 (1997)
Internet country code:
.cm
Internet hosts:
479 (2004)
Internet Service Providers (ISPs):
1 (2002)
Internet users:
60,000 (2002)
note: Cameroon also had more than 100 cyber-cafes in 2001
Transportation Cameroon
Railways:
total: 1,008 km
narrow gauge: 1,008 km 1.000-m gauge (2004)
Highways:
total: 34,300 km
paved: 4,288 km
unpaved: 30,012 km (1999 est.)
Waterways:
navigation mainly on Benue River; limited during rainy season (2004)
Pipelines:
gas 90 km; liquid petroleum gas 9 km; oil 1,120 km (2004)
Ports and harbors:
Douala, Limboh Terminal
Merchant marine:
total: 1 ships (1,000 GRT or over) 169,593 GRT/357,023 DWT
by type: petroleum tanker 1 (2005)
Airports:
47 (2004 est.)
Airports - with paved runways:
total: 11
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
Airports - with unpaved runways:
total: 36
1,524 to 2,437 m: 7
914 to 1,523 m: 20
under 914 m: 9 (2004 est.)
Military Cameroon
Military branches:
Cameroon Armed Forces: Army, Navy (includes Naval Infantry), Air
Force
Military service age and obligation:
18 years of age for voluntary military service; no conscription
(1999)
Manpower available for military service:
males age 18-49: 3,410,440 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,720,385 (2005 est.)
Manpower reaching military service age annually:
males: 188,662 (2005 est.)
Military expenditures - dollar figure:
$221.1 million (2004)
Military expenditures - percent of GDP:
1.6% (2004)
Transnational Issues Cameroon
Disputes - international:
ICJ ruled in 2002 on the entire Cameroon-Nigeria land and maritime
boundary but the parties formed a Joint Border Commission, which
continues to meet regularly to resolve differences bilaterally and
have commenced with demarcation in less-contested sections of the
boundary, starting in Lake Chad in the north; implementation of the
ICJ ruling on the Cameroon-Equatorial Guinea-Nigeria maritime
boundary in the Gulf of Guinea is impeded by imprecisely defined
coordinates, the unresolved Bakassi allocation, and a sovereignty
dispute between Equatorial Guinea and Cameroon over an island at the
mouth of the Ntem River; Nigeria initially rejected cession of the
Bakasi Peninsula, then agreed, but has yet to withdraw its forces
while much of the indigenous population opposes cession; only
Nigeria and Cameroon have heeded the Lake Chad Commission''s
admonition to ratify the delimitation treaty which also includes
Chad and Niger
Refugees and internally displaced persons:
refugees (country of origin): 39,261 (Chad) 16,983 (Nigeria) 9,634
(Cote d''Ivoire) (2004)
This page was last updated on 20 October, 2005
======================================================================
@Canada
Introduction Canada
French Togoland became Togo in 1960. Gen. Gnassingbe EYADEMA,
installed as military ruler in 1967, continued to rule well into the
21st century. Despite the facade of multiparty elections instituted
in the early 1990s, the government continued to be dominated by
President EYADEMA, whose Rally of the Togolese People (RPT) party
maintained power almost continually since 1967. Togo has come under
fire from international organizations for human rights abuses and is
plagued by political unrest. While most bilateral and multilateral
aid to Togo remains frozen, the European Union initiated a partial
resumption of cooperation and development aid to Togo in late 2004.
Upon his death in February 2005, President EYADEMA was succeeded by
his son Faure GNASSINGBE. The succession, supported by the military
and in contravention of the nation''s constitution, was challenged by
popular protest and a threat of sanctions from regional leaders.
GNASSINGBE succumbed to pressure and agreed to hold elections in
late April 2005.
total: 2
2,438 to 3,047 m: 2 (2004 est.)
total: 7
914 to 1,523 m: 5
under 914 m: 2 (2004 est.)
deforestation attributable to slash-and-burn agriculture and
the use of wood for fuel; water pollution presents health hazards
and hinders the fishing industry; air pollution increasing in urban
areas
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
1.9% (2004)
108.8 million kWh (2002)
451.2 million kWh (2002)
350 million kWh; note - electricity supplied by Ghana (2002)
0 kWh (2002)
32% (1989 est.)
lowest 10%: NA
highest 10%: NA
agriculture 65%, industry 5%, services 30% (1998 est.)
reexports, cotton, phosphates, coffee, cocoa
Burkina Faso 16.4%, Ghana 15.1%, Benin 9.4%, Mali 7.6%, China
7.5%, India 5.6% (2004)
5 regions (regions, singular - region); Kara, Plateaux,
Savanes, Centrale, Maritime
coffee, cocoa, cotton, yams, cassava (tapioca), corn, beans,
rice, millet, sorghum; livestock; fish
9 (2004 est.)
33.48 births/1,000 population (2005 est.)
Togolese Armed Forces (FAT): Army, Navy, Air Force, Gendarmerie
(2005)
revenues: $239.2 million
expenditures: $273.3 million, including capital expenditures of NA
(2004 est.)','ecf89a9d3d74013625fc74731d863455b5360747c30c1f5054c8d82304e22360','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce647c3ebec102d262e9dd5f629463c5ab5f1eba9cfa43d03da0c9a7e570bbc1',2005,'LB','Lebanon','economy',131,'GDP (purchasing power parity):
$925.1 billion (2004 est.)
GDP - real growth rate:
4.6% (2004 est.)
GDP - per capita:
purchasing power parity - $19,200 (2004 est.)
GDP - composition by sector:
agriculture: 3.2%
industry: 40.4%
services: 56.3% (2004 est.)
Labor force:
22.9 million (2004 est.)
Labor force - by occupation:
agriculture 8%, industry 19%, services 73% (2004 est.)
Unemployment rate:
3.6% (2004 est.)
Population below poverty line:
4% (2001 est.)
Household income or consumption by percentage share:
lowest 10%: 2.9%
highest 10%: 22.5% (1999 est.)
Distribution of family income - Gini index:
35.8 (2000)
Inflation rate (consumer prices):
3.6% (2004 est.)
Investment (gross fixed):
28.7% of GDP (2004 est.)
Budget:
revenues: $150.5 billion
expenditures: $155.8 billion, including capital expenditures of NA
(2004 est.)
Public debt:
21.3% of GDP (2004 est.)
Agriculture - products:
rice, root crops, barley, vegetables, fruit; cattle, pigs,
chickens, milk, eggs; fish
Industries:
electronics, telecommunications, automobile production, chemicals,
shipbuilding, steel
Industrial production growth rate:
10.1% (2004 est.)
Electricity - production:
322.5 billion kWh (2003)
Electricity - production by source:
fossil fuel: 62.4%
hydro: 0.8%
nuclear: 36.6%
other: 0.2% (2001)
Electricity - consumption:
293.6 billion kWh (2003)
Electricity - exports:
0 kWh (2003)
Electricity - imports:
0 kWh (2003)
Oil - production:
0 bbl/day (2004 est.)
Oil - consumption:
2.07 million bbl/day (2004 est.)
Oil - exports:
630,100 bbl/day (2003)
Oil - imports:
2.263 million bbl/day (2003)
Natural gas - production:
0 cu m (2003 est.)
Natural gas - consumption:
20.92 billion cu m (2003 est.)
Natural gas - exports:
0 cu m (2003 est.)
Natural gas - imports:
21.11 billion cu m (2003 est.)
Current account balance:
$26.78 billion (2004 est.)
Exports:
$250.6 billion f.o.b. (2004 est.)
Exports - commodities:
semiconductors, wireless telecommunications equipment, motor
vehicles, computers, steel, ships, petrochemicals
Exports - partners:
China 19.7%, US 17%, Japan 8.6%, Hong Kong 7.2% (2004)
Imports:
$214.2 billion f.o.b. (2004 est.)
Imports - commodities:
machinery, electronics and electronic equipment, oil, steel,
transport equipment, organic chemicals, plastics
Imports - partners:
Japan 20.6%, China 13.2%, US 12.9%, Saudi Arabia 5.3% (2004)
Reserves of foreign exchange and gold:
$199.1 billion (2004 est.)
Debt - external:
$160 billion (2004 est.)
Economic aid - donor:
ODA $334 million (2003)
Currency (code):
South Korean won (KRW)
Currency code:
KRW
Exchange rates:
South Korean won per US dollar - 1,145.3 (2004), 1,191.6 (2003),
1,251.1 (2002), 1,291 (2001), 1,131 (2000)
Fiscal year:
calendar year
Communications Korea, South
Telephones - main lines in use:
22.877 million (2003)
Telephones - mobile cellular:
33,591,800 (2003)
Telephone system:
general assessment: excellent domestic and international services
domestic: NA
international: country code - 82; fiber-optic submarine cable to
China; the Russia-Korea-Japan submarine cable; satellite earth
stations - 3 Intelsat (2 Pacific Ocean and 1 Indian Ocean) and 1
Inmarsat (Pacific Ocean region)
Radio broadcast stations:
AM 58, FM 150, shortwave 2 (2004)
Radios:
47.5 million (2000)
Television broadcast stations:
64 (additionally 119 Cable Operators; 239 Relay Cable Operators)
(2004)
Televisions:
15.9 million (1997)
Internet country code:
.kr
Internet hosts:
694,206 (2001)
Internet Service Providers (ISPs):
11 (2000)
Internet users:
29.22 million (2003)
Transportation Korea, South
Railways:
total: 3,472 km
standard gauge: 3,472 km 1.435-m gauge (1,342 km electrified) (2004)
Highways:
total: 86,990 km
paved: 66,721 km (including 1,996 km of expressways)
unpaved: 20,269 km (2001)
Waterways:
1,608 km
note: most navigable only by small craft (2004)
Pipelines:
gas 1,433 km; refined products 827 km (2004)
Ports and harbors:
Inch''on, Masan, P''ohang, Pusan, Ulsan
Merchant marine:
total: 601 ships (1,000 GRT or over) 6,992,656 GRT/11,081,142 DWT
by type: bulk carrier 125, cargo 196, chemical tanker 88, container
71, liquefied gas 20, passenger 5, passenger/cargo 22, petroleum
tanker 51, refrigerated cargo 15, roll on/roll off 5, vehicle
carrier 3
foreign-owned: 2 (Germany 1, United Kingdom 1)
registered in other countries: 366 (2005)
Airports:
179 (2004 est.)
Airports - with paved runways:
total: 88
over 3,047 m: 3
2,438 to 3,047 m: 21
1,524 to 2,437 m: 14
914 to 1,523 m: 12
under 914 m: 38 (2004 est.)
Airports - with unpaved runways:
total: 91
914 to 1,523 m: 3
under 914 m: 88 (2004 est.)
Heliports:
206 (2004 est.)
Military Korea, South
Military branches:
Army, Navy, Air Force, Marine Corps, National Maritime Police
(Coast Guard)
Military service age and obligation:
20-30 years of age for compulsory military service; conscript
service obligation - 24-28 months, depending on the military branch
involved; 18 years of age for voluntary military service; some 4,000
women serve as commissioned and noncommissioned officers, approx.
2.3% of all officers; women, in service since 1950, are admitted to
seven service branches, including infantry; excluded from artillery,
armor, anti-air, and chaplaincy corps (2005)
Manpower available for military service:
males age 20-49: 12,458,257 (2005 est.)
Manpower fit for military service:
males age 20-49: 9,932,026 (2005 est.)
Manpower reaching military service age annually:
males: 344,723 (2005 est.)
Military expenditures - dollar figure:
$16.18 billion (2004)
Military expenditures - percent of GDP:
2.8% (2004)
Transnational Issues Korea, South
Disputes - international:
Military Demarcation Line within the 4-km wide Demilitarized Zone
has separated North from South Korea since 1953; periodic maritime
disputes with North Korea over the Northern Limit Line; South Korea
and Japan claim Liancourt Rocks (Tok-do/Take-shima), occupied by
South Korea since 1954
This page was last updated on 20 October, 2005
======================================================================
@Kuwait
Introduction Kuwait
total: 5
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
under 914 m: 1 (2004 est.)
total: 3
914 to 1,523 m: 2
under 914 m: 1 (2004 est.)
deforestation; soil erosion; desertification; air pollution
in Beirut from vehicular traffic and the burning of industrial
wastes; pollution of coastal waters from raw sewage and oil spills
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental Modification, Marine Life
Conservation
3.1% (FY99) (2004)
8.066 billion kWh (2002)
8.591 billion kWh (2002)
1.09 billion kWh (2002)
0 kWh (2002)
28% (1999 est.)
lowest 10%: NA
highest 10%: NA
agriculture NA, industry NA, services NA
authentic jewelry, inorganic chemicals, miscellaneous
consumer goods, fruit, tobacco, construction minerals, electric
power machinery and switchgear, textile fibers, paper
Syria 24.9%, UAE 10%, Turkey 6.9%, Switzerland 6.7%, Saudi
Arabia 5.3% (2004)
6 governorates (mohafazat, singular - mohafazah); Beyrouth,
Beqaa, Liban-Nord, Liban-Sud, Mont-Liban, Nabatiye
citrus, grapes, tomatoes, apples, vegetables, potatoes,
olives, tobacco; sheep, goats
8 (2004 est.)
18.88 births/1,000 population (2005 est.)
Lebanese Armed Forces (LAF): Army, Navy, and Air Force
revenues: $4.895 billion
expenditures: $6.642 billion, including capital expenditures of NA
(2004 est.)
The 1975-91 civil war seriously damaged Lebanon''s economic
infrastructure, cut national output by half, and all but ended
Lebanon''s position as a Middle Eastern entrepot and banking hub. In
the years since, Lebanon has rebuilt much of its war-torn physical
and financial infrastructure by borrowing heavily - mostly from
domestic banks. In an attempt to reduce the ballooning national
debt, the HARIRI government began an austerity program, reining in
government expenditures, increasing revenue collection, and
privatizing state enterprises. In November 2002, the government met
with international donors at the Paris II conference to seek
bilateral assistance in restructuring its massive domestic debt at
lower rates of interest. Substantial receipts from donor nations
stabilized government finances in 2003, but did little to reduce the
debt, which stood at nearly 180% of GDP. In 2004 the HARIRI
government issued Eurobonds in an effort to manage maturing debt,
and the KARAMI government has continued this practice. However,
privatization of state-owned enterprises had not occurred by the end
of 2004, as promised during the Paris II conference.','50f2548ea0a29cbb07e7b1e86a52b27d69437a231f4a0da791984e6185b8840c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efba3d6f927ac9aeaf3b39be3824060c5a27cef887cbc10338aae63d210bd335',2005,'SA','Saudi Arabia','economy',614,'In 1902, ABD AL-AZIZ bin Abd al-Rahman Al Saud captured
Riyadh and set out on a 30-year campaign to unify the Arabian
Peninsula. A son of ABD AL-AZIZ rules the country today, and the
country''s Basic Law stipulates that the throne shall remain in the
hands of the aging sons and grandsons of the kingdom''s founder.
Following Iraq''s invasion of Kuwait in 1990, Saudi Arabia accepted
the Kuwaiti royal family and 400,000 refugees while allowing Western
and Arab troops to deploy on its soil for the liberation of Kuwait
the following year. The continuing presence of foreign troops on
Saudi soil after Operation Desert Storm remained a source of tension
between the royal family and the public until the US military''s
near-complete withdrawal to neighboring Qatar in 2003. The first
major terrorist attacks in Saudi Arabia in several years, which
occurred in May and November 2003, prompted renewed efforts on the
part of the Saudi government to counter domestic terrorism and
extremism, which also coincided with a slight upsurge in media
freedom and announcement of government plans to phase in partial
political representation. A burgeoning population, aquifer
depletion, and an economy largely dependent on petroleum output and
prices are all ongoing governmental concerns.
total: 72
over 3,047 m: 32
2,438 to 3,047 m: 13
1,524 to 2,437 m: 23
914 to 1,523 m: 2
under 914 m: 2 (2004 est.)
total: 129
over 3047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 72
914 to 1,523 m: 39
under 914 m: 12 (2004 est.)
desertification; depletion of underground water
resources; the lack of perennial rivers or permanent water bodies
has prompted the development of extensive seawater desalination
facilities; coastal pollution from oil spills
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
10% (2002)
138.2 billion kWh (2002)
128.5 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 12%, industry 25%, services 63% (1999 est.)
petroleum and petroleum products 90%
US 18.2%, Japan 14.9%, South Korea 9.5%, China 6.1%,
Taiwan 4.5%, Singapore 4.1% (2004)
13 provinces (mintaqat, singular - mintaqah); Al Bahah,
Al Hudud ash Shamaliyah, Al Jawf, Al Madinah, Al Qasim, Ar Riyad,
Ash Sharqiyah (Eastern Province), ''Asir, Ha''il, Jizan, Makkah,
Najran, Tabuk
wheat, barley, tomatoes, melons, dates, citrus; mutton,
chickens, eggs, milk
201 (2004 est.)
29.56 births/1,000 population (2005 est.)
Land Force (Army), Navy, Air Force, Air Defense Force,
National Guard, Ministry of Interior Forces (paramilitary)
revenues: $104.8 billion
expenditures: $78.66 billion, including capital expenditures of NA
(2004 est.)','5624e803d8ed9cfdafd92275e5341750e61d63b579dfc39b3edbf8f9f79e32fb','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59a2a86d544908fd25812a6cd1e130d60c7cabb60ffa28e8a93069defc35f107',2005,'SN','Senegal','economy',615,'Independent from France in 1960, Senegal joined with The
Gambia to form the nominal confederation of Senegambia in 1982.
However, the envisaged integration of the two countries was never
carried out, and the union was dissolved in 1989. Despite peace
talks, a southern separatist group sporadically has clashed with
government forces since 1982. Senegal has a long history of
participating in international peacekeeping.
Serbia and Montenegro
The Kingdom of Serbs, Croats, and Slovenes was
formed in 1918; its name was changed to Yugoslavia in 1929.
Occupation by Nazi Germany in 1941 was resisted by various
paramilitary bands that fought each other as well as the invaders.
The group headed by Marshal TITO took full control upon German
expulsion in 1945. Although Communist, his new government and its
successors (he died in 1980) managed to steer their own path between
the Warsaw Pact nations and the West for the next four and a half
decades. In the early 1990s, post-TITO Yugoslavia began to unravel
along ethnic lines: Slovenia, Croatia, Macedonia, and Bosnia and
Herzegovina were recognized as independent states in 1992. The
remaining republics of Serbia and Montenegro declared a new "Federal
Republic of Yugoslavia" (FRY) in April 1992 and, under President
Slobodan MILOSEVIC, Serbia led various military intervention efforts
to unite ethnic Serbs in neighboring republics into a "Greater
Serbia." All of these efforts were ultimately unsuccessful and led
to Yugoslavia being ousted from the UN in 1992. In 1998-99, massive
expulsions by FRY forces and Serb paramilitaries of ethnic Albanians
living in Kosovo provoked an international response, including the
NATO bombing of Serbia and the stationing of a NATO-led force
(KFOR), in Kosovo. Federal elections in the fall of 2000, brought
about the ouster of MILOSEVIC and installed Vojislav KOSTUNICA as
president. The arrest of MILOSEVIC in 2001 allowed for his
subsequent transfer to the International Criminal Tribunal for the
Former Yugoslavia in The Hague to be tried for crimes against
humanity. In 2001, the country''s suspension from the UN was lifted,
and it was once more accepted into UN organizations under the name
of the Federal Republic of Yugoslavia. Kosovo has been governed by
the UN Interim Administration Mission in Kosovo (UNMIK) since June
1999, under the authority of UN Security Council Resolution 1244,
pending a determination by the international community of its future
status. In 2002, the Serbian and Montenegrin components of
Yugoslavia began negotiations to forge a looser relationship. These
talks became a reality in February 2003 when lawmakers restructured
the country into a loose federation of two republics called Serbia
and Montenegro. The Constitutional Charter of Serbia and Montenegro
includes a provision that allows either republic to hold a
referendum after three years that would allow for their independence
from the state union.
total: 9
over 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 2 (2004 est.)
Serbia and Montenegro
total: 19
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 6
914 to 1,523 m: 2
under 914 m: 4 (2004 est.)
total: 11
1,524 to 2,437 m: 6
914 to 1,523 m: 4
under 914 m: 1 (2004 est.)
Serbia and Montenegro
total: 25
1,524 to 2,437 m: 2
914 to 1,523 m: 10
under 914 m: 13 (2004 est.)
wildlife populations threatened by poaching; deforestation;
overgrazing; soil erosion; desertification; overfishing
Serbia and Montenegro
pollution of coastal waters from sewage
outlets, especially in tourist-related areas such as Kotor; air
pollution around Belgrade and other industrial cities; water
pollution from industrial wastes dumped into the Sava which flows
into the Danube
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Life Conservation, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
Serbia and Montenegro
party to: Air Pollution, Biodiversity, Climate
Change, Endangered Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
1.5% (2004)
Serbia and Montenegro
NA
1.737 billion kWh (2002)
Serbia and Montenegro
31.64 billion kWh (2002)
1.615 billion kWh (2002)
Serbia and Montenegro
32.33 billion kWh (2002)
0 kWh (2002)
Serbia and Montenegro
3.3 billion kWh (2002)
0 kWh (2002)
Serbia and Montenegro
400 million kWh (2002)
54% (2001 est.)
Serbia and Montenegro
30% (1999 est.)
lowest 10%: 2.6%
highest 10%: 33.5% (1995)
Serbia and Montenegro
lowest 10%: NA%
highest 10%: NA%
agriculture 70%
Serbia and Montenegro
agriculture NA, industry NA, services NA
fish, groundnuts (peanuts), petroleum products, phosphates,
cotton
Serbia and Montenegro
manufactured goods, food and live animals, raw
materials
India 14.4%, Mali 13.1%, France 9.8%, Italy 7.3%, Spain
6.6%, Guinea-Bissau 5.6%, Gambia, The 4.8% (2004)
Serbia and Montenegro
Italy 29%, Germany 16.6%, Austria 7%, Greece
6.7%, France 4.9%, Slovenia 4.1% (2004)
11 regions (regions, singular - region); Dakar, Diourbel,
Fatick, Kaolack, Kolda, Louga, Matam, Saint-Louis, Tambacounda,
Thies, Ziguinchor
Serbia and Montenegro
2 republics (republike, singular - republika);
and 2 nominally autonomous provinces* (autonomn pokrajine, singular
- autonomna pokrajina); Kosovo* (temporarily under UN
administration, per UN Security Council Resolution 1244),
Montenegro, Serbia, Vojvodina*
peanuts, millet, corn, sorghum, rice, cotton, tomatoes,
green vegetables; cattle, poultry, pigs; fish
Serbia and Montenegro
cereals, fruits, vegetables, tobacco, olives;
cattle, sheep, goats
20 (2004 est.)
Serbia and Montenegro
44 (2004 est.)
35.21 births/1,000 population (2005 est.)
Serbia and Montenegro
12.12 births/1,000 population (2005 est.)
Army, Navy (Marine Senegalaise), Air Force (2005)
Serbia and Montenegro
Serbian and Montenegrin Armed Forces (Vojska
Srbije i Crne Gore, VSCG): Ground Forces, Air and Air Defense
Forces, Naval Forces (2005)
revenues: $1.572 billion
expenditures: $1.627 billion, including capital expenditures of $357
million (2004 est.)
Serbia and Montenegro
revenues: $9.773 billion
expenditures: $10.46 billion, including capital expenditures of NA
(2004 est.)','e2dc67ed49ed7f6d3610b06109576b4b8c6ab2f945c4a7c09bfb60440ee0ce74','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e0e66a20017c355a75fb39aba66b647a10ad38f32ad1774f1728e317f95b067',2005,'SC','Seychelles','economy',616,'A lengthy struggle between France and Great Britain for
the islands ended in 1814, when they were ceded to the latter.
Independence came in 1976. Socialist rule was brought to a close
with a new constitution and free elections in 1993. The most recent
presidential elections were held in 2001; President RENE, who had
served since 1977, was re-elected. In April 2004 RENE stepped down
and Vice President James MICHEL was sworn in as president.
total: 8
2,438 to 3,047 m: 1
914 to 1,523 m: 4
under 914 m: 3 (2004 est.)
total: 7
914 to 1,523 m: 3
under 914 m: 4 (2004 est.)
water supply depends on catchments to collect rainwater
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
1.8% (2004)
218 million kWh (2002)
202.8 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 10%, industry 19%, services 71% (1989)
canned tuna, frozen fish, cinnamon bark, copra, petroleum
products (reexports)
UK 27.7%, France 15.8%, Spain 12.6%, Japan 8.6%, Italy
7.5%, Germany 5.6% (2004)
23 administrative districts; Anse aux Pins, Anse Boileau,
Anse Etoile, Anse Louis, Anse Royale, Baie Lazare, Baie Sainte Anne,
Beau Vallon, Bel Air, Bel Ombre, Cascade, Glacis, Grand'' Anse (on
Mahe), Grand'' Anse (on Praslin), La Digue, La Riviere Anglaise, Mont
Buxton, Mont Fleuri, Plaisance, Pointe La Rue, Port Glaud, Saint
Louis, Takamaka
coconuts, cinnamon, vanilla, sweet potatoes, cassava
(tapioca), bananas; broiler chickens; tuna fish
15 (2004 est.)
16.22 births/1,000 population (2005 est.)
Seychelles Defense Force: Army, Coast Guard (includes
Navy Wing, Air Wing), National Guard (2005)
revenues: $318.3 million
expenditures: $298.5 million, including capital expenditures of NA
(2004 est.)','e0781085e08c4ccbb786494781c24cf2558e68d110a14f1e78a8d73ad79a677f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7d7dc2f40e234d3db0702da53286bbcd7b0935bbae12b2df90a98b6cd0e4b5c',2005,'SL','Sierra Leone','economy',617,'The 1991 to 2002 civil war between the government and
the Revolutionary United Front (RUF) resulted in tens of thousands
of deaths and the displacement of more than 2 million people (about
one-third of the population), many of whom are now refugees in
neighboring countries. With the support of the UN peacekeeping force
and contributions from the World Bank and international community,
demobilization and disarmament of the RUF and Civil Defense Forces
(CDF) combatants has been completed. National elections were held in
May 2002 and the government continues to slowly reestablish its
authority. However, the gradual withdrawal of most UN Mission in
Sierra Leone (UNAMSIL) peacekeepers in 2004 and early 2005,
deteriorating political and economic conditions in Guinea, and the
tenuous security situation in neighboring Liberia may present
challenges to the continuation of Sierra Leone''s stability.
total: 1
over 3,047 m: 1 (2004 est.)
total: 9
914 to 1,523 m: 7
under 914 m: 2 (2004 est.)
rapid population growth pressuring the environment;
overharvesting of timber, expansion of cattle grazing, and
slash-and-burn agriculture have resulted in deforestation and soil
exhaustion; civil war depleting natural resources; overfishing
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification
1.7% (2004)
255.3 million kWh (2002)
237.4 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
68% (1989 est.)
lowest 10%: 0.5%
highest 10%: 43.6% (1989)
agriculture NA, industry NA, services NA
diamonds, rutile, cocoa, coffee, fish (1999)
Belgium 61.6%, Germany 11.8%, US 5.4% (2004)
3 provinces and 1 area*; Eastern, Northern, Southern,
Western*
rice, coffee, cocoa, palm kernels, palm oil, peanuts;
poultry, cattle, sheep, pigs; fish
10 (2004 est.)
42.84 births/1,000 population (2005 est.)
Republic of Sierra Leone Armed Forces (RSLAF): Army
(includes Air Wing, Maritime Wing)
revenues: $96 million
expenditures: $351 million, including capital expenditures of NA
(2000 est.)','70606d5ee8b7c7c28a37f8a2314cbe7faf162da9b9d73514a0c7562a7bbb85b7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('692ca25127670806ea7af2c400c5cf3a256576f1512c0cafe612af86988ac5fc',2005,'SG','Singapore','economy',618,'Singapore was founded as a British trading colony in 1819.
It joined the Malaysian Federation in 1963 but separated two years
later and became independent. It subsequently became one of the
world''s most prosperous countries with strong international trading
links (its port is one of the world''s busiest in terms of tonnage
handled) and with per capita GDP equal to that of the leading
nations of Western Europe.
total: 10
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
industrial pollution; limited natural fresh water
resources; limited land availability presents waste disposal
problems; seasonal smoke/haze resulting from forest fires in
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
4.9% (FY01)
35.33 billion kWh (2003)
32 billion kWh (2003)
0 kWh (2003)
0 kWh (2003)
NA
lowest 10%: NA
highest 10%: NA
manufacturing 18%, construction 6%, transportation and
communication 11%, financial, business, and other services 49%,
other 16% (2003)
machinery and equipment (including electronics), consumer
goods, chemicals, mineral fuels
Malaysia 15.2%, US 13%, Hong Kong 9.8%, China 8.6%, Japan
6.4%, Taiwan 4.6%, Thailand 4.3%, South Korea 4.1% (2004)
none
rubber, copra, fruit, orchids, vegetables, poultry, eggs,
fish, ornamental fish
10 (2004 est.)
9.49 births/1,000 population (2005 est.)
Singapore Armed Forces: Army, Navy, Air Force, Air Defense
(2005)
revenues: $17.05 billion
expenditures: $18.45 billion, including capital expenditures of $5.8
billion (2004 est.)','77bbbf41d9662102eac5b398684f50a8269f9ac73017df0bbf3d4877aea26bac','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('918f11558dc56126655c457e88d82b43140ada447ae5ab6b9c5bb68bb6d5b20f',2005,'SK','Slovakia','economy',619,'In 1918 the Slovaks joined the closely related Czechs to
form Czechoslovakia. Following the chaos of World War II,
Czechoslovakia became a Communist nation within Soviet-ruled Eastern
Europe. Soviet influence collapsed in 1989 and Czechoslovakia once
more became free. The Slovaks and the Czechs agreed to separate
peacefully on 1 January 1993. Slovakia joined both NATO and the EU
in the spring of 2004.
total: 17
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 7 (2004 est.)
total: 17
2,438 to 3,047 m: 1
914 to 1,523 m: 9
under 914 m: 7 (2004 est.)
air pollution from metallurgical plants presents human
health risks; acid rain damaging forests
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
1.89% (2002)
31.15 billion kWh (2003)
28.89 billion kWh (2003)
6 billion kWh (2003)
8 billion kWh (2003)
NA
lowest 10%: 5.1%
highest 10%: 18.2% (1992)
agriculture 5.8%, industry 29.3%, construction 9%, services
55.9% (2003)
vehicles 25.9%, machinery and electrical equipment 21.3%,
base metals 14.6%, chemicals and minerals 10.1%, plastics 5.4%%
(2004 est.)
Germany 34.4%, Czech Republic 14.7%, Austria 8.2%, Italy
5.8%, Poland 5.3%, US 4.5%, Hungary 4.3% (2004)
8 regions (kraje, singular - kraj); Banskobystricky,
Bratislavsky, Kosicky, Nitriansky, Presovsky, Trenciansky, Trnavsky,
Zilinsky
grains, potatoes, sugar beets, hops, fruit; pigs, cattle,
poultry; forest products
34 (2004 est.)
10.62 births/1,000 population (2005 est.)
Army of the Slovak Republic (Armady Slovenskej Republika):
Land Command, Air Forces (Vozdushne Sily), Training and Support
Command, Logistics Command (2005)
revenues: $15.44 billion
expenditures: $16.7 billion, including capital expenditures of NA
(2004 est.)','ef480529d7aaf7b6a312a85c71fe43dab8c1d5de36cc965d7b9f924f81a8beb1','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('522b4bc9f3892be33818823def2070b01ac942c3fbf6dda0eb0c038c48f60ed4',2005,'SI','Slovenia','economy',620,'The Slovene lands were part of the Holy Roman Empire and
Austria until 1918 when the Slovenes joined the Serbs and Croats in
forming a new multinational state, renamed Yugoslavia in 1929. After
World War II, Slovenia became a republic of the renewed Yugoslavia,
which though Communist, distanced itself from Moscow''s rule.
Dissatisfied with the exercise of power by the majority Serbs, the
Slovenes succeeded in establishing their independence in 1991 after
a short 10-day war. Historical ties to Western Europe, a strong
economy, and a stable democracy have assisted in Slovenia''s
transformation to a modern state. Slovenia acceded to both NATO and
the EU in the spring of 2004.
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2004 est.)
total: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 4 (2004 est.)
Sava River polluted with domestic and industrial waste;
pollution of coastal waters with heavy metals and toxic chemicals;
forest damage near Koper from air pollution (originating at
metallurgical and chemical plants) and resulting acid rain
party to: Air Pollution, Air Pollution-Sulfur 94,
Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.7% (FY00)
12.49 billion kWh (2003)
11.8 billion kWh (2003)
5.194 billion kWh (2002)
7.448 billion kWh (2002)
NA
lowest 10%: 3.9%
highest 10%: 23% (1998)
agriculture 6%, industry 40%, services 55% (2002)
manufactured goods, machinery and transport equipment,
chemicals, food
Germany 18.3%, Italy 11.6%, Austria 11.5%, France 7.4%,
Croatia 7.4%, Bosnia and Herzegovina 4.8% (2004)
182 municipalities (obcine, singular - obcina) and 11 urban
municipalities* (mestne obcine , singular - mestna obcina )
Ajdovscina, Beltinci, Benedikt, Bistrica ob Sotli, Bled, Bloke,
Bohinj, Borovnica, Bovec, Braslovce, Brda, Brezice, Brezovica,
Cankova, Celje*, Cerklje na Gorenjskem, Cerknica, Cerkno,
Cerkvenjak, Crensovci, Crna na Koroskem, Crnomelj, Destrnik, Divaca,
Dobje, Dobrepolje, Dobrna, Dobrova-Horjul-Polhov Gradec,
Dobrovnik-Dobronak, Dolenjske Toplice, Dol pri Ljubljani, Domzale,
Dornava, Dravograd, Duplek, Gorenja Vas-Poljane, Gorisnica, Gornja
Radgona, Gornji Grad, Gornji Petrovci, Grad, Grosuplje, Hajdina,
Hoce-Slivnica, Hodos-Hodos, Horjul, Hrastnik, Hrpelje-Kozina,
Idrija, Ig, Ilirska Bistrica, Ivancna Gorica, Izola-Isola, Jesenice,
Jezersko, Jursinci, Kamnik, Kanal, Kidricevo, Kobarid, Kobilje,
Kocevje, Komen, Komenda, Koper-Capodistria*, Kostel, Kozje, Kranj*,
Kranjska Gora, Krizevci, Krsko, Kungota, Kuzma, Lasko, Lenart,
Lendava-Lendva, Litija, Ljubljana*, Ljubno, Ljutomer, Logatec, Loska
Dolina, Loski Potok, Lovrenc na Pohorju, Luce, Lukovica, Majsperk,
Maribor*, Markovci, Medvode, Menges, Metlika, Mezica, Miklavz na
Dravskem Polju, Miren-Kostanjevica, Mirna Pec, Mislinja, Moravce,
Moravske Toplice, Mozirje, Murska Sobota*, Muta, Naklo, Nazarje,
Nova Gorica*, Novo Mesto*, Odranci, Oplotnica, Ormoz, Osilnica,
Pesnica, Piran-Pirano, Pivka, Podcetrtek, Podlehnik, Podvelka,
Polzela, Postojna, Prebold, Preddvor, Prevalje, Ptuj*, Puconci,
Race-Fram, Radece, Radenci, Radlje ob Dravi, Radovljica, Ravne na
Koroskem, Razkrizje, Ribnica, Ribnica na Pohorju, Rogasovci, Rogaska
Slatina, Rogatec, Ruse, Salovci, Selnica ob Dravi, Semic,
Sempeter-Vrtojba, Sencur, Sentilj, Sentjernej, Sentjur pri Celju,
Sevnica, Sezana, Skocjan, Skofja Loka, Skofljica, Slovenj Gradec*,
Slovenska Bistrica, Slovenske Konjice, Smarje pri Jelsah, Smartno ob
Paki, Smartno pri Litiji, Sodrazica, Solcava, Sostanj, Starse,
Store, Sveta Ana, Sveti Andraz v Slovenskih Goricah, Sveti Jurij,
Tabor, Tisina, Tolmin, Trbovlje, Trebnje, Trnovska Vas, Trzic,
Trzin, Turnisce, Velenje*, Velika Polana, Velike Lasce, Verzej,
Videm, Vipava, Vitanje, Vodice, Vojnik, Vransko, Vrhnika, Vuzenica,
Zagorje ob Savi, Zalec, Zavrc, Zelezniki, Zetale, Ziri, Zirovnica,
Zuzemberk, Zrece
note: there may be 45 more municipalities
potatoes, hops, wheat, sugar beets, corn, grapes; cattle,
sheep, poultry
14 (2004 est.)
8.95 births/1,000 population (2005 est.)
Slovenian Army (includes Air and Naval Forces)
revenues: $13.36 billion
expenditures: $13.99 billion, including capital expenditures of NA
(2004 est.)','1711fa8c2a92fea29911280b6476b27c81dddc1f2dddaeaac5e58ece099d34de','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a484051a4ce0c402420a3e113d7f25845efbbf6555bcfa0c53b77d8389ad3617',2005,'SB','Solomon Islands','economy',621,'The UK established a protectorate over the Solomon
Islands in the 1890s. Some of the bitterest fighting of World War II
occurred on these islands. Self-government was achieved in 1976 and
independence two years later. Ethnic violence, government
malfeasance, and endemic crime have undermined stability and civil
society. In June 2003, Prime Minister Sir Allen KEMAKEZA sought the
assistance of Australia in reestablishing law and order; the
following month, an Australian-led multinational force arrived to
restore peace and disarm ethnic militias. The Regional Assistance
Mission to the Solomon Islands (RAMSI) has been very effective in
restoring law and order and rebuilding government institutions.
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 31
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 21 (2004 est.)
deforestation; soil erosion; many of the surrounding
coral reefs are dead or dying
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Environmental Modification,
Law of the Sea, Marine Dumping, Marine Life Conservation, Ozone
Layer Protection, Whaling
signed, but not ratified: none of the selected agreements
NA
32 million kWh (2002)
29.76 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 75%, industry 5%, services 20% (2000
est.)
timber, fish, copra, palm oil, cocoa
China 27.8%, South Korea 17.1%, Thailand 15.7%,
Japan 9.7%, Philippines 4.8% (2004)
9 provinces and 1 capital territory*; Central,
Choiseul, Guadalcanal, Honiara*, Isabel, Makira, Malaita, Rennell
and Bellona, Temotu, Western
cocoa beans, coconuts, palm kernels, rice, potatoes,
vegetables, fruit; cattle, pigs; timber; fish
33 (2004 est.)
30.74 births/1,000 population (2005 est.)
no regular military forces; Royal Solomon Islands
Police (RSIP)
revenues: $49.7 million
expenditures: $75.1 million, including capital expenditures of $0
(2003)','6ce9b7b2b898569cb03cac0d48f3537ed56bc1f2fea289db0e027087d698ca68','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19922d741fdb31ec0b3cf547af9b51ac0320b8ddd6cf6958ca1cf9394bca7a18',2005,'SO','Somalia','economy',622,'The regime of Mohamed SIAD Barre was ousted in January 1991;
turmoil, factional fighting, and anarchy have followed in the years
since. In May of 1991, northern clans declared an independent
Republic of Somaliland that now includes the administrative regions
of Awdal, Woqooyi Galbeed, Togdheer, Sanaag, and Sool. Although not
recognized by any government, this entity has maintained a stable
existence, aided by the overwhelming dominance of a ruling clan and
economic infrastructure left behind by British, Russian, and
American military assistance programs. The regions of Bari and
Nugaal and northern Mudug comprise a neighboring self-declared
autonomous state of Puntland, which has been self-governing since
1998, but does not aim at independence; it has also made strides
towards reconstructing a legitimate, representative government, but
has suffered some civil strife. Puntland disputes its border with
Somaliland as it also claims portions of eastern Sool and Sanaag.
Beginning in 1993, a two-year UN humanitarian effort (primarily in
the south) was able to alleviate famine conditions, but when the UN
withdrew in 1995, having suffered significant casualties, order
still had not been restored. The mandate of the Transitional
National Government (TNG), created in August 2000 in Arta, Djibouti,
expired in August 2003. New Somali President Abdullahi YUSUF Ahmed
has formed a new Transitional Federal Government (TFG) consisting of
a 275-member parliament. It was established in October 2004 to
replace the TNG but has not yet moved to Mogadishu. Discussions
regarding the establishment of a new government in Mogadishu are
ongoing in Kenya. Numerous warlords and factions are still fighting
for control of the capital city as well as for other southern
regions. Suspicion of Somali links with global terrorism further
complicates the picture.
total: 6
over 3,047 m: 4
2438 to 3047 m: 1
1,524 to 2,437 m: 1 (2004 est.)
total: 54
2,438 to 3,047 m: 4
1,524 to 2,437 m: 19
914 to 1,523 m: 29
under 914 m: 2 (2004 est.)
famine; use of contaminated water contributes to human
health problems; deforestation; overgrazing; soil erosion;
desertification
party to: Endangered Species, Law of the Sea, Ozone Layer
Protection
0.9% (2003)
240.3 million kWh (2002)
223.5 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture (mostly pastoral nomadism) 71%, industry and
services 29%
livestock, bananas, hides, fish, charcoal, scrap metal
UAE 39.3%, Thailand 24.3%, Yemen 12.2%, Oman 4.7% (2004)
18 regions (plural - NA, singular - gobolka); Awdal, Bakool,
Banaadir, Bari, Bay, Galguduud, Gedo, Hiiraan, Jubbada Dhexe,
Jubbada Hoose, Mudug, Nugaal, Sanaag, Shabeellaha Dhexe, Shabeellaha
Hoose, Sool, Togdheer, Woqooyi Galbeed
cattle, sheep, goats; bananas, sorghum, corn, coconuts,
rice, sugarcane, mangoes, sesame seeds, beans; fish
60 (2004 est.)
45.62 births/1,000 population (2005 est.)
A Somali National Army was attempted under the interim
government; numerous factions and clans maintain independent
militias, and the Somaliland and Puntland regional governments
maintain their own security and police forces
revenues: NA
expenditures: NA, including capital expenditures of NA','b10b971977b1d9ca358b8f21e03a0ba33d66c9f68837ac26947258c526916bc3','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('630ff485e98f8d39bd0336d168dbb00d04fc3c417dbb6422171941453572efab',2005,'ZA','South Africa','economy',623,'After the British seized the Cape of Good Hope area in
1806, many of the Dutch settlers (the Boers) trekked north to found
their own republics. The discovery of diamonds (1867) and gold
(1886) spurred wealth and immigration and intensified the
subjugation of the native inhabitants. The Boers resisted British
encroachments, but were defeated in the Boer War (1899-1902). The
resulting Union of South Africa operated under a policy of apartheid
- the separate development of the races. The 1990s brought an end to
apartheid politically and ushered in black majority rule.
total: 144
over 3,047 m: 10
2,438 to 3,047 m: 5
1,524 to 2,437 m: 51
914 to 1,523 m: 67
under 914 m: 11 (2004 est.)
total: 584
1,524 to 2,437 m: 34
914 to 1,523 m: 300
under 914 m: 250 (2004 est.)
lack of important arterial rivers or lakes requires
extensive water conservation and control measures; growth in water
usage outpacing supply; pollution of rivers from agricultural runoff
and urban discharge; air pollution resulting in acid rain; soil
erosion; desertification
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Southern Ocean
the Southern Ocean is subject to all international
agreements regarding the world''s oceans; in addition, it is subject
to these agreements specific to the Antarctic region: International
Whaling Commission (prohibits commercial whaling south of 40 degrees
south [south of 60 degrees south between 50 degrees and 130 degrees
west]); Convention on the Conservation of Antarctic Seals (limits
sealing); Convention on the Conservation of Antarctic Marine Living
Resources (regulates fishing)
note: many nations (including the US) prohibit mineral resource
exploration and exploitation south of the fluctuating Polar Front
(Antarctic Convergence) which is in the middle of the Antarctic
Circumpolar Current and serves as the dividing line between the very
cold polar surface waters to the south and the warmer waters to the
north
1.5% (2004)
202.6 billion kWh (2002)
189.4 billion kWh (2002)
7.873 billion kWh (2002)
6.95 billion kWh (2002)
50% (2000 est.)
lowest 10%: 1.1%
highest 10%: 45.9% (1994)
agriculture 30%, industry 25%, services 45% (1999 est.)
gold, diamonds, platinum, other metals and minerals,
machinery and equipment (1998 est.)
US 10.2%, UK 9.2%, Japan 9%, Germany 7.1%, Netherlands
4% (2004)
9 provinces; Eastern Cape, Free State, Gauteng,
KwaZulu-Natal, Limpopo, Mpumalanga, North-West, Northern Cape,
Western Cape
corn, wheat, sugarcane, fruits, vegetables; beef,
poultry, mutton, wool, dairy products
728 (2004 est.)
18.48 births/1,000 population (2005 est.)
South African National Defense Force (SANDF): Army,
Navy, Air Force, Joint Operations, Joint Support, Military
Intelligence, Military Health Service (2004)
revenues: $47.43 billion
expenditures: $52.54 billion, including capital expenditures of NA
(2004 est.)','ef0b03149e57480c83c5a084093152e782eb08b47dfee91284dc1cf3dd2c60f6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e04e36586dbac343114a1c3283399213578d9680b5586cbff03439b96d600626',2005,'GS','South Georgia and the South Sandwich Islands','economy',624,'The islands lie
approximately 1,000 km east of the Falkland Islands and have been
under British administration since 1908, except for a brief period
in 1982 when Argentina occupied them. Grytviken, on South Georgia,
was a 19th and early 20th century whaling station. Famed explorer
Ernest SHACKLETON stopped there in 1914 en route to his ill-fated
attempt to cross Antarctica on foot. He returned some 20 months
later with a few companions in a small boat and arranged a
successful rescue for the rest of his crew, stranded off the
Antarctic Peninsula. He died in 1922 on a subsequent expedition and
is buried in Grytviken. Today, the station houses scientists from
the British Antarctic Survey. The islands have large bird and seal
populations, and, recognizing the importance of preserving the
marine stocks in adjacent waters, the UK, in 1993, extended the
exclusive fishing zone from 12 nm to 200 nm around each island.
Southern Ocean
A decision by the International Hydrographic
Organization in the spring of 2000 delimited a fifth world ocean -
the Southern Ocean - from the southern portions of the Atlantic
Ocean, Indian Ocean, and Pacific Ocean. The Southern Ocean extends
from the coast of Antarctica north to 60 degrees south latitude,
which coincides with the Antarctic Treaty Limit. The Southern Ocean
is now the fourth largest of the world''s five oceans (after the
Pacific Ocean, Atlantic Ocean, and Indian Ocean, but larger than the
Arctic Ocean).
NA
Southern Ocean
increased solar ultraviolet radiation resulting from
the Antarctic ozone hole in recent years, reducing marine primary
productivity (phytoplankton) by as much as 15% and damaging the DNA
of some fish; illegal, unreported, and unregulated fishing in recent
years, especially the landing of an estimated five to six times more
Patagonian toothfish than the regulated fishery, which is likely to
affect the sustainability of the stock; large amount of incidental
mortality of seabirds resulting from long-line fishing for toothfish
note: the now-protected fur seal population is making a strong
comeback after severe overexploitation in the 18th and 19th centuries
none (2004 est.)','241cedea292114c6bd004f4208cb1ce90b2d45fcc8ba57ed9a491751165105e7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d218c5c866c3945e3535bc25a9bd191eb5ba187ecc646ee3429ef4f47031c50',2005,'ES','Spain','economy',625,'Spain''s powerful world empire of the 16th and 17th centuries
ultimately yielded command of the seas to England. Subsequent
failure to embrace the mercantile and industrial revolutions caused
the country to fall behind Britain, France, and Germany in economic
and political power. Spain remained neutral in World Wars I and II,
but suffered through a devastating civil war (1936-39). In the
second half of the 20th century, Spain has played a catch-up role in
the western international community; it joined the EU in 1986.
Continuing challenges include Basque Fatherland and Liberty (ETA)
terrorism and further reductions in unemployment.
Spratly Islands
The Spratly Islands consist of more than 100 small
islands or reefs. They are surrounded by rich fishing grounds and
potentially by gas and oil deposits. They are claimed in their
entirety by China, Taiwan, and Vietnam, while portions are claimed
by Malaysia and the Philippines. About 45 islands are occupied by
relatively small numbers of military forces from China, Malaysia,
the Philippines, Taiwan, and Vietnam. Brunei has established a
fishing zone that overlaps a southern reef, but has not made any
formal claim.
total: 95
over 3,047 m: 15
2,438 to 3,047 m: 10
1,524 to 2,437 m: 19
914 to 1,523 m: 23
under 914 m: 28 (2004 est.)
Spratly Islands
total: 2
914 to 1,523 m: 1
less than 914 m: 1 (2004 est.)
total: 61
1,524 to 2,437 m: 2
914 to 1,523 m: 15
under 914 m: 44 (2004 est.)
Spratly Islands
total: 1
914 to 1,523 m: 1 (2004 est.)
pollution of the Mediterranean Sea from raw sewage and
effluents from the offshore production of oil and gas; water quality
and quantity nationwide; air pollution; deforestation;
desertification
Spratly Islands
NA
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.2% (2003)
229 billion kWh (2002)
218.4 billion kWh (2002)
9.8 billion kWh (2002)
4.4 billion kWh (2002)
NA
lowest 10%: 2.8%
highest 10%: 25.2% (1990)
agriculture 5.3%, manufacturing, mining, and construction
30.1%, services 64.6% (2004 est.)
machinery, motor vehicles; foodstuffs, pharmaceuticals,
medicines, other consumer goods
France 19.3%, Germany 11.7%, Portugal 9.6%, UK 9%, Italy 9%,
US 4% (2004)
17 autonomous communities (comunidades autonomas, singular -
comunidad autonoma)and 2 autonomous cities* (ciudades autonomas,
singular - ciudad autonoma); Andalucia, Aragon, Asturias, Baleares
(Balearic Islands), Ceuta*, Canarias (Canary Islands), Cantabria,
Castilla-La Mancha, Castilla y Leon, Cataluna, Comunidad Valenciana,
Extremadura, Galicia, La Rioja, Madrid, Melilla*, Murcia, Navarra,
Pais Vasco (Basque Country)
note: the autonomous cities of Ceuta and Melilla plus three small
islands of Islas Chafarinas, Penon de Alhucemas, and Penon de Velez
de la Gomera, administered directly by the Spanish central
government, are all located off the coast of Morocco and are
collectively referred to as Places of Sovereignty (Plazas de
Soberania)
grain, vegetables, olives, wine grapes, sugar beets, citrus;
beef, pork, poultry, dairy products; fish
156 (2004 est.)
Spratly Islands
3 (2004 est.)
10.1 births/1,000 population (2005 est.)
Army, Navy, Air Force (Ejercito del Aire, EdA), Naval Infantry
revenues: $383.7 billion
expenditures: $386.4 billion, including capital expenditures of
$12.8 billion (2004 est.)','54b3fa51461d87cc5e5c9567f25a491108eee74f2ce45e2b72e16e8b95918c87','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91f0382a6d9abb25cc060a81b4adc6f865bf3df2d283c9c8b4dbca107f11fb92',2005,'LK','Sri Lanka','economy',626,'The Sinhalese arrived in Sri Lanka late in the 6th century
B.C., probably from northern India. Buddhism was introduced
beginning in about the mid-third century B.C., and a great
civilization developed at the cities of Anuradhapura (kingdom from
circa 200 B.C. to circa A.D. 1000) and Polonnaruwa (from about 1070
to 1200). In the 14th century, a south Indian dynasty seized power
in the north and established a Tamil kingdom. Occupied by the
Portuguese in the 16th century and by the Dutch in the 17th century,
the island was ceded to the British in 1796, became a crown colony
in 1802, and was united under British rule by 1815. As Ceylon, it
became independent in 1948; its name was changed to Sri Lanka in
1972. Tensions between the Sinhalese majority and Tamil separatists
erupted into war in 1983. Tens of thousands have died in an ethnic
conflict that continues to fester. After two decades of fighting,
the government and Liberation Tigers of Tamil Eelam formalized a
cease-fire in February 2002, with Norway brokering peace
negotiations.
total: 13
over 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 6 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
deforestation; soil erosion; wildlife populations
threatened by poaching and urbanization; coastal degradation from
mining activities and increased pollution; freshwater resources
being polluted by industrial wastes and sewage runoff; waste
disposal; air pollution in Colombo
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
2.6% (2004)
6.697 billion kWh (2002)
6.228 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
22% (1997 est.)
lowest 10%: 3.5%
highest 10%: 28% (1995)
agriculture 38%, industry 17%, services 45% (1998 est.)
textiles and apparel; tea and spices; diamonds, emeralds,
rubies; coconut products; rubber manufactures, fish
US 32.4%, UK 13.5%, India 6.8%, Germany 4.8% (2004)
8 provinces; Central, North Central, North Eastern, North
Western, Sabaragamuwa, Southern, Uva, Western; note - North Eastern
province may have been divided in two - Northern and Eastern
rice, sugarcane, grains, pulses, oilseed, spices, tea,
rubber, coconuts; milk, eggs, hides, beef
14 (2004 est.)
15.63 births/1,000 population (2005 est.)
Army, Navy, Air Force, Police Force
revenues: $3.34 billion
expenditures: $4.686 billion, including capital expenditures of NA
(2004 est.)','ba8f5885e137a4c6d80695219dd1023e5db51d67246eb4c0bc550f9db1ff9f45','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6da5ad976a4a96c0875dc29479a171577b6762d2d14b4e37c0397cfd65aab414',2005,'SD','Sudan','economy',627,'Military regimes favoring Islamic-oriented governments have
dominated national politics since independence from the UK in 1956.
Sudan was embroiled in two prolonged civil wars during most of the
remainder of the 20th century. These conflicts were rooted in
northern economic, political, and social domination of non-Muslim,
non-Arab southern Sudanese. The first civil war ended in 1972, but
broke out again in 1983. The second war and famine-related effects
resulted in more than 2 million deaths and over 4 million people
displaced over a period of two decades. Peace talks gained momentum
in 2002-04 with the signing of several accords; a final Naivasha
peace treaty of January 2005 granted the southern rebels autonomy
for six years, after which a referendum for independence is
scheduled to be held. A separate conflict that broke out in the
western region of Darfur in 2003 resulted in tens of thousands of
deaths and over 1 million displaced, but by early 2005, peackeeping
troops had stabilized the situation.
total: 12
over 3,047 m: 1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3 (2004 est.)
total: 63
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 17
914 to 1,523 m: 33
under 914 m: 11 (2004 est.)
inadequate supplies of potable water; wildlife populations
threatened by excessive hunting; soil erosion; desertification;
periodic drought
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Law of the Sea, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
3% (1999) (2004)
2.581 billion kWh (2002)
2.4 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
40% (2004 est.)
lowest 10%: NA
highest 10%: NA
agriculture 80%, industry and commerce 7%, government 13%
(1998 est.)
oil and petroleum products; cotton, sesame, livestock,
groundnuts, gum arabic, sugar
China 66.9%, Japan 10.7%, Saudi Arabia 4.4% (2004)
26 states (wilayat, singular - wilayah); A''ali an Nil (Upper
Nile), Al Bahr al Ahmar (Red Sea), Al Buhayrat (Lakes), Al Jazirah
(El Gezira), Al Khartum (Khartoum), Al Qadarif (Gedaref), Al Wahdah
(Unity), An Nil al Abyad (White Nile), An Nil al Azraq (Blue Nile),
Ash Shamaliyah (Northern), Bahr al Jabal (Bahr al Jabal), Gharb al
Istiwa''iyah (Western Equatoria), Gharb Bahr al Ghazal (Western Bahr
al Ghazal), Gharb Darfur (Western Darfur), Gharb Kurdufan (Western
Kordofan), Janub Darfur (Southern Darfur), Janub Kurdufan (Southern
Kordofan), Junqali (Jonglei), Kassala (Kassala), Nahr an Nil (Nile),
Shamal Bahr al Ghazal (Northern Bahr al Ghazal), Shamal Darfur
(Northern Darfur), Shamal Kurdufan (Northern Kordofan), Sharq al
Istiwa''iyah (Eastern Equatoria), Sinnar (Sinnar), Warab (Warab)
cotton, groundnuts (peanuts), sorghum, millet, wheat, gum
arabic, sugarcane, cassava (tapioca), mangos, papaya, bananas, sweet
potatoes, sesame; sheep, livestock
75 (2004 est.)
35.17 births/1,000 population (2005 est.)
Sudanese People''s Armed Forces (SPAF): Army, Navy, Air Force,
Popular Defense Force
revenues: $3.057 billion
expenditures: $2.965 billion, including capital expenditures of $304
million (2004 est.)','c34b3965b08461114f71940f9a5fea909fe1a91c2c778ce9bfae6c87c44ba81a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b856b3b0019d0317282903859ac2c00246260c813e638afbe091ff7600580ea5',2005,'SR','Suriname','economy',628,'Independence from the Netherlands was granted in 1975. Five
years later the civilian government was replaced by a military
regime that soon declared a socialist republic. It continued to rule
through a succession of nominally civilian administrations until
1987, when international pressure finally forced a democratic
election. In 1989, the military overthrew the civilian government,
but a democratically-elected government returned to power in 1991.
Svalbard
First discovered by the Norwegians in the 12th century, the
islands served as an international whaling base during the 17th and
18th centuries. Norway''s sovereignty was recognized in 1920; five
years later it officially took over the territory.
Swaziland
Autonomy for the Swazis of southern Africa was guaranteed
by the British in the late 19th century; independence was granted in
1968. Student and labor unrest during the 1990s pressured the
monarchy (one of the oldest on the continent) to grudgingly allow
political reform and greater democracy. Swaziland recently surpassed
Botswana as the country with the world''s highest known rates of
HIV/AIDS infection
total: 5
over 3,047 m: 1
under 914 m: 4 (2004 est.)
Svalbard
total: 2
1,524 to 2,437 m: 1
914 to 1523 m: 1 (2004 est.)
Swaziland
total: 1
2,438 to 3,047 m: 1 (2004 est.)
total: 41
1,524 to 2,437 m: 1
914 to 1,523 m: 5
under 914 m: 35 (2004 est.)
Svalbard
total: 2
under 914 m: 2 (2004 est.)
Swaziland
total: 17
914 to 1,523 m: 7
under 914 m: 10 (2004 est.)
deforestation as timber is cut for export; pollution of
inland waterways by small-scale mining activities
Svalbard
NA
Swaziland
limited supplies of potable water; wildlife populations
being depleted because of excessive hunting; overgrazing; soil
degradation; soil erosion
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
Swaziland
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Ozone Layer Protection
signed, but not ratified: Law of the Sea
0.7% (2003)
Swaziland
1.4% (2004)
1.984 billion kWh (2002)
Swaziland
402 million kWh (2002)
1.845 billion kWh (2002)
Swaziland
1.173 billion kWh (2002)
0 kWh (2002)
Swaziland
799 million kWh; note - electricity supplied by South
Africa (2002)
0 kWh (2002)
Swaziland
0 kWh (2002)
70% (2002 est.)
Swaziland
40% (1995)
lowest 10%: NA%
highest 10%: NA%
Swaziland
lowest 10%: 1%
highest 10%: 50.2% (1995)
agriculture NA%, industry NA%, services NA%
Swaziland
NA
alumina, crude oil, lumber, shrimp and fish, rice, bananas
Swaziland
soft drink concentrates, sugar, wood pulp, cotton yarn,
refrigerators, citrus and canned fruit
Norway 29.3%, US 15.1%, Canada 12.5%, Belgium 10.2%, France
8.4%, UAE 6.1%, Iceland 4.3% (2004)
Swaziland
South Africa 59.7%, EU 8.8%, US 8.8%, Mozambique 6.2%
(2004)
10 districts (distrikten, singular - distrikt); Brokopondo,
Commewijne, Coronie, Marowijne, Nickerie, Para, Paramaribo,
Saramacca, Sipaliwini, Wanica
Swaziland
4 districts; Hhohho, Lubombo, Manzini, Shiselweni
paddy rice, bananas, palm kernels, coconuts, plantains,
peanuts; beef, chickens; forest products; shrimp
Swaziland
sugarcane, cotton, corn, tobacco, rice, citrus,
pineapples, sorghum, peanuts; cattle, goats, sheep
46 (2004 est.)
Svalbard
4 (2004 est.)
Swaziland
18 (2004 est.)
18.39 births/1,000 population (2005 est.)
Svalbard
NA births/1,000 population
Swaziland
27.72 births/1,000 population (2005 est.)
National Army (includes small Navy and Air Force elements)
Swaziland
Umbutfo Swaziland Defense Force (USDF): Ground Force
(includes Air Wing), Royal Swaziland Police Force (RSPF) (2005)
revenues: $400 million
expenditures: $440 million, including capital expenditures of $34
million (2003)
Svalbard
revenues: $11.5 million
expenditures: $11.5 million, including capital expenditures of NA
(1998 est.)
Swaziland
revenues: $494.6 million
expenditures: $552.7 million, including capital expenditures of $147
million (2004 est.)','ad7cefbf28b4ae74c7b047c056c2b36c82a559c8a2b2c155cf2e39124b007f35','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5226bdb3b9a866ea3f6bf8986aea644d112e6f7d0d03d8c7162d883d2e4b7760',2005,'SE','Sweden','economy',629,'A military power during the 17th century, Sweden has not
participated in any war in almost two centuries. An armed neutrality
was preserved in both World Wars. Sweden''s long-successful economic
formula of a capitalist system interlarded with substantial welfare
elements was challenged in the 1990s by high unemployment and in
2000-02 by the global economic downturn, but fiscal discipline over
the past several years has allowed the country to weather economic
vagaries. Indecision over the country''s role in the political and
economic integration of Europe delayed Sweden''s entry into the EU
until 1995, and waived the introduction of the euro in 1999.
total: 154
over 3,047 m: 3
2,438 to 3,047 m: 12
1,524 to 2,437 m: 82
914 to 1,523 m: 22
under 914 m: 35 (2004 est.)
total: 100
914 to 1,523 m: 10
under 914 m: 90 (2004 est.)
acid rain damage to soils and lakes; pollution of the North
Sea and the Baltic Sea
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1.7% (2004)
142.8 billion kWh (2002)
138.1 billion kWh (2002)
20.1 billion kWh (2002)
14.8 billion kWh (2002)
NA
lowest 10%: 3.7%
highest 10%: 20.1% (1992)
agriculture 2%, industry 24%, services 74% (2000 est.)
machinery 35%, motor vehicles, paper products, pulp and wood,
iron and steel products, chemicals
US 10.7%, Germany 10.2%, Norway 8.6%, UK 7.8%, Denmark 6.7%,
Finland 5.7%, France 4.8%, Netherlands 4.8%, Belgium 4.5% (2004)
21 counties (lan, singular and plural); Blekinge, Dalarnas,
Gavleborgs, Gotlands, Hallands, Jamtlands, Jonkopings, Kalmar,
Kronobergs, Norrbottens, Orebro, Ostergotlands, Skane,
Sodermanlands, Stockholms, Uppsala, Varmlands, Vasterbottens,
Vasternorrlands, Vastmanlands, Vastra Gotalands
barley, wheat, sugar beets; meat, milk
254 (2004 est.)
10.36 births/1,000 population (2005 est.)
Army, Royal Swedish Navy (RSwN), Air Force (Flygvapnet)
revenues: $201.3 billion
expenditures: $199.6 billion, including capital expenditures of NA
(2004 est.)','ec1cfcea058ff36d7055a795e8edb11697b94a83b7df4c9efee54df2a5bf2b37','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc9eceaad26774a3433507f68131adea88abe2353f6ca6854f9d7f695f02db33',2005,'CH','Switzerland','economy',630,'The Swiss Confederation was founded in 1291 as a
defensive alliance among three cantons. In succeeding years, other
localities joined the original three. The Swiss Confederation
secured its independence from the Holy Roman Empire in 1499.
Switzerland''s sovreignty and neutrality have long been honored by
the major European powers, and the country was not involved in
either of the two World Wars. The political and economic integration
of Europe over the past half century, as well as Switzerland''s role
in many UN and international organizations, has strengthened
Switzerland''s ties with its neighbors. However, the country did not
officially become a UN member until 2002. Switzerland remains active
in many UN and international organizations, but retains a strong
commitment to neutrality.
Syria
Following the breakup of the Ottoman Empire during World War
I, Syria was administered by the French until independence in 1946.
In the 1967 Arab-Israeli War, Syria lost the Golan Heights to
Israel. Syrian troops - stationed in Lebanon since 1976 in an
ostensible peacekeeping role - were withdrawn in April of 2005. Over
the past decade, Syria and Israel have held occasional peace talks
over the return of the Golan Heights.
Taiwan
In 1895, military defeat forced China to cede Taiwan to
Japan. Taiwan reverted to Chinese control after World War II.
Following the Communist victory on the mainland in 1949, 2 million
Nationalists fled to Taiwan and established a government using the
1946 constitution drawn up for all of China. Over the next five
decades, the ruling authorities gradually democratized and
incorporated the native population within the governing structure.
In 2000, Taiwan underwent its first peaceful transfer of power from
the Nationalist to the Democratic Progressive Party. Throughout this
period, the island prospered and became one of East Asia''s economic
"Tigers." The dominant political issues continue to be the
relationship between Taiwan and China - specifically the question of
eventual unification - as well as domestic political and economic
reform.
total: 42
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 10
914 to 1,523 m: 8
under 914 m: 16 (2004 est.)
Syria
total: 26
over 3,047 m: 5
2,438 to 3,047 m: 16
914 to 1,523 m: 3
under 914 m: 2 (2004 est.)
Taiwan
total: 37
over 3,047 m: 8
2,438 to 3,047 m: 8
1,524 to 2,437 m: 12
914 to 1,523 m: 8
under 914 m: 1 (2004 est.)
total: 23
under 914 m: 23 (2004 est.)
Syria
total: 66
1,524 to 2,437 m: 2
914 to 1,523 m: 10
under 914 m: 54 (2004 est.)
Taiwan
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (2004 est.)
air pollution from vehicle emissions and open-air
burning; acid rain; water pollution from increased use of
agricultural fertilizers; loss of biodiversity
Syria
deforestation; overgrazing; soil erosion; desertification;
water pollution from raw sewage and petroleum refining wastes;
inadequate potable water
Taiwan
air pollution; water pollution from industrial emissions, raw
sewage; contamination of drinking water supplies; trade in
endangered species; low-level radioactive waste disposal
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-Volatile Organic
Compounds, Antarctic Treaty, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Marine Dumping, Marine
Life Conservation, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Law of the Sea
Syria
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental Modification
Taiwan
party to: none of the selected agreements because of Taiwan''s
international status
signed, but not ratified: none of the selected agreements because of
Taiwan''s international status
1% (FY01)
Syria
5.9% (FY00)
Taiwan
2.6% (2004)
63.47 billion kWh (2002)
Syria
26.15 billion kWh (2002)
Taiwan
158.5 billion kWh (2002)
54.53 billion kWh (2002)
Syria
24.32 billion kWh (2002)
Taiwan
147.4 billion kWh (2002)
27.8 billion kWh (2002)
Syria
0 kWh (2002)
Taiwan
0 kWh (2002)
32.3 billion kWh (2002)
Syria
0 kWh (2002)
Taiwan
0 kWh (2002)
NA
Syria
20% (2004 est.)
Taiwan
1% (2000 est.)
lowest 10%: 2.6%
highest 10%: 25.2% (1992)
Syria
lowest 10%: NA
highest 10%: NA
Taiwan
lowest 10%: 6.7%
highest 10%: 41.1% (2002 est.)
agriculture 4.6%, industry 26.3%, services 69.1% (1998)
Syria
agriculture 30%, industry 27%, services 43% (2002 est.)
Taiwan
agriculture 8%, industry 35%, services 57% (2001 est.)
machinery, chemicals, metals, watches, agricultural
products
Syria
crude oil, petroleum products, fruits and vegetables, cotton
fiber, clothing, meat and live animals, wheat
Taiwan
computer products and electrical equipment, metals, textiles,
plastics and rubber products, chemicals (2002)
Germany 20.2%, US 10.5%, France 8.7%, Italy 8.3%, UK
5.1%, Spain 4% (2004)
Syria
Italy 22.7%, France 18%, Turkey 12.9%, Iraq 9%, Saudi Arabia
6.2% (2004)
Taiwan
China, including Hong Kong 37%, US 16%, Japan 7.7% (2004)
26 cantons (cantons, singular - canton in French;
cantoni, singular - cantone in Italian; kantone, singular - kanton
in German); Aargau, Appenzell Ausser-Rhoden, Appenzell Inner-Rhoden,
Basel-Landschaft, Basel-Stadt, Bern, Fribourg, Geneve, Glarus,
Graubunden, Jura, Luzern, Neuchatel, Nidwalden, Obwalden, Sankt
Gallen, Schaffhausen, Schwyz, Solothurn, Thurgau, Ticino, Uri,
Valais, Vaud, Zug, Zurich
Syria
14 provinces (muhafazat, singular - muhafazah); Al Hasakah, Al
Ladhiqiyah, Al Qunaytirah, Ar Raqqah, As Suwayda'', Dar''a, Dayr az
Zawr, Dimashq, Halab, Hamah, Hims, Idlib, Rif Dimashq, Tartus
Taiwan
includes central island of Taiwan plus numerous smaller
islands near central island and off coast of China''s Fujian
Province; Taiwan is divided into 18 counties (hsien, singular and
plural), 5 municipalities (shih, singular and plural), and 2 special
municipalities (chuan-shih, singular and plural)
counties: Chang-hua, Chia-i, Hsin-chu, Hua-lien, I-lan, Kao-hsiung
county, Kin-men, Lien-chiang, Miao-li, Nan-t''ou, P''eng-hu,
P''ing-tung, T''ai-chung, T''ai-nan, T''ai-pei county, T''ai-tung,
T''ao-yuan, and Yun-lin
municipalities: Chia-i, Chi-lung, Hsin-chu, T''ai-chung, T''ai-nan
special municipalities: Kao-hsiung city, T''ai-pei city
note: Taiwan generally uses Wade-Giles system for romanization;
special municipality of Taipei adopted standard pinyin romanization
for street and place names within city boundaries, other local
authorities have selected a variety of romanization systems
grains, fruits, vegetables; meat, eggs
Syria
wheat, barley, cotton, lentils, chickpeas, olives, sugar
beets; beef, mutton, eggs, poultry, milk
Taiwan
rice, corn, vegetables, fruit, tea; pigs, poultry, beef,
milk; fish
65 (2004 est.)
Syria
92 (2004 est.)
Taiwan
40 (2004 est.)
9.77 births/1,000 population (2005 est.)
Syria
28.29 births/1,000 population (2005 est.)
Taiwan
12.64 births/1,000 population (2005 est.)
Land Forces, Swiss Air Force (Schweizer Luftwaffe)
Syria
Syrian Arab Army, Syrian Arab Navy, Syrian Arab Air Force
(includes Air Defense Command), Police and Security Force
Taiwan
Army, Navy (includes Marine Corps), Air Force, Coast Guard
Administration, Armed Forces Reserve Command, Combined Service
Forces Command, Armed Forces Police Command
revenues: $131.5 billion
expenditures: $140.4 billion, including capital expenditures of NA
(2004 est.)
Syria
revenues: $6.58 billion
expenditures: $9.45 billion, including capital expenditures of $4.67
billion (2004 est.)
Taiwan
revenues: $67.41 billion
expenditures: $76.7 billion, including capital expenditures of $14.4
billion (2004 est.)','19807d2610b748d238e91f30765f90cf4d3adccabcc24a7ec4b37fddd4265dfb','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48b741c133c60f7d090a3ef025b1ed5a8a0bc773b6df638a7f54ff0b72960f7b',2005,'TJ','Tajikistan','economy',631,'The Tajik people came under Russian rule in the 1860s and
1870s, but Russia''s hold on Central Asia weakened following the
Revolution of 1917. Bolshevik control of the area was fiercely
contested and not fully reestablished until 1925. Tajikistan became
independent in 1991 following the breakup of the Soviet Union and
has now completed its transition from the civil war that plagued the
country from 1992 to 1997. There have been no major security
incidents in recent years, although the country remains the poorest
in the region. Attention by the international community in the wake
of the war in Afghanistan has brought increased economic development
assistance, which could create jobs and increase stability in the
long term. Tajikistan is in the early stages of seeking World Trade
Organization membership and has joined NATO''s Partnership for Peace.
Tanzania
Shortly after independence, Tanganyika and Zanzibar merged
to form the nation of Tanzania in 1964. One-party rule came to an
end in 1995 with the first democratic elections held in the country
since the 1970s. Zanzibar''s semi-autonomous status and popular
opposition have led to two contentious elections since 1995, which
the ruling party won despite international observers'' claims of
voting irregularities.
total: 17
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 3
under 914 m: 3 (2004 est.)
Tanzania
total: 11
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 38
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 35 (2004 est.)
Tanzania
total: 112
1,524 to 2,437 m: 19
914 to 1,523 m: 60
under 914 m: 33 (2004 est.)
inadequate sanitation facilities; increasing levels of
soil salinity; industrial pollution; excessive pesticides
Tanzania
soil degradation; deforestation; desertification;
destruction of coral reefs threatens marine habitats; recent
droughts affected marginal agriculture; wildlife threatened by
illegal hunting and trade, especially for ivory
party to: Biodiversity, Climate Change, Desertification,
Environmental Modification, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Tanzania
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
3.9% (FY01)
Tanzania
0.2% (2004)
15.08 billion kWh (2002)
Tanzania
2.727 billion kWh (2002)
14.41 billion kWh (2002)
Tanzania
2.566 billion kWh (2002)
4.359 billion kWh (2002)
Tanzania
30 million kWh (2002)
3.974 billion kWh (2002)
Tanzania
0 kWh (2002)
60% (2004 est.)
Tanzania
36% (2002 est.)
lowest 10%: 3.2%
highest 10%: 25.2% (1998)
Tanzania
lowest 10%: 2.8%
highest 10%: 30.1% (1993)
agriculture 67.2%, industry 7.5%, services 25.3% (2000
est.)
Tanzania
agriculture 80%, industry and services 20% (2002 est.)
aluminum, electricity, cotton, fruits, vegetable oil,
textiles
Tanzania
gold, coffee, cashew nuts, manufactures, cotton
Netherlands 41.4%, Turkey 15.3%, Uzbekistan 7.2%, Latvia
7.1%, Switzerland 6.9%, Russia 6.6% (2004)
Tanzania
India 9.1%, Spain 8.3%, Netherlands 6.4%, Japan 5.8%, UK
5%, China 4.8%, Kenya 4.7% (2004)
2 provinces (viloyatho, singular - viloyat) and 1
autonomous province* (viloyati mukhtor); Viloyati Mukhtori Kuhistoni
Badakhshon* [Gorno-Badakhshan] (Khorugh), Viloyati Khatlon
(Qurghonteppa), Viloyati Sughd (Khujand)
note: the administrative center name follows in parentheses
Tanzania
26 regions; Arusha, Dar es Salaam, Dodoma, Iringa, Kagera,
Kigoma, Kilimanjaro, Lindi, Manyara, Mara, Mbeya, Morogoro, Mtwara,
Mwanza, Pemba North, Pemba South, Pwani, Rukwa, Ruvuma, Shinyanga,
Singida, Tabora, Tanga, Zanzibar Central/South, Zanzibar North,
Zanzibar Urban/West
cotton, grain, fruits, grapes, vegetables; cattle, sheep,
goats
Tanzania
coffee, sisal, tea, cotton, pyrethrum (insecticide made
from chrysanthemums), cashew nuts, tobacco, cloves, corn, wheat,
cassava (tapioca), bananas, fruits, vegetables; cattle, sheep, goats
55 (2004 est.)
Tanzania
123 (2004 est.)
32.58 births/1,000 population (2005 est.)
Tanzania
38.16 births/1,000 population (2005 est.)
Army, Air Force, Air Defense Force
Tanzania
Tanzanian People''s Defense Force (JWTZ): Army, Naval Wing,
Air Defense Command (includes Air Wing), National Service
revenues: $311.2 million
expenditures: $321.5 million, including capital expenditures of $86
million (2004 est.)
Tanzania
revenues: $1.985 billion
expenditures: $2.074 billion, including capital expenditures of NA
(2004 est.)','2605a39c42f48e7fd82d714852401599d93d55a70730e29faa69bb6965fe5694','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58fa9925a1032f081a9ddad7ffab21d8bf1fdbb301d40553815fcb6ccb1077f9',2005,'TH','Thailand','economy',632,'A unified Thai kingdom was established in the mid-14th
century. Known as Siam until 1939, Thailand is the only Southeast
Asian country never to have been taken over by a European power. A
bloodless revolution in 1932 led to a constitutional monarchy. In
alliance with Japan during World War II, Thailand became a US ally
following the conflict. Thailand is currently facing armed violence
in its three Muslim-majority southernmost provinces.
total: 65
over 3,047 m: 7
2,438 to 3,047 m: 10
1,524 to 2,437 m: 23
914 to 1,523 m: 19
under 914 m: 6 (2004 est.)
total: 44
1,524 to 2,437 m: 1
914 to 1,523 m: 15
under 914 m: 28 (2004 est.)
air pollution from vehicle emissions; water pollution from
organic and factory wastes; deforestation; soil erosion; wildlife
populations threatened by illegal hunting
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Life Conservation, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
1.8% (2003)
118.9 billion kWh (2003)
106.1 billion kWh (2003)
600 million kWh (2002)
188 million kWh (2002)
10% (2004 est.)
lowest 10%: 2.8%
highest 10%: 32.4% (1998)
agriculture 49%, industry 14%, services 37% (2000 est.)
textiles and footwear, fishery products, rice, rubber,
jewelry, automobiles, computers and electrical appliances
US 15.9%, Japan 13.9%, China 7.3%, Singapore 7.2%, Malaysia
5.4%, Hong Kong 5.1% (2004)
76 provinces (changwat, singular and plural); Amnat
Charoen, Ang Thong, Buriram, Chachoengsao, Chai Nat, Chaiyaphum,
Chanthaburi, Chiang Mai, Chiang Rai, Chon Buri, Chumphon, Kalasin,
Kamphaeng Phet, Kanchanaburi, Khon Kaen, Krabi, Krung Thep
Mahanakhon (Bangkok), Lampang, Lamphun, Loei, Lop Buri, Mae Hong
Son, Maha Sarakham, Mukdahan, Nakhon Nayok, Nakhon Pathom, Nakhon
Phanom, Nakhon Ratchasima, Nakhon Sawan, Nakhon Si Thammarat, Nan,
Narathiwat, Nong Bua Lamphu, Nong Khai, Nonthaburi, Pathum Thani,
Pattani, Phangnga, Phatthalung, Phayao, Phetchabun, Phetchaburi,
Phichit, Phitsanulok, Phra Nakhon Si Ayutthaya, Phrae, Phuket,
Prachin Buri, Prachuap Khiri Khan, Ranong, Ratchaburi, Rayong, Roi
Et, Sa Kaeo, Sakon Nakhon, Samut Prakan, Samut Sakhon, Samut
Songkhram, Sara Buri, Satun, Sing Buri, Sisaket, Songkhla,
Sukhothai, Suphan Buri, Surat Thani, Surin, Tak, Trang, Trat, Ubon
Ratchathani, Udon Thani, Uthai Thani, Uttaradit, Yala, Yasothon
rice, cassava (tapioca), rubber, corn, sugarcane, coconuts,
soybeans
109 (2004 est.)
15.7 births/1,000 population (2005 est.)
Royal Thai Army, Royal Thai Navy (includes Royal Thai
Marine Corps), Royal Thai Air Force
revenues: $30.86 billion
expenditures: $31.94 billion, including capital expenditures of $5
billion (2004 est.)','e611c7ae05ed25b66e8673cbc4ce86e419a118f739f278d535329a82602b1238','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fb82a3d6d64e36dac8b6f753b013716dd52ce39ca51c5b4adc598d2c9b71057',2005,'TK','Tokelau','economy',633,'Originally settled by Polynesian emigrants from surrounding
island groups, the Tokelau Islands were made a British protectorate
in 1889. They were transferred to New Zealand administration in 1925.
very limited natural resources and overcrowding are
contributing to emigration to New Zealand
NA kWh
NA kWh
NA
lowest 10%: NA
highest 10%: NA
stamps, copra, handicrafts
New Zealand (2000)
none (territory of New Zealand)
coconuts, copra, breadfruit, papayas, bananas; pigs,
poultry, goats
none; lagoon landings are possible by amphibious aircraft
(2004 est.)
NA
revenues: $430,800
expenditures: $2.8 million, including capital expenditures of
$37,300 (1987 est.)','52d03e3911ea960f6c91c2d713e1132b3dd383837c7f10770c3883dac79016aa','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05aa244ec1240756973bacbbaf444bab6804aeabc395892810587b3596e3cdba',2005,'TO','Tonga','economy',634,'The archipelago of "The Friendly Islands" was united into a
Polynesian kingdom in 1845. It became a constitutional monarchy in
1875 and a British protectorate in 1900. Tonga acquired its
independence in 1970 and became a member of the Commonwealth of
Nations. It remains the only monarchy in the Pacific.
total: 1
2,438 to 3,047 m: 1 (2004 est.)
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 1 (2004 est.)
deforestation results as more and more land is being cleared
for agriculture and settlement; some damage to coral reefs from
starfish and indiscriminate coral and shell collectors; overhunting
threatens native sea turtle populations
party to: Biodiversity, Climate Change, Desertification, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
NA
24.79 million kWh (2002)
23.06 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 65% (1997 est.)
squash, fish, vanilla beans, root crops
Japan 37.1%, China 18.7%, US 17.7%, Taiwan 8.7%, New Zealand
7.4% (2004)
3 island groups; Ha''apai, Tongatapu, Vava''u
squash, coconuts, copra, bananas, vanilla beans, cocoa,
coffee, ginger, black pepper; fish
6 (2004 est.)
25.18 births/1,000 population (2005 est.)
Tonga Defense Services: Ground Forces (Royal Marines, Royal
Guard), Maritime Force (includes Air Wing)
revenues: $39.9 million
expenditures: $52.4 million, including capital expenditures of $1.9
million (FY99/00 est.)','7c0f4d60a8e753757807993a5729b39a01c5006a0dbecb30d1fbb16dbd5eaee6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('211439469745df5027f2e4907409427cd15f5abf12e35bd94a4c0c99adc8a8e4',2005,'TT','Trinidad and Tobago','economy',635,'The islands came under British control in the
19th century; independence was granted in 1962. The country is one
of the most prosperous in the Caribbean thanks largely to petroleum
and natural gas production and processing. Tourism, mostly in
Tobago, is targeted for expansion and is growing.
Tromelin Island
First explored by the French in 1776, the island
came under the jurisdiction of Reunion in 1814. At present, it
serves as a sea turtle sanctuary and is the site of an important
meteorological station.
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2004 est.)
total: 3
914 to 1,523 m: 1
under 914 m: 2 (2004 est.)
Tromelin Island
total: 1
under 914 m: 1 (2004 est.)
water pollution from agricultural chemicals,
industrial wastes, and raw sewage; oil pollution of beaches;
deforestation; soil erosion
Tromelin Island
NA
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
0.6% (2003)
5.743 billion kWh (2002)
5.341 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
21% (1992 est.)
lowest 10%: NA
highest 10%: NA
agriculture 9.5%, manufacturing, mining, and
quarrying 14%, construction and utilities 12.4%, services 64.1%
(1997 est.)
petroleum and petroleum products, chemicals,
steel products, fertilizer, sugar, cocoa, coffee, citrus, flowers
US 67.1%, Jamaica 5.7%, France 3.5% (2004)
9 regional corporations, 2 city corporations, 3
borough corporations, and 1 ward
regional corporations: Couva/Tabaquite/Talparo, Diego Martin,
Mayaro/Rio Claro, Penal/Debe, Princes Town, Sangre Grande, San
Juan/Laventille, Siparia, Tunapuna/Piarco
city corporations: Port-of-Spain, San Fernando;
borough corporations: Arima, Point Fortin, Chaguanas
ward: Tobago
cocoa, rice, citrus, coffee, vegetables; poultry
6 (2004 est.)
Tromelin Island
1 (2004 est.)
12.81 births/1,000 population (2005 est.)
Trinidad and Tobago Defense Force: Ground Force,
Coast Guard (includes Air Wing) (2004)
revenues: $3.25 billion
expenditures: $3.193 billion, including capital expenditures of
$117.3 million (2004 est.)','580dbbdde40c564e3b6057d443bef5f555be975ccfbbede333fe95195ec34598','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('325220643b5fbfb61908f7c7d4a98a6ee72bddf227cb0f03bc7a951828a5ecbf',2005,'TN','Tunisia','economy',636,'Following independence from France in 1956, President Habib
BOURGUIBA established a strict one-party state. He dominated the
country for 31 years, repressing Islamic fundamentalism and
establishing rights for women unmatched by any other Arab nation. In
recent years, Tunisia has taken a moderate, non-aligned stance in
its foreign relations. Domestically, it has sought to defuse rising
pressure for a more open political society.
Turkey
Modern Turkey was founded in 1923 from the Anatolian remnants
of the defeated Ottoman Empire by national hero Mustafa KEMAL, who
was later honored with the title Ataturk, or "Father of the Turks."
Under his authoritarian leadership, the country adopted wide-ranging
social, legal, and political reforms. After a period of one-party
rule, an experiment with multi-party politics led to the 1950
election victory of the opposition Democratic Party and the peaceful
transfer of power. Since then, Turkish political parties have
multiplied, but democracy has been fractured by periods of
instability and intermittent military coups (1960, 1971, 1980),
which in each case eventually resulted in a return of political
power to civilians. In 1997, the military again helped engineer the
ouster - popularly dubbed a "post-modern coup" - of the then
Islamic-oriented government. Turkey intervened militarily on Cyprus
in 1974 to prevent a Greek takeover of the island and has since
acted as patron state to the "Turkish Republic of Northern Cyprus,"
which only Turkey recognizes. A separatist insurgency begun in 1984
by the Kurdistan Workers'' Party (PKK) - now known as the People''s
Congress of Kurdistan or Kongra-Gel (KGK) - has dominated the
Turkish military''s attention and claimed more than 30,000 lives, but
after the capture of the group''s leader in 1999, the insurgents
largely withdrew from Turkey, mainly to northern Iraq. In 2004, KGK
announced an end to its ceasefire and attacks attributed to the KGK
increased. Turkey joined the UN in 1945 and in 1952 it became a
member of NATO. In 1964, Turkey became an associate member of the
European Community; over the past decade, it has undertaken many
reforms to strengthen its democracy and economy, enabling it to
begin accession membership talks with the European Union.
total: 14
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 3 (2004 est.)
Turkey
total: 87
over 3,047 m: 16
2,438 to 3,047 m: 30
1,524 to 2,437 m: 20
914 to 1,523 m: 17
under 914 m: 4 (2004 est.)
total: 16
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 7 (2004 est.)
Turkey
total: 32
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 8
under 914 m: 20 (2004 est.)
toxic and hazardous waste disposal is ineffective and poses
health risks; water pollution from raw sewage; limited natural fresh
water resources; deforestation; overgrazing; soil erosion;
desertification
Turkey
water pollution from dumping of chemicals and detergents; air
pollution, particularly in urban areas; deforestation; concern for
oil spills from increasing Bosporus ship traffic
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Turkey
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species, Hazardous
Wastes, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification
1.5% (FY99)
Turkey
5.3% (2003)
10.72 billion kWh (2002)
Turkey
139.7 billion kWh (2003)
10.05 billion kWh (2002)
Turkey
117.9 billion kWh (2002)
90 million kWh (2002)
Turkey
3.6 billion kWh (2002)
10 million kWh (2002)
Turkey
433 million kWh (2002)
7.6% (2001 est.)
Turkey
20% (2002)
lowest 10%: 2.3%
highest 10%: 31.8% (1995)
Turkey
lowest 10%: 2.3%
highest 10%: 30.7% (2000)
services 55%, industry 23%, agriculture 22% (1995 est.)
Turkey
agriculture 35.9%, industry 22.8%, services 41.2% (3rd
quarter, 2004)
textiles, mechanical goods, phosphates and chemicals,
agricultural products, hydrocarbons
Turkey
apparel, foodstuffs, textiles, metal manufactures, transport
equipment
France 33.1%, Italy 25.3%, Germany 9.2%, Spain 6.1% (2004)
Turkey
Germany 13.9%, UK 8.8%, US 7.7%, Italy 7.4%, France 5.8%,
Spain 4.2% (2004)
24 governorates; Ariana (Aryanah), Beja (Bajah), Ben Arous
(Bin ''Arus), Bizerte (Banzart), Gabes (Qabis), Gafsa (Qafsah),
Jendouba (Jundubah), Kairouan (Al Qayrawan), Kasserine (Al Qasrayn),
Kebili (Qibili), Kef (Al Kaf), Mahdia (Al Mahdiyah), Manouba
(Manubah), Medenine (Madanin), Monastir (Al Munastir), Nabeul
(Nabul), Sfax (Safaqis), Sidi Bou Zid (Sidi Bu Zayd), Siliana
(Silyanah), Sousse (Susah), Tataouine (Tatawin), Tozeur (Tawzar),
Tunis, Zaghouan (Zaghwan)
Turkey
81 provinces (iller, singular - il); Adana, Adiyaman,
Afyonkarahisar, Agri, Aksaray, Amasya, Ankara, Antalya, Ardahan,
Artvin, Aydin, Balikesir, Bartin, Batman, Bayburt, Bilecik, Bingol,
Bitlis, Bolu, Burdur, Bursa, Canakkale, Cankiri, Corum, Denizli,
Diyarbakir, Duzce, Edirne, Elazig, Erzincan, Erzurum, Eskisehir,
Gaziantep, Giresun, Gumushane, Hakkari, Hatay, Igdir, Isparta,
Istanbul, Izmir, Kahramanmaras, Karabuk, Karaman, Kars, Kastamonu,
Kayseri, Kilis, Kirikkale, Kirklareli, Kirsehir, Kocaeli, Konya,
Kutahya, Malatya, Manisa, Mardin, Mersin, Mugla, Mus, Nevsehir,
Nigde, Ordu, Osmaniye, Rize, Sakarya, Samsun, Sanliurfa, Siirt,
Sinop, Sirnak, Sivas, Tekirdag, Tokat, Trabzon, Tunceli, Usak, Van,
Yalova, Yozgat, Zonguldak
olives, olive oil, grain, dairy products, tomatoes, citrus
fruit, beef, sugar beets, dates, almonds
Turkey
tobacco, cotton, grain, olives, sugar beets, pulse, citrus;
livestock
30 (2004 est.)
Turkey
119 (2004 est.)
15.5 births/1,000 population (2005 est.)
Turkey
16.83 births/1,000 population (2005 est.)
Army, Navy, Air Force (2003)
Turkey
Turkish Armed Forces (TSK): Land Forces, Naval Forces
(includes Naval Air and Naval Infantry), Air Force
revenues: $6.799 billion
expenditures: $7.573 billion, including capital expenditures of $1.6
billion (2004 est.)
Turkey
revenues: $78.53 billion
expenditures: $110.9 billion, including capital expenditures of NA
(2004 est.)','139e928f3a2555d487c30487a59c069ec3bb5dbad22895e08ea986b4864b88ef','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17f23aceae19e21a8d1670457a2db647853f169c8a3c7fa08eeacc4dbdda8914',2005,'TM','Turkmenistan','economy',637,'Annexed by Russia between 1865 and 1885, Turkmenistan
became a Soviet republic in 1924. It achieved its independence upon
the dissolution of the USSR in 1991. President NIYAZOV retains
absolute control over the country and opposition is not tolerated.
Extensive hydrocarbon/natural gas reserves could prove a boon to
this underdeveloped country if extraction and delivery projects were
to be expanded. The Turkmenistan Government is actively seeking to
develop alternative petroleum transportation routes in order to
break Russia''s pipeline monopoly.
total: 23
over 3,047 m: 1
2,438 to 3,047 m: 10
1,524 to 2,437 m: 9
914 to 1,523 m: 2
under 914 m: 1 (2004 est.)
total: 30
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 26 (2004 est.)
contamination of soil and groundwater with agricultural
chemicals, pesticides; salination, water-logging of soil due to poor
irrigation methods; Caspian Sea pollution; diversion of a large
share of the flow of the Amu Darya into irrigation contributes to
that river''s inability to replenish the Aral Sea; desertification
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous Wastes, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
3.4% (FY99)
11.41 billion kWh (2004 est.)
8.908 billion kWh (2002)
0 kWh (2002)
1.136 billion kWh (2004)
58% (2003 est.)
lowest 10%: 2.6%
highest 10%: 31.7% (1998)
agriculture 48.2%, industry 13.8%, services 37% (2003
est.)
gas, crude oil, petrochemicals, cotton fiber, textiles
Ukraine 46.6%, Iran 17.3%, Turkey 4.2%, Italy 4.1%
(2004)
5 provinces (welayatlar, singular - welayat): Ahal
Welayaty (Ashgabat), Balkan Welayaty (Balkanabat), Dashoguz
Welayaty, Lebap Welayaty (Turkmenabat), Mary Welayaty
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
cotton, grain; livestock
53 (2004 est.)
27.68 births/1,000 population (2005 est.)
Ground Forces, Air and Air Defense Forces (2004)
revenues: $3.05 billion
expenditures: $3.05 billion, including capital expenditures of NA
(2004 est.)','91d4447aad82b7fad83a2a89cf9d76276b105784c75ad285dafbeee819dff590','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c69d68292cc5baed52b5bb79cad58d5a238b95e6b48932407bb5e81493c4f77',2005,'TC','Turks and Caicos Islands','economy',638,'The islands were part of the UK''s Jamaican
colony until 1962, when they assumed the status of a separate crown
colony upon Jamaica''s independence. The governor of The Bahamas
oversaw affairs from 1965 to 1973. With Bahamian independence, the
islands received a separate governor in 1973. Although independence
was agreed upon for 1982, the policy was reversed and the islands
remain a British overseas territory.
total: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 2 (2004 est.)
total: 2
under 914 m: 2 (2004 est.)
limited natural fresh water resources,
private cisterns collect rainwater
5 million kWh (2002)
4.65 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA
highest 10%: NA
about 33% in government and 20% in
agriculture and fishing; significant numbers in tourism, financial,
and other services
lobster, dried and fresh conch, conch shells
US, UK
none (overseas territory of the UK)
corn, beans, cassava (tapioca), citrus
fruits; fish
8 (2004 est.)
22.23 births/1,000 population (2005 est.)
revenues: $47 million
expenditures: $33.6 million, including capital expenditures of NA
(1997-98 est.)','8486f04122ef1045c00e2e090f7105ade7e947870d05d49abfd511d1663793f4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa7ff35b41f4aa01fe9ecec843e7619371b9b57d16934ed08048f11028adb54a',2005,'TV','Tuvalu','economy',639,'In 1974, ethnic differences within the British colony of the
Gilbert and Ellice Islands caused the Polynesians of the Ellice
Islands to vote for separation from the Micronesians of the Gilbert
Islands. The following year, the Ellice Islands became the separate
British colony of Tuvalu. Independence was granted in 1978. In 2000,
Tuvalu negotiated a contract leasing its Internet domain name ".tv"
for $50 million in royalties over the next dozen years.
total: 1
1,524 to 2,437 m: 1 (2004 est.)
since there are no streams or rivers and groundwater is not
potable, most water needs must be met by catchment systems with
storage facilities (the Japanese Government has built one
desalination plant and plans to build one other); beachhead erosion
because of the use of sand for building materials; excessive
clearance of forest undergrowth for use as fuel; damage to coral
reefs from the spread of the Crown of Thorns starfish; Tuvalu is
very concerned about global increases in greenhouse gas emissions
and their effect on rising sea levels, which threaten the country''s
underground water table; in 2000, the government appealed to
Australia and New Zealand to take in Tuvaluans if rising sea levels
should make evacuation necessary
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: none of the selected agreements
NA
NA
lowest 10%: NA
highest 10%: NA
people make a living mainly through exploitation of the sea,
reefs, and atolls and from wages sent home by those abroad (mostly
workers in the phosphate industry and sailors)
copra, fish
Germany 56.5%, Fiji 14.3%, Italy 10.9%, UK 7.7%, Poland 4.9%
(2004)
none
coconuts; fish
1 (2004 est.)
21.91 births/1,000 population (2005 est.)
no regular military forces; national police force
revenues: $22.5 million
expenditures: $11.2 million, including capital expenditures of $4.2
million (2000 est.)','8ea748f180cd1003e57a7cf0b7bf808d9b71ffc1fbf69e62fa8e8f96f63bb3a7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd5140429b48474b587a97b0eef6c69016061d92caa76020c72493102178779a',2005,'UG','Uganda','economy',640,'Uganda achieved independence from the UK in 1962. The
dictatorial regime of Idi AMIN (1971-79) was responsible for the
deaths of some 300,000 opponents; guerrilla war and human rights
abuses under Milton OBOTE (1980-85) claimed at least another 100,000
lives. During the 1990s, the government promulgated non-party
presidential and legislative elections.
total: 4
over 3,047 m: 3
1,524 to 2,437 m: 1 (2004 est.)
total: 25
2,438 to 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 11
under 914 m: 7 (2004 est.)
draining of wetlands for agricultural use; deforestation;
overgrazing; soil erosion; water hyacinth infestation in Lake
Victoria; poaching is widespread
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Life Conservation, Ozone Layer Protection,
Wetlands
signed, but not ratified: Environmental Modification
2.2% (2004)
1.775 billion kWh (2002)
1.401 billion kWh (2002)
0 kWh (2002)
250 million kWh (2002)
35% (2001 est.)
lowest 10%: 4%
highest 10%: 21% (2000)
agriculture 82%, industry 5%, services 13% (1999 est.)
coffee, fish and fish products, tea; gold, cotton, flowers,
horticultural products
Kenya 15%, Netherlands 10.7%, Belgium 9%, France 4.4%,
Germany 4.4% (2004)
56 districts; Adjumani, Apac, Arua, Bugiri, Bundibugyo,
Bushenyi, Busia, Gulu, Hoima, Iganga, Jinja, Kabale, Kabarole,
Kaberamaido, Kalangala, Kampala, Kamuli, Kamwenge, Kanungu,
Kapchorwa, Kasese, Katakwi, Kayunga, Kibale, Kiboga, Kisoro, Kitgum,
Kotido, Kumi, Kyenjojo, Lira, Luwero, Masaka, Masindi, Mayuge,
Mbale, Mbarara, Moroto, Moyo, Mpigi, Mubende, Mukono, Nakapiripirit,
Nakasongola, Nebbi, Ntungamo, Pader, Pallisa, Rakai, Rukungiri,
Sembabule, Sironko, Soroti, Tororo, Wakiso, Yumbe
coffee, tea, cotton, tobacco, cassava (tapioca), potatoes,
corn, millet, pulses; beef, goat meat, milk, poultry, cut flowers
29 (2004 est.)
47.39 births/1,000 population (2005 est.)
Ugandan Peoples'' Defense Force (UPDF): Army, Marine Unit, Air
Wing
revenues: $1.491 billion
expenditures: $1.727 billion, including capital expenditures of NA
(2004 est.)','50a3ca8df32508be2c13609911e0cf986fd90af3b62b4d626718f3665b742594','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7d80079f528a0524e9d23fad570623a86d399caf53b402cbdc5430ada480d04',2005,'UA','Ukraine','economy',641,'Ukraine was the center of the first Slavic state, Kievan
Rus, which during the 10th and 11th centuries was the largest and
most powerful state in Europe. Weakened by internecine quarrels and
Mongol invasions, Kievan Rus was incorporated into the Grand Duchy
of Lithuania and eventually into the Polish-Lithuanian Commonwealth.
The cultural and religious legacy of Kievan Rus laid the foundation
for Ukrainian nationalism through subsequent centuries. A new
Ukrainian state, the Cossack Hetmanate, was established during the
mid-17th century after an uprising against the Poles. Despite
continuous Muscovite pressure, the Hetmanate managed to remain
autonomous for well over 100 years. During the latter part of the
18th century, most Ukrainian ethnographic territory was absorbed by
the Russian Empire. Following the collapse of czarist Russia in
1917, Ukraine was able to bring about a short-lived period of
independence (1917-20), but was reconquered and forced to endure a
brutal Soviet rule that engineered two artificial famines (1921-22
and 1932-33) in which over 8 million died. In World War II, German
and Soviet armies were responsible for some 7 to 8 million more
deaths. Although final independence for Ukraine was achieved in 1991
with the dissolution of the USSR, democracy remained elusive as the
legacy of state control and endemic corruption stalled efforts at
economic reform, privatization, and civil liberties. A peaceful mass
protest "Orange Revolution" in the closing months of 2004 forced the
authorities to overturn a rigged presidential election and to allow
a new internationally monitored vote that swept into power a
reformist slate under Viktor YUSHCHENKO. The new government presents
its citizens with hope that the country may at last attain true
freedom and prosperity.
total: 174
over 3,047 m: 13
2,438 to 3,047 m: 57
1,524 to 2,437 m: 30
914 to 1,523 m: 4
under 914 m: 70 (2004 est.)
total: 482
over 3,047 m: 3
2,438 to 3,047 m: 3
1,524 to 2,437 m: 14
914 to 1,523 m: 34
under 914 m: 428 (2004 est.)
inadequate supplies of potable water; air and water
pollution; deforestation; radiation contamination in the northeast
from 1986 accident at Chornobyl'' Nuclear Power Plant
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulfur 94, Air Pollution-Volatile Organic
Compounds
1.4% (FY02)
180 billion kWh (2003)
132 billion kWh (2003)
0 kWh (2002)
1.2 billion kWh (2002)
29% (2003 est.)
lowest 10%: 3.7%
highest 10%: 23.2% (1999)
agriculture 24%, industry 32%, services 44% (1996)
ferrous and nonferrous metals, fuel and petroleum products,
chemicals, machinery and transport equipment, food products
Russia 18%, Germany 5.8%, Turkey 5.7%, Italy 5%, US 4.6%
(2004)
24 provinces (oblasti, singular - oblast''), 1 autonomous
republic* (avtonomna respublika), and 2 municipalities (mista,
singular - misto) with oblast status**; Cherkasy, Chernihiv,
Chernivtsi, Crimea or Avtonomna Respublika Krym* (Simferopol''),
Dnipropetrovs''k, Donets''k, Ivano-Frankivs''k, Kharkiv, Kherson,
Khmel''nyts''kyy, Kirovohrad, Kiev (Kyyiv)**, Kyyiv, Luhans''k, L''viv,
Mykolayiv, Odesa, Poltava, Rivne, Sevastopol''**, Sumy, Ternopil'',
Vinnytsya, Volyn'' (Luts''k), Zakarpattya (Uzhhorod), Zaporizhzhya,
Zhytomyr
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
grain, sugar beets, sunflower seeds, vegetables; beef, milk
656 (2004 est.)
10.49 births/1,000 population (2005 est.)
Ground Forces, Naval Forces, Air Forces (Viyskovo-Povitryani
Syly), Air Defense Forces (2002)
revenues: $13.57 billion
expenditures: $12.26 billion, including capital expenditures of NA;
note - these estimates probably do not include the government''s
doubling of pensions in September of 2004 (2004 est.)','edd47104e094985b2acbcbdff6c6ea652546dff66f6a8b2983998114a4c3be82','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('304b6aca57bcfe4b1c033347252235ea0564ae2aba8332490be31bd85a96c502',2005,'AE','United Arab Emirates','economy',642,'The Trucial States of the Persian Gulf coast
granted the UK control of their defense and foreign affairs in 19th
century treaties. In 1971, six of these states - Abu Zaby, ''Ajman,
Al Fujayrah, Ash Shariqah, Dubayy, and Umm al Qaywayn - merged to
form the United Arab Emirates (UAE). They were joined in 1972 by
Ra''s al Khaymah. The UAE''s per capita GDP is on par with those of
leading West European nations. Its generosity with oil revenues and
its moderate foreign policy stance have allowed the UAE to play a
vital role in the affairs of the region.
total: 22
over 3,047 m: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 3 (2004 est.)
total: 13
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 4 (2004 est.)
lack of natural freshwater resources
compensated by desalination plants; desertification; beach pollution
from oil spills
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping, Ozone Layer Protection
signed, but not ratified: Law of the Sea
3.1% (FY00)
45.12 billion kWh (2004)
36.51 billion kWh (2002)
0 kWh (2004)
0 kWh (2004)
NA
lowest 10%: NA
highest 10%: NA
agriculture 7%, industry 15%, services 78%
(2000 est.)
crude oil 45%, natural gas, reexports, dried
fish, dates
Japan 24.9%, South Korea 9.9%, India 5.4%,
Thailand 5.2% (2004)
7 emirates (imarat, singular - imarah); Abu
Zaby (Abu Dhabi), ''Ajman, Al Fujayrah, Ash Shariqah (Sharjah),
Dubayy (Dubai), Ra''s al Khaymah, Umm al Qaywayn
dates, vegetables, watermelons; poultry, eggs,
dairy products; fish
35 (2004 est.)
18.78 births/1,000 population (2005 est.)
Army, Navy (includes Marines and Coast Guard),
Air and Air Defense Force, paramilitary forces (includes Federal
Police Force)
revenues: $23.68 billion
expenditures: $25.45 billion, including capital expenditures of $3.4
billion (2004 est.)','68cfc29de757cd5f6de74b1af1bd63494c6c1b8fd8e5b638bfebe3aaffcc2757','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cda18676b30c1179cb8b9bcebb383677b95fe7ce2dd87fc105cac3355030552',2005,'GB','United Kingdom','economy',643,'Great Britain, the dominant industrial and maritime
power of the 19th century, played a leading role in developing
parliamentary democracy and in advancing literature and science. At
its zenith, the British Empire stretched over one-fourth of the
earth''s surface. The first half of the 20th century saw the UK''s
strength seriously depleted in two World Wars. The second half
witnessed the dismantling of the Empire and the UK rebuilding itself
into a modern and prosperous European nation. As one of five
permanent members of the UN Security Council, a founding member of
NATO, and of the Commonwealth, the UK pursues a global approach to
foreign policy; it currently is weighing the degree of its
integration with continental Europe. A member of the EU, it chose to
remain outside the Economic and Monetary Union for the time being.
Constitutional reform is also a significant issue in the UK. The
Scottish Parliament, the National Assembly for Wales, and the
Northern Ireland Assembly were established in 1999, but the latter
is suspended due to bickering over the peace process.
total: 334
over 3,047 m: 8
2,438 to 3,047 m: 33
1,524 to 2,437 m: 150
914 to 1,523 m: 86
under 914 m: 57 (2004 est.)
total: 137
2438 to 3047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 23
under 914 m: 112 (2004 est.)
continues to reduce greenhouse gas emissions (has met
Kyoto Protocol target of a 12.5% reduction from 1990 levels and
intends to meet the legally binding target and move towards a
domestic goal of a 20% cut in emissions by 2010); by 2005 the
government aims to reduce the amount of industrial and commercial
waste disposed of in landfill sites to 85% of 1998 levels and to
recycle or compost at least 25% of household waste, increasing to
33% by 2015; between 1998-99 and 1999-2000, household recycling
increased from 8.8% to 10.3%
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulfur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
2.4% (2003)
395.9 billion kWh (2003)
337.4 billion kWh (2003)
5.119 billion kWh (2003)
2.959 billion kWh (2003)
17% (2002 est.)
lowest 10%: 2.1%
highest 10%: 28.5% (1999)
agriculture 1.5%, industry 19.1%, services 79.5%
(2004)
manufactured goods, fuels, chemicals; food,
beverages, tobacco
US 15.3%, Germany 10.8%, France 9.2%, Ireland 6.8%,
Netherlands 6%, Belgium 5.1%, Spain 4.5%, Italy 4.2% (2004)
England - 47 boroughs, 36 counties, 29 London
boroughs, 12 cities and boroughs, 10 districts, 12 cities, 3 royal
boroughs
boroughs: Barnsley, Blackburn with Darwen, Blackpool, Bolton,
Bournemouth, Bracknell Forest, Brighton and Hove, Bury, Calderdale,
Darlington, Doncaster, Dudley, Gateshead, Halton, Hartlepool,
Kirklees, Knowsley, Luton, Medway, Middlesbrough, Milton Keynes,
North Tyneside, Oldham, Poole, Reading, Redcar and Cleveland,
Rochdale, Rotherham, Sandwell, Sefton, Slough, Solihull,
Southend-on-Sea, South Tyneside, St. Helens, Stockport,
Stockton-on-Tees, Swindon, Tameside, Thurrock, Torbay, Trafford,
Walsall, Warrington, Wigan, Wirral, Wolverhampton
counties: Bedfordshire, Buckinghamshire, Cambridgeshire, Cheshire,
Cornwall, Cumbria, Derbyshire, Devon, Dorset, Durham, East Sussex,
Essex, Gloucestershire, Hampshire, Herefordshire, Hertfordshire,
Isle of Wight, Kent, Lancashire, Leicestershire, Lincolnshire,
Norfolk, Northamptonshire, Northumberland, North Yorkshire,
Nottinghamshire, Oxfordshire, Shropshire, Somerset, Staffordshire,
Suffolk, Surrey, Warwickshire, West Sussex, Wiltshire, Worcestershire
London boroughs: Barking and Dagenham, Barnet, Bexley, Brent,
Bromley, Camden, Croydon, Ealing, Enfield, Greenwich, Hackney,
Hammersmith and Fulham, Haringey, Harrow, Havering, Hillingdon,
Hounslow, Islington, Lambeth, Lewisham, Merton, Newham, Redbridge,
Richmond upon Thames, Southwark, Sutton, Tower Hamlets, Waltham
Forest, Wandsworth
cities and boroughs: Birmingham, Bradford, Coventry, Leeds,
Liverpool, Manchester, Newcastle upon Tyne, Salford, Sheffield,
Sunderland, Wakefield, Westminster
districts: Bath and North East Somerset, East Riding of Yorkshire,
North East Lincolnshire, North Lincolnshire, North Somerset,
Rutland, South Gloucestershire, Telford and Wrekin, West Berkshire,
Wokingham
cities: City of Bristol, Derby, City of Kingston upon Hull,
Leicester, City of London, Nottingham, Peterborough, Plymouth,
Portsmouth, Southampton, Stoke-on-Trent, York
royal boroughs: Kensington and Chelsea, Kingston upon Thames,
Windsor and Maidenhead
Northern Ireland - 24 districts, 2 cities, 6 counties
districts: Antrim, Ards, Armagh, Ballymena, Ballymoney, Banbridge,
Carrickfergus, Castlereagh, Coleraine, Cookstown, Craigavon, Down,
Dungannon, Fermanagh, Larne, Limavady, Lisburn, Magherafelt, Moyle,
Newry and Mourne, Newtownabbey, North Down, Omagh, Strabane
cities: Belfast, Derry
counties: County Antrim, County Armagh, County Down, County
Fermanagh, County Londonderry, County Tyrone
Scotland - 32 council areas: Aberdeen City, Aberdeenshire, Angus,
Argyll and Bute, The Scottish Borders, Clackmannanshire, Dumfries
and Galloway, Dundee City, East Ayrshire, East Dunbartonshire, East
Lothian, East Renfrewshire, City of Edinburgh, Falkirk, Fife,
Glasgow City, Highland, Inverclyde, Midlothian, Moray, North
Ayrshire, North Lanarkshire, Orkney Islands, Perth and Kinross,
Renfrewshire, Shetland Islands, South Ayrshire, South Lanarkshire,
Stirling, West Dunbartonshire, Eilean Siar (Western Isles), West
Lothian;
Wales - 11 county boroughs, 9 counties, 2 cities and counties
county boroughs: Blaenau Gwent, Bridgend, Caerphilly, Conwy,
Gwynedd, Merthyr Tydfil, Neath Port Talbot, Newport, Rhondda Cynon
Taff, Torfaen, Wrexham
counties: Isle of Anglesey, Ceredigion, Carmarthenshire,
Denbighshire, Flintshire, Monmouthshire, Pembrokeshire, Powys, The
Vale of Glamorgan
cities and counties: Cardiff, Swansea
cereals, oilseed, potatoes, vegetables; cattle,
sheep, poultry; fish
471 (2004 est.)
10.78 births/1,000 population (2005 est.)
Army, Royal Navy (includes Royal Marines), Royal Air
Force
revenues: $834.9 billion
expenditures: $896.7 billion, including capital expenditures of NA
(2004 est.)','3e3c8f932e234b86abf67ed83f8f1f0b3b6b31fcb57087d373133775fcdd33d3','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8009c434ebfe027c2cb02a12bfc3bb4ca510db82888c2f81082586830edc9678',2005,'US','United States','economy',644,'Britain''s American colonies broke with the mother
country in 1776 and were recognized as the new nation of the United
States of America following the Treaty of Paris in 1783. During the
19th and 20th centuries, 37 new states were added to the original 13
as the nation expanded across the North American continent and
acquired a number of overseas possessions. The two most traumatic
experiences in the nation''s history were the Civil War (1861-65) and
the Great Depression of the 1930s. Buoyed by victories in World Wars
I and II and the end of the Cold War in 1991, the US remains the
world''s most powerful nation state. The economy is marked by steady
growth, low unemployment and inflation, and rapid advances in
technology.
total: 5,128
over 3,047 m: 188
2,438 to 3,047 m: 221
1,524 to 2,437 m: 1,375
914 to 1,523 m: 2,383
under 914 m: 961 (2004 est.)
total: 9,729
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 160
914 to 1,523 m: 1,718
under 914 m: 7,843 (2004 est.)
air pollution resulting in acid rain in both the US
and Canada; the US is the largest single emitter of carbon dioxide
from the burning of fossil fuels; water pollution from runoff of
pesticides and fertilizers; limited natural fresh water resources in
much of the western part of the country require careful management;
desertification
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Antarctic-Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic Treaty, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Marine Dumping, Marine Life Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change-Kyoto Protocol, Hazardous Wastes
3.3% (FY03 est.) (February 2004)
3.839 trillion kWh (2002)
3.66 trillion kWh (2002)
36.23 billion kWh (2002)
13.36 billion kWh (2002)
12% (2004 est.)
lowest 10%: 1.8%
highest 10%: 30.5% (1997)
farming, forestry, and fishing 0.7%, manufacturing,
extraction, transportation, and crafts 22.7%, managerial,
professional, and technical 34.9%, sales and office 25.5%, other
services 16.3%
note: figures exclude the unemployed (2004)
agricultural products (soybeans, fruit, corn) 9.2%,
industrial supplies (organic chemicals) 26.8%, capital goods
(transistors, aircraft, motor vehicle parts, computers,
telecommunications equipment) 49.0%, consumer goods (automobiles,
medicines) 15.0% (2003)
Canada 23%, Mexico 13.6%, Japan 6.7%, UK 4.4%, China
4.3% (2004)
50 states and 1 district*; Alabama, Alaska, Arizona,
Arkansas, California, Colorado, Connecticut, Delaware, District of
Columbia*, Florida, Georgia, Hawaii, Idaho, Illinois, Indiana, Iowa,
Kansas, Kentucky, Louisiana, Maine, Maryland, Massachusetts,
Michigan, Minnesota, Mississippi, Missouri, Montana, Nebraska,
Nevada, New Hampshire, New Jersey, New Mexico, New York, North
Carolina, North Dakota, Ohio, Oklahoma, Oregon, Pennsylvania, Rhode
Island, South Carolina, South Dakota, Tennessee, Texas, Utah,
Vermont, Virginia, Washington, West Virginia, Wisconsin, Wyoming
wheat, corn, other grains, fruits, vegetables, cotton;
beef, pork, poultry, dairy products; forest products; fish
14,857 (2004 est.)
14.14 births/1,000 population (2005 est.)
Army, Navy and Marine Corps, Air Force, and Coast
Guard (Coast Guard administered in peacetime by the Department of
Homeland Security, but in wartime reports to the Department of the
Navy)
revenues: $1.862 trillion
expenditures: $2.338 trillion, including capital expenditures of NA
(2004 est.)','a7cc21631e3e8bff682bfa860f428a3660805354029a835f0597cd63a584c4f4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7974e7f3dc4f22085367920e0ffde688050b6c9438e1dc26a950914218084b96',2005,'UY','Uruguay','economy',645,'Montevideo, founded by the Spanish in 1726 as a military
stronghold, soon took advantage of its natural harbor to became an
important commercial center. Annexed by Brazil as a separate
province in 1821, Uruguay declared its independence four years later
and secured its freedom in 1828 after a three-year struggle. The
administrations of President BATLLE in the early 20th century
established widespread political, social, and economic reforms. A
violent Marxist urban guerrilla movement, the Tupamaros, launched in
the late 1960s, led Uruguay''s president to agree to military control
of his administration in 1973. By yearend, the rebels had been
crushed, but the military continued to expand its hold throughout
the government. Civilian rule was not restored until 1985. Uruguay''s
political and labor conditions are among the freest on the continent.
total: 14
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 6
under 914 m: 2 (2004 est.)
total: 50
1,524 to 2,437 m: 2
914 to 1,523 m: 17
under 914 m: 31 (2004 est.)
water pollution from meat packing/tannery industry;
inadequate solid/hazardous waste disposal
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping, Marine Life Conservation
2% (2004)
8.536 billion kWh (2003)
5.878 billion kWh (2003)
434.2 million kWh (2003)
954 million kWh (2003)
21% of households (2003)
lowest 10%: 3.7%
highest 10%: 25.8% (1997)
agriculture 14%, industry 16%, services 70%
meat, rice, leather products, wool, fish, dairy products
US 17.3%, Brazil 16%, Germany 6.3%, Argentina 6.2%, Mexico
4.2% (2004)
19 departments (departamentos, singular - departamento);
Artigas, Canelones, Cerro Largo, Colonia, Durazno, Flores, Florida,
Lavalleja, Maldonado, Montevideo, Paysandu, Rio Negro, Rivera,
Rocha, Salto, San Jose, Soriano, Tacuarembo, Treinta y Tres
rice, wheat, corn, barley; livestock; fish
64 (2004 est.)
14.09 births/1,000 population (2005 est.)
Army, Navy (includes Naval Air Arm, Marines, Maritime
Prefecture in wartime), Air Force
revenues: $3.332 billion
expenditures: $3.787 billion, including capital expenditures of $193
million (2004 est.)','32ca50b60c382c4e3d939a35becfefb28af032945d4cc7c4bc2556dfba1b6698','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bed0fd9916051f473e2e9be4d57b6e67dc3e68b123243ccf16e913b0332efe8',2005,'UZ','Uzbekistan','economy',646,'Russia conquered Uzbekistan in the late 19th century.
Stiff resistance to the Red Army after World War I was eventually
suppressed and a socialist republic set up in 1924. During the
Soviet era, intensive production of "white gold" (cotton) and grain
led to overuse of agrochemicals and the depletion of water supplies,
which have left the land poisoned and the Aral Sea and certain
rivers half dry. Independent since 1991, the country seeks to
gradually lessen its dependence on agriculture while developing its
mineral and petroleum reserves. Current concerns include terrorism
by Islamic militants, economic stagnation, and the curtailment of
human rights and democratization.
total: 33
over 3,047 m: 5
2,438 to 3,047 m: 14
1,524 to 2,437 m: 5
914 to 1,523 m: 5
under 914 m: 4 (2004 est.)
total: 193
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 187 (2004 est.)
shrinkage of the Aral Sea is resulting in growing
concentrations of chemical pesticides and natural salts; these
substances are then blown from the increasingly exposed lake bed and
contribute to desertification; water pollution from industrial
wastes and the heavy use of fertilizers and pesticides is the cause
of many human health disorders; increasing soil salination; soil
contamination from buried nuclear processing and agricultural
chemicals, including DDT
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
2% (FY97)
47.7 billion kWh (2002)
46.66 billion kWh (2002)
6.8 billion kWh (2002)
4.5 billion kWh (2002)
28% (2004 est.)
lowest 10%: 3.6%
highest 10%: 22% (2000)
agriculture 44%, industry 20%, services 36% (1995)
cotton 41.5%, gold 9.6%, energy products 9.6%, mineral
fertilizers, ferrous metals, textiles, food products, automobiles
(1998 est.)
Russia 22%, China 14.7%, Turkey 6.4%, Tajikistan 6.1%,
Kazakhstan 4.2%, Bangladesh 4% (2004)
12 provinces (viloyatlar, singular - viloyat), 1
autonomous republic* (respublika), and 1 city** (shahar); Andijon
Viloyati, Buxoro Viloyati, Farg''ona Viloyati, Jizzax Viloyati,
Namangan Viloyati, Navoiy Viloyati, Qashqadaryo Viloyati (Qarshi),
Qaraqalpog''iston Respublikasi* (Nukus), Samarqand Viloyati, Sirdaryo
Viloyati (Guliston), Surxondaryo Viloyati (Termiz), Toshkent
Shahri**, Toshkent Viloyati, Xorazm Viloyati (Urganch)
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
cotton, vegetables, fruits, grain; livestock
226 (2004 est.)
26.22 births/1,000 population (2005 est.)
Army, Air and Air Defense Forces, National Guard
revenues: $2.457 billion
expenditures: $2.482 billion, including capital expenditures of NA
(2004 est.)','38b6c93e67bc89475e78f79b78b3296cab6c9e6d3efb5dac51c6de39d563f8bc','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c34e024c4d3fcd4714a9bdffd1fe92081408d2c4530bcf9264c4f916c97832a',2005,'VU','Vanuatu','economy',647,'The British and French, who settled the New Hebrides in the
19th century, agreed in 1906 to an Anglo-French Condominium, which
administered the islands until independence in 1980.
Venezuela
Venezuela was one of three countries that emerged from the
collapse of Gran Colombia in 1830 (the others being Colombia and
Ecuador). For most of the first half of the 20th century, Venezuela
was ruled by generally benevolent military strongmen, who promoted
the oil industry and allowed for some social reforms. Democratically
elected governments have held sway since 1959. Current concerns
include: a polarized political environment, a politicized military,
drug-related violence along the Colombian border, increasing
internal drug consumption, overdependence on the petroleum industry
with its price fluctuations, and irresponsible mining operations
that are endangering the rain forest and indigenous peoples.
Vietnam
The conquest of Vietnam by France began in 1858 and was
completed by 1884. It became part of French Indochina in 1887.
Independence was declared after World War II, but the French
continued to rule until 1954 when they were defeated by Communist
forces under Ho Chi MINH, who took control of the North. US economic
and military aid to South Vietnam grew through the 1960s in an
attempt to bolster the government, but US armed forces were
withdrawn following a cease-fire agreement in 1973. Two years later,
North Vietnamese forces overran the South. Despite the return of
peace, for over two decades the country experienced little economic
growth because of conservative leadership policies. Since 2001,
Vietnamese authorities have committed to economic liberalization and
enacted structural reforms needed to modernize the economy and to
produce more competitive, export-driven industries. The country
continues to experience protests from the Montagnard ethnic minority
population of the Central Highlands over loss of land to Vietnamese
settlers and religious persecution.
Virgin Islands
During the 17th century, the archipelago was divided
into two territorial units, one English and the other Danish.
Sugarcane, produced by slave labor, drove the islands'' economy
during the 18th and early 19th centuries. In 1917, the US purchased
the Danish portion, which had been in economic decline since the
abolition of slavery in 1848.
Wake Island
The US annexed Wake Island in 1899 for a cable station.
An important air and naval base was constructed in 1940-41. In
December 1941, the island was captured by the Japanese and held
until the end of World War II. In subsequent years, Wake was
developed as a stopover and refueling site for military and
commercial aircraft transiting the Pacific. Since 1974, the island''s
airstrip has been used by the US military and some commercial cargo
planes, as well as for emergency landings. There are over 700
landings a year on the island.
total: 3
2,438 to 3,047 m: 1
1524 to 2437 m: 1
914 to 1,523 m: 1 (2004 est.)
Venezuela
total: 127
over 3,047 m: 5
2,438 to 3,047 m: 11
1,524 to 2,437 m: 31
914 to 1,523 m: 61
under 914 m: 19 (2004 est.)
Vietnam
total: 21
over 3,047 m: 6
2,438 to 3,047 m: 5
1,524 to 2,437 m: 9
914 to 1,523 m: 1 (2004 est.)
Virgin Islands
total: 2
1,524 to 2,437 m: 2 (2004 est.)
Wake Island
total: 1
2,438 to 3,047 m: 1 (2004 est.)
total: 27
914 to 1,523 m: 10
under 914 m: 17 (2004 est.)
Venezuela
total: 242
1,524 to 2,437 m: 10
914 to 1,523 m: 88
under 914 m: 144 (2004 est.)
Vietnam
total: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
a majority of the population does not have access to a
reliable supply of potable water; deforestation
Venezuela
sewage pollution of Lago de Valencia; oil and urban
pollution of Lago de Maracaibo; deforestation; soil degradation;
urban and industrial pollution, especially along the Caribbean
coast; threat to the rainforest ecosystem from irresponsible mining
operations
Vietnam
logging and slash-and-burn agricultural practices contribute
to deforestation and soil degradation; water pollution and
overfishing threaten marine life populations; groundwater
contamination limits potable water supply; growing urban
industrialization and population migration are rapidly degrading
environment in Hanoi and Ho Chi Minh City
Virgin Islands
lack of natural freshwater resources
Wake Island
NA
party to: Antarctic-Marine Living Resources, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 94
signed, but not ratified: none of the selected agreements
Venezuela
party to: Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Life Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed but not ratified:: none of the selected agreements
Vietnam
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
NA
Venezuela
1.5% (2004)
Vietnam
2.5% (FY98)
West Bank
NA
World
roughly 2% of gross world product (1999 est.)
48.42 million kWh (2002)
Venezuela
89.7 billion kWh (2003)
Vietnam
34.48 billion kWh (2002)
Virgin Islands
1.035 billion kWh (2002)
Wake Island
NA
45.03 million kWh (2002)
Venezuela
89.3 billion kWh (2003)
Vietnam
32.06 billion kWh (2002)
Virgin Islands
962.6 million kWh (2002)
0 kWh (2002)
Venezuela
30 million kWh (2003)
Vietnam
0 kWh (2002)
Virgin Islands
0 kWh (2002)
0 kWh (2002)
Venezuela
450 million kWh (2003)
Vietnam
0 kWh (2002)
Virgin Islands
0 kWh (2002)
NA
Venezuela
47% (1998 est.)
Vietnam
28.9% (2002 est.)
Virgin Islands
NA%
lowest 10%: NA
highest 10%: NA
Venezuela
lowest 10%: 0.8%
highest 10%: 36.5% (1998)
Vietnam
lowest 10%: 3.6%
highest 10%: 29.9% (1998)
Virgin Islands
lowest 10%: NA
highest 10%: NA
agriculture 65%, industry 5%, services 30% (2000 est.)
Venezuela
agriculture 13%, industry 23%, services 64% (1997 est.)
Vietnam
agriculture 63%, industry and services 37% (2000 est.)
Virgin Islands
agriculture 1%, industry 19%, services 80% (2003 est.)
copra, beef, cocoa, timber, kava, coffee
Venezuela
petroleum, bauxite and aluminum, steel, chemicals,
agricultural products, basic manufactures
Vietnam
crude oil, marine products, rice, coffee, rubber, tea,
garments, shoes
Virgin Islands
refined petroleum products
Thailand 47%, Malaysia 18.4%, Japan 7.5%, Belgium 5.4%,
China 4.9% (2004)
Venezuela
US 55.6%, Netherlands Antilles 4.7%, Dominican Republic
2.8% (2004)
Vietnam
US 20.2%, Japan 13.6%, China 9%, Australia 7%, Germany 5.9%,
Singapore 4.8%, UK 4.6% (2004)
Virgin Islands
US, Puerto Rico
6 provinces; Malampa, Penama, Sanma, Shefa, Tafea, Torba
Venezuela
23 states (estados, singular - estado), 1 federal
district* (distrito federal), and 1 federal dependency**
(dependencia federal); Amazonas, Anzoategui, Apure, Aragua, Barinas,
Bolivar, Carabobo, Cojedes, Delta Amacuro, Dependencias Federales**,
Distrito Federal*, Falcon, Guarico, Lara, Merida, Miranda, Monagas,
Nueva Esparta, Portuguesa, Sucre, Tachira, Trujillo, Vargas,
Yaracuy, Zulia
note: the federal dependency consists of 11 federally controlled
island groups with a total of 72 individual islands
Vietnam
59 provinces (tinh, singular and plural) and 5
municipalities (thu do, singular and plural)
provinces: An Giang, Bac Giang, Bac Kan, Bac Lieu, Bac Ninh, Ba
Ria-Vung Tau, Ben Tre, Binh Dinh, Binh Duong, Binh Phuoc, Binh
Thuan, Ca Mau, Cao Bang, Dac Lak, Dac Nong, Dien Bien, Dong Nai,
Dong Thap, Gia Lai, Ha Giang, Hai Duong, Ha Nam, Ha Tay, Ha Tinh,
Hau Giang, Hoa Binh, Hung Yen, Khanh Hoa, Kien Giang, Kon Tum, Lai
Chau, Lam Dong, Lang Son, Lao Cai, Long An, Nam Dinh, Nghe An, Ninh
Binh, Ninh Thuan, Phu Tho, Phu Yen, Quang Binh, Quang Nam, Quang
Ngai, Quang Ninh, Quang Tri, Soc Trang, Son La, Tay Ninh, Thai Binh,
Thai Nguyen, Thanh Hoa, Thua Thien-Hue, Tien Giang, Tra Vinh, Tuyen
Quang, Vinh Long, Vinh Phuc, Yen Bai
municipalities: Can Tho, Da Nang, Hai Phong, Hanoi, Ho Chi Minh
Virgin Islands
none (territory of the US); there are no first-order
administrative divisions as defined by the US Government, but there
are three islands at the second order; Saint Croix, Saint John,
Saint Thomas
copra, coconuts, cocoa, coffee, taro, yams, coconuts,
fruits, vegetables; fish, beef
Venezuela
corn, sorghum, sugarcane, rice, bananas, vegetables,
coffee; beef, pork, milk, eggs; fish
Vietnam
paddy rice, coffee, fish and seafood, rubber, cotton, tea,
pepper, soybeans, cashews, sugar cane, peanuts, bananas, poultry
Virgin Islands
fruit, vegetables, sorghum; Senepol cattle
30 (2004 est.)
Venezuela
369 (2004 est.)
Vietnam
24 (2004 est.)
Virgin Islands
2 (2004 est.)
Wake Island
1 (2004 est.)
23.06 births/1,000 population (2005 est.)
Venezuela
18.91 births/1,000 population (2005 est.)
Vietnam
17.07 births/1,000 population (2005 est.)
Virgin Islands
14.2 births/1,000 population (2005 est.)
no regular military forces; security forces comprise the
Vanuatu Police Force (VPF) and paramilitary Vanuatu Mobile Force
(VMF), which includes Vanuatu''s naval force, known as the Police
Maritime Wing (PMW); border security in Vanuatu is the joint
responsibility of the Customs and Inland Revenue Service, VPF, VMF,
and PMW (2003)
Venezuela
National Armed Forces (Fuerzas Armadas Nacionales, FAN):
Ground Forces or Army (Fuerzas Terrestres or Ejercito), Naval Forces
(Fuerzas Navales or Armada - includes Marines, Coast Guard), Air
Force (Fuerzas Aereas or Aviacion), Armed Forces of Cooperation or
National Guard (Fuerzas Armadas de Cooperacion or Guardia Nacional)
Vietnam
People''s Army of Vietnam: Ground Forces, People''s Navy
Command (includes Naval Infantry), Air and Air Defense Force, Coast
Guard
revenues: $52.6 million
expenditures: $54.3 million, including capital expenditures of
$700,000 (2003 est.)
Venezuela
revenues: $26.91 billion
expenditures: $30.7 billion, including capital expenditures of $2.6
billion (2004 est.)
Vietnam
revenues: $10.66 billion
expenditures: $13.09 billion, including capital expenditures of $1.8
billion (2004 est.)
Virgin Islands
revenues: $560
expenditures: NA (2003)','8e8ee61e8cdfa0b9667a7b364a6e35f4fca7ce622cacf9525eaefd0cdf9e1386','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('071348708af404fa6e4cb5b66fd12914c44cbea81968b4f81e5dba51f99ccb07',2005,'WF','Wallis and Futuna','economy',648,'Although discovered by the Dutch and the British
in the 17th and 18th centuries, it was the French who declared a
protectorate over the islands in 1842. In 1959, the inhabitants of
the islands voted to become a French overseas territory.
West Bank
The Israel-PLO Declaration of Principles on Interim
Self-Government Arrangements (the DOP), signed in Washington on 13
September 1993, provided for a transitional period not exceeding
five years of Palestinian interim self-government in the Gaza Strip
and the West Bank. Under the DOP, Israel agreed to transfer certain
powers and responsibilities to the Palestinian Authority, which
includes the Palestinian Legislative Council elected in January
1996, as part of the interim self-governing arrangements in the West
Bank and Gaza Strip. A transfer of powers and responsibilities for
the Gaza Strip and Jericho took place pursuant to the Israel-PLO 4
May 1994 Cairo Agreement on the Gaza Strip and the Jericho Area and
in additional areas of the West Bank pursuant to the Israel-PLO 28
September 1995 Interim Agreement, the Israel-PLO 15 January 1997
Protocol Concerning Redeployment in Hebron, the Israel-PLO 23
October 1998 Wye River Memorandum, and the 4 September 1999 Sharm
el-Sheikh Agreement. The DOP provides that Israel will retain
responsibility during the transitional period for external and
internal security and for public order of settlements and Israeli
citizens. Direct negotiations to determine the permanent status of
Gaza and West Bank that began in September 1999 after a three-year
hiatus, were derailed by a second intifadah that broke out in
September 2000. The resulting widespread violence in the West Bank
and Gaza Strip, Israel''s military response, and instability within
the Palestinian Authority continue to undermine progress toward a
permanent agreement. Following the death of longtime Palestinian
leader Yasir ARAFAT in November 2004, the election of his successor
Mahmud ABBAS in January 2005 could bring a turning point in the
conflict.
total: 1
1,524 to 2,437 m: 1 (2004 est.)
West Bank
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 1 (2004 est.)
total: 1
914 to 1,523 m: 1 (2004 est.)
deforestation (only small portions of the original
forests remain) largely as a result of the continued use of wood as
the main fuel source; as a consequence of cutting down the forests,
the mountainous terrain of Futuna is particularly prone to erosion;
there are no permanent settlements on Alofi because of the lack of
natural fresh water resources
West Bank
adequacy of fresh water supply; sewage treatment
NA kWh
West Bank
NA kWh; note - most electricity imported from Israel; East
Jerusalem Electric Company buys and distributes electricity to
Palestinians in East Jerusalem and its concession in the West Bank;
the Israel Electric Company directly supplies electricity to most
Jewish residents and military facilities; some Palestinian
municipalities, such as Nablus and Janin, generate their own
electricity from small power plants
NA kWh
West Bank
NA kWh
0 kWh (2002)
West Bank
NA kWh
0 kWh (2002)
NA%
West Bank
59% (2004 est.)
lowest 10%: NA%
highest 10%: NA%
West Bank
lowest 10%: NA
highest 10%: NA
agriculture, livestock, and fishing 80%,
government 4% (2001 est.)
West Bank
agriculture 15%, industry 25%, services 60% (2004 est.)
copra, chemicals, construction materials
West Bank
olives, fruit, vegetables, limestone
Italy 40%, Croatia 15%, US 14%, Denmark 13%
West Bank
Israel, Jordan, Gaza Strip (2000)
none (overseas territory of France); there are no
first-order administrative divisions as defined by the US
Government, but there are three kingdoms at the second order named
Alo, Sigave, Wallis
breadfruit, yams, taro, bananas; pigs, goats
West Bank
olives, citrus, vegetables; beef, dairy products
2 (2004 est.)
West Bank
3 (2004 est.)
NA births/1,000 population
West Bank
32.37 births/1,000 population (2005 est.)
revenues: $20 million
expenditures: $17 million, including capital expenditures of NA
(1998 est.)
West Bank
revenues: $676.6 million
expenditures: $1.155 billion, including capital expenditures of NA;
note - these budget data include Gaza Strip (2003)','f5b67be548fc54be9855a7d1f37aa3b4ed3ea87dfea5c9a80e542fa201d01830','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51314108db9fdfa3bcfe0e103c4c54c1bd314cdb19b222e22252a60582b77e6e',2005,'YE','Yemen','economy',649,'North Yemen became independent of the Ottoman Empire in 1918.
The British, who had set up a protectorate area around the southern
port of Aden in the 19th century, withdrew in 1967 from what became
South Yemen. Three years later, the southern government adopted a
Marxist orientation. The massive exodus of hundreds of thousands of
Yemenis from the south to the north contributed to two decades of
hostility between the states. The two countries were formally
unified as the Republic of Yemen in 1990. A southern secessionist
movement in 1994 was quickly subdued. In 2000, Saudi Arabia and
Yemen agreed to a delimitation of their border.
total: 16
over 3,047 m: 3
2,438 to 3,047 m: 9
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m: 11
under 914 m: 4 (2004 est.)
very limited natural fresh water resources; inadequate
supplies of potable water; overgrazing; soil erosion; desertification
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
7.8% (2003)
3.04 billion kWh (2002 est.)
2.827 billion kWh (2002 est.)
0 kWh (2002)
0 kWh (2002)
45.2% (2003)
lowest 10%: 3%
highest 10%: 25.9% (2003)
most people are employed in agriculture and herding; services,
construction, industry, and commerce account for less than
one-fourth of the labor force
crude oil, coffee, dried and salted fish
Thailand 33.8%, China 30.3%, Singapore 7.8% (2004)
19 governorates (muhafazat, singular - muhafazah); Abyan,
''Adan, Ad Dali'', Al Bayda'', Al Hudaydah, Al Jawf, Al Mahrah, Al
Mahwit, ''Amran, Dhamar, Hadramawt, Hajjah, Ibb, Lahij, Ma''rib,
Sa''dah, San''a'', Shabwah, Ta''izz
note: for electoral and administrative purposes, the capital city of
Sanaa is treated as an additional governorate
grain, fruits, vegetables, pulses, qat (mildly narcotic
shrub), coffee, cotton; dairy products, livestock (sheep, goats,
cattle, camels), poultry; fish
44 (2004 est.)
43.07 births/1,000 population (2005 est.)
Army (includes Special Forces), Naval Forces and Coastal
Defenses (includes Marines), Air Force (includes Air Defense
Forces), Republican Guard (2002)
revenues: $4.251 billion
expenditures: $4.568 billion, including capital expenditures of NA
(2004 est.)','003a55a1b9bad312b2a6f16eebd76be692ce59fdfe40f9ddf0d552f45498a12f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f7c58d8576d11cae7c7947d34717a1c098f7cbec87104b96624c7489f800b17',2005,'ZM','Zambia','economy',650,'The territory of Northern Rhodesia was administered by the
South Africa Company from 1891 until it was taken over by the UK in
1923. During the 1920s and 1930s, advances in mining spurred
development and immigration. The name was changed to Zambia upon
independence in 1964. In the 1980s and 1990s, declining copper
prices and a prolonged drought hurt the economy. Elections in 1991
brought an end to one-party rule, but the subsequent vote in 1996
saw blatant harassment of opposition parties. The election in 2001
was marked by administrative problems with three parties filing a
legal petition challenging the election of ruling party candidate
Levy MWANAWASA. The new president launched a far-reaching
anti-corruption campaign in 2002, which resulted in the prosecution
of former President Frederick CHILUBA and many of his supporters in
late 2003. Opposition parties currently hold a majority of seats in
the National Assembly.
total: 10
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2004 est.)
total: 99
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 62
under 914 m: 32 (2004 est.)
air pollution and resulting acid rain in the mineral
extraction and refining region; chemical runoff into watersheds;
poaching seriously threatens rhinoceros, elephant, antelope, and
large cat populations; deforestation; soil erosion; desertification;
lack of adequate water treatment presents human health risks
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
1.8% (2004)
8.167 billion kWh (2002)
5.345 billion kWh (2002)
0 kWh (2002)
2.25 billion kWh (2002)
86% (1993)
lowest 10%: 1.1%
highest 10%: 41% (1998)
agriculture 85%, industry 6%, services 9%
copper/cobalt 64%, cobalt, electricity, tobacco, flowers,
cotton
South Africa 25.6%, UK 17%, Switzerland 16%, Tanzania 7.4%,
Democratic Republic of the Congo 7%, Zimbabwe 5.8% (2004)
9 provinces; Central, Copperbelt, Eastern, Luapula, Lusaka,
Northern, North-Western, Southern, Western
corn, sorghum, rice, peanuts, sunflower seed, vegetables,
flowers, tobacco, cotton, sugarcane, cassava (tapioca); cattle,
goats, pigs, poultry, milk, eggs, hides; coffee
109 (2004 est.)
41.38 births/1,000 population (2005 est.)
Zambian National Defense Force (ZNDF): Army, Air Force,
Police, National Service
revenues: $1.129 billion
expenditures: $1.307 billion, including capital expenditures of NA
(2004 est.)','2f40cabf7cc029df86e681d29921b9c2a43a2cdf95d8bb7bfe1c686fbb0cf120','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a31e27d467d7b0e3e27bbef6b62ea5ba3cd44249fcd8f72dfc34d706d59f4afd',2005,'AF','Afghanistan','economy',651,'total: 10
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
under 914 m: 1 (2004 est.)
total: 37
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 14
914 to 1,523 m: 4
under 914 m: 11 (2004 est.)
limited natural fresh water resources; inadequate
supplies of potable water; soil degradation; overgrazing;
deforestation (much of the remaining forests are being cut down for
fuel and building materials); desertification; air and water
pollution
Akrotiri
shooting around the salt lake; note - breeding place for
loggerhead and green turtles; only remaining colony of griffon
vultures is on the base
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Marine Dumping
signed, but not ratified: Hazardous Wastes, Law of the Sea, Marine
Life Conservation
2.6% (2004)
540 million kWh (2002)
652.2 million kWh (2002)
150 million kWh (2002)
0 kWh (2002)
53% (2003)
lowest 10%: NA
highest 10%: NA
agriculture 80%, industry 10%, services 10% (2004 est.)
opium, fruits and nuts, handwoven carpets, wool, cotton,
hides and pelts, precious and semi-precious gems
Pakistan 24%, India 21.3%, US 12.4%, Germany 5.5% (2004)
34 provinces (velayat, singular - velayat); Badakhshan,
Badghis, Baghlan, Balkh, Bamian, Daykondi, Farah, Faryab, Ghazni,
Ghowr, Helmand, Herat, Jowzjan, Kabol, Kandahar, Kapisa, Khowst,
Konar, Kondoz, Laghman, Lowgar, Nangarhar, Nimruz, Nurestan,
Oruzgan, Paktia, Paktika, Panjshir, Parvan, Samangan, Sar-e Pol,
Takhar, Vardak, and Zabol
opium, wheat, fruits, nuts, wool, mutton, sheepskins,
lambskins
47 (2004 est.)
47.02 births/1,000 population (2005 est.)
Afghan National Army (includes Afghan Air Force), Afghan
Militia Force (AMF) (2005)
revenues: $300 million
expenditures: $609 million, including capital expenditures of NA
(FY04-05 budget)
Kabul
Akrotiri
Episkopi Cantonment; also serves as capital of Dhekelia','b9fda3c7e3a940aab035eb7b7fbe0c1511467204f6675004dab76f2746a86af9','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a08f6ec018124c00172ff17a1554657bce7eef454ee1efcd5d0152d917d884f',2005,'AL','Albania','economy',652,'total: 3
2,438 to 3,047 m: 3 (2004 est.)
total: 8
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 4 (2004 est.)
deforestation; soil erosion; water pollution from industrial
and domestic effluents
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
1.49% (FY02)
5.68 billion kWh (2004)
6.76 billion kWh (2004)
1.08 billion kWh (2004 est.)
100 million kWh (2002)
25% (2004 est.)
lowest 10%: NA
highest 10%: NA
agriculture 57%, non-agricultural private sector 20%, public
sector 23% (2004 est.)
textiles and footwear; asphalt, metals and metallic ores,
crude oil; vegetables, fruits, tobacco
Italy 71.7%, Canada 4.3%, Germany 4.3% (2004)
12 counties (qarqe, singular - qark); Qarku i Beratit, Qarku
i Dibres, Qarku i Durresit, Qarku i Elbasanit, Qarku i Fierit, Qarku
i Gjirokastres, Qarku i Korces, Qarku i Kukesit, Qarku i Lezhes,
Qarku i Shkodres, Qarku i Tiranes, Qarku i Vlores
wheat, corn, potatoes, vegetables, fruits, sugar beets,
grapes; meat, dairy products
11 (2004 est.)
15.08 births/1,000 population (2005 est.)
General Staff Headquarters, Land Forces Command (Army),
Naval Forces Command, Air Defense Command, Logistics Command,
Training and Doctrine Command
revenues: $2.05 billion
expenditures: $2.46 billion, including capital expenditures of $500
million (2004 est.)
Tirana','b143e662f5c0084098eba92c087b3c7b4743b57d282ae3c47474d3065d9f2ff8','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e12dd5266c4a1bebc5bf8a8760006b8fa3d743793da72a7a21a0044784c376ad',2005,'DZ','Algeria','economy',653,'total: 52
over 3,047 m: 10
2,438 to 3,047 m: 27
1,524 to 2,437 m: 10
914 to 1,523 m: 4
under 914 m: 1 (2004 est.)
total: 85
2,438 to 3,047 m: 2
1,524 to 2,437 m: 26
914 to 1,523 m: 38
under 914 m: 19 (2004 est.)
soil erosion from overgrazing and other poor farming
practices; desertification; dumping of raw sewage, petroleum
refining wastes, and other industrial effluents is leading to the
pollution of rivers and coastal waters; Mediterranean Sea, in
particular, becoming polluted from oil wastes, soil erosion, and
fertilizer runoff; inadequate supplies of potable water
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
3.2% (2004)
25.76 billion kWh (2002)
23.61 billion kWh (2002)
150 million kWh (2002)
500 million kWh (2002)
23% (1999 est.)
lowest 10%: 2.8%
highest 10%: 26.8% (1995)
agriculture 14%, industry 13.4%, construction and public
works 10%, trade 14.6%, government 32%, other 16% (2003 est.)
petroleum, natural gas, and petroleum products 97%
US 22.6%, Italy 17.2%, France 11.4%, Spain 10.1%, Canada
7.5%, Brazil 6.1%, Belgium 4.6% (2004)
48 provinces (wilayas, singular - wilaya); Adrar, Ain Defla,
Ain Temouchent, Alger, Annaba, Batna, Bechar, Bejaia, Biskra, Blida,
Bordj Bou Arreridj, Bouira, Boumerdes, Chlef, Constantine, Djelfa,
El Bayadh, El Oued, El Tarf, Ghardaia, Guelma, Illizi, Jijel,
Khenchela, Laghouat, Mascara, Medea, Mila, Mostaganem, M''Sila,
Naama, Oran, Ouargla, Oum el Bouaghi, Relizane, Saida, Setif, Sidi
Bel Abbes, Skikda, Souk Ahras, Tamanghasset, Tebessa, Tiaret,
Tindouf, Tipaza, Tissemsilt, Tizi Ouzou, Tlemcen
wheat, barley, oats, grapes, olives, citrus, fruits; sheep,
cattle
137 (2004 est.)
17.13 births/1,000 population (2005 est.)
People''s National Army (ANP; includes Land Forces), Algerian
National Navy (MRA), Air Force (QJJ), Territorial Air Defense Force
(2005)
revenues: $31.47 billion
expenditures: $29.3 billion, including capital expenditures of $5.8
billion (2004 est.)
Algiers','1e706beab01e78c32974820a1b78d977c8669b3b86eeed22a3ad0e4355fe0010','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f44527988ad84afd043947da39be2f884b51c3472aca406e067c210b8b479f5',2005,'AS','American Samoa','economy',654,'total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
limited natural fresh water resources; the water
division of the government has spent substantial funds in the past
few years to improve water catchments and pipelines
130 million kWh (2002)
120.9 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA%
highest 10%: NA%
tuna canneries 34%, government 33%, other 33% (1990)
canned tuna 93%
Samoa 39.8%, Australia 19.9%, Japan 15.1%, New
Zealand 10.5% (2004)
none (territory of the US); there are no first-order
administrative divisions as defined by the US Government, but there
are three districts and two islands* at the second order; Eastern,
Manu''a, Rose Island*, Swains Island*, Western
bananas, coconuts, vegetables, taro, breadfruit,
yams, copra, pineapples, papayas; dairy products, livestock
3 (2004 est.)
23.13 births/1,000 population (2005 est.)
revenues: $121 million (37% in local revenue and 63%
in US grants)
expenditures: $127 million, including capital expenditures of NA
(FY96/97)
Pago Pago','f257a7768dad8015f38b773034ac670b0228113d10c4858bd7319f0e93d87220','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d1289ccd8689eadfa2d9f2676d6d1746e16622545e34739505affba00140a9d',2005,'AO','Angola','economy',655,'total: 32
over 3,047 m: 4
2,438 to 3,047 m: 8
1,524 to 2,437 m: 14
914 to 1,523 m: 5
under 914 m: 1 (2004 est.)
total: 211
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 30
914 to 1,523 m: 95
under 914 m: 80 (2004 est.)
overuse of pastures and subsequent soil erosion attributable
to population pressures; desertification; deforestation of tropical
rain forest, in response to both international demand for tropical
timber and to domestic use as fuel, resulting in loss of
biodiversity; soil erosion contributing to water pollution and
siltation of rivers and dams; inadequate supplies of potable water
party to: Biodiversity, Climate Change, Desertification, Law
of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
10.6% (2004)
1.707 billion kWh (2002)
1.587 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
70% (2003 est.)
lowest 10%: NA
highest 10%: NA
agriculture 85%, industry and services 15% (2003 est.)
crude oil, diamonds, refined petroleum products, gas, coffee,
sisal, fish and fish products, timber, cotton
US 38%, China 35.9%, Taiwan 6.8%, France 6.5% (2004)
18 provinces (provincias, singular - provincia); Bengo,
Benguela, Bie, Cabinda, Cuando Cubango, Cuanza Norte, Cuanza Sul,
Cunene, Huambo, Huila, Luanda, Lunda Norte, Lunda Sul, Malanje,
Moxico, Namibe, Uige, Zaire
bananas, sugarcane, coffee, sisal, corn, cotton, manioc
(tapioca), tobacco, vegetables, plantains; livestock; forest
products; fish
243 (2004 est.)
44.64 births/1,000 population (2005 est.)
Army, Navy (Marinha de Guerra, MdG), Air and Air Defense
Forces (FANA)
revenues: $9.013 billion
expenditures: $9.562 billion, including capital expenditures of $963
million (2004 est.)
Luanda','ef8f6b339c005ade99e69a10b0fd8d6a898c09cb891230783efaa90256f18788','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1a406ee065678d0807ad9c01ee0b868311f3f64ad6b433952038957c971f4be',2005,'AI','Anguilla','economy',656,'total: 1
914 to 1,523 m: 1 (2004 est.)
total: 2
under 914 m: 2 (2004 est.)
supplies of potable water sometimes cannot meet increasing
demand largely because of poor distribution system
NA
42.6 million kWh
23% (2002)
lowest 10%: NA
highest 10%: NA
agriculture/fishing/forestry/mining 4%, manufacturing 3%,
construction 18%, transportation and utilities 10%, commerce 36%,
services 29% (2000 est.)
lobster, fish, livestock, salt, concrete blocks, rum
UK, US, Puerto Rico, Saint-Martin (2000)
none (overseas territory of the UK)
small quantities of tobacco, vegetables; cattle raising
3 (2004 est.)
14.26 births/1,000 population (2005 est.)
revenues: $22.8 million
expenditures: $22.5 million, including capital expenditures of NA
(2000 est.)
The Valley','b98ad0d7191987a70916daa9a556f8587e3f31ee2a47fa8f31e2a0e7709fd77e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dee2deb9c3241df6b8bf2fdaa282a8f4f50439add7e4429440b9707dd6bb40eb',2005,'AG','Antigua and Barbuda','economy',657,'total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
water management - a major concern because of
limited natural fresh water resources - is further hampered by the
clearing of trees to increase crop production, causing rainfall to
run off quickly
Arctic Ocean
endangered marine species include walruses and whales;
fragile ecosystem slow to change and slow to recover from
disruptions or damage; thinning polar icepack
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
NA
110.8 million kWh (2002)
103 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 7%, industry 11%, services 82% (1983)
petroleum products 48%, manufactures 23%,
machinery and transport equipment 17%, food and live animals 4%,
other 8%
Poland 47.8%, UK 24.6%, Germany 8.7% (2004)
6 parishes and 2 dependencies*; Barbuda*,
Redonda*, Saint George, Saint John, Saint Mary, Saint Paul, Saint
Peter, Saint Philip
cotton, fruits, vegetables, bananas, coconuts,
cucumbers, mangoes, sugarcane; livestock
3 (2004 est.)
17.26 births/1,000 population (2005 est.)
Royal Antigua and Barbuda Defense Force:
Infantry, Coast Guard (2004)
revenues: $123.7 million
expenditures: $145.9 million, including capital expenditures of NA
(2000 est.)
Saint John''s (Antigua)','289ebdaaa11556ba9ff2bca91e01b2f156de0da283b1e8e47c43a381e8ce3303','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f42efd75f47f38a5f8ebe0d0a8186f17e8ad57aa60606397aef6591d9aeae480',2005,'AR','Argentina','economy',658,'total: 144
over 3,047 m: 4
2,438 to 3,047 m: 26
1,524 to 2,437 m: 62
914 to 1,523 m: 44
under 914 m: 8 (2004 est.)
total: 1,190
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 50
914 to 1,523 m: 569
under 914 m: 567 (2004 est.)
environmental problems (urban and rural) typical of an
industrializing economy such as deforestation, soil degradation,
desertification, air pollution, and water pollution
note: Argentina is a world leader in setting voluntary greenhouse
gas targets
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
1.3% (FY00)
81.39 billion kWh (2002)
81.65 billion kWh (2002)
8.775 billion kWh (2002)
2.818 billion kWh (2002)
44.3% (June 2004)
lowest 10%: NA%
highest 10%: NA%
agriculture NA%, industry NA%, services NA%
edible oils, fuels and energy, cereals, feed, motor
vehicles
Brazil 15.3%, Chile 10.7%, US 10.2%, China 8.7%, Spain
4.4% (2004)
23 provinces (provincias, singular - provincia), and 1
autonomous city* (distrito federal); Buenos Aires, Buenos Aires
Capital Federal*, Catamarca, Chaco, Chubut, Cordoba, Corrientes,
Entre Rios, Formosa, Jujuy, La Pampa, La Rioja, Mendoza, Misiones,
Neuquen, Rio Negro, Salta, San Juan, San Luis, Santa Cruz, Santa Fe,
Santiago del Estero, Tierra del Fuego - Antartida e Islas del
Atlantico Sur, Tucuman
note: the US does not recognize any claims to Antarctica
sunflower seeds, lemons, soybeans, grapes, corn, tobacco,
peanuts, tea, wheat; livestock
1,334 (2004 est.)
16.9 births/1,000 population (2005 est.)
Argentine Army, Navy of the Argentine Republic (includes
Naval Aviation and Marines), Argentine Air Force (Fuerza Aerea
Argentina, FAA)
revenues: $29.15 billion
expenditures: $26.84 billion, including capital expenditures of NA
(2004 est.)
Buenos Aires','6175d33ead53765ca5e5a498b4ff0ed48228bea0c61068cac9cb30822e3cd005','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbc841e23835670c4342d45e775025766ef2419aa3cca099934106df2117e3d6',2005,'AM','Armenia','economy',659,'total: 11
over 3,047 m: 2
2,438 to 3,047: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2004 est.)
total: 5
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 1 (2004 est.)
soil pollution from toxic chemicals such as DDT; the energy
crisis of the 1990s led to deforestation when citizens scavenged for
firewood; pollution of Hrazdan (Razdan) and Aras Rivers; the
draining of Sevana Lich (Lake Sevan), a result of its use as a
source for hydropower, threatens drinking water supplies; restart of
Metsamor nuclear power plant in spite of its location in a
seismically active zone
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
6.5% (FY01)
6.492 billion kWh (2002)
5.797 billion kWh (2002)
463 million kWh; note - imports an unknown quantity from
Iran (2002)
704 million kWh; note - exports an unknown quantity to
Georgia; includes exports to Nagorno-Karabakh region in Azerbaijan
(2002)
50% (2002 est.)
lowest 10%: 2.3%
highest 10%: 46.2% (1999)
agriculture 45%, industry 25%, services 30% (2002 est.)
diamonds, mineral products, foodstuffs, energy
Belgium 18%, Israel 15.3%, Germany 13.3%, Russia 12.5%, US
8.1%, Netherlands 7.2%, Iran 5.5%, Georgia 4.3%, UAE 4% (2004)
11 provinces (marzer, singular - marz); Aragatsotn, Ararat,
Armavir, Geghark''unik'', Kotayk'', Lorri, Shirak, Syunik'', Tavush,
Vayots'' Dzor, Yerevan
fruit (especially grapes), vegetables; livestock
16 (2004 est.)
11.76 births/1,000 population (2005 est.)
Army, Air Force, Air Defense Force
revenues: $428.1 million
expenditures: $491.2 million, including capital expenditures of NA
(2004 est.)
Yerevan','c889514a0bcf6cbe5106b3f5257436ab307bfe1a3284fcb6f34bb455bcbd238b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe15137d688745eb1496ac0244fc27d9e349bc4c0bfb654121ea5c4b4cf49b3e',2005,'AW','Aruba','economy',660,'total: 1
2,438 to 3,047 m: 1 (2004 est.)
NA
Ashmore and Cartier Islands
NA
Atlantic Ocean
endangered marine species include the manatee, seals,
sea lions, turtles, and whales; drift net fishing is hastening the
decline of fish stocks and contributing to international disputes;
municipal sludge pollution off eastern US, southern Brazil, and
eastern Argentina; oil pollution in Caribbean Sea, Gulf of Mexico,
Lake Maracaibo, Mediterranean Sea, and North Sea; industrial waste
and municipal sewage pollution in Baltic Sea, North Sea, and
Mediterranean Sea
807.7 million kWh (2002)
751.2 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
most employment is in wholesale and retail trade and repair,
followed by hotels and restaurants; oil refining
live animals and animal products, art and collectibles,
machinery and electrical equipment, transport equipment
Netherlands 28.5%, Panama 17.5%, Venezuela 14.7%, Netherlands
Antilles 11.2%, Colombia 10.7%, US 10.4% (2004)
none (part of the Kingdom of the Netherlands)
aloes; livestock; fish
1 (2004 est.)
11.26 births/1,000 population (2005 est.)
no regular indigenous military forces; Royal Dutch Navy and
Marines, Coast Guard
revenues: $135.8 million
expenditures: $147 million, including capital expenditures of NA
(2000)
Oranjestad','1ed7562faa2197470678cde70ffd7b6824f93a3267ef305637dd5ac60fba9f15','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4f778e6445ac089b541d79b858c1810dec369c91f274982a04e10edcd1fea8d',2005,'AU','Australia','economy',661,'total: 305
over 3,047 m: 10
2,438 to 3,047 m: 12
1,524 to 2,437 m: 131
914 to 1,523 m: 139
under 914 m: 13 (2004 est.)
total: 143
1,524 to 2,437 m: 17
914 to 1,523 m: 112
under 914 m: 14 (2004 est.)
soil erosion from overgrazing, industrial development,
urbanization, and poor farming practices; soil salinity rising due
to the use of poor quality water; desertification; clearing for
agricultural purposes threatens the natural habitat of many unique
animal and plant species; the Great Barrier Reef off the northeast
coast, the largest coral reef in the world, is threatened by
increased shipping and its popularity as a tourist site; limited
natural fresh water resources
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
2.7% (2004)
210.3 billion kWh (2002)
195.6 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: 2%
highest 10%: 25.4% (1994)
agriculture 3.6%, industry 26.4%, services 70% (2004 est.)
coal, gold, meat, wool, alumina, iron ore, wheat,
machinery and transport equipment
Japan 18.6%, China 9.2%, US 8.1%, South Korea 7.7%, New
Zealand 7.4%, India 4.6%, UK 4.2% (2004)
6 states and 2 territories*; Australian Capital
Territory*, New South Wales, Northern Territory*, Queensland, South
Australia, Tasmania, Victoria, Western Australia
wheat, barley, sugarcane, fruits; cattle, sheep, poultry
448 (2004 est.)
12.26 births/1,000 population (2005 est.)
Australian Defense Force (ADF): Australian Army, Royal
Australian Navy, Royal Australian Air Force, Special Operations
Command
revenues: $222.7 billion
expenditures: $221.7 billion, including capital expenditures of NA
(2004 est.)
Canberra','40195d6bca9a90c5319be9d3d5ad93a3beb5eed9c63fc4b62f27bf3569012d41','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('262a7cbbddf0b549627fcb41811687c52b026cb41f754f0864e621ca22f5bd95',2005,'AT','Austria','economy',662,'total: 24
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 14 (2004 est.)
total: 31
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 27 (2004 est.)
some forest degradation caused by air and soil pollution;
soil pollution results from the use of agricultural chemicals; air
pollution results from emissions by coal- and oil-fired power
stations and industrial plants and from trucks transiting Austria
between northern and southern Europe
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the selected agreements
0.9% (2004)
58.49 billion kWh (2002)
55.09 billion kWh (2002)
15.4 billion kWh (2002)
14.7 billion kWh (2002)
3.9% (1999)
lowest 10%: 2.5%
highest 10%: 22.5% (1995)
agriculture and forestry 4%, industry and crafts 29%,
services 67% (2001 est.)
machinery and equipment, motor vehicles and parts, paper and
paperboard, metal goods, chemicals, iron and steel; textiles,
foodstuffs
Germany 32%, Italy 8.9%, US 6%, Switzerland 4.8%, France
4.2%, UK 4.2% (2004)
9 states (Bundeslaender, singular - Bundesland); Burgenland,
Kaernten, Niederoesterreich, Oberoesterreich, Salzburg, Steiermark,
Tirol, Vorarlberg, Wien (Vienna)
grains, potatoes, sugar beets, wine, fruit; dairy products,
cattle, pigs, poultry; lumber
55 (2004 est.)
8.81 births/1,000 population (2005 est.)
Land Forces (KdoLdSK), Air Forces (KdoLuSK)
revenues: $142.5 billion
expenditures: $146.4 billion, including capital expenditures of NA
(2004 est.)
Vienna','156d39b68883e5e179f628fcee46bfef156e661052caba52ba7de219cd4db267','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6a46a8ebc5a69da3ac59920ed2fa204ab7a9a23576c1ec83a0367ce9bf35d59',2005,'AZ','Azerbaijan','economy',663,'total: 27
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 15
914 to 1,523 m: 3
under 914 m: 1 (2004 est.)
Bahamas, The
total: 29
over 3,047 m: 2
2,438 to 3,047 m: 3
1,524 to 2,437 m: 14
914 to 1,523 m: 9
under 914 m: 1 (2004 est.)
total: 23
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 6
under 914 m: 15 (2004 est.)
Bahamas, The
total: 34
1,524 to 2,437 m: 3
914 to 1,523 m: 10
under 914 m: 21 (2004 est.)
local scientists consider the Abseron Yasaqligi (Apsheron
Peninsula) (including Baku and Sumqayit) and the Caspian Sea to be
the ecologically most devastated area in the world because of severe
air, soil, and water pollution; soil pollution results from oil
spills, from the use of DDT as a pesticide, and from toxic
defoliants used in the production of cotton
Bahamas, The
coral reef decay; solid waste disposal
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Bahamas, The
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
2.6% (FY99)
Bahamas, The
NA
17.55 billion kWh (2002)
Bahamas, The
1.716 billion kWh (2002)
17.37 billion kWh (2002)
Bahamas, The
1.596 billion kWh (2002)
1.558 billion kWh (2002)
Bahamas, The
0 kWh (2002)
505 million kWh (2002)
Bahamas, The
0 kWh (2002)
49% (2002 est.)
Bahamas, The
NA
lowest 10%: 2.8%
highest 10%: 27.8% (1995)
Bahamas, The
lowest 10%: NA
highest 10%: 27% (2000)
agriculture and forestry 41%, industry 7%, services 52%
(2001)
Bahamas, The
agriculture 5%, industry 5%, tourism 50%, other
services 40% (1999 est.)
oil and gas 90%, machinery, cotton, foodstuffs
Bahamas, The
mineral products and salt, animal products, rum,
chemicals; fruit and vegetables
Italy 26.6%, Czech Republic 11.9%, Germany 8.1%,
Indonesia 6.4%, Romania 6.2%, Georgia 6%, Russia 5.3%, Turkey 5.2%,
France 4.1% (2004)
Bahamas, The
US 40.2%, Poland 13.3%, Spain 11.6%, Germany 5.9%,
France 4.3% (2004)
59 rayons (rayonlar; rayon - singular), 11 cities*
(saharlar; sahar - singular), 1 autonomous republic** (muxtar
respublika)
rayons: Abseron Rayonu, Agcabadi Rayonu, Agdam Rayonu, Agdas Rayonu,
Agstafa Rayonu, Agsu Rayonu, Astara Rayonu, Balakan Rayonu, Barda
Rayonu, Beylaqan Rayonu, Bilasuvar Rayonu, Cabrayil Rayonu,
Calilabad Rayonu, Daskasan Rayonu, Davaci Rayonu, Fuzuli Rayonu,
Gadabay Rayonu, Goranboy Rayonu, Goycay Rayonu, Haciqabul Rayonu,
Imisli Rayonu, Ismayilli Rayonu, Kalbacar Rayonu, Kurdamir Rayonu,
Lacin Rayonu, Lankaran Rayonu, Lerik Rayonu, Masalli Rayonu,
Neftcala Rayonu, Oguz Rayonu, Qabala Rayonu, Qax Rayonu, Qazax
Rayonu, Qobustan Rayonu, Quba Rayonu, Qubadli Rayonu, Qusar Rayonu,
Saatli Rayonu, Sabirabad Rayonu, Saki Rayonu, Salyan Rayonu, Samaxi
Rayonu, Samkir Rayonu, Samux Rayonu, Siyazan Rayonu, Susa Rayonu,
Tartar Rayonu, Tovuz Rayonu, Ucar Rayonu, Xacmaz Rayonu, Xanlar
Rayonu, Xizi Rayonu, Xocali Rayonu, Xocavand Rayonu, Yardimli
Rayonu, Yevlax Rayonu, Zangilan Rayonu, Zaqatala Rayonu, Zardab
Rayonu
cities: Ali Bayramli Sahari, Baki Sahari, Ganca Sahari, Lankaran
Sahari, Mingacevir Sahari, Naftalan Sahari, Saki Sahari, Sumqayit
Sahari, Susa Sahari, Xankandi Sahari, Yevlax Sahari
autonomous republic: Naxcivan Muxtar Respublikasi
Bahamas, The
21 districts; Acklins and Crooked Islands, Bimini, Cat
Island, Exuma, Freeport, Fresh Creek, Governor''s Harbour, Green
Turtle Cay, Harbour Island, High Rock, Inagua, Kemps Bay, Long
Island, Marsh Harbour, Mayaguana, New Providence, Nichollstown and
Berry Islands, Ragged Island, Rock Sound, Sandy Point, San Salvador
and Rum Cay
cotton, grain, rice, grapes, fruit, vegetables, tea,
tobacco; cattle, pigs, sheep, goats
Bahamas, The
citrus, vegetables; poultry
50 (2004 est.)
Bahamas, The
63 (2004 est.)
20.4 births/1,000 population (2005 est.)
Bahamas, The
17.87 births/1,000 population (2005 est.)
Army, Navy, Air and Air Defense Forces
Bahamas, The
Royal Bahamaian Defense Force (naval forces) (2004)
revenues: $2.715 billion
expenditures: $2.801 billion, including capital expenditures of NA
(2004 est.)
Bahamas, The
revenues: $1 billion
expenditures: $1 billion, including capital expenditures of $106.7
million (FY03/04)
Baku (Baki)
Bahamas, The
Nassau','6f22a0eba85462d98fbd29d4e98b343b5d1f83b1d4fb31e12f67baaf75eef255','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('486a467707cc61c864480f0448078b2d1c1c389ae2aaf2cc10b51e8b5a41e0a4',2005,'BH','Bahrain','economy',664,'total: 3
over 3,047 m: 2
1524 to 2437 m: 1 (2004 est.)
total: 1
1,524 to 2,437 m: 1 (2004 est.)
desertification resulting from the degradation of limited
arable land, periods of drought, and dust storms; coastal
degradation (damage to coastlines, coral reefs, and sea vegetation)
resulting from oil spills and other discharges from large tankers,
oil refineries, and distribution stations; lack of freshwater
resources, groundwater and seawater are the only sources for all
water needs
Baker Island
no natural fresh water resources
party to: Biodiversity, Climate Change, Desertification,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
6.3% (2004)
6.86 billion kWh (2002)
6.379 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 1%, industry, commerce, and services 79%,
government 20% (1997 est.)
petroleum and petroleum products, aluminum, textiles
Saudi Arabia 3%, US 2.9%, UAE 2.2% (2004)
12 municipalities (manatiq, singular - mintaqah); Al Hadd,
Al Manamah, Al Mintaqah al Gharbiyah, Al Mintaqah al Wusta, Al
Mintaqah ash Shamaliyah, Al Muharraq, Ar Rifa'' wa al Mintaqah al
Janubiyah, Jidd Hafs, Madinat Hamad, Madinat ''Isa, Juzur Hawar,
Sitrah
note: all municipalities administered from Manama
fruit, vegetables; poultry, dairy products; shrimp, fish
4 (2004 est.)
Baker Island
1 abandoned World War II runway of 1,665 m, completely
covered with vegetation and unusable (2004 est.)
18.1 births/1,000 population (2005 est.)
Bahrain Defense Forces (BDF): Ground Force (includes Air
Defense), Navy, Air Force, National Guard
revenues: $3.825 billion
expenditures: $3.262 billion, including capital expenditures of $700
million (2004 est.)
Manama','d8482c0abc7d8845137d682efd3b5cb99b69f6483f61deb07a57915f1862a09d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de1c582c61f331f6aab3ca9c1c87e5c819f637ed7e092f0fea379747c7e76dce',2005,'BD','Bangladesh','economy',665,'total: 15
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 6 (2004 est.)
total: 1
1,524 to 2,437 m: 1 (2004 est.)
many people are landless and forced to live on and
cultivate flood-prone land; water-borne diseases prevalent in
surface water; water pollution, especially of fishing areas, results
from the use of commercial pesticides; ground water contaminated by
naturally occurring arsenic; intermittent water shortages because of
falling water tables in the northern and central parts of the
country; soil degradation and erosion; deforestation; severe
overpopulation
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
1.8% (2004)
16.45 billion kWh (2002)
15.3 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
45% (2004 est.)
lowest 10%: 3.9%
highest 10%: 28.6% (1995-96 est.)
agriculture 63%, industry 11%, services 26% (FY95/96)
garments, jute and jute goods, leather, frozen fish and
seafood (2001)
US 22.4%, Germany 14.5%, UK 11.2%, France 6.9%, Italy 4%
(2004)
6 divisions; Barisal, Chittagong, Dhaka, Khulna,
Rajshahi, and Sylhet
rice, jute, tea, wheat, sugarcane, potatoes, tobacco,
pulses, oilseeds, spices, fruit; beef, milk, poultry
16 (2004 est.)
30.01 births/1,000 population (2005 est.)
Army, Navy, Air Force
revenues: $5.921 billion
expenditures: $8.262 billion, including capital expenditures of NA
(2004 est.)
Dhaka','8854bba0b19cf215b721e55186befdb98c4bc9597d5ecb01d8f2495bea2c9eb0','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('283a44fc77c9f02d96f111e3c8a514af3ee1f37016917dad0761510d13445a8b',2005,'BB','Barbados','economy',666,'total: 1
over 3,047 m: 1 (2004 est.)
pollution of coastal waters from waste disposal by ships;
soil erosion; illegal solid waste disposal threatens contamination
of aquifers
Bassas da India
NA
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
NA
800 million kWh (2002)
744 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 10%, industry 15%, services 75% (1996 est.)
sugar and molasses, rum, other foods and beverages,
chemicals, electrical components
US 20.6%, UK 14.5%, Trinidad and Tobago 13.9%, Saint Lucia
6.9%, Jamaica 6.6%, Saint Vincent and the Grenadines 5.1% (2004)
11 parishes; Christ Church, Saint Andrew, Saint George,
Saint James, Saint John, Saint Joseph, Saint Lucy, Saint Michael,
Saint Peter, Saint Philip, Saint Thomas; note - the city of
Bridgetown may be given parish status
sugarcane, vegetables, cotton
1 (2004 est.)
12.83 births/1,000 population (2005 est.)
Royal Barbados Defense Force: Troops Command and Coast
Guard (2005)
revenues: $847 million (including grants)
expenditures: $886 million, including capital expenditures of NA
(2000 est.)
Bridgetown','65566a8b03b464f4f20e5f5d4ee6afca2ec03abea8d074206de998044dde2513','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82e6df99cf782293f3c16ea3a4babaa9c7f519c715f71458aa3d7dc51870f8de',2005,'BY','Belarus','economy',667,'total: 50
over 3,047 m: 2
2,438 to 3,047 m: 22
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 21 (2004 est.)
total: 83
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 11
under 914 m: 64 (2004 est.)
soil pollution from pesticide use; southern part of the
country contaminated with fallout from 1986 nuclear reactor accident
at Chornobyl'' in northern Ukraine
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Marine Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
1.4% (FY02)
30 billion kWh (2004)
34.3 billion kWh (2004)
3.2 billion kWh (2003)
800 million kWh (2004)
27.1% (2003 est.)
lowest 10%: 5.1%
highest 10%: 20% (1998)
agriculture 14%, industry 34.7%, services 51.3% (2003 est.)
machinery and equipment, mineral products, chemicals,
metals; textiles, foodstuffs
Russia 47%, UK 8.3%, Netherlands 6.7%, Poland 5.3% (2004)
6 provinces (voblastsi, singular - voblasts'') and 1
municipality* (horad); Brest, Homyel'', Horad Minsk*, Hrodna,
Mahilyow, Minsk, Vitsyebsk
note: administrative divisions have the same names as their
administrative centers
grain, potatoes, vegetables, sugar beets, flax; beef, milk
133 (2004 est.)
10.83 births/1,000 population (2005 est.)
Army, Air and Air Defense Force
revenues: $3.326 billion
expenditures: $3.564 billion, including capital expenditures of $180
million (2004 est.)
Minsk','f4228b7c1bf7b366037966319854f8a82c49b7c962a756f1f157244b9264f8c4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cf3508c52adf28b591977385375a0c5290fc3cbc574dd88157832c5fc85d83e',2005,'BE','Belgium','economy',668,'total: 25
over 3,047 m: 6
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 7 (2004 est.)
total: 18
914 to 1,523 m: 2
under 914 m: 16 (2004 est.)
the environment is exposed to intense pressures from human
activities: urbanization, dense transportation network, industry,
extensive animal breeding and crop cultivation; air and water
pollution also have repercussions for neighboring countries;
uncertainties regarding federal and regional responsibilities (now
resolved) have slowed progress in tackling environmental challenges
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.3% (2003)
76.58 billion kWh (2002)
78.82 billion kWh (2002)
16.7 billion kWh (2002)
9.1 billion kWh (2002)
4% (1989 est.)
lowest 10%: 3.2%
highest 10%: 23% (1996)
agriculture 1.3%, industry 24.5%, services 74.2% (2003 est.)
machinery and equipment, chemicals, diamonds, metals and
metal products, foodstuffs
Germany 19.9%, France 17.2%, Netherlands 11.8%, UK 8.6%, US
6.5%, Italy 5.2% (2004)
10 provinces (French: provinces, singular - province; Dutch:
provincies, singular - provincie) and 3 regions* (French: regions;
Dutch: gewesten); Antwerpen, Brabant Wallon, Brussels* (Bruxelles),
Flanders*, Hainaut, Liege, Limburg, Luxembourg, Namur,
Oost-Vlaanderen, Vlaams-Brabant, Wallonia*, West-Vlaanderen
note: as a result of the 1993 constitutional revision that furthered
devolution into a federal state, there are now three levels of
government (federal, regional, and linguistic community) with a
complex division of responsibilities
sugar beets, fresh vegetables, fruits, grain, tobacco; beef,
veal, pork, milk
43 (2004 est.)
10.48 births/1,000 population (2005 est.)
Land, Naval, and Air Components (2005)
revenues: $173.7 billion
expenditures: $174.8 billion, including capital expenditures of
$1.56 billion (2004 est.)
Brussels','8601c131433cdb25a193ffea4ae944a85e8036b64424d3b5ed5794787e3cb3be','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e76bee627c34efb2f9f77c40287d2a7ddd3448a6d9b1a32d4960c5d1ab8874d1',2005,'BZ','Belize','economy',669,'total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (2004 est.)
total: 38
2,438 to 3,047 m: 1
914 to 1,523 m: 11
under 914 m: 26 (2004 est.)
deforestation; water pollution from sewage, industrial
effluents, agricultural runoff; solid and sewage waste disposal
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
2% (2003)
117 million kWh (2002)
108.8 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
33% (1999 est.)
lowest 10%: NA
highest 10%: NA
agriculture 27%, industry 18%, services 55% (2001 est.)
sugar, bananas, citrus, clothing, fish products, molasses,
wood
US 37.2%, UK 26.8%, Jamaica 4.6% (2004)
6 districts; Belize, Cayo, Corozal, Orange Walk, Stann Creek,
Toledo
bananas, coca, citrus, sugar; fish, cultured shrimp; lumber;
garments
43 (2004 est.)
29.34 births/1,000 population (2005 est.)
Belize Defense Force (BDF): Army, Maritime Wing, Air Wing,
and Volunteer Guard
revenues: $244.5 million
expenditures: $300 million, including capital expenditures of $70
million (2004 est.)
Belmopan','f04ef95541435a420873ae6fac2c48dd36e8d691e290cfdc6c9ec5f3e0d4ad87','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b278e450f77b2dd7235a4ed6a2c9e267885a6194540006cd06c331b23d093aa2',2005,'BJ','Benin','economy',670,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
total: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2004 est.)
inadequate supplies of potable water; poaching threatens
wildlife populations; deforestation; desertification
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
2.4% (2004)
285.2 million kWh (2002)
565.2 million kWh (2002)
300 million kWh (2002)
0 kWh (2002)
33% (2001 est.)
lowest 10%: NA
highest 10%: NA
cotton, crude oil, palm products, cocoa
China 28.7%, India 18.4%, Ghana 6.3%, Thailand 6%, Niger 5.8%,
Indonesia 4.2%, Nigeria 4.2% (2004)
12 departments; Alibori, Atakora, Atlantique, Borgou,
Collines, Kouffo, Donga, Littoral, Mono, Oueme, Plateau, Zou
cotton, corn, cassava (tapioca), yams, beans, palm oil,
peanuts, livestock (2001)
5 (2004 est.)
41.99 births/1,000 population (2005 est.)
Army, Navy, Air Force
revenues: $869.4 million
expenditures: $720.4 million, including capital expenditures of NA
(2004 est.)
Porto-Novo is the official capital; Cotonou is the seat of','079afaae7a010083a51fa30511e3d7fdf0d00759fe88fa756d8e455ed4348854','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02d0edcc13cc935b81bbb203af17b4e075e358541a3d65b39e5fcb4d51a91c82',2005,'BM','Bermuda','economy',671,'total: 1
2,438 to 3,047 m: 1 (2004 est.)
asbestos disposal; water pollution; preservation of open
space; sustainable development
0.11% (FY00/01)
643 million kWh (2002)
598 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
19% (2000)
lowest 10%: NA
highest 10%: NA
agriculture and fishing 3%, laborers 17%, clerical 22%,
professional and technical 17%, administrative and managerial 13%,
sales 8%, services 20% (2000 est.)
reexports of pharmaceuticals
France 73.2%, UK 6.2%, Spain 2.4% (2004)
9 parishes and 2 municipalities*; Devonshire, Hamilton,
Hamilton*, Paget, Pembroke, Saint George*, Saint George''s, Sandys,
Smith''s, Southampton, Warwick
bananas, vegetables, citrus, flowers; dairy products
1 (2004 est.)
11.6 births/1,000 population (2005 est.)
Bermuda Regiment
revenues: $671.1 million
expenditures: $594.6 million, including capital expenditures of $55
million (FY03/04)','1708b9150a72829b22eb80c61501173b21f7a794fc78f88e9e57236426c93875','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62ba9bd66b706b46a9bfcfcf7d0b71f4845253c4f915baaf51cc245d80d95c50',2005,'BT','Bhutan','economy',672,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
Bolivia
total: 16
over 3,047 m: 4
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2004 est.)
total: 1
914 to 1,523 m: 1 (2004 est.)
Bolivia
total: 1,049
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 60
914 to 1,523 m: 207
under 914 m: 778 (2004 est.)
soil erosion; limited access to potable water
Bolivia
the clearing of land for agricultural purposes and the
international demand for tropical timber are contributing to
deforestation; soil erosion from overgrazing and poor cultivation
methods (including slash-and-burn agriculture); desertification;
loss of biodiversity; industrial pollution of water supplies used
for drinking and irrigation
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Endangered Species, Hazardous Wastes
signed, but not ratified: Law of the Sea
Bolivia
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification, Marine Life
Conservation, Ozone Layer Protection
1.8% (2004)
Bolivia
1.6% (2004)
2.001 billion kWh (2002)
Bolivia
4.132 billion kWh (2002)
312.9 million kWh (2002)
Bolivia
3.848 billion kWh (2002)
12 million kWh (2002)
Bolivia
9 million kWh (2002)
1.56 billion kWh (2002)
Bolivia
3 million kWh (2002)
NA
Bolivia
64% (2004 est.)
lowest 10%: NA
highest 10%: NA
Bolivia
lowest 10%: 1.3%
highest 10%: 32% (1999)
agriculture 93%, industry and commerce 2%, services 5%
Bolivia
agriculture NA%, industry NA%, services NA%
electricity (to India), cardamom, gypsum, timber,
handicrafts, cement, fruit, precious stones, spices
Bolivia
natural gas, soybeans and soy products, crude petroleum,
zinc ore, tin
Bangladesh 47.4%, Japan 30.2%, France 3.4% (2004)
Bolivia
Brazil 40%, US 13.9%, Colombia 8.7%, Peru 6.3%, Japan 4.5%
(2004)
18 districts (dzongkhag, singular and plural); Bumthang,
Chhukha, Chirang, Dagana, Geylegphug, Ha, Lhuntshi, Mongar, Paro,
Pemagatsel, Punakha, Samchi, Samdrup Jongkhar, Shemgang, Tashigang,
Thimphu, Tongsa, Wangdi Phodrang
note: there may be two new districts named Gasa and Yangtse
Bolivia
9 departments (departamentos, singular - departamento);
Chuquisaca, Cochabamba, Beni, La Paz, Oruro, Pando, Potosi, Santa
Cruz, Tarija
rice, corn, root crops, citrus, foodgrains; dairy products,
eggs
Bolivia
soybeans, coffee, coca, cotton, corn, sugarcane, rice,
potatoes; timber
2 (2004 est.)
Bolivia
1,065 (2004 est.)
34.03 births/1,000 population (2005 est.)
Bolivia
23.76 births/1,000 population (2005 est.)
Royal Bhutan Army (includes Royal Bodyguard and Royal Bhutan
Police) (2005)
Bolivia
Army (Ejercito Boliviano), Navy (Fuerza Naval; includes
Marines), Air Force (Fuerza Aerea Boliviana) (2004)
revenues: $146 million
expenditures: $152 million, including capital expenditures of NA
note: the government of India finances nearly three-fifths of
Bhutan''s budget expenditures (FY95/96 est.)
Bolivia
revenues: $2.264 billion
expenditures: $2.769 billion, including capital expenditures of $741
million (2004 est.)','c9138a08c3ed31fa80791c1352d3df7be6992b88e592d8fa54f070a475430e81','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e594c07fec68c41d0efb500748a0ee200d4b99cbdb8e25f4da91faf0abf45b4',2005,'BA','Bosnia and Herzegovina','economy',673,'total: 8
2,438 to 3,047 m: 4
1,524 to 2,437 m: 1
under 914 m: 3 (2004 est.)
total: 19
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 11 (2004 est.)
air pollution from metallurgical plants;
sites for disposing of urban waste are limited; water shortages and
destruction of infrastructure because of the 1992-95 civil strife;
deforestation
party to: Air Pollution, Biodiversity,
Climate Change, Hazardous Wastes, Law of the Sea, Marine Life
Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
4.5% (FY02)
10.04 billion kWh (2002)
8.318 billion kWh (2002)
2.271 billion kWh (2002)
3.288 billion kWh (2002)
25% (2004 est.)
lowest 10%: NA%
highest 10%: NA%
agriculture NA, industry NA, services NA
metals, clothing, wood products
Italy 22.3%, Croatia 21.1%, Germany 20.8%,
Austria 7.4%, Slovenia 7.1%, Hungary 4.8% (2004)
2 first-order administrative divisions and 1
internationally supervised district* - Brcko district (Brcko
Distrikt)*, the Bosniak/Croat Federation of Bosnia and Herzegovina
(Federacija Bosna i Hercegovina) and the Bosnian Serb-led Republika
Srpska; note - Brcko district is in northeastern Bosnia and is an
administrative unit under the sovereignty of Bosnia and Herzegovina;
the district remains under international supervision
wheat, corn, fruits, vegetables; livestock
27 (2004 est.)
12.49 births/1,000 population (2005 est.)
VF Army (the air and air defense forces are
subordinate commands within the Army), VRS Army (the air and air
defense forces are subordinate commands within the Army)
revenues: $3.618 billion
expenditures: $3.642 billion, including capital expenditures of NA
(2004 est.)','c427ce70388df2ae3d4c3ad5a3c97b25f0de85b83143a168e2c8e73af8deddea','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd1696896ff4499a54508f54a3685439452a49fc6eade1dbf2abe1792b9a96fa',2005,'BW','Botswana','economy',674,'total: 10
2,438 to 3,047 m: 2
1,524 to 2,437 m: 7
914 to 1,523 m: 1 (2004 est.)
total: 75
1,524 to 2,437 m: 3
914 to 1,523 m: 54
under 914 m: 18 (2004 est.)
overgrazing; desertification; limited fresh water resources
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
3.9% (2004)
930 million kWh (2002)
1.89 billion kWh (2002)
1.025 billion kWh (2002)
0 kWh (2002)
47% (2002 est.)
lowest 10%: NA
highest 10%: NA
NA
diamonds, copper, nickel, soda ash, meat, textiles
European Free Trade Association (EFTA) 87%, Southern
African Customs Union (SACU) 7%, Zimbabwe 4% (2000)
9 districts and 5 town councils*; Central, Francistown*,
Gaborone*, Ghanzi, Jwaneng*, Kgalagadi, Kgatleng, Kweneng, Lobatse*,
Northwest, Northeast, Selebi-Pikwe*, Southeast, Southern
livestock, sorghum, maize, millet, beans, sunflowers,
groundnuts
85 (2004 est.)
23.33 births/1,000 population (2005 est.)
Botswana Defense Force (includes an Air Wing)
revenues: $3.735 billion
expenditures: $3.743 billion, including capital expenditures of NA
(2004 est.)','53db0fecb50f5ed967afe95bca4bcf97254cea61fe18becd367d30730b9dbe90','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6280a4a6619851610e9927dc525652b97478d03b1474ceaa6b4abda54af48ee8',2005,'BR','Brazil','economy',675,'total: 698
over 3,047 m: 7
2,438 to 3,047 m: 23
1,524 to 2,437 m: 158
914 to 1,523 m: 461
under 914 m: 49 (2004 est.)
total: 3,438
over 3,047 m: 1
1,524 to 2,437 m: 78
914 to 1,523 m: 1,579
under 914 m: 1,780 (2004 est.)
British Virgin Islands
total: 1
914 to 1,523 m: 1 (2004 est.)
Brunei
total: 1
914 to 1,523 m: 1 (2004 est.)
deforestation in Amazon Basin destroys the habitat and
endangers a multitude of plant and animal species indigenous to the
area; there is a lucrative illegal wildlife trade; air and water
pollution in Rio de Janeiro, Sao Paulo, and several other large
cities; land degradation and water pollution caused by improper
mining activities; wetland degradation; severe oil spills
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Brunei
party to: Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
1.8% (2004)
Brunei
5.1% (2004)
339 billion kWh (2002)
351.9 billion kWh (2002)
36.58 billion kWh; note - supplied by Paraguay (2002)
British Virgin Islands
0 kWh (2002)
Brunei
0 kWh (2002)
7 million kWh (2002)
British Virgin Islands
0 kWh (2002)
Brunei
0 kWh (2002)
22% (1998 est.)
British Virgin Islands
NA
Brunei
NA
lowest 10%: 0.7%
highest 10%: 48% (1998)
British Virgin Islands
lowest 10%: NA
highest 10%: NA
Brunei
lowest 10%: NA
highest 10%: NA
agriculture 20%, industry 14%, services 66% (2003 est.)
British Virgin Islands
agriculture NA%, industry NA%, services NA%
Brunei
agriculture, forestry, and fishing 10%, production of oil,
natural gas, services, and construction 42%, government 48% (1999
est.)
transport equipment, iron ore, soybeans, footwear, coffee,
autos
British Virgin Islands
rum, fresh fish, fruits, animals; gravel, sand
Brunei
crude oil, natural gas, refined products
US 20.8%, Argentina 7.5%, Netherlands 6.1%, China 5.6%,
Germany 4.1%, Mexico 4% (2004)
British Virgin Islands
Virgin Islands (US), Puerto Rico, US
Brunei
Japan 38.1%, South Korea 14%, Australia 11.2%, US 8.6%,
Thailand 7.9%, Indonesia 5.9%, China 4.5% (2004)
26 states (estados, singular - estado) and 1 federal
district* (distrito federal); Acre, Alagoas, Amapa, Amazonas, Bahia,
Ceara, Distrito Federal*, Espirito Santo, Goias, Maranhao, Mato
Grosso, Mato Grosso do Sul, Minas Gerais, Para, Paraiba, Parana,
Pernambuco, Piaui, Rio de Janeiro, Rio Grande do Norte, Rio Grande
do Sul, Rondonia, Roraima, Santa Catarina, Sao Paulo, Sergipe,
Tocantins
British Virgin Islands
none (overseas territory of the UK)
Brunei
4 districts (daerah-daerah, singular - daerah); Belait,
Brunei and Muara, Temburong, Tutong
coffee, soybeans, wheat, rice, corn, sugarcane, cocoa,
citrus; beef
British Virgin Islands
fruits, vegetables; livestock, poultry; fish
Brunei
rice, vegetables, fruits, chickens, water buffalo
4,136 (2004 est.)
16.83 births/1,000 population (2005 est.)
British Virgin Islands
14.96 births/1,000 population (2005 est.)
Brunei
19.01 births/1,000 population (2005 est.)
Brazilian Army, Brazilian Navy (includes Naval Air and
Marines), Brazilian Air Force (FAB)
Brunei
Royal Brunei Armed Forces: Royal Brunei Land Forces, Royal
Brunei Navy, Royal Brunei Air Force
revenues: $140.6 billion
expenditures: $172.4 billion, including capital expenditures of NA
(2004)
British Virgin Islands
revenues: $121.5 million
expenditures: $115.5 million, including capital expenditures of NA
(1997)
Brunei
revenues: $4.9 billion
expenditures: $4.2 billion, including capital expenditures of $1.35
billion (2003 est.)','2f326565cf56fd5e47cf00291d550ac9b14e7b6e16ff46b2274ec00c4de8e156','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('424858054ff77b39900b6f8651d6f3eb7f81e2f35b34a8c9e934da014228de60',2005,'IO','British Indian Ocean Territory','economy',676,'total: 1
over 3,047 m: 1 (2004 est.)
British Virgin Islands
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
Brunei
total: 1
over 3,047 m: 1 (2004 est.)
NA
British Virgin Islands
limited natural fresh water resources (except
for a few seasonal streams and springs on Tortola, most of the
islands'' water supply comes from wells and rainwater catchments)
Brunei
seasonal smoke/haze resulting from forest fires in Indonesia
NA kWh; note - electricity supplied
by the US military
British Virgin Islands
36.28 million kWh (2002)
Brunei
2.458 billion kWh (2002)
NA kWh
British Virgin Islands
33.74 million kWh (2002)
Brunei
2.286 billion kWh (2002)
1 (2004 est.)
British Virgin Islands
3 (2004 est.)
Brunei
2 (2004 est.)','7bad723bd5c427acb25e98ab0806e9b5eea33c5259e3d8e1030d99ecf0c07999','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd5587c93b0d08fc8d47204d9609fd43a292e55346b3b89162ca6078ec29d7a7',2005,'BG','Bulgaria','economy',677,'total: 128
over 3,047 m: 1
2,438 to 3,047 m: 19
1,524 to 2,437 m: 15
914 to 1,523 m: 1
under 914 m: 92 (2004 est.)
total: 85
1,524 to 2,437 m: 2
914 to 1,523 m: 11
under 914 m: 72 (2004 est.)
air pollution from industrial emissions; rivers polluted
from raw sewage, heavy metals, detergents; deforestation; forest
damage from air pollution and resulting acid rain; soil
contamination from heavy metals from metallurgical plants and
industrial wastes
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Sulfur 94
2.6% (2003)
43.07 billion kWh (2002)
32.71 billion kWh (2002)
960 million kWh (2002)
8.3 billion kWh (2002)
13.4% (2002 est.)
lowest 10%: 4.5%
highest 10%: 22.8% (1997)
agriculture 11%, industry 32.7%, services 56.3% (3rd
quarter 2004 est.)
clothing, footwear, iron and steel, machinery and
equipment, fuels
Italy 13.1%, Germany 11.6%, Turkey 9.3%, Belgium 6.1%,
Greece 5.6%, US 5.3%, France 4.9% (2004)
28 provinces (oblasti, singular - oblast); Blagoevgrad,
Burgas, Dobrich, Gabrovo, Khaskovo, Kurdzhali, Kyustendil, Lovech,
Montana, Pazardzhik, Pernik, Pleven, Plovdiv, Razgrad, Ruse, Shumen,
Silistra, Sliven, Smolyan, Sofiya, Sofiya-Grad, Stara Zagora,
Turgovishte, Varna, Veliko Turnovo, Vidin, Vratsa, Yambol
vegetables, fruits, tobacco, livestock, wine, wheat,
barley, sunflowers, sugar beets
213 (2004 est.)
9.66 births/1,000 population (2005 est.)
Ground Forces, Naval Forces, Air and Air Defense Forces
revenues: $9.67 billion
expenditures: $9.619 billion, including capital expenditures of NA
(2004 est.)','1185167a559435c4a683cae82bf16a5918b17300daf8e05c117c375a302896f0','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56426ced09892f84e28ad96a80e7fcbf7713d5777e3b461d2938eceed6946362',2005,'BF','Burkina Faso','economy',678,'total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (2004 est.)
Burma
total: 9
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 2 (2004 est.)
total: 31
1,524 to 2,437 m: 3
914 to 1,523 m: 11
under 914 m: 17 (2004 est.)
Burma
total: 69
over 3,047 m: 2
1,524 to 2,437 m: 16
914 to 1,523 m: 20
under 914 m: 31 (2004 est.)
recent droughts and desertification severely affecting
agricultural activities, population distribution, and the economy;
overgrazing; soil degradation; deforestation
Burma
deforestation; industrial pollution of air, soil, and water;
inadequate sanitation and water treatment contribute to disease
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Life Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Burma
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94
signed, but not ratified: none of the selected agreements
1.3% (2004)
Burma
2.1% (FY97)
361 million kWh (2002)
Burma
5.068 billion kWh (2003)
335.7 million kWh (2002)
Burma
3.484 billion kWh (2003)
0 kWh (2002)
Burma
0 kWh (2004)
0 kWh (2002)
Burma
0 kWh (2002)
45% (2003 est.)
Burma
25% (2000 est.)
lowest 10%: 2%
highest 10%: 46.8% (1994)
Burma
lowest 10%: 2.8%
highest 10%: 32.4% (1998)
agriculture 90% (2000 est.)
Burma
agriculture 70%, industry 7%, services 23% (2001 est.)
cotton, livestock, gold
Burma
clothing, gas, wood products, pulses, beans, fish, rice
China 32.1%, Singapore 11.5%, Ghana 4.7%, Bangladesh
4.3% (2004)
Burma
Thailand 37.8%, India 11.7%, China 6%, Japan 5.3% (2004)
45 provinces; Bale, Bam, Banwa, Bazega, Bougouriba,
Boulgou, Boulkiemde, Comoe, Ganzourgou, Gnagna, Gourma, Houet, Ioba,
Kadiogo, Kenedougou, Komondjari, Kompienga, Kossi, Koulpelogo,
Kouritenga, Kourweogo, Leraba, Loroum, Mouhoun, Namentenga, Nahouri,
Nayala, Noumbiel, Oubritenga, Oudalan, Passore, Poni, Sanguie,
Sanmatenga, Seno, Sissili, Soum, Sourou, Tapoa, Tuy, Yagha, Yatenga,
Ziro, Zondoma, Zoundweogo
Burma
7 divisions (taing-myar, singular - taing) and 7 states (pyi
ne-myar, singular - pyi ne)
divisions: Ayeyarwady, Bago, Magway, Mandalay, Sagaing, Tanintharyi,
Yangon
states: Chin State, Kachin State, Kayin State, Kayah State, Mon
State, Rakhine State, Shan State
cotton, peanuts, shea nuts, sesame, sorghum, millet,
corn, rice; livestock
Burma
rice, pulses, beans, sesame, groundnuts, sugarcane; hardwood;
fish and fish products
33 (2004 est.)
Burma
78 (2004 est.)
44.17 births/1,000 population (2005 est.)
Burma
18.11 births/1,000 population (2005 est.)
Army, Air Force, National Gendarmerie (2005)
Burma
Myanmar Armed Forces (Tatmadaw): Army, Navy, Air Force (2005)
revenues: $695.2 million
expenditures: $876.3 million, including capital expenditures of NA
(2004 est.)
Burma
revenues: $474.9 million
expenditures: $955.5 million, including capital expenditures of $5.7
billion (2004 est.)','e219ca6c4513c3d09e8cf5785ed489694a3ee43251b92eda3aae3bb32d4d8e74','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22226397fcbfbe36706605852a4d49021de2be01f2051684c774dc7b1e32aa51',2005,'BI','Burundi','economy',679,'total: 1
over 3,047 m: 1 (2004 est.)
total: 7
914 to 1,523 m: 4
under 914 m: 3 (2004 est.)
soil erosion as a result of overgrazing and the expansion of
agriculture into marginal lands; deforestation (little forested land
remains because of uncontrolled cutting of trees for fuel); habitat
loss threatens wildlife populations
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes,
Ozone Layer Protection
signed, but not ratified: Law of the Sea
6% (2004)
132 million kWh (2002)
137.8 million kWh (2002)
15 million kWh; note - supplied by the Democratic Republic
of the Congo (2002)
0 kWh (2002)
68% (2002 est.)
lowest 10%: 1.8%
highest 10%: 32.9% (1998)
agriculture 93.6%, industry 2.3%, services 4.1% (2002 est.)
coffee, tea, sugar, cotton, hides
Germany 19.6%, Belgium 8.2%, Pakistan 6.7%, US 5.6%, Rwanda
5.6%, Thailand 5.4% (2004)
16 provinces; Bubanza, Bujumbura, Bururi, Cankuzo, Cibitoke,
Gitega, Karuzi, Kayanza, Kirundo, Makamba, Muramvya, Muyinga, Mwaro,
Ngozi, Rutana, Ruyigi
coffee, cotton, tea, corn, sorghum, sweet potatoes, bananas,
manioc (tapioca); beef, milk, hides
8 (2004 est.)
39.66 births/1,000 population (2005 est.)
National Defense Force (Forces de Defense Nationales, FDN):
Army (includes Naval Detachment and Air Wing), National Gendarmerie
(2005)
revenues: $152.5 million
expenditures: $187.7 million, including capital expenditures of NA
(2004 est.)','bcfd4551d2c00d58950884ae55afa507d26953eb5b316913845455ed0418b513','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad1e7936d425559adffc69f7c4ed9f42a8931881760c87bd2e9fda7ee9c78c68',2005,'KH','Cambodia','economy',680,'total: 6
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 2 (2004 est.)
total: 14
1,524 to 2,437 m: 2
914 to 1,523 m: 11
under 914 m: 1 (2004 est.)
illegal logging activities throughout the country and strip
mining for gems in the western region along the border with Thailand
have resulted in habitat loss and declining biodiversity (in
particular, destruction of mangrove swamps threatens natural
fisheries); soil erosion; in rural areas, most of the population
does not have access to potable water; declining fish stocks because
of illegal fishing and overfishing
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Life Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
3% (FY01 est.)
122 million kWh (2003)
100.6 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
40% (2004 est.)
lowest 10%: 2.9%
highest 10%: 33.8% (1997)
agriculture 75% (2004 est.)
Clothing, timber, rubber, rice, fish, tobacco, footwear
US 55.9%, Germany 11.7%, UK 6.9%, Vietnam 4.4%, Canada 4.2%
(2004)
20 provinces (khaitt, singular and plural) and 4
municipalities (krong, singular and plural)
provinces: Banteay Mean Chey, Batdambang, Kampong Cham, Kampong
Chhnang, Kampong Spoe, Kampong Thum, Kampot, Kandal, Koh Kong,
Kracheh, Mondol Kiri, Otdar Mean Chey, Pouthisat, Preah Vihear, Prey
Veng, Rotanakir, Siem Reab, Stoeng Treng, Svay Rieng, Takao
municipalities: Keb, Pailin, Phnom Penh, Preah Seihanu
rice, rubber, corn, vegetables, cashews, tapioca
20 (2004 est.)
27.08 births/1,000 population (2005 est.)
Royal Cambodian Armed Forces: Army, Navy, Air Force
revenues: $548.2 million
expenditures: $836.7 million, including capital expenditures of $291
million of which 75% was financed by external assistance (2004 est.)','7adb770c30f4c1ae83cd3cd9cd5ae4aa40b1d1e59d00a5cb805f83102e3f5688','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dc61038fed60afd85e95960b40677b25d3550e249b411e38d8865bd1b66ca2c',2005,'CM','Cameroon','economy',681,'total: 11
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 36
1,524 to 2,437 m: 7
914 to 1,523 m: 20
under 914 m: 9 (2004 est.)
waterborne diseases are prevalent; deforestation;
overgrazing; desertification; poaching; overfishing
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
1.6% (2004)
3.571 billion kWh (2002)
3.321 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
48% (2000 est.)
lowest 10%: 1.9%
highest 10%: 36.6% (1996)
agriculture 70%, industry and commerce 13%, other 17%
crude oil and petroleum products, lumber, cocoa beans,
aluminum, coffee, cotton
Spain 15.2%, Italy 12.3%, UK 10.2%, France 9.2%, US 8.8%,
South Korea 7.1%, Netherlands 4.3% (2004)
10 provinces; Adamaoua, Centre, Est, Extreme-Nord,
Littoral, Nord, Nord-Ouest, Ouest, Sud, Sud-Ouest
coffee, cocoa, cotton, rubber, bananas, oilseed, grains,
root starches; livestock; timber
47 (2004 est.)
34.67 births/1,000 population (2005 est.)
Cameroon Armed Forces: Army, Navy (includes Naval
Infantry), Air Force
revenues: $2.493 billion
expenditures: $2.248 billion, including capital expenditures of NA
(2004 est.)','fe1ece4aa856dfa61d48b54679f71350df75668b6c376384a1644f07fab5b323','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b5fdbb3ec307eee64b7202c198cb0f9023bfdac346cbb20c1a3d0b3435a34ca',2005,'CA','Canada','economy',682,'total: 503
over 3,047 m: 18
2,438 to 3,047 m: 15
1,524 to 2,437 m: 150
914 to 1,523 m: 245
under 914 m: 75 (2004 est.)
Cape Verde
total: 6
over 3,047 m: 1
914 to 1,523 m: 5 (2004 est.)
total: 823
1,524 to 2,437 m: 67
914 to 1,523 m: 347
under 914 m: 409 (2004 est.)
Cape Verde
total: 1
under 914 m: 1 (2004 est.)
air pollution and resulting acid rain severely affecting
lakes and damaging forests; metal smelting, coal-burning utilities,
and vehicle emissions impacting on agricultural and forest
productivity; ocean waters becoming contaminated due to
agricultural, industrial, mining, and forestry activities
Cape Verde
soil erosion; deforestation due to demand for wood used
as fuel; desertification; environmental damage has threatened
several species of birds and reptiles; illegal beach sand
extraction; overfishing
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Air Pollution-Volatile Organic Compounds,
Marine Life Conservation
Cape Verde
party to: Biodiversity, Climate Change, Desertification,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
1.1% (2003)
Cape Verde
1.5% (2004)
548.9 billion kWh (2002)
Cape Verde
43.08 million kWh (2002)
487.3 billion kWh (2002)
Cape Verde
40.06 million kWh (2002)
13 billion kWh (2002)
Cape Verde
0 kWh (2002)
36.13 billion kWh (2002)
Cape Verde
0 kWh (2002)
NA
Cape Verde
30% (2000)
lowest 10%: 2.8%
highest 10%: 23.8% (1994)
Cape Verde
lowest 10%: NA
highest 10%: NA
agriculture 3%, manufacturing 15%, construction 5%, services
74%, other 3% (2000)
motor vehicles and parts, industrial machinery, aircraft,
telecommunications equipment; chemicals, plastics, fertilizers; wood
pulp, timber, crude petroleum, natural gas, electricity, aluminum
Cape Verde
fuel, shoes, garments, fish, hides
US 85.2%, Japan 2.1%, UK 1.6% (2004)
Cape Verde
Portugal 59.4%, US 17.2%, UK 11.4% (2004)
10 provinces and 3 territories*; Alberta, British Columbia,
Manitoba, New Brunswick, Newfoundland and Labrador, Northwest
Territories*, Nova Scotia, Nunavut*, Ontario, Prince Edward Island,
Quebec, Saskatchewan, Yukon Territory*
Cape Verde
17 municipalities (concelhos, singular - concelho); Boa
Vista, Brava, Maio, Mosteiros, Paul, Praia, Porto Novo, Ribeira
Grande, Sal, Santa Catarina, Santa Cruz, Sao Domingos, Sao Filipe,
Sao Miguel, Sao Nicolau, Sao Vicente, Tarrafal
wheat, barley, oilseed, tobacco, fruits, vegetables; dairy
products; forest products; fish
Cape Verde
bananas, corn, beans, sweet potatoes, sugarcane, coffee,
peanuts; fish
1,326 (2004 est.)
Cape Verde
7
note: 3 airports are reported to be nonoperational (2004 est.)
10.84 births/1,000 population (2005 est.)
Cape Verde
25.33 births/1,000 population (2005 est.)
Canadian Armed Forces: Land Forces Command, Maritime Command,
Air Command, Canada Command (homeland security) to be operational in
early 2006 (2005)
Cape Verde
People''s Revolutionary Armed Forces (FARP): Army, Coast
Guard (includes maritime air wing)
revenues: $151 billion
expenditures: $144 billion, including capital expenditures of NA
(2004 est.)
Cape Verde
revenues: $260.6 million
expenditures: $305.3 million, including capital expenditures of NA
(2004 est.)
As an affluent, high-tech industrial society, newly entered
in the trillion dollar class, Canada closely resembles the US in its
market-oriented economic system, pattern of production, and affluent
living standards. Since World War II, the impressive growth of the
manufacturing, mining, and service sectors has transformed the
nation from a largely rural economy into one primarily industrial
and urban. The 1989 US-Canada Free Trade Agreement (FTA) and the
1994 North American Free Trade Agreement (NAFTA) (which includes
Mexico) touched off a dramatic increase in trade and economic
integration with the US. Given its great natural resources, skilled
labor force, and modern capital plant Canada enjoys solid economic
prospects. Solid fiscal management has produced a long-term budget
surplus which is substantially reducing the national debt, although
public debate continues over how to manage the rising cost of the
publicly funded healthcare system. Exports account for roughly a
third of GDP. Canada enjoys a substantial trade surplus with its
principal trading partner, the United States, which absorbs more
than 85% of Canadian exports.
Cape Verde
This island economy suffers from a poor natural resource
base, including serious water shortages exacerbated by cycles of
long-term drought. The economy is service-oriented, with commerce,
transport, tourism, and public services accounting for 72% of GDP.
Although nearly 70% of the population lives in rural areas, the
share of agriculture in GDP in 2004 was only 12%, of which fishing
accounted for 1.5%. About 82% of food must be imported. The fishing
potential, mostly lobster and tuna, is not fully exploited. Cape
Verde annually runs a high trade deficit, financed by foreign aid
and remittances from emigrants; remittances supplement GDP by more
than 20%. Economic reforms are aimed at developing the private
sector and attracting foreign investment to diversify the economy.
Future prospects depend heavily on the maintenance of aid flows, the
encouragement of tourism, remittances, and the momentum of the
government''s development program.','abc72ca03fb509a7b6040f9ff057a762096b066a0f1284df07049840e256b79b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce72965c839851de6bd3ad4f095ff4e1fcb8756159ec1f24dbef512fa90ef398',2005,'KY','Cayman Islands','economy',683,'total: 2
1,524 to 2,437 m: 2 (2004 est.)
total: 1
914 to 1,523 m: 1 (2004 est.)
no natural fresh water resources; drinking water
supplies must be met by rainwater catchments
410.8 million kWh (2002)
382.1 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA (2002 est.)
lowest 10%: NA
highest 10%: NA
agriculture 1.4%, industry 12.6%, services 86% (1995)
turtle products, manufactured consumer goods
mostly US
8 districts; Creek, Eastern, Midland, South Town,
Spot Bay, Stake Bay, West End, Western
vegetables, fruit; livestock, turtle farming
3 (2004 est.)
12.92 births/1,000 population (2005 est.)
no regular military forces; Royal Cayman Islands
Police Force
revenues: $265.2 million
expenditures: $248.9 million, including capital expenditures of NA
(1997)
With no direct taxation, the islands are a thriving
offshore financial center. More than 40,000 companies were
registered in the Cayman Islands as of 1998, including almost 600
banks and trust companies; banking assets exceed $500 billion. A
stock exchange was opened in 1997. Tourism is also a mainstay,
accounting for about 70% of GDP and 75% of foreign currency
earnings. The tourist industry is aimed at the luxury market and
caters mainly to visitors from North America. Total tourist arrivals
exceeded 1.2 million in 1997, with 600,000 from the US. About 90% of
the islands'' food and consumer goods must be imported. The
Caymanians enjoy one of the highest outputs per capita and one of
the highest standards of living in the world.','7b9e81b7d895e8811c7a734fbd97c3aabf6a08f0ded0e957328b6532c8e6b062','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0ca9c1ab892a92e76413a2f9fdac9214feae6216dd894fe8939ce79229413ed',2005,'CF','Central African Republic','economy',684,'total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2 (2004 est.)
total: 47
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 13 (2004 est.)
tap water is not potable; poaching has
diminished the country''s reputation as one of the last great
wildlife refuges; desertification; deforestation
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer Protection,
Tropical Timber 94
signed, but not ratified: Law of the Sea
1% (2004)
106 million kWh (2002)
98.58 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA (1993)
lowest 10%: 0.7%
highest 10%: 47.7% (1993)
diamonds, timber, cotton, coffee, tobacco
Belgium 39.2%, Italy 8.6%, Spain 7.9%, US
6.2%, France 6.1%, Indonesia 5.8%, China 4.9% (2004)
14 prefectures (prefectures, singular -
prefecture), 2 economic prefectures* (prefectures economiques,
singular - prefecture economique), and 1 commune**;
Bamingui-Bangoran, Bangui**, Basse-Kotto, Haute-Kotto, Haut-Mbomou,
Kemo, Lobaye, Mambere-Kadei, Mbomou, Nana-Grebizi*, Nana-Mambere,
Ombella-Mpoko, Ouaka, Ouham, Ouham-Pende, Sangha-Mbaere*, Vakaga
cotton, coffee, tobacco, manioc (tapioca),
yams, millet, corn, bananas; timber
50 (2004 est.)
35.17 births/1,000 population (2005 est.)
Central African Armed Forces (FACA): Ground
Forces, Air Force; General Directorate of Gendarmerie Inspection
(DGIG), Republican Guard (2004)
revenues: NA
expenditures: NA, including capital expenditures of NA
Subsistence agriculture, together with
forestry, remains the backbone of the economy of the Central African
Republic (CAR), with more than 70% of the population living in
outlying areas. The agricultural sector generates half of GDP.
Timber has accounted for about 16% of export earnings and the
diamond industry, for 54%. Important constraints to economic
development include the CAR''s landlocked position, a poor
transportation system, a largely unskilled work force, and a legacy
of misdirected macroeconomic policies. Factional fighting between
the government and its opponents remains a drag on economic
revitalization, with GDP growth at only 0.5% in 2004. Distribution
of income is extraordinarily unequal. Grants from France and the
international community can only partially meet humanitarian needs.','af4437d16c9d4f4f5c50f9f33346e6ab050ccd40ccf407315fcd7ea1fc7bc5ef','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3f56b63b72f623533b4caf465bdcc52ec340a82a65c71f1cfd14e86342f3f84',2005,'TD','Chad','economy',685,'total: 7
over 3,047 m: 2
2,438 to 3,047 m: 3
1,524 to 2,437 m: 1
under 914 m: 1 (2004 est.)
total: 44
1,524 to 2,437 m: 14
914 to 1,523 m: 20
under 914 m: 10 (2004 est.)
inadequate supplies of potable water; improper waste disposal
in rural areas contributes to soil and water pollution;
desertification
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Marine Dumping
2.1% (2004)
96.13 million kWh (2002)
89.4 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
80% (2001 est.)
lowest 10%: NA
highest 10%: NA
agriculture more than 80% (subsistence farming, herding, and
fishing)
cotton, cattle, gum arabic
US 67.8%, China 21.5%, Portugal 4.3% (2004)
14 prefectures (prefectures, singular - prefecture); Batha,
Biltine, Borkou-Ennedi-Tibesti, Chari-Baguirmi, Guera, Kanem, Lac,
Logone Occidental, Logone Oriental, Mayo-Kebbi, Moyen-Chari,
Ouaddai, Salamat, Tandjile
note: instead of 14 prefectures, there may be a new administrative
structure of 28 departments (departments, singular - department),
and 1 city*; Assongha, Baguirmi, Bahr El Gazal, Bahr Koh, Batha
Oriental, Batha Occidental, Biltine, Borkou, Dababa, Ennedi, Guera,
Hadjer Lamis, Kabia, Kanem, Lac, Lac Iro, Logone Occidental, Logone
Oriental, Mandoul, Mayo-Boneye, Mayo-Dallah, Monts de Lam,
N''Djamena*, Ouaddai, Salamat, Sila, Tandjile Oriental, Tandjile
Occidental, Tibesti
cotton, sorghum, millet, peanuts, rice, potatoes, manioc
(tapioca); cattle, sheep, goats, camels
50 (2004 est.)
45.98 births/1,000 population (2005 est.)
Chadian National Army (Armee Nationale Tchadienne, ANT), Air
Force, Gendarmerie (2004)
revenues: $1.131 billion
expenditures: $957.7 million, including capital expenditures of $146
million (2004 est.)
Chad''s primarily agricultural economy will continue to be
boosted by major oilfield and pipeline projects that began in 2000.
Over 80% of Chad''s population relies on subsistence farming and
livestock raising for its livelihood. Cotton, cattle, and gum arabic
provide the bulk of Chad''s export earnings; Chad began to export oil
in 2004. Chad''s economy has long been handicapped by its landlocked
position, high energy costs, and a history of instability. Chad
relies on foreign assistance and foreign capital for most public and
private sector investment projects. A consortium led by two US
companies has been investing $3.7 billion to develop oil reserves
estimated at 1 billion barrels in southern Chad. Oil production came
on stream in late 2003.','17ffc86b31739d6e5fb24430bff7e4412b8d47b7050f6cc5f8581a5512c83f35','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcaf6fa5f34f51be10d1b7401ac6c19c7724ef252e9ade40a7a3491a7e206422',2005,'CL','Chile','economy',686,'total: 71
over 3,047 m: 6
2,438 to 3,047 m: 6
1,524 to 2,437 m: 21
914 to 1,523 m: 23
under 914 m: 15 (2004 est.)
total: 293
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 11
914 to 1,523 m: 60
under 914 m: 217 (2004 est.)
widespread deforestation and mining threaten natural
resources; air pollution from industrial and vehicle emissions;
water pollution from raw sewage
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
3.8% (2004)
48.6 billion kWh (2004)
41.8 billion kWh (2002)
1.813 billion kWh (2002)
0 kWh (2002)
20.6% (2000)
lowest 10%: 1.2%
highest 10%: 47% (2000)
agriculture 13.6%, industry 23.4%, services 63% (2003)
copper, fruit, fish products, paper and pulp, chemicals, wine
US 14%, Japan 11.4%, China 9.9%, South Korea 5.5%, Netherlands
5.1%, Brazil 4.3%, Italy 4.1%, Mexico 4% (2004)
13 regions (regiones, singular - region); Aisen del General
Carlos Ibanez del Campo, Antofagasta, Araucania, Atacama, Bio-Bio,
Coquimbo, Libertador General Bernardo O''Higgins, Los Lagos,
Magallanes y de la Antartica Chilena, Maule, Region Metropolitana
(Santiago), Tarapaca, Valparaiso
note: the US does not recognize claims to Antarctica
grapes, apples, pears, onions, wheat, corn, oats, peaches,
garlic, asparagus, beans, beef, poultry, wool; fish; timber
364 (2004 est.)
15.44 births/1,000 population (2005 est.)
Army of the Nation, National Navy (includes naval air, Coast
Guard, and Marine Corps), Chilean Air Force, Chilean Carabineros
(National Police)
revenues: $21.53 billion
expenditures: $19.95 billion, including capital expenditures of
$3.33 billion (2004 est.)
Chile has a market-oriented economy characterized by a high
level of foreign trade. During the early 1990s, Chile''s reputation
as a role model for economic reform was strengthened when the
democratic government of Patricio AYLWIN - which took over from the
military in 1990 - deepened the economic reform initiated by the
military government. Growth in real GDP averaged 8% during 1991-97,
but fell to half that level in 1998 because of tight monetary
policies implemented to keep the current account deficit in check
and because of lower export earnings - the latter a product of the
global financial crisis. A severe drought exacerbated the recession
in 1999, reducing crop yields and causing hydroelectric shortfalls
and electricity rationing, and Chile experienced negative economic
growth for the first time in more than 15 years. Despite the effects
of the recession, Chile maintained its reputation for strong
financial institutions and sound policy that have given it the
strongest sovereign bond rating in South America. By the end of
1999, exports and economic activity had begun to recover, and growth
rebounded to 4.2% in 2000. Growth fell back to 3.1% in 2001 and 2.1%
in 2002, largely due to lackluster global growth and the devaluation
of the Argentine peso. Chile''s economy began a slow recovery in
2003, growing 3.2% and accelerated to 5.8% in 2004. GDP growth
benefited from high copper prices, solid export earnings
(particularly forestry, fishing, and mining), and stepped-up foreign
direct investment. Unemployment, however, remains stubbornly high.
Chile deepened its longstanding commitment to trade liberalization
with the signing of a free trade agreement with the US, which took
effect on 1 January 2004.','e358366c83dc490b18945c943faf8f830644bf46c0d4a6be747c10714494444b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ff43803576a6019c667f1973e63eda31b26c4ea8bf06b00ea8e0a1a29614caa',2005,'CN','China','economy',687,'total: 383
over 3,047 m: 53
2,438 to 3,047 m: 116
1,524 to 2,437 m: 141
914 to 1,523 m: 23
under 914 m: 50 (2004 est.)
total: 89
over 3,047 m: 5
2,438 to 3,047 m: 4
1,524 to 2,437 m: 13
914 to 1,523 m: 32
under 914 m: 35 (2004 est.)
air pollution (greenhouse gases, sulfur dioxide particulates)
from reliance on coal produces acid rain; water shortages,
particularly in the north; water pollution from untreated wastes;
deforestation; estimated loss of one-fifth of agricultural land
since 1949 to soil erosion and economic development;
desertification; trade in endangered species
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
4.3% (2004)
1.91 trillion kWh (2003)
1.63 trillion kWh (2003)
2.3 billion kWh (2002)
10.38 billion kWh (2002)
10% (2001 est.)
lowest 10%: 2.4%
highest 10%: 30.4% (1998)
agriculture 49%, industry 22%, services 29% (2003 est.)
machinery and equipment, plastics, optical and medical
equipment, iron and steel
US 21.1%, Hong Kong 17%, Japan 12.4%, South Korea 4.7%,
Germany 4% (2004)
23 provinces (sheng, singular and plural), 5 autonomous
regions (zizhiqu, singular and plural), and 4 municipalities (shi,
singular and plural)
provinces: Anhui, Fujian, Gansu, Guangdong, Guizhou, Hainan, Hebei,
Heilongjiang, Henan, Hubei, Hunan, Jiangsu, Jiangxi, Jilin,
Liaoning, Qinghai, Shaanxi, Shandong, Shanxi, Sichuan, Yunnan,
Zhejiang
autonomous regions: Guangxi, Nei Mongol, Ningxia, Xinjiang, Xizang
(Tibet)
municipalities: Beijing, Chongqing, Shanghai, Tianjin
note: China considers Taiwan its 23rd province; see separate entries
for the special administrative regions of Hong Kong and Macau
rice, wheat, potatoes, corn, peanuts, tea, millet, barley,
apples, cotton, oilseed, pork, fish
472 (2004 est.)
13.14 births/1,000 population (2005 est.)
People''s Liberation Army (PLA): Ground Forces, Navy (includes
marines and naval aviation), Air Force (includes Airborne Forces),
and II Artillery Corps (strategic missile force); People''s Armed
Police Force (internal security troops considered to be an adjunct
to the PLA); Militia (2003)
revenues: $317.9 billion
expenditures: $348.9 billion, including capital expenditures of NA
(2004 est.)
In late 1978 the Chinese leadership began moving the economy
from a sluggish, inefficient, Soviet-style centrally planned economy
to a more market-oriented system. Whereas the system operates within
a political framework of strict Communist control, the economic
influence of non-state organizations and individual citizens has
been steadily increasing. The authorities switched to a system of
household and village responsibility in agriculture in place of the
old collectivization, increased the authority of local officials and
plant managers in industry, permitted a wide variety of small-scale
enterprises in services and light manufacturing, and opened the
economy to increased foreign trade and investment. The result has
been a quadrupling of GDP since 1978. Measured on a purchasing power
parity (PPP) basis, China in 2004 stood as the second-largest
economy in the world after the US, although in per capita terms the
country is still poor. Agriculture and industry have posted major
gains especially in coastal areas near Hong Kong and opposite Taiwan
and in Shanghai, where foreign investment has helped spur output of
both domestic and export goods. The leadership, however, often has
experienced - as a result of its hybrid system - the worst results
of socialism (bureaucracy and lassitude) and of capitalism (growing
income disparities and rising unemployment). China thus has
periodically backtracked, retightening central controls at
intervals. The government has struggled to (a) sustain adequate jobs
growth for tens of millions of workers laid off from state-owned
enterprises, migrants, and new entrants to the work force; (b)
reduce corruption and other economic crimes; and (c) keep afloat the
large state-owned enterprises, many of which had been shielded from
competition by subsidies and had been losing the ability to pay full
wages and pensions. From 100 to 150 million surplus rural workers
are adrift between the villages and the cities, many subsisting
through part-time, low-paying jobs. Popular resistance, changes in
central policy, and loss of authority by rural cadres have weakened
China''s population control program, which is essential to
maintaining long-term growth in living standards. At the same time,
one demographic consequence of the "one child" policy is that China
is now one of the most rapidly aging countries in the world. Another
long-term threat to growth is the deterioration in the environment -
notably air pollution, soil erosion, and the steady fall of the
water table especially in the north. China continues to lose arable
land because of erosion and economic development. As part of its
effort to gradually slow the rapid economic growth seen in 2004,
Beijing says it will reduce somewhat its spending on infrastructure
in 2005, while continuing to focus on poverty relief and through
rural tax reform. Accession to the World Trade Organization helps
strengthen its ability to maintain strong growth rates but at the
same time puts additional pressure on the hybrid system of strong
political controls and growing market influences. China has
benefited from a huge expansion in computer Internet use, with 94
million users at the end of 2004. Foreign investment remains a
strong element in China''s remarkable economic growth. Shortages of
electric power and raw materials may affect industrial output in
2005. More power generating capacity is scheduled to come on line in
2006. In its rivalry with India as an economic power, China has a
lead in the absorption of technology, the rising prominence in world
trade, and the alleviation of poverty; India has one important
advantage in its relative mastery of the English language, but the
number of competent Chinese English-speakers is growing rapidly.','bf9c8d4d545077a0bb89d5d54ab3cab7658c707d623791e36dde0294e7d966ba','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67e208a6f473338a0f6c711b5269b445517534182e955de4363e361e4911208e',2005,'CX','Christmas Island','economy',688,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
NA
Clipperton Island
NA
NA
phosphate
Australia, NZ
none (territory of Australia)
NA
1 (2004 est.)
NA
revenues: NA
expenditures: NA, including capital expenditures of NA
Phosphate mining had been the only significant
economic activity, but in December 1987 the Australian Government
closed the mine. In 1991, the mine was reopened. With the support of
the government, a $34 million casino opened in 1993. The casino
closed in 1998. The Australian Government in 2001 agreed to support
the creation of a commercial space-launching site on the island,
projected to begin operations in the near future
Clipperton Island
Although 115 species of fish have been identified
in the territorial waters of Clipperton Island, the only economic
activity is tuna fishing.','5fe92655ede382eb071b81dfd06f503c63dc4ca48ec6c28f1e2cd8d193293799','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92fdce0dc5e87a959b864451689189e54b64e472a424cfeea7ed039cabf3154e',2005,'CC','Cocos (Keeling) Islands','economy',689,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
fresh water resources are limited to
rainwater accumulations in natural underground reservoirs
the Cocos Islands Cooperative Society Ltd.
employs construction workers, stevedores, and lighterage workers;
tourism employs others
copra
none (territory of Australia)
vegetables, bananas, pawpaws, coconuts
1 (2004 est.)
NA
revenues: NA
expenditures: NA
Grown throughout the islands, coconuts are
the sole cash crop. Small local gardens and fishing contribute to
the food supply, but additional food and most other necessities must
be imported from Australia. There is a small tourist industry.','b7684d4220f53f2fc9d2c179520642ac572c1c78587aca56c08dda70c53e9f19','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4288261ac294cdb80aa3afe8e5c538880235d641a23c3e85c2bdee2767507f8f',2005,'CO','Colombia','economy',690,'total: 101
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 39
914 to 1,523 m: 39
under 914 m: 12 (2004 est.)
total: 879
2,438 to 3,047 m: 1
1,524 to 2,437 m: 34
914 to 1,523 m: 272
under 914 m: 572 (2004 est.)
Congo, Democratic Republic of the
total: 206
1,524 to 2,437 m: 17
914 to 1,523 m: 92
under 914 m: 97 (2004 est.)
Congo, Republic of the
total: 28
1,524 to 2,437 m: 6
914 to 1,523 m: 11
under 914 m: 11 (2004 est.)
deforestation; soil and water quality damage from overuse
of pesticides; air pollution, especially in Bogota, from vehicle
emissions
party to: Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Life Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
3.4% (FY01)
44.87 billion kWh (2002)
41.14 billion kWh (2002)
23 million kWh (2002)
618 million kWh (2002)
55% (2001)
lowest 10%: 1%
highest 10%: 44% (1999)
agriculture 30%, industry 24%, services 46% (1990)
petroleum, coffee, coal, apparel, bananas, cut flowers
US 42.1%, Venezuela 9.7%, Ecuador 6% (2004)
32 departments (departamentos, singular - departamento) and
1 capital district* (distrito capital); Amazonas, Antioquia, Arauca,
Atlantico, Distrito Capital de Bogota*, Bolivar, Boyaca, Caldas,
Caqueta, Casanare, Cauca, Cesar, Choco, Cordoba, Cundinamarca,
Guainia, Guaviare, Huila, La Guajira, Magdalena, Meta, Narino, Norte
de Santander, Putumayo, Quindio, Risaralda, San Andres y
Providencia, Santander, Sucre, Tolima, Valle del Cauca, Vaupes,
Vichada
coffee, cut flowers, bananas, rice, tobacco, corn,
sugarcane, cocoa beans, oilseed, vegetables; forest products; shrimp
980 (2004 est.)
20.82 births/1,000 population (2005 est.)
Army (Ejercito Nacional), Navy (Armada Nacional, includes
Naval Aviation, Marines, and Coast Guard), Air Force (Fuerza Aerea
Colombiana)
revenues: $15.33 billion
expenditures: $21.03 billion, including capital expenditures of NA
(2004 est.)
Colombia''s economy has been on a recovery trend during the
past two years despite a serious armed conflict. The economy
continues to improve thanks to austere government budgets, focused
efforts to reduce public debt levels, and an export-oriented growth
focus. Ongoing economic problems facing President URIBE range from
reforming the pension system to reducing high unemployment. New
exploration is needed to offset declining oil production. On the
positive side, several international financial institutions have
praised the economic reforms introduced by URIBE, which include
measures designed to reduce the public-sector deficit below 2.5% of
GDP. The government''s economic policy and democratic security
strategy have engendered a growing sense of confidence in the
economy, particularly within the business sector. Coffee prices have
recovered from previous lows as the Colombian coffee industry
pursues greater market shares in developed countries such as the
United States.','889a0cad914d61ab373797cffaa856a1f2f1c101b53620db99cf52edca23c86c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90048e4e5ea1b4b58e9112e47d639655480d7acb193a5cb4e1e47e96ffbd5c47',2005,'KM','Comoros','economy',691,'total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (2004 est.)
Congo, Democratic Republic of the
total: 24
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m: 16
914 to 1,523 m: 2 (2004 est.)
Congo, Republic of the
total: 4
over 3,047 m: 1
1,524 to 2,437 m: 3 (2004 est.)
soil degradation and erosion results from crop cultivation
on slopes without proper terracing; deforestation
Congo, Democratic Republic of the
poaching threatens wildlife
populations; water pollution; deforestation; refugees responsible
for significant deforestation, soil erosion, and wildlife poaching;
mining of minerals (coltan - a mineral used in creating capacitors,
diamonds, and gold) causing environmental damage
Congo, Republic of the
air pollution from vehicle emissions; water
pollution from the dumping of raw sewage; tap water is not potable;
deforestation
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Congo, Democratic Republic of the
party to: Biodiversity, Climate
Change, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification
Congo, Republic of the
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
3% (2004)
Congo, Democratic Republic of the
1.5% (2004)
Congo, Republic of the
2.8% (2004)
23.84 million kWh (2002)
Congo, Democratic Republic of the
6.086 billion kWh (2002)
Congo, Republic of the
348 million kWh (2002)
22.17 million kWh (2002)
Congo, Democratic Republic of the
4.168 billion kWh (2002)
Congo, Republic of the
573.6 million kWh (2002)
0 kWh (2002)
Congo, Democratic Republic of the
8 million kWh (2002)
Congo, Republic of the
250 million kWh (2002)
0 kWh (2002)
Congo, Democratic Republic of the
1.5 billion kWh (2002)
Congo, Republic of the
0 kWh (2002)
60% (2002 est.)
Congo, Democratic Republic of the
NA
Congo, Republic of the
NA
lowest 10%: NA
highest 10%: NA
Congo, Democratic Republic of the
lowest 10%: NA
highest 10%: NA
Congo, Republic of the
lowest 10%: NA
highest 10%: NA
agriculture 80%
Congo, Democratic Republic of the
NA
vanilla, ylang-ylang, cloves, perfume oil, copra
Congo, Democratic Republic of the
diamonds, copper, crude oil,
coffee, cobalt
Congo, Republic of the
petroleum, lumber, plywood, sugar, cocoa,
coffee, diamonds
US 43.8%, France 18.6%, Singapore 16.5%, Turkey 4.8%,
Germany 4.5% (2004)
Congo, Democratic Republic of the
Belgium 47.8%, Finland 21%, US
10.9%, China 7.6% (2004)
Congo, Republic of the
China 26.8%, Taiwan 19.2%, North Korea 8.4%,
US 7.3%, France 5.5%, South Korea 4.8% (2004)
3 islands; Grande Comore (Njazidja), Anjouan (Nzwani), and
Moheli (Mwali); note - there are also four municipalities named
Domoni, Fomboni, Moroni, and Moutsamoudou
Congo, Democratic Republic of the
10 provinces (provinces, singular
- province) and 1 city* (ville); Bandundu, Bas-Congo, Equateur,
Kasai-Occidental, Kasai-Oriental, Katanga, Kinshasa*, Maniema,
Nord-Kivu, Orientale, Sud-Kivu
Congo, Republic of the
10 regions (regions, singular - region) and 1
commune*; Bouenza, Brazzaville*, Cuvette, Cuvette-Ouest, Kouilou,
Lekoumou, Likouala, Niari, Plateaux, Pool, Sangha
vanilla, cloves, perfume essences, copra, coconuts, bananas,
cassava (tapioca)
Congo, Democratic Republic of the
coffee, sugar, palm oil, rubber,
tea, quinine, cassava (tapioca), palm oil, bananas, root crops,
corn, fruits; wood products
Congo, Republic of the
cassava (tapioca), sugar, rice, corn,
peanuts, vegetables, coffee, cocoa; forest products
4 (2004 est.)
Congo, Democratic Republic of the
230 (2004 est.)
Congo, Republic of the
32 (2004 est.)
37.52 births/1,000 population (2005 est.)
Congo, Democratic Republic of the
44.38 births/1,000 population
(2005 est.)
Congo, Republic of the
27.88 births/1,000 population (2005 est.)
Comoran Security Force
Congo, Democratic Republic of the
Army, Navy, Air Force
Congo, Republic of the
Congolese Armed Forces (FAC): Army, Air Force
(Armee de l''Air Congolaise), Navy, Gendarmerie, Republican Guard
(2005)
revenues: $27.6 million
expenditures: NA, including capital expenditures of NA (2001 est.)
Congo, Democratic Republic of the
revenues: $269 million
expenditures: $244 million, including capital expenditures of $24
million (1996 est.)
Congo, Republic of the
revenues: $870.1 million
expenditures: $1.102 billion, including capital expenditures of NA
(2004 est.)
One of the world''s poorest countries, Comoros is made up of
three islands that have inadequate transportation links, a young and
rapidly increasing population, and few natural resources. The low
educational level of the labor force contributes to a subsistence
level of economic activity, high unemployment, and a heavy
dependence on foreign grants and technical assistance. Agriculture,
including fishing, hunting, and forestry, contributes 40% to GDP,
employs 80% of the labor force, and provides most of the exports.
The country is not self-sufficient in food production; rice, the
main staple, accounts for the bulk of imports. The government -
which is hampered by internal political disputes - is struggling to
upgrade education and technical training, privatize commercial and
industrial enterprises, improve health services, diversify exports,
promote tourism, and reduce the high population growth rate.
Increased foreign support is essential if the goal of 4% annual GDP
growth is to be met. Remittances from 150,000 Comorans abroad help
supplement GDP.
Congo, Democratic Republic of the
The economy of the Democratic
Republic of the Congo - a nation endowed with vast potential wealth
- has declined drastically since the mid-1980s. The war, which began
in August 1998, dramatically reduced national output and government
revenue, increased external debt, and resulted in the deaths of
perhaps 3.5 million people from war, famine, and disease. Foreign
businesses curtailed operations due to uncertainty about the outcome
of the conflict, lack of infrastructure, and the difficult operating
environment. Conditions improved in late 2002 with the withdrawal of
a large portion of the invading foreign troops. Several IMF and
World Bank missions have met with the government to help it develop
a coherent economic plan, and President KABILA has begun
implementing reforms. Much economic activity lies outside the GDP
data. Economic stability, aided by international donors, improved in
2003-04, although an uncertain legal framework, corruption, and a
lack of openness in government policy continues to hamper growth. In
2005, renewed activity in the mining sector, the source of most
exports, could boost Kinshasa''s fiscal position and GDP growth.
Congo, Republic of the
The economy is a mixture of village
agriculture and handicrafts, an industrial sector based largely on
oil, support services, and a government characterized by budget
problems and overstaffing. Oil has supplanted forestry as the
mainstay of the economy, providing a major share of government
revenues and exports. In the early 1980s, rapidly rising oil
revenues enabled the government to finance large-scale development
projects with GDP growth averaging 5% annually, one of the highest
rates in Africa. The government has mortgaged a substantial portion
of its oil earnings, contributing to a shortage of revenues. The 12
January 1994 devaluation of Franc Zone currencies by 50% resulted in
inflation of 61% in 1994, but inflation has subsided since. Economic
reform efforts continued with the support of international
organizations, notably the World Bank and the IMF. The reform
program came to a halt in June 1997 when civil war erupted. Denis
SASSOU-NGUESSO, who returned to power when the war ended in October
1997, publicly expressed interest in moving forward on economic
reforms and privatization and in renewing cooperation with
international financial institutions. However, economic progress was
badly hurt by slumping oil prices and the resumption of armed
conflict in December 1998, which worsened the republic''s budget
deficit. The current administration presides over an uneasy internal
peace and faces difficult economic challenges of stimulating
recovery and reducing poverty.','dbea8b8185ab5ea84122c31e98962f61e1749c9910346a4828487226ffb9f064','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b3889b3e185a6ed36f69a6cbab0d400b6be069c7f92a2ba35d6269bb4a7e117',2005,'CK','Cook Islands','economy',692,'total: 2
1,524 to 2,437 m: 2 (2004 est.)
total: 7
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 1 (2004 est.)
NA
Coral Sea Islands
no permanent fresh water resources
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law of the Sea
signed, but not ratified: none of the selected agreements
27 million kWh (2002)
25.11 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 29%, industry 15%, services 56%
note: shortage of skilled labor (1995)
copra, papayas, fresh and canned citrus fruit, coffee;
fish; pearls and pearl shells; clothing
Australia 34%, Japan 27%, New Zealand 25%, US 8% (2000)
none
copra, citrus, pineapples, tomatoes, beans, pawpaws,
bananas, yams, taro, coffee; pigs, poultry
9 (2004 est.)
NA
no regular military forces; Ministry of Police and
Disaster Management (2004)
revenues: $28 million
expenditures: $27 million, including capital expenditures of $3.3
million (FY00/01 est.)
Like many other South Pacific island nations, the Cook
Islands'' economic development is hindered by the isolation of the
country from foreign markets, the limited size of domestic markets,
lack of natural resources, periodic devastation from natural
disasters, and inadequate infrastructure. Agriculture provides the
economic base with major exports made up of copra and citrus fruit.
Manufacturing activities are limited to fruit processing, clothing,
and handicrafts. Trade deficits are offset by remittances from
emigrants and by foreign aid, overwhelmingly from New Zealand. In
the 1980s and 1990s, the country lived beyond its means, maintaining
a bloated public service and accumulating a large foreign debt.
Subsequent reforms, including the sale of state assets, the
strengthening of economic management, the encouragement of tourism,
and a debt restructuring agreement, have rekindled investment and
growth.
Coral Sea Islands
no economic activity','12fae3886b247e257a9939f016b4c0636c43e1302224e926fefe610c565fbed6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0af230b5f97f6abdf885b0841e00e6fa2454f959abc4f2c790d14f2e22a59157',2005,'CR','Costa Rica','economy',693,'total: 30
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 18
under 914 m: 8 (2004 est.)
Cote d''Ivoire
total: 7
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4 (2004 est.)
total: 119
914 to 1,523 m: 24
under 914 m: 95 (2004 est.)
Cote d''Ivoire
total: 30
1,524 to 2,437 m: 7
914 to 1,523 m: 15
under 914 m: 8 (2004 est.)
deforestation and land use change, largely a result of
the clearing of land for cattle ranching and agriculture; soil
erosion; coastal marine pollution; fisheries protection; solid waste
management; air pollution
Cote d''Ivoire
deforestation (most of the country''s forests - once
the largest in West Africa - have been heavily logged); water
pollution from sewage and industrial and agricultural effluents
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
Cote d''Ivoire
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
0.4% (2003)
Cote d''Ivoire
1.2% (2004)
6.614 billion kWh (2002)
Cote d''Ivoire
4.759 billion kWh (2002)
5.733 billion kWh (2002)
Cote d''Ivoire
2.976 billion kWh (2002)
59 million kWh (2002)
Cote d''Ivoire
0 kWh (2002)
477 million kWh (2002)
Cote d''Ivoire
1.45 billion kWh (2002)
18% (2004 est.)
Cote d''Ivoire
37% (1995)
lowest 10%: 1.1%
highest 10%: 36.8% (2002)
Cote d''Ivoire
lowest 10%: 3.1%
highest 10%: 28.8% (1995)
agriculture 20%, industry 22%, services 58% (1999 est.)
coffee, bananas, sugar; pineapples; textiles, electronic
components, medical equipment
Cote d''Ivoire
cocoa, coffee, timber, petroleum, cotton, bananas,
pineapples, palm oil, fish
US 46.9%, Netherlands 5.3%, Guatemala 4.4% (2004)
Cote d''Ivoire
US 11.6%, Netherlands 10.3%, France 9.5%, Italy 5.5%,
Belgium 4.7%, Germany 4.7% (2004)
7 provinces (provincias, singular - provincia); Alajuela,
Cartago, Guanacaste, Heredia, Limon, Puntarenas, San Jose
Cote d''Ivoire
19 regions; Agneby, Bafing, Bas-Sassandra, Denguele,
Dix-Huit Montagnes, Fromager, Haut-Sassandra, Lacs, Lagunes,
Marahoue, Moyen-Cavally, Moyen-Comoe, N''zi-Comoe, Savanes,
Sud-Bandama, Sud-Comoe, Vallee du Bandama, Worodougou, Zanzan
coffee, pineapples, bananas, sugar, corn, rice, beans,
potatoes; beef; timber
Cote d''Ivoire
coffee, cocoa beans, bananas, palm kernels, corn,
rice, manioc (tapioca), sweet potatoes, sugar, cotton, rubber; timber
149 (2004 est.)
Cote d''Ivoire
37 (2004 est.)
18.6 births/1,000 population (2005 est.)
Cote d''Ivoire
35.51 births/1,000 population (2005 est.)
no regular military forces; Ministry of Public Security,
Government, and Police
Cote d''Ivoire
Army, Navy, Air Force
revenues: $2.497 billion
expenditures: $3.094 billion, including capital expenditures of NA
(2004 est.)
Cote d''Ivoire
revenues: $2.412 billion
expenditures: $2.767 billion, including capital expenditures of $420
million (2004 est.)
Costa Rica''s basically stable economy depends on tourism,
agriculture, and electronics exports. Poverty has been substantially
reduced over the past 15 years, and a strong social safety net has
been put into place. Foreign investors remain attracted by the
country''s political stability and high education levels, and tourism
continues to bring in foreign exchange. Low prices for coffee and
bananas have hurt the agricultural sector. The government continues
to grapple with its large deficit and massive internal debt. The
reduction of inflation remains a difficult problem because of rises
in the price of imports, labor market rigidities, and fiscal
deficits. The country also needs to reform its tax system and its
pattern of public expenditure. Costa Rica recently concluded
negotiations to participate in the US-Central American Free Trade
Agreement, which, if ratified by the Costa Rican Legislature, would
result in economic reforms and an improved investment climate.
Cote d''Ivoire
Cote d''Ivoire is among the world''s largest producers
and exporters of coffee, cocoa beans, and palm oil. Consequently,
the economy is highly sensitive to fluctuations in international
prices for these products and weather conditions. Despite government
attempts to diversify the economy, it is still heavily dependent on
agriculture and related activities, engaging roughly 68% of the
population. After several years of lagging performance, the Ivorian
economy began a comeback in 1994, due to the 50% devaluation of the
CFA franc and improved prices for cocoa and coffee, growth in
nontraditional primary exports such as pineapples and rubber,
limited trade and banking liberalization, offshore oil and gas
discoveries, and generous external financing and debt rescheduling
by multilateral lenders and France. Moreover, government adherence
to donor-mandated reforms led to a jump to 5% annual growth during
1996-99. Growth was negative in 2000-03 because of the difficulty of
meeting the conditions of international donors, continued low prices
of key exports, and severe civil war. In November 2004 the situation
deteriorated when President GBAGBO''s troops attacked and killed nine
French peacekeeping forces, and the UN imposed an arms embargo.
Political uncertainty has clouded the economic outlook for 2005,
with fear among Ivorians spreading, foreign investment shriveling,
businessmen fleeing, travel within the country falling, and criminal
elements that traffic in weapons and diamonds gaining ground.','56a702c75ae74bec6c704155b3ace552cf00f1c1e76a7f17cefbad1bcdd7cc4f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b87ad2ca65fa2597624fdedf1e5b1e490115f4d2680f530b5584caca24d3df8f',2005,'HR','Croatia','economy',694,'total: 23
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 9 (2004 est.)
total: 45
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 37 (2004 est.)
air pollution (from metallurgical plants) and resulting acid
rain is damaging the forests; coastal pollution from industrial and
domestic waste; landmine removal and reconstruction of
infrastructure consequent to 1992-95 civil strife
party to: Air Pollution, Air Pollution-Sulfur 94,
Biodiversity, Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
2.39% (2002 est.)
12.51 billion kWh (2002)
15.2 billion kWh (2002)
3.966 billion kWh (2002)
406 million kWh (2002)
11% (2003)
lowest 10%: 3.4%
highest 10%: 24.5% (2003 est.)
agriculture 2.7%, industry 32.8%, services 64.5% (2004)
transport equipment, textiles, chemicals, foodstuffs, fuels
Italy 23%, Bosnia and Herzegovina 13.4%, Germany 11.4%,
Austria 9.6%, Slovenia 7.6% (2004)
20 counties (zupanije, zupanija - singular) and 1 city*
(grad - singular); Bjelovarsko-Bilogorska Zupanija, Brodsko-Posavska
Zupanija, Dubrovacko-Neretvanska Zupanija, Istarska Zupanija,
Karlovacka Zupanija, Koprivnicko-Krizevacka Zupanija,
Krapinsko-Zagorska Zupanija, Licko-Senjska Zupanija, Medimurska
Zupanija, Osjecko-Baranjska Zupanija, Pozesko-Slavonska Zupanija,
Primorsko-Goranska Zupanija, Sibensko-Kninska Zupanija,
Sisacko-Moslavacka Zupanija, Splitsko-Dalmatinska Zupanija,
Varazdinska Zupanija, Viroviticko-Podravska Zupanija,
Vukovarsko-Srijemska Zupanija, Zadarska Zupanija, Zagreb*,
Zagrebacka Zupanija
wheat, corn, sugar beets, sunflower seed, barley, alfalfa,
clover, olives, citrus, grapes, soybeans, potatoes; livestock, dairy
products
68 (2004 est.)
9.57 births/1,000 population (2005 est.)
Ground Forces (Hrvatska Vojska, HKoV), Naval Forces
(Hrvatska Ratna Mornarica, HRM), Air and Air Defense Forces
(Hrvatsko Ratno Zrakoplovstvo i Protuzrakoplovna Obrana, HRZiPZO)
revenues: $14.14 billion
expenditures: $15.65 billion, including capital expenditures of NA
(2004 est.)
Before the dissolution of Yugoslavia, the Republic of
Croatia, after Slovenia, was the most prosperous and industrialized
area, with a per capita output perhaps one-third above the Yugoslav
average. The economy emerged from a mild recession in 2000 with
tourism, banking, and public investments leading the way.
Unemployment remains high, at about 14 percent, with structural
factors slowing its decline. While macroeconomic stabilization has
largely been achieved, structural reforms lag because of deep
resistance on the part of the public and lack of strong support from
politicians. Growth, while impressively about 4% for the last
several years, has been achieved through high fiscal and current
account deficits. The government is gradually reducing a heavy back
log of civil cases, many involving land tenure. The EU accession
process should accelerate fiscal and structural reform.','33df1f0493a9a7bf6d8993e0a538268b1a45c8e3b6bc959db9e8cfbcaedd0914','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8116139db15607a6803a2051f01ca29f95fcee7deb7f55e8ed9870ba5e868c6',2005,'CU','Cuba','economy',695,'total: 79
over 3,047 m: 7
2,438 to 3,047 m: 9
1,524 to 2,437 m: 20
914 to 1,523 m: 6
under 914 m: 37 (2004 est.)
total: 91
914 to 1,523 m: 29
under 914 m: 62 (2004 est.)
air and water pollution; biodiversity loss; deforestation
party to: Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
1.8% (2003)
14.41 billion kWh (2002)
13.4 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 24%, industry 25%, services 51% (1999)
sugar, nickel, tobacco, fish, medical products, citrus, coffee
Netherlands 22.7%, Canada 20.6%, China 7.7%, Russia 7.5%, Spain
6.4%, Venezuela 4.4% (2004)
14 provinces (provincias, singular - provincia) and 1 special
municipality* (municipio especial); Camaguey, Ciego de Avila,
Cienfuegos, Ciudad de La Habana, Granma, Guantanamo, Holguin, Isla
de la Juventud*, La Habana, Las Tunas, Matanzas, Pinar del Rio,
Sancti Spiritus, Santiago de Cuba, Villa Clara
sugar, tobacco, citrus, coffee, rice, potatoes, beans; livestock
170 (2004 est.)
12.03 births/1,000 population (2005 est.)
Revolutionary Armed Forces (FAR): Revolutionary Army (ER),
Revolutionary Navy (MGR), Air and Air Defense Force (DAAFAR),
Territorial Militia Troops (MTT), Youth Labor Army (EJT)
revenues: $18.01 billion
expenditures: $19.06 billion, including capital expenditures of NA
(2004 est.)
The government continues to balance the need for economic
loosening against a desire for firm political control. It has
undertaken limited reforms to increase enterprise efficiency and
alleviate serious shortages of food, consumer goods, and services. A
major feature of the economy is the dichotomy between relatively
efficient export enclaves and inefficient domestic sectors. The
average Cuban''s standard of living remains at a lower level than
before the depression of the 1990s, which was caused by the loss of
Soviet aid and domestic inefficiencies. The government in 2004
strengthened its controls over dollars coming into the economy from
tourism, remittances, and trade.','a296665b3e4a114f966c1107e7fcc6398c60e08016969ac4eda4874a8e75c607','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d11a8cc76534eac50349e7a11de87061c55ad0b54b2bc8bb70e1596473695113',2005,'CY','Cyprus','economy',696,'total: 13
2,438 to 3,047 m: 7
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 1 (2004 est.)
Czech Republic
total: 44
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 14
914 to 1,523 m: 2
under 914 m: 17 (2004 est.)
total: 4
914 to 1,523 m: 2
under 914 m: 2 (2004 est.)
Czech Republic
total: 76
1,524 to 2,437 m: 1
914 to 1,523 m: 27
under 914 m: 48 (2004 est.)
water resource problems (no natural reservoir catchments,
seasonal disparity in rainfall, sea water intrusion to island''s
largest aquifer, increased salination in the north); water pollution
from sewage and industrial wastes; coastal degradation; loss of
wildlife habitats from urbanization
Czech Republic
air and water pollution in areas of northwest Bohemia
and in northern Moravia around Ostrava present health risks; acid
rain damaging forests; efforts to bring industry up to EU code
should improve domestic pollution
party to: Air Pollution, Air Pollution-Persistent Organic
Pollutants, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
Czech Republic
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
3.8% (FY02)
Czech Republic
2.02% (2004)
4 billion kWh; north Cyprus: NA kWh (2003)
Czech Republic
71.75 billion kWh (2002)
Republic of Cyprus: 3.663 billion kWh (2003); north Cyprus:
602 million kWh (2003)
Czech Republic
55.33 billion kWh (2002)
0 kWh (2002)
Czech Republic
9.5 billion kWh (2002)
0 kWh (2002)
Czech Republic
20.9 billion kWh (2002)
NA%
Czech Republic
NA
lowest 10%: NA%
highest 10%: NA%
Czech Republic
lowest 10%: 4.3%
highest 10%: 22.4% (1996)
Republic of Cyprus: agriculture 4.9%, industry 19.4%,
services 75.6%
north Cyprus: agriculture 15.1%, industry 27%, services 57.9% (2003
est.)
Czech Republic
agriculture 4%, industry 38%, services 58% (2002 est.)
Republic of Cyprus: citrus, potatoes, pharmaceuticals,
cement, clothing and cigarettes; north Cyprus: citrus, potatoes,
textiles
Czech Republic
machinery and transport equipment 52%, chemicals 5%,
raw materials and fuel 9% (2003)
UK 27.2%, Greece 11.9%, Germany 5%, UAE 4.8% (2004)
Czech Republic
Germany 36.1%, Slovakia 8.4%, Austria 6%, Poland
5.3%, UK 4.7%, France 4.7%, Italy 4.3%, Netherlands 4.3% (2004)
6 districts; Famagusta, Kyrenia, Larnaca, Limassol, Nicosia,
Paphos; note - Turkish Cypriot area''s administrative divisions
include Kyrenia, all but a small part of Famagusta, and small parts
of Lefkosia (Nicosia) and Larnaca
Czech Republic
13 regions (kraje, singular - kraj) and 1 capital
city* (hlavni mesto); Jihocesky Kraj, Jihomoravsky Kraj, Karlovarsky
Kraj, Kralovehradecky Kraj, Liberecky Kraj, Moravskoslezsky Kraj,
Olomoucky Kraj, Pardubicky Kraj, Plzensky Kraj, Praha (Prague)*,
Stredocesky Kraj, Ustecky Kraj, Vysocina, Zlinsky Kraj
citrus, vegetables, barley, grapes, olives, vegetables,
poultry, pork, lamb, kids, dairy, cheese
Czech Republic
wheat, potatoes, sugar beets, hops, fruit; pigs,
poultry
17 (2004 est.)
Czech Republic
120 (2004 est.)
12.57 births/1,000 population (2005 est.)
Czech Republic
9.07 births/1,000 population (2005 est.)
Republic of Cyprus: Greek Cypriot National Guard (GCNG;
includes air and naval elements)
north Cyprus: Turkish Cypriot Security Force (GKK)
Czech Republic
Army of the Czech Republic (ACR): Joint Forces
Command, Support and Training Forces Command (2005)
revenues: Republic of Cyprus - $5.616 billion (2004 est.),
north Cyprus - $404.3 million (2003 est.)
expenditures: Republic of Cyprus - $685.7 million, including capital
expenditures of $685.7 million, north Cyprus - $775.7 million,
including capital expenditures of $91.4 million (2004 est.)
Czech Republic
revenues: $39.31 billion
expenditures: $45.8 billion, including capital expenditures of NA
(2004 est.)
The Greek Cypriot economy is prosperous but highly
susceptible to external shocks. The service sector, mainly tourism
and financial services, dominates the economy; erratic growth rates
over the past decade reflect the economy''s reliance on tourism,
which often fluctuates with political instability in the region and
economic conditions in Western Europe. Economic policy is focused on
meeting the criteria to join the European Exchange Rate Mechanism
(ERM2) within the next two years although sluggish tourism and poor
fiscal management have resulted in growing budget deficits since
2001. As in the Turkish sector, water shortages are a perennial
problem; a few desalination plants are now on-line. After 10 years
of drought, the country received substantial rainfall from 2001-03,
alleviating immediate concerns. The Turkish Cypriot economy has
roughly one-third of the per capita GDP of the south, and economic
growth tends to be volatile, given north Cyprus''s relative
isolation, bloated public sector, reliance on the Turkish lira, and
small market size. The Turkish Cypriot economy grew 2.6% in 2004,
fueled by growth in the construction and education sectors as well
as increased employment of Turkish Cypriots in the Republic of
Cyprus. The Turkish Cypriots are heavily dependent on transfers from
the Turkish government. Ankara provides around $300 million a year
directly into the "TRNC" budget and regularly provides additional
financing for large infrastructure projects. Agriculture and
government service, together employ almost half of the work force,
and the potential for tourism is promising, especially with the
easing of border restrictions with the Greek Cypriots in April 2003.
Czech Republic
The Czech Republic is one of the most stable and
prosperous of the post-Communist states of Central and Eastern
Europe. Growth in 2000-04 was supported by exports to the EU,
primarily to Germany, and a strong recovery of foreign and domestic
investment. Domestic demand is playing an ever more important role
in underpinning growth as interest rates drop and the availability
of credit cards and mortgages increases. Current account deficits of
around 5% of GDP are beginning to decline as demand for Czech
products in the European Union increases. Inflation is under
control. Recent accession to the EU gives further impetus and
direction to structural reform. In early 2004 the government passed
increases in the Value Added Tax (VAT) and tightened eligibility for
social benefits with the intention to bring the public finance gap
down to 4% of GDP by 2006, but more difficult pension and healthcare
reforms will have to wait until after the next elections.
Privatization of the state-owned telecommunications firm Cesky
Telecom is scheduled to take place in 2005. Intensified
restructuring among large enterprises, improvements in the financial
sector, and effective use of available EU funds should strengthen
output growth.','0e33e1d5381d55b7fe844aeea72478d0b7ffb5e61beebc4499d774c66d619e6e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('289e9bf3c845abe73395d649edd21fb942a097ed8c638c6e3b5ca12f2e00b215',2005,'DK','Denmark','economy',697,'total: 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 3 (2004 est.)
total: 69
914 to 1,523 m: 6
under 914 m: 63 (2004 est.)
air pollution, principally from vehicle and power plant
emissions; nitrogen and phosphorus pollution of the North Sea;
drinking and surface water becoming polluted from animal wastes and
pesticides
Dhekelia
netting and trapping of small migrant songbirds in the
spring and autumn
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1.5% (2004)
36.38 billion kWh (2002)
31.63 billion kWh (2002)
8.9 billion kWh (2002)
11.1 billion kWh (2002)
NA
lowest 10%: 2%
highest 10%: 24% (2000 est.)
agriculture 4%, industry 17%, services 79% (2002 est.)
machinery and instruments, meat and meat products, dairy
products, fish, chemicals, furniture, ships, windmills
Germany 18%, Sweden 13.2%, UK 8.7%, US 5.8%, Netherlands
5.5%, Norway 5.4%, France 5% (2004)
metropolitan Denmark - 14 counties (amter, singular - amt)
and 2 boroughs* (amtskommuner, singular - amtskommune); Arhus,
Bornholm, Frederiksberg*, Frederiksborg, Fyn, Kobenhavn, Kobenhavn
(Copenhagen)*, Nordjylland, Ribe, Ringkobing, Roskilde,
Sonderjylland, Storstrom, Vejle, Vestsjalland, Viborg
note: since 2005 Bornholm may have become a borough; in the future
the counties may be replaced by regions; see separate entries for
the Faroe Islands and Greenland, which are part of the Kingdom of
Denmark and are self-governing overseas administrative divisions
barley, wheat, potatoes, sugar beets; pork, dairy products;
fish
97 (2004 est.)
11.36 births/1,000 population (2005 est.)
Royal Danish Army, Royal Danish Navy, Royal Danish Air
Force, Home Guard (Hjemmevaernet)
revenues: $136.1 billion
expenditures: $133.4 billion, including capital expenditures of $500
million (2004 est.)
This thoroughly modern market economy features high-tech
agriculture, up-to-date small-scale and corporate industry,
extensive government welfare measures, comfortable living standards,
a stable currency, and high dependence on foreign trade. Denmark is
a net exporter of food and energy and enjoys a comfortable balance
of payments surplus. Government objectives include streamlining the
bureaucracy and further privatization of state assets. The
government has been successful in meeting, and even exceeding, the
economic convergence criteria for participating in the third phase
(a common European currency) of the European Economic and Monetary
Union (EMU), but Denmark has decided not to join 12 other EU members
in the euro; even so, the Danish krone remains pegged to the euro.
Growth in 2004 was sluggish, yet above the scanty 0.3% of 2003.
Because of high GDP per capita, welfare benefits, a low Gini index,
and political stability, the Danish people enjoy living standards
topped by no other nation. A major long-term issue will be the sharp
decline in the ratio of workers to retirees.
Dhekelia
Economic activity is limited to providing services to the
military and their families located in Dhekelia. All food and
manufactured goods must be imported.','aa889a2c4152440980e1cfbd1a91f677f8269531be27f16a5b2fe77c0e251840','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f75bf9e4fd8adae6308382f2d504a2635e6e7f5eee7ed40b2852f925c6789140',2005,'DJ','Djibouti','economy',698,'total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1524 to 2437 m: 1 (2004 est.)
total: 10
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 3 (2004 est.)
inadequate supplies of potable water; limited arable land;
desertification; endangered species
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected agreements
4.4% (2004)
180 million kWh (2002)
167.4 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
50% (2001 est.)
lowest 10%: NA
highest 10%: NA
NA
reexports, hides and skins, coffee (in transit)
Somalia 63.8%, Yemen 22.6%, Ethiopia 5% (2004)
5 districts (cercles, singular - cercle); ''Ali Sabih,
Dikhil, Djibouti, Obock, Tadjoura
fruits, vegetables; goats, sheep, camels, animal hides
13 (2004 est.)
39.98 births/1,000 population (2005 est.)
Djibouti National Army (includes Navy and Air Force)
revenues: $135 million
expenditures: $182 million, including capital expenditures of NA
(1999 est.)
The economy is based on service activities connected with
the country''s strategic location and status as a free trade zone in
northeast Africa. Two-thirds of the inhabitants live in the capital
city, the remainder are mostly nomadic herders. Scanty rainfall
limits crop production to fruits and vegetables, and most food must
be imported. Djibouti provides services as both a transit port for
the region and an international transshipment and refueling center.
Djibouti has few natural resources and little industry. The nation
is, therefore, heavily dependent on foreign assistance to help
support its balance of payments and to finance development projects.
An unemployment rate of at least 50% continues to be a major
problem. While inflation is not a concern, due to the fixed tie of
the Djiboutian franc to the US dollar, the artificially high value
of the Djiboutian franc adversely affects Djibouti''s balance of
payments. Per capita consumption dropped an estimated 35% over the
last seven years because of recession, civil war, and a high
population growth rate (including immigrants and refugees). Faced
with a multitude of economic difficulties, the government has fallen
in arrears on long-term external debt and has been struggling to
meet the stipulations of foreign aid donors.','59b5a47b8fd17b4bb08f5818c45fef64be71d5b8c376f72c3834588e1cc45d8d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02d877db3296f333c8d3250b7a667982b748a179095acd23f515cc6bae7c5d18',2005,'DM','Dominica','economy',699,'total: 2
914 to 1,523 m: 2 (2004 est.)
NA
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
NA
68.41 million kWh (2002)
63.62 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
30% (2002 est.)
lowest 10%: NA
highest 10%: NA
agriculture 40%, industry and commerce 32%, services 28%
bananas, soap, bay oil, vegetables, grapefruit, oranges
UK 21.6%, Jamaica 14.8%, Antigua and Barbuda 8.8%, Guyana
7.5%, Japan 5.4%, Trinidad and Tobago 4.8%, US 4.3%, Saint Lucia 4%
(2004)
10 parishes; Saint Andrew, Saint David, Saint George, Saint
John, Saint Joseph, Saint Luke, Saint Mark, Saint Patrick, Saint
Paul, Saint Peter
bananas, citrus, mangoes, root crops, coconuts, cocoa;
forest and fishery potential not exploited
2 (2004 est.)
15.73 births/1,000 population (2005 est.)
no regular military forces; Commonwealth of Dominica Police
Force (includes Coast Guard)
revenues: $73.9 million
expenditures: $84.4 million, including capital expenditures of NA
(2001)
The Dominican economy depends on agriculture, primarily
bananas, and remains highly vulnerable to climatic conditions and
international economic developments. Production of bananas dropped
precipitously in 2003, a major reason for the 1% decline in GDP.
Tourism increased in 2003 as the government sought to promote
Dominica as an "ecotourism" destination. Development of the tourism
industry remains difficult, however, because of the rugged
coastline, lack of beaches, and the absence of an international
airport. The government began a comprehensive restructuring of the
economy in 2003 - including elimination of price controls,
privatization of the state banana company, and tax increases - to
address Dominica''s economic crisis and to meet IMF targets. In order
to diversify the island''s production base the government is
attempting to develop an offshore financial sector and is planning
to construct an oil refinery on the eastern part of the island.','cc49a5638b21af39820ae6a28744d736351a1ebbf141dff8f7e1559192ce73dd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be6c33f04a9c7629bfa68c70087b3ce7ba9dcafcd5d799b41cb5789efab07a3f',2005,'DO','Dominican Republic','economy',700,'total: 13
over 3,047 m: 3
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 1 (2004 est.)
East Timor
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 18
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 10 (2004 est.)
East Timor
total: 5
914 to 1,523 m: 3
under 914 m: 2 (2004 est.)
water shortages; soil eroding into the sea
damages coral reefs; deforestation
East Timor
widespread use of slash and burn agriculture has led to
deforestation and soil erosion
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: Law of the Sea
East Timor
NA
1.1% (1998)
East Timor
NA
9.583 billion kWh (2002)
East Timor
NA kWh (2002)
8.912 billion kWh (2002)
East Timor
NA kWh (2002)
0 kWh (2002)
East Timor
0 kWh (2002)
0 kWh (2002)
East Timor
0 kWh (2002)
25%
East Timor
42% (2003 est.)
lowest 10%: 2.1%
highest 10%: 37.9% (1998)
East Timor
lowest 10%: NA
highest 10%: NA
agriculture 17%, industry 24.3%, services and
government 58.7% (1998 est.)
East Timor
NA
ferronickel, sugar, gold, silver, coffee, cocoa,
tobacco, meats, consumer goods
East Timor
coffee, sandalwood, marble; note - the potential for oil
and vanilla exports
US 80%, South Korea 2.1%, Canada 1.9% (2004)
East Timor
Indonesia 100%
31 provinces (provincias, singular - provincia)
and 1 district* (distrito); Azua, Baoruco, Barahona, Dajabon,
Distrito Nacional*, Duarte, Elias Pina, El Seibo, Espaillat, Hato
Mayor, Independencia, La Altagracia, La Romana, La Vega, Maria
Trinidad Sanchez, Monsenor Nouel, Monte Cristi, Monte Plata,
Pedernales, Peravia, Puerto Plata, Salcedo, Samana, Sanchez Ramirez,
San Cristobal, San Jose de Ocoa, San Juan, San Pedro de Macoris,
Santiago, Santiago Rodriguez, Santo Domingo, Valverde
East Timor
13 administrative districts; Aileu, Ainaro, Baucau,
Bobonaro (Maliana), Cova-Lima (Suai), Dili, Ermera, Lautem (Los
Palos), Liquica, Manatuto, Manufahi (Same), Oecussi (Ambeno),
Viqueque
sugarcane, coffee, cotton, cocoa, tobacco, rice,
beans, potatoes, corn, bananas; cattle, pigs, dairy products, beef,
eggs
East Timor
coffee, rice, maize, cassava, sweet potatoes, soybeans,
cabbage, mangoes, bananas, vanilla
31 (2004 est.)
East Timor
8 (2004 est.)
23.28 births/1,000 population (2005 est.)
East Timor
27.19 births/1,000 population (2005 est.)
Army, Navy, Air Force
East Timor
East Timor Defense Force (Forcas de Defesa de
Timor-L''este, FDTL): Army, Navy (Armada) (2005)
revenues: $2.625 billion
expenditures: $3.382 billion, including capital expenditures of $1.1
billion (2004 est.)
East Timor
revenues: $107.7 million
expenditures: $73 million, including capital expenditures of NA
(2004 est.)
The Dominican Republic is a Caribbean
representative democracy which enjoyed GDP growth of more than 7% in
1998-2000. Growth subsequently plummeted as part of the global
economic slowdown. Although the country has long been viewed
primarily as an exporter of sugar, coffee, and tobacco, in recent
years the service sector has overtaken agriculture as the economy''s
largest employer, due to growth in tourism and free trade zones. The
country suffers from marked income inequality; the poorest half of
the population receives less than one-fifth of GNP, while the
richest 10% enjoys nearly 40% of national income. Growth turned
negative in 2003 with reduced tourism, a major bank fraud, and
limited growth in the US economy (the source of about 85% of export
revenues), but recovered slightly in 2004. Resumption of a badly
needed IMF loan, slowed due to government repurchase of electrical
power plants, is basic to the restoration of social and economic
stability. Newly elected President FERNANDEZ in mid-2004 promised
belt-tightening reform. His administration has passed tax reform and
is working to meet preconditions for a $600 IMF standby arrangement
to ease the country''s fiscal situation.
East Timor
In late 1999, about 70% of the economic infrastructure of
East Timor was laid waste by Indonesian troops and anti-independence
militias, and 300,000 people fled westward. Over the next three
years, however, a massive international program, manned by 5,000
peacekeepers (8,000 at peak) and 1,300 police officers, led to
substantial reconstruction in both urban and rural areas. By 2003,
all but about 30,000 of the refugees had returned. Growth was held
back in 2003 by extensive drought and the gradual winding down of
the international presence. The country faces great challenges in
continuing the rebuilding of infrastructure, strengthening the
infant civil administration, and generating jobs for young people
entering the workforce. One promising long-term project is the
planned development of oil and gas resources in nearby waters, which
have begun to supplement government revenues ahead of schedule.','d8b8b549c79d66a621db00a36a7ccabc7bbb8283ea32466d454033ba5cd9e027','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4187fd96a1facb0ef80e3e92eaa08b6760c926bd9749c371e5b0fde46d1e13f',2005,'EC','Ecuador','economy',701,'total: 62
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 18
914 to 1,523 m: 19
under 914 m: 18 (2004 est.)
total: 143
914 to 1,523 m: 30
under 914 m: 113 (2004 est.)
deforestation; soil erosion; desertification; water
pollution; pollution from oil production wastes in ecologically
sensitive areas of the Amazon Basin and Galapagos Islands
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous Wastes, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected agreements
2.2% (2004)
11.54 billion kWh (2002)
10.79 billion kWh (2002)
57 million kWh (2002)
0 kWh (2002)
45% (2001 est.)
lowest 10%: 2%
highest 10%: 32%
note: data for urban households only (October 2003)
agriculture 8%, industry 24%, services 68% (2001)
petroleum, bananas, cut flowers, shrimp
US 42.9%, Panama 14.3%, Peru 7.9%, Italy 4.6% (2004)
22 provinces (provincias, singular - provincia); Azuay,
Bolivar, Canar, Carchi, Chimborazo, Cotopaxi, El Oro, Esmeraldas,
Galapagos, Guayas, Imbabura, Loja, Los Rios, Manabi,
Morona-Santiago, Napo, Orellana, Pastaza, Pichincha, Sucumbios,
Tungurahua, Zamora-Chinchipe
bananas, coffee, cocoa, rice, potatoes, manioc (tapioca),
plantains, sugarcane; cattle, sheep, pigs, beef, pork, dairy
products; balsa wood; fish, shrimp
205 (2004 est.)
22.67 births/1,000 population (2005 est.)
Army, Navy (includes Naval Infantry, Naval Aviation, Coast
Guard), Air Force (Fuerza Aerea Ecuatoriana, FAE)
revenues: $7.9 billion
expenditures: planned $7.3 billion, including capital expenditures
of $1.6 billion (2004 est.)
Ecuador has substantial petroleum resources, which have
accounted for 40% of the country''s export earnings and one-fourth of
central government budget revenues in recent years. Consequently,
fluctuations in world market prices can have a substantial domestic
impact. In the late 1990s, Ecuador suffered its worst economic
crisis, with natural disasters and sharp declines in world petroleum
prices driving Ecuador''s economy into free fall in 1999. Real GDP
contracted by more than 6%, with poverty worsening significantly.
The banking system also collapsed, and Ecuador defaulted on its
external debt later that year. The currency depreciated by some 70%
in 1999, and, on the brink of hyperinflation, the MAHAUD government
announced it would dollarize the economy. A coup, however, ousted
MAHAUD from office in January 2000, and after a short-lived junta
failed to garner military support, Vice President Gustavo NOBOA took
over the presidency. In March 2000, Congress approved a series of
structural reforms that also provided the framework for the adoption
of the US dollar as legal tender. Dollarization stabilized the
economy, and growth returned to its pre-crisis levels in the years
that followed. Under the administration of Lucio GUTIERREZ - January
2003 to April 2005 - Ecuador benefited from higher world petroleum
prices, but the government has made little progress on economic
reforms necessary to reduce Ecuador''s vulnerability to petroleum
price swings and financial crises.','b39b98401db021211b2226a948e358e33c87210ad881a3cb016c8856a4577bed','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('764e9a4916727eb65043635e659e0f2ed8fdb9863f4d61c4f54fff86e7eec6e4',2005,'EG','Egypt','economy',702,'total: 72
over 3,047 m: 13
2,438 to 3,047 m: 38
1,524 to 2,437 m: 17
under 914 m: 4 (2004 est.)
total: 15
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 7 (2004 est.)
agricultural land being lost to urbanization and windblown
sands; increasing soil salination below Aswan High Dam;
desertification; oil pollution threatening coral reefs, beaches, and
marine habitats; other water pollution from agricultural pesticides,
raw sewage, and industrial effluents; very limited natural fresh
water resources away from the Nile which is the only perennial water
source; rapid growth in population overstraining the Nile and
natural resources
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
3.4% (2004)
81.27 billion kWh (2002)
75.58 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
16.7% (2000 est.)
lowest 10%: 4.4%
highest 10%: 25% (1995)
agriculture 32%, industry 17%, services 51% (2001 est.)
crude oil and petroleum products, cotton, textiles, metal
products, chemicals
Italy 11.9%, US 10.8%, UK 7%, Syria 6.2%, Germany 4.7%, Spain
4.2% (2004)
26 governorates (muhafazat, singular - muhafazah); Ad
Daqahliyah, Al Bahr al Ahmar, Al Buhayrah, Al Fayyum, Al Gharbiyah,
Al Iskandariyah, Al Isma''iliyah, Al Jizah, Al Minufiyah, Al Minya,
Al Qahirah, Al Qalyubiyah, Al Wadi al Jadid, Ash Sharqiyah, As
Suways, Aswan, Asyut, Bani Suwayf, Bur Sa''id, Dumyat, Janub Sina'',
Kafr ash Shaykh, Matruh, Qina, Shamal Sina'', Suhaj
cotton, rice, corn, wheat, beans, fruits, vegetables; cattle,
water buffalo, sheep, goats
87 (2004 est.)
23.32 births/1,000 population (2005 est.)
Army, Navy, Air Force, Air Defense Command
revenues: $15.42 billion
expenditures: $20.76 billion, including capital expenditures of $2.7
billion (2004 est.)
Lack of substantial progress on economic reform since the mid
1990s has limited foreign direct investment in Egypt and kept annual
GDP growth in the range of 2%-3% in 2001-03. However, in 2004 Egypt
implemented several measures to boost foreign direct investment. In
September 2004, Egypt pushed through custom reforms, proposed income
and corporate tax reforms, reduced energy subsidies, and privatized
several enterprises. The budget deficit rose to an estimated 8% of
GDP in 2004 compared to 6.1% of GDP the previous year, in part as a
result of these reforms. Monetary pressures on an overvalued
Egyptian pound led the government to float the currency in January
2003, leading to a sharp drop in its value and consequent
inflationary pressure. In 2004, the Central Bank implemented
measures to improve currency liquidity. Egypt reached record tourism
levels, despite the Taba and Nuweiba bombings in September 2004. The
development of an export market for natural gas is a bright spot for
future growth prospects, but improvement in the capital-intensive
hydrocarbons sector does little to reduce Egypt''s persistent
unemployment.','5fcc79bfa40b4a7f4970f76489c286dadb2f394cbec6cbc157994bb9eb72ddb8','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ec266862276277cff40065efbb681670fc9762a8dc902d2e0ae16b082d62270',2005,'SV','El Salvador','economy',703,'total: 4
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2004 est.)
total: 69
914 to 1,523 m: 15
under 914 m: 54 (2004 est.)
deforestation; soil erosion; water pollution;
contamination of soils from disposal of toxic wastes
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
1.1% (2003)
4.158 billion kWh (2004)
4.45 billion kWh (2004)
473 million kWh (2004)
91 million kWh (2004)
36.1% (2003 est.)
lowest 10%: 1.4%
highest 10%: 39.3% (2001)
agriculture 17.1%, industry 17.1%, services 65.8% (2003
est.)
offshore assembly exports, coffee, sugar, shrimp,
textiles, chemicals, electricity
US 65.6%, Guatemala 11.8%, Honduras 6.3% (2004)
14 departments (departamentos, singular - departamento);
Ahuachapan, Cabanas, Chalatenango, Cuscatlan, La Libertad, La Paz,
La Union, Morazan, San Miguel, San Salvador, Santa Ana, San Vicente,
Sonsonate, Usulutan
coffee, sugar, corn, rice, beans, oilseed, cotton,
sorghum; shrimp; beef, dairy products
73 (2004 est.)
27.04 births/1,000 population (2005 est.)
Army, Navy (FNES), Air Force (FAS)
revenues: $2.491 billion
expenditures: $2.782 billion, including capital expenditures of NA
(2004 est.)
GDP per capita is roughly half that of Brazil,
Argentina, and Chile, and the distribution of income is highly
unequal. The government is striving to open new export markets,
encourage foreign investment, modernize the tax and healthcare
systems, and stimulate the sluggish economy. Implementation of the
Central America-Dominican Republic Free Trade Agreement, ratified by
El Salvador in 2004, is viewed as a key policy to help achieve these
objectives. The trade deficit has been offset by annual remittances
from Salvadorans living abroad - 16% of GDP in 2004 - and external
aid. With the adoption of the US dollar as its currency, El Salvador
has lost control over monetary policy and must concentrate on
maintaining a disciplined fiscal policy.','81799e6a09320d5ba8ec4e1dba9e0a8d3da5b37ca6144190fe23de9aeec00447','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('547daa962900f16aad80863e4e8e66829df7fa10ff4989c86abfebb19683ffb6',2005,'GQ','Equatorial Guinea','economy',704,'total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
less than 914 m: 1 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
tap water is not potable; deforestation
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ship Pollution
signed, but not ratified: none of the selected agreements
2.5% (2004)
26.69 million kWh (2002)
24.82 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
petroleum, methanol, timber, cocoa
US 29.3%, China 22.8%, Spain 16%, Taiwan 14.9%,
Canada 6.8% (2004)
7 provinces (provincias, singular - provincia);
Annobon, Bioko Norte, Bioko Sur, Centro Sur, Kie-Ntem, Litoral,
Wele-Nzas
coffee, cocoa, rice, yams, cassava (tapioca),
bananas, palm oil nuts; livestock; timber
4 (2004 est.)
36.18 births/1,000 population (2005 est.)
Army, Navy, Air Force (2005)
revenues: $813.2 million
expenditures: $375.3 million, including capital expenditures of NA
(2004 est.)
The discovery and exploitation of large oil
reserves have contributed to dramatic economic growth in recent
years. Forestry, farming, and fishing are also major components of
GDP. Subsistence farming predominates. Although pre-independence
Equatorial Guinea counted on cocoa production for hard currency
earnings, the neglect of the rural economy under successive regimes
has diminished potential for agriculture-led growth (the government
has stated its intention to reinvest some oil revenue into
agriculture). A number of aid programs sponsored by the World Bank
and the IMF have been cut off since 1993 because of corruption and
mismanagement. No longer eligible for concessional financing because
of large oil revenues, the government has been unsuccessfully trying
to agree on a "shadow" fiscal management program with the World Bank
and IMF. Businesses, for the most part, are owned by government
officials and their family members. Undeveloped natural resources
include titanium, iron ore, manganese, uranium, and alluvial gold.
Growth presumably remained strong in 2004, led by oil.','0a78c3efadf2dbab9ffd2b08d718e62e4a43cb0bdf2f849500f5bfceb3080bf6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d5f8ba0d2ec1991b35796e3411a589cbad9373df61e662a864a6c502d03d202',2005,'ER','Eritrea','economy',705,'total: 4
over 3,047 m: 2
2,438 to 3,047 m: 2 (2004 est.)
total: 13
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m: 2 (2004 est.)
deforestation; desertification; soil erosion; overgrazing;
loss of infrastructure from civil warfare
party to: Biodiversity, Climate Change, Desertification,
Endangered Species
signed, but not ratified: none of the selected agreements
13.4% (2004)
246.6 million kWh (2002)
229.4 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
50% (2004 est.)
lowest 10%: NA
highest 10%: NA
agriculture 80%, industry and services 20%
livestock, sorghum, textiles, food, small manufactures (2000)
Malaysia 26.6%, Italy 17.1%, Japan 8%, Germany 6.6%, China
5%, UK 4.9%, US 4.7%, France 4.4%, Poland 4.2% (2004)
6 regions (zobatat, singular - zoba); Anseba, Debub
(Southern), Debubawi K''eyih Bahri (Southern Red Sea), Gash Barka,
Ma''akel (Central), Semenawi Keyih Bahri (Northern Red Sea)
sorghum, lentils, vegetables, corn, cotton, tobacco, coffee,
sisal; livestock, goats; fish
17 (2004 est.)
38.62 births/1,000 population (2005 est.)
Army, Navy, Air Force
revenues: $235.2 million
expenditures: $373.2 million, including capital expenditures of NA
(2004 est.)
Since independence from Ethiopia on 24 May 1993, Eritrea has
faced the economic problems of a small, desperately poor country.
Like the economies of many African nations, the economy is largely
based on subsistence agriculture, with 80% of the population
involved in farming and herding. The Ethiopian-Eritrea war in
1998-2000 severely hurt Eritrea''s economy. GDP growth fell to zero
in 1999 and to -12.1% in 2000. The May 2000 Ethiopian offensive into
northern Eritrea caused some $600 million in property damage and
loss, including losses of $225 million in livestock and 55,000
homes. The attack prevented planting of crops in Eritrea''s most
productive region, causing food production to drop by 62%. Even
during the war, Eritrea developed its transportation infrastructure,
asphalting new roads, improving its ports, and repairing war damaged
roads and bridges. Since the war ended, the government has
maintained a firm grip on the economy, expanding the use of the
military and party-owned businesses to complete Eritrea''s
development agenda. Erratic rainfall and the delayed demobilization
of agriculturalists from the military kept cereal production well
below normal, holding down growth in 2002-04. Eritrea''s economic
future depends upon its ability to master social problems such as
illiteracy, unemployment, and low skills, and to open its economy to
private enterprise so the diaspora''s money and expertise can foster
economic growth.','bdf5b7f59cf25de5d0c8dd3ea647ba8c7b429a1e31dfb46a9e24ce17c6174461','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9998fda1c832509580da8ac879a5b1c21a8c959bccdd46354d717363ebf371a8',2005,'EE','Estonia','economy',706,'total: 14
over 3,047 m: 1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 1 (2004 est.)
total: 15
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 4
under 914 m: 6 (2004 est.)
air polluted with sulfur dioxide from oil-shale burning
power plants in northeast; however, the amount of pollutants emitted
to the air have fallen steadily, the emissions of 2000 were 80% less
than in 1980; the amount of unpurified wastewater discharged to
water bodies in 2000 was one twentieth the level of 1980; in
connection with the start-up of new water purification plants, the
pollution load of wastewater decreased; Estonia has more than 1,400
natural and manmade lakes, the smaller of which in agricultural
areas need to be monitored; coastal seawater is polluted in certain
locations
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Endangered Species, Hazardous Wastes, Ship Pollution,
Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
2% (2002 est.)
8.301 billion kWh (2002)
6.358 billion kWh (2002)
200 million kWh (2002)
1.562 billion kWh (2002)
NA (2000)
lowest 10%: 3%
highest 10%: 29.8% (1998)
agriculture 11%, industry 20%, services 69% (1999 est.)
machinery and equipment 33%, wood and paper 15%, textiles
14%, food products 8%, furniture 7%, metals, chemical products (2001)
Finland 23.1%, Sweden 15.3%, Germany 8.4%, Latvia 7.9%,
Russia 5.7%, Lithuania 4.4% (2004)
15 counties (maakonnad, singular - maakond): Harjumaa
(Tallinn), Hiiumaa (Kardla), Ida-Virumaa (Johvi), Jarvamaa (Paide),
Jogevamaa (Jogeva), Laanemaa (Haapsalu), Laane-Virumaa (Rakvere),
Parnumaa (Parnu), Polvamaa (Polva), Raplamaa (Rapla), Saaremaa
(Kuressaare), Tartumaa (Tartu), Valgamaa (Valga), Viljandimaa
(Viljandi), Vorumaa (Voru)
note: counties have the administrative center name following in
parentheses
potatoes, vegetables; livestock and dairy products; fish
29 (2004 est.)
9.91 births/1,000 population (2005 est.)
Estonian Defense Forces: Ground Forces, Navy, Air Force and
Air Defense Staff, Republic Security Forces (internal and border
troops), Volunteer Defense League (Kaitseliit), Maritime Border
Guard, Coast Guard
note: Border Guards and Ministry of Internal Affairs become part of
the Estonian Defense Forces in wartime; the Coast Guard is
subordinate to the Ministry of Defense in peacetime and the Estonian
Navy in wartime
revenues: $4.622 billion
expenditures: $4.601 billion, including capital expenditures of NA
(2004 est.)
Estonia, as a new member of the World Trade Organization and
the European Union, has transitioned effectively to a modern market
economy with strong ties to the West, including the pegging of its
currency to the euro. The economy benefits from strong electronics
and telecommunications sectors and is greatly influenced by
developments in Finland, Sweden, and Germany, three major trading
partners. The current account deficit remains high; however, the
state budget enjoyed a surplus of $130 million in 2003.','dd22e646bfa5ff95356a9b2b27e221acac48d25a87aabb7a732709dd9ffea144','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db83738d81cae6c7db62099e0a9e62738a574619dfdc0f393ee2bb6ba9e10d68',2005,'ET','Ethiopia','economy',707,'total: 14
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 5
914 to 1,523 m: 1 (2004 est.)
European Union
total: 1,834
Falkland Islands (Islas Malvinas)
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2004 est.)
total: 69
over 3,047 m: 3
2,438 to 3,047 m: 3
1,524 to 2,437 m: 13
914 to 1,523 m: 27
under 914 m: 23 (2004 est.)
Europa Island
total: 1
914 to 1,523 m: 1 (2004 est.)
European Union
total: 1,296
Falkland Islands (Islas Malvinas)
total: 3
under 914 m: 3 (2004 est.)
deforestation; overgrazing; soil erosion; desertification;
water shortages in some areas from water-intensive farming and poor
management
Europa Island
NA
European Union
NA
Falkland Islands (Islas Malvinas)
overfishing by unlicensed vessels
is a problem; reindeer were introduced to the islands in 2001 for
commercial reasons; this is the only commercial reindeer herd in the
world unaffected by the Chornobyl disaster
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Environmental Modification, Law of the Sea
European Union
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 94, Antarctic-Marine Living Resources,
Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Tropical Timber 82, Tropical Timber 94
signed but not ratified: Air Pollution-Volatile Organic Compounds
4.6% (2004)
Falkland Islands (Islas Malvinas)
NA
2.149 billion kWh (2002)
European Union
2.888 trillion kWh (2002 est.)
Falkland Islands (Islas Malvinas)
19.06 million kWh (2002)
1.998 billion kWh (2002)
European Union
2.661 trillion kWh (2002 est.)
Falkland Islands (Islas Malvinas)
17.72 million kWh (2002)
0 kWh (2002)
European Union
268.5 billion kWh (2002 est.)
Falkland Islands (Islas Malvinas)
0 kWh (2002)
0 kWh (2002)
European Union
270.8 billion kWh (2002)
Falkland Islands (Islas Malvinas)
0 kWh (2002)
50% (2004 est.)
European Union
See individual country listings
Falkland Islands (Islas Malvinas)
NA
lowest 10%: 3%
highest 10%: 33.7% (1995)
European Union
lowest 10%: 2.9%
highest 10%: 25.4% (1995 est.)
Falkland Islands (Islas Malvinas)
lowest 10%: NA%
highest 10%: NA%
agriculture and animal husbandry 80%, industry and
construction 8%, government and services 12% (1985)
European Union
agriculture 4.5%, industry 27.4%, services 66.9%
note: the remainder is in miscellaneous public and private sector
industries and services (2004)
Falkland Islands (Islas Malvinas)
agriculture 95% (mostly
sheepherding and fishing)
coffee, qat, gold, leather products, live animals, oilseeds
European Union
machinery, motor vehicles, aircraft, plastics,
pharmaceuticals and other chemicals, fuels, iron and steel,
nonferrous metals, wood pulp and paper products, textiles, meat,
dairy products, fish, alcoholic beverages.
Falkland Islands (Islas Malvinas)
wool, hides, meat
Djibouti 13.3%, Germany 10%, Japan 8.4%, Saudi Arabia 5.6%,
US 5.2%, UAE 5%, Italy 4.6% (2004)
European Union
US 22.9%, Switzerland 6.9%, China 4.1%, Japan 4%
Falkland Islands (Islas Malvinas)
Spain 77.4%, UK 9.4%, US 4.9%
(2004)
9 ethnically-based states (kililoch, singular - kilil) and
2 self-governing administrations* (astedaderoch, singular -
astedader); Adis Abeba* (Addis Ababa), Afar, Amara (Amhara),
Binshangul Gumuz, Dire Dawa*, Gambela Hizboch (Gambela Peoples),
Hareri Hizb (Harari People), Oromiya (Oromia), Sumale (Somali),
Tigray, Ye Debub Biheroch Bihereseboch na Hizboch (Southern Nations,
Nationalities and Peoples)
Falkland Islands (Islas Malvinas)
none (overseas territory of the
UK; also claimed by Argentina)
cereals, pulses, coffee, oilseed, sugarcane, potatoes, qat;
hides, cattle, sheep, goats
European Union
wheat, barley, oilseeds, sugar beets, wine, grapes,
dairy products, cattle, sheep, pigs, poultry, fish
Falkland Islands (Islas Malvinas)
fodder and vegetable crops; sheep,
dairy products
83 (2004 est.)
Europa Island
1 (2004 est.)
European Union
3,130 (2004 est.)
Falkland Islands (Islas Malvinas)
5 (2004 est.)
38.61 births/1,000 population (2005 est.)
European Union
10 births/1,000 population (July 2005 est.)
Falkland Islands (Islas Malvinas)
NA births/1,000 population (2005
est.)
Ethiopian National Defense Force (ENDF): Ground Forces, Air
Force
note: Ethiopia is landlocked and has no navy; following the
secession of Eritrea, Ethiopian naval facilities remained in
Eritrean possession (2003)
Falkland Islands (Islas Malvinas)
no regular military forces
revenues: $1.887 billion
expenditures: $2.388 billion, including capital expenditures of $788
million (2004 est.)
Falkland Islands (Islas Malvinas)
revenues: $66.2 million
expenditures: $67.9 million, including capital expenditures of $23.2
million (FY98/99 est.)
Ethiopia''s poverty-stricken economy is based on
agriculture, accounting for half of GDP, 60% of exports, and 80% of
total employment. The agricultural sector suffers from frequent
drought and poor cultivation practices. Coffee is critical to the
Ethiopian economy with exports of some $156 million in 2002, but
historically low prices have seen many farmers switching to qat to
supplement income. The war with Eritrea in 1998-2000 and recurrent
drought have buffeted the economy, in particular coffee production.
In November 2001, Ethiopia qualified for debt relief from the Highly
Indebted Poor Countries (HIPC) initiative. Under Ethiopia''s land
tenure system, the government owns all land and provides long-term
leases to the tenants; the system continues to hamper growth in the
industrial sector as entrepreneurs are unable to use land as
collateral for loans. Drought struck again late in 2002, leading to
a 2% decline in GDP in 2003. Normal weather patterns late in 2003
helped agricultural and GDP growth recover in 2004.
Europa Island
no economic activity
European Union
Domestically, the European Union attempts to lower
trade barriers, adopt a common currency, and move toward convergence
of living standards. Internationally, the EU aims to bolster
Europe''s trade position and its political and economic power.
Because of the great differences in per capita income (from $10,000
to $28,000) and historic national animosities, the European
Community faces difficulties in devising and enforcing common
policies. For example, both Germany and France since 2003 have
flouted the member states'' treaty obligation to prevent their
national budgets from running more than a 3% deficit. In 2004, the
EU admitted 10 central and eastern European countries that are, in
general, less advanced technologically and economically than the
existing 15. Twelve EU member states introduced the euro as their
common currency on 1 January 1999. The UK, Sweden, and Denmark do
not now participate; the 10 new member states may choose to adopt
the euro when they meet the EU''s fiscal and monetary criteria and
the member states so agree.
Falkland Islands (Islas Malvinas)
The economy was formerly based on
agriculture, mainly sheep farming, but today fishing contributes the
bulk of economic activity. In 1987 the government began selling
fishing licenses to foreign trawlers operating within the Falklands
exclusive fishing zone. These license fees total more than $40
million per year, which goes to support the island''s health,
education, and welfare system. Squid accounts for 75% of the fish
taken. Dairy farming supports domestic consumption; crops furnish
winter fodder. Exports feature shipments of high-grade wool to the
UK and the sale of postage stamps and coins. The islands are now
self-financing except for defense. The British Geological Survey
announced a 200-mile oil exploration zone around the islands in
1993, and early seismic surveys suggest substantial reserves capable
of producing 500,000 barrels per day; to date no exploitable site
has been identified. An agreement between Argentina and the UK in
1995 seeks to defuse licensing and sovereignty conflicts that would
dampen foreign interest in exploiting potential oil reserves.
Tourism, especially eco-tourism, is increasing rapidly, with about
30,000 visitors in 2001. Another large source of income is interest
paid on money the government has in the bank. The British military
presence also provides a sizeable economic boost.','22ddbe9c913d9e55e8010d1ebecdc2dfb0aa10931ffcd4416df92b48c6c1318f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bae022ea8af1df48e3f48cf5e27ba8c9dc4b899e639a66b569a7c25924ecaeb0',2005,'FO','Faroe Islands','economy',708,'total: 1
914 to 1,523 m: 1 (2004 est.)
NA
NA
220 million kWh (2002)
204.6 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
fishing, fish processing, and manufacturing 33%,
construction and private services 33%, public services 34%
fish and fish products 94%, stamps, ships (1999)
Denmark 33.5%, UK 29.7%, Norway 8.4%, Nigeria 7.2%
(2004)
none (part of the Kingdom of Denmark; self-governing
overseas administrative division of Denmark); there are no
first-order administrative divisions as defined by the US
Government, but there are 49 municipalities
milk, potatoes, vegetables; sheep; salmon, other fish
1 (2004 est.)
13.97 births/1,000 population (2005 est.)
no regular military forces
revenues: $488 million
expenditures: $484 million, including capital expenditures of $21
million (1999)
The Faroese economy has had a strong performance since
1994, mostly as a result of increasing fish landings and high and
stable export prices. Unemployment is minimal and there are signs of
labor shortages in several sectors. The positive economic
development has helped the Faroese Home Rule Government produce
increasing budget surpluses, which in turn has helped to reduce the
large public debt, most of it owed to Denmark. However, the total
dependence on fishing makes the Faroese economy extremely
vulnerable, and the present fishing efforts appear in excess of what
is a sustainable level of fishing in the long term. Oil finds close
to the Faroese area give hope for deposits in the immediate Faroese
area, which may eventually lay the basis for a more diversified
economy and thus lessen dependence on Danish economic assistance.
Aided by a substantial annual subsidy (15% of GDP) from Denmark, the
Faroese have a standard of living not far below the Danes and other
Scandinavians.','3faf580f7e8d7e4b108e04b137bd42ee016300af58a52bd8c2602d3f7f57a39b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcd32e2bb50e6a0a65c429354092d0879af046413eed156c2c48e4fca7aa54ce',2005,'FJ','Fiji','economy',709,'total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 25
914 to 1,523 m: 6
under 914 m: 19 (2004 est.)
deforestation; soil erosion
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Law of the Sea,
Marine Life Conservation, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
2.2% (FY02)
750 million kWh (2002)
697.5 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
25.5% (1990-91)
lowest 10%: NA
highest 10%: NA
agriculture, including subsistence agriculture 70% (2001 est.)
sugar, garments, gold, timber, fish, molasses, coconut oil
US 24%, Australia 19%, UK 12.6%, Samoa 6.5%, Japan 4.1% (2004)
4 divisions and 1 dependency*; Central, Eastern, Northern,
Rotuma*, Western
sugarcane, coconuts, cassava (tapioca), rice, sweet potatoes,
bananas; cattle, pigs, horses, goats; fish
28 (2004 est.)
22.73 births/1,000 population (2005 est.)
Republic of Fiji Military Forces (RFMF): Land Forces, Naval
Division (2005)
revenues: $427.9 million
expenditures: $531.4 million, including capital expenditures of NA
(2000 est.)
Fiji, endowed with forest, mineral, and fish resources, is one
of the most developed of the Pacific island economies, though still
with a large subsistence sector. Sugar exports and a growing tourist
industry - with 300,000 to 400,000 tourists annually - are the major
sources of foreign exchange. Sugar processing makes up one-third of
industrial activity, but is inefficient. Long-term problems include
low investment, uncertain land ownership rights, and the
government''s ability to manage its budget. Yet short-run economic
prospects are good, provided tensions do not again erupt between
indigenous Fijians and Indo-Fijians. Overseas remittances from
Fijians working in Kuwait and Iraq have increased significantly.','8805e2cf19bab96064611ad1fa65a4809e9e6ad5d03b8d59402b1120a43dc172','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1a64443a2758e567fe15a5fdd5b8d0c398b1dc0b6022add22eb5736e6956610',2005,'FI','Finland','economy',710,'total: 75
over 3,047 m: 2
2,438 to 3,047 m: 27
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 13 (2004 est.)
total: 73
914 to 1,523 m: 4
under 914 m: 69 (2004 est.)
air pollution from manufacturing and power plants
contributing to acid rain; water pollution from industrial wastes,
agricultural chemicals; habitat loss threatens wildlife populations
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
2% (FY98/99)
71.59 billion kWh (2002)
78.58 billion kWh (2002)
13.5 billion kWh (2002)
1.5 billion kWh (2002)
NA
lowest 10%: 4.2%
highest 10%: 21.6% (1991)
agriculture and forestry 8%, industry 22%, construction 6%,
commerce 14%, finance, insurance, and business services 10%,
transport and communications 8%, public services 32%
machinery and equipment, chemicals, metals; timber, paper,
pulp (1999)
Sweden 11.1%, Germany 10.7%, Russia 8.9%, UK 7%, US 6.4%,
Netherlands 5.1% (2004)
6 provinces (laanit, singular - laani); Aland, Etela-Suomen
Laani, Ita-Suomen Laani, Lansi-Suomen Laani, Lappi, Oulun Laani
barley, wheat, sugar beets, potatoes; dairy cattle; fish
148 (2004 est.)
10.5 births/1,000 population (2005 est.)
Finnish Defense Forces: Army, Navy (includes Coastal Defense
Forces), Air Force (2003)
revenues: $96.43 billion
expenditures: $91.95 billion, including capital expenditures of NA
(2004 est.)
Finland has a highly industrialized, largely free-market
economy, with per capita output roughly that of the UK, France,
Germany, and Italy. Its key economic sector is manufacturing -
principally the wood, metals, engineering, telecommunications, and
electronics industries. Trade is important, with exports equaling
two-fifths of GDP. Finland excels in high-tech exports, e.g., mobile
phones. Except for timber and several minerals, Finland depends on
imports of raw materials, energy, and some components for
manufactured goods. Because of the climate, agricultural development
is limited to maintaining self-sufficiency in basic products.
Forestry, an important export earner, provides a secondary
occupation for the rural population. Rapidly increasing integration
with Western Europe - Finland was one of the 12 countries joining
the European Economic and Monetary Union (EMU) - will dominate the
economic picture over the next several years. Growth in 2003 was
held back by the global slowdown but picked up in 2004. High
unemployment remains a persistent problem.','d7242cfdb42312770e32bb5c9f6749819d0e742a0e1a7bbe68ebeb142efe5504','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88e10a5450dbf23d3131755c2d08010f7426b1ecf8802c5162101a05bbb49ddc',2005,'FR','France','economy',711,'total: 283
over 3,047 m: 13
2,438 to 3,047 m: 28
1,524 to 2,437 m: 95
914 to 1,523 m: 82
under 914 m: 65 (2004 est.)
total: 195
1,524 to 2,437 m: 3
914 to 1,523 m: 72
under 914 m: 120 (2004 est.)
some forest damage from acid rain; air pollution from
industrial and vehicle emissions; water pollution from urban wastes,
agricultural runoff
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
2.6% (2003)
528.6 billion kWh (2002)
414.7 billion kWh (2002)
3 billion kWh (2002)
79.9 billion kWh (2002)
6.5% (2000)
lowest 10%: 2.8%
highest 10%: 25.1% (1995)
agriculture 4.1%, industry 24.4%, services 71.5% (1999)
machinery and transportation equipment, aircraft, plastics,
chemicals, pharmaceutical products, iron and steel, beverages
Germany 15%, Spain 9.5%, UK 9.3%, Italy 9%, Belgium 7.2%, US
6.7% (2004)
22 regions (regions, singular - region); Alsace, Aquitaine,
Auvergne, Basse-Normandie, Bourgogne, Bretagne, Centre,
Champagne-Ardenne, Corse, Franche-Comte, Haute-Normandie,
Ile-de-France, Languedoc-Roussillon, Limousin, Lorraine,
Midi-Pyrenees, Nord-Pas-de-Calais, Pays de la Loire, Picardie,
Poitou-Charentes, Provence-Alpes-Cote d''Azur, Rhone-Alpes
note: metropolitan France is divided into 22 regions (including the
"territorial collectivity" of Corse or Corsica) and is subdivided
into 96 departments; see separate entries for the overseas
departments (French Guiana, Guadeloupe, Martinique, Reunion) and the
overseas territorial collectivities (Mayotte, Saint Pierre and
Miquelon)
wheat, cereals, sugar beets, potatoes, wine grapes; beef,
dairy products; fish
478 (2004 est.)
12.15 births/1,000 population (2005 est.)
Army (includes Marines, Foreign Legion, Army Light Aviation),
Navy (includes naval air), Air Force (includes Air Defense),
National Gendarmerie
revenues: $1.005 trillion
expenditures: $1.08 trillion, including capital expenditures of $23
billion (2004 est.)
France is in the midst of transition, from a well-to-do
modern economy that has featured extensive government ownership and
intervention to one that relies more on market mechanisms. The
government has partially or fully privatized many large companies,
banks, and insurers. It retains controlling stakes in several
leading firms, including Air France, France Telecom, Renault, and
Thales, and is dominant in some sectors, particularly power, public
transport, and defense industries. The telecommunications sector is
gradually being opened to competition. France''s leaders remain
committed to a capitalism in which they maintain social equity by
means of laws, tax policies, and social spending that reduce income
disparity and the impact of free markets on public health and
welfare. The government has lowered income taxes and introduced
measures to boost employment and reform the pension system. In
addition, it is focusing on the problems of the high cost of labor
and labor market inflexibility resulting from the 35-hour workweek
and restrictions on lay-offs. The tax burden remains one of the
highest in Europe (43.8% of GDP in 2003). The lingering economic
slowdown and inflexible budget items have pushed the budget deficit
above the eurozone''s 3%-of-GDP limit. Finance Minister Herve GAYMARD
has promised that the 2005 deficit will fall below 3%.','652f81aa57197f8b4d8381b7b6833c0c322cea45617b9237848041635c2812fb','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a216dce411e379adab81ec97f5fd9b01b3a41e5ce5e5a2d85c0d2f98c7366a65',2005,'GF','French Guiana','economy',712,'total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2004 est.)
total: 7
914 to 1,523 m: 2
under 914 m: 5 (2004 est.)
NA
NA
460.1 million kWh (2002)
427.9 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 18.2%, industry 21.2%, services,
government, and commerce 60.6% (1980)
shrimp, timber, gold, rum, rosewood essence, clothing
France 62%, Switzerland 7%, US 2% (2001)
none (overseas department of France)
corn, rice, manioc (tapioca), sugar, cocoa,
vegetables, bananas; cattle, pigs, poultry
11 (2004 est.)
20.7 births/1,000 population (2005 est.)
no regular military forces; Gendarmerie
revenues: $225 million
expenditures: $390 million, including capital expenditures of $105
million (1996)
The economy is tied closely to the much larger French
economy through subsidies and imports. Besides the French space
center at Kourou (which accounts for 25% of GDP), fishing and
forestry are the most important economic activities. Forest and
woodland cover 90% of the country. The large reserves of tropical
hardwoods, not fully exploited, support an expanding sawmill
industry that provides sawn logs for export. Cultivation of crops is
limited to the coastal area, where the population is largely
concentrated; rice and manioc are the major crops. French Guiana is
heavily dependent on imports of food and energy. Unemployment is a
serious problem, particularly among younger workers.','1c4a9e05358461800bf62484553a88a725c44b5dfd867242c242256d596cc4fb','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0471f4440dbfd921f37b7e9ae952b257aeb591fdb651ff5eb290bb00099467a6',2005,'PF','French Polynesia','economy',713,'total: 37
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 23
under 914 m: 7 (2004 est.)
total: 13
914 to 1,523 m: 5
under 914 m: 8 (2004 est.)
NA
French Southern and Antarctic Lands
NA
380 million kWh (2002)
353.4 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 13%, industry 19%, services 68% (2002)
cultured pearls, coconut products, mother-of-pearl,
vanilla, shark meat
France 36.6%, Japan 22.7%, US 16.1%, Niger 13%,
Thailand 4.1% (2004)
none (overseas lands of France); there are no
first-order administrative divisions as defined by the US
Government, but there are 5 archipelagic divisions named Archipel
des Marquises, Archipel des Tuamotu, Archipel des Tubuai, Iles du
Vent, and Iles Sous-le-Vent
note: Clipperton Island is administered by France from French
Polynesia
French Southern and Antarctic Lands
none (overseas territory of
France); there are no first-order administrative divisions as
defined by the US Government, but there are 3 districts named Ile
Crozet, Iles Kerguelen, and Iles Saint-Paul et Amsterdam; excludes
"Adelie Land" claim in Antarctica that is not recognized by the US
coconuts, vanilla, vegetables, fruits; poultry,
beef, dairy products, coffee
50 (2004 est.)
French Southern and Antarctic Lands
none (2004 est.)
16.93 births/1,000 population (2005 est.)
no regular military forces; Gendarmerie and
National Police Force
revenues: $1 billion
expenditures: $900 million, including capital expenditures of $185
million (1996)
Since 1962, when France stationed military
personnel in the region, French Polynesia has changed from a
subsistence agricultural economy to one in which a high proportion
of the work force is either employed by the military or supports the
tourist industry. With the halt of French nuclear testing in 1996,
the military contribution to the economy fell sharply. Tourism
accounts for about one-fourth of GDP and is a primary source of hard
currency earnings. Other sources of income are pearl farming and
deep-sea commercial fishing. The small manufacturing sector
primarily processes agricultural products. The territory benefits
substantially from development agreements with France aimed
principally at creating new businesses and strengthening social
services.
French Southern and Antarctic Lands
Economic activity is limited to
servicing meteorological and geophysical research stations and
French and other fishing fleets. The fish catches landed on Iles
Kerguelen by foreign ships are exported to France and Reunion.','9d86c98024526f9ae1ef76318c50d40c9b70b13d33bc03dac642ca516607e061','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15680a96b6a484e0df378ec7b1530fd2e9c3a6f6a89986240c9dbd1f6a91eb1a',2005,'GA','Gabon','economy',714,'total: 11
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 8
914 to 1,523 m: 1 (2004 est.)
Gambia, The
total: 1
over 3,047 m: 1 (2004 est.)
Gaza Strip
total: 1
over 3,047 m: 1 (2004 est.)
total: 45
1,524 to 2,437 m: 7
914 to 1,523 m: 15
under 914 m: 23 (2004 est.)
Gaza Strip
total: 1
under 914 m: 1 (2004 est.)
deforestation; poaching
Gambia, The
deforestation; desertification; water-borne diseases
prevalent
Gaza Strip
desertification; salination of fresh water; sewage
treatment; water-borne disease; soil degradation; depletion and
contamination of underground water resources
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected agreements
Gambia, The
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
2% (2004)
Gambia, The
0.3% (2004)
Gaza Strip
NA
1.161 billion kWh (2002)
Gambia, The
90.31 million kWh (2002)
Gaza Strip
NA kWh; note - electricity supplied by Israel
1.08 billion kWh (2002)
Gambia, The
83.99 million kWh (2002)
Gaza Strip
NA kWh
0 kWh (2002)
Gambia, The
0 kWh (2002)
Gaza Strip
NA kWh; note - electricity supplied by Israel (2001)
0 kWh (2002)
Gambia, The
0 kWh (2002)
Gaza Strip
0 kWh (2001)
NA
Gambia, The
NA
Gaza Strip
81% (2004 est.)
lowest 10%: NA
highest 10%: NA
Gambia, The
lowest 10%: NA
highest 10%: NA
Gaza Strip
lowest 10%: NA
highest 10%: NA
agriculture 60%, industry 15%, services 25%
Gambia, The
agriculture 75%, industry, commerce, and services 19%,
government 6%
Gaza Strip
agriculture 14%, industry 19%, services 66% (2004)
crude oil 77%, timber, manganese, uranium (2001)
Gambia, The
peanut products, fish, cotton lint, palm kernels,
re-exports
Gaza Strip
citrus, flowers
US 53.3%, China 8.5%, France 7.4% (2004)
Gambia, The
India 21.4%, Thailand 15.1%, UK 13.7%, France 12.9%,
Germany 8.7%, Italy 7.5% (2004)
Gaza Strip
Israel, Egypt, West Bank
9 provinces; Estuaire, Haut-Ogooue, Moyen-Ogooue, Ngounie,
Nyanga, Ogooue-Ivindo, Ogooue-Lolo, Ogooue-Maritime, Woleu-Ntem
Gambia, The
5 divisions and 1 city*; Banjul*, Central River, Lower
River, North Bank, Upper River, Western
cocoa, coffee, sugar, palm oil, rubber; cattle; okoume (a
tropical softwood); fish
Gambia, The
rice, millet, sorghum, peanuts, corn, sesame, cassava
(tapioca), palm kernels; cattle, sheep, goats
Gaza Strip
olives, citrus, vegetables; beef, dairy products
56 (2004 est.)
Gambia, The
1 (2004 est.)
Gaza Strip
2 (2001)
note: includes Gaza International Airport (GIA), inaugurated on 24
November 1998 as part of agreements stipulated in the September 1995
Oslo II Accord and the 23 October 1998 Wye River Memorandum; GIA has
been largely closed since October 2000 by Israeli orders and its
runway was destroyed by the Israeli Defense Forces in December 2001
(2004 est.)
36.24 births/1,000 population (2005 est.)
Gambia, The
39.86 births/1,000 population (2005 est.)
Gaza Strip
40.03 births/1,000 population (2005 est.)
Army, Navy, Air Force, National Gendarmerie, National Police
Gambia, The
Gambian National Army (GNA), Gambian Navy (GN),
Presidential Guard, National Guard
Gaza Strip
in accordance with the peace agreement, the Palestinian
Authority is not permitted conventional military forces; there are,
however, public security forces (2002)
revenues: $2.129 billion
expenditures: $1.64 billion, including capital expenditures of $310
million (2004 est.)
Gambia, The
revenues: $44.85 million
expenditures: $59.94 million, including capital expenditures of $4.1
million (2004 est.)
Gaza Strip
revenues: $676.6 million
expenditures: $1.155 billion, including capital expenditures of NA;
note - these budget data include West Bank (2003)
Gabon enjoys a per capita income four times that of most of
sub-Saharan African nations. This has supported a sharp decline in
extreme poverty; yet because of high income inequality a large
proportion of the population remains poor. Gabon depended on timber
and manganese until oil was discovered offshore in the early 1970s.
The oil sector now accounts for 50% of GDP. Gabon continues to face
fluctuating prices for its oil, timber, and manganese exports.
Despite the abundance of natural wealth, poor fiscal management
hobbles the economy. Devaluation of its currency by 50% in January
1994 sparked a one-time inflationary surge, to 35%; the rate dropped
to 6% in 1996. The IMF provided a one-year standby arrangement in
1994-95, a three-year Enhanced Financing Facility (EFF) at near
commercial rates beginning in late 1995, and stand-by credit of $119
million in October 2000. Those agreements mandate progress in
privatization and fiscal discipline. France provided additional
financial support in January 1997 after Gabon had met IMF targets
for mid-1996. In 1997, an IMF mission to Gabon criticized the
government for overspending on off-budget items, overborrowing from
the central bank, and slipping on its schedule for privatization and
administrative reform. The rebound of oil prices in 1999-2000 helped
growth, but drops in production hampered Gabon from fully realizing
potential gains. In December 2000, Gabon signed a new agreement with
the Paris Club to reschedule its official debt. A follow-up
bilateral repayment agreement with the US was signed in December
2001. Gabon signed a 14 month Stand-By Arrangement with the IMF in
May 2004, and received Paris Club debt rescheduling later that year.
Short-term progress depends on an upbeat world economy and fiscal
and other adjustments in line with IMF policies.
Gambia, The
The Gambia has no significant mineral or natural
resource deposits and has a limited agricultural base. About 75% of
the population depends on crops and livestock for its livelihood.
Small-scale manufacturing activity features the processing of
peanuts, fish, and hides. Reexport trade normally constitutes a
major segment of economic activity, but a 1999 government-imposed
preshipment inspection plan, and instability of the Gambian dalasi
(currency) have drawn some of the reexport trade away from The
Gambia. The government''s 1998 seizure of the private peanut firm
Alimenta eliminated the largest purchaser of Gambian groundnuts; the
following two marketing seasons saw substantially lower prices and
sales. Despite an announced program to begin privatizing key
parastatals, no plans have been made public that would indicate that
the government intends to follow through on its promises.
Unemployment and underemployment rates remain extremely high;
short-run economic progress depends on sustained bilateral and
multilateral aid, on responsible government economic management, on
continued technical assistance from the IMF and bilateral donors,
and on expected growth in the construction sector.
Gaza Strip
High population density, limited land access, and strict
internal and external controls have kept economic conditions in the
Gaza Strip - the smaller of the two areas under the Palestinian
Authority - even more degraded than in the West Bank. An anticipated
Israeli withdrawal from the Gaza Strip in 2005 may offer some
medium-term opportunities for economic growth. The beginning of the
second intifadah in September 2000 sparked an economic downturn,
largely the result of Israeli closure policies; these policies,
which were imposed in response to security interests in Israel,
disrupted labor and commodity relationships with the Gaza Strip. In
2001, and even more severely in 2003, Israeli military measures in
Palestinian Authority areas resulted in the destruction of much
capital plant, the disruption of administrative structure, and
widespread business closures. Including the West Bank, the UN
estimates that more than 100,000 Palestinians out of the 125,000 who
used to work in Israel or in joint industrial zones have lost their
jobs. International aid of $2 billion to Gaza Strip and the West
Bank in 2004 prevented the complete collapse of the economy and
allowed some reforms in the government''s financial operations.
Meanwhile unemployment has continued at half the labor force.
ARAFAT''s death in 2004 leaves open more political options that could
affect the economy.','7eb6ac180ca0a7042d9c744e504ce53acdf4c94657f8a060bd244d1100cd2ddd','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75f816a41ead5fa71d350dba0875fccf55e5ae74cb55462bfc647035a83096ae',2005,'GE','Georgia','economy',715,'total: 17
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 5
914 to 1,523 m: 3
under 914 m: 1 (2004 est.)
total: 13
914 to 1,523 m: 3
under 914 m: 10 (2004 est.)
air pollution, particularly in Rust''avi; heavy pollution of
Mtkvari River and the Black Sea; inadequate supplies of potable
water; soil pollution from toxic chemicals
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected agreements
0.59% (FY00)
6.732 billion kWh (2002)
6.811 billion kWh (2002)
850 million kWh (2002)
300 million kWh (2002)
54% (2001 est.)
lowest 10%: 2.3%
highest 10%: 27.9% (1996)
agriculture 40%, industry 20%, services 40% (1999 est.)
scrap metal, machinery, chemicals; fuel reexports; citrus
fruits, tea, wine
Turkey 18.3%, Turkmenistan 17.8%, Russia 16.2%, Armenia
8.4%, UK 4.9% (2004)
9 regions (mkharebi, singular - mkhare), 9 cities
(k''alak''ebi, singular - k''alak''i), and 2 autonomous republics
(avtomnoy respubliki, singular - avtom respublika)
regions: Guria, Imereti, Kakheti, Kvemo Kartli, Mtskheta-Mtianeti,
Racha-Lechkhumi and Kvemo Svaneti, Samegrelo and Zemo Svaneti,
Samtskhe-Javakheti, Shida Kartli
cities: Chiat''ura, Gori, K''ut''aisi, P''ot''i, Rust''avi, T''bilisi,
Tqibuli, Tsqaltubo, Zugdidi
autonomous republics: Abkhazia or Ap''khazet''is Avtonomiuri
Respublika (Sokhumi), Ajaria or Acharis Avtonomiuri Respublika
(Bat''umi)
note: the administrative centers of the 2 autonomous republics are
shown in parentheses
citrus, grapes, tea, hazelnuts, vegetables; livestock
30 (2004 est.)
10.25 births/1,000 population (2005 est.)
Ground Forces (includes National Guard), Air and Air Defense
Forces, Maritime Defense Force, Interior Forces
revenues: $671.7 million
expenditures: $804.7 million, including capital expenditures of NA
(2004 est.)
Georgia''s main economic activities include the cultivation
of agricultural products such as citrus fruits, tea, hazelnuts, and
grapes; mining of manganese and copper; and output of a small
industrial sector producing alcoholic and nonalcoholic beverages,
metals, machinery, and chemicals. The country imports the bulk of
its energy needs, including natural gas and oil products. Its only
sizable internal energy resource is hydropower. Despite the severe
damage the economy has suffered due to civil strife, Georgia, with
the help of the IMF and World Bank, has made substantial economic
gains since 1995, achieving positive GDP growth and curtailing
inflation. However, the Georgian Government has suffered from
limited resources due to a chronic failure to collect tax revenues.
Georgia''s new government is making progress in reforming the tax
code, enforcing taxes, and cracking down on corruption. Georgia also
suffers from energy shortages; it privatized the T''bilisi
electricity distribution network in 1998, but payment collection
rates remain low, both in T''bilisi and throughout the regions. The
country is pinning its hopes for long-term growth on its role as a
transit state for pipelines and trade. The construction on the
Baku-T''bilisi-Ceyhan oil pipeline and the Baku-T''bilisi-Erzerum gas
pipeline have brought much-needed investment and job opportunities.','b773f2dedf5460670811dc9e962016d4b79b6dd2f1df3b5e79954650bff5db78','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d98022b93c6851ce27f57c95576466315f3627047e0420589580d05fd02cf85',2005,'DE','Germany','economy',716,'total: 331
over 3,047 m: 13
2,438 to 3,047 m: 51
1,524 to 2,437 m: 62
914 to 1,523 m: 71
under 914 m: 134 (2004 est.)
total: 219
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 31
under 914 m: 185 (2004 est.)
emissions from coal-burning utilities and industries
contribute to air pollution; acid rain, resulting from sulfur
dioxide emissions, is damaging forests; pollution in the Baltic Sea
from raw sewage and industrial effluents from rivers in eastern
Germany; hazardous waste disposal; government established a
mechanism for ending the use of nuclear power over the next 15
years; government working to meet EU commitment to identify nature
preservation areas in line with the EU''s Flora, Fauna, and Habitat
directive
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1.5% (2003)
560 billion kWh (2003)
519.5 billion kWh (2003)
45.8 billion kWh (2003)
53.8 billion kWh (2003)
NA
lowest 10%: 3.6%
highest 10%: 25.1% (1997)
agriculture 2.8%, industry 33.4%, services 63.8% (1999)
machinery, vehicles, chemicals, metals and manufactures,
foodstuffs, textiles
France 10.3%, US 8.8%, UK 8.3%, Italy 7.2%, Netherlands
6.2%, Belgium 5.6%, Austria 5.4%, Spain 5% (2004)
13 states (Laender, singular - Land) and 3 free states*
(Freistaaten, singular - Freistaat); Baden-Wuerttemberg, Bayern*,
Berlin, Brandenburg, Bremen, Hamburg, Hessen,
Mecklenburg-Vorpommern, Niedersachsen, Nordrhein-Westfalen,
Rheinland-Pfalz, Saarland, Sachsen*, Sachsen-Anhalt,
Schleswig-Holstein, Thueringen*
potatoes, wheat, barley, sugar beets, fruit, cabbages;
cattle, pigs, poultry
550 (2004 est.)
8.33 births/1,000 population (2005 est.)
Federal Armed Forces (Bundeswehr): Army (Heer), Navy
(Deutsche Marine, includes naval air arm), Air Force (Luftwaffe),
Joint Support Service, Central Medical Service
revenues: $1.2 trillion
expenditures: $1.3 trillion, including capital expenditures of NA
(2004 est.)
Germany''s affluent and technologically powerful economy -
the fifth largest in the world - has become one of the slowest
growing economies in the euro zone. A quick turnaround is not in the
offing in the foreseeable future. Growth in 2001-03 fell short of
1%, rising to 1.7% in 2004. The modernization and integration of the
eastern German economy continues to be a costly long-term process,
with annual transfers from west to east amounting to roughly $70
billion. Germany''s aging population, combined with high
unemployment, has pushed social security outlays to a level
exceeding contributions from workers. Structural rigidities in the
labor market - including strict regulations on laying off workers
and the setting of wages on a national basis - have made
unemployment a chronic problem. Corporate restructuring and growing
capital markets are setting the foundations that could allow Germany
to meet the long-term challenges of European economic integration
and globalization, particularly if labor market rigidities are
further addressed. In the short run, however, the fall in government
revenues and the rise in expenditures have raised the deficit above
the EU''s 3% debt limit.','7973e2919cd5c93cf5d81b3c41a547293c85b3c0a78f7a27b593f6fd48997ce1','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fcf34f69ad67698795eea2f6074b4b0dc906a9abb2480014e8e4ead2c4ec9b5',2005,'GH','Ghana','economy',717,'total: 7
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2004 est.)
total: 5
914 to 1,523 m: 3
under 914 m: 2 (2004 est.)
Glorioso Islands
total: 1
914 to 1,523 m: 1 (2004 est.)
recurrent drought in north severely affects agricultural
activities; deforestation; overgrazing; soil erosion; poaching and
habitat destruction threatens wildlife populations; water pollution;
inadequate supplies of potable water
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Marine Life Conservation
0.6% (2004)
6.922 billion kWh (2002)
6.137 billion kWh (2002)
200 million kWh (2002)
500 million kWh (2002)
31.4% (1992 est.)
lowest 10%: 2.2%
highest 10%: 30.1% (1999)
agriculture 60%, industry 15%, services 25% (1999 est.)
gold, cocoa, timber, tuna, bauxite, aluminum, manganese ore,
diamonds
Mexico 69.8%, Netherlands 3.7%, UK 3% (2004)
10 regions; Ashanti, Brong-Ahafo, Central, Eastern, Greater
Accra, Northern, Upper East, Upper West, Volta, Western
cocoa, rice, coffee, cassava (tapioca), peanuts, corn, shea
nuts, bananas; timber
12 (2004 est.)
23.97 births/1,000 population (2005 est.)
Army, Navy, Air Force
revenues: $2.17 billion
expenditures: $2.56 billion, including capital expenditures of NA
(2004 est.)
Well endowed with natural resources, Ghana has roughly twice
the per capita output of the poorer countries in West Africa. Even
so, Ghana remains heavily dependent on international financial and
technical assistance. Gold, timber, and cocoa production are major
sources of foreign exchange. The domestic economy continues to
revolve around subsistence agriculture, which accounts for 34% of
GDP and employs 60% of the work force, mainly small landholders.
Ghana opted for debt relief under the Heavily Indebted Poor Country
(HIPC) program in 2002. Priorities include tighter monetary and
fiscal policies, accelerated privatization, and improvement of
social services. Receipts from the gold sector helped sustain GDP
growth in 2004. Inflation should ease, but remain a major internal
problem.','11a44a068093de2aab3ae8f700be2809043f4c74284839c3220676a594b03f4e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d379e6682801e0d3460a2ab377d4954657cc36867ebfc97bb60e1874d0805da6',2005,'GI','Gibraltar','economy',718,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
limited natural freshwater resources: large concrete or
natural rock water catchments collect rainwater (no longer used for
drinking water) and adequate desalination plant
Glorioso Islands
NA
104 million kWh (2002)
96.76 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture negligible, industry 40%, services 60%
(principally reexports) petroleum 51%, manufactured goods
41%, other 8%
France 19.4%, Spain 14.1%, Turkmenistan 12.1%, Switzerland
11.7%, Germany 10.1%, UK 9.1%, Greece 6.8% (2004)
none (overseas territory of the UK)
none
1 (2004 est.)
Glorioso Islands
1 (2004 est.)
10.87 births/1,000 population (2005 est.)
Royal Gibraltar Regiment
revenues: $307 million
expenditures: $284 million, including capital expenditures of NA
(FY00/01 est.)
Self-sufficient Gibraltar benefits from an extensive
shipping trade, offshore banking, and its position as an
international conference center. The British military presence has
been sharply reduced and now contributes about 7% to the local
economy, compared with 60% in 1984. The financial sector, tourism
(almost 5 million visitors in 1998), shipping services fees, and
duties on consumer goods also generate revenue. The financial
sector, the shipping sector, and tourism each contribute 25%-30% of
GDP. Telecommunications accounts for another 10%. In recent years,
Gibraltar has seen major structural change from a public to a
private sector economy, but changes in government spending still
have a major impact on the level of employment.
Glorioso Islands
no economic activity','043b7aa46c6213c83fc090d305994036297eb2e19cc0b4e6b493e4f81f3d2645','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4478f5603e5ab2552cc29bc9a11b68fe2727d1f063db36e8a50a42e7e8c5f9c',2005,'GR','Greece','economy',719,'total: 66
over 3,047 m: 5
2,438 to 3,047 m: 16
1,524 to 2,437 m: 20
914 to 1,523 m: 16
under 914 m: 9 (2004 est.)
total: 14
914 to 1,523 m: 3
under 914 m: 11 (2004 est.)
air pollution; water pollution
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 94, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds
4.3% (2003)
47.22 billion kWh (2002)
47.42 billion kWh (2002)
4.6 billion kWh (2002)
1.1 billion kWh (2002)
NA
lowest 10%: 3%
highest 10%: 28.3% (1998 est.)
agriculture 12%, industry 20%, services 68% (2004 est.)
food and beverages, manufactured goods, petroleum products,
chemicals, textiles
Germany 13.2%, Italy 10.3%, UK 7.5%, Bulgaria 6.3%, US 5.3%,
Cyprus 4.6%, Turkey 4.5%, France 4.2% (2004)
51 prefectures (nomoi, singular - nomos) and 1 autonomous
region*; Agion Oros* (Mt. Athos), Achaia, Aitolia kai Akarmania,
Argolis, Arkadia, Arta, Attiki, Chalkidiki, Chanion, Chios,
Dodekanisos, Drama, Evros, Evrytania, Evvoia, Florina, Fokidos,
Fthiotis, Grevena, Ileia, Imathia, Ioannina, Irakleion, Karditsa,
Kastoria, Kavala, Kefallinia, Kerkyra, Kilkis, Korinthia, Kozani,
Kyklades, Lakonia, Larisa, Lasithi, Lefkas, Lesvos, Magnisia,
Messinia, Pella, Pieria, Preveza, Rethynnis, Rodopi, Samos, Serrai,
Thesprotia, Thessaloniki, Trikala, Voiotia, Xanthi, Zakynthos
wheat, corn, barley, sugar beets, olives, tomatoes, wine,
tobacco, potatoes; beef, dairy products
80 (2004 est.)
9.72 births/1,000 population (2005 est.)
Hellenic Army, Hellenic Navy, Hellenic Air Force (Polemiki
Aeroporia, EPA)
revenues: $54.39 billion
expenditures: $64.4 billion, including capital expenditures of NA
(2004 est.)
Greece has a capitalist economy with the public sector
accounting for about 40% of GDP and with per capita GDP 70% of the
leading euro-zone economies. Tourism provides 15% of GDP. Immigrants
make up nearly one-fifth of the work force, mainly in menial jobs.
Greece is a major beneficiary of EU aid, equal to about 3.3% of
annual GDP. The Greek economy grew by about 4.0% for the past two
years, largely because of an investment boom and infrastructure
upgrades for the 2004 Athens Olympic Games. Despite strong growth,
Greece has failed to meet the EU''s Growth and Stability Pact budget
deficit criteria of 3% of GDP since 2000; public debt, inflation,
and unemployment are also above the eurozone average. Further
restructuring of the economy will need to include privatizing of
several state enterprises, undertaking pension and other reforms,
and minimizing bureaucratic inefficiencies.','4b2c153ff134dd4dcf36f2e4d7e70754612ec9fdd0971230a393b1e378ce0b73','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fae79a6ea057f0408dc3b54cb9f78b416bed9a373a122de94a04f0a638ce73a9',2005,'GL','Greenland','economy',720,'total: 9
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 5 (2004 est.)
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (2004 est.)
protection of the arctic environment; preservation of the
Inuit traditional way of life, including whaling and seal hunting
245 million kWh (2002)
227.9 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
fish and fish products 94% (prawns 63%)
Denmark 63.8%, Japan 12.6%, China 3.9% (2004)
3 districts (landsdele); Avannaa (Nordgronland), Tunu
(Ostgronland), Kitaa (Vestgronland)
note: there are 18 municipalities in Greenland
forage crops, garden and greenhouse vegetables; sheep,
reindeer; fish
14 (2004 est.)
15.93 births/1,000 population (2005 est.)
revenues: $646 million
expenditures: $629 million, including capital expenditures of $85
million (1999)
The economy remains critically dependent on exports of
fish and substantial support from the Danish Government, which
supplies about half of government revenues. The public sector,
including publicly-owned enterprises and the municipalities, plays
the dominant role in the economy. Despite several interesting
hydrocarbon and minerals exploration activities, it will take
several years before production can materialize. Tourism is the only
sector offering any near-term potential, and even this is limited
due to a short season and high costs.','def1f67712527bebc9f3154fc73b716c53c5b89b2cb5dd489dd82396ec848c37','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98e56a649c80848d9baf1d08a38d64c3aad38b7903d835134184f8981a306446',2005,'GD','Grenada','economy',721,'total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 1 (2004 est.)
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Law of the Sea, Ozone
Layer Protection, Whaling
signed, but not ratified: none of the selected agreements
NA
149 million kWh (2002)
138.6 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
32% (2000)
lowest 10%: NA
highest 10%: NA
agriculture 24%, industry 14%, services 62% (1999 est.)
bananas, cocoa, nutmeg, fruit and vegetables, clothing, mace
Saint Lucia 12.7%, US 12.2%, Antigua and Barbuda 8.7%,
Netherlands 7.9%, Saint Kitts and Nevis 7.8%, Dominica 7.8%, Germany
7.1%, France 4.6% (2004)
6 parishes and 1 dependency*; Carriacou and Petit
Martinique*, Saint Andrew, Saint David, Saint George, Saint John,
Saint Mark, Saint Patrick
bananas, cocoa, nutmeg, mace, citrus, avocados, root crops,
sugarcane, corn, vegetables
3 (2004 est.)
22.3 births/1,000 population (2005 est.)
no regular military forces; Royal Grenada Police Force
revenues: $85.8 million
expenditures: $102.1 million, including capital expenditures of $28
million (1997)
Grenada relies on tourism as its main source of foreign
exchange, especially since the construction of an international
airport in 1985. Strong performances in construction and
manufacturing, together with the development of an offshore
financial industry, have also contributed to growth in national
output.','f6b20d83588b998e84708acec7f2828fda2dd4a9384d59fde749683baa2740a0','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb7c5199d06b15f43b6fa5304aac69266dd3b678e6b175002113c0ca9cdf169f',2005,'GP','Guadeloupe','economy',722,'total: 8
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 5 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
NA
1.16 billion kWh (2002)
1.079 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
NA
bananas, sugar, rum
France 60%, Martinique 18%, US 4% (1999)
none (overseas department of France)
bananas, sugarcane, tropical fruits and vegetables;
cattle, pigs, goats
9 (2004 est.)
15.42 births/1,000 population (2005 est.)
no regular military forces
revenues: $225 million
expenditures: $390 million, including capital expenditures of $105
million (1996)
The Caribbean economy depends on agriculture, tourism,
light industry, and services. It also depends on France for large
subsidies and imports. Tourism is a key industry, with most tourists
from the US; an increasingly large number of cruise ships visit the
islands. The traditional sugarcane crop is slowly being replaced by
other crops, such as bananas (which now supply about 50% of export
earnings), eggplant, and flowers. Other vegetables and root crops
are cultivated for local consumption, although Guadeloupe is still
dependent on imported food, mainly from France. Light industry
features sugar and rum production. Most manufactured goods and fuel
are imported. Unemployment is especially high among the young.
Hurricanes periodically devastate the economy.','bba713b9725bbeddcc0a341817a2e96d52986c6eb84132fcd59fa4729fca4e9c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c40e5668c919d448b8a2e466ad5a02b1aac5693e1841f80cf4a84de38a6a157b',2005,'GU','Guam','economy',723,'total: 4
over 3,047 m: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
extirpation of native bird population by the rapid
proliferation of the brown tree snake, an exotic, invasive species
835 million kWh (2002)
776.6 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
23% (2001 est.)
lowest 10%: NA
highest 10%: NA
private 74% (industry 10%, trade 24%, other services 40%),
federal and territorial government 26% (2000 est.)
mostly transshipments of refined petroleum products;
construction materials, fish, food and beverage products
Japan 66.1%, South Korea 9.9%, Singapore 8.4% (2004)
none (territory of the US)
fruits, copra, vegetables; eggs, pork, poultry, beef
5 (2004 est.)
19.03 births/1,000 population (2005 est.)
revenues: $340 million
expenditures: $445 million, including capital expenditures of NA
(2000 est.)
The economy depends on US military spending, tourism, and the
export of fish and handicrafts. Total US grants, wage payments, and
procurement outlays amounted to $1 billion in 1998. Over the past 20
years, the tourist industry has grown rapidly, creating a
construction boom for new hotels and the expansion of older ones.
More than 1 million tourists visit Guam each year. The industry had
recently suffered setbacks because of the continuing Japanese
slowdown; the Japanese normally make up almost 90% of the tourists.
Most food and industrial goods are imported. Guam faces the problem
of building up the civilian economic sector to offset the impact of
military downsizing.','a65a578da58fda9315627e1c1afab8c0779b4bc16a04c17bad68ff632a3f3dae','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23295781f06d8ea3363086d2544d5145287b52943d50b52274a10f4a563780e8',2005,'GT','Guatemala','economy',724,'total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 2 (2004 est.)
total: 441
2,438 to 3,047 m: 1
1,524 to 2,437 m: 8
914 to 1,523 m: 109
under 914 m: 323 (2004 est.)
deforestation in the Peten rainforest; soil erosion; water
pollution
party to: Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
0.8% (2003)
6.608 billion kWh (2002)
5.76 billion kWh (2002)
55 million kWh (2002)
440 million kWh (2002)
75% (2004 est.)
lowest 10%: 1.6%
highest 10%: 46% (1998)
agriculture 50%, industry 15%, services 35% (1999 est.)
coffee, sugar, petroleum, apparel, bananas, fruits and
vegetables, cardamom
US 53%, El Salvador 11.4%, Honduras 7.1%, Mexico 4.1%
(2004)
22 departments (departamentos, singular - departamento);
Alta Verapaz, Baja Verapaz, Chimaltenango, Chiquimula, El Progreso,
Escuintla, Guatemala, Huehuetenango, Izabal, Jalapa, Jutiapa, Peten,
Quetzaltenango, Quiche, Retalhuleu, Sacatepequez, San Marcos, Santa
Rosa, Solola, Suchitepequez, Totonicapan, Zacapa
sugarcane, corn, bananas, coffee, beans, cardamom; cattle,
sheep, pigs, chickens
452 (2004 est.)
34.11 births/1,000 population (2005 est.)
Army, Navy (includes Marines), Air Force
revenues: $2.878 billion
expenditures: $3.411 billion, including capital expenditures of $750
million (2004 est.)
Guatemala is the largest and most populous of the Central
American countries with a GDP per capita roughly one-half that of
Brazil, Argentina, and Chile. The agricultural sector accounts for
about one-fourth of GDP, two-thirds of exports, and half of the
labor force. Coffee, sugar, and bananas are the main products. The
1996 signing of peace accords, which ended 36 years of civil war,
removed a major obstacle to foreign investment, but widespread
political violence and corruption scandals continue to dampen
investor confidence. The distribution of income remains highly
unequal, with perhaps 75% of the population below the poverty line.
Other ongoing challenges include increasing government revenues,
negotiating further assistance from international donors, upgrading
both government and private financial operations, curtailing drug
trafficking, and narrowing the trade deficit.','4a4b339da798eed348d78895a0adae246652f71ce40267ce5f823986c852e960','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d180fc9297fc2ed6a4be328477100d9b7f3c8980a855abfca86d42ede36292c',2005,'GG','Guernsey','economy',725,'total: 2
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
NA
NA kWh
NA kWh
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
tomatoes, flowers and ferns, sweet peppers, eggplant, other
vegetables
UK (regarded as internal trade)
none (British crown dependency); there are no first-order
administrative divisions as defined by the US Government, but there
are 10 parishes including Saint Peter Port, Saint Sampson, Vale,
Castel, Saint Saviour, Saint Pierre du Bois, Torteval, Forest, Saint
Martin, Saint Andrew
tomatoes, greenhouse flowers, sweet peppers, eggplant,
fruit; Guernsey cattle
2 (2004 est.)
9.01 births/1,000 population (2005 est.)
revenues: $539.2 million
expenditures: $448.3 million, including capital expenditures of NA
(2002 est.)
Financial services - banking, fund management, insurance -
account for about 55% of total income in this tiny, prosperous
Channel Island economy. Tourism, manufacturing, and horticulture,
mainly tomatoes and cut flowers, have been declining. Light tax and
death duties make Guernsey a popular tax haven. The evolving
economic integration of the EU nations is changing the environment
under which Guernsey operates.','e11cc099520081840ab89eaf9a6d5319698af3acef86beaa0b60ca03feba14c4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abdd7dc8b11f5f1697f2d5cd38b856908567751d7b6ba8dafdb532db2fb5d0f6',2005,'GN','Guinea','economy',726,'total: 5
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3 (2004 est.)
total: 11
1,524 to 2,437 m: 6
914 to 1,523 m: 3
under 914 m: 2 (2004 est.)
deforestation; inadequate supplies of potable water;
desertification; soil contamination and erosion; overfishing,
overpopulation in forest region; poor mining practices have led to
environmental damage
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1.7% (2004)
855 million kWh (2002)
795.2 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
40% (2003 est.)
lowest 10%: 2.6%
highest 10%: 32% (1994)
agriculture 80%, industry and services 20% (2000 est.)
bauxite, alumina, gold, diamonds, coffee, fish, agricultural
products
France 17.7%, Belgium 14.7%, UK 14.7%, Switzerland 12.8%,
Ukraine 4.2% (2004)
33 prefectures and 1 special zone (zone special)*; Beyla,
Boffa, Boke, Conakry*, Coyah, Dabola, Dalaba, Dinguiraye, Dubreka,
Faranah, Forecariah, Fria, Gaoual, Gueckedou, Kankan, Kerouane,
Kindia, Kissidougou, Koubia, Koundara, Kouroussa, Labe, Lelouma,
Lola, Macenta, Mali, Mamou, Mandiana, Nzerekore, Pita, Siguiri,
Telimele, Tougue, Yomou
rice, coffee, pineapples, palm kernels, cassava (tapioca),
bananas, sweet potatoes; cattle, sheep, goats; timber
16 (2004 est.)
42.03 births/1,000 population (2005 est.)
Army (includes Presidential Guard, Republican Guard), Navy,
Air Force, National Gendarmerie, General Directorate of National
Police
revenues: $382.7 million
expenditures: $711.4 million, including capital expenditures of NA
(2004 est.)
Guinea possesses major mineral, hydropower, and agricultural
resources, yet remains an underdeveloped nation. The country
possesses over 30% of the world''s bauxite reserves and is the
second-largest bauxite producer. The mining sector accounted for
about 75% of exports in 1999. Long-run improvements in government
fiscal arrangements, literacy, and the legal framework are needed if
the country is to move out of poverty. Fighting along the Sierra
Leonean and Liberian borders, as well as refugee movements, have
caused major economic disruptions, aggravating a loss in investor
confidence. Foreign mining companies have reduced expatriate staff.
Panic buying has created food shortages and inflation and caused
riots in local markets. Guinea is not receiving multilateral aid.
The IMF and World Bank cut off most assistance in 2003. Growth rose
slightly in 2004, primarily due to increases in global demand and
commodity prices on world markets.','472b47f71b068a230592d46cc3dfaf6b02e781c1e1cec032e14a4a2e955319ba','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('238872f3dc80a0b408ec3cf3324a94274dc076b35c3bd0d49d9b3223208a7f0a',2005,'GW','Guinea-Bissau','economy',727,'total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 25
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 20 (2004 est.)
deforestation; soil erosion; overgrazing; overfishing
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea, Wetlands
signed, but not ratified: none of the selected agreements
3.1% (2004)
55 million kWh (2002)
51.15 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: 0.5%
highest 10%: 42.4% (1991)
agriculture 82% (2000 est.)
cashew nuts, shrimp, peanuts, palm kernels, sawn lumber
India 52.1%, US 22.2%, Nigeria 13.2% (2004)
9 regions (regioes, singular - regiao); Bafata,
Biombo, Bissau, Bolama, Cacheu, Gabu, Oio, Quinara, Tombali; note -
Bolama may have been renamed Bolama/Bijagos
rice, corn, beans, cassava (tapioca), cashew nuts,
peanuts, palm kernels, cotton; timber; fish
28 (2004 est.)
37.65 births/1,000 population (2005 est.)
People''s Revolutionary Armed Force (FARP; includes
Army, Navy, and Air Force), paramilitary force
revenues: NA
expenditures: NA, including capital expenditures of NA
One of the 10 poorest countries in the world,
Guinea-Bissau depends mainly on farming and fishing. Cashew crops
have increased remarkably in recent years, and the country now ranks
sixth in cashew production. Guinea-Bissau exports fish and seafood
along with small amounts of peanuts, palm kernels, and timber. Rice
is the major crop and staple food. However, intermittent fighting
between Senegalese-backed government troops and a military junta
destroyed much of the country''s infrastructure and caused widespread
damage to the economy in 1998; the civil war led to a 28% drop in
GDP that year, with partial recovery in 1999-2002. Before the war,
trade reform and price liberalization were the most successful part
of the country''s structural adjustment program under IMF
sponsorship. The tightening of monetary policy and the development
of the private sector had also begun to reinvigorate the economy.
Because of high costs, the development of petroleum, phosphate, and
other mineral resources is not a near-term prospect. However,
unexploited offshore oil reserves could provide much-needed revenue
in the long run. The inequality of income distribution is one of the
most extreme in the world. The government and international donors
continue to work out plans to forward economic development from a
lamentably low base. In December 2003, the World Bank, IMF, and UNDP
were forced to step in to provide emergency budgetary support in the
amount of $107 million for 2004, representing over 80% of the total
national budget. Government drift and indecision, however, have
resulted in continued low growth in 2004.','1bea87df5591e6663deaaac95866d3009512729be5e4694eb9f63fbd630d4aa7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43be20e2844f79f11dc4d70c6f9de3a6e3000c2cfea9c55e91c6ce2a77cbaa46',2005,'GY','Guyana','economy',728,'total: 8
1,524 to 2,437 m: 3
under 914 m: 5 (2004 est.)
total: 41
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 32 (2004 est.)
water pollution from sewage and agricultural and industrial
chemicals; deforestation
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
0.9% (2004)
808 million kWh (2002)
751.4 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture NA%, industry NA%, services NA%
sugar, gold, bauxite/alumina, rice, shrimp, molasses, rum,
timber
Canada 23.2%, US 19.2%, UK 10.9%, Portugal 9%, Belgium 6.4%,
Jamaica 5.2% (2004)
10 regions; Barima-Waini, Cuyuni-Mazaruni, Demerara-Mahaica,
East Berbice-Corentyne, Essequibo Islands-West Demerara,
Mahaica-Berbice, Pomeroon-Supenaam, Potaro-Siparuni, Upper
Demerara-Berbice, Upper Takutu-Upper Essequibo
sugarcane, rice, wheat, vegetable oils; beef, pork, poultry,
dairy products; fish, shrimp
49 (2004 est.)
18.45 births/1,000 population (2005 est.)
Guyana Defense Force: Ground Forces, Coast Guard, Air Corps,
Guyana People''s Militia
revenues: $287.6 million
expenditures: $371.6 million, including capital expenditures of
$93.4 million (2004 est.)
The Guyanese economy exhibited moderate economic growth in
2001-02, based on expansion in the agricultural and mining sectors,
a more favorable atmosphere for business initiatives, a more
realistic exchange rate, fairly low inflation, and the continued
support of international organizations. Growth then slowed in 2003
and came back gradually in 2004, buoyed largely by increased export
earnings. Chronic problems include a shortage of skilled labor and a
deficient infrastructure. The government is juggling a sizable
external debt against the urgent need for expanded public
investment. The bauxite mining sector should benefit in the near
term from restructuring and partial privatization.','cc4b57a95dc892ed88c1bed67e70bc6e32017a93049191b0b5c806ae8e68d5c3','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd073dc872a6f0abbca73666ad6783e0b72103193bee29a4b99dacfdd5e47d26',2005,'HT','Haiti','economy',729,'total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (2004 est.)
total: 9
914 to 1,523 m: 4
under 914 m: 5 (2004 est.)
extensive deforestation (much of the remaining forested land
is being cleared for agriculture and used as fuel); soil erosion;
inadequate supplies of potable water
party to: Biodiversity, Climate Change, Desertification, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection
signed, but not ratified: Hazardous Wastes
Holy See (Vatican City)
party to: none of the selected agreements
signed, but not ratified: Air Pollution, Environmental Modification
0.9% (2003)
618 million kWh (2002)
Holy See (Vatican City)
NA kWh
574.7 million kWh (2002)
Holy See (Vatican City)
NA kWh
0 kWh (2002)
Holy See (Vatican City)
NA kWh; note - electricity supplied by Italy
0 kWh (2002)
Holy See (Vatican City)
0 kWh
80% (2003 est.)
Holy See (Vatican City)
NA%
lowest 10%: NA
highest 10%: NA
Holy See (Vatican City)
lowest 10%: NA%
highest 10%: NA%
agriculture 66%, industry 9%, services 25%
Holy See (Vatican City)
essentially services with a small amount of
industry; note - dignitaries, priests, nuns, guards, and 3,000 lay
workers live outside the Vatican
manufactures, coffee, oils, cocoa, mangoes
US 81.2%, Dominican Republic 7.3%, Canada 4.1% (2004)
9 departments (departements, singular - departement);
Artibonite, Centre, Grand ''Anse, Nord, Nord-Est, Nord-Ouest, Ouest,
Sud, Sud-Est
Holy See (Vatican City)
none
coffee, mangoes, sugarcane, rice, corn, sorghum, wood
13 (2004 est.)
Holy See (Vatican City)
none (2004 est.)
36.59 births/1,000 population (2005 est.)
the regular Haitian Armed Forces (FAdH) - Army, Navy, and Air
Force - have been demobilized but still exist on paper until or
unless they are constitutionally abolished
Holy See (Vatican City)
Pontifical Swiss Guard (Corpo della Guardia
Svizzera Pontificia)
revenues: $330.2 million
expenditures: $529.6 million, including capital expenditures of NA
(2004 est.)
Holy See (Vatican City)
revenues: $245.2 million
expenditures: $260.4 million, including capital expenditures of NA
(2002)
In this poorest country in the Western Hemisphere, 80% of the
population lives in abject poverty, and natural disasters frequently
sweep the nation. Two-thirds of all Haitians depend on the
agriculture sector, which consists mainly of small-scale subsistence
farming. Following legislative elections in May 2000, fraught with
irregularities, international donors - including the US and EU -
suspended almost all aid to Haiti. The economy shrank an estimated
1.2% in 2001, 0.9% in 2002, grew 0.4% in 2003, and shrank by 3.5% in
2004. Suspended aid and loan disbursements totaled more than $500
million at the start of 2003. Haiti also suffers from rampant
inflation, a lack of investment, and a severe trade deficit. In
early 2005 Haiti paid its arrears to the World Bank, paving the way
to reengagement with the Bank. The resumption of aid flows from all
donors is alleviating but not ending the nation''s bitter economic
problems. Civil strife in 2004 combined with extensive damage from
flooding in southern Haiti in May 2004 and Tropical Storm Jeanne in
northwestern Haiti in September 2004 further impoverished Haiti.','461cb50f8c79d54a2ec977be9a2ddbe4030a91110e6ee9d9b59effa0ffa618be','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe28c2ea18ed0020bb375a692d2c006e47336166b4e5718968f9c2bc107ca1f8',2005,'HN','Honduras','economy',730,'total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 3 (2004 est.)
total: 104
1,524 to 2,437 m: 2
914 to 1,523 m: 18
under 914 m: 84 (2004 est.)
urban population expanding; deforestation results from
logging and the clearing of land for agricultural purposes; further
land degradation and soil erosion hastened by uncontrolled
development and improper land use practices such as farming of
marginal lands; mining activities polluting Lago de Yojoa (the
country''s largest source of fresh water), as well as several rivers
and streams, with heavy metals
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected agreements
1.4% (2004)
3.626 billion kWh (2002)
3.771 billion kWh (2002)
415 million kWh (2002)
16 million kWh (2002)
53% (1993 est.)
lowest 10%: 0.6%
highest 10%: 42.7% (1998)
agriculture 34%, industry 21%, services 45% (2001 est.)
coffee, shrimp, bananas, gold, palm oil, fruit, lobster,
lumber
US 54.4%, El Salvador 8.1%, Germany 5.9%, Guatemala 5.4%
(2004)
18 departments (departamentos, singular - departamento);
Atlantida, Choluteca, Colon, Comayagua, Copan, Cortes, El Paraiso,
Francisco Morazan, Gracias a Dios, Intibuca, Islas de la Bahia, La
Paz, Lempira, Ocotepeque, Olancho, Santa Barbara, Valle, Yoro
bananas, coffee, citrus; beef; timber; shrimp
115 (2004 est.)
30.38 births/1,000 population (2005 est.)
Army, Navy (includes Naval Infantry), Air Force
revenues: $1.467 billion
expenditures: $1.722 billion, including capital expenditures of $106
million (2004 est.)
Honduras, one of the poorest countries in the Western
Hemisphere with an extraordinarily unequal distribution of income
and massive unemployment, is banking on expanded trade under the
U.S.-Central America Free Trade Agreement (CAFTA) and on debt relief
under the Heavily Indebted Poor Countries (HIPC) initiative. The
country has met most of its macroeconomic targets, and began a
three-year IMF Poverty Reduction and Growth Facility (PGRF) program
in February 2004. Growth remains dependent on the economy of the US,
its largest trading partner, on commodity prices, particularly
coffee, and on reduction of the high crime rate.','af80296dd0230151dfec5ac7fdd0ea946e8f2e4a9a84f93dc307fe337971956e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11c4b774a3acbf64b0944744d037360910b226c48238cfbe30e8ec70289a2c56',2005,'HK','Hong Kong','economy',731,'total: 4
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1523 m: 1
under 914 m: 1 (2004 est.)
air and water pollution from rapid urbanization
Howland Island
no natural fresh water resources
party to: Marine Dumping (associate member)
NA
35.51 billion kWh (2003)
38.45 billion kWh (2003)
10.4 billion kWh (2003)
3 billion kWh (2003)
NA
lowest 10%: NA
highest 10%: NA
manufacturing 7.5%, construction 2.9%, wholesale and
retail trade, restaurants, and hotels 43.7%, financing, insurance,
and real estate 19.2%, transport and communications 7.9%, community
and social services 18.5%
note: above data exclude public sector (2004 est.)
electrical machinery and appliances, textiles, apparel,
footwear, watches and clocks, toys, plastics, precious stones,
printed material
China 44%, US 17%, Japan 5.3% (2004)
none (special administrative region of China)
fresh vegetables, poultry, fish, pork
4 (2004 est.)
Howland Island
airstrip constructed in 1937 for scheduled refueling
stop on the round-the-world flight of Amelia EARHART and Fred NOONAN
- they left Lae, New Guinea, for Howland Island, but were never seen
again; the airstrip is no longer serviceable (2004 est.)
7.23 births/1,000 population (2005 est.)
no regular indigenous military forces; Hong Kong garrison
of China''s People''s Liberation Army (PLA) includes elements of the
PLA Ground Forces, PLA Navy, and PLA Air Force; these forces are
under the direct leadership of the Central Military Commission in
Beijing and under administrative control of the adjacent Guangzhou
Military Region
revenues: $26.6 billion
expenditures: $31.7 billion, including capital expenditures of $5.9
billion (2004 est.)
Hong Kong has a free market, entrepot economy, highly
dependent on international trade. Natural resources are limited, and
food and raw materials must be imported. Gross imports and exports
(i.e., including reexports to and from third countries) each exceed
GDP in dollar value. Even before Hong Kong reverted to Chinese
administration on 1 July 1997, it had extensive trade and investment
ties with China. Hong Kong has been further integrating its economy
with China because China''s growing openness to the world economy has
made manufacturing in China much more cost effective. Hong Kong''s
reexport business to and from China is a major driver of growth. Per
capita GDP is comparable to that of the four big economies of
Western Europe. GDP growth averaged a strong 5% from 1989 to 1997,
but Hong Kong suffered two recessions in the past six years because
of the Asian financial crisis in 1998 and the global downturn in
2001 and 2002. Although the Severe Acute Respiratory Syndrome (SARS)
outbreak also battered Hong Kong''s economy, a boom in tourism from
the mainland because of China''s easing of travel restrictions, a
return of consumer confidence, and a solid rise in exports resulted
in the resumption of strong growth in late 2003 and in 2004.
Howland Island
no economic activity','511cf29082dfd56d9c692df09b941efe39159652532ad55874bd7e59273d0f8a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d669f38fbea4da3c14c712d87f9eb4dd80f7724c12f6d0d4e5f2daa3f826b8e',2005,'HU','Hungary','economy',732,'total: 18
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 914 m: 1 (2004 est.)
total: 26
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 11
under 914 m: 9 (2004 est.)
the upgrading of Hungary''s standards in waste management,
energy efficiency, and air, soil, and water pollution to meet EU
requirements will require large investments
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Sulfur 94
1.75% (2002 est.)
34.07 billion kWh (2002)
35.99 billion kWh (2002)
12.6 billion kWh (2002)
8.3 billion kWh (2002)
8.6% (1993 est.)
lowest 10%: 4.1%
highest 10%: 20.5% (1998)
agriculture 6.2%, industry 27.1%, services 66.7% (2002)
machinery and equipment 61.1%, other manufactures 28.7%,
food products 6.5%, raw materials 2%, fuels and electricity 1.6%
(2003)
Germany 31.4%, Austria 6.8%, France 5.7%, Italy 5.6%, UK
5.1% (2004)
19 counties (megyek, singular - megye), 20 urban counties
(singular - megyei varos), and 1 capital city (fovaros)
counties: Bacs-Kiskun, Baranya, Bekes, Borsod-Abauj-Zemplen,
Csongrad, Fejer, Gyor-Moson-Sopron, Hajdu-Bihar, Heves,
Jasz-Nagykun-Szolnok, Komarom-Esztergom, Nograd, Pest, Somogy,
Szabolcs-Szatmar-Bereg, Tolna, Vas, Veszprem, Zala
urban counties: Bekescsaba, Debrecen, Dunaujvaros, Eger, Gyor,
Hodmezovasarhely, Kaposvar, Kecskemet, Miskolc, Nagykanizsa,
Nyiregyhaza, Pecs, Sopron, Szeged, Szekesfehervar, Szolnok,
Szombathely, Tatabanya, Veszprem, Zalaegerszeg
capital city: Budapest
wheat, corn, sunflower seed, potatoes, sugar beets; pigs,
cattle, poultry, dairy products
44 (2004 est.)
9.76 births/1,000 population (2005 est.)
Ground Forces, Air Forces
revenues: $46.07 billion
expenditures: $51.36 billion, including capital expenditures of NA
(2004 est.)
Hungary has made the transition from a centrally planned to
a market economy, with a per capita income one-half that of the Big
Four European nations. Hungary continues to demonstrate strong
economic growth and acceded to the European Union in May 2004. The
private sector accounts for over 80% of GDP. Foreign ownership of
and investment in Hungarian firms are widespread, with cumulative
foreign direct investment totaling more than $23 billion since 1989.
Hungarian sovereign debt was upgraded in 2000 and together with the
Czech Republic holds the highest rating among the Central European
transition economies; however, ratings agencies have expressed
concerns over Hungary''s unsustainable budget and current account
deficits. Inflation has declined from 14% in 1998 to 7% in 2004.
Unemployment has persisted around the 6% level, but Hungary''s labor
force participation rate of 57% is one of the lowest in the OECD.
Germany is by far Hungary''s largest economic partner. Policy
challenges include cutting the public sector deficit to 3% of GDP by
2008, from about 5% in 2004, and orchestrating an orderly interest
rate reduction without sparking capital outflows.','380ee14b673fa8dcfdc31181c3649a5e30b67c0575a30d97b1a7370979d75d67','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acbe26e04de2a922869e53c2a4140ee2ef03b2b8226cd8f1920eefa7d67d901c',2005,'IS','Iceland','economy',733,'total: 5
over 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (2004 est.)
total: 93
1,524 to 2,437 m: 3
914 to 1,523 m: 29
under 914 m: 61 (2004 est.)
water pollution from fertilizer runoff; inadequate
wastewater treatment
party to: Air Pollution, Air Pollution-Persistent Organic
Pollutants, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes,
Kyoto Protocol, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Transboundary Air Pollution, Wetlands
signed, but not ratified: Environmental Modification, Marine Life
Conservation
8.271 billion kWh (2002)
7.692 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture, fishing and fish processing 10.3%, industry
18.3%, services 71.4% (2003)
fish and fish products 70%, aluminum, animal products,
ferrosilicon, diatomite
UK 19.1%, Germany 17.2%, Netherlands 11.5%, US 9.8%, Spain
6.8%, Denmark 4.6% (2004)
8 regions; Austurland, Hofudhborgarsvaedhi, Nordhurland
Eystra, Nordhurland Vestra, Sudhurland, Sudhurnes, Vestfirdhir,
Vesturland
potatoes, green vegetables, mutton, dairy products, fish
98 (2004 est.)
13.73 births/1,000 population (2005 est.)
no regular armed forces; Icelandic National Police,
Icelandic Coast Guard (Islenska Landhelgisgaeslan)
revenues: $4.154 billion
expenditures: $4.058 billion, including capital expenditures of $467
million (2004 est.)
Iceland''s Scandinavian-type economy is basically
capitalistic, yet with an extensive welfare system (including
generous housing subsidies), low unemployment, and remarkably even
distribution of income. In the absence of other natural resources
(except for abundant geothermal power), the economy depends heavily
on the fishing industry, which provides 70% of export earnings and
employs 8% of the work force. The economy remains sensitive to
declining fish stocks as well as to fluctuations in world prices for
its main exports: fish and fish products, aluminum, and
ferrosilicon. Government policies include reducing the budget and
current account deficits, limiting foreign borrowing, containing
inflation, revising agricultural and fishing policies, diversifying
the economy, and privatizing state-owned industries. The government
remains opposed to EU membership, primarily because of Icelanders''
concern about losing control over their fishing resources. Iceland''s
economy has been diversifying into manufacturing and service
industries in the last decade, and new developments in software
production, biotechnology, and financial services are taking place.
The tourism sector is also expanding, with the recent trends in
ecotourism and whale watching. Growth had been remarkably steady in
1996-2001 at 3%-5%, but could not be sustained in 2002 in an
environment of global recession. Growth resumed in 2003, and
estimates call for strong growth until 2007, slowly dropping until
the end of the decade.','353efead0ea9a95d5b81310f47b01de40ad53f24cb8bcc1ce1f3b25c496ba751','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb622fa7a2d75dad80fe41b90e29e077be80e5a3d51a62fb8157f7d5cc126725',2005,'IN','India','economy',734,'total: 234
over 3,047 m: 14
2,438 to 3,047 m: 47
1,524 to 2,437 m: 78
914 to 1,523 m: 74
under 914 m: 21 (2004 est.)
total: 99
2,438 to 3,047 m: 3
1,524 to 2,437 m: 9
914 to 1,523 m: 42
under 914 m: 45 (2004 est.)
deforestation; soil erosion; overgrazing; desertification; air
pollution from industrial effluents and vehicle emissions; water
pollution from raw sewage and runoff of agricultural pesticides; tap
water is not potable throughout the country; huge and growing
population is overstraining natural resources
Indian Ocean
endangered marine species include the dugong, seals,
turtles, and whales; oil pollution in the Arabian Sea, Persian Gulf,
and Red Sea
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
2.93% (2005/06)
547.2 billion kWh (2002)
510.1 billion kWh (2002)
1.54 billion kWh (2002)
350 million kWh (2002)
25% (2002 est.)
lowest 10%: 3.5%
highest 10%: 33.5% (1997)
agriculture 60%, industry 17%, services 23% (1999)
textile goods, gems and jewelry, engineering goods, chemicals,
leather manufactures
US 17%, UAE 8.8%, China 5.5%, Hong Kong 4.7%, UK 4.5%,
Singapore 4.5% (2004)
28 states and 7 union territories*; Andaman and Nicobar
Islands*, Andhra Pradesh, Arunachal Pradesh, Assam, Bihar,
Chandigarh*, Chhattisgarh, Dadra and Nagar Haveli*, Daman and Diu*,
Delhi*, Goa, Gujarat, Haryana, Himachal Pradesh, Jammu and Kashmir,
Jharkhand, Karnataka, Kerala, Lakshadweep*, Madhya Pradesh,
Maharashtra, Manipur, Meghalaya, Mizoram, Nagaland, Orissa,
Pondicherry*, Punjab, Rajasthan, Sikkim, Tamil Nadu, Tripura,
Uttaranchal, Uttar Pradesh, West Bengal
rice, wheat, oilseed, cotton, jute, tea, sugarcane, potatoes;
cattle, water buffalo, sheep, goats, poultry; fish
333 (2004 est.)
22.32 births/1,000 population (2005 est.)
Army, Navy (includes naval air arm), Air Force, Coast Guard,
various security or paramilitary forces (includes Border Security
Force, Assam Rifles, National Security Guards, Indo-Tibetan Border
Police, Special Frontier Force, Central Reserve Police Force,
Central Industrial Security Force, Railway Protection Force, and
Defense Security Corps)
revenues: $67.3 billion
expenditures: $104 billion, including capital expenditures of $13.5
billion (2004 est.)
India''s diverse economy encompasses traditional village
farming, modern agriculture, handicrafts, a wide range of modern
industries, and a multitude of services. Services are the major
source of economic growth, though two-thirds of the workforce is in
agriculture. The UPA government has committed to furthering economic
reforms and developing basic infrastructure to improve the lives of
the rural poor and boost economic performance. Government controls
on foreign trade and investment have been reduced in some areas, but
high tariffs (averaging 20% in 2004) and limits on foreign direct
investment are still in place. The government has indicated it will
do more to liberalize investment in civil aviation, telecom, and
insurance sectors in the near term. Privatization of
government-owned industries has proceeded slowly, and continues to
generate political debate; continued social, political, and economic
rigidities hold back needed initiatives. The economy has posted an
excellent average growth rate of 6.8% since 1994, reducing poverty
by about 10 percentage points. India is capitalizing on its large
numbers of well-educated people skilled in the English language to
become a major exporter of software services and software workers.
Despite strong growth, the World Bank and others worry about the
combined state and federal budget deficit, running at approximately
9% of GDP. The huge and growing population is the fundamental
social, economic, and environmental problem. In late December 2004,
a major tsunami took nearly 11,000 lives, left almost 6,000 missing,
destroyed $1.2 billion worth of property, and severely damaged the
fishing fleet.
Indian Ocean
The Indian Ocean provides major sea routes connecting
the Middle East, Africa, and East Asia with Europe and the Americas.
It carries a particularly heavy traffic of petroleum and petroleum
products from the oilfields of the Persian Gulf and Indonesia. Its
fish are of great and growing importance to the bordering countries
for domestic consumption and export. Fishing fleets from Russia,
Japan, South Korea, and Taiwan also exploit the Indian Ocean, mainly
for shrimp and tuna. Large reserves of hydrocarbons are being tapped
in the offshore areas of Saudi Arabia, Iran, India, and western
Australia. An estimated 40% of the world''s offshore oil production
comes from the Indian Ocean. Beach sands rich in heavy minerals and
offshore placer deposits are actively exploited by bordering
countries, particularly India, South Africa, Indonesia, Sri Lanka,
and Thailand.','8ea4104d732d58df1b652b2b0507cabcf43ae07577f8a42059d7d19db00928f6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9981972c53e2b51c050f4c726cb51367c06e6fc01011b78d9c7ca677a071c28d',2005,'ID','Indonesia','economy',735,'total: 154
over 3,047 m: 4
2,438 to 3,047 m: 13
1,524 to 2,437 m: 44
914 to 1,523 m: 49
under 914 m: 44 (2004 est.)
Iran
total: 127
over 3,047 m: 39
2,438 to 3,047 m: 25
1,524 to 2,437 m: 26
914 to 1,523 m: 32
under 914 m: 5 (2004 est.)
total: 513
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 27
under 914 m: 480 (2004 est.)
Iran
total: 178
over 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 129
under 914 m: 39 (2004 est.)
deforestation; water pollution from industrial wastes,
sewage; air pollution in urban areas; smoke and haze from forest
fires
Iran
air pollution, especially in urban areas, from vehicle
emissions, refinery operations, and industrial effluents;
deforestation; overgrazing; desertification; oil pollution in the
Persian Gulf; wetland losses from drought; soil degradation
(salination); inadequate supplies of potable water; water pollution
from raw sewage and industrial waste; urbanization
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Life Conservation
Iran
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Marine Dumping, Ozone Layer
Protection, Wetlands
signed, but not ratified: Environmental Modification, Law of the
Sea, Marine Life Conservation
3% (2004)
Iran
3.3% (2003 est.)
110.2 billion kWh (2003)
Iran
129 billion kWh (2002)
92.35 billion kWh (2003)
Iran
119.9 billion kWh (2002)
0 kWh (2002)
Iran
0 kWh (2002)
0 kWh (2002)
Iran
0 kWh (2002)
27% (1999)
Iran
40% (2002 est.)
lowest 10%: 4%
highest 10%: 26.7% (1999)
Iran
lowest 10%: NA
highest 10%: NA
agriculture 45%, industry 16%, services 39% (1999 est.)
Iran
agriculture 30%, industry 25%, services 45% (2001 est.)
oil and gas, electrical appliances, plywood, textiles,
rubber
Iran
petroleum 80%, chemical and petrochemical products, fruits and
nuts, carpets
Japan 22.3%, US 12.3%, Singapore 8.4%, South Korea 6.8%,
China 6.4%, Malaysia 4.2% (2004)
Iran
Japan 18.4%, China 9.7%, Italy 6%, South Africa 5.8%, South
Korea 5.4%, Taiwan 4.6%, Turkey 4.4%, Netherlands 4% (2004)
30 provinces (propinsi-propinsi, singular - propinsi), 2
special regions* (daerah-daerah istimewa, singular - daerah
istimewa), and 1 special capital city district** (daerah khusus
ibukota); Aceh*, Bali, Banten, Bengkulu, Gorontalo, Irian Jaya
Barat, Jakarta Raya**, Jambi, Jawa Barat, Jawa Tengah, Jawa Timur,
Kalimantan Barat, Kalimantan Selatan, Kalimantan Tengah, Kalimantan
Timur, Kepulauan Bangka Belitung, Kepulauan Riau, Lampung, Maluku,
Maluku Utara, Nusa Tenggara Barat, Nusa Tenggara Timur, Papua, Riau,
Sulawesi Barat, Sulawesi Selatan, Sulawesi Tengah, Sulawesi
Tenggara, Sulawesi Utara, Sumatera Barat, Sumatera Selatan, Sumatera
Utara, Yogyakarta*; note - with the implementation of
decentralization on 1 January 2001, the 357 districts or regencies
became the key administrative units responsible for providing most
government services
Iran
30 provinces (ostanha, singular - ostan); Ardabil, Azarbayjan-e
Gharbi, Azarbayjan-e Sharqi, Bushehr, Chahar Mahall va Bakhtiari,
Esfahan, Fars, Gilan, Golestan, Hamadan, Hormozgan, Ilam, Kerman,
Kermanshah, Khorasan-e Janubi, Khorasan-e Razavi, Khorasan-e
Shemali, Khuzestan, Kohgiluyeh va Buyer Ahmad, Kordestan, Lorestan,
Markazi, Mazandaran, Qazvin, Qom, Semnan, Sistan va Baluchestan,
Tehran, Yazd, Zanjan
rice, cassava (tapioca), peanuts, rubber, cocoa, coffee,
palm oil, copra, poultry, beef, pork, eggs
Iran
wheat, rice, other grains, sugar beets, fruits, nuts, cotton;
dairy products, wool; caviar
667 (2004 est.)
Iran
305 (2004 est.)
20.71 births/1,000 population (2005 est.)
Iran
16.83 births/1,000 population (2005 est.)
Indonesia Armed Forces (TNI): Army (TNI-AD), Navy (TNI-AL,
includes Marines, Naval Air arm), Air Force (TNI-AU)
Iran
Islamic Republic of Iran Regular Forces (Artesh): Ground
Forces, Navy, Air Force (includes Air Defense)
Islamic Revolutionary Guard Corps (Sepah-e Pasdaran-e Enqelab-e
Eslami, IRGC): Ground Forces, Navy, Air Force, Qods Force (special
operations), and Basij Force (Popular Mobilization Army)
Law Enforcement Forces: (2004)
revenues: $52.13 billion
expenditures: $55.88 billion, including capital expenditures of NA
(2004 est.)
Iran
revenues: $43.34 billion
expenditures: $47.7 billion, including capital expenditures of $7.6
billion (2004 est.)
Indonesia, a vast polyglot nation, has restored financial
stability and pursued sober fiscal policies since the Asian
financial crisis, but many economic development problems remain,
including high unemployment, a fragile banking sector, endemic
corruption, inadequate infrastructure, a poor investment climate,
and unequal resource distribution among regions. Indonesia became a
net oil importer in 2004 due to declining production and lack of new
exploration investment. As a result, Jakarta is not reaping the
benefits of high world oil prices, and the cost of subsidizing
domestic fuel prices has placed an increasing strain on the budget.
Keys to future growth remain internal reform, building up the
confidence of international and domestic investors, and strong
global economic growth. In late December 2004, a major tsunami took
nearly 127,000 lives, left more than 93,000 missing and nearly
441,000 displaced, and destroyed $4.5 to $5.0 billion worth of
property.
Iran
Iran''s economy is marked by a bloated, inefficient state
sector, over reliance on the oil sector, and statist policies that
create major distortions throughout. Most economic activity is
controlled by the state. Private sector activity is typically
small-scale - workshops, farming, and services. President KHATAMI
has continued to follow the market reform plans of former President
RAFSANJANI, with limited progress. Relatively high oil prices in
recent years have enabled Iran to amass some $30 billion in foreign
exchange reserves, but have not eased economic hardships such as
high unemployment and inflation. The proportion of the economy
devoted to the development of weapons of mass destruction remains a
contentious issue with leading Western nations.','5edd3e3a89188591cc1e89bbce356260408db71a2dac9c18ad4165c53b8f1552','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c51f5c4a479da6287583dca7a9f7bfaac703ba6aca7eb697e37451a07ca0cfd7',2005,'IQ','Iraq','economy',736,'total: 79
over 3,047 m: 21
2,438 to 3,047 m: 36
1,524 to 2,437 m: 5
914 to 1,523 m: 7
under 914 m: 10 (2004 est.)
total: 32
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 12
under 914 m: 9 (2004 est.)
government water control projects have drained most of the
inhabited marsh areas east of An Nasiriyah by drying up or diverting
the feeder streams and rivers; a once sizable population of Marsh
Arabs, who inhabited these areas for thousands of years, has been
displaced; furthermore, the destruction of the natural habitat poses
serious threats to the area''s wildlife populations; inadequate
supplies of potable water; development of the Tigris and Euphrates
rivers system contingent upon agreements with upstream riparian
Turkey; air and water pollution; soil degradation (salination) and
erosion; desertification
party to: Law of the Sea
signed, but not ratified: Environmental Modification
NA
32.6 billion kWh (2004)
33.7 billion kWh (2004)
1.1 billion kWh (2004)
0 kWh (2004)
NA
lowest 10%: NA
highest 10%: NA
agriculture NA, industry NA, services NA
crude oil (83.9%), crude materials excluding fuels (8.0%), food
and live animals (5.0%)
US 51.9%, Spain 7.3%, Japan 6.6%, Italy 5.7%, Canada 5.2% (2004)
18 governorates (muhafazat, singular - muhafazah); Al Anbar, Al
Basrah, Al Muthanna, Al Qadisiyah, An Najaf, Arbil, As Sulaymaniyah,
At Ta''mim, Babil, Baghdad, Dahuk, Dhi Qar, Diyala, Karbala'', Maysan,
Ninawa, Salah ad Din, Wasit
wheat, barley, rice, vegetables, dates, cotton; cattle, sheep,
poultry
111; note - unknown number were damaged during the March-April
2003 war (2004 est.)
32.5 births/1,000 population (2005 est.)
Iraqi Armed Forces: Iraqi Regular Army (includes Iraqi Special
Operations Force, Iraqi Intervention Force), Iraqi Navy (former
Iraqi Coastal Defense Force), Iraqi Air Force (former Iraqi Army Air
Corps) (2005)
revenues: $17.1 billion
expenditures: $28.2 billion, including capital expenditures of $5.6
billion (2004 budget)
Iraq''s economy is dominated by the oil sector, which has
traditionally provided about 95% of foreign exchange earnings.
Iraq''s seizure of Kuwait in August 1990, subsequent international
economic sanctions, and damage from military action by an
international coalition beginning in January 1991 drastically
reduced economic activity. Although government policies supporting
large military and internal security forces and allocating resources
to key supporters of the regime hurt the economy, implementation of
the UN''s oil-for-food program beginning in December 1996 helped
improve conditions for the average Iraqi citizen. Iraq was allowed
to export limited amounts of oil in exchange for food, medicine, and
some infrastructure spare parts. In December 1999, the UN Security
Council authorized Iraq to export under the program as much oil as
required to meet humanitarian needs. The drop in GDP in 2001-02 was
largely the result of the global economic slowdown and lower oil
prices. Per capita food imports increased significantly, while
medical supplies and health care services steadily improved. Per
capita output and living standards were still well below the
pre-1991 level, but any estimates have a wide range of error. The
military victory of the US-led coalition in March-April 2003
resulted in the shutdown of much of the central economic
administrative structure. Although a comparatively small amount of
capital plant was damaged during the hostilities, looting, insurgent
attacks, and sabotage have undermined efforts to rebuild the
economy. Despite continuing political uncertainty, the Iraqi Interim
Government (IG) has founded the institutions needed to implement
economic policy, and has successfully concluded a debt reduction
agreement with the Paris Club. The high percentage gain estimated
for GDP in 2004 is the result of starting from a low base.','9f8171a421b2a539c043e67b5c15dea271260c4efcf7670b17e52b36d963566d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e42fe3928ffc10a30dcdfba470c3e8e2cde5f962166b20f3725db170cfbfd146',2005,'IE','Ireland','economy',737,'total: 15
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 914 m: 6 (2004 est.)
total: 21
914 to 1,523 m: 4
under 914 m: 17 (2004 est.)
water pollution, especially of lakes, from agricultural
runoff
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 94, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Marine Life Conservation
0.9% (FY00/01)
22.88 billion kWh (2002)
21.78 billion kWh (2002)
600 million kWh (2002)
100 million kWh (2002)
10% (1997 est.)
lowest 10%: 2%
highest 10%: 27.3% (1997)
agriculture 8%, industry 29%, services 63% (2002 est.)
machinery and equipment, computers, chemicals,
pharmaceuticals; live animals, animal products
US 19.7%, UK 17.7%, Belgium 14.7%, Germany 7.7%, France 6%,
Netherlands 4.6%, Italy 4.5% (2004)
26 counties; Carlow, Cavan, Clare, Cork, Donegal, Dublin,
Galway, Kerry, Kildare, Kilkenny, Laois, Leitrim, Limerick,
Longford, Louth, Mayo, Meath, Monaghan, Offaly, Roscommon, Sligo,
Tipperary, Waterford, Westmeath, Wexford, Wicklow
note: Cavan, Donegal, and Monaghan are part of Ulster Province
turnips, barley, potatoes, sugar beets, wheat; beef, dairy
products
36 (2004 est.)
14.47 births/1,000 population (2005 est.)
Army (includes Naval Service and Air Corps)
revenues: $62.51 billion
expenditures: $63.52 billion, including capital expenditures of $5.5
billion (2004 est.)
Ireland is a small, modern, trade-dependent economy with
growth averaging a robust 7% in 1995-2004. Agriculture, once the
most important sector, is now dwarfed by industry and services.
Industry accounts for 46% of GDP, about 80% of exports, and 29% of
the labor force. Although exports remain the primary engine for
Ireland''s growth, the economy has also benefited from a rise in
consumer spending, construction, and business investment. Per capita
GDP is 10% above that of the four big European economies and the
second highest in the EU behind Luxembourg. Over the past decade,
the Irish Government has implemented a series of national economic
programs designed to curb price and wage inflation, reduce
government spending, increase labor force skills, and promote
foreign investment. Ireland joined in circulating the euro on 1
January 2002 along with 11 other EU nations.','dd89377a1662ac34f512b5678a03c1a2c20b775dde5a6198922594f2f440c530','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a22bcae0b5b4f78acede103ac4881be4aa68bb816d62db8592f45026e725c81b',2005,'IL','Israel','economy',738,'total: 28
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 8
914 to 1,523 m: 10
under 914 m: 4 (2004 est.)
total: 23
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 20 (2004 est.)
limited arable land and natural fresh water resources pose
serious constraints; desertification; air pollution from industrial
and vehicle emissions; groundwater pollution from industrial and
domestic waste, chemical fertilizers, and pesticides
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
8.7% (FY02)
42.67 billion kWh (2002)
38.3 billion kWh (2002)
0 kWh (2002)
1.387 billion kWh (2002)
18% (2001 est.)
lowest 10%: 2.4%
highest 10%: 28.3% (1997)
agriculture, forestry, and fishing 2.6%, manufacturing 20.2%,
construction 7.5%, commerce 12.8%, transport, storage, and
communications 6.2%, finance and business 13.1%, personal and other
services 6.4%, public services 31.2% (1996)
machinery and equipment, software, cut diamonds, agricultural
products, chemicals, textiles and apparel
US 36.8%, Belgium 7.5%, Hong Kong 4.9% (2004)
6 districts (mehozot, singular - mehoz); Central, Haifa,
Jerusalem, Northern, Southern, Tel Aviv
citrus, vegetables, cotton; beef, poultry, dairy products
51 (2004 est.)
18.21 births/1,000 population (2005 est.)
Israel Defense Forces (IDF): Ground Corps, Navy, Air and
Space Force (includes Air Defense Forces); historically there have
been no separate Israeli military services
revenues: $48.09 billion
expenditures: $52.11 billion, including capital expenditures of NA
(2004 est.)
Israel has a technologically advanced market economy with
substantial government participation. It depends on imports of crude
oil, grains, raw materials, and military equipment. Despite limited
natural resources, Israel has intensively developed its agricultural
and industrial sectors over the past 20 years. Israel imports
substantial quantities of grain, but is largely self-sufficient in
other agricultural products. Cut diamonds, high-technology
equipment, and agricultural products (fruits and vegetables) are the
leading exports. Israel usually posts sizable current account
deficits, which are covered by large transfer payments from abroad
and by foreign loans. Roughly half of the government''s external debt
is owed to the US, which is its major source of economic and
military aid. The bitter Israeli-Palestinian conflict; difficulties
in the high-technology, construction, and tourist sectors; and
fiscal austerity in the face of growing inflation led to small
declines in GDP in 2001 and 2002. The economy grew at 1% in 2003,
with improvements in tourism and foreign direct investment. In 2004,
rising business and consumer confidence - as well as higher demand
for Israeli exports boosted GDP by 3.9%.','da71def5685bcc162b093a638e7845a5727d679194016fc70174f960152ae03b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('320092b8e9e262368df9dc6a9fbdb2748023facd369674688e5aeef2b8c8a7ca',2005,'IT','Italy','economy',739,'total: 96
over 3,047 m: 6
2,438 to 3,047 m: 32
1,524 to 2,437 m: 16
914 to 1,523 m: 30
under 914 m: 12 (2004 est.)
total: 38
1,524 to 2,437 m: 2
914 to 1,523 m: 18
under 914 m: 18 (2004 est.)
air pollution from industrial emissions such as sulfur
dioxide; coastal and inland rivers polluted from industrial and
agricultural effluents; acid rain damaging lakes; inadequate
industrial waste treatment and disposal facilities
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.8% (2004)
261.6 billion kWh (2002)
293.9 billion kWh (2002)
51.5 billion kWh (2002)
900 million kWh (2002)
NA
lowest 10%: 2.1%
highest 10%: 26.6% (2000)
agriculture 5%, industry 32%, services 63% (2001)
engineering products, textiles and clothing, production
machinery, motor vehicles, transport equipment, chemicals; food,
beverages and tobacco; minerals and nonferrous metals
Germany 13.6%, France 12.3%, US 8%, Spain 7.2%, UK 6.9%,
Switzerland 4.2% (2004)
16 regions (regioni, singular - regione) and 4 autonomous
regions* (regioni autonome, singular - regione autonoma); Abruzzo,
Basilicata, Calabria, Campania, Emilia-Romagna, Friuli-Venezia
Giulia*, Lazio, Liguria, Lombardia, Marche, Molise, Piemonte,
Puglia, Sardegna*, Sicilia, Toscana, Trentino-Alto Adige*, Umbria,
Valle d''Aosta*, Veneto
fruits, vegetables, grapes, potatoes, sugar beets, soybeans,
grain, olives; beef, dairy products; fish
134 (2004 est.)
8.89 births/1,000 population (2005 est.)
Army (Esercito Italiano, EI), Navy (Marina Militare Italiana,
MMI), Air Force (Aeronautica Militare Italiana, AMI), Carabinieri
Corps (Corpo dei Carabinieri, CC) (2005)
revenues: $768.9 billion
expenditures: $820.1 billion, including capital expenditures of NA
(2004 est.)
Italy has a diversified industrial economy with roughly the
same total and per capita output as France and the UK. This
capitalistic economy remains divided into a developed industrial
north, dominated by private companies, and a less developed,
welfare-dependent agricultural south, with 20% unemployment. Most
raw materials needed by industry and more than 75% of energy
requirements are imported. Over the past decade, Italy has pursued a
tight fiscal policy in order to meet the requirements of the
Economic and Monetary Unions and has benefited from lower interest
and inflation rates. The current government has enacted numerous
short-term reforms aimed at improving competitiveness and long-term
growth. Italy has moved slowly, however, on implementing needed
structural reforms, such as lightening the high tax burden and
overhauling Italy''s rigid labor market and over-generous pension
system, because of the current economic slowdown and opposition from
labor unions. But the leadership faces a severe economic constraint:
the budget has breached the 3% EU deficit ceiling.','3030127540a888cbaaa917e18b0fc825c8c6bf948674e6038b5ef28cc17b043f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65ab1a6830c85639ea1a171b841ad60176a58a433b552a5fb1fda4383acfdb89',2005,'JM','Jamaica','economy',740,'total: 11
2,438 to 3,047 m: 2
914 to 1,523 m: 4
under 914 m: 5 (2004 est.)
total: 24
914 to 1,523 m: 2
under 914 m: 22 (2004 est.)
Jan Mayen
total: 1
1,524 to 2,437 m: 1 (2004 est.)
heavy rates of deforestation; coastal waters polluted by
industrial waste, sewage, and oil spills; damage to coral reefs; air
pollution in Kingston results from vehicle emissions
Jan Mayen
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
0.4% (2003)
6.289 billion kWh (2002)
5.849 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
19.7% (2002 est.)
lowest 10%: 2.7%
highest 10%: 30.3% (2000)
agriculture 20.1%, industry 16.6%, services 63.4% (2003)
alumina, bauxite, sugar, bananas, rum, coffee, yams,
beverages, chemicals, wearing apparel, mineral fuels
US 17.4%, Canada 14.8%, France 13%, China 10.5%, UK 8.7%,
Netherlands 7.5%, Norway 6%, Germany 5.9% (2004)
14 parishes; Clarendon, Hanover, Kingston, Manchester,
Portland, Saint Andrew, Saint Ann, Saint Catherine, Saint Elizabeth,
Saint James, Saint Mary, Saint Thomas, Trelawny, Westmoreland
note: for local government purposes, Kingston and Saint Andrew were
amalgamated in 1923 into the present single corporate body known as
the Kingston and Saint Andrew Corporation
sugarcane, bananas, coffee, citrus, yams, vegetables,
poultry, goats, milk, crustaceans, and mollusks
35 (2004 est.)
Jan Mayen
1 (2004 est.)
16.56 births/1,000 population (2005 est.)
Jamaica Defense Force: Ground Forces, Coast Guard, Air Wing
revenues: $2.793 billion
expenditures: $3.157 billion, including capital expenditures of $236
million (2004 est.)
The Jamaican economy is heavily dependent on services, which
now account for 60% of GDP. The country continues to derive most of
its foreign exchange from tourism, remittances, and bauxite/alumina.
The global economic slowdown, particularly after the terrorist
attacks in the US on 11 September 2001, stunted economic growth; the
economy rebounded moderately in 2003-04, with brisk tourist seasons.
But the economy faces serious long-term problems: high interest
rates; increased foreign competition; a pressured, sometimes
sliding, exchange rate; a sizable merchandise trade deficit;
large-scale unemployment; and a growing internal debt, the result of
government bailouts to ailing sectors of the economy. The ratio of
debt to GDP is close to 150%. Inflation, previously a bright spot,
is expected to remain in the double digits. Uncertain economic
conditions have led to increased civil unrest, including gang
violence fueled by the drug trade. In 2004, the government faced the
difficult prospect of having to achieve fiscal discipline in order
to maintain debt payments while simultaneously attacking a serious
and growing crime problem which is hampering economic growth.
Attempts at deficit control were derailed by Hurricane Ivan in
September 2004, which required substantial government spending to
repair the damage. Despite the hurricane, tourism looks set to enjoy
solid growth for the foreseeable future.
Jan Mayen
Jan Mayen is a volcanic island with no exploitable natural
resources. Economic activity is limited to providing services for
employees of Norway''s radio and meteorological stations on the
island.','10784a769936276738d897ca77960272192430c4dcd9707e5dbb79bb4e0aecf4','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5542918dc723103c1917d58ae6514adf377d853eebd45e7d369ce45078582bb',2005,'JP','Japan','economy',741,'total: 143
over 3,047 m: 7
2,438 to 3,047 m: 37
1,524 to 2,437 m: 39
914 to 1,523 m: 28
under 914 m: 32 (2004 est.)
total: 31
over 3047 m: 1
914 to 1,523 m: 4
under 914 m: 26 (2004 est.)
air pollution from power plant emissions results in acid rain;
acidification of lakes and reservoirs degrading water quality and
threatening aquatic life; Japan is one of the largest consumers of
fish and tropical timber, contributing to the depletion of these
resources in Asia and elsewhere
Jarvis Island
no natural fresh water resources
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
1% (2004)
1.044 trillion kWh (2002)
971 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: 4.8%
highest 10%: 21.7% (1993)
agriculture 5%, industry 25%, services 70% (2002 est.)
transport equipment, motor vehicles, semiconductors,
electrical machinery, chemicals
US 22.7%, China 13.1%, South Korea 7.8%, Taiwan 7.4%, Hong
Kong 6.3% (2004)
47 prefectures; Aichi, Akita, Aomori, Chiba, Ehime, Fukui,
Fukuoka, Fukushima, Gifu, Gumma, Hiroshima, Hokkaido, Hyogo,
Ibaraki, Ishikawa, Iwate, Kagawa, Kagoshima, Kanagawa, Kochi,
Kumamoto, Kyoto, Mie, Miyagi, Miyazaki, Nagano, Nagasaki, Nara,
Niigata, Oita, Okayama, Okinawa, Osaka, Saga, Saitama, Shiga,
Shimane, Shizuoka, Tochigi, Tokushima, Tokyo, Tottori, Toyama,
Wakayama, Yamagata, Yamaguchi, Yamanashi
rice, sugar beets, vegetables, fruit, pork, poultry, dairy
products, eggs, fish
174 (2004 est.)
9.47 births/1,000 population (2005 est.)
Ground Self-Defense Force (Army), Maritime Self-Defense Force
(Navy), Air Self-Defense Force (Air Force)
revenues: $1.401 trillion
expenditures: $1.748 trillion, including capital expenditures
(public works only) of about $71 billion (2004 est.)
Government-industry cooperation, a strong work ethic, mastery
of high technology, and a comparatively small defense allocation (1%
of GDP) helped Japan advance with extraordinary rapidity to the rank
of second most technologically-powerful economy in the world after
the US and third-largest economy after the US and China, measured on
a purchasing power parity (PPP) basis. (Using market exhange rates
rather than PPP rates, Japan''s economy is larger than China''s.) One
notable characteristic of the economy is the working together of
manufacturers, suppliers, and distributors in closely-knit groups
called keiretsu. A second basic feature has been the guarantee of
lifetime employment for a substantial portion of the urban labor
force. Both features are now eroding. Industry, the most important
sector of the economy, is heavily dependent on imported raw
materials and fuels. The tiny agricultural sector is highly
subsidized and protected, with crop yields among the highest in the
world. Usually self sufficient in rice, Japan must import about 50%
of its requirements of other grain and fodder crops. Japan maintains
one of the world''s largest fishing fleets and accounts for nearly
15% of the global catch. For three decades overall real economic
growth had been spectacular: a 10% average in the 1960s, a 5%
average in the 1970s, and a 4% average in the 1980s. Growth slowed
markedly in the 1990s, averaging just 1.7%, largely because of the
after effects of overinvestment during the late 1980s and
contractionary domestic policies intended to wring speculative
excesses from the stock and real estate markets. From 2000 to 2003,
government efforts to revive economic growth met with little success
and were further hampered by the slowing of the US, European, and
Asian economies. In 2004, growth improved and the lingering fears of
deflation in prices and economic activity lessened. Japan''s huge
government debt, which totals more than 160% of GDP, and the aging
of the population are two major long-run problems. A rise in taxes
could be viewed as endangering the revival of growth. Robotics
constitutes a key long-term economic strength with Japan possessing
410,000 of the world''s 720,000 "working robots." Internal conflict
over the proper way to reform the ailing banking system continues.
Jarvis Island
no economic activity','632d320da8b5f070c39f487141f4b9333803b002cc8fc7ed1ea0e81b94d4a6b1','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05935ed3c1a67f5306ef588cbcec92ef741f5871c37368b613201e36bd834efd',2005,'JE','Jersey','economy',742,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
Johnston Atoll
total: 1
2,438 to 3,047 m: 1 (2004 est.)
NA
Johnston Atoll
no natural fresh water resources
630.1 million kWh (2004 est.)
NA kWh; note - electricity supplied by France
NA%
lowest 10%: NA%
highest 10%: NA%
light industrial and electrical goods, foodstuffs, textiles
UK
none (British crown dependency)
potatoes, cauliflower, tomatoes; beef, dairy products
1 (2004 est.)
Johnston Atoll
1 (2004 est.)
9.66 births/1,000 population (2005 est.)
revenues: $601 million
expenditures: $588 million, including capital expenditures of $98
million (2000 est.)
The Channel Island economy is based on international
financial services, agriculture, and tourism. In 1996 the finance
sector accounted for about 60% of the island''s output. Potatoes,
cauliflower, tomatoes, and especially flowers are important export
crops, shipped mostly to the UK. The Jersey breed of dairy cattle is
known worldwide and represents an important export income earner.
Milk products go to the UK and other EU countries. Tourism accounts
for 24% of GDP. In recent years, the government has encouraged light
industry to locate in Jersey, with the result that an electronics
industry has developed alongside the traditional manufacturing of
knitwear. All raw material and energy requirements are imported, as
well as a large share of Jersey''s food needs. Light taxes and death
duties make the island a popular tax haven. Living standards come
close to those of the UK.
Johnston Atoll
Economic activity is limited to providing services to
US military personnel and contractors located on the island. All
food and manufactured goods must be imported.','cabaca5210ceb1ecc056c72dfdbec10de4b35b6987ec95c80be75dd3a858d8bf','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06d6b79f511f4121bdce2de0bdfaf219a51c0da37cc3c457249a1170c5e3cad0',2005,'JO','Jordan','economy',743,'total: 15
over 3,047 m: 7
2,438 to 3,047 m: 6
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 2
under 914 m: 2 (2004 est.)
Juan de Nova Island
total: 1
914 to 1,523 m: 1 (2004 est.)
limited natural fresh water resources; deforestation;
overgrazing; soil erosion; desertification
Juan de Nova Island
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
14.6% (2004)
7.307 billion kWh (2002)
7.094 billion kWh (2002)
300 million kWh (2002)
2 million kWh (2002)
30% (2001 est.)
lowest 10%: 3.3%
highest 10%: 29.8% (1997)
agriculture 5%, industry 12.5%, services 82.5% (2001 est.)
clothing, phosphates, fertilizers, potash, vegetables,
manufactures, pharmaceuticals
US 28.9%, Iraq 17.6%, India 7.1%, Saudi Arabia 5.6% (2004)
12 governorates (muhafazat, singular - muhafazah); Ajlun, Al
''Aqabah, Al Balqa'', Al Karak, Al Mafraq, ''Amman, At Tafilah, Az
Zarqa'', Irbid, Jarash, Ma''an, Madaba
wheat, barley, citrus, tomatoes, melons, olives; sheep,
goats, poultry
17 (2004 est.)
Juan de Nova Island
1 (2004 est.)
21.76 births/1,000 population (2005 est.)
Jordanian Armed Forces (JAF): Royal Jordanian Land Force,
Royal Jordanian Navy, Royal Jordanian Air Force, and Special
Operations Command (SOCOM); note - Public Security Directorate
normally falls under Ministry of Interior but comes under JAF in
wartime or crisis situations
revenues: $3.483 billion
expenditures: $3.616 billion, including capital expenditures of $782
million (2004 est.)
Jordan is a small Arab country with inadequate supplies of
water and other natural resources such as oil. Debt, poverty, and
unemployment are fundamental problems, but King ABDALLAH, since
assuming the throne in 1999, has undertaken some broad economic
reforms in a long-term effort to improve living standards. Amman in
the past three years has worked closely with the IMF, practiced
careful monetary policy, and made substantial headway with
privatization. The government also has liberalized the trade regime
sufficiently to secure Jordan''s membership in the WTO (2000), a free
trade accord with the US (2001), and an association agreement with
the EU (2001). These measures have helped improve productivity and
have put Jordan on the foreign investment map. Jordan imported most
of its oil from Iraq, but the US-led war in Iraq in 2003 made Jordan
more dependent on oil from other Gulf nations forcing the Jordanian
government to raise retail petroleum product prices and the sales
tax base. Jordan''s export market, which is heavily dependent on
exports to Iraq, was also affected by the war but recovered quickly
while contributing to the Iraq recovery effort. The main challenges
facing Jordan are reducing dependence on foreign grants, reducing
the budget deficit, and creating investment incentives to promote
job creation.
Juan de Nova Island
Up to 12,000 tons of guano are mined per year.','75dcf03ac978d34249fdc85d7feb7acd15622437c20fa4a763dbcf61d8c9c248','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f1cafb67aad5f75c2f087939dfe080a322de16a64ed89fe25e3d400d8d5af7d',2005,'KZ','Kazakhstan','economy',744,'total: 67
over 3,047 m: 9
2,438 to 3,047 m: 26
1,524 to 2,437 m: 17
914 to 1,523 m: 4
under 914 m: 11 (2004 est.)
total: 247
over 3,047 m: 6
2,438 to 3,047 m: 6
1,524 to 2,437 m: 11
914 to 1,523 m: 27
under 914 m: 197 (2004 est.)
radioactive or toxic chemical sites associated with
former defense industries and test ranges scattered throughout the
country pose health risks for humans and animals; industrial
pollution is severe in some cities; because the two main rivers
which flowed into the Aral Sea have been diverted for irrigation, it
is drying up and leaving behind a harmful layer of chemical
pesticides and natural salts; these substances are then picked up by
the wind and blown into noxious dust storms; pollution in the
Caspian Sea; soil pollution from overuse of agricultural chemicals
and salination from poor infrastructure and wasteful irrigation
practices
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Climate Change-Kyoto Protocol
0.9% (Ministry of Defense expenditures) (FY02)
66.82 billion kWh (2003)
62.21 billion kWh (203)
2.506 billion kWh (2003)
4.975 billion kWh (2003)
19% (2004 est.)
lowest 10%: 3.3%
highest 10%: 26.5% (2004 est.)
agriculture 20%, industry 30%, services 50% (2002 est.)
oil and oil products 58%, ferrous metals 24%, chemicals
5%, machinery 3%, grain, wool, meat, coal (2001)
Russia 15.1%, Bermuda 13.8%, Germany 11%, China 9.9%,
France 6.6%, Italy 4% (2004)
14 provinces (oblystar, singular - oblys) and 3 cities*
(qala, singular - qalasy); Almaty Oblysy, Almaty Qalasy*, Aqmola
Oblysy (Astana), Aqtobe Oblysy, Astana Qalasy*, Atyrau Oblysy, Batys
Qazaqstan Oblysy (Oral), Bayqongyr Qalasy*, Mangghystau Oblysy
(Aqtau), Ongtustik Qazaqstan Oblysy (Shymkent), Pavlodar Oblysy,
Qaraghandy Oblysy, Qostanay Oblysy, Qyzylorda Oblysy, Shyghys
Qazaqstan Oblysy (Oskemen), Soltustik Qazaqstan Oblysy
(Petropavlovsk), Zhambyl Oblysy (Taraz)
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses); in 1995, the Governments of
Kazakhstan and Russia entered into an agreement whereby Russia would
lease for a period of 20 years an area of 6,000 sq km enclosing the
Baykonur space launch facilities and the city of Bayqongyr
(Baykonur, formerly Leninsk); in 2004, a new agreement extended the
lease to 2050
grain (mostly spring wheat), cotton; livestock
314 (2004 est.)
15.78 births/1,000 population (2005 est.)
Ground Forces, Air and Air Defense Forces, Naval Force,
Republican Guard
revenues: $8.67 billion
expenditures: $8.968 billion, including capital expenditures of NA
(2004 est.)
Kazakhstan, the largest of the former Soviet republics in
territory, excluding Russia, possesses enormous fossil fuel reserves
as well as plentiful supplies of other minerals and metals. It also
has a large agricultural sector featuring livestock and grain.
Kazakhstan''s industrial sector rests on the extraction and
processing of these natural resources and also on a growing
machine-building sector specializing in construction equipment,
tractors, agricultural machinery, and some defense items. The
breakup of the USSR in December 1991 and the collapse in demand for
Kazakhstan''s traditional heavy industry products resulted in a
short-term contraction of the economy, with the steepest annual
decline occurring in 1994. In 1995-97, the pace of the government
program of economic reform and privatization quickened, resulting in
a substantial shifting of assets into the private sector. Kazakhstan
enjoyed double-digit growth in 2000-01 - and a solid 9.5% in 2002 -
thanks largely to its booming energy sector, but also to economic
reform, good harvests, and foreign investment. Growth remained at
the high 9% level in 2003 and 2004. The opening of the Caspian
Consortium pipeline in 2001, from western Kazakhstan''s Tengiz
oilfield to the Black Sea, substantially raised export capacity. The
country has embarked upon an industrial policy designed to diversify
the economy away from overdependence on the oil sector, by
developing light industry. Additionally, the policy aims to reduce
the influence of foreign investment and foreign personnel; the
government has engaged in several disputes with foreign oil
companies over the terms of production agreements, and tensions
continue.','991af90813319604cfcf80773675846c559c4d527c69a3b9c4e353176a54305a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47b0eccfb1904c82a234ef2bcabfc14c9235db0084fe1b3e74a95380eb98e265',2005,'KE','Kenya','economy',745,'total: 15
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 6
under 914 m: 1 (2004 est.)
total: 206
1,524 to 2,437 m: 12
914 to 1,523 m: 110
under 914 m: 84 (2004 est.)
water pollution from urban and industrial wastes; degradation
of water quality from increased use of pesticides and fertilizers;
water hyacinth infestation in Lake Victoria; deforestation; soil
erosion; desertification; poaching
Kingman Reef
none
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1.3% (2004)
4.475 billion kWh (2002)
4.337 billion kWh (2002)
175 million kWh (2002)
0 kWh (2002)
50% (2000 est.)
lowest 10%: 2%
highest 10%: 37.2% (2000)
agriculture 75% (2003 est.)
Korea, North
agricultural 36%, nonagricultural 64%
Korea, South
agriculture 8%, industry 19%, services 73% (2004 est.)
tea, horticultural products, coffee, petroleum products, fish,
cement
Uganda 13.3%, UK 11.4%, US 10.6%, Netherlands 8.2%, Egypt
4.9%, Tanzania 4.5%, Pakistan 4.3% (2004)
7 provinces and 1 area*; Central, Coast, Eastern, Nairobi
Area*, North Eastern, Nyanza, Rift Valley, Western
tea, coffee, corn, wheat, sugarcane, fruit, vegetables; dairy
products, beef, pork, poultry, eggs
221 (2004 est.)
Kingman Reef
lagoon was used as a halfway station between Hawaii and
American Samoa by Pan American Airways for flying boats in 1937 and
1938 (2004 est.)
40.13 births/1,000 population (2005 est.)
Army, Navy, Air Force
revenues: $2.89 billion
expenditures: $3.443 billion, including capital expenditures of NA
(2004 est.)
The regional hub for trade and finance in East Africa, Kenya
has been hampered by corruption and by reliance upon several primary
goods whose prices have remained low. In 1997, the IMF suspended
Kenya''s Enhanced Structural Adjustment Program due to the
government''s failure to maintain reforms and curb corruption. A
severe drought from 1999 to 2000 compounded Kenya''s problems,
causing water and energy rationing and reducing agricultural output.
As a result, GDP contracted by 0.2% in 2000. The IMF, which had
resumed loans in 2000 to help Kenya through the drought, again
halted lending in 2001 when the government failed to institute
several anticorruption measures. Despite the return of strong rains
in 2001, weak commodity prices, endemic corruption, and low
investment limited Kenya''s economic growth to 1.2%. Growth lagged at
1.1% in 2002 because of erratic rains, low investor confidence,
meager donor support, and political infighting up to the elections.
In the key 27 December 2002 elections, Daniel Arap MOI''s 24-year-old
reign ended, and a new opposition government took on the formidable
economic problems facing the nation. In 2003, progress was made in
rooting out corruption and encouraging donor support, with GDP
growth edging up to 1.7%. GDP grew a moderate 2.2% in 2004.
Kingman Reef
no economic activity','b633e29a8313aae3e01dd9bed03df01896adf8d3933789f3e67f8e5df8ee818e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cee922ecaaddd77e68648c510597ef9af2219edad24bc977e7070b25d7f4f01',2005,'KI','Kiribati','economy',746,'total: 3
1,524 to 2,437 m: 3 (2004 est.)
Korea, North
total: 35
over 3,047 m: 2
2,438 to 3,047 m: 23
1,524 to 2,437 m: 6
914 to 1,523 m: 1
under 914 m: 3 (2004 est.)
Korea, South
total: 88
over 3,047 m: 3
2,438 to 3,047 m: 21
1,524 to 2,437 m: 14
914 to 1,523 m: 12
under 914 m: 38 (2004 est.)
total: 17
1,524 to 2,437 m: 1
914 to 1,523 m: 12
under 914 m: 4 (2004 est.)
Korea, North
total: 43
2,438 to 3,047 m: 1
1,524 to 2,437 m: 20
914 to 1,523 m: 14
under 914 m: 8 (2004 est.)
Korea, South
total: 91
914 to 1,523 m: 3
under 914 m: 88 (2004 est.)
heavy pollution in lagoon of south Tarawa atoll due to
heavy migration mixed with traditional practices such as lagoon
latrines and open-pit dumping; ground water at risk
Korea, North
water pollution; inadequate supplies of potable water;
waterborne disease; deforestation; soil erosion and degradation
Korea, South
air pollution in large cities; acid rain; water
pollution from the discharge of sewage and industrial effluents;
drift net fishing
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Korea, North
party to: Antarctic Treaty, Biodiversity, Climate
Change, Environmental Modification, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Law of the Sea
Korea, South
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
NA
Korea, North
NA
Korea, South
2.8% (2004)
7 million kWh (2002)
Korea, North
33.62 billion kWh (2002)
Korea, South
322.5 billion kWh (2003)
6.51 million kWh (2002)
Korea, North
31.26 billion kWh (2002)
Korea, South
293.6 billion kWh (2003)
0 kWh (2002)
Korea, North
0 kWh (2002)
Korea, South
0 kWh (2003)
0 kWh (2002)
Korea, North
0 kWh (2002)
Korea, South
0 kWh (2003)
NA
Korea, North
NA
Korea, South
4% (2001 est.)
lowest 10%: NA
highest 10%: NA
Korea, North
lowest 10%: NA
highest 10%: NA
Korea, South
lowest 10%: 2.9%
highest 10%: 22.5% (1999 est.)
copra 62%, coconuts, seaweed, fish
Korea, North
minerals, metallurgical products, manufactures
(including armaments); textiles and fishery products
Korea, South
semiconductors, wireless telecommunications equipment,
motor vehicles, computers, steel, ships, petrochemicals
France 45.7%, Japan 29.2%, US 9.1%, Thailand 5.4% (2004)
Korea, North
China 29.9%, South Korea 24.1%, Japan 13.2% (2004)
Korea, South
China 19.7%, US 17%, Japan 8.6%, Hong Kong 7.2% (2004)
3 units; Gilbert Islands, Line Islands, Phoenix Islands;
note - in addition, there are 6 districts (Banaba, Central Gilberts,
Line Islands, Northern Gilberts, Southern Gilberts, Tarawa) and 21
island councils - one for each of the inhabited islands (Abaiang,
Abemama, Aranuka, Arorae, Banaba, Beru, Butaritari, Kanton,
Kiritimati, Kuria, Maiana, Makin, Marakei, Nikunau, Nonouti, Onotoa,
Tabiteuea, Tabuaeran, Tamana, Tarawa, Teraina)
Korea, North
9 provinces (do, singular and plural) and 4
municipalities (si, singular and plural)
provinces: Chagang-do (Chagang), Hamgyong-bukto (North Hamgyong),
Hamgyong-namdo (South Hamgyong), Hwanghae-bukto (North Hwanghae),
Hwanghae-namdo (South Hwanghae), Kangwon-do (Kangwon),
P''yongan-bukto (North P''yongan), P''yongan-namdo (South P''yongan),
Yanggang-do (Yanggang)
municipalites: Kaesong-si (Kaesong), Najin Sonbong-si (Najin),
Namp''o-si (Namp''o), P''yongyang-si (Pyongyang)
Korea, South
9 provinces (do, singular and plural) and 7
metropolitan cities (gwangyoksi, singular and plural)
provinces: Cheju-do, Cholla-bukto (North Cholla), Cholla-namdo
(South Cholla), Ch''ungch''ong-bukto (North Ch''ungch''ong),
Ch''ungch''ong-namdo (South Ch''ungch''ong), Kangwon-do, Kyonggi-do,
Kyongsang-bukto (North Kyongsang), Kyongsang-namdo (South Kyongsang)
metropolitan cities: Inch''on-gwangyoksi (Inch''on),
Kwangju-gwangyoksi (Kwangju), Pusan-gwangyoksi (Pusan),
Soul-t''ukpyolsi (Seoul), Taegu-gwangyoksi (Taegu), Taejon-gwangyoksi
(Taejon), Ulsan-gwangyoksi (Ulsan)
copra, taro, breadfruit, sweet potatoes, vegetables; fish
Korea, North
rice, corn, potatoes, soybeans, pulses; cattle, pigs,
pork, eggs
Korea, South
rice, root crops, barley, vegetables, fruit; cattle,
pigs, chickens, milk, eggs; fish
20 (2004 est.)
Korea, North
78 (2004 est.)
Korea, South
179 (2004 est.)
30.86 births/1,000 population (2005 est.)
Korea, North
16.09 births/1,000 population (2005 est.)
Korea, South
10.08 births/1,000 population (2005 est.)
no regular military forces; Police Force (carries out law
enforcement functions and paramilitary duties; small police posts
are on all islands)
Korea, North
North Korean People''s Army: Ground Force, Navy, Air
Force; Civil Security Forces (2005)
Korea, South
Army, Navy, Air Force, Marine Corps, National Maritime
Police (Coast Guard)
revenues: $28.4 million
expenditures: $37.2 million, including capital expenditures of NA
(2000 est.)
Korea, North
revenues: NA
expenditures: NA, including capital expenditures of NA
Korea, South
revenues: $150.5 billion
expenditures: $155.8 billion, including capital expenditures of NA
(2004 est.)
A remote country of 33 scattered coral atolls, Kiribati has
few natural resources. Commercially viable phosphate deposits were
exhausted at the time of independence from the UK in 1979. Copra and
fish now represent the bulk of production and exports. The economy
has fluctuated widely in recent years. Economic development is
constrained by a shortage of skilled workers, weak infrastructure,
and remoteness from international markets. Tourism provides more
than one-fifth of GDP. The financial sector is at an early stage of
development as is the expansion of private sector initiatives.
Foreign financial aid from UK, Japan, Australia, New Zealand, and
China equals 25%-50% of GDP. Remittances from workers abroad account
for more than $5 million each year.
Korea, North
North Korea, one of the world''s most centrally planned
and isolated economies, faces desperate economic conditions.
Industrial capital stock is nearly beyond repair as a result of
years of underinvestment and spare parts shortages. Industrial and
power output have declined in parallel. The nation has suffered its
eleventh year of food shortages because of a lack of arable land,
collective farming, weather-related problems, and chronic shortages
of fertilizer and fuel. Massive international food aid deliveries
have allowed the regime to escape mass starvation since 1995, but
the population remains the victim of prolonged malnutrition and
deteriorating living conditions. Large-scale military spending eats
up resources needed for investment and civilian consumption. In July
2002, the government took limited steps toward a freer market
economy. In 2004, heightened political tensions with key donor
countries and general donor fatigue threatened the flow of
desperately needed food aid and fuel aid. Black market prices have
continued to rise following the increase in official prices and
wages in the summer of 2002, leaving some vulnerable groups, such as
the elderly and unemployed, less able to buy goods. In 2004, the
regime allowed private markets to sell a wider range of goods and
permitted private farming on an experimental basis in an effort to
boost agricultural output. Firm political control remains the
Communist government''s overriding concern, which will constrain any
further loosening of economic regulations.
Korea, South
Since the early 1960s, South Korea has achieved an
incredible record of growth and integration into the high-tech
modern world economy. Four decades ago GDP per capita was comparable
with levels in the poorer countries of Africa and Asia. In 2004, it
joined the trillion dollar club of world economies. Today its GDP
per capita is 14 times North Korea''s and equal to the lesser
economies of the European Union. This success through the late 1980s
was achieved by a system of close government/business ties,
including directed credit, import restrictions, sponsorship of
specific industries, and a strong labor effort. The government
promoted the import of raw materials and technology at the expense
of consumer goods and encouraged savings and investment over
consumption. The Asian financial crisis of 1997-99 exposed
longstanding weaknesses in South Korea''s development model,
including high debt/equity ratios, massive foreign borrowing, and an
undisciplined financial sector. Growth plunged to a negative 6.9% in
1998, then strongly recovered to 9.5% in 1999 and 8.5% in 2000.
Growth fell back to 3.3% in 2001 because of the slowing global
economy, falling exports, and the perception that much-needed
corporate and financial reforms had stalled. Led by consumer
spending and exports, growth in 2002 was an impressive 7.0%, despite
anemic global growth. Economic growth fell to 3.1% in 2003 because
of a downturn in consumer spending and recovered to an estimated
4.6% in 2004 on the strength of rapid export growth. The government
plans to boost infrastructure spending in 2005. Moderate inflation,
low unemployment, an export surplus, and fairly equal distribution
of income characterize this solid economy.','cd2d399bb1adfeab56d375c8cd8df580ca5981075573987a1a5386b4a5d00b3a','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff5ab1eb50be3b5cd4245608d177eb756bf049ac8c2b74df507deb51afbdd162',2005,'KW','Kuwait','economy',747,'total: 4
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2004 est.)
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (2004 est.)
limited natural fresh water resources; some of world''s
largest and most sophisticated desalination facilities provide much
of the water; air and water pollution; desertification
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection
signed, but not ratified: Marine Dumping
5.3% (2004)
32.43 billion kWh (2002)
30.16 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture NA, industries NA, services NA
oil and refined products, fertilizers
Japan 20.5%, South Korea 13.7%, US 12.4%, Singapore 11.3%,
Taiwan 9.9% (2004)
5 governorates (muhafazat, singular - muhafazah); Al Ahmadi,
Al Farwaniyah, Al ''Asimah, Al Jahra'', Hawalli
practically no crops; fish
7 (2004 est.)
21.88 births/1,000 population (2005 est.)
Land Forces, Navy, Air Force (includes Air Defense Force),
National Guard (2002)
revenues: $35.82 billion
expenditures: $19.53 billion, including capital expenditures of NA
(2004 est.)
Kuwait is a small, rich, relatively open economy with proved
crude oil reserves of about 96 billion barrels - 10% of world
reserves. Petroleum accounts for nearly half of GDP, 95% of export
revenues, and 80% of government income. Kuwait''s climate limits
agricultural development. Consequently, with the exception of fish,
it depends almost wholly on food imports. About 75% of potable water
must be distilled or imported. Kuwait continues its discussions with
foreign oil companies to develop fields in the northern part of the
country.','51a0d33beef4ecbd5586ddc9ab72d7e690717cdc8acd6e6a7cd910170d6a6341','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cf94ad277194747ec156f727aa18549210050586023266bb9e70610de34be0f',2005,'KG','Kyrgyzstan','economy',748,'total: 16
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 10
under 914 m: 2 (2004 est.)
Laos
total: 9
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2004 est.)
total: 36
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 31 (2004 est.)
Laos
total: 35
1,524 to 2,437 m: 1
914 to 1,523 m: 13
under 914 m: 21 (2004 est.)
water pollution; many people get their water directly
from contaminated streams and wells; as a result, water-borne
diseases are prevalent; increasing soil salinity from faulty
irrigation practices
Laos
unexploded ordnance; deforestation; soil erosion; most of the
population does not have access to potable water
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Hazardous Wastes,
Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Laos
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
1.4% (FY01)
Laos
0.5% (2004)
11.72 billion kWh (2002)
Laos
3.56 billion kWh (2002)
10.21 billion kWh (2002)
Laos
3.036 billion kWh (2002)
375 million kWh (2002)
Laos
125 million kWh (2002)
1.062 billion kWh (2002)
Laos
400 million kWh (2002)
40% (2004 est.)
Laos
40% (2002 est.)
lowest 10%: 3.9%
highest 10%: 23.3% (2001)
Laos
lowest 10%: 3.2%
highest 10%: 30.6% (1997)
agriculture 55%, industry 15%, services 30% (2000 est.)
Laos
agriculture 80% (1997 est.)
cotton, wool, meat, tobacco; gold, mercury, uranium,
natural gas, hydropower; machinery; shoes
Laos
garments, wood products, coffee, electricity, tin
UAE 28.2%, Russia 19.1%, China 12%, Kazakhstan 11.1%,
Switzerland 6.3% (2004)
Laos
Thailand 19.3%, Vietnam 13.4%, France 8%, Germany 5.3%, UK 5%
(2004)
7 provinces (oblastlar, singular - oblasty) and 1 city*
(shaar); Batken Oblasty, Bishkek Shaary*, Chuy Oblasty (Bishkek),
Jalal-Abad Oblasty, Naryn Oblasty, Osh Oblasty, Talas Oblasty,
Ysyk-Kol Oblasty (Karakol)
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
Laos
16 provinces (khoueng, singular and plural), 1 municipality*
(kampheng nakhon, singular and plural), and 1 special zone**
(khetphiset, singular and plural); Attapu, Bokeo, Bolikhamxai,
Champasak, Houaphan, Khammouan, Louangnamtha, Louangphrabang,
Oudomxai, Phongsali, Salavan, Savannakhet, Viangchan (Vientiane)*,
Viangchan, Xaignabouli, Xaisomboun**, Xekong, Xiangkhoang
tobacco, cotton, potatoes, vegetables, grapes, fruits and
berries; sheep, goats, cattle, wool
Laos
sweet potatoes, vegetables, corn, coffee, sugarcane, tobacco,
cotton, tea, peanuts, rice, water buffalo, pigs, cattle, poultry
52 (2004 est.)
Laos
44 (2004 est.)
22.48 births/1,000 population (2005 est.)
Laos
35.99 births/1,000 population (2005 est.)
Army, Air Force, National Guard (2004)
Laos
Lao People''s Army (LPA; includes Riverine Force), Air Force
revenues: $431.3 million
expenditures: $445.4 million, including capital expenditures of NA
(2004 est.)
Laos
revenues: $284.3 million
expenditures: $416.5 million, including capital expenditures of NA
(2004 est.)
Kyrgyzstan is a poor, mountainous country with a
predominantly agricultural economy. Cotton, tobacco, wool, and meat
are the main agricultural products, although only tobacco and cotton
are exported in any quantity. Industrial exports include gold,
mercury, uranium, and natural gas and electricity. Kyrgyzstan has
been fairly progressive in carrying out market reforms, such as an
improved regulatory system and land reform. Kyrgyzstan was the first
CIS country to be accepted into the World Trade Organization. With
fits and starts, inflation has been lowered to an estimated 7% in
2001, 2.1% in 2002, 4% in 2003, and 3.2% in 2004. Much of the
government''s stock in enterprises has been sold. Drops in production
had been severe after the breakup of the Soviet Union in December
1991, but by mid-1995 production began to recover and exports began
to increase. Kyrgyzstan has distinguished itself by adopting
relatively liberal economic policies. The drop in output at the
Kumtor gold mine sparked a 0.5% decline in GDP in 2002, but GDP
growth bounced back to 6% in 2003 and 2004. The government has made
steady strides in controlling its substantial fiscal deficit and
aims to reduce the deficit to 3% of GDP in 2004. The government and
the international financial institutions have been engaged in a
comprehensive medium-term poverty reduction and economic growth
strategy. Further restructuring of domestic industry and success in
attracting foreign investment are keys to future growth.
Laos
The government of Laos - one of the few remaining official
Communist states - began decentralizing control and encouraging
private enterprise in 1986. The results, starting from an extremely
low base, were striking - growth averaged 6% in 1988-2004 except
during the short-lived drop caused by the Asian financial crisis
beginning in 1997. Despite this high growth rate, Laos remains a
country with a primitive infrastructure; it has no railroads, a
rudimentary road system, and limited external and internal
telecommunications. The government has sponsored major improvements
in the road system. Electricity is available in only a few urban
areas. Subsistence agriculture accounts for half of GDP and provides
80% of total employment. The economy will continue to benefit from
aid from the IMF and other international sources and from new
foreign investment in food processing and mining. In late 2004, Laos
gained Normal Trade Relations status with the US, allowing
Laos-based producers to face lower tariffs on their exports; this
may help spur growth.','0aadc2054533938e3b9f5e1f476f1c93d8b86530c12bcc36958e2926fa3da8b7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d557c603cb0b6a169b9539ea707cd81df58f663b147644020962bed0ae71650d',2005,'LV','Latvia','economy',749,'total: 26
2,438 to 3,047 m: 7
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 16 (2004 est.)
total: 24
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 20 (2004 est.)
Latvia''s environment has benefited from a shift to service
industries after the country regained independence; the main
environmental priorities are improvement of drinking water quality
and sewage system, household, and hazardous waste management, as
well as reduction of air pollution; in 2001, Latvia closed the EU
accession negotiation chapter on environment committing to full
enforcement of EU environmental directives by 2010
party to: Air Pollution, Air Pollution-Persistent Organic
Pollutants, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Endangered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
1.2% (FY01)
4.547 billion kWh (2002)
5.829 billion kWh (2002)
2.7 billion kWh (2002)
1.1 billion kWh (2002)
NA
lowest 10%: 2.9%
highest 10%: 25.9% (1998)
agriculture 15%, industry 25%, services 60% (2000 est.)
wood and wood products, machinery and equipment, metals,
textiles, foodstuffs
UK 12.8%, Germany 12%, Sweden 10%, Lithuania 9.1%, Estonia
8%, Russia 6.4%, Denmark 5.4% (2004)
26 counties (singular - rajons) and 7 municipalities*:
Aizkraukles Rajons, Aluksnes Rajons, Balvu Rajons, Bauskas Rajons,
Cesu Rajons, Daugavpils*, Daugavpils Rajons, Dobeles Rajons,
Gulbenes Rajons, Jekabpils Rajons, Jelgava*, Jelgavas Rajons,
Jurmala*, Kraslavas Rajons, Kuldigas Rajons, Liepaja*, Liepajas
Rajons, Limbazu Rajons, Ludzas Rajons, Madonas Rajons, Ogres Rajons,
Preilu Rajons, Rezekne*, Rezeknes Rajons, Riga*, Rigas Rajons,
Saldus Rajons, Talsu Rajons, Tukuma Rajons, Valkas Rajons, Valmieras
Rajons, Ventspils*, Ventspils Rajons
grain, sugar beets, potatoes, vegetables; beef, pork, milk,
eggs; fish
50 (2004 est.)
9.04 births/1,000 population (2005 est.)
Ground Forces, Navy, Air Force, Border Guard, Home Guard
(Zemessardze)
revenues: $4.231 billion
expenditures: $4.504 billion, including capital expenditures of NA
(2004 est.)
Latvia''s transitional economy recovered from the 1998 Russian
financial crisis, largely due to the government''s budget stringency
and a gradual reorientation of exports toward EU countries,
lessening Latvia''s trade dependency on Russia. The majority of
companies, banks, and real estate have been privatized, although the
state still holds sizable stakes in a few large enterprises. Latvia
officially joined the World Trade Organization in February 1999. EU
membership, a top foreign policy goal, came in May 2004. The current
account and internal government deficits remain major concerns, but
the government''s efforts to increase efficiency in revenue
collection may lessen the budget deficit. A growing perception that
many of Latvia''s banks facilitate illicit activity could damage the
country''s vibrant financial sector.','1e28e9012ba98c8ff03d635cf4e2029097e6c92d8be6fe1837ecdfc28ff5b6c7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eb7d02037e58e9cb16a670276e7ee446053f157291b3ab8b6ffe5649c1a9c2f',2005,'LS','Lesotho','economy',750,'total: 3
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 25
914 to 1,523 m: 4
under 914 m: 21 (2004 est.)
population pressure forcing settlement in marginal areas
results in overgrazing, severe soil erosion, and soil exhaustion;
desertification; Highlands Water Project controls, stores, and
redirects water to South Africa
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes,
Marine Life Conservation, Ozone Layer Protection
signed, but not ratified: Law of the Sea
2.3% (2004)
314 million kWh; note - electricity supplied by South Africa
(2002)
308 million kWh (2002)
16 million kWh; note - electricity supplied by South Africa
(2002)
0 kWh (2002)
49% (1999)
lowest 10%: 0.9%
highest 10%: 43.4%
86% of resident population engaged in subsistence
agriculture; roughly 35% of the active male wage earners work in
manufactures 75% (clothing, footwear, road vehicles), wool
and mohair, food and live animals (2000)
US 97%, Canada 2.1%, UK 0.3% (2004)
10 districts; Berea, Butha-Buthe, Leribe, Mafeteng, Maseru,
Mohale''s Hoek, Mokhotlong, Qacha''s Nek, Quthing, Thaba-Tseka
corn, wheat, pulses, sorghum, barley; livestock
28 (2004 est.)
26.53 births/1,000 population (2005 est.)
Lesotho Defense Force (LDF): Army and Air Wing
revenues: $698.5 million
expenditures: $697.6 million, including capital expenditures of $15
million (2004 est.)
Small, landlocked, and mountainous, Lesotho relies on
remittances from miners employed in South Africa and customs duties
from the Southern Africa Customs Union for the majority of
government revenue, but the government has strengthened its tax
system to reduce dependency on customs duties. Completion of a major
hydropower facility in January 1998 now permits the sale of water to
South Africa, also generating royalties for Lesotho. As the number
of mineworkers has declined steadily over the past several years, a
small manufacturing base has developed based on farm products that
support the milling, canning, leather, and jute industries and a
rapidly growing apparel-assembly sector. The garment industry has
grown significantly, mainly due to Lesotho qualifying for the trade
benefits contained in the Africa Growth and Opportunity Act. The
economy is still primarily based on subsistence agriculture,
especially livestock, although drought has decreased agricultural
activity. The extreme inequality in the distribution of income
remains a major drawback. Lesotho has signed an Interim Poverty
Reduction and Growth Facility with the IMF.','5acc2826a577d1eb327a09067d7a1857e72f11a87ab25797e78fc557d811cf90','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b07bc79dc1576b268c1b024e08bcb49c1b07e7cc2218d152f342f845da7e7565',2005,'LR','Liberia','economy',751,'total: 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (2004 est.)
total: 51
1,524 to 2,437 m: 5
914 to 1,523 m: 8
under 914 m: 38 (2004 est.)
tropical rain forest deforestation; soil erosion; loss of
biodiversity; pollution of coastal waters from oil residue and raw
sewage
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Environmental Modification, Law of the
Sea, Marine Life Conservation
0.2% (2004)
488.8 million kWh (2002)
454.6 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
80%
lowest 10%: NA
highest 10%: NA
agriculture 70%, industry 8%, services 22% (2000 est.)
rubber, timber, iron, diamonds, cocoa, coffee
Denmark 29.5%, Germany 18.9%, Poland 14.3%, US 8.9%, Greece
8% (2004)
15 counties; Bomi, Bong, Gbarpolu, Grand Bassa, Grand Cape
Mount, Grand Gedeh, Grand Kru, Lofa, Margibi, Maryland, Montserrado,
Nimba, River Cess, River Gee, Sinoe
rubber, coffee, cocoa, rice, cassava (tapioca), palm oil,
sugarcane, bananas; sheep, goats; timber
53 (2004 est.)
44.22 births/1,000 population (2005 est.)
Armed Forces of Liberia (AFL): Army, Navy, Air Force
revenues: $85.4 million
expenditures: $90.5 million, including capital expenditures of NA
(2000 est.)
Civil war and government mismanagement have destroyed much
of Liberia''s economy, especially the infrastructure in and around
Monrovia, while continued international sanctions on diamonds and
timber exports will limit growth prospects for the foreseeable
future. Many businessmen have fled the country, taking capital and
expertise with them. Some have returned, but many will not. Richly
endowed with water, mineral resources, forests, and a climate
favorable to agriculture, Liberia had been a producer and exporter
of basic products - primarily raw timber and rubber. Local
manufacturing, mainly foreign owned, had been small in scope. The
departure of the former president, Charles TAYLOR, to Nigeria in
August 2003, the establishment of the all-inclusive Transitional
Government, and the arrival of a UN mission are all necessary for
the eventual end of the political crisis, but thus far have done
little to encourage economic development. The reconstruction of
infrastructure and the raising of incomes in this ravaged economy
will largely depend on generous financial support and technical
assistance from donor countries.','c82fae7531b9710aec04f1d0db391b72b0f3ffa4f37125ac6a6ff8c6034b91b6','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e19e4ff3cfa186cfc23c0a6b8ab433bf81c62b81abbd896704d0d8c2a4a466b',2005,'LY','Libya','economy',752,'total: 59
over 3,047 m: 23
2,438 to 3,047 m: 6
1,524 to 2,437 m: 23
914 to 1,523 m: 5
under 914 m: 2 (2004 est.)
total: 80
over 3,047 m: 5
2,438 to 3,047 m: 2
1,524 to 2,437 m: 14
914 to 1,523 m: 41
under 914 m: 18 (2004 est.)
desertification; very limited natural fresh water resources;
the Great Manmade River Project, the largest water development
scheme in the world, is being built to bring water from large
aquifers under the Sahara to coastal cities
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Marine Dumping, Ozone Layer
Protection
signed, but not ratified: Law of the Sea
3.9% (FY99)
20.89 billion kWh (2002)
19.43 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 17%, industry 29%, services 54% (1997 est.)
crude oil, refined petroleum products, natural gas
Italy 37%, Germany 16.6%, Spain 11.9%, Turkey 7.1%, France
6.2% (2004)
25 municipalities (baladiyat, singular - baladiyah); Ajdabiya,
Al ''Aziziyah, Al Fatih, Al Jabal al Akhdar, Al Jufrah, Al Khums, Al
Kufrah, An Nuqat al Khams, Ash Shati'', Awbari, Az Zawiyah, Banghazi,
Darnah, Ghadamis, Gharyan, Misratah, Murzuq, Sabha, Sawfajjin, Surt,
Tarabulus, Tarhunah, Tubruq, Yafran, Zlitan; note - the 25
municipalities may have been replaced by 13 regions
wheat, barley, olives, dates, citrus, vegetables, peanuts,
soybeans; cattle
139 (2004 est.)
26.82 births/1,000 population (2005 est.)
Armed Peoples on Duty (Army), Navy, Air Force, Air Defense
Command
revenues: $13.52 billion
expenditures: $12.23 billion, including capital expenditures of $5.6
billion (2004 est.)
The Libyan economy depends primarily upon revenues from the
oil sector, which contribute practically all export earnings and
about one-quarter of GDP. These oil revenues and a small population
give Libya one of the highest per capita GDPs in Africa, but little
of this income flows down to the lower orders of society. Libyan
officials in the past four years have made progress on economic
reforms as part of a broader campaign to reintegrate the country
into the international fold. This effort picked up steam after UN
sanctions were lifted in September 2003 and as Libya announced in
December 2003 that it would abandon programs to build weapons of
mass destruction. Almost all US unilateral sanctions against Libya
were removed in April 2004. Libya faces a long road ahead in
liberalizing the socialist-oriented economy, but initial steps -
including applying for WTO membership, reducing some subsidies, and
announcing plans for privatization - are laying the groundwork for a
transition to a more market-based economy. The non-oil manufacturing
and construction sectors, which account for about 20% of GDP, have
expanded from processing mostly agricultural products to include the
production of petrochemicals, iron, steel, and aluminum. Climatic
conditions and poor soils severely limit agricultural output, and
Libya imports about 75% of its food.','0a90c32ff5c8d4605c61abfe424c2f7b0b887c8adcfbd08f1173b02bcca4d2cc','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03713aba3ec498d4ba9d557c999374ad6de17c6bfe86db0c3120a703eed3c176',2005,'LT','Lithuania','economy',753,'total: 28
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 2
under 914 m: 14 (2004 est.)
total: 74
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 68 (2004 est.)
contamination of soil and groundwater with petroleum
products and chemicals at military bases
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Endangered Species, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1.9% (FY01)
17.93 billion kWh (2002)
10.17 billion kWh (2002)
300 million kWh (2002)
6.8 billion kWh (2002)
NA
lowest 10%: 3.1%
highest 10%: 25.6% (1996)
agriculture 20%, industry 30%, services 50% (1997 est.)
mineral products 23%, textiles and clothing 16%, machinery
and equipment 11%, chemicals 6%, wood and wood products 5%,
foodstuffs 5% (2001)
Germany 10.2%, Latvia 10.2%, Russia 9.3%, France 6.3%, UK
5.3%, Sweden 5.1%, Estonia 5%, Poland 4.8%, Netherlands 4.8%,
Denmark 4.8%, US 4.7%, Switzerland 4.6% (2004)
10 counties (apskritys, singular - apskritis); Alytaus,
Kauno, Klaipedos, Marijampoles, Panevezio, Siauliu, Taurages,
Telsiu, Utenos, Vilniaus
grain, potatoes, sugar beets, flax, vegetables; beef,
milk, eggs; fish
102 (2004 est.)
8.62 births/1,000 population (2005 est.)
Ground Forces, Navy, Air Force, National Defense Volunteer
Forces (SKAT)
revenues: $6.542 billion
expenditures: $7.121 billion, including capital expenditures of NA
(2004 est.)
Lithuania, the Baltic state that has conducted the most
trade with Russia, has slowly rebounded from the 1998 Russian
financial crisis. Unemployment dropped from 11% in 2003 to 8% in
2004. Growing domestic consumption and increased investment have
furthered recovery. Trade has been increasingly oriented toward the
West. Lithuania has gained membership in the World Trade
Organization and joined the EU in May 2004. Privatization of the
large, state-owned utilities, particularly in the energy sector, is
nearing completion. Overall, more than 80% of enterprises have been
privatized. Foreign government and business support have helped in
the transition from the old command economy to a market economy.','0ffe309486028ea1d6d6e728b488396a3988d2d39c535785311c750c3eebaa12','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf9a97798bce021118d3ba0baa364d878a9a42a01801291925e051dbf48aa0db',2005,'LU','Luxembourg','economy',754,'total: 1
over 3,047 m: 1 (2004 est.)
Macau
total: 1
over 3,047 m: 1 (2004 est.)
Macedonia
total: 10
2,438 to 3,047 m: 2
under 914 m: 8 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
Macedonia
total: 7
914 to 1,523 m: 3
under 914 m: 4 (2004 est.)
air and water pollution in urban areas, soil pollution of
farmland
Macau
NA
Macedonia
air pollution from metallurgical plants
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification
Macedonia
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Endangered Species, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
0.9% (2003)
Macedonia
6% (FY01/02 est.)
2.511 billion kWh (2002)
Macau
1.719 billion kWh (2003)
Macedonia
6.273 billion kWh (2003)
5.735 billion kWh (2002)
Macau
1.772 billion kWh (2003)
Macedonia
7.216 billion kWh (2003)
6.3 billion kWh (2002)
Macau
179.7 million kWh (2003)
Macedonia
953 million kWh (2003)
2.9 billion kWh (2002)
Macau
1 million kWh (2003)
Macedonia
0 kWh (2003)
NA%
Macau
NA
Macedonia
30.2% (2003 est.)
lowest 10%: NA%
highest 10%: NA%
Macau
lowest 10%: NA
highest 10%: NA
Macedonia
lowest 10%: NA%
highest 10%: NA%
agriculture 1%, industry 13%, services 86% (2004 est.)
Macau
manufacturing 18.3%, construction 8%, transport and
communications 7%, wholesale and retail trade 16.2%, restaurants and
hotels 10.9%, gambling 11.6%, public sector 8.8%, other services and
agriculture 19.2% (2003 est.)
Macedonia
agriculture NA%, industry NA%, services NA%
machinery and equipment, steel products, chemicals,
rubber products, glass
Macau
clothing, textiles, footwear, toys, electronics, machinery and
parts
Macedonia
food, beverages, tobacco; miscellaneous manufactures, iron
and steel
Germany 22.1%, France 20.1%, Belgium 10.2%, UK 8.4%,
Italy 7.3%, Spain 5.9%, Netherlands 4.3% (2004)
Macau
US 48.7%, China 13.9%, Germany 8.3%, Hong Kong 7.6%, UK 4.4%
(2004)
Macedonia
Serbia and Montenegro 31.4%, Germany 19.9%, Greece 8.9%,
Croatia 6.9%, US 4.9% (2004)
3 districts; Diekirch, Grevenmacher, Luxembourg
Macau
none (special administrative region of China)
Macedonia
85 municipalities (opstini, singular - opstina); Aerodrom
(Skopje), Aracinovo, Berovo, Bitola, Bogdanci, Bogovinje, Bosilovo,
Brvenica, Butel (Skopje), Cair (Skopje), Caska, Centar (Skopje),
Centar Zupa, Cesinovo, Cucer-Sandevo, Debar, Debartsa, Delcevo,
Demir Hisar, Demir Kapija, Dojran, Dolneni, Drugovo, Gazi Baba
(Skopje), Gevgelija, Gjorce Petrov (Skopje), Gostivar, Gradsko,
Ilinden, Jegunovce, Karbinci, Karpos (Skopje), Kavadarci, Kicevo,
Kisela Voda (Skopje), Kocani, Konce, Kratovo, Kriva Palanka,
Krivogastani, Krusevo, Kumanovo, Lipkovo, Lozovo, Makedonska
Kamenica, Makedonski Brod, Mavrovo i Rastusa, Mogila, Negotino,
Novaci, Novo Selo, Ohrid, Oslomej, Pehcevo, Petrovec, Plasnica,
Prilep, Probistip, Radovis, Rankovce, Resen, Rosoman, Saraj
(Skopje), Skopje, Sopiste, Staro Nagoricane, Stip, Struga, Strumica,
Studenicani, Suto Orizari (Skopje), Sveti Nikole, Tearce, Tetovo,
Valandovo, Vasilevo, Veles, Vevcani, Vinica, Vranestica, Vrapciste,
Zajas, Zelenikovo, Zelino, Zrnovci
note: the ten municipalities followed by Skopje in parentheses
collectively constitute "greater Skopje"
barley, oats, potatoes, wheat, fruits, wine grapes;
livestock products
Macau
only 2% of land area is cultivated, mainly by vegetable
growers; fishing, mostly for crustaceans, is important, some of
catch is exported to Hong Kong; most food requirements are met by
imports, primarily from China
Macedonia
wheat, grapes, rice, tobacco, corn, millet, cotton,
sesame, mulberry leaves, citrus, vegetables; beef, pork, poultry,
mutton
2 (2004 est.)
Macau
1 (2004 est.)
Macedonia
17 (2004 est.)
12.06 births/1,000 population (2005 est.)
Macau
8.04 births/1,000 population (2005 est.)
Macedonia
12 births/1,000 population (2005 est.)
Army
Macau
China''s People''s Revolutionary Army (PLA) constitutes the only
armed force in Macau; several police forces constitute the Security
Forces of Macau (SFM) that are subordinate to the General
Secretariat of Security, a body comparable to a ministry of interior
(2004)
Macedonia
Army of the Republic of Macedonia (ARM; includes Air and
Air Defense Command)
revenues: $13.74 billion
expenditures: $14.49 billion, including capital expenditures of $760
million (2004 est.)
Macau
revenues: $1.84 billion
expenditures: $1.57 billion, including capital expenditures of NA
(2003)
Macedonia
revenues: $1.198 billion
expenditures: $1.245 billion, including capital expenditures of $114
million (2004 est.)
This stable, high-income economy - in between France,
Belgium, and Germany - features solid growth, low inflation, and low
unemployment. The industrial sector, initially dominated by steel,
has become increasingly diversified to include chemicals, rubber,
and other products. Growth in the financial sector, which now
accounts for about 22% of GDP, has more than compensated for the
decline in steel. Most banks are foreign-owned and have extensive
foreign dealings. Agriculture is based on small family-owned farms.
The economy depends on foreign and cross-border workers for more
than 30% of its labor force. Although Luxembourg, like all EU
members, has suffered from the global economic slump, the country
enjoys an extraordinarily high standard of living.
Macau
Macau''s well-to-do economy has remained one of the most open
in the world since its reversion to China in 1999. Apparel exports
and tourism are mainstays of the economy. Although the territory was
hit hard by the 1998 Asian financial crisis and the global downturn
in 2001, its economy grew 9.5% in 2002 and 15.6% in 2003. During the
first three quarters of 2004, Macau registered year-on-year GDP
increases of more than 20 percent. A rapid rise in the number of
mainland visitors because of China''s easing of restrictions on
travel, increased public works expenditures, and significant
investment inflows associated with the liberalization of Macau''s
gaming industry drove the recovery. The budget also returned to
surplus in 2002 because of the surge in visitors from China and a
hike in taxes on gambling profits, which generated about 70% of
government revenue. The three companies awarded gambling licenses
have pledged to invest $2.2 billion in the territory, which will
boost GDP growth. Much of Macau''s textile industry may move to the
mainland as the Multi-Fiber Agreement is phased out. The territory
may have to rely more on gambling and trade-related services to
generate growth. Two new casinos were opened by new foreign gambling
licensees in 2004; development of new infrastructure and facilities
in preparation for Macau''s hosting of the 2005 East Asian Games will
bolster the construction sector. The Closer Economic Partnership
Agreement (CEPA) between Macau and mainland China that came into
effect on 1 January 2004 offers many Macau-made products tariff-free
access to the mainland, and the range of products covered by CEPA
was to be expanded on 1 January 2005.
Macedonia
At independence in September 1991, Macedonia was the least
developed of the Yugoslav republics, producing a mere 5% of the
total federal output of goods and services. The collapse of
Yugoslavia ended transfer payments from the center and eliminated
advantages from inclusion in a de facto free trade area. An absence
of infrastructure, UN sanctions on the down-sized Yugoslavia, one of
its largest markets, and a Greek economic embargo over a dispute
about the country''s constitutional name and flag hindered economic
growth until 1996. GDP subsequently rose each year through 2000.
However, the leadership''s commitment to economic reform, free trade,
and regional integration was undermined by the ethnic Albanian
insurgency of 2001. The economy shrank 4.5% because of decreased
trade, intermittent border closures, increased deficit spending on
security needs, and investor uncertainty. Growth barely recovered in
2002 to 0.9%, then rose by a moderate 3.4% in 2003, and is estimated
at 1.3% in 2004. Unemployment at one-third of the workforce remains
a critical economic problem. Much of the extensive grey market
activity falls outside official statistics.','fb4d7bda27eddf8668b7aeec679485ac803fd119d69bb566ecf3a9466dcaf082','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70889524818f98bfa1407103842867e0ea51b4569a31d8162b90aa567e19ac29',2005,'MG','Madagascar','economy',755,'total: 29
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 20
under 914 m: 2 (2004 est.)
total: 87
1,524 to 2,437 m: 2
914 to 1,523 m: 42
under 914 m: 43 (2004 est.)
soil erosion results from deforestation and overgrazing;
desertification; surface water contaminated with raw sewage and
other organic wastes; several species of flora and fauna unique to
the island are endangered
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Life Conservation, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
1.2% (2004)
840.2 million kWh (2002)
781.4 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
50% (2004 est.)
lowest 10%: 3%
highest 10%: 29% (1999)
coffee, vanilla, shellfish, sugar; cotton cloth,
chromite, petroleum products
US 35.8%, France 30.8%, Germany 7.7% (2004)
6 provinces (faritany); Antananarivo, Antsiranana,
Fianarantsoa, Mahajanga, Toamasina, Toliara
coffee, vanilla, sugarcane, cloves, cocoa, rice, cassava
(tapioca), beans, bananas, peanuts; livestock products
116 (2004 est.)
41.66 births/1,000 population (2005 est.)
People''s Armed Forces: Intervention Force, Development
Force, and Aeronaval (Navy and Air) Force; National Gendarmerie
revenues: $783.7 million
expenditures: $1.079 billion, including capital expenditures of $331
million (2004 est.)
Having discarded past socialist economic policies,
Madagascar has since the mid 1990s followed a World Bank and IMF led
policy of privatization and liberalization. This strategy has placed
the country on a slow and steady growth path from an extremely low
level. Agriculture, including fishing and forestry, is a mainstay of
the economy, accounting for more than one-fourth of GDP and
employing 80% of the population. Exports of apparel have boomed in
recent years primarily due to duty-free access to the United States.
Deforestation and erosion, aggravated by the use of firewood as the
primary source of fuel are serious concerns. President RAVALOMANANA
has worked aggressively to revive the economy following the 2002
political crisis, which triggered a 12% drop in GDP that year.
Poverty reduction and combating corruption will be the centerpieces
of economic policy for the next few years.','8dd327af68dae4d28178cbdf6978fecea9455a50ac0d87e0e524e88d51f29c2e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac10c5da790ba1931957a1e8ccb40b6310d56122377b98f71eb88189f02033b3',2005,'MW','Malawi','economy',756,'total: 6
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 4 (2004 est.)
total: 36
1,524 to 2,437 m: 1
914 to 1,523 m: 15
under 914 m: 20 (2004 est.)
deforestation; land degradation; water pollution from
agricultural runoff, sewage, industrial wastes; siltation of
spawning grounds endangers fish populations
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
0.7% (2004)
1.088 billion kWh (2002)
1.012 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
55% (2004 est.)
lowest 10%: NA
highest 10%: NA
agriculture 90% (2003 est.)
tobacco 60%, tea, sugar, cotton, coffee, peanuts, wood
products, apparel
South Africa 13.5%, US 12%, Germany 11.6%, Egypt 8.4%, UK
6.6%, Mozambique 4.5% (2004)
27 districts; Balaka, Blantyre, Chikwawa, Chiradzulu,
Chitipa, Dedza, Dowa, Karonga, Kasungu, Likoma, Lilongwe, Machinga
(Kasupe), Mangochi, Mchinji, Mulanje, Mwanza, Mzimba, Ntcheu, Nkhata
Bay, Nkhotakota, Nsanje, Ntchisi, Phalombe, Rumphi, Salima, Thyolo,
Zomba
tobacco, sugarcane, cotton, tea, corn, potatoes, cassava
(tapioca), sorghum, pulses; groundnuts, Macadamia nuts; cattle, goats
42 (2004 est.)
43.95 births/1,000 population (2005 est.)
Malawi Armed Forces: Army (includes Air Wing and Naval
Detachment), Police (includes Mobile Force Unit)
revenues: $536 million
expenditures: $635.6 million, including capital expenditures of NA
(2004 est.)
Landlocked Malawi ranks among the world''s least developed
countries. The economy is predominately agricultural, with about 90%
of the population living in rural areas. Agriculture accounted for
nearly 40% of GDP and 88% of export revenues in 2001. The
performance of the tobacco sector is key to short-term growth as
tobacco accounts for over 50% of exports. The economy depends on
substantial inflows of economic assistance from the IMF, the World
Bank, and individual donor nations. In late 2000, Malawi was
approved for relief under the Heavily Indebted Poor Countries (HIPC)
program. The government faces strong challenges, including
developing a market economy, improving educational facilities,
facing up to environmental problems, dealing with the rapidly
growing problem of HIV/AIDS, and satisfying foreign donors that
fiscal discipline is being tightened. In 2005, the anticorruption
campaign championed by President MUTHARIKA may help encourage
investment and economic growth.','012f0952d36d78ded1b97c36fadc3b0f7f8a9b11bf8f868698a7f3b7a178da23','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45945bbc448cd4fcecdf7c7ffa23690b453a1e1e2d7825ae89f22052b3943749',2005,'MY','Malaysia','economy',757,'total: 38
over 3,047 m: 5
2,438 to 3,047 m: 7
1,524 to 2,437 m: 10
914 to 1,523 m: 9
under 914 m: 7 (2004 est.)
total: 79
1,524 to 2,437 m: 1
914 to 1,523 m: 6
under 914 m: 72 (2004 est.)
air pollution from industrial and vehicular emissions;
water pollution from raw sewage; deforestation; smoke/haze from
Indonesian forest fires
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
2.03% (FY00)
75.33 billion kWh (2002)
68.4 billion kWh (2002)
0 kWh (2002)
70 million kWh (2002)
8% (1998 est.)
lowest 10%: 1.4%
highest 10%: 39.2% (2003 est.)
agriculture 14.5%, industry 36%, services 49.5% (2000 est.)
electronic equipment, petroleum and liquefied natural gas,
wood and wood products, palm oil, rubber, textiles, chemicals
US 18.8%, Singapore 15%, Japan 10.1%, China 6.7%, Hong Kong
6%, Thailand 4.8% (2004)
13 states (negeri-negeri, singular - negeri) Johor, Kedah,
Kelantan, Melaka, Negeri Sembilan, Pahang, Perak, Perlis, Pulau
Pinang, Sabah, Sarawak, Selangor, and Terengganu; and one federal
territory (wilayah persekutuan) with three components, city of Kuala
Lumpur, Labuan, and Putrajaya
Peninsular Malaysia - rubber, palm oil, cocoa, rice; Sabah
- subsistence crops, rubber, timber, coconuts, rice; Sarawak -
rubber, pepper, timber
117 (2004 est.)
23.07 births/1,000 population (2005 est.)
Malaysian Army (Tentera Darat Malaysia), Royal Malaysian
Navy (Tentera Laut Diraja Malaysia, TLDM), Royal Malaysian Air Force
(Tentera Udara Diraja Malaysia, TUDM) (2005)
revenues: $25.33 billion
expenditures: $29.33 billion, including capital expenditures of $9.4
billion (2004 est.)
Malaysia, a middle-income country, transformed itself from
1971 through the late 1990''s from a producer of raw materials into
an emerging multi-sector economy. Growth was almost exclusively
driven by exports - particularly of electronics. As a result,
Malaysia was hard hit by the global economic downturn and the slump
in the information technology (IT) sector in 2001 and 2002. GDP in
2001 grew only 0.5% due to an estimated 11% contraction in exports,
but a substantial fiscal stimulus package equal to US $1.9 billion
mitigated the worst of the recession and the economy rebounded in
2002 with a 4.1% increase. The economy grew 4.9% in 2003,
notwithstanding a difficult first half, when external pressures from
SARS and the Iraq War led to caution in the business community.
Growth topped 7% in 2004. Healthy foreign exchange reserves, low
inflation, and a small external debt are all strengths that make it
unlikely that Malaysia will experience a financial crisis similar to
the one in 1997. The economy remains dependent on continued growth
in the US, China, and Japan, top export destinations and key sources
of foreign investment.','e965ab1b520ecc888452a1bbfcd60f70594a778f6c3d75d35281f447db20ab0c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd65595f8d9f0534900693481c684101e4b7d826379ee31440ade980fc1c32ca',2005,'MV','Maldives','economy',758,'total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (2004 est.)
total: 3
914 to 1,523 m: 3 (2004 est.)
depletion of freshwater aquifers threatens water supplies;
global warming and sea level rise; coral reef bleaching
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
5.5% (2004)
124.4 million kWh (2002)
115.7 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 22%, industry 18%, services 60% (1995)
fish, clothing
US 26.5%, Thailand 23.5%, Sri Lanka 12.3%, Japan 11.7%, UK
9.8%, Germany 4.9% (2004)
19 atolls (atholhu, singular and plural) and 1 other
first-order administrative division*; Alifu, Baa, Dhaalu, Faafu,
Gaafu Alifu, Gaafu Dhaalu, Gnaviyani, Haa Alifu, Haa Dhaalu, Kaafu,
Laamu, Lhaviyani, Maale*, Meemu, Noonu, Raa, Seenu, Shaviyani, Thaa,
Vaavu
coconuts, corn, sweet potatoes; fish
5 (2004 est.)
35.43 births/1,000 population (2005 est.)
National Security Service includes Security Branch (ground
forces), Air Element, Coast Guard
revenues: $224 million (excluding foreign grants)
expenditures: $282 million, including capital expenditures of $80
million (2002 est.)
Tourism, Maldives'' largest industry, accounts for 20% of
GDP and more than 60% of the Maldives'' foreign exchange receipts.
Over 90% of government tax revenue comes from import duties and
tourism-related taxes. Fishing is a second leading sector. The
Maldivian Government began an economic reform program in 1989
initially by lifting import quotas and opening some exports to the
private sector. Subsequently, it has liberalized regulations to
allow more foreign investment. Agriculture and manufacturing
continue to play a lesser role in the economy, constrained by the
limited availability of cultivable land and the shortage of domestic
labor. Most staple foods must be imported. Industry, which consists
mainly of garment production, boat building, and handicrafts,
accounts for about 18% of GDP. Maldivian authorities worry about the
impact of erosion and possible global warming on their low-lying
country; 80% of the area is one meter or less above sea level. In
late December 2004, a major tsunami left more than 100 dead, 12,000
displaced, and property damage exceeding $300 million.','58b9e4aea03b4e33086ac031c9159f7ad5edd1f1e6ef0bdc98a9ce1db8a03825','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cd75ac3d4946f887712479a067b3fe70feb088f0ec5fac06ce5f154e6b778c5',2005,'ML','Mali','economy',759,'total: 9
2,438 to 3,047 m: 4
1,524 to 2,437 m: 4
914 to 1,523 m: 1 (2004 est.)
total: 19
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 5
under 914 m: 8 (2004 est.)
deforestation; soil erosion; desertification; inadequate
supplies of potable water; poaching
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
0.4% (2004)
700 million kWh (2002)
651 million kWh (2002)
0 kWh (2002)
0 kWh; note - recent hydropower developments may be providing
electricity to Senegal and Mauritania (2002)
64% average; 30% of the total population living in urban areas;
70% of the total population living in rural areas) (2001 est.)
lowest 10%: 1.8%
highest 10%: 40.4% (1994)
agriculture and fishing 80% (2001 est.)
cotton, gold, livestock
China 31.6%, Pakistan 10%, Italy 6.9%, Thailand 5.8%, Germany
5.1%, India 4.8%, Bangladesh 4.5%, Taiwan 4% (2004)
8 regions (regions, singular - region); Gao, Kayes, Kidal,
Koulikoro, Mopti, Segou, Sikasso, Tombouctou
cotton, millet, rice, corn, vegetables, peanuts; cattle, sheep,
goats
28 (2004 est.)
46.77 births/1,000 population (2005 est.)
Army, Air Force, National Guard
revenues: $764 million
expenditures: $828 million, including capital expenditures of NA
(2002 est.)
Mali is among the poorest countries in the world, with 65% of
its land area desert or semidesert and with a highly unequal
distribution of income. Economic activity is largely confined to the
riverine area irrigated by the Niger. About 10% of the population is
nomadic and some 80% of the labor force is engaged in farming and
fishing. Industrial activity is concentrated on processing farm
commodities. Mali is heavily dependent on foreign aid and vulnerable
to fluctuations in world prices for cotton, its main export, along
with gold. The government has continued its successful
implementation of an IMF-recommended structural adjustment program
that is helping the economy grow, diversify, and attract foreign
investment. Mali''s adherence to economic reform and the 50%
devaluation of the African franc in January 1994 have pushed up
economic growth to a sturdy 5% average in 1996-2004. Worker
remittances and external trade routes have been jeopardized by
continued unrest in neighboring Cote d''Ivoire.','29f33cc4ef8bd3ee37888d5e4539fb04a92058cfedc64bb411317f095e448fcc','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f5dc696da5e4b3b180d17194ad6235e805d972d589a8137c2fa47594faaac93',2005,'MT','Malta','economy',760,'total: 1
over 3,047 m: 1 (2004 est.)
Man, Isle of
total: 1
1,524 to 2,437 m: 1 (2004 est.)
very limited natural fresh water resources; increasing
reliance on desalination
Man, Isle of
waste disposal (both household and industrial);
transboundary air pollution
party to: Air Pollution, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
0.7% (2004)
2.15 billion kWh (2002)
2 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
Man, Isle of
NA
lowest 10%: NA%
highest 10%: NA%
Man, Isle of
lowest 10%: NA%
highest 10%: NA%
agriculture 5%, industry 24%, services 71% (1999 est.)
Man, Isle of
agriculture, forestry and fishing 3%, manufacturing
11%, construction 10%, transport and communication 8%, wholesale and
retail distribution 11%, professional and scientific services 18%,
public administration 6%, banking and finance 18%, tourism 2%,
entertainment and catering 3%, miscellaneous services 10%
machinery and transport equipment, manufactures
Man, Isle of
tweeds, herring, processed shellfish, beef, lamb
US 15.7%, France 15.5%, Singapore 14.5%, UK 11.2%, Germany
10.8% (2004)
Man, Isle of
UK (2000)
none (administered directly from Valletta); note - Local
Councils carry out administrative orders
Man, Isle of
none; there are no first-order administrative divisions
as defined by the US Government, but there are 24 local authorities
each with its own elections
potatoes, cauliflower, grapes, wheat, barley, tomatoes,
citrus, cut flowers, green peppers; pork, milk, poultry, eggs
Man, Isle of
cereals, vegetables; cattle, sheep, pigs, poultry
1 (2004 est.)
Man, Isle of
1 (2004 est.)
10.17 births/1,000 population (2005 est.)
Man, Isle of
11.18 births/1,000 population (2005 est.)
Armed Forces of Malta (AFM; includes air and maritime
elements) (2005)
revenues: $2.27 billion
expenditures: $2.549 billion, including capital expenditures of NA
(2004 est.)
Man, Isle of
revenues: $485 million
expenditures: $463 million, including capital expenditures of NA
(FY00/01 est.)
Major resources are limestone, a favorable geographic
location, and a productive labor force. Malta produces only about
20% of its food needs, has limited fresh water supplies, and has no
domestic energy sources. The economy is dependent on foreign trade,
manufacturing (especially electronics and textiles), and tourism.
Continued sluggishness in the European economy is holding back
exports, tourism, and overall growth.
Man, Isle of
Offshore banking, manufacturing, and tourism are key
sectors of the economy. The government''s policy of offering
incentives to high-technology companies and financial institutions
to locate on the island has paid off in expanding employment
opportunities in high-income industries. As a result, agriculture
and fishing, once the mainstays of the economy, have declined in
their shares of GDP. Trade is mostly with the UK. The Isle of Man
enjoys free access to EU markets.','994dccc346afb13e4cd315491263785f8cf7c8e7e1b7e5f44c86e7f6af765c69','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3837f9a1ffef5b6e6a6e21a06674167acf22cd673892b09e2a23fddd90505cde',2005,'MH','Marshall Islands','economy',761,'total: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (2004 est.)
total: 11
914 to 1,523 m: 10
under 914 m: 1 (2004 est.)
inadequate supplies of potable water; pollution of
Majuro lagoon from household waste and discharges from fishing
vessels
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
NA
NA
lowest 10%: NA
highest 10%: NA
agriculture 21.4%, industry 20.9%, services 57.7%
copra cake, coconut oil, handicrafts, fish
US, Japan, Australia, China (2000)
33 municipalities; Ailinginae, Ailinglaplap, Ailuk,
Arno, Aur, Bikar, Bikini, Bokak, Ebon, Enewetak, Erikub, Jabat,
Jaluit, Jemo, Kili, Kwajalein, Lae, Lib, Likiep, Majuro, Maloelap,
Mejit, Mili, Namorik, Namu, Rongelap, Rongrik, Toke, Ujae, Ujelang,
Utirik, Wotho, Wotje
coconuts, tomatoes, melons, taro, breadfruit,
fruits; pigs, chickens
15 (2004 est.)
33.52 births/1,000 population (2005 est.)
no regular military forces; Marshall Islands Police
revenues: $42 million
expenditures: $40 million, including capital expenditures of NA
(1999)
US Government assistance is the mainstay of this
tiny island economy. Agricultural production, primarily subsistence,
is concentrated on small farms; the most important commercial crops
are coconuts and breadfruit. Small-scale industry is limited to
handicrafts, tuna processing, and copra. The tourist industry, now a
small source of foreign exchange employing less than 10% of the
labor force, remains the best hope for future added income. The
islands have few natural resources, and imports far exceed exports.
Under the terms of the Amended Compact of Free Association, the US
will provide millions of dollars per year to the Marshall Islands
(RMI) through 2023, at which time a Trust Fund made up of US and RMI
contributions will begin perpetual annual payouts. Government
downsizing, drought, a drop in construction, the decline in tourism
and foreign investment due to the Asian financial difficulties, and
less income from the renewal of fishing vessel licenses have held
GDP growth to an average of 1% over the past decade.','0eff1b7ef6b6471b4ff2ca4307958649a1736e814992401e43c13ecb4c3bdd3f','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b5aa51e1d53ed11317388f8e5f864bd1dc900fcc323a22a6431adf00a8e9af6',2005,'MQ','Martinique','economy',762,'total: 1
over 3,047 m: 1 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
NA
1.178 billion kWh (2002)
1.095 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 10%, industry 17%, services 73% (1997)
refined petroleum products, bananas, rum, pineapples
(2001 est.)
France 45%, Guadeloupe 28% (2000)
none (overseas department of France)
pineapples, avocados, bananas, flowers, vegetables,
sugarcane
2 (2004 est.)
14.14 births/1,000 population (2005 est.)
no regular military forces; Gendarmerie
revenues: $900 million
expenditures: $2.5 billion, including capital expenditures of $140
million (1996)
The economy is based on sugarcane, bananas, tourism, and
light industry. Agriculture accounts for about 6% of GDP and the
small industrial sector for 11%. Sugar production has declined, with
most of the sugarcane now used for the production of rum. Banana
exports are increasing, going mostly to France. The bulk of meat,
vegetable, and grain requirements must be imported, contributing to
a chronic trade deficit that requires large annual transfers of aid
from France. Tourism, which employs more than 11,000 people, has
become more important than agricultural exports as a source of
foreign exchange.','e8e48f36711f5cec5b87689280a5b51824936fd148aac05c77dd05c105a45aeb','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('214ece7533a129c4ae7029712bea06dbe91fc2c001011e7975fdee63dc43cfd9',2005,'MR','Mauritania','economy',763,'total: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5 (2004 est.)
total: 16
1,524 to 2,437 m: 9
914 to 1,523 m: 6
under 914 m: 1 (2004 est.)
overgrazing, deforestation, and soil erosion aggravated
by drought are contributing to desertification; very limited natural
fresh water resources away from the Senegal, which is the only
perennial river; locust infestation
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
1.7% (2004)
190.2 million kWh (2002)
176.9 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
40% (2004 est.)
lowest 10%: 2.5%
highest 10%: 30.2% (2000)
agriculture 50%, industry 10%, services 40% (2001 est.)
iron ore, fish and fish products, gold
Japan 13.1%, France 11%, Spain 9.7%, Germany 9.7%, Italy
9.6%, Belgium 7.5%, China 6.1%, Russia 4.6%, Cote d''Ivoire 4.1%
(2004)
12 regions (regions, singular - region) and 1 capital
district*; Adrar, Assaba, Brakna, Dakhlet Nouadhibou, Gorgol,
Guidimaka, Hodh Ech Chargui, Hodh El Gharbi, Inchiri, Nouakchott*,
Tagant, Tiris Zemmour, Trarza
dates, millet, sorghum, rice, corn, dates; cattle, sheep
24 (2004 est.)
41.43 births/1,000 population (2005 est.)
Mauritanian Armed Forces: Army, Navy (Marine
Mauritanienne; includes Naval Infantry), Air Force (Force Aerienne
Islamique de Mauritanie, FAIM) (2005)
revenues: $421 million
expenditures: $378 million, including capital expenditures of $154
million (2002 est.)
Half the population still depends on agriculture and
livestock for a livelihood, even though many of the nomads and
subsistence farmers were forced into the cities by recurrent
droughts in the 1970s and 1980s. Mauritania has extensive deposits
of iron ore, which account for nearly 40% of total exports. The
decline in world demand for this ore, however, has led to cutbacks
in production. The nation''s coastal waters are among the richest
fishing areas in the world, but overexploitation by foreigners
threatens this key source of revenue. The country''s first deepwater
port opened near Nouakchott in 1986. In the past, drought and
economic mismanagement resulted in a buildup of foreign debt. In
February 2000, Mauritania qualified for debt relief under the
Heavily Indebted Poor Countries (HIPC) initiative and in December
2001 received strong support from donor and lending countries at a
triennial Consultative Group review. In 2001, exploratory oil wells
in tracts 80 km offshore indicated potential extraction at current
world oil prices. A new investment code approved in December 2001
improved the opportunities for direct foreign investment. Ongoing
negotiations with the IMF involve problems of economic reforms and
fiscal discipline. Substantial oil production and exports probably
will not begin until 2006. Meantime the government emphasizes
reduction of poverty, improvement of health and education, and
promoting privatization of the economy.','27a5bd8786717e570e834af22ed98542cc62bcf67af0b05478bedcb41f3b1c35','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4482df7418c9e192c8e14e0db3db65bc729c83b2fdd293a1fa59e1e5b43967ff',2005,'MU','Mauritius','economy',764,'total: 2
over 3,047 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 4
914 to 1,523 m: 2
under 914 m: 2 (2004 est.)
water pollution, degradation of coral reefs
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Life Conservation, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
0.2% (2004)
1.836 billion kWh (2002)
1.707 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
10% (2001 est.)
lowest 10%: NA
highest 10%: NA
agriculture and fishing 14%, construction and industry
36%, transportation and communication 7%, trade, restaurants, hotels
16%, finance 3%, other services 24% (1995)
clothing and textiles, sugar, cut flowers, molasses
UK 33.1%, France 20.4%, US 14.8%, Madagascar 5.1%, Italy
4.1% (2004)
9 districts and 3 dependencies*; Agalega Islands*, Black
River, Cargados Carajos Shoals*, Flacq, Grand Port, Moka,
Pamplemousses, Plaines Wilhems, Port Louis, Riviere du Rempart,
Rodrigues*, Savanne
sugarcane, tea, corn, potatoes, bananas, pulses; cattle,
goats; fish
6 (2004 est.)
15.62 births/1,000 population (2005 est.)
National Police Force (includes the paramilitary Special
Mobile Force or SMF and National Coast Guard)
revenues: $1.231 billion
expenditures: $1.582 billion, including capital expenditures of NA
(2004 est.)
Since independence in 1968, Mauritius has developed from a
low-income, agriculturally based economy to a middle-income
diversified economy with growing industrial, financial, and tourist
sectors. For most of the period, annual growth has been in the order
of 5% to 6%. This remarkable achievement has been reflected in more
equitable income distribution, increased life expectancy, lowered
infant mortality, and a much-improved infrastructure. Sugarcane is
grown on about 90% of the cultivated land area and accounts for 25%
of export earnings. The government''s development strategy centers on
expanding local financial institutions and building a domestic
information telecommunications industry. Mauritius has attracted
more than 9,000 offshore entities, many aimed at commerce in India
and South Africa, and investment in the banking sector alone has
reached over $1 billion. Mauritius, with its strong textile sector,
has been well poised to take advantage of the Africa Growth and
Opportunity Act (AGOA).','662625732bc0e4a5dc3644b11373a700907618bc45c64d8d120803bb95f90f96','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dca58c16586dedd08734fde07f04a5115a5d33ba12394183bab2c1bc5d14cc2d',2005,'YT','Mayotte','economy',765,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
NA
NA kWh
NA kWh
NA%
lowest 10%: NA%
highest 10%: NA%
ylang-ylang (perfume essence), vanilla, copra, coconuts,
coffee, cinnamon
France 80%, Comoros 15%, Reunion (2000)
none (territorial collectivity of France)
vanilla, ylang-ylang (perfume essence), coffee, copra
1 (2004 est.)
41.58 births/1,000 population (2005 est.)
revenues: NA
expenditures: $73 million, including capital expenditures of NA
(1991 est.)
Economic activity is based primarily on the agricultural
sector, including fishing and livestock raising. Mayotte is not
self-sufficient and must import a large portion of its food
requirements, mainly from France. The economy and future development
of the island are heavily dependent on French financial assistance,
an important supplement to GDP. Mayotte''s remote location is an
obstacle to the development of tourism.','700ed1a97991ac92df6b15b988e7018498b4897c86c08c4a1e4726c131934bb8','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3af956a4c891eed89b8f6abe740a30c7a99c1016cbbdbe95ad7def330b6afa67',2005,'MX','Mexico','economy',766,'total: 233
over 3,047 m: 12
2,438 to 3,047 m: 28
1,524 to 2,437 m: 84
914 to 1,523 m: 80
under 914 m: 29 (2004 est.)
total: 1,600
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 69
914 to 1,523 m: 454
under 914 m: 1,075 (2004 est.)
Midway Islands
total: 1
914 to 1,523 m: 1 (2004 est.)
Moldova
total: 17
1,524 to 2,437 m: 1
914 to 1,523 m: 5
under 914 m: 11 (2004 est.)
scarcity of hazardous waste disposal facilities; rural to
urban migration; natural fresh water resources scarce and polluted
in north, inaccessible and poor quality in center and extreme
southeast; raw sewage and industrial effluents polluting rivers in
urban areas; deforestation; widespread erosion; desertification;
deteriorating agricultural lands; serious air and water pollution in
the national capital and urban centers along US-Mexico border; land
subsidence in Valley of Mexico caused by groundwater depletion
note: the government considers the lack of clean water and
deforestation national security issues
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
0.9% (2004)
Moldova
0.4% (FY02)
203.6 billion kWh (2002)
189.7 billion kWh (2002)
367.7 million kWh (2002)
98.65 million kWh (2002)
40% (2003 est.)
lowest 10%: 1.6%
highest 10%: 35.6% (2002)
agriculture 18%, industry 24%, services 58% (2003)
manufactured goods, oil and oil products, silver, fruits,
vegetables, coffee, cotton
US 87.6%, Canada 1.8%, Spain 1.1% (2004)
31 states (estados, singular - estado) and 1 federal
district* (distrito federal); Aguascalientes, Baja California, Baja
California Sur, Campeche, Chiapas, Chihuahua, Coahuila de Zaragoza,
Colima, Distrito Federal*, Durango, Guanajuato, Guerrero, Hidalgo,
Jalisco, Mexico, Michoacan de Ocampo, Morelos, Nayarit, Nuevo Leon,
Oaxaca, Puebla, Queretaro de Arteaga, Quintana Roo, San Luis Potosi,
Sinaloa, Sonora, Tabasco, Tamaulipas, Tlaxcala, Veracruz-Llave,
Yucatan, Zacatecas
corn, wheat, soybeans, rice, beans, cotton, coffee, fruit,
tomatoes; beef, poultry, dairy products; wood products
1,833 (2004 est.)
21.01 births/1,000 population (2005 est.)
Secretariat of National Defense (Sedena): Army and Air Force
(FAM)
Secretariat of the Navy (Semar): Naval Air and Marines (2004)
revenues: $160 billion
expenditures: $158 billion, including capital expenditures of NA
(2004 est.)
Mexico has a free market economy that recently entered the
trillion dollar class. It contains a mixture of modern and outmoded
industry and agriculture, increasingly dominated by the private
sector. Recent administrations have expanded competition in
seaports, railroads, telecommunications, electricity generation,
natural gas distribution, and airports. Per capita income is
one-fourth that of the US; income distribution remains highly
unequal. Trade with the US and Canada has tripled since the
implementation of NAFTA in 1994. Mexico has 12 free trade agreements
with over 40 countries including, Guatemala, Honduras, El Salvador,
the European Free Trade Area, and Japan, putting more than 90% of
trade under free trade agreements. The government is cognizant of
the need to upgrade infrastructure, modernize the tax system and
labor laws, and provide incentives to invest in the energy sector,
but progress is slow.','236c933c6534c4495486cb47e4709960dd97fc00ac9c60d8178e05de9734e18c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b434af26f7e78cbbf0c9c849b83badfcead5420de4b8b7d8ebc0693b856db69',2005,'FM','Micronesia, Federated States of','economy',767,'total: 6
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2004 est.)
Midway Islands
total: 2
1,524 to 2,437 m: 2 (2004 est.)
Moldova
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
under 914 m: 1 (2004 est.)
overfishing, climate change,
pollution
Midway Islands
NA
Moldova
heavy use of agricultural chemicals, including banned
pesticides such as DDT, has contaminated soil and groundwater;
extensive soil erosion from poor farming methods
party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Moldova
party to: Air Pollution, Air Pollution-Persistent Organic
Pollutants, Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes,
Ozone Layer Protection
signed, but not ratified: none of the selected agreements
192 million kWh (2002)
Moldova
3.876 billion kWh (2002)
178.6 million kWh (2002)
Moldova
4.605 billion kWh (2002)
0 kWh (2002)
Moldova
1 billion kWh (2002)
0 kWh (2002)
Moldova
0 kWh (2002)
26.7%
Moldova
80% (2001 est.)
lowest 10%: NA
highest 10%: NA
Moldova
lowest 10%: 2.2%
highest 10%: 30.7% (1997)
two-thirds are government employees
Moldova
agriculture 40%, industry 14%, services 46% (1998)
fish, garments, bananas, black pepper
Moldova
foodstuffs, textiles, machinery
Japan, US, Guam (2000)
Moldova
Russia 35.8%, Italy 13.9%, Romania 10%, Germany 7.3%,
Ukraine 6.6%, Belarus 6%, US 4.6% (2004)
4 states; Chuuk (Truk), Kosrae
(Kosaie), Pohnpei (Ponape), Yap
Moldova
32 raions (raioane, singular - raionul), 3 municipalities
(municipiul), 1 autonomous territorial unit (unitatea teritoriala
autonoma), and 1 territorial unit (unitatea teritoriala)
counties: Anenii Noi, Basarabeasca, Briceni, Cahul, Cantemir,
Calarasi, Causeni, Cimislia, Criuleni, Donduseni, Drochia, Dubasari,
Edinet, Falesti, Floresti, Glodeni, Hincesti, Ialoveni, Leova,
Nisporeni, Ocnita, Orhei, Rezina, Riscani, Singerei, Soldanesti,
Soroca, Stefan-Voda, Straseni, Taraclia, Telenesti, Ungheni
municipalities: Balti, Bender, Chisinau
autonomous territorial unit: Gagauzia
territorial unit: Stinga Nistrului
black pepper, tropical fruits and
vegetables, coconuts, cassava (tapioca), betel nuts, sweet potatoes;
pigs, chickens
Moldova
vegetables, fruits, wine, grain, sugar beets, sunflower
seed, tobacco; beef, milk
6 (2004 est.)
Midway Islands
3 (2004 est.)
Moldova
23 (2004 est.)
25.11 births/1,000 population (2005
est.)
Moldova
15.27 births/1,000 population (2005 est.)
no ministry of defense and no
standing armed forces; the paramilitary Maritime Wing, a small
maritime law enforcement unit, is responsible to the Division of
Maritime Surveillance within the Office of the Attorney General
(2003)
Moldova
National Army: Ground Forces, Air Force
revenues: $161 million ($69 million
less grants)
expenditures: $160 million, including capital expenditures of NA
(1998 est.)
Moldova
revenues: $648.1 million
expenditures: $634.8 million, including capital expenditures of NA
(2004 est.)
Economic activity consists primarily
of subsistence farming and fishing. The islands have few mineral
deposits worth exploiting, except for high-grade phosphate. The
potential for a tourist industry exists, but the remote location, a
lack of adequate facilities, and limited air connections hinder
development. The Amended Compact of Free Association with the US
guarantees the Federated States of Micronesia (FSM) millions of
dollars in annual aid through 2023, and establishes a Trust Fund
into which the US and the FSM make annual contributions in order to
provide annual payouts to the FSM in perpetuity after 2023. The
country''s medium-term economic outlook appears fragile due not only
to the reduction in US assistance but also to the slow growth of the
private sector. Geographical isolation and a poorly developed
infrastructure remain major impediments to long-term growth.
Midway Islands
The economy is based on providing support services
for the national wildlife refuge activities located on the islands.
All food and manufactured goods must be imported.
Moldova
Moldova remains one of the poorest countries in Europe
despite recent progress from its small economic base. It enjoys a
favorable climate and good farmland but has no major mineral
deposits. As a result, the economy depends heavily on agriculture,
featuring fruits, vegetables, wine, and tobacco. Moldova must import
almost all of its energy supplies from Russia. Energy shortages
contributed to sharp production declines after the breakup of the
Soviet Union in December 1991. As part of an ambitious reform effort
after independence, Moldova introduced a convertible currency, freed
prices, stopped issuing preferential credits to state enterprises,
backed steady land privatization, removed export controls, and freed
interest rates. The government entered into agreements with the
World Bank and the IMF to promote growth and reduce poverty. The
economy returned to positive growth of 2.1% in 2000, 6.1% in 2001,
7.2% in 2002, 6.3% in 2003, and 6.8% in 2004. Further reforms will
come slowly because of strong political forces backing government
controls. The economy remains vulnerable to higher fuel prices, poor
agricultural weather, and the skepticism of foreign investors.','6e4eb2a8f1ff8aee558faf785cdf4d5fb4923ccb1faee124c9b50ed936c405b1','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1db5644f72d88c2ee1a699acfa0ae39f58ee6dfa412b54f218afe41b2f0b471a',2005,'MN','Mongolia','economy',768,'total: 15
over 3,047 m: 1
2,438 to 3,047 m: 11
1,524 to 2,437 m: 3 (2004 est.)
total: 31
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 18
914 to 1,523 m: 4
under 914 m: 3 (2004 est.)
limited natural fresh water resources in some areas; the
policies of former Communist regimes promoted rapid urbanization and
industrial growth that had negative effects on the environment; the
burning of soft coal in power plants and the lack of enforcement of
environmental laws severely polluted the air in Ulaanbaatar;
deforestation, overgrazing, and the converting of virgin land to
agricultural production increased soil erosion from wind and rain;
desertification and mining activities had a deleterious effect on
the environment
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
2.2% (FY02)
2.692 billion kWh (2004 est.)
2.209 billion kWh (2004 est.)
130.5 million kWh (2004 est.)
8.2 million kWh (2004 est.)
36.1% (2004 est.)
lowest 10%: 2.1%
highest 10%: 37% (1995)
herding/agriculture 42%, mining 4%, manufacturing 6%, trade
14%, services 29%, public sector 5%, other 3.7% (2003)
copper, apparel, livestock, animal products, cashmere,
wool, hides, fluorspar, other nonferrous metals
China 47.8%, US 17.9%, UK 15.7% (2004)
21 provinces (aymguud, singular - aymag) and 1
municipality* (singular - hot); Arhangay, Bayanhongor, Bayan-Olgiy,
Bulgan, Darhan Uul, Dornod, Dornogovi, Dundgovi, Dzavhan,
Govi-Altay, Govi-Sumber, Hentiy, Hovd, Hovsgol, Omnogovi, Orhon,
Ovorhangay, Selenge, Suhbaatar, Tov, Ulaanbaatar*, Uvs
wheat, barley, vegetables, forage crops, sheep, goats,
cattle, camels, horses
46 (2004 est.)
21.52 births/1,000 population (2005 est.)
Mongolian Armed Forces: Mongolian People''s Army (MPA),
Mongolian People''s Air Force (MPAF) (2005)
revenues: $582 million
expenditures: $602 million, including capital expenditures of NA
(2004 est.)
Economic activity in Mongolia has traditionally been based
on herding and agriculture. Mongolia has extensive mineral deposits;
copper, coal, molybdenum, tin, tungsten and gold account for a large
part of industrial production. Soviet assistance, at its height
one-third of GDP, disappeared almost overnight in 1990 and 1991 at
the time of the dismantlement of the USSR. The following decade saw
Mongolia endure both deep recession due to political inaction and
natural disasters, as well as economic growth due to reform
embracing free-market economics and extensive privatization of the
formerly state-run economy. Severe winters and summer droughts in
2000, 2001, and 2002 resulted in massive livestock die-off and zero
or negative GDP growth. This was compounded by falling prices for
Mongolia''s primary sector exports and widespread opposition to
privatization. Growth improved from 2002 at 4% to 2003 at 5%, due
largely to high copper prices and new gold production, with the
government claiming a 10.6% growth rate for 2004 that is
unconfirmed. Mongolia''s economy continues to be heavily impacted by
its neighbors. For example, Mongolia purchases 80% of its petroleum
products and a substantial amount of electric power from Russia,
leaving it vulnerable to price increases. China is Mongolia''s chief
export partner and a main source of the "shadow" or "grey" economy.
The World Bank and other international financial institutions
estimate the grey economy to be at least equal to that of the
official economy. The actual size of this grey - largely cash -
economy is difficult to calculate since the money does not pass
through the hands of tax authorities or the banking sector.
Remittances from Mongolians working abroad both legally and
illegally constitute a sizeable portion. Money laundering is growing
as an accompanying concern. Mongolia settled its $11 billion debt
with Russia at the end of 2003 on very favorable terms. Mongolia,
which joined the World Trade Organization in 1997, seeks to expand
its participation and integration into Asian regional economic and
trade regimes.','eee02f864f1a0952a9799f689e33355ef7ebf9eed9dad86891c7813d26d72962','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d266ef25f7fad9890f3c9e641d1c298d0660b7f497736b985b7fdb88f90db558',2005,'MS','Montserrat','economy',769,'total: 1
under 914 m: 1 (2004 est.)
land erosion occurs on slopes that have been cleared for
cultivation
1.8 million kWh (2002)
1.674 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture NA%, industry NA%, services NA%
electronic components, plastic bags, apparel, hot
peppers, live plants, cattle
US, Antigua and Barbuda
3 parishes; Saint Anthony, Saint Georges, Saint Peter
cabbages, carrots, cucumbers, tomatoes, onions, peppers,
livestock products
1 (2004 est.)
17.56 births/1,000 population (2005 est.)
no regular military forces; Royal Montserrat Police Force
(2005)
revenues: $31.4 million
expenditures: $31.6 million, including capital expenditures of $8.4
million (1997 est.)
Severe volcanic activity, which began in July 1995, has
put a damper on this small, open economy. A catastrophic eruption in
June 1997 closed the airports and seaports, causing further economic
and social dislocation. Two-thirds of the 12,000 inhabitants fled
the island. Some began to return in 1998, but lack of housing
limited the number. The agriculture sector continued to be affected
by the lack of suitable land for farming and the destruction of
crops. Prospects for the economy depend largely on developments in
relation to the volcano and on public sector construction activity.
The UK has launched a three-year $122.8 million aid program to help
reconstruct the economy. Half of the island is expected to remain
uninhabitable for another decade.','4d04f466956e5b2f966ac5641cc3da39755909edb3cb038d12495e392c3ca84b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdbfaa4d63509b7d3b03ae23280f24b23f1124cc43a905a264241342ee7b431b',2005,'MA','Morocco','economy',770,'total: 25
over 3,047 m: 11
2,438 to 3,047 m: 4
1,524 to 2,437 m: 8
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 38
2,438 to 3,047 m: 2
1,524 to 2,437 m: 10
914 to 1,523 m: 15
under 914 m: 11 (2004 est.)
land degradation/desertification (soil erosion resulting
from farming of marginal areas, overgrazing, destruction of
vegetation); water supplies contaminated by raw sewage; siltation of
reservoirs; oil pollution of coastal waters
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes,
Marine Dumping, Ozone Layer Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: Environmental Modification, Law of the Sea
5% (2004)
13.91 billion kWh (2002)
14.24 billion kWh (2002)
1.3 billion kWh (2002)
0 kWh (2002)
19% (1999 est.)
lowest 10%: 2.6%
highest 10%: 30.9% (1998-99)
agriculture 40%, industry 15%, services 45% (2003 est.)
clothing, fish, inorganic chemicals, transistors, crude
minerals, fertilizers (including phosphates), petroleum products,
fruits, vegetables
France 33.6%, Spain 17.4%, UK 7.7%, Italy 4.7%, US 4.1%
(2004)
14 regions: Grand Casablanca, Chaouia-Ouardigha,
Doukkala-Abda, Fes-Boulemane, Gharb-Chrarda-Beni Hssen, Guelmim-Es
Smara, Marrakech-Tensift-Al Haouz, Meknes-Tafilalet, Oriental,
Rabat-Sale-Zemmour-Zaer, Souss-Massa-Draa, Tadla-Azilal,
Tanger-Tetouan, Taza-Al Hoceima-Taounate
note: Morocco claims the territory of Western Sahara, the political
status of which is considered undetermined by the United States
Government; one additional region, Oued Eddahab-Lagouira, falls
entirely within Western Sahara; another region,
Laayoune-Boujdour-Sahia El Hamra, falls mostly within Western
Sahara; a small portion of this region, in the southwestern part of
the country, falls within Moroccan-administered territory as
recognized by the United States; the province of Guelmim-Es Smara
lies in both entities
barley, wheat, citrus, wine, vegetables, olives; livestock
63 (2004 est.)
22.29 births/1,000 population (2005 est.)
Royal Armed Forces: Army, Navy, Air Force (Force Aerienne
Royale Marocaine)
revenues: $12.86 billion
expenditures: $15.4 billion, including capital expenditures of $2.19
billion (2004 est.)
Morocco faces problems typical for developing countries:
restraining government spending, reducing constraints on private
activity and foreign trade, and achieving sustainable growth.
Despite structural adjustment programs supported by the IMF, the
World Bank, and the Paris Club, the dirham is only fully convertible
for current account transactions. In 2004 Moroccan authorities
instituted measures to boost foreign direct investment and trade by
signing a free trade agreement with the US and selling government
shares in the state telecommunications company and in the largest
state-owned bank. Favorable rainfall over the past two years has
boosted agricultural output and GDP growth passed 4% in 2004. In
2005 the budget deficit is expected to rise sharply - from 1.9% of
GDP in 2004 - because of substantial increases in wages and oil
subsidies. Long-term challenges include preparing the economy for
freer trade with the US and European Union, improving education and
job prospects for Morocco''s youth, and raising living standards.','7aa3864269adeb4a02377c78c1f1b5f881a870fdbaa71cd5c2975feea05c5e7d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9eabdd5e4c410931755a1a1589437ca7e6ceb302ffe3ce7ba92fe636031f7922',2005,'MZ','Mozambique','economy',771,'total: 22
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 10
914 to 1,523 m: 3
under 914 m: 5 (2004 est.)
total: 136
2,438 to 3,047 m: 1
1,524 to 2,437 m: 14
914 to 1,523 m: 34
under 914 m: 87 (2004 est.)
a long civil war and recurrent drought in the hinterlands
have resulted in increased migration of the population to urban and
coastal areas with adverse environmental consequences;
desertification; pollution of surface and coastal waters; elephant
poaching for ivory is a problem
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
2.2% (2004)
8.859 billion kWh (2002)
5.046 billion kWh (2002)
3.907 billion kWh (2002)
7.1 billion kWh (2002)
70% (2001 est.)
lowest 10%: 2.5%
highest 10%: 31.7% (1997)
agriculture 81%, industry 6%, services 13% (1997 est.)
aluminum, prawns, cashews, cotton, sugar, citrus, timber;
bulk electricity
Netherlands 60.9%, South Africa 12.9%, Malawi 3.3% (2004)
10 provinces (provincias, singular - provincia), 1 city
(cidade)*; Cabo Delgado, Gaza, Inhambane, Manica, Maputo, Cidade de
Maputo*, Nampula, Niassa, Sofala, Tete, Zambezia
cotton, cashew nuts, sugarcane, tea, cassava (tapioca),
corn, coconuts, sisal, citrus and tropical fruits, potatoes,
sunflowers; beef, poultry
158 (2004 est.)
35.79 births/1,000 population (2005 est.)
Mozambique Armed Defense Forces: Army, Navy, Air and Air
Defense Forces, Logistics Command
revenues: $1.186 billion
expenditures: $1.398 billion, including capital expenditures of
$479.4 million (2004 est.)
At independence in 1975, Mozambique was one of the
world''s poorest countries. Socialist mismanagement and a brutal
civil war from 1977-92 exacerbated the situation. In 1987, the
government embarked on a series of macroeconomic reforms designed to
stabilize the economy. These steps, combined with donor assistance
and with political stability since the multi-party elections in
1994, have led to dramatic improvements in the country''s growth
rate. Inflation was reduced to single digits during the late 1990s
although it returned to double digits in 2000-03. Fiscal reforms,
including the introduction of a value-added tax and reform of the
customs service, have improved the government''s revenue collection
abilities. In spite of these gains, Mozambique remains dependent
upon foreign assistance for much of its annual budget, and the
majority of the population remains below the poverty line.
Subsistence agriculture continues to employ the vast majority of the
country''s workforce. A substantial trade imbalance persists although
the opening of the MOZAL aluminum smelter, the country''s largest
foreign investment project to date has increased export earnings.
Additional investment projects in titanium extraction and processing
and garment manufacturing should further close the import/export
gap. Mozambique''s once substantial foreign debt has been reduced
through forgiveness and rescheduling under the IMF''s Heavily
Indebted Poor Countries (HIPC) and Enhanced HIPC initiatives, and is
now at a manageable level.','5fd18b71b59fc3029f10876d9495843ae2b986d3b5158179ef452b1f691b4cf1','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbf7d4d4ddc269cc32a59f0deb55a152d892ced972a3d4f177e42c2d7b2b143a',2005,'NA','Namibia','economy',772,'total: 21
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 13
914 to 1,523 m: 4 (2004 est.)
total: 115
2,438 to 3,047 m: 2
1,524 to 2,437 m: 22
914 to 1,523 m: 71
under 914 m: 20 (2004 est.)
very limited natural fresh water resources; desertification;
wildlife poaching; land degradation has led to few conservation areas
party to: Antarctic-Marine Living Resources, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
3.1% (2004)
1.167 billion kWh (2002)
1.92 billion kWh (2002)
900 million kWh; note - electricity supplied by South Africa
(2002)
65 million kWh (2002)
50% (2002 est.)
lowest 10%: NA
highest 10%: NA
agriculture 47%, industry 20%, services 33% (1999 est.)
diamonds, copper, gold, zinc, lead, uranium; cattle,
processed fish, karakul skins
EU 79%, US 4% (2001)
13 regions; Caprivi, Erongo, Hardap, Karas, Khomas, Kunene,
Ohangwena, Okavango, Omaheke, Omusati, Oshana, Oshikoto, Otjozondjupa
millet, sorghum, peanuts; livestock; fish
136 (2004 est.)
25.16 births/1,000 population (2005 est.)
Namibian Defense Force: Army (includes Air Wing), Navy,
Police
revenues: $1.788 billion
expenditures: $1.956 billion, including capital expenditures of NA
(2004 est.)
The economy is heavily dependent on the extraction and
processing of minerals for export. Mining accounts for 20% of GDP.
Rich alluvial diamond deposits make Namibia a primary source for
gem-quality diamonds. Namibia is the fourth-largest exporter of
nonfuel minerals in Africa, the world''s fifth-largest producer of
uranium, and the producer of large quantities of lead, zinc, tin,
silver, and tungsten. The mining sector employs only about 3% of the
population while about half of the population depends on subsistence
agriculture for its livelihood. Namibia normally imports about 50%
of its cereal requirements; in drought years food shortages are a
major problem in rural areas. A high per capita GDP, relative to the
region, hides the great inequality of income distribution; nearly
one-third of Namibians had annual incomes of less than $1,400 in
constant 1994 dollars, according to a 1993 study. The Namibian
economy is closely linked to South Africa with the Namibian dollar
pegged to the South African rand. Privatization of several
enterprises in coming years may stimulate long-run foreign
investment. Mining of zinc, copper, and silver and increased fish
production led growth in 2003-04.','4cd9821c6a15ff139314f2a04ec945d60065e7641b5b7914308a9acb4fb66d9b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca4e206aa87bdf3ab42b56ae34226d84d845a914f29cde29b669071bb394e4a5',2005,'NR','Nauru','economy',773,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
limited natural fresh water resources, roof storage tanks
collect rainwater, but mostly dependent on a single, aging
desalination plant; intensive phosphate mining during the past 90
years - mainly by a UK, Australia, and NZ consortium - has left the
central 90% of Nauru a wasteland and threatens limited remaining
land resources
Navassa Island
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
NA
30 million kWh (2002)
27.9 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
employed in mining phosphates, public administration,
education, and transportation
phosphates
South Africa 43.4%, Germany 20.7%, India 11.8%, Japan 7.2%,
Poland 4% (2004)
14 districts; Aiwo, Anabar, Anetan, Anibare, Baiti, Boe,
Buada, Denigomodu, Ewa, Ijuw, Meneng, Nibok, Uaboe, Yaren
coconuts
1 (2004 est.)
25.14 births/1,000 population (2005 est.)
no regular military forces; Nauru Police Force
revenues: $23.4 million
expenditures: $64.8 million, including capital expenditures of NA
(FY95/96)
Revenues of this tiny island have traditionally come from
exports of phosphates, but reserves are now depleted. Few other
resources exist with most necessities being imported, mainly from
Australia, its former occupier and later major source of support.
The rehabilitation of mined land and the replacement of income from
phosphates are serious long-term problems. In anticipation of the
exhaustion of Nauru''s phosphate deposits, substantial amounts of
phosphate income have been invested in trust funds to help cushion
the transition and provide for Nauru''s economic future. As a result
of heavy spending from the trust funds, the government faces virtual
bankruptcy. To cut costs the government has called for a freeze on
wages, a reduction of over-staffed public service departments,
privatization of numerous government agencies, and closure of some
overseas consulates. In recent years Nauru has encouraged the
registration of offshore banks and corporations. In 2004 the
deterioration in housing, hospitals, and other capital plant
continued, and the cost to Australia of keeping the government and
economy afloat has substantially mounted. Few comprehensive
statistics on the Nauru economy exist, with estimates of Nauru''s GDP
varying widely.
Navassa Island
subsistence fishing and commercial trawling
activities within refuge waters','dd63492ca88f2acbdf3a37ab4cb11cb30475c106b239838afe26237c8e8bf728','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b741a7e45b76799a4f102a0f308122e59d90027ebaf4185f685c2246c196e74',2005,'NP','Nepal','economy',774,'total: 9
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 7 (2004 est.)
total: 37
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 29 (2004 est.)
deforestation (overuse of wood for fuel and lack of
alternatives); contaminated water (with human and animal wastes,
agricultural runoff, and industrial effluents); wildlife
conservation; vehicular emissions
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Life Conservation
1.5% (2004)
2.054 billion kWh (2002)
2.005 billion kWh (2002)
237 million kWh (2002)
142 million kWh (2002)
42% (1995-96)
lowest 10%: 3.2%
highest 10%: 29.8% (1995-96)
agriculture 81%, industry 3%, services 16%
carpets, clothing, leather goods, jute goods, grain
India 47.4%, US 22.7%, Germany 8.4% (2004)
14 zones (anchal, singular and plural); Bagmati, Bheri,
Dhawalagiri, Gandaki, Janakpur, Karnali, Kosi, Lumbini, Mahakali,
Mechi, Narayani, Rapti, Sagarmatha, Seti
rice, corn, wheat, sugarcane, root crops; milk, water buffalo
meat
46 (2004 est.)
31.45 births/1,000 population (2005 est.)
Royal Nepalese Army (includes Royal Nepalese Army Air
Service), Nepalese Police Force
revenues: $665 million
expenditures: $1.1 billion, including capital expenditures of NA
(FY99/00 est.)
Nepal is among the poorest and least developed countries in
the world with 40% of its population living below the poverty line.
Agriculture is the mainstay of the economy, providing a livelihood
for over 80% of the population and accounting for 40% of GDP.
Industrial activity mainly involves the processing of agricultural
produce including jute, sugarcane, tobacco, and grain. Security
concerns in the wake of the Maoist conflict have led to a decrease
in tourism, a key source of foreign exchange. Nepal has considerable
scope for exploiting its potential in hydropower and tourism, areas
of recent foreign investment interest. Prospects for foreign trade
or investment in other sectors will remain poor, however, because of
the small size of the economy, its technological backwardness, its
remoteness, its landlocked geographic location, its civil strife,
and its susceptibility to natural disaster.','f0d2fbb8cdae1213ebbb8845f87cc5d49f63e80ffa0419ee30cb2d9ea8c1c782','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45be53638291298f3edd955909590bbb897181a6864cbb0bfeb8fab7f81a62cb',2005,'NL','Netherlands','economy',775,'total: 20
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 2 (2004 est.)
Netherlands Antilles
total: 5
over 3,047 m: 1
2038 to 3047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
total: 7
914 to 1,523 m: 2
under 914 m: 5 (2004 est.)
water pollution in the form of heavy metals, organic
compounds, and nutrients such as nitrates and phosphates; air
pollution from vehicles and refining activities; acid rain
Netherlands Antilles
NA
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Kyoto Protocol, Law of
the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
1.6% (2004)
90.61 billion kWh (2002)
Netherlands Antilles
1.005 billion kWh (2002)
100.7 billion kWh (2002)
Netherlands Antilles
934.3 million kWh (2002)
20.9 billion kWh (2002)
Netherlands Antilles
0 kWh (2002)
4.5 billion kWh (2002)
Netherlands Antilles
0 kWh (2002)
NA
Netherlands Antilles
NA
lowest 10%: 2.8%
highest 10%: 25.1% (1994)
Netherlands Antilles
lowest 10%: NA
highest 10%: NA
agriculture 4%, industry 23%, services 73% (1998 est.)
Netherlands Antilles
agriculture 1%, industry 13%, services 86%
(2000 est.)
machinery and equipment, chemicals, fuels; foodstuffs
Netherlands Antilles
petroleum products
Germany 25%, Belgium 12.4%, UK 10.1%, France 9.9%, Italy
6%, US 4.3% (2004)
Netherlands Antilles
US 20.4%, Panama 11.2%, Guatemala 8.8%, Haiti
7.1%, Bahamas, The 5.6%, Honduras 4.2% (2004)
12 provinces (provincies, singular - provincie);
Drenthe, Flevoland, Friesland (Fryslan), Gelderland, Groningen,
Limburg, Noord-Brabant, Noord-Holland, Overijssel, Utrecht, Zeeland,
Zuid-Holland
Netherlands Antilles
none (part of the Kingdom of the Netherlands)
note: each island has its own government
grains, potatoes, sugar beets, fruits, vegetables;
livestock
Netherlands Antilles
aloes, sorghum, peanuts, vegetables, tropical
fruit
27 (2004 est.)
Netherlands Antilles
5 (2004 est.)
11.14 births/1,000 population (2005 est.)
Netherlands Antilles
15 births/1,000 population (2005 est.)
Royal Netherlands Army, Royal Netherlands Navy (includes
Naval Air Service and Marine Corps), Royal Netherlands Air Force
(Koninklijke Luchtmacht, KLu), Royal Constabulary, Defense
Interservice Command (DICO) (2004)
Netherlands Antilles
National Guard, Police Force
revenues: $256.9 billion
expenditures: $274.4 billion, including capital expenditures of NA
(2004 est.)
Netherlands Antilles
revenues: $710.8 million
expenditures: $741.6 million, including capital expenditures of NA
(1997 est.)
The Netherlands has a prosperous and open economy, which
depends heavily on foreign trade. The economy is noted for stable
industrial relations, moderate unemployment and inflation, a sizable
current account surplus, and an important role as a European
transportation hub. Industrial activity is predominantly in food
processing, chemicals, petroleum refining, and electrical machinery.
A highly mechanized agricultural sector employs no more than 4% of
the labor force but provides large surpluses for the food-processing
industry and for exports. The Netherlands, along with 11 of its EU
partners, began circulating the euro currency on 1 January 2002. The
country continues to be one of the leading European nations for
attracting foreign direct investment. Economic growth slowed
considerably in 2001-04, as part of the global economic slowdown,
but for the four years before that, annual growth averaged nearly
4%, well above the EU average.
Netherlands Antilles
Tourism, petroleum refining, and offshore
finance are the mainstays of this small economy, which is closely
tied to the outside world. Although GDP has declined or grown
slightly in each of the past eight years, the islands enjoy a high
per capita income and a well-developed infrastructure compared with
other countries in the region. Almost all consumer and capital goods
are imported, the US and Mexico being the major suppliers. Poor
soils and inadequate water supplies hamper the development of
agriculture. Budgetary problems hamper reform of the health and
pension systems of an aging population.','690e547df9bc47de4d340cbd8af49fe2b9d70c8e97b4721a7488515f803fc184','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57d99720a9a66db0da21d22bd95f70f5152fe238755c2927a8e083792f79dc60',2005,'NC','New Caledonia','economy',776,'total: 11
over 3,047 m: 1
914 to 1,523 m: 8
under 914 m: 2 (2004 est.)
total: 14
914 to 1,523 m: 8
under 914 m: 6 (2004 est.)
erosion caused by mining exploitation and forest fires
NA
1.581 billion kWh (2002)
1.471 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 7%, industry 23%, services 70% (1999 est.)
ferronickels, nickel ore, fish
Japan 22%, France 16.5%, Taiwan 12.3%, South Korea
12%, Spain 6.3%, Australia 6.1%, China 4.8%, South Africa 4.5% (2004)
none (overseas territory of France); there are no
first-order administrative divisions as defined by the US
Government, but there are 3 provinces named Iles Loyaute, Nord, and
Sud
vegetables; beef, deer, other livestock products
25 (2004 est.)
18.49 births/1,000 population (2005 est.)
no regular indigenous military forces; French Armed
Forces (includes Army, Navy, Air Force, Gendarmerie); Police Force
revenues: $861.3 million
expenditures: $735.3 million, including capital expenditures of $52
million (1996 est.)
New Caledonia has about 25% of the world''s known
nickel resources. Only a small amount of the land is suitable for
cultivation, and food accounts for about 20% of imports. In addition
to nickel, substantial financial support from France - equal to more
than one-fourth of GDP - and tourism are keys to the health of the
economy. Substantial new investment in the nickel industry, combined
with the recovery of global nickel prices, brightens the economic
outlook for the next several years.','1660cdbf2114ea4fa1efb7c9772e9b8448f878d56c56292be3ea20226098845d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fc96b9d136d082f175a22cb88271e6bd600861fedbb88084474ed50d82de44f',2005,'NZ','New Zealand','economy',777,'total: 46
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 11
914 to 1,523 m: 27
under 914 m: 5 (2004 est.)
total: 70
1,524 to 2,437 m: 2
914 to 1,523 m: 29
under 914 m: 39 (2004 est.)
deforestation; soil erosion; native flora and fauna
hard-hit by species introduced from outside
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Antarctic Seals, Marine Life Conservation
1% (FY02)
38.39 billion kWh (2002)
35.71 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: 0.3%
highest 10%: 29.8% (1991 est.)
agriculture 10%, industry 25%, services 65% (1995)
dairy products, meat, wood and wood products, fish,
machinery
Australia 21%, US 14.4%, Japan 11.3%, China 5.7%, UK
4.7% (2004)
16 regions and 1 territory*; Auckland, Bay of Plenty,
Canterbury, Chatham Islands*, Gisborne, Hawke''s Bay,
Manawatu-Wanganui, Marlborough, Nelson, Northland, Otago, Southland,
Taranaki, Tasman, Waikato, Wellington, West Coast
wheat, barley, potatoes, pulses, fruits, vegetables;
wool, beef, lamb and mutton, dairy products; fish
116 (2004 est.)
13.9 births/1,000 population (2005 est.)
New Zealand Army, Royal New Zealand Navy, Royal New
Zealand Air Force
revenues: $38.29 billion
expenditures: $36.12 billion, including capital expenditures of NA
(2004 est.)
Over the past 20 years the government has transformed
New Zealand from an agrarian economy dependent on concessionary
British market access to a more industrialized, free market economy
that can compete globally. This dynamic growth has boosted real
incomes (but left behind many at the bottom of the ladder),
broadened and deepened the technological capabilities of the
industrial sector, and contained inflationary pressures. Per capita
income has risen for six consecutive years and is now more than
$23,000 in purchasing power parity terms. New Zealand is heavily
dependent on trade - particularly in agricultural products - to
drive growth. Exports are equal to about 20% of GDP. Thus far the
economy has been resilient, and the Labor Government promises that
expenditures on health, education, and pensions will increase
proportionately to output.','681f48b32d9152cea60379f8a9c8937f65966d54f5927e0f2cb397772372dc22','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96724d41358baacd91fc2f34bd8b609d52f0ed30f4876fc041ad945ad57d4d2b',2005,'NI','Nicaragua','economy',778,'total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 3 (2004 est.)
total: 165
1,524 to 2,437 m: 1
914 to 1,523 m: 23
under 914 m: 141 (2004 est.)
deforestation; soil erosion; water pollution
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental Modification
0.7% (2004)
2.553 billion kWh (2002)
2.318 billion kWh (2002)
15.3 million kWh (2002)
6.8 million kWh (2002)
50% (2001 est.)
lowest 10%: 1.2%
highest 10%: 45% (2001)
agriculture 30.5%, industry 17.3%, services 52.2% (2003
est.)
coffee, beef, shrimp and lobster, tobacco, sugar, gold,
peanuts
US 64.8%, El Salvador 7%, Mexico 3.6% (2004)
15 departments (departamentos, singular - departamento)
and 2 autonomous regions* (regiones autonomistas, singular - region
autonomista); Atlantico Norte*, Atlantico Sur*, Boaco, Carazo,
Chinandega, Chontales, Esteli, Granada, Jinotega, Leon, Madriz,
Managua, Masaya, Matagalpa, Nueva Segovia, Rio San Juan, Rivas
coffee, bananas, sugarcane, cotton, rice, corn, tobacco,
sesame, soya, beans; beef, veal, pork, poultry, dairy products
176 (2004 est.)
24.88 births/1,000 population (2005 est.)
Army (includes Navy, Air Force)
revenues: $725.5 million
expenditures: $1.039 billion, including capital expenditures of NA
(2004 est.)
Nicaragua, one of the hemisphere''s poorest countries,
faces low per capita income, massive unemployment, and huge external
debt. Distribution of income is one of the most unequal on the
globe. While the country has made progress toward macroeconomic
stability over the past few years, GDP annual growth has been far
too low to meet the country''s needs. As a result of successful
performance under its International Monetary Fund policy program and
other efforts, Nicaragua qualified in early 2004 for some $4 billion
in foreign debt reduction under the Heavily Indebted Poor Countries
(HIPC) initiative. Even after this reduction, however, the
government continues to bear a significant foreign and domestic debt
burden. If ratified, the US-Central America Free Trade Agreement
(CAFTA) will provide an opportunity for Nicaragua to attract
investment, create jobs, and deepen economic development. While
President BOLANOS enjoys the support of the international financial
bodies, his internal political base is meager.','27d1462cfa557ae0b6e3f57ecabfbc8dcfab539c72505fc3291ad8e6961b809e','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c68166f9639fa0dda691f6a56a11ff9572ed9916a93e8727f9bf50553e9f2105',2005,'NE','Niger','economy',779,'total: 9
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
under 914 m: 1 (2004 est.)
total: 18
1,524 to 2,437 m: 2
914 to 1,523 m: 14
under 914 m: 2 (2004 est.)
overgrazing; soil erosion; deforestation; desertification;
wildlife populations (such as elephant, hippopotamus, giraffe, and
lion) threatened because of poaching and habitat destruction
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
1.1% (2004)
266.2 million kWh (2002)
327.6 million kWh (2002)
80 million kWh (2002)
0 kWh (2002)
63% (1993 est.)
lowest 10%: 0.8%
highest 10%: 35.4% (1995)
agriculture 90%, industry and commerce 6%, government 4%
uranium ore, livestock, cowpeas, onions
France 41%, Nigeria 22.4%, Japan 15.3%, Switzerland 6%, Spain
4.1%, Ghana 4% (2004)
8 regions (regions, singular - region) includes 1 capital
district* (commune urbaine); Agadez, Diffa, Dosso, Maradi, Niamey*,
Tahoua, Tillaberi, Zinder
cowpeas, cotton, peanuts, millet, sorghum, cassava (tapioca),
rice; cattle, sheep, goats, camels, donkeys, horses, poultry
27 (2004 est.)
48.3 births/1,000 population (2005 est.)
Niger Armed Forces (Forces Armees Nigeriennes, FAN): Army,
National Air Force (2005)
revenues: $320 million - including $134 million from foreign
sources
expenditures: $320 million, including capital expenditures of $178
million (2002 est.)
Niger is one of the poorest countries in the world, a
landlocked Sub-Saharan nation, whose economy centers on subsistence
crops, livestock, and some of the world''s largest uranium deposits.
Drought cycles, desertification, a 3.3% population growth rate, and
the drop in world demand for uranium have undercut the economy.
Niger shares a common currency, the CFA franc, and a common central
bank, the Central Bank of West African States (BCEAO), with seven
other members of the West African Monetary Union. In December 2000,
Niger qualified for enhanced debt relief under the International
Monetary Fund program for Highly Indebted Poor Countries (HIPC) and
concluded an agreement with the Fund on a Poverty Reduction and
Growth Facility (PRGF). Debt relief provided under the enhanced HIPC
initiative significantly reduces Niger''s annual debt service
obligations, freeing funds for expenditures on basic health care,
primary education, HIV/AIDS prevention, rural infrastructure, and
other programs geared at poverty reduction. Nearly half of the
government''s budget is derived from foreign donor resources. Future
growth may be sustained by exploitation of oil, gold, coal, and
other mineral resources.','6092c79e9200726e55f1f923601a0b91e3bdb122c3403a1811527ecf990ad613','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d520685f5ca8ad15451157e29433fca3fa0498960fc3323d89b312ab08bafb7',2005,'NG','Nigeria','economy',780,'total: 36
over 3,047 m: 7
2,438 to 3,047 m: 11
1,524 to 2,437 m: 9
914 to 1,523 m: 6
under 914 m: 3 (2004 est.)
total: 34
1,524 to 2,437 m: 3
914 to 1,523 m: 13
under 914 m: 18 (2004 est.)
soil degradation; rapid deforestation; urban air and water
pollution; desertification; oil pollution - water, air, and soil;
has suffered serious damage from oil spills; loss of arable land;
rapid urbanization
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
0.8% (2004)
19.85 billion kWh (2002)
18.43 billion kWh (2002)
0 kWh (2002)
30 million kWh (2002)
60% (2000 est.)
lowest 10%: 1.6%
highest 10%: 40.8% (1996-97)
agriculture 70%, industry 10%, services 20% (1999 est.)
petroleum and petroleum products 95%, cocoa, rubber
US 47.5%, Brazil 10.7%, Spain 7.1% (2004)
36 states and 1 territory*; Abia, Adamawa, Akwa Ibom,
Anambra, Bauchi, Bayelsa, Benue, Borno, Cross River, Delta, Ebonyi,
Edo, Ekiti, Enugu, Federal Capital Territory*, Gombe, Imo, Jigawa,
Kaduna, Kano, Katsina, Kebbi, Kogi, Kwara, Lagos, Nassarawa, Niger,
Ogun, Ondo, Osun, Oyo, Plateau, Rivers, Sokoto, Taraba, Yobe, Zamfara
cocoa, peanuts, palm oil, corn, rice, sorghum, millet,
cassava (tapioca), yams, rubber; cattle, sheep, goats, pigs; timber;
fish
70 (2004 est.)
40.65 births/1,000 population (2005 est.)
Army, Navy, Air Force
revenues: $11.78 billion
expenditures: $11.47 billion, including capital expenditures of NA
(2004 est.)
Oil-rich Nigeria, long hobbled by political instability,
corruption, inadequate infrastructure, and poor macroeconomic
management, is undertaking some reforms under the new civilian
administration. Nigeria''s former military rulers failed to diversify
the economy away from overdependence on the capital-intensive oil
sector, which provides 20% of GDP, 95% of foreign exchange earnings,
and about 65% of budgetary revenues. The largely subsistence
agricultural sector has failed to keep up with rapid population
growth - Nigeria is Africa''s most populous country - and the
country, once a large net exporter of food, now must import food.
Following the signing of an IMF stand-by agreement in August 2000,
Nigeria received a debt-restructuring deal from the Paris Club and a
$1 billion credit from the IMF, both contingent on economic reforms.
Nigeria pulled out of its IMF program in April 2002, after failing
to meet spending and exchange rate targets, making it ineligible for
additional debt forgiveness from the Paris Club. In the last year
the government has begun showing the political will to implement the
market-oriented reforms urged by the IMF, such as to modernize the
banking system, to curb inflation by blocking excessive wage
demands, and to resolve regional disputes over the distribution of
earnings from the oil industry. During 2003 the government began
deregulating fuel prices, announced the privatization of the
country''s four oil refineries, and instituted the National Economic
Empowerment Development Strategy, a domestically designed and run
program modeled on the IMF''s Poverty Reduction and Growth Facility
for fiscal and monetary management. GDP rose strongly in 2004.','56f76aa75cdf9abced0fc11fce8909cd9d6950f3e07d1d5dbe4dd3d09dde0df0','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8991405535cdfb24a43438957245fb810e0febd262a6d966aec36bd3baef2d4',2005,'NU','Niue','economy',781,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
increasing attention to conservationist practices to counter
loss of soil fertility from traditional slash and burn agriculture
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification
signed, but not ratified: Law of the Sea
3 million kWh (2002)
2.79 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
most work on family plantations; paid work exists only in
government service, small industry, and the Niue Development Board
canned coconut cream, copra, honey, vanilla, passion fruit
products, pawpaws, root crops, limes, footballs, stamps, handicrafts
New Zealand mainly, Fiji, Cook Islands, Australia (2000)
none; note - there are no first-order administrative divisions
as defined by the US Government, but there are 14 villages at the
second order
coconuts, passion fruit, honey, limes, taro, yams, cassava
(tapioca), sweet potatoes; pigs, poultry, beef cattle
1 (2004 est.)
NA births/1,000 population
no regular indigenous military forces; Police Force
revenues: NA
expenditures: NA
The economy suffers from the typical Pacific island problems of
geographic isolation, few resources, and a small population.
Government expenditures regularly exceed revenues, and the shortfall
is made up by critically needed grants from New Zealand that are
used to pay wages to public employees. Niue has cut government
expenditures by reducing the public service by almost half. The
agricultural sector consists mainly of subsistence gardening,
although some cash crops are grown for export. Industry consists
primarily of small factories to process passion fruit, lime oil,
honey, and coconut cream. The sale of postage stamps to foreign
collectors is an important source of revenue. The island in recent
years has suffered a serious loss of population because of migration
of Niueans to New Zealand. Efforts to increase GDP include the
promotion of tourism and a financial services industry, although
former Premier LAKATANI announced in February 2002 that Niue will
shut down the offshore banking industry. Economic aid from New
Zealand in 2002 was about $2.6 million. Niue suffered a devastating
hurricane in January 2004, which decimated nascent economic
programs. While in the process of rebuilding, Niue has been
dependent on foreign aid.','872456d21acf4427ab2c0661f402630f3e3828ba41e174a74612c79846248b15','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52389d38af7da25ac5f1907a54b8cb9e3ed6b2e7e7a5cf4f33c9b8763e345d8a',2005,'NF','Norfolk Island','economy',782,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
NA
NA kWh
NA kWh
NA
lowest 10%: NA
highest 10%: NA
tourism 90%, subsistence agriculture 10%
postage stamps, seeds of the Norfolk Island pine and
Kentia palm, small quantities of avocados
Australia, other Pacific island countries, NZ, Asia,
Europe
none (territory of Australia)
Norfolk Island pine seed, Kentia palm seed, cereals,
vegetables, fruit; cattle, poultry
1 (2004 est.)
NA
revenues: $20 million
expenditures: $20 million, including capital expenditures of $2
million (FY99/00)
Tourism, the primary economic activity, has steadily
increased over the years and has brought a level of prosperity
unusual among inhabitants of the Pacific islands. The agricultural
sector has become self-sufficient in the production of beef,
poultry, and eggs.','d99bd16dfcbe0e7ceaee87219a4eda6b676647e5ec0f88fb72e55b88ee943fca','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee82d3afcfaf65b46c52559dbf658390ab8d4b56979dd4bbed87c5269577c230',2005,'MP','Northern Mariana Islands','economy',783,'total: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2004 est.)
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2004 est.)
contamination of groundwater on Saipan may
contribute to disease; clean-up of landfill; protection of
endangered species conflicts with development
NA kWh
NA kWh
0 kWh
0 kWh
NA
lowest 10%: NA
highest 10%: NA
NA
garments
US (2000)
none (commonwealth in political union with
the US); there are no first-order administrative divisions as
defined by the US Government, but there are four municipalities at
the second order: Northern Islands, Rota, Saipan, Tinian
coconuts, fruits, vegetables; cattle
5 (2004 est.)
19.51 births/1,000 population (2005 est.)
revenues: $193 million
expenditures: $223 million, including capital expenditures of NA
(FY01/02 est.)
The economy benefits substantially from
financial assistance from the US. The rate of funding has declined
as locally generated government revenues have grown. The key tourist
industry employs about 50% of the work force and accounts for
roughly one-fourth of GDP. Japanese tourists predominate. Annual
tourist entries have exceeded one-half million in recent years, but
financial difficulties in Japan have caused a temporary slowdown.
The agricultural sector is made up of cattle ranches and small farms
producing coconuts, breadfruit, tomatoes, and melons. Garment
production is by far the most important industry with employment of
17,500 mostly Chinese workers and sizable shipments to the US under
duty and quota exemptions.','8924f6999fa37d2782a641382d9a249743647136c2d7ea124ab18e9aa284e976','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5a96345aa5be97426dc63fbf69940519a99b486a09ec7d66ef5afdec61bee46',2005,'NO','Norway','economy',784,'total: 65
2,438 to 3,047 m: 13
1,524 to 2,437 m: 12
914 to 1,523 m: 14
under 914 m: 26 (2004 est.)
total: 36
914 to 1,523 m: 7
under 914 m: 29 (2004 est.)
water pollution; acid rain damaging forests and adversely
affecting lakes, threatening fish stocks; air pollution from vehicle
emissions
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1.9% (2003)
125.9 billion kWh (2002)
107.4 billion kWh (2002)
5.3 billion kWh (2002)
15 billion kWh (2002)
NA
lowest 10%: 4.1%
highest 10%: 21.8% (1995)
agriculture, forestry, and fishing 4%, industry 22%, services
74% (1995)
petroleum and petroleum products, machinery and equipment,
metals, chemicals, ships, fish
UK 22.4%, Germany 12.9%, Netherlands 9.9%, France 9.6%, US
8.4%, Sweden 6.7% (2004)
19 counties (fylker, singular - fylke); Akershus, Aust-Agder,
Buskerud, Finnmark, Hedmark, Hordaland, More og Romsdal, Nordland,
Nord-Trondelag, Oppland, Oslo, Ostfold, Rogaland, Sogn og Fjordane,
Sor-Trondelag, Telemark, Troms, Vest-Agder, Vestfold
barley, wheat, potatoes; pork, beef, veal, milk; fish
101 (2004 est.)
11.67 births/1,000 population (2005 est.)
Norwegian Army, Royal Norwegian Navy (includes Coastal
Rangers and Coast Guard (Kystvakt)), Royal Norwegian Air Force
(Kongelige Norske Luftforsvaret, RNoAF), Home Guard
revenues: $134 billion
expenditures: $116.8 billion, including capital expenditures of NA
(2004 est.)
The Norwegian economy is a prosperous bastion of welfare
capitalism, featuring a combination of free market activity and
government intervention. The government controls key areas, such as
the vital petroleum sector (through large-scale state enterprises).
The country is richly endowed with natural resources - petroleum,
hydropower, fish, forests, and minerals - and is highly dependent on
its oil production and international oil prices, with oil and gas
accounting for one-third of exports. Only Saudi Arabia and Russia
export more oil than Norway. Norway opted to stay out of the EU
during a referendum in November 1994; nonetheless, it contributes
sizably to the EU budget. The government has moved ahead with
privatization. With arguably the highest quality of life worldwide,
Norwegians still worry about that time in the next two decades when
the oil and gas will begin to run out. Accordingly, Norway has been
saving its oil-boosted budget surpluses in a Government Petroleum
Fund, which is invested abroad and now is valued at more than $150
billion. After lackluster growth of 1% in 2002 and 0.5% in 2003, GDP
growth picked up to 3.3% in 2004.','ac246e8333d1bc4325673de641a870e51dd904a4b9ddc8c12a93d9ca56c27d50','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a94dde269f5ace5a3e41db4b4ca9626caa6c74b850044dfc763de206b82b1975',2005,'OM','Oman','economy',785,'total: 6
over 3,047 m: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 130
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 52
914 to 1,523 m: 34
under 914 m: 35 (2004 est.)
rising soil salinity; beach pollution from oil spills; very
limited natural fresh water resources
Pacific Ocean
endangered marine species include the dugong, sea
lion, sea otter, seals, turtles, and whales; oil pollution in
Philippine Sea and South China Sea
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
11.4% (2003)
9.896 billion kWh (2003)
9.792 billion kWh (2003)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture NA, industry NA, services NA
petroleum, reexports, fish, metals, textiles
China 29.5%, South Korea 17.5%, Japan 11.5%, Thailand 10.6%,
UAE 7.2% (2004)
5 regions (manaatiq, singular - mintaqat) and 3 governorates*
(muhaafazaat, singular - muhaafaza) Ad Dakhiliyah, Al Batinah, Al
Wusta, Ash Sharqiyah, Az Zahirah, Masqat*, Musandam*, Zufar*
dates, limes, bananas, alfalfa, vegetables; camels, cattle; fish
136 (2004 est.)
36.73 births/1,000 population (2005 est.)
Royal Omani Armed Forces: Royal Army of Oman, Royal Navy of
Oman, Royal Air Force of Oman (2005)
revenues: $9.291 billion
expenditures: $8.747 billion, including capital expenditures of NA
(2004 est.)
Oman is a middle-income economy in the Middle East with notable
oil and gas resources, a substantial trade surplus, and low
inflation. The government is privatizing its utilities and
diversifying its economy to attract foreign investment. Oman
continues to liberalize its markets and joined the World Trade
Organization (WTO) in November 2000. To reduce unemployment and
limit dependence on foreign countries, the government is encouraging
the replacement of expatriate workers with local people, i.e.,
Omanization. Training in information technology, business
management, and English support this objective. Industrial
development plans focus on gas resources, metal manufacturing,
petrochemicals, and international transshipment ports.
Pacific Ocean
The Pacific Ocean is a major contributor to the world
economy and particularly to those nations its waters directly touch.
It provides low-cost sea transportation between East and West,
extensive fishing grounds, offshore oil and gas fields, minerals,
and sand and gravel for the construction industry. In 1996, over 60%
of the world''s fish catch came from the Pacific Ocean. Exploitation
of offshore oil and gas reserves is playing an ever-increasing role
in the energy supplies of the US, Australia, NZ, China, and Peru.
The high cost of recovering offshore oil and gas, combined with the
wide swings in world prices for oil since 1985, has led to
fluctuations in new drillings.','78c7089efe0f6a783f3a18982f0eaa4624b0c3bfb265d6f4f05a1aa76c7a6a66','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4f61ba766b7d340871b4c34a940dd49edde68862f4f20e6feaf60a1eb0bf410',2005,'PK','Pakistan','economy',786,'total: 92
over 3,047 m: 14
2,438 to 3,047 m: 22
1,524 to 2,437 m: 32
914 to 1,523 m: 18
under 914 m: 6 (2004 est.)
total: 39
over 3,047 m: 1
1,524 to 2,437 m: 8
914 to 1,523 m: 9
under 914 m: 21 (2004 est.)
water pollution from raw sewage, industrial wastes, and
agricultural runoff; limited natural fresh water resources; a
majority of the population does not have access to potable water;
deforestation; soil erosion; desertification
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
4.9% (2004)
75.27 billion kWh (2003)
52.66 billion kWh (2003)
0 kWh (2003)
0 kWh (2003)
32% (FY00/01 est.)
lowest 10%: 4.1%
highest 10%: 27.6% (FY96/97)
agriculture 42%, industry 20%, services 38% (2004 est.)
textiles (garments, bed linen, cotton cloth, and yarn),
rice, leather goods, sports goods, chemicals, manufactures, carpets
and rugs
US 23.5%, UAE 7.4%, UK 7.3%, Germany 5%, Hong Kong 4.4%
(2004)
4 provinces, 1 territory*, and 1 capital territory**;
Balochistan, Federally Administered Tribal Areas*, Islamabad Capital
Territory**, North-West Frontier Province, Punjab, Sindh
note: the Pakistani-administered portion of the disputed Jammu and
Kashmir region includes Azad Kashmir and the Northern Areas
cotton, wheat, rice, sugarcane, fruits, vegetables; milk,
beef, mutton, eggs
131 (2004 est.)
30.42 births/1,000 population (2005 est.)
Army, Navy, Air Force
revenues: $13.45 billion
expenditures: $16.51 billion, including capital expenditures of NA
(2004 est.)
Pakistan, an impoverished and underdeveloped country, has
suffered from decades of internal political disputes, low levels of
foreign investment, and a costly, ongoing confrontation with
neighboring India. However, IMF-approved government policies,
bolstered by generous foreign assistance and renewed access to
global markets since 2001, have generated solid macroeconomic
recovery the last three years. The government has made substantial
macroeconomic reforms since 2000, although progress on more
politically sensitive reforms has slowed. For example, in the third
and final year of its $1.3 billion IMF Poverty Reduction and Growth
Facility, Islamabad has continued to require waivers for energy
sector reforms. While long-term prospects remain uncertain, given
Pakistan''s low level of development, medium-term prospects for job
creation and poverty reduction are the best in nearly a decade.
Islamabad has raised development spending from about 2% of GDP in
the 1990s to 4% in 2003, a necessary step towards reversing the
broad underdevelopment of its social sector. GDP growth, spurred by
double-digit gains in industrial production over the past year, has
become less dependent on agriculture. Foreign exchange reserves
continued to reach new levels in 2004, supported by robust export
growth and steady worker remittances.','04e48bd4b6c57a2bc3480704aa115aa6fce2453d6e70482862d9ba88a2d4c1c7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('963385cbd7a53820f5e8ded5a3f2fd2b5f6f5c8930dcb02adf87c156cdeaabf4',2005,'PW','Palau','economy',787,'total: 1
1,524 to 2,437 m: 1 (2004 est.)
total: 2
1,524 to 2,437 m: 2 (2004 est.)
Palmyra Atoll
total: 1
1,524 to 2,437 m: 1 (2004 est.)
inadequate facilities for disposal of solid waste; threats to
the marine ecosystem from sand and coral dredging, illegal fishing
practices, and overfishing
Palmyra Atoll
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
NA
NA
lowest 10%: NA
highest 10%: NA
agriculture 20%, industry NA, services NA (1990)
shellfish, tuna, copra, garments
US, Japan, Singapore (2000)
16 states; Aimeliik, Airai, Angaur, Hatohobei, Kayangel,
Koror, Melekeok, Ngaraard, Ngarchelong, Ngardmau, Ngatpang,
Ngchesar, Ngeremlengui, Ngiwal, Peleliu, Sonsorol
coconuts, copra, cassava (tapioca), sweet potatoes
3 (2004 est.)
Palmyra Atoll
1 (2004 est.)
18.37 births/1,000 population (2005 est.)
no regular military forces; Police Force
revenues: $57.7 million
expenditures: $80.8 million, including capital expenditures of $17.1
million (FY98/99 est.)
The economy consists primarily of tourism, subsistence
agriculture, and fishing. The government is the major employer of
the work force, relying heavily on financial assistance from the US.
Business and tourist arrivals numbered 63,000 in 2003. The
population enjoys a per capita income twice that of the Philippines
and much of Micronesia. Long-run prospects for the key tourist
sector have been greatly bolstered by the expansion of air travel in
the Pacific, the rising prosperity of leading East Asian countries,
and the willingness of foreigners to finance infrastructure
development.
Palmyra Atoll
no economic activity','1478e6f51735a817c9727456271338ebacf4205b76f1bb275ddb217b91c8ab3b','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a79b9be24d27a7a9bbba30a92d9bd95e0943be6b8fe04191689b383a56541db8',2005,'PA','Panama','economy',788,'total: 44
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 15
under 914 m: 22 (2004 est.)
total: 61
914 to 1,523 m: 12
under 914 m: 49 (2004 est.)
water pollution from agricultural runoff threatens fishery
resources; deforestation of tropical rain forest; land degradation
and soil erosion threatens siltation of Panama Canal; air pollution
in urban areas; mining threatens natural resources
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
1.1% (2004)
4.873 billion kWh (2002)
4.473 billion kWh (2002)
61 million kWh (2002)
120 million kWh (2002)
37% (1999 est.)
lowest 10%: 1.2%
highest 10%: 35.7% (1997)
agriculture 20.8%, industry 18%, services 61.2% (1995 est.)
bananas, shrimp, sugar, coffee, clothing (1999)
US 50.5%, Sweden 6.6%, Spain 5.1%, Netherlands 4.4%, Costa
Rica 4.2% (2004)
9 provinces (provincias, singular - provincia) and 1
territory* (comarca); Bocas del Toro, Chiriqui, Cocle, Colon,
Darien, Herrera, Los Santos, Panama, San Blas*(Kuna Yala), and
Veraguas
bananas, rice, corn, coffee, sugarcane, vegetables;
livestock; shrimp
105 (2004 est.)
19.96 births/1,000 population (2005 est.)
an amendment to the Constitution abolished the armed forces,
but there are security forces (Panamanian Public Forces or PPF
includes the Panamanian National Police, National Maritime Service,
and National Air Service)
revenues: $3.095 billion
expenditures: $3.737 billion, including capital expenditures of $471
million (2004 est.)
Panama''s dollarised economy rests primarily on a
well-developed services sector that accounts for four-fifths of GDP.
Services include operating the Panama Canal, banking, the Colon Free
Zone, insurance, container ports, flagship registry, and tourism. A
slump in Colon Free Zone and agricultural exports, the global
slowdown, and the withdrawal of US military forces held back
economic growth in 2000-03; growth picked up in 2004 led by
export-oriented services and a construction boom stimulated by tax
incentives. The government has been backing tax reforms, reform of
the social security program, new regional trade agreements, and
development of tourism. Unemployment remains high.','5711db2a5bc7af19b0226c812ffcb492775833fd736ff38e846055c499035b59','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99df7cb1053d0b07b2e3c1e9b4fa7571bd84acf2ffdcb780d1951a62fa27b189',2005,'PG','Papua New Guinea','economy',789,'total: 21
2,438 to 3,047 m: 2
1,524 to 2,437 m: 14
914 to 1,523 m: 4
under 914 m: 1 (2004 est.)
Paracel Islands
total: 1
1,524 to 2,437 m: 1 (2004 est.)
total: 550
1,524 to 2,437 m: 10
914 to 1,523 m: 62
under 914 m: 478 (2004 est.)
rain forest subject to deforestation as a result of
growing commercial demand for tropical timber; pollution from mining
projects; severe drought
Paracel Islands
NA
party to: Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
1.4% (FY02)
1.679 billion kWh (2002)
1.561 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
37% (2002 est.)
lowest 10%: 1.7%
highest 10%: 40.5% (1996)
agriculture 85%, industry NA, services NA
oil, gold, copper ore, logs, palm oil, coffee,
cocoa, crayfish, prawns
Australia 28%, Japan 5.8%, Germany 4.7%, China 4.6%
(2004)
20 provinces; Bougainville, Central, Chimbu,
Eastern Highlands, East New Britain, East Sepik, Enga, Gulf, Madang,
Manus, Milne Bay, Morobe, National Capital, New Ireland, Northern,
Sandaun, Southern Highlands, Western, Western Highlands, West New
Britain
coffee, cocoa, coconuts, palm kernels, tea, rubber,
sweet potatoes, fruit, vegetables, poultry, pork
571 (2004 est.)
Paracel Islands
1 (2004 est.)
29.95 births/1,000 population (2005 est.)
Papua New Guinea Defense Force (includes Maritime
Operations Element, Air Operations Element)
revenues: $1.174 billion
expenditures: $1.232 billion, including capital expenditures of $344
million (2004 est.)
Papua New Guinea is richly endowed with natural
resources, but exploitation has been hampered by rugged terrain and
the high cost of developing infrastructure. Agriculture provides a
subsistence livelihood for 85% of the population. Mineral deposits,
including oil, copper, and gold, account for 72% of export earnings.
The economy has improved over the past two years, following a
prolonged period of instability. Former Prime Minister Mekere
MORAUTA had tried to restore integrity to state institutions, to
stabilize the kina, restore stability to the national budget, to
privatize public enterprises where appropriate, and to ensure
ongoing peace on Bougainville. Australia annually supplies $240
million in aid, which accounts for 20% of the national budget.
Challenges face Prime Minister Michael SOMARE, including gaining
further investor confidence, continuing efforts to privatize
government assets, maintaining the support of members of Parliament,
and balancing relations with Australia, the former colonial ruler.
Paracel Islands
China announced plans in 1997 to open the islands
for tourism.','2036c9d16bf559fed4ec4a7d7ccab0dd28360b2183718b1a4f81df28f39936c9','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a8261aa6e51cc13a953d4809c64dc67a6f7f80b02c81ba6577053eaf10d86a9',2005,'PY','Paraguay','economy',790,'total: 12
over 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 4 (2004 est.)
total: 866
1,524 to 2,437 m: 26
914 to 1,523 m: 323
under 914 m: 517 (2004 est.)
deforestation; water pollution; inadequate means for waste
disposal pose health risks for many urban residents; loss of wetlands
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
0.9% (2003)
48.36 billion kWh (2002)
2.469 billion kWh (2002)
0 kWh (2002)
42.51 billion kWh (2002)
36% (2001 est.)
lowest 10%: 0.5%
highest 10%: 43.8% (1998)
agriculture 45%
soybeans, feed, cotton, meat, edible oils, electricity,
wood, leather
Uruguay 27.8%, Brazil 19.2%, Argentina 6.3%, Switzerland
4.1% (2004)
17 departments (departamentos, singular - departamento) and
1 capital city*; Alto Paraguay, Alto Parana, Amambay, Asuncion*,
Boqueron, Caaguazu, Caazapa, Canindeyu, Central, Concepcion,
Cordillera, Guaira, Itapua, Misiones, Neembucu, Paraguari,
Presidente Hayes, San Pedro
cotton, sugarcane, soybeans, corn, wheat, tobacco, cassava
(tapioca), fruits, vegetables; beef, pork, eggs, milk; timber
878 (2004 est.)
29.43 births/1,000 population (2005 est.)
Army, Navy (includes Naval Aviation, River Defense Corps,
Coast Guard), Air Force
revenues: $1.123 billion
expenditures: $1.129 billion, including capital expenditures of $700
million (2004 est.)
Landlocked Paraguay has a market economy marked by a large
informal sector. This sector features both reexport of imported
consumer goods to neighboring countries as well as the activities of
thousands of microenterprises and urban street vendors. Because of
the importance of the informal sector, accurate economic measures
are difficult to obtain. A large percentage of the population
derives their living from agricultural activity, often on a
subsistence basis. The formal economy grew by an average of about 3%
annually in 1995-97, but averaged near-zero growth in 1998-2001 and
contracted by 2.3 percent in 2002, in response to regional contagion
and an outbreak of hoof-and-mouth desease. On a per capita basis,
real income has stagnated at 1980 levels. Most observers attribute
Paraguay''s poor economic performance to political uncertainty,
corruption, lack of progress on structural reform, substantial
internal and external debt, and deficient infrastructure. Aided by a
firmer exchange rate and perhaps a greater confidence in the
economic policy of the Duarte FRUTOS administration, the economy
rebounded in 2003 and 2004, posting modest growth each year.','41ae2bc3488544ed6236b55a1ada227644696c82467a0830e6b7b45e1c4919ac','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('170993d7fcc2c965bccaba2e12ae75b61869ea98d35c8b5890b24cea9499acd8',2005,'PE','Peru','economy',791,'total: 52
over 3,047 m: 5
2,438 to 3,047 m: 20
1,524 to 2,437 m: 16
914 to 1,523 m: 9
under 914 m: 2 (2004 est.)
total: 182
1,524 to 2,437 m: 21
914 to 1,523 m: 62
under 914 m: 99 (2004 est.)
deforestation (some the result of illegal logging); overgrazing
of the slopes of the costa and sierra leading to soil erosion;
desertification; air pollution in Lima; pollution of rivers and
coastal waters from municipal and mining wastes
party to: Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
1.4% (2004)
22.88 billion kWh (2004 est.)
20.22 billion kWh (2002)
0 kWh (2003)
0 kWh (2003)
54% (2003 est.)
lowest 10%: 0.8%
highest 10%: 37.2% (2000)
agriculture 9%, industry 18%, services 73% (2001)
copper, gold, zinc, crude petroleum and petroleum products,
coffee
US 29.5%, China 9.9%, UK 9%, Chile 5.1%, Japan 4.4% (2004)
25 regions (regiones, singular - region) and 1 province*
(provincia); Amazonas, Ancash, Apurimac, Arequipa, Ayacucho,
Cajamarca, Callao, Cusco, Huancavelica, Huanuco, Ica, Junin, La
Libertad, Lambayeque, Lima, Lima*, Loreto, Madre de Dios, Moquegua,
Pasco, Piura, Puno, San Martin, Tacna, Tumbes, Ucayali
coffee, cotton, sugarcane, rice, potatoes, corn, plantains,
grapes, oranges, coca; poultry, beef, dairy products; fish
234 (2004 est.)
20.87 births/1,000 population (2005 est.)
Army (Ejercito Peruano), Navy (Marina de Guerra del Peru;
includes Naval Air, Naval Infantry, and Coast Guard), Air Force
(Fuerza Aerea del Peru; FAP)
revenues: $13.6 billion
expenditures: $14.6 billion, including capital expenditures of $1.8
billion, for general government, excluding private enterprises (2004
est.)
Peru''s economy reflects its varied geography - an arid coastal
region, the Andes further inland, and tropical lands bordering
Colombia and Brazil. Abundant mineral resources are found in the
mountainous areas, and Peru''s coastal waters provide excellent
fishing grounds. However, overdependence on minerals and metals
subjects the economy to fluctuations in world prices, and a lack of
infrastructure deters trade and investment. After several years of
inconsistent economic performance, the Peruvian economy grew by an
average 4 percent per year during the period 2002-2004, with a
stable exchange rate and low inflation. Risk premiums on Peruvian
bonds on secondary markets reached historically low levels in late
2004, reflecting investor optimism regarding the government''s
prudent fiscal policies and openness to trade and investment.
Despite the strong macroeconomic performance, the TOLEDO
administration remained unpopular in 2004, and unemployment and
poverty have stayed persistently high.','ae78b082cc17b2cf59de014b52aafe7c9ab6798bba5de61ee86019e62b66a2b5','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0abeac3ffab6a810f75ec1dc48a03bfad2f38781bdc6bf1da97bd84490590ac',2005,'PH','Philippines','economy',792,'total: 82
over 3,047 m: 4
2,438 to 3,047 m: 6
1,524 to 2,437 m: 26
914 to 1,523 m: 35
under 914 m: 11 (2004 est.)
total: 173
1,524 to 2,437 m: 5
914 to 1,523 m: 68
under 914 m: 100 (2004 est.)
uncontrolled deforestation especially in watershed
areas; soil erosion; air and water pollution in major urban centers;
coral reef degradation; increasing pollution of coastal mangrove
swamps that are important fish breeding grounds
Pitcairn Islands
deforestation (only a small portion of the original
forest remains because of burning and clearing for settlement)
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
1% (2004)
52.86 billion kWh (2003)
Pitcairn Islands
NA kWh; note - electric power is provided by a
small diesel-powered generator
46.05 billion kWh (2003)
Pitcairn Islands
NA kWh
0 kWh (2003)
0 kWh (2003)
40% (2001 est.)
Pitcairn Islands
NA
lowest 10%: 2.3%
highest 10%: 31.9% (2003)
Pitcairn Islands
lowest 10%: NA
highest 10%: NA
agriculture 36%, industry 16%, services 48% (2004 est.)
Pitcairn Islands
no business community in the usual sense; some
public works; subsistence farming and fishing
electronic equipment, machinery and transport equipment,
garments, optical instruments, coconut products, fruits and nuts,
copper products, chemicals
Pitcairn Islands
fruits, vegetables, curios, stamps
Japan 20.1%, US 18.2%, Netherlands 9%, Hong Kong 7.9%,
China 6.7%, Singapore 6.6%, Taiwan 5.6%, Malaysia 5.2% (2004)
Pitcairn Islands
NA
79 provinces and 116 chartered cities
provinces: Abra, Agusan del Norte, Agusan del Sur, Aklan, Albay,
Antique, Apayao, Aurora, Basilan, Bataan, Batanes, Batangas,
Biliran, Benguet, Bohol, Bukidnon, Bulacan, Cagayan, Camarines
Norte, Camarines Sur, Camiguin, Capiz, Catanduanes, Cavite, Cebu,
Compostela, Davao del Norte, Davao del Sur, Davao Oriental, Eastern
Samar, Guimaras, Ifugao, Ilocos Norte, Ilocos Sur, Iloilo, Isabela,
Kalinga, Laguna, Lanao del Norte, Lanao del Sur, La Union, Leyte,
Maguindanao, Marinduque, Masbate, Mindoro Occidental, Mindoro
Oriental, Misamis Occidental, Misamis Oriental, Mountain Province,
Negros Occidental, Negros Oriental, North Cotabato, Northern Samar,
Nueva Ecija, Nueva Vizcaya, Palawan, Pampanga, Pangasinan, Quezon,
Quirino, Rizal, Romblon, Samar, Sarangani, Siquijor, Sorsogon, South
Cotabato, Southern Leyte, Sultan Kudarat, Sulu, Surigao del Norte,
Surigao del Sur, Tarlac, Tawi-Tawi, Zambales, Zamboanga del Norte,
Zamboanga del Sur, Zamboanga Sibugay
chartered cities: Alaminos, Angeles, Antipolo, Bacolod, Bago,
Baguio, Bais, Balanga, Batangas, Bayawan, Bislig, Butuan,
Cabanatuan, Cadiz, Cagayan de Oro, Calamba, Calapan, Calbayog,
Candon, Canlaon, Cauayan, Cavite, Cebu, Cotabato, Dagupan, Danao,
Dapitan, Davao, Digos, Dipolog, Dumaguete, Escalante, Gapan, General
Santos, Gingoog, Himamaylan, Iligan, Iloilo, Isabela, Iriga,
Kabankalan, Kalookan, Kidapawan, Koronadal, La Carlota, Laoag,
Lapu-Lapu, Las Pinas, Legazpi, Ligao, Lipa, Lucena, Maasin, Makati,
Malabon, Malaybalay, Malolos, Mandaluyong, Mandaue, Manila, Marawi,
Markina, Masbate, Muntinlupa, Munoz, Naga, Olongapo, Ormoc,
Oroquieta, Ozamis, Pagadian, Palayan, Panabo, Paranaque, Pasay,
Pasig, Passi, Puerto Princesa, Quezon, Roxas, Sagay, Samal, San
Carlos (in Negros Occidental), San Carlos (in Pangasinan), San
Fernando (in La Union), San Fernando (in Pampanga), San Jose, San
Jose del Monte, San Pablo, Santa Rosa, Santiago, Silay, Sipalay,
Sorsogon, Surigao, Tabaco, Tacloban, Tacurong, Tagaytay, Tagbilaran,
Tagum, Talisay (in Cebu), Talisay (in Negros Oriental), Tanauan,
Tangub, Tanjay, Tarlac, Toledo, Tuguegarao, Trece Martires,
Urdaneta, Valencia, Valenzuela, Victorias, Vigan, Zamboanga
Pitcairn Islands
none (overseas territory of the UK)
sugarcane, coconuts, rice, corn, bananas, casavas,
pineapples, fish, mangoes, pork, eggs, beef
Pitcairn Islands
wide variety of fruits and vegetables, goats,
chickens
255 (2004 est.)
Pitcairn Islands
none (2004 est.)
25.31 births/1,000 population (2005 est.)
Pitcairn Islands
NA
Armed Forces of the Philippines (AFP): Army, Navy
(includes Coast Guard, Marine Corps), Air Force
revenues: $12.22 billion
expenditures: $15.84 billion, including capital expenditures of $2.4
million (2004 est.)
Pitcairn Islands
revenues: $746,000
expenditures: $1.028 million, including capital expenditures of NA
(FY04/05)
The Philippines was less severely affected by the Asian
financial crisis of 1998 than its neighbors, aided in part by annual
remittances of $7-8 billion from overseas workers and no sustained
runup in asset prices or foreign borrowing prior to the crisis. From
a 0.6% decline in 1998, GDP expanded by 2.4% in 1999, and 4.4% in
2000, but slowed to 3.2% in 2001 in the context of a global economic
slowdown, an export slump, and political and security concerns. GDP
growth accelerated to 4.3% in 2002, 4.7% in 2003, and about 6% in
2004, reflecting the continued resilience of the service sector, and
improved exports and agricultural output. Nonetheless, it will take
a higher, sustained growth path to make appreciable progress in
poverty alleviation given the Philippines'' high annual population
growth rate and unequal distribution of income. The Philippines also
faces higher oil prices, higher interest rates on its dollar
borrowings, and higher inflation. Fiscal constraints limit Manila''s
ability to finance infrastructure and social spending. The
Philippines'' consistently large budget deficit has produced a high
debt level and has forced Manila to spend a large portion of the
national government budget on debt service. Large, unprofitable
public enterprises, especially in the energy sector, contribute to
the government''s debt because of slow progress on privatization.
Credit rating agencies are increasingly concerned about the
Philippines'' ability to sustain the debt; legislative progress on
new revenue measures will weigh heavily on credit rating decisions.
Pitcairn Islands
The inhabitants of this tiny isolated economy exist
on fishing, subsistence farming, handicrafts, and postage stamps.
The fertile soil of the valleys produces a wide variety of fruits
and vegetables, including citrus, sugarcane, watermelons, bananas,
yams, and beans. Bartering is an important part of the economy. The
major sources of revenue are the sale of postage stamps to
collectors and the sale of handicrafts to passing ships. In October
2004, more than one-quarter of Pitcairn''s labor force was arrested,
putting the economy in a bind, since their services were required as
lighter crew to load or unload passing ships.','caea84c98d76a21e16fda6695eb501c08e215d30d76a712f3877f1e34682af01','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef7ea731e0dc27e71f65b3889533e7a396a71c7c85c39648377260635b8fb129',2005,'PL','Poland','economy',793,'total: 84
over 3,047 m: 3
2,438 to 3,047 m: 30
1,524 to 2,437 m: 40
914 to 1,523 m: 8
under 914 m: 3 (2004 est.)
total: 39
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 13
under 914 m: 21 (2004 est.)
situation has improved since 1989 due to decline in heavy
industry and increased environmental concern by post-Communist
governments; air pollution nonetheless remains serious because of
sulfur dioxide emissions from coal-fired power plants, and the
resulting acid rain has caused forest damage; water pollution from
industrial and municipal sources is also a problem, as is disposal
of hazardous wastes; pollution levels should continue to decrease as
industrial establishments bring their facilities up to European
Union code, but at substantial cost to business and the government
party to: Air Pollution, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Kyoto Protocol, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 94
1.71% (2002)
133.8 billion kWh (2002)
117.4 billion kWh (2002)
4.5 billion kWh (2002)
11.5 billion kWh (2002)
18.4% (2000 est.)
lowest 10%: 3.2%
highest 10%: 24.7% (1998)
agriculture 16.1%, industry 29%, services 54.9% (2002)
machinery and transport equipment 37.8%, intermediate
manufactured goods 23.7%, miscellaneous manufactured goods 17.1%,
food and live animals 7.6% (2003)
Germany 30%, Italy 6.1%, France 6%, UK 5.4%, Czech Republic
4.3%, Netherlands 4.3% (2004)
16 provinces (wojewodztwa, singular - wojewodztwo);
Dolnoslaskie, Kujawsko-Pomorskie, Lodzkie, Lubelskie, Lubuskie,
Malopolskie, Mazowieckie, Opolskie, Podkarpackie, Podlaskie,
Pomorskie, Slaskie, Swietokrzyskie, Warminsko-Mazurskie,
Wielkopolskie, Zachodniopomorskie
potatoes, fruits, vegetables, wheat; poultry, eggs, pork
123 (2004 est.)
10.78 births/1,000 population (2005 est.)
Land Forces, Navy, Polish Air Force (PSP)
revenues: $44.52 billion
expenditures: $54.93 billion, including capital expenditures of NA
(2004 est.)
Poland has steadfastly pursued a policy of economic
liberalization throughout the 1990s and today stands out as a
success story among transition economies. Even so, much remains to
be done, especially in bringing down unemployment. The privatization
of small and medium-sized state-owned companies and a liberal law on
establishing new firms has encouraged the development of the private
business sector, but legal and bureaucratic obstacles alongside
persistent corruption are hampering its further development.
Poland''s agricultural sector remains handicapped by surplus labor,
inefficient small farms, and lack of investment. Restructuring and
privatization of "sensitive sectors" (e.g., coal, steel, railroads,
and energy), while recently initiated, have stalled. Reforms in
health care, education, the pension system, and state administration
have resulted in larger-than-expected fiscal pressures. Further
progress in public finance depends mainly on reducing losses in
Polish state enterprises, restraining entitlements, and overhauling
the tax code to incorporate the growing gray economy and farmers,
most of whom pay no tax. The government has introduced a package of
social and administrative spending cuts to reduce public spending by
about $17 billion through 2007. Additional reductions are under
discussion in the legislature but could be trumped by election-year
politics in 2005. Poland joined the EU in May 2004, and surging
exports to the EU contributed to Poland''s strong growth in 2004,
though its competitiveness could be threatened by the zloty''s
appreciation. GDP per capita roughly equals that of the three Baltic
states. Poland stands to benefit from nearly $13.5 billion in EU
funds, available through 2006. Farmers have already begun to reap
the rewards of membership via higher food prices and EU agricultural
subsidies.','6fca124aac9f5f64c0e63115b8264f451ba502a65ed41d449fc86ac1416432e5','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04f6586cae8125c4ed568ca7d8af2a4139de236da5fd9b32995f4b3b053b6448',2005,'PT','Portugal','economy',794,'total: 42
over 3,047 m: 5
2,438 to 3,047 m: 9
1,524 to 2,437 m: 3
914 to 1,523 m: 15
under 914 m: 10 (2004 est.)
total: 23
914 to 1,523 m: 1
under 914 m: 22 (2004 est.)
soil erosion; air pollution caused by industrial and
vehicle emissions; water pollution, especially in coastal areas
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Environmental
Modification
2.3% (2003)
43.28 billion kWh (2002)
42.15 billion kWh (2002)
5.3 billion kWh (2002)
3.4 billion kWh (2002)
NA
lowest 10%: 3.1%
highest 10%: 28.4% (1995 est.)
agriculture 10%, industry 30%, services 60% (1999 est.)
clothing and footwear, machinery, chemicals, cork and paper
products, hides
Spain 25%, France 14%, Germany 13.5%, UK 9.6%, US 6%, Italy
4.3%, Netherlands 4% (2004)
18 districts (distritos, singular - distrito) and 2
autonomous regions* (regioes autonomas, singular - regiao autonoma);
Aveiro, Acores (Azores)*, Beja, Braga, Braganca, Castelo Branco,
Coimbra, Evora, Faro, Guarda, Leiria, Lisboa, Madeira*, Portalegre,
Porto, Santarem, Setubal, Viana do Castelo, Vila Real, Viseu
grain, potatoes, olives, grapes; sheep, cattle, goats,
poultry, beef, dairy products
65 (2004 est.)
10.82 births/1,000 population (2005 est.)
Army, Navy (Marinha Portuguesa; includes Marine Corps), Air
Force (Forca Aerea Portuguesa, FAP), National Republican Guard
(Guarda Nacional Republicana) (2005)
revenues: $74.38 billion
expenditures: $79.86 billion, including capital expenditures of NA
(2004 est.)
Portugal has become a diversified and increasingly
service-based economy since joining the European Community in 1986.
Over the past decade, successive governments have privatized many
state-controlled firms and liberalized key areas of the economy,
including the financial and telecommunications sectors. The country
qualified for the European Monetary Union (EMU) in 1998 and began
circulating the euro on 1 January 2002 along with 11 other EU member
economies. Economic growth had been above the EU average for much of
the past decade, but fell back in 2001-04. GDP per capita stands at
two-thirds that of the Big Four EU economies. A poor educational
system, in particular, has been an obstacle to greater productivity
and growth. Portugal has been increasingly overshadowed by
lower-cost producers in Central Europe and Asia as a target for
foreign direct investment. The government faces tough choices in its
attempts to boost Portugal''s economic competitiveness while keeping
the budget deficit within the eurozone''s 3%-of-GDP ceiling.','5a59cb28ad240d891f8eeb25ca5a34d1072ffffd218b314249f812ebbdb3545d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4dea5cd424aa77933aa1b134c11eedcb13c71f234080526b8de24cd6812c9ff',2005,'PR','Puerto Rico','economy',795,'total: 17
over 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 5 (2004 est.)
total: 13
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 10 (2004 est.)
erosion; occasional drought causing water shortages
22.09 billion kWh (2002)
20.54 billion kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 3%, industry 20%, services 77% (2000 est.)
Reunion
agriculture 13%, industry 12%, services 75% (2000)
chemicals, electronics, apparel, canned tuna, rum,
beverage concentrates, medical equipment
US 90.3%, UK 1.6%, Netherlands 1.4%, Dominican Republic
1.4% (2002 est.)
none (commonwealth associated with the US); there are no
first-order administrative divisions as defined by the US
Government, but there are 78 municipalities (municipios, singular -
municipio) at the second order; Adjuntas, Aguada, Aguadilla, Aguas
Buenas, Aibonito, Anasco, Arecibo, Arroyo, Barceloneta,
Barranquitas, Bayamon, Cabo Rojo, Caguas, Camuy, Canovanas,
Carolina, Catano, Cayey, Ceiba, Ciales, Cidra, Coamo, Comerio,
Corozal, Culebra, Dorado, Fajardo, Florida, Guanica, Guayama,
Guayanilla, Guaynabo, Gurabo, Hatillo, Hormigueros, Humacao,
Isabela, Jayuya, Juana Diaz, Juncos, Lajas, Lares, Las Marias, Las
Piedras, Loiza, Luquillo, Manati, Maricao, Maunabo, Mayaguez, Moca,
Morovis, Naguabo, Naranjito, Orocovis, Patillas, Penuelas, Ponce,
Quebradillas, Rincon, Rio Grande, Sabana Grande, Salinas, San
German, San Juan, San Lorenzo, San Sebastian, Santa Isabel, Toa
Alta, Toa Baja, Trujillo Alto, Utuado, Vega Alta, Vega Baja,
Vieques, Villalba, Yabucoa, Yauco
sugarcane, coffee, pineapples, plantains, bananas,
livestock products, chickens
30 (2004 est.)
13.93 births/1,000 population (2005 est.)
no regular indigenous military forces; paramilitary
National Guard, Police Force
revenues: $6.7 billion
expenditures: $9.6 billion, including capital expenditures of NA
(FY99/00)
Puerto Rico has one of the most dynamic economies in the
Caribbean region. A diverse industrial sector has far surpassed
agriculture as the primary locus of economic activity and income.
Encouraged by duty-free access to the US and by tax incentives, US
firms have invested heavily in Puerto Rico since the 1950s. US
minimum wage laws apply. Sugar production has lost out to dairy
production and other livestock products as the main source of income
in the agricultural sector. Tourism has traditionally been an
important source of income, with estimated arrivals of nearly 5
million tourists in 1999. Growth fell off in 2001-03, largely due to
the slowdown in the US economy, and has recovered in 2004.','f36261f4454f07dcb3bef17486c267dac9f69bd5eddb2d94f4b9d33a50c70519','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94145223da7e69869c16e6fe8e6cb92d19e6fcf6b1890803bb80ec782acfa236',2005,'QA','Qatar','economy',796,'total: 2
over 3,047 m: 2 (2004 est.)
Reunion
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2004 est.)
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2004 est.)
limited natural fresh water resources are increasing
dependence on large-scale desalination facilities
Reunion
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
10% (FY00)
9.727 billion kWh (2002)
Reunion
1.166 billion kWh (2002)
9.046 billion kWh (2002)
Reunion
1.084 billion kWh (2002)
0 kWh (2002)
Reunion
0 kWh (2002)
0 kWh (2002)
Reunion
0 kWh (2002)
NA
Reunion
NA%
lowest 10%: NA
highest 10%: NA
Reunion
lowest 10%: NA%
highest 10%: NA%
liquefied natural gas (LNG), petroleum products, fertilizers,
steel
Reunion
sugar 63%, rum and molasses 4%, perfume essences 2%, lobster
3%, (1993)
Japan 41.9%, South Korea 15.8%, Singapore 9.1%, India 5.4%
(2004)
Reunion
France 74%, Japan 6%, Comoros 4% (2000)
10 municipalities (baladiyat, singular - baladiyah); Ad
Dawhah, Al Ghuwayriyah, Al Jumayliyah, Al Khawr, Al Wakrah, Ar
Rayyan, Jarayan al Batinah, Madinat ash Shamal, Umm Sa''id, Umm Salal
Reunion
none (overseas department of France); there are no
first-order administrative divisions as defined by the US
Government, but there are 4 arrondissements, 24 communes, and 47
cantons
fruits, vegetables; poultry, dairy products, beef; fish
Reunion
sugarcane, vanilla, tobacco, tropical fruits, vegetables,
corn
4 (2004 est.)
Reunion
2 (2004 est.)
15.54 births/1,000 population (2005 est.)
Reunion
19.26 births/1,000 population (2005 est.)
Qatari Amiri Land Force (QALF), Qatari Amiri Navy (QAN),
Qatari Amiri Air Force (QAAF)
Reunion
no regular indigenous military forces; French forces
(includes Army, Navy, Air Force, and Gendarmerie)
revenues: $10.17 billion
expenditures: $7.61 billion, including capital expenditures of $2.2
billion (2004 est.)
Reunion
revenues: $1.26 billion
expenditures: $2.62 billion, including capital expenditures of NA
(1998)
Oil and gas account for more than 55% of GDP, roughly 85% of
export earnings, and 70% of government revenues. Oil and gas have
given Qatar a per capita GDP about 80% of that of the leading West
European industrial countries. Proved oil reserves of 16 billion
barrels should ensure continued output at current levels for 23
years. Qatar''s proved reserves of natural gas exceed 14 trillion
cubic meters, more than 5% of the world total and third largest in
the world. Long-term goals feature the development of offshore
natural gas reserves to offset the ultimate decline in oil
production. In recent years, Qatar has consistently posted trade
surpluses largely because of high oil prices and increased natural
gas exports, becoming one of the world''s fastest growing and highest
per-capita income countries.
Reunion
The economy has traditionally been based on agriculture, but
services now dominate. Sugarcane has been the primary crop for more
than a century, and in some years it accounts for 85% of exports.
The government has been pushing the development of a tourist
industry to relieve high unemployment, which amounts to one-third of
the labor force. The gap in Reunion between the well-off and the
poor is extraordinary and accounts for the persistent social
tensions. The white and Indian communities are substantially better
off than other segments of the population, often approaching
European standards, whereas minority groups suffer the poverty and
unemployment typical of the poorer nations of the African continent.
The outbreak of severe rioting in February 1991 illustrates the
seriousness of socioeconomic tensions. The economic well-being of
Reunion depends heavily on continued financial assistance from
France.','5246407772acd51386a6d26ba0af0af7fbcf84e101fca4a7f29c502a3f53f4cf','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('166874e9d563d5d3945b140642b20ebdaea28b4c81469cab79d3a43a1e975ac5',2005,'RO','Romania','economy',797,'total: 25
over 3,047 m: 4
2,438 to 3,047 m: 9
1,524 to 2,437 m: 12 (2004 est.)
Russia
total: 577
over 3,047 m: 55
2,438 to 3,047 m: 197
1,524 to 2,437 m: 128
914 to 1,523 m: 98
under 914 m: 99 (2004 est.)
total: 36
1,524 to 2,437 m: 2
914 to 1,523 m: 10
under 914 m: 24 (2004 est.)
Russia
total: 2,009
over 3,047 m: 14
2,438 to 3,047 m: 30
1,524 to 2,437 m: 111
914 to 1,523 m: 257
under 914 m: 1,597 (2004 est.)
soil erosion and degradation; water pollution; air pollution
in south from industrial effluents; contamination of Danube delta
wetlands
Russia
air pollution from heavy industry, emissions of coal-fired
electric plants, and transportation in major cities; industrial,
municipal, and agricultural pollution of inland waterways and
seacoasts; deforestation; soil erosion; soil contamination from
improper application of agricultural chemicals; scattered areas of
sometimes intense radioactive contamination; groundwater
contamination from toxic waste; urban solid waste management;
abandoned stocks of obsolete pesticides
party to: Air Pollution, Air Pollution-Persistent Organic
Pollutants, Antarctic Treaty, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Russia
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Endangered Species, Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands, Whaling
signed, but not ratified: Air Pollution-Sulfur 94
2.47% (2002)
Russia
NA
56.53 billion kWh (2003)
Russia
915 billion kWh (2003)
57.5 billion kWh (2003)
Russia
894.3 billion kWh (2003)
962 million kWh (2003)
Russia
12.65 billion kWh (2002)
3.046 billion kWh (2003)
Russia
20.7 billion kWh (2003)
28.9% (2002)
Russia
25% (January 2003 est.)
lowest 10%: 2.4%
highest 10%: 27.6% (2003)
Russia
lowest 10%: 5.9%
highest 10%: 47% (2001)
agriculture 31.6%, industry 30.7%, services 37.7% (2004)
Russia
agriculture 12.3%, industry 22.7%, services 65% (2002 est.)
textiles and footwear, metals and metal products, machinery
and equipment, minerals and fuels, chemicals, agricultural products
Russia
petroleum and petroleum products, natural gas, wood and wood
products, metals, chemicals, and a wide variety of civilian and
military manufactures
Italy 21.4%, Germany 15%, France 8.5%, Turkey 7%, UK 6.6%
(2004)
Russia
Netherlands 9.1%, Germany 8%, Ukraine 6.4%, Italy 6.2%, China
6%, US 5%, Switzerland 4.7%, Turkey 4.3% (2004)
41 counties (judete, singular - judet) and 1 municipality*
(municipiu); Alba, Arad, Arges, Bacau, Bihor, Bistrita-Nasaud,
Botosani, Braila, Brasov, Bucuresti (Bucharest)*, Buzau, Calarasi,
Caras-Severin, Cluj, Constanta, Covasna, Dimbovita, Dolj, Galati,
Gorj, Giurgiu, Harghita, Hunedoara, Ialomita, Iasi, Ilfov,
Maramures, Mehedinti, Mures, Neamt, Olt, Prahova, Salaj, Satu Mare,
Sibiu, Suceava, Teleorman, Timis, Tulcea, Vaslui, Vilcea, Vrancea
Russia
49 oblasts (oblastey, singular - oblast), 21 republics
(respublik, singular - respublika), 10 autonomous okrugs
(avtonomnykh okrugov, singular - avtonomnyy okrug), 6 krays (krayev,
singular - kray), 2 federal cities (singular - gorod), and 1
autonomous oblast (avtonomnaya oblast'')
oblasts: Amur (Blagoveshchensk), Arkhangel''sk, Astrakhan'', Belgorod,
Bryansk, Chelyabinsk, Chita, Irkutsk, Ivanovo, Kaliningrad, Kaluga,
Kamchatka (Petropavlovsk-Kamchatskiy), Kemerovo, Kirov, Kostroma,
Kurgan, Kursk, Leningrad, Lipetsk, Magadan, Moscow, Murmansk,
Nizhniy Novgorod, Novgorod, Novosibirsk, Omsk, Orenburg, Orel,
Penza, Perm'', Pskov, Rostov, Ryazan'', Sakhalin (Yuzhno-Sakhalinsk),
Samara, Saratov, Smolensk, Sverdlovsk (Yekaterinburg), Tambov,
Tomsk, Tula, Tver'', Tyumen'', Ul''yanovsk, Vladimir, Volgograd,
Vologda, Voronezh, Yaroslavl''
republics: Adygeya (Maykop), Altay (Gorno-Altaysk), Bashkortostan
(Ufa), Buryatiya (Ulan-Ude), Chechnya (Groznyy), Chuvashiya
(Cheboksary), Dagestan (Makhachkala), Ingushetiya (Magas),
Kabardino-Balkariya (Nal''chik), Kalmykiya (Elista),
Karachayevo-Cherkesiya (Cherkessk), Kareliya (Petrozavodsk),
Khakasiya (Abakan), Komi (Syktyvkar), Mariy-El (Yoshkar-Ola),
Mordoviya (Saransk), Sakha [Yakutiya] (Yakutsk), North Ossetia
(Vladikavkaz), Tatarstan (Kazan''), Tyva (Kyzyl), Udmurtiya (Izhevsk)
autonomous okrugs: Aga Buryat (Aginskoye), Chukotka (Anadyr''), Evenk
(Tura), Khanty-Mansi, Komi-Permyak (Kudymkar), Koryak (Palana),
Nenets (Nar''yan-Mar), Taymyr [Dolgano-Nenets] (Dudinka), Ust''-Orda
Buryat (Ust''-Ordynskiy), Yamalo-Nenets (Salekhard)
krays: Altay (Barnaul), Khabarovsk, Krasnodar, Krasnoyarsk,
Primorskiy (Vladivostok), Stavropol''
federal cities: Moscow (Moskva), Saint Petersburg (Sankt-Peterburg)
autonomous oblast: Yevrey [Jewish] (Birobidzhan)
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center
name following in parentheses)
wheat, corn, barley, sugar beets, sunflower seed, potatoes,
grapes; eggs, sheep
Russia
grain, sugar beets, sunflower seed, vegetables, fruits; beef,
milk
61 (2004 est.)
Russia
2,586 (2004 est.)
10.7 births/1,000 population (2005 est.)
Russia
9.8 births/1,000 population (2005 est.)
Land Forces, Naval Forces, Air and Air Defense Forces (AMR),
Special Operations, Civil Defense (2005)
Russia
Ground Forces (SV), Navy (VMF), Air Forces (VVS); Airborne
Troops (VDV), Strategic Rocket Troops (RVSN), and Space Troops (KV)
are independent "combat arms," not subordinate to any of the three
branches
revenues: $22.1 billion
expenditures: $23.2 billion, including capital expenditures of $2.2
billion (2004 est.)
Russia
revenues: $106.4 billion
expenditures: $93.33 billion, including capital expenditures of NA
(2004 est.)
Romania began the transition from Communism in 1989 with a
largely obsolete industrial base and a pattern of output unsuited to
the country''s needs. The country emerged in 2000 from a punishing
three-year recession thanks to strong demand in EU export markets.
Despite the global slowdown in 2001-02, strong domestic activity in
construction, agriculture, and consumption have kept growth above
4%. An IMF standby agreement, signed in 2001, has been accompanied
by slow but palpable gains in privatization, deficit reduction, and
the curbing of inflation. The IMF Board approved Romania''s
completion of the standby agreement in October 2003, the first time
Romania has successfully concluded an IMF agreement since the 1989
revolution. In July 2004, the executive board of the IMF approved a
24-month standby agreement for $367 million. The Romanian
authorities do not intend to draw on this agreement, however,
viewing it simply as a precaution. Meanwhile, recent macroeconomic
gains have done little to address Romania''s widespread poverty,
while corruption and red tape continue to handicap the business','d8a9c96d61aafb1c09f1440a4366f3ba537ba80d28b02a70899f0b6b4e9ca998','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e5f947f91c0572a2924e2692867057878019ef3bb9bbeafa5d33115d29911b8',2005,'RW','Rwanda','economy',798,'total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2004 est.)
Saint Helena
total: 1
over 3,047 m: 1 (2004 est.)
total: 5
914 to 1,523 m: 2
under 914 m: 3 (2004 est.)
deforestation results from uncontrolled cutting of trees for
fuel; overgrazing; soil exhaustion; soil erosion; widespread poaching
Saint Helena
NA
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes,
Ozone Layer Protection
signed, but not ratified: Law of the Sea
3.2% (2004)
166.7 million kWh (2002)
Saint Helena
5 million kWh (2002)
195 million kWh (2002)
Saint Helena
4.65 million kWh (2002)
40 million kWh (2002)
Saint Helena
0 kWh (2002)
0 kWh (2002)
Saint Helena
0 kWh (2002)
60% (2001 est.)
Saint Helena
NA
lowest 10%: 4.2%
highest 10%: 24.2% (1985)
Saint Helena
lowest 10%: NA
highest 10%: NA
agriculture 90%
Saint Helena
agriculture and fishing 6%, industry (mainly
construction) 48%, services 46% (1987 est.)
coffee, tea, hides, tin ore
Saint Helena
fish (frozen, canned, and salt-dried skipjack, tuna),
coffee, handicrafts
Indonesia 64.2%, China 3.6%, Germany 2.7% (2004)
Saint Helena
Tanzania 30.3%, US 23.8%, Japan 10.4%, UK 7.1%, Spain
6.3% (2004)
12 provinces (in French - provinces, singular - province; in
Kinyarwanda - prefigintara for singular and plural); Butare, Byumba,
Cyangugu, Gikongoro, Gisenyi, Gitarama, Kibungo, Kibuye, Kigali
Rurale, Kigali-ville, Umutara, Ruhengeri
Saint Helena
1 administrative area and 2 dependencies*; Ascension*,
Saint Helena, Tristan da Cunha*
coffee, tea, pyrethrum (insecticide made from
chrysanthemums), bananas, beans, sorghum, potatoes; livestock
Saint Helena
corn, potatoes, vegetables; timber; fish, crawfish (on
Tristan da Cunha)
9 (2004 est.)
Saint Helena
1 (2004 est.)
40.6 births/1,000 population (2005 est.)
Saint Helena
12.33 births/1,000 population (2005 est.)
Rwandan Defense Forces: Army, Air Force
revenues: $354.5 million
expenditures: $385 million, including capital expenditures of NA
(2004 est.)
Saint Helena
revenues: $11.2 million
expenditures: $11 million, including capital expenditures of NA
(FY92/93)','ce79b18cdd84abe851b83bd2eb31a80e7cbd18c0208513d7c314b798a4a7c7c7','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bf92292c2ed61c6c5e509834d2bda01bfcea5da0f7e9cbf03026609c70283df',2005,'KN','Saint Kitts and Nevis','economy',799,'total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
NA
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
NA
105.8 million kWh (2002)
98.44 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA
highest 10%: NA
NA
machinery, food, electronics, beverages,
tobacco
US 57.5%, Canada 9%, Portugal 8.3%, UK 6.7%
(2004)
14 parishes; Christ Church Nichola Town, Saint
Anne Sandy Point, Saint George Basseterre, Saint George Gingerland,
Saint James Windward, Saint John Capesterre, Saint John Figtree,
Saint Mary Cayon, Saint Paul Capesterre, Saint Paul Charlestown,
Saint Peter Basseterre, Saint Thomas Lowland, Saint Thomas Middle
Island, Trinity Palmetto Point
sugarcane, rice, yams, vegetables, bananas;
fish
2 (2004 est.)
18.12 births/1,000 population (2005 est.)
Saint Kitts and Nevis Defense Force (includes
Coast Guard), Royal Saint Kitts and Nevis Police Force
revenues: $89.7 million
expenditures: $128.2 million, including capital expenditures of
$19.5 million (2003 est.)','2ebeb3f9c6be8b498a329cf046a63fe2d6b94b3ed79c131ad6cb3e0c274e461d','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49581c9a9ccc216a50b5127f010e09758d3bae0d914a07d841faa6ab34b28b94',2005,'LC','Saint Lucia','economy',800,'total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2004 est.)
deforestation; soil erosion, particularly in the
northern region
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
NA
270.3 million kWh (2002)
251.3 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 21.7%, industry, commerce, and manufacturing
24.7%, services 53.6% (2002 est.)
bananas 41%, clothing, cocoa, vegetables, fruits,
coconut oil
UK 41.4%, US 16.5%, Brazil 11.6%, Barbados 5.8%, Antigua
and Barbuda 4.6%, Dominica 4.5% (2004)
11 quarters; Anse-la-Raye, Castries, Choiseul, Dauphin,
Dennery, Gros-Islet, Laborie, Micoud, Praslin, Soufriere, Vieux-Fort
bananas, coconuts, vegetables, citrus, root crops, cocoa
2 (2004 est.)
20.05 births/1,000 population (2005 est.)
Royal Saint Lucia Police Force (includes Special Service
Unit, Coast Guard)
revenues: $141.2 million
expenditures: $146.7 million, including capital expenditures of
$25.1 million (2000 est.)','618be26112e48df1bd56336b54ee49406348f82d5c8e39df7f176bfea0839508','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bbe4cf126f5fab5eab212db60f2a265f69fe54cc7bfe960e4a5bc6e6ffaf957',2005,'PM','Saint Pierre and Miquelon','economy',801,'total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
recent test drilling for oil in waters
around Saint Pierre and Miquelon may bring future development that
would impact the environment
43.08 million kWh (2002)
40.06 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
fishing 18%, industry (mainly
fish-processing) 41%, services 41% (1996 est.)
fish and fish products, soybeans, animal
feed, mollusks and crustaceans, fox and mink pelts
Belgium 41.3%, US 19.9%, Spain 14.9%,
France 10%, Germany 4.1% (2004)
none (territorial collectivity of France);
note - there are no first-order administrative divisions as defined
by the US Government, but there are two communes - Saint Pierre,
Miquelon at the second order
vegetables; poultry, cattle, sheep, pigs;
fish
2 (2004 est.)
13.83 births/1,000 population (2005 est.)
revenues: $70 million
expenditures: $60 million, including capital expenditures of $24
million (1996 est.)','137f429e9af3dd5d819db03918a73b483d49702737727d9cafd1d6e912f43253','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ee4c335c184b6b3b5150d8865c57bab6747d8d4934ec328270c4d5be68c6d91',2005,'VC','Saint Vincent and the Grenadines','economy',802,'total: 5
914 to 1,523 m: 4
under 914 m: 1 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
pollution of coastal waters and
shorelines from discharges by pleasure yachts and other effluents;
in some areas, pollution is severe enough to make swimming
prohibitive
party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
NA
91.2 million kWh (2002)
84.82 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
agriculture 26%, industry 17%,
services 57% (1980 est.)
bananas 39%, eddoes and dasheen
(taro), arrowroot starch; tennis racquets
UK 33.5%, Barbados 13.1%, Saint
Lucia 11.5%, Trinidad and Tobago 9.9%, Antigua and Barbuda 8.3%, US
5.3%, Grenada 5.3%, Dominica 4.1% (2004)
6 parishes; Charlotte, Grenadines,
Saint Andrew, Saint David, Saint George, Saint Patrick
bananas, coconuts, sweet potatoes,
spices, small numbers of cattle, sheep, pigs, goats, fish
6 (2004 est.)
16.34 births/1,000 population (2005
est.)
no regular military forces; Royal
Saint Vincent and the Grenadines Police Force (includes Special
Service Unit), Coast Guard
revenues: $94.6 million
expenditures: $85.8 million, including capital expenditures of NA
(2000 est.)','3e59f3e0cf8af4122c0f325c9646ebbe3e8b378a034db509f69f477b9620c3cb','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57d66609de1a13f9865d4cc4607bd3ceb7c21883b8f8d29766c38001c8acd4de',2005,'WS','Samoa','economy',803,'total: 3
2,438 to 3,047 m: 1
under 914 m: 2 (2004 est.)
total: 1
under 914 m: 1 (2004 est.)
soil erosion, deforestation, invasive species, overfishing
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
NA
122 million kWh (2002)
113.5 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
NA
lowest 10%: NA
highest 10%: NA
NA
fish, coconut oil and cream, copra, taro, automotive parts,
garments, beer
Australia 67.2%, US 5.7%, Indonesia 5.3% (2004)
11 districts; A''ana, Aiga-i-le-Tai, Atua, Fa''asaleleaga,
Gaga''emauga, Gagaifomauga, Palauli, Satupa''itea, Tuamasaga,
Va''a-o-Fonoti, Vaisigano
coconuts, bananas, taro, yams, coffee, cocoa
4 (2004 est.)
15.95 births/1,000 population (2005 est.)
no regular armed services; Samoa Police Force
revenues: $105 million
expenditures: $119 million, including capital expenditures of NA
(2001-02)','a1abefc8f2ee6872e2188555d2e3ded3fdc7d59cb44175121a199cb57bae9e5c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('827571a09c144edd3d98b43a6cf871fd8dfe27263757079bbd4e94ab06ead770',2005,'ST','Sao Tome and Principe','economy',804,'total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2004 est.)
deforestation; soil erosion and exhaustion
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification, Law
of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
0.8% (2004)
17 million kWh (2002)
15.81 million kWh (2002)
0 kWh (2002)
0 kWh (2002)
54% (2004 est.)
lowest 10%: NA
highest 10%: NA
population mainly engaged in subsistence
agriculture and fishing
note: shortages of skilled workers
cocoa 80%, copra, coffee, palm oil
Netherlands 35.9%, China 12.3%, Belgium 7.4%,
Germany 6.3%, Poland 5.1%, France 4.8%, Thailand 4.1% (2004)
2 provinces; Principe, Sao Tome
note: Principe has had self-government since 29 April 1995
cocoa, coconuts, palm kernels, copra,
cinnamon, pepper, coffee, bananas, papayas, beans; poultry; fish
2 (2004 est.)
40.8 births/1,000 population (2005 est.)
Armed Forces of Sao Tome and Principe (FASTP):
Army, Coast Guard, Presidential Guard (2004)
revenues: $27.94 million
expenditures: $43.91 million, including capital expenditures of $54
million (2004 est.)','b5c5482d0756165637b71dcf4366ee10b8cde8aeb406bc90c4371c721a2b7ec3','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5f66004854307000d1dfe0aaf6fa8e2f00cf55e1f7c28489858b08e4c920199',2005,'AQ','Antarctica','economy',805,'total: 20
over 3,047 m: 6
2,438 to 3,047 m: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 6 (2004 est.)
in 1998, NASA satellite data showed that the antarctic
ozone hole was the largest on record, covering 27 million square
kilometers; researchers in 1997 found that increased ultraviolet
light passing through the hole damages the DNA of icefish, an
antarctic fish lacking hemoglobin; ozone depletion earlier was shown
to harm one-celled antarctic marine plants; in 2002, significant
areas of ice shelves disintegrated in response to regional warming
there are no developed public access airports or landing
facilities; 30 stations, operated by 16 national governments party
to the Antarctic Treaty, have restricted aircraft landing facilities
for either helicopters or fixed-wing aircraft; commercial
enterprises operate two additional aircraft landing facilities;
helicopter pads are available at 27 stations; runways at 15
locations are gravel, sea-ice, blue-ice, or compacted snow suitable
for landing wheeled, fixed-wing aircraft; of these, one is greater
than 3 km in length, six are between 2 km and 3 km in length, three
are between 1 km and 2 km in length, three are less than 1 km in
length, and two are of unknown length; snow surface skiways, limited
to use by ski-equipped, fixed-wing aircraft, are available at
another 15 locations; of these, four are greater than 3 km in
length, three are between 2 km and 3 km in length, two are between 1
km and 2 km in length, two are less than 1 km in length, and four
are of unknown length; aircraft landing facilities generally subject
to severe restrictions and limitations resulting from extreme
seasonal and geographic conditions; aircraft landing facilities do
not meet ICAO standards; advance approval from the respective
governmental or nongovernmental operating organization required for
using their facilities; landed aircraft are subject to inspection in
accordance with Article 7, Antarctic Treaty; guidelines for the
operation of aircraft near concentrations of birds in Antarctica
were adopted in 2004; relevant legal instruments and authorization
procedures adopted by states party to the Antarctic Treaty
regulating access to the Antarctic Treaty area, that is to all areas
between 60 and 90 degrees of latitude South, have to be complied
with (see information under "Legal System"); an Antarctic Flight
Information Manual (AFIM) providing up-to-date details of Antarctic
air facilities and procedures is maintained and published by the
Council of Managers of National Antarctic Programs (2004 est.)','3da97dc7a3239ed3f14ddd5e51481bf1eaf6f2831d91f38b4fc6c4b62d710fee','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('969e9597540e8d3e768eaffb935ae5222b1701fe7af062f285db76cea963203d',2005,'AD','Andorra','economy',806,'deforestation; overgrazing of mountain meadows contributes
to soil erosion; air pollution; wastewater treatment and solid waste
disposal
party to: Hazardous Wastes
signed, but not ratified: none of the selected agreements
NA kWh
NA kWh
NA kWh; note - most electricity supplied by Spain and
France; Andorra generates a small amount of hydropower
0 kWh (2002)
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 1%, industry 21%, services 78% (2000 est.)
tobacco products, furniture
Spain 58%, France 34% (2000)
7 parishes (parroquies, singular - parroquia); Andorra la
Vella, Canillo, Encamp, La Massana, Escaldes-Engordany, Ordino, Sant
Julia de Loria
small quantities of rye, wheat, barley, oats, vegetables;
sheep
none (2004 est.)
9 births/1,000 population (2005 est.)
no regular military forces, Police Service of Andorra
revenues: $385 million
expenditures: $342 million, including capital expenditures of NA
(1997)
Andorra la Vella','4568fa45d3e75d9e50fcea68e169fc8edb13ffe9c8d8e58cf413712f68b151a0','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57b82b35d3069ac7fbce96321b29c17e3e9398c603ffa2624a2fa5886323f0a3',2005,'HM','Heard Island and McDonald Islands','economy',807,'NA
Holy See (Vatican City)
NA
No indigenous economic activity,
but the Australian Government allows limited fishing around the
islands.
Holy See (Vatican City)
This unique, noncommercial economy is
supported financially by an annual contribution from Roman Catholic
dioceses throughout the world (known as Peter''s Pence); by the sale
of postage stamps, coins, medals, and tourist mementos; by fees for
admission to museums; and by the sale of publications. Investments
and real estate income also account for a sizable portion of
revenue. The incomes and living standards of lay workers are
comparable to those of counterparts who work in the city of Rome.','7edb9614048c38e3fbf2a774ed6457fa8948cb63b89bdeb3a0bd58919f691850','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24733886af1720497bbcd0dc75375fb029293ae24cda9eb80c8cb0792ac73341',2005,'LI','Liechtenstein','economy',808,'NA
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air Pollution-Volatile
Organic Compounds, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered Species,
Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 1.3%, industry 47.4%, services 51.3% (31
December 2001 est.)
small specialty machinery, connectors for audio and
video, parts for motor vehicles, dental products, hardware, prepared
foodstuffs, electronic equipment, optical products
EU 62.6% (Germany 24.3%, Austria 9.5%, France 8.9%,
Italy 6.6%, UK 4.6%), US 18.9%, Switzerland 15.7%
11 communes (Gemeinden, singular - Gemeinde); Balzers,
Eschen, Gamprin, Mauren, Planken, Ruggell, Schaan, Schellenberg,
Triesen, Triesenberg, Vaduz
wheat, barley, corn, potatoes; livestock, dairy
products
none (2004 est.)
10.41 births/1,000 population (2005 est.)
revenues: $424.2 million
expenditures: $414.1 million, including capital expenditures of NA
(1998 est.)
Despite its small size and limited natural resources,
Liechtenstein has developed into a prosperous, highly
industrialized, free-enterprise economy with a vital financial
service sector and living standards on a par with its large European
neighbors. The Liechtenstein economy is widely diversified with a
large number of small businesses. Low business taxes - the maximum
tax rate is 20% - and easy incorporation rules have induced many
holding or so-called letter box companies to establish nominal
offices in Liechtenstein, providing 30% of state revenues. The
country participates in a customs union with Switzerland and uses
the Swiss franc as its national currency. It imports more than 90%
of its energy requirements. Liechtenstein has been a member of the
European Economic Area (an organization serving as a bridge between
the European Free Trade Association (EFTA) and the EU) since May
1995. The government is working to harmonize its economic policies
with those of an integrated Europe.','4113c5f55e60e7eb4ffe68092d05c37b415c11ca670134c8f81e3f091450e6ce','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7a8958b78541cddb787235f68cf642b8717824fd775218d069819a26a734505',2005,'MC','Monaco','economy',809,'NA
party to: Air Pollution, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
NA kWh
NA kWh
note: electricity supplied by France
NA%
lowest 10%: NA%
highest 10%: NA%
none; there are no first-order administrative divisions as
defined by the US Government, but there are four quarters
(quartiers, singular - quartier); Fontvieille, La Condamine,
Monaco-Ville, Monte-Carlo
none
none; linked to the airport at Nice, France by helicopter
service (2004 est.)
9.26 births/1,000 population (2005 est.)
revenues: $518 million
expenditures: $531 million, including capital expenditures of NA
(1995)
Monaco, bordering France on the Mediterranean coast, is a
popular resort, attracting tourists to its casino and pleasant
climate. In 2001, a major construction project extended the pier
used by cruise ships in the main harbor. The principality has
successfully sought to diversify into services and small,
high-value-added, nonpolluting industries. The state has no income
tax and low business taxes and thrives as a tax haven both for
individuals who have established residence and for foreign companies
that have set up businesses and offices. The state retains
monopolies in a number of sectors, including tobacco, the telephone
network, and the postal service. Living standards are high, roughly
comparable to those in prosperous French metropolitan areas. Monaco
does not publish national income figures; the estimates below are
extremely rough.','0a18e2d5fc526e5a9db82d513ab3b9ff8a99be5b95fcf5f82605a5c024a302ce','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e41bbdad59acc1577e5bcf82c80937a2373ee2d33b1eb35c7ddc620c6bd03d92',2005,'SM','San Marino','economy',810,'NA
party to: Biodiversity, Climate Change, Desertification
signed, but not ratified: Air Pollution
NA
NA%
lowest 10%: NA%
highest 10%: NA%
agriculture 1%, industry 42%, services 57% (2000 est.)
building stone, lime, wood, chestnuts, wheat, wine, baked
goods, hides, ceramics
9 municipalities (castelli, singular - castello);
Acquaviva, Borgo Maggiore, Chiesanuova, Domagnano, Faetano,
Fiorentino, Montegiardino, San Marino Citta, Serravalle
wheat, grapes, corn, olives; cattle, pigs, horses, beef,
cheese, hides
none (2004 est.)
10.18 births/1,000 population (2005 est.)
Voluntary Military Force (Corpi Militari Voluntar); note
- performs ceremonial duties and limited police assistance
revenues: $400 million
expenditures: $400 million, including capital expenditures of NA
(2000 est.)','9107fcb2ccdb8c373e2111797aa8007239362ddfaf4986f0f652cea9a46c431c','internet-archive','theciaworldfactb27560gut','txt','d4ed053291f82fd7d770c4f2e9194c82a2393d8cddf34f80ed593cfa4cbf0e2f','https://archive.org/download/theciaworldfactb27560gut/27560.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b1b10e240486ef47f3046158f9f3ea0726648446ed87dc1a2f2110d1e1f406a',1968,'','','people-and-society',2,'Population: 37,717,000, average annual growth rate 2.6%
(current) ,
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English ;
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force
ARABIA','f8b7605ba1b2a23088aac7fcfb362b6313b7efb6c969c93029fd1c2dc7706c95','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acc4f3e8655910b215447eb55dee534d871a18ac9934f06f527cc9dbf837df89',1968,'AF','Afghanistan','people-and-society',5,'Population: 14,541,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Afghan(s); adjective—Afghan
Ethnic divisions: 50% Pushtuns, 25% Taiiks, 9% Uzbeks,
9% Hazaras; minor ethnic groups include Chahar Aimaks,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11%
Turkic languages (primarily Uzbek and Turkmen), 10%
thirty minor languages (primarily Baluchi and Pashai); much
bilingualism
Literacy: under 10%
Labor force: about 5.88 million (FY78 est.); 75%-80%
agriculture-and animal husbandry, 20%-25% commerce,
small industry, services; massive shortage of skilled labor
Organized labor: none','e00a96ef1d2491d3d68bd982c4ed3e80c4e7bd5f68ae6a4674978caa3418d70b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd59fb003a10946dfb431f3c2db2cb1f5256a415de85c0aa96df881356b603c2',1968,'BG','Bulgaria','people-and-society',11,'Population: 2,597,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Albanian(s); adjective—Albanian
Ethnic divisions: 96% Albanian, remaining 4% are
Greeks, Vlachs, Gypsies, and Bulgarians
January 1979
Religion: 70% Muslim, 20% Albanian Orthodox, 10%
Roman Catholic; observances prohibited; Albania claims to
be the world’s first atheist state
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics avail-
able, but probably greatly improved
Labor force: 911,000 (1969); 60.5% agriculture, 17.9%
industry, 21.6% other nonagricultural
Population: 8,871,000 (January 1979), average annual
growth rate 0.5% (current)
Nationality: noun—Bulgarian(s); adjective—Bulgarian.
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Sik cal ee aS
wane Beet AL een ay
Oe ee Oe Oe =O
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Sofia
(See reference map IV)
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsiés, 2.5% Macedonians, 0.3% Armenians, 0.2% Russians,
0.6% other
Religion: regime promotes atheism; religious background
of population is 85% Bulgarian Orthodox, 18% Muslim, 0.8%
Jewish, 0.7% Roman Catholic, 0.5% Protestant, Gregorian-
Armenian and other
Language: Bulgarian; secondary languages closely corre-
spond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 5.0 million (1974); 32% agriculture, 33%
industry, 35% other
Population: 33,123,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Burman(s); adjective—Burmese
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2%
Kachin, 2% Chin, 2% Chinese, 3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their
own languages :
Literacy: 70% (official claim)
28
Labor force: 12.2 million (1976); 67% agriculture, 9%
industry, 20% services, commerce, and transportation
Organized labor: no figure available; old Jabor organiza-
tions have been disbanded, and government is forming one
central labor organization','f7a47dde8ce59a4f9b1840e55391f9347627456c99429dbf4a71d11230bb4a4d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb8092e56659c3ffb05ad81ab187a2a15c8ecfc427ac3b690e35be1cfeb6d1c7',1968,'DZ','Algeria','people-and-society',15,'Population: 17,944,000 (January 1979), average annual
growth rate 3.4% (current)
Nationality: noun—Algerian(s); adjective—Algerian
Ethnic divisions: 99% Arab-Berbers, less than 1%
Europeans i
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 4.0 million; 50% agriculture, 20% industry,
25% other (military, police, civil service, transportation
workers, teachers, merchants, construction workers); at least
20% of urban labor unemployed
“Organized labor: 25% of labor force claimed; General
Union of Algerian Workers (UGTA) is the only labor
organization and is subordinate to the National Liberation
Front
(See reference map lV}
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages;
Italian, Portuguese, and Russian also spoken; English used in
the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian
laborers
Organized labor: over 6,000','908de9af355d76f65617ee95e50880e5409e86f1a2d29e8b05db87a2e99c732c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee1122080175f82fa0a924addba9055ad77db1d7927477f3f5ee61287cd27a4d',1968,'AD','Andorra','people-and-society',19,'Population: 29,000 (official estimate for 1 July 1976)
Nationality: noun—Andorran(s); adjective—Andorran
Ethnic divisions: Catalan stock; 30% Andorrans, 61%
Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French and
Castilian
--Labor force: unorganized; largely shepherds and farmers','249984b2e7fcbf3e39e8c2569017c09c023341170e97d7e0a51a6c0dd498512c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32a86cd7b5029cd8c60002444a91b8f2ae2bdf782071997dc0f9470d284a3216',1968,'AO','Angola','people-and-society',23,'Population: Angola (including Cabinda), 6,527,000 (Janu-
ary 1979), does not take into account emigration from
Atlantic
Ocean
O
{See reference map Vi)
Angola, average annual growth rate 2.4% (current); Cabinda,
105,000 (January 1979), average annual growth rate 3.3%
(12-60 to 12-70)
Nationality: noun—Angolan(s); adjective—Angolan
Ethnic divisions: 93% African, 5% European, 1% mestizo
Religion: about 84% animist, 12% Roman Catholic, 4%
Protestant
Language: Portuguese (official), many native dialects
Literacy: 10-15%
Labor force: 2.6 million economically active (1964);
531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)
Population: 73,000 (January 1979), average annual
growth rate 1.3% (7-70 to 7-77)
Nationality: noun—Antiguan(s),; adjective—Antiguan
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other
Protestant sects, and some Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000, 20% unemployment','013b15de4fae2e6c40bb29ee3d4c7bce1613764d1612814d09184e9d9416451f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a779498ea06a3e6d7e697e48f6eaa9c0495fbe7d65b595fdb6703a2eff1ad1fa',1968,'AR','Argentina','people-and-society',27,'Population: 26,658,000 (January 1979), average annual
growth rate 1.38% (current)
Nationality: noun—Argentine(s); adjective—Argentine
Ethnic divisions: approximately 85% white, 15% mestizo,
Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic (less than 20%
practicing), 2% Protestant, 2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 10 million; 19% agriculture, 25% manufac-
turing, 20% services, 11% commerce, 6% transport and
communications, 19% other; 4-5% estimated unemployment
Organized labor: 25% of labor force (est.)
Population: 2,000 (official estimate for 31 December
1977)
Nationality: noun—Falkland Islander(s); adjective—Falk-
land Island
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); est. over 95% in agriculture,
mostly sheepherding ,
Population: 2,902,000 (January 1979), average annual
growth rate 0.6% (current)
218
Nationality: noun—Uruguayan(s); adjective—Uruguayan
Ethnic divisions: 85-95% white, 5% Negro, 5-10% mestizo
Religion: 66% Roman Catholic (less than half adult
population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed
in important sectors—25% government; 34% industry; 10%
service; 23% other; 8% agriculture, forestry, fishing and
mining; no shortage of skilled labor
Organized ‘labor: about 25% of labor force
Population: 1,000 (official estimate for 1 July 1977)
Ethnic divisions: primarily Italians but also many other
nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees
divided into 3 categories—executives, officeworkers, and
salaried employees
Organized labor: none
Population: 14,541,000, excluding Indian jungle popula-
tion (January 1979), average. annual growth rate 2.2%
(current) ,
Nationality: _noun—Venezuelan(s); adjective—Vene-
zuelan
Ethnic divisions: 67% mestizo, 21% white, 10% Negro,
2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish ,
Literacy: 74% (claimed, 1970 est.)
Labor force: 3.7 million (1975); 24% agriculture, 6%
construction, 17% manufacturing, 6% transportation, 18%
commerce, 25% services, 4% petroleum, utilities, and other
Organized labor: 45% of labor force','73f33745df21df10d5bd44ba485208f93a9c1847de7baad4fbefcb087106e661','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9011621c1513c7f8e26c8241e07f99d1cb408c03133f5a2a2f3e610724bfc3d',1968,'AU','Australia','people-and-society',31,'Population: 14,298,000 (January 1979), average annual
growth rate 1.1% (current) 4
Nationality: noun—Australian(s); adjective—Australian
Ethnic divisions: 99% Caucasian, 1% Asian and aborigine
Religion: 98% Christian
Language: English
Literacy: 98.5%
Labor force: 6 million; 14% agriculture, 32% industry,
37% services, 15% commerce, 2% other; 6% unemployment
Organized labor: 44% of labor force’
- Population: 615,000 (January 1979), average annual
growth rate 1.6% (current)
Nationality: noun—Fijian(s); adjective—Fijian
Ethnic divisions: 44% Fijian, 50% Indian, 6% European,
Chinese and others
Religion: Fijians mainly Christian, Indians are Hindu
with a Muslim minority
Language: English and Fijian (official), Hindustani
spoken among Indians
64
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no
breakdown on remainder
Organized labor: about 50% of labor force organized into
22 unions; unions organized along lines of work, breakdown
by ethnic origin causes further fragmentation
Population: 52,000 (preliminary total from census of 8
December 1973) ,
Nationality: noun—Gilbertese or Gilbert Islander(s);
adjective—Gilbertese, or Gilbert Islander
Ethnic divisions: Micronesian
Religion: Catholic
Literacy: less than 50%
Population: 145,958,000, including East Timor and West
Irian (January 1979), average annual growth rate 2.1%
. (current)
Nationality: noun—lIndonesian(s); adjective—Indonesian
_ Ethnic divisions: majority of Malay stock comprising 45%
Javanese, 14% Sundanese, 7.5% Madurese, 7.5% coastal
Malays, 26% other
Religion: 90% Muslim, 5% Christian, 3% Hindu, 2% other
Language: Indonesian (modified form of Malay) official;
English, and Dutch leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 55 million; 64% agriculture, 12% trade, 7%
industry, 17% other
Organized labor: 10% of labor force
Population: 35,808,000 (January 1979), average annual
growth rate 3.0% (current)
Nationality: noun—Iranian(s); adjective—Iranian
Ethnic divisions: 63% ethnic Persians, 3% Kurds, 18% °
other Iranian, 18% Turkic, 83% Arab and other Semitic, 1%
other
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2%
Zoroastrians, Jews, Christians and Baha’is—
Language: Persian (Farsi), Turkish dialects, Kurdish,
Arabic ,
Literacy: about 37% of those 7 years of age and older
(1976 est.)
Labor force: 10.1 million est. 1976; 36% agriculture, 21%
manufacturing; shortage of skilled labor substantial
Population: 12,689,000 (January 1979), average annual
growth rate 3.4% (current)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
—
eS =
ee
AAA a em RA a
Pua.
\\
Pa
4
e
4
C4
“4
Thala.
poe
Ng er ey
Ne Nag NN a a EE ta — ar” sg =
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
IRAQ/IRELAND
Nationality: ‘noun—Iraqi(s); adjective—Iraqi
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7%
Assyrians, 2.4% Turkomans, 7.7% other
Religion: 90% Muslim (50% Shiah Muslim, 40% Sunni
Muslim), 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry,
6.7% government, 16.8% other; rural underemployment .
high, but not serious because low subsistence levels make it
easy to care for unemployed; severe shortage of technically
trained personnel
Organized labor: 11% of labor force
Population: 7,000 (official estimate for 30 June 1969)
Nationality: noun—Nauruan(s); adjective—Nauruan
Ethnic divisions: 48% Nauruans, 19% Chinese, 7%
Europeans, 26% other Pacific Islanders
Religion: Christian (two-thirds Protestant, one-third
Catholic)
Language: Nauruan, a distinct Pacific Island tongue;
English, the language of school instruction, spoken and
understood by nearly all
Literacy: nearly universal
Population: 140,000 (January 1979), average annual
growth rate 1.6% (current)
Nationality: noun—New Caledonian(s); adjective—New
Caledonian ;
_ Ethnic divisions: Melanesian 42%; French 40%; remain-
der Vietnamese, Indonesian, Chinese, Polynesian
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese
laborers were imported for plantations and mines in
pre-World War II period; immigrant labor now coming
from Wallis Islands, New Hebrides, and French Polynesia
“Organized labor: unorganized
150
Population: 102,000 (January 1979), average annual
growth rate 2.2% (7-74 to 7-77)
Nationality: noun—New Hebridean(s); adjective—New
Hebrides
Ethnic divisions: 92% indigenous Melanesian, 3% Euro-
pean, remainder Vietnamese, Chinese, and various Pacific
Islanders
Religion: most at least nominally. Christian
Literacy: probably 10%-20%
Tasman
Sea
: NEW %
aw, 7, Wellington
(See reference map Vill}
Nationality: noun—New Zealander(s); adjective—New
Zealand
Ethnic divisions: 98% European, 7% Maori
Religion: 90% Christian, 9% none or unspecified; 1%
Hindu, Confucian, and other ;
Literacy: 98%
Labor force: 1,207,700; 13% agriculture, 33% manufac-
turing and construction, 9% transportation and communica-
tions, 24% commerce and finance, 21% administrative and
professional; unemployment 5.7% (1976)
Organized labor: 52% of labor force
Population: 3,024,000 (January 1979), average annual
growth rate 2.6% (7-73 to 7-77)
Nationality: noun—Papua New Guinean(s); adjective—
Papua New Guinean
Ethnic divisions: predominantly Melanesian and Papuan,
some Negrito, Micronesian, and Polynesian types
Religion: over one-half of population nominally Christian
(490,000 Catholic, 320,000 Lutheran, other Protestant sects);
remainder animist
Language: 700 indigenous languages; pidgin English and
2 or 3 native languages are linguae francae for over one-half
of population; English spoken by 1% to 2% of population
Literacy: 15%; in English, 0.1%
Labor force: no available figures; mostly subsistence
farmers ,
Population: 6,000 (preliminary total from census of 8
December 1973)
Ethaic divisions: Polynesian
Religion: Protestant
Literacy: less than 50%
Population: 155,000 (January 1979),
growth rate 1.0% (1-76 to 1-77)
Nationality: noun— Western Samoan(s); pave ests
ern Samoa
Ethnic divisions: Polynesians, about 12,000 Euronesians
(persons of European and Polynesian blood), 700 Europeans
Religion:—99.7% Christian (about half of population
associated with the London Missionary Society)
Language: Samoan (Polynesian), . English
‘Literacy: 85%-90% (education compulsory for all children
from 7-15 years)
average annual
Labor force: agriculture 19,148; mining and manufactur-
ing 1,716 (1961)
Organized labor: unorganized .
Population: 1,765,000, excluding the fends of Perim and
Arabian
Sea .
Indian
_ Ocean
{See reference map VV) -
Kamaran for which no data are available (January 1979),
average annual growth rate’ 1.9% (current)
Nationality: noun—Yemeni(s); adjective—Yemeni _
Ethnic divisions: almost all Arabs; a few Indians, Somalis,
and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 5,078,000 (January 1979), average annual
growth rate 1.9% (current)
Nationality: noun—Yemeni(s); adjective—Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and herding
Population: 22,074,000 (January 1979), average annual
growth rate 0.9% (current)
Nationality: noun—Yugoslav(s); adjective—Yugoslav
Ethnic divisions: 39.7% Serb, 22.1% Croat, 8.4% Muslims,
8.2% Slovene, 5.8% Macedonian, 2.5% Montenegrin, 6.4%
Albanian, 2.3% Hungarian, 4.6% other (197] census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic,
12% Muslim, 3% other, 12% none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Alba-
nian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 9.2 million (1976); 36% agriculture, 20%
mining and manufacturing, 44% other nonagricultural
activities; estimated unemployment averaged 5% of domes-
tic labor force in 1976
Population: 27,474,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Zairian(s); adjective—Zairian
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes—Mongo, Luba,
Kongo (all Bantu), and the Mangbetu-Azande (Hamitic)
make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo,
and Chiluba are all classified as official. languages
Literacy:. 5% fluent in French, about 35% have an
acquaintance with French
Labor force: about 8 million, but only about 13% in wage
structure','3d29fb16d595b09f582d83387e8dbf77d02d4a5323b26b969c9090092f8c337e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7dbc5933d57232dda36e1475f4100b8da7da63eefe20148bd2d676a93421b69',1968,'AT','Austria','people-and-society',36,'Population: 7,511,000 (January 1979), average annual
growth rate —0.0% (1-77 to 1-78)
Nationality: noun—Austrian(s); adjective—Austrian
10
CZECHOSLOVAKIA
(See reference map iV)
Ethnic divisions: 98.1% German, 0.7% Croatian, 0.3%
Slovene, 0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8% none or
other
Language: German
Literacy: 98%
Labor force: 2,784,635 (1977); 18% agriculture and
forestry, 49% industry and crafts, 18% trade and communi-
cations, 7% professions, 6% public service, 2% other; 2.4%
registered unemployed; an estimated 200,000 Austrians are
employed in other European countries; foreign laborers in
Austria number more than 200,000 (1972); unemployment
1.2% (September 1977)
Organized labor: about two-thirds of wage and salary
workers (1971)
Population: 229,000 (January 1979), average annual
growth rate 2.8% (7-76 to 7-77) :
Nationality: noun—Bahamian (sing., pl.); adjective—
Bahamian
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: Baptists 29%, Church of England 23%, Roman
Catholic 23%, smaller groups of other Protestant, Greek
Orthodox, and Jews
Il
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
THE BAHAMAS/BAHRAIN
UNITED
STATES
Atlantic Ocean
THE
4 \\ eAMas','ffee1729d7f1299bfd558b980d056696b537f2c99ce8ff71684f9789108ad912','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c6cf5ffdd18db8b9d2e5cb600513176b5018e2c1c71fb11310e7b3e51b3e055',1968,'HT','Haiti','people-and-society',39,'—\\
= q
DOMINICAN _
REPUBLIC ~
Caribbean Sea
(See reterence map tl}
Language: English
Labor force: 84,228 (1976), 25% organized; 25% unem-
ployment (1977)
Population: 5,600,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Haitian(s); adjective—Haitian
Ethnic divisions: over 90% Negro, nearly 10% mulatto,
few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of
which an overwhelming majority also practice Voodoo)
Language: French (official) spoken by only 10% of
population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.3 million (est. 1975); 79% agriculture, 14%
services, 7% industry, 5% unemployed; shortage of skilled
labor; unskilled labor abundant ~
Organized labor: less than 1% of labor force','ac8837c19fbdaf677881cd52ecd0f7f2f8288594464467ae5984e837145041d5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bae04d88d598c38d99512602b1bddbdb12ea5105009dd48f492a3fb6e9a8b575',1968,'BH','Bahrain','people-and-society',44,'Population: 289,000 (January 1979), average annual
growth rate 3.5% (7-75 to. 7-76) ;
Nationality: noun—Bahraini(s); adjective—Bahraini
_ Ethnic divisions: 90% Arab, 7% Yranian, Pakistani, and
Indian, 3% other; native Bahrainis are a minority
Religion: Muslim
Language: Arabic, English also widely spoken
- Literacy: about 40% (1970)
Labor force: 78,507 (1976)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BAHRAIN/BANGLADESH
Arabian
Sea
(See reference map V}','24623dbc2f683797c9283085817b5799b513d4c6b79a681adb0d5e835b04ba1b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c018834a350059b56c3f965ff7a3a38ea4b468935f4da96128d296ca99b525c',1968,'BD','Bangladesh','people-and-society',48,'Population: 86,931,000 (January 1979), average annual
growth rate 2.7% (current)
’ Nationality: noun—Bangladeshi(s), adjective—Bangla-
desh
13
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
(See reference map Vil}
Ethnic divisions: predominantly Bengali; fewer than 1
“Biharis” and fewer than 1 million tribals
Religion: about 83% Muslim, 16% Hindu; less than 1%
Buddhist and other
Language: Bengali
Literacy: about 25%
Labor force: over 20 million; extensive export of labor to
U.A.E., Qatar, Kuwait, Iraq, and Oman; over 75% of labor
force is in agriculture
million','53fcdc752066b94ca25802782ff7ae35f3b02157b5ff1fc3194250bf14943f24','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('226ba825f5d5b0b446ee5e1f731035ba7bda3e6b31f4fd4e7d14371d424e4d10',1968,'BB','Barbados','people-and-society',52,'Population: 260,000 (January 1979), average annual
growth rate 1.5% (1-76 to 1-77)
Nationality: noun—Barbadian(s); adjective—Barbadian
Ethnic divisions: 80% African, 17% mixed, 4% European
Religion: Anglican (70%), Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1973 est.) wage and salary earners;
unemployment 20-25% (1976) -
Organized labor: 32%','88d38d862766294960a57c49311219788f87578f94e17899f6dd5a030d9b45db','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8350169117d37de1728f0085d519123707c22c12df014f58a82a899b59fa066a',1968,'BE','Belgium','people-and-society',56,'Population: 9,842,000 (January 1979), average annual
growth rate 0.0% (current)
Nationality: noun—Belgian(s); adjective—Belgian
Ethnic divisions: 55% Flemings, 33% Walloons, 12%
mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch), German, in small
area of eastern Belgium; divided along ethnic lines
16
Literacy: 97%
Labor force: 4.09 million (July 1978); in June 1976, 46.7%
in services, 28.0% in mining and manufacturing, .7.4% in
construction, 6.6% in transportation, 3.2% in agriculture,
1.0% commuting foreign workers, 0.4% in public works,
6.7% unemployed; 8.1% unemployed first quarter 1978,
seasonally adjusted
Organized labor:. 48% of labor force (1969)','9fcb6b14817332a9574075255d1fc24c565face1fae275cd9e0eab3eecca317e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deae6845c0c3e22f38677ab9b2ef3bfaf4389f871f3b7f8cdcccc7f0a97c7004',1968,'HN','Honduras','people-and-society',61,'Population: 154,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Belizean(s); adjective—Belizean
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerin-
dian, 8% other
17
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BELIZE/BENIN
'' Religion: 50% Roman Catholic; Anglican, Seventh-day
Adventist, Methodist, Baptist, Jehovah’s Witnesses, Men-
nonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
- Labor force: 34,500; 39% agriculture, 14% manufactur-
ing, 8% commerce, 12% construction and transport, 20%
services, 7% other; shortage of skilled labor and all types of
technical personnel; over 15% are unemployed
Organized labor: 8% of labor force
Population: 3,578,000 (January 1979), average annual
growth rate 3.4% (current)
Nationality: noun—Honduran(s); . adjective—Honduran
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 47% of persons 10 years of age and over (est.
1970)
Labor force: approx. 900,000 (est. mid-1972); 66%
agriculture, 12% services, 8% manufacturing, 5% commerce,
6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-1972)','d5b705cce152e676127f029ead84b1266418516f01ad20ff1fb6bda612d5086d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f40f1b39b5555baa44328eecac113641dc3f5f66cd8d8df4b270bd148c8236a',1968,'BJ','Benin','people-and-society',65,'Population: 3,333,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Beninese (sing. & pl.); adjective—
Beninese
Ethnic divisions: 99% Africans (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba), 5,500
Europeans ,
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a
=e ne Ne ee Nn Oe ee), OO ee ae oe:
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
2 *
BENIN/BERMUDA
i UPPER VOLTA
0
Gulf of Guinea
(See reference map Vi}
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most
common vernaculars in south, at least 6 major tribal
languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture;
15% civil service, artisans, and industry
Organized labor: approximately 75% of wage earners,
divided among two major and several minor unions','ad24746651041086748bcf16d4111f07d02dd88f197a59462d5af287bdd23008','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3afd84ee337add560e3382bd2771bf3b8d67cc88d88e934a66d66b3472e8868',1968,'BM','Bermuda','people-and-society',69,'Population: 60,000 (January 1979), average annual
growth rate 1.2% (7-70 to 7-76)
Nationality: noun—Bermudian(s); adjective—Bermudian
" Ethnic divisions: approximately 59% black, 41% white
Religion: 47.5% Church of England, 38.2% other Protes-
tant, 10.2% Catholic, 4.1% other
Language: English
Literacy: virtually 100%
Labor force: 25,200 (1975)
Population: 1,282,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Bhutanese (sing., pl.); adjective—
Bhutanese
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese, 15%
indigenous or migrant tribes
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
eR ALA LAL nae Ba ake:
ek te a A a en a AT AA en en A ee ee a a A A a i.
Rte Gt ee tee oe
a ee ee eee ee ee ae eS ee ee a ee ee ee
SE er ee ee ae, ee,
ee eee ee | ee ee a a ee ee ee
et i i i in A Il
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BHUTAN/BOLIVIA
(See reference map Vil)
Religion: 75% lLamaistic Buddhism, 25% Buddhist-
influenced Hinduism
Language: Bhotias speak various Tibetan dialects, most
widely spoken dialect is Dzongkha, the official language;
Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry;
massive lack of skilled labor
Population: 5,149,000 (January 1979), average annual
growth rate 2.6% (current)
’ Nationality: noun—Bolivian(s); adjective—Bolivian
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic; active Protes-
tant minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.8 million (1977); 70% agriculture, 3%
mining, 10% services and utilities, 7% manufacturing, 10%
other
21
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BOLIVIA','757ee4bed3a8c90672354ee5a2198881e168d62c04d5bfbf4da664d0bb452fa5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e821278d0c3e16d9ea4cf067251e5fea717f27fdc42458ffee986c1f4869342',1968,'BR','Brazil','people-and-society',72,'Pacific
(See reference map til)
Organized labor: 150,000-200,000, concentrated in min-
ing, industry, construction, and transportation
Population: 122,602,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Brazilian(s); adjective—Brazilian
Ethnic divisions: 60% white, 30% mixed, 8% Negro, and
2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: 83% of the population 15 years or older (1978)
Labor force: about 30 million in 1970 (est.); 44.2%
agriculture, livestock, forestry, and fishing, 17.8% industry,
15.3% services, transportation, and communication, 8.9%
commerce, 4.8% social activities, 3.9% public administration,
5.1% other
Organized labor: about 50% of labor force; only about 1.5
million pay dues
Population: 190,000 official estimate for 1 July 1977
Nationality:. noun—Bruneian(s); adjective—Bruneian
Ethnic divisions: 52% Malays, 28% Chinese, 15%
indigenous tribes, 5% other
25
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BRUNEI/BULGARIA
ARR
South China Sea We Dy
: BRUNEI
Bandar Seri Begawa''
0
INDONESEA
(See reference map Vil}
Religion: 60% Muslim (Islam official religion); 8%
Christian; 32% other (Buddhist and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture; 32.8% industry,
manufacturing, and construction; 33.8% trade, transport,
services; 2.9% other
Organized labor: 8.4% of labor force
Population: 7,665,000, excluding nomadic Indian tribes,
‘(January 1979), average annual growth rate 3.0% (current)
Nationality: noun—Ecuadorean(s); adjective—Ecuador-
ean
55
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Population: 388,000 (January 1979), average annual
growth rate 1.5% (1-68 to 1-77)
Nationality: noun—Surinamer(s); adiective—Surinamese
Ethnic divisions: 31% Creole (Negro and mixed), 37%
Hindustani (East Indian), 15.3% Javanese, 10.3% Bush
Negro, 2.6% Amerindian, 1.7% Chinese, 1.0% Europeans,
1.7% other and unknown
Religion: Hindu, Muslim, Roman Catholic, Moravian,
other
Language: Dutch official; English widely spoken; Sranan
Tongo (Surinamese, sometimes called Taki-Taki) is native
language of Creoles and much of the younger population,
_and is lingua franca among others; Hindi; Javanese
Literacy: 80%
Labor force: 118,000
Organized labor: approx. 33% of labor force','058b2431a9b74e6d5fa795487e33b08789c7b653c284ae9b639332b0320e19ed','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9870cb43f76ace8efa4f4848ac78a40aafd97dd823802d19523d96224714c928',1968,'BW','Botswana','people-and-society',77,'Population: 760,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Botswana (sing.), Batswana (pl.);
adjective—Botswana
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% Euro-
pean :
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 32% in Tswana; less
than 1% secondary school . graduates
Labor force: 385,000; most are engaged in cattle raising
and subsistence agriculture; about 51,000 in internal cash
economy, another 60,000 spend at least 6 to 9 months per
year as wage earners in South Africa (1971)
Organized labor: eight trade unions organized with a total
membership of approximately 9,000 (1972 est.)
Population: 7,431,000 (January 1979), average annual
growth rate 3.5% (current)
Nationality: noun—Rhodesian(s); adjective—Rhodesian
Ethnic divisions: 96% African, less than 4% European,
less than 0.5% coloreds and Asians
Religion: 51% syncretic (part Christian, part animist),
24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and Sindebele also
widely used
Literacy: 25%-30%; of whites, nearly .100%
Labor force: (1972) 778,000 Africans (including some
migrants from Zambia and Malawi), 108,000 Europeans,
Asians, and coloreds (people of mixed heritage); 35%
agriculture, 25% mining, manufacturing, construction, 40%
transport and services
Organized labor: about one-third of. European wage
earners are unionized, but only a small minority of Africans
(1966)','493f2d6b76af1981bc2c869398669eb52fe6576f3365082824f703ca6f77af5f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad61ada4a3456202f71e91a059b7d70a78c6b1107fcfe6735700131826fbcf0d',1968,'RO','Romania','people-and-society',80,'Black Sea
(See reference map 1V)
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.4 million; 14% agriculture, 38.6% industry,
11% services, 36.4% construction, communications and
others
Population: 21,964,000 (January 1979), average annual
growth rate 0.8% (current)
Nationality: noun—Romanian(s); adjective—Romanian
Ethnic divisions: 87% Romanian, 8% Hungarian, 2%
German, 3% other
Religion: 14 million Romanian Orthodox, 1 million
Roman Catholic, 1 million Protestants, 60,000 Jews, 30,000 "
Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.2 million (1975); 38% agriculture, 31%
industry, 31% other nonagricultural','dcfe6e9c7029c073414cf8f4bb3bc33aaefab316164bd30accd328869076e8f1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcc44b967e12ddf9f437ab16b076df708c716c91c2ae8f2c2650fbbb57710be8',1968,'BI','Burundi','people-and-society',82,'Population: 4,263,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Burundian(s); adjective—Burundian
Ethnic divisions: Africans—85% Hutu (Bantu), 14% Tutsi
(Hamitic), 1% Twa (Pigmy); other Africans include perhaps
50,000 Zairians and 40,000 Rwandans; non-Africans include
about 3,000 Europeans and 1,000 South Asians
Religion: about 60% Christian (53% Catholic, 7%
Protestant); rest mostly animist plus perhaps 2% Muslims
~ TANZANIA
LO
{See reference map Vi)
Language: Kirundi and French official plus Swahili
(along Lake Tanganyika and in the Bujumbura area)
Literacy: about 15% in Kirundi, 3% in French, no
serviceable estimate for Kiswahili
Labor force: about 2 million (1976 est.)
_ Organized labor: sole group is the. Union of Burundi
Workers (UTB); by charter, membership is extended to all
Burundi workers (informally); figures denoting “‘active
membership” have been unobtainable','95a3ea14edc16e612b126fa75ee0933f4eaeac38af3f313febb989753f082366','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6616c6a2d0c01feff8068c94aab3d979a29ab90b9c7b7c067b9bf475660480a3',1968,'GA','Gabon','people-and-society',87,'Population: 8,088,000 (January 1979), average annual
growth rate 2.0% (current)
Nationality: mnoun—Cameroonian(s); adjective—Came-
roonian
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroon Highlanders, 19% Equatorial
Bantu, 8% Northwestern Bantu, 10% Fulani, 7% Eastern
Nigritic, 11% Kirdi, 13% other African, less than 1%
non- African ;
Religion: about one-half animist, one-third Christian; rest
Muslim
Language: English and French official, 24 major African
language groups ;
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence
agriculture and herding; 200,000 wage earners (maximum)
including 22,000 government employees, 63,000 paid
agricultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force
Population: 575,000 (January 1979), average annual
growth rate 1.7% (7-66 to 7-70)
Nationality: noun—Gabonese (sing., pl.); adjective—
Gabonese ;
Ethnic divisions: about 40 Bantu tribes, including 4 major
tribal groupings (Fang, Eshira, Mbede, Okande); about
100,000 expatriate Africans and Europeans, including 30,000
French
Religion: 55% to 75% Christian, less than 1% Muslim,
remainder animist
Language: French official language and medium of
instruction in schools; Fang is a major vernacular language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are wage
earners in the modern sector
Organized labor: less than 30% of wage labor force
Population: 576,000 (January 1979), average annual
growth rate 2.7% (7-76 to 7-77)
Nationality: noun—Gambian(s); adjective—Gambian
Ethnic divisions: over 99% Africans (Mandinka 40.8%,
Fulani 13.5%, Wolof 12.9%, remainder made up of several
smaller groups), fewer than 1% Europeans and Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Mandinka and Wolof most
widely used vernaculars
Literacy: about 10%
71
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
THE GAMBIA/GERMAN DEMOCRATIC REPUBLIC
Labor force: approx. 165,000, mostly engaged in subsist-
ence farming; about 15,000 are wage earners (government,
trade, services)
Organized labor: 25% to 30% of wage labor force at most
Population: 16,783,000, including East Berlin (January
1979), average annual growth rate 0.1% (current)
Nationality: noun—German(s); adjective—German
Ethnic divisions: 99.7% German, .3% Slavic and other
Religion: 58% -Protestant, 8% Roman Catholic, 39%
unaffiliated or other; less than 5% of Protestants and about
25% of Roman Catholics actively participate
Language: German, small Sorb (West Slavic) minority
Literacy: 99%
Labor force: 8.2 million; 34.1% industry; 4.7% handi-
crafts; 6.8% construction, 11.9% agriculture; 6.8% transport
and communications; 10.1% commerce; 16.8% services; 2.5%
other
Organized labor: 87.7% of total labor force
Population: 61,262,000, including West Berlin (January
1979), average annual growth rate —0.1% (current)
Nationality: noun—German(s); adjective—German
Ethnic divisions: 99% Germanic, 1% other
Religion: 48.9% Protestant, 44.7% Roman Catholic, 7.7%
other (as of 1975)
Language: German
Literacy: 99%
74
Labor force: 26.7 million; 42.9% in manufacturing and
construction, 18.0% services, 12% commerce, 9.9% govern-
ment, 6.3% agriculture, 5.9% communication and transpor-
tation, 1% mining; 4.2% average unemployed as of 1977,
excluding self employed
Organized labor: 32.6% of total labor force; 41.4% of
wage and salary earners
Population: 82,000 (January 1979), .average annual
growth rate 1.2% (current)
Nationality: noun—Sao Tomean(s): adjective—Sao
Tomean ; .
Ethnie divisions: native Sao Tomeans, migrant Cape
Verdians, Portuguese °.
Religion: Roman -Catholic,
Seventh Day Adventist
Language: Portuguese official
Literacy: estimated at 5%-10%
Evangelical Protestant,
180
Labor force: most of population engaged in subsistence
agriculture and fishing; nearly half the island’s work force,
about 10,000 people, are unemployed, the other half work
on cocoa plantations','9f654fba3c0da45520df3ba7d34ebce3b9a57d7dec800c4b2aa8a60889dcd63c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('144f41b41b291b75aedb8cb5958a2d3d4c8a1645bd1773fc8dac8af953428583',1968,'CA','Canada','people-and-society',91,'Population: 23,712,000 (January 1979), average annual
growth rate 1.1% (1-77 to 1-78)
Nationality: noun—Canadian(s); adjective—Canadian
Ethnic divisions: 44% British Isles origin, 30% French
origin, 26% other - :
” Religion: 48% Protestant,. 47% Catholic, 5% other
31
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Language: English and French official
Labor force: 11.1 million; 29% service, 22% manufactur-
ing, 16% trade, 8% transportation and utilities, 6% agricul-
ture, 6% construction, 8% other; 8.5% unemployment
(September 1978)
Organized labor: 30% of labor force
Population: 318,000 (January 1979), average annual
growth rate 1.9% (12-70 to 7-76)
Nationality: noun—Capeverdean(s); adjective—Capever-
dian
Ethnic divisions: about 28% African; 70% mulatto; 2%
European
Religion: Catholicism, fused with local superstitions
Language: Portuguese and crioula, a blend of Portuguese
and West African words,
Literacy: 14% .
Labor force: bulk of population engaged in subsistence
agriculture
Population: 1,934,000 (January 1979), average annual
growth rate 2.38% (current)
Nationality: noun—Central African(s); adjective—Cen-
tral African
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and_ linguistic
characteristics; Banda (32%) and Baya-Mandiia (29%) are
largest single groups; 6,500 Europeans, of whom 6,000 are
French and majority of the rest Portuguese
Religion: 40% Protestant, 28%-Catholic, 24% animist, 8%
Muslim; animistic beliefs and practices strongly influence
the Christian majority
, Language: French official; Sangho, lingua franca and
national language |
Literacy: estimated at 5%-10%
* ’ Labor force: about half the population economically
active, 80% of whom are in agriculture; approximately
64,000 salaried workers
Organized labor: 1% of labor force
Population: 4,472,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: noun—Chadian(s); adjective—Chadian
Ethnic divisions: over 240 tribes representing 12 major
ethnic groups—Muslims (Arabs, Toubou, Fulani, Kotoko,
Hausa, Kanembou, Baguirmi, Boulala, and Wadai) in the
north and center and non-Muslims (Sara, Mayo-Kebbi, and
Chari) in the south; some 150,000 nonindigenous, 5,000 of
them French
Religion: about half Muslim, 5% Christian, remainder
animist
Language: French official; Chadian Arabic is lingua
franca in north, Sara and Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically
active group, of which 90% are engaged in unpaid
subsistence farming, herding, and fishing; 47,000 wage
earners in industry and civil service
Organized labor: about 20% of wage labor force','09e8debd1ee77ca6b2238ccb2a5c38af2b780ed2c26fb2268e8eef54841ed71e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('464ffd14ea2c54a5612e34e6c2aad988b8fb3e68bb9f8e73fa9c14c7b874cd84',1968,'CL','Chile','people-and-society',95,'Population: 10,770,000 (January 1979), average annual
.-growth rate 1.5% (current)
Nationality: noun—Chilean(s); adjective—Chilean
.Ethnic. divisions: 95% European stock and mixed
European with some Indian admixture, 3% -Indian, 2% other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 90% (1977)
Labor force: 3.7 million economically active (1977); 30%
agricultural, 29% industry and construction, 7% services,
10% commerce, 7% mining, 9% transportation, 8% other
(1977)
Organized labor: 25% of labor force (1973)','ada27ae09446c1e38106a8e8746a3860796d6b9ea328b0f588714b759a8258d0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10b457d1766fa175c6b4e682d01edaf30f5411732ae04ec01d8ae33d5c4482de',1968,'CN','China','people-and-society',99,'Population: 1,014,074,000 (January 1979), average annual
growth rate 1.9% (current)
Nationality: noun—Chinese (sing., pl.); adjective—
Chinese
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur,
Hui, Yi, Tibetan, Miao, Manchu, Mongol, Pu-I, Korean, and
numerous lesser nationalities
Religion: most people, even before 1949, have been
pragmatic and eclectic, not seriously religious; most impor-
tant elements of religion are Confucianism, Taoism,
Buddhism, ancestor worship; about 2%-3% Muslim, 1%
Christian
Language: Chinese (Mandarin mainly; also Cantonese,
Wu, Fukienese, Amoy, Hsiang, Kan, Hakka dialects), and
minority languages (see ethnic divisions above)
Literacy: at least 25%
38
Labor force: 335 million (mid-1966); 85% agriculture,
15% other; shortage of skilled labor (managerial, technical,
mechanics, etc.); surplus of unskilled labor
Population: 17,124,000, excluding the population of
Quemoy and Matsu Islands and foreigners (January 1979),
average annual growth rate 1.8% (1-77 to 1-78)
Nationality: noun—People of Taiwan; adjective—Taiwan
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese,
2% aborigines
* Religion: 98% mixture of Buddhism, Confucianism, and
Taoism; 4.5% Christian; 2.5% other
Language: Chinese Mandarin (official language), also
Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 6.12 million (1978); 26.2% primary industry
(agriculture), 39% secondary industry (including manufac-
turing, mining, construction), 34.8% tertiary industry (in-
cluding commerce and services) 1977; 2% unemployment
(1976)
39
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TAIWAN/COLOMBIA
Organized labor: about 12% of 1972 labor force
(government controlled)
Population: 39,206,000 (January 1979), average annual
growth rate 1.7% (current)
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: homogeneous; smal] Chinese minority
(approx. 20,000)
Religion: strong Confucian tradition; pervasive folk
religion (Shamanism); vigorous Christian minority (16.6%
Christian population); Buddhism (including estimated
20,000 members of Soka Gakkai); Chondokyo (religion of
the heavenly way), eclectic religion with nationalist over-
tones founded in 19th century, claims about 1.5 million
adherents
Language: Korean
Literacy: about 90%
Labor force: about 12.9 million (1977); 42% agriculture,
fishing, forestry; 22% mining and manufacturing; 36%
services and other; average unemployment 3.8% (1977)
Organized labor: about 13% of nonagricultural labor
force','e12c6344322d725f03b8efcd5cd9a0cec5b18afaa7dfc6335b8292e79c244444','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('046c6bb06664d6a0dcf1fc045d3f3c08c81595720f49c43f02ebb6d2e0a606bc',1968,'CO','Colombia','people-and-society',103,'Population: 25,837,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Colombian(s); adjective—Colombian
Ethnic divisions: 58% mestizo, 20% caucasian, 14%
mulatto, 4% Negro, 3% mixed Negro-Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture, 13%
manufacturing, 18% services, 9% commerce, 13% other
(1964); 10%-13% unemployment (1975)
Organized labor: 13% of labor force (1968)
Population: 249,000 (January 1979), average annual
growth rate 1.3% (1-76 to 1-77)
Nationality: noun—Netherlands Antillean(s); adjective—
Netherlands Antillean
Ethnic divisions: racial mixture with African, Caribbean
Indian, European, Latin, and oriental influences; negroid
characteristics are dominant on Curacao, Indian on Aruba
Religion: predominantly Roman Catholic; sizable Protes-
tant, smaller Jewish _minorities
Language: officially Dutch; Papiamento, a Spanish-
Portuguese-Dutch-English dialect predominates; English
widely spoken
Literacy: 95%
Labor force: 76,000 (1972); 2% agriculture, 20% industry,
10% construction, 65% government and services, 3% other
Organized labor: 60%-70% of labor force','b70b11db19e70a318bf6e80b0e715fa375e5b41de4b821233eac9cb4728f9055','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('662e149b92c1ca6cebcd95a851a1ccde7cc5e65e5bbcf1b96c5711ea06635f8e',1968,'KM','Comoros','people-and-society',107,'-Population: 320,000 (January 1979), average annual
growth rate 2.1% (current)
_ Nationality: noun—Comoran(s); Sdiseive- Comoran
42
January 1979
Indian Ocean
Moroni, ComoRoS ‘
-4
.
Population: 1,484,000 (January 1979),. average annual
growth rate 2.7% (current).
Nationality: noun—Congolese (sing., pl.); adjective—
Congolese or Congo
‘Ethnic divisions: about 15 ethnic groups divided into
some 75 tribes, almost all Bantu; most important ethnic
groups are Kongo (48%) in south, Teke (17%) in center,
M’Bochi (12%) and Sangha (20%) in north, about 8,500
Europeans, mostly French
Religion: about half animist, half nominally Christian, less
than 1% Muslim
Language: French official, many African languages with
Lingala and Kikongo most widely used
Literacy: about 20%
Labor force: about 40% of population economically
active, most engaged in subsistence agriculture; 79,100 wage
earners; 40,000-60,000 unemployed.
Organized labor: 16% of total labor force (1965 est.)','4a330afdf7b8e03717e1e092fb1a6ebf0298677831506c4cc6408e44e00a662c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63b1565fc8f3c49ab48861b31c272de62755c7939439b10a14af9c05debad8c7',1968,'MG','Madagascar','people-and-society',108,'(See reference map Vi}
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
" Literacy: presumably low
Labor force: mainly agricultural','9e8c65e2411252914935ab1b1e191b8d6be5ea6fc8a49cfb6e11f615af10b582','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9d36ccc0ac5caf50163a81f46f58c07c3e4a37f03e7e38c02a23fe1ed50cd51',1968,'CK','Cook Islands','people-and-society',113,'Population: 18,000 (total from the census of 1 December
1976)
Nationality: noun—Cook Islander(s); adjective—Cook
Islander ;
Ethnic divisions: 81.3% Polynesian (full blood), 7.7%
Polynesian and European, 7.7% Polynesian and other, 2.4%
European, 0.9% other
Religion: Christian, majority of populace members of
Cook Islands Christian Church','511ba9476ca78dd38f25177836b9d963b74d53f23b23cf221f60b6a9d8fe4009','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6eb58f6784d45cf21a3c9e7f4e187c2f0ea7de61f00bab65bcb771d5540ba835',1968,'CR','Costa Rica','people-and-society',117,'Population: 2,144,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: noun—Costa Rican(s); adjective—Costa
Rican
{See reference map fl)
Ethnic divisions: 98% white (including mestizo), 2%
Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 90%
Labor force: 657,709 (1976); 32.6% agriculture; 13.8%
manufacturing; 15.3% commerce; 6.1% construction; 5.2%
transportation, utilities; 20.3% service (government, educa-
tion, social); 0.5% other; 6.2% unemployment (1976)
Organized labor: about 11.5% of labor force
Population: 9,874,000 (January 1979), average annual
growth rate 1.6%. (current)
Nationality: noun—Cuban(s); adjective—Cuban
Ethnic divisions: 51% mulatto, 37% white, 11% Negro,
1% Chinese :
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
4
a ttl a i i i a a ee ae —
ee RE SE Se a ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CUBA/CYPRUS
Religion: at least 85% nominally Roman Catholic before
Castro assumed power
'' Language: Spanish
Literacy: about 96%
Labor force: 2.7 million in 1976;»33% agriculture, 17%
industry, 9% construction, 7% transportation, 32% services,
2% unemployed','604eaad25f6d5214518c9059d4202b3c1dddaebcbc36703748f1b94747a76f12','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7f1e11ad21c19d6a8a5fcdee93ca296759d8c08a2067d8701a94d0c759a725a',1968,'CY','Cyprus','people-and-society',121,'Population: 642,000 (January 1979), average annual
growth rate 0.2% (7-76 to 7-77)
Nationality: noun—Cypriot(s); adjective—Cypriot
Ethnic divisions: 78% Greek; 18% Turkish; 4% British,
Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Maron-
ite, Armenian, Apostolic, and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Greek Sector labor force: 207,700 (1976), 22% agricul-
ture, forestry, fishing; 14% manufacturing; 6% construction;
1% mining and quarrying; 14% services; 10% trade and
finance; 3% transportation and communications; 5% public
administration, 25% other; unemployment 4% (1977)
Turkish Sector labor force: 179,400 (145,900 employed,
33,500 unemployed); 31% agriculture, 18% services, 17%
manufacturing, 12% wholesale and retail trade, 22% other
(1975)
Population: 15,189,000 (January 1979), average annual
growth rate 0.7% (current)
Nationality: noun—Czechoslovak(s); adjective—Czecho-
slovak
Ethnic divisions: 64.3% Czechs, 30.0% Slovaks, 4.0%
Magyars, 0.6% Germans, 0.5% Poles, 0.4% Ukrainians, 0.2%
others (Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant, 2%
Orthodox, 1% other
49
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CZECHOSLOVAKIA
REPUBLIC CZECHOSLOVAKIA
OF GERMANY','bdf026027aec3b26e7e2067628cc7767a2d4544cd6d69f6114386bd8d9482341','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f18a64d016c72f0c7b9cc4a8bec1f9e67421a09ef2bfe66a6a035939b4e52531',1968,'DK','Denmark','people-and-society',127,'Population: 5,112,000 (January 1979), average annual
growth rate 0.3% (current)
Nationality: noun—Dane(s); adjective—Danish
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 1% other
Language: Danish; small German-speaking minority
Literacy: 99% ,
Labor force: 2,579 million (October 1977); 8.6% -agricul-
ture, forestry, fishing, 24.6% manufacturing, 8.1% construc-
tion, 15.4% commerce, 6.6% transportation, 5.4% services, .
29.3% government, 2.0% other; 6.4% (164,000) registered
unemployed as percentage of total labor force (1977 annual
average)
Organized labor: 65% of Jabor force','64c88a59aaea3b0f16bad1b3dd2212edeaed6d428e9b163b948f6b3121898d55','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c27625391c4c759c3ad9dd57714450b73508ae089ed94728fee13239e41f27ac',1968,'DM','Dominica','people-and-society',134,'Population: 78,000 (January 1979), average annual
growth rate 0.7% (1-75 to 1-77)
Nationality: noun—Dominican(s); adjective—Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist ‘
Language: English; French patois
Literacy: about 80%
Labor force: 23,000; about 50% in agriculture; 24%
unemployment
Organized labor: 25% of: the labor force','8ccaea5bae31b084d182236cb55958b29523c2782a87da5b2787e0e78a1e11e4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd005d9bcaf1c2b4ffc50ba26175c030e7ee9c20f1d8d0f7802dc465459ae939',1968,'DO','Dominican Republic','people-and-society',138,'Population: 5,466,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Dominican(s); adjective—Dominican
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.3 million; 73% agriculture, 8% industry,
19% services and other
Organized labor: 12% of labor force','71d384beb24332779497dfa64c69f857bea20c946fa880df4cc0b1fec03ba3c2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d299e1b229172f4b58dccd88f1fe325bbf506c11750fe836391b289fd29dd70',1968,'EC','Ecuador','people-and-society',142,'Ethnic divisions: 40% mestizo, 40% Indian, 10% white,
5% Negro, 5% Oriental and other
Religion: 95% Roman Catholic (majority nonpracticing)
Language: Spanish, Ouschiva:
Literacy: 57% :
Labor force: 2 million, of which 56% agriculture, 13%
manufacturing, 4% construction, 7% commerce, 4% public
administration, 16% other servicés and activities
Organized labor: less*than 15% of labor force
Population: 40,424,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: noun—Egyptian(s); adjective—Egyptian or
Arab Republic of Egypt
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek,
Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt and
other
Language: Arabic official, English and French widely
understood by educated classes
Literacy: around 40%
Labor force: 12 million; 45 to 50% agriculture, 10%
industry, 10% trade and finance, 30% services and other;
shortage of skilled labor
Organized labor: 1 to 3 million','ca8ed967ff99e7b1f1e6f6c046ebe8dc606a0647460bcf8efa92d82347d7c675','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f11c44db637b186fa2d38d3e8cfe77bcffdfbf532fc0dda0d7cc6838fcc10f2',1968,'SV','El Salvador','people-and-society',146,'Population: 4,580,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Salvadoran(s); adjective—Salvadoran
58
HONDURAS.
NICARAGUA |
(See reference map ti)
Ethnic divisions: 84%-88% mestizo; Indian and white
minorities, 6%-8% each a
Religion: predominantly. Roman Catholic, probably
97%-98%
Language: Spanish
Literacy: 50% literacy in urban areas, 30% in rural areas
Labor force: 1,500,000 (est. 1977); 57% agriculture, 14%
services, 14% manufacturing, 6% commerce, 9% other;
shortage of skilled labor and large pool of unskilled labor,
but manpower training programs improving situation
Organized labor: 5% of total labor force; 10% of
nonagricultural labor force (1977)','2cef4da3c9cb2b0f02a78e32e229db82ddb5c33d157c732eef9bd04d20be92ce','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a652dd87d8cc9b923709e3833f6e3f68a9b0037af54a5f54045cbc6ebff90926',1968,'CM','Cameroon','people-and-society',149,'Population: 339,000 (January 1979), this estimate does not
take into account emigration from Equatorial Guinea during
the last several years, average annual growth rate 1.8% (7-68
to 7-69); Rio Muni, 237,000, average annual growth rate
1.5% (7-68 to 7-69); Fernando Po, 102,000, average annual
growth rate 2.6% (7-68 to 7-69)
Nationality: noun—Equatorial Guinean(s); adjective—
Equatorial Guinean
Ethnic divisions: -indigenous population of Province
Macias Nguema Biyogo, primarily Bubi, some Fernandinos;
of Rio Muni primarily Fang; less than 1,000 Europeans,
primarily Spanish
Religion: natives all nominally Christian and predomi-
nantly Roman Catholic; some pagan practices retained
Language: Spanish official language of government and
business; also pidgin English, Fang
Literacy: 20% ;
Labor force: most Equatorial Guineans involved in
subsistence agriculture','88e5a61c6dad7d3d9e1feacd8f7f9dd4a17955175d76b854e6ccadf07dce0212','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f557f33d0a1cec12eecc6adafe7f95024dde5b6a77fc1cd85954d3436a3b7477',1968,'ET','Ethiopia','people-and-society',153,'Population: 31,341,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Ethiopian(s); adjective—Ethiopian
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
fa Pret
a Oe VP” Oe aE OES OO
4
ALAA
RA MAL RL ARAL AA RA RA Rk AN ek NR A AN ERA A AR AAR AA Ae
a
SS es ee me ee
| Sait Ae tar a
!
bi. ss i A eo AU te, A Ria Sa Re A i i ll Ee a A ee ll lle ee, a
i a A dE I el Mi ee ee ii Se a i A ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
(See reference map Vi}
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%,
Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%, Gurage 2%,
other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Mus-
lims, 15%-20% animist, 5% other :
Language: Amharic official; many local languages and
dialects; English major foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10%
government, military, and quasi-government
Organized Jabor: All Ethiopian Trade Union formed
January 1977 to represent 273,000 registered trade union
members','b120e4ff77dba8e6b1e667de35faac370f140bce46197e39879a8642a5c37fd5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b93e43fbf83402e0d2b31f6a4e844438ed6f416ceb5b95b47c73486d04e442ea',1968,'FO','Faroe Islands','people-and-society',159,'Population: 43,000 (January 1979), average annual
growth rate 1.4% (1-75 to 1-77) :
Nationality: noun—Faroese (sing., pl.); adjective—
Faroese
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faroese (derived from Old Norse), Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufac-
turing, transportation, and commerce','7a948852209e9f8fd0735279ec605688dd7df799f2a93f8fb2dad05e6a3ee815','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b994d283d2b5597d96060ae02f8bf4363f6700defca64005ff00b6ba85c628aa',1968,'FI','Finland','people-and-society',163,'Population: 4,755,000 (January 1979), average annual
growth rate 0.3% (1-77 to 1-78)
Nationality: noun—Finn(s); adjective—Finnish
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox,
1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and
Russian-speaking minorities
Literacy: 99%
Labor force: 2.2 million; 16.6% agriculture, forestry, and
fishing, 26.4% mining and manufacturing, 8.4% construc-
tion, 15.4% commerce, 6.8% transportation and communica-
tions, 4.0% banking and finance, 20.1% services; 6.1%
(186,000) unemployed 1977 annual coverage
Organized labor: 60% of labor force','94b4d640ee63af9fde02e8cfe3f7e3807bb33ae404ed9908745ae00d81410a26','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3523bd484f927061af7950887a5ad7ca499a797242e13766f59e8a1062e4e9aa',1968,'FR','France','people-and-society',167,'Population: 53,536,000 (January 1979), average annual
growth rate 0.6% (current)
Nationality: noun—Frenchman (men); adjective—
French
Ethnic divisions: 45% Celtic; remainder Latin, Germanic,
Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1%
Muslim (North African workers), 18% unaffiliated
Language: French (100% of population); rapidly declin-
ing regional patois—Provencal, Breton, Germanic, Corsican,
Catalan, Basque, Flemish
Literacy: 97%
Labor force: 22 million (est. in mid-1977); 47% services,
38% industry, 11% agriculture, 5% unemployed
Organized labor: approximately 17% of labor force, 23%
of salaried labor force’
Population: 3,242,000 (January 1979), average annual
growth rate 1.0% (7-75 to 7-77)
Nationality: noun—Irishman(men), Irish (collective pl.);
adjective—Irish
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 2% other
Language: English and Gaelic official; English is gen-
erally spoken
Literacy: 98%-99%
Labor force: about 1,143,000 (1976); 26% agriculture,
forestry, fishing; 19% manufacturing; 15% commerce; 7%
construction; 5% transportation; 4% government; 24% other;
9.8% unemployment (February 1976)
Organized labor: 36% of labor force
Population: 358,000 (January 1979), average annual
growth rate 0.4% (current)
Nationality: noun—Luxembourger(s); adjective—Luxem-
bourg
Ethnic divisions: 83% Luxembourger, including an
estimated 5% of Italian descent; remainder French, German,
Belgian, etc. ;
Religion: 97% Roman Catholic, remaining 3% Protestant
and Jewish :
Language: Luxembourgish, German, French; most edu-
cated Luxembourgers also speak English
Literacy: 98%
Labor force: (1977) 147,300; one-third of labor force is
foreign, comprised mostly of workers from Portugal, Italy,
France, Belgium, and West Germany (1977); unemployment
0.2% (1977)','52af2b0b382ad9718123d5d3a85297115f17570aef030d868753f4517b5a5deb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0596f11ef645e1f4bbc3393edd8a26d48813e25de36b34531b8c07be89a3a6f6',1968,'GY','Guyana','people-and-society',171,'Population: 60,000 (January 1979), annual growth rate
2.2% (10-74 to 11-77)
Nationality: noun—French Guianese (sing., pl.); adjec-
tive—French Guiana
Ethnic divisions: 95% Negro or mulatto, 5% caucasian,
10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%, construc-
tion 21%, agriculture 18%, industry 8%, transportation 4%;
information on unemployment unavailable
Organized labor: 7% of labor force
Population: 818,000 (January 1979), average annual
growth rate 1.3% (current)
Nationality: noun—Guyanese (sing., pl.); adjective—
Guyanese ;
Ethnic divisions: 51% East Indians, 43% Negro and
Negro mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1%
other
Language: English
Literacy: 86% .
Labor force: 242,000 (1975); 29% agriculture, 31%
manufacturing/mining, 40% services; 21% unemployed
Organized labor: 34% of labor force','a5f51911ebaef32913c23ef37bf760bb81b501522370e1d73267d257c50ebffd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9a38f9e312b2299dd9ac6a328b011647a2e69b109bfd2fbe4f621cc8ac8e524',1968,'PF','French Polynesia','people-and-society',175,'Population: 143,000 (January 1979), annual growth rate
2.3% (current)
Nationality: noun—French Polynesian(s); adjective—
French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chinese, 6% local
French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 32% Catholic','9626f88d901fa2e43c55161f586d2c035bd4994306deef3fb8be42a429510ef7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c38dd96861db215ccfb5c3ffcefb242fade7dd43e3f77b2134e3b64f68a60cc4',1968,'GN','Guinea','people-and-society',179,'Population: 11,553,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun—Ghanaian(s); adjective—Ghanaian
Ethnic divisions: 99.8% Negroid African (major tribes
Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12% Muslim
Language: English official; African languages include
Akan 44%, Mole-Dagbani 16%, Ewe 13%, and Ga-Adangbe
8%
75
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GHANA/GIBRALTAR
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing,
16.8% industry, 15.2% sales and clerical, 4.1% services,
transportation,- and communications, 2.9% professional;
400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor
force
Population: 5,973,000 (January 1979), average arinual
growth rate 2.6% (current)
Nationality: noun—Guinean(s); adjective—Guinean
‘Ethnic divisions: 99% African (8 major tribes—Fulani,
Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less than
1%
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written
language ,
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GUINEA/GUINEA-BISSAU
Labor force: 1.8 million, of whom less than 10% are wage
earners; most of population engages in subsistence agricul-
ture
Organized labor: virtually 100% of wage labor force
loosely affiliated with the National Confederation of
Guinean Workers, which is closely tied to the PDG
Population: 5,450,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Senegalese (sing. & pl.); adjective—
Senegalese
Ethnic divisions: 36%-Wolof, 17.5% Fulani, 16.5% Serer,
9% Tukulor, 9% Dyola, 6.5% Malinke, 4.5% other African,
1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly
Roman Catholic)
182
Language: French official, but regular use limited to
literate minority; most Senegalese speak own tribal language;
use of Wolof vernacular spreading—now spoken to some
degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence agricul-
tural workers; about 170,000 wage earners
Organized labor: majority of wage-labor force repre-
sented by unions; however, dues-paying membership very
limited, three labor central] unions, major central is CNTS,
an affiliate of governing party','57b95551dd421a23304b3f3762126c126c7e789ede67e09014f4348f57366c82','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d76908e45226424dece91681d073699d3f9ae9368c52ae3d4ee1d1736a092674',1968,'GI','Gibraltar','people-and-society',183,'Population: 30,000 (official estimate for 1 July 1977)
Nationality: noun—Gibraltarian; adjective—Gibraltar,
Ethnic divisions: mostly Italian, English, Maltese, Portu-
guese and Spanish descent
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GIBRALTAR/GILBERT ISLANDS
Atlantic Ocean','30cbb791d3e85520367c2191118f94e903035a60d1952ba19acbc707c96dff32','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5a12d204b3e294c24055d06407b398aecd639de91f3b0d32bad0dcb25f9799e',1968,'GR','Greece','people-and-society',185,'Population: 9,372,000 (January 1979), average annual
growth rate 0.6% (7-67 to 7-77)
Nationality: noun—Greek(s); adjective—Greek
Ethnic divisions: 96% Greek, 2% Turkish, 2% other
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total
about 82%
Labor force: 3,400,000 (1975 est.); 40.5% agriculture,
25.6% industry, 33.7% services; unemployment 3%, but there
is substantial underemployment in agriculture
Organized labor: 20% of labor force est.','3ba7d8d2b8201f004a597b7495a81bad8a9a51a7f37343f09ac949685fffe1b7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1ace11005cda403f26f7f42a86856bcd33d18fa296796f1a0e8978ba7436871',1968,'GL','Greenland','people-and-society',189,'Population: 50,000 (January 1979), average annual
growth rate 0.2% (1-75 to 1-77)
80
Nationality: noun—Greenlander(s); adjective—Green-
land
Ethnic divisions: 86% Greenlander (Eskimos and Green-
Jand-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep
breeding','0f614e969f2a9f6dbffb159cc78c6781e6ac88cfb2af3e39a30aca1881a4c0b0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04bf09e3e3fc6eedaf9c5ad59715b97710dae4fff8b9cd1bfc2c54ab6bb36d5c',1968,'GD','Grenada','people-and-society',193,'Population: 106,000 (January 1979), average annual
growth rate 1.4% (4-70 ‘to 7-77)
Nationality: noun—Grenadian(s); adjective—Grenadian
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects;
Roman Catholic
Language: English; some French _ patois
Literacy: unknown
Labor force: 27,314 (1960); 40% agriculture, 30%
unemployed or underemployed
Organized labor: 33% of labor force','45cd8f8204ccbfa0148db208ad939642a046114cf21e45b00b24141be6c8c59a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba456d71a38e0172d35a252dc445b9f90a4ce8b1992fe6a116b2ff4bd53c61d0',1968,'GP','Guadeloupe','people-and-society',197,'Population: 324,000 (January 1979), average annual
growth rate 0.3% (10-67 to 1-76)
Nationality: noun—Guadeloupian(s); adjective—Guade-
loupe
Ethnic divisions: 90% Negro or Mulatto, less than 5% East
Indian, Lebanese, Chinese, 5% Caucasian ,
82
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force','6aa25801fec8d40657e64a078788593ec29f85df4a333cdad74cae1277e661f4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c7d6608da3e73eaa5904704348e6d905c91ff5d30392d9d139cdb42fd2e4b0a',1968,'MX','Mexico','people-and-society',200,'Population: 6,716,000 (January 1979), average annual
growth rate 2.9% (7-76 to 7-77)
Nationality: noun—Guatemalan(s); adjective—Guatema-
lan
Ethnic divisions: 41.4% Indian, 58.6% Ladino (mestizo
and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks
an Indian language as a primary tongue
Literacy: about 50%
Labor force (1974): 1.8 million; 52.5% agriculture, 10.1%
manufacturing, 21.7% services, 7.9% commerce, 3.9%
construction, 2.1% transport, 0.7% mining, 1.2% electrical,
0.8% other. Unemployment estimates vary from 3% to 25%
Organized labor: 6.4% of labor force (1975)
Population: 66,938,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun—Mexican(s); adjective—Mexican
Ethnic divisions: 60% mestizo, 30% Indian or predomi-
nantly Indian, 9% white or predominantly white, 1% other
Religion: 97% nominally Roman Catholic, 3% other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force: 17.6 million (1977) (defined as those 12 years
of age and older); 33.0% agriculture, 16.0% manufacturing,
16.6% services, 16.8% construction, utilities, commerce, and
transport, 3% government, 5.4% unspecified activities; 10%
unemployed, 40% underemployed
Organized labor: 20% of total labor force','36f887d5491460d92c72a8f6b5a6444372596da506433fb21498f6da3d613b39','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1f0ef150974664bd8814e8ee69a2db2325af6287fdd4395e703f12e0178a1d7',1968,'GW','Guinea-Bissau','people-and-society',204,'Population: 625,000 (January 1979), average annual
growth rate 1.7% (current)
Nationality: noun—Guinean(s); adjective—Guinean
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes);
less than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
85
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GUINEA-BISSAU/GUYANA
Se
Atlantic Ocean
(See reference map Vi}
Language: Portuguese and numerous African languages
Literacy: 3% to 5%
Labor force: 90% of economically active population
engaged in subsistence agriculture','133dc8294a34cd5ddc1cdf26910767de0bea110f99a4ed4dd097ea70b5598da4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8c5010131b007ef87ffa058a00472c1d2eb6052fda8ca44b52fb42b383f7438',1968,'PH','Philippines','people-and-society',208,'Population: 4,622,000 (January 1979), average annual
growth rate 1.6% (7-76 to 7-77)
Nationality: adjective—Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local
~ religions
Language: Chinese, English
Literacy: 75%
Labor force (1976 Census): 1.87 million; 45.3% manufac-
turing, 18.6% services, 6.0% construction, mining, quarrying
and utilities, 19.4% commerce, 2.6% agriculture, forestry,
fisheries, and hunting, 7.3% communications, 0.7% other;
underemployment is a serious problem
Organized labor: 21% of 1976 labor force
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
HONG KONG/HUNGARY
Population: 285,000 (January 1979), average annual
growth rate 1.5% (current)
Nationality: noun—Macaon(s); adjective—Macaon
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about
one-half are Chinese
Language: 98% Chinese, 2% Portuguese
Literacy: almost 100% among Portuguese and Macanese;
no data on Chinese population
Labor force: 5% agriculture, 30% manufacturing, 3%
construction, 1% utilities, 27% commerce, 8% transportation
and communications, 26% services (1960 data)
Population: 46,388,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Filipino(s); adjective—Philippine
Ethnic divisions: 91.5% Christian Malay, 4% Muslim
Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4%
Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national
language of the Philippine Republic; English is the language
of school instruction and government business
Literacy: about 83%
Labor force: 15.4 million (1976); 60% agriculture,
forestry, fishing, 12% manufacturing, 10.5% commerce,
166
January 1979
10.5% government and services (business, recreation, domes-
tic, personal), 3.5% transport, storage, communication, 3%
construction; 0.5% other','77379b1c1ac1a12b914f6f3bacc933707fc43bb81c89ac21a6ce20a5b0c5bafa','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('673ad1b24306315535e7db8cf85d9633b30921f0721e7cdab4f0e4945143b2e1',1968,'HU','Hungary','people-and-society',213,'Population: 10,715,000 (January 1979), average annual
growth rate 0.4% (current)
Nationality: noun—Hungarian(s); adjective—Hungarian
Ethnie divisions: 92.4% Magyar, 2.5% German, 3.3%
Gypsy, 0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20.0% Calvinist, 5.0%
Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5,230,000 (1977); 20% agriculture, 34%
industry and building, 46% other non-agriculture
91
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
{See reference map IV}','3ac7cd669526bb59d4899b147992032972ac07afc075a30b933b170cd968fb4d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f6526b97318549f47423b25fcdd1e8db86dd01459557a7f2f3cd663eb8d400e',1968,'IS','Iceland','people-and-society',217,'Population: 224,000 (January 1979),. average annual
growth rate 0.7% (12-76 to 12-77) :
Nationality: noun—Icelander(s); adjective—Icelandic
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 90,000; 22.6% agriculture and fishing; 25.6%
mining and manufacturing; 10.7% construction; 12.8%
commerce; 7.8% transportation and communications; 15.2%
services; and 5.7% other; unemployment 1977, 0.6%
Organized: labor: 60% of labor force','057138990ef5c28a7f1afc5da930df37d46d999bea587947cde0df14b1ac702a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f842209d8338e889d1e27202e9720939ff17271105c5962bdeecdf208407d8a9',1968,'IN','India','people-and-society',221,'Population: 667,907,000, including Sikkim and_ the
Indian-held part of disputed Jammu-Kashmir (January
1979), average annual growth rate 2.2% (current)
Nationality: noun—Indian(s); adjective—Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3%
Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.6%
Christian, 0.7% Buddhist, 0.7% other
Language: 24 languages spoken by a million or more
persons each; numerous other languages and dialects, for the
most part mutually unintelligible; Hindi is the national
language and primary tongue of 30% of the people; English
enjoys “associate” status but is the most important language
for national, political, and commercial communication;
Hindustani, a popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Literacy: males 839%; females 18%; both sexes 29% (1971
census)
Labor force: about 197 million; 70% agriculture, more
than 10% unemployed and underemployed; shortage of
skilled labor is significant and unemployment is rising
Organized labor: about 2.5% of total labor force','40af836fd609b5c35c06069984350a89bf5236c10b16c9b135c1f8ed446ebb6c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26e8eda0303631f43eb882d922aa6b2c4d8fa35fd0523000694868835e85b6eb',1968,'IL','Israel','people-and-society',227,'Population: 3,712,000, excluding East Jerusalem and the
other occupied territories (January 1979), average annual
growth rate 2.4% (1-77 to 1-78)
Nationality: noun—Israeli(s); adjective—Israel
Ethnic divisions: 85% Jews, 15% non-Jews (mostly Arabs)
Religion: 85% Judaism, 11% Islam, 4% Christian and
other
Language: Hebrew official; Arabic used officially for
Arab minority; English most commonly used foreign
language
Literacy: 88% Jews, 48% Arabs
Labor force: 1,133,000; 6.5% agriculture, forestry and
fishing; 25.3% manufacturing (mining, industry); 0.9%
electricity and water; 8.1% construction and public works;
12.2% commerce; 7.7% transport, storage, and communica-
tions; 6.5% finance and business; 26.1% public services; 6.7%
personal and other services (1974)
Organized labor: 90% of labor force','f5d9450bc3de79c2cf4230a9c2a95ac739c973c8fca827b4d5bc543d3eb9ef62','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6ae2db2884e46b44be788e9077ac875d87c714f1ece4f11aec56fb88e3d8ac0',1968,'IT','Italy','people-and-society',231,'Population: 56,867,000 (January 1979), average annual
growth rate 0.5% (current) .
Nationality: noun—lItalian(s); adjective—Italian
Ethnic divisions: primarily Italian but population in-
cludes small clusters of German-, French-, and Slovene-Ital-
ians in the north and of Albanian-Italians in the south
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ce ae Oe Se
i Oe Oe eS ee,
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
(See reference map IV}
Religion: almost 100% nominally Roman Catholic (de
facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region
(e.g., Bolzano) are predominantly German speaking; signifi-
cant French-speaking minority in Valle d’Aosta Region;
Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5%-7% of population allterate (1972); illiteracy
varies widely by region
Labor force: 20,125,000 (July 1978); 15.0% sericea:
42.9% industry, 39.0% other (1975); 7.1% unemployment
(1978); 1.5 million Italians employed in other Western
European countries
Organized labor: 50-55% (est.) of labor force
Population: 7,365,000, resident African population only,
(January 1979), average annual growth rate 2.7% (current)
Nationality: noun—Ivorian(s); adjective—Ivorian
- Ethnic divisions: 7 major indigenous ethnic groups; no
single tribe more than 20% of population; most important
are Agni, Baoule, Krou, Senoufou, Mandingo; approximately _
2 million foreign Africans, mostly Upper Voltans; about
75,000 to 90,000 non-Africans (50,000 to 60,000 French and
25,000 to 30,000 Lebanese)
Religion: 66% animist, 22% Muslim, 12% Christian
Language: French official, over 60 native dialects, Dioula
most widely spoken
Literacy: about 65% at primary school level
Labor force: over 85% of population engaged in
agriculture, forestry, livestock raising; about 11% of labor
force are wage earners, nearly half in agriculture, remainder
in‘ government, industry, commerce, and professions
Organized -labor: 20% of wage labor force','a3b58a2525f5094a6a5e2a6fc177ba020f8e7f036da6080ed59412f9ab9290ae','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b042d0b5ca200ca3045e139c4fe9e032d1eae5bb0245d8452101d8917f84e6f',1968,'JM','Jamaica','people-and-society',235,'Population: 2,217,000 (January 1979), average annual
growth rate 1.4% (current)
Nationality: noun—Jamaican(s); . adiective—Jamaican
Ethnic divisions: African 76.3%, Afro-European 15.1%,
Chinese and Afro-Chinese 1.2%, East Indian and Afro-East
Indian 3.4%, white 3.2%, other 0.9%
105
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Atlantic
Ocean
\\ |
os
> CUBR © DOMINICAN
REPUBLIC
HAITI.
N
JAMAICA Kingston
Ba Caribbean Sea
ICARAGUA
{See reference map il}
Religion: predominantly Protestant, some Roman Catho-
lic, some spiritualist cults
Language: English
Literacy: government claims 82%, but probably only
about one-half of that number are functionally literate
Labor force: 672,000 (1975); 29% in agriculture, forestry,
fishing and mining, 12% manufacturing/mining, 8% public
administration, 5% construction, 10% commerce, 3% trans-
portation and utilities, 33% services; 25% unemployed;
shortage of technical and managerial personnel
Organized labor: about 25% of labor force (1966)
Population: 115,493,000, including Ryukyus (January
1979), average annual growth rate 1.0% (current)
Nationality: noun—Japanese (sing., pl.); adjective—
Japanese
Ethnic divisions: 99.2% Japanese, 0.8% other (mostly
Korean)
Religion: most Japanese observe both Shinto and Buddhist
rites; about 16% belong to other faiths, including 0.8%
Christian
Language: Japanese
Literacy: 97.8% of those 15 years old and above (1960
data)
‘Labor force (1977): 54.5 million; 11% agriculture
forestry, and fishing; 34% manufacturing, mining, and
construction; 48% trade and services; 5% government; 2.0%
unemployed
Organized labor: 33.7% of labor force','0cc0a76fda25b23bd767ad8d2cd3ca59282c0c33e68202d256ffa44a408d59db','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26b4d59dce8f7a7205f58e1d22992ea211c5cf6f6c1f8c80b3076326474d9748',1968,'JO','Jordan','people-and-society',239,'Population: 3,008,000, including West Bank and East
Jerusalem (January 1979), average annual growth rate 3.2%
(7-70 to 7-76); East Bank, 2,224,000, average annual growth
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
JORDAN/KAMPUCHEA
rate 3.6% (7-70 to 7-76); West Bank, including East
Jerusalem, 784,000, average annual growth rate 1.9% (1-71
to 1-77)
Nationality: noun—Jordanian(s); adjective—Jordanian
Ethnic divisions: 98% Arab, 1% Circassian, 1% Armenian
Religion: 90%-92% Sunni Muslim, 8%-10% Christian
Language: Arabic official, English widely understood
among upper and middle classes
Literacy: about 50%-55% in East Jordan; somewhat less
than 60% in West Jordan
Labor force: 638,000; less than 5% unemployed
Organized labor: 9.8% of labor force
Population: 8,087,000 (January. 1979), average annual
growth rate 1.6% (current)
Nationality: noun—Kampuchean(s); adjective—Kampu-
chean
Ethnic divisions: 90% Khmer (Kampuchean), 5% Chi-
nese, 5% other minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian','667b00f65221132f0fa8d26668d9ca172c75a678c2dbe21aff8ef9559340f236','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e6fd42a0a89eb38bb40d0ca00f113a9bf172b86eeba408215685e6695c3b05c',1968,'KE','Kenya','people-and-society',243,'Population: 15,096,000 (January 1979), average annual
growth rate 3.6% (current),
Nationality: noun—Kenyan(s); adjective—Kenyan
Ethnic divisions: 97% native African (including Bantu,
Nilotic, Hamitic and Nilo-Hamitic); 2% Asian; 1% Euro-
pean, Arab, and others
Religion: 56% Christian, 36% animist, 7% Muslim, 1%
Hindu
Language: English and Swahili official; each tribe has
own language ;
Literacy: 27%
Labor force: 2.5 million; about 977,000, (39%) in
monetary economy (1967)
Organized labor: about 215,000
Population: 18,421,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Korean(s); adjective—Korean
112
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities
now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 48% agriculture, 52% non-agri-
cultural; shortage of skilled and unskilled labor','78248f58b1640895a4676c497f8ff47e8297b7be1942099b0ee4ff3a8b149784','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5b16a5ea938bb13c0976131c678834d5549f0db768969cec1ffb91e76b53b7b',1968,'SA','Saudi Arabia','people-and-society',247,'Population: 1,241,000 (January 1979), average annual
growth rate 5.9% (current)
RE it EE
Ft i a a ae
Th,
}
ay ON ON eae ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
KUWAIT/LAOS
Nationality: noun—Kuwaiti(s); adjective—Kuwaiti
Ethnic divisions: 85% Arabs, 13% Iranians, Indians, and
Pakistani; native Kuwaitis are a minority
Religion: 99% Muslim, 1% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign
language
Literacy: about 60% _
Labor force: 340,000 (1976 est.); 26% manufacturing, 25% -
services, 35% government and professions, 9% commerce,
_ 5% oil industry; two-thirds of labor force is non-Kuwaiti
Organized labor: labor unions, first authorized in 1964,
formed in oil industry and among government personnel
. Population: 3,587,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Lao (sing., Lao or Laotian); adjec-
tive—Lao or Laotian
Ethnic divisions: 48% Lao; 14% Tribal Tai; 25%
Phoutheung (Kha); 138% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
5
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
LAOS
(See reference map Vil}
Language: Lao official, French predominant foreign
language
Literacy: about 12%
Labor force: about 1-1.5 million; 80%-90% agriculture
Organized labor: only labor organization is subordinate to
the Communist Party
(See reference mep V)
Nationality: noun—Qatari(s); adjective—Qatari
Ethnic divisions: 56% Arab; 23% Iranian; 14% Pakistani;
7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: primarily foreign
Population: 7,984,000 (January 1979), average annual
growth rate 3.1% (current)
Nationality: noun—Saudi(s); adjective—Saudi Arabian or
Saudi ,
Ethnic divisions: 90% Arab, 10% Afro-Asian (est.)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% -(est.)
Labor force: about 33% (one-half foreign). of population;
40% agriculture and herding, 12% construction, 12% service,
12% government, 11% commerce, 13% other','5f369ed115119d03da3649212cf6ee4b28d4055acb1b7558fb3bd2e9c49080e1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eba663f2099910572e1d996946aca630c044573e27a273fe82e04bfa461e60de',1968,'LB','Lebanon','people-and-society',251,'Population: 2,568,000 (January 1979), average annual
growth rate 2.3% (current)
Nationality: noun—Lebanese (sing. and pl.); adjective—
Lebanese ,
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1%
other (official estimates); Muslims, in fact, constitute a
majority :
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically. active; 49%
agriculture, 11% industry, 14% commerce, 26% other;
moderate unemployment
LAOS/LEBANON
Organized labor: about 65,000','96a91807f24aca756fbc05a1a472ec6b7155cded627becee9c1eef92a206ea05','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a258b3e918939271be7524939f0f5a56b92a42ff220841102f87dff869718d19',1968,'LS','Lesotho','people-and-society',255,'Population: 1,291,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Mosotho (sing.), Basotho (pl); adjec-
tive—Basotho
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800
Asians -
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in
subsistence agriculture; 150,000 to 250,000 spend 6 months
to many years as wage earners in South Africa
Organized labor: negligible','198d2b2b7c5c1029093b522ef47f06b59f230af81e59be17820b528ab0ff2b10','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e4796aa9c60a623bcc6c602938652e58e5de4198b2f425c54c6cfe39247e031',1968,'LR','Liberia','people-and-society',259,'Population: 1,761,000 (January 1979), average annual
growth rate 3.8% (current)
Nationality: noun—Liberian(s); adjective—Liberian
Ethnic divisions: 5% descendants of immigrant Negroes;
95% indigenous Negroid African tribes including Kpelle,
Bassa, Kru, Grebo, Gola, Kissi, Krahn, and Mandingo
Religion: probably more Muslims than Christians;
70%-80% animist
Language: English official; 28 tribal languages or dialects,
pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 600,000, of which 120,000 are in monetary
economy; about 2,000 non-African foreigners hold about
95% of the top level management and engineering jobs
Organized labor: 2% of labor force
119
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
LIBERIA/LIBYA','48f02cb723fab066d9774bb67c4b0c309eda4b44f55bf608decdacc84dce169c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0dfc380a2d0a8006e4a655930b1f508801aa2548ec8d6a5e4f958c4a9351c522',1968,'LY','Libya','people-and-society',263,'Population: 2,816,000 (January 1979), average annual
growth rate 4.1% (current)
Nationality: noun—Libyan(s); adjective—Libyan
Ethnic divisions: 97% Berber and Arab with some Negro
stock; some Greeks, Maltese, Jews, Italians, Egyptians,
Pakistanis, Turks, Indians, and Tunisians ;
Religion: 97% Muslim
'' Language: Arabic; Italian and English widely understood
in major cities
Literacy: 35%
Labor force: 900,000 of which about 350,000 are resident
foreigners (est. 1977)','58cdd651e5d28896eafb11548d57a9ab42bac8456cf43ee5463baa2f5334609f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fa25c3fc17943b0ef061b44dcaa64269f2c81d69fbc50de724027def85a73dc',1968,'LI','Liechtenstein','people-and-society',267,'Population: 22,000 (January’ 1979), average annual
growth rate 0.5% (current)
Nationality:
noun—Liechtensteiner(s); adjective—
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly from
Austria and Italy); 59% industry, 20% trade and commerce, ©
138% professional and other, 8% agriculture','1d89bd1cdad549feb2d49de19bd0691733d242e1752e54bdb8a551cd53198c2a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e3d87785bf73dcf9d93c0d0de86c858076a17cf9ab049f4d6f0851f2763b641',1968,'ZA','South Africa','people-and-society',274,'Population: 8,258,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Malagasy (sing. and pl.); adjective—
Malagasy
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting of Mer-
ina (1,643,000) and related Betsileo (760,000), on the one
hand, and coastal tribes with mixed Negroid, Malayo-Indo-
nesian, and Arab ancestry on the other; coastal tribes include
Betsimisaraka 941,000, Tsimihety 442,000, Sakalava
375,000, Antaisaka 415,000; there are also 10-12,000
European French, 5,000 Indians of French nationality, and
5,000 Creoles
Religion: more than half animist; about 41% Christian,
7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are
nonsalaried family workers engaged in subsistence agricul-
ture; of 175,000 wage and salary earners, 26% agriculture,
17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscel-
laneous
Organized labor: 4% of labor force
Population: 27,754,000, including Bophuthatswana and
Transkei (January 1979), average annual growth rate 2.5%
(7-75 to 7-76); Bophuthatswana 1,123,000 (January 1979),
average annual growth rate 2.2% (current); Transkei
2,214,000 (January 1979), average annual growth rate 2.2%
(current)
Nationality: noun—South African(s); adjective—South
African
Ethnic divisions: 17.8% white, 69.9% African, 9.4%
Colored, 2.9% Asian
Religion: most whites and coloreds and roughly 60% of
Africans are Christian; roughly 60% of Asians are Hindu,
20% are Muslim
Language: Afrikaans and English official, Africans have
many vernacular languages :
Literacy: almost all white population literate; government
estimates 50% of Africans literate
Labor force: 8.7 million (total of economically active,
1970); 538% agriculture, 8% manufacturing, 7% mining, 5%
commerce, 27% miscellaneous services
Organized labor: about 7% ‘of total labor force is
unionized (mostly white workers); relatively small African
unions have no bargaining power
Population: 2,214,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Transkeian(s); adjective—Transkeian
Ethnic divisions: 98.9% African, 0.6% white, 0.5%
colored. (mulatto); Africans belong to Xhosa ethnic group
Religion: whites and coloreds predominantly Christian;
Africans either animist or Christian
Language: whites, coloreds, and educated minority of
Africans speak Afrikaans or English; bulk of Africans speak
Xhosa
Literacy: high for: whites and coloreds; low for Africans
Labor force: roughly 400,000 of whom only 50,000 are
regularly employed in Transkei; bulk are migrant workers in
Organized labor: no trade union, although some Trans-
keians employed in South Africa belong to South African
unions
Population: 37,774,000, including the Balearic and
Canary Islands; also including Alhucemas, Ceuta, Chafar-
inas, Melilla, and Penon de Velez de la Gomera (January
1979), average annual growth rate 1.2% (current)
Nationality: noun—Spaniard(s): adjective—Spanish
Ethnic divisions: homogeneous composite of Mediterra-
nean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great maiority;
but 17% speak Catalan, 7% Galician, and 2% Basque
Literacy: about 97% ,
Labor force (1976): 13.3 million; 21% agriculture, 38%
industry, 41% services; unemployment now estimated at 8%
of labor force
Organized labor: labor unions legalized April 1977
experiencing surge in membership; probably represent about
25% of the labor force','80f4337c884e61ffad37104c393604d4296e40f49e09c384a25c6c90a4078785','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdcea0731f44539373c155408726927b5f7467d2c483b595774293ab7a2c3e6a',1968,'MW','Malawi','people-and-society',278,'Population: 5,777,000 (January 1979), average annual
growth rate 2.9% (8-66 to 10-77)
Nationality: noun—Malawian(s); adjective—Malawian
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is
second African language
Literacy: 15% of population
‘Labor force: 225,000 wage earners employed in Malawi
(1974); 30% agriculture, 11% construction, 10% commerce,
13% manufacturing, 10% administration, 26% miscellaneous
services; 6,000 Europeans permanently employed
Organized labor: small minority of wage earners are
unionized','7b6e60b376be3497b2ae3abb95689204fabf40e4326f364543c2099412d861a4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83af66bcd54a2a68bba10a287ea50ec60becb59f000096a47b466c87408cbf3c',1968,'MY','Malaysia','people-and-society',282,'Population: 13,099,000 (January 1979), average annual
growth rate 2.8% (current)
Peninsular Malaysia: 10,926,000,
growth rate 2.6% (8-70 to 1-77)
Sabah: 967,000, average annual growth rate 4.8% (8-70
to 1-77)
Sarawak: 1,206,000, average annual growth rate 2.6%
average annual
(8-70 to 1-75)
Nationality: noun—Malaysian(s); adjective—Malaysian
Ethnic divisions:
Malaysia: 50% Malay, 35% Chinese, 10% Indian
Peninsular Malaysia: 58% Malay, 35% Chinese, 11%
Indian and Pakistani, 1% other
Sabah: 21% Chinese, 69% indigenous tribes, 10% other
Sarawak: 30% Chinese, 50% indigenous tribes, 19%
Malay, 1% other
Religion:
Peninsular Malaysia: Malays nearly all Muslim,
Chinese predominantly Buddhists, Indians predominantly
Hindu
Sabah: 38% Muslim, 17% Christian, 45%. other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist,
16% Christian, 35% tribal religion, 2% other
Language:
Peninsular Malaysia: Malay (official); English, Chinese
dialects, .Tamil
Sabah: English, Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal
languages
Literacy:
Peninsular Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 4.2 million (1975)
Peninsular Malaysia: 3.6 million; 46.2% agriculture,
forestry, and fishing, 10.9% manufacturing and construction,
31.9% trade, transport, and services (1975)
Sabah: 213,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 13% trade and
transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 13% trade,
transportation, and services, 1% other
Organized labor: 500,000 (1975 est.), about 15% of total
labor force; unemployment about 7% of total labor force, but
higher in urban areas
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','cb79ca8d68de2db185880575116f6268d90e4dbd38fb3a5890e53eb538bbb094','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cfdb272646157d886797e9383e9f0c4f4b2357c9b92082b57d7545a673b3432',1968,'MV','Maldives','people-and-society',288,'Population: 143,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Maldivian(s); adjective—Maldivian
Ethnic divisions: admixtures of Sinhalese, Dravidian,
‘Arab, and Negro
Religion: official Sunni Muslim
Language: Divehi ‘(dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the male
population aa
Population: 6,287,000 (January 1979), average annual
growth rate 2.0% (current)
Nationality: noun—Malian(s); adjective—Malian
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African languages, of
which Mande group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried, 50,000 of
whom are employed by the government; most of population
engaged in agriculture and animal husbandry
Organized labor: Union National des Travailleurs Maliens
(UNTM) is umbrella organization over thirteen national
unions','44c76c02ba826e6db8504dff650d0952a490bcd726f22f97a82bc9ebe2e9ce4b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f040ef34ee5bede5898011f88cac8ca4c418b3fd10d0db3076b75b682ece208',1968,'MT','Malta','people-and-society',292,'Population: 326,000 (official estimate for 31 December
1977) —
‘Nationality: noun’ Maltese (sing. and pl.); adjec-
tive Maltese
Ethnic ‘divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in
1946
Labor force: 119,554 (November 1977); 32% services
(except government), 18% government (except job corps),
5% job corps, 26% manufacturing, 6% agriculture, 3%
construction, 5% utilities and drydocks; 4% registered
unemployed
Organized labor: approximately 40% of labor force','0249f802ce81819db8c8e79c057453cbc95db3911df1632cecff2d3b91df50b0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5f738afae26d2c44c1182360bfcbff0c57c8ec8606bb4d44b7933d30c675286',1968,'MQ','Martinique','people-and-society',296,'Population: 319,000 (January 1979), average annual
growth rate —0.0% (10-67 to 1-77)
Nationality: noun Martiniquais (sing. and pl.); adjective
Martiniquais
Ethnic divisions: 90% African and African-Caucasian-
Indian mixture, less than 5% East Indian Lebanese, Chinese,
5% Caucasian
134
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public
services, 11% construction and public works, 10% commerce
and banking, 10% services, 9% industry, 17% other
Organized labor: 11% of labor force','7e58f20790424b0279e739dd054235fddc729ad83c562d6dff46da3c04a26d51','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07c1de99858fc1ce1ab10855b1694cbdaa34b9b1d46cfa0578c4971c9aeb817a',1968,'MR','Mauritania','people-and-society',300,'Population: 1,562,000 (January 1979), average annual
growth rate 2.7% (7-72 to 7-75)
Nationality: noun—Mauritanian(s); adjective—Maurita-
nian
Ethnic divisions: nearly one third Moor, at least one third
Negro, one third mix Moor/Negro
Religion: nearly 100% Muslim
Language: Hassaniya Arabic is the national language
spoken by some 80% of the population, French is the
working language for government and commerce
Literacy: about 10%
Labor force: about 35,000 wage earners (1976); remain-
der of population in farming and herding; considerable
unemployment
Organized labor: 18,000 union members claimed by
single union, Mauritanian Workers’ Union
Population: 19,199,000 (January 1979), average annual
growth rate 3.0% (7-75 to 7-76)
Nationality: noun—Moroccan(s); adjective—Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish, 0.7%
non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2% Jewish
Language: Arabic (official); several Berber dialects;
French is language of much business, government, diplo-
macy, and postprimary education
Literacy: 20%
Labor force: 5 million (1977 est.); 50% agriculture, 15%
industry, 26% services, 9% other; 10-20% unemployment
Organized labor: about 5% of the labor force, mainly in
the Union of Moroccan Workers (UMT)
Population: 75,000 (total from the census of 1974)
Nationality: noun—Saharan(s); adjective—Saharan
Ethnic divisions: Arab, Berber, and Negro nomads
Religion: Muslim
Language: Hassaniya Arabic
Literacy: among Spanish, probably nearly 100%; among
nomads, perhaps 5% :
Labor force: 12,000; 50% animal husbandry and subsist-
ence farming, 50% other
Organized labor: none','05c7edd865bac7b1ee53e7bb0c041a1bf7fe9d8d5530a8e21f722ab19c1d6e9b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4459d7434003a5ed340ece52ac9abee7065bb127cb6881bae1380adabb817b5',1968,'MU','Mauritius','people-and-society',304,'Population: 927,000 (January 1979), average annual
growth rate 1.3% (7-71 to 7-77)
Nationality: noun—Mauritian(s); adjective—Mauritian
Ethnic divisions: 67% Indians, 29% Creoles, 3.5%
Chinese, 0.5% English and French
Religion: 51% Hindu, 33% Christian (mostly Catholic
with a few Anglican Protestants), 16% Muslim
Language: English official language; Hindi, Chinese,
French Creole
Literacy: estimated 60% for those over 21, and 90% for
those of school age
Labor force: 175,000; 50% agriculture, 6% industry; 20%
government services; 14% are unemployed, underemployed,
or self-employed, 10% other
Organized labor: about 35% of labor force
Population: 505,000 (January 1979), average annual
growth rate 1.3% (1-74 to 1-78)
Nationality: noun—Reunionese (sing. & pl.); adjective—
Reunionese ;
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese,
Pakistani, and Indian. origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal
unemployment','26e6a90d6da766f8e501b2914bbb2515661763e5af6e8579a1c0b9d1b6313b4c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3bcf88910e4d7a1753636ab4488527a13e772b698c46b593bf018d7eb71456c',1968,'MC','Monaco','people-and-society',308,'Population: 25,000 (official estimate for 1 July 1976)
Nationality: noun—Monacan(s) or Monegasque(s); adjec-
tive—Monacan or Monegasque
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
‘Literacy: almost complete','2531f6d4b1199713f401c2374dff14d98a37309c4b7d81fbd3549e387a58ce33','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8456fb0d9750d78d673759cf531dc17a4f312b8448639ac575b823b26727cec',1968,'MN','Mongolia','people-and-society',312,'Population: 1,612,000 (January 1979), average annual
growth rate 3.3% (current) ,
Nationality: noun—Mongolian(s); adjective—Mongolian
140
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese,
2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about 4%
Muslim, limited religious activity because of Communist
regime ;
Languages: Khalkha Mongol used by over 90% of
population; minor languages include Turkic, Russian, and
Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the
population is in the labor force, including a Jarge percentage
of Mongolian women; shortage of skilled labor (no reliable
information available)','81671fd0dbf111e81ba577cd4b9dcd5776c7055dcbfcc437c87518c35f2dec46','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9de55279108a00d6e139dad56638e6a6eb66e2ec63a17185d15ad797186bfc1d',1968,'MZ','Mozambique','people-and-society',317,'Population: 9,987,000 (January 1979), average annual
growth rate 2.4% (current)
Nationality: noun—Mozambicar(s); adjective—Mozam-
bique ;
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
wiA_aAK_AA_»AA_A Aa AAA AKL _
Paina.
a=
pe aA __AL__A.
x
Sn Te AA an in ad
A
AA
ee
ro"
7
SE ee ee ee ae
January 1979
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
MOZAMBIQUE/NAMIBIA
Ethnic divisions: over 99% native African, less than 1%
European and Asian _
Religion: 65.6% animist, 21.5% Christian, 10.5% Muslim,
2.4% other ;
Language: Portuguese (official); many tribal dialects
Literacy: 7%-10% (est.)
Labor force: (1963 est.) 610,000; 50,000 non-African wage
earners, 560,000 African wage earners in Mozambique;
290,000 additional African wage earners temporarily work-
ing in Rhodesia and South Africa; unemployment serious
problem; most native Africans provide unskilled labor or
remain in subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970); 75% are
white
Population: 533,000 (January 1979), average annual
growth rate 2.8% (5-66 to 8-76)
Nationality: noun—Swazi(s); adjective—Swazi
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence
agriculture; 55,000-60,000 wage earners, many only inter-
mittently, with 31% agriculture, 11% government, 11%
manufacturing, 12% mining and forestry, 35% other (1968
est.); 22,000 employed in South African mines (1976)
Organized labor:
unionized','f9bedbce5ac73499b2fa4a958375141de18e3c5968cf5103b4b120f167e97410','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e4ec0e013839fe7cbb6c47aa2aa354b8cf7c172739b040c54949b3a4a8a8b09',1968,'NA','Namibia','people-and-society',321,'Population: 978,000 (January 1979), average annual
growth rate 2.9% (current)
143
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Atlantic
Ocean
Windhoek
; 1
SOUTH AFRICA»? *
(WALVIS BAY)
3
{See reference map Vi}
Nationality: noun—Namibian(s); adjective—Namibian
Ethnic divisions: 12% white, 6% mulatto, 82% African;
over half the Africans belong to Ovambo tribe
Religion: whites predominantly Christian, nonwhites
either animist or Christian
Language: Afrikaans principal language of about 70% of
white population, German of 22% and English of 8%; several
African languages ,
Literacy: high for white population; low for nonwhite
Labor force: 203,300 (total of economically active, 1970);
68% agriculture, 15% railroads, 18% mining, 4% fishing
Organized labor: no trade unions, although some white
wage earners belong to South African unions','f0babfd2ddf6db9c75da106049699e4b613853d853a3746d910d3201b4eff735','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('333e93a24e79def5fd7c09654bc9431429f88d7a9473fab69e9283224c0a8fa6',1968,'NP','Nepal','people-and-society',325,'Population: 13,854,000 (January 1979), average annual
growth rate 2.5% (current)
. Nationality: noun—Nepalese (sing. and pl.); adjective—
Nepalese
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%), representing
considerable intermixture of Indo-Aryan and Mongolian
racial strains; country divided among many quasi-tribal
communities
Religion: only official Hindu Kingdom in world, although
no sharp distinction between many Hindu and Buddhist
groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided
into numerous dialects; Nepali official language and lingua
franca for much of the country; same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95%: agriculture, 5% industry;
great lack of skilled labor','8571d4db9301916af1ebdfc09f01a3f19db13ebcaf5d516f0c95249623586d6a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd4ccf43cd32d51a6ca78ba31705e7665c749b1b3c038c9fa234f6fc8db3929b',1968,'NL','Netherlands','people-and-society',329,'Population: 13,976,000 (January- 1979), average annual
growth rate 0.6% (current)
Nationality: noun—Netherlander(s); adjective—Nether-.
lands
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 81% Protestant, 40% Roman Catholic, 24%
unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24%
services, 16% commerce, 10% agriculture, 9% construction,
7% transportation and communications, 4% other; 5.1%
unemployment, March 1977
Organized labor: 33% of labor force','96ebace5fed92310e3888c6b2bdcef0e3bff0c926cb76730b550780340f5f44c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5196e886b54cde4a2f1060c6c2d3618c054c3b62f11db2067be8fd3a195c8f7d',1968,'NZ','New Zealand','people-and-society',333,'Population: 3,176,000 (January 1979), average annual:
growth rate 0.8% (1-75 to 1-78)
151
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
a
* Pacific
\\ Ocean
Coral Sea','162c021581540374ad45f70eff3b2b409aa6b83377948002315128070d064242','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46b05b4d1c404644794d1af40504c22c6809b22dd9e438e24850fe02ea660313',1968,'NI','Nicaragua','people-and-society',336,'Population: 2,447,000 (January 1979), average annual
growth rate 3.1% (current)
Nationality: noun—Nicaraguan(s);
guan
Ethnic divisions: 69% mestizo, 17% white, 9% Nesta, 5%
Indian
Religion: 95% Roman Catholic
Language: Spanish (official); English speaking sHinoniy
on Atlantic coast
Literacy: 52% of population 10 years of age and over
Labor force: 728,419 (1977 est.); 43% agriculture, 15%
manufacturing, 13% commerce, 29% other; shortage of
adjective—Nicara-
skilled labor, but underemployment of unskilled labor
except during harvest
Organized labor: about 5.6% of labor force
Population: 5,064,000 (January 1979), average annual
growth rate 2.8% (7-76 to 7-77)
Nationality: noun—Nigerien (sing. and pl.); adjective—','8f2185f4321a9e74cc948ad5e8b06b404bc5fca8f7d80bd2549fc69eb31d2d20','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac6da80569ac9d0baa9ab4547e7b30ffb35f8e05a32d151c4037f61c1860bdb9',1968,'NE','Niger','people-and-society',340,'Ethnic divisions: main Negroid groups 75% (of which,
Hausa 50%, Dierma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a
very few Christians
Language: French official, many African languages;
Hausa used for trade
Literacy: about 6%
Labor force: 26,000 wage earners; bulk of population
engaged in subsistence agriculture and animal husbandry
Organized labor: negligible ;','66b5a60f99843200b5aaceee8c97df4479300a774186c264f384bbeafcbacd78','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b889e7f722b043bd977607b34eacb22bc43e44a8362d793761c9f02e6f35cc3e',1968,'NG','Nigeria','people-and-society',345,'Population: 69,492,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun—Nigerian(s); adjective—Nigerian
Ethnic divisions: of the more than 250 tribal groups, the
Hausa and Fulani of the north, the Yoruba of the south, and
the Ibos of the east comprise 60% of the population; about
27,000 non-Africans .
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25%
Language: English official; Hausa, Yoruba, and Ibo also
widely used
Labor force: approx. 22.5 million; about 41% of total
population; roughly 1.3 million wage earners, of whom
560,000 work in modern enterprises
Organized labor: between 800,000 and 1 million wage
earners, approx. 2.4% of total labor force, belong to some 70
unions"','1976557148117846f47993c4fe8fc6fe6a4d636d3a8b3ebcdc0037ff45962f5c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('421d08dbd9042003d74265c54301db9ab56b3282cca1d5a126dd6cc628cbccb5',1968,'NO','Norway','people-and-society',349,'Population: 4,067,000 (January 1979), average annual
growth rate 0.4% (1-77 to 1-78)
Nationality: noun—Norwegian(s); adjective—Norwegian
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant
and Roman Catholic, 1% other
Language: Norwegian, smal] Lapp and Finnish-speaking
minorities
Literacy: 100%
Labor force: 1.9 million; 11.4% agriculture, forestry,
fishing, 25.3% mining and manufacturing, 8.1% construc-
tion, 16.38% commerce, 9.9% transportion and communica-
tion, 28.5% services; 1.4% unemployed (average annual
1977)
Organized labor: 60% of labor force
Population: 558,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Omani(s); adjective—Omani
Ethnic divisions: almost entirely Arab with small groups
of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low','204b41b67315f123ae927a7f279013515a49bf0ea543b4cb36e07972afc34ab9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee49eaf80b915ab2392b957f58d8e7caf89ac4eb4dad724ee6b0f8909a5e7626',1968,'PK','Pakistan','people-and-society',353,'Population: 78,978,000, excluding Junagadh, Manavadar,
Gilgit, Baltistan, and the disputed area-of Jammu-Kashmir,
(January 1979), average annual growth rate 3.0% (current)
Nationality: noun—Pakistani(s); adjective—Pakistani
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages—7%
Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu, 9% other;
English is lingua franca
Literacy: about 17%
Labor force: 22 million (1978 est.); 60% agriculture, 16%
industry, 7% commerce, 15% service, 2% unemployed ,
Organized labor: 5% of labor force','50f7cb7e9fdba8f9ab3eccd4d2d7f9eb45adfd2852cf70ba738498341d453dbe','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('619ee3e79d827562ce9340038fbef888e59e3fc4c40b067493f6957bab770fbd',1968,'PA','Panama','people-and-society',357,'Population: 1,837,000 (January 1979), average annual
growth rate 2.7% (current)
Nationality: adjective—Pana-
manian
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7%
Indian and other
noun—Panamanian(s);
Religion: over 90% Roman Catholic, remainder mainly
Protestant
Language: Spanish; about 14% speak English as native
tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and over
Labor force: 482,200 (1972 est.); 39.5% commerce,
finance and services; 33.9% agriculture, hunting and fishing;
9.7% manufacturing and mining; 6.8% construction; 5%
Canal Zone; 3.9% transportation and communications; 1.2%
utilities; unemployment estimated at 10%. to 18%; shortage
of skilled labor but an oversupply of unskilled labor
Organized labor: 8.4% of labor force (1972 est.)','87571f4bc2cf2d92e77f5dd5b13ec80a5fb2cdd3cb60120724160c65a2c85b2f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d4d0b818017c8a383c1b524e36d09986e328dd321a49746eaecf8404bfd2b84',1968,'PY','Paraguay','people-and-society',361,'Population: 3,143,000 (January 1979), average annual
growth rate 3.1% (current)
Nationality:| noun—Paraguayan(s); adjective—Para-
guayan . ;
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman’ Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 800,000 (1971 est.); 52.6% agriculture,
forestry, fishing; 28.2% services; 19.2% manufacturing and
mining (1970)
Organized labor: about 5% of labor force
Pepulation: 17,053,000 (January 1979), average annual
growth rate 2.8% (current)
Nationality: noun—Peruvian; adjective—Peruvian
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Lm am A
mK Am RA A RR AA ERA RR Ke A A ee
Sm
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','c90da50b1e6bf235599c0bebe6b1486a8909ca8d390e1b5c9298e44f5445e5fa','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('266bfb398c226e2afeefd9650c6b1b84747f1b6491335dfb7b6894bf9a038af2',1968,'PE','Peru','people-and-society',364,'Ethnic divisions: 46% Indian; 38% mestizo (white-
Indian); 15% white; 1% Negro, Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish,. Quechua, Aymara
Literacy: 45% to 50%
Labor force: 5.0 million (1975); 42.1% agriculture, 17%
services, 14% manufacturing, 9% trade, 4% construction, 4%
transportation, 2% mining, 4% other
Organized labor: 37.1% of labor force','ee000242b5b933cae632c5fc67af0f797143804a1f885d908861014aa48a99fe','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('729df50129c596e14da494b4da8a88c98a2e7874a9f372660115552be3b0de75',1968,'PL','Poland','people-and-society',369,'Population: 35,210,000 (January 1979), average annual
growth rate 1.0% (current)
. Nationality: noun—Pole(s); adjective—Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians, 0.5%
Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75% practicing),
5% Uniate, Greek Orthodox, Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 18.8 million; 32% agriculture, 25% aaaUsiey,
43% other non-agricultural (1977)','9e5d2c6e98595e2e4531e04444a9cf42f00090dc890dd8f080372a0258f945ed','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6c9f3e0c2276d4061c42200ad1e225b908b261e5f26f1145d08525118c08ad1',1968,'PT','Portugal','people-and-society',372,'Population: metropolitan Portugal (including the Azores
and Madeira Islands), 9,833,000 (January 1979), average
annual growth rate 0.7% (current)
Nationality: noun—Portuguese (sing. & pl.); adjective—
Portuguese
Ethnic divisions: homogeneous Mediterranean stock in
mainland, Azores, Madeira Islands; citizens of black African
descent who immigrated to mainland during decolonization
‘number less than 100,000
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Religion: 97% Roman Catholic, 1% Protestant sects, 2%
other
Language: Portuguese
Literacy: 70%
Labor force: (1976) 3.2 million; 27% agriculture, 36%
industry, 37% services; unemployment—now more than
14%—is largely due to influx of refugees from former
colonies, returning migrant workers, and military cutbacks
Organized labor: the Communist-dominated General
Confederation of Portuguese Workers—National Intersindi-
cal (CJTP-IN) claims to represent 85% of the labor force; the
Socialists and Social Democrats have Jost ground over the last
year despite efforts to improve their standing with organized
labor','17246c5bf59dcd0dd16f345dcd63da30f9fee568c3614dc85b3141ef3e14949e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3315dacd944538caf1961cfa752fa015f53d867b48934dd33e35f73a8d669558',1968,'QA','Qatar','people-and-society',376,'Population: 165,000 (January 1979), average annual
growth rate 3.2% (current)
170','88b6401ee0e5960d4c5fa414f3031e8563c78979c68bcdd7a4f0d2c9b727f9c9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68d6e25672755a47ac9b8006738a3968aba88507fda262e00a36b8010b56afa1',1968,'RW','Rwanda','people-and-society',378,'Population: 4,508,000 (January 1979), average annual
growth rate 2.9% (current)
Nationality: noun Rwandan(s); adjective—Rwandan
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa
(Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French official; Kiswahili
used in commercial centers
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','02fa453d5ee27f1742f677f7adb3658553d83a26d75c70dfb06ccada2eff8e70','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ba3277487b0b88dfa68b6fd4fabf2d2c57ccb6f17c0ab0473efe30041813d16',1968,'AI','Anguilla','people-and-society',382,'Population: 57,000 (January 1979), average annual
growth rate 1.1% (7-76 to 7-77)
Ethnic divisions: mainly of African Negro descent
Nationality: noun—Kittsian(s), Nevisian(s), Anguillan(s);
adjective—Kittsian, Nevisian, Anguillan
Religion: Church of England, other Protestant sects,
Roman Catholic
Language: English
Literacy: about 80%
Labor force: 19,616 (1960 est.)
Organized labor: 6,700
Population: 120,000 (January 1979), average annual
growth rate 1.7% (current)
Nationality: noun—St. Lucian(s); adjective—St. Lucian
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about. 80%
Labor force: 38,000 (1969); 50% agriculture; 30%-35%
unemployment (1975)
Organized labor: 20% of labor force
Population: 112,000 (January 1979), average annual
growth rate 1.8% (4-60 to 1-76)
Nationality: noun—St. Vincentian(s) or Vincentian(s);
adjectives—St. Vincentian or Vincentian
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian and
Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60% unemployed
Organized labor: 10% of. labor force','ee5f5ea3f4298fb05242ef1251c106afcc41dc5621d6d5f74aff4ad6b53e7c1b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af451cec3dcb82501dc5b7e403406a62139248cf6e469895b0f997e9374aad0d',1968,'SM','San Marino','people-and-society',386,'Population: 21,000 (official estimate for 30 June 1977)
Nationality: noun—Sanmarinese (sing. & pl.); adjective—
Sanmarinese
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Mediterranean Sea
(See reference mop IV)
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of
Sanmarinese Workers (affiliated with ICFTU) has about
1,800 members; Communist-dominated Camera del Lavoro,
about 1,000 members a','5b6861c622367bdccfe9d25985a89743d414b1e691be899db94ee2221b3cf6c6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e0649fc99cff2b1f9145c2dca18e7745cd2aadece13092c3e919e696d74c77b',1968,'SC','Seychelles','people-and-society',390,'Population: 64,000 (January 1979), average annual
growth rate 2.4% (7-72 to 7-77) =,
Nationality: noun—Seychellois (sing. & pl.); adjective—
Seychelles :
Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans) ,
Religion: 90% Roman Catholic
. Language: English official; Creole most widely spoken
Literacy: limited; 90% of school-age population is
attending school
Labor force: 15,000 in monetized sector (excluding self-
employed, domestic servants, and workers on small farms);
83% public sector employment, 20% private sector employ-
ment in agricuture, 20% private sector employment in
construction and catering services
Organized labor: 3 major trade unions','b5f1ffc788ac1dcb2ad8a96b26f429bff5ca68e8a9a11d965d7e024fc5d0dc3f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d5f78522ff6c39fe3345708b911bccaf89d9e408d00ab27d791f05a8d6f68a4',1968,'SL','Sierra Leone','people-and-society',394,'Population: 3,293,000 (January 1979), average annual
growth rate 2.3% (12-74 to 7-76)
Nationality: -.noun—Sierra Leonean, adjective—Sierra
Leonean
Ethnic divisions: over 99% native African, rest European
and Asian; 13. tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to
literate minority; principal vernaculars are Mende in south
and Temne in north; “Krio,” the language of the resettled
ex-slave population of the Freetown area, is used as a lingua
franca
Literacy: about 10%
Labor force: about 1.5 million; most of population
engages in subsistence agriculture; only small minority, some
70,000, earn wages
Organized labor: 35% of wage earners','3d71d9407c3587fc790d1ec017c05f708d344c31fb58e03aa4b6242d2a7f81e3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93bbb04db7d4592c7b71c26de9626b6ab0129a2f406e1eabc47f954b31c8e8e1',1968,'SG','Singapore','people-and-society',397,'Population: 2,354,000 (January 1979), average annual
growth rate 1.8% (7-76 to 7-77) a
Nationality: noun—Singaporean(s), adjective—Singapore
Ethnic divisions: 76.2%. Chinese, 15% Malay, 7% Indians
and Pakistani, 1.8% other _
Religion: majority of Chinese are Buddhists or atheists;
Malays nearly all Muslim; minorities include Christians,
Hindus, Sikhs, Taoists, Confucianists ;
Language: national language is Malay; Chinese, Malay,
Tamil, and English are official languages’
Literacy: 70% (1970)
Labor force: 919,000; 2.2% agriculture, forestry, and
fishing, 0.2% mining and quarrying, 27.2% manufacturing,
30.5% services, 4.6% construction, 23.5% commerce, 11.7%
transport, storage, and communications
Organized labor: 24% of labor force','c918e3221ce116e1ee6b6bf0a4bb31cdac16f1dee0d3974c9b4be3fbde83a192','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1e9441b6ed3bd2cca61a92ec9fcccea946b843a4a6827965b4383d5acc3a641',1968,'SB','Solomon Islands','people-and-society',400,'Population: 215,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Solomon Islander(s); adjective—Solo-
mon Islander
Nn
Ethnic divisions: 93.0% Melariesians, 4.0% Polynesians,
1.5% Micronesians, 0.3% Chinese, 0.8% Europeans, 0.4%
others
Religion: almost all at least nominally Christian; Roman
Catholic, Anglican, and Methodist churches dominant
Literacy: 60% ‘','848fa29fb22107a9a8400ab4f03ee7ae103a7cc3cbe47125a1f080f0953132ce','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('257f86fbd700cac21013226eeecae5e0fad3cc43379efd294479e0af4f389206',1968,'SO','Somalia','people-and-society',404,'Population: 3,428,000 (January 1979), average annual
srowth rate 2.4% (current)
Nationality: noun—Somali(s); adjective—Somali ;
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000
Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (written form instituted by government
in 1976); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled
laborers; 70% pastoral nomads, 30% agriculturists, govern-
ment employees, traders, fishermen, handicraftsmen, other
Organized labor: General Federation of Somali Trade
Unions, a government-controlled organization, established in
1977 :','cd785174ec3705fa45d09b58d7b4e806b6bffc9b81bc1d2a73a873ec2014f744','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('217e2e335bd29448d16b1ae8ae4209e833e103e0e28ef9a4b4f571913b130b00',1968,'LK','Sri Lanka','people-and-society',412,'Population: 14,393,000 (July 1978), average annual
growth rate 1.5% (current)
Nationality: noun—Sri Lankan(s); adjective—Sri Lankan
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor,
2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6%
Muslim, 1% other , :
Language: Sinhala official, spoken by about 70% of
population; Tamil] spoken by about 22%; English commonly
used in government and spoken by about 10% of the
population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed; employed
persons—53.4% agriculture, 14.8% mining and manufactur-
ing, 12.4% trade and transport, 19.4% services and other;
.extensive underemployment
Organized labor: 43% of labor force, over 50% of which
employed on tea, rubber, and coconut estates
193
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
SRI LANKA/SUDAN','222425cd12a782d708c75bab14000c5342a01a134cd68437290a522ef6b1c7b0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7da7d3743a39f15949d6f188b154a1e4f6098b315e06514d137ca13d09624cd7',1968,'SD','Sudan','people-and-society',416,'Population: 17,912,000 (January 1979), average annual
growth rate 3.2% (current)
Nationality: noun—Sudanese (sing. and pl.); adjective—
Sudanese
Ethnic divisions: 89% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other a
Religion: 73% Sunni Muslims in north, 23% pagan, 4%
Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects
of Nilotic, Nilo-Hamitic, and Sudanic languages, English;
program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15% industry,
commerce, services, etc.; labor shortages exist for almost all:
categories of employment','e935d061a7be8165292b085571ee81e844060f6f54fc0fd46cf5279982238133','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c98241bdfecf952d4d082cfb5490f7403464c44a690434894192f1834ec22a1c',1968,'SE','Sweden','people-and-society',420,'Population: 8,285,000 (January 1979), average annual.
growth rate 0.2% (current) ;
Nationality: noun—Swede(s); adjective—Swedish
Ethnic divisions: homogeneous white population; small
Lappish minority ,
Religion: 92% Evangelical Lutheran, 7% other Protestant,
Roman Catholic, Eastern Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking
minorities —
Literacy: 99%
Labor force: 4.2 million; 6.4% agriculture, forestry,
fishing; 29.2% mining. and manufacturing; 7.2% construc-
tion; 13.6% commerce; 6.5% transportation and communica-
tions; 29.8% services including government; 5% banking;
75,000 or 1.8% unemployed (average annual 1977)
Organized labor: 80% of labor force
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Re eg I RN gg gy A=
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','f511cbe827cd46c35fb25d9cd3f2dfa51de66a12c934985e21f855f1ef9bd277','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cda2bc589ddf063d0da2bafdda47504d5ae5e8bf9f3013966a93012296f37aa',1968,'CH','Switzerland','people-and-society',424,'Population: 6,286,000 (January 1979), average annual
growth rate —0.1% (1-77 to 1-78)
Nationality: noun—Swiss (sing. & pl.); adjective—Swiss
Ethnic divisions: total population—69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals—74% German, 20% French, 4% Italian, 1%
Romansch, 1% other :
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals—74% German, 20% French,
4% Italian, 1% Romansch, 1% other; total population—69%
German; 19% French, 10% Italian, 1% Romansch, 1% other
Literacy: 98%
Labor force: 2.6 million, about one-tenth foreign workers,
mostly Italian; 16% agriculture and forestry, 47% industry
and crafts, 20% trade and transportation, 5% professions, 2%
in public service, 10% domestic and other; approximately
0.3% unemployed in July 1978
Organized labor: 20% of labor force
Population: 8,260,000 (January 1979), average annual
growth rate 3.3% (current)
Nationality: noun—Syrian(s); adjective—Syrian
Ethnie divisions: 90.3% Arab; 9.7% Kurds, Armenians,
and other
Religion: 70.5% Sunni Muslim, 16.3% Alawites, Druze,
and other Muslim sects, 13.2% Christians of various sects
Language: Arabic, Kurdish, Armenian; French and
English widely understood
Literacy: about 40%
Labor force: 1.8 million; 32% agriculture, 26% industry
(including construction), 42% miscellaneous services; major-
ity unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 17,098,000 (January 1979), average annual
growth rate 3.0% (current) —
Nationality: noun—Tanzanian(s); adjective—Tanzanian
Ethnic divisions: 99% native Africans consisting of . well
_ over 100 tribes; 1% Asian, European, and Arab
Religion: Mainland—40% Animist, 30% Christian, 30%
Muslim; Zanzibar—almost all Muslim
Language: Swahili and English official, English primary
language of commerce, administration and higher education;
Swahili widely understood and generally used for communi-
cation between ethnic groups; first language of most people
is one of the local languages
Literacy: 61%
Labor force: under 400,000 in paid employment, over
90% in agriculture
Organized labor: 15% of: labor force','5781503e49edd4ff1560601f1d4086e58a3a13b8d7f45adee2330c3cbeae4ed5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e27d514ccefb902d2e00212ceef758ef31d965d219857ece2b628ba8837e8e56',1968,'TH','Thailand','people-and-society',428,'Population: 46,443,000 (January 1979), average annual
growth rate 2.6% (current)
204
Nationality: noun—Thai (sing. & pl.); adjective—Thai
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70%
Labor force: 78% agriculture, 15% services, 7% industry
Population: 51,883,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Vietnamese (sing. & pl.); adjective—
Vietnamese
Ethnic divisions: 85%-90% predominantly Vietnamese;
3% Chinese; ethnic minorities include Muong, Thai, Meo,
Khmer, Man, Cham, and mountain ttibesman
Religion: Buddhism, Confucianism, Taoism, Catholicism,
Animism, Islam, and Protestantism
Language: Vietnamese, French, Chinese, English, Khmer,
tribal languages (Mon-Khmer and Malayo-Polynesian)
Labor force: approximately 15 million, not including
military; about 70% agriculture and 8% industry','39e8cddf032daedd331405c676b7993043b1129030be5c32f303f2e07047b493','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('585b4a119e81eb304e96f14769db58fbcce18b26e3a2b314e3041941c3cbc590',1968,'TG','Togo','people-and-society',432,'Population: 2,493,000 (January 1979), average annual
growth rate 2.8% (current) ;
Nationality: noun—Togolese (sing. & pl.); adijective—
Togolese
Ethnic divisions: 37 tribes; largest and most important are
Ewe in south and Cabrais in north; under 1% European and
Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of com-
merce; major African languages are Ewe and Mina in the
south and Dagomba and Kabie in the north
Literacy: 54.9% of school age (7-14) currently in school
Labor force: over 90% of population engaged in
subsistence agriculture; about 30,000 wage earners, evenly
divided between public and private sectors
Organized labor: 1 national union, the CNTT organized
in 1972','68d8cae9e52d65560f9acb717a5a80fe9574112ee6cbce1869fe76f101777a71','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65b0a8227cf121aa8750e6c1283b68d8d7d8fcb654c1fddaa0a2702c9ddd2fee',1968,'TO','Tonga','people-and-society',436,'Population: 91,000 (January 1979), average annual
growth rate 0.8% (current)
Nationality: noun—Tongan(s); adjective—Tongan
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free: Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children
between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: ‘unorganized','2700249dcfefd34ecd5f17cf484a2d2dab23324d268229b98b56524cd85acfcd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('687a7f7f3c982fb9c01b1c7f1f1c588a9c25f7eb28a41c04bba855c05f8c0b58',1968,'TT','Trinidad and Tobago','people-and-society',440,'Population: 1,129,000 (January 1979), average annual
growth rate 1.1% (7-70 to 7-76).
Nationality: noun—Trinidadian(s), Tobagonian(s); adjec-
tive—Trinidadian
Ethnic divisions: 43% Negro, 40% East Indian, 14%
mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23.0%
Hindu, 6.0% Muslim, 13.0% unknown
Language: English
Literacy: 95%
Labor force: 393,800 (July 1975), 13.5% agriculture,
20.0% mining, quarrying, and manufacturing, 17.4% com-
merce; 15.7% construction and utilities; 7.5% transportation
and communications; 23.0% services, 2.9% other
Organized labor: 30% of labor force','3102506b42cd032246e3b96ebcb74a5cc9b967a920a9d78c57369bbb56df351d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae23fcc2169c2fee9f434fa7c195148f1f9c7b6c2f0fe8ca064b05e3c790d6eb',1968,'TN','Tunisia','people-and-society',444,'Population: 6,327,000 (January 1979), average annual
growth rate 2.7% (current)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
A RA RA AA A AS any, Waa eae ee, a
RR an oe ek ne ee RR A
AD AR A aA mA AA A ne!
TSR A AM RA A AL
a a a. a Or ae as
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
(See reference map Vi}
Nationality: noun—Tunisian(s); adjective—Tunisian
Ethnic divisions: 98% Arab, 1% European, less than 1%
Jewish
Religion: 95% Muslim, 4% Christian, 1% Jewish
Language: Arabic (official), Arabic and French
(commerce)
Literacy: about 32%
Labor force: 1.4 million; 45% agriculture, 19% manufac-
turing and construction, 5% trade and finance, 3%
transportation, communications, and utilities, 2% mining;
10%-20% unemployed; shortage of skilled labor
Organized labor: 25% of labor force; General Union of
‘Tunisian Workers (UGTT), quasi-independent of Destourian
Socialist Party','d66d82b29b3c35da39ece40020d43b03b48770d34abf83131189e54c7a2e2d7d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc0d95b45091c392ffb8cdfde6262e76f72f70f2b188d3ae981aa59d6a6d089c',1968,'DE','Germany','people-and-society',447,'Population: 43,767,000 (January 1979), average annual
growth rate 2.6% (current)
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 8% . other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 55% ; :
Labor force: 16.4 million; 61% agriculture, 13% industry,
25% service; substantial shortage of skilled labor; ample
unskilled labor (1978)
Organized labor: 12% of labor force','936938c7b9d196bb13c61174976ca6d23e6b99eba080a91d8718244c9cee8882','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('497425c31b3dfe768e1ce74f94d44c168c6d15661d3b1a53e096d423ca9bc947',1968,'UG','Uganda','people-and-society',451,'Population: 13,002,000 (January 1979), average annual
growth rate 3.5% (current)
Nationality: noun—Ugandan(s); Aieiive ganda
Ethnic divisions: 99% African, 1%.Européan, Asian, Arab
Religion: about 60% nominally Christian, 5%-10% Mus-
lim, rest animist ,
Language: English official; Luganda and Swahili widely
used; other Bantu and Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which about
250,000 in paid labor, remaining in subsistence activities
Organized labor: 125,000 union members
Population: 262,586,000 (January 1979), average annual
growth rate’ 0.9% (current) -
Nationality: noun—Soviet(s); adjective—Soviet
Ethnic divisions: 74% Slavic, 26% among some 170 ethnic
groups,
Religion: 70% atheist, 18% Russian Orthodox, 9% Musi,
3% other
Language: more ‘had 200 languages and dialects (at least
18 with more than 1 million speakers); 76% Slavic group, 8%
othe: Indo-European, 11% Altaic, 3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 138 million (mid-year 1978), 25%
agriculture, 75% industry and other non-agricultural fields,
unemployed not reported, shortage of skilled labor reported','8c29a2f4948db36dca161ff3408063593c5948539fbf186afcb570bf1e976960','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d644d152d438e636184a4f9136bb0fc20a49625466907192a593a2dda0b4e07',1968,'AE','United Arab Emirates','people-and-society',455,'Population: 656,000 (preliminary total from the census of
29 August 1975) .
Ethnic divisions: Arabs 42%, South Asians 50% (fluctuat-
ing), other expatriates (includes Westerners and East Asians)
8%
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 25% est. (1975)
Labor force: 203,000 (1975 est.); 85% in industry; 2%
U.A.E. Arabs, 7% non-U.A.E. Arabs, 91% Indians, Pakistanis,
Iranians','d38f5aeeffe3cddec61bbad4f587fdf88d1e3c0992022e61449650695df5b2fb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebc77142dc3d38fd1cc9e6e5879ed5be1b8e2c0d4aa0f7c2268bd3f4378458f8',1968,'GB','United Kingdom','people-and-society',459,'Population: 55,846,000 (January 1979) average annual
growth rate —0.1% (current)
Nationality: noun—Briton(s),
adjective—British
Ethnic divisions: 88% English, 9% Scottish, 5% Welsh, 3%
Irish :
Religion: 27.0 million Church of England, 5.3 million
Roman Catholic, 2.0 million Presbyterians, 760,000 Method-
ist, 450,000 Jews (registered)
Language: English, Welsh (about 26% of population of
Wales), Scottish form of Gaelic (about 60,000 in Scotland)
Literacy: 98% to 99%
Labor force: (1974) 25.6 million; 1.6% agriculture, 1.4%
mining, 30.7% manufacturing, 6.2% government, 7.2%
transportation and utilities, 5.2% construction, 10.6% dis-
tributive trades, 25.3% all services, 9.7% other; 2.1%
unemployed :
Organized labor: 40% of labor force
Population: 6,582,000 (January 1979), average annual
growth rate 2.2% (current)
Nationality: noun—Upper Voltan(s); adjective—Upper
‘Voltan
Ethnic divisions: more than 50 tribes; principal tribe is
Mossi (about 2.5 million); other important groups are
Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to
Sudanic family, spoken .by 50% of the population
Literacy: 5%-10% a .
Labor force: about 95% of the - economically active
population engaged in animal husbandry, subsistence farm-
ing, and related agricultural pursuits; about 30,000 are wage
earners; about 20% of male labor force migrates annually to
neighboring countries for seasonal employment
Organized labor: 4 principal trade union . groups','ecdfd3dfe54ae20636a18be8b59fae8cf2d3441d87a38953873b7c61c859af76','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aacd89b273256e68505c5272311ef7f7d8a32cee61c5007bcd6ae4ee445f80de',1968,'WF','Wallis and Futuna','people-and-society',463,'Population: 9,000 (official estimate for 1 July 1973)
Nationality: noun—Wallisian(s), Futunan(s), or Wallis
and Futuna Islander; adjective—Wallisian, Futunan, or
Wallis and Futuna Islanders
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','eee2ded006719b315e3ecd4d0f9059021c8b24cfd43bd59d59294889fe8428ed','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f794b3e14f0d185f34d4d792b62290ec6d93e823c6f94694fa85648c793623f8',1968,'ZM','Zambia','people-and-society',467,'Population: 5,559,000 (January 1979), average annual
growth rate 3.2% (7-76 to 7-77)
Nationality: noun—Zambian(s); adjective—Zambian
Ethnic divisions: 98.7% African, 1.1% European, 0.2%
other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000 Africans,
27,000 non-Africans; 15% mining, 9% agriculture, 9%
230
domestic service, 19% construction, 9% commerce, 10%
manufacturing, 23% government and miscellaneous services,
6% transport
Organized labor: 100,000 wage earners, primarily in
industrial sector, are unionized (early 1968)','7a1c39b19c9f11adb5da0ef73ac3e2bf8fe4b929342f332dca1287f938b9436e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c048f1a2d7e30697e2c5f506d3ab566fc00dc7f4f9139959412372b6d987e114',1968,'US','United States','people-and-society',471,'Population: 219,334,000 (January 1979), average annual
growth rate 0.8% (current)
ZAMBIA/UNITED STATES
Ethnic divisions: 86.5% white, 11.7% black, 1.9% other
Religion: total membership in religious bodies,
129,714,000; Protestant 69,743,000, Roman Catholic
48,882,000, Jewish 6,115,000, other religions 4,973,000 -
(1975) ; : ,
Language: English, predominantly
Literacy: almost complete
Labor force: 96.9 million, unemployment 7.7% (1976)
Organized labor: 20.1% of total (1976 prelim.)','bb7ecf2dd4d3fd7ff27200269fb07b510ad077184d25aba2708254951aaccc8f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

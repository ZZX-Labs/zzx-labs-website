SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9392143ef74ee31940bb5e331d842e41330f2b178bb0cbd6d4a003c5fb944ccf',1968,'BG','Bulgaria','military-and-security',4,'Military Organizations of the People’s Republic of China
CR 81-12564, October 1981, wall chart
Political
Central Government Organizations of the People’s Republic of China,
CR 81-10215, May 1981, wall chart
Politburo of the Chinese Communist Party Central Committee,
CR 81-10218, December 1981, wall chart
Scientific
Directory of Chinese Scientific and Educational Officials,
CR 81-10216, June 1981
Economic
China: The Continuing Search for a Modernization Strategy,
ER 80-10248, April 1980
The Chinese Ministry of Foreign Trade,
CR 80-10343, January 1980, wall chart
Electric Power for China’s Modernization: The Hydroelectric Option,
ER 80-10089U, May 1980
Chinese Defense Spending, 1965-79,
SR 80-10091, July 1980
Military Organizations of the People’s Republic of China,
CR 80-10320, April 1980, wall chart
Political
Directory of Chinese Officials: National Level Organizations,
CR 80-12651, July 1980
Scientific
Hybrid Rice Development and Seed Production in China,
SW 80-10022, May 1980
Economic
China: Agriculture in 1978,
ER 79-10206, April 1979
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
? ‘
China, People’s Republic of (continued)
China: Demand for Foreign Grain,
ER 79-10073, January 1979
China: Post-Mao Search for Civilian Industrial Technology,
ER 79-10020U, February 1979
China: A Statistical Compendium,
ER 79-10374, July 1979
China: The Steel Industry in the 1970s and 1980s,
ER 79-10245, May 1979 }
Chinese Coal Industry: Prospects Over the Next Decade,
ER 79-10092, February 1979
Political
Chinese Communist Party Organizations,
CR 79-14074, August 1979, wall chart
Chinese Ministry of Foreign Affairs,
CR 79-11830, October 1979, wall chart
Politburo of the 11th Chinese Communist Party Central Committee,
CR 79-10564, March 1979
Scientific
Academies of Sciences and Social Sciences of the People’s Republic of China,
CR 79-12497, May 1979, wall chart
Directory of Chinese Scientific and Educational Officials,
CR 79-11870, April 1979
Plant Breeding and Protection Research for Food Production in China,
SI 79-10024, March 1979
Economic
China: Economic Indicators,
ER 78-10750, December 1978
China: Gross Value of Industrial Output, 1965-77,
ER 78-10355, June 1978
China: In Pursuit of Economic Modernization,
ER 78-10680, December 1978
China: International Trade, 1977-78,
ER 78-10721, December 1978
China: The Nonferrous Metals Industry in the 1970s,
ER 78-10104U, May 1978
Geographic
China City Brief, Hsi-an,
GC 78-10170, 1978
China City Brief, Pao-t’ou,
GC 78-10171, 1978
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
’ q
China, People’s Republic of (continued)
Military Organizations of the People’s Republic of China,
CR 78-11398, May 1978, wall chart
Political
Central Government Organizations of the People’s Republic of China,
CR 78-11613, May 1978, wall chart
Central Government Organizations of the People’s Republic of China,
CR 78-13497, August 1978, wall chart
Chinese Communist Party Organization,
CR 78-14919, December 1978, wall chart
Directory of Officials of the People’s Republic of China,
CR 78-11373, April 1978
Directory of Officials of the People’s Republic of China,
CR 78-16506, November 1978
Ministry of Foreign Affairs—People’s Republic of China,
CR 78-10122, April 1978, wall chart
Economic
China: Economic Indicators,
ER 77-10508, October 1977
China: International Trade, 1976-77,
ER 77-10674, November 1977
China: 1977 Midyear Grain Outlook,
ER 77-10606, October 1977
China Oil Production Prospects, |
ER 77-10030U, June 1977
China: Real Trends in Trade With Non-Communist Countries Since 1970,
ER 77-10477, October 1977
China’s Cement Industry,
ER 77-10704, November 1977
China''s Economy,
ER 77-10738, November 1977
Foreign Trade Organizations of the People’s Republic of China,
CR 77-13037, July 1977, wall chart
Political
China: A Look at the 11th Central Committee,
RP 77-10276, October 1977
The Chinese Communist Party Central Committee—
Members Elected at the 11th Party Congress,
CR 77-14473, September 1977
Chinese Communist Party Organizations,
CR 77-13125, September 1977, wall chart
Directory of Officials of the People’s Republic of China,
CR 77-15208, October 1977
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
4
China, People’s Republic of (continued)
Foreign Affairs Organization of the People’s Republic of China,
CR 77-12843, June 1977, wall chart
Politburo of the Chinese Communist Party,
CR 77-15211, December 1977, wall chart
Economic
China: Agricultural Performance in 1975,
ER 76-10149, March 1976
China’s Minerals and Metals Position in the World Market,
ER 76-10150, March 1976
China: The Coal Industry,
ER 76-10691, November 1976
Chinese Merchant Ship Production,
ER 76-10193, March 1976
People’s Republic of China: Estimated Yuan Value of Foreign Trade in
Machinery and Equipment, 1951-73,
ER 76-10250, April 1976
People’s Republic af China: Handbook of Economic Indicators,
ER 76-10540, August 1976
People’s Republic of China: International Trade Handbook,
ER 76-10610, October 1976
People’s Republic of China: Timber Production and End Uses,
ER 76-10493, October 1976
Military Organizations of the People’s Republic of China,
CR 76-12748, June 1976, wall chart
Political
Central Government Organizations of the People’s Republic of China,
CR 76-14670, November 1976, wall chart
Chinese Communist Party Organization,
CR 76-11230, March 1976, wall chart
Foreign Affairs Organization of the People’s Republic of China,
CR 76-10905, March 1976, wall chart
Politburo of the Chinese Communist Party,
CR 76-12982, July 1976, wall chart
Scientific .
Civilian Scientific Research Academies in the People’s Republic of China,
CR 76-10211, January 1976
Economic
China: Energy Balance Projections,
A (ER) 75-75, November 1975
Foreign Trade Organizations of the People’s Republic of China,
A (CR) 75-6, February 1975, wall chart
5
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
} i
China, People’s Republic of (continued)
People’s Republic of China: Chemical Fertilizer Supplies, 1949-74,
A (ER) 75-70, August 1975
People’s Republic of China: Foreign Trade in Machinery
and Equipment Since 1952,
A (ER) 75-60, January 1975
People’s Republic of China: Handbook of Economic Indicators,
A (ER) 75-72, August 1975
People’s Republic of China: International Trade Handbook,
A (ER) 75-73, October 1975
Prices of Machinery and Equipment in the People’s Republic of China,
A (ER) 75-64, May 1975 ,
Production of Machinery and Equipment in the People’s Republic of China,
A (ER) 75-63, May 1975
Value Added by Work Brigades in Railroad and
Highway Construction in China 1952-57,
A (ER) 75-74, November 1975
Geographic
China City Briefs,
November 1975
Military Organizations of the People’s Republic of China,
A (CR) 75-21, June 1975, wall chart
Political
Bibliography of Literature Written in the People’s Republic
of China During the Campaign to Criticize Lin Piao
and Confucius, July 1973-December 1974,
A (CR) 75-40, October 1975
Central Government Organizations of the People’s Republic of China,
A (CR) 75-37, September 1975, wall chart
Chinese Communist Party Organization,
A (CR) 75-34, August 1975, wall chart
Directory of Officials of the People’s Republic of China,
A (CR) 75-16, April 1975
Foreign Organizations of the People’s Republic of China,
A (CR) 75-22, June 1975, wall chart
Politburo of the Chinese Communist Party,
A (CR) 75-42, November 1975, wall chart
Economic
An Index of Construction Activity in China,
A (ER) 74-9, March 1974
China: Role of Small Plants in Economic Development,
A (ER) 74-60, May 1974
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
t ‘
China, People’s Republic of (continued)
People’s Republic of China: International Trade Handbook,
A (ER) 74-63, September 1974
Military Organizations of the People’s Republic of China,
A (CR) 74-14, April 1974, wall chart
Political
Chinese Communist Party Organization,
A (CR) 74-24, July 1974, wall chart
Foreign Affairs Apparatus of the People’s Republic of China,
A (CR) 74-10, March 1974, wall chart
Politburo of the Chinese Communist Party,
A (CR) 74-5, wall chart
Economic
People’s Republic of China: International Trade Handbook,
A 73-29, October 1973
Political
Chinese Communist Party Provincial Leaders,
A 73-2, January 1973
Directory of Officials of the People’s Republic of China,
A 73-35, December 1973
Economic
People’s Republic of China: International Trade Handbook,
A 72-38, December 1972
Political
Chinese Communist Party Central Committee,
A 72-11, 1972
Directory of Officials of the People’s Republic of China,
A 72-21, August 1972','09db03fad4861741f41f095bde95e7aaf5ad3265f64d4c0fae98295d34fcbe57','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed201e2dea5bb61a2b5512fa655c58faaf3ae702516a846564fde2d884fa0203',1968,'CU','Cuba','military-and-security',5,'Cuban Chronology, 1978-1980,
PA 81-10068, February 1981
The Cuban Economy: A Statistical Review,
ER 81-10052, PA 81-10074, March 1981
Cuban Leadership,
CR 81-11989, June 1981, wall chart
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
) 1
Cuba (continued)
Directory of Officials of the Republic of Cuba,
CR 81-11988, June 1981
Cuban Chronology, 1977-79,
PA 80-10173, April 1980
Cuban Leadership,
CR 80-11711, September 1980, wall chart
Cuban Chronology,
RP 79-10162, April 1979
Cuban Leadership,
CR 79-10001, January 1979, wall chart
Cuban Leadership,
CR 79-15445, October 1979, wall chart
Directory of Cuban Officials,
CR 79-10002, January 1979
Directory of Officials of the Republic af Cuba,
CR 79-15444, October 1979
Cuban Chronology,
RP 78-10073, March 1978
Cuban Leadership,
CR 78-11610, June 1978, wall chart
Directory of the Cuban Government and Mass Organizations,
CR 78-11938, June 1978
Directory of the Cuban Government and Mass Organizations,
CR 77-16183, December 1977
The Cuban Economy: A Statistical Review, 1968-76,
ER 76-10708, December 1976
Cuba: Foreign Trade,
A (ER) 75-69, July 1975
Directory of Personalities of the Cuban Government,
A (CR) 74-7, March 1974
Directory of Personalities of the Cuban Government
Official Organizations and Mass Organizations,
A 73-12, May 1973
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
C ‘
Czechoslovakia
Directory of Officials of the Czechoslovak Socialist Republic,
CR 80-11926, July 1980
Czechoslovak Communist Party (KSC),
CR 79-12585, September 1979, wall chart
Government of the Czechoslovak Socialist Republic,
CR 79-12586, September 1979, wall chart
Directory of Officials of the Czechoslovak Socialist Republic,
CR 78-14528, September 1978
Czechoslovak Socialist Republic Party and Government,
A (CR) 74-28, August 1974, wall chart
Directory of Czechoslovak Officials,
A 72-17, August 1972
Eastern Europe
Estimating Soviet and East European Hard Currency Debt,
ER 80-10327, June 1980
Energy Supplies in Eastern Europe: A Statistical Compilation,
ER 79-10624, December 1979
Foreign Trade of East European Communist Countries -
1960-70 - A Statistical Summary,
A 72-15, July 1972
German Democratic Republic
Directory of Officials of the German Democratic Republic,
CR 80-10125, January 1980
German Democratic Republic Socialist Unity Party (SED),
CR 80-11911, October 1980, wall chart
Government of the German Democratic Republic,
CR 80-11910, October 1980, wall chart
Directory of Officials of the German Democratic Republic,
CR 78-11599, April 1978
Government of the German Democratic Republic,
CR 77-10002, February 1977, wall chart
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
) re |
German Democratic Republic (continued)
German Democratic Republic Socialist Unity Party,
CR 76-13076, November 1976, wall chart
Directory of Officials of the German Democratic Republic,
A (CR) 75-44, November 1975
German Democratic Republic Party and Government Structure,
A (CR) 75-30, August 1975, wall chart
Directory of East German Officials,
A 72-40, December 1972','95e6d4afbd9db0803652b3477415a759e040bbe07fd7e2b0b081502ca2f16026','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a220e78910600ee4d6fb17215b52a1e4855ee0ac544c06b43a3eba91118a09ec',1968,'HU','Hungary','military-and-security',6,'Government of the Hungarian People’s Republic,
CR 81-10088, February 1981, wall chart
Hungarian Socialist Worker''s Party,
CR 81-10089, February 1981, wall chart
Directory of Officials of the Hungarian People’s Republic,
CR 79-15804, October 1979
Directory of Officials of the Hungarian People’s Republic,
CR 78-14039, August 1978
Government of the Hungarian People’s Republic,
CR 78-13619, September 1978, wall chart
Hungarian Socialist Worker''s Party,
CR 78-13620, September 1978, wall chart
Directory of Officials of the Hungarian People’s Republic,
A (CR) 75-1, January 1975
Hungarian People’s Republic Government and Party Structure,
A (CR) 75-33, September 1975, wall chart','7985335bf55eda351f34c412543fc0422dedf86bfdbd945818e059ea238fa08e','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('943b273cac28364a6ffcaa6c71cd34dea9fd5e0d19b4377b1c69d82ea3bfbd18',1968,'JP','Japan','military-and-security',7,'Japanese Cabinet Ministers and Leaders of the Liberal Democratic Party,
A (CR) 75-13, April 1975, wall chart
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Kampuchea
Bleak Prospects for Meeting Kampuchean Food Needs,
GC 80-10034, April 1980
Kampuchea: A Demograhic Catastrophe,
GC 80-10019U, May 1980
Democratic Cambodia Government Structure,
CR 77-12966, August 1977, wall chart
Korea, Democratic People’s Republic of
Directory of Officials, Democratic People’s Republic of Korea,
CR 81-11025, April 1981
Party Organization and Structure of DPRK,
CR 81-11024, April 1981, wall chart
Directory of Officials of the Democratic People’s Republic of Korea,
CR 80-11041, March 1980
Government Structure of the Democratic People’s Republic of Korea,
CR 80-10353, March 1980, wall chart
Directory of Officials of the Democratic People’s Republic of Korea,
CR 79-12254, May 1979
Directory of Officials af the Democratic People’s Republic of Korea,
CR 78-11396, April 1978
Government Structure of the Democratic People’s Republic of Korea,
CR 78-10194, April 1978, wall chart
Korea: The Economic Race Between the North and the South,
ER 78-10008, January 1978
Democratic People’s Republic of Korea Party and Government Structure,
CR 77-11706, April 1977, wall chart
Democratic People’s Republic of Korea Party and Government Structure,
CR 76-10904, March 1976, wall chart
North Korean Party and Government Structure,
A (CR) 74-27, August 1974, wall chart
North Korean Party and Government Structure,
A 73-15, April 1973, wall chart
Directory of North Korean Officials,
A 72-19, August 1972
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
a |','161c050ef7a59084f9fa9d691d1a95d07abb13c2f39b7f939855b0b90378aa15','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4732e6f7b099008a9831946072e0a1f5ab8c796d45bdd96f4abef349a80e44ee',1968,'KR','Korea, Republic of','military-and-security',8,'Korea: The Economic Race Between the North and the South,
ER 78-10008, January 1978
Laos
Lao People’s Democratic Republic Party and Government Structure,
CR 79-10822, May 1979, wall chart
Lao People’s Democratic Republic Party and Government Structure,
CR 77-10787, March 1977, wall chart','31909a762944ecabde46c80a49285a29b1dda83aa0dec70e6edf7914c40d2248','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3db86683ad564420924c93ef5a6c921eaad21dfba59a254a8b08836aec61c6c4',1968,'PL','Poland','military-and-security',9,'Directory of Officials of the Polish People’s Republic,
CR 79-14078, August 1979
Economic
The Scope of Poland’s Economic Dilemma,
ER 78-10340U, July 1978
Political
Directory of Officials of the Polish People’s Republic,
CR 78-13478, July 1978
Polish People’s Republic Government Structure,
CR 78-10278, February 1978, wall chart
Polish People''s Republic Party Structure,
CR 78-10114, February 1978, wall chart
Directory of Officials of the Polish People’s Republic,
CR 77-13209, July 1977
Polish People’s Republic: Government and Party Structure,
CR 76-13415, November 1976, wall chart
Polish People’s Republic Government and Party Structure,
A (CR) 74-41, December 1974, wall chart
Directory of Polish Officials,
A 73-4, February 1973
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
t v','6602bd375140742503b24519e5d56b733d7251530cd0ad061c450925dfa3e156','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd2fd095f6005c92778803fca64a00d65c521ab09165008d9bb1718b283dbe18',1968,'RO','Romania','military-and-security',10,'Government of the Socialist Republic of Romania,
CR 81-10108, April 1981, wall chart
Romanian Communist Party,
CR 81-10107, April 1981, wall chart
Directory of Officials of the Socialist Republic of Romania,
CR 80-13258, August 1980
Directory of Officials of the Socialist Republic of Romania,
CR 79-15012, September 1979
Directory of Officials of the Socialist Republic of Romania,
CR 77-15215, November 1977
Socialist Republic of Romania: Government Structure,
CR 77-15883, December 1977, wall chart
Socialist Republic of Romania: Party Structure,
CR 77-16679, December 1977, wall chart
Directory of Officials of the Socialist Republic of Romania,
CR 76-12095, July 1976
Romanian Socialist Republic Government and Party Structure,
A (CR) 75-28, August 1975, wall chart
Directory of Romanian Officials,
A 73-24, August 1973','28addcb1f59335e25a9dfbb48defa8f37f6520e8185cd245db5ebca6f2276ad7','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c30410cb0cb2451af20e42890277338c687efcb54a4ff9478a01cc82baf1a1be',1968,'TH','Thailand','military-and-security',11,'The Refugee Resettlement Problem in Thailand,
GC 78-10048U, May 1978
USSR
Economic
USSR: Seasonality in Energy Production and Foreign Trade,
ER 81-10004, February 1981
Soviet and US Defense Activities, 1971-80: A Dollar Cost Comparison,
SR 81-10005, January 1981
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
1 i]
USSR (continued)
Political
CPSU Central Committee and Central Auditing Commission,
CR 81-11349, May 1981, wall chart
CPSU Central Committee: Executive and Administrative Apparatus,
CR 81-11128, April 1981, wall chart
CPSU Politburo and Secretariat,
CR 81-10183, April 1981, wall chart
Directory of Soviet Officials: National Organizations,
CR 81-11343, May 1981
Soviet Leadership Since Stalin,
CR 81-10182, April 1981, wall chart
USSR Council of Ministers,
CR 81-10155, April 1981, wall chart
Scientific
USSR State Committee for Science and Technology,
CR 81-11110, June 1981, wall chart
Economic
Central Siberian Brown Coal as a Potential Source of Power for European Russia,
SW 80-10006, April 1980
Directory of USSR Foreign Trade Organizations and Officials,
CR 80-10788, March 1980
Energy Decisionmaking in the USSR,
CR 80-10623, August 1980, wall chart
Estimating Soviet and East European Hard Currency Debt,
ER 80-10327, June 1980
The Lead and Zinc Industry in the USSR,
ER 80-10072, March 1980
The Soviet Economy in 1978-79 and Prospects for 1980,
ER 80-10328, June 1980
USSR and the United States: Price Ratios for Machinery, 1967 Rubles — 1972
Dollars, Volume I and Volume I,
ER 80-10410, September 1980
USSR: Coal Industry Problems and Prospects,
ER 80-10154, March 1980
Geographic
Moscow S. treet Guide, May 1980
\\
\\
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
USSR (continued)
Directory af USSR Ministry of Defense and Armed Forces Officials,
CR 80-11888, April 1980
Organization of the USSR Ministry of Defense,
CR 80-11951, September 1980, wall chart
Political Control of the Soviet Armed Forces,
SR 80-10058U, July 1980
Soviet and US Defense Activities, 1970-79: A Dollar Cost Comparison,
SR 80-10005, January 1980
Political
CPSU Central Committee: Executive and Administrative Apparatus,
CR 80-10002, February 1980, wall chart
CPSU Politburo and Secretariat: Positions and Responsibilities,
CR 80-10001, February 1980, wall chart
Directory of Soviet Officials, Volume II: RSFSR Orgameations,
CR 80-13212, July 1980
Directory of USSR Ministry of Foreign Affairs Officials,
CR 80-13493, August 1980
Key Soviet-Yugoslav Documents,
PA 80-10032, February 1980
Soviet Leadership Since Stalin: CPSU Politburo and Secretariat, 1952-79,
CR 80-10003, February 1980, wall chart
Scientific
Directory of Soviet Officials, Volume IV: Science and Education,
CR 80-13202, July 1980
Economic
An Analysis of the Behavior of Soviet Machinery Prices, 1960-73,
ER 79-10631, December 1979
Simulations of Soviet Growth Options to 1985,
ER 79-10131, March 1979
Soviet Strategy and Tactics in Economic and Commercial
Negotiations With the United States,
ER 79-10276, June 1979
SOVSIM: A Model of the Soviet Economy,
ER 79-10001, February 1979
USSR: Long-Term Outlook for Grain Imports,
ER 79-10057, January 1979
USSR: Ministry of Foreign Trade,
CR 79-10007, May 1979, wall chart
USSR: Role of Foreign Technology in the
Development of the Motor Vehicle Industry,
ER 79-10571, October 1979
USSR: Trends and Prospects in Educational Attainment, 1959-85,
ER 79-10344, June 1979
15
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
t 1
USSR (continued)
~~ A Dollar Cost Comparison of Soviet and US Defense Activities, 1 968-78,
SR 79-10004, January 1979
Political
CPSU Central Committee: Executive and Administrative Apparatus,
CR 79-10464, January 1979, wall chart
CPSU Central Committee: Executive and Administrative Apparatus,
CR 79-12053, May 1979, wall chart
CPSU Politburo and Secretariat: Positions and Responsibilities,
CR 79-12092, May 1979, wall chart
Directory of Soviet Officials, Volume I: National Organizations,
CR 79-16593, November 1979
Directory of Soviet Officials, Volume II: RSFSR Organizations,
CR 79-10005, March 1979
Directory of Soviet Officials, Volume IH: Union Republics,
CR 79-11484, March 1979
Evolution of the Central Administrative Structure of the USSR, 1917-79,
CR 79-10123, August 1979, wall chart
The Soviet Leadership Since Stalin: CPSU Politburo and Secretariat, 1952-79,
CR 79-14399, August 1979, wall chart
USSR State Committee for Science and Technology,
CR 79-10070, November 1979, wall chart
Economic
Changing Patterns in Soviet-LDC Trade, 1976-77,
ER 78-10326, May 1978
Soviet Agricultural Commodity Trade, 1960-76: A Statistical Survey,
ER 78-10516, September 1978
Soviet Chemical Equipment Purchases From the West:
Impact on Production and Foreign Trade,
ER 78-10554, October 1978
The Soviet Economy in 1976-77 and Outlook for 1978,
ER 78-10512, August 1978
USSR: Development of the Gas Industry,
ER 78-10393, July 1978
USSR: Toward a Reconciliation of Marxist and
Western Measures of National Income,
ER 78-10505, October 1978
Directory of USSR Ministry of Defense and Armed Forces Officials,
CR 78-10471, April 1978
Directory of USSR Ministry of Defense and Armed Forces Officials,
CR 78-15073, October 1978
A Dollar Cost Comparison of Soviet and US Defense Activities, 1967-77,
SR-10002, January 1978
16
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
USSR (continued)
Estimated Soviet Defense Spending: Trends and Prospects,
SR 78-10121, June 1978
Soviet Civil Defense,
NI 78-10003, July 1978
Political
CPSU Politburo and Secretariat: Positions and Responsibilities,
CR 78-15480, December 1978, wall chart
Directory of Soviet Officials, Volume I: National Organizations,
CR 78-14025, September 1978
Organization of the USSR Ministry of Defense,
CR 78-15257, December 1978, wall chart
USSR Council of Ministers,
CR 78-15321, December 1978, wall chart
The USSR Leadership: Party and Government,
CR 78-15494, December 1978, wall chart
Scientific
Biological and Environmental Factors Affecting Soviet Grain Quality,
SI 78-10057/A/U, December 1978
Directory of Soviet Research Organizations,
CR 78-11336, March 1978
Influence of Agrotechnology and Geoclimate
on Grain Yield Potential in the USSR,
SI 78-10058, May 1978
Economic
The Impact of Fertilizer on Soviet Grain Output, 1960-80,
ER 77-10557, November 1977
Organization and Management in the Soviet Economy:
The Ceaseless Search for Panaceas,
ER 77-10769, December 1977
Prospects for Soviet Oil Production,
ER 77-10270, April 1977
Prospects for Soviet Oil Production: AS eaeeaal Analysis,
ER 77-10425, July 1977
Peconciliation of Soviet and Western Foreign Trade Statistics,
ER 77-10132, May 1977
Soviet Commercial Operations in the West,
ER 77-10486, September 1977
Soviet Economic Problems and Prospects,
ER 77-10436U, July 1977
The Soviet State Budget Since 1965,
ER 77-10529, December 1977
Soviet Tin Industry: Recent Developments and Prospects Through 1980,
ER 77-10011, January 1977
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
'' J
USSR (continued)
USSR: Hard Currency Trade and Payments, 1977-78,
ER 77-10035U, March 1977
USSR Ministry of Agriculture,
CR 77-11900, April 1977, wall chart
USSR Ministry of Foreign Trade,
CR 77-13114, June 1977, wall chart
USSR: Some Implications of Demographic Trends for Economic Policies,
ER 77-10012, January 1977
Directory of USSR Ministry of Defense and Armed Forces Officials,
CR 77-12060, May 1977
A Dollar Cost Comparison of Soviet and US Defense Activities, 1966-76,
SR 77-10001U, January 1977
Political
Communist Party of the Soviet Union (CPSU) Central
Committee: Executive and Administrative Apparatus,
CR 77-10017, March 1977, wall chart
Communist Party of the Soviet Union (CPSU) Central
Committee: Executive and Administrative Apparatus,
CR 77-13211, October 1977, wall chart
Communist Party of the Soviet Union (CPSU) Politburo
and Secretariat: Positions and Responsibilities,
CR 77-10225, January 1977, wall chart
Directory of USSR Ministry of Foreign Affairs Officials,
CR 77-11829, April 1977
USSR Council of Ministers,
CR 77-13213, September 1977, wall chart
The USSR Leadership: Party and Government,
CR 77-14798, December 1977, wall chart
Scientific
Membership, USSR Academy of Sciences,
CR 77-11360, March 1977
Economic
Directory of USSR Foreign Trade Organizations and Officials,
CR 76-11076, April 1976
Directory of USSR Foreign Trade Organizations and Officials,
CR 76-15051, December 1976
Recent Developments in Soviet Hard Currency Trade,
ER 76-10015, January 1976
Ruble-Dollar Ratios for Construction,
ER 76-10068, February 1976 ;
Soviet Economic Plans for 1976-80: A First Look,
ER 76-10471, August 1976
18
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
USSR (continued)
The Soviet Economy: Performance in 1975 and Prospects for 1976,
ER 76-10296, May 1976
USSR: The Impact of Recent Climate Change on Grain Production,
ER 76-10577U, October 1976
Directory af USSR Ministry of Defense and Armed Forces Officials,
CR 76-14079, September 1976
A Dollar Comparison of Soviet and US Defense Activities 1965-1975,
SR 76-10053, February 1976
Estimated Soviet Defense Spending in Rubles, 1970-1975,
SR 76-10121U, May 1976
Political
Communist Party of the Soviet Union (CPSU) Central
Committee: Executive and Administrative Apparatus,
CR 76-12718, August 1976, wall chart
Communist Party of the Soviet Union (CPSU) Politburo
and Secretariat: Positions and Responsibilities,
CR 76-10845, March 1976, wall chart
The CPSU Central Committee and Central Auditing
Commission—Members Elected at the 25th Party Congress,
CR 76-11259, August 1976
The CPSU Under Brezhnev,
CI 76-10019U, April 1976
Directory of Soviet Officials, Volume H: RSFSR,
CR 76-14711, December 1976
Directory of USSR Ministry of Foreign Affairs Officials,
CR 76-11637, April 1976
USSR Council of Ministers,
CR 76-12970, August 1976, wall chart
USSR Council of Ministers, ,
CR 76-14815, December 1976, wall chart
USSR Institute of the United States of America and Canada,
CR 76-10864, April 1976
The USSR Leadership: Party and Government,
CR 76-10979, April 1976, wall chart
The USSR Leadership: Party and Government,
CR 76-15094, December 1976, wall chart
Scientific
Directory of Soviet Research Organizations,
CR 76-14379, October 1976
Economic
The Soviet Economy. 1974 Results and 1975 Prospects,
A (ER) 75-62, March 1975
19
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
t ’
USSR (continued)
The Soviet Grain Balance, 1960-73,
A (ER) 75-68, September 1975
Soviet Long-Range Energy Forecasts,
A (ER) 75-71, September 1975
USSR: Gross National Product Accounts, 1970,
A (ER) 75-76, November 1975
USSR: Long-Range Prospects for Hard Currency Trade,
A (ER) 75-61, January 1975
Directory of USSR Ministry of Defense and Armed Forces Officials,
A (CR) 75-14, April 1975
Directory of USSR Ministry of Defense and Armed Forces Officials,
A (CR) 75-41, November 1975
Political
Communist Party of the Soviet Union (CPSU) Central Committee:
Executive and Administrative Apparatus,
A (CR) 75-19, June 1975, wall chart
Directory of Soviet Officials, Volume I: National Organizations,
A (CR) 75-45, December 1975
Directory of Soviet Officials, Volume III: Union Republics,
A (CR) 75-18, May 1975
USSR Council of Ministers,
A (CR) 75-12, March 1975, wall chart
USSR Council of Ministers,
A (CR) 75-36, September 1975, wall chart
Scientific
Membership, USSR Academy of Sciences,
A (CR) 75-4, January 1975
Economic
Directory of USSR Foreign Trade Organizations and Officials,
A (CR) 74-3, January 1974
Directory of USSR Foreign Trade Organizations and Officials,
CR 74-42, December 1974
The Soviet Economy in 1973: Performance, Plans, and Implications,
A (ER) 74-62, July 1974
Geographic
Moscow Street Guide 1974
Directory of USSR Ministry of Defense and Armed Forces Officials,
A(CR) 74-1, January 1974
20
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
USSR (continued)
Directory af USSR Ministry of Defense and Armed Forces Officials,
A (CR) 74-29, August 1974
Political
Communist Party of the Soviet Union (CPSU) Central Committee: Executive and
Administrative Apparatus,
A (CR) 74-16, April 1974, wall chart
Communist Party of the Soviet Union (CPSU) Central Committee: Executive and
Administrative Apparatus,
A (CR) 74-38, November 1974, wall chart
Communist Party of the Soviet Union (CPSU) Politburo and Secretariat: ©
Positions and Responsibilities,
A (CR) 74-35, September 1974, wall chart
Directory of USSR Ministry of Foreign Affairs Officials,
A (CR) 74-26, July 1974
USSR Council of Ministers,
A (CR) 74-17, April 1974, wall chart
USSR Council of Ministers, ,
A (CR) 74-34, August 1974, wall chart
Political
Directory of Soviet Officials, Volume I: National Organizations,
A 73-31, November 1973
Directory of Ukrainian Officials,
A 73-8, March 1973
Scientific
Membership, USSR Academy of Sciences,
A 73-18, May 1973
Economic
Central Economic Administrative Structure of the USSR,
A 72-14, July 1972, part one of wall chart
Directory of USSR Ministry of Foreign Trade Officials,
A 72-37, December 1972
Evolution of the Central Administrative Structure of the USSR,
A 72-14, August 1972, part two of wall chart
Political
CPSU Central Committee,
March 1972, wall chart
CPSU Politburo and Secretariat,
A 72-26.1, August 1972, photo wall chart
CPSU Politburo and Secretariat,
A 72-26.3, August 1972, photo wall chart
Directory of HO Personnel—USSR Ministry of Foreign Affairs,
A 72-31, October 1972
21
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
USSR (continued)
USSR Council of Ministers,
March 1972, wall chart
USSR Council of Ministers,
A 72-26.2, August 1972, wall chart
Vietnam
Government Structure of the Socialist Republic of Vietnam,
CR 81-12565, July 1981, wall chart
Directory of Officials of the Socialist Republic of Vietnam,
CR 80-15659, December 1980
Socialist Republic of Vietnam Party and Government Structure,
CR 78-16350, December 1978, wall chart
Council of Ministers of the Socialist Republic of Vietnam,
CR 77-10004, January 1977
Socialist Republic of Vietnam Party and Government Structure,
CR 77-10229, March 1977, wall chart
Socialist Republic of Vietnam Party and Government Structure,
CR 76-12948, October 1976, wall chart
Democratic Republic of Vietnam Party and Government Structure,
A (CR) 75-31, August 1975, wall chart
Democratic Republic of Vietnam Party and Government Structure,
A (CR) 74-19, May 1974, wall chart
Yugoslavia
Directory of Officials of the Socialist Federal Republic of Yugoslavia,
CR 81-10083, February 1981
Key Soviet-Yugoslav Documents,
PA 80-10032, February 1980
Directory of Officials of the Socialist Federal Republic of Y'' ugoslavia,
CR 79-11490, April 1979
Structure of the League of Communists of Yugoslavia (LCY),
CR 79-11245, August 1979, wall chart
Yugoslavia Government Structure,
CR 79-11244, August 1979, wall chart
22
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
c
Yugoslavia (continued)
Yugoslavia Government Structure,
CR 79-11244, August 1979, wall chart
Directory of Officials of the Socialist Federal Republic of Yugoslavia,
CR 76-10408, February 1976
Yugoslav Socialist Federal Republic Party and Government Structure,
A (CR) 75-3, January 1975, wall chart
Directory of Yugoslav Officials,
A 72-12, February 1972
Government and Party Leaders of the Socialist Federal Republic of Yugoslavia,
May 1972, wall chart
International
Handbook of Economic Statistics, 1981,
NF HES 81-001, November 1981
Patterns of International Terrorism: 1980,
PA 81-10163U, June 1981
US Export Competitiveness: A Review and Evaluation,
ER 81-10044, February 1981
Ariane: A European Space Launch Vehicle,
SW 80-10074, October 1980
Communist Aid Activities in Non-Communist Less Developed Countries, 1979 and 1954-79,
ER 80-10318U, October 1980
Comparing Planned and Actual Growth of Industrial Output in Centrally Planned Economics,
ER 80-10461, August 1980
Developed Country Imports of Manufactured Products From LDCs,
ER 80-10476, September 1980
Handbook of Economic Statistics, 1980,
ER 80-10452, October 1980
International Terrorism in 1979,
PA 80-10072U, April 1980
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
t
,
International (continued)
The New Global Fishing Regime: Impact and Response,
GC 80-10029, June 1980
Non-OPEC LDCs. External Debt Positions,
ER 80-10030, January 1980
OECD Countries: Unemployment in the 1970s and Perspectives for the 1980s,
ER 80-10579, November 1980
The OECD Steel Industries: Difficult Years Ahead,
ER 80-10513, October 1980
Some Perspectives on Oil Availability for the Non-OPEC LDCs,
ER 80-10493, September 1980
The Burgeoning LDC Steel Industry: More Problems for Major Steel Producers,
ER 79-10425, July 1979
Communist Aid Activities in Non-Communist Less Developed Countries, 1978,
ER 79-10412U, September 1979
Foreign Development and Application of Automated Controls
Sor the Steel Industry,
SI 79-10010, January 1979
A Guide to Political Acronyms,
PA 79-10474, October 1979
Handbook of Economic Statistics, 1979,
ER 79-10274, August 1979
The Holocaust Revisited: A Retrospective Analysis of the
Auschwitz—Birkenau Extermination Complex,
ST 79-10001, February 1979
International Political Effects of the Spread of Nuclear Weapons,
unnumbered, April 1979
International Terrorism in 1978,
RP 79-10149, March 1979
Non-OPEC LDC Terms of Trade, 1970-77,
ER 79-10145, March 1979
Recent Gains in Nonfuel Trade Between the Developing Nations,
ER 79-10067, March 1979
The US Position in World Markets,
ER 79-10305, May 1979
The US Position in World Markets,
ER 79-10466, August 1979
The World Oil Market in the Years Ahead,
ER 79-10327U, August 1979
Arms Flows to LDCs: US-Soviet Comparisons, 1974-77,
ER 78-10494U, November 1978
Communist Aid to Less Developed Countries of the Free World, 1977,
ER 78-10478U, November 1978
East African Desert Locust Threat Increasing,
SI 78-10093, September 1978
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
International (continued)
Handbook of Economic Statistics, 1978,
ER 78-10365, October 1978
International Terrorism in 1977,
RP 78-10255U, August 1978
Least Developed Countries: Economic Characteristics
and Stake in North-South Issues,
ER 78-10253, May 1978
Non-OPEC LDCs: Changing Patterns of Official Economic Aid Flows,
ER 78-10114, March 1978
Relating Climate Change to Its Effects,
GC 78-10154, August 1978
The Role of the LDCs in the US Balance of Payments,
ER 78-10484, September 1978
1977 Communist Aid to the Less Developed Countries of the Free World, 1976,
v ER 77-10296U, August 1977
Handbook of Economic Statistics, 1977,
ER 77-10537, September 1977
The International Energy Situation: Outlook to 1985,
ER 77-10240U, April 1977
International Terrorism in 1976,
RP 77-10034U, July 1977
Major Oil and Gas Fields of the Free World,
ER 77-10313, June 1977
Major Petroleum Refining Centers for Export,
ER 77-10140, April 1977
Natural Gas,
ER 77-10062, February 1977
Nuclear Energy,
ER 77-10468, August 1977
World Shipbuilding: Facing Up to Overcapacity,
ER 77-10678, November 1977
World Steel Market: Continued Trouble Ahead,
ER 77-10351U, May 1977
An Analysis of the Cyclical Dynamics of Industrialized Countries,
PR 76-10009, January 1976
Annotated Bibliography on Transnational and International Terrorism,
PR 76-10073U, December 1976
. Communist Aid to Less Developed Countries of the Free World, 1976,
ER 76-10372U, July 1976
Handbook of Economic Statistics,
ER 76-10481, September 1976
International and Transnational Terrorism: Diagnosis and Prognosis,
PR 76-10030, April 1976
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
r ''
International (continued)
Major Oil and Gas Fields of the Free World,
ER 76-10001, January 1976
Non-OPEC LDCs: Terms of Trade Since 1970,
ER 76-10383, June 1976
OPEC Countries: Current Account Trends, 1975-76,
ER 76-10370, June 1976
Profile of Violence: Analytical Model,
PR 76-10025, June 1976
A Study of Climatological Research as it Pertains to Intelligence Production,
(no publication number)
Export Refining Centers of the World,
A (ER) 75-66, June 1975
Free World Oil Refineries,
A (ER) 75-67, December 1975
Handbook of Economic Statistics, 1975,
A (ER) 75-65, August 1975
Methods of Constructing Economic Indexes From Incomplete Data,
A (ER) 74-64, December 1974
Potential Implications of Trends in World Population,
Food Production, and Climate,
OPR, 401, August 1974
World Oil Refineries,
A (ER) 74-61, June 1974
Serials
Appearances and Activities of Leading Personalities of the People’s Republic of
China, published semiannually in 1972-73 and annually since 1974. In DOCEX
since 1972.
Appearances of Soviet Leaders, published semiannually in 1972-78 and annually
since 1979. In DOCEX since 1972.
Chiefs of State and Cabinet Members of Foreign Governments, published
_ monthly. In DOCEX since February 1972.
China: International Trade Quarterly Review. In DOCEX since September 1979.
Economic and Energy Indicators, published biweekly since May 1980, formerly
titled International Economic and Energy Statistical Review. In DOCEX since
March 1976.
International Energy Statistical Review, published every four weeks, formerly
titled International Oil Developments—Statistical Survey. In DOCEX since
March 1976.
National Basic Intelligence Factbook, published semiannually in 1972-79 and.
annually since 1980. In DOCEX since January 1975.
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7','fb4bae52607a2dcb6a3d26f674354977b9b190a044b19163fa64c38582526c7b','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3bb62271da67449221738f5e52f2dcb49f582fe0804c98df5d0ac78539291d4',1968,'PH','Philippines','military-and-security',207,'{See reference map Vil}
LAND
1,036 km?; 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country)
Land boundaries: 24 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 733 km','3f89a38ad44b5312771f40bfd41f522634f4aed09193edc24b28088b44935a09','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a4a9bb31084d85866b0a4f145adc6b89009bb4807a45d34154f3fe5b2c793e0',1998,'ID','Indonesia','people-and-society',72,'Unemployment rate: NA%
Budget: revenues: $NA expenditures: $NA, including capital expenditures
of SNA
Industries: tourism, phosphate extraction (near depletion)
Industrial production growth rate: NA%
Electricity-capacity: NA kW
Electricity-production: NA kWh
Electricity-consumption per capita: NA kWh
Agriculture-products: NA
Exports: $NA commodities: phosphate partners: Australia, NZ
Imports: $NA commodities: consumer goods partners: principally Australia
Debt-external: $NA
Economic aid: none
Currency: 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1-1.5281 (January 1998),
1.3439 (1997), 1.2773 (1996), 1.3486 (1995), 1.3667 (1994), 1.4704,
(1993)
Fiscal year: 1 July-30 June','2a6f85553752a0de23f0dbb5a53883850aee394b4d1faf5ad1b73eab9f323c98','internet-archive','1998-cia-world-factbook-united-states-central-intelligence-agency','txt','ed8d799a5289d0958a7a95ba11403072d40c0ab0f88fcf382252becb0759ed16','https://archive.org/download/1998-cia-world-factbook-united-states-central-intelligence-agency/1998-cia-world-factbook-united-states-central-intelligence-agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba4a667cd5b0130d53910fb286a0c2e15790b58ab2ce9cccf8e499c79eecfc8a',1998,'US','United States','people-and-society',8,'Population
Age structure
0-14 years
15-64 years
65 years and over
Population growth rate
Birth rate
Death rate
Net migration rate
Sex ratio
at birth
under 15 years
15-64 years
65 years and over
total population
Infant mortality rate
Life expectancy at birth
total population
male
female
Total fertility rate
Nationality
noun
adjective
Ethnic groups
Religions
Languages
Literacy
definition
total population
male
female
People— note
Population: 24,792,375 (July 1998 est.)
Age structure:
0-14 years: 43% (male 5,425,510; female 5,216,954)
15-64 years: 54% (male 6,978,549; female
6,494,253)
65 years and over: 3% (male 357,780; female
319,329) (July 1998 est.)
Population growth rate: 4.21% (1998 est.)
note: this rate reflects the continued return of refugees
Birth rate: 42.37 births/1 ,000 population (1998 est.)
Death rate: 17.4 deaths/1, 000 population (1998 est.)
Net migration rate: 17.14 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 ma!e(s)/female
15-64 years: 1 .07 male(s)/female
65 years and over: 1.12 male(s)/female (1 998 est.)
Infant mortality rate: 1 43.63 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 46.83 years
male: 47.35 years
female: 46.29 years (1998 est.)
Total fertility rate: 6.01 children born/woman (1998
est.)
Nationality:
noun.''Afghan(s)
adjective: Afghan
Ethnic groups: Pashtun 38%, Tajik 25%, Uzbek
6%, Hazara 19%, minor ethnic groups (Aimaks,
Turkmen, Baloch, and others)
Religions: Sunni Muslim 84%, Shi''a Muslim 15%,
other 1%
Languages: Pashtu 35%, Afghan Persian (Dari)
50%, Turkic languages (primarily Uzbek and
Turkmen) 1 1 %, 30 minor languages (primarily Balochi
and Pashai) 4%, much bilingualism
Literacy:
definition: age 15 and over can read and write
total population: 31 .5%
male: 412%
female: 15% (1995 est.)','694e1c3963ed7df53a43f42d821ca7acc5ae6b4bbad9362958764ae7167b87e0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73be48bd1222a36c6f983796e0ec73ecff47b02274360a1a34e3e0b901af647d',1998,'AL','Albania','people-and-society',17,'Population: 3,330,754 (July 1998 est.)
Age structure:
0-14 years: 33% (male 572,430; female 532,917)
15-64 years: 61% (male 941,076; female 1,086,541)
65 years and over: 6% (male 82,1 84; female
115,606) (July 1998 est.)
Population growth rate: 0.97% (1998 est.)
Birth rate: 21 .35 births/1 ,000 population (1998 est.)
Death rate: 7.45 deaths/1 ,000 population (1 998 est.)
Net migration rate: -4.16 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 0.87 male(s)/female
65 years and over: 0.71 male(s)/female (1 998 est.)
Infant mortality rate: 45.01 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 68.64 years
male: 65.58 years
female: 71 .94 years (1 998 est.)
Total fertility rate: 2.57 children born/woman (1998
est.)
Nationality:
noun.''Albanian(s)
adjective : Albanian
Ethnic groups: Albanian 95%, Greeks 3%, other 2%
(Vlachs, Gypsies, Serbs, and Bulgarians) (1989 est.)
note: in 1989, other estimates of the Greek population
ranged from 1% (official Albanian statistics) to 12%
(from a Greek organization)
Religions: Muslim 70%, Albanian Orthodox 20%,
Roman Catholic 10%
note: all mosques and churches were closed in 1967
and religious observances prohibited; in November
1990, Albania began allowing private religious
practice
Languages: Albanian (Tosk is the official dialect),
Greek
Literacy:
definition: age 9 and over can read and write
total population: 72%
male: 80%
female: 63% (1 955 est.)
3
Albania (continued)','36cbcfbc458c0f2c043a28683cc078ffa98c5904bb2d2b1e283561e31e5777f7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49fae2e321ded235732a0ca6228c0bb133d8f60dbce571b259c3dae5ca02dae2',1998,'DZ','Algeria','people-and-society',24,'Population: 30,480,793 (July 1998 est.)
Age structure:
0-14 years: 38% (male 5,923,087; female 5,709,614)
15-64 years: 58% (male 8,931 ,896; female
8,752,014)
65 years and over: 4% (male 542,01 2; female
622,170) (July 1998 est.)
Population growth rate: 2.14% (1998 est.)
Birth rate: 27.51 births/1,000 population (1998 est.)
Death rate: 5.63 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.49 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.87 male(s)/female (1998 est.)
Infant mortality rate: 45.44 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 68.93 years
male: 67.78 years
female: 70.1 2 years (1998 est.)
Total fertility rate: 3.38 children born/woman (1998
est.)
Nationality:
noun: Algerian(s)
adjective: Algerian
Ethnic groups: Arab-Berber 99%, European less
than 1%
Religions: Sunni Muslim (state religion) 99%,
Christian and Jewish 1%
Languages: Arabic (official), French, Berber dialects
Literacy:
definition: age 15 and over can read and write
total population: 61.6%
male: 73.9%
female: 49% (1995 est.)
Population: 39,133,996 (July 1998 est.)
Age structure:
0-14 years: 15% (male 3,057,919; female 2,879,109)
15-64 years: 69% (male 13,407,270; female
13,408,685)
65 years and over: 16% (male 2,651 ,149; female
3,729,864) (July 1998 est.)
Population growth rate: 0.08% (1998 est.)
Birth rate: 9.73 births/1 ,000 population (1998 est.)
Death rate: 9.62 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0.66 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female (1998 est.)
Infant mortality rate: 6.51 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 77.56 years
male: 73.78 years
female: 81 .59 years (1 998 est.)
Total fertility rate: 1.21 children born/woman (1998
est.)
Nationality:
noun: Spaniard(s)
adjective: Spanish
Ethnic groups: composite of Mediterranean and
Nordic types
Religions: Roman Catholic 99%, other 1%
Languages: Castilian Spanish 74%, Catalan 17%,
Galician 7%, Basque 2%
Literacy:
definition: age 1 5 and over can read and write
total population: 96%
male: 98%
female: 94% (1986 est.)','49bf119178d7ad926b3683a3571508eb25d43fcd23bb33a501a3b35e593abe6e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e32c2419d4c7d2ede456c255af644a15abcf6e17b87cacc95d0037c4fb20fdfc',1998,'AS','American Samoa','people-and-society',29,'Population: 62,093 (July 1998 est.)
Age structure:
0-14 years : 39% (male 12,575; female 1 1 ,824)
15-64 years: 56% (male 17,513; female 17,477)
65 years and over: 5% (male 1 ,364; female 1 ,340)
(July 1998 est.)
Population growth rate: 2.74% (1998 est.)
Birth rate: 27.31 births/1,000 population (1998 est.)
Death rate: 4.03 deaths/1 ,000 population (1 998 est.)
Net migration rate: 4.11 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 1 .01 male(s)/fema!e (1 998 est.)
Infant mortality rate: 1 0.47 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.23 years
male: 70.95 years
female: 79.77 years (1998 est.)
Total fertility rate: 3.72 children born/woman (1998
est.)
Nationality:
noun: American Samoan(s)
adjective: American Samoan
Ethnic groups: Samoan (Polynesian) 89%,
Caucasian 2%, Tongan 4%, other 5%
Religions: Christian Congregationalist 50%, Roman
Catholic 20%, Protestant denominations and other
30%
Languages: Samoan (closely related to Hawaiian
and other Polynesian languages), English
note: most people are bilingual
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 97% (1980 est.)
Population: 64,716 (July 1998 est.)
Age structure:
0-14 years: 14% (male 4,819; female 4,474)
15-64 years: 73% (male 25,448; female 22,028)
65 years and over: 13% (male 4,041 ; female 3,906)
(July 1998 est.)
Population growth rate: 1 .5% (1 998 est.)
Birth rate: 10.48 births/1 ,000 population (1998 est.)
Death rate: 5.35 deaths/1 ,000 population (1 998 est.)
Net migration rate: 9.84 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1 .1 5 male(s)/female
65 years and over: 1 .03 male(s)/female (1 998 est.)
Infant mortality rate: 4.09 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 83.45 years
male: 80.54 years
female : 86.54 years (1 998 est.)
Total fertility rate: 1 .23 children born/woman (1 998
est.)
Nationality:
noun: Andorran(s)
adjective: Andorran
Ethnic groups: Spanish 61%, Andorran 30%,
French 6%, other 3%
Religions: Roman Catholic (predominant)
Languages: Catalan (official), French, Castilian
Literacy: NA
Population: 10,864,512 (July 1998 est.)
Age structure:
0-14 years: 45% (male 2,471,108; female 2,401,631)
15-64 years: 52% (male 2,864,152; female
2,831,209)
65 years and over: 3% (male 137,432; female
158,980) (July 1998 est.)
Population growth rate: 2.84% (1998 est.)
Birth rate: 43.58 births/1,000 population (1998 est.)
Death rate: 1 6.79 deaths/1 ,000 population (1 998
est.)
Net migration rate: 1 .65 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1.02 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.86 male(s)/female (1 998 est.)
Infant mortality rate: 132.44 deaths/1 ,000 live
births (1998 est.)
11
Angola (continued)
Life expectancy at birth:
total population: 47.86 years
male: 45.6 years
female: 50.23 years (1998 est.)
Total fertility rate: 6.2 children born/woman (1998
est.)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%, Kimbundu 25%,
Bakongo 13%, mestico (mixed European and Native
African) 2%, European 1%, other 22%
Religions: indigenous beliefs 47%, Roman Catholic
38%, Protestant 15% (est.)
Languages: Portuguese (official), Bantu and other
African languages
Literacy:
definition: age 15 and over can read and write
total population: 42%
male: 56%
female: 28% (1990 est.)
Population: 11,147 (July 1998 est.)
Age structure:
0- 14 years: 28% (male 1 ,558; female 1 ,51 1 )
15-64 years: 65% (male 3,713; female 3,545)
65 years and over: 7% (male 359; female 461 ) (July
1998 est.)
Population growth rate: 3.25% (1998 est.)
Birth rate: 1 7.04 births/1 ,000 population (1 998 est.)
Death rate: 5.47 deaths/1 ,000 population (1 998 est.)
Net migration rate: 20.9 migrant(s)/1,000
population (1998 est.)
Sex ratio:
at birth: 1.02 male(s)/fema!e
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .05 male(s)/fema!e
65 years and over: 0.78 male(s)/female (1 998 est.)
Infant mortality rate: 20.16 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 77.37 years
male: 74.39 years
female: 80.43 years (1 998 est.)
Total fertility rate: 1 .98 children born/woman (1 998
est.)
Nationality:
noun: Anguillan(s)
adjective: Anguillan
Ethnic groups: black
Religions: Anglican 40%, Methodist 33%,
Seventh-Day Adventist 7%, Baptist 5%, Roman
Catholic 3%, other 12%
Languages: English (official)
Literacy:
definition: age 12 and over can read and write
total population: 95%
male: 95%
female: 95% (1984 est.)','700cd07a80068bba6723f9e35f44230e8361361e877d130b02df76006373db4c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69fdb275f4e5606e3dc2fd5b771988da490654c718a715d6dff71ba39a243a34',1998,'AQ','Antarctica','people-and-society',38,'Population: no indigenous inhabitants; note— there
are seasonally staffed research stations; Summer
(January) population— over 4,1 15 total; Argentina
207, Australia 268, Belgium 13, Brazil 80, Chile 256,
China NA, Ecuador NA, Finland 11, France 78,
Germany 32, Greenpeace 12, India 60, Italy 210,
Japan 59, South Korea 14, Netherlands 10, NZ 264,
Norway 23, Peru 39, Poland NA, South Africa 79,
Spain 43, Sweden 10, UK 116, Uruguay NA, US
1,666, former USSR 565 (1989-90); Winter (July)
population— over 1,046 total; Argentina 150, Australia
71, Brazil 12, Chile 73, China NA, France 33,
Germany 19, Greenpeace 5, India 1 , Japan 38, South
Korea 14, NZ 1 1 , Poland NA, South Africa 12, UK 69,
Uruguay NA, US 225, former USSR 313 (1989-90);
Year-round stations— 42 total; Argentina 6, Australia
3, Brazil 1 , Chile 3, China 2, Finland 1 , France 1 ,
Germany 1, India 1, Japan 2, South Korea 1, NZ 1,
Poland 1 , South Africa 3, UK 5, Uruguay 1 , US 3,
former USSR 6 (1990-91); Summer-only stations —
over 38 total; Argentina 7, Australia 3, Chile 5,
Germany 3, India 1 , Italy 1 , Japan 4, NZ 2, Norway 1 ,
Peru 1 , South Africa 1 , Spain 1 , Sweden 2, UK 1 , US
numerous, former USSR 5 (1989-90); note— the
disintegration of the former USSR has placed the
status and future of its Antarctic facilities in doubt;
stations may be subject to closings at any time
because of ongoing economic difficulties
15
Antarctica (continued)
Population: 3,421 ,775 (July 1 998 est.)
Age structure:
0-14 years: 26% (male 460,191 ; female 441 ,906)
15-64 years: 65% (male 1 ,092,652; female
1,139,916)
65 years and over: 9% (male 1 1 9,464; female
167,646) (July 1998 est.)
Population growth rate: -0.36% (1998 est.)
Birth rate: 1 3.52 births/1 ,000 population (1 998 est.)
Death rate: 8.82 deaths/1 ,000 population (1 998 est.)
Net migration rate: -8.29 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.71 ma!e(s)/female (1998 est.)
Infant mortality rate: 40.77 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 66.73 years
male: 62.45 years
female : 71 .23 years (1 998 est.)
Total fertility rate: 1 .69 children born/woman (1 998
est.)
Nationality:
nou/?:Armenian(s)
adjective: Armenian
Ethnic groups: Armenian 93%, Azeri 3%, Russian
2%, other (mostly Yezidi Kurds) 2% (1989)
note: as of the end of 1993, virtually all Azeris had
emigrated from Armenia
Religions: Armenian Orthodox 94%
Languages: Armenian 96%, Russian 2%, other 2%
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 98% (1989 est.)
Population: 68,325 (July 1998 est.)
Age structure:
0-14 years: 22% (male 7,775; female 7,114)
15-64 years: 69% (male 22,616; female 24,700)
65 years and over: 9% (male 2,523; female 3,597)
(July 1998 est.)
Population growth rate: 0.47% (1998 est.)
Birth rate: 13.74 births/1 ,000 population (1998 est.)
Death rate: 6.4 deaths/1 ,000 population (1998 est.)
Net migration rate: -2.63 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/fema!e
under 15 years: 1.09 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.7 male(s)/female (1998 est.)
Infant mortality rate: 7.96 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 76.92 years
mate: 73.22 years
female: 80. 81 years (1998 est.)
Total fertility rate: 1 .81 children born/woman (1 998
est.)
Nationality:
mm’Aruban(s)
adjective: Aruban
Ethnic groups: mixed white/Caribbean Amerindian
80%
Religions: Roman Catholic 82%, Protestant 8%,
Hindu, Muslim, Confucian, Jewish
Languages: Dutch (official), Papiamento (a Spanish,
Portuguese, Dutch, English dialect), English (widely
spoken), Spanish
Literacy: NA
Population:
note; there are only seasonal caretakers
Population: 18,613,087 (July 1998 est.)
Age structure:
0-14 years: 21% (male 2,023,147; female 1 ,926,206)
15-64 years: 66% (male 6,251,159; female
6,105,381)
65 years and over : 1 3% (male 1 ,005,1 96; female
1,301,998) (July 1998 est.)
Population growth rate: 0.93% (1998 est.)
Birth rate: 1 3.47 births/1 ,000 population (1 998 est.)
Death rate: 6.89 deaths/1 ,000 population (1 998 est.)
Net migration rate: 2.69 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.05 male(s)/fema!e
15-64 years: 1 .02 male(s)/female
65 years and over: 0.77 male(s)/female (1 998 est.)
Infant mortality rate: 5.26 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 79.89 years
male: 76.95 years
female: 82.98 years (1998 est.)
Total fertility rate: 1 .82 children born/woman (1 998
est.)
Nationality:
mm*Australian(s)
ac/yecf/Ve; Australian
Ethnic groups: Caucasian 92%, Asian 7%,
aboriginal and other 1%
Religions: Anglican 26.1%, Roman Catholic 26%,
other Christian 24.3%, non-Christian 11%
Languages: English, native languages
Literacy:
definition: age 1 5 and over can read and write
total population: 100%
male: 100%
female: 100% (1980 est.)
Population: 8,133,611 (July 1998 est.)
Age structure:
0-14 years: 17% (male 709,890; female 673,696)
15-64 years: 68% (male 2,783,569; female
2,707,113)
65 years and over: 1 5% (male 471 ,924; female
787,419) (July 1998 est.)
Population growth rate: 0.05% (1998 est.)
Birth rate: 9.89 births/1 ,000 population (1998 est.)
Death rate: 1 0.05 deaths/1 ,000 population (1 998
est.)
Net migration rate: 0.65 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/fema!e
15-64 years: 1 .02 male(s)/female
65 years and over: 0.59 male(s)/female (1998 est.)
Infant mortality rate: 5.16 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 77.31 years
male: 74.1 3 years
female: 80.67 years (1998 est.)
Total fertility rate: 1 .37 children born/woman (1 998
est.)
Nationality:
mm’Austrian(s)
adjective: Austrian
Ethnic groups: German 99.4%, Croatian 0.3%,
Slovene 0.2%, other 0.1%
Religions: Roman Catholic 78%, Protestant 5%,
other 17%
Languages: German
Literacy:
definition: age 15 and over can read and write
total population: 99% (1974 est.)
male: NA%
female: NA%','151b2ef4036a8ff57e4995b8271c6cb89c7c7b4f94696d5b807d154db9233fdc','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('635afa6be11be33acd98983fb976ce3c62c3721f54b38d33efcd367fb0f3b99b',1998,'AG','Antigua and Barbuda','people-and-society',46,'Population: 64,006 (July 1998 est.)
Age structure:
0-14 years: 26% (male 8,482; female 8,200)
15-64 years: 68% (male 21 ,695; female 22,042)
65 years and over: 6% (male 1 ,548; female 2,039)
(July 1998 est.)
Population growth rate: 0.39% (1998 est.)
Birth rate: 16.72 births/1 ,000 population (1998 est.)
Death rate: 5.87 deaths/1 ,000 population (1 998 est.)
Net migration rate: -6.92 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.76 male(s)/female (1 998 est.)
Infant mortality rate: 21 .35 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 7 1 . 1 9 years
male: 68.82 years
female: 73.69 years (1998 est.)
Total fertility rate: 1.74 children born/woman (1998
est.)
Nationality:
noun.''Antiguan(s), Barbudan(s)
adjective: Antiguan, Barbudan
Ethnic groups: black, British, Portuguese,
Lebanese, Syrian
Religions: Anglican (predominant), other Protestant
sects, some Roman Catholic
Languages: English (official), local dialects
Literacy:
definition: age 1 5 and over has completed five or more
years of schooling
total population: 89%
male: 90%
female: 88% (1960 est.)
Population: 36,265,463 (July 1998 est.)
Age structure:
0-14 years: 27% (male 5,078,061 ; female 4,888,883)
15-64 years: 62% (male 1 1 ,299,1 55; female
11,315,522)
65 years and over: 1 1 % (male 1 ,526,682; female
2,157,160) (July 1998 est.)
Population growth rate: 1.3% (1998 est.)
Birth rate: 1 9.96 births/1 ,000 population (1 998 est.)
Death rate: 7.67 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0.66 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female (1 998 est.)
Infant mortality rate: 1 9.03 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 74.54 years
male: 70.9 years
female: 78.34 years (1998 est.)
Total fertility rate: 2.68 children born/woman (1998
est.)
Nationality:
noun:Argentine(s)
adjective: Argentine
Ethnic groups: white 85%, mestizo, Amerindian, or
other nonwhite groups 15%
Religions: nominally Roman Catholic 90% (less
than 20% practicing), Protestant 2%, Jewish 2%,
other 6%
Languages: Spanish (official), English, Italian,
German, French
Literacy:
definition: age 15 and over can read and write
total population: 96.2%
male: 96.2%
female: 96.2% (1995 est.)','890834612d1b47be8866a6c082ef1346f172d769f6473140700477d131917c54','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b581fb3b177fe17d926c63b21310c22a46cec2f49f66764a709b022e471fcee5',1998,'AZ','Azerbaijan','people-and-society',57,'Population: 7,855,576 (July 1998 est.)
Age structure:
0-14 years: 32% (male 1 ,300,236; female 1 ,247,027)
15-64 years: 61% (male 2,336,568; female
2,468,679)
65 years and over: 7% (male 1 95,322; female
307,744) (July 1998 est.)
Population growth rate: 0.7% (1998 est.)
Birth rate: 22.2 births/1,000 population (1998 est.)
Death rate: 9.41 deaths/1 ,000 population (1 998 est.)
Net migration rate: -5.75 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.63 male(s)/female (1998 est.)
Infant mortality rate: 81 .64 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 63.3 years
male: 59.01 years
female: 67.81 years (1998 est.)
Total fertility rate: 2.72 children born/woman (1998
est.)
Nationality:
noun: Azerbaijani(s)
adjective: Azerbaijani
Ethnic groups: Azeri 90%, Dagestani Peoples
3.2%, Russian 2.5%, Armenian 2.3%, other 2% (1 995
est.)
32
note: almost all Armenians live in the separatist
Nagorno-Karabakh region
Religions: Muslim 93.4%, Russian Orthodox 2.5%,
Armenian Orthodox 2.3%, other 1.8% (1995 est.)
note: religious affiliation is still nominal in Azerbaijan;
actual practicing adherents are much lower
Languages: Azeri 89%, Russian 3%, Armenian 2%,
other 6% (1995 est.)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 96% (1989 est.)
Population: 279,833 (July 1998 est.)
Age structure:
0-14 years: 28% (male 39,239; female 38,708)
15-64 years: 67% (male 91 ,208; female 95,1 98)
65 years and over: 5% (male 6,444; female 9,036)
(July 1998 est.)
Population growth rate: 1 .39% (1 998 est.)
Birth rate: 21 .03 births/1 ,000 population (1 998 est.)
Death rate: 5.44 deaths/1, 000 population (1998 est.)
Net migration rate: -1 .72 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.71 male(s)/female (1 998 est.)
Infant mortality rate: 18.97 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 74 years
male: 70.65 years
female: 77 .42 years (1998 est.)
Total fertility rate: 2.33 children born/woman (1998
est.)
Nationality:
noun: Bahamian(s)
adjective: Bahamian
Ethnic groups: black 85%, white 1 5%
Religions: Baptist 32%, Anglican 20%, Roman
Catholic 1 9%, Methodist 6%, Church of God 6%, other
Protestant 12%, none or unknown 3%, other 2%
Languages: English, Creole (among Haitian
immigrants)
Literacy:
definition: age 15 and over can read and write but
definition of literacy not available
total population: 98.2%
male: 98.5%
fema/e: 98% (1995 est.)','45cbfb3eb15b6ceb37a1f7defe814a41424eb1cbf27a9803b0fe8228f11e741c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c8bd2a91042b78a9bca105c31d496567f6d53fb37a08867d9d3f0ee304de2d3',1998,'BH','Bahrain','people-and-society',70,'Population: 616,342 (July 1998 est.)
note: includes 224,640 non-nationals (July 1998 est.)
Age structure:
0-14 years: 31% (male 95,871; female 93,232)
15-64 years: 67% (male 245,099; female 164,946)
65 years and over: 2% (male 8,799; female 8,395)
(July 1998 est.)
Population growth rate: 2.09% (1998 est.)
Birth rate: 22.43 births/1 ,000 population (1998 est.)
Death rate: 3.25 deaths/1 ,000 population (1 998 est.)
Net migration rate: 1 .73 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 ma!e(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .49 male(s)/female
65 years and over: 1 .05 male(s)/female (1 998 est.)
Infant mortality rate: 15.54 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
totai population : 74.96 years
male: 72.42 years
female: 77.57 years (1998 est.)
Total fertility rate: 3.01 children born/woman (1998
est.)
Nationality:
noun: Bahraini(s)
adjective: Bahraini
Ethnic groups: Bahraini 63%, Asian 13%, other
Arab 10%, Iranian 8%, other 6%
Religions: Shi''a Muslim 75%, Sunni Muslim 25%
Languages: Arabic, English, Farsi, Urdu
Literacy:
definition: age 1 5 and over can read and write
total population: 85.2%
ma/e;89.1%
female: 79.4% (1995 est.)
Population: 127,567,002 (July 1998 est.)
Age structure:
0-14 years: 38% (male 24,339,519; female
23,377,955)
15-64 years: 59% (male 38,897,130; female
36,818,818)
65 years and over: 3% (male 2,239,638; female
1,893,942) (July 1998 est.)
Population growth rate: 1 .76% (1 998 est.)
Birth rate: 28.89 births/1 ,000 population (1998 est.)
Death rate: 1 0.6 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.69 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 1.18 male(s)/female (1 998 est.)
Infant mortality rate: 97.67 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 56.66 years
male: 56.69 years
female: 56.63 years (1998 est.)
Total fertility rate: 3.32 children born/woman (1998
est.)
Nationality:
noun: Bangladeshi(s)
adjective: Bangladesh
Ethnic groups: Bengali 98%, Biharis 250,000,
tribals less than 1 million
Religions: Muslim 88.3%, Hindu 10.5%, other 1.2%
Languages: Bangla (official), English
Literacy:
definition: age 15 and over can read and write
total population: 38. 1 %
male: 49.4%
female: 26.1% (1995 est.)
| G o v e r n m e n t
Country name:
conventional long form: People''s Republic of','7c6af25757ca3e4994e0392f36818040874a6868142bb99e20c80f63f7cd83a3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f18e3eac055be8c16d31871b29dbd1c7afbecdebf70b61f0aa5bb4e5ebb8fd95',1998,'BD','Bangladesh','people-and-society',76,'conventional short form: Bangladesh
former: East Pakistan
Data code: BG
39
Bangladesh (continued)
Government type: republic
National capital: Dhaka
Administrative divisions: 4 divisions; Chittagong,
Dhaka, Khulna, Rajshahi
note: there may be two new divisions named Barisal
and Sylhet
Independence: 16 December 1971 (from Pakistan)
National holiday: Independence Day, 26 March
(1971)
Constitution: 4 November 1972, effective 16
December 1972, suspended following coup of 24
March 1982, restored 10 November 1986, amended
many times
Legal system: based on English common law
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Shahabuddin AHMED (since
9 October 1996); note— the president''s duties are
normally ceremonial, but with the 13th amendment to
the constitution ("Caretaker Government
Amendment"), the president''s role becomes
significant at times when Parliament is dissolved and
a caretaker government is installed— at presidential
direction— to supervise the elections
head of government: Prime Minister Sheikh HASINA
Wajed (since 23 June 1996)
cabinet: Cabinet selected by the prime minister and
appointed by the president
elections: president elected by National Parliamentfor
a five-year term; election last held 24 July 1996 (next
to be held by NA October 2001); following legislative
elections, the leader of the party that wins the most
seats is usually appointed prime minister by the
president
election results: Shahabuddin AHMED elected
president without opposition; percent of National
Parliament vote— NA
Legislative branch: unicameral National Parliament
or Jatiya Sangsad (330 seats; 300 elected by popular
vote from single territorial constituencies, 30 seats
reserved for women; members serve five-year terms)
elections: last held 1 2 June 1 996 (next to be held NA
2001)
election results: percent of vote by party— AL 33.87%,
BNP 30.87%; seats by party-AL 178, BNP 113, JP
33, Jl 3, other 2, election still to be held 1 ; note— the
elections of 1 2 June 1 996 brought to power an Awami
League government for the first time in twenty-one
years; held under a neutral, caretaker administration,
the elections were characterized by a peaceful,
orderly process and massive voter turnout, ending a
bitter two-year impasse between the former BNP and
opposition parties that had paralyzed National
Parliament and led to widespread street violence
Judicial branch: Supreme Court, the Chief Justices
and other judges are appointed by the president
Political parties and leaders: Bangladesh
Nationalist Party (BNP), Khaleda ZIAur Rahman;
Awami League (AL), Sheikh HASINA Wajed; Jatiyo
Party (JP), Hussain Mohammad ERSHAD;
Jamaat-E-lslami (Jl), Motiur Rahman NIZAMI;
Bangladesh Communist Party (BCP), Saifuddin
Ahmed MANIK
International organization participation: AsDB,C,
CCC, CP, ESCAP, FAO, G-77, IAEA, IBRD, ICAO,
ICC, ICFTU, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO,
IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, IOM, ISO,
ITU, MINURSO, MONUA, NAM, OIC, SAARC, UN,
UNCTAD, UNESCO, UNHCR, UNIDO, UNIKOM,
UNMIBH, UNMOP, UNMOT, UNOMIG, UNOMIL,
UNPREDEP, UNU, UPU, WCL, WFTU, WHO, WIPO,
WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Khwaja Mohammad
SHEHABUDDIN
chancery: 2201 Wisconsin Avenue NW, Washington,
DC 20007
telephone: [1] (202) 342-8372 through 8376
consulate(s) general: Los Angeles and New York
Diplomatic representation from the US:
chief of mission: Ambassador John C. HOLZMAN
embassy: Diplomatic Enclave, Madani Avenue,
Baridhara, Dhaka 1212
mailing address: G.P.O. Box 323, Dhaka 1000
telephone: [880] (2) 884700 through 884722
FAX: [880] (2) 883-744
Flag description: green with a large red disk slightly
to the hoist side of center; the red sun of freedom
represents the blood shed to achieve independence;
the green field symbolizes the lush countryside, and
secondarily, the traditional color of Islam','97c395aeb70405a597d85d84d3cfae13e0690d3ab6ac1e94e8117793aa0ea3fb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abf643d500a0c0821913731fe069643d522b101f45c0a8239c471fd5efde81e7',1998,'BB','Barbados','people-and-society',83,'Population: 259,025 (July 1998 est.)
Age structure:
0-14 years: 23% (male 30,592; female 29,747)
15-64 years: 67% (male 84,725; female 87,730)
65 years and over: 1 0% (male 9,926; female 1 6,305)
(July 1998 est.)
Population growth rate: 0.09% (1998 est.)
Birth rate: 1 4.92 births/1 ,000 population (1 998 est.)
Death rate: 8.21 deaths/1 ,000 population (1998 est.)
Net migration rate: -5.86 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.61 male(s)/female (1998 est.)
Infant mortality rate: 17.25 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 74.79 years
male: 72.03 years
female : 77.62 years (1 998 est.)
Total fertility rate: 1 .85 children born/woman (1998
est.)
Nationality:
noun: Barbadian(s)
adjective: Barbadian
Ethnic groups: black 80%, white 4%, other 1 6%
Religions: Protestant 67% (Anglican 40%,
Pentecostal 8%, Methodist 7%, other 12%), Roman
Catholic 4%, none 17%, unknown 3%, other 9%
(1980)
Languages: English
Literacy:
definition: age 1 5 and over has ever attended school
total population: 97.4%
male: 98%
female: 96.8% (1995 est.)','4705147b94aef936e585259e8e7ef9aa29f262d88529786f7e6b763289c5dab2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3984d1478043a943b40fdc85f472b3677ec136a2e605f950ef7164119bf2ad6c',1998,'LC','Saint Lucia','people-and-society',91,'Population: uninhabited
S'' Government
Country name:
conventional long form: none
conventional short form: Bassas da India
Data code: BS
Dependency status: possession of France;
administered by a high commissioner of the Republic,
resident in Reunion
Legal system: NA
Diplomatic representation in the US: none
(possession of France)
Diplomatic representation from the US: none
(possession of France)
Flag description: the flag of France is used','7f83e818460f577c62bb6dc13b2d1e0bb3355514faf2d82ccfb08e505c8bb9bb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1222445dd5c5439b99c4c46a7954e1da7affee97f9dc18b23305196d0163e6ac',1998,'FR','France','people-and-society',94,'Population: 10,409,050 (July 1998 est.)
Age structure:
0-14 years: 20% (male 1,062,012; female 1,018,154)
15-64 years : 67% (male 3,365,065; female
3,564,078)
65 years and over: 13% (male 460,633; female
939,108) (July 1998 est.)
Population growth rate: -0.05% (1998 est.)
Birthrate: 9.71 births/1 ,000 population (1998 est.)
Death rate: 1 3.47 deaths/1 ,000 population (1 998
est.)
Net migration rate: 3.25 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/fema!e
under 15 years: 1.04 male(s)/female
15-64 years ; 0.94 male(s)/female
65 years and over: 0.49 male(s)/female (1 998 est.)
Infant mortality rate: 14.16 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 68.26 years
male: 6226 years
female: 74.56 years (1998 est.)
Total fertility rate: 1.34 children born/woman (1998
est.)
Nationality:
noun: Belarusian(s)
adjective: Belarusian
Ethnic groups: Byelorussian 77.9%, Russian
13.2%, Polish 4.1%, Ukrainian 2.9%, other 1.9%
Religions: Eastern Orthodox 80%, other (including
Roman Catholic, Protestant, Jewish, and Muslim)
20% (1997 est.)
Languages: Byelorussian, Russian, other
Literacy:
definition : age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
Population: 10,174,922 (July 1998 est.)
Age structure:
0-14 years: 17% (male 903,954; female 860,940)
15-64 years: 66% (male 3,387,329; female
3,318,221)
65 years and over: 1 7% (male 693,51 9; female
1,010,959) (July 1998 est.)
Population growth rate: 0.09% (1998 est.)
Birth rate: 1 0.21 births/1 ,000 population (1 998 est.)
Death rate: 10.41 deaths/1,000 population (1998
est.)
Net migration rate: 1 .05 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 ma!e(s)/female
65 years and over: 0.68 male(s)/female (1 998 est.)
Infant mortality rate: 6.27 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 77.35 years
male: 74.1 3 years
female: 80.74 years (1998 est.)
Total fertility rate: 1 .49 children born/woman (1998
est.)
Nationality:
noun: Belgian(s)
adjective: Belgian
Ethnic groups: Fleming 55%, Walloon 33%, mixed
or other 12%
Religions: Roman Catholic 75%, Protestant or other
25%
Languages: Flemish 56%, French 32%, German
1%, legally bilingual 11%
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1980 est.)
male: NA%
female: NA%
Population: 230,160 (July 1998 est.)
Age structure:
0-14 years: 42% (male 49,486; female 47,596)
15-64 years: 54% (male 63,259; female 61 ,567)
65 years and over: 4% (male 4,048; female 4,204)
(July 1998 est.)
Population growth rate: 2.42% (1998 est.)
Birth rate: 31 .05 births/1 ,000 population (1 998 est.)
Death rate: 5.5 deaths/1 ,000 population (1998 est.)
Net migration rate: -1 .38 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.96 male(s)/female (1 998 est.)
Infant mortality rate: 32.36 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 68.97 years
male: 67.01 years
female: 71 .03 years (1998 est.)
Total fertility rate: 3.87 children born/woman (1998
est.)
Nationality:
noun: Belizean(s)
adjective: Belizean
Ethnic groups: mestizo 44%, Creole 30%, Maya
11%, Garifuna 7%, other 8%
Religions: Roman Catholic 62%, Protestant 30%
(Anglican 12%, Methodist 6%, Mennonite 4%,
Seventh-Day Adventist 3%, Pentecostal 2%,
Jehovah''s Witnesses 1%, other 2%), none 2%, other
6% (1980)
Languages: English (official), Spanish, Mayan,
Garifuna (Carib)
Literacy:
definition: age 14 and over has ever attended school
total population: 70.3%
male: 70.3%
female: 70.3% (1991 est.)
note: other sources list the literacy rate as high as
75%
48
Population: 637 (July 1998 est.)
Age structure:
0-1 4 years: NA
15-64 years: NA
65 years and over: NA (July 1 998 est.)
Population growth rate: -0.21% (1998 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun; Cocos Islander(s)
adjective: Cocos Islander
Ethnic groups: Europeans, Cocos Malays
Religions: Sunni Muslim 57%, Christian 22%, other
21% (1981 est.)
Languages: English, Malay
Population: 2,805 (July 1998 est.)
Age structure:
0- 14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 4.13% (1998 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Falkland Islander(s)
adjective: Falkland Island
Ethnic groups: British
Religions: primarily Anglican, Roman Catholic,
United Free Church, Evangelist Church, Jehovah''s
Witnesses, Lutheran, Seventh-Day Adventist
Languages: English
Population: 58,804,944 (July 1998 est.)
Age structure:
0-14years: 19% (male 5,674,417; female 5,411,685)
15-64 years: 65% (male 19,243,919; female
19,182,933)
65 years and over: 1 6% (male 3,759,565; female
5,532,425) (July 1998 est.)
Population growth rate: 0.31% (1998 est.)
Birth rate: 1 1 .68 births/1 ,000 population (1 998 est.)
Death rate: 9.12 deaths/1 ,000 population (1998 est.)
Net migration rate: 0.58 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.67 male(s)/female (1 998 est.)
Infant mortality rate: 5.69 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.51 years
male: 74.6 years
female : 82.62 years (1998 est.)
Total fertility rate: 1 .63 children born/woman (1 998
est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Celtic and Latin with Teutonic,
Slavic, North African, Indochinese, Basque minorities
Religions: Roman Catholic 90%, Protestant 2%,
Jewish 1%, Muslim (North African workers) 1%,
unaffiliated 6%
Languages: French 1 00%, rapidly declining regional
dialects and languages (Provencal, Breton, Alsatian,
Corsican, Catalan, Basque, Flemish)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1980 est.)
Population: 59,309 (July 1998 est.)
Age structure:
0-14 years: 26% (male 7,814; female 7,709)
15-64 years: 68% (male 22,099; female 18,487)
65 years and over: 6% (male 1 ,476; female 1 ,724)
(July 1998 est.)
Population growth rate: 0.9% (1998 est.)
Birth rate: 15.83 births/1,000 population (1998 est.)
Death rate: 6.88 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.01 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 .2 male(s)/female
65 years and over: 0.86 male(s)/female (1 998 est.)
Infant mortality rate: 21 .33 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 69.46 years
male: 65.29 years
female: 73.65 years (1998 est.)
Total fertility rate: 2.17 children born/woman (1998
est.)
Nationality:
noun: Greenlander(s)
adjective: Greenlandic
Ethnic groups: Greenlander 87% (Eskimos and
Greenland-born whites), Danish and others 13%
Religions: Evangelical Lutheran
Languages: Eskimo dialects, Danish, Greenlandic
(an Inuit dialect)
Literacy: NA
note: similar to Denmark proper
Population: 16,846,808 (July 1998 est.)
Age structure:
0-14 years: 29% (male 2,486,607; female 2,413,207)
15-64 years: 64% (male 5,243,028; female
5,523,199)
65 years and over: 7% (male 393,950; female
786,817) (July 1998 est.)
Population growth rate: -0.17% (1998 est.)
Birth rate: 17.24 births/1,000 population (1998 est.)
Death rate: 10.15 deaths/1 ,000 population
(1998 est.)
Net migration rate: -8.79 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years : 0.95 male(s)/female
65 years and over: 0.5 male(s)/female (1 998 est.)
247
Kazakhstan (continued)
Infant mortality rate: 58.25 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 63.59 years
male: 58.12 years
female: 69.33 years (1998 est.)
Total fertility rate: 2.12 children born/woman
(1998 est.)
Nationality:
noun: Kazakhstani(s)
adjective: Kazakhstani
Ethnic groups: Kazakh (Qazaq) 46%, Russian
34.7%, Ukrainian 4.9%, German 3.1%, Uzbek 2.3%,
Tatar 1.9%, other 7.1% (1996)
Religions: Muslim 47%, Russian Orthodox 44%,
Protestant 2%, other 7%
Languages: Kazakh (Qazaq) official language
spoken by over 40% of population, Russian official
language spoken by two-thirds of population and used
in everyday business
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male : 99%
female: 96% (1989 est.)
Population: 2,51 1 ,473 (July 1 998 est.)
Age structure:
0-14 years: 46% (male 584,303; female 583,526)
15-64 years: 51% (male 624,144; female 660,478)
65 years and over: 3% (male 24,81 3; female 34,209)
(July 1998 est.)
Population growth rate: 2.52% (1998 est.)
Birth rate: 44.46 births/1,000 population (1998 est.)
Death rate: 14.59 deaths/1 ,000 population (1998
est.)
Net migration rate: -4.65 migrant(s)/1,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.73 ma!e(s)/female (1 998 est.)
Infant mortality rate: 78.22 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 49.99 years
male: 46.95 years
female: 53.11 years (1998 est.)
Total fertility rate: 6.41 children born/woman (1998
est.)
Nationality:
noun: Mauritanian(s)
adjective: Mauritanian
Ethnic groups: mixed Maur/black 40%, Maur 30%,
black 30%
Religions: Muslim 100%
Languages: Hasaniya Arabic (official), Pular,
Soninke, Wolof (official), French
Literacy:
definition: age 1 5 and over can read and write
total population : 37.7%
male: 49.6%
female: 26.3% (1995 est.)
Population: 2,578,530 (July 1998 est.)
Age structure:
0-14 years: 37% (male 483,795; female 468,700)
15-64 years: 59% (male 764,665; female 764,825)
65 years and over: 4% (male 41 ,488; female 55,057)
(July 1998 est.)
Population growth rate: 1 .54% (1998 est.)
Birth rate: 23.56 births/1,000 population (1998 est.)
Death rate: 8.1 9 deaths/1, 000 population (1998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.05 male(s)/fema!e
under 15 years: 1 .03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.75 male(s)/female (1 998 est.)
Infant mortality rate: 66.34 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 61 .46 years
male: 59.4 years
female: 63.61 years (1998 est.)
Total fertility rate: 2.75 children born/woman (1998
est.)
Nationality:
noun: Mongolian(s)
adjective: Mongolian
Ethnic groups: Mongol 90%, Kazakh 4%, Chinese
2%, Russian 2%, other 2%
Religions: predominantly Tibetan Buddhist, Muslim
4%
note: previously limited religious activity because of
communist regime
Languages: Khalkha Mongol 90%, Turkic, Russian,
Chinese
Literacy:
definition: age 1 5 and over can read and write
total population: 82.9%
male: 88.6%
female: 77.2% (1988 est.)
Population: 1 ,622,328 (July 1 998 est.)
Age structure:
0-14 years: 44% (male 362,310; female 354,386)
15-64 years: 52% (male 414,281; female 426,921)
65 years and over: 4% (male 27,001 ; female 37,429)
(July 1998 est.)
Population growth rate: 1 .6% (1998 est.)
Birth rate: 35.84 births/1,000 population (1998 est.)
Death rate: 1 9.82 deaths/1 ,000 population (1 998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.72 male(s)/female (1 998 est.)
Infant mortality rate: 66.76 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population : 41 .48 years
male: 41 .73 years
female: 41 .24 years (1 998 est.)
Total fertility rate: 4.99 children born/woman (1998
est.)
Nationality:
noun: Namibian(s)
adjective: Namibian
Ethnic groups: black 86%, white 6.6%, mixed 7.4%
note: about 50% of the population belong to the
Ovambo tribe and 9% to the Kavangos tribe; other
ethnic groups are: Herero7%, Damara7%, Nama5%,
Caprivian 4%, Bushmen 3%, Baster 2%, Tswana
0.5%
Religions: Christian 80% to 90% (Lutheran 50% at
least, other Christian denominations 30%), native
religions 10% to 20%
Languages: English 7% (official), Afrikaans common
language of most of the population and about 60% of
the white population, German 32%, indigenous
languages: Oshivambo, Herero, Nama
Literacy:
definition: age 15 and over can read and write
total population: 38%
male: 45%
female: 31% (1960 est.)
Population: 1 1 9,81 8 (July 1 998 est.)
Age structure:
0-14 years: 31% (male 18,630; female 17,994)
15-64 years: 64% (male 38,562; female 37,979)
65 years and over: 5% (male 2,740; female 3,91 3)
(July 1998 est.)
Population growth rate: 0.6% (1998 est.)
Birth rate: 1 8.74 births/1 ,000 population (1 998 est.)
Death rate: 5.28 deaths/1 ,000 population (1 998 est.)
Net migration rate: -7.47 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.7 male(s)/female (1 998 est.)
Infant mortality rate: 1 5.69 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 73.51 years
male: 72 years
female: 75.07 years (1998 est.)
Total fertility rate: 1 .97 children born/woman (1 998
est.)
Nationality:
noun : Saint Vincentian(s) or Vincentian(s)
adjective: Saint Vincentian or Vincentian
Ethnic groups: black, white, East Indian, Carib
Amerindian
Religions: Anglican, Methodist, Roman Catholic,
Seventh-Day Adventist
Languages: English, French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 96%
male: 96%
female: 96% (1970 est.)
Population: 58,970,1 19 (July 1998 est.)
Age structure:
0-14 years: 19% (male 5,832,086; female 5,530,679)
15-64 years: 65% (male 19,304,762; female
19,032,024)
65 years and over: 16% (male 3,807,710; female
5,462,858) (July 1998 est.)
Population growth rate: 0.25% (1998 est.)
Birthrate: 12.01 births/1 ,000 population (1998 est.)
Death rate: 1 0.72 deaths/1 ,000 population (1 998
est.)
Net migration rate: 1 .2 migrant(s)/1 ,000 population
(1998 est)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.7 ma!e(s)/female (1 998 est.)
Infant mortality rate: 5.87 deaths/1 ,000 live births
(1998 est.)
488
Life expectancy at birth:
total population: 77.1 9 years
male: 74.57 years
female: 79.96 years (1998 est.)
Total fertility rate: 1.7 children born/woman (1998
est.)
Nationality:
noun : Briton(s), British (collective plural)
adjective: British
Ethnic groups: English 81.5%, Scottish 9.6%, Irish
2.4%, Welsh 1.9%, Ulster 1.8%, West Indian, Indian,
Pakistani, and other 2.8%
Religions: Anglican 27 million, Roman Catholic 9
million, Muslim 1 million, Presbyterian 800,000,
Methodist 760,000, Sikh 400,000, Hindu 350,000,
Jewish 300,000(1991 est.)
note: the UK does not include a question on religion in
its census
Languages: English, Welsh (about 26% of the
population of Wales), Scottish form of Gaelic (about
60,000 in Scotland)
Literacy:
definition: age 1 5 and over has completed five or more
years of schooling
total population: 99% (1978 est.)
male: NA%
female: NA%
Population: 270,31 1 ,756 (July 1 998 est.)
Age structure:
0-14 years: 22% (male 29,952,220; female
28,560,357)
15-64 years: 66% (male 88,1 13,895; female
89,399,501)
65 years and over: 12% (male 14,088,571; female
20,197,212) (July 1998 est.)
Population growth rate: 0.87% (1998 est.)
Birth rate: 14.4 births/1 ,000 population (1998 est.)
Death rate: 8.8 deaths/1,000 population (1998 est.)
Net migration rate: 3 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.7 male(s)/female (1 998 est.)
Infant mortality rate: 6.44 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 76.1 3 years
male: 72.85 years
female: 79.58 years (1998 est.)
Total fertility rate: 2.07 children born/woman (1998
est.)
Nationality:
noun: American(s)
adjective: American
Ethnic groups: white 83.4%, black 12.4%, Asian
3.3%, Amerindian 0.8% (1992)
Religions: Protestant 56%, Roman Catholic 28%,
Jewish 2%, other 4%, none 10% (1989)
Languages: English, Spanish (spoken by a sizable
minority)
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male : 97%
female: 97% (1979 est.)
Population: 1 ,556,91 9 (July 1 998 est.)
note: in addition, there are 155,000 Israeli settlers in
the West Bank and 164,000 in East Jerusalem
(August 1997 est.)
Age structure:
0-14 years: 45% (male 359,848; female 342,173)
15-64 years: 52% (male 405,929; female 396,928)
65 years and over: 3% (male 21 ,853; female 30,1 88)
(July 1998 est.)
Population growth rate: 3.71% (1998 est.)
Birth rate: 36.65 births/1 ,000 population (1 998 est.)
Death rate: 4.35 deaths/1 ,000 population (1 998 est.)
Net migration rate: 4.82 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/fema!e
15-64 years: 1 .02 male(s)/female
65 years and over: 0.72 male(s)/female (1998 est.)
Infant mortality rate: 26.35 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 72 .47 years
male: 70.7 years
female: 74.33 years (1 998 est.)
Total fertility rate: 4.92 children born/woman (1998
est.)
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 83%,
Jewish 17%
Religions: Muslim 75% (predominantly Sunni),
Jewish 17%, Christian and other 8%
Languages: Arabic, Hebrew (spoken by Israeli
settlers and many Palestinians), English (widely
understood)
Literacy: NA','67b0d11f1b2d98651b61e8889cb8ce12ab6ebd77b0f1da46d958b20208a70f24','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c66d64e96cd79bfcaf441d71f00c807e6eaae0967e43c1479b8e7d9e60d48def',1998,'BJ','Benin','people-and-society',106,'Population: 6,100,799 (July 1998 est.)
Age structure:
0-14 years : 48% (male 1 ,465,067; female 1 ,455,852)
15-64 years: 50% (male 1,455,224; female
1,582,880)
65 years and over: 2% (male 61 ,523; female 80,253)
(July 1998 est.)
Population growth rate: 3.31% (1998 est.)
Birth rate: 45.82 births/1,000 population (1998 est.)
Death rate: 12.77 deaths/1 ,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 ma!e(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.91 male(s)/fema1e
65 years and over: 0.76 male(s)/female (1 998 est.)
Infant mortality rate: 1 00.22 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 53.61 years
male: 51 .56 years
female: 55.72 years (1998 est.)
Total fertility rate: 6.48 children born/woman (1998
est.)
Nationality:
noun: Beninese (singular and plural)
adjective: Beninese
Ethnic groups: African 99% (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba),
Europeans 5,500
Religions: indigenous beliefs 70%, Muslim 15%,
Christian 15%
Languages: French (official), Fon and Yoruba (most
common vernaculars in south), tribal languages (at
50
least six major ones in north)
Literacy:
definition: age 15 and over can read and write
total population: 37%
male: 48.7%
female: 25.8% (1 995 est.)','8055b8376f34b6038f4f8ca1f10bd92ce78311a44d038f750ad60f0a178b6d51','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6a1e42e3458a5a06d9b16dea5bb443e4cbd534c6e44078d350cccb2dc6b3381',1998,'BM','Bermuda','people-and-society',110,'Population: 62,009 (July 1998 est.)
Age structure:
0-14 years: 20% (male 6,191; female 6,046)
15-64 years: 70% (male 21 ,330; female 21 ,91 2)
65 years and over: 1 0% (male 2,777; female 3,753)
(July 1998 est.)
Population growth rate: 0.77% (1998 est.)
Birth rate: 12.21 births/1 ,000 population (1998 est.)
Death rate: 7.22 deaths/1 ,000 population (1 998 est.)
Net migration rate: 2.68 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.97 male(s)/fema!e
65 years and over: 0.74 male(s)/female (1 998 est.)
Infant mortality rate: 9.57 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 76.77 years
male: 75 years
female: 78.63 years (1998 est.)
Total fertility rate: 1 .71 children born/woman (1998
est.)
Nationality:
noun: Bermudian(s)
adjective: Bermudian
Ethnic groups: black 61%, white and other 39%
Religions: Anglican 28%, Roman Catholic 15%,
African Methodist Episcopal (Zion) 12%, Seventh-Day
Adventist 6%, Methodist 5%, other 34% (1991)
Languages: English (official), Portuguese
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 98%
female: 99% (1970 est.)
Population: 1 ,908,307 (July 1 998 est.)
note: other estimates range as low as 600,000
Age structure:
0-14 years: 40% (male 396,839; female 368,391)
15-64 years: 56% (male 549,050; female 518,780)
65 years and over: 4% (male 38,235; female 37,012)
(July 1998 est.)
Population growth rate: 2.27% (1998 est.)
Birth rate: 37.33 births/1 ,000 population (1 998 est.)
Death rate: 1 4.6 deaths/1 ,000 population (1998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 1 .03 male(s)/female (1 998 est.)
Infant mortality rate: 1 1 1 .66 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 52.31 years
male: 52.77 years
female: 51 .83 years (1 998 est.)
Total fertility rate: 5.22 children born/woman (1998
est.)
Nationality:
noun: Bhutanese (singular and plural)
adjective: Bhutanese
Ethnic groups: Bhote 50%, ethnic Nepalese 35%,
indigenous or migrant tribes 15%
Religions: Lamaistic Buddhism 75%, Indian- and
Nepalese-influenced Hinduism 25%
Languages: Dzongkha (official), Bhotes speak
various Tibetan dialects, Nepalese speak various
Nepalese dialects
Literacy:
definition: age 15 and over can read and write
total population: 42.2%
male: 56.2%
female: 28.1% (1995 est.)
People— note: refugee issue over the presence in
Nepal of approximately 91,000 Bhutanese refugees,
90% of whom are in seven United Nations Office of
the High Commissioner for Refugees (UNHCR)
camps','f2732e4a446c5ed3e842402ae390bb6572294dbee0583429db50fcc15c354c0e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22875b03a94ed65af6bbf758be73891dee32ad8058d0b087ad249c2661a06bf6',1998,'BR','Brazil','people-and-society',118,'Population: 7,826,352 (July 1998 est.)
Age structure:
0-14 years: 39% (male 1,559,149; female 1 ,526,646)
15-64 years: 56% (male 2,139,680; female
2,245,268)
65 years and over: 5% (male 1 61 ,431 ; female
194,178) (July 1998 est.)
Population growth rate: 2% (1998 est.)
Birth rate: 31 .43 births/1 ,000 population (1 998 est.)
Death rate: 9.89 deaths/1 ,000 population (1 998 est.)
Net migration rate: -1.53 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .02 male(s)/fema!e
15-64 years: 0.95 male(s)/female
65 years and over: 0.83 male(s)/female (1 998 est.)
Infant mortality rate: 63.86 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 60.89 years
male: 57.98 years
female: 63.94 years (1998 est.)
Total fertility rate: 4.05 children born/woman (1998
est.)
Nationality:
noun:Bo\\\\mn(s)
adjective: Bolivian
Ethnic groups: Quechua 30%, Aymara 25%,
mestizo (mixed white and Amerindian ancestry)
25%-30%, white 5%-15%
Religions: Roman Catholic 95%, Protestant
(Evangelical Methodist)
Languages: Spanish (official), Quechua (official),
Aymara (official)
Literacy:
definition: age 15 and over can read and write
total population: 83 .1%
male: 90.5%
fema/e:76%(1995 est.)
Population: 3,365,727 (July 1998 est.)
note: all data dealing with population is subject to
considerable error because of the dislocations caused
by military action and ethnic cleansing
Age structure:
0-14 years: 18% (male 307,857; female 291 ,424)
58
15-64 years: 71 % (male 1 ,1 77,51 6; female
1,195,419)
65 years and over: 1 1 % (male 1 56,041 ; female
237,470) (July 1998 est.)
Population growth rate: 3.63% (1998 est.)
Birth rate: 8.72 births/1,000 population (1998 est.)
Death rate: 1 2.32 deaths/1 ,000 population (1 998
est.)
Net migration rate: 39.91 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.65 male(s)/female (1 998 est.)
Infant mortality rate: 30.8 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 63.03 years
male: 58.35 years
female: 68.02 years (1998 est.)
Total fertility rate: 1.14 children born/woman (1998
est.)
Nationality:
noun: Bosnian(s), Herzegovinian(s)
adjective: Bosnian, Herzegovinian
Ethnic groups: Serb 40%, Muslim 38%, Croat 22%
(est.)
Religions: Muslim 40%, Orthodox 31%, Catholic
15%, Protestant 4%, other 10%
Languages: Serbo-Croatian (often called Bosnian)
99%
Literacy: NA
Population: 1,448,454 (July 1998 est.)
Age structure:
0-14 years: 42% (male 310,253; female 302,960)
15-64 years: 54% (male 370,925; female 409,941)
65 years and over: 4% (male 20,637; female 33,738)
(July 1998 est.)
Population growth rate: 1 .1 1 % (1 998 est.)
Birth rate: 32.02 births/1,000 population (1998 est.)
Death rate: 20.89 deaths/1,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.61 male(s)/female (1998 est.)
Infant mortality rate: 59.29 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 40.09 years
male: 39.46 years
female: 40.75 years (1998 est.)
Total fertility rate: 4.03 children born/woman (1998
est.)
Nationality:
noun: Motswana (singular), Batswana (plural)
adjective: Motswana (singular), Batswana (plural)
Ethnic groups: Batswana 95%, Kalanga, Basarwa,
and Kgalagadi 4%, white 1%
Religions: indigenous beliefs 50%, Christian 50%
Languages: English (official), Setswana
Literacy:
definition: age 15 and over can read and write
total population: 69.8%
male: 80.5%
female: 59.9% (1995 est.)
Population: 26,111,110 (July 1998 est.)
Age structure:
0-14 years: 36% (male 4,745,363; female 4,589,017)
15-64 years: 60% (male 7,856,414; female
7,752,085)
65 years and over: 4% (male 535,566; female
632,665) (July 1998 est.)
Population growth rate: 1 .97% (1998 est.)
Birth rate: 26.69 births/1,000 population (1998 est.)
Death rate: 5.81 deaths/1 ,000 population (1 998 est.)
Net migration rate: -1.15 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1.03 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.85 male(s)/female (1 998 est.)
Infant mortality rate: 43.42 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 69.97 years
male: 67.78 years
female: 72.25 years (1 998 est.)
Total fertility rate: 3.31 children born/woman (1998
est.)
Nationality:
noun: Peruvian(s)
adjective: Peruvian
Ethnic groups: Amerindian 45%, mestizo (mixed
Amerindian and white) 37%, white 15%, black,
Japanese, Chinese, and other 3%
Religions: Roman Catholic
Languages: Spanish (official), Quechua (official),
Aymara
Literacy:
definition: age 1 5 and over can read and write
total population: 88.7%
male: 94.5%
female: 83% (1995 est.)','c2e88bd5d8e471d84c7fa85bf028483ac129c0a0981637d62c5b59adcaa3ea4a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e0cf3ba0816a6062643e6d6ff78a2fe7f8a170271974e998327cf7dbb174449',1998,'NO','Norway','people-and-society',129,'Population: 169,806,557 (July 1998 est.)
note: Brazil took a census in August 1 996 which
showed a total of 1 57,079,573; this figure is about 5%
lower than projections by the US Census Bureau,
which is close to the implied underenumeration of
4.6% for 1991; since the full results of the census have
not been released for analysis, the numbers shown for
Brazil do not take into consideration the results of this
1996 census
Age structure:
0-14 years: 30% (male 26,090,859; female
25.132.122)
15-64 years: 65% (male 54,199,642; female
55.769.122)
65 years and over: 5% (male 3,499,272; female
5,115,540) (July 1998 est.)
Population growth rate: 1.24% (1998 est.)
Birth rate: 20.92 births/1 ,000 population (1998 est.)
Death rate: 8.53 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.03 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over : 0.68 ma!e(s)/fema!e (1 998 est.)
infant mortality rate: 36.96 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
tota! population: 64.36 years
male: 59.39 years
female: 69.59 years (1998 est.)
Total fertility rate: 2.33 children born/woman (1998
est.)
Nationality:
/?oun:Brazilian(s)
adjective: Brazilian
Ethnic groups: white (includes Portuguese,
German, Italian, Spanish, Polish) 55%, mixed white
and black 38%, black 6%, other (includes Japanese,
Arab, Amerindian) 1%
Religions: Roman Catholic (nominal) 70%
Languages: Portuguese (official), Spanish, English,
French
Literacy:
definition: age 1 5 and over can read and write
total population: 83.3%
male: 83.3%
female: 83.2% (1995 est.)
Population: 125,931,533 (July 1998 est.)
Age structure:
0-14 years: 15% (male 9,802,921 ; female 9,342,254)
15-64 years: 69% (male 43,486,840; female
43,135,979)
65 years and over: 16% (male 8,388,242; female
11,775,297) (July 1998 est.)
Population growth rate: 0.2% (1998 est.)
Birth rate: 10.26 births/1 ,000 population (1998 est.)
Death rate: 7.94 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.36 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.71 male(s)/female (1 998 est.)
Infant mortality rate: 4.1 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 80 years
male : 76.91 years
female: 83.25 years (1998 est.)
Total fertility rate: 1.46 children born/woman
(1998 est.)
Nationality:
noun: Japanese (singular and plural)
adjective: Japanese
Ethnic groups: Japanese 99.4%, other 0.6%
(mostly Korean)
Religions: observe both Shinto and Buddhist 84%,
other 16% (including Christian 0.7%)
Languages: Japanese
Literacy:
definition: age 15 and over can read and write
total population: 99% (1970 est.)
male: NA%
female: NA%','a9a70c40f94e07a667489607a1f0b6a555596a4953d106d83f691d680aeea7ee','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85edcbb34bf7265af70472c52de5e71036c3c1f23d189cbac617aa040733e54f',1998,'ID','Indonesia','people-and-society',135,'Population: no indigenous inhabitants
note: there are UK-US military personnel and civilian
contractors; approximately 3,000 native inhabitants,
known as the Chagosians or Hois, were evacuated to
Mauritius before construction of UK-US military
facilities
Population: 18,705 (July 1998 est.)
Age structure:
0-14 years: 21 % (male 2,008; female 1 ,957)
15-64 years: 74% (male 7,079; female 6,689)
65 years and over: 5% (male 535; female 437) (July
1998 est.)
Population growth rate: 2.41% (1998 est.)
Birth rate: 16.15 births/1,000 population (1998 est.)
Death rate: 4.76 deaths/1 ,000 population (1998 est.)
Net migration rate: 12.67 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 1 .22 male(s)/female (1 998 est.)
Infant mortality rate: 22.97 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 74.94 years
male: 74. 19 years
female: 75.73 years (1998 est.)
Total fertility rate: 1 .72 children born/woman (1 998
est.)
Nationality:
noun: British Virgin Islander(s)
adjective: British Virgin Islander
Ethnic groups: black 90%, white, Asian
Religions: Protestant 86% (Methodist 45%,
Anglican 21%, Church of God 7%, Seventh-Day
Adventist 5%, Baptist 4%, Jehovah''s Witnesses 2%,
other 2%), Roman Catholic 6%, none 2%, other 6%
(1981)
Languages: English (official)
Literacy:
definition: age 15 and over can read and write
total population: 97. 8% (1991 est.)
male: NA%
female: NA%
Population: 212,941,810 (July 1998 est.)
Age structure:
0-14 years: 31% (male 33,311,867; female
32,361,468)
15-64 years: 65% (male 69,215,722; female
69,578,527)
65 years and over: 4% (male 3,744,314; female
4,729,912) (July 1998 est.)
Population growth rate: 1 .49% (1998 est.)
Birth rate: 23.1 births/1 ,000 population (1998 est.)
Death rate: 8.22 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.79 male(s)/female (1998 est.)
Infant mortality rate: 59.23 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 62.49 years
male: 60.28 years
female: 64.81 years (1998 est.)
Total fertility rate: 2.61 children born/woman
(1998 est.)
Nationality:
noun : Indonesian(s)
adjective: Indonesian
Ethnic groups: Javanese 45%, Sundanese 14%,
Madurese 7.5%, coastal Malays 7.5%, other 26%
Religions: Muslim 87%, Protestant 6%, Roman
Catholic 3%, Hindu 2%, Buddhist 1 %, other 1 % (1 985)
Languages: Bahasa Indonesia (official, modified
form of Malay), English, Dutch, local dialects, the most
widely spoken of which is Javanese
Literacy:
definition: age 15 and over can read and write
total population: 83.8%
male: 89.6%
female: 78% (1995 est.)
Population: 68,959,931 (July 1998 est.)
note: includes 607,252 non-nationals (July 1998 est.)
Age structure:
0-14 years: 43% (male 15,371,060; female
14,513,782)
15-64 years: 53% (male 18,469,620; female
17,810,596)
65 years and over: 4% (male 1 ,428,471 ; female
1,366,402) (July 1998 est.)
Population growth rate: 2.04% (1998 est.)
Birth rate: 31 .37 births/1 ,000 population (1998 est.)
Death rate: 6. 19 deaths/1 ,000 population (1998 est.)
Net migration rate: -4.79 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 .04 ma!e(s)/female
65 years and over: 1 .05 male(s)/fema!e (1 998 est.)
Infant mortality rate: 48.95 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 68.25 years
male: 66.83 years
female: 69.74 years (1998 est.)
Total fertility rate: 4.31 children born/woman
(1998 est.)
Nationality:
noun: Iranian(s)
adjective: Iranian
Ethnic groups: Persian 51%, Azerbaijani 24%,
Gilaki and Mazandarani 8%, Kurd 7%, Arab 3%,
Lur 2%, Baloch 2%, Turkmen 2%, other 1%
Religions: Shi''a Muslim 89%, Sunni Muslim 10%,
Zoroastrian, Jewish, Christian, and Baha''i 1%
Languages: Persian and Persian dialects 58%,
Turkic and Turkic dialects 26%, Kurdish 9%, Luri 2%,
Balochi 1%, Arabic 1%, Turkish 1%, other 2%
Literacy:
definition: age 15 and over can read and write
total population: 72.1%
male: 78.4%
female: 65.8% (1994 est.)
224
Population: 21 ,722,287 (July 1998 est)
Age structure:
0-14 years: 44% (male 4,865,820; female 4,71 1 ,791 )
15-64 years: 53% (male 5,794,336; female
5,662,163)
65 years and over: 3% (male 320,672; female
367,505) (July 1998 est.)
Population growth rate: 3.2% (1998 est.)
Birth rate: 38.58 births/1,000 population (1998 est.)
Death rate: 6.57 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.87 male(s)/female (1 998 est.)
Infant mortality rate: 62.41 deaths/1 ,000 live births
(1998 est)
Life expectancy at birth:
total population: 66.52 years
male: 65.54 years
female: 67.56 years (1998 est.)
Total fertility rate: 5.23 children born/woman
(1998 est.)
Nationality:
noun: Iraqi(s)
adjective: Iraqi
Ethnic groups: Arab 75%-80%, Kurdish 15%-20%,
Turkoman, Assyrian or other 5%
Religions: Muslim 97% (Shi''a 60%-65%, Sunni
32%-37%), Christian or other 3%
Languages: Arabic, Kurdish (official in Kurdish
regions), Assyrian, Armenian
Literacy:
definition: age 1 5 and over can read and write
total population: 58%
male: 70.7%
female: 45% (1995 est.)
Population: 129,658 (July 1998 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 3.31% (1998 est.)
Birth rate: 27.55 births/1,000 population (1998 est.)
Death rate: 6.07 deaths/1 ,000 population (1 998 est.)
Net migration rate: 1 1 .65 migrant(s)/1 ,000
population (1998 est.)
Infant mortality rate: 34.51 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 68.34 years
male: 66.38 years
female: 70.34 years (1998 est.)
Total fertility rate: 3.9 children born/woman (1998
est.)
Nationality:
noun: Micronesian(s)
adjective: Micronesian; Kosrae(s), Pohnpeian(s),
Trukese, Yapese
Ethnic groups: nine ethnic Micronesian and
Polynesian groups
Religions: Roman Catholic 50%, Protestant 47%,
other and none 3%
Languages: English (official and common
language), Trukese, Pohnpeian, Yapese, Kosrean
Literacy:
definition: age 15 and over can read and write
total population: 89%
male: 91%
female: 88% (1980 est.)
Population: no indigenous inhabitants
Population growth rate: 0% (1998 est.)
314
Population: 4,457,729 (July 1998 est.)
Age structure:
0-14 years: 25% (male 568,609; female 548,837)
15-64 years: 65% (male 1,394,604; female
1,514,749)
65 years and over: 1 0% (male 1 59,972; female
270,958) (July 1998 est.)
Population growth rate: 0.04% (1998 est.)
Birth rate: 14.35 births/1,000 population (1998 est.)
Death rate: 12.42 deaths/1 ,000 population (1998
est.)
Net migration rate: -1 .54 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.59 male(s)/female (1 998 est.)
Infant mortality rate: 43.72 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 64.32 years
male: 59.61 years
female: 6927 years (1998 est.)
Total fertility rate: 1.88 children born/woman (1998
est.)
Nationality:
noun: Moldovan(s)
adjective: Moldovan
Ethnic groups: Moldavian/Romanian 64.5%,
Ukrainian 13.8%, Russian 13%, Gagauz 3.5%,
Jewish 1 .5%, Bulgarian 2%, other 1 .7% (1 989 figures)
note: internal disputes with ethnic Russians and
Ukrainians in the Nistru region and Gagauz Turks in
the south
Religions: Eastern Orthodox 98.5%, Jewish 1 .5%,
Baptist (only about 1,000 members) (1991)
note: the large majority of churchgoers are ethnic
Moldavian
Languages: Moldovan (official .virtually the same as
315
Moldova (continued)
the Romanian language), Russian, Gagauz (a Turkish
dialect)
Literacy:
definition: age 1 5 and over can read and write
total population: 96%
male: 99%
female: 94% (1989 est.)
Population: 3,490,356 (July 1998 est.)
Age structure:
0-14 years: 21% (male 383,960; female 361 ,244)
15-64 years: 12% (male 1,252,427; female
1,255,795)
65 years and over: 7% (male 1 05,41 7; female
131,513) (July 1998 est.)
Population growth rate: 1.2% (1998 est.)
Birth rate: 1 3.79 births/1 ,000 population (1 998 est.)
Death rate: 4.68 deaths/1 ,000 population (1 998 est.)
Net migration rate: 2.87 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1 .06 ma!e(s)/female
15-64 years:) male(s)/female
65 years and over: 0.8 male(s)/female (1 998 est.)
Infant mortality rate: 3.87 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.49 years
male: 75.46 years
female: 81.'' 77 years (1998 est.)
Total fertility rate: 1 .46 children born/woman (1 998
est.)
Nationality:
noun: Singaporean(s)
adjective: Singapore
Ethnic groups: Chinese 76.4%, Malay 14.9%,
Indian 6.4%, other 2.3%
Religions: Buddhist (Chinese), Muslim (Malays),
Christian, Hindu, Sikh, Taoist, Confucianist
Languages: Chinese (official), Malay (official and
national), Tamil (official), English (official)
Literacy:
definition: age 15 and over can read and write
total population: 91.1%
male: 95.9%
female: 86.3% (1995 est.)','10854aaa00635f0af8064c278056286096e7746d4be4e8033adef100832837d1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee94a69d26fc8e12b1e1d76afdc02d41b19fdbf5ebefafe13022f8aaa3d63573',1998,'BI','Burundi','people-and-society',162,'Population: 5,537,387 (July 1998 est.)
Age structure:
0-14 years: 47% (male 1 ,313,1 12; female 1 ,309,600)
15-64 years: 50% (male 1 ,331 ,336; female
1,417,228)
65 years and over: 3% (male 69,71 8; female 96,393)
(July 1998 est.)
Population growth rate: 3.51% (1998 est.)
Birth rate: 41.61 births/1,000 population (1998 est.)
Death rate: 1 7.38 deaths/1 ,000 population (1998
est.)
Net migration rate: 1 0.84 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.72 maie(s)/female (1998 est.)
Infant mortality rate: 101.19 deaths/1,000 live
births (1998 est.)
Life expectancy at birth:
total population: 45.56 years
male: 43.79 years
female: 47.38 years (1998 est.)
Total fertility rate: 6.4 children born/woman (1998
est.)
Nationality:
noun: Burundian(s)
adjective: Burundi
Ethnic groups: Hutu (Bantu) 85%, Tutsi (Hamitic)
14%, Twa (Pygmy) 1%, Europeans 3,000, South
Asians 2,000
Religions: Christian 67% (Roman Catholic 62%,
Protestant 5%), indigenous beliefs 32%, Muslim 1%
Languages: Kirundi (official), French (official),
Swahili (along Lake Tanganyika and in the Bujumbura
area)
Literacy:
definition: age 1 5 and over can read and write
total population: 35.3%
male: 49.3%
female: 22.5% (1995 est.)
Population: 11,339,562 (July 1998 est.)
Age structure:
0-14 years: 45% (male 2,61 1 ,684; female 2,533,313)
15-64 years: 52% (male 2,729,598; female
3,119,579)
65 years and over: 3% (male 1 42,836; female
202,552) (July 1998 est.)
Population growth rate: 2.51% (1998 est.)
Birth rate: 41 .63 births/1 ,000 population (1 998 est.)
Death rate: 1 6.49 deaths/1 ,000 population (1 998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/fema!e
15-64 years: 0.87 male(s)/female
65 years and over: 0.7 male(s)/fema!e (1 998 est.)
infant mortality rate: 1 06.76 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 47.99 years
male: 46.64 years
female: 49.41 years (1998 est.)
Total fertility rate: 5.81 children born/woman (1998
est.)
Nationality:
noun: Cambodian(s)
adjective: Cambodian
Ethnic groups: Khmer 90%, Vietnamese 5%,
Chinese 1%, other 4%
Religions: Theravada Buddhism 95%, other 5%
Languages: Khmer (official), French
Literacy:
definition: age 1 5 and over can read and write
total population: 35%
male: 48%
female: 22% (1990 est.)','530c6de1bb657a48442252c684805e4a4ef8f01a3b859e2c7ea2b06d218098c1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23254eb0ebd7d83c99573adb202fdd3a7f47ba27bd9ab70fa56dfa14538ac624',1998,'CA','Canada','people-and-society',178,'Population: 30,675,398 (July 1998 est.)
Age structure:
0-14 years: 20% (male 3,106,331 ; female 2,961 ,328)
15-64 years: 68% (male 10,457,686; female
10,328,953)
65 years and over: 1 2% (male 1 ,61 9,704; female
2,201,396) (July 1998 est.)
Population growth rate: 1 .09% (1 998 est.)
Birth rate: 12.12 births/1,000 population (1998 est.)
Death rate: 7.25 deaths/1 ,000 population (1 998 est.)
Net migration rate: 6.03 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.74 ma!e(s)/femaie (1 998 est.)
Infant mortality rate: 5.59 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 79.1 6 years
male: 75.86 years
female: 82.63 years (1998 est.)
Total fertility rate: 1 .65 children born/woman (1 998
est.)
Nationality:
noun: Canadian(s)
adjective: Canadian
Ethnic groups: British isles origin 40%, French
origin 27%, other European 20%, Amerindian 1.5%,
other, mostly Asian 1 1 .5%
Religions: Roman Catholic 45%, United Church
12%, Anglican 8%, other 35% (1991)
Languages: English (official), French (official)
Literacy:
definition: age 15 and over can read and write
total population: 97% (1986 est.)
male: NA%
female: NA%
Population: 399,857 (July 1998 est.)
Age structure:
0-14 years: 46% (male 92,175; female 90,557)
15-64 years: 48% (male 90,183; female 102,541)
65 years and over: 6% (male 9,765; female 14,636)
(July 1998 est.)
Population growth rate: 1 .49% (1 998 est.)
Birth rate: 34.47 births/1 ,000 population (1 998 est.)
Death rate: 7.04 deaths/1 ,000 population (1 998 est.)
Net migration rate: -12.54 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.87 male(s)/female
65 years and over: 0.66 male(s)/female (1 998 est.)
Infant mortality rate: 47.53 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 70.5 years
male: 67.21 years
female: 73.89 years (1998 est.)
Total fertility rate: 5.08 children born/woman (1998
est.)
Nationality:
noun: Cape Verdean(s)
adjective: Cape Verdean
Ethnic groups: Creole (mulatto) 71%, African 28%,
European 1%
Religions: Roman Catholicism fused with
indigenous beliefs
Languages: Portuguese, Crioulo, a blend of
Portuguese and West African words
Literacy:
definition: age 1 5 and over can read and write
total population: 71. 6%
male: 81 .4%
female: 63.8% (1995 est.)
f; Government
Country name:
conventional long form: Republic of Cape Verde
conventional short form: Cape Verde
local long form: Republica de Cabo Verde
local short form: Cabo Verde
Data code: CV
Government type: republic
National capital: Praia
Administrative divisions: 14 districts (concelhos,
singular — concelho); Boa Vista, Brava, Fogo, Maio,
Paul, Praia, Porto Novo, Ribeira Grande, Sal, Santa
Catarina, Santa Cruz, Sao Nicolau, Sao Vicente,
Tarrafal
note: there may be a new administrative structure of
16 districts (Boa Vista, Brava, Maio, Mosteiros, Paul,
Praia, Porto Novo, Ribeira Grande, Sal, Santa
Catarina, Santa Cruz, Sao Domingos, Sao Nicolau,
Sao Filipe, Sao Vicente, Tarrafa)
Independence: 5 July 1975 (from Portugal)
National holiday: Independence Day, 5 July (1975)
Constitution: new constitution came into force 25
September 1992
Legal system: derived from the legal system of','1c126bd7bc3048c734fc4efc8215b9acd96aa5901fbc108cd1687f6a317810d3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('028230728528907f5e999b609f1ed601fd72ed7f7b33b57a4187bf39b16d15dd',1998,'PT','Portugal','people-and-society',184,'Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Antonio MASCARENHAS
Monteiro (since 22 March 1991)
head of government: Prime Minister Carlos Alberto
Wahnon de Carvalho VEIGA (since 1 3 January 1 991 )
cabinet: Council of Ministers appointed by the
president on the recommendation of the prime
minister from among the members of the National
Assembly
elections: president elected by popular vote for a
five-year term; election last held 18 February 1996
(next to be held NA February 2001); prime minister
nominated by the National Assembly and appointed
by the president
election results: Antonio MASCARENHAS Monteiro
elected president; percent of vote— Antonio
MASCARENHAS Monteiro (independent) 80.1%
Legislative branch: unicameral National Assembly
or Assembleia Nacional (72 seats; members are
elected by popular vote to serve five-year terms)
elections: last held 17 December 1995 (next to be
held NA 2000)
election results: percent of vote by party— MPD 59%,
PAICV 28%, PCD 6%; seats by party-MPD 50,
PAICV 21, PCD 1
Judicial branch: Supreme Tribunal of Justice or
Supremo Tribunal de Justia
Political parties and leaders: Movement for
Democracy or MPD [Prime Minister Carlos VEIGA,
founder and president]; African Party for
Independence of Cape Verde or PAICV [Pedro
Verona Rodrigues PIRES, chairman]; Party for
Democratic Convergence or PCD; Social Democratic
Party or PSD [Joao ALEM, president]
International organization participation: ACCT,
ACP, AfDB, CCC, ECA, ECOWAS, FAO, G-77, IBRD,
ICAO, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS, ILO,
IMF, IMO, Intelsat, Interpol, IOC, IOM (observer), ITU,
NAM, OAU, UN, UNCTAD, UNESCO, UNIDO, UPU,
WCL, WHO, WMO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador (vacant); Deputy Chief
of Mission is Charge d''Affaires Manuel MATOS
chancery : 3415 Massachusetts Avenue NW,
Washington, DC 20007
telephone: [\\] (202) 965-6820
FAX: [1] (202) 965-1207
consulate(s) general: Boston
Diplomatic representation from the US:
chief of mission: Ambassador Lawrence Neal
BENEDICT (17 June 1996)
embassy: Rua Abilio Macedo 81 , Praia
mailing address: C. P. 201 , Praia
telephone: [238] 61 5616
FAX: [238] 61 13 55
Flag description: three horizontal bands of light
blue (top, double width), white (with a horizontal red
stripe in the middle third), and light blue; a circle of 10
yellow five-pointed stars is centered on the hoist end
of the red stripe and extends into the upper and lower
blue bands
Population: 2,009,387 (July 1998 est.)
note: the Macedonian government census of July
1 994 put the population at 1 .94 million, but ethnic
allocations were likely undercounted
Age structure:
0-14 years: 24% (male 244,636; female 230,103)
15-64 years: 67% (male 675,783; female 669,878)
65 years and over: 9% (male 85,030; female
103,957) (July 1998 est.)
Population growth rate: 0.68% (1998 est.)
Birth rate: 15.71 births/1,000 population (1998 est.)
Death rate: 8.08 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.88 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.81 male(s)/female (1 998 est.)
Infant mortality rate: 19.49 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 72.77 years
male: 70.67 years
female: 75.03 years (1998 est.)
Total fertility rate: 2.06 children born/woman (1998
est.)
Nationality:
noun: Macedonian(s)
adjective: Macedonian
Ethnic groups: Macedonian 65%, Albanian 22%,
Turkish 4%, Serb 2%, Gypsies 3%, other 4%
Religions: Eastern Orthodox 67%, Muslim 30%,
other 3%
Languages: Macedonian 70%, Albanian 21%,
Turkish 3%, Serbo-Croatian 3%, other 3%
Literacy: NA
Population: 14,462,509 (July 1998 est.)
Age structure:
0-14 years: 45% (male 3,272,236; female 3,196,565)
15-64 years: 52% (male 3,722,459; female
3,792,178)
65 years and over: 3% (male 231 ,582; female
247,489) (July 1998 est.)
Population growth rate: 2.81% (1998 est.)
Birth rate: 41 .89 births/1 ,000 population (1 998 est.)
Death rate: 1 3.83 deaths/1 ,000 population (1 998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/femaie
under 15 years: 1 .02 male(s)/fema!e
15-64 years: 0.98 male(s)/female
65 years and over: 0.93 male(s)/female (1 998 est.)
Infant mortality rate: 90.57 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 52.88 years
male: 51 .7 years
female: 54.1 years (1998 est.)
Total fertility rate: 5.76 children born/woman (1998
est.)
Nationality:
noun: Malagasy (singular and plural)
adjective: Malagasy
Ethnic groups: Malayo-lndonesian (Merina and
related Betsileo), Cotiers (mixed African,
Malayo-lndonesian, and Arab ancestry—
Betsimisaraka, Tsimihety, Antaisaka, Sakalava),
French, Indian, Creole, Comoran
Religions: indigenous beliefs 52%, Christian 41%,
Muslim 7%
Languages: French (official), Malagasy (official)
Literacy:
definition: age 15 and over can read and write
total population: 80%
male : 88%
female: 73% (1990 est.)','4f7f2a05884d89d0e1cbaaade331406fec7569fc1c06f1d88c2a6a4a0ffb9d25','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8819322239d5e3b14d23a1ada5e4e9bfa881313ea9766f730b8a12cda0ea89a9',1998,'HN','Honduras','people-and-society',193,'Population: 37,716 (July 1998 est.)
Age structure:
0- 14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 4.22% (1998 est.)
Birth rate: 1 3.95 births/1 ,000 population (1 998 est.)
Death rate: 4.98 deaths/1 ,000 population (1 998 est.)
Net migration rate: 33.2 migrant(s)/1 ,000
population (1998 est.)
note: major destination for Cubans trying to migrate to
the US
Infant mortality rate: 8.4 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 77 A years
male: 75.37 years
female: 78.81 years (1998 est.)
Total fertility rate: 1 .34 children born/woman (1 998
est.)
Nationality:
noun: Caymanian(s)
adjective: Caymanian
Ethnic groups: mixed 40%, white 20%, black 20%,
expatriates of various ethnic groups 20%
Religions: United Church (Presbyterian and
Congregational), Anglican, Baptist, Roman Catholic,
Church of God, other Protestant denominations
Languages: English
Literacy:
definition: age 1 5 and over has ever attended school
total population: 98%
male: 98%
female: 98% (1 970 est.)
Population: 3,375,771 (July 1998 est.)
Age structure:
0-14 years: 44% (male 745,128; female 737,879)
15-64 years: 52% (male 864,263; female 906,656)
65 years and over: 4% (male 55,051 ; female 66,794)
(July 1998 est.)
Population growth rate: 2.02% (1998 est.)
Birth rate: 38.72 births/1 ,000 population (1998 est.)
Death rate: 1 6.75 deaths/1 ,000 population (1 998
est.)
Net migration rate: -1 .78 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/fema!e
under 15 years: 1 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.82 male(s)/female (1 998 est.)
Infant mortality rate: 1 05.73 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 46.82 years
male: 45.02 years
female: 48.68 years (1 998 est.)
Total fertility rate: 5.12 children born/woman (1998
est.)
Nationality:
noun: Central African(s)
adjective : Central African
Ethnic groups: Baya 34%, Banda 27%, Sara 10%,
Mandjia 21%, Mboum 4%, M''Baka 4%, Europeans
6,500 (including 3,600 French)
Religions: indigenous beliefs 24%, Protestant 25%,
Roman Catholic 25%, Muslim 15%, other 11%
note: animistic beliefs and practices strongly influence
the Christian majority
Languages: French (official), Sangho (lingua franca
and national language), Arabic, Hunsa, Swahili
Literacy:
definition: age 1 5 and over can read and write
total population: 60%
male: 68.5%
female: 52.4% (1995 est.)
90
Population: 5,861 ,955 (July 1 998 est.)
Age structure:
0- 14 years: 42% (male 1 ,248,291 ; female 1 ,204,574)
15-64 years: 55% (male 1 ,591 ,995; female
1,615,449)
65 years and over: 3% (male 96,01 7; female
105,629) (July 1998 est.)
Population growth rate: 2.33% (1998 est.)
Birth rate: 31 .79 births/1 ,000 population (1 998 est.)
Death rate: 7.02 deaths/1 ,000 population (1 998 est.)
Net migration rate: -1.48 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.91 male(s)/female (1 998 est.)
Infant mortality rate: 41 .88 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 65.01 years
male: 63.31 years
female: 66.8 years (1998 est.)
Total fertility rate: 4.12 children born/woman (1998
est.)
Nationality:
noun: Honduran(s)
adjective: Honduran
Ethnic groups: mestizo (mixed Amerindian and
European) 90%, Amerindian 7%, black 2%, white 1%
Religions: Roman Catholic 97%, Protestant minority
Languages: Spanish, Amerindian dialects
Literacy:
definition: age 15 and over can read and write
total population: 72.7%
male: 72.6%
female: 72.7% (1 995 est.)
Population: 6,706,965 (July 1998 est.)
Age structure:
0-14 years: 18% (male 637,808; female 591,900)
15-64 years: 71% (male 2,360,878; female
2,425,291)
65 years and over: 1 1 % (male 31 2,033; female
379,055) (July 1998 est.)
Population growth rate: 2.24% (1998 est.)
Birth rate: 12.85 births/1,000 population (1998 est.)
Death rate: 5.87 deaths/1 ,000 population (1 998 est.)
Net migration rate: 15.41 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .08 ma!e(s)/female
15-64 years: 0.97 male(s)/fema!e
65 years and over: 0.82 male(s)/female (1 998 est.)
Infant mortality rate: 5.24 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.81 years
male: 76.07 years
female : 81 .74 years (1 998 est.)
Total fertility rate: 1 .36 children born/woman
(1998 est.)
Nationality:
noun: Chinese
adjective : Chinese
Ethnic groups: Chinese 95%, other 5%
Religions: eclectic mixture of local religions 90%,
Christian 10%
Languages: Chinese (Cantonese), English
Literacy:
definition: age 15 and over has ever attended school
total population: 92.2%
male: 96%
female: 88.2% (1996 est.)
Population: 9,671,848 (July 1998 est.)
Age structure:
0-14 years: 48% (male 2,374,482; female 2,277,1 76)
15-64 years: 50% (male 2,345,773; female
2,447,951)
65 years and over: 2% (male 1 1 9,644; female
106,822) (July 1998 est.)
Population growth rate: 2.96% (1998 est.)
Birthrate: 53.01 births/1 ,000 population (1998 est.)
Death rate: 23.38 deaths/1,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/fema!e
under 15 years: 1 .04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 1.12 male(s)/female (1 998 est.)
Infant mortality rate: 1 1 4.39 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 41 .52 years
male: 41.83 years
female: 41.21 years (1998 est.)
Total fertility rate: 7.3 children born/woman (1998
est.)
Nationality:
noun: Nigerien(s)
adjective: Nigerien
Ethnic groups: Hausa 56%, Djerma 22%, Fula
8.5%, Tuareg 8%, Beri Beri (Kanouri) 4.3%, Arab,
Toubou, and Gourmantche 1 .2%, about 1 ,200 French
expatriates
Religions: Muslim 80%, remainder indigenous
beliefs and Christians
Languages: French (official), Hausa, Djerma
Literacy:
definition: age 15 and over can read and write
total population: 13.6%
male: 20.9%
female: 6.6% (1995 est.)','be3ba0369ae7a890b014fcb5809d6b75661ccd860ed6cd722f5de2f96bede61b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5b3c1ca035366f188abb78c04a786533085cdc29e8b2d101bc829ff2476142a',1998,'TD','Chad','people-and-society',202,'Population: 7,359,512 (July 1998 est.)
Age structure:
0-14 years: 44% (male 1,631,010; female 1 ,623,272)
15-64 years: 53% (male 1,903,012; female
1,982,257)
65 years and over: 3% (male 97,1 1 8; female
122,843) (July 1998 est.)
Population growth rate: 2.66% (1998 est.)
Birth rate: 43.45 births/1 ,000 population (1998 est.)
Death rate: 1 6.86 deaths/1 ,000 population
(1998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .04 maie(s)/female
under 15 years:) male(s)/fema!e
15-64 years: 0.96 ma!e(s)/fema!e
65 years and over: 0.79 male(s)/female (1 998 est.)
92
Infant mortality rate: 1 1 6.97 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 48.22 years
male: 45.81 years
female: 50.73 years (1998 est.)
Total fertility rate: 5.74 children born/woman
(1998 est.)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic groups: Muslims (Arabs, Toubou, Hadjerai,
Fulbe, Kotoko, Kanembou, Baguirmi, Boulala,
Zaghawa, and Maba), non-Muslims (Sara,
Ngambaye, Mbaye, Goulaye, Moundang, Moussei,
Massa), nonindigenous 150,000 (of whom 1,000 are
French)
Religions: Muslim 50%, Christian 25%, indigenous
beliefs (mostly animism) 25%
Languages: French (official), Arabic (official), Sara
and Sango (in south), more than 100 different
languages and dialects
Literacy:
definition: age 15 and over can read and write in
French or Arabic
total population: 48.1%
male: 62.1%
female: 34.7% (1995 est.)','115caeff01cc8c41f13faec4b37e1482b615063316f123a4604054456a576674','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('074e3a8ed8b3a17b112fea735a1bf5d72b0f5aefb1f1067aa56c09aa225ced55',1998,'CN','China','people-and-society',216,'Population: 1,236,914,658 (July 1998 est.)
Age structure:
0-14 years: 26% (male 169,347,516; female
149,897,253)
15-64 years : 68% (male 431 ,164,591 ; female
404,513,208)
65 years and over: 6% (male 38,398,920; female
43,593,170) (July 1998 est.)
Population growth rate: 0.83% (1998 est.)
Birth rate: 15.73 births/1,000 population (1998 est.)
Death rate: 6.99 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.41 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.15 male(s)/fema!e
under 15 years: 1.13 male(s)/female
15-64 years: 1 .07 male(s)/female
65 years and over: 0.88 ma!e(s)/female (1 998 est.)
Infant mortality rate: 45.46 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 69.59 years
male: 68.32 years
female: 71 .06 years (1998 est.)
Total fertility rate: 1 .8 children born/woman
(1998 est.)
Nationality:
noun: Chinese (singular and plural)
adjective : Chinese
Ethnic groups: Han Chinese 91.9%, Zhuang,
Uygur, Hui, Yi, Tibetan, Miao, Manchu, Mongol, Buyi,
Korean, and other nationalities 8.1%
Religions: Daoism (Taoism), Buddhism, Muslim
2%-3%, Christian 1% (est.)
note: officially atheist, but traditionally pragmatic and
eclectic
Languages: Standard Chinese or Mandarin
(Putonghua, based on the Beijing dialect), Yue
(Cantonese), Wu (Shanghaiese), Minbei (Fuzhou),
Minnan (Hokkien-Taiwanese), Xiang, Gan, Hakka
dialects, minority languages (see Ethnic divisions
entry)
Literacy:
definition: age 1 5 and over can read and write
total population: 81 .5%
male: 89.9%
female: 72.7% (1995 est.)','949a9a4b04abf1e5e4a2522acfb96b0ec215926f445ad4fc4de69cb48b95b4de','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f267d6d070a0768614839f96c2c986803c8cf8b6ca5f5fe570d9fec3d72801e9',1998,'CX','Christmas Island','people-and-society',224,'Population: 2,195 (July 1998 est.)
Age structure:
0-14 years: NA
15-64 years : NA
65 years and over: NA
Population growth rate: 7.77% (1998 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: N A
male: NA
female : NA
Total fertility rate: NA children born/woman
Nationality:
noun: Christmas Islander(s)
adjective: Christmas Island
Ethnic groups: Chinese 61%, Malay 25%,
European 11%, other 3%, no indigenous population
Religions: Buddhist 55%, Christian 15%, Muslim
10%, other 20% (1991)
Languages: English
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: tourism, phosphate extraction (near
depletion)
Industrial production growth rate: NA%
Electricity— capacity: NA kW
Electricity— production: NA kWh
Electricity— consumption per capita: NA kWh
Agriculture— products: NA
Exports: $NA
commodities: phosphate
partners: Australia, NZ
Imports: $NA
commodities: consumer goods
partners: principally Australia
Debt— external: $NA
Economic aid: none
Currency: 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1 —
1 .5281 (January 1 998), 1 .3439 (1 997), 1 .2773 (1 996),
1.3486 (1995), 1.3667 (1994), 1.4704, (1993)
Fiscal year: 1 July— 30 June','5d4d30977ef31659d29ed257b7a3e3895c98cd5e30d18aade9f1cb52b036ae97','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74c0315679816bf410c30100481da412fde9f10e65ab6f819379609a4c84f0f7',1998,'AU','Australia','people-and-society',231,'Population: uninhabited
Population: no indigenous inhabitants
note: there is a staff of three to four at the
meteorological station
Population: 860 (July 1998 est.)
Population growth rate: 1.15% (1998 est.)
Nationality:
noun: none
adjective : none
Ethnic groups: Italians, Swiss, other
Religions: Roman Catholic
Languages: Italian, Latin, various other languages
Population: uninhabited
note; American civilians evacuated in 1942 after
Japanese air and naval attacks during World War II;
occupied by US military during World War II, but
abandoned after the war; public entry is by
special-use permit only and generally restricted to
scientists and educators
Population: 66,561 (July 1998 est.)
Age structure:
0-14 years: 24% (male 8,110; female 7,869)
15-64 years : 74% (male 23,847; female 25,659)
65 years and over: 2% (male 518; female 558) (July
1998 est.)
Population growth rate: 4.2% (1998 est.)
Birth rate: 22.81 births/1 ,000 population (1998 est.)
Death rate: 2.28 deaths/1 ,000 population (1 998 est.)
Net migration rate: 21 .42 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .03 male(s)/fema!e
15-64 years: 0.92 male(s)/female
65 years and over: 0.93 male(s)/female (1998 est.)
Infant mortality rate: 6.53 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.82 years
male: 72.76 years
female: 79.08 years (1998 est.)
Total fertility rate: 1 .89 children born/woman (1 998
est.)
Nationality:
noun: NA
adjective: NA
Ethnic groups: Chamorro, Carolinians and other
Micronesians, Caucasian, Japanese, Chinese,
Korean
Religions: Christian (Roman Catholic majority,
although traditional beliefs and taboos may still be
found)
Languages: English, Chamorro, Carolinian
note: 86% of population speaks a language other than
English at home
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 97%
female: 96% (1 980 est.)','621e353fc4374dbbaca6c459b821cebdcf9a25624aeb04a7cd430778109861f2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('496166f36727eeec3c4dd7e3879f6646fa867f5bcdbb24d4ddd8eee9b90ae7c3',1998,'CO','Colombia','people-and-society',237,'Population: 38,580,949 (July 1998 est.)
Age structure:
0-14 years: 33% (male 6,474,927; female 6,321 ,404)
15-64 years: 62% (male 1 1 ,725,078; female
12,333,982)
65 years and over: 5% (male 780,486; female
945,072) (July 1998 est.)
Population growth rate: 1.89% (1998 est.)
Birth rate: 24.93 births/1,000 population (1998 est.)
Death rate: 5.69 deaths/1 ,000 population (1998 est.)
Net migration rate: -0.34 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.83 male(s)/female (1 998 est.)
Infant mortality rate: 25.44 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 70.06 years
male: 66.1 5 years
female: 74.1 1 years (1998 est.)
Total fertility rate: 2.9 children born/woman (1998
est.)
Nationality:
noun: Colombian(s)
adjective: Colombian
Ethnic groups: mestizo 58%, white 20%, mulatto
14%, black 4%, mixed black-Amerindian 3%,
Amerindian 1%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy:
definition: age 1 5 and over can read and write
total population: 91 .3%
male: 91. 2%
female: 91 .4% (1995 est.)
103
Colombia (continued)','81b7e3d122468d02c7fe8a318f6e11a1928b076b77bb349edf6d79c1e45436ae','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fa8cfc702642ee3fe83de23da7aecbd6150e304fac4a3b768b40dec3b69b845',1998,'MZ','Mozambique','people-and-society',247,'Population: 545,528 (July 1998 est.)
Age structure:
0-14 years: 43% (male 1 1 6,345; female 1 15,886)
15-64 years: 54% (male 146,655; female 150,612)
65 years and over: 3% (male 7,644; female 8,386)
(July 1998 est.)
Population growth rate: 3.1% (1998 est.)
Birth rate: 40.52 births/1,000 population (1998 est.)
Death rate: 9.52 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.91 male(s)/female (1998 est.)
Infant mortality rate: 84.54 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 60.36 years
male: 57.95 years
female: 62.84 years (1 998 est.)
Total fertility rate: 5.48 children born/woman
(1998 est.)
Nationality:
noun: Comoran(s)
adjective: Comoran
Ethnic groups: Antalote, Cafre, Makoa, Oimatsaha,
Sakalava
Religions: Sunni Muslim 86%, Roman Catholic 1 4%
Languages: Arabic (official), French (official),
Comoran (a blend of Swahili and Arabic)
Literacy:
definition: age 1 5 and over can read and write
total population: 57.3%
male: 64.2%
female: 50.4% (1995 est.)
f Government
Country name:
conventional long form: Federal Islamic Republic of
the Comoros
conventional short form: Comoros
local long form: Republique Federale Islamique des
Comores
local short form: Comores
Data code: CN
Government type: independent republic
National capital: Moroni
Administrative divisions: three islands; Grande
Comore (Njazidja), Anjouan (Nzwani), and Moheli
(Mwali)
note: there are also four municipalities named
Domoni, Fomboni, Moroni, and Mutsamudu
Independence: 6 July 1975 (from France)
National holiday: Independence Day, 6 July (1975)
Constitution: 20 October 1996
Legal system: French and Muslim law in a new
consolidated code
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Mohamed TAKI Abdulkarim
(since 16 March 1996)
head of government: Prime Minister Nourdine
BOURHANE (since 6 December 1 997)
cabinet: Council of Ministers appointed by the
president
elections: president elected by popular vote to a
five-year term; election last held 16 March 1996 (next
to be held NA March 2001); prime minister appointed
by the president
election results: Mohamed TAK! Abdulkarim elected
president; share of vote— 64%
Legislative branch: bicameral legislature consists
of the Senate (15 seats; members selected by
regional councils for six-year terms) and a Federal
Assembly or Assemblee Federale (43 seats;
members elected by popular vote to serve four-year
terms)
elections: last held 1 and 8 December 1996 (next to
be held NA December 2000)
election results: percent of vote by party— NA; seats
by party— RND 39, RND candidate running as
independent 1 , FNJ 3
Judicial branch: Supreme Court or CourSupremes,
two members are appointed by the president, two
members are elected by the Federal Assembly, one
by the Council of each island, and former presidents
of the republic
Political parties and leaders: Rassemblement
National pour le Development or RND [Mohamed
TAKI Abdulkarim], party of the government; Front
National pour la Justice or FNJ, Islamic party in
opposition
note: under a new constitution ratified in October
1996, a two party system was established; President
Mohamed TAKI Abdulkarim called for all parties to
dissolve and join him in creating the RND; the
constitution stipulates that only parties that win six
seats in the Federal Assembly (two from each island)
are permitted to be in opposition, but if no party
accomplishes that the second most successful party
will be in opposition; in the elections of December
1996 the FNJ appeared to qualify as opposition
International organization participation: ACCT,
ACP, AfDB, AFESD, AL, CCC, ECA, FAO, FZ, G-77 ,
IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF, InOC,
Intelsat (nonsignatory user), IOC, ITU, NAM, OAU,
OIC, UN, UNCTAD, UNESCO, UNIDO, UPU, WHO,
WMO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Ahmed DJABIR
(ambassador to the US and Canada and permanent
representative to the UN)
chancery: (temporary) care of the Permanent Mission
of the Federal and Islamic Republic of the Comoros to
the United Nations, 336 East 45th Street, 2nd Floor,
New York, NY 10017
telephone: [\\] (212) 972-8010
Diplomatic representation from the US: the US
does not have an embassy in Comoros; the
ambassador to Mauritius is accredited to Comoros
Flag description: green with a white crescent in the
center of the field, its points facing downward; there
are four white five-pointed stars placed in a line
between the points of the crescent; the crescent,
stars, and color green are traditional symbols of Islam;
the four stars represent the four main islands of the
archipelago— Mwali, Njazidja, Nzwani, and Mayotte (a
territorial collectivity of France, but claimed by
Comoros); the design, the most recent of several, is
described in the constitution approved by referendum
on 7 June 1992
Population: 49,000,511 (July 1998 est.)
Age structure:
0-14 years: 48% (male 1 1 ,829,386; female
11,766,829)
15-64 years: 49% (male 1 1 ,778,1 21 ; female
12,339,837)
65 years and over: 3% (male 557,095; female
729,243) (July 1998 est.)
Population growth rate: 2.99% (1998 est.)
Birth rate: 46.77 births/1 ,000 population (1998 est.)
Death rate: 1 5.2 deaths/1 ,000 population (1 998 est.)
Net migration rate: -1 .63 migrant(s)/1 ,000
population (1998 est.)
note: in 1994, about a million refugees fled into Zaire
(now called Democratic Republic of the Congo) to
escape the fighting between the Hutus and the Tutsis
in Rwanda and Burundi; the outbreak of widespread
fighting between rebels and government forces in
October 1996 spurred about 875,000 refugees to
return to Rwanda in late 1996 and early 1997;
additionally, Democratic Republic of the Congo is host
to about 200,000 Angolan, about 1 10,000 Burundi,
about 100,000 Sudanese, about 15,000 Ugandan,
and about 18,000 Republic of the Congo refugees
Sex ratio:
at birth: 1 .03 ma!e(s)/female
under 15 years: 1 ma!e(s)/female
15-64 years: 0.95 ma!e(s)/female
65 years and over: 0.76 male(s)/female (1998 est.)
Infant mortality rate: 101.6 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 49.31 years
male: 47 .27 years
female: 51 .4 years (1 998 est.)
Total fertility rate: 6.51 children born/woman (1998
est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: over 200 African ethnic groups of
which the majority are Bantu; the four largest tribes —
Mongo, Luba, Kongo (all Bantu), and the
Mangbetu-Azande (Hamitic) make up about 45% of
the population
Religions: Roman Catholic 50%, Protestant 20%,
Kimbanguist 10%, Muslim 10%, other syncretic sects
and traditional beliefs 10%
Languages: French (official), Lingala (a lingua
franca trade language), Kingwana (a dialect of
Kiswahili or Swahili), Kikongo, Tshiluba
Literacy:
definition: age 15 and over can read and write in
French, Lingala, Kingwana, or Tshiluba
total population: 77. 3%
male: 86.6%
female: 67.7% (1995 est.)
Population: 1 8,641 ,469 (July 1 998 est.)
Age structure:
0-14 years: 45% (male 4,1 29,779; female 4,232,091)
15-64 years: 53% (male 4,807,742; female
5,043,299)
65 years and over: 2% (male 177,895; female
250,663) (July 1998 est.)
Population growth rate: 2.57% (1998 est.)
Birth rate: 43.52 births/1,000 population (1998 est.)
Death rate: 17.81 deaths/1,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.97 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.7 male(s)/female (1 998 est.)
Infant mortality rate: 120.26 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 45.37 years
male: 44.22 years
female: 46.55 years (1998 est.)
Total fertility rate: 6 children born/woman (1998
est.)
Nationality:
noun: Mozambican(s)
adjective: Mozambican
Ethnic groups: indigenous tribal groups 99.66%
(Shangaan, Chokwe, Manyika, Sena, Makua, and
others), Europeans 0.06%, Euro-Africans 0.2%,
Indians 0.08%
Religions: indigenous beliefs 50%, Christian 30%,
325
Mozambique (continued)
Muslim 20%
Languages: Portuguese (official), indigenous
dialects
Literacy:
definition: age 15 and over can read and write
total population: 40.1%
male: 57.7%
female: 23.3% (1995 est.)
Population: 21,908,135 (July 1998 est.)
Age structure:
0-14 years: 22% (male 2,543,524; female 2,367,077)
15-64 years: 69% (male 7,730,185; female
7,472,525)
65 years and over: 9% (male 963,797; female
831,027) (July 1998 est.)
Population growth rate: 0.94% (1998 est.)
Birth rate: 1 4.79 births/1 ,000 population (1 998 est.)
Death rate: 5.42 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.02 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years : 1 .03 male(s)/female
65 years and over: 1.16 male(s)/female (1 998 est.)
Infant mortality rate: 6.34 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 76.82 years
male: 73.82 years
female : 80.05 years (1998 est.)
Total fertility rate: 1 .77 children born/woman (1998
est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Taiwanese (including Hakka) 84%,
mainland Chinese 14%, aborigine 2%
Religions: mixture of Buddhist, Confucian, and
Taoist 93%, Christian 4.5%, other 2.5%
Languages: Mandarin Chinese (official), Taiwanese
(Min), Hakka dialects
Literacy:
definition: age 15 and over can read and write
total population: 86%
male: 93%
female: 79% (1980 est.)
note: literacy for the total population increased to
92.65% in 1997','4702b1fe95dc529ab8627b7d9c47de0a638830e745ebe66c6866ca251ff0f0cf','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a98da2a5010ec7fcd209cf7a0633eb5504c40c00706c95f393daadec908f27d2',1998,'CG','Congo','people-and-society',260,'Population: 2,658,123 (July 1998 est.)
Age structure:
0-14 years: 43% (male 569,382; female 563,327)
15-64 years: 54% (male 700,507; female 734,447)
65 years and over: 3% (male 36,383; female 54,077)
(July 1998 est.)
Population growth rate: 2.21% (1998 est.)
Birth rate: 38.5 births/1 ,000 population (1 998 est.)
Death rate: 16.45 deaths/1 ,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/fema!e
15-64 years: 0.95 male(s)/female
65 years and over: 0.67 male(s)/female (1 998 est.)
Infant mortality rate: 102.69 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 47.07 years
male: 45.29 years
female : 48.89 years (1 998 est.)
Total fertility rate: 4.98 children born/woman
(1998 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: Kongo 48%, Sangha 20%, M''Bochi
12%, Teke 17%, Europeans NA%; note— Europeans
estimated at 8,500, mostly French, before the 1997
civil war; may be half of that in 1998, following the
widespread destruction of foreign businesses in 1997
Religions: Christian 50%, animist 48%, Muslim 2%
Languages: French (official), Lingala and
Monokutuba (lingua franca trade languages), many
local languages and dialects (of which Kikongo has
the most users)
Literacy:
definition: age 15 and over can read and write
total population: 74.9%
male:Q3A%
female: 67.2% (1995 est.)','47976d5115d73f1ea5a71d49f7740cb53cf6359702b6d8587818eae68853278b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9e77a7aa07bef37d4b67b370e8d8ff83fbef06ae753d762f4c9a7f6c05c54fb',1998,'CK','Cook Islands','people-and-society',263,'Population: 19,989 (July 1998 est.)
Age structure:
0- 74 years: N A
15-64 years: NA
65 years and over: NA
Population growth rate: 1 .06% (1 998 est.)
Birth rate: 22.52 births/1,000 population (1998 est.)
Death rate: 5.2 deaths/1,000 population (1998 est.)
Net migration rate: -6.71 migrant(s)/1 ,000
population (1998 est.)
Infant mortality rate: 24.7 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 71 .1 4 years
male: 69.2 years
female: 73.1 years (1998 est.)
Total fertility rate: 3.19 children born/woman
(1998 est.)
Nationality:
noun: Cook Islander(s)
adjective: Cook Islander
Ethnic groups: Polynesian (full blood) 81 .3%,
Polynesian and European 7.7%, Polynesian and
non-European 7.7%, European 2.4%, other 0.9%
Religions: Christian (majority of populace are
members of the Cook Islands Christian Church)
Languages: English (official), Maori
Literacy: NA
Population: uninhabited
note: Millersville settlement on western side of island
occasionally used as a weather station from 1 935 until
World War II, when it was abandoned; reoccupied in
1957 during the International Geophysical Year by
scientists who left in 1958; public entry is by
special-use permit only and generally restricted to
scientists and educators','466d096af3bd4a1965d6c72e789324b5bdd06ee86a8613fa3cfb0f3b08aeb71c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab8f7a19039c1d550007420210344321193182c0534f90bcb83c37cc3f3ec9e2',1998,'CR','Costa Rica','people-and-society',271,'Population: 3,604,642 (July 1998 est.)
Age structure:
0-14 years: 34% (male 620,496; female 591 ,299)
15-64 years: 61 % (male 1,120,118; female
1,093,099)
65 years and over: 5% (male 82,893; female 96,737)
(July 1998 est.)
Population growth rate: 1 .95% (1 998 est.)
Birth rate: 22.89 births/1 ,000 population (1998 est.)
Death rate: 4.1 5 deaths/1 ,000 population (1998 est.)
Net migration rate: 0.72 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.02 ma!e(s)/female
65 years and over: 0.86 male(s)/female (1998 est.)
Infant mortality rate: 13.1 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.93 years
male: 73.5 years
female: 78.48 years (1998 est.)
Total fertility rate: 2.81 children born/woman (1998
est.)
Nationality:
noun: Costa Rican(s)
adjective : Costa Rican
Ethnic groups: white (including mestizo) 96%, black
2%, Amerindian 1%, Chinese 1%
Religions: Roman Catholic 95%
Languages: Spanish (official), English spoken
around Puerto Limon
Literacy:
definition: age 1 5 and over can read and write
total population: 94.8%
male: 94.7%
female: 95% (1995 est.)','5989a7b6ffabe4542c4976f8b0a09f0991d9c6ad024e425e1c3fa78206fa92c9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecb118e28a19d881afcbb6dc0548c4f84b8ad66f9e1c2d46f7ea8d1513ebc92a',1998,'MX','Mexico','people-and-society',281,'Population: 15,446,231 (July 1998 est.)
Age structure:
0-14 years: 47% (male 3,629,286; female 3,590,782)
15-64 years: 51% (male 4,049,355; female
3,842,508)
65 years and over: 2% (male 1 70,1 20; female
164,180) (July 1998 est.)
Population growth rate: 2.41% (1998 est.)
Birth rate: 42.15 births/1,000 population (1998 est.)
Death rate: 16.12 deaths/1 ,000 population (1998
est.)
Net migration rate: -1 .96 migrant(s)/1 ,000
population (1998 est.)
note: of the more than 350,000 refugees that fled to
Cote d''Ivoire since 1989 to escape the civil war in
Liberia, only about 21 0,000 remained in Cote d’Ivoire
according to a 1997 census
Sex ratio:
at birth: 1.03 male($)/female
under 15 years: 1.01 ma!e(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 1 .03 male(s)/femaie (1 998 est.)
Infant mortality rate: 95.95 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population : 46.24 years
male: 44.73 years
female: 47.8 years (1998 est.)
Total fertility rate: 5.97 children born/woman (1998
est.)
Nationality:
noun: Ivorian(s)
adjective: Ivorian
Ethnic groups: Baoule 23%, Bete 18%, Senoufou
15%, Malinke 11%, Agni, foreign Africans (mostly
Burkinabe and Malians, about 3 million), non-Africans
130,000 to 330,000 (French 30,000 and Lebanese
100,000 to 300,000)
Religions: Muslim 60%, Christian 12%, indigenous
25% (some of these are also numbered among the
Christians and Muslims)
Languages: French (official), 60 native dialects with
Dioula the most widely spoken
Literacy:
definition: age 15 and over can read and write
total population: 40A%
male: 49.9%
fema/e; 30% (1995 est.)
Population: 20,932,901 (July 1998 est.)
Age structure:
0-14 years: 36% (male 3,832,040; female 3,635,136)
1 5-64 years: 60% (male 6,314,693; female
6,324,389)
65 years and over: 4% (male 359,006; female
467,637) (July 1998 est.)
Population growth rate: 2. 11% (1998 est.)
Birth rate: 26.5 births/1 ,000 population (1 998 est.)
Death rate: 5.36 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .06 ma!e(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.77 male(s)/female (1998 est.)
Infant mortality rate: 22.45 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 70.36 years
male: 67.35 years
female: 73.56 years (1998 est.)
Total fertility rate: 3.37 children born/woman (1 998
est.)
Nationality:
noun: Malaysian(s)
adjective: Malaysian
Ethnic groups: Malay and other indigenous 58%,
Chinese 26%, Indian 7%, others 9%
Religions: Peninsular Malaysia— Muslim (Malays),
Buddhist (Chinese), Hindu (Indians); Sabah— Muslim
38%, Christian 17%, other 45%; Sarawak— tribal
religion 35%, Buddhist and Confucianist 24%, Muslim
20%, Christian 16%, other 5%
Languages: Peninsular Malaysia— Malay (official),
English, Chinese dialects, Tamil; Sabah— English,
Malay, numerous tribal dialects, Chinese (Mandarin
and Hakka dialects predominate); Sarawak— English,
Malay, Mandarin, numerous tribal languages
Literacy:
definition: age 1 5 and over can read and write
total population: 83.5%
male: 89.1%
female: 78.1% (1995 est.)
Population: 98,552,776 (July 1998 est.)
Age structure:
0-14 years: 36% (male 17,883,007; female
17,193,082)
15-64 years: 60% (male 28,932,074; female
30,511,443)
65 years and over: 4% (male 1 ,808,581 ; female
2,224,589) (July 1998 est.)
Population growth rate: 1.77% (1998 est.)
Birth rate: 25.49 births/1 ,000 population (1 998 est.)
Death rate: 4.91 deaths/1 ,000 population (1 998 est.)
Net migration rate: -2.89 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.81 male(s)/female (1 998 est.)
Infant mortality rate: 25.82 deaths/1 ,000 live births
(1998 est.)
310
Life expectancy at birth:
total population: 71 .63 years
male: 68.62 years
female: 74.79 years (1998 est.)
Total fertility rate: 2.91 children born/woman (1998
est.)
Nationality:
noun: Mexican(s)
adjective: Mexican
Ethnic groups: mestizo (Amerindian-Spanish) 60%,
Amerindian or predominantly Amerindian 30%, white
9%, other 1%
Religions: nominally Roman Catholic 89%,
Protestant 6%
Languages: Spanish, various Mayan, Nahuatl, and
other regional indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 89.6%
male: 91 .8%
female: 87.4% (1995 est.)
Population: 4,419,955 (July 1998 est.)
Age structure:
0-14 years: 20% (male 444,373; female 420,940)
15-64 years: 65% (male 1 ,454,733; female
1,407,395)
65 years and over: 1 5% (male 288,056; female
404,458) (July 1998 est.)
Population growth rate: 0.44% (1 998 est.)
Birth rate: 12.9 births/1 ,000 population (1998 est.)
Death rate: 10.17 deaths/1,000 population (1998
est.)
Net migration rate: 1 .64 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.06 male(s)/fema!e
15-64 years: 1 .03 male(s)/female
65 years and over: 0.71 male(s)/female (1998 est.)
Infant mortality rate: 5.01 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.23 years
male: 75.42 years
female: 81.21 years (1998 est.)
Total fertility rate: 1 .8 children born/woman (1 998
est.)
Nationality:
noun: Norwegian(s)
adjective: Norwegian
Ethnic groups: Germanic (Nordic, Alpine, Baltic),
Lapps (Sami) 20,000
Religions: Evangelical Lutheran 87.8% (state
church), other Protestant and Roman Catholic 3.8%,
none 3.2%, unknown 5.2% (1980)
Languages: Norwegian (official)
note: small Lapp- and Finnish-speaking minorities
Literacy:
definition: age 15 and over can read and write
total population: 99% (1 976 est.)
male: NA%
female: NA%
Population: 38,606,922 (July 1998 est.)
Age structure:
0-14 years: 21% (male 4,075,959; female 3,883,778)
15-64 years: 68% (male 12,956,689; female
13,129,495)
65 years and over: 1 1 % (male 1 ,732,788; female
2,828,213) (July 1998 est.)
Population growth rate: -0.04% (1998 est.)
Birth rate: 9.79 births/1,000 population (1998 est.)
Death rate: 9.76 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.4 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/fema!e
under 15 years: 1 .04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.61 male(s)/female (1 998 est.)
Infant mortality rate: 13.18 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 72.77 years
male: 68.6 years
female: 77.1 6 years (1 998 est.)
Total fertility rate: 1 .36 children born/woman (1998
est.)
Nationality:
noun: Pole(s)
adjective: Polish
Ethnic groups: Polish 97.6%, German 1.3%,
Ukrainian 0.6%, Byelorussian 0.5% (1990 est.)
Religions: Roman Catholic 95% (about 75%
practicing), Eastern Orthodox, Protestant, and other
5%
Languages: Polish
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 98% (1978 est.)
Population: 9,927,556 (July 1998 est.)
Age structure:
0-14 years: 17% (male 881 ,091 ; female 834,775)
15-64 years: 68% (male 3,283,273; female
3,429,233)
65 years and over: 15% (male 612,221; female
886,963) (July 1998 est.)
Population growth rate: -0.07% (1998 est.)
Birth rate: 1 0.63 births/1 ,000 population (1 998 est.)
Death rate: 1 0.26 deaths/1 ,000 population (1 998
est.)
Net migration rate: -1.01 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/femaie
under 15 years: 1.06 male(s)/female
15-64 years: 0.96 ma!e(s)/female
65 years and over: 0.69 male(s)/female (1 998 est.)
Infant mortality rate: 6.87 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.66 years
male: 72.27 years
female: 79.25 years (1998 est.)
Total fertility rate: 1 .35 children born/woman (1 998
est.)
Nationality:
noun: Portuguese (singular and plural)
adjective: Portuguese
Ethnic groups: homogeneous Mediterranean stock
in mainland, Azores, Madeira Islands; citizens of black
African descent who immigrated to mainland during
decolonization number less than 100,000
Religions: Roman Catholic 97%, Protestant
denominations 1%, other 2%
Languages: Portuguese
Literacy:
definition: age 15 and over can read and write
total population: 85%
male: 89%
female: 82% (1 990 est.)
Population: 76,236,259 (July 1998 est.)
Age structure:
0-14 years: 35% (male 13,570,312; female
12,796,687)
15-64 years: 60% (male 22,222,286; female
23,621,122)
65 years and over: 5% (male 1 ,61 3,1 03; female
2,412,749) (July 1998 est.)
Population growth rate: 1 .43% (1 998 est.)
Birth rate: 21.55 births/1,000 population (1998 est.)
Death rate: 6.69 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.54 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/femaie
15-64 years: 0.94 male(s)/female
65 years and over: 0.67 male(s)/female (1 998 est.)
Infant mortality rate: 36.02 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 67.74 years
male: 65.37 years
female: 70.25 years (1998 est.)
Total fertility rate: 2.5 children born/woman (1998
est.)
Nationality:
noun: Vietnamese (singular and plural)
adjective: Vietnamese
Ethnic groups: Vietnamese 85%-90%, Chinese 3%,
Muong, Tai, Meo, Khmer, Man, Cham
Religions: Buddhist, Taoist, Roman Catholic,
indigenous beliefs, Islam, Protestant, Cao Dai, Hoa
Hao
Languages: Vietnamese (official), Chinese, English,
French, Khmer, tribal languages (Mon-Khmer and
Malayo-Polynesian)
Literacy:
definition: age 15 and over can read and write
total population: 93.7%
male: 96.5%
female: 91 .2% (1995 est.)','295b5f120f8f379afc017a46f1d8e508369381e5ebfc5e96ad0aa2b9d5c9f582','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2042162333eb2242fb9a65b3eaa213285535e3b407e37dc4a00e4c864eb428ca',1998,'SI','Slovenia','people-and-society',285,'Population: 4,671,584 (July 1998 est.)
Age structure:
0-14 years: 17% (male 41 1 ,022; female 389,354)
15-64 years: 68% (male 1 ,591 ,71 6; female
1,592,485)
65 years and over: 1 5% (male 262,471 ; female
424,536) (July 1998 est.)
Population growth rate: 0.13% (1998 est.)
Birth rate: 1 0.45 births/1 ,000 population (1 998 est.)
Death rate: 11.14 deaths/1,000 population (1998
est.)
Net migration rate: 1 .94 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .05 male(s)/fema!e
15-64 years: 0.99 male(s)/female
65 years and over: 0.61 male(s)/female (1 998 est.)
Infant mortality rate: 8 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population : 73.75 years
male: 70.43 years
female: 77.28 years (1 998 est.)
Total fertility rate: 1 .54 children born/woman (1 998
est.)
Nationality:
noun: Croat(s)
adjective: Croatian
Ethnic groups: Croat 78%, Serb 12%, Muslim 0.9%,
Hungarian 0.5%, Slovenian 0.5%, others 8.1 % (1 991 )
Religions: Catholic 76.5%, Orthodox 11.1%, Slavic
Muslim 1 .2%, Protestant 0.4%, others and unknown
10.8%
Languages: Serbo-Croatian 96%, other 4%
(including Italian, Hungarian, Czechoslovak, and
German)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 95% (1991 est.)','9e20219959c62fdfadc723b55ddbfff9499ff57c4f539d60226b40f78154e1bd','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd51904f1d227fff1da26bfed243d930b30d77713b7486f844e466f9bb7df40a',1998,'CU','Cuba','people-and-society',293,'Population: 11,050,729 (July 1998 est.)
Age structure:
0-14 years: 22% (male 1,247,339; female 1,182,612)
15-64 years: 69% (male 3,795,310; female
3,777,454)
65 years and over: 9% (male 490,883; female
557,131) (July 1998 est.)
Population growth rate: 0.42% (1998 est.)
Birth rate: 13.13 births/1,000 population (1998 est.)
Death rate: 7.35 deaths/1 ,000 population (1 998 est.)
Net migration rate: -1 .53 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.88 male(s)/female (1 998 est.)
Infant mortality rate: 7.89 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.64 years
male: 73.29 years
female: 78.1 3 years (1998 est.)
Total fertility rate: 1 .57 children born/woman (1 998
est.)
121
Cuba (continued)
Nationality:
noun: Cuban(s)
adjective: Cuban
Ethnic groups: mulatto 51%, white 37%, black 1 1 %,
Chinese 1%
Religions: nominally Roman Catholic 85% prior to
CASTRO assuming power; Protestants, Jehovah''s
Witnesses, Jews, and Santeria are also represented
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 95.7%
male: 96.2%
female: 95.3% (1995 est.)','e49b024bc902eae9390d9742330526f4303d8a4ce955a116b76838d2640a8981','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77134d63161d085d0896ad33f62f85435c58d5353b2a9b300e07e8baeed55b83',1998,'CY','Cyprus','people-and-society',301,'Population: 748,982 (July 1998 est.)
Age structure:
0-14 years: 25% (male 94,006; female 89,256)
15-64 years : 65% (male 245,739; female 241 ,935)
65 years and over: 10% (male 33,989; female
44,057) (July 1998 est.)
Population growth rate: 0.69% (1998 est.)
Birth rate: 1 3.93 births/1 ,000 population (1 998 est.)
Death rate: 7.51 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0.44 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .02 ma!e(s)/female
65 years and over: 0.77 male(s)/female (1998 est.)
Infant mortality rate: 7.97 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 76.79 years
male: 74.62 years
female: 79.07 years (1998 est.)
Total fertility rate: 2.03 children born/woman (1998
est.)
Nationality:
noun: Cypriot(s)
adjective: Cypriot
Ethnic groups: Greek 78% (99.5% of the Greeks
live in the Greek Cypriot area; 0.5% of the Greeks live
in the T urkish Cypriot area), Turkish 1 8% (1 .3% of the
Turks live in the Greek Cypriot area; 98.7% of the
Turks live in the Turkish Cypriot area), other 4%
(99.2% of the other ethnic groups live in the Greek
Cypriot area; 0.8% of the other ethnic groups live in
the Turkish Cypriot area)
Religions: Greek Orthodox 78%, Muslim 18%,
Maronite, Armenian Apostolic, and other 4%
Languages: Greek, Turkish, English
Literacy:
definition: age 15 and over can read and write
total population: 94%
male: 98%
female: 91% (1987 est.)
Population: 10,286,470 (July 1998 est.)
Age structure:
0-14 years: 17% (male 907,744; female 864,202)
15-64 years: 69% (male 3,555,822; female
3,548,548)
65 years and over: 14% (male 541 ,031 ; female
869,123) (July 1998 est.)
Population growth rate: -0.1 1% (1998 est.)
Birth rate: 8.96 births/1,000 population (1998 est.)
Death rate: 10.92 deaths/1 ,000 population (1998
est.)
Net migration rate: 0.92 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.62 male(s)/fema!e (1 998 est.)
Infant mortality rate: 6.79 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 74.1 1 years
male: 70.75 years
female: 77.65 years (1998 est.)
Total fertility rate: 1.17 children born/woman (1998
est.)
Nationality:
noun: Czech(s)
adjective: Czech
note: 300,000 Slovaks declared themselves Czech
citizens in 1994
Ethnic groups: Czech 94.4%, Slovak 3%, Polish
0.6%, German 0.5%, Gypsy 0.3%, Hungarian 0.2%,
other 1%
Religions: atheist 39.8%, Roman Catholic 39.2%,
Protestant 4.6%, Orthodox 3%, other 13.4%
Languages: Czech, Slovak
Literacy:
definition: age NA and over can read and write
total population: 99% (est.)
male: NA%
female: NA%','71a75e6c3d7392d5aa4acd906e4626424950595f8d3f0015d39ae7099cfe9cf0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7eac2acf92c66b4dd643d838899a76bd98df6ad000400387ec5841a7ec75c922',1998,'DK','Denmark','people-and-society',309,'Population: 5,333,617 (July 1998 est.)
Age structure:
0-1 4 years: 18% (male 496,886; female 471,891)
15-64 years: 67% (male 1 ,807,384; female
1,760,353)
65 years and over: 1 5% (male 330,385; female
466,718) (July 1998 est.)
Population growth rate: 0.49% (1998 est.)
Birth rate: 12.18 births/1,000 population (1998 est.)
Death rate: 1 1 .08 deaths/1 ,000 population (1 998
est.)
Net migration rate: 3.77 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.71 male(s)/female (1 998 est.)
Infant mortality rate: 5.17 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 76.31 years
male: 73.64 years
female: 79.12 years (1998 est.)
Total fertility rate: 1 .68 children born/woman (1998
est.)
Nationality:
noun: Dane(s)
adjective: Danish
Ethnic groups: Scandinavian, Eskimo, Faroese,
German
Religions: Evangelical Lutheran 91%, other
Protestant and Roman Catholic 2%, other 7% (1988)
Languages: Danish, Faroese, Greenlandic (an
Eskimo dialect), German (small minority)
129
Denmark (continued)
Literacy:
definition: age 15 and over can read and write
total population: 99% (1 980 est.)
male: NA%
female: NA%
Population: 440,727 (July 1998 est.)
Age structure:
0-14 years: 43% (male 94,399; female 94,154)
15-64 years: 55% (male 127,190; female 113,582)
65 years and over: 2% (male 5,877; female 5,525)
(July 1998 est.)
Population growth rate: 1.51% (1998 est.)
Birth rate: 41 .75 births/1 ,000 population (1998 est.)
Death rate: 1 4.69 deaths/1 ,000 population (1 998
est.)
Net migration rate: -11.91 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 1 .06 male(s)/female (1 998 est.)
Infant mortality rate: 1 02.4 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 51 .07 years
male: 49.06 years
female: 53.15 years (1998 est.)
Total fertility rate: 5.94 children born/woman (1998
est.)
Nationality:
noun: Djiboutian(s)
adjective: Djiboutian
Ethnic groups: Somali 60%, Afar 35%, French,
Arab, Ethiopian, and Italian 5%
Religions: Muslim 94%, Christian 6%
Languages: French (official), Arabic (official),
Somali, Afar
Literacy:
definition: age 15 and over can read and write
total population: 46.2%
male: 60.3%
female: 32.7% (1995 est.)','e126ed4e80a8042912d301e91063034a0156d5b4fbb80a51bba133407a46b382','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad699635033b2843153ad01b19f006759344f09374fc3f8ddeed7f8260918cf6',1998,'DM','Dominica','people-and-society',317,'Population; 65,777 (July 1998 est.)
Age structure:
0-14 years: 27% (male 8,987; female 8,826)
15-64 years: 63% (male 21 ,231 ; female 20,464)
65 years and over: 1 0% (male 2,572; female 3,697)
(July 1998 est.)
Population growth rate: -1 .33% (1 998 est.)
Birth rate: 17.35 births/1 ,000 population (1998 est.)
Death rate: 6.29 deaths/1 ,000 population (1 998 est.)
Net migration rate: -24.36 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 .04 ma!e(s)/fema!e
65 years and over: 0.7 male(s)/female (1998 est.)
Infant mortality rate: 9.04 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 77.8 years
male: 74.94 years
female: 80.8 years (1998 est.)
Total fertility rate: 1 .9 children born/woman (1 998
est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: black, Carib Amerindian
Religions: Roman Catholic 77%, Protestant 15%
(Methodist 5%, Pentecostal 3%, Seventh-Day
Adventist 3%, Baptist 2%, other 2%), none 2%,
unknown 1%, other 5%
Languages: English (official), French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 94%
male: 94%
female: 94% (1970 est.)
Population: 7,998,766 (July 1998 est.)
Age structure:
0-14 years: 35% (male 1,435,698; female 1 ,382,377)
15-64 years: 60% (male 2,452,310; female
2,379,991)
65 years and over: 5% (male 1 65,602; female
182,788) (July 1998 est.)
Population growth rate: 1.63% (1998 est.)
Birth rate: 26.42 births/1 ,000 population (1998 est.)
Death rate: 5.73 deaths/1 ,000 population (1 998 est.)
Net migration rate: -4.37 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.91 male(s)/female (1998 est.)
Infant mortality rate: 44.26 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 69.73 years
male: 67.53 years
female: 72.04 years (1998 est.)
Total fertility rate: 3.06 children born/woman (1998
est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: white 16%, black 11%, mixed 73%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 82. 1 %
male: 82%
female: 82.2% (1995 est.)
Gov e r n m e n t
Country name:
conventional long form: Dominican Republic
conventional short form: none
local long form: Republica Dominicana
local short form: none
Data code: DR
Government type: republic
National capital: Santo Domingo
Administrative divisions: 29 provinces (provincias,
135
Dominican Republic (continued)
singular— provincia) and 1 district* (distrito); Azua,
Baoruco, Barahona, Dajabon, Distrito National*,
Duarte, Elias Pina, El Seibo, Espailiat, Hato Mayor,
independencia, La Altagracia, La Romana, La Vega,
Maria Trinidad Sanchez, Monsenor Nouel, Monte
Cristi, Monte Plata, Pedernales, Peravia, Puerto
Plata, Salcedo, Samana, Sanchez Ramirez, San
Cristobal, San Juan, San Pedro de Macoris, Santiago,
Santiago Rodriguez, Valverde
Independence: 27 February 1844 (from Haiti)
National holiday: Independence Day, 27 February
(1844)
Constitution: 28 November 1966
Legal system: based on French civil codes
Suffrage: 1 8 years of age, universal and
compulsory; married persons regardless of age
note: members of the armed forces and police cannot
vote
Executive branch:
chief of state: President Leonel FERNANDEZ Reyna
(since 16 August 1996); Vice President Jaime David
FERNANDEZ Mirabal (since 16 August 1996); note-
the president is both the chief of state and head of','3ad13a97097679edf66e71e6bdcc25adf7c365551898d30de4bea0c8847c9b9f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81e3ea38ced7ff658385fea6efe652a90027e1eae265f666e1545e5fe792e494',1998,'PE','Peru','people-and-society',325,'Population: 12,336,572 (July 1998 est.)
Age structure:
0-14 years: 36% (male 2,253,920; female 2,175,402)
15-64 years: 60% (male 3,636,637; female
3,725,766)
65 years and over: 4% (male 254,432; female
290,415) (July 1998 est.)
Population growth rate: 1.86% (1998 est.)
Birth rate: 23.16 births/1,000 population (1998 est.)
Death rate: 5.17 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0.56 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/fema!e
15-64 years: 0.98 male(s)/female
65 years and over: 0.88 male(s)/female (1 998 est.)
Infant mortality rate: 32.07 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 71 .8 years
male: 69.19 years
female: 74.54 years (1998 est.)
Total fertility rate: 2.75 children born/woman (1998
est.)
Nationality:
noun: Ecuadorian(s)
adjective: Ecuadorian
Ethnic groups: mestizo (mixed Amerindian and
Spanish) 55%, Amerindian 25%, Spanish 10%, black
10%
Religions: Roman Catholic 95%
Languages: Spanish (official), Amerindian
languages (especially Quechua)
Literacy:
definition: age 1 5 and over can read and write
total population: 90. 1 %
male: 92%
female: 88.2% (1995 est.)','e4034e135c81669e3309c9a3eb3b7b64b5f6a0caf923e122056eb5242a39e153','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d81481bd983c3a2e60a65433f0b9cd434aad7ef8f68dae3cf8ee9c609c58b957',1998,'SD','Sudan','people-and-society',334,'Population: 66,050,004 (July 1998 est.)
Age structure:
0-14 years: 36% (male 12,173,882; female
11,637,239)
15-64 years: 60% (male 20,108,426; female
19,718,302)
65 years and over: 4% (male 1 ,074,271 ; female
1,337,884) (July 1998 est.)
Population growth rate: 1 .86% (1 998 est.)
Birthrate: 27.31 births/1 ,000 population (1998 est.)
Death rate: 8.41 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.35 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1 .05 male(s)/female
15-64 years : 1 .02 male(s)/female
65 years and over: 0.8 male(s)/female (1 998 est.)
Infant mortality rate: 69.23 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 62.07 years
male: 60.09 years
female: 64.14 years (1998 est.)
Total fertility rate: 3.41 children born/woman (1998
est.)
Nationality:
noun: Egyptian(s)
adjective: Egyptian
Ethnic groups: Eastern Hamitic stock (Egyptians,
Bedouins, and Berbers) 99%, Greek, Nubian,
Armenian, other European (primarily Italian and
French) 1%
Religions: Muslim (mostly Sunni) 94% (official
estimate), Coptic Christian and other 6% (official
estimate)
Languages: Arabic (official), English and French
widely understood by educated classes
Literacy:
definition: age 1 5 and over can read and write
total population: 51 .4%
male: 63.6%
female: 38.8% (1995 est.)
Population: 33,550,552 (July 1998 est.)
Age structure:
0-14 years: 45% (male 7,769,266; female 7,449,510)
15-64 years: 52% (male 8,81 8,01 8; female
8,778,485)
65 years and over: 3% (male 410,170; female
325,103) (July 1998 est.)
Population growth rate: 2.73% (1998 est.)
Birth rate: 39.94 births/1 ,000 population (1998 est.)
Death rate: 10.88 deaths/1,000 population (1998
est.)
Net migration rate: -1 .73 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 ma!e(s)/female
65 years and over: 1 .26 male(s)/female (1 998 est.)
Infant mortality rate: 72.64 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 55.97 years
male: 55 years
female: 56.98 years (1998 est.)
Total fertility rate: 5.68 children born/woman (1 998
est.)
Nationality:
noun: Sudanese (singular and plural)
adjective: Sudanese
Ethnic groups: black 52%, Arab 39%, Beja 6%,
foreigners 2%, other 1%
Religions: Sunni Muslim 70% (in north), indigenous
beliefs 25%, Christian 5% (mostly in south and
Khartoum)
Languages: Arabic (official), Nubian, Ta Bedawie,
diverse dialects of Nilotic, Nilo-Hamitic, Sudanic
languages, English
note: program of Arabization in process
Literacy:
definition: age 15 and over can read and write
total population: 46. 1 %
male: 57.7%
female: 34.6% (1995 est.)
439
Sudan (continued)','130093cd11aedacf15f575559239efb6940ea50d28ebaa8e575ac69111300c42','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f810762a5dbe757efcb1b6b6d0e2b8c5e9360e7c869d8861e0ad2707f6fed5d2',1998,'SV','El Salvador','people-and-society',342,'Population: 5,752,067 (July 1998 est.)
Age structure:
0-14 years: 37% (male 1 ,088,579; female 1 ,042,087)
15-64 years: 58% (male 1 ,575,806; female
1,748,250)
65 years and over: 5% (male 135,556; female
161,789) (July 1998 est.)
Population growth rate: 1.57% (1998 est.)
Birth rate: 26.71 births/1,000 population (1998 est.)
Death rate: 6.32 deaths/1 ,000 population (1 998 est.)
Net migration rate: -4.73 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/fema!e
under 15 years: 1 .04 male(s)/female
15-64 years: 0.9 male(s)/fema!e
65 years and over: 0.84 male(s)/female (1998 est.)
Infant mortality rate: 29.07 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 69.66 years
male: 66.31 years
female: 73.17 years (1998 est.)
Total fertility rate: 3.06 children born/woman (1998
est.)
Nationality:
noun: Salvadoran(s)
adjective: Salvadoran
Ethnic groups: mestizo 94%, Amerindian 5%, white
1%
Religions: Roman Catholic 75%
note: there is extensive activity by Protestant groups
throughout the country; by the end of 1 992, there were
an estimated 1 million Protestant evangelicals in El
Salvador
Languages: Spanish, Nahua (among some
Amerindians)
Literacy:
definition: age 15 and over can read and write
total population: 71.5%
male: 73.5%
female: 69.8% (1995 est.)','6de209ce37008fc70cda003061fe433c8a69515b025d4ac9c1763a8b1dd8770b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20a7b0143b205e3b691c89492a4d128367e9d7bb4377d514e7e81def9a44c265',1998,'GQ','Equatorial Guinea','people-and-society',346,'Population: 454,001 (July 1998 est.)
Age structure:
0-14 years: 43% (male 97,993; female 97,470)
15-64 years: 53% (male 1 14,960; female 126,453)
65 years and over: 4% (male 7,597; female 9,528)
(July 1998 est.)
Population growth rate: 2.56% (1998 est.)
Birth rate: 38.9 births/1 ,000 population (1998 est.)
Death rate: 13.32 deaths/1,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.79 male(s)/female (1 998 est.)
Infant mortality rate: 93.45 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 53.93 years
male: 51.61 years
female: 56.31 years (1998 est.)
Total fertility rate: 5.06 children born/woman (1998
est.)
Nationality:
noun: Equatorial Guinean(s) or Equatoguinean(s)
adjective: Equatorial Guinean or Equatoguinean
Ethnic groups: Bioko (primarily Bubi, some
Fernandinos), Rio Muni (primarily Fang), Europeans
less than 1,000, mostly Spanish
Religions: nominally Christian and predominantly
Roman Catholic, pagan practices
Languages: Spanish (official), French (official),
pidgin English, Fang, Bubi, Ibo
Literacy:
definition: age 1 5 and over can read and write
total population: 78.5%
male: 89.6%
female: 68.1% (1995 est.)','b305576de5248eeb82483adbcefe2afad1b383c663e3c3ea66a3e69624449b9e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6b0ad2446bbea20182ee3f2b53392cf3c261da3c596dfecbe046f65c16b1283',1998,'GN','Guinea','people-and-society',354,'Population: 3,842,436 (July 1998 est.)
Age structure:
0-14 years: 43% (male 826,686; female 818,323)
15-64 years: 54% (male 1 ,026,922; female
1,042,156)
65 years and over: 3% (male 66,222; female 62,127)
(July 1998 est.)
Population growth rate: 3.39% (1998 est.)
Birth rate: 42.52 births/1,000 population (1998 est.)
Death rate: 12.57 deaths/1 ,000 population (1998
est.)
Net migration rate: 3.9 migrant(s)/1 ,000 population
(1998 est.)
note: it is estimated that between 200,000 and
350,000 Eritrean refugees were still living in Sudan in
mid-1997
Sex ratio:
at birth : 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1.06 male(s)/female (1998 est.)
Infant mortality rate: 78.51 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 55.31 years
male: 53.19 years
female: 57.51 years (1998 est.)
Total fertility rate: 5.99 children born/woman (1998
est.)
Nationality:
noun: Eritrean(s)
adjective: Eritrean
Ethnic groups: ethnic Tigrinya 50%, Tigre and
Kunama 40%, Afar 4%, Saho (Red Sea coast
dwellers) 3%
147
Eritrea (continued)
Religions: Muslim, Coptic Christian, Roman
Catholic, Protestant
Languages: Afar, Amharic, Arabic, Tigre and
Kunama, Tigrinya, minor ethnic group languages
Literacy: NA','e22bbbdec7ca0981fc8c876475780b94a1071cd9b3ed80392beba744258174f0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9972b2f19384c89a8e4d40ed777accc53b0c6c18fd9e7c9914b3ae081610bc22',1998,'EE','Estonia','people-and-society',356,'Population: 1 ,421 ,335 (July 1 998 est.)
Age structure:
0-14 years: 19% (male 136,278; female 131,480)
15-64 years: 67% (male 456,796; female 492,946)
65 years and over: 14% (male 66,261 ; female
137,574) (July 1998 est.)
Population growth rate: -0.99% (1998 est.)
Birth rate: 9.04 births/1,000 population (1998 est.)
Death rate: 14.15 deaths/1,000 population (1998
est.)
Net migration rate: -4.76 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.48 ma!e(s)/female (1998 est.)
Infant mortality rate: 1 3.98 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 68.52 years
male: 62.5 years
female: 74.83 years (1998 est.)
Total fertility rate: 1 .29 children born/woman (1 998
est.)
Nationality:
noun: Estonian(s)
adjective: Estonian
Ethnic groups: Estonian 64.2%, Russian 28.7%,
Ukrainian 2.7%, Byelorussian 1.5%, Finn 1%, other
1.9% (1995)
Religions: Evangelical Lutheran, Russian Orthodox,
Estonian Orthodox, others include Baptist, Methodist,
7th Day Adventist, Roman Catholic, Pentecostal,
Word of Life, 7th Day Baptist, Judaism
Languages: Estonian (official), Russian, Ukrainian,
other
Literacy:
definition: age 15 and over can read and write
total population: 100%
ma/e:100%
female: 100% (1989 est.)
Population: 58,390,351 (July 1998 est.)
Age structure:
0-14 years: 46% (male 13,468,783; female
13,398,500)
15-64 years: 51% (male 15,095,357; female
14,812,537)
65 years and over: 3% (male 734,471 ; female
880,703) (July 1998 est.)
Population growth rate: 2.21% (1998 est.)
Birth rate: 44.69 births/1,000 population (1998 est.)
Death rate: 21 .25 deaths/1 ,000 population (1 998
est.)
Net migration rate: -1 .33 migrant(s)/1 ,000
population (1998 est.)
note: repatriation of Ethiopians who fled to Sudan,
Kenya, and Somalia for refuge from war and famine in
earlier years, is expected to continue slowly in 1998;
small numbers of Sudanese and Somali refugees,
who fled to Ehiopia from the fighting in their own
countries, began returning to their homes in 1998
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over : 0.83 ma!e(s)/female (1 998 est.)
Infant mortality rate: 125.65 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 40.85 years
male: 39.76 years
female: 41 .97 years (1 998 est.)
Total fertility rate: 6.88 children born/woman (1998
est.)
Nationality:
noun: Ethiopian(s)
adjective: Ethiopian
Ethnic groups: Oromo 40%, Amhara and Tigrean
32%, Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%,
Gurage 2%, other 1%
Religions: Muslim 45%-50%, Ethiopian Orthodox
35%-40%, animist 12%, other 3%-8%
Languages: Amharic (official), Tigrinya, Orominga,
Guaraginga, Somali, Arabic, English (major foreign
language taught in schools)
Literacy:
definition: age 15 and over can read and write
total population: 35.5%
male: 45.5%
female: 25.3% (1995 est.)
Population: no indigenous inhabitants
note: there is a small French military garrison','33c8b244a0bb4e6caeda85c9e6f90069ec4c4d77cfde258109e7d034c2f43968','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9c5b480c47509631d665b9ea81c32906391b2d00350b450e1bba3b2e90af483',1998,'FO','Faroe Islands','people-and-society',365,'Population: 41 ,834 (July 1 998 est.)
Age structure:
0-14 years: 23% (male 4,971 ; female 4,777)
15-64 years: 62% (male 13,896; female 12,034)
65 years and over: 15% (male 2,759; female 3,397)
(July 1998 est.)
Population growth rate: -1 .72% (1998 est.)
Birth rate: 13.08 births/1 ,000 population (1998 est.)
Death rate: 8.84 deaths/1 ,000 population (1 998 est.)
Net migration rate: -21 .42 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1.15 ma!e(s)/female
65 years and over: 0.81 male(s)/female (1 998 est.)
Infant mortality rate: 1 0.5 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.43 years
male: 75.53 years
female: 81 .45 years (1998 est.)
Total fertility rate: 2.36 children born/woman (1998
est.)
Nationality:
noun: Faroese (singular and plural)
adjective: Faroese
Ethnic groups: Scandinavian
Religions: Evangelical Lutheran
Languages: Faroese (derived from Old Norse),
Danish
Literacy: NA
note: similar to Denmark proper','3e5d134153f00b428b4e000efeefa4a877166e0175a94b8db2ac1e6ec8639b7b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9eae6450981e6380b88374dc4c863b124b631783c252a4800830a66716dcc61',1998,'JE','Jersey','people-and-society',372,'Population: 802,611 (July 1998 est.)
Age structure:
0-14 years: 34% (male 139,713; female 134,220)
15-64 years: 63% (male 251 ,646; female 251 ,425)
65 years and over: 3% (male 12,051 ; female 1 3,556)
(July 1998 est.)
Population growth rate: 1 .28% (1 998 est.)
Birth rate: 22.92 births/1 ,000 population (1998 est.)
Death rate: 6.25 deaths/1 ,000 population (1 998 est.)
Net migration rate: -3.92 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 ma!e(s)/female
15-64 years: 1 male(s)/fema!e
65 years and over: 0.89 male(s)/fema!e (1 998 est.)
Infant mortality rate: 16.65 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population : 66.29 years
male: 63.92 years
female: 68.78 years (1998 est.)
Total fertility rate: 2.74 children born/woman (1 998
est.)
Nationality:
noun: Fijian(s)
adjective : Fijian
Ethnic groups: Fijian 49%, Indian 46%, European,
other Pacific Islanders, overseas Chinese, and other
5%
Religions: Christian 52% (Methodist 37%, Roman
Catholic 9%), Hindu 38%, Muslim 8%, other 2%
note: Fijians are mainly Christian, Indians are Hindu,
and there is a Muslim minority (1986)
Languages: English (official), Fijian, Hindustani
Literacy:
definition: age 1 5 and over can read and write
total population: 91 .6%
male: 93.8%
female: 89.3% (1995 est.)
Population: 89,136 (July 1998 est.)
Age structure:
0-1 4 years: 18% (male 8,160; female 7,567)
15-64 years: 68% (male 30,106; female 30,639)
65 years and over: 1 4% (male 5,243; female 7,421 )
(July 1998 est.)
Population growth rate: 0.68% (1998 est.)
Birth rate: 1 2.27 births/1 ,000 population (1 998 est.)
Death rate: 9. 12 deaths/1 ,000 population (1998 est.)
Net migration rate: 3.66 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.71 ma!e(s)/fema!e (1998 est.)
Infant mortality rate: 2.75 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.67 years
male: 75.93 years
female: SI .71 years (1998 est.)
Total fertility rate: 1 .5 children born/woman
(1998 est.)
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Baptist,
Congregational New Church, Methodist, Presbyterian
Languages: English (official), French (official),
Norman-French dialect spoken in country districts
Literacy: NA
Population: no indigenous inhabitants
note: there are 1,200 US military and civilian
contractor personnel (January 1997 est.)
Population growth rate: -6.41% (1998 est.)
Population: 1 ,91 3,285 (July 1 998 est.)
note: includes 1,168,185 non-nationals
(July 1998 est.)
Age structure:
0-14 years: 32% (male 338,933; female 279,087)
15-64 years: 66% (male 81 1,713; female 444,679)
65 years and over: 2% (male 23,642; female 1 5,231)
(July 1998 est.)
Population growth rate: 4.1% (1998 est.)
note: this rate reflects the continued post-Gulf crisis
return of expatriates
Birth rate: 20.97 births/1,000 population (1998 est.)
Death rate: 2.29 deaths/1 ,000 population (1 998 est.)
Net migration rate: 22.31 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .21 male(s)/female
15-64 years: 1.82 male(s)/female
65 years and over: 1 .55 male(s)/female (1998 est.)
Infant mortality rate: 1 0.74 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population ; 76.78 years
mate; 74.76 years
female: 78.91 years (1998 est.)
Total fertility rate: 3.44 children born/woman
(1998 est.)
Nationality:
noun: Kuwaiti(s)
adjective: Kuwaiti
Ethnic groups: Kuwaiti 45%, other Arab 35%, South
Asian 9%, Iranian 4%, other 7%
Religions: Muslim 85% (Sunni 45%, Shi''a 40%),
Christian, Hindu, Parsi, and other 15%
Languages: Arabic (official), English widely spoken
Literacy:
definition: age 1 5 and over can read and write
total population: 78.6%
male: 82.2%
female: 74.9% (1995 est.)
Population: 194,197 (July 1998 est.)
338
Age structure:
0-14 years: 30% (male 29,423; female 28,320)
15-64 years: 65% (male 63,444; female 62,055)
65 years and over: 5% (male 5,202; female 5,753)
(July 1998 est.)
Population growth rate: 1 .64% (1 998 est.)
Birth rate: 21 .08 births/1 ,000 population (1 998 est.)
Death rate: 4.84 deaths/1 ,000 population (1998 est.)
Net migration rate: 0.15 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.9 male(s)/female (1 998 est.)
Infant mortality rate: 12.71 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.01 years
male: 71 .75 years
female: 78.44 years (1998 est.)
Total fertility rate: 2.46 children born/woman (1998
est.)
Nationality:
noun: New Caledonian(s)
adjective: New Caledonian
Ethnic groups: Melanesian 42.5%, European
37.1%, Wallisian 8.4%, Polynesian 3.8%, Indonesian
3.6%, Vietnamese 1.6%, other 3%
Religions: Roman Catholic 60%, Protestant 30%,
other 10%
Languages: French, 28 Melanesian-Polynesian
dialects
Literacy:
definition: age 15 and over can read and write
total population: 91%
male: 92%
female: 90% (1976 est.)
Land boundaries:
total: 1,334 km
border countries: Austria 330 km, Croatia 670 km,
Italy 232 km, Hungary 102 km
Coastline: 46.6 km
Maritime claims: NA
Climate: Mediterranean climate on the coast,
continental climate with mild to hot summers and cold
winters in the plateaus and valleys to the east
Terrain: a short coastal strip on the Adriatic, an
alpine mountain region adjacent to Italy, mixed
mountain and valleys with numerous rivers to the east
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Triglav 2,864 m
Natural resources: lignite coal, lead, zinc, mercury,
uranium, silver
Land use:
arable land: 12%
permanent crops: 3%
permanent pastures: 28%
forests and woodland: 51 %
other: 6% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: flooding and earthquakes
Environment— current issues: Sava River polluted
with domestic and industrial waste; pollution of coastal
waters with heavy metals and toxic chemicals; forest
damage near Koper from air pollution (originating at
Age structure:
0-14 years: 17% (male 168,633; female 160,202)
15-64 years: 70% (male 692,043; female 686,707)
65 years and over: 1 3% (male 96,023; female
168,131) (July 1998 est.)
Population growth rate: -0.08% (1998 est.)
Birth rate: 8.58 births/1,000 population (1998 est.)
Death rate: 9.56 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0.21 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .05 male(s)/fema!e
15-64 years: 1 male(s)/female
65 years and over: 0.57 male(s)/female (1998 est.)
infant mortality rate: 5.34 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.15 years
male: 71 .48 years
female: 79.02 years (1 998 est.)
Total fertility rate: 1.17 children born/woman (1998
est.)
Nationality:
noun: Slovene(s)
adjective: Slovenian
Ethnic groups: Slovene 91%, Croat 3%, Serb 2%,
Muslim 1%, other 3%
Religions: Roman Catholic 70.8% (including 2%
Uniate), Lutheran 1%, Muslim 1%, other 27.2%
424
Languages: Slovenian 91%, Serbo-Croatian 6%,
other 3%
Literacy:
definition: NA
total population: 99%
male: NA%
female: NA%
Population: 966,462 (July 1998 est.)
Age structure:
0-14 years: 46% (male 223,649; female 224,782)
15-64 years: 51% (male 238,547; female 255,137)
65 years and over: 3% (male 9,625; female 14,722)
(July 1998 est.)
Population growth rate: 1 .96% (1998 est.)
Birth rate: 41 births/1,000 population (1998 est.)
Death rate: 21 .4 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.93 ma!e(s)/female
65 years and over: 0.65 male(s)/female (1 998 est.)
Infant mortality rate: 1 03.37 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population : 38.53 years
male: 37.31 years
female: 39.79 years (1998 est.)
Total fertility rate: 5.96 children born/woman (1998
est.)
Nationality:
noun: Swazi (s)
adjective: Swazi
Ethnic groups: African 97%, European 3%
Religions: Christian 60%, indigenous beliefs 40%
Languages: English (official, government business
conducted in English), siSwati (official)
Literacy:
definition : age 15 and over can read and write
total population: 76.7%
male: 78%
female: 75.6% (1995 est.)','f2be39f785034b5cc1304472df7a622908d0ea9d699fee3d0e1056af86ed4bac','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dd2d83a3066f845f646c208f36bf83e2e1b63af36fed8085bed9dd97e9d1f23',1998,'FI','Finland','people-and-society',381,'Population: 5,149,242 (July 1998 est.)
Age structure:
0-14 years: 19% (male 488,974; female 469,343)
15-64 years: 67% (male 1 ,736,883; female
1,700,466)
65 years and over: 14% (male 284,929; female
468,647) (July 1998 est.)
Population growth rate: 0.2% (1998 est.)
Birth rate: 1 1 .24 births/1 ,000 population (1 998 est.)
Death rate: 9.65 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0.45 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.04 ma!e(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .02 male(s)/fema!e
65 years and over: 0.61 male(s)/female (1 998 est.)
Infant mortality rate: 3.82 deaths/1 ,000 live births
(1998 est.)
160
Life expectancy at birth:
total population: 77. 1 5 years
male: 73.61 years
female: 80.83 years (1998 est.)
Total fertility rate: 1 .73 children born/woman (1 998
est.)
Nationality:
noun: Finn(s)
adjective: Finnish
Ethnic groups: Finn 93%, Swede 6%, Lapp 0.1 1%,
Gypsy 0.12%, Tatar 0.02%
Religions: Evangelical Lutheran 89%, Greek
Orthodox 1%, none 9%, other 1%
Languages: Finnish 93.5% (official), Swedish 6.3%
(official), small Lapp- and Russian-speaking
minorities
Literacy:
definition: age 1 5 and over can read and write
total population: 100% (1980 est.)
male: NA%
female: NA%
Population: 3,505,794 (July 1998 est.)
Age structure:
0-14 years: 30% (male 532,688; female 512,979)
15-64 years: 64% (male 1 ,060,903; female
1,174,236)
65 years and over: 6% (male 102,946; female
122,042) (July 1998 est.)
Population growth rate: 1 .62% (1998 est.)
Birth rate: 22.66 births/1,000 population (1998 est.)
Death rate: 6.51 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/fema!e
15-64 years: 0.9 maie(s)/female
65 years and over: 0.84 male(s)/female (1 998 est.)
Infant mortality rate: 31 .64 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 70.64 years
male: 68.08 years
female: 73.33 years (1 998 est.)
Total fertility rate: 2.28 children born/woman
(1998 est.)
Nationality:
noun: Lebanese (singular and plural)
adjective : Lebanese
Ethnic groups: Arab 95%, Armenian 4%, other 1%
Religions: Islam 70% (5 legally recognized Islamic
groups— Alawite or Nusayri, Druze, Isma''ilite, Shi''a,
Sunni), Christian 30% (1 1 legally recognized Christian
groups— 4 Orthodox Christian, 6 Catholic, 1
Protestant), Judaism NEGL%
Languages: Arabic (official), French, English,
Armenian widely understood
Literacy:
definition: age 15 and over can read and write
total population: 86.4%
male: 90.8%
female: 82.2% (1997 est.)','a066c190b805e94b9aeb6b420b474525267d9702c52a412928a6a61887c812a5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('385aaffde257d4f8e9e728f088f29e25045ec52a2d5087878ffebba026f28641',1998,'GF','French Guiana','people-and-society',394,'Population: 162,547 (July 1998 est.)
Age structure:
0-14 years: 31% (male 26,003; female 24,840)
15-64 years: 64% (male 56,034; female 47,250)
65 years and over: 5% (male 4,245; female 4,175)
(July 1998 est.)
Population growth rate: 3.4% (1998 est.)
Birth rate: 23.73 births/1,000 population (1998 est.)
Death rate: 4.53 deaths/1 ,000 population (1 998 est.)
Net migration rate: 14.76 migrant(s)/1,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/fema!e
under 15 years: 1.05 male(s)/fema!e
15-64 years: 1.19 ma!e(s)/female
65 years and over: 1.02 male(s)/female (1998 est.)
Infant mortality rate: 13.48 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 76.34 years
male: 73.12 years
female: 79.71 years (1998 est.)
Total fertility rate: 3.35 children born/woman (1998
est.)
Nationality:
noun: French Guianese (singular and plural)
adjective: French Guianese
Ethnic groups: black or mulatto 66%, white 12%,
East Indian, Chinese, Amerindian 12%, other 10%
Religions: Roman Catholic
Languages: French
Literacy:
definition: age 1 5 and over can read and write
total population: 83%
male: 84%
female: 82% (1982 est.)','077e9413d91dd358df8bbe2c10df56f7829744fc88bbc13d8e3c26156fd87e76','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eacf545dddafab2759a74cf92c112669d6018ef36a212c59cc687751b2f98dfe',1998,'GA','Gabon','people-and-society',403,'Population: no indigenous inhabitants
note: there were 101 (1997) mostly researchers
whose numbers vary from winter (July) to summer
(January)
Population: 1 ,207,844 (July 1 998 est.)
Age structure:
0-14 years: 33% (male 202,364; female 202,249)
15-64 years: 61% (male 372,157; female 364,806)
65 years and over: 6% (male 32,71 8; female 33,550)
(July 1998 est.)
Population growth rate: 1.48% (1998 est.)
Birth rate: 28 births/1,000 population (1998 est.)
Death rate: 13.23 deaths/1 ,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.03 male(s)/fema!e
under 15 years: 1 ma!e(s)/fema!e
15-64 years: 1.02 ma!e(s)/female
65 years and over: 0.97 male(s)/female (1 998 est.)
Infant mortality rate: 85.43 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 56.51 years
male: 53.55 years
female: 59.56 years (1998 est.)
Total fertility rate: 3.81 children born/woman (1998
est.)
Nationality:
noun; Gabonese (singular and plural)
adjective: Gabonese
Ethnic groups: Bantu tribes including four major
tribal groupings (Fang, Eshira, Bapounou, Bateke),
other Africans and Europeans 154,000, including
6,000 French and 11,000 persons of dual nationality
Religions: Christian 55%-75%, Muslim less than
1%, animist
Languages: French (official), Fang, Myene, Bateke,
Bapounou/Eschira, Bandjabi
Literacy:
definition: age 15 and over can read and write
total population: 63.2%
male: 73.7%
female: 53.3% (1995 est.)
Population: 1 ,291 ,858 (July 1 998 est.)
Age structure:
0-14 years: 46% (male 296,108; female 295,136)
15-64 years: 52% (male 330,215; female 336,056)
65 years and over: 2% (male 1 8,1 94; female 1 6,1 49)
(July 1998 est.)
Population growth rate: 3.42% (1998 est.)
Birth rate: 43.3 births/1 ,000 population (1 998 est.)
Death rate: 12.93 deaths/1,000 population (1998
est.)
Net migration rate: 3.77 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1.12 male(s)/female (1 998 est.)
Infant mortality rate: 77.07 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 53.91 years
male: 51 .59 years
female: 56.29 years (1 998 est.)
Total fertility rate: 5.91 children born/woman (1998
est.)
Nationality:
noun: Gambian(s)
adjective: Gambian
Ethnic groups: African 99% (Mandinka 42%, Fula
18%, Wolof 16%, Jola 10%, Serahuli 9%, other 4%),
non-African 1%
Religions: Muslim 90%, Christian 9%, indigenous
beliefs 1%
Languages: English (official), Mandinka, Wolof,
Fula, other indigenous vernaculars
Literacy:
definition: age 15 and over can read and write
total population: 38.6%
male: 52.8%
female: 24.9% (1995 est.)','18419a5818d1cedf32162dfb75584b602d5487a1a48bc7a7f11843fc3b6c7ca2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8d4faefdefb2f4cd4733aa7f00efe8fea5aa85827d675795c45cbc74e59d27e',1998,'GE','Georgia','people-and-society',412,'Population: 5,108,527 (July 1998 est.)
Age structure:
0-14 years: 22% (male 562,623; female 540,378)
15-64 years: 66% (male 1 ,631 ,296; female
1,756,087)
65 years and over: 1 2% (male 235,042; female
383,101) (July 1998 est.)
Population growth rate: -0.92% (1998 est.)
Birth rate: 1 1 .72 births/1 ,000 population (1998 est.)
Death rate: 14.1 deaths/1 ,000 population (1998 est.)
Net migration rate: -6.79 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years : 1 .04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.61 male(s)/female (1 998 est.)
Infant mortality rate: 51 .07 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 64.79 years
male: 61.36 years
female : 68.4 years (1998 est.)
Total fertility rate: 1 .54 children born/woman (1 998
est.)
Nationality:
noun: Georgian(s)
adjective : Georgian
Ethnic groups: Georgian 70.1%, Armenian 8.1%,
Russian 6.3%, Azeri 5.7%, Ossetian 3%, Abkhaz
1.8%, other 5%
Religions: Christian Orthodox 75% (Georgian
Orthodox 65%, Russian Orthodox 1 0%), Muslim 1 1 %,
Armenian Apostolic 8%, unknown 6%
Languages: Armenian 7%, Azeri 6%, Georgian 71 %
(official), Russian 9%, other 7%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 100%
female: 98% (1989 est.)','b13e4ee7a3da6c5d53568218e6597429ad9ee07a93dde2afc96193d2ea3baa39','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8a86dc9a397585b6d1a93111467e627308c3aec07a9f87c391d25a856637dc2',1998,'DE','Germany','people-and-society',419,'Population: 82,079,454 (July 1998 est.)
Age structure:
0-14 years: 16% (male 6,570,582; female 6,240,671)
15-64 years: 68% (male 28,688,052; female
27,532,099)
65 years and over: 1 6% (male 4,866, 1 22; female
8,181,928) (July 1998 est.)
Population growth rate: 0.02% (1998 est.)
Birth rate: 8.84 births/1,000 population (1998 est.)
Death rate: 10.77 deaths/1,000 population (1998
est.)
Net migration rate: 2.08 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.59 male(s)/female (1998 est.)
Infant mortality rate: 5.2 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 76.99 years
male: 73.83 years
female: 80.33 years (1998 est.)
Total fertility rate: 1 .25 children born/woman (1 998
est.)
Nationality:
noun: German(s)
adjective: German
Ethnic groups: German 91 .5%, Turkish 2.4%,
Italians 0.7%, Greeks 0.4%, Poles 0.4%, other 4.6%
(made up largely of people fleeing the war in the
former Yugoslavia)
Religions: Protestant 38%, Roman Catholic 34%,
Muslim 1 .7%, unaffiliated or other 26.3%
Languages: German
Literacy:
definition : age 15 and over can read and write
total population: 99% (1 977 est.)
male: NA%
female: NA%
Population: 425,017 (July 1998 est.)
Age structure:
0-14 years: 18% (male 39,565; female 37,824)
15-64 years: 67% (male 145,060; female 139,628)
65 years and over: 1 5% (male 25,449; female
37,491) (July 1998 est.)
Population growth rate: 1.02% (1998 est.)
Birth rate: 11.12 births/1,000 population (1998 est.)
Death rate: 9.29 deaths/1 ,000 population (1 998 est.)
Net migration rate: 8.4 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .05 ma!e($)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.68 male(s)/female (1998 est.)
Infant mortality rate: 5.04 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 77.49 years
male: 74.41 years
female: 80.68 years (1998 est.)
Total fertility rate: 1 .63 children born/woman (1 998
est.)
Nationality:
noun: Luxembourger(s)
adjective: Luxembourg
Ethnic groups: Celtic base (with French and
German blend), Portuguese, Italian, and European
(guest and worker residents)
Religions: Roman Catholic 97%, Protestant and
Jewish 3%
Languages: Luxembourgian, German, French,
English
Literacy:
definition: age 15 and over can read and write
total population: 100%
ma/e;100%
female: 100% (1980 est.)
Population: 429,152 (July 1998 est.)
Age structure:
0-14 years: 25% (male 54,845; female 51 ,354)
15-64 years: 68% (male 138,871; female 153,801)
65 years and over: 1% (male 12,139; female 18,142)
(July 1998 est.)
Population growth rate: 1 .91 % (1 998 est.)
Birth rate: 12.76 births/1,000 population (1998 est.)
Death rate: 3.48 deaths/1 ,000 population (1 998 est.)
Net migration rate: 9.78 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years : 0.9 male(s)/female
65 years and over: 0.67 male(s)/female (1 998 est.)
Infant mortality rate: 4.4 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 81 .6 years
male: 78.66 years
female: 84.68 years (1998 est.)
Total fertility rate: 1 .27 children born/woman (1 998
est.)
Nationality:
noun: Macanese (singular and plural)
adjective : Macau
Ethnic groups: Chinese 95%, Portuguese 3%, other
2%
Religions: Buddhist 50%, Roman Catholic 15%,
none and other 35% (1997 est.)
Languages: Portuguese, Chinese (Cantonese)
Literacy:
definition: age 15 and over can read and write
total population: 90%
male: 93%
fema/e;86%(1981 est.)
Population: 32,035 (July 1998 est.)
Age structure:
0-14 years: 17% (male 2,730; female 2,659)
15-64 years: 64% (male 9,934; female 10,463)
65 years and over: 1 9% (male 2,300; female 3,949)
(July 1998 est.)
Population growth rate: 0.4% (1998 est.)
Birth rate: 10.71 births/1,000 population (1998 est.)
Death rate: 1 1 .86 deaths/1 ,000 population (1 998
est.)
Net migration rate: 5.18 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years : 0.95 male(s)/female
65 years and over: 0.58 male(s)/female (1998 est.)
Infant mortality rate: 6.6 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.41 years
male: 74.79 years
female: 82.21 years (1998 est.)
Total fertility rate: 1 .7 children born/woman (1 998
est.)
Nationality:
noun: Monegasque(s) or Monacan(s)
adjective: Monegasque or Monacan
Ethnic groups: French 47%, Monegasque 16%,
Italian 16%, other 21%
Religions: Roman Catholic 95%
Languages: French (official), English, Italian,
Monegasque
Literacy: NA','24f2cc1930117f781c5a4690147ab93b2e57bcc3d39dacac59329400bdea5f0d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ebb60968720712c3fcaf3345568490e028a4c0d7257654b30e29eb1e22b1bc8',1998,'GH','Ghana','people-and-society',422,'Population: 18,497,206 (July 1998 est.)
Age structure:
0-14 years: 43% (male 3,985,21 9; female 3,947,640)
15-64 years: 54% (male 4,905,442; female
5,077,521)
65 years and over: 3% (male 275,192; female
306,192) (July 1998 est.)
Population growth rate: 2.13% (1998 est.)
Birth rate: 32.81 births/1,000 population (1998 est.)
Death rate: 1 0.63 deaths/1 ,000 population (1 998
est.)
Net migration rate: -0.9 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.89 male(s)/female (1 998 est.)
Infant mortality rate: 77.53 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 56.82 years
male: 54.77 years
female : 58.92 years (1998 est.)
Total fertility rate: 4.27 children born/woman (1998
est.)
Nationality:
noun: Ghanaian(s)
adjective: Ghanaian
Ethnic groups: black African 99.8% (major tribes —
Akan 44%, Moshi-Dagomba 1 6%, Ewe 1 3%, Ga 8%),
European and other 0.2%
Religions: indigenous beliefs 38%, Muslim 30%,
Christian 24%, other 8%
Languages: English (official), African languages
(including Akan, Moshi-Dagomba, Ewe, and Ga)
Literacy:
definition: age 15 and over can read and write
total population: 64.5%
male: 75.9%
female: 53.5% (1995 est.)','98cdcf52aa335b3f1691428569b79dc4d8a7f905600e4db52e0872485b26fad5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('534eb8c35f0ed6e64214adfa5d56f756954f8bae59d79d004d0600980dacda53',1998,'GD','Grenada','people-and-society',439,'Population: 96,217 (July 1998 est.)
Age structure:
0-14 years : 43% (male 21 ,077; female 20,378)
15-64 years: 52% (male 26,959; female 23,403)
65 years and over: 5% (male 2,061 ; female 2,339)
(July 1998 est.)
Population growth rate: 0.77% (1998 est.)
Birth rate: 28.1 births/1 ,000 population (1998 est.)
Death rate: 5.33 deaths/1 ,000 population (1 998 est.)
Net migration rate: -15.11 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth : 1 .02 male(s)/female
under 15 years: 1.03 ma!e(s)/female
15-64 years: 1.15 male(s)/female
65 years and over: 0.88 male(s)/female (1 998 est.)
Infant mortality rate: 1 1 .37 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 71 .36 years
male: 68.77 years
female: 74 years (1998 est.)
Total fertility rate: 3.64 children born/woman (1998
est.)
Nationality:
noun:Grenadian(s)
adjective: Grenadian
Ethnic groups: black
Religions: Roman Catholic 53%, Anglican 13.8%,
other Protestant sects 33.2%
Languages: English (official), French patois
Literacy:
definition: age 15 and over can read and write
total population: 98%
maie: 98%
female: 98% (1 970 est.)
Population: 416,439 (July 1998 est.)
Age structure:
0-14 years: 25% (male 53,239; female 51,148)
15-64 years: 66% (male 136,439; female 139,555)
65 years and over: 9% (male 1 5,243; female 20,81 5)
(July 1998 est.)
Population growth rate: 1 .1 % (1 998 est.)
Birth rate: 1 6.73 births/1 ,000 population (1 998 est.)
Death rate: 5.61 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.16 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 ma!e(s)/fema!e
15-64 years: 0.98 male(s)/female
65 years and over: 0.73 male(s)/female (1998 est.)
Infant mortality rate: 8.79 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 77.8 years
male: 74.78 years
female: 80.97 years (1998 est.)
Total fertility rate: 1 .84 children born/woman (1 998
est.)
Nationality:
noun : Guadeloupian(s)
adjective: Guadeloupe
Ethnic groups: black or mulatto 90%, white 5%,
East Indian, Lebanese, Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan
African 4%, Protestant sects 1%
Languages: French (official) 99%, Creole patois
Literacy:
definition: age 1 5 and over can read and write
total population: 90%
male: 90%
female: 90% (1982 est.)','a5ac227c7faa64c8e4253eef854ae63bb0b6cb13c5d021bbbc7bd389b829668b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81a518fa998916318fa5f975ddcb219f3875983e0f9d42efe90a9b005e2d349c',1998,'GU','Guam','people-and-society',448,'Population: 148,060 (July 1998 est.)
Age structure:
0-14 years: 34% (male 25,972; female 24,097)
15-64 years: 60% (male 47,357; female 42,1 89)
65 years and over: 6% (male 4,244; female 4,201 )
(July 1998 est.)
Population growth rate: 1 .5% (1 998 est.)
Birth rate: 25.04 births/1 ,000 population (1998 est.)
Death rate: 4.42 deaths/1 ,000 population (1 998 est.)
Net migration rate: -5.59 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.07 ma!e(s)/fema!e
15-64 years: 1 .12 male(s)/female
65 years and over: 1 .01 male(s)/female (1 998 est.)
Infant mortality rate: 8.28 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 76.7 years
male: 74.12 years
female: 79.44 years (1 998 est.)
Total fertility rate: 3.58 children born/woman (1998
est.)
Nationality:
noun: Guamanian(s)
adjective: Guamanian
Ethnic groups: Chamorro 47%, Filipino 25%, white
10%, Chinese, Japanese, Korean, and other 18%
Religions: Roman Catholic 98%, other 2%
Languages: English, Chamorro, Japanese
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1990 est.)
Population: 12,007,580 (July 1998 est.)
Age structure:
0-14 years: 43% (male 2,629,861 ; female 2,522,1 12)
15-64 years: 54% (male 3,21 3,744; female
3,216,415)
65 years and over: 3% (male 199,738; female
225,710) (July 1998 est.)
Population growth rate: 2.71% (1998 est.)
Birth rate: 36.02 births/1,000 population (1998 est.)
Death rate: 6.96 deaths/1 ,000 population (1998 est.)
Net migration rate: -1 .99 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.88 male($)/female (1 998 est.)
Infant mortality rate: 47.68 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 66.04 years
male : 63.4 years
female: 68.81 years (1998 est.)
Total fertility rate: 4.81 children born/woman (1998
est.)
Nationality:
noun: Guatemalan(s)
adjective: Guatemalan
Ethnic groups: Mestizo (mixed
Amerindian-Spanish— in local Spanish called Ladino)
56%, Amerindian or predominantly Amerindian 44%
Religions: Roman Catholic, Protestant, traditional
Mayan
Languages: Spanish 60%, Amerindian languages
40% (23 Amerindian languages, including Quiche,
Cakchiquel, Kekchi)
Literacy:
definition: age 1 5 and over can read and write
total population: 55.6%
male: 62.5%
female: 48.6% (1995 est.)
195
Guatemala (continued)','26dfd93d9bd75209cce0d13ce0ed958be3c259fae6eb7da65881e24e281b3981','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('323af8daabc1e5c93bc1fbf0dcb4d0d8f398fdd66d9236f22b21d2a8d39b444d',1998,'GG','Guernsey','people-and-society',456,'Population: 64,555 (July 1998 est.)
Age structure:
0-14 years: 18% (male 5,856; female 5,721)
15-64 years: 67% (male 21 ,094; female 21 ,939)
65 years and over: 15% (male 4,001 ; female 5,944)
(July 1998 est.)
Population growth rate: 1.28% (1998 est.)
Birth rate: 13.91 births/1 ,000 population (1998 est.)
Death rate: 9.53 deaths/1 ,000 population (1998 est.)
Net migration rate: 8.46 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.04 ma!e(s)/fema!e
under 15 years: 1.02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.67 male(s)/female (1998 est.)
Infant mortality rate: 8.67 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.55 years
male: 75.61 years
female: 81 .6 years (1 998 est.)
Total fertility rate: 1.68 children born/woman (1998
est.)
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Presbyterian,
Baptist, Congregational, Methodist
Languages: English, French, Norman-French
dialect spoken in country districts
Literacy: NA
Population: 7,477,1 10 (July 1998 est.)
Age structure:
0-14 years: 44% (male 1 ,634,344; female 1 ,644,863)
15-64 years: 53% (male 1 ,952,442; female
2,044,363)
65 years and over: 3% (male 83,616; female
117,482) (July 1998 est.)
Population growth rate: 0.83% (1998 est.)
Birth rate: 41 .28 births/1 ,000 population (1998 est.)
Death rate: 17.76 deaths/1,000 population (1998
est.)
Net migration rate: -15.25 migrant(s)/1 ,000
population (1998 est.)
note: in prior years Guinea received several hundred
thousand refugees from the civil wars in Liberia and
Sierra Leone, some of whom are now returning to their
own countries
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.99 ma!e(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.71 male(s)/female (1998 est.)
Infant mortality rate: 128.92 deaths/1,000 live
births (1998 est.)
Life expectancy at birth:
total population: 46.01 years
male: 43.58 years
female: 48.52 years (1998 est.)
Total fertility rate: 5.59 children born/woman (1998
est.)
Nationality:
mm''Guinean(s)
adjective: Guinean
Ethnic groups: Peuhl 40%, Malinke 30%, Soussou
20%, smaller tribes 10%
Religions: Muslim 85%, Christian 8%, indigenous
beliefs 7%
Languages: French (official), each tribe has its own
language
Literacy:
definition: age 15 and over can read and write
total population: 35.9%
male: 49.9%
female: 21 .9% (1995 est.)','e7eda9dbdbb8cac4911f044dec5381ec0acff62f29c8d129580c803c48e5db70','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43a4236200c2564abc4e4c6e29572a2ba0a156aa5375ac626d778c1e1a54716b',1998,'GW','Guinea-Bissau','people-and-society',463,'Population: 1,206,311 (July 1998 est.)
Age structure:
0-14 years: 42% (male 256,315; female 255,208)
15-64 years: 55% (male 31 3,270; female 347,431 )
65 years and over: 3% (male 15,986; female 18,101)
(July 1998 est.)
Population growth rate: 2.32% (1998 est.)
Birth rate: 38.67 births/1 ,000 population (1998 est.)
Death rate: 15.48 deaths/1 ,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.88 male(s)/female (1 998 est.)
Infant mortality rate: 1 1 1 .61 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 49. 1 4 years
male: 47.47 years
female: 50.85 years (1 998 est.)
Total fertility rate: 5.17 children born/woman (1998
est.)
Nationality:
noun: Guinean (s)
adjective: Guinean
Ethnic groups: African 99% (Balanta 30%, Fula
20%, Manjaca 14%, Mandinga 13%, Papel 7%),
European and mulatto less than 1%
Religions: indigenous beliefs 50%, Muslim 45%,
Christian 5%
Languages: Portuguese (official), Crioulo, African
languages
Literacy:
definition: age 1 5 and over can read and write
total population: 53.9%
ma/e:67.1%
female: 40.7% (1997 est.)','179c1cb639f2f11526c43c87f4b8890379e07793db8ded197570877a05bd1697','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7546c850736d91c115dfd95a5fcd03d8accb1e7b584d4c876f7b9ccbdfd70555',1998,'GY','Guyana','people-and-society',468,'Population: 707,954 (July 1998 est.)
Age structure:
0-14 years: 31% (male 112,339; female 108,095)
15-64 years: 64% (male 228,719; female 226,309)
65 years and over: 5% (male 14,652; female 17,840)
(July 1998 est.)
Population growth rate: -0.47% (1998 est.)
Birth rate: 18.49 births/1,000 population (1998 est.)
Death rate: 8.72 deaths/1 ,000 population (1 998 est.)
Net migration rate: -14.45 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.82 male(s)/female (1998 est.)
Infant mortality rate: 48.67 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 62.34 years
male: 59.5 years
female: 65.32 years (1998 est.)
Total fertility rate: 2.12 children born/woman (1998
est.)
Nationality:
noun: Guyanese (singular and plural)
adjective: Guyanese
Ethnic groups: East Indian 49%, black 32%, mixed
12%, Amerindian 6%, white and Chinese 1%
Religions: Christian 57%, Hindu 33%, Muslim 9%,
other 1%
Languages: English, Amerindian dialects
Literacy:
, definition: age 15 and over has ever attended school
total population: 98.1%
male: 98.6%
female: 97.5% (1995 est.)
Population: 6,780,501 (July 1998 est.)
Age structure:
0- 14 years: 43% (male 1 ,465,735; female 1 ,422,260)
15-64 years: 53% (male 1 ,733,636; female
1,881,367)
65 years and over: 4% (male 1 38,678; female
138,825) (July 1998 est.)
Population growth rate: 1 .51 % (1 998 est.)
Birth rate: 32.84 births/1,000 population (1998 est.)
Death rate: 14.17 deaths/1 ,000 population (1 998
est.)
Net migration rate: -3.61 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.92 maie(s)/female
65 years and over: 1 male(s)/female (1 998 est.)
Infant mortality rate: 98.98 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 51 .4 years
male: 49.33 years
female: 53.58 years (1998 est.)
Total fertility rate: 4.67 children born/woman (1998
est.)
Nationality:
noun: Haitian(s)
adjective: Haitian
Ethnic groups: black 95%, mulatto plus white 5%
Religions: Roman Catholic 80%, Protestant 16%
(Baptist 10%, Pentecostal 4%, Adventist 1%, other
1%), none 1%, other 3% (1982)
note: roughly one-half of the population also practices
Voodoo
Languages: French (official) 20%, Creole
Literacy:
definition: age 15 and over can read and write
total population: 45%
male: 48%
female: 42.2% (1995 est.)
Holy See
| j
DM
Population: uninhabited
(Vatican City)
$
(territory of Australia)
Population: 427,980 (July 1998 est.)
Age structure:
0-14 years: 33% (male 72,945; female 69,468)
15-64 years: 62% (male 133,840; female 129,452)
65 years and over: 5% (male 1 0,309; female 1 1 ,966)
(July 1998 est.)
Population growth rate: 0.77% (1998 est.)
Birth rate: 22.48 births/1 ,000 population (1998 est.)
Death rate: 5.79 deaths/1 ,000 population (1 998 est.)
Net migration rate: -8.99 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.86 ma!e(s)/female (1998 est.)
Infant mortality rate: 27.44 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 70.61 years
male: 68.05 years
female: 73.29 years (1 998 est.)
Total fertility rate: 2.59 children born/woman (1998
est.)
Nationality:
noun: Surinamer(s)
adjective: Surinamese
Ethnic groups: Hindustani (also known locally as
"East Indians"; their ancestors emigrated from
northern India in the latter part of the 19th century)
37%, Creole (mixed white and black) 31%, Javanese
15.3%, "Maroons" (their African ancestors were
brought to the country in the 17th and 18th centuries
as slaves and escaped to the interior) 10.3%,
Amerindian 2.6%, Chinese 1.7%, white 1%, other
1.1%
Religions: Hindu 27.4%, Muslim 19.6%, Roman
Catholic 22.8%, Protestant 25.2% (predominantly
Moravian), indigenous beliefs 5%
Languages: Dutch (official), English (widely
spoken), Sranang Tongo (Surinamese, sometimes
called Taki-Taki, is native language of Creoles and
much of the younger population and is lingua franca
among others), Hindustani (a dialect of Hindi),
Javanese
Literacy:
definition: age 15 and over can read and write
total population: 93%
male : 95%
female: 91% (1995 est.)
Population: 2,594 (July 1998 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -3.55% (1998 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA
male: NA
female : NA
Total fertility rate: NA children born/woman
Ethnic groups: Russian and Ukrainian 62%,
Norwegian 38%, other NEGL% (1994)
Languages: Russian, Norwegian','13357645cef4c7138ddc2f930c179fcca4089dd4f9016a58ada856ff747c0d45','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6592013fc889b76480362c7132f5cd9c97aadf4b79f60e59186c0405d8952152',1998,'HU','Hungary','people-and-society',477,'Population: 10,208,127 (July 1998 est.)
Age structure:
0-14 years: 18% (male 915,412; female 872,706)
15-64 years: 68% (male 3,413,170; female
3,533,085)
65 years and over : 14% (male 550,974; female
922,780) (July 1998 est.)
Population growth rate: -0.23% (1998 est.)
Birth rate: 1 0.69 births/1 ,000 population (1 998 est.)
Death rate: 1 3.46 deaths/1 ,000 population (1 998
est.)
Net migration rate: 0.49 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.6 male(s)/female (1998 est.)
Infant mortality rate: 9.7 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 70.83 years
male: 66.46 years
female: 75.44 years (1 998 est.)
Total fertility rate: 1 .45 children born/woman
(1998 est.)
Nationality:
noun: Hungarian(s)
adjective: Hungarian
Ethnic groups: Hungarian 89.9%, Gypsy 4%,
German 2.6%, Serb 2%, Slovak 0.8%, Romanian
0.7%
Religions: Roman Catholic 67.5%, Calvinist 20%,
Lutheran 5%, atheist and other 7.5%
Languages: Hungarian 98.2%, other 1.8%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 98% (1980 est.)','60afb69070dfb6c50e2694e7c6a38ddcc5f67df38fd7409d5a6a049116d9366c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0de97ccce8da060f57b023d5ce17db6e695cdacb67de93cbc9f8a7f100400d21',1998,'IS','Iceland','people-and-society',485,'Population: 271 ,033 (July 1998 est.)
note: population data estimates based on average
growth rate may differ slightly from official population
data because of volatile migration rates
Age structure:
0-14 years: 24% (male 32,723; female 31 ,196)
15-64 years: 65% (male 88,608; female 86,775)
65 years and over: 11% (male 1 4,324; female
17,407) (July 1998 est.)
Population growth rate: 0.52% (1998 est.)
Birth rate: 15.11 births/1,000 population (1998 est.)
Death rate: 6.97 deaths/1 ,000 population (1 998 est.)
Net migration rate: -2.94 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.06 ma!e(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .02 male(s)/fema!e
65 years and over: 0.82 male(s)/female (1998 est.)
Infant mortality rate: 5.27 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.84 years
male: 76.76 years
female: 81 .05 years (1 998 est.)
Total fertility rate: 2.04 children born/woman
(1998 est.)
Nationality:
noun: lcelander(s)
adjective: Icelandic
Ethnic groups: homogeneous mixture of
descendants of Norwegians and Celts
Religions: Evangelical Lutheran 96%, other
Protestant and Roman Catholic 3%, none 1% (1988)
Languages: Icelandic
Literacy:
definition: age 15 and over can read and write
total population: 100% (1976 est.)
male: NA%
female: NA%
Population: no permanent inhabitants
note: there are personnel who operate the Long
Range Navigation (Loran) C base and the weather
and coastal services radio station','00a3b367f982569b0ce110a18b0ac1c53b8339a81d0c732171ba1746184a8d75','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85cf860d6b4cc3aab3d8099a84b13426f3c8f7e67ad622dd3d2254dfae437727',1998,'IN','India','people-and-society',494,'Population: 984,003,683 (July 1998 est.)
Age structure:
0-14 years: 34% (male 174,578,403; female
164,755,937)
15-64 years: 61% (male 310,995,355; female
288,344,336)
65 years and over: 5% (male 23,051 ,278; female
22,278,374) (July 1998 est.)
Population growth rate: 1 .71% (1998 est.)
Birth rate: 25.91 births/1 ,000 population (1998 est.)
Death rate: 8.69 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.08 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/fema!e
under 15 years: 1.06 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 1 .04 male(s)/female (1 998 est.)
Infant mortality rate: 63.14 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 62.9 years
male: 62.11 years
female: 63.73 years (1 998 est.)
Total fertility rate: 3.24 children born/woman
(1998 est.)
Nationality:
noun: Indian(s)
adjective: Indian
Ethnic groups: Indo-Aryan 72%, Dravidian 25%,
Mongoloid and other 3%
Religions: Hindu 80%, Muslim 14%, Christian 2.4%,
Sikh 2%, Buddhist 0.7%, Jains 0.5%, other 0.4%
Languages: English enjoys associate status but is
the most important language for national, political, and
commercial communication, Hindi the national
language and primary tongue of 30% of the people,
Bengali (official), Telugu (official), Marathi (official),
218
Tamil (official), Urdu (official), Gujarati (official),
Malayalam (official), Kannada (official), Oriya
(official), Punjabi (official), Assamese (official),
Kashmiri (official), Sindhi (official), Sanskrit (official),
Hindustani a popular variant of Hindu/Urdu, is spoken
widely throughout northern India
note: 24 languages each spoken by a million or more
persons; numerous other languages and dialects, for
the most part mutually unintelligible
Literacy:
definition: age 15 and over can read and write
total population: 52%
male: 65.5%
female: 37.7% (1995 est.)','ce7a0024a09399dc74a0a4a1a908f8122b6854603b275f37d4506b1ce5efca3c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6264c94477bae139cd6fb1243bb9e4a7b0e7080b04e678e47c1dbc6a233d28bf',1998,'IE','Ireland','people-and-society',501,'Population: 3,619,480 (July 1998 est.)
Age structure:
0-14 years: 22% (male 406,741 ; female 384,459)
15-64 years: 67% (male 1,218,514; female
1,200,214)
65 years and over: 1 1 % (male 1 73,978; female
235,574) (July 1998 est.)
Population growth rate: 0.36% (1998 est.)
Birth rate: 13.49 births/1,000 population (1998 est)
Death rate: 8.51 deaths/1 ,000 population (1 998 est.)
Net migration rate: -1.39 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.74 male(s)/female (1998 est.)
Infant mortality rate: 6.04 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population : 76.1 9 years
male: 73.44 years
female: 79.1 1 years (1 998 est.)
Total fertility rate: 1 .82 children born/woman
(1998 est.)
Nationality:
noun: Irishman(men), Irishwoman(men), Irish
(collective plural)
adjective: Irish
Ethnic groups: Celtic, English
Religions: Roman Catholic 93%, Anglican 3%, none
1%, unknown 2%, other 1% (1981)
Languages: Irish (Gaelic), spoken mainly in areas
located along the western seaboard, English is the
language generally used
Literacy:
definition: age 15 and over can read and write
total population: 98% (1981 est.)
male: NA%
female: NA%
Population: 5,643,966 (July 1998 est.)
note: includes 155,000 Israeli settlers in the West
Bank, 17,000 in the Israeli-occupied Golan Heights,
6,000 in the Gaza Strip, and 164,000 in East
Jerusalem (August 1997 est.)
Age structure:
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female (1 998 est.)
Infant mortality rate: 8.02 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population:7BA1 years
male: 76.52 years
female: 80.39 years (1998 est.)
Total fertility rate: 2.71 children born/woman
(1998 est.)
Nationality:
noun : Israeli(s)
adjective: Israeli
Ethnic groups: Jewish 82% (Israel-born 50%,
Europe/Americas/Oceania-born 20%, Africa-born 7%,
Asia-born 5%), non-Jewish 18% (mostly Arab)
(1993 est.)
Religions: Judaism 82%, Islam 14% (mostly Sunni
Muslim), Christian 2%, Druze and other 2%
Languages: Hebrew (official), Arabic used officially
for Arab minority, English most commonly used
foreign language
Literacy:
definition: age 15 and over can read and write
total population: 95%
male: 97%
female: 93% (1992 est.)','829db3e8d2164c218f0c0b31c093adb11fc72c067415f2f10271091404661bee','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec049df0ddc3ea88a65367513ac2e38c524caccfe05f73d8d32667a060d861f2',1998,'TN','Tunisia','people-and-society',510,'Population: 56,782,748 (July 1998 est.)
Age structure:
0-14 years: 14% (male 4,192,662; female 3,955,857)
15-64 years: 68% (male 19,265,714; female
19,369,554)
65 years and over: 1 8% (male 4,098,526; female
5,900,435) (July 1998 est.)
Population growth rate: -0.08% (1998 est.)
Birth rate: 9.13 births/1,000 population (1998 est.)
Death rate: 10.18 deaths/1 ,000 population
(1998 est.)
Net migration rate: 0.21 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.06 ma!e(s)/fema!e
under 15 years: 1.06 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.69 male(s)/female (1998 est.)
Infant mortality rate: 6.4 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.38 years
male: 75.26 years
female: 81.7 years (1 998 est.)
Total fertility rate: 1.19 children born/woman
(1998 est.)
Nationality:
noun: Italian(s)
adjective: Italian
Ethnic groups: Italian (includes small clusters of
German-, French-, and Slovene-ltalians in the north
and Albanian-ltalians and Greek-ltalians in the south)
Religions: Roman Catholic 98%, other 2%
Languages: Italian, German (parts of Trentino-Alto
Adige region are predominantly German speaking),
French (small French-speaking minority in Valle
d''Aosta region), Slovene (Slovene-speaking minority
in the Trieste-Gorizia area)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 96% (1990 est.)
Population: 9,380,404 (July 1998 est.)
Age structure:
0-14 years: 32% (male 1 ,526,743; female 1 ,433,503)
15-64 years: 63% (male 2,933,487; female
2,947,189)
65 years and over: 5% (male 275,41 1 ; female
264,071) (July 1998 est.)
Population growth rate: 1 .43% (1 998 est.)
Birth rate: 20.07 births/1,000 population (1998 est.)
Death rate: 5.06 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.73 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 1 .04 male(s)/female (1 998 est.)
Infant mortality rate: 32.64 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 73.1 years
male: 71 .72 years
female: 74.58 years (1998 est.)
Total fertility rate: 2.44 children born/woman (1998
est.)
Nationality:
noun:Tunisian(s)
adjective: Tunisian
Ethnic groups: Arab 98%, European 1%, Jewish
and other 1%
Religions: Muslim 98%, Christian 1%, Jewish 1%
Languages: Arabic (official and one of the
languages of commerce), French (commerce)
470
Literacy:
definition: age 15 and over can read and write
total population: 66.7%
male: 78.6%
female: 54.6% (1995 est.)
Population: 64,566,511 (July 1998 est.)
Age structure:
0-14 years: 31% (male 10,165,804; female
9,802,232)
15-64 years : 63% (male 20,790,422; female
20,106,320)
65 years and over: 6% (male 1 ,706,939; female
1,994,794) (July 1998 est.)
Population growth rate: 1 .6% (1998 est.)
Birth rate: 21 .38 births/1 ,000 population (1 998 est.)
Death rate: 5.35 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years : 1 .03 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.85 ma!e(s)/fema!e (1 998 est.)
Infant mortality rate: 38.27 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 72.82 years
472
male: 70.38 years
female: 75.39 years (1998 est.)
Total fertility rate: 2.47 children born/woman (1998
est.)
Nationality:
noun: Turk(s)
adjective: Turkish
Ethnic groups: Turkish 80%, Kurdish 20%
Religions: Muslim 99.8% (mostly Sunni), other 0.2%
(Christian and Jews)
Languages: Turkish (official), Kurdish, Arabic
Literacy:
definition: age 15 and over can read and write
total population: 82.3%
male: 91 .7%
female: 72.4% (1995 est.)
Population: 4,297,629 (July 1998 est.)
Age structure:
0-14 years: 39% (male 843,839; female 813,837)
15-64 years : 57% (male 1 ,21 1 ,477; female
1,249,085)
65 years and over: 4% (male 67,842; female
111,549) (July 1998 est.)
Population growth rate: 1 .6% (1 998 est.)
Birth rate: 26.24 births/1 ,000 population (1998 est.)
Death rate: 8.7 deaths/1,000 population (1998 est.)
Net migration rate: -1 .58 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1 .03 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.6 ma!e(s)/female (1 998 est.)
Infant mortality rate: 72.89 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 61 .3 years
male: 57.68 years
female: 65.11 years (1998 est.)
Total fertility rate: 3.26 children born/woman (1 998
est.)
Nationality:
Religions: Muslim 89%, Eastern Orthodox 9%,
unknown 2%
Languages: Turkmen 72%, Russian 12%, Uzbek
9%, other 7%
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)','7b97b1578e164051ea27e4bc19d676393644dda93e7ba2a9b49d1796bc0ab45b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33176bf8598d33215595f09720c64120549a12e83d3905462ba514a1f660bc03',1998,'JM','Jamaica','people-and-society',519,'Population: 2,634,678 (July 1998 est)
Age structure:
0-14 years: 32% (male 425,233; female 406,529)
15-64 years: 62% (male 806,846; female 817,145)
65 years and over: 6% (male 79,125; female 99,800)
(July 1998 est.)
Population growth rate: 0.7% (1998 est.)
Birth rate: 20.91 births/1 ,000 population (1998 est.)
Death rate: 5.45 deaths/1 ,000 population (1 998 est.)
Net migration rate: -8.45 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/fema!e
65 years and over: 0.79 male(s)/female (1 998 est.)
Infant mortality rate: 1 4.47 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.37 years
male: 73.01 years
female: 77.84 years (1998 est.)
Total fertility rate: 2.33 children born/woman
(1998 est.)
Nationality:
/70un:Jamaican(s)
adjective: Jamaican
Ethnic groups: black 90.4%, East Indian 1 .3%,
white 0.2%, Chinese 0.2%, mixed 7.3%, other 0.6%
236
Religions: Protestant 61 .3% (Church of God 21 .2%,
Baptist 8.8%, Anglican 5.5%, Seventh-Day Adventist
9%, Pentecostal 7.6%, Methodist 2.7%, United
Church 2.7%, Brethren 1 .1%, Jehovah''s Witness
1.6%, Moravian 1.1%), Roman Catholic 4%, other,
including some spiritual cults 34.7%
Languages: English, Creole
Literacy:
definition: age 15 and over has ever attended school
total population: 85%
male: 80.8%
female: 89.1% (1995 est.)','79c5d3a8e0db8b921a75f8756ba45db3e41a1e7f443f51b6ceaa28343c3d7d67','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f15cb7526a0f7bf178a05e314771d23328146469011de851ecd7c6558a22608',1998,'KE','Kenya','people-and-society',534,'Population: 28,337,071 (July 1998 est.)
Age structure:
0-14 years: 44% (male 6,248,260; female 6,109,443)
15-64 years: 54% (male 7,609,631 ; female
7,607,810)
65 years and over: 2% (male 333,881 ; female
428,046) (July 1998 est.)
Population growth rate: 1 .71 % (1 998 est.)
Birth rate: 31 .68 births/1 ,000 population (1 998 est.)
Death rate: 14.19 deaths/1 ,000 population
(1998 est.)
Net migration rate: >0.35 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.03 male(s)/fema!e
under 15 years: 1.02 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.78 male(s)/female (1998 est.)
Infant mortality rate: 59.38 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 47.57 years
male: 47.02 years
female: 48.13 years (1998 est.)
Total fertility rate: 4.07 children born/woman
(1998 est.)
Nationality:
noun: Kenyan(s)
adjective: Kenyan
Ethnic groups: Kikuyu 22%, Luhya 14%, Luo 13%,
Kalenjin 12%, Kamba 11%, Kisii 6%, Meru 6%, other
African 15%, non-African (Asian, European, and
Arab) 1%
Religions: Protestant (including Anglican) 38%,
Roman Catholic 28%, indigenous beliefs 26%, Muslim
6%, other 2%
Languages: English (official), Swahili (official),
numerous indigenous languages
Literacy:
definition: age 1 5 and over can read and write
total population: 78.1%
male: 86.3%
female: 70% (1995 est.)','b8ee16496ba839fb4fb268a86126dd8913e3691e35afdc70f14f359865b1d881','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('671788753ad41a0d1a3184f320ce627328da970594f9a74a0eda7b3c2b06e9bd',1998,'WS','Samoa','people-and-society',542,'Population: uninhabited
Population: uninhabited
Population: 2,735,943 (July 1998 est.)
Age structure:
0-14 years: 32% (male 446,001 ; female 428,532)
15-64 years: 62% (male 864,382; female 841 ,870)
65 years and over: 6% (male 74,529; female 80,629)
(July 1998 est.)
Population growth rate: 1 .56% (1 998 est.)
Birth rate: 21 .99 births/1 ,000 population (1 998 est.)
Death rate: 5.1 4 deaths/1 ,000 population (1998 est.)
Net migration rate: -1 .28 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.04 ma!e(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.92 male(s)/female (1998 est.)
Infant mortality rate: 24 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 74 .47 years
male: 71 .73 years
female: 77.31 years (1998 est.)
Total fertility rate: 2.57 children born/woman (1998
est.)
Nationality:
noun: Panamanian(s)
adjective: Panamanian
Ethnic groups: mestizo (mixed Amerindian and
white) 70%, Amerindian and mixed (West Indian)
14%, white 10%, Amerindian 6%
Religions: Roman Catholic 85%, Protestant 15%
Languages: Spanish (official), English 14%
note: many Panamanians bilingual
Literacy:
definition: age 15 and over can read and write
total population: 90.8%
male : 91 .4%
female: 90.2% (1995 est.)','6a2354f0159d35973bd1c2944e1e601e16bdaece3f8c1be008f0bad15ccd1a0c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e54a139d2789ac1580a3a9d4e152f6931575db88f446185c40ada95512d4437',1998,'KI','Kiribati','people-and-society',550,'Population: 83,976 (July 1998 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1.82% (1998 est.)
Birth rate: 26.46 births/1 ,000 population (1 998 est.)
Death rate: 7.62 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.66 migrant(s)/1 ,000
population (1998 est.)
Infant mortality rate: 49.69 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 62.61 years
male: 60.79 years
female : 64.68 years (1998 est.)
Total fertility rate: 3.13 children born/woman
(1998 est.)
Nationality:
noun: l-Kiribati (singular and plural)
adjective: l-Kiribati
Ethnic groups: Micronesian
Religions: Roman Catholic 53%, Protestant
(Congregational) 41%, Seventh-Day Adventist,
Baha''i, Church of God, Mormon 6% (1985 est.)
Languages: English (official), Gilbertese
Literacy: NA
Population: 21,234,387 (July 1998 est.)
Age structure:
0-14 years: 26% (male 2,800,857; female 2,669,250)
15-64 years: 68% (male 7,089,039; female
7,406,901)
65 years and over: 6% (male 387,01 1 ; female
881,329) (July 1998 est.)
Population growth rate: -0.03% (1998 est.)
Birth rate: 15.3 births/1,000 population (1998 est.)
Death rate: 1 5.57 deaths/1 ,000 population
(1998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 ma!e(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.44 male(s)/female (1998 est.)
Infant mortality rate: 87.83 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 51 .32 years
male: 48.88 years
female: 53.88 years (1998 est.)
Total fertility rate: 1 .6 children born/woman
(1998 est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: racially homogeneous; there is a
small Chinese community and a few ethnic Japanese
Religions: Buddhism and Confucianism, some
Christianity and syncretic Chondogyo
note: autonomous religious activities now almost
nonexistent; government-sponsored religious groups
exist to provide illusion of religious freedom
Languages: Korean
Population: 46,416,796 (July 1998 est.)
Age structure:
0-14 years: 22% (male 5,505,564; female 4,894,780)
15-64 years: 71 % (male 1 6,772,31 9; female
16,272,145)
65 years and over 7% (male 1,126,963; female
1,845,025) (July 1998 est.)
Population growth rate: 1.01% (1998 est.)
Birth rate: 16.08 births/1,000 population (1998 est.)
Death rate: 5.67 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.31 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.14 male(s)/female
under 15 years: 1.12 male(s)/fema!e
15-64 years: 1 .03 ma!e(s)/female
65 years and over: 0.61 male(s)/female (1 998 est.)
Infant mortality rate: 7.79 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 73.95 years
male: 70.37 years
female: 78 years (1998 est.)
Total fertility rate: 1 .79 children born/woman
(1998 est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: homogeneous (except for about
20,000 Chinese)
Religions: Christianity 49%, Buddhism 47%,
Confucianism 3%, pervasive folk religion
(shamanism), Chondogyo (Religion of the Heavenly
Way), and other 1%
Languages: Korean, English widely taught in junior
high and high school
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 99.3%
female : 96.7% (1 995 est.)','36a5666ff88780a98e753af358b2144b780682a27712b9562ba03176cede6c4a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4de55a2e0a9bb94e76ad1825fd3abeda14da50832b86490f5b5a30435e54042b',1998,'KG','Kyrgyzstan','people-and-society',558,'Population: 4,522,281 (July 1998 est.)
Age structure:
0-14 years: 36% (male 817,229; female 800,248)
15-64 years: 58% (male 1 ,285,520; female
1,337,259)
65 years and over: 6% (male 1 04,1 05; female
177,920) (July 1998 est.)
Population growth rate: 0.37% (1998 est.)
Birth rate: 22.03 births/1 ,000 population (1998 est.)
Death rate: 8.65 deaths/1 ,000 population (1 998 est.)
Net migration rate: -9.72 migrant($)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.96 ma!e(s)/female
65 years and over: 0.58 male(s)/female (1998 est.)
Infant mortality rate: 74.76 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 63.77 years
male: 59.45 years
female: 68.3 years (1998 est.)
Total fertility rate: 2.68 children born/woman
(1998 est.)
Nationality:
noun: Kyrgyzstani(s)
adjective : Kyrgyzstan i
Ethnic groups: Kirghiz 52.4%, Russian 1 8%, Uzbek
12.9%, Ukrainian 2.5%, German 2.4%, other 11.8%
Religions: Muslim 75%, Russian Orthodox 20%,
other 5%
Languages: Kirghiz (Kyrgyz)— official language,
Russian— official language
note: in March 1996, the Kyrgyzstani legislature
amended the constitution to make Russian an official
language, along with Kirghiz, in territories and work
places where Russian-speaking citizens predominate
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 96% (1989 est.)
Population: 5,260,842 (July 1998 est.)
Age structure:
0-14 years: 45% (male 1,205,210; female 1,174,323)
15-64 years: 52% (male 1 ,31 8,061 ; female
1,393,386)
65 years and over: 3% (male 77,388; female 92,474)
(July 1998 est.)
Population growth rate: 2.76% (1998 est.)
Birth rate: 40.58 births/1 ,000 population (1 998 est.)
Death rate: 12.97 deaths/1 ,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/fema!e
15-64 years: 0.95 maie(s)/female
65 years and over: 0.84 male(s)/female (1 998 est.)
Infant mortality rate: 91 .81 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 53.7 years
male: 52.1 3 years
female : 55.34 years (1998 est.)
Total fertility rate: 5.66 children born/woman
(1998 est.)
Nationality:
noun: Lao(s) or Laotian(s)
adjective: Lao or Laotian
Ethnic groups: Lao Loum (lowland) 68%, Lao
Theung (upland) 22%, Lao Soung (highland) including
the Hmong ("Meo") and the Yao (Mien) 9%, ethnic
Vietnamese/Chinese 1%
Religions: Buddhist 60%, animist and other 40%
Languages: Lao (official), French, English, and
various ethnic languages
Literacy:
definition: age 15 and over can read and write
total population: 56.6%
male: 69.4%
female; 44.4% (1995 est.)','7a56ee511ec02f73e32bd5abcc0621d3bd656fa28a6324f821366613ddc3b483','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fc69ea5cab0bf231aa0334736ed492df7438765dfb45136de1ee80165fbbef8',1998,'LV','Latvia','people-and-society',566,'Population: 2,385,396 (July 1998 est.)
Age structure:
0-14 years: 19% (male 227,634; female 218,321)
15-64 years: 66% (male 754,416; female 829,801)
65 years and over: 1 5% (male 1 1 3,925; female
241,299) (July 1998 est.)
Population growth rate: -1 .41 % (1 998 est.)
Birth rate: 8.14 births/1,000 population (1998 est.)
Death rate: 15.78 deaths/1 ,000 population (1998
est.)
Net migration rate: -6.47 migrant(s)/1,000
population (1998 est.)
Sex ratio:
at birth : 1 .05 male(s)/female
under 15 years: 1.04 male(s)/fema!e
15-64 years: 0.9 male(s)/female
65 years and over: 0.47 male(s)/female (1998 est.)
Infant mortality rate: 1 7.44 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 67.11 years
male: 61.02 years
female: 73.5 years (1 998 est.)
Total fertility rate: 1 .2 children born/woman
(1998 est.)
Nationality:
noun: Latvian(s)
adjective: Latvian
Ethnic groups: Latvian 56.5%, Russian 30.4%,
Byelorussian 4.3%, Ukrainian 2.8%, Polish 2.6%,
other 3.4%
Religions: Lutheran, Roman Catholic, Russian
Orthodox
266
Languages: Lettish (official), Lithuanian, Russian,
other
Literacy:
definition : age 1 5 and over can read and write
total population: 100%
male: 100%
female: 99% (1989 est.)','94f4c96a4c64b71d734d50c10b94c5ebd532496abe9bf3180166e9b38fa7a8d4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e276ede78e946f0e60ba42e1243b87d72250c6d52b434018bbc96fa22f8489e',1998,'ZA','South Africa','people-and-society',579,'Population: 2,771,901 (July 1998 est.)
Age structure:
0-14 years: 45% (male 622,797; female 616,902)
15-64 years: 52% (male 734,425; female 700,1 24)
65 years and over: 3% (male 47,099; female 50,554)
(July 1998 est.)
Population growth rate: 5.76% (1998 est.)
Birth rate: 41 .88 births/1 ,000 population (1 998 est.)
Death rate: 1 1 .28 deaths/1 ,000 population (1 998
est.)
Net migration rate: 27.02 migrant(s)/1 ,000
population (1998 est.)
note: until domestic peace is restored, many Liberian
refugees will not return from exile
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.93 male(s)/female (1998 est.)
Infant mortality rate: 103.13 deaths/1,000 live
births (1998 est.)
Life expectancy at birth:
total population: 59.45 years
male : 56.81 years
female: 62.1 6 years (1 998 est.)
Total fertility rate: 6.09 children born/woman (1998
est.)
Nationality:
noun: Liberian(s)
adjective: Liberian
Ethnic groups: indigenous African tribes 95%
(including Kpelle, Bassa, Gio, Kru, Grebo, Mano,
Krahn, Gola, Gbandi, Loma, Kissi, Vai, and Bella),
Americo-Liberians 2.5% (descendants of immigrants
from the US who had been slaves)
Religions: traditional 70%, Muslim 20%, Christian
10%
Languages: English 20% (official), about 20 tribal
languages, of which a few can be written and are used
in correspondence
Literacy:
definition: age 1 5 and over can read and write
total population: 38.3%
male: 53.9%
female: 22.4% (1 995 est.)','337afb45273989463bdb42f2466bf5db18cd1cc0a0746852d50d7c347a184830','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2536c7971371859b9d5591fc4658b8dd7502215102825710b4fe89f9ef831feb',1998,'LY','Libya','people-and-society',581,'Population: 5,690,727 (July 1998 est.)
note: includes 144,363 non-nationals (July 1998 est.)
Age structure:
0-14 years: 48% (male 1 ,399,354; female 1 ,351 ,442)
15-64 years: 49% (male 1 ,412,067; female
1,361,372)
65 years and over: 3% (male 81 ,71 1 ; female 84,781 )
(July 1998 est.)
Population growth rate: 3.68% (1998 est.)
Birth rate: 43.95 births/1,000 population (1998 est.)
Death rate: 7.1 5 deaths/1 ,000 population (1998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.96 male(s)/female (1 998 est.)
Infant mortality rate: 55.81 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population : 65.44 years
male: 63.21 years
female: 67.78 years (1998 est.)
Total fertility rate: 6.18 children born/woman (1998
est.)
Nationality:
noun: Libyan(s)
adjective: Libyan
Ethnic groups: Berber and Arab 97%, Greeks,
Maltese, Italians, Egyptians, Pakistanis, Turks,
Indians, Tunisians
Religions: Sunni Muslim 97%
Languages: Arabic, Italian, English, all are widely
understood in the major cities
Literacy:
definition: age 1 5 and over can read and write
total population: 76.2%
male: 87.9%
female: 63% (1995 est.)','799a5c494131c12d8a51d796150f8a54a1d1f1d8fbc70908a37bec89c793d558','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a98118be3d805dbdce6c0ea9174438397a2838aabfcc22afe22b987635af3a94',1998,'CH','Switzerland','people-and-society',589,'Population: 31,717 (July 1998 est.)
Age structure:
0-14 years: 19% (male 3,058; female 2,926)
15-64 years: 70% (male 1 1 ,084; female 1 1 ,1 54)
65 years and over: 1 1 % (male 1 ,442; female 2,053)
(July 1998 est.)
Population growth rate: 1 .05% (1 998 est.)
Birth rate: 12.64 births/1 ,000 population (1998 est.)
Death rate: 7.31 deaths/1 ,000 population (1 998 est.)
Net migration rate: 5.2 migrant(s)/1,000 population
(1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/fema!e
65 years and over: 0.7 male(s)/female (1 998 est.)
Infant mortality rate: 5.28 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 77.96 years
male: 75.51 years
female : 80.52 years (1998 est.)
Total fertility rate: 1.61 children born/woman (1998
est.)
Nationality:
noun: Liechtensteiner(s)
adjective: Liechtenstein
Ethnic groups: Alemannic 87.5%, Italian, Turkish,
and other 12.5%
Religions: Roman Catholic 80%, Protestant 7.4%,
unknown 7.7%, other 4.9% (1996)
Languages: German (official), Alemannic dialect
Literacy:
definition: age 1 0 and over can read and write
total population: 100%
male: 100%
female: 100% (1981 est.)
Population: 3,600,158 (July 1998 est.)
Age structure:
0-14 years: 20% (male 376,034; female 360,446)
15-64 years: 67% (male 1 ,155,733; female
1,238,671)
65 years and over: 1 3% (male 1 59,526; female
309,748) (July 1998 est.)
Population growth rate: -0.45% (1998 est.)
Birth rate: 1 0.57 births/1 ,000 population (1 998 est.)
Death rate: 1 2.94 deaths/1 ,000 population (1 998
est.)
Net migration rate: -2.09 migrant(s)/1,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/femaie
under 15 years: 1 .04 male(s)/female
15-64 years: 0.93 ma!e(s)/female
65 years and over: 0.52 male(s)/female (1 998 est.)
Infant mortality rate: 14.75 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 68.83 years
male: 62.76 years
female: 75.21 years (1998 est.)
Total fertility rate: 1 .46 children born/woman (1 998
est.)
Nationality:
noun: Lithuanian(s)
adjective: Lithuanian
Ethnic groups: Lithuanian 80.6%, Russian 8.7%,
Polish 7%, Byelorussian 1.6%, other 2.1%
Religions: primarily Roman Catholic, others include
Lutheran, Russian Orthodox, Protestant, evangelical
Christian Baptist, Islam, Judaism
Languages: Lithuanian (official), Polish, Russian
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
fema/e:98%(1989 est.)','363f3f696533024cd830658d63f102059a75ce0723d07d9994bce0b56c2fca9a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bde38824e84c82422c2cd0da68437500b733995b7020b581c26581a39df2771',1998,'MW','Malawi','people-and-society',599,'Population: 9,840,474 (July 1998 est.)
Age structure:
0-14 years: 46% (male 2,249,108; female 2,228,934)
15-64 years: 52% (male 2,512,768; female
2,584,516)
65 years and over: 2% (male 1 1 1 ,089; female
154,059) (July 1998 est.)
Population growth rate: 1 .66% (1998 est.)
Birth rate: 40.22 births/1,000 population (1998 est.)
Death rate: 23.68 deaths/1 ,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/femaie
65 years and over: 0.72 male(s)/female (1 998 est.)
Infant mortality rate: 1 33.77 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 36.59 years
male: 36.64 years
female: 36.54 years (1998 est.)
Total fertility rate: 5.62 children born/woman (1998
est.)
Nationality:
noun: Malawian(s)
adjective: Malawian
Ethnic groups: Chewa, Nyanja, Tumbuko, Yao,
Lomwe, Sena, Tonga, Ngoni, Ngonde, Asian,
European
Religions: Protestant 55%, Roman Catholic 20%,
Muslim 20%, traditional indigenous beliefs
Languages: English (official), Chichewa (official),
other languages important regionally
Literacy:
definition: age 15 and over can read and write
total population: 56.4%
mate; 71 .9%
female: 41.8% (1995 est.)','7e550d5dcc013e934cd2b7b443c369ac72b0a5ac2d32e64c8d3802cb13cb5fd2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0da77931da4bbe5b8c13112d18cc8a3bad791dfed66701e11335e974f4acbd9a',1998,'MV','Maldives','people-and-society',609,'Population: 290,211 (July 1998 est.)
Age structure:
0-14 years: 47% (male 70,244; female 66,758)
15-64 years: 50% (male 73,784; female 70,539)
65 years and over: 3% (male 4,735; female 4,151)
(July 1998 est.)
Population growth rate: 3.42% (1998 est.)
Birth rate: 40.12 births/1,000 population (1998 est.)
Death rate: 5.96 deaths/1 ,000 population (1998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 1.14 male(s)/female (1 998 est.)
Infant mortality rate: 41 .1 2 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 67.57 years
male : 65.87 years
female: 69.35 years (1998 est.)
Total fertility rate: 5.84 children born/woman (1998
est.)
Nationality:
noun: Maldivian(s)
adjective: Maldivian
Ethnic groups: Sinhalese, Dravidian, Arab, African
Religions: Sunni Muslim
Languages: Maldivian Divehi (dialect of Sinhala,
script derived from Arabic), English spoken by most
government officials
Literacy:
definition : age 15 and over can read and write
total population: 93.2%
male: 93.3%
female: 93% (1995 est.)
Population: 379,563 (July 1998 est.)
Age structure:
0-14 years: 21% (male 40,655; female 38,425)
15-64 years: 68% (male 128,958; female 127,391)
65 years and over: 11% (male 18,629; female
25,505) (July 1998 est.)
Population growth rate: 0.58% (1998 est.)
Birth rate: 1 1 .73 births/1 ,000 population (1 998 est.)
Death rate: 7.35 deaths/1 ,000 population (1998 est.)
Net migration rate: 1 .45 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.73 male(s)/female (1 998 est.)
Infant mortality rate: 7.57 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 77.6 years
male: 75.3 years
female: 80.05 years (1998 est.)
Total fertility rate: 1.73 children born/woman (1998
est.)
Nationality:
noun: Maltese (singular and plural)
adjective: Maltese
Ethnic groups: Maltese (descendants of ancient
Carthaginians and Phoenicians, with strong elements
of Italian and other Mediterranean stock)
Religions: Roman Catholic 98%
Languages: Maltese (official), English (official)
Literacy:
definition: age 1 0 and over can read and write
total population: 88%
male: 88%
female: 88% (1985)
Population: 75,121 (July 1998 est.)
Age structure:
0-14 years: 18% (male 6,790; female 6,510)
15-64 years: 65% (male 24,466; female 24,366)
65 years and over: 17% (male 5,168; female 7,821)
(July 1998 est.)
Population growth rate: 0.79% (1998 est.)
Birth rate: 1 2.49 births/1 ,000 population (1 998 est.)
Death rate: 1 1 .69 deaths/1 ,000 population (1 998
est.)
Net migration rate: 7.1 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.66 male(s)/female (1 998 est.)
Infant mortality rate: 2.42 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 77.57 years
male: 74.04 years
female: 81 .28 years (1998 est.)
Total fertility rate: 1.67 children born/woman (1998
est.)
Nationality:
noun: Manxman, Manxwoman
adjective: Manx
Ethnic groups: Manx (Norse-Celtic descent), Briton
Religions: Anglican, Roman Catholic, Methodist,
Baptist, Presbyterian, Society of Friends
Languages: English, Manx Gaelic
Literacy: NA','3be8d961d1824b1ce15e1a762a05e50db320a599125e74f4a5864d7ab3740ee6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('116ec82dc379ffbcc82f61d50e6389c1ae7eb2a7e2685c2af61ad82a0f43cb97',1998,'MH','Marshall Islands','people-and-society',615,'Population: 63,031 (July 1998 est.)
Age structure:
0-1 4 years: 50% (male 16,073; female 15,432)
15-64 years: 48% (male 15,408; female 14,695)
65 years and over: 2% (male 669; female 754) (July
1998 est.)
Population growth rate: 3.85% (1998 est.)
Birth rate: 45.39 births/1 ,000 population (1998 est.)
Death rate: 6.9 deaths/1,000 population (1998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 ma!e(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.89 male(s)/female (1 998 est.)
Infant mortality rate: 44.54 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 64.48 years
male: 62.89 years
female: 66.14 years (1998 est.)
Total fertility rate: 6.72 children born/woman (1998
est.)
Nationality:
noun: Marshallese (singular and plural)
adjective: Marshallese
Ethnic groups: Micronesian
Religions: Christian (mostly Protestant)
Languages: English (universally spoken and is the
official language), two major Marshallese dialects
from the Malayo-Polynesian family, Japanese
Literacy:
definition: age 1 5 and over can read and write
total population: 93%
ma/e:100%
female: 88% (1980 est.)
Population: 407,284 (July 1998 est.).
Age structure:
0-14 years: 23% (male 47,431 ; female 46,457)
15-64 years: 67% (male 134,738; female 137,818)
65 years and over: 10% (male 17,216; female
23,624) (July 1998 est.)
Population growth rate: 1 .05% (1 998 est.)
Birth rate: 16.52 births/1,000 population (1998 est.)
Death rate: 5.91 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.09 migrant(s)/1,000
population (1998 est.)
Sex ratio:
at birth: 1 .02 male(s)/fema!e
under 15 years: 1 .02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.73 male(s)/female (1 998 est.)
Infant mortality rate: 6.89 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 79.1 3 years
male: 76.34 years
female: 81 .98 years (1 998 est.)
Total fertility rate: 1 .8 children born/woman (1 998
est.)
Nationality:
noun: Martiniquais (singular and plural)
adjective: Martiniquais
Ethnic groups: African and African-white-lndian
mixture 90%, white 5%, East Indian, Lebanese,
Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan
African 5%
Languages: French, Creole patois
Literacy:
definition: age 1 5 and over can read and write
total population: 93%
male : 92%
female: 93% (1982 est.)','de57dd63d70c92e172bc88217c9e07e835b83895fb04b4813318811cc2ac1445','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d80c2cb0a77b99a434195751ef5949581e0734f1509695b6cd833c5abdcdbe6c',1998,'MU','Mauritius','people-and-society',627,'Population: 1,168,256 (July 1998 est.)
Age structure:
0-14 years: 26% (male 155,917; female 152,563)
15-64 years: 68% (male 393,330; female 397,285)
65 years and over: 6% (male 28,092; female 41 ,069)
(July 1998 est.)
Population growth rate: 1.2% (1998 est.)
Birth rate: 1 8.64 births/1 ,000 population (1 998 est.)
Death rate: 6.69 deaths/1 ,000 population (1998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.68 male(s)/female (1998 est.)
Infant mortality rate: 16.54 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 70.9 years
male: 67.05 years
femaie: 74.74 years (1998 est.)
Total fertility rate: 2.22 children born/woman (1998
est.)
Nationality:
noun: Mauritian(s)
adjective: Mauritian
Ethnic groups: Indo-Mauritian 68%, Creole 27%,
Sino-Mauritian 3%, Franco-Mauritian 2%
Religions: Hindu 52%, Christian 28.3% (Roman
Catholic 26%, Protestant 2.3%), Muslim 16.6%, other
3.1%
Languages: English (official), Creole, French, Hindi,
Urdu, Hakka, Bojpoori
Literacy:
definition: age 1 5 and over can read and write
total population: 82.9%
male: 87 A%
female: 78.8% (1995 est.)','106a49ab2c46aa3a4d3038a391a8b69ecf6260f96e4f977f503f69beb8991304','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ca59a8915853bac52145c27e72a777299bdbcd9da6d0f297606c5601e1265bc',1998,'YT','Mayotte','people-and-society',636,'Population: 1 41 ,944 (July 1 998 est.)
Age structure:
0-14 years: 46% (male 33,067; female 33,016)
15-64 years: 52% (male 40,009; female 33,380)
65 years and over: 2% (male 1 ,214; female 1 ,258)
(July 1998 est.)
Population growth rate: 5.16% (1998 est.)
Birth rate: 46.96 births/1,000 population (1998 est.)
Death rate: 9.22 deaths/1 ,000 population (1998 est.)
Net migration rate: 13.87 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/fema!e
15-64 years: 1 .2 male(s)/female
65 years and over: 0.96 male(s)/femaie (1998 est.)
Infant mortality rate: 71.13 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 59.58 years
male: 57.21 years
female: 62.02 years (1998 est.)
Total fertility rate: 6.48 children born/woman (1998
est.)
Nationality:
noun: Mahorais (singular and plural)
adjective: Mahoran
Ethnic groups: NA
Religions: Muslim 99%, Christian (mostly Roman
Catholic)
Languages: Mahorian (a Swahili dialect), French
Literacy: NA','933925d6b79fe5671e3494bd52095f183fd8f4022b4ce1f1836fd1a9c070635a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88a32e6b0811e0871e5588b1fc00bc6b8e799aa8b983c98cbee3420535b2b3ad',1998,'MS','Montserrat','people-and-society',644,'Population: 12,828 (July 1998 est.)
note: demographic figures include an estimated 8,000
refugees who left the island following the resumption
of volcanic activity in July 1995
Age structure:
0- 1 4 years: NA
15-64 years: NA
65 years and over: H A
Population growth rate: 0.23% (1998 est.)
Birth rate: 1 4.27 births/1 ,000 population (1 998 est.)
Death rate: 9.86 deaths/1 ,000 population (1 998 est.)
Net migration rate: -2.12 migrant(s)/1 ,000
population (1998 est.)
Infant mortality rate: 1 1 .91 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.6 years
male: 73.83 years
female: 77 A years (1998 est.)
Total fertility rate: 1 .83 children born/woman (1 998
est.)
Nationality:
noun: Montserratian(s)
adjective: Montserratian
Ethnic groups: black, white
Religions: Anglican, Methodist, Roman Catholic,
Pentecostal, Seventh-Day Adventist, other Christian
denominations
Languages: English
Literacy:
definition: age 1 5 and over has ever attended school
total population: 97%
male: 97%
female: 97% (1970 est.)','7d44d25fdea897c10d5fc24ef7abb24666febe261f2d82ecb8dcc2548a33702c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea535cfb3eda969d7bca6bad4c4c51bce690e89d7ffcd2e032ac82c83ebec6ae',1998,'GI','Gibraltar','people-and-society',651,'Population: 29,1 14,497 (July 1998 est.)
Age structure:
0-14 years: 36% (male 5,398,692; female 5,200,660)
15-64 years: 59% (male 8,525,344; female
8,682,277)
65 years and over: 5% (male 606,203; female
701,321) (July 1998 est.)
Population growth rate: 1 .89% (1 998 est.)
Birth rate: 26.37 births/1 ,000 population (1998 est.)
Death rate: 6.24 deaths/1 ,000 population (1 998 est.)
Net migration rate: -1.28 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1 .04 male(s)/female
15-64 years: 0.98 ma!e(s)/female
65 years and over: 0.86 ma!e(s)/female (1 998 est.)
Infant mortality rate: 52.99 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 68.51 years
male: 66.49 years
female: 70.64 years (1998 est.)
Total fertility rate: 3.35 children born/woman (1998
est.)
Nationality:
noun: Moroccan(s)
adjective: Moroccan
Ethnic groups: Arab-Berber 99.1%, other 0.7%,
Jewish 0.2%
Religions: Muslim 98.7%, Christian 1.1%, Jewish
0.2%
Languages: Arabic (official), Berber dialects, French
often the language of business, government, and
diplomacy
Literacy:
definition: age 15 and over can read and write
total population: 43.7%
male: 56.6%
female: 31% (1995 est.)','aa536b920a789b6f05ada64a206efc589c78bcc0b065bbec2635452e1173ddf7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('635e503f3a9b59bca4d03b5477085998d8824bb95c464158ec1880d2990eebec',1998,'NR','Nauru','people-and-society',658,'Population: 10,501 (July 1998 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1 .33% (1 998 est.)
Birth rate: 1 8.03 births/1 ,000 population (1 998 est.)
Death rate: 5.1 deaths/1,000 population (1998 est.)
Net migration rate: 0.4 migrant(s)/1 ,000 population
(1998 est.)
Infant mortality rate: 40.6 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 66.68 years
male: 64.3 years
female: 69 .18 years (1998 est.)
Total fertility rate: 2.08 children born/woman (1998
est.)
Nationality:
noun: Nauruan(s)
adjective: Nauruan
Ethnic groups: Nauruan 58%, other Pacific Islander
26%, Chinese 8%, European 8%
Religions: Christian (two-thirds Protestant, one-third
Roman Catholic)
Languages: Nauruan (official, a distinct Pacific
Island language), English widely understood, spoken,
and used for most government and commercial
purposes
Literacy: NA
Population: uninhabited
note: transient Haitian fishermen and others camp on
the island
Population: 23,698,421 (July 1998 est.)
Age structure:
0-14 years: 42% (male 5,087,855; female 4,779,941)
15-64 years: 55% (male 6,655,865; female
6,387,255)
65 years and over: 3% (male 392,141 ; female
395,364) (July 1998 est.)
Population growth rate: 2.52% (1998 est.)
Birth rate: 35.66 births/1 ,000 population (1998 est.)
Death rate: 10.44 deaths/1 ,000 population (1 998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.99 male(s)/female (1 998 est.)
Infant mortality rate: 75.98 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 57.89 years
male: 58.04 years
female: 57.74 years (1998 est.)
Total fertility rate: 4.87 children born/woman (1998
est.)
Nationality:
noun: Nepalese (singular and plural)
adjective: Nepalese
Ethnic groups: Newars, Indians, Tibetans,
Gurungs, Magars, Tamangs, Bhotias, Rais, Limbus,
Sherpas
Religions: Hindu 90%, Buddhist 5%, Muslim 3%,
other 2% (1981)
note: only official Hindu state in the world, although no
sharp distinction between many Hindu and Buddhist
groups
Languages: Nepali (official), 20 other languages
divided into numerous dialects
Literacy:
definition: age 15 and over can read and write
total population: 27.5%
male: 40.9%
female : 14% (1995 est.)
People— note: refugee issue over the presence in
Nepal of approximately 91,000 Bhutanese refugees,
90% of whom are in seven United Nations Office of
the High Commissioner for Refugees (UNHCR)
camps','0aedcf362117081dc5d3da8d2c33e84bb0cf6bb0aea07a1e7d8c1a4bbb2bf0aa','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aea5a56053821b00c23c1cd24108f42a900ca26d8533d6646f431e157a9d04f9',1998,'NL','Netherlands','people-and-society',666,'Population: 15,731,112 (July 1998 est.)
Age structure:
0-14 years: 18% (male 1,472,236; female 1,406,919)
15-64 years: 68% (male 5,457,225; female
5,268,376)
65 years and over: 1 4% (male 862,574; female
1,263,782) (July 1998 est.)
Population growth rate: 0.5% (1998 est.)
Birth rate: 1 1 .62 births/1 ,000 population (1 998 est.)
Death rate: 8.69 deaths/1 ,000 population (1 998 est.)
Net migration rate: 2.11 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 ma!e(s)/female
65 years and over: 0.68 male(s)/female (1 998 est.)
Infant mortality rate: 5.17 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.01 years
male: 75. 14 years
female: 81 .03 years (1 998 est.)
Total fertility rate: 1 .49 children born/woman (1 998
est.)
Nationality:
noun: Dutchman(men), Dutchwoman(women)
adjective: Dutch
Ethnic groups: Dutch 96%, Moroccans, Turks, and
other 4% (1988)
Religions: Roman Catholic 34%, Protestant 25%,
Muslim 3%, other 2%, unaffiliated 36% (1991)
Languages: Dutch
Literacy:
definition: age 15 and over can read and write
total population: 99% (1 979 est.)
male: NA%
female: NA%
Population: 205,693 (July 1998 est.)
Age structure:
0-14 years: 26% (male 27,001 ; female 26,091)
15-64 years: 67% (male 64,964; female 72,329)
65 years and over: 7% (male 6,393; female 8,91 5)
(July 1998 est.)
Population growth rate: 1 .06% (1 998 est.)
Birth rate: 17.61 births/1 ,000 population (1998 est.)
Death rate: 6.63 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.43 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/fema!e
under 15 years: 1 .04 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.72 male(s)/fema!e (1 998 est.)
Infant mortality rate: 12.95 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 74.05 years
/7?a/e: 71 .99 years
female: 76.2 years (1998 est.)
Total fertility rate: 2.1 1 children born/woman (1998
est.)
Nationality:
noun: Netherlands Antiliean(s)
adjective: Netherlands Antillean
Ethnic groups: mixed black 85%, Carib Amerindian,
white, East Asian
Religions: Roman Catholic, Protestant, Jewish,
Seventh-Day Adventist
Languages: Dutch (official), Papiamento, a
Spanish-Portuguese-Dutch-English dialect
predominates, English widely spoken, Spanish
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 98%
female: 99% (1981 est.)','b066270312d032f964cb12d9412b67a3acb91c516585f1eb0b8be322bf1d7939','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd52ad5633978b9496f58e702796085ee1b74dd95b4a047e53c8419269e252bc',1998,'NZ','New Zealand','people-and-society',670,'Population: 3,625,388 (July 1998 est.)
Age structure:
0-14 years: 23% (male 427,776; female 407,074)
15-64 years: 65% (male 1 ,1 88,468; female
1,181,002)
65 years and over: 12% (male 1 82,253; female
238,815) (July 1998 est.)
Population growth rate: 1.04% (1998 est.)
Birth rate: 1 4.89 births/1 ,000 population (1 998 est.)
Death rate: 7.6 deaths/1 ,000 population (1998 est.)
Net migration rate: 3.06 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.76 male(s)/female (1 998 est.)
Infant mortality rate: 6.37 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 77.55 years
male: 74.35 years
female: 80.91 years (1998 est.)
Total fertility rate: 1 .91 children born/woman (1 998
est.)
Nationality:
noun: New Zealander(s)
adjective: New Zealand
Ethnic groups: New Zealand European 74.5%,
Maori 9.7%, other European 4.6%, Pacific Islander
3.8%, Asian and others 7.4%
Religions: Anglican 24%, Presbyterian 1 8%, Roman
Catholic 15%, Methodist 5%, Baptist 2%, other
Protestant 3%, unspecified or none 33% (1986)
Languages: English (official), Maori
340
Literacy:
definition: age 15 and over can read and write
total population: 99% (1 980 est.)
male: NA%
female: NA%
Population: 108,207 (July 1998 est.)
Age structure:
0-14 years: N A
15-64 years: NA
65 years and over: NA
Population growth rate: 0.81% (1998 est.)
Birth rate: 26.43 births/1,000 population (1998 est.)
Death rate: 6.07 deaths/1 ,000 population (1 998 est.)
Net migration rate: -1 .23 migrant(s)/1 ,000
population (1998 est.)
Infant mortality rate: 38.57 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population : 69.54 years
male : 67.51 years
female: 71 .96 years (1 998 est.)
Total fertility rate: 3.63 children born/woman (1998
est.)
Nationality:
noun: Tongan(s)
adjective: Tongan
Ethnic groups: Polynesian, Europeans about 300
Religions: Christian (Free Wesleyan Church claims
over 30,000 adherents)
Languages: Tongan, English
Literacy:
definition: can read and write Tongan and/or English
total population: 98.5%
male: 98.4%
female: 98.7% (1996 est.)
Population: 1,116,595 (July 1998 est.)
Age structure:
0-14 years: 28% (male 159,353; female 152,898)
15-64 years: 65% (male 375,889; female 347,115)
65 years and over: 7% (male 36,627; female 44,71 3)
(July 1998 est.)
Population growth rate: -1 .27% (1 998 est.)
Birth rate: 14.89 births/1,000 population (1998 est.)
Death rate: 8 deaths/1 ,000 population (1998 est.)
Net migration rate: -19.55 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 0.82 ma!e(s)/fema!e (1998 est.)
Infant mortality rate: 1 8.84 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 70.51 years
male: 68.06 years
female: 73.03 years (1998 est.)
Total fertility rate: 2.09 children born/woman (1998
est.)
Nationality:
noun: Trinidadian(s), Tobagonian(s)
adjective: Trinidadian, Tobagonian
Ethnic groups: black 40%, East Indian (a local
term— primarily immigrants from northern India)
40.3%, mixed 14%, white 1%, Chinese 1%, other
3.7%
Religions: Roman Catholic 32.2%, Hindu 24.3%,
Anglican 14.4%, other Protestant 14%, Muslim 6%,
none or unknown 9.1%
Languages: English (official), Hindi, French,
Spanish
Literacy:
definition: age 15 and over can read and write
total population: 97.9%
male: 98.8%
female: 97% (1995 est.)
Population: uninhabited
Population: 14,974 (July 1998 est.)
Age structure:
0-14 years: NA
1 5-64 years: NA
65 years and over: N A
Population growth rate: 1.06% (1998 est.)
Birth rate: 23.02 births/1,000 population (1998 est.)
Death rate: 4.78 deaths/1 ,000 population (1998 est.)
Net migration rate: -7.61 migrant(s)/1 ,000
population (1998 est.)
Infant mortality rate: 20.93 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 73.82 years
male: 73.24 years
female: 74.4 years (1 998 est.)
Total fertility rate: 2.78 children born/woman (1998
est.)
Nationality:
noun;Wa!lisian(s), Futunan(s), or Wallis and Futuna
Islanders
adjective: Wallisian, Futunan, or Wallis and Futuna
Islander
Ethnic groups: Polynesian
Religions: Roman Catholic 100%
Languages: French, Wallisian (indigenous
Polynesian language)
Literacy:
definition : age 1 5 and over can read and write
total population: 50%
male: 50%
female: 50% (1969 est.)','aa2f4c1ee15de34a4f2f683339b3229184ca27bde233c32ecdcc4fe8cd043e36','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc361586ddce472f6bf0aacce445709a2638f8fdcb4819422b848d051f4ef679',1998,'NI','Nicaragua','people-and-society',678,'Population: 4,583,379 (July 1998 est.)
Age structure:
0-14 years : 44% (male 1 ,017,1 90; female 1 ,000,436)
15-64 years: 53% (male 1,191,323; female
1,251,828)
65 years and over: 3% (male 52,836; female 69,766)
(July 1998 est.)
Population growth rate: 2.92% (1998 est.)
Birth rate: 36.04 births/1,000 population (1998 est.)
Death rate: 5.8 deaths/1 ,000 population (1 998 est.)
Net migration rate: -1.09 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.76 male(s)/female (1 998 est.)
Infant mortality rate: 42.26 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 66.62 years
male: 64.26 years
female : 69.08 years (1998 est.)
Total fertility rate: 4.28 children born/woman (1998
est.)
Nationality:
noun: Nicaraguan(s)
adjective : Nicaraguan
Ethnic groups: mestizo (mixed Amerindian and
white) 69%, white 17%, black 9%, Amerindian 5%
Religions: Roman Catholic 95%, Protestant 5%
Languages: Spanish (official)
note: English- and Amerindian-speaking minorities on
Atlantic coast
Literacy:
definition: age 15 and over can read and write
total population: 65.7%
male: 64.6%
female: 66.6% (1995 est.)','ddcce5370ffaea3866bf819bad9bea5214f23c0398eef1a26169361f11c02fb1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ce78d0f83a5f561e61f617f61ae04e16ffbe07db66be798311a2b5cb649e461',1998,'NG','Nigeria','people-and-society',689,'Population: 1 10,532,242 (July 1998 est.)
Age structure:
0-14 years: 45% (male 24,871 ,855; female
24,661,134)
15-64 years: 52% (male 29,420,428; female
28,343,567)
65 years and over: 3% (male 1 ,627,452; female
1,607,806) (July 1998 est.)
Population growth rate: 2.96% (1998 est.)
Birth rate: 42.24 births/1 ,000 population (1998 est.)
Death rate: 12.95 deaths/1,000 population (1998
est.)
Net migration rate: 0.32 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years:) male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 1 .01 male(s)/female (1 998 est.)
Infant mortality rate: 70.74 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 53.55 years
male: 52.68 years
female: 54.45 years (1998 est.)
Total fertility rate: 6.09 children born/woman (1998
est.)
Nationality:
noun: Nigerian(s)
adjective: Nigerian
Ethnic groups: Hausa, Fulani, Yoruba, Ibo, Kanuri,
Ibibio, Tiv, Ijaw
Religions: Muslim 50%, Christian 40%, indigenous
beliefs 10%
Languages: English (official), Hausa, Yoruba, Ibo,
Fulani
Literacy:
definition: age 15 and over can read and write
total population: 57.1%
male: 67.3%
female: 47.3% (1995 est.)','e47fc0f0765b4e50605271b8c34096fca31bf81d092ba1723b73a315a8259eea','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c46f41bf0a8b405800fec59d96dc2ac65de97220cbb2f58b82c06277a4499c7a',1998,'NU','Niue','people-and-society',693,'Population: 1 ,647 (July 1 998 est.)
Age structure:
0- 14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -3.65% (1998 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Niuean(s)
adjective: Niuean
Ethnic groups: Polynesian (with some 200
Europeans, Samoans, and Tongans)
Religions: Ekalesia Niue (Niuean Church) 75%— a
Protestant church closely related to the London
Missionary Society, Latter-Day Saints 10%, other
15% (mostly Roman Catholic, Jehovah''s Witnesses,
Seventh-Day Adventist)
Languages: Polynesian closely related to Tongan
and Samoan, English
Literacy:
definition: NA
total population: 95%
male: NA%
female: NA%','13eab14b0cc15c1b157aa93cfd339848fce839db0a4d09aa1f3e8f3cce50da03','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17d06f2ebf0c6a2c1d52febc474badb8a67d0f3b5950849236e7137681ff9a81',1998,'NF','Norfolk Island','people-and-society',700,'Population: 2,179 (July 1998 est.)
Age structure:
0-14 years: NA
15-64 years : NA
65 years and over: NA
Population growth rate: -0.69% (1998 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: N A
male: NA
female : NA
Total fertility rate: NA children born/woman
Nationality:
noun: Norfolk Islander(s)
adjective: Norfolk Islander(s)
Ethnic groups: descendants of the Bounty
mutineers, Australian, New Zealander, Polynesians
Religions: Anglican 39%, Roman Catholic 1 1 .7%,
Uniting Church in Australia 16.4%, Seventh-Day
Adventist 4.4%, none 9.2%, unknown 16.9%, other
2.4% (1986)
Languages: English (official), Norfolk a mixture of
18th century English and ancient Tahitian','cc9ced9c0ec80c6a60e1df86d64fcb2ba57e7a810200c5945fab4a61cc3fea73','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ffae598a44a67480c7e4f0595dee888eda9de80b1a05cc102191ea754c7168d',1998,'OM','Oman','people-and-society',713,'Population: 2,363,591 (July 1998 est.)
Age structure:
0-14 years: 41% (male 488,244; female 469,831)
15-64 years: 57% (male 835,872; female 514,236)
65 years and over: 2% (male 28,966; female 26,442)
(July 1998 est.)
Population growth rate: 3.45% (1998 est.)
Birth rate: 37.83 births/1,000 population (1998 est.)
Death rate: 4.37 deaths/1 ,000 population (1 998 est.)
Net migration rate: 1.08 migrant(s)/1,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .63 male(s)/female
65 years and over: 1 .1 male(s)/female (1 998 est.)
Infant mortality rate: 25.55 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 71 .02 years
male: 69.04 years
female: 73.1 years (1998 est.)
Total fertility rate: 6.13 children born/woman (1998
est.)
Nationality:
not//?: Omani(s)
adjective: Omani
Ethnic groups: Arab, Baluchi, South Asian (Indian,
Pakistani, Sri Lankan, Bangladeshi), African
Religions: Ibadhi Muslim 75%, Sunni Muslim, Shi''a
Muslim, Hindu
Languages: Arabic (official), English, Baluchi, Urdu,
Indian dialects
Literacy:
definition: NA
total population: approaching 80%
male: NA%
female: NA%','b7581b7b2fd25d3b85b6dd2fc57121b29782673a5b1c692efb7342e91cd063eb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cb228f088fc9397c4df5ec50e7d2630f4560962a48280ec7fc73ebfc9a474c2',1998,'PK','Pakistan','people-and-society',721,'Population: 135,135,195 (July 1998 est.)
note: population figures based on 1981 national
census results— 1998 census results are pending
Age structure:
0-14 years: 42% (male 29,083,284; female
27,425,172)
15-64 years: 54% (male 37,432,059; female
35,731,170)
65 years and over: 4% (male 2,716,739; female
2,746,771) (July 1998 est.)
Population growth rate: 2.2% (1998 est.)
Birth rate: 34.38 births/1 ,000 population (1998 est.)
Death rate: 10.69 deaths/1 ,000 population (1998
est.)
Net migration rate: -1.71 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.99 male(s)/female (1 998 est.)
Infant mortality rate: 93.48 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 59.07 years
male: 58.23 years
female: 59.96 years (1998 est.)
Total fertility rate: 4.91 children born/woman (1998
est.)
Nationality:
noun: Pakistani(s)
adjective: Pakistani
Ethnic groups: Punjabi, Sindhi, Pashtun (Pathan),
Baloch, Muhajir (immigrants from India and their
descendants)
Religions: Muslim 97% (Sunni 77%, Shi''a 20%),
Christian, Hindu, and other 3%
Languages: Punjabi 48%, Sindhi 12%, Siraiki (a
Punjabi variant) 10%, Pashtu 8%, Urdu (official) 8%,
Balochi 3%, Hindko 2%, Brahui 1%, English (official
and lingua franca of Pakistani elite and most
359
Pakistan (continued)
government ministries), Burushaski, and other 8%
Literacy:
definition: age 15 and over can read and write
total population: 37.8%
male: 50%
female: 24.4% (1995 est.)
Population: 18,110 (July 1998 est.)
Age structure:
0-14 years: 27% (male 2,555; female 2,405)
15-64 years: 68% (male 6,727; female 5,535)
65 years and over: 5% (male 41 6; female 472) (July
1998 est.)
Population growth rate: 1 .96% (1 998 est.)
Birth rate: 21 .26 births/1 ,000 population (1998 est.)
Death rate: 7.9 deaths/1 ,000 population (1998 est.)
Net migration rate: 6.24 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 ma!e(s)/female
under 15 years : 1 .06 male(s)/female
15-64 years: 1 .22 ma!e(s)/fema!e
65 years and over: 0.88 male(s)/female (1998 est.)
Infant mortality rate: 1 8.82 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 67.54 years
male: 64.49 years
female: 70.78 years (1998 est.)
Total fertility rate: 2.6 children born/woman (1998
est.)
Nationality:
noun: Palauan(s)
adjective: Palauan
Ethnic groups: Palauans are a composite of
Polynesian, Malayan, and Melanesian races
Religions: Christian (Catholics, Seventh-Day
Adventists, Jehovah''s Witnesses, the Assembly of
God, the Liebenzell Mission, and Latter-Day Saints),
Modekngei religion (one-third of the population
observes this religion which is indigenous to Palau)
Languages: English (official in all of Palau''s 16
states), Sonsorolese (official in the state of Sonsoral),
Angaurand Japanese (in the state of Anguar), Tobi (in
the state of Tobi), Palauan (in the other 13 states)
Literacy:
definition: age 1 5 and over can read and write
total population: 92%
male: 93%
female: 90% (1980 est.)','01bf8b158fc6866c17f3f96475b363d5b3bf1db068245be4f0530e154e87062c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eebf3d46f896c38f8580fa282986725ce43ab48a33da692d2cfc8e8944abba27',1998,'PG','Papua New Guinea','people-and-society',730,'Population: 4,599,785 (July 1998 est.)
Age structure:
0-14 years: 40% (male 936,206; female 888,427)
15-64 years : 57% (male 1 ,374,471 ; female
1,263,750)
65 years and over: 3% (male 62,593; female 74,338)
(July 1998 est.)
Population growth rate: 2.27% (1998 est.)
Birth rate: 32.37 births/1,000 population (1998 est.)
Death rate: 9.65 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.05 male(s)/femaie
under 15 years: 1.05 male(s)/female
15-64 years: 1.09 male(s)/female
65 years and over: 0.84 male(s)/female (1 998 est.)
Infant mortality rate: 57.09 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 58.06 years
male: 57.1 8 years
female: 58.98 years (1998 est.)
Total fertility rate: 4.26 children born/woman (1998
est.)
Nationality:
noun: Papua New Guinean(s)
adjective: Papua New Guinean
Ethnic groups: Melanesian, Papuan, Negrito,
Micronesian, Polynesian
Religions: Roman Catholic 22%, Lutheran 16%,
Presbyterian/Methodist/London Missionary Society
8%, Anglican 5%, Evangelical Alliance 4%,
Seventh-Day Adventist 1%, other Protestant sects
10%, indigenous beliefs 34%
Languages: English spoken by 1%-2%, pidgin
English widespread, Motu spoken in Papua region
note: 71 5 indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 72.2%
male: 81%
female: 62.7% (1 995 est.)
366','c5b4426cdf779ce2e2c1705a4e57f67d3600a459148763f681baab8efca3008d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f65fe9dd590c8d9176c089178cf5d2793ad9cb6daf652e1ee605df9e504492ae',1998,'PH','Philippines','people-and-society',743,'Population: no indigenous inhabitants
note; there are scattered Chinese garrisons
368
Population: 77,725,862 (July 1998 est.)
Age structure:
0-14 years: 38% (male 14,867,972; female
14,379,722)
15-64 years: 59% (male 22,582,178; female
23,136,055)
65 years and over: 3% (male 1 ,232,81 3; female
1,527,122) (July 1998 est.)
Population growth rate: 2.09% (1998 est.)
Birth rate: 28.43 births/1,000 population (1998 est.)
Death rate: 6.52 deaths/1 ,000 population (1 998 est.)
Net migration rate: -1.04 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.81 male(s)/female (1998 est.)
Infant mortality rate: 34.56 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 66.35 years
male: 63.57 years
female: 69.28 years (1998 est.)
Total fertility rate: 3.54 children born/woman (1998
est.)
Nationality:
noun: Filipino(s)
adjective: Philippine
Ethnic groups: Christian Malay 91.5%, Muslim
Malay 4%, Chinese 1 .5%, other 3%
373
Philippines (continued)
Religions: Roman Catholic 83%, Protestant 9%,
Muslim 5%, Buddhist and other 3%
Languages: Pilipino (official, based on Tagaiog),
English (official)
Literacy:
definition: age 15 and over can read and write
total population: 94.6%
male: 95%
female: 94.3% (1995 est.)
Population: 50 (July 1998 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -0.6% (1998 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun : Pitcairn Islander(s)
adjective: Pitcairn Islander
Ethnic groups: descendants of the Bounty
mutineers and their Tahitian wives
Religions: Seventh-Day Adventist 100%
Languages: English (official), Tahitian/English
dialect
Population: no indigenous inhabitants
note: there are scattered garrisons occupied by
personnel of several claimant states','70c2eef22e6dcb6103ce58e1483fed7182a8d13b6ee14c89c69cafdf44198f83','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d8798545c191127272d3a3aca8505d1350425c9bd6c82a7d6eb8890fb5057f7',1998,'AR','Argentina','people-and-society',745,'Population: 5,291,020 (July 1998 est.)
Age structure:
0-14 years: 39% (male 1 ,061 ,972; female 1 ,026,983)
15-64 years: 56% (male 1 ,483,089; female
1,473,372)
65 years and over: 5% (male 1 1 3,298; female
132,306) (July 1998 est.)
Population growth rate: 2.68% (1998 est.)
Birth rate: 32.21 births/1,000 population (1998 est.)
Death rate: 5.29 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.1 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/fema!e
15-64 years: 1.01 male(s)/female
65 years and over: 0.86 male(s)/female (1 998 est.)
Infant mortality rate: 37.39 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 72.23 years
male: 1021 years
female: 74.29 years (1 998 est.)
Total fertility rate: 4.26 children born/woman (1 998
est.)
Nationality:
noun: Paraguayan(s)
adjective: Paraguayan
Ethnic groups: mestizo (mixed Spanish and
Amerindian) 95%, white plus Amerindian 5%
Religions: Roman Catholic 90%, Mennonite and
other Protestant denominations
Languages: Spanish (official), Guarani
Literacy:
definition: age 15 and over can read and write
total population: 92.1%
male: 93.5%
female: 90.6% (1995 est.)','c902ff5298197efc29422fefc850036ed9d3af137be21c364fde8baf1275c5dd','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61dad3362aec320f9b20bd3bd2ef270d8f7f2559058b74990605cac7e7e37661',1998,'DO','Dominican Republic','people-and-society',753,'Population: 3,857,070 (July 1998 est.)
Age structure:
0-14 years: 24% (male 483,268; female 461 ,632)
15-64 years: 65% (male 1 ,206,385; female
1,310,406)
65 years and over: 11% (male 171 ,889; female
223,490) (July 1998 est.)
Population growth rate: 0.68% (1998 est.)
Birth rate: 16.7 births/1,000 population (1998 est.)
Death rate: 8.08 deaths/1 ,000 population (1 998 est.)
Net migration rate: -1 .83 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.77 male(s)/female (1 998 est.)
Infant mortality rate: 1 2.09 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 74.2 years
male: 69.58 years
female: 79.1 1 years (1 998 est.)
Total fertility rate: 2.03 children born/woman (1998
est.)
Nationality:
noun: Puerto Rican(s) (US citizens)
adjective: Puerto Rican
Ethnic groups: Hispanic
Religions: Roman Catholic 85%, Protestant
denominations and other 15%
Languages: Spanish, English
Literacy:
definition: age 15 and over can read and write
total population: 89%
male: 90%
female: 88% (1980 est.)','fb81079dc6ce2d35369bf2ab20fb2436d22b4527eb0ea2765df9e3a8fcffbc02','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f4d346b8e916fb9e228c28a0fd4ac0f1ef67aeaae760542660077c62f9a934f',1998,'QA','Qatar','people-and-society',760,'Population: 697,126 (July 1998 est.)
note: includes 516,508 non-nationals (July 1997 est.)
Age structure:
0-1 < 4 years: 27% (male 97,317; female 93,532)
15-64 years: 7 1% (male 353,700; female 138,564)
65 years and over: 2% (male 9,731 ; female 4,282)
(July 1998 est.)
Population growth rate: 3.82% (1998 est.)
Birth rate: 1 6.97 births/1 ,000 population (1 998 est.)
Death rate: 3.53 deaths/1 ,000 population (1 998 est.)
Net migration rate: 24.76 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/fema!e
under 15 years : 1 .04 male(s)/female
15-64 years: 2.55 male(s)/fema!e
65 years and over: 2.27 male(s)/female (1998 est.)
Infant mortality rate: 1 8.09 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 73.89 years
male: 71 .38 years
female : 76.54 years (1998 est.)
Total fertility rate: 3.5 children born/woman (1998
est.)
Nationality:
noun:Qatari(s)
adjective : Qatari
Ethnic groups: Arab 40%, Pakistani 18%, Indian
18%, Iranian 10%, other 14%
Religions: Muslim 95%
Languages: Arabic (official), English commonly
used as a second language
Literacy:
definition: age 15 and over can read and write
total population: 79.4%
male: 79.2%
female: 79.9% (1995 est.)
Population: 705,053 (July 1998 est.)
Age structure:
0- 14 years: 32% (male 1 1 6,705; female 1 1 1 ,262)
15-64 years: 62% (male 214,914; female 221,502)
65 years and over: 6% (male 16,846; female 23,824)
(July 1998 est.)
Population growth rate: 1.81% (1998 est.)
Birth rate: 22.78 births/1 ,000 population (1 998 est.)
Death rate: 4.67 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant($)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years : 1 .04 male(s)/female
15-64 years: 0.97 male(s)/fema!e
65 years and over: 0.7 male(s)/female (1 998 est.)
Infant mortality rate: 7.09 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.4 years
male: 72.36 years
female: 78.6 years (1998 est.)
Total fertility rate: 2.67 children born/woman (1998
est.)
Nationality:
noun: Reunionese (singular and plural)
adjective: Reunionese
Ethnic groups: French, African, Malagasy, Chinese,
Pakistani, Indian
Religions: Roman Catholic 94%, Hindu, Islam,
Buddhist
Languages: French (official), Creole widely used
Literacy:
definition: age 15 and over can read and write
total population: 79%
male: 76%
female: 80% (1982 est.)','c8b227586d125db9364abbb12ac54a503a725beae30fd3d1676496bc66cf66c6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75465238480172cb7e41594495ad6b45fb28a5819b00be383758581bd4a0ba33',1998,'UA','Ukraine','people-and-society',769,'Population: 22,395,848 (July 1998 est.)
Age structure:
0- 14 years: 1 9% (male 2,1 69,581 ; female 2,078,51 5)
15-64 years: 68% (male 7,571 ,61 9; female
7,668,689)
65 years and over: 13% (male 1,213,406; female
1,694,038) (July 1998 est.)
Population growth rate: -0.32% (1998 est.)
Birth rate: 9.33 births/1 ,000 population (1998 est.)
Death rate: 1 1 .62 deaths/1 ,000 population (1 998
est.)
Net migration rate: -0.88 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.71 ma!e(s)/femaie (1998 est.)
Infant mortality rate: 1 8.83 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 70.47 years
male: 66.67 years
female: 74.47 years (1998 est.)
Total fertility rate: 1.17 children born/woman (1998
est.)
Nationality:
noun: Romanian(s)
adjective: Romanian
Ethnic groups: Romanian 89.1%, Hungarian 8.9%,
German 0.4%, Ukrainian, Serb, Croat, Russian, Turk,
and Gypsy 1 .6%
Religions: Romanian Orthodox 70%, Roman
Catholic 6% (of which 3% are Uniate), Protestant 6%,
unaffiliated 18%
Languages: Romanian, Hungarian, German
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 95% (1992 est.)
Population: 146,861,022 (July 1998 est.)
Age structure:
0-14 years: 20% (male 14,756,787; female
14,189,564)
15-64 years: 68% (male 48,138,173; female
51,366,412)
65 years and over: 12% (male 5,699,334; female
12,710,752) (July 1998 est.)
Population growth rate: -0.31% (1998 est.)
Birth rate: 9.57 births/1 ,000 population (1998 est.)
Death rate: 14.89 deaths/1,000 population (1998
est.)
Net migration rate: 2.21 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.44 male(s)/fema!e (1 998 est.)
Infant mortality rate: 23.26 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 64.97 years
male: 58.61 years
female: 71 .64 years (1 998 est.)
Total fertility rate: 1 .34 children born/woman (1 998
est.)
Nationality:
noun: Russian(s)
adjective: Russian
Ethnic groups: Russian 81 .5%, Tatar 3.8%,
Ukrainian 3%, Chuvash 1.2%, Bashkir 0.9%,
Byelorussian 0.8%, Moldavian 0.7%, other 8.1%
Religions: Russian Orthodox, Muslim, other
Languages: Russian, other
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 100%
female: 97% (1989 est.)','0e31387e42085acfa8fc8c3b03ee395e1488ecf66b052b8debc119c19c7fac79','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abd8bdb19577cb823fc21a76ffa56745852677a98f684e6516cde94d0199d7b0',1998,'UG','Uganda','people-and-society',780,'Population: 7,956,172 (July 1998 est.)
Age structure:
0-14 years: 45% (male 1 ,785,650; female 1 ,772,609)
15-64 years: 53% (male 2,070,401 ; female
2,106,809)
65 years and over: 2% (male 90,941 ; female
129,762) (July 1998 est.)
Population growth rate: 2.5% (1998 est.)
Birth rate: 38.99 births/1,000 population (1998 est.)
Death rate: 1 9 deaths/1 ,000 population (1 998 est.)
Net migration rate: 5.03 migrant(s)/1 ,000
population (1998 est.)
note: following the outbreak of genocidal strife in
Rwanda in April 1994 between Tutsi and Hutu
factions, more than 2 million refugees fled to
neighboring Burundi, Tanzania, Uganda, and
Democratic Republic of the Congo, formerly Zaire;
according to the UN High Commission on Refugees,
in 1996 and early 1997 nearly 1,300,000 Hutus
returned to Rwanda; of these 720,000 returned from
Democratic Republic of the Congo, 480,000 from
Tanzania, 88,000 from Burundi, and 10,000 from
Uganda; probably fewer than 100,000 Rwandans
remained outside of Rwanda at the end of 1997
Sex ratio:
at birth: 1 .03 ma!e(s)/fema!e
under 15 years: 1 ma!e(s)/fema!e
15-64 years: 0.98 ma!e(s)/fema!e
65 years and over: 0.7 male(s)/female (1998 est.)
Infant mortality rate: 1 1 3.31 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 41 .93 years
ma/e:41.49 years
female: 42.4 years (1998 est.)
Total fertility rate: 5.86 children born/woman (1998
est.)
Nationality:
noun: Rwandan(s)
adjective: Rwandan
Ethnic groups: Hutu 80%, Tutsi 19%, Twa
(Pygmoid) 1%
Religions: Roman Catholic 65%, Protestant 9%,
Muslim 1%, indigenous beliefs and other 25%
Languages: Kinyarwanda (official) universal Bantu
vernacular, French (official), English (official),
Kiswahili (Swahili) used in commercial centers
Literacy:
definition: age 15 and over can read and write
total population: 60.5%
male: 69.8%
female: 51 .6% (1995 est.)
Population: 7,091 (July 1998 est.)
Age structure:
0-14 years: 20% (male 718; female 694)
15-64 years : 71% (male 2,643; female 2,423)
65 years and over: 9% (male 249; female 364) (July
1998 est.)
Population growth rate: 0.76% (1998 est.)
Birth rate: 14.1 births/1,000 population (1998 est.)
Death rate: 6.49 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 .09 male(s)/female
65 years and over: 0.68 ma!e(s)/female (1 998 est.)
Infant mortality rate: 28.81 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.73 years
male: 72.66 years
female: 78.96 years (1998 est.)
Total fertility rate: 1 .5 children born/woman (1 998
est.)
Nationality:
noun: Saint Helenian(s)
adjective: Saint Helenian
Ethnic groups: African descent, white
Religions: Anglican (majority), Baptist, Seventh-Day
Adventist, Roman Catholic
Languages: English
Literacy:
definition: age 20 and over can read and write
total population: 97%
male: 97%
female: 98% (1987 est.)','9e48e4d8fb02df5f2bdb28488fee04bac7e853b3ffc569f5d027fe11bef43467','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f61c56a291c184559eee0271bd00954d6d293670516ff27bbc15bf88160d65c',1998,'TT','Trinidad and Tobago','people-and-society',788,'Population: 42,291 (July 1998 est.)
Age structure:
0-14 years: 33% (male 7,217; female 6,860)
15-64 years: 61% (male 12,860; female 12,748)
65 years and over: 6% (male 1 ,058; female 1 ,548)
(July 1998 est.)
Population growth rate: 1 .23% (1 998 est.)
Birth rate: 22.87 births/1,000 population (1998 est.)
Death rate: 8.51 deaths/1 ,000 population (1 998 est.)
Net migration rate: -2.08 migrant(s)/1,000
population (1998 est.)
Sex ratio:
at birth : 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.68 male(s)/fema!e (1 998 est.)
Infant mortality rate: 17.89 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 67.58 years
male: 64.52 years
female: 70.82 years (1998 est.)
Total fertility rate: 2.45 children born/woman (1998
est.)
Nationality:
noun: Kittitian(s), Nevisian(s)
adjective: Kittitian, Nevisian
Ethnic groups: black
Religions: Anglican, other Protestant sects, Roman
Catholic
Languages: English
Literacy:
definition : age 1 5 and over has ever attended school
total population: 97%
male: 97%
female: 98% (1980 est.)
Population: 152,335 (July 1998 est.)
Age structure:
0-14 years: 34% (male 26,261 ; female 25,747)
15-64 years: 60% (male 45,182; female 46,956)
65 years and over: 6% (male 3,095; female 5,094)
(July 1998 est.)
Population growth rate: 1 .11% (1998 est.)
Birth rate: 22.48 births/1 ,000 population (1998 est.)
Death rate: 5.64 deaths/1 ,000 population (1 998 est.)
Net migration rate: -5.7 migrant(s)/1 ,00CTpopulation
(1998 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.61 maie(s)/female (1 998 est.)
Infant mortality rate: 1 6.95 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 71 .58 years
male: 67.94 years
female: 75 .48 years (1998 est.)
Total fertility rate: 2.35 children born/woman (1 998
est.)
Nationality:
noun: Saint Lucian(s)
adjective: Saint Lucian
Ethnic groups: black 90%, mixed 6%, East Indian
3%, white 1%
Religions: Roman Catholic 90%, Protestant 7%,
Anglican 3%
Languages: English (official), French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 67%
male: 65%
female: 69% (1980 est.)','de61668a869c1aca3cfc76b3caea1fbd193f7ae406933a2ddbc781eb64689263','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3b1073502db33f19692c8f3d3cf09d995a0638fefff7b8e42c2477abc7a0e68',1998,'MQ','Martinique','people-and-society',800,'Population: 6,914 (July 1998 est.)
Age structure:
0-14 years: NA
75-64 years: N A
65 years and over: NA
Population growth rate: 0.76% (1998 est.)
Birth rate: 1 2.45 births/1 ,000 population (1 998 est.)
Death rate: 5.49 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0.59 migrant(s)/1 ,000
population (1998 est.)
Infant mortality rate: 8.62 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 76.91 years
male: 75.35 years
female: 78.79 years (1998 est.)
Total fertility rate: 1 .6 children born/woman (1 998
est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective : French
Ethnic groups: Basques and Bretons (French
fishermen)
Religions: Roman Catholic 99%
Languages: French
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)','59ef57390904b93f8f0de19badf175b0a2ea1bb24b10cb3596355060dc78a5ad','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('940f2fc1ffcb76d2c4fed988b74141608f0224ead0af961333196f698f8df7bd',1998,'IT','Italy','people-and-society',804,'Population: 24,894 (July 1998 est.)
Age structure:
0-14 years: 16% (male 1,994; female 2,013)
15-64 years: 67% (male 8,480; female 8,282)
65 years and over: 1 7% (male 1 ,732; female 2,393)
(July 1998 est.)
Population growth rate: 0.7% (1998 est.)
Birth rate: 1 0.52 births/1 ,000 population (1 998 est.)
Death rate: 8.11 deaths/1 ,000 population (1 998 est.)
Net migration rate: 4.54 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 1 .02 ma!e(s)/female
65 years and over: 0.72 male(s)/female (1 998 est.)
Infant mortality rate: 5.44 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population : 81 .42 years
male : 77.5 years
female : 85.34 years (1998 est.)
Total fertility rate: 1.51 children born/woman (1998
est.)
Nationality:
noun : Sammarinese (singular and plural)
adjective: Sammarinese
Ethnic groups: Sammarinese, Italian
Religions: Roman Catholic
Languages: Italian
Literacy:
definition: age 10 and over can read and write
total population: 96%
male: 97%
female: 95% (1 976 est.)
Population: 150,123 (July 1998 est.)
Age structure:
0-14 years: 48% (male 36,127; female 35,253)
15-64 years: 48% (male 34,980; female 37,555)
65 years and over: 4% (male 2,81 3; female 3,395)
(July 1998 est.)
Population growth rate: 3.1% (1998 est.)
Birth rate: 43.48 births/1,000 population (1998 est.)
Death rate: 8.31 deaths/1 ,000 population (1 998 est.)
Net migration rate: -4.15 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.82 male(s)/female (1 998 est.)
Infant mortality rate: 54.55 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 64.34 years
male : 62.87 years
female: 65.86 years (1998 est.)
Total fertility rate: 6.1 9 children born/woman (1 998
est.)
Nationality:
noun: Sao Tomean(s)
adjective: Sao Tomean
Ethnic groups: mestico, angolares (descendants of
Angolan slaves), forros (descendants of freed slaves),
servicais (contract laborers from Angola,
Mozambique, and Cape Verde), tongas (children of
servicais born on the islands), Europeans (primarily
Portuguese)
Religions: Roman Catholic, Evangelical Protestant,
Seventh-Day Adventist
Languages: Portuguese (official)
Literacy:
definition: age 15 and over can read and write
total population: 73%
male: 85%
female: 62% (1991 est.)
I Government
Country name:
conventional long form: Democratic Republic of Sao
Tome and Principe
conventional short form: Sao Tome and Principe
local long form : Republica Democratica de Sao Tome
e Principe
local short form: Sao Tome e Principe
Data code: TP
Government type: republic
National capital: Sao Tome
Administrative divisions: 2 districts (concelhos,
singular— concelho); Principe, Sao Tome
Independence: 12 July 1975 (from Portugal)
National holiday: Independence Day, 12 July
(1975)
Constitution: approved March 1990; effective 10
September 1990
407
Sao Tome and Principe (continued)
Legal system: based on Portuguese legal system
and customary law; has not accepted compulsory ICJ
jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Miguel TROVOADA (since 4
April 1991)
head of government: Prime Minister Raul Wagner
BRAGANCA NETO (since 20 November 1996)
cabinet: Council of Ministers appointed by the
president on the proposal of the prime minister
elections: president elected by popular vote for a
five-year term; election last held 30 June and 15 July
1996 (next to be held in 2001); prime minister chosen
by the National Assembly and approved by the
president
election results: Miguel TROVOADA reelected
president in Sao Tome''s second multiparty
presidential election; percent of vote— NA
Legislative branch: unicameral National Assembly
or Assembleia Nacional (55 seats; members are
elected by direct popular vote to serve five-year terms)
elections: parliament dissolved by President
TROVOADA in July 1994; early elections held 2
October 1994 (next to be held October 1998)
election results: percent of vote by party— MLSTP
49%, PCD-GR 25.5%, ADI 25.5%; seats by party —
MLSTP 27, PCD-GR 14, AD1 14
Judicial branch: Supreme Court, judges are
appointed by the National Assembly
Political parties and leaders: Party for Democratic
Convergence-Reflection Group or PCD-GR [Armindo
AGUIAR, secretary general]; Movement for the
Liberation of Sao Tome and Principe or MLSTP
[Francisco Fortunas PIRES]; Christian Democratic
Front or FDC [Alphonse Dos SANTOS]; Democratic
Opposition Coalition or CODO; Independent
Democratic Action or ADI [Carlos NEVES]; other small
parties
International organization participation: ACP,
AfDB, CEEAC, ECA, FAO, G-77, IBRD, ICAO, ICRM,
IDA, IFAD, IFRCS, ILO, IMF, IMO, Intelsat
(nonsignatory user), Interpol, IOC, IOM (observer),
ITU, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO,
UPU, WHO, WMO, WToO, WTrO (applicant)
Diplomatic representation in the US: Sao Tome
and Principe does not have an embassy in the US, but
does have a Permanent Mission to the UN, headed by
First Secretary Domingos AUGUSTO Ferreira,
located at 122 East 42nd Street, Suite 1604, New
York, NY 10168, telephone [1] (212) 697-4211
Diplomatic representation from the US: the US
does not have an embassy in Sao Tome and Principe;
the Ambassador to Gabon is accredited to Sao Tome
and Principe on a nonresident basis and makes
periodic visits to the islands
Flag description: three horizontal bands of green
(top), yellow (double width), and green with two black
five-pointed stars placed side by side in the center of
the yellow band and a red isosceles triangle based on
the hoist side; uses the popular pan-African colors of
Population: 7,260,357 (July 1998 est.)
Age structure:
0-14 years: 17% (male 642,365; female 613,931)
15-64 years: 68% (male 2,506,653; female
2,415,647)
65 years and over: 1 5% (male 436,804; female
644,957) (July 1998 est.)
Population growth rate: 0.22% (1998 est.)
Birth rate: 10.81 births/1 ,000 population (1998 est.)
Death rate: 9.03 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0.42 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 ma!e(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.68 male(s)/female (1 998 est.)
Infant mortality rate: 4.92 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.88 years
male: 75.71 years
female : 82.22 years (1998 est.)
Total fertility rate: 1 .46 children born/woman (1 998
est.)
Nationality:
noun: Swiss (singular and plural)
adjective: Swiss
Ethnic groups: total population— German 65%,
French 18%, Italian 10%, Romansch 1%, other 6%
note: Swiss nationals— German 74%, French 20%,
Italian 4%, Romansch 1%, other 1%
Religions: Roman Catholic 46.1%, Protestant 40%,
other 5%, no religion 8.9% (1990)
Languages: German 63.7%, French 19.2%, Italian
7.6%, Romansch 0.6%, other 8.9%
note: figures for Swiss nationals only: German 74%,
French 20%, Italian 4%, Romansch 1%, other 1%
Literacy:
definition: age 15 and over can read and write
total population: 99% (1980 est.)
male: NA%
female : NA%
Population: 16,673,282 (July 1998 est.)
note: in addition, there are 35,150 people living in the
Israeli-occupied Golan Heights— 18,150 Arabs
(1 6,500 Druze and 1 ,650 Alawites) and 1 7,000 Israeli
settlers (August 1997 est.)
Age structure:
0-14 years: 46% (male 3,937,575; female 3,748,881 )
15-64 years: 51% (male 4,342,022; female
4,157,268)
65 years and over: 3% (male 240,603; female
246,933) (July 1998 est.)
Population growth rate: 3.23% (1998 est.)
Birth rate: 37.83 births/1,000 population (1998 est.)
Death rate: 5.55 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.97 male(s)/female (1998 est.)
Infant mortality rate: 37.6 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 67.76 years
male: 66.48 years
female: 69.1 1 years (1998 est.)
Total fertility rate: 5.55 children born/woman (1998
est.)
Nationality:
noun: Syrian(s)
adjective: Syrian
Ethnic groups: Arab 90.3%, Kurds, Armenians, and
other 9.7%
Religions: Sunni Muslim 74%, Alawite, Druze, and
other Muslim sects 16%, Christian (various sects)
10%, Jewish (tiny communities in Damascus, Al
Qamishli, and Aleppo)
Languages: Arabic (official); Kurdish, Armenian,
Aramaic, Circassian widely understood; French,
English somewhat understood
Literacy:
definition: age 1 5 and over can read and write
total population: 70.8%
male: 85.7%
female: 55.8% (1 997 est.)','eb0d7f3056d98dc2898f01184a1bfe08d7e6cffab236f37edf69329bb5664a86','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b75149efbdeee9042c22ca3c1653e1af06b32f0e3e26f26e4217ba67a8726b47',1998,'SA','Saudi Arabia','people-and-society',812,'Population: 20,785,955 (July 1998 est.)
note: includes 5,244,058 non-nationals (July 1998
est.)
Age structure:
0-14 years: 43% (male 4,547,971 ; female 4,398,628)
15-64 years: 55% (male 6,738,820; female
4,591,477)
65 years and over: 2% (male 268,1 36; female
240,923) (July 1998 est.)
Population growth rate: 3.41% (1998 est.)
Birth rate: 37.63 births/1,000 population (1998 est.)
Death rate: 5.02 deaths/1 ,000 population (1 998 est.)
Net migration rate: 1 .44 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/fema!e
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .46 male(s)/female
65 years and over: 1.11 male(s)/female (1 998 est.)
Infant mortality rate: 41 .34 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 70.03 years
male: 68.19 years
female: 71 .96 years (1 998 est.)
Total fertility rate: 6.38 children born/woman (1998
est.)
Nationality:
noun: Saudi(s)
adjective: Saudi or Saudi Arabian
Ethnic groups: Arab 90%, Afro-Asian 10%
Religions: Muslim 100%
Languages: Arabic
Literacy:
definition: age 15 and over can read and write
total population: 62.8%
male: 71.5%
female: 50.2% (1995 est.)','9f06a83fbdd7f77371297df4d17f271132f8b37b23c4155d72d754143c1eb545','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d09fff47345fd06c4dcd4bfd987362f87c6dd8e0cb36a5ad97e9b9a0d52bf4c',1998,'MR','Mauritania','people-and-society',820,'Population: 9,723,149 (July 1998 est.)
Age structure:
0-14 years: 48% (male 2,331 ,388; female 2,343,654)
15-64 years: 49% (male 2,273,200; female
2,504,063)
65 years and over: 3% (male 1 32,671 ; female
138,173) (July 1998 est.)
Population growth rate: 3.33% (1998 est.)
Birth rate: 44.38 births/1 ,000 population (1998 est.)
Death rate: 1 1 .05 deaths/1 ,000 population (1 998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/fema!e
under 15 years: 0.99 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.96 male(s)/female (1 998 est.)
Infant mortality rate: 61 .2 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 57.37 years
male: 54.55 years
female: 60.28 years (1998 est.)
Total fertility rate: 6.18 children born/woman (1998
est.)
Nationality:
noun: Senegalese (singular and plural)
adjective: Senegalese
Ethnic groups: Wolof 36%, Fulani 17%, Serer 17%,
Toucouleur 9%, Diola 9%, Mandingo 9%, European
and Lebanese 1%, other 2%
Religions: Muslim 92%, indigenous beliefs 6%,
Christian 2% (mostly Roman Catholic)
Languages: French (official), Wolof, Pulaar, Diola,
Mandingo
Literacy:
definition: age 15 and over can read and write
total population: 33.1 %
male: 43%
female: 23.2% (1 995 est.)','64794ed9d6ed2cd5a412bb74e52e58c7a10ea6babaeec934ba552883c248b45c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7dbbd6b25ade0b3227edc7b46f2b128f8389ac04dd44f09cd50c8001e24ffd2',1998,'ME','Montenegro','people-and-society',828,'Population: 11,206,039 (July 1998 est.)
(Montenegro— 679,904; Serbia— 10,526,135)
Age structure:
0-14 years: Montenegro— 22% (male 76,764; female
71,647); Serbia- 20% (male 1,121,483; female
1,043,535)
15-64 years: Montenegro— 67% (male 231 ,849;
female 227,268); Serbia- 67% (male 3,539,198;
female 3,487,318)
65 years and over: Montenegro— 11% (male 29,837;
female 42,539); Serbia— 13% (male 575,697; female
758,904) (July 1998 est.)
Population growth rate: Montenegro— 0.07%;
Serbia— 0.02% (1998 est.)
Birth rate: Montenegro— 13.55 births/1,000
population; Serbia— 12.62 births/1,000 population
(1998 est.)
Death rate: Montenegro— 7.40 deaths/1 ,000
population; Serbia— 9.67 deaths/1,000 population
(1998 est.)
Net migration rate: Montenegro: -5.43 migrant(s)/
1,000 population; Serbia: -3.1 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: Montenegro— 1 .09 male(s)/fema!e; Serbia —
1 .08 male(s)/female
under 15 years: Montenegro— 1 .07 male(s)/female;
Serbia— 1 .07 male(s)/female
15-64 years: Montenegro— 1 .02 male(s)/fema!e;
Serbia— 1.01 male(s)/female
65 years and over: Montenegro— 0.70 male(s)/
female; Serbia— 0.75 male(s)/female (1998 est.)
Infant mortality rate: Montenegro— 1 1 .24 deaths/
1,000 live births; Serbia— 17.11 deaths/1,000 live
births (1998 est.)
Life expectancy at birth:
total population: Montenegro— 76.14 years; Serbia —
73.17 years
male: Montenegro— 72.67 years; Serbia— 70.77
years
female: Montenegro— 79.92 years; Serbia— 75.76
years (1998 est.)
Total fertility rate: Montenegro— 1 .76 children born /
woman; Serbia— 1.75 children born/woman (1998
est.)
Nationality:
noun: Serb(s) and Montenegrin(s)
adjective: Serbian and Montenegrin
Ethnic groups: Serbs 63%, Albanians 14%,
Montenegrins 6%, Hungarians 4%, other 13%
Religions: Orthodox 65%, Muslim 19%, Roman
Catholic 4%, Protestant 1%, other 11%
Languages: Serbo-Croatian 95%, Albanian 5%
Literacy: NA','d5e1b4e31b5300ead0a2f49451e9238a570f7c29811682582d2f8862d8ee19ba','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cc915525a046d4d0d5dc2b10b6f7f4e829082773b40573663781c64787b6234',1998,'SC','Seychelles','people-and-society',833,'Population: 78,641 (July 1998 est.)
Age structure:
0-14 years: 30% (male 1 1 ,787; female 1 1 ,694)
15-64 years: 64% (male 24,555; female 25,681)
65 years and over: 6% (male 1 ,700; female 3,224)
(July 1998 est.)
Population growth rate: 0.67% (1998 est.)
Birth rate: 19.71 births/1,000 population (1998 est.)
Death rate: 6.61 deaths/1 ,000 population (1 998 est.)
Net migration rate: -6.36 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 ma!e(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.52 male(s)/fema!e (1 998 est.)
Infant mortality rate: 17 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 70.76 years
male: 66.1 3 years
female: 75.53 years (1998 est.)
Total fertility rate: 1 .98 children born/woman (1 998
est.)
Nationality:
noun; Seychellois (singular and plural)
adjective: Seychelles
Ethnic groups: Seychellois (mixture of Asians,
Africans, Europeans)
Religions: Roman Catholic 90%, Anglican 8%, other
2%
Languages: English (official), French (official),
Creole
Literacy:
definition: age 15 and over can read and write
total population: 58%
male: 56%
female: 60% (1971 est.)','37074bbafd6d2df339fcc3aef7363db2f20015838f43f4191b926bc6c9211826','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea698be7040fdf872d662c3a669ba4042574f2b637cfcd6733b5abac6c03acf4',1998,'SL','Sierra Leone','people-and-society',842,'Population: 5,080,004 (July 1998 est.)
Age structure:
0-14 years: 45% (male 1,130,728; female 1,167,084)
15-64 years: 52% (male 1 ,257,901 ; female
1,367,902)
65 years and over: 3% (male 79,1 1 3; female 77,276)
(July 1998 est.)
Population growth rate: 4.01% (1998 est.)
Birth rate: 46.16 births/1,000 population (1998 est.)
Death rate: 1 7.25 deaths/1 ,000 population (1 998
est.)
Net migration rate: 11.18 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.03 male(s)/fema!e
under 15 years: 0.96 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 1 .02 male(s)/female (1 998 est.)
Infant mortality rate: 129.38 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 48.57 years
male: 45.56 years
female : 51 .66 years (1 998 est.)
Total fertility rate: 6.23 children born/woman
(1998 est.)
Nationality:
noun: Sierra Leonean(s)
adjective: Sierra Leonean
Ethnic groups: 20 native African tribes 90% (Temne
30%, Mende 30%, other 30%), Creole 10%
(descendents of freed Jamaican slaves who were
settled in the Freetown area in the late-eighteenth
century), refugees from Liberia''s recent civil war,
small numbers of Europeans, Lebanese, Pakistanis
and Indians
Religions: Muslim 60%, indigenous beliefs 30%,
Christian 10%
Languages: English (official, regular use limited to
literate minority), Mende (principal vernacular in the
south), Temne (principal vernacular in the north), Krio
(English-based Creole, spoken by the descendents of
freed Jamaican slaves who were settled in the
Freetown area, a lingua franca and a first language for
10% of the population but understood by 95%)
Literacy:
definition: age 15 and over can read and write in
English, Mende, Temne, or Arabic
total population: 31 .4%
male: 45.4%
female: 18.2% (1995 est.)','6d2da8b03dd7dae7d9aae6cd2adbe1c23c0f1bff060e7df8b59ea3259c023348','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e244cb597be70a8feefd25bc5f770ecc823aff1e1a1c33adb8ec4c71390a9c59',1998,'SB','Solomon Islands','people-and-society',849,'Population: 441 ,039 (July 1998 est.)
Age structure:
0-14 years: 45% (male 101,338; female 97,584)
15-64 years: 52% (male 116,045; female 112,840)
65 years and over: 3% (male 6,571 ; female 6,661 )
(July 1998 est.)
Population growth rate: 3.24% (1998 est.)
Birth rate: 36.62 births/1,000 population (1998 est.)
Death rate: 4.21 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/fema!e
65 years and over: 0.99 male(s)/female (1 998 est.)
Infant mortality rate: 23.93 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 71 .77 years
male: 69.26 years
female: 74.41 years (1998 est.)
Total fertility rate: 5.12 children born/woman (1998
est.)
Nationality:
noun: Solomon Islander(s)
adjective: Solomon Islander
Ethnic groups: Melanesian 93%, Polynesian 4%,
Micronesian 1.5%, European 0.8%, Chinese 0.3%,
other 0.4%
Religions: Anglican 34%, Roman Catholic 19%,
Baptist 17%, United (Methodist/Presbyterian) 11%,
Seventh-Day Adventist 10%, other Protestant 5%,
traditional beliefs 4%
Languages: Melanesian pidgin in much of the
country is lingua franca, English spoken by 1%-2% of
population
note: 120 indigenous languages
Literacy: NA
Population: 6,841,695 (July 1998 est.)
note: this estimate was derived from an official census
taken in 1987 by the Somali Government with the
cooperation of the UN and the US Bureau of the
Census; population estimates are updated year by
year between census years by factoring growth rates
into them and by taking account of refugee
movements and of losses due to famine; lower
estimates of Somalia''s population in mid-1996 (on the
order of 6.0 million to 6.5 million) have been made by
aid and relief agencies, based on the number of
persons being fed; population counting in Somalia is
complicated by the large numbers of nomads and by
refugee movements in response to famine and clan
warfare
Age structure:
0-14 years: 44% (male 1 ,512,01 4; female 1 ,51 1 ,858)
15-64 years: 53% (male 1 ,833,922; female
1,786,261)
65 years and over: 3% (male 90,475; female
107,165) (July 1998 est.)
Population growth rate: 4.43% (1998 est.)
Birth rate: 46.75 births/1 ,000 population (1 998 est.)
Death rate: 1 8.5 deaths/1 ,000 population (1 998 est.)
Net migration rate: 1 6.08 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.84 ma!e(s)/fema!e (1 998 est.)
Infant mortality rate: 125.77 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 46.23 years
male: 44.66 years
female: 47.85 years (1 998 est.)
Total fertility rate: 7.01 children born/woman (1998
est.)
Nationality:
noun: Somali(s)
adjective: Somali
Ethnic groups: Somali 85%, Bantu, Arabs 30,000
Religions: Sunni Muslim
Languages: Somali (official), Arabic, Italian, English
Literacy:
definition: age 15 and over can read and write
total population: 24%
male: 36%
fema/e;14%(1990 est.)
428
Population: 42,834,520 (July 1998 est.)
note : South Africa took a census 1 0 October 1 996
which showed a total of 37,859,000 (after a 6.8%
adjustment for underenumeration based on a
post-enumeration survey); this figure is still about 1 0%
below projections from earlier censuses; since the full
results of the census have not been released for
analysis, the numbers shown for South Africa do not
take into consideration the results of this 1 996 census
Age structure:
0-14 years: 35% (male 7,502,396; female 7,366,144)
15-64 years: 61% (male 12,947,521 ; female
13,079,892)
65 years and over: 4% (male 778,767; female
1,159,800) (July 1998 est.)
Population growth rate: 1 .42% (1 998 est.)
Birth rate: 26.43 births/1 ,000 population (1998 est.)
Death rate: 12.28 deaths/1,000 population (1998
est.)
Net migration rate: 0.08 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 maie(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.67 male(s)/female (1 998 est.)
Infant mortality rate: 52.04 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 55.65 years
male: 53.56 years
female: 57.8 years (1998 est.)
Total fertility rate: 3.16 children born/woman (1 998
est.)
Nationality:
noun: South African(s)
adjective: South African
Ethnic groups: black 75.2%, white 13.6%, Colored
8.6%, Indian 2.6%
430
Religions: Christian 68% (includes most whites and
Coloreds, about 60% of blacks and about 40% of
Indians), Muslim 2%, Hindu 1.5% (60% of Indians),
traditional and animistic 28.5%
Languages: 11 official languages, including
Afrikaans, English, Ndebele, Pedi, Sotho, Swazi,
Tsonga, Tswana, Venda, Xhosa, Zulu
Literacy:
definition: age 15 and over can read and write
total population: 81 .8%
male: 81 .9%
female: 81.7% (1995 est.)
b Government
Country name:
conventional long form: Republic of South Africa
conventional short form: South Africa
abbreviation: RSA
Data code: SF
Government type: republic
National capital: Pretoria (administrative); Cape
Town (legislative); Bloemfontein (judicial)
Administrative divisions: 9 provinces; Eastern
Cape, Free State, Gauteng, KwaZulu-Natal,
Mpumalanga, North-West, Northern Cape, Northern
Province, Western Cape
Independence: 31 May 1910 (from UK)
National holiday: Freedom Day, 27 April (1994)
Constitution: 10 December 1996; this new
constitution was certified by the Constitutional Court
on 4 December 1996, was signed by President
MANDELA on 10 December 1996, and entered into
effect on 3 February 1997; it is being implemented in
phases
Legal system: based on Roman-Dutch law and
English common law; accepts compulsory ICJ
jurisdiction, with reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Nelson MANDELA (since 10
May 1994); Executive Deputy President Thabo
MBEKI (since 10 May 1994); note— the president is
both the chief of state and head of government
head of government: President Nelson MANDELA
(since 10 May 1994); Executive Deputy President
Thabo MBEKI (since 10 May 1994); note— the
president is both the chief of state and head of
Population: no indigenous population
note: there is a small military garrison on South
Georgia, and the British Antarctic Survey has a
biological station on Bird Island; the South Sandwich
Islands are uninhabited','937ba50d029f7a0259ef5422c69d055cf75fc1f50b450db8b4816a794ffb1894','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1e6e43b9077ed05b94f51f3ce0caf5d6e860bdac7c4d114a096f81260a11643',1998,'LK','Sri Lanka','people-and-society',857,'Population: 18,933,558 (July 1998 est.)
note: since the outbreak of hostilities between the
government and armed Tamil separatists in the
mid-1980s, several hundred thousand Tamil civilians
have fled the island; as of late 1996, 63,068 were
housed in refugee camps in south India, another
30,000-40,000 lived outside the Indian camps, and
more than 200,000 Tamils have sought political
asylum in the West
Age structure:
0-14 years: 28% (male 2,673,194; female 2,556,926)
15-64 years: 66% (male 6,126,759; female
6,385,450)
65 years and over: 6% (male 579,329; female
611,900) (July 1998 est.)
Population growth rate: 1 .12% (1998 est.)
Birth rate: 18.4 births/1,000 population (1998 est.)
Death rate: 5.96 deaths/1 ,000 population (1 998 est.)
Net migration rate: -1 .25 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.95 male(s)/female (1 998 est.)
infant mortality rate: 16.33 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 72.55 years
male: 69.82 years
female: 75.41 years (1998 est.)
Total fertility rate: 2.12 children born/woman (1998
est.)
Nationality:
noun: Sri Lankan(s)
adjective: Sri Lankan
Ethnic groups: Sinhalese 74%, Tamil 18%, Moor
7%, Burgher, Malay, and Vedda 1%
Religions: Buddhist 69%, Hindu 15%, Christian 8%,
Muslim 8%
Languages: Sinhala (official and national language)
74%, Tamil (national language) 18%
note: English is commonly used in government and is
spoken by about 10% of the population
Literacy:
definition: age 1 5 and over can read and write
total population: 90.2%
male: 93.4%
female: 87.2% (1995 est.)','9b0576378b5c2e8def4e35394d8df380a9643822cf1d496bdf17aaf95b6cfc02','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b6b979a5d4d51a598f70611c2f3c46ca95f791e4822903e067ece12e8cbe63b',1998,'TH','Thailand','people-and-society',879,'Population: 60,037,366 (July 1998 est.)
Age structure:
0-14 years: 24% (male 7,440,863; female 7,169,837)
15-64 years: 70% (male 20,605,197; female
21,210,697)
65 years and over: 6% (male 1 ,596,267; female
2,014,505) (July 1998 est.)
Population growth rate: 0.97% (1998 est.)
Birth rate: 1 6.76 births/1 ,000 population (1 998 est.)
Death rate: 7.1 1 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 mafe(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.79 male(s)/female (1 998 est.)
Infant mortality rate: 30.82 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 69 years
male: 65.35 years
female: 72.83 years (1 998 est.)
Total fertility rate: 1 .84 children born/woman (1 998
est.)
Nationality:
noun; Thai (singular and plural)
adjective: Thai
Ethnic groups: Thai 75%, Chinese 14%, other 11%
Religions: Buddhism 95%, Muslim 3.8%,
Christianity 0.5%, Hinduism 0.1%, other 0.6% (1991)
Languages: Thai, English (secondary language of
the elite), ethnic and regional dialects
Literacy:
definition: age 15 and over can read and write
total population: 93.8%
male: 96%
female: 91 .6% (1 995 est.)
Population: 4,905,827 (July 1998 est.)
Age structure:
0-14 years: 48% (male 1,190,812; female 1,180,739)
15-64 years: 49% (male 1,175,570; female
1,252,274)
65 years and over: 3% (male 48,483; female 57,949)
(July 1998 est.)
Population growth rate: 3.52% (1998 est.)
Birth rate: 45.23 births/1,000 population (1998 est.)
Death rate: 10 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.83 male(s)/female (1998 est.)
Infant mortality rate: 79.8 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 58.78 years
male: 56.52 years
female: 61 .1 2 years (1 998 est.)
Total fertility rate: 6.6 children born/woman (1998
est.)
Nationality:
noun: Togolese (singular and plural)
adjective: Togolese
Ethnic groups: native African (37 tribes; largest and
most important are Ewe, Mina, and Kabre) 99%,
European and Syrian-Lebanese less than 1%
Religions: indigenous beliefs 70%, Christian 20%,
Muslim 10%
Languages: French (official and the language of
commerce), Ewe and Mina (the two major African
462
languages in the south), Kabye (sometimes spelled
Kabiye) and Dagomba (the two major African
languages in the north)
Literacy:
definition : age 15 and over can read and write
total population: 51.7%
male: 67%
female: 37% (1995 est.)
i Government
Country name:
conventional long form: Togolese Republic
conventional short form: Togo
local long form: Republique Togolaise
local short form: none
former: French Togo
Data code: TO
Government type: republic under transition to
multiparty democratic rule
National capital: Lome
Administrative divisions: 21 circumscriptions
(circonscriptions, singular — circonscription); Amlame,
Aneho, Atakpame, Badou, Bafilo, Bassar, Dapaong,
Kande, Kara, Kpalime, Lome, Niamtougou, Notse,
Pagouda, Sansanne-Mango, Sokode, Sotouboua,
Tabligbo, Tchamba, Tsevie, Vogan
note : the 21 units may have become second-order
administrative divisions with the imposition of a new
first-order level of five prefectures (singular-
prefecture) named De La Kara, Des Plateaux, Des
Savanes, Du Centre, and Maritime
Independence: 27 April 1960 (from
French-administered UN trusteeship)
National holiday: Independence Day, 27 April
(1960)
Constitution: multiparty draft constitution approved
by High Council of the Republic 1 July 1 992; adopted
by public referendum 27 September 1992
Legal system: French-based court system
Suffrage: NA years of age; universal adult
Executive branch:
chief of state: President Gen. Gnassingbe EYADEMA
(since 14 April 1967)
head of government: Prime Minister Kwassi KLUTSE
(since August 1996)
cabinet: Council of Ministers appointed by the
president and the prime minister
elections: president elected by popular vote for a
five-year term; election last held 25 August 1 993 (next
to be held June 1 998); prime minister appointed by the
president
election results: Gnassingbe EYADEMA elected
president; percent of vote— Gnassingbe EYADEMA
96.5%; note— all major opposition parties boycotted
the election
Legislative branch: unicameral National Assembly
(81 seats; members are elected by popular vote to
serve five-year terms)
elections: last held 6 and 20 February 1 994 (next to be
held NA 1999)
election results: percent of vote by party— NA; seats
by party-CAR 36, RPT 35, UTD 7, UJD 2, CFN 1
note: as a result of a byelection in August 1996,
ordered by the Supreme Court for three seats of the
Action Committee for Renewal and the Togolese
Union for Democracy, representation in the National
Assembly changed to RPT 38, CAR 34, UTD 6, UJD
2, and CFN 1 ; as a result of subsequent defections
from the CAR to the RPT and the merging of the UJD
with the RPT, representation in the National Assembly
in August 1 997 was RPT 42, CAR 32, UTD 5, CFN 1 ,
independent 1
Judicial branch: Court of Appeal or Cour d''Appel;
Supreme Court or Cour Supreme
Political parties and leaders: Rally of the Togolese
People or RPT [President Gen. Gnassingbe
EYADEMA]; Coordination des Forces Nouvelles or
CFN [Joseph KOFFIGOH]; Togolese Union for
Democracy or UTD [Edem KODJO]; Action
Committee for Renewal or CAR [Yao AGBOYIBOR];
Union for Democracy and Solidarity or UDS [Antoine
FOLLY]; Pan-African Sociodemocrats Group or GSP,
an alliance of three radical parties: CDPA, PDR, and
PSP; Democratic Convention of African Peoples or
CDPA [Leopold GNININVI]; Party for Democracy and
Renewal or PDR [Zarifou AYEVA]; Pan-African Social
Party or PSP [Francis AGBAGLI]; Union of Forces for
Change or UFC [Gilchrist OLYMPIO (in exile);
Jeane-Pierre FABRE, general secretary in Togo];
Union of Justice and Democracy or UJD [Lai
TAXPANDJAN]
note: Rally of the Togolese People or RPT, led by
President EYADEMA, was the only party until the
formation of multiple parties was legalized 12 April
1991
International organization participation: ACCT,
ACP, AfDB, CCC, ECA, ECOWAS, Entente, FAO, FZ,
G-77, IBRD, ICAO, ICC, ICFTU, ICRM, IDA, IFAD,
IFC, IFRCS, ILO, IMF, IMO, Intelsat, Interpol, IOC,
ITU, MINURSO, MIPONUH, NAM, OAU, OIC
(observer), UN, UNCTAD, UNESCO, UNIDO, UPU,
WADB, WAEMU, WCL, WFTU, WHO, WIPO, WMO,
WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Pascal BODJONA
chancery: 2208 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [1] (202) 234-4212
FAX: [1] (202) 232-3190
Diplomatic representation from the US:
chief of mission: Ambassador Brenda Brown
SCHOONOVER
embassy: Rue Pelletier Caventou and Rue Vauban,
Lome
mailing address: B. P. 852, Lome
telephone: [228] 21 77 17, 21 29 91 through 21 29 94
FAX: [228] 21 79 52
Flag description: five equal horizontal bands of
green (top and bottom) alternating with yellow; there is
a white five-pointed star on a red square in the upper
hoist-side corner; uses the popular pan-African colors
of Ethiopia','28b943a1a33b0156bceb639c38413627869ef7b45661a608d441d589275ba64a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edc86e7f4bbd232b745fb32cf3f0b964e889edc8f16878ac29fe656e5a723ead',1998,'TK','Tokelau','people-and-society',887,'Population: 1 ,443 (July 1998 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: HA
Population growth rate: -1.35% (1998 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: HA
male : HA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun:Tokelauan(s)
adjective: Tokelauan
Ethnic groups: Polynesian
Religions: Congregational Christian Church 70%,
Roman Catholic 28%, other 2%
note: on Atafu, all Congregational Christian Church of
Samoa; on Nukunonu, all Roman Catholic; on
Fakaofo, both denominations, with the
Congregational Christian Church predominant
Languages: Tokelauan (a Polynesian language),
English','60d15812b5e4726cb57d78ccad11b003902800526ab8712b431738a62589b2a8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe71fce1a5394ddf35a534a828b8980660d7df44b3052818d4276815e77bdda7',1998,'AF','Afghanistan','people-and-society',896,'Population: 16,249 (July 1998 est.)
Age structure:
0-14 years: (male 2,666; female 2,588)
15-64 years: (male 5,418; female 4,907)
65 years and over: (male 293; female 377) (July 1 998
est.)
Population growth rate: 3.77% (1998 est.)
Birth rate: 27.14 births/1,000 population (1998 est.)
Death rate: 4.98 deaths/1 ,000 population (1 998 est.)
Net migration rate: 15.57 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .1 male(s)/female
65 years and over: 0.78 male(s)/female (1 998 est.)
Infant mortality rate: 21 .7 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population : 72.1 5 years
male: 70.21 years
female: 742 years (1998 est.)
Total fertility rate: 3.32 children born/woman (1998
est.)
Nationality:
noun: none
adjective: none
Ethnic groups: black
Religions: Baptist 41 .2%, Methodist 1 8.9%,
Anglican 18.3%, Seventh-Day Adventist 1 .7%, other
19.9% (1980)
Languages: English (official)
Literacy:
definition : age 15 and over has ever attended school
total population: 98%
male: 99%
fema/e; 98% (1970 est.)
Population: 185,204 (July 1998 est.)
Age structure:
0-14 years: 39% (male 36,865; female 35,576)
15-64 years: 58% (male 55,066; female 52,142)
65 years and over: 3% (male 3,01 3; female 2,542)
(July 1998 est.)
Population growth rate: 2.07% (1998 est.)
Birth rate: 29.18 births/1,000 population (1998 est.)
Death rate: 8.44 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/fema!e
15-64 years: 1 .06 male(s)/female
65 years and over: 1.19 male(s)/female (1 998 est.)
Infant mortality rate: 61 .27 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 61 years
male: 59.02 years
female: 63.07 years (1 998 est.)
Total fertility rate: 3.74 children born/woman (1998
est.)
Nationality:
noun.''Ni-Vanuatu (singular and plural)
adjective: Ni-Vanuatu
Ethnic groups: indigenous Melanesian 94%,
French 4%, Vietnamese, Chinese, Pacific Islanders
Religions: Presbyterian 36.7%, Anglican 15%,
Catholic 15%, indigenous beliefs 7.6%, Seventh-Day
Adventist 6.2%, Church of Christ 3.8%, other 15.7%
Languages: English (official), French (official),
pidgin (known as Bislama or Bichelama)
498
Literacy:
definition: age 15 and over can read and write
total population: 53%
male: 57%
fema/e:48%(1979 est.)','c67d122890d78ab6c9dc1cb9f8c36954d06651d53075ac1a3baa0bb976894411','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ae7750d6cf707e2bb3aee61efb9be2f71ac7f0cf40d5c2b1642f21452ef1f20',1998,'BS','Bahamas','people-and-society',899,'Population: 22,167,195 (July 1998 est.)
Age structure:
0-14 years: 51% (male 5,682,510; female 5,643,962)
15-64 years: 47% (male 5,157,818; female
5,199,080)
65 years and over: 2% (male 236,374; female
247,451) (July 1998 est.)
Population growth rate: 2.85% (1998 est.)
Birthrate: 49.21 births/1,000 population (1998 est.)
Death rate: 1 8.95 deaths/1 ,000 population (1 998
est.)
Net migration rate: -1 .8 migrant(s)/1 ,000 population
(1998 est.)
note: Uganda is host to refugees from a number of
neighboring countries, including: Sudan 175,000,
Rwanda possibly 10,000, and Democratic Republic of
the Congo about 5,000
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0,95 male(s)/female (1 998 est.)
Infant mortality rate: 92.86 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 42.6 years
male: 41 .81 years
female: 43.41 years (1998 est.)
Total fertility rate: 7.09 children born/woman (1998
est.)
Nationality:
noun: Ugandan(s)
adjective: Ugandan
Ethnic groups: Baganda 17%, Karamojong 12%,
Basogo 8%, Iteso 8%, Langi 6%, Rwanda 6%, Bagisu
5%, Acholi 4%, Lugbara 4%, Bunyoro 3%, Batobo 3%,
non-African (European, Asian, Arab) 1%, other 23%
Religions: Roman Catholic 33%, Protestant 33%,
Muslim 16%, indigenous beliefs 18%
Languages: English (official national language,
taught in grade schools, used in courts of law and by
most newspapers and some radio broadcasts),
Ganda or Luganda (most widely used of the
Niger-Congo languages, preferred for native
language publications and may be taught in school),
other Niger-Congo languages, Nilo-Saharan
languages, Swahili, Arabic
Literacy:
definition: age 1 5 and over can read and write
total population: 61. 8%
male: 73.7%
female: 50.2% (1995 est.)','f148bce8afa13925287306bf91d074b825d1bb0a2d3b7e0f186b1a324e277131','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80fc7152c9e9065e29c149500cec041e43fe81a15ce6481b138bd842fb1fe2ff',1998,'AE','United Arab Emirates','people-and-society',903,'Population: 2,303,088 (July 1998 est.)
note: includes 1,561,840 non-nationals (July 1998
est.)
Age structure:
0-14 years: 32% (male 372,41 3; female 356,834)
15-64 years: 66% (male 995,798; female 535,014)
65 years and over: 2% (male 29,1 69; female 1 3,860)
(July 1998 est.)
Population growth rate: 1 .78% (1 998 est.)
Birth rate: 18.61 births/1,000 population (1998 est.)
Death rate: 3.06 deaths/1 ,000 population (1 998 est.)
Net migration rate: 2.25 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth : 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .86 male(s)/female
65 years and over: 2.1 male(s)/female (1 998 est.)
Infant mortality rate: 14.77 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 74.93 years
male: 73.5 years
female: 76.44 years (1998 est.)
Total fertility rate: 3.56 children born/woman (1998
est.)
Nationality:
noun: Emirian(s)
adjective: Emirian
Ethnic groups: Emiri 19%, other Arab and Iranian
23%, South Asian 50%, other expatriates (includes
Westerners and East Asians) 8% (1982)
note : less than 20% are UAE citizens (1982)
Religions: Muslim 96% (Shi''a 16%), Christian,
Hindu, and other 4%
Languages: Arabic (official), Persian, English, Hindi,
Urdu
Literacy:
definition: age 15 and over can read and write but
definition of literacy not available
total population: 79.2%
male: 78.9%
female: 79.8% (1995 est.)','1fceed775b3e5091920dea0ffe8418b8475122f35cb486e46e2c239fb1a18f2e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05faf812e4aa24856fdaab55b39e4d724611da446a7823f97f7d0dc59f2702d0',1998,'UY','Uruguay','people-and-society',911,'Population: 3,284,841 (July 1998 est.)
Age structure:
0-14 years: 24% (male 405,894; female 386,479)
15-64 years: 63% (male 1 ,01 9,682; female
1,048,844)
65 years and over: 13% (male 176,467; female
247,475) (July 1998 est.)
Population growth rate: 0.71% (1998 est.)
Birth rate: 1 6.92 births/1 ,000 population (1 998 est.)
Death rate: 8.89 deaths/1 ,000 population (1998 est.)
Net migration rate: -0.91 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 ma!e(s)/female
under 15 years: 1 .05 ma!e(s)/fema!e
15-64 years: 0.97 male(s)/female
65 years and over: 0.71 male(s)/fema!e (1998 est.)
Infant mortality rate: 14.11 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.53 years
male: 72.39 years
female: 78.84 years (1998 est.)
Total fertility rate: 2.29 children born/woman (1998
est.)
Nationality:
noun: Uruguayan(s)
adjective: Uruguayan
Ethnic groups: white 88%, mestizo 8%, black 4%,
Amerindian, practically nonexistent
Religions: Roman Catholic 66% (less than one-half of
the adult population attends church regularly),
Protestant 2%, Jewish 2%, nonprofessing or other 30%
Languages: Spanish, Portunol, or Brazilero
(Portuguese-Spanish mix on the Brazilian frontier)
Literacy:
definition: age 15 and over can read and write
total population: 97.3%
male: 96.9%
female: 97.7% (1995 est.)','1a79c68e8bfa017317822d617b2fe01479de1240209cb9478af988ec90a6d237','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6856f732d6fd1aca92cba2fd97f916e708e73b558faf6f9fa52e758f4c91d1c',1998,'UZ','Uzbekistan','people-and-society',920,'Population: 23,784,321 (July 1998 est.)
Age structure:
0-14 years: 38% (male 4,591 ,140; female 4,451 ,246)
15-64 years: 57% (male 6,755,371 ; female
6,874,483)
65 years and over: 5% (male 435,036; female
677,045) (July 1998 est.)
Population growth rate: 1.33% (1998 est.)
Birth rate: 23.69 births/1,000 population (1998 est.)
Death rate: 7.68 deaths/1 ,000 population (1 998 est.)
Net migration rate: -2.68 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.64 male(s)/female (1998 est.)
Infant mortality rate: 71 .04 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population : 64.1 1 years
male: 60.49 years
female: 67.91 years (1998 est.)
Total fertility rate: 2.87 children born/woman (1998
est.)
Nationality:
noun: Uzbekistani(s)
adjective: Uzbekistani
Ethnic groups: Uzbek 80%, Russian 5.5%, Tajik
5%, Kazakh 3%, Karakalpak 2.5%, Tatar 1.5%, other
2.5% (1996 est.)
Religions: Muslim 88% (mostly Sunnis), Eastern
Orthodox 9%, other 3%
Languages: Uzbek 74.3%, Russian 14.2%, Tajik
4.4%, other 7.1%
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 96% (1989 est.)','2e908a7ded931e82f2938cc02076cb87066086b2cb421c519819ec42a9a595a9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c3cc627abaca9261a71f27ec702bfd9ac732cb4930d52e4f55a53a57c452e48',1998,'VU','Vanuatu','people-and-society',933,'Population: 22,803,409 (July 1998 est.)
Age structure:
0-14 years: 34% (male 3,979,045; female 3,733,364)
15-64 years: 62% (male 7,054,525; female
7,011,814)
65 years and over: 4% (male 469,799; female
554,862) (July 1998 est.)
Population growth rate: 1 .77% (1 998 est.)
Birth rate: 22.96 births/1,000 population (1998 est.)
Death rate: 4.98 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.27 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1 .01 maie(s)/fema!e
65 years and over: 0.85 male(s)/female (1 998 est.)
Infant mortality rate: 27.52 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 72.66 years
male: 69.68 years
female: 75.87 years (1998 est.)
Total fertility rate: 2.7 children born/woman (1998
est.)
Nationality:
noun: Venezuelan(s)
adjective: Venezuelan
Ethnic groups: mestizo 67%, white 21%, black
10%, Amerindian 2%
Religions: nominally Roman Catholic 96%,
Protestant 2%
Languages: Spanish (official), native dialects
spoken by about 200,000 Amerindians in the remote
interior
Literacy:
definition: age 15 and over can read and write
total population: 91.1%
male: 91 .8%
female: 90.3% (1995 est.)
500','8e1177edc8f08db0eecf7adf7218c881637c967d051375d0509de10910343a5d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('056f12abf5fa577110ee8d3d293b8ddde824089038a16ec3d5a35728d3385206',1998,'PR','Puerto Rico','people-and-society',934,'Population: 1 1 8,21 1 (July 1 998 est.)
note: West Indian (45% born in the Virgin islands and
29% born elsewhere in the West Indies) 74%, US
mainland 13%, Puerto Rican 5%, other 8%
Age structure:
0-14 years: 29% (male 17,310; female 16,502)
15-64 years: 64% (male 34,434; female 40,645)
65 years and over: 1% (male 4,065; female 5,255)
(July 1998 est.)
Population growth rate: 1.16% (1998 est.)
Birth rate: 16.45 births/1,000 population (1998 est.)
Death rate: 5.01 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0.13 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.84 male(s)/fema!e
65 years and over: 0.77 male(s)/female (1998 est.)
Infant mortality rate: 9.6 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.3 years
male : 74.68 years
female: 82.15 years (1998 est.)
Total fertility rate: 2.32 children born/woman (1998
est.)
Nationality:
noun: Virgin Islander(s)
adjective: Virgin Islander
Ethnic groups: black 80%, white 15%, other 5%
Religions: Baptist 42%, Roman Catholic 34%,
Episcopalian 17%, other 7%
Languages: English (official), Spanish, Creole
Literacy: NA','89b655ee7db6b9254170f185312304ecf8489c676f5325d98ba4b1b3dc30b410','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2721db71a0bccad8ca00bdbd85f7458a9f945b2102a90826478e13062292777e',1998,'MP','Northern Mariana Islands','people-and-society',939,'Population: no indigenous inhabitants
note: there are no permanent US military personnel
on the island; some civilian contract personnel remain
(1998 est.)','036e1a81a391c0e0c799f6ce1d32219c805cd00a0d770d975260b34316f8934a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39e56e45840ddbb40998970d833f2a25137681ebfcd6f7baaca43f714d3547c1',1998,'EH','Western Sahara','people-and-society',942,'Population: 233,730 (July 1998 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: HA
Population growth rate: 2.4% (1998 est.)
Birth rate: 45.78 births/1,000 population (1998 est.)
Death rate: 1 7.05 deaths/1 ,000 population (1 998
est.)
Net migration rate: -4.78 migrant(s)/1 ,000
population (1998 est.)
Infant mortality rate: 1 39.74 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 48.41 years
male: 47.32 years
female: 49.83 years (1998 est.)
Total fertility rate: 6.75 children born/woman (1998
est.)
Nationality:
noun: Sahrawi(s), Sahraoui(s)
adjective: Sahrawian, Sahraouian
Ethnic groups: Arab, Berber
Religions: Muslim
Languages: Hassaniya Arabic, Moroccan Arabic
Literacy: NA
Population: 5,926,466,814 (July 1998 est.)
Population growth rate: 1.3% (1998 est.)
Birth rate: 22 births/1,000 population (1998 est.)
Death rate: 9 deaths/1 ,000 population (1998 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .06 male(s)/fema!e
15-64 years: 1 .02 ma!e(s)/female
65 years and over: 0.77 ma!e(s)/female
Infant mortality rate: 58 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 63 years
male: 61 years
female: 65 years (1 998 est.)
Total fertility rate: 2.9 children born/woman (1998
est.)','fb3a72c6c4f6ebbf8deae42b6026b214b117678a346f3eb53b3cc3d287b19271','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82320606a6478e852f2ff95a0f0638aa73b74d9026d352713289cc4507988b48',1998,'YE','Yemen','people-and-society',950,'Population: 16,387,963 (July 1998 est.)
note: other estimates range as high as 16.6 million
Age structure:
0-14 years: 48% (male 4,01 6,052; female 3,859,079)
15-64 years: 49% (male 4,066,601 ; female
3,902,686)
65 years and over: 3% (male 280,152; female
263,393) (July 1998 est.)
Population growth rate: 3.31% (1998 est.)
Birth rate: 43.36 births/1,000 population (1998 est.)
Death rate: 10.27 deaths/1,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 ma!e(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 1 .06 male(s)/female (1998 est.)
Infant mortality rate: 72.2 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 59.47 years
male: 57.71 years
female: 61 .32 years (1 998 est.)
Total fertility rate: 7.14 children born/woman (1998
est.)
Nationality:
noun: Yemeni(s)
adjective: Yemeni
Ethnic groups: predominantly Arab; Afro-Arab
concentrations in western coastal locations; South
Asians in southern regions; small European
communities in major metropolitan areas
Religions: Muslim including Shaf''i (Sunni) and Zaydi
(Shi''a), small numbers of Jewish, Christian, and Hindu
Languages: Arabic
Literacy:
definition: age 1 5 and over can read and write
total population: 38%
male: 53%
female: 26% (1990 est.)','7f1fb83f928066406db80324fabcc34f5db409d3e123b6a38827598df11bf2ea','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eeec419a5353cb27ab54fc2e8aaf837958977f17fd6b31312ce2736ca288bad',1998,'ZM','Zambia','people-and-society',958,'Population: 9,460,736 (July 1998 est.)
Age structure:
0-14 years: 49% (male 2,342,043; female 2,316,357)
15-64 years: 48% (male 2,244,251 ; female
2,326,159)
65 years and over: 3% (male 1 06,950; female
124,976) (July 1998 est.)
Population growth rate: 2.13% (1998 est.)
Birth rate: 44.6 births/1,000 population (1998 est.)
Death rate: 22.55 deaths/1 ,000 population (1998
est.)
Net migration rate: -0.8 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 ma!e(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.85 male(s)/femaie (1 998 est.)
Infant mortality rate: 92.57 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 37.07 years
male: 36.81 years
female: 37.33 years (1998 est.)
Total fertility rate: 6.41 children born/woman (1998
est.)
Nationality:
noun : Zambian(s)
adjective: Zambian
Ethnic groups: African 98.7%, European 1 .1%,
other 0.2%
Religions: Christian 50%-75%, Muslim and Hindu
24%-49%, indigenous beliefs 1%
Languages: English (official), major vernaculars—
Bemba, Kaonda, Lozi, Lunda, Luvale, Nyanja, Tonga,
and about 70 other indigenous languages
Literacy:
definition: age 15 and over can read and write in
English
total population: 78.2%
male: 85.6%
female: 71 .3% (1995 est.)','51fdf95ebc55e43c2f76e2af6839f8c949dd523f05ec7260736c00d81f156383','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ee0853b4f3eef6989fb7488852799df413813045f586c57b725c6787d99bc6e',1998,'US','United States','military-and-security',13,'Military branches
Military manpower— military age
Military manpower— availability
males age 15-49
females age 15-49
Military manpower— fit for military service
males
females
Military manpower— reaching military age
annually
males
females
Military expenditures— dollar figure
Military expenditures— percent of GDP
Military— note
Military branches: NA; note— the military does not
exist on a national basis; some elements of the former
Army, Air and Air Defense Forces, National Guard,
Border Guard Forces, National Police Force
(Sarandoi), and tribal militias still exist but are
factionalized among the various groups
Military manpower— military age: NA years of age
Military manpower— availability:
males age 15-49 : NA
Military manpower— fit for military service:
males: NA
Military manpower— reaching military age
annually:
males: NA
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%','59e07b719d9f1e27b00d1daa8e387b9e7dde2888c004179ed4b414dd3084f31a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9929b0e26b793f6b6d65cf05b8192f2949c53cf86aff5aff78e7d5c2a5f0ed3',1998,'DZ','Algeria','military-and-security',22,'Military branches: Army, Navy, Air and Air Defense
Forces, Interior Ministry Troops, Border Guards
Military manpower— military age: 1 9 years of age
Military manpower— availability:
males age 15-49: 749,633 (1 998 est.)
Military manpower— fit for military service:
males: 609,986 (1998 est.)
Military manpower— reaching military age
annually:
males: 32,367 (1998 est.)
Military expenditures— dollar figure: $42 million
(1996)
Military expenditures— percent of GDP: 1 .5% to
2.0% (1996)
Military branches: National Popular Army, Navy, Air
Force, Territorial Air Defense, National Gendarmerie
Military manpower— military age: 19 years of age
Military manpower— availability:
males age 15-49: 7,949,708 (1998 est.)
Military manpower— fit for military service:
males: 4,871 ,931 (1998 est.)
Military manpower— reaching military age
annually:
males: 347, 952 (1998 est.)
Military expenditures— dollar figure: $1 .3 billion
(1994)
Military expenditures— percent of GDP: 2.7%
(1994)
Military branches: Army, Navy, Air Force, Marines,
Civil Guard, National Police, Coastal Civil Guard
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 10,387,539 (1998 est.)
Military manpower— fit for military service:
males: 8,369,756 (1998 est.)
Military manpower— reaching military age
annually:
males: 323,552 (1998 est.)
Military expenditures— dollar figure: $6.3 billion
(1995)
Military expenditures— percent of GDP: 1 .4%
(1995)','cce2dd579cacc16cfd790ec4db84e20f778d60a4f53b3dfe950abe507a1115cf','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c42c564a88137cda03c979c3b4bd299d53cf29c4243e590b34581a01795ad5cf',1998,'AS','American Samoa','military-and-security',34,'Military— note: defense is the responsibility of the
US
Military— note: defense is the responsibility of
France and Spain
Military branches: Army, Navy, Air and Air Defense
Forces, National Police Force
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 2,476,766 (1998 est.)
Military manpower— fit for military service:
males: 1,246,349 (1998 est.)
Military manpower— reaching military age
annually:
males: 105,283 (1998 est.)
Military expenditures— dollar figure: $1 .2 billion
(1998 est.)
Military expenditures— percent of GDP: 31 %
(1993)','b042500c82b73a545ea110f8b18c2403c86ab3b0990f404a672173dc40b68a7a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('468576b3f83913bbd9539905abaf093cb7a9958b15ceda9eb9fd41b5b3522b33',1998,'AQ','Antarctica','military-and-security',43,'Military— note: the Antarctic Treaty prohibits any
measures of a military nature, such as the
establishment of military bases and fortifications, the
carrying out of military maneuvers, or the testing of
any type of weapon; it permits the use of military
personnel or equipment for scientific research or for
any other peaceful purposes
Military branches: Argentine Army, Navy of the
Argentine Republic (includes Naval Aviation, Marines,
and Coast Guard), Argentine Air Force, National
Gendarmerie, National Aeronautical Police Force
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 9,056,532 (1998 est.)
Military manpower— fit for military service:
males: 7,344,910 (1998 est.)
Military manpower— reaching military age
annually:
males: 332,008 (1998 est.)
Military expenditures— dollar figure: $4.6 billion
(1997)
Military expenditures— percent of GDP: 1 .5%
(1997)
Military branches: Army, Air Force, Air Defense
Force, Security Forces (internal and border troops)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 914,134 (1998 est.)
Military manpower— fit for military service:
males: 726,938 (1998 est.)
Military manpower— reaching military age
annually:
males: 31 ,81 4 (1998 est.)
Military expenditures— dollar figure: 33.3 billion
drams (1998); note— conversion of defense
expenditures into US dollars using prevailing
exchange rates could produce misleading results
Military expenditures— percent of GDP: NA%
23
Armenia (continued)
Military— note: defense is the responsibility of the
Kingdom of the Netherlands
Military— note: defense is the responsibility of
Australia; periodic visits by the Royal Australian Navy
and Royal Australian Air Force
Military branches: Australian Army, Royal
Australian Navy, Royal Australian Air Force
Military manpower— military age: 1 7 years of age
Military manpower— availability:
males age 15-49: 4,873,392 (1998 est.)
Military manpower— fit for military service:
males: 4,206,1 04 (1998 est.)
Military manpower— reaching military age
annually:
males: 128,524 (1998 est.)
Military expenditures— dollar figure: $8.2 billion
(FY97/98)
Military expenditures— percent of GDP: 1 .9%
(FY97/98)
Military branches: Army (includes Flying Division)
Military manpower— military age: 19 years of age
31
Austria (continued)
Military manpower— availability:
males age 15-49: 2,098,409 (1998 est.)
Military manpower— fit for military service:
maies: 1,744,035 (1998 est.)
Military manpower— reaching military age
annually:
males: 46,854 (1998 est.)
Military expenditures— dollar figure: $1 .8 billion
(1998 est.)
Military expenditures— percent of GDP: 0.83%
(1998 est.)','40c5f74661ea4ccbfc2adbd700f1cc0c807b6d310bc03740a2f2c157c6f3b912','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('010704222b16fd38743d5b9903cef8aa7e57ffdc499ea524415712ddca8971ea',1998,'AG','Antigua and Barbuda','military-and-security',51,'Military branches: Royal Antigua and Barbuda
Defense Force, Royal Antigua and Barbuda Police
Force (includes the Coast Guard)
Military expenditures— dollar figure: $1 .4 million
(FY90/91)
Military expenditures— percent of GDP: 1 %
(FY90/91)','a2fd185309f0cc20e66a0cfa6305f687888f88f1701a7583c924c0fbeed91795','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdaea1f9bb3165f3546de5a5e1d2e43cb9588f660e4d61d78a36d47a42cc826e',1998,'AZ','Azerbaijan','military-and-security',62,'Military branches: Army, Navy, Air and Air Defense
Forces, Border Guards
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 2,01 1 ,076 (1 998 est.)
Military manpower— fit for military service:
males: 1,61 6, 41 2 (1998 est.)
Military manpower— reaching military age
annually:
males: 71,922 (1998 est.)
Military expenditures— dollar figure: 1 05.7 billion
manats (1998 est.); note— conversion of defense
expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures— percent of GDP: NA%','b7a2f4fd063bee8f834eb1116e93373deaaf3513934bef7294abfb9817839e14','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b4f8e0dcb992ff3af574e6425aed07393ea0d71e53622755b4978a3a527de92',1998,'BS','Bahamas','military-and-security',67,'Military branches: Royal Bahamas Defense Force
(Coast Guard only), Royal Bahamas Police Force
Military expenditures— dollar figure: $22.9 million
(FY96/97)
Military expenditures— percent of GDP: 3.8%
(FY95/96)
Military branches: no regular military forces; Police
Force (consists of 56 full- and part-time personnel)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military branches: Army, Navy, Air Wing
Military manpower— availability:
males age 15-49: 4,672,307 (1998 est.)
Military manpower— fit for military service:
males: 2,534,993 (1998 est.)
Military expenditures— dollar figure: $56 million
(FY93/94)
Military expenditures— percent of GDP: 1 .7%
(FY93/94)','8680e9adcb562d63e6054dece215d28842a3f9e46c5c557c83efee1d4fb480bb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdf725e231bb35cf992dc922bf4abb97c16f55a1b88aa0b1717c413d5675c826',1998,'BH','Bahrain','military-and-security',75,'Military branches: Ground Force, Navy, Air Force,
Coast Guard, Internal Security Forces
Military manpower— military age: 15 years of age
Military manpower— availability:
males age 15-49: 218,831 (1998 est.)
Military manpower— fit for military service:
males: 120,753 (1998 est.)
Military manpower— reaching military age
annually:
males: NA
Military expenditures— dollar figure: $256 million
(1994)
Baker Island
(territory of the US)
=
0 _ c
0
/ u day beacon
).25 0.5 km
0.25 0.5 mi
North Pacific
Ocean
G e o g r a p h y
Location: Oceania, atoll in the North Pacific Ocean,
about one-half of the way from Hawaii to Australia
Geographic coordinates: 0 13 N, 176 31 W
Map references: Oceania
Area:
total: 1.4 sq km
land: 1.4 sq km
water: 0 sq km
Area— comparative: about 2.5 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 4.8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: equatorial; scant rainfall, constant wind,
burning sun
Terrain: low, nearly level coral island surrounded by
a narrow fringing reef
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 8 m
Natural resources: guano (deposits worked until
1891)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures : 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment— current issues: no natural fresh
water resources
Environment— international agreements:
party to: NA
signed, but not ratified: N A
Geography— note: treeless, sparse, and scattered
Military expenditures— percent of GDP: 5.4%
(1995)','05c031958c179ace0b8e89f974df474c5ad8e7329f11c742b3a34cd0fe2312b3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a02c15d68ed3c2f1ac486e6e6d9b33b95d39605e92decfaf6e57fb468271304c',1998,'BD','Bangladesh','military-and-security',80,'Military branches: Army, Navy, Air Force,
paramilitary forces (includes Bangladesh Rifles,
Bangladesh Ansars, Armed Police Reserve, Village
Defense Parties, National Cadet Corps)
Military manpower— availability:
males age 15-49: 33,780,741 (1998 est.)
Military manpower— fit for military service:
males: 19,984,761 (1998 est.)
Military expenditures— dollar figure: $481 million
(FY95/96)
Military expenditures— percent of GDP: 1 .7%
(FY95/96)','0e44c3f267bcc236b8315f3154692b1c0383909e406f8e769bb3a786f7caf368','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6038ab99021aa3eec9b6f0247028a177d89b26cce68f57830e8fb1d4e5f52811',1998,'LC','Saint Lucia','military-and-security',89,'Military branches: Royal Barbados Defense Force
(includes Ground Forces and Coast Guard), Royal
Barbados Police Force
Military manpower— availability:
males age 15-49: 71,891 (1998 est.)
Military manpower— fit for military service:
males: 49,562 (1998 est.)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
j Transnational Issues
Disputes— international: none
Illicit drugs: one of many Caribbean transshipment
points for narcotics bound for the US and Europe
42
Bassas da India ■ ■
(possession of France) §||','4ce9adf28e04a0c19310db96ae7b77813ec9a8c783e4ae21046b6cb75e4b9a0f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b9735321e4a1745d275e662e8491a2ebab6c4831f2360b5ccf21639026f36d8',1998,'FR','France','military-and-security',103,'Military branches: Army, Air Force, Air Defense
Force, Interior Ministry Troops, Border Guards
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49:2,681,014 (1998 est.)
Military manpower— fit for military service:
males: 2,099,860 (1998 est.)
Military manpower— reaching military age
annually:
males: 78,780 (1998 est.)
Military expenditures— dollar figure: 4.5 trillion
rubles (1997 est.); note— conversion of defense
expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures— percent of GDP: 1 .3%
(1997 est.)
Military branches: Army, Navy, Air Force, National
Gendarmerie
Military manpower— military age: 1 9 years of age
Military manpower— availability:
males age 15-49: 2,549,277 (1998 est.)
Military manpower— fit for military service:
males: 2, 11 1,332 (1998 est.)
Military manpower— reaching military age
annually:
males: 63,937 (1998 est.)
Military expenditures— dollar figure: $4.6 billion
(1995)
Military expenditures— percent of GDP: 1 .7%
(1995)
Military branches: Belize Defense Force (includes
Ground Forces, Maritime Wing, Air Wing, and
Volunteer Guard), Belize National Police
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 56,142 (1998 est.)
Military manpower— fit for military service:
males: 33,328 (1998 est.)
Military manpower— reaching military age
annually:
males: 2,536 (1998 est.)
Military expenditures— dollar figure: $15 million
(FY97/98)
Military expenditures— percent of GDP: 2%
Military branches: Armed Forces (includes Army,
Navy, Air Force), National Gendarmerie
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 1,311,490
females age 15-49: 1 ,378,979 (1 998 est.)
note: both sexes are liable for military service
Military manpower— fit for military service:
males: 671 ,230
females: 698,290 (1998 est.)
Military manpower— reaching military age
annually:
males: 65,498
females: 65,1 12 (1998 est.)
Military expenditures— dollar figure: $33 million
(1994)
Military expenditures— percent of GDP: 3.2%
(1994)
Military branches: British Forces Falkland Islands
(includes Army, Royal Air Force, Royal Navy, and
Royal Marines), Police Force
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of the
UK
Military branches: Army, Navy, Air Force, Frontier
Guard (includes Sea Guard)
Military manpower— military age: 17 years of age
Military manpower— availability:
males age 15-49 : 1 ,286,563 (1998 est.)
Military manpower— fit for military service:
males: 1,059,657 (1998 est.)
Military manpower— reaching military age
annually:
males: 33,492 (1998 est.)
Military expenditures— dollar figure: $1 .9 billion
(1995)
Military expenditures— percent of GDP: 1 .6%
(1995)
Military branches: French Forces, Gendarmerie
Military manpower— availability:
males age 15-49: 46,136 (1998 est.)
Military manpower— fit for military service:
mates: 29,878 (1998 est.)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of
Military branches: Hellenic Army, Hellenic Navy,
Hellenic Air Force, National Guard, Police
Military manpower— military age: 21 years of age
Military manpower— availability:
males age 15-49: 2,693,1 16 (1998 est.)
Military manpower— fit for military service:
males: 2,062,1 17 (1998 est.)
Military manpower— reaching military age
annually:
males: 78,894 (1998 est.)
Military expenditures— dollar figure: $4.04 billion
(1998 est.)
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of
Military branches: French Forces, Gendarmerie
Military— note: defense is the responsibility of
Military branches: French forces (Army, Navy, Air
Force), Gendarmerie
Military— note: defense is the responsibility of
Military branches: Mongolian People''s Army
(includes Internal Security Forces and Frontier
Guards), Air Force
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 680,345 (1998 est.)
320
Military manpower— fit for military service:
males: 443,668 (1998 est.)
Military manpower— reaching military age
annually:
males: 28,1 12 (1998 est.)
Military expenditures— dollar figure: $22.8 million
(1992)
Military expenditures— percent of GDP: 1 %
(1992)
Military branches: Army, Naval Command, Air and
Air Defense Forces, Militia
Military manpower— availability:
males age 15-49: 4,265,778 (1 998 est.)
Military manpower— fit for military service:
males: 2,457,587 (1998 est.)
Military expenditures— dollar figure: $84 million
(1994)
Military expenditures— percent of GDP: 5.3%
(1994)
i Transnational issues
Disputes— international: none
Illicit drugs: Southern African transit hub for South
American cocaine probably destined for the European
and US markets; producer of hashish and
methaqualone
Military branches: National Defense Force (Army),
Police
Military manpower— availability:
males age 15-49: 369,826 (1998 est.)
Military manpower— fit for military service:
males: 221 ,624 (1998 est.)
Military expenditures— dollar figure: $64 million
(FY95/96)
Military expenditures— percent of GDP: 2.1%
(FY95/96)
Military branches: French forces (Army, Navy, Air
Force, and Gendarmerie)
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 182,620 (1998 est.)
Military manpower— fit for military service:
males: 93,572 (1998 est.)
Military manpower— reaching military age
annually:
males: 5,780 (1998 est.)
Military— note: defense is the responsibility of
Saint Vincent and
the Grenadines
Military branches: Royal Saint Vincent and the
Grenadines Police Force, Coast Guard
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military branches: Army, Royal Navy (includes
Royal Marines), Royal Air Force
Military manpower— availability:
males age 15-49: 14,468,079 (1998 est.)
Military manpower— fit for military service:
males: 12,069,296 (1998 est.)
Military expenditures— dollar figure: $35.1 billion
(FY95/96)
Military expenditures— percent of GDP: 3.1 %
(FY95/96)
Military branches: Department of the Army,
Department of the Navy (includes Marine Corps),
Department of the Air Force
note: the Coast Guard falls under the Department of
Transportation, but in wartime reports to the
Department of the Navy
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 69,672,51 9 (1 998 est.)
Military manpower— fit for military service:
males: NA
Military manpower— reaching military age
annually:
males: 1,990,912 (1998 est.)
Military expenditures— dollar figure: $267.2 billion
(1997 est.)
Military expenditures— percent of GDP: 3.4%
(1997 est.)
Military branches: NA
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%','6ff4147c3a38feb5c5249ccdfc99889ed709846e12beecbbfc8e4fa16409739f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b88b79c74b1b22e68b048358a3e129f92aea29ef928c44a400a649f8feb938ab',1998,'BM','Bermuda','military-and-security',115,'Military branches: Bermuda Regiment, Bermuda
Police Force, Bermuda Reserve Constabulary
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of the
UK
Military branches: Royal Bhutan Army, Palace
Guard, Militia
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 466,594 (1 998 est.)
Military manpower— fit for military service:
males: 248,985 (1998 est.)
Military manpower— reaching military age
annually:
males: 18,946 (1998 est.)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
I Tran sn at i o n a \\ I s s u e s
Disputes— international: with Nepal over 91 ,000
Bhutanese refugees in Nepal
55','b14cea9a1196a1b9e6342e74b32530fed559bb13f3e4ad2ec2f0b54f5e9c542c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83797229c71985544f3d3dfccaf3a76f71c4979805531b98508a93c84e852653',1998,'BR','Brazil','military-and-security',121,'Military branches: Army (Ejercito Boliviano), Navy
(Fuerza Naval Boliviana, includes Marines), Air Force
(Fuerza Aerea Boliviana), National Police Force
(Policia Nacional de Bolivia)
Military manpower— military age: 1 9 years of age
Military manpower— availability:
males age 15-49 : 1 ,859,823 (1 998 est.)
Military manpower— fit for military service:
males: 1,209,537 (1998 est.)
Military manpower— reaching military age
annually:
males: 82,670 (1998 est.)
Military expenditures— dollar figure: $154 million
(1997)
Military expenditures— percent of GDP: 1 .9%
(1996)
Military branches: Army
Military manpower— military age: 19 years of age
Military manpower— availability:
males age 15-49: 912,536 (1998 est.)
Military manpower— fit for military service:
males: 733,931 (1998 est.)
Military manpower— reaching military age
annually:
ma/es: 26,1 14 (1998 est.)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military branches: Botswana Defense Force
(includes Army and Air Wing), Botswana National
Police
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 335,301 (1998 est.)
Military manpower— fit for military service:
males: 177, 248 (1998 est.)
Military manpower— reaching military age
annually:
males: 18,148 (1998 est.)
Military expenditures— dollar figure: $199 million
(FY93/94)
Military expenditures— percent of GDP: 5.2%
(FY93/94)
Military branches: Army, Navy (includes Naval Air
and Marines), Air Force
Military manpower— military age: 17 years of age
Military manpower— availability:
males age 15-49: 1 ,274,297 (1 998 est.)
Military manpower— fit for military service:
males: 921 ,323 (1998 est.)
Military manpower— reaching military age
annually:
males: 53,51 4 (1998 est.)
Military expenditures— dollar figure: $94 million
(1994)
Military expenditures— percent of GDP: 0.6%
(1994)
Military branches: Army (Ejercito Peruano), Navy
(Marina de Guerra del Peru; includes Naval Air,
Marines, and Coast Guard), Air Force (Fuerza Aerea
del Peru), National Police
Military manpower-military age: 20 years of age
Military manpower— availability:
males age 15-49: 6,756,771 (1998 est.)
Military manpower— fit for military service:
males: 4,555,282 (1998 est.)
Military manpower— reaching military age
annually:
males: 264,91 5 (1998 est.)
Military expenditures— dollar figure: $998 million
(1996); note— may not include off-budget purchases
related to military modernization program
Military expenditures— percent of GDP: 1 .9%
(1996)','85fb1b7f731eecb4d21cd74446c01d20bb39ba60a8df520d63110c3adfcd26f5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1030992762f941f3813a71e9db49de0795c41a1beb696a7659cf424587158f10',1998,'NO','Norway','military-and-security',133,'Military branches: Brazilian Army, Brazilian Navy
(includes Marines), Brazilian Air Force, Federal Police
(paramilitary)
65
Brazil (continued)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 46,620,486 (1998 est.)
Military manpower— fit for military service:
males: 31 ,337,037 (1998 est.)
Military manpower— reaching military age
annually:
males: 1,806,162 (1998 est.)
Military expenditures— dollar figure: $15.1 billion
(1997)
Military expenditures— percent of GDP: 1 .9%
(1997)
Military branches: Japan Ground Self-Defense
Force (Army), Japan Maritime Self-Defense Force
(Navy), Japan Air Self-Defense Force (Air Force)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 31 ,1 05,541 (1 998 est.)
Military manpower— fit for military service:
males: 26,778,356 (1998 est.)
Military manpower— reaching military age
annually:
males: 808,846 (1998 est.)
Military expenditures— dollar figure: $48.5 billion
(FY96/97)
Military expenditures— percent of GDP: 1 %
(FY96/97)','ec287f4fdd2b947a0c6692d0a8281d1afc72c73c1be01ba53be214acc270abb2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e0a5fedabd66270c31650ed79914bca300a7e1ab65a972fdbb8a0f55d2a7851',1998,'ID','Indonesia','military-and-security',140,'Military— note: defense is the responsibility of the
UK; the US lease on Diego Garcia expires in 2016
Military branches: Land Forces, Navy, Air Force,
Royal Brunei Police
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 87,048 (1998 est.)
Military manpower— fit for military service:
males: 50,408 (1998 est.)
Military manpower— reaching military age
annually:
males: 3,1 26 (1998 est.)
Military expenditures— dollar figure: $312 million
(1994)
Military expenditures— percent of GDP: 6.2%
(1994)
Military branches: Army, Navy, Air Force, National
Police
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 59,862,854 (1998 est.)
Military manpower— fit for military service:
males: 35,148,486 (1998 est.)
Military manpower— reaching military age
annually:
males: 2,286,098 (1998 est.)
Military expenditures— dollar figure: $3.3 billion
(FY97/98)
Military expenditures— percent of GDP: 1 .3%
(FY97/98)
Military branches: Islamic Republic of Iran regular
forces (includes Ground Forces, Navy, Air and Air
Defense Forces), Revolutionary Guards (includes
Ground, Air, Navy, Qods, and
Basij-mobilization-forces), Law Enforcement Forces
Military manpower— military age: 21 years of age
Military manpower— availability:
males age 15-49 : 16,270,295 (1998 est.)
Military manpower— fit for military service:
males: 9,672,021 (1998 est.)
Military manpower— reaching military age
annually:
males: 671 ,734 (1998 est.)
Military expenditures— dollar figure: according to
official Iranian data, Iran budgeted 8,283.9 billion rials
for defense in 1997; note— conversion of defense
expenditures into US dollars using current exchange
rates could produce misleading results
Military branches: Army, Republican Guard and
Special Republican Guard, Navy, Air Force, Air
Defense Force, Border Guard Force, Interna! Security
Forces
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 5,247,809 (1998 est.)
Military manpower— fit for military service:
males: 2,941 ,01 4 (1998 est.)
Military manpower— reaching military age
annually:
males: 253,504 (1998 est.)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of the
US
Military— note: defense is the responsibility of the
US
Military branches: Army, Navy, Air Force, People''s
Defense Force, Police Force
Military manpower— availability:
males age 15-49: 1 ,040,1 47 (1 998 est.)
Military manpower— fit for military service:
males: 758,435 (1998 est.)
Military expenditures— dollar figure: $4.03 billion
(FY96/97)
Military expenditures— percent of GDP: 4.3%
(FY96/97)','2a1c5421a254e0a1003fc8c5f0f571ba916cdb77251339ab63a281c84e1c185e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0211184bfa53222ac34e8aeeb2bb06c7ef6b00b16b4b267f8de741bfe6ce2df6',1998,'BG','Bulgaria','military-and-security',148,'Military branches: Army, Navy, Air and Air Defense
Forces, Border Troops, Internal Troops
Military manpower— military age: 1 9 years of age
Military manpower— availability:
males age 15-49: 2,042,441 (1998 est.)
Military manpower— fit for military service:
males: 1,703,879 (1998 est.)
Military manpower— reaching military age
annually:
males: 61 ,643 (1998 est.)
Military expenditures— dollar figure: $41 8.6
million (1996)
Military expenditures— percent of GDP: 2.0% to
2.5% (1996)
f Transnational Issues
Disputes— international: twenty bilateral
agreements remain unsigned in a dispute over
Bulgarian nonrecognition of Macedonian as a
language distinct from Bulgarian
lliicit drugs: major European transshipment point for
Southwest Asian heroin and, to a lesser degree,
South American cocaine for the European market;
limited producer of precursor chemicals; significant
producer of amphetamines, much of which are
consumed in the Middle East','0e29a121741ea649bdab0e9b2e46cf63210469ad7c0b5bcf1e3501dc34a7262f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c306c4c0dd4e1084dd880f03990c57659e18f849bef8784ed4cb61ca11dff13',1998,'MY','Malaysia','military-and-security',158,'Military branches: Army, Navy, Air Force
Military manpower— military age: 1 8 years of age
Military manpower— availability:
maies age 15-49: 12,208,916
females age 15-49: 1 1 ,983,225 (1 998 est.)
note: both sexes liable for military service
Military manpower— fit for military service:
males: 6,523,797
females: 6,387,291 (1998 est.)
Military manpower— reaching military age
annually:
males: 488,81 8
females: 469,850 (1998 est.)
Military expenditures— dollar figure: $380 million
(FY96/97 est.)
Military expenditures— percent of GDP: NA%
Military branches: Army, Air and Air Defense
Forces, Reserve Force (Home Guards)
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 1 ,471,103 (1998 est.)
Military manpower— fit for military service:
males: 1,125,200 (1998 est.)
Military manpower— reaching military age
annually:
males: 46,964 (1998 est.)
Military expenditures— dollar figure: $423 million
(1996)
Military expenditures— percent of GDP: 2.7%
(1996)','5c1556f9957d19cfcf3065f20e58376316892b101591d030cab24ef91c26287b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed9c926878d88172787c83bd198bb1166244d1d215be991bf19fd34487a39661',1998,'BI','Burundi','military-and-security',167,'Military branches: Royal Cambodian Armed Forces
(RCAF) — created in 1993 by the merger of the
Cambodian People''s Armed Forces and the two
noncommunist resistance armies
note: there are also resistance forces comprised of
the Khmer Rouge (also known as the National United
Army or NUA) and a separate royalist resistance
movement
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 2,477,842 (1998 est.)
Military manpower— fit for military service:
males: 1 ,381 ,787 (1 998 est.)
Military manpower— reaching military age
annually:
males: 11 3,098 (1998 est.)
Military expenditures— dollar figure: $160 million
(1996)
Military expenditures— percent of GDP: NA%','49617e018677c5b7c710a604d9503b709c2d87f58e6b95e297dc0bbbc81ac5ac','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1b8636374f38d1e9499f531edf64baf051890aa109b6b58b6a10412e28a83a0',1998,'CA','Canada','military-and-security',183,'Military branches: Canadian Armed Forces
(includes Land Forces Command or LC, Maritime
Command or MC, Air Command or AC,
Communications Command or CC, Training
Command orTC), Royal Canadian Mounted Police
(RCMP)
Military manpower— military age: 17 years of age
Military manpower— availability:
males age 15-49: 8,200,963 (1998 est.)
Military manpower— fit for military service:
males: 7,033,996 (1998 est.)
Military manpower— reaching military age
annually:
males: 209,679 (1998 est.)
Military expenditures— dollar figure: $7.1 billion
(FY97/98)
Military expenditures— percent of GDP: 1 .2%
(FY97/98)
l T r ansnational Issues
Disputes— international: maritime boundary
disputes with the US (Dixon Entrance, Beaufort Sea,
Strait of Juan de Fuca, Machias Seal Island)
Illicit drugs: illicit producer of cannabis for the
domestic drug market; use of hydroponics technology
permits growers to plant large quantities of
high-quality marijuana indoors; growing role as a
transit point for heroin and cocaine entering the US
market
G e o g r a p h y
Location: Western Africa, group of Islands in the
North Atlantic Ocean, west of Senegal
Geographic coordinates: 1 6 00 N, 24 00 W
Map references: World
Area:
total: 4,030 sq km
land: 4,030 sq km
water: 0 sq km
Area— comparative: slightly larger than Rhode
Island
Land boundaries: 0 km
Coastline: 965 km
Maritime claims: measured from claimed
archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; warm, dry summer; precipitation
meager and very erratic
Terrain: steep, rugged, rocky, volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico 2,829 m
Natural resources: salt, basalt rock, pozzuolana (a
siliceous volcanic ash used to produce hydraulic
cement), limestone, kaolin, fish
Land use:
arable land: 11%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 0%
other: 83% (1 993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: prolonged droughts; harmattan
wind can obscure visibility; volcanically and
seismically active
Environment— current issues: overgrazing of
livestock and improper land use such as the
cultivation of crops on steep slopes has led to soil
erosion; demand for wood used as fuel has resulted in
86
deforestation; desertification; environmental damage
has threatened several species of birds and reptiles;
overfishing
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of
the Sea, Marine Dumping, Nuclear Test Ban
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location 500 km from
west coast of Africa near major north-south sea
routes; important communications station; important
sea and air refueling site
Military branches: National Armed Forces (Fuerzas
Armadas Nacionales or FAN) includes Ground Forces
or Army (Fuerzas Terrestres or Ejercito), Naval
Forces (Fuerzas Navales or Armada), Air Force
(Fuerzas Aereas or Aviacion), Armed Forces of
Cooperation or National Guard (Fuerzas Armadas de
Cooperacion or Guardia Nacional)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 6,134,691 (1998 est.)
Military manpower— fit for military service:
males: 4,429,265 (1998 est.)
Military manpower— reaching military age
annually:
males: 240,506 (1998 est.)
Military expenditures— dollar figure: $902 million
(1996)
Military expenditures— percent of GDP: 1 .4%
(1996)','33324bef87425d34b61cfe4410ea5f2f4a513874f550545f1d3811a26b0d5af6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0335db28863243bf76346c9f3bcddca6348b9da152c7bf9031a5574b31ef74a6',1998,'PT','Portugal','military-and-security',188,'Military branches: People''s Revolutionary Armed
Forces (FARP; includes Army and Navy), Security
Service
Military manpower— availability:
males age 15-49: 81 ,265 (1998 est.)
Military manpower— fit for military service:
males: 46,235 (1998 est.)
Military expenditures— dollar figure: $3.4 million
(1994)
Military expenditures— percent of GDP: 2.2%
(1997 est.)
Military branches: Army, Navy, Air and Air Defense
Forces, Police Force
Military manpower— military age: 1 9 years of age
Military manpower— availability:
males age 15-49: 536,321 (1998 est.)
Military manpower— fit for military service:
males: 432, 190 (1998 est.)
Military manpower— reaching military age
annually:
males: 16,857 (1998 est.)
Military expenditures— dollar figure: 7 billion
denars (1993 est.); note— conversion of defense
expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures— percent of GDP: NA%
Military branches: Popular Armed Forces (includes
Intervention Forces, Development Forces, Aeronaval
Forces— includes Navy and Air Force), Gendarmerie,
Presidential Security Regiment
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 3,308,300 (1998 est.)
Military manpower— fit for military service:
males: 1,964,545 (1998 est.)
Military manpower— reaching military age
annually:
males: 140,429 (1998 est.)
Military expenditures— dollar figure: $29 million
(1994)
Military expenditures— percent of GDP: 1%
(1994)','aa1fb401426654b965ad4e4bd27212a32941acf12e1a97b01605d897fa66b6fd','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3d8182aea294b8649b26e6897f7ea501a116b5e8ed0173e2b284adbcc41faf4',1998,'HN','Honduras','military-and-security',198,'Military branches: Royal Cayman Islands Police
Force (RCIPF)
Military— note: defense is the responsibility of the
UK
Military branches: Central African Army (includes
Republican Guard), Air Force, National Gendarmerie,
Police Force
Military manpower— availability:
males age 15-49: 763,085 (1998 est.)
Military manpower— fit for military service:
males: 398,617 (1998 est.)
Military expenditures— dollar figure: $30 million
(1994)
Military expenditures— percent of GDP: 2.3%
(1994)
Military branches: Army, Navy, Air Force
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 1,362,504 (1998 est.)
Military manpower— fit for military service:
males: 864,41 9 (1998 est.)
Military manpower— reaching military age
annually:
males: 65, 130 (1998 est.)
Military expenditures— dollar figure: $1 04 million
(1997)
Military expenditures— percent of GDP: 0.9%
(1997)
Military branches: Army, Navy (includes Marines),
Air Force, Public Security Forces (FUSEP, now being
converted to a civilian police force)
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 1,409,012 (1998 est.)
Military manpower— fit for military service:
males: 839,283 (1998 est.)
210
Military manpower— reaching military age
annually:
males: 68,076 (1998 est.)
Military expenditures— dollar figure: $42.5 million
(1997)
Military expenditures— percent of GDP: about
1.5% (1997)
Military branches: the People''s Liberation Army
(PLA) has a low-profile presence in Hong Kong
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 1,908,604 (1998 est.)
Military manpower— fit for military service:
males: 1 ,442,870 (1 998 est.)
Military manpower— reaching military age
annually:
males: 45,276 (1998 est.)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of China','6245e2c95f83bdc79fd86ac9ab4f5b77f7d671814adf50579a5e1c6118f28e0e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46dfd7fb56a5415bab7d1dbc78e98b93d59804cf233073c94f46ead49aaa4b61',1998,'TD','Chad','military-and-security',207,'Military branches: Armed Forces (includes Ground
Force, Air Force, and Gendarmerie), Republican
Guard, Police
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 1,645,295 (1998 est.)
Military manpower— fit for military service:
males: 852,705 (1998 est.)
Military manpower— reaching military age
annually:
males: 68,343 (1998 est.)
Military expenditures— dollar figure: $74 million
(1994)
Military expenditures— percent of GDP: 11.1%
(1994)','299c54e9746c0ffcad9590252a11dc1b573a26d493686c4db3f1ed144a071a5a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7435ebad7e18d12bacf77a00e4b4bf4422dbb80ae21969627fa2024483fa408b',1998,'CL','Chile','military-and-security',214,'Military branches: Army of the Nation, National
Navy (includes Naval Air, Coast Guard, and Marines),
Air Force of the Nation, Carabineros of Chile (National
Police), Investigations Police
Military manpower— military age: 19 years of age
Military manpower— availability:
males age 15-49: 3,919,465 (1998 est.)
Military manpower— fit for military service:
males: 2,909,927 (1998 est.)
Military manpower— reaching military age
annually:
males: 128,442 (1998 est.)
Military expenditures— dollar figure: $2.8 billion
(1997); note— includes earnings from CODELCO
Company; probably includes costs of pensions and
internal security
Military expenditures— percent of GDP: 3.5%
(1997)','3e2fe1565c4bae2b296bbb12359c14980f4bfd166189f18f54963a8cac8a4609','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1054f6d0d27e56e92c8ac7491e98d65a09ba61664ae267523536233484c4234',1998,'HK','Hong Kong','military-and-security',221,'Military branches: People''s Liberation Army (PLA),
which includes the Ground Forces, Navy (includes
Marines and Naval Aviation), Air Force, Second
Artillery Corps (the strategic missile force), People''s
Armed Police (internal security troops, nominally
subordinate to Ministry of Public Security, but included
by the Chinese as part of the "armed forces" and
considered to be an adjunct to the PLA in wartime)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 359,057,859 (1998 est.)
Military manpower— fit for military service:
males: 197,553,118 (1998 est.)
Military manpower— reaching military age
annually:
males: 9,553,823 (1998 est.)
Military expenditures— dollar figure: the officially
announced 1 998 figure is 91 billion yuan, but China''s
defense expenditures are almost certainly two to three
times the announced budget; note— conversion of the
defense budget into US dollars using the current
exchange rate could produce misleading results
Military expenditures— percent of GDP: NA%','14156c30ad4d70259423d104bf746e4a7cc67f9ad9aef508772b7e55ca5f87f7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ed1782bc75ec8445606cc7789595d9903f7e1195aa5046fab6f9547c84bfeaf',1998,'AU','Australia','military-and-security',235,'Military— note: defense is the responsibility of
Military— note: defense is the responsibility of
Australia; visited regularly by the Royal Australian
Navy; Australia has control over the activities of
visitors
Military— note: defense is the responsibility of Italy;
Swiss Papal Guards are posted at entrances to the
Vatican City
Military— note: defense is the responsibility of the
US; visited annually by the US Coast Guard','de5dfcc78d0c69d834cf609679b574dd0b2f07d75cb37a79d2eca87ec293bffa','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b36a580fd846c7ec0cfc74e63e3554d7647c1ebbb078fea1ad661bdc77427a0f',1998,'CO','Colombia','military-and-security',242,'Military branches: Army (Ejercito Nacional), Navy
(Armada Nacional, includes Marines and Coast
Guard), Air Force (Fuerza Aerea Colombiana),
National Police (Policia Nacional)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 10,229,023 (1998 est.)
Military manpower— fit for military service:
males: 6,862,893 (1998 est.)
Military manpower— reaching military age
annually:
males: 352,204 (1998 est.)
Military expenditures— dollar figure: $2 billion
(1995)
Military expenditures— percent of GDP: 2.8%
(1995)','b5746b9edbe2735a07147f9a83e6da26eabab808af161dfc2545345d3470b607','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a608fccba511ebb400ed79670f1308e531e6153fe8cdcb4b7a077704a614ef24',1998,'MZ','Mozambique','military-and-security',251,'Military branches: Comoran Security Force
Military manpower— availability:
males age 15-49: 129,095 (1998 est.)
Military manpower— fit for military service:
males: 76,991 (1998 est.)
Military expenditures— dollar figure: $3 million
(1994 est.)
Military expenditures— percent of GDP: NA%
v Transnational Issues
Disputes— international: claims
French-administered Mayotte
Congo, Democratic
Republic of the
Military branches: Zimbabwe National Army, Air
Force of Zimbabwe, Zimbabwe Republic Police
(includes Police Support Unit, Paramilitary Police)
Military manpower— availability:
males age 15-49: 2,662,702 (1998 est.)
Military manpower— fit for military service:
males: 1 ,659,659 (1998 est.)
Military expenditures— dollar figure: $236 million
(FY95/96)
Military expenditures— percent of GDP: 3.4%
(FY95/96)
Military branches: Army, Navy (includes Marines),
Air Force, Coastal Patrol and Defense Command,
Armed Forces Reserve Command, Combined Service
Forces
Military manpower— military age: 19 years of age
Military manpower— availability:
males age 15-49: 6,476,878 (1998 est.)
Military manpower— fit for military service:
males: 4,978,865 (1998 est.)
Military manpower— reaching military age
annually:
males: 206,975 (1998 est.)
Military expenditures— dollar figure: $1 1 .5 billion
(FY96/97)
Military expenditures— percent of GDP: 3.6%
(FY96/97)','7e54e8dcf784d74b1f3dc13400384d60b84362ef79b1b75fcedee057579e072f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1cc79fa59a1a59fb2400f5214fd0cb2eb6533ac58dc0e42c9041bf693ff297f',1998,'CG','Congo','military-and-security',257,'Military branches: Army, Navy, Air Force
Military manpower— availability:
males age 15-49: 10,543,138 (1998 est.)
Military manpower— fit for military service:
males: 5,366,937 (1998 est.)
Military expenditures— dollar figure: NA
Military expenditures— percent of GDP: NA
Military branches: Army, Navy (includes Marines),
Air Force, National Police
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 623,924 (1998 est.)
Military manpower— fit for military service:
males: 31 7,997 (1998 est.)
Military manpower— reaching military age
annually:
males: 27,354 (1998 est.)
Military expenditures— dollar figure: $110 million
(1993)
Military expenditures— percent of GDP: 3.8%
(1993)','f2b1391309f3204bf6e447a1980cfbdbd1c345b52290ad7f9afffb4035a50d1f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0112d6142e7fe18e50be84b5d6869018004d2daf9e01065ce00242dd8993691a',1998,'CK','Cook Islands','military-and-security',268,'Military— note: defense is the responsibility of New
Zealand, in consultation with the Cook Islands and at
its request
Military— note: defense is the responsibility of the
US; visited annually by the US Coast Guard','72c0fbeccfd93b13668b4e2f70e98b6e53a159994fa177bc7fac66ceeaafb9dd','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b2943aec198032799eac15ec4b4af90573b08c1e76f59ee718b6fd7cbf7357d',1998,'DE','Germany','military-and-security',277,'Military branches: Coast Guard, Air Section,
Ministry of Public Security Force (Fuerza Publica);
note— during 1996, the Ministry of Public Security
reorganized and eliminated the Civil Guard, Rural
Assistance Guard, and Frontier Guards as separate
entities; they are now under the Ministry and operate
on a geographic command basis performing ground
security, law enforcement, counternarcotics, and
national security (border patrol) functions; the
constitution prohibits armed forces
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 964,405 (1998 est.)
Military manpower— fit for military service:
males: 646,873 (1998 est.)
Military manpower— reaching military age
annually:
males: 35,51 3 (1998 est.)
Military expenditures— dollar figure: $55 million
(1995)
Military expenditures— percent of GDP: 2%
(1995)
Military branches: Army, Navy, National Police,
National Guard
Military manpower— availability:
males age 15-49: 286,847 (1 998 est.)
Military manpower— fit for military service:
males: 144,547 (1998 est.)
Military expenditures— dollar figure: $1 .2 million
(FY96/97)
Military expenditures— percent of GDP: 3.8%
(FY93/94)
Military branches: Army, Navy (includes Naval Air
Arm), Air Force, Medical Corps, Border Police, Coast
Guard
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 20,915,978 (1998 est.)
Military manpower— fit for military service:
males: 17,888,396 (1998 est.)
Military manpower— reaching military age
annually:
males: 465, 179 (1998 est.)
Military expenditures— dollar figure: $42.8 billion
(1995)
Military expenditures— percent of GDP: 1 .5%
(1995)
Military branches: Ministry of Defense (Border
Guards, General Purpose Forces, Air Force),
Republican Guard
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 4,429,484 (1998 est.)
Military manpower— fit for military service:
males: 3,534,839 (1998 est.)
Military manpower— reaching military age
annually:
males: 154,218 (1998 est.)
Military expenditures— dollar figure: 1 8.9 billion
tenges (1995); note— conversion of defense
expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures— percent of GDP: NA%
Military branches: Army, National Gendarmerie
Military manpower— military age: 19 years of age
Military manpower— availability:
males age 15-49:108,111 (1998 est.)
Military manpower— fit for military service:
males: 88,807 (1998 est.)
Military manpower— reaching military age
annually:
males: 2,388 (1998 est.)
Military expenditures— dollar figure: $142 million
(1995)
Military expenditures— percent of GDP: 0.8%
(1995)
Military branches: NA
Military manpower— availability:
males age 15-49: 1 1 9,1 02 (1 998 est.)
Military manpower— fit for military service:
males: 65,530 (1998 est.)
Military— note: defense is the responsibility of
Military branches: Army (includes Air Wing and
Naval Detachment), Police (includes paramilitary
Mobile Force Unit)
Military manpower— availability:
males age 1 5-49: 2,248,023 (1998 est.)
Military manpower— fit for military service:
males: 1,151 ,594 (1998 est.)
Military expenditures— dollar figure: $1 0.4 million
(FY94/95)
Military expenditures— percent of GDP: NA%
Military branches: Ground Forces, Air and Air
Defense Forces, Republic Security Forces (internal
and border troops)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 1,145,260 (1998 est.)
Military manpower— fit for military service:
males: 902,238 (1998 est.)
Military manpower— reaching military age
annually:
males: 38,082 (1998 est.)
Military expenditures— dollar figure: 203 million
lei (1995); note— conversion of defense expenditures
into US dollars using the current exchange rate could
produce misleading results
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of','8fe4d3e10cdb5796dfcb9bfcb9b20e8e78a07c6591dc8eed16a47e898130e197','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d6f5ccad87846a8bbedb7867ab4ce05600ba9b788c3a72198bf90a0cc31a7ea',1998,'SI','Slovenia','military-and-security',290,'Military branches: Ground Forces, Naval Forces,
Air and Air Defense Forces, Frontier Guard, Home
Guard
Military manpower— military age: 1 9 years of age
Military manpower— availability:
males age 15-49: 1,191,191 (1998 est.)
Military manpower— fit for military service:
males: 945,746 (1998 est.)
Military manpower— reaching military age
annually:
males: 33,736 (1998 est.)
Military expenditures— dollar figure: $1 .5 billion
(1997)
Military expenditures— percent of GDP: 8.2%
(1997)','4cc6afd670087cc34668b3bb2c9778d64d5aef1fa5e96802938f1b8d3feb0dd5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14338ada1a8ba0bfa86fdc3a5ceede0cc857d194146eb23380c0e2614a10c29d',1998,'CU','Cuba','military-and-security',298,'Military branches: Revolutionary Armed Forces
(FAR) includes ground forces, Revolutionary Navy
(MGR), Air and Air Defense Force (DAAFAR),
Territorial Troops Militia (MTT), and Youth Labor Army
(EJT); The Border Guard (TGF), which is controlled by
the Interior Ministry
Military manpower— military age: 17 years of age
Military manpower— availability:
males age 15-49: 3,060,954
females age 15-49: 3,010,932 (1998 est.)
Military manpower— fit for military service:
males: 1,898,351
females: 1 ,861 ,976 (1 998 est.)
Military manpower— reaching military age
annually:
males: 67,200
females: 63,71 6 (1998 est.)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: roughly
4% (1995 est.)
Military— note: Moscow, for decades the key
military supporter and supplier of Cuba, cut off almost
all military aid by 1993','ce1ca0a356a0cab62afb78b2fe07cd1b3fbd7a1ca2f7c4588f0eff43593f91f0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea0af4c7418805c451ba8813519820366fa5da3853440aa681bee236eba6be96',1998,'CY','Cyprus','military-and-security',306,'Military branches: Greek Cypriot area: Greek
Cypriot National Guard (GCNG; includes air and naval
elements); Hellenic Forces Regiment on Cyprus
(ELDYK); Greek Cypriot Police; Turkish Cypriot area:
Turkish Cypriot Security Force (TCSF), Turkish
Forces Regiment on Cyprus (KTKA), Turkish
mainland army units
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 192,389 (1998 est.)
Military manpower— fit for military service:
males: 132,252 (1998 est.)
Military manpower— reaching military age
annually:
males: 6,220 (1998 est.)
Military expenditures— dollar figure: $405 million
(1996)
Military expenditures— percent of GDP: 5.4%
(1996)
Military branches: Army, Air Force, Civil Defense
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 2,699,023 (1 998 est.)
Military manpower— fit for military service:
males: 2,056,386 (1998 est.)
Military manpower— reaching military age
annually:
males: 78,1 88 (1998 est.)
Military expenditures— dollar figure: $1 .22 billion
(1996)
Military expenditures— percent of GDP: 2.2%
(1996)','8256e760ba0cd2a51d5f004b855a6fb25160f911e381dd720d314356b34700d8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02eff7548da45e6f7af852119779bee94bfe8c615fee6cf5310afe15488225f1',1998,'DK','Denmark','military-and-security',314,'Military branches: Royal Danish Army, Royal
Danish Navy, Royal Danish Air Force, Home Guard
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 1,324,150 (1998 est.)
Military manpower— fit for military service:
males: 1,137,563 (1998 est.)
Military manpower— reaching military age
annually:
males: 32,918 (1998 est.)
Military expenditures— dollar figure: $2.9 billion
(1997 est.)
Military expenditures— percent of GDP: 1 .6%
(1997 est.)
Military branches: Djibouti National Army (includes
Navy and Air Force), National Security Force (Force
Nationale de Securite), National Police Force
Military manpower— availability:
males age 15-49: 104,450 (1998 est.)
Military manpower— fit for military service:
males: 61 ,31 9 (1998 est.)
Military expenditures— dollar figure: $26 million
(1989)
Military expenditures— percent of GDP: NA%','e0853feedaa70a5608da8ab1c0d33df6d24f7a6aea5fcd13d1733bd9bcd56bec','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('405f234adac46418818a1c6319c873463ac0c6fb328cdf3d93524b6a1a9b71b9',1998,'DM','Dominica','military-and-security',323,'Military branches: Army, Navy, Air Force, National
Police
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 2,1 1 9,278 (1 998 est.)
Military manpower— fit for military service:
males: 1,332,971 (1998 est.)
Military manpower— reaching military age
annually:
males: 80,784 (1998 est.)
Military expenditures— dollar figure: $116 million
(1994)
Military expenditures— percent of GDP: 1 .4%
(1994)','a89583fcf82340783866b7b81521fe2a1af2e1f8bd10a4de82a8b8e838e17205','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea9636d5d3befae225ca08c34d9746af1d661dbc1373b95115e5a930ad24c834',1998,'PE','Peru','military-and-security',330,'Military branches: Army (Ejercito Ecuatoriano),
Navy (Armada Ecuatoriana, includes Marines), Air
Force (Fuerza Aerea Ecuatoriana), National Police
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 3,1 68,489 (1 998 est.)
Military manpower— fit for military service:
males: 2,1 39,51 6 (1 998 est.)
Military manpower— reaching military age
annually:
ma/es; 127,810 (1998 est.)
Military expenditures— dollar figure: $411 million
(1997)
Military expenditures— percent of GDP: 2.1 %
(1997)','317ad98bd7b886466473eec1c38197446952badf937f29f308efa0fac0b4fa10','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fad3311a3eb4aa37b3e8af8d1b7dcfbb6a9144f5c4e5f04ed0a319650bb23b5e',1998,'SD','Sudan','military-and-security',339,'Military branches: Army, Navy, Air Force, Air
Defense Command
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 17,350,925 (1998 est.)
Military manpower— fit for military service:
males: 11,247,896 (1998 est.)
Military manpower— reaching military age
annually:
males: 683,868 (1998 est.)
Military expenditures— dollar figure: $3.28 billion
(FY95/96)
Military expenditures— percent of GDP: 8.2%
(FY95/96)','251e94b9e413c556961295c825bb4081d0c8676dc6b5ea1580a0f849740b63b8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b3ae48dd1a5c0e6b99a5f80b556925efea203012758bf50720d8dcd71432a9c',1998,'GN','Guinea','military-and-security',351,'Military branches: Army, Navy, Air Force, Rapid
intervention Force, National Police
Military manpower— availability:
males age 15-49: 98,960 (1 998 est.)
Military manpower— fit for military service:
males: 50,308 (1998 est.)
Military expenditures— dollar figure: $2.5 million
(FY93/94)
Military expenditures— percent of GDP: NA%
Military branches: Army, Navy, Air Force
Military expenditures— dollar figure: $40 million
(1995)
Military expenditures— percent of GDP: NA%','33fc50f5f02bf58d8d1aa9017e1e6fbcce662d60ecbd10ac6b882b596ecc4363','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('141a36cb443a2cec1065b25132e81f76d3d9303597baaeb7f9c316fd18b0c356',1998,'EE','Estonia','military-and-security',362,'Military branches: Ground Forces, Air Force, Police
note; following the secession of Eritrea, Ethiopia''s
naval facilities remained in Eritrea''s possession;
current reorganization plans do not include a navy
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 13,240,029 (1998 est.)
Military manpower— fit for military service:
males: 6,900,452 (1998 est.)
Military manpower— reaching military age
annually:
males: 630,087 (1998 est.)
Military expenditures— dollar figure: $126 million
(budget for FY97/98)
Military expenditures— percent of GDP: NA%
153
Ethiopia (continued)
Military— note: defense is the responsibility of','7a3462bf90f674041256b4522502e0445cfa6cf749f39c09dc385b41f4b755a3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bd23d4424e61dbfc656ce6c85ac39aee3c11c39c952aa92def844c7ec7deb55',1998,'JE','Jersey','military-and-security',378,'Military branches: Republic of Fiji Military Forces
(RFMF; includes army, navy, and a small air wing)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 214,475 (1998 est.)
Military manpower— fit for military service:
males: 118,181 (1998 est.)
Military manpower— reaching military age
annually:
males: 9,1 80 (1998 est.)
Military expenditures— dollar figure: $32 million
(1997)
Military expenditures— percent of GDP: 5%
(1997)
Military branches: Israel Defense Forces (includes
ground, naval, and air components), Pioneer Fighting
Youth (Nahal), Frontier Guard, Chen (women); note—
historically there have been no separate Israeli
military services
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 1 ,446,634
females age 15-49: 1,414,898 (1998 est.)
Military manpower— fit for military service:
males: 1,1 83, 989
females: 1,153,670 (1998 est.)
Military— note: defense is the responsibility of the
UK
Military— note: defense is the responsibility of the
US
Military branches: Army, Navy, Air Force, National
Guard, Ministry of Interior Forces, Coast Guard
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 690,989 (1 998 est.)
Military manpower— fit for military service:
males: 409,563 (1998 est.)
Military manpower— reaching military age
annually:
males: 19,553 (1998 est.)
Military expenditures— dollar figure: $3.5 billion
(FY95/96)
Military expenditures— percent of GDP: 12.8%
(FY95/96)
Military branches: French Armed Forces (Army,
Navy, Air Force, Gendarmerie); Police Force
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of
Military branches: Slovenian Army (includes Air
and Naval Forces)
Military manpower— military age: 1 9 years of age
Military manpower— availability:
males age 15-49: 531 ,429 (1 998 est.)
Military manpower— fit for military service:
males: 423, 198 (1998 est.)
Military manpower— reaching military age
annually:
males: 15,546 (1998 est.)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: 2.1 %
(1997)
Military branches: Swedish Army, Royal Swedish
Navy, Swedish Air Force
Military manpower— military age: 1 9 years of age
Military manpower— availability:
males age 15-49: 2,088,061 (1998 est.)
Military manpower— fit for military service:
males: 1,827,336 (1998 est.)
Military manpower— reaching military age
annually:
males: 52,208 (1998 est.)
Military expenditures— dollar figure: $5.8 billion
(FY94/95)
Military expenditures— percent of GDP: 2.5%
(FY94/95)','c92cae26b53aa2b1e45aaa3337bdbaf307503b90354e8f5f03085070544a9397','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('746947d61902d5e4661113721a785436d165b97d9f1d72f4f65f811833625c1e',1998,'WF','Wallis and Futuna','military-and-security',390,'Military branches: Army (includes Marines), Navy
(includes Naval Air), Air Force (includes Air Defense,
National Gendarmerie
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 14,739,065 (1998 est.)
Military manpower— fit for military service:
males: 12,264,824 (1998 est.)
Military manpower— reaching military age
annually:
males: 407,794 (1998 est.)
Military expenditures— dollar figure: $47.7 billion
(1995)
Military expenditures— percent of GDP: 2.5%
(1995)','6ea64f155f5478e45e6061919fede1e061a34d81c821a810057dadba02ff145c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a178375cbdb403a6a03cbbd12ffd5466da0f340561df06b602bb79636554f70d',1998,'PF','French Polynesia','military-and-security',401,'Military branches: French Forces (includes Army,
Navy, Air Force), Gendarmerie
Military— note: defense is the responsibility of','b09e1ef1d51e60a66e6a80df2c85068d92c328e9f9d4bb702046419ff9ae6c1c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5bb0e04c46e45e8774e0727a30d7d7a8a0ed9306b7d3533c936e270b638ed29',1998,'GA','Gabon','military-and-security',409,'Military branches: Army, Navy, Air Force,
Republican Guard (charged with protecting the
president and other senior officials), National
Gendarmerie, National Police
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 277,850 (1 998 est.)
Military manpower— fit for military service:
males: 142,334 (1998 est.)
Military manpower— reaching military age
annually:
males: 11,352 (1998 est.)
Military expenditures— dollar figure: $1 54 million
(1993)
Military expenditures— percent of GDP: 2.4%
(1993)','18b85247982c9fbe25109e95feb446ccc192de56aaa3a3018f3fc467f1157d9b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d4bed1f6ad381566df27236f92b2dbe94f9008f4a86c6ea0f482a04da75a833',1998,'GE','Georgia','military-and-security',417,'Military branches: Ground Forces, Navy, Air Force,
Air Defense Forces, National Guard, Republic
Security Forces (internal and border troops)
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 1,286,126 (1998 est.)
Military manpower— fit for military service:
males: 1,017,954 (1998 est.)
Military manpower— reaching military age
annually:
males: 40,946 (1998 est.)
Military expenditures— dollar figure: 79 million lari
(1997); note— conversion of defense expenditures
into US dollars using the current exchange rate could
produce misleading results
Military expenditures— percent of GDP: 8.8%
(1998 approved budget)','eca33fda2cc6d275138d48edd962c44f3737553e402b6dfb348982390871a310','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('418622ae2a197a06f37b607630115faf102d661b0d47c2ccb861b71739d27aa3',1998,'NL','Netherlands','military-and-security',428,'Military branches: Army, Navy, Air Force, National
Police Force, Palace Guard, Civil Defense
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 4,386,728 (1998 est.)
Military manpower— fit for military service:
males: 2,434,732 (1998 est.)
Military manpower— reaching military age
annually:
males: 181,169 (1998 est.)
Military expenditures— dollar figure: $30 million
(1994)
Military expenditures— percent of GDP: 0.8%
(1994)
Military branches: Royal Netherlands Army, Royal
Netherlands Navy (includes Naval Air Service and
Marine Corps), Royal Netherlands Air Force, Royal
Constabulary
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 4,136,224 (1998 est.)
Military manpower— fit for military service:
males: 3,61 7,322 (1998 est.)
Military manpower— reaching military age
annually:
males: 94,734 (1998 est.)
Military expenditures— dollar figure: $8.2 billion
(1995)
Military expenditures— percent of GDP: 2.1%
(1995)
Military branches: Royal Netherlands Navy, Marine
Corps, Royal Netherlands Air Force, National Guard,
Police Force
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 52,845 (1 998 est.)
Military manpower— fit for military service:
males: 29,664 (1998 est.)
Military manpower— reaching military age
annually:
males: 1 ,456 (1998 est.)
Military— note: defense is the responsibility of the
Kingdom of the Netherlands','d9b588e0b822bffdcd299736f2599d31d0ecff9e0b5d914f264b945b7869ee46','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6caa88c160698cd323adb135365cfe7d318d3349bf2ab353233b15206c07dabf',1998,'ES','Spain','military-and-security',435,'Military branches: British Army, Royal Navy, Royal
Air Force
Military— note: defense is the responsibility of the
UK
Military— note: defense is the responsibility of','c5c021facf6a0420b6e794a6819a64619947859bc7982ff4ad277087058824c4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3757d2752c4bc5094c56232f07674f45f8a970025889ae2a74ca9712d69e55e7',1998,'GD','Grenada','military-and-security',444,'Military branches: Royal Grenada Police Force,
Coast Guard
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%','d56d0d558d6d5d278b273d4a8f27f76aceb58798dfbbe0f8f1ba4bdf09d1ed24','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b33e31fd351728c3b4785679c7df68713c08f8a39d7e76f4a70d5c7ffb104a3',1998,'GU','Guam','military-and-security',452,'Military— note: defense is the responsibility of the
US
Military branches: Army, Navy, Air Force
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 2,827,992 (1998 est.)
Military manpower— fit for military service:
males: 1,846,963 (1998 est.)
Military manpower— reaching military age
annually:
ma/es; 132,208 (1998 est.)
Military expenditures— dollar figure: $1 32.9
million (1998 est.)
Military expenditures— percent of GDP: 0.66%
(1998 est.)','dd2ad2fb7f2da9049e845395f216001cbf4b2582b9e23549d5257f84282aea90','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('942ac9d2256a790a81145c75aee4a540d5431df5f626b39e41e4fe2a16775e09',1998,'GG','Guernsey','military-and-security',454,'(British crown dependency)
Military branches: Army, Navy (acts primarily as a
coast guard), Air Force, Republican Guard,
Presidential Guard, paramilitary National
Gendarmerie, National Police Force (Surete National)
Military manpower— availability:
males age 15-49: 1 ,706,395 (1998 est.)
Military manpower— fit for military service:
males: 861,036 (1998 est.)
Military expenditures— dollar figure: $50 million
(1994)
Military expenditures— percent of GDP: 1 .6%
(1994)','dcc348cb8f4d272ca594a9de522f72891ccf9c88e598b65239bbedd2c2f09a05','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2dff3630ae3315fa74acf88a0fe5ca099485215f3552e4d2f042b7d1a2b43ab',1998,'ET','Ethiopia','military-and-security',466,'Military branches: People''s Revolutionary Armed
Force (FARP; includes Army, Navy, and Air Force),
paramilitary force
Military manpower— availability:
males age 15-49: 276,417 (1998 est.)
Military manpower— fit for military service:
males: 157,674 (1998 est.)
Military expenditures— dollar figure: $9 million
(1994)
Military expenditures— percent of GDP: 4.5%
(1994)
Military branches: Army, Navy, Security Police
Military manpower— availability:
males age 15-49: 30,573 (1988 est.)
Military manpower— fit for military service:
males: 16,172 (1998 est.)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%','4eb915edafbd0ae89dc53cb15fdbe123a0b042cf24f4b7d359a3bf573912109e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6803fcaf1dc5c296b7ccb6b264d5a16fbcce9fd5114d13f975abfade866878cc',1998,'GY','Guyana','military-and-security',473,'Military branches: Guyana Defense Force (GDF;
includes Ground Forces, Coast Guard, and Air
Corps), Guyana People''s Militia (GPM), Guyana
National Service (GNS)
Military manpower— availability:
males age 15-49: 201 ,1 26 (1 998 est.)
Military manpower— fit for military service:
males: 151,963 (1998 est.)
Military expenditures— dollar figure: $7 million
(1994)
Military expenditures— percent of GDP: 1 .7%
(1994)
Military branches: Haitian National Police (HNP)
note: the regular Haitian Army, Navy, and Air Force
have been demobilized but still exist on paper until/
unless constitutionally abolished
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 1,490,464 (1998 est.)
Military manpower— fit for military service:
males : 807,330 (1998 est.)
Military manpower— reaching military age
annually:
males: 75,448 (1998 est.)
Military expenditures— dollar figure: $NA; note—
mainly for police and security activities
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of
Military branches: National Army (includes small
Navy and Air Force elements), Civil Police
Military manpower— availability:
males age 15-49: 1 17,031 (1 998 est.)
Military manpower— fit for military service:
males: 68,985 (1998 est.)
Military expenditures— dollar figure: $8.5 million
(1997 est.)
Military expenditures— percent of GDP: 1 .6%
(1997 est.)
Military— note: demilitarized by treaty (9 February
1920)','bdbbafa7bf6c664f59ca62c9695ddead9b7e84d01611b3819321cfb4ef49ffb9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8716457571f81dab8084a7c9285cb1560af1d5910e67e5045126f6afc15a123',1998,'AT','Austria','military-and-security',482,'Military branches: Ground Forces, Air Force,
Border Guard
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 2,61 8,41 6 (1 998 est.)
Military manpower— fit for military service:
males: 2, 087, 877 (1998 est.)
Military manpower— reaching military age
annually:
males: 74,254 (1998 est.)
Military expenditures— dollar figure: $550 million
(1996)
Military expenditures— percent of GDP: 1 .5%
(1996)','4907a5ecb77263aee1d01cf36e2fbf9fcea097d46d3ca3a26bdc35c1fe9f8cb9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76e5dd88d8954120e5909d549679dec592b62dcd75b45ee0babd33aa0fd68873',1998,'IS','Iceland','military-and-security',490,'Military branches: no regular armed forces; Police,
Coast Guard; note— Iceland''s defense is provided by
the US-manned Icelandic Defense Force (IDF)
headquartered at Keflavik
Military manpower— availability:
males age 15-49: 70,906 (1998 est.)
Military manpower— fit for military service:
males: 62,595 (1998 est.)
Military expenditures— dollar figure: none
Military— note: defense is the responsibility of','b7351c061fdfd5085d66471e0f1f09f847ee72edf82046e22414ee30377c5d67','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff47b6b0ba4099f63029fbf22033522f3eb7212408441dbc2985eb6c5f32759b',1998,'IN','India','military-and-security',499,'Military branches: Army, Navy, Air Force, various
security or paramilitary forces (includes Border
Security Force, Assam Rifles, and Coast Guard)
Military manpower— military age: 17 years of age
Military manpower— availability:
males age 15-49: 263,765,005 (1 998 est.)
Military manpower— fit for military service:
males: 154,925,081 (1998 est.)
Military manpower— reaching military age
annually:
males: 10,566,718 (1998 est.)
Military expenditures— dollar figure: $8 billion
(FY95/96)
Military expenditures— percent of GDP: 2.7%
(FY95/96)','783323b4be4c942f72e05da5122a6bbaa09b76805462210ff259b1b08caf9359','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6219770d23919afa941e6e69907515fa43a58f7db81f6368d4eb434302fea75',1998,'IE','Ireland','military-and-security',506,'Military branches: Army (includes Naval Service
and Air Corps), National Police (Garda Siochana)
Military manpower— military age: 17 years of age
Military manpower— availability:
males age 15-49: 967,621 (1998 est.)
Military manpower— fit for military service:
males: 784,766 (1998 est.)
Military manpower— reaching military age
annually:
males: 35,338 (1998 est.)
Military expenditures— dollar figure: $618 million
(1994)
Military expenditures— percent of GDP: 1 .3%
(1994)','a960177c41a1086aca3d8a41ea0f06ea7ccd1a75b993a45482bb21b756ba5459','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('171f012d9841fd1c4e8524bc5bb1c7d476d7f3b7f0e850e8631f4ba105eda56b',1998,'TN','Tunisia','military-and-security',515,'Military branches: Army, Navy, Air Force,
Carabinieri
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 14,249,145 (1998 est.)
Military manpower— fit for military service:
males: 12,31 4,086 (1998 est.)
Military manpower— reaching military age
annually:
males: 324,437 (1998 est.)
Military expenditures— dollar figure: $20.4 billion
(1995)
Military expenditures— percent of GDP: 1 .9%
(1995)
235
Italy (continued)
Military branches: Army, Navy, Air Force,
paramilitary forces
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 2,534,929 (1998 est.)
Military manpower— fit for military service:
males: 1,450,442 (1998 est)
Military manpower— reaching military age
annually:
males: 96,966 (1998 est.)
Military expenditures— dollar figure: $535 million
(1995)
Military expenditures— percent of GDP: 2.8%
(1995)
Military branches: Land Forces, Navy (includes
Naval Air and Naval Infantry), Air Force, Coast Guard,
Gendarmerie
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 1 7,761 ,347 (1 998 est.)
Military manpower— fit for military service:
males: 10,789,134 (1998 est.)
Military manpower— reaching military age
annually:
males: 658,946 (1998 est.)
Military expenditures— dollar figure: $4.3 billion
(1996); note— figures do not include about $7 billion
for the government''s counterinsurgency effort
Military expenditures— percent of GDP: 3.5%
(1996)
Military branches: Ministry of Defense (Army, Air
and Air Defense, Navy, Border Troops, and Internal
Troops), National Guard
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 1,080,486 (1998 est.)
Military manpower— fit for military service:
males: 878,274 (1 998 est.)
Military manpower— reaching military age
annually:
males: 43,901 (1998 est.)
Military expenditures— dollar figure: 4.5 billion
manats (1995); note— conversion of defense
expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures— percent of GDP: 3%
(1995)','63a036b5c8edcc212e4d8caa755cc9e27299e0249bcf0b7419b18e08eb3909ea','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('131bc81eafe4f8218805076b646078ae9f2186c3e944c5358c7da8fd0954a5a0',1998,'JM','Jamaica','military-and-security',524,'Military branches: Jamaica Defense Force
(includes Ground Forces, Coast Guard and Air Wing),
Jamaica Constabulary Force
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 703,697 (1998 est.)
Military manpower— fit for military service:
males: 496,276 (1998 est.)
Military manpower— reaching military age
annually:
males: 25,525 (1998 est.)
Military expenditures— dollar figure: $47.9 million
(FY97/98 est.)
Military expenditures— percent of GDP: NA%','2bc26170c36ffd198153b0d6fb2e7a191d5f8dfbf428ccc5d2c927a4da35ef1a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9fcf7ab7398c278abee11f4c30042f9c50e3bde6eca948b4e11766c6da76c9c',1998,'JO','Jordan','military-and-security',532,'Military branches: Jordanian Armed Forces (JAF;
includes Royal Jordanian Land Force, Royal Naval
Force, and Royal Jordanian Air Force); Badiya
(irregular) Border Guards; Ministry of the Interior''s
Public Security Force (falls under JAF only in wartime
or crisis situations)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 1 ,076,618 (1998 est.)
Military manpower— fit for military service:
males: 766,973 (1998 est.)
Military manpower— reaching military age
annually:
males: 48,706 (1998 est.)
Military expenditures— dollar figure: $627 million
(1997 est.)
Military expenditures— percent of GDP: 7.8%
(1997)
Military— note: defense is the responsibility of','8b8e46714b57f8f1725a63d97bae62c297a1833af61f0e63b579420e481765fa','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4b4b2f979c51b9eb1206b85b6cf4bed9d7af65472fb779b4a01870990998921',1998,'KE','Kenya','military-and-security',539,'Military branches: Army, Navy, Air Force,
paramilitary General Service Unit of the Police
Military manpower— availability:
males age 15-49: 6,870,889 (1998 est.)
Military manpower— fit for military service:
males: 4,257,985 (1998 est.)
Military expenditures— dollar figure: $1 34 million
(FY94/95)
Military expenditures— percent of GDP: 3.9%
(FY94/95)
251
Kenya (continued)','4ad2ffbc319fe38107300c852459fcde629cb7e82dbb93e708b8b93819e5dc3a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7934f5b96667006179514afe5089461fa82dbd4f004dd11b80a85b1d0e5f3e34',1998,'WS','Samoa','military-and-security',546,'Military— note: defense is the responsibility of the
US
Military— note: defense is the responsibility of the
US
Military branches: an amendment to the
Constitution abolished the armed forces, but there are
security forces (Panamanian Public Forces or PPF
includes the National Police, National Maritime
Service, and National Air Service)
Military manpower— availability:
males age 15-49: 733,019 (1998 est.)
Military manpower— fit for military service:
males: 502,731 (1998 est.)
Military expenditures— dollar figure: $78 million
(1995); note— for police and security forces
Military expenditures— percent of GDP: NA%
Military branches: no regular armed services;
Samoa Police Force
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%','2ec0bf113e9b079a20f63f741a903608f8cc7ec61f0557132dfdcbb5520bec65','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b89376f1fe3691e55385297e9a993951da7eef44b8dcb630ffa80f359365df18',1998,'KI','Kiribati','military-and-security',555,'Military branches: no regular military forces; Police
Force (carries out law enforcement functions and
paramilitary duties; small police posts are on all
islands)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military branches: Korean People''s Army (includes
Army, Navy, Air Force), Civil Security Forces
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 5,704,690 (1998 est.)
Military manpower— fit for military service:
males: 3,449,880 (1998 est.)
256
Military manpower— reaching military age
annually:
males: 175,181 (1998 est.)
Military expenditures— dollar figure: $5 billion to
$7 billion (1995 est.)
Military expenditures— percent of GDP: 25%
(1995 est.)
Military branches: Army, Navy, Air Force, Marine
Corps, National Maritime Police (Coast Guard)
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 13,849,615 (1998 est.)
Military manpower— fit for military service:
males: 8,837,541 (1998 est.)
Military manpower— reaching military age
annually:
males: 399,034 (1998 est.)
Military expenditures— dollar figure: $1 7.4 billion
(1996)
Military expenditures— percent of GDP: 3.3%
(1996)','b2bf992e0c7a75be449ea41c5f01017f6708c8a2de02b104773eb70df997f8d9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baf569f7fe77d4374467f2a585616ad55cc4b2364865e50120598e6f583f04ef',1998,'KG','Kyrgyzstan','military-and-security',563,'Military branches: Army, National Guard, Security
Forces (internal and border troops), Civil Defense
note: border troops controlled by Russia
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 1,124,900 (1998 est.)
Military manpower— fit for military service:
males: 91 2,596 (1998 est.)
Military manpower— reaching military age
annually:
males: 45,066 (1998 est.)
Military expenditures— dollar figure: 151 million
soms (1995); note— conversion of defense
expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures— percent of GDP: NA%
Military branches: Lao People’s Army (LPA;
includes militia element), Lao People''s Navy (LPN;
includes riverine element), Air Force, National Police
Department
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 1,161,497 (1998 est.)
Military manpower— fit for military service:
males: 626,880 (1998 est.)
Military manpower— reaching military age
annually:
males: 55,903 (1998 est.)
Military expenditures— dollar figure: $105 million
(FY92/93)
Military expenditures— percent of GDP: 8.1%
(FY92/93)','cacffae1f4bc7bd50f3ee3ecd2895b212e001dd7591500577d83fe2c9e9b9d92','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fe05bcaa06963f1f31efb953213e3da6292198c5f2f838b73deaaf81c0f07f9',1998,'FI','Finland','military-and-security',569,'Military branches: Ground Forces, Navy, Air and Air
Defense Forces, Security Forces, Border Guard,
Home Guard (Zemessardze)
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 569,745 (1998 est.)
Military manpower— fit for military service:
males: 446,562 (1998 est.)
Military manpower— reaching military age
annually:
males: 16,594 (1998 est.)
Military expenditures— dollar figure: 176 million
rubles (1994); note— conversion of defense
expenditures into US dollars using the prevailing
exchange rate could produce misleading results
Military expenditures— percent of GDP: 3% to 5%
(1994)
Military branches: Lebanese Armed Forces (LAF;
includes Army, Navy, and Air Force)
Military manpower— availability:
males age 15-49: 901 ,603 (1 998 est.)
Military manpower— fit for military service:
males: 558,774 (1998 est.)
Military expenditures— dollar figure: $445 million
(1997)
Military expenditures— percent of GDP: 5%
(1997)','7c91dc44b3944864534353efd053d846c7adc2a6749605b67fd393d45a6d4436','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e68e474116454eabe90044b4bb7e051d62279e41f25e581e8e9052e4b1943945',1998,'ZA','South Africa','military-and-security',578,'Military branches: Lesotho Defense Force (LDF;
includes Army and Air Wing), Royal Lesotho Mounted
Police (RLMP)
Military manpower— availability:
males age 15-49: 490,1 28 (1 998 est.)
Military manpower— fit for military service:
males: 264,255 (1998 est.)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military branches:
note : The new government of Liberia has developed a
plan for the armed forces: total strength 5,000, of
which Army 3,400, Navy 1,100, Air Force 500; note—
the Navy is to have several small coastal patrol
vessels and the Air Force is to comprise two air wings
274
Military manpower— availability:
males age 15-49: 631,546 (1998 est.)
Military manpower— fit for military service:
males: 337,744 (1998 est.)
Military expenditures— dollar figure: $14 million
(1993)
Military expenditures— percent of GDP: 2.9%
(1993)','9c1529cdfc5cbb8acd1bb7b2ace0cbe7b55c8e37ba03563fb9b4e3cb5d5a8544','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('daa8e17abaa6884388b44ca5dfbc1bfca61beea63655559727c4c72d74b05ff8',1998,'LY','Libya','military-and-security',586,'Military branches: Army, Navy, Air and Air Defense
Command
Military manpower— military age: 1 7 years of age
Military manpower— availability:
males age 15-49: 1,229,080 (1998 est.)
Military manpower— fit for military service:
males: 731 ,963 (1998 est.)
Military manpower— reaching military age
annually:
males: 59,730 (1998 est.)
Military expenditures— dollar figure: $1 .4 billion
(1994 est.)
Military expenditures— percent of GDP: 6.1%
(1994 est.)','ebc90b70bb924fbf33c1a606f24449d73c5edb2029a8326bd6f66bda2b7918b3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a364e3872d046d6a9048e8eee4000a1cad8b069def2cbaf201f4ef1bf63c3e2',1998,'CH','Switzerland','military-and-security',593,'Military— note: defense is the responsibility of
Military branches: Ground Forces, Navy, Air and Air
Defense Force, Security Forces (internal and border
troops), National Guard (Skat)
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 905,259 (1998 est.)
Military manpower— fit for military service:
males: 71 2,593 (1998 est.)
Military manpower— reaching military age
annually:
males: 26,211 (1998 est.)
Military expenditures— dollar figure: $81 .2 million
(1997)
Military expenditures— percent of GDP: 0.9%
(1997)','9d5725f6292d7f4003a0c712e8e5c5fc9fa92adf2157b30416aa98d46c7f32ec','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('282901629a062b64066d22a729fbe0af36e1e548adf05e507ed8ad7219d0c4e9',1998,'MV','Maldives','military-and-security',607,'Military branches: Malaysian Army, Royal
Malaysian Navy, Royal Malaysian Air Force, Royal
Malaysian Police Force, Marine Police, Sarawak
Border Scouts
Military manpower— military age: 21 years of age
Military manpower— availability:
males age 15-49: 5,402,322 (1 998 est.)
Military manpower— fit for military service:
Military branches: National Security Service
(paramilitary police force)
Military manpower— availability:
males age 15-49: 63,879 (1 998 est.)
Military manpower— fit for military service:
males: 35,61 0(1 998 est.)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military branches: Army, Air Force, Gendarmerie,
Republican Guard, National Guard, National Police
(Surete Nationale)
Military manpower— availability:
males age 15-49: 2,051 ,976 (1998 est.)
Military manpower— fit for military service:
males: 1,174,078 (1998 est.)
Military expenditures— dollar figure: $66 million
(1994)
Military expenditures— percent of GDP: 2.2%
(1994)
Military branches: Armed Forces, Maltese Police
Force
Military manpower— availability:
males age 15-49: 99,066 (1 998 est.)
Military manpower— fit for military service:
males: 78,805 (1998 est.)
Military expenditures— dollar figure: $65.5 million
(FY96/97)
Military expenditures— percent of GDP: 2.7%
(FY96/97)
298
Military— note: defense is the responsibility of the
UK','d722030f73c2605e6b74c8ce45dde956cdfac6d2c1ab17cca600a106f5b3f17a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a4a519b3c170f9b9b47bc4a28ccfdf9b341e57df1af14532244e8bfe4e86bb8',1998,'MH','Marshall Islands','military-and-security',620,'Military branches: no regular military forces (a
coast guard may be established); Police Force
Military— note: defense is the responsibility of the
US','2eb276e83e0fd992016eb9e1901814f1ed4dbe028b5bc38ffd7ba898f94d1ffe','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee2aacbac96d98b042d1a64ab030647246710dcd5fc74b188e5f3b8676e030f7',1998,'MR','Mauritania','military-and-security',625,'Military branches: Army, Navy, Air Force, National
Gendarmerie, National Guard, National Police,
Presidential Guard
Military manpower— availability:
males age 15-49:555,492 (1998 est.)
Military manpower— fit for military service:
males: 269,884 (1998 est.)
Military expenditures— dollar figure: $33 million
(1995)
Military expenditures— percent of GDP: 2.5%
(1995)','be321354f8f9abd2dc86df95128469cf57ceab2bce281aaa7ff4100eacae2321','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e22382ba86fb43004445e4f9320c7524d01625992d53e5c501e01331e8730eb7',1998,'MU','Mauritius','military-and-security',632,'Military branches: National Police Force (includes
the paramilitary Special Mobile Force or SMF, Special
Support Units or SSU, and National Coast Guard)
Military manpower— availability:
males age 15-49: 336,655 (1998 est.)
Military manpower— fit for military service:
males: 170,695 (1998 est.)
Military expenditures— dollar figure: $13.9 million
(FY94/95)
Military expenditures— percent of GDP: 0.1%
(FY94/95)','88e98f69f6157a67a6f099d157a95cb95a2c5d3fcd40865c30ede1fc57202657','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d53dbaec7343ab4a4843af68ef637eb6ab516a9112f358dae7d811940f9c8689',1998,'YT','Mayotte','military-and-security',641,'Military— note: defense is the responsibility of
France; small contingent of French forces stationed
on the island','eba194601cec8b116195f008ea0e8bf25f3b6e80ec5f2efc58c5abfbb79a7cbd','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40e4c9686083ef25d03f88217a071e834aa203011f65eda42d4a732bd0d341b4',1998,'MX','Mexico','military-and-security',643,'Military branches: National Defense Secretariat
(includes Army and Air Force), Navy Secretariat
(includes Naval Air and Marines)
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 25,1 14,890 (1998 est.)
Military manpower— fit for military service:
males: 18,280,523 (1998 est.)
Military manpower— reaching military age
annually:
males: 1 ,077,800 (1998 est.)
Military expenditures— dollar figure: $2.2 billion
(1997)
Military expenditures— percent of GDP: 0.3%
(1997)
Military branches: Norwegian Army, Royal
Norwegian Navy (includes Coast Artillery and Coast
Guard), Royal Norwegian Air Force, Home Guard
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 1 ,107,727 (1998 est.)
Military manpower— fit for military service:
males: 921 ,368 (1998 est.)
Military manpower— reaching military age
annually:
males: 27,406 (1998 est.)
Military expenditures— dollar figure: $3.7 billion
(1995)
Military expenditures— percent of GDP: 2.9%
(1995)
Military branches: Army, Navy, Air and Air Defense
Force, Territorial Defense Forces
Military manpower— military age: 1 9 years of age
Military manpower— availability:
males age 15-49: 10,374,242 (1998 est.)
Military manpower— fit for military service:
males: 8,069,61 1 (1 998 est.)
Military manpower— reaching military age
annually:
males: 333, 074 (1998 est.)
Military expenditures— dollar figure: $3.46 billion
(1997)
Military expenditures— percent of GDP: 2.3%
(1997)
Disputes— international: none
Illicit drugs: major illicit producer of amphetamines
for the international market; transshipment point for
Asian and Latin American illicit drugs to Western
Europe
Military branches: Army, Navy (includes Marines),
Air Force, National Republican Guard, Fiscal Guard,
Public Security Police
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 2,545,464 (1 998 est.)
Military manpower— fit for military service:
males: 2,048,310 (1998 est.)
Military manpower— reaching military age
annually:
males: 76, 870 (1998 est.)
Military expenditures— dollar figure: $2.07 billion
(1996)
Military expenditures— percent of GDP: 1 .9%
(1996)
Military branches: People''s Army of Vietnam
(PAVN) (includes Ground Forces, Navy, and Air
Force), Coast Guard
Military manpower— military age: 17 years of age
Military manpower— availability:
males age 15-49: 19,818,187 (1998 est.)
Military manpower— fit for military service:
males: 12,51 9,072 (1998 est.)
504
Military manpower— reaching military age
annually:
males: 81 1,382 (1998 est.)
Military expenditures— dollar figure: $544 million
(1995)
Military expenditures— percent of GDP: 2.7%
(1995)','697ac8b820ba400721924bd2d489d00279b67b147a219b85c6b26df210ba5d16','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00e9019e44a4d299ee373fca8f22123dcd5a42cbcb33ce4805fcabac8382d561',1998,'MS','Montserrat','military-and-security',649,'Military branches: Police Force
Military— note: defense is the responsibility of the
UK','0839aa03fb5c3985e6a9e5fd827d73f6f08ad3d916c8c233f88d0649bca08611','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0dbf0971e7e474036e9c57a4ca1e0baf54196f0dc19f61f31eab50dd8dc8467b',1998,'GI','Gibraltar','military-and-security',656,'Military branches: Royal Armed Forces (includes
Army, Navy, Air Force)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 7,505,524 (1 998 est.)
Military manpower— fit for military service:
males: 4,748,01 8 (1998 est.)
Military manpower— reaching military age
annually:
males: 31 4,329 (1998 est.)
Military expenditures— dollar figure: $1.31 3 billion
(1996)
Military expenditures— percent of GDP: 3.7%
(1996)','41aba8969894434027faf4abd91443a890b1a5e4f798bf860e795fec7e52aa48','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c01fe9c114f36dc13c979f9944a117cdeadb4b9332dc46b8e56823d9a48b84ea',1998,'NR','Nauru','military-and-security',662,'Military branches: no regular armed forces;
Directorate of the Nauru Police Force
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of the
US
Military branches: Royal Nepalese Army, Royal
Nepalese Army Air Service, Nepalese Police Force
Military manpower— military age: 17 years of age
Military manpower— availability:
males age 15-49: 5,739,283 (1998 est.)
Military manpower— fit for military service:
males: 2,983,449 (1998 est.)
Military manpower— reaching military age
annually:
males: 275,582 (1998 est.)
Military expenditures— dollar figure: $36 million
(FY92/93)
Military expenditures— percent of GDP: 1 .2%
(FY92/93)','ec9778b87587737b9f4f1461365a8d041abc285a7dd591240157c82f2103c6bc','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8eadd92ff0386a47f35635dea707e84ce3efc751d1d99df745ca2b9e76d73216',1998,'NZ','New Zealand','military-and-security',675,'Military branches: New Zealand Army, Royal New
Zealand Navy, Royal New Zealand Air Force
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49:938,194 (1998 est.)
Military manpower— fit for military service:
males: 789,542 (1998 est.)
Military manpower— reaching military age
annually:
males: 25, 61 2 (1998 est.)
Military expenditures— dollar figure: $1 .1 2 billion
(FY97/98)
Military expenditures— percent of GDP: 1 .05%
(FY97/98)
Military branches: Trinidad and Tobago Defense
Force (includes Ground Forces, Coast Guard, and Air
Wing), Trinidad and Tobago Police Service
Military manpower— availability:
males age 15-49: 31 3,01 8 (1 998 est.)
Military manpower— fit for military service:
males: 223,511 (1998 est.)
Military expenditures— dollar figure: $83 million
(1994)
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of
Military— note: defense is the responsibility of','7f7ab384cd41923dfa30b9b58db65e57028879fba9a76d8c5f08f4f38b126bc4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('117c390a9520102938cfd4f95e12b7a356b494d9fe6c8f5da8686aa53e90fa25',1998,'NI','Nicaragua','military-and-security',683,'Military branches: Ground Forces, Navy, Air Force
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 1 ,067,336 (1 998 est.)
Military manpower— fit for military service:
males: 656,672 (1998 est.)
Military manpower— reaching military age
annually:
males: 51 ,576 (1998 est.)
Military expenditures— dollar figure: $27.48
million (1996)
Military expenditures— percent of GDP: 1 .35%
(1996)','b99f35139afb6b7701e573f78025bccfba9cd56b9d492725d0a4271e9c811952','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e2faac4a0fd1405b15c0f6cada7a9062f159e347465d78abc96963d104b0b60',1998,'NG','Nigeria','military-and-security',686,'Military branches: Army, Air Force, National
Gendarmerie, Republican Guard, National Police
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 2,049,296 (1998 est.)
Military manpower— fit for military service:
males: 1,105,821 (1998 est.)
Military manpower— reaching military age
annually:
males: 98,946 (1998 est.)
Military expenditures— dollar figure: $23 million
(FY97/98)
Military expenditures— percent of GDP: 1 .3%
(FY92/93)
Military branches: Army, Navy, Air Force,
paramilitary Police Force
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 25,228,197 (1998 est.)
Military manpower— fit for military service:
males: 14,461 ,304 (1998 est.)
Military manpower— reaching military age
annually:
ma/es; 1 ,154,721 (1998 est.)
Military expenditures— dollar figure: $685 million
(1996 est.)
Military expenditures— percent of GDP: less than
1% (1996 est.)','0ac194ddbe2a6ca8a5dd7f658b0732848b596624b3501744155c717c382f18ae','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('131b135e4ea255182ec6e3335f52d3b778fefbbdd66352e3c77615a4950e1577',1998,'NU','Niue','military-and-security',698,'Military branches: Police Force
Military— note: defense is the responsibility of New
Zealand','5f20d91beb7092ad3fbfb5768fedbde0ce410e2317a280f70a9cf124451e6794','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('251714166cf82deb179895ae11220c5ecb2cc7d36e138c3787425c97da279cf3',1998,'MP','Northern Mariana Islands','military-and-security',709,'Military— note: defense is the responsibility of the
US
Military— note: defense is the responsibility of the
US','9fc94a627971428b8747a208195b92ee7530fe5fcc7a4796f2841d7c684010fd','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d45dfac50ae4b6c0a5c8917103c36db99577d97ba1804febdbe3225e6b0e6427',1998,'OM','Oman','military-and-security',718,'Military branches: Army, Navy, Air Force,
paramilitary (includes Royal Oman Police)
Military manpower— availability:
males age 15-49: 740,901 (1998 est.)
Military manpower— fit for military service:
males: 41 4,528 (1998 est.)
Military manpower— reaching military age
annually:
males: NA
Military expenditures— dollar figure: $1 .82 billion
(1996)
Military expenditures— percent of GDP: 13.7%
(1996)','9ffd40784cd6aff7474a254e5da78e73524758f6e00f65837fd32c2d21dc421e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33e93c9cb2008c7f59b9fc3797c6c55438ff205f7e5663272489f14dba7ff6ac',1998,'PK','Pakistan','military-and-security',726,'Military branches: Army, Navy, Air Force, Civil
Armed Forces, National Guard
Military manpower— military age: 1 7 years of age
Military manpower— availability:
males age 15-49: 32,450,056 (1998 est.)
Military manpower— fit for military service:
males: 19,888,353 (1998 est.)
Military manpower— reaching military age
annually:
males: 1,472,272 (1998 est.)
Military expenditures— dollar figure: $3.3 billion
(FY96/97)
Military expenditures— percent of GDP: 5.3%
(FY96/97)
Military branches: NA
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of the
US','151265f4af91bf2b8b4862f058d83128632cc3d769fd4a1853302cbd94935689','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73d351a739e08d09105ae366cbb5a38c8544f885bc455b8e9cc4bd86371d5997',1998,'PG','Papua New Guinea','military-and-security',735,'Military branches: Papua New Guinea Defense
Force (includes Ground, Naval, and Air Forces, and
Special Forces Unit)
Military manpower— availability:
males age 15-49: 1 ,206,458 (1 998 est.)
Military manpower— fit for military service:
males: 670,51 0(1 998 est.)
Military expenditures— dollar figure: $63 million
(1997); note— includes $12 million to cover leftover
1996 expenditures
Military expenditures— percent of GDP: NA','6a490c12efe7ba7d2e3b04823eee75d30a4ad6df33096ba7eeeb81938fbb407b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41ad9998d3d5d5c2411fcb866c029fed12a96f5354622908ab63d97988a9f9f7',1998,'PH','Philippines','military-and-security',741,'Military— note: occupied by China
Military branches: Army, Navy (includes Coast
Guard and Marine Corps), Air Force
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 19,734,347 (1998 est.)
Military manpower— fit for military service:
males: 13,921 ,259 (1998 est.)
Military manpower— reaching military age
annually:
males: 800, 148 (1998 est.)
Military expenditures— dollar figure: $1 .3 billion
(1996)
Military expenditures— percent of GDP: 0.7%
(1996)
Military— note: defense is the responsibility of the
UK
Military— note: about 50 small islands or reefs are
occupied by China, Malaysia, the Philippines, Taiwan,
and Vietnam','8aae49a237614e76d3e7f15031fbcbb143ba74adc7624393504a99cab42d5e6a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b88afc5584e8ece022937bb86d616ec49f2357ac3be9da9f9bb9fc515b70e930',1998,'DO','Dominican Republic','military-and-security',758,'Military branches: paramilitary National Guard,
Police Force
Military— note: defense is the responsibility of the
US','10ffb5f4d57351cb97ca86a9ca9711bedb35f27549247218916b23a9050bda55','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e48bf16c15b1ce5891ac8333bbce3a1cead50231be1591b0bd2d1ae98919d22',1998,'QA','Qatar','military-and-security',765,'Military branches: Army, Navy, Air Force, Public
Security
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 294,205 (1 998 est.)
note: includes non-nationals
Military manpower— fit for military service:
males: 154,436 (1998 est.)
Military manpower— reaching military age
annually:
males: 5, 777 (1998 est.)
Military expenditures— dollar figure: $400 million
(1996 est.)
Military expenditures— percent of GDP: 3.5%
(1996 est.)','45cc0ae4e966f968a958fb3166771eb01b0427d92354c160848ac51f419abee4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3de010ca2c092379dcaba4b925b44e39db44febaab813a18ce2a0cc25558cc0',1998,'UA','Ukraine','military-and-security',774,'Military branches: Army, Navy, Air and Air Defense
Forces, Paramilitary Forces, Civil Defense
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 5,888,775 (1998 est.)
Military manpower— fit for military service:
males: 4,951 ,586 (1998 est.)
Military manpower— reaching military age
annually:
males: 197,036 (1998 est.)
Military expenditures— dollar figure: $650 million
(1996)
Military expenditures— percent of GDP: 2.5%
(1996)','9b72cd73a830182a6a3711416bae0587baa07a7591d4b038cb25c261b81dcde9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22833322a437818248b9c8b85707c0539e7c07b976b89e5acc1e821a99829f1a',1998,'RW','Rwanda','military-and-security',777,'Military branches: Ground Forces, Navy, Air
Forces, Air Defense Forces, Strategic Rocket Forces
note: the air force and air defense force are to merge
in mid-1998
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 38,585,841 (1998 est.)
Military manpower— fit for military service:
males: 30,098,346 (1998 est.)
Military manpower— reaching military age
annually:
males: 1,128,416 (1998 est.)
Military expenditures— dollar figure: $NA
note: the Intelligence Community estimates that
defense spending in Russia fell by about 10% in real
terms in 1996, reducing Russian defense outlays to
about one-sixth of peak Soviet levels in the late 1 980s
(1997 est.)
Military expenditures— percent of GDP: NA%','4151593145c17605419ae637600a12c79899a1c0403020c1c41206e135b95757','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11fc9e72bb742edd1a78f2744dd453dcf62c8e7a42ca95bb7dcde5ba130bfe4b',1998,'UG','Uganda','military-and-security',785,'Military branches: Army, Gendarmerie
Military manpower— availability:
males age 15-49: 1 ,892,503 (1 998 est.)
Military manpower— fit for military service:
males: 963,21 8 (1998 est.)
Military expenditures— dollar figure: $112.5
million (1992)
Military expenditures— percent of GDP: 7%
(1992)
Military— note: defense is the responsibility of the
UK','a9c7ced18888c32bb835af6e5bc3b541a7d3ec9535f8def39ab1f8f6bd767dd9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d51da3ece7ed6e3c2dd2e3ef0e7151f4be1f216ead365a7491f76a210ae2613a',1998,'TT','Trinidad and Tobago','military-and-security',793,'Military branches: Royal Saint Kitts and Nevis
Police Force, Coast Guard
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%','1b3df22eb92fced08b4645cc3005091d302d0a9fd367e6bbc9940e4fa4a0747d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56f05a12c91e824188f0f1b5841af65c50681af3c01fc44b3374686c2925b9a4',1998,'MQ','Martinique','military-and-security',797,'Military branches: Royal Saint Lucia Police Force,
Coast Guard
Military expenditures— dollar figure: $5 million
(1991); note— for police force
Military expenditures— percent of GDP: 2%
(1991)
Military— note: defense is the responsibility of','24cf612a60183dd1f7464271b71e3a3f551660fec913fc1d07b0e5e4869adc52','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba506c64b5f6481631a80ce9fec03d246756f630b3a9a47fd68c07a3e6754bfe',1998,'IT','Italy','military-and-security',809,'Military branches: Voluntary Military Force, Police
Force
Military expenditures— dollar figure: $3.7 million
(1995)
Military expenditures— percent of GDP: 1 %
(1995)
Military branches: Army, Air Force, Frontier
Guards, Fortification Guards
Military manpower— military age: 20 years of age
Military manpower— availability:
males age 15-49: 1 ,878,453 (1 998 est.)
Military manpower— fit for military service:
males: 1,605,409 (1998 est.)
Military manpower— reaching military age
annually:
males: 40,887 (1998 est.)
Military expenditures— dollar figure: $3.2 billion
(1997)
Military expenditures— percent of GDP: 1 .2%
(1997)
Military branches: Syrian Arab Army, Syrian Arab
Navy, Syrian Arab Air Force, Syrian Arab Air Defense
Forces, Police and Security Force
Military manpower— military age: 19 years of age
Military manpower— availability:
males age 15-49: 3,899,714 (1998 est.)
Military manpower— fit for military service:
males: 2,182,608 (1998 est.)
Military manpower— reaching military age
annually:
males: 177,946 (1998 est.)
Military expenditures— dollar figure: $800
million-$1 billion (1997 est.); note— based on official
budget data that understate actual spending
Military expenditures— percent of GDP: 8% (1995
est.)
1 Transnational Issues
Disputes— international: Golan Heights is Israeli
occupied; Hatay question with Turkey; dispute with
upstream riparian Turkey over Turkish water
development plans for the Tigris and Euphrates
Rivers; Syrian troops in northern, central, and eastern
Lebanon since October 1976
Illicit drugs: a transit point for opiates and hashish
bound for regional and Western markets
454
[Taiwan
Entry
follows','1b52c8ea8e4bcb850d9e212bb4e7e350a17c759c214ff6668ed51aea1433298f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('981263bc470461d889215ad716954b50889b445b973457b0919b2212674a6c11',1998,'SA','Saudi Arabia','military-and-security',817,'Military branches: Land Force (Army), Navy, Air
Force, Air Defense Force, National Guard, Coast
Guard, Frontier Forces, Public Security Force,
Ministry of Interior Forces
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 5,595,295 (1998 est.)
Military manpower— fit for military service:
males: 3,1 12,733 (1998 est.)
Military manpower— reaching military age
annually:
males: 186,574 (1998 est.)
Military expenditures— dollar figure: $18.1 billion
(1997 est.)
Military expenditures— percent of GDP: 12%
(1997 est.)','a03ae97be450223f027318afea7e955edb7c49e9871e024fd916c52fdfbe648b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf216c5b4cb5189e2d10e7870a4f6417bf6f9f1725db116c26ad7a699d5e77ca',1998,'ML','Mali','military-and-security',824,'Military branches: Army, Navy, Air Force, National
Gendarmerie, National Police (Surete Nationale)
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 2,01 6,1 28 (1 998 est.)
Military manpower— fit for military service:
males: 1,052,825 (1998 est.)
Military manpower— reaching military age
annually:
males: 98,869 (1998 est.)
Military expenditures— dollar figure: $81 million
(1996 est.)
Military expenditures— percent of GDP: 2.1%
(1996 est.)','078762b429c3e89466890eb8f952a59a761c8cd37ad4ece926495870ab284ecb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac43387eb8e6c7c7495e98139dd1650903e093469aa9c13349c4be0a5927b675',1998,'SC','Seychelles','military-and-security',836,'Military branches: Army, Coast Guard, Marines,
National Guard, Presidential Protection Unit, Police
Force
Military manpower— availability:
males age 15-49 : 22,107 (1998 est.)
Military manpower— fit for military service:
males: 11,111 (1998 est.)
Military expenditures— dollar figure: $13.7 million
(1995)
Military expenditures— percent of GDP: NA%','4401f9351f82dd0b1078c19393b5994adfcba2ec906f559c41b6de939bd6e1a3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('335ab3e5e3a32ec70e59088a8cda743e3a2a4f1382d3c59eae2dee8225a7bd34',1998,'SB','Solomon Islands','military-and-security',854,'Military branches: no regular military forces;
Solomon Islands National Reconnaissance and
Surveillance Force; Royal Solomon Islands Police
(RS1P)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military branches: South African National Defense
Force or SANDF (includes Army, Navy, Air Force, and
Medical Services), South African Police Service or
SAPS
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 1 1 ,1 44,895 (1 998 est.)
Military manpower— fit for military service:
males: 6,777,677 (1998 est.)
Military manpower— reaching military age
annually:
males: 445,1 10 (1998 est.)
Military expenditures— dollar figure: $2.9 billion
(FY95/96)
Military expenditures— percent of GDP: 2.2%
(FY95/96)
Military— note: defense is the responsibility of the
UK','96f189b589eb995e7d32e423c7a931296e818266d23822679ddb1321a40c4af2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('329850f16647e290a6cd81058cba4bcd3f6fab089289e47e1d6bb686dd7eda1a',1998,'LK','Sri Lanka','military-and-security',862,'Military branches: Army, Navy, Air Force, Police
Force
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 5,147,100 (1998 est.)
Military manpower— fit for military service:
males: 4,006,31 4 (1998 est.)
Military manpower— reaching military age
annually:
males: 193,851 (1998 est.)
Military expenditures— dollar figure: $736 million
(1997)
Military expenditures— percent of GDP: 5.7%
(1997)
i Transnational Issues
Disputes— international: none','66ea2f94d3ef7682430db359d8ce5318593a4dbcf08cedc27790e4120467ccee','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c97cf5c755bea66209a70ae703e15c2664c54ec1e02535e189ec3759861ed816',1998,'SR','Suriname','military-and-security',866,'Military branches: Army, Navy, Air Force, Popular
Defense Force Militia
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 7,690,798 (1998 est.)
Military manpower— fit for military service:
males: 4,733,457 (1998 est.)
Military manpower— reaching military age
annually:
males: 363,752 (1998 est.)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%','4c1bb007ba1fdfd570d7c7bb702fa6a77e94245bebfb5eed379b44f4e60601db','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dabf1b28096c36529ce56146b05ea3c04ddf2c6689c899fbbf0f763b454af93c',1998,'ZW','Zimbabwe','military-and-security',869,'I "tro du ction Land use:
Current issues: Tajikistan has experienced three
changes of government and a civil war since it gained
independence in September 1 991 . The current
president, Emomali RAHMONOV, was elected in
November 1 994, yet has been in power since 1 992. A
peace agreement was signed in June 1997, but
implementation is progressing slowly. Russian-led
peacekeeping troops are deployed throughout the
country, and Russian-commanded border guards are
stationed along the Tajikistani-Afghan border.
Military branches: Army, Air Force, Presidential
National Guard, Security Forces (internal and border
troops)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 1 ,432,800 (1 998 est.)
Military manpower— fit for military service:
males: 1,174,683 (1998 est.)
Military manpower— reaching military age
annually:
males: 62,558 (1998 est.)
Military expenditures— dollar figure: 1 80 billion
rubles (1995); note— conversion of defense
expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures— percent of GDP: 3.4%
(1995)','2e8c7a19ba52f819c24544d104d675e6dbfbc0516dc34a94f056df2ed0d4ca6d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad276907d08c1209619f33d0edb0438abb4d13596ac3ec899c9539767288c09c',1998,'TH','Thailand','military-and-security',883,'Military branches: Royal Thai Army, Royal Thai
Navy (includes Royal Thai Marine Corps), Royal Thai
Air Force, Paramilitary Forces
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 17,296,871 (1998 est.)
Military manpower— fit for military service:
males: 10,435,956 (1998 est.)
Military manpower— reaching military age
annually:
males: 558,579 (1998 est.)
Military expenditures— dollar figure: $4 billion
(FY95/96)
Military expenditures— percent of GDP: 2.5%
(FY94/95)
Military branches: Army, Navy, Air Force,
Gendarmerie
Military manpower— availability:
males age 15-49: 1 ,058,480 (1 998 est.)
Military manpower— fit for military service:
males: 555,263 (1998 est.)
Military expenditures— dollar figure: $48 million
(1993)
Military expenditures— percent of GDP: 2.9%
(1993)','cc940ce7475f1e6fbfd98e06caea6efbf946e659a074369860d0560097ba0bf0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8fce77e94490cf9137da454725646b1c1eb59062574364e6612d946b21ed284',1998,'CN','China','military-and-security',901,'Military branches: Army, Navy, Air Force, Air
Defense Force, Internal Troops, National Guard,
Border Troops
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 12,431,318 (1998 est.)
Military manpower— fit for military service:
males: 9,733, 193 (1998 est.)
Military manpower— reaching military age
annually:
males: 367, 160 (1998 est.)
Military expenditures— dollar figure: 1.71 billion
hryvni (Ukrainian Government''s forecast for 1998);
note— conversion of defense expenditures into US
dollars using the current exchange rate could produce
misleading results
Military expenditures— percent of GDP: NA%','a8bf00054a4b391a0f932a08ab98608247b82426287cbfca467a878da818d248','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5932b5bd48d65fd982e6e8e10f4d4f84e8b51bae276bf39d0bbba1c8a83c3d62',1998,'UY','Uruguay','military-and-security',916,'Military branches: Army, Navy (includes Naval Air
Arm, Coast Guard, Marines), Air Force, Police
(Coracero Guard, Grenadier Guard)
Military manpower— availability:
males age 15-49: 799,977 (1998 est.)
Military manpower— fit for military service:
males: 648,999 (1998 est.)
Military expenditures— dollar figure: $172 million
(1996)
Military expenditures— percent of GDP: 0.9%
(1996)','1cdabdd4217235807e0bee0aac6a10a5dfae6dfae83b46c950640aad43c0d8ca','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6590dab7d134a03c70bdd9b13b1389f8ade4d004f574f804b0f8101f3e08713',1998,'UZ','Uzbekistan','military-and-security',925,'Military branches: Ministry of Defense (Army, Air,
and Air Defense), Security Forces (internal and border
troops)
note: National Guard is a component of the Army
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 5,996,041 (1998 est.)
Military manpower— fit for military service:
males: 4,874,324 (1998 est.)
Military manpower— reaching military age
annually:
males: 246,706 (1998 est.)
Military expenditures— dollar figure: 39.2 billion
soms (1996); note— conversion of defense
expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures— percent of GDP: 7%
(1996)','a05bdd335f99df4c65e959021332b5aa0e2dff82286370519ebf49dc764e4169','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ae0310a8e3af25f5779b507bd8f16e1843cff27ddc8875942a4f7bfd2efa6b2',1998,'VU','Vanuatu','military-and-security',931,'Military branches: no regular military forces;
Vanuatu Police Force (VPF; includes the paramilitary
Vanuatu Mobile Force or VMF)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%','ced5567929ea87d0374a9060ecc384467af6678fcd8abd67792ec28bed632a73','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57afe071778b625bd8d3b9070071f46208d17c992583a5187163e35fade8c28a',1998,'EH','Western Sahara','military-and-security',947,'Military branches: NA
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military branches: ground, maritime, and air forces
at all levels of technology
Military expenditures— dollar figure: aggregate
real expenditure on arms worldwide in 1997 remained
at about the 1 996 level, about three-quarters of a
trillion dollars in money terms (1997 est.)
Military expenditures— percent of GDP: roughly
2% of gross world product (1997 est.)
514','6cce4190d8dfeaf355e1c29f3275e013d258e0a7deab3c1a58dfef99b30c8da0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('428858baea19f01eaf6da653d32f327469908edac15fdad66381f88973816860',1998,'YE','Yemen','military-and-security',955,'Military branches: Army, Navy, Air Force,
paramilitary (includes Police)
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 3,61 1 ,41 9 (1 998 est.)
Military manpower— fit for military service:
males: 2,026,1 75 (1998 est.)
Military manpower— reaching military age
annually:
males: 204,674 (1998 est.)
Military expenditures— dollar figure: $407 million
(1998 est.)
Military expenditures— percent of GDP: 5% (1998
est.)','6d450fab446d3aa667d314b3789cb4aad0b726a435a06c9c1f154c875ccae01d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

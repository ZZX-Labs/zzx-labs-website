SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4220206a597362bae824a013da36f5ae1fc4899a70e216795bbe7e7a12850037',1998,'US','United States','transportation',12,'Railways
total
broad gauge
dual gauge
narrow gauge
other gauges
standard gauge
Highways
total
paved
unpaved
Waterways
Pipelines
Ports and harbors
Merchant marine
total
ships by type
Airports
Airports— with paved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Airports— with unpaved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Heliports
Transportation— note
Railways:
total: 24.6 km
broad gauge: 9.6 km 1 .524-m gauge from Gushgy
(Turkmenistan) toTowraghondi; 15 km 1, 524-m
gauge from Termiz (Uzbekistan) to Kheyrabad
transshipment point on south bank of Amu Darya
Highways:
total: 21 ,000 km
paved: 2,793 km
unpaved: 18,207 km (1996 est.)
Waterways: 1 ,200 km; chiefly Amu Darya, which
handles vessels up to about 500 DWT
Pipelines: petroleum products— Uzbekistan to
Bagram and Turkmenistan to Shindand; natural gas
180 km
Ports and harbors: Kheyrabad, Shir Khan
Airports: 44 (1997 est.)
Airports— with paved runways:
total: 11
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
under 914 m: 2(1997 est.)
Airports— with unpaved runways:
total: 33
2,438 to 3,047 m: 5
1,524 to 2,437 m: 14
914 to 1,523 m: 4
under 914 m:10(1997 est.)
Heliports: 3 (1997 est.)
2','5c570e486cd8c8bc150923fb6b90d86acdd9dd02369409e7ee04548e0a42e7e8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49483fad5dfc8280cf0714192f5938a7aa194c05540468cacd85a279c84332a2',1998,'DZ','Algeria','transportation',21,'Railways:
total: 670 km
standard gauge: 670 km 1 .435-m gauge (1995)
Highways:
total: 18,000 km
paved: 5,400 km
unpaved: 12,600 km (1996 est.)
Waterways: 43 km plus Albanian sections of Lake
Scutari, Lake Ohrid, and Lake Prespa (1990)
Pipelines: crude oil 145 km; petroleum products 55
km; natural gas 64 km (1991)
Ports and harbors: Durres, Sarande, Shengjin,
Vlore
Merchant marine:
total: 8 cargo ships (1 ,000 GRT or over) totaling
36,582 GRT/54,832 DWT (1997 est.)
Airports: 9 (1997 est.)
Airports— with paved runways:
total: 5
2,438 to 3,047 m: 3
914 to 1, 523 m: 2 (1997 est.)
Airports— with unpaved runways:
total : 4
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2(1997 est.)
Heliports: 1 (1997 est.)
Railways:
total: 4,772 km
standard gauge: 3,616 km 1.435-m gauge (301 km
electrified; 215 km double track)
narrow gauge: 1 ,156 km 1 .055-m gauge
Highways:
total: 102,424 km
paved: 70,570 km (including 608 km of expressways)
unpaved: 31 ,854 km (1 995 est.)
Pipelines: crude oil 6,612 km; petroleum products
298 km; natural gas 2,948 km
Ports and harbors: Algiers, Annaba, Arzew, Bejaia,
Beni Saf, Dellys, Djendjene, Ghazaouet, Jijel,
Mostaganem, Oran, Skikda, Tenes
Merchant marine:
total: 78 ships (1 ,000 GRT or over) totaling 928,965
G RT/1, 094,1 04 DWT
ships by type: bulk 9, cargo 27, chemical tanker 7,
liquefied gas tanker 1 1, oil tanker 5, roll-on/roll-off
cargo 1 3, short-sea passenger 5, specialized tanker 1
(1997 est.)
Airports: 136 (1997 est.)
Airports— with paved runways:
total: 50
over 3,047 m: 8
2,438 to 3,047 m: 24
1,524 to 2,437 m: 13
914 to 1,523 m: 4
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 86
2,438 to 3,047 m: 3
1,524 to 2,437 m: 24
914 to 1,523 m: 40
under 914 m: 19 (1997 est.)
Heliports: 1 (1997 est.)
Railways:
total: 15,172 km
broad gauge: 12,781 km 1.668-m gauge (6,355 km
electrified; 2,295 km double track)
standard gauge: 664 km 1 .435-m gauge (480 km
electrified)
narrow gauge: 1 ,727 km (privately owned: 1,708 km
1.000-m gauge, 517 km electrified; government
owned: 19 km 1.000-m gauge, all electrified) (1996)
Highways:
total: 344,847 km
paved: 341,399 km (including 7,747 km of
expressways)
unpaved: 3,448 km (1996 est.)
435
Spain (continued)
Waterways: 1 ,045 km, but of minor economic
importance
Pipelines: crude oil 265 km; petroleum products
1,794 km; natural gas 1,666 km
Ports and harbors: Aviles, Barcelona, Bilbao,
Cadiz, Cartagena, Castellon de la Plana, Ceuta,
Huelva, La Coruna, Las Palmas (Canary Islands),
Malaga, Melilla, Pasajes, Gijon, Santa Cruz de
Tenerife (Canary Islands), Santander, Tarragona,
Valencia, Vigo
Merchant marine:
total: 135 ships (1,000 GRT or over) totaling
1,043,747 GRT/1 ,651 ,634 DWT
ships by type: bulk 10, cargo 30, chemical tanker 7,
combination ore/oil 1 , container 8, liquefied gas tanker
3, oil tanker 29, passenger 2, refrigerated cargo 8,
roll-on/roll-off cargo 30, short-sea passenger 6,
specialized tanker 1 (1997 est.)
Airports: 98 (1997 est.)
Airports— with paved runways:
total: 64
over 3, 047 m: 15
2,438 to 3,047 m: 11
1,524 to 2,437 m: 16
91 4 to 1,523 m: 13
under 914 m: 9 (1997 est.)
Airports— with unpaved runways:
total: 34
1,524 to 2,437 mA
914 to 1,523 mA2
under 91 4 m: 21 (1997 est.)
Heliports: 2 (1997 est.)','a728231ac2e059c6d27943b3ef3cd01485832c7b324c9456f3c4c7c959d3efe2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e12632eaeee7cd0e03f5e7c731512feb66becafc4c403cc3781f4e083e754281',1998,'AS','American Samoa','transportation',33,'Railways: 0 km
Highways:
total: 350 km
paved: 150 km
unpaved : 200 km
Ports and harbors: Aunu''u (new construction),
Auasi, Faleosao, Ofu, Pago Pago, Ta''u
Merchant marine: none
Airports: 4 (1997 est.)
Airports— with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m:! (1997 est.)
Airports— with unpaved runways:
total: 2
under 914 m: 2 (1997 est.)
Railways: 0 km
Highways:
total: 269 km
paved: 198 km
unpaved: 71 km (1991 est.)
Ports and harbors: none
Airports: none
Railways:
total: 2,952 km limited trackage in use because of land
mines still in place from the civil war (1997 est.)
narrow gauge: 2,798 km 1.067-m gauge; 154 km
0.600-m gauge
Highways:
total: 72,626 km
paved: 18,157 km
unpaved: 54,469 km (1996 est.)
Waterways: 1 ,295 km navigable
Pipelines: crude oil 179 km
Ports and harbors: Ambriz, Cabinda, Lobito,
Luanda, Malongo, Namibe, Porto Amboim, Soyo
Merchant marine:
total: 1 0 ships (1 ,000 GRT or over) totaling 48,384
GRT/78,357 DWT
ships by type: cargo 9, oil tanker 1 (1 997 est.)
Airports: 252 (1 997 est.)
Airports— with paved runways:
total: 32
over 3,047 m: 4
2,438 to 3,047 m: 9
1,524 to 2,437 m: 12
914 to 1,523 m: 6
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 220
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 32
914 to 1,523 m: 101
under 914 m: 82 (1997 est.)
Railways: 0 km
Highways:
total: 105 km
paved: 65 km
unpaved: 40 km (1992 est.)
Ports and harbors: Blowing Point, Road Bay
Merchant marine: none
Airports: 3 (1997 est.)
Airports— with paved runways:
total: 1
914 to 1,523 m:1 (1997 est.)
Airports— with unpaved runways:
total: 2
under 914 m: 2 (1997 est.)
14
I Military
Military— note: defense is the responsibility of the
UK
l Transnational issues
Disputes— international: none','2ff88f704f57b5842a54f232b0bdffe38f18ba333faabe64f1332c1f383d67ac','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a956b0e6b6b27b315dda4926e14e4cf214e1abb5baa90280be47f328740222e5',1998,'AQ','Antarctica','transportation',37,'Location: continent mostly south of the Antarctic
Circle
Geographic coordinates: 90 00 S, 0 00 E
Map references: Antarctic Region
Area:
total: 14 million sq km
land: 14 million sq km (280,000 sq km ice-free, 13.72
million sq km ice-covered) (est.)
note: second-smallest continent (after Australia)
Area— comparative: slightly less than 1 .5 times the
size of the US
Land boundaries: 0 km
note: see entry on International disputes
Coastline: 17,968 km
Maritime claims: none, but see entry on
International disputes
Climate: severe low temperatures vary with latitude,
elevation, and distance from the ocean; East
Antarctica is colder than West Antarctica because of
its higher elevation; Antarctic Peninsula has the most
moderate climate; higher temperatures occur in
January along the coast and average slightly below
freezing
Terrain: about 98% thick continental ice sheet and
2% barren rock, with average elevations between
2,000 and 4,000 meters; mountain ranges up to about
5,000 meters; ice-free coastal areas include parts of
southern Victoria Land, Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on McMurdo
Sound; glaciers form ice shelves along about half of
the coastline, and floating ice shelves constitute 11%
of the area of the continent
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Vinson Massif 5,140 m
Natural resources: none presently exploited; iron
ore, chromium, copper, gold, nickel, platinum and
other minerals, and coal and hydrocarbons have been
found in small, uncommercial quantities
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (ice 98%, barren rock 2%)
Irrigated land: 0sqkm(1993)
Natural hazards: katabatic (gravity-driven) winds
blow coastward from the high interior; frequent
blizzards form near the foot of the plateau; cyclonic
storms form over the ocean and move clockwise along
the coast; volcanism on Deception Island and isolated
areas of West Antarctica; other seismic activity rare
and weak
Environment— current issues: in 1995 it was
reported that the ozone shield, which protects the
Earth''s surface from harmful ultraviolet radiation, had
dwindled to the lowest level recorded over Antarctica
since 1975 when measurements were first taken
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography— note: the coldest, windiest, highest,
and driest continent; during summer, more solar
radiation reaches the surface at the South Pole than is
received at the Equator in an equivalent period; mostly
uninhabitable
Ports and harbors: none; offshore anchorage
Airports: 1 8 (1 997 est.); 39 landing facilities at
different locations operated by 16 national
governments party to the Treaty; two additional air
facilities operated by commercial (nongovernmental)
tourist organizations; helicopter pads at 33 of these
locations; runways at 13 locations are gravel, sea ice,
glacier ice, or compacted snow surface suitable for
wheeled fixed-wing aircraft; no paved runways; 14
locations have snow-surface skiways limited to use by
ski-equipped planes— 8 run ways/ski ways greater
than 3,000 m, 12 runways/skiways 1 ,000 to 3,000 m,
2 runways/skiways less than 1 ,000 m, and 5 of
unspecified or variable length; airports generally
subject to severe restrictions and limitations resulting
from extreme seasonal and geographic conditions;
airports do not meet ICAO standards; advance
approval from the respective governmental or
nongovernmental operating organization required for
landing (1997 est.)
Airports— with unpaved runways:
total: 1 8
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 5 (1997 est.)
Heliports: 1 (1997 est.)
Railways:
total: 37,910 km
broad gauge: 24,124 km 1.676-m gauge (142 km
electrified)
standard gauge: 2,765 km 1.435-m gauge
narrow gauge: 1 1 ,021 km 1 .000-m gauge (26 km
electrified)
Highways:
total: 218,276 km
paved: 63,518 km (including 567 km of expressways)
unpaved: 154,758 km (1996 est.)
Waterways: 1 1 ,000 km navigable
Pipelines: crude oil 4,090 km; petroleum products
2,900 km; natural gas 9,918 km
Ports and harbors: Bahia Blanca, Buenos Aires,
Comodoro Rivadavia, Concepcion del Uruguay, La
Plata, Mar del Plata, Necochea, Rio Gallegos,
Rosario, Santa Fe, Ushuaia
Merchant marine:
total: 34 ships (1 ,000 GRT or over) totaling 268,492
GRT/388,524 DWT
ships by type: cargo 1 1 , container 2, oil tanker 13,
railcar carrier 1 , refrigerated cargo 6, roil-on/roll-off
cargo 1 (1997 est.)
Airports: 1,411 (1997 est.)
Airports— with paved runways:
total: 137
over 3,047 m:b
2,438 to 3,047m: 25
1,524 to 2,437 m: 55
914 to 1,523 m: 44
under 914 m: 8 (1997 est.)
Airports— with unpaved runways:
total: 1,274
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 65
914 to 1,523 m: 635
under 914 m: 570 (1997 est.)
Ports and harbors: none; offshore anchorage only
Ports and harbors: Alexandria (Egypt), Algiers
(Algeria), Antwerp (Belgium), Barcelona (Spain),
Buenos Aires (Argentina), Casablanca (Morocco),
Colon (Panama), Copenhagen (Denmark), Dakar
(Senegal), Gdansk (Poland), Hamburg (Germany),
Helsinki (Finland), Las Palmas (Canary Islands,
Spain), Le Havre (France), Lisbon (Portugal), London
(UK), Marseille (France), Montevideo (Uruguay),
Montreal (Canada), Naples (Italy), New Orleans (US),
New York (US), Oran (Algeria), Oslo (Norway),
Piraeus (Greece), Rio de Janeiro (Brazil), Rotterdam
(Netherlands), Saint Petersburg (Russia), Stockholm
(Sweden)
Transportation— note: Kiel Canal and Saint
Lawrence Seaway are two important waterways
Railways:
total: 38,563 km (2,914 km electrified; 172 km dual
gauge)
broad gauge: 6,083 km 1.600-m gauge
standard gauge: 1 6,752 km 1 .435-m gauge
narrow gauge: 1 5,728 km 1 .067-m gauge
Highways:
total: 91 3,000 km
paved: 353,331 km (including 1,3630 km of
expressways)
unpaved: 559,669 km (1996 est.)
Waterways: 8,368 km; mainly by small, shallow-draft
craft
Pipelines: crude oil 2,500 km; petroleum products
500 km; natural gas 5,600 km
Ports and harbors: Adelaide, Brisbane, Cairns,
Darwin, Devonport (Tasmania), Fremantle, Geelong,
Hobart (Tasmania), Launceston (Tasmania), Mackay,
Melbourne, Sydney, Townsville
Merchant marine:
total: 64 ships (1 ,000 GRT or over) totaling 2,1 22,604
GRT/3,045,417 DWT
ships by type: bulk 31 , cargo 3, chemical tanker 4,
combination bulk 1 , container 5, liquefied gas tanker
4, oil tanker 10, passenger 1 , roll-on/roll-off cargo 5
(1997 est.)
Airports: 419 (1997 est.)
Airports— with paved runways:
total: 259
over 3,047 m: 8
2,438 to 3,047 m: 13
1,524 to 2,437 m: 111
91 4 to 1,523 m:m
under 914 m: 8 (1997 est.)
Airports— with unpaved runways:
total: 160
1,524 to 2,437 m: 22
914 to 1,523 m: 123
under 914 m: 15(1997 est.)
Railways:
total: 5,636 km
standard gauge: 5,294 km 1 ,435-m gauge (3,263 km
electrified)
narrow gauge: 342 km 1.000-m and 0.760-m gauge
(84 km electrified) (1996)
Highways: 129,055 km
paved: 129,055 km (including 1,607 km of
expressways)
unpaved: 0 km (1 996 est.)
Waterways: 356 km (1996)
Pipelines: crude oil 777 km; natural gas 909.1 km
Ports and harbors: Linz, Vienna, Enns, Krems
Merchant marine:
total: 25 ships (1 ,000 GRT or over) totaling 84,103
GRT/114,616 DWT
ships by type: bulk 1 , cargo 1 9, combination bulk 2,
container 1, refrigerated cargo 2 (1997 est.)
Airports: 55 (1997 est.)
Airports— with paved runways:
total: 20
over 3,047 m:1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 1 0 (1 997 est.)
Airports— with unpaved runways:
total: 35
914 to 1,523 m: 4
under 914 m: 31 (1997 est.)
Heliports: 1 (1997 est.)','22263a694d8ff30c261c18c23d8e2fe7f2e4c22ccdda6e80f71af6090ca33ad4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('964518f2e876748536900c8706026fdcdc62a205451f91f2dfe56c28a737ed31',1998,'AG','Antigua and Barbuda','transportation',50,'Railways:
total: 77 km
narrow gauge: 64 km 0.760-m gauge; 13 km 0.61 0-m
gauge (used almost exclusively for handling
sugarcane)
Highways:
total: 250 km (1996 est.)
paved: NA km
unpaved: NA km
Ports and harbors: Saint John''s
Merchant marine:
total: 440 ships (1 ,000 GRT or over) totaling
2,025,920 GRT/2,690,028 DWT
ships by type: bulk 12, cargo 295, chemical tanker 6,
combination bulk 1 , container 89, liquefied gas tanker
2, oil tanker 4, refrigerated cargo 10, roll-on/roll-off
cargo 20, vehicle carrier 1
note: a flag of convenience registry: Germany owns
1 1 ships, Slovenia 3, Cyprus 2, and US 1 (1997 est.)
Airports: 3 (1997 est.)
Airports— with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m:1 (1997 est.)
Airports— with unpaved runways:
total: 1
under 914 m: 1 (1997 est.)
Ports and harbors: Churchill (Canada), Murmansk
(Russia), Prudhoe Bay (US)
Transportation— note: sparse network of air,
ocean, river, and land routes; the Northwest Passage
(North America) and Northern Sea Route (Eurasia)
are important seasonal waterways','c0eaf5bfccadd1a140719aec7d200e9e320eff93db021daa3d34960e8528edfc','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4582db9b333b706518233ca84606bc410ef0d726911e47b0c8fd3e533922c427',1998,'AZ','Azerbaijan','transportation',61,'Railways:
total: 2,125 km in common carrier service; does not
include industrial lines
broad gauge: 2,125 km 1 .520-m gauge (1,278 km
electrified) (1993)
Highways:
total: 57,770 km
paved: 54,1 88 km
unpaved: 3,582 km (1995 est.)
Pipelines: crude oil 1 ,130 km; petroleum products
630 km; natural gas 1 ,240 km
Ports and harbors: Baku (Baki)
Airports: 69 (1996 est.)
Airports— with paved runways:
total: 29
over 3,047 m: 2
2,438 to 3,047 m:6
1,524 to 2,437 m: 17
914 to 1,523 m: 3
under 914 m: 1 (1996 est.)
Airports— with unpaved runways:
total: 40
914 to 1,523 m: 1
under 914 m: 33 (1996 est.)','6cc53dfc856bb61f072ed305c12a9ac676e5b90129bacec9633af1b8e4bde987','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efcdcc34861ca91daa87725d232ae14aa7a86a95cf278fd42124eedd1e811708',1998,'BS','Bahamas','transportation',66,'Railways: 0 km
Highways:
total: 2,693 km
paved: 1 ,546 km
unpaved: 1 ,147 km (1997 est.)
Ports and harbors: Freeport, Matthew Town,
Nassau
Merchant marine:
total: 1 ,024 ships (1 ,000 GRT or over) totaling
24,674,594 GRT/38,334,892 DWT
ships by type: bulk 205, cargo 223, chemical tanker
34, combination bulk 8, combination ore/oil 21 ,
container 55, liquefied gas tanker 25, oil tanker 176,
passenger 53, railcar carrier 1 , refrigerated cargo 1 45,
roll-on/roll-off cargo 49, short-sea passenger 11,
specialized tanker 1, vehicle carrier 17
note: a flag of convenience registry; includes ships
from 48 countries among which are Norway 172,
Greece 145, UK 122, US 70, Denmark 42, Sweden
29, Finland 27, Monaco 27, Japan 26, and Italy 25
(1997 est.)
Airports: 62 (1997 est.)
Airports— with paved runways:
total: 32
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 15
914 to 1,523 m: 12
under 914 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 30
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 21 (1997 est.)
Railways: 0 km
Highways:
total: 121 km
paved: 24 km
unpaved: 97 km
Ports and harbors: Grand Turk, Providenciales
Merchant marine: none
Airports: 7 (1997 est.)
Airports— with paved runways:
total: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 3
914 to 1,523 m: 2
under 914 m: 1 (1997 est.)
f . Military
Military— note: defense is the responsibility of the
UK
l Transnational Issues
Disputes— international: none
Illicit drugs: transshipment point for South American
narcotics destined for the US
478
Railways: 0 km
Highways:
total: 8 km (1996 est.)
paved: NA km
unpaved: NA km
Ports and harbors: Funafuti, Nukufetau
Merchant marine:
total: 14 ships (1 ,000 GRT or over) totaling 53,220
GRT/83,118 DWT
ships by type: cargo 8, chemical tanker 4, oil tanker 1 ,
passenger-cargo 1 (1997 est.)
Airports: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)
Railways:
total: 1,241 km
narrow gauge: 1,241 km 1.000-m gauge
note: a program to rehabilitate the railroad is
underway (1995)
Highways:
total: 27,000 km
paved: 1,800 km
unpaved: 25,200 km (of which about 4,800 km are
all-weather roads) (1990 est.)
Waterways: Lake Victoria, Lake Albert, Lake Kyoga,
Lake George, Lake Edward, Victoria Nile, Albert Nile
Ports and harbors: Entebbe, Jinja, Port Bell
Merchant marine:
total: 3 roll-on/roll-off cargo ships (1 ,000 GRT or over)
totaling 5,091 GRT/8,229 DWT (1997 est.)
Airports: 29 (1997 est.)
Airports— with paved runways:
total : 5
over 3,047 m: 3
1,524 to 2,437 m: 1
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 24
2,438 to 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 8
under 914 m: 8 (1997 est.)','6f39816fbd2898bd041b8ce9cdbea4b2748d147cdf321aa9a6e2a7a31c358339','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41f4a0c5ebb1b59571cb1eaa64754ab2146630136a2a0a35041cfd308a5d5d0b',1998,'BH','Bahrain','transportation',74,'Railways: 0 km
Highways:
tofa/;3,013km
paved: 2,284 km
unpaved: 729 km (1996 est.)
Pipelines: crude oil 56 km; petroleum products 16
km; natural gas 32 km
Ports and harbors: Manama, Mina'' Salman, Sitrah
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 1 31 ,91 9
GRT/21 2,510 DWT
ships by type: bulk 2, cargo 3, oil tanker 1 (1997 est.)
Airports: 3 (1997 est.)
Airports— with paved runways:
total: 2
over 3,047 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)
Heliports: 1 (1997 est.)
Ports and harbors: none; offshore anchorage only;
note— there is one boat landing area along the middle
of the west coast
Airports: 1 abandoned World War II runway of 1 ,665
m
Transportation— note: there is a day beacon near
the middle of the west coast
1 Military
Military— note: defense is the responsibility of the
US; visited annually by the US Coast Guard
f Transnational Issues
Disputes— international: none
{Bangladesh
Geo g r a p by
Location: Southern Asia, bordering the Bay of
Bengal, between Burma and India
Geographic coordinates: 24 00 N, 90 00 E
Map references: Asia
Area:
total: 144,000 sq km
/and; 133,910 sq km
water: 10, 090 sq km
Area— comparative: slightly smaller than Wisconsin
Land boundaries:
total: 4,246 km
border countries: Burma 193 km, India 4,053 km
Coastline: 580 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: up to the outer limits of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; cool, dry winter (October to
March); hot, humid summer (March to June); cool,
rainy monsoon (June to October)
Terrain: mostly flat alluvial plain; hilly in southeast
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Reng Hang 957 m
Natural resources: natural gas, arable land, timber
Land use:
arable land: 73%
permanent crops: 2%
permanent pastures: 5%
forests and woodland: 1 5%
other: 5% (1993 est.)
Irrigated land: 31 ,000 sq km (1993 est.)
Natural hazards: droughts, cyclones; much of the
country routinely flooded during the summer monsoon
season
Environment— current issues: many people are
landless and forced to live on and cultivate
flood-prone land; limited access to potable water;
water-borne diseases prevalent; water pollution
especially of fishing areas results from the use of
commercial pesticides; intermittent water shortages
because of falling water tables in the northern and
central parts of the country; soil degradation;
deforestation; severe overpopulation
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Nuclear Test Ban,
Ozone Layer Protection, Wetlands
signed , but not ratified: Law of the Sea','3f960bf609ee573ea7c5cfe04ec7d2d73ca6b6c1b1511ec0fb2bff8f4090617a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32745223db1da815ff668c6dbbf5af5549cffa015df00ecb57896a124f710585',1998,'BD','Bangladesh','transportation',79,'Railways:
total: 2,892 km
broad gauge: 978 km 1.676-m gauge
narrow gauge: 1,914 km 1.000-m gauge (1992)
Highways:
total: 223,391 km
pav/ed; 16,084 km
unpaved : 207,307 km (1995 est.)
Waterways: 5,150-8,046 km navigable waterways
(includes 2,575-3,058 km main cargo routes)
Pipelines: natural gas 1 ,220 km
Ports and harbors: Chittagong, Dhaka, Mongla Port
(Chalna Port)
Merchant marine:
total: 39 ships (1 ,000 GRT or over) totaling 310,728
GRT/444,245 DWT
ships by type: bulk 2, cargo 31 , oil tanker 2,
refrigerated cargo 2, roll-on/roll-off cargo 2 (1 997 est.)
Airports: 16 (1997 est.)
Airports— with paved runways:
total: 1 5
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m:1
under 914 m: 7 (1997 est.)
Airports— with unpaved runways:
total: 1
over 3,047 m: 1 (1997 est.)','df1b7f27e9379ef0a8f26f519afce2d355698cd1c453e9083df02da97e23714c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fa03085a4b7ab961173cd47aad75c1372ee2f597eacbb08b4067deca418dd98',1998,'LC','Saint Lucia','transportation',88,'Railways: 0 km
Highways:
total: 1,640 km
paved: 1 ,573 km
unpaved: 67 km (1996 est.)
Ports and harbors: Bridgetown
Merchant marine:
total: 57 ships (1 ,000 GRT or over) totaling 869,363
GRT/1 ,365,640 DWT
ships by type: bulk 15, cargo 30, container 1 ,
combination bulk 4, multifunction large-load carrier 1,
oil tanker 4, refrigerated cargo 1, roll-on/roll-off cargo
1
note: a flag of convenience registry; includes ships of
2 countries: Canada owns 2 ships, Hong Kong 1
(1997 est.)
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (1997 est.)
Ports and harbors: none; offshore anchorage only
M iiitary
Military— note: defense is the responsibility of','89ebf9888a840df0d0f8c4fed628a5c8aab9a6f9e69c10b9e7489268a5afa3c7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8faa57d684289c1379d1742780abc0377b76d3e1d4a5953f9850f2cd8940acd4',1998,'FR','France','transportation',102,'Railways:
total: 5,488 km
broad gauge: 5,488 km 1 .520-m gauge (873 km
electrified) (1993)
Highways:
total: 52,131 km
paved: 36,544 km
unpaved: 15,587 km (1996 est.)
Waterways: NA km; note— Belarus has extensive
and widely used canal and river systems
Pipelines: crude oil 1,470 km; refined products
1,100 km; natural gas 1,980 km (1992)
Ports and harbors: Mazyr
Merchant marine:
note: claims 5% of former Soviet fleet (1 995 est.)
Airports: 118 (1996 est.)
Airports— with paved runways:
total: 36
over 3,047 m: 2
2,438 to 3,047 m: 1 8
1,524 to 2,437 m: 5
under 914 m: 11 (1996 est.)
Airports— with unpaved runways:
total: 82
over 3,047 m: 1
2,438 to 3,047 m: 6
1,524 to 2,437 m: 4
914 to 1,523 m: 9
under 914 m: 62 (1 996 est.)
Railways:
total: 3,368 km (2,386 km electrified; 2,563 km double
track)
standard gauge: 3,368 km 1 .435-m gauge (1996)
Highways:
total: 143,175 km
paved: 143,175 km (including 1,674 km of
expressways)
unpaved: 0 km (1996 est.)
Waterways: 2,043 km (1,528 km in regular
commercial use)
Pipelines: crude oil 161 km; petroleum products
1,167 km; natural gas 3,300 km
Ports and harbors: Antwerp (one of the world''s
busiest ports), Brugge, Gent, Hasselt, Liege, Mons,
Namur, Oostende, Zeebrugge
Merchant marine:
total: 25 ships (1 ,000 GRT or over) totaling 60,082
GRT/93,973 DWT
47
Belgium (continued)
ships by type: bulk 2, cargo 7, chemical tanker 5,
liquefied gas tanker 1, oil tanker 10 (1997 est.)
Airports: 42 (1997 est.)
Airports— with paved runways:
total: 24
over 3,047 m: 6
2,438 to 3,047 m: 9
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 6 (1997 est.)
Airports— with unpaved runways:
total: 18
914 to 1,523 m: 3
under 914 m: 15 (1997 est.)
Heliports: 1 (1997 est.)
Railways: 0 km
Highways:
total: 2,248 km
paved: 427 km
unpaved: 1,821 km (1996 est.)
Waterways: 825 km river network used by
shallow-draft craft; seasonally navigable
49
Belize (continued)
Ports and harbors: Belize City, Big Creek, Corozol,
Punta Gorda
Merchant marine:
total: 265 ships (1 ,000 GRT or over) totaling
1 ,298,562 GRT/2, 055,027 DWT
ships by type: bulk 26, cargo 1 84, chemical tanker 4,
combination bulk 1 , container 6, liquefied gas tanker
1 , oil tanker 26, passenger-cargo 2, refrigerated cargo
8, roll-on/roll-off cargo 4, specialized tanker 2, vehicle
carrier 1
note: a flag of convenience registry; includes ships of
8 countries: Cuba 1 , Cyprus 1 , Greece 1 , Hong Kong
1, Panama 1 , Singapore 2, UAE 2, and US 1 (1997
est.)
Airports: 44 (1997 est.)
Airports— with paved runways:
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 41
2,438 to 3,047 m: 1
914 to 1,523 m: 10
under 914 m: 30 (1997 est.)
Railways:
total: 578 km (single track)
narrow gauge: 578 km 1 .000-m gauge (1 995 est.)
Highways:
total: 6,787 km
paved: 1 ,357 km (including 10 km of expressways)
unpaved: 5,430 km (1996 est.)
Waterways: navigable along small sections,
important only locally
Ports and harbors: Cotonou, Porto-Novo
Merchant marine: none
Airports: 6 (1997 est.)
Airports— with paved runways:
total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 4
1,524 to 2,437 m: 1
914 to 1,523 m: 3 (1997 est.)
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: none; lagoon anchorage only
Merchant marine: none
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)
J T'' . . Military
Military— note: defense is the responsibility of
Railways:
total: 660 km
narrow gauge: 660 km 1 .000-meter gauge; 25 km
double track (1995 est.)
Highways:
total: 50,400 km
paved: 4,889 km
unpaved: 45,511 km (1996 est.)
Waterways: 980 km navigable rivers, canals, and
numerous coastal lagoons
Ports and harbors: Abidjan, Aboisso, Dabou,
San-Pedro
Merchant marine:
total: 1 oil tanker (1 ,000 GRT or over) totaling 1 ,200
GRT/1,500 DWT (1997 est.)
Airports: 36 (1997 est.)
Airports— with paved runways:
total: 7
over 3,047 m:\\
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4(1997 est.)
Airports— with unpaved runways:
total: 29
1,524 to 2,437 m: 8
914 to 1,523 m: 12
under 914 m: 9 (1997 est.)
M ill tar y
Military branches: Army, Navy, Air Force,
paramilitary Gendarmerie, Presidential Guard
Military manpower— military age: 18 years of age
Military manpower— availability:
males age 15-49: 3,583,410 (1998 est.)
Military manpower— fit for military service:
males: 1,866, 896 (1998 est.)
Military manpower— reaching military age
annually:
males: 172,000 (1998 est.)
Military expenditures— dollar figure: $1 40 million
(1993)
Military expenditures— percent of GDP: 1 .4%
(1993)
Railways: 0 km
Highways:
total: 348 km
paved: 83 km
unpaved: 265 km
Ports and harbors: Stanley
Merchant marine: none
Airports: 5 (1997 est.)
Airports— with paved runways:
total: 2
2,438 to 3,047 m:\\
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 3
under 914 m: 3 (1997 est.)
Location: Western Europe, bordering the Bay of
Biscay and English Channel, between Belgium and
Spain southeast of the UK; bordering the
Mediterranean Sea, between Italy and Spain
Geographic coordinates: 46 00 N, 2 00 E
Map references: Europe
Area:
total: 547,030 sq km
land: 545,630 sq km
water: 1 ,400 sq km
note: includes only metropolitan France, but excludes
the overseas administrative divisions
Area— comparative: slightly less than twice the size
of Colorado
Land boundaries:
total: 2,892.4 km
border countries: Andorra 60 km, Belgium 620 km,
Germany 451 km, Italy 488 km, Luxembourg 73 km,
Monaco 4.4 km, Spain 623 km, Switzerland 573 km
Coastline: 3,427 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm (does not apply to
the Mediterranean)
territorial sea: 12 nm
Climate: generally cool winters and mild summers,
but mild winters and hot summers along the
Mediterranean
Terrain: mostly flat plains or gently rolling hills in
north and west; remainder is mountainous, especially
Pyrenees in south, Alps in east
Elevation extremes:
lowest point: Rhone River delta -2 m
highest point: Mont Blanc 4,807 m
Natural resources: coal, iron ore, bauxite, fish,
timber, zinc, potash
Ports and harbors: Hamina, Helsinki, Kokkola,
Kotka, Loviisa, Oulu, Pori, Rauma, Turku,
Uusikaupunki, Varkaus
Merchant marine:
total: 93 ships (1 ,000 GRT or over) totaling 1 ,069,794
GRT/1 ,1 27,087 DWT
ships by type: bulk 8, cargo 22, chemical tanker 5, oil
tanker 1 1 , passenger 1 , railcar carrier 1 , roll-on/roll-off
cargo 34, short-sea passenger 11 (1997 est.)
Airports: 158 (1997 est.)
Airports— with paved runways:
total: 69
over 3,047 m: 3
2,438 to 3,047 m: 23
1,524 to 2,437 m: 13
914 to 1,523 m: 21
under 914 m: 9 (1997 est.)
Airports— with unpaved runways:
total: 89
914 to 1,523 m: 5
under 914 m: 84 (1997 est.)
Railways: 0 km (1995)
Highways:
total: 1,817 km (national 432 km, departmental 385
km, community 1,000 km)
paved: 727 km
unpaved: 1 ,090 km (1 995 est.)
Waterways: 460 km, navigable by small oceangoing
vessels and river and coastal steamers; 3,300 km
navigable by native craft
Ports and harbors: Cayenne, Degrad des Cannes,
Saint-Laurent du Maroni
Merchant marine: none
Airports: 11 (1997 est.)
Airports— with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 7
914 to 1,523 m: 3
under 914 m: 4(1997 est.)
Railways: 0 km
Highways:
total: 150 km
paved: 60 km
unpaved: 90 km
Ports and harbors: Kangerluarsoruseq,
Kangerlussuaq, Nanortalik, Narsarsuaq, Nuuk
(Godthab), Sisimiut
Merchant marine: none
Airports: 10 (1997 est.)
Airports— with paved runways:
total: 1
over 3,047 m:1
2,438 to 3,047m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2(1997 est.)
Airports— with unpaved runways:
total: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 2(1997 est.)
Railways:
total: NA km; privately owned, narrow-gauge
plantation lines
Highways:
total: 2,082 km (national 329 km, regional 582 km,
community/local 1,171 km)
paved: 1 ,742 km
unpaved: 340 km (1985 est.)
note: in 1 996 there were 3,200 km of roads
Ports and harbors: Basse-Terre, Gustavia (on
Saint Barthelemy), Marigot, Pointe-a-Pitre
Merchant marine: none
Airports: 9 (1997 est.)
Airports— with paved runways:
total: 8
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 5 (1997 est.)
Airports— with unpaved runways:
total: 1
under 914 m: 1 (1997 est.)
Railways: 0 km
Highways:
total: 2,724 km
paved: NA km
unpaved: NA km (1994)
Ports and harbors: Fort-de-France, La Trinite
Merchant marine: none
Airports: 2 (1997 est.)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)
Railways:
total: 1,928 km
broad gauge: 1,928 km 1.524-m gauge (1994)
Highways:
total: 46,470 km
paved: 3,730 km
unpaved: 42,740 km (1997 est.)
note: much of the unpaved rural road system consists
of rough cross-country tracks
Waterways: 397 km of principal routes (1988)
Ports and harbors: none
Airports: 34 (1994 est.)
Airports— with paved runways:
total: 8
2,438 to 3,047 m: 7
under 914 m: 1 (1994 est.)
Airports— with unpaved runways:
total: 26
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 10
914 to 1,523 m: 3
under 91 4 m: 5(1994 est.)
Railways:
total: 3,1 31 km
narrow gauge: 2,988 km 1.067-m gauge; 143 km
0.762-m gauge (1994)
Highways:
total: 30,400 km
paved: 5,685 km
unpaved: 24,715 km (1996 est.)
note: highway traffic impeded by land mines not
removed at end of civil war
Waterways: about 3,750 km of navigable routes
Pipelines: crude oil (not operating) 306 km;
petroleum products 289 km
Ports and harbors: Beira, Inhambane, Maputo,
Cidade de Nacala, Pemba
Merchant marine:
total: 4 cargo ships (1 ,000 GRT or over) totaling 5,694
GRT/9,724DWT (1997 est.)
Airports: 174 (1997 est.)
Airports— with paved runways:
total: 22
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 10
914 to 1,523 m: 4
under 914 m: 4 (1997 est.)
Airports— with unpaved runways:
total: 152
2,438 to 3,047 m: 1
1,524 to 2,437 m: 16
914 to 1,523 m: 38
under 914 m: 97 (1997 est.)
Railways:
total: 2,382 km
narrow gauge: 2,382 km 1 .067-m gauge; single track
(1995)
Highways:
total: 64,799 km
paved: 7,841 km
unpaved: 56,958 km (1996 est.)
Ports and harbors: Luderitz, Walvis Bay
Merchant marine: none
Airports: 135 (1997 est.)
328
Airports— with paved runways:
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 15
914 to 1,523 m: 3(1997 est)
Airports— with unpaved runways:
total: 113
2,438 to 3,047 m: 2
1,524 to 2,437 m: 20
91 4 to 1,523 m: 70
under 91 4 m: 21 (1997 est.)
Railways: 0 km
Highways:
total: 2,784 km
paved: 2,187 km
unpaved: 597 km (1987 est.)
Ports and harbors: Le Port, Pointe des Galets
Merchant marine: none
Airports: 2 (1997 est.)
Airports— with paved runways:
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1997 est.)
Railways: 0 km
Highways:
total: 1,040 km
paved: 320 km
unpaved: 720 km (1996 est.)
Ports and harbors: Kingstown
Merchant marine:
total: 799 ships (1,000 GRT or over) totaling
8,063,755 GRT/1 2,629,61 2 DWT
ships by type: barge carrier 1 , bulk 1 36, cargo 383,
chemical tanker 27, combination bulk 1 1 , combination
ore/oil 9, container 44, liquefied gas tanker 4, livestock
carrier 4, multi-function large load carrier 2, oil tanker
70, passenger 1, passenger-cargo 1, refrigerated
cargo 37, roll-on/roll-off cargo 53, short-sea
passenger 10, specialized tanker 5, vehicle carrier 1
note: a flag of convenience registry; includes ships
from 24 countries among which are Croatia 22,
Slovenia 8, China 7, Greece 7, UAE 4, Norway 3,
India 2, Japan 2, Russia 2, and Ukraine 2 (1997 est.)
Airports: 6 (1997 est.)
Airports— with paved runways:
total: 5
914 to 1,523 m: 2
under 914 m: 3(1997 est.)
Airports— with unpaved runways:
total: 1
under 914 m:) (1997 est.)
Railways:
total: 16,878 km
broad gauge: 342 km 1 .600-m gauge (1 90 km double
track); note— all 1 .600-m gauge track, of which 342
km is in common carrier use, is in Northern Ireland
standard gauge: 16,536 km 1 .435-m gauge (4,928 km
electrified; 12,591 km double or multiple track) (1996)
Highways:
total: 372,000 km
paved: 372,000 km (including 3,270 km of
expressways)
unpaved: 0 km (1996 est.)
Waterways: 3,200 km under British Waterways
Board
Pipelines: crude oil (almost all insignificant) 933 km;
petroleum products 2,993 km; natural gas 12,800 km
Ports and harbors: Aberdeen, Belfast, Bristol,
Cardiff, Dover, Falmouth, Felixstowe, Grangemouth,
Hull, Leith, Liverpool, London, Manchester,
Peterhead, Plymouth, Scapa Flow, Sullom Voe, Tees,
Tyne
Merchant marine:
total: 142 ships (1 ,000 GRT or over) totaling
2,192,956 GRT/2,224, 71 5 DWT
ships by type: bulk 5, cargo 26, chemical tanker 5,
combination ore/oil 1, container 21, liquefied gas
tanker 2, oil tanker 47, passenger 8, passenger-cargo
1 , roll-on/roll-off cargo 13, short-sea passenger 12,
specialized tanker 1
note: UK owns 337 additional ships (1 ,000 GRT or
over) totaling 13,511,240 DWT that operate under the
registries of Bermuda, The Bahamas, Cayman
Islands, Cyprus, Hong Kong, Isle of Man, Liberia,
Malta, Panama, Singapore, and Saint Vincent and the
Grenadines (1997 est.)
Airports: 497 (1997 est.)
Airports— with paved runways:
total: 356
over 3,047 m: 1 0
2,438 to 3,047m: 32
1,524 to 2,437 m: 170
914 to 1,523 m: 90
under 914 m: 54 (1997 est.)
Airports— with unpaved runways:
total: 141
1,524 to 2,437 m: 1
914 to 1,523 m: 24
under 914 m: 116 (1997 est.)
Heliports: 12 (1997 est.)
Railways:
total: 240,000 km mainline routes (nongovernment
owned)
standard gauge: 240,000 km 1.435-m gauge (1989)
Highways:
total: 6A2 million km
paved: 3,903,360 km (including 88,400 km of
expressways)
unpaved: 2,51 6,640 km (1996 est.)
Waterways: 41 ,009 km of navigable inland
channels, exclusive of the Great Lakes
Pipelines: petroleum products 276,000 km; natural
gas 331,000 km (1991)
Ports and harbors: Anchorage, Baltimore, Boston,
Charleston, Chicago, Duluth, Hampton Roads,
Honolulu, Houston, Jacksonville, Los Angeles, New
Orleans, New York, Philadelphia, Port Canaveral,
Portland (Oregon), Prudhoe Bay, San Francisco,
Savannah, Seattle, Tampa, Toledo
Merchant marine:
total: 286 ships (1 ,000 GRT or over) totaling
9,627,000 GRT/1 3,257,000 DWT
ships by type: bulk 15, container 79, chemical tanker
15, roll-on/roll-off 28, liquefied gas tanker 13, cruise/
passenger 3, tanker 94, tanker tug-barge 12, other 27
note: in addition, there are 192 government-owned
vessels (1997 est.)
Airports: 14,574 (1997 est.)
Airports— with paved runways:
total: 5,167
over 3,047 m: 181
2,438 to 3,047 m: 21 8
1,524 to 2,437 m: 1,280
914 to 1,523 m: 2,450
under 914 m: 1 ,038 (1 997 est.)
Airports— with unpaved runways:
total: 9,407
over 3,047 m: 1
2,438 to 3,047 m: 6
1,524 to 2,437 m: 164
914 to 1,523 m: 1,686
under 914 m: 7, 550 (1997 est.)
Heliports: 109 (1997 est.)
Railways: 0 km
Highways:
total: 4,500 km
paved: 2,700 km
unpaved: 1 ,800 km (1997 est.)
note : Israelis have developed many highways to
service Jewish settlements
Ports and harbors: none
Airports: 2 (1997 est.)
Airports— with paved runways:
total: 2
1,524 to 2,437 m: 1
under 914 m:1 (1997 est.)','cf39582dfd8ecb8ec3daa53d9e403b61c2752610b5f129f78a9497f8c6abe31e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56df7184e65806ed03380254edb66352de360c5b951f5bd0747797a1f5a58872',1998,'BM','Bermuda','transportation',114,'Railways: 0 km
Highways:
total: 225 km
paved: 225 km
unpaved: 0 km (1997 est.)
note : in addition, there are 232 km of paved and
unpaved roads that are privately owned
Ports and harbors: Hamilton, Saint George
Merchant marine:
total: 91 ships (1 ,000 GRT or over) totaling 4,590,132
GRT/7,440,524 DWT
ships by type: bulk 1 8, chemical tanker 1 , container
18, liquefied gas tanker 7, oil tanker 26, refrigerated
cargo 15, roll-on/roll-off cargo 3, short-sea passenger
2, vehicle carrier 1
note: a flag of convenience registry; includes ships
from 8 countries among which are UK 31 , Canada 1 3,
US 1 6, Norway 2, Hong Kong 1 , Nigeria 4, Sweden 4,
and Mexico 1 (1997 est.)
Airports: 1 (1 997 est.)
Airports— with paved runways:
total: 1
2,438 to 3,047 m: 1 (1997 est.)
Railways: 0 km
Highways:
total: 3,285 km
paved: 1 ,994 km
unpaved: 1 ,291 km (1996 est.)
Ports and harbors: none
Airports: 2 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)','4741679085c4ae8bb417f4bde9e5b8cdeb88fbd9cdb145ef0b6cc7f0508db9a8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f3256b5a8d60d1a15a779801cfcdb52392132e25800c51233a86934b028e924',1998,'BR','Brazil','transportation',124,'Railways:
total: 1 ,021 km (electrified 795 km; operating as diesel
or steam until grids are repaired)
standard gauge: 1 ,021 km 1 .435-m gauge (1 995);
note— some segments still need repair and/or
reconstruction
Highways:
total: 21 ,846 km
paved: 11,425 km
unpaved: 10,421 km (1996 est.)
note: roads need maintenance and repair
Waterways: NA km; Sava blocked by downed
bridges
Pipelines: crude oil 174 km; natural gas 90 km
(1992); note— pipelines now disrupted
Ports and harbors: Bosanski Brod (an inland
waterway port on the Sava which is not useable),
Orasje (ferry)
Merchant marine: none
Airports: 26 (1997 est.)
Airports— with paved runways:
total: 9
2,438 to 3, 047 m: 4
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 17
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 7 (1997 est.)
Heliports: 2 (1997 est.)
Railways:
total: 971 km
narrow gauge: 971 km 1.067-m gauge (1995)
Highways:
total: 18,482 km
paved: 4,343 km
unpaved: 1 4,1 39 km (1 996 est.)
Ports and harbors: none
Airports: 92 (1997 est.)
Airports— with paved runways:
total: 12
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 80
1,524 to 2,437 m: 3
91 4 to 1,523 m: 55
under 914 m: 22 (1997 est.)
Railways:
total: 971 km
standard gauge: 441 km 1.435-m gauge
narrow gauge: 60 km 1 .000-m gauge
other gauge: 470 km various gauges (privately
owned)
Highways:
total: 29,500 km
paved: 2,803 km
unpaved: 26,697 km (1996 est.)
Waterways: 3,100 km
Ports and harbors: Asuncion, Villeta, San Antonio,
Encarnacion
Merchant marine:
total: 19 ships (1 ,000 GRT or over) totaling 26,442
GRT/32,510 DWT
ships by type: cargo 14, chemical tanker 1 , oil tanker
3, roll-on/roll-off 1 (1997 est.)
Airports: 948 (1997 est.)
Airports— with paved runways:
total: 10
over 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 4 (1997 est.)
Airports— with unpaved runways:
total: 938
over 3,047 m: 1
1,524 to 2,437 m: 29
914 to 1,523 m: 353
under 914 m: 555 (1997 est.)
Railways:
total: 2,041 km
standard gauge: 1 ,726 km 1 .435-m gauge
narrow gauge: 31 5 km 0.91 4-m gauge (1994)
Highways:
total: 72,800 km
paved: 7,353 km
unpaved: 65,447 km (1996 est.)
Waterways: 8,600 km of navigable tributaries of
Amazon system and 208 km of Lago Titicaca
Pipelines: crude oil 800 km; natural gas and natural
gas liquids 64 km
Ports and harbors: Callao, Chimbote, llo, Matarani,
372
Paita, Puerto Maldonado, Salaverry, San Martin,
Talara, Iquitos, Pucallpa, Yurimaguas
note: Iquitos, Pucallpa, and Yurimaguas are all on the
upper reaches of the Amazon and its tributaries
Merchant marine:
total: 8 ships (1,000 GRT or over) totaling 68,752
GRT/1 00,21 3 DWT
ships by type: bulk 1 , cargo 7 (1 997 est.)
Airports: 244 (1997 est.)
Airports— with paved runways:
total: 43
over 3,047 m: 6
2,438 to 3,047 m: 15
1,524 to 2,437 m: 12
914 to 1,523 m: 8
under 914 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 201
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 24
91 4 to 1,523 m: 73
under 914 m: 1 00 (1 997 est.)','b292eb48349dafb7d3c9810c2e35c3c9a465f1e73024e0dadc9d0b237787753e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a0de1ec9a96b9b63adf191de1c6bad7d55333788f00e0a137103730ddd497be',1998,'NO','Norway','transportation',132,'Railways:
total: 26,895 km (1 ,750 km electrified)
broad gauge: 5,730 km 1.600-m gauge
standard gauge: 1 94 km 1 .440-m gauge
narrow gauge: 20,958 km 1.000-m gauge; 13 km
0.760-m gauge
dual gauge: 523 km 1.000-m and 1.600-m gauges
Highways:
total: 1.98 million km
paved: 184,1 40 km
unpaved: 1 ,795,860 km (1996 est.)
Waterways: 50,000 km navigable
Pipelines: crude oil 2,000 km; petroleum products
3,804 km; natural gas 1,095 km
Ports and harbors: Belem, Fortaleza, llheus,
Imbituba, Manaus, Paranagua, Porto Alegre, Recife,
Rio de Janeiro, Rio Grande, Salvador, Santos, Vitoria
Merchant marine:
total: 1 88 ships (1 ,000 GRT or over) totaling
4,498,081 GRT/7,279,945 DWT
ships by type: bulk 37, cargo 26, chemical tanker 9,
combination ore/oil 11, container 16, liquefied gas
tanker 10, multifunction large-load carrier 1 , oil tanker
61 , passenger-cargo 5, refrigerated cargo 1 , roll-on/
roll-off cargo 1 1 (1997 est.)
Airports: 3,291 (1997 est.)
Airports— with paved runways:
total: 502
over 3, 047 m: 5
2,438 to 3,047 m: 19
1,524 to 2,437 m: 130
914 to 1,523 m: 319
under 914 m: 29 (1997 est.)
Airports— with unpaved runways:
total: 2,789
1,524 to 2,437 m: 76
914 to 1,523 m: 1 ,324
under 914 m: 1 ,389 (1 997 est.)
Railways:
total: 23,670.7 km
standard gauge: 2,893.1 km 1.435-m gauge (entirely
electrified)
narrow gauge: 89.8 km 1 .372-m gauge (89.8 km
electrified); 20,656.8 km 1 .067-m gauge (1 0,383.6 km
electrified); 31 km 0.762-m gauge (3.6 km electrified)
(1994)
Highways:
total: 1.16 million km
paved: 859,560 km (including 6,070 km of
expressways)
unpaved: 300,440 km (1996 est.)
Waterways: about 1 ,770 km; seagoing craft ply all
coastal inland seas
Pipelines: crude oil 84 km; petroleum products
322 km; natural gas 1 ,800 km
Ports and harbors: Akita, Amagasaki, Chiba,
Hachinohe, Hakodate, Higashi-Harima, Himeji,
Hiroshima, Kawasaki, Kinuura, Kobe, Kushiro,
Mizushima, Moji, Nagoya, Osaka, Sakai, Sakaide,
Shimizu, Tokyo, Tomakomai
Merchant marine:
total: 738 ships (1 ,000 GRT or over) totaling
14,323,766 GRT/20,709,738 DWT
ships by type: bulk 1 69, cargo 55, chemical tanker 6,
combination bulk 1 1, combination ore/oil 6, container
32, liquefied gas tanker 39, oil tanker 244, passenger
7, passenger-cargo 2, refrigerated cargo 34, roll-on/
roll-off cargo 46, short-sea passenger 16, specialized
tanker 1 , vehicle carrier 70
note: Japan owns an additional 1 ,534 ships (1 ,000
GRT or over) totaling 54,985,374 DWT operating
under the registries of The Bahamas, Burma, Cayman
Islands, Cyprus, Hong Kong, Honduras, Liberia,
Marshall Islands, Norway, Panama, Philippines, Saint
Vincent and the Grenadines, Singapore, and Vanuatu
(1997 est.)
Airports: 167 (1997 est.)
Airports — with paved runways:
total: 137
over 3,047 m:7
2,438 to 3,047 m: 32
1,524 to 2,437 m: 38
914 to 1,523 m: 29
under 91 4 m: 31 (1997 est.)
Airports— with unpaved runways:
total: 30
914 to 1,523 m: 2
under 914 m: 28 (1997 est.)
Heliports: 14 (1997 est.)','b79961c9a5fa8728094acc6edf91a5fec724c2061cfe46b3c46bfaf6ce509358','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e38289485be6d785a1b0f284ed1e11c513bacf7c8780c6965200b973fa77a19c',1998,'ID','Indonesia','transportation',142,'Railways: 0 km
Highways:
total: 113 km (1995 est.)
paved: NA km
unpaved: NA km
Ports and harbors: Road Town
Merchant marine: none (1995 est.)
Airports: 3 (1997 est.)
Airports— with paved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)
j! Military
Military— note: defense is the responsibility of the
UK
Railways:
total: 13 km (private line)
narrow gauge: 13 km 0.61 0-m gauge
Highways:
total: 1,150 km
paved: 399 km
unpaved: 751 km (1996 est.)
Waterways: 209 km; navigable by craft drawing less
than 1.2 m
Pipelines: crude oil 1 35 km; petroleum products 41 8
km; natural gas 920 km
Ports and harbors: Bandar Seri Begawan, Kuala
Belait, Muara, Seria, Tutong
Merchant marine:
total: 7 liquefied gas tankers (1,000 GRT or over)
totaling 348,476 GRT/340,635 DWT (1997 est.)
Airports: 2 (1997 est.)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)
Heliports: 3 (1997 est.)
Railways:
total: 6,458 km
narrow gauge: 5,961 km 1.067-m gauge (101 km
electrified; 101 km double track); 497 km 0.750-m
gauge (1995)
Highways:
total: 393,000 km
paved: 178,815 km
unpaved: 214,185 km (1996 est.)
Waterways: 21 ,579 km total; Sumatra 5,471 km,
Java and Madura 820 km, Kalimantan 10,460 km,
Sulawesi (Celebes) 241 km, Irian Jaya 4,587 km
Pipelines: crude oil 2,505 km; petroleum products
456 km; natural gas 1,703 km (1989)
Ports and harbors: Cilacap, Cirebon, Jakarta,
Kupang, Palembang, Semarang, Surabaya,
Ujungpandang
Merchant marine:
total: 503 ships (1 ,000 GRT or over) totaling
2,433,857 GRT/3, 51 0,81 8 DWT
223
Indonesia (continued)
ships by type: bulk 35, cargo 291 , chemical tanker 8,
container 1 1 , liquefied gas tanker 5, livestock carrier
1, oil tanker 105, passenger 8, passenger-cargo 12,
roll-on/roll-off cargo 10, short-sea passenger 6,
specialized tanker 6, vehicle carrier 5 (1997 est.)
Airports: 442 (1997 est.)
Airports— with paved runways:
total: 124
over 3,047 m: 4
2,438 to 3,047 m: 11
1,524 to 2,437 m: 40
914 to 1,523 m: 41
under 914 m: 28 (1997 est.)
Airports— with unpaved runways:
total: 31 8
1,524 to 2,437 m: 5
914 to 1,523 m: 32
under 914 m: 281 (1997 est.)
Heliports: 4 (1997 est.)
Railways:
total: 7,286 km
broad gauge: 94 km 1.676-m gauge
standard gauge: 7, 192 km 1.435-m gauge (146 km
electrified) (1996 est.)
Highways:
total: 162,000 km
paved: 81 ,000 km (including 470 km of expressways)
unpaved: 81 ,000 km (1996 est.)
Waterways: 904 km; the Shaft al Arab is usually
navigable by maritime traffic for about 130 km;
channel has been dredged to 3 m and is in use
Pipelines: crude oil 5,900 km; petroleum products
3,900 km; natural gas 4,550 km
Ports and harbors: Abadan (largely destroyed in
fighting during 1980-88 war), Ahvaz, Bandar ''Abbas,
Bandar-e Anzaii, Bushehr, Bandar-e Khomeyni,
Bandar-e Lengeh, Bandar-e Mahshahr, Bandar-e
Torkaman, Chabahar (Bandar Beheshti), Jazireh-ye
Khark, Jazireh-ye Lavan, Jazireh-ye Sirri,
Khorramshahr (limited operation since November
1992), Now Shahr
Merchant marine:
total: 135 ships (1 ,000 GRT or over) totaling
3,465,226 GRT/6,1 28,443 DWT
ships by type: bulk 47, cargo 34, chemical tanker 4,
combination bulk 2, container 4, liquefied gas tanker
1, multifunction large-load carrier 6, oil tanker 23,
refrigerated cargo 3, roll-on/roll-off cargo 10,
short-sea passenger 1
note: Iran owns an additional 5 ships (1,000 GRT or
over) totaling 245,742 DWT that operate under the
registries of Cyprus, Honduras, and Panama
(1997 est.)
Airports: 280 (1997 est.)
Airports— with paved runways:
total : 103
over 3,047 m: 36
2,438 to 3,047 m: 14
1,524 to 2,437 m: 27
914 to 1,523 m: 21
under 914 m: 5 (1997 est.)
Airports— with unpaved runways:
total: 177
over 3,047 m: 1
2,438 to 3,047m: 4
1,524 to 2,437 m: 14
914 to 1,523 m: 124
under 914 m: 34 (1997 est.)
Heliports: 11 (1997 est.)
Railways:
total: 2,032 km
standard gauge: 2,032 km 1.435-m gauge
Highways:
total: 47,400 km
paved: 40,764 km
unpaved: 6,636 km (1996 est.)
Waterways: 1,015 km; Shatt al Arab is usually
navigable by maritime traffic for about 130 km;
channel has been dredged to 3 meters and is in use;
Tigris and Euphrates Rivers have navigable sections
for shallow-draft watercraft; Shatt al Basrah canal was
navigable by shallow-draft craft before closing in 1 991
because of the Persian Gulf war
Pipelines: crude oil 4,350 km; petroleum products
725 km; natural gas 1,360 km
Ports and harbors: Umm Qasr, Khawr az Zubayr,
and Al Basrah have limited functionality
Merchant marine:
total: 35 ships (1 ,000 GRT or over) totaling 791 ,485
GRT/1 ,428,307 DWT
ships by type: cargo 14, oil tanker 16, passenger 1 ,
passenger-cargo 1 , refrigerated cargo 1, roll-on/
roll-off cargo 2 (1997 est.)
Airports: 111 (1997 est.)
Airports— with paved runways:
total: 76
over 3,047 m: 22
2,438 to 3,047 m: 33
1,524 to 2,437 m: 7
914 to 1,523 m: 7
under 914 m: 7 (1997 est.)
Airports— with unpaved runways:
total: 35
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 10 (1997 est.)
Heliports: 4 (1997 est.)
Railways: 0 km
Highways:
total: 240 km
paved: 42 km
unpaved: 1 98 km (1996 est.)
Ports and harbors: Colonia (Yap), Kolonia
(Pohnpei), Lele, Moen
Merchant marine: none
Airports: 6 (1997 est.)
Airports— with paved runways:
total: 5
1,524 to 2,437 m: 4
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
91 4 to 1,523 m: 1 (1997 est.)
Highways:
total: 32 km
paved: NA km
unpaved: NA km
Pipelines: 7.8 km
Ports and harbors: Sand Island
Airports: 3 (1997 est.)
Airports— with paved runways:
total: 2
1,524 to 2,437 m: 2 (1 997 est.)
Airports— with unpaved runways:
total: 1
914 to 1,523 m:] (1997 est.)
419
Singapore (continued)
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography— note: focal point for Southeast Asian
sea routes
Railways:
total: 38.6 km
narrow gauge: 38.6 km 1 .000-m gauge
note; there is a 67 km mass transit system with 42
stations
Highways:
total: 3,01 0 km
paved: 2,932 km (including 150 km of expressways)
unpaved: 78 km (1995 est.)
Ports and harbors: Singapore
Merchant marine:
total: 856 ships (1 ,000 GRT or over) totaling
18,463,338 GRT/29,322,743 DWT
ships by type: bulk 135, cargo 146, chemical tanker
42, combination bulk 5, combination ore/oil 6,
container 143, liquefied gas tanker 30, livestock
carrier 1, multifunction large-load carrier 7, oil tanker
284, refrigerated cargo 9, roll-on/roll-off cargo 1 1 ,
short-sea passenger 1 , specialized tanker 7, vehicle
carrier 29
note: a flag of convenience registry; includes ships
from 22 countries among which are Japan 42,
Denmark 32, Hong Kong 31 , Sweden 24, Thailand 24,
Germany 18, Taiwan 12, Belgium 12, China 11, and
Indonesia 1 1 ; Singapore also owns an additional 1 96
ships (1,000 GRT or over) totaling 10,052,598 DWT
that operate under the registries of The Bahamas,
Belize, Cyprus, Hong Kong, Honduras, Liberia, Malta,
Panama, Philippines, and Saint Vincent and the
Grenadines (1997 est.)
Airports: 9 (1997 est.)
Airports— with paved runways:
total: 9
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m:] (1997 est.)','3ef4552cd793efa9b2453fb151b8f71ac338425bfb58ac826f65472e7133c2aa','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9eccfc66937417a0e79d7c3b1b16f5c22549152b916b288ec0ab6045b47d5e18',1998,'BG','Bulgaria','transportation',147,'Railways:
total: 4,292 km
standard gauge: 4,047 km 1 .435-m gauge (2,650 km
electrified; 917 double track)
other gauge: 245 km 0.760-m gauge (1995)
Highways:
total: 36,720 km
paved: 33,746 km (including 314 km of expressways)
unpaved: 2,974 km (1996 est.)
Waterways: 470 km (1987)
Pipelines: crude oil 193 km; petroleum products 525
km; natural gas 1,400 km (1992)
Ports and harbors: Burgas, Lorn, Nesebur, Ruse,
Varna, Vidin
Merchant marine:
total: 94 ships (1 ,000 GRT or over) totaling 1 ,027,1 1 7
GRT/1,541,266 DWT
ships by type: bulk 45, cargo 23, chemical tanker 4,
container 2, oil tanker 9, passenger-cargo 1, railcar
carrier 2, refrigerated cargo 1 , roll-on/roll-off cargo 6,
short-sea passenger 1 (1997 est.)
Airports: 34 (1997 est.)
Airports— with paved runways:
total: 34
over 3,047 m: 1
2,438 to 3,047 m: 14
1,524 to 2,437 m: 9
under 914 m: 10 (1997 est.)
72','96cf336939701313a6c9d11c6ab30a653d5d5a4a6a2432369a72af356581ca86','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64cffaed493938f2759d332c37162fd7d67db48d5b84fd239f0f019a72b5bd4a',1998,'ET','Ethiopia','transportation',150,'Railways:
total: 622 km (51 7 km from Ouagadougou to the Cote
d''Ivoire border and 105 km from Ouagadougou to
Kaya)
narrow gauge: 622 km 1.000-m gauge (1995 est.)
Highways:
total: 12,506 km
paved: 2,001 km
unpaved: 10,505 km (1995 est.)
Ports and harbors: none
Airports: 33 (1997 est.)
Airports— with paved runways:
total: 2
over 3,047 m:1
2,438 to 3,047 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 31
1,524 to 2,437 m: 3
914 to 1,523 m: 14
under 914 m: 14(1997 est.)
f Military
Military branches: Army, Air Force, National
Gendarmerie, National Police, People''s Militia
Military manpower— availability:
males age 15-49: 2,317,227 (1998 est.)
Military manpower— fit for military service:
males: 1,187,840 (1998 est.)
Military expenditures— dollar figure: $104 million
(1994)
Military expenditures— percent of GDP: 6.4%
(1994)
Railways: 0 km
Highways:
total: 4,400 km
paved: 453 km
unpaved: 3,947 km (1 996 est.)
Waterways: several rivers are accessible to coastal
shipping
Ports and harbors: Bissau, Buba, Cacheu, and
Farim
Merchant marine: none
Airports: 30 (1997 est.)
Airports— with paved runways:
total: 3
over 3,047 m: 1
1,524 to 2,437 mA
914 to 1,523 mA (1997 est.)
Airports— with unpaved runways:
total: 27
1,524 to 2,437 mA
914 to 1,523 m: 4
under 914 m: 22 (1997 est.)
Railways: 0 km
Highways:
total: 320 km
paved: 21 8 km
unpaved: 102 km (1996 est.)
Ports and harbors: Santo Antonio, Sao Tome
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 1 ,096
GRT/1,105 DWT (1997 est.)
Airports: 2 (1997 est.)
Airports— with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1997 est.)','a020fac25065ed65f38f6e6e9577d3718bd65e45c4508504942475b7817b53fb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51e58ee316b3d668aed6eb7e124dd1cba3ef983676d5732b695a4344d1ea06fc',1998,'MY','Malaysia','transportation',157,'Railways:
totai: 3,569 km
narrow gauge: 3,569 km 1.000-m gauge (1995)
Highways:
totai: 28,200 km
paved: 3,440 km
unpaved: 24,760 km (1996 est.)
Waterways: 1 2,800 km; 3,200 km navigable by large
commercial vessels
Pipelines: crude oil 1,343 km; natural gas 330 km
Ports and harbors: Bassein, Bhamo, Chauk,
Mandalay, Moulmein, Myitkyina, Rangoon, Akyab
(Sittwe), Tavoy
Merchant marine:
total: 45 ships (1 ,000 GRT or over) totaling 561 ,786
GRT/742,450 DWT
ships by type: bulk 1 5, cargo 1 8, chemical tanker 1 ,
container 2, oil tanker 3, passenger-cargo 3,
refrigerated cargo 1 , vehicle carrier 2
note: a flag of convenience registry; includes ships of
2 countries: Japan owns 2 ships, US 3 (1997 est.)
Airports: 80 (1997 est.)
Airports— with paved runways:
total: 24
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 12
914 to 1,523 m: 7(1997 est.)
Airports— with unpaved runways:
total: 56
over 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 19
under 914 m: 32 (1997 est.)
Heliports: 1 (1997 est.)
Railways:
total: 3,665 km
broad gauge: 107 km 1.520-m gauge
standard gauge: 3,507 km 1.435-m gauge (1424 km
electrified)
narrow gauge: 51 km (46 km 1,000-m gauge; 5 km
0.750-m gauge) (1996)
Highways:
total: 36,608 km
paved: 36,059 km (including 21 5 km of expressways)
unpaved: 549 km (1996 est.)
Waterways: 172 km on the Danube
Pipelines: petroleum products NA km; natural gas
2,700 km
Ports and harbors: Bratislava, Komarno
423
Slovakia (continued)
Merchant marine:
total: 3 cargo ships (1 ,000 GRT or over) totaling
15,041 GRT/1 9,517 DWT (1997 est.)
Airports: 13 (1997 est.)
Airports— with paved runways:
total: 8
over 3,047 m: 1
2,438 to 3,047m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 5
914 to 1,523 m: 2
under 91 4 m: 3 (1997 est.)','7be8559ec52eec122c932625f9dbf6d768113eb8277a65b5a09b23d7db7d3cda','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a1927ca1fd17e92f095e8ee2d8f2b72e9d424d587826fc97ca4dfd2c33c4b1f',1998,'BI','Burundi','transportation',166,'Railways: 0 km
Highways:
total: 14,480 km
paved: 1,028 km
unpaved: 13,452 km (1995 est.)
Waterways: Lake Tanganyika
Ports and harbors: Bujumbura
Airports: 4 (1997 est.)
Airports— with paved runways:
total: 1
over 3,047 m:1 (1997 est.)
Airports— with unpaved runways:
total: 3
914 to 1,523 m: 2
under 914 m: 1 (1997 est.)
I Military
Military branches: Army (includes naval and air
units), paramilitary Gendarmerie
Military manpower— military age: 16 years of age
Military manpower— availability:
males age 15-49: 1 ,203,51 8 (1 998 est.)
Military manpower— fit for military service:
males: 627,587 (1998 est.)
Military manpower— reaching military age
annually:
males: 69,030 (1998 est.)
Military expenditures— dollar figure: $25 million
(1993)
Military expenditures— percent of GDP: 2.6%
(1993)
I Transnational issues
Disputes— international: none
Geogr a p h y
Location: Southeastern Asia, bordering the Gulf of
Thailand, between Thailand, Vietnam, and Laos
Geographic coordinates: 13 00 N, 105 00 E
Map references: Southeast Asia
Area:
total: 181,040 sq km
land: 176, 520 sq km
water: 4,520 sq km
Area— comparative: slightly smaller than Oklahoma
Land boundaries:
total: 2,572 km
border countries: Laos 541 km, Thailand 803 km,
Vietnam 1,228 km
Coastline: 443 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy, monsoon season (May to
November); dry season (December to April); little
seasonal temperature variation
Terrain: mostly low, flat plains; mountains in
southwest and north
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Phnum Aoral 1 ,81 0 m
Natural resources: timber, gemstones, some iron
ore, manganese, phosphates, hydropower potential
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 1 1 %
forests and woodland: 66%
other: 10% (1993 est.)
Irrigated land: 920 sq km (1 993 est.)
Natural hazards: monsoonal rains (June to
November); flooding; occasional droughts
Environment— current issues: logging activities
79
Cambodia (continued)
throughout the country and strip mining for gems in
the western region along the border with Thailand are
resulting in habitat loss and declining biodiversity (in
particular, destruction of mangrove swamps threatens
natural fisheries); deforestation; soil erosion; in rural
areas, a majority of the population does not have
access to potable water
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Marine Life Conservation, Ship
Pollution, Tropical Timber 94
signed, but not ratified : Endangered Species, Law of
the Sea, Marine Dumping
Geography— note: a land of paddies and forests
dominated by the Mekong River and Tonle Sap
Railways:
total: 603 km
narrow gauge: 603 km 1 .000-m gauge
Highways:
total: 35,769 km
paved: 4, 165 km
unpaved: 31 ,604 km (1 997 est.)
Waterways: 3,700 km navigable all year to craft
drawing 0.6 m; 282 km navigable to craft drawing 1 .8 m
Ports and harbors: Kampong Saom
(Sihanoukville), Kampot, Krong Kaoh Kong, Phnom
Penh
Merchant marine:
total: 87 ships (1 ,000 GRT or over) totaling 390,566
GRT/556,743 DWT
ships by type: bulk 1 0, cargo 66, container 2, livestock
carrier 2, oil tankers 3, refrigerated cargo 1, roll-on/
roll-off cargo 3
note: a flag of convenience registry; includes ships of
7 countries: Aruba 1 , Cyprus 8, Egypt 1 , South Korea
1 , Malta 1 , Panama 1 , Russia 5 (1 997 est.)
Airports: 20 (1997 est.)
Airports— with paved runways:
total: 7
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 3 (1997 est.)
Airports— with unpaved runways:
total: 13
1,524 to 2,437 m: 3
914 to 1,523 m: 10 (1997 est.)
Heliports: 3 (1997 est.)','8e562894456c8e2e66e992540f0e2833c3bbd894bcf728e563a2e9f6f1a87c66','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('398c944683d3e71a3a15bec3e734c417159803ef2fb2723ee7de1251a304911e',1998,'CN','China','transportation',174,'Railways:
total: 1,104 km
narrow gauge: 1 ,1 04 km 1 .000-m gauge (1 995 est.)
Highways:
total: 34,300 km
paved: 4,288 km
unpaved: 30,012 km (1995 est.)
Waterways: 2,090 km; of decreasing importance
Ports and harbors: Bonaberi, Douala, Garoua,
Kribi, Tiko
Merchant marine:
total: 2 cargo ships (1 ,000 GRT or over) totaling
24,122 GRT/33,509 DWT (1996 est.)
Airports: 52 (1997 est.)
Airports— with paved runways:
total: 1 1
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 41
1,524 to 2,437 m: 8
914 to 1,523 m: 19
under 914 m: 14 (1997 est.)
1 . lilt ary .
Military branches: Army, Navy (includes Naval
Infantry), Air Force, National Gendarmerie,
Presidential Guard
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 3,287,626 (1998 est.)
Military manpower— fit for military service:
males: 1 ,663,852 (1 998 est.)
Military manpower— reaching military age
annually:
males: 160,640 (1998 est.)
Military expenditures— dollar figure: $1 02 million
(FY93/94)
Military expenditures— percent of GDP: NA%
Railways:
total: 23,350 km
broad gauge: 23,350 km 1 .524-m gauge (8,600 km
electrified)
Highways:
total: 172,565 km
paved: 163,937 km (including 1,875 km of
expressways); note— these roads are said to be
hard-surfaced, meaning that some are paved and
some are all-weather gravel surfaced
unpaved: 8,628 km (1996 est.)
Waterways: 4,400 km navigable waterways, of
which 1,672 km were on the PrypMyat'' and Dnistr
(1990)
Pipelines: crude oil 2,010 km; petroleum products
1 ,920 km; natural gas 7,800 km (1992)
Ports and harbors: Berdyans''k, lllichivs''k, Izmayil,
Kerch, Kherson, Kiev (Kyyiv), Mariupol1, Mykolayiv,
Odesa, Reni
Merchant marine:
total: 202 ships (1 ,000 GRT or over) totaling
1,498,653 GRT/1 ,709,393 DWT
ships by type: barge carrier 3, bulk 13, cargo 122,
chemical tanker 2, combination bulk 1 , container 3,
multifunction large-load carrier 2, oil tanker 19,
passenger 7, passenger-cargo 4, railcar carrier 2,
refrigerated cargo 6, roll-on/roll-off cargo 13,
short-sea passenger 5
note: Ukraine owns an additional 41 ships (1 ,000 GRT
or over) totaling 51 5,743 DWT operating under the
registries of The Bahamas, Cyprus, Liberia, Malta,
Panama, and Saint Vincent and the Grenadines (1 997
est.)
Airports: 706 (1994 est.)
Airports— with paved runways:
total: 1 63
over 3,047 m: 14
2,438 to 3,047 m: 55
1,524 to 2,437 m: 34
914 to 1,523 m: 3
under 914 m: 57 (1994 est.)
Airports— with unpaved runways:
total: 543
over 3,047 m: 7
2,438 to 3,047 m: 7
1,524 to 2,437 m: 16
914 to 1,523 m: 37
under 914 m: 476 (1 994 est.)','b3c2841e390e88cbf59780e56585eb91f3f36e64c1079080c921c254656ec98c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('585295a73782807f10228ec4a90c4112a3681a2aab08909c81d41a2c04cef267',1998,'CA','Canada','transportation',182,'Railways:
total: 72,963 km; note— there are two major
transcontinental freight railway systems: Canadian
National (privatized November 1995) and Canadian
Pacific Railway; passenger service provided by
government-operated firm VIA, which has no trackage
of its own
standard gauge: 72,963 km 1.435-m gauge (183 km
electrified) (1996)
Highways:
total: 1 .021 million km
paved: 358,371 km (including 19,000 km of
expressways)
unpaved: 662,629 km (1995 est.)
85
Canada (continued)
Waterways: 3,000 km, including Saint Lawrence
Seaway
Pipelines: crude and refined oil 23,564 km; natural
gas 74,980 km
Ports and harbors: Becancour (Quebec), Churchill,
Halifax, Hamilton, Montreal, New Westminster, Prince
Rupert, Quebec, Saint John (New Brunswick), St.
John''s (Newfoundland), Sept Isles, Sydney,
Trois-Rivieres, Thunder Bay, Toronto, Vancouver,
Windsor
Merchant marine:
total: 57 ships (1 ,000 GRT or over) totaling 638,267
GRT/902,923 DWT
ships by type: bulk 10, cargo 9, chemical tanker 4, oil
tanker 16, passenger 2, passenger-cargo 1 , railcar
carrier 2, roll-on/roll-off cargo 7, short-sea passenger
5, specialized tanker 1
note: does not include ships used exclusively in the
Great Lakes (1997 est.)
Airports: 1,393 (1997 est.)
Airports— with paved runways:
total: 515
over 3,047 m: 17
2,438 to 3,047 m: 16
1,524 to 2,437 m: 149
914 to 1,523 m: 240
under 914 m: 93 (1997 est.)
Airports— with unpaved runways:
total: 878
1,524 to 2,437 m: 73
914 to 1,523 m: 350
under 914 m: 455 (1 997 est.)
Heliports: 17 (1997 est.)
Railways:
total: 584 km (336 km single track; 248 km privately
owned)
standard gauge: 584 km 1 .435-m gauge
Highways:
total: 84,300 km
paved: 33,2 14 km
unpaved: 51,086 km (1996 est.)
Waterways: 7,100 km; Rio Orinoco and Lago de
Maracaibo accept oceangoing vessels
Pipelines: crude oil 6,370 km; petroleum products
480 km; natural gas 4,010 km
Ports and harbors: Amuay, Bajo Grande, El
Tablazo, La Guaira, La Salina, Maracaibo, Matanzas,
Palua, Puerto Cabello, Puerto la Cruz, Puerto Ordaz,
Puerto Sucre, Punta Cardon
Merchant marine:
total: 28 ships (1 ,000 GRT or over) totaling 526,832
GRT/933,135 DWT
ships by type : bulk 4, cargo 5, combination bulk 1 ,
container 1 , liquefied gas tanker 2, oil tanker 9,
passenger-cargo 1, roll-on/roll-off cargo 4, short-sea
passenger 1 (1997 est.)
Airports: 377 (1997 est.)
Airports— with paved runways:
total: 126
over 3,047 m: 5
2,438 to 3,047 m: 10
1,524 to 2,437 m: 35
914 to 1,523 m: 61
under 914 m: 15(1997 est.)
Airports— with unpaved runways:
total: 251
1,524 to 2,437 m: 8
914 to 1,523 m: 96
under 914 m: 147 (1997 est.)','aa9b3a95670533f6d6309300e10ec6f851b247242133b9b9b695c7d5b605db98','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c34439a123c05ea5b5bffac79d27bc60654d0daff5cb305e71d9b08f5115008',1998,'PT','Portugal','transportation',187,'Railways: 0 km
Highways:
total: 1,100 km
paved: 858 km
unpaved : 242 km (1995 est.)
Ports and harbors: Mindelo, Praia, Tarrafal
Merchant marine:
total : 4 (1 ,000 GRT or over) totaling 9,620 GRT/
13,920 DWT
ships by type: cargo 3, chemical tanker 1 (1997 est.)
Airports: 6 (1997 est.)
Airports— with paved runways:
total: 6
over 3,047 m: 1
914 to 1,523 m: 5 (1997 est.)
Railways:
total: 922 km
standard gauge: 922 km 1.435-m gauge (232 km
electrified) (1997)
Highways:
total: 10,591 km
paved: 5,500 km (including 133 km of expressways)
unpaved: 5,091 km (1997 est.)
Waterways: none, lake transport only
Pipelines: 0 km
Ports and harbors: none
Airports: 16 (1997 est.)
Airports— with paved runways:
total : 10
2,438 to 3,047 m: 2
under 914 m: 8 (1997 est.)
Airports— with unpaved runways:
total: 6
914 to 1,523 m: 2
under 914 m: 4 (1 997 est.)
Railways:
total: 883 km
narrow gauge: 883 km 1.000-m gauge (1994)
Highways:
total: 49,837 km
paved: 5,781 km
unpaved: 44,056 km (1 996 est.)
Waterways: of local importance only; isolated
streams and small portions of Canal des Pangalanes
Ports and harbors: Antsiranana,
Antsohimbondrona, Mahajanga, Toamasina, Toliara
Merchant marine:
total : 10 ships (1 ,000 GRT or over) totaling 20,624
GRT/28,621 DWT
ships by type: cargo 4, chemical tanker 1 , liquefied
gas tanker 1 , oil tanker 2, roll-on/roll-off cargo 2 (1 997
est.)
Airports: 136 (1997 est.)
Airports— with paved runways:
total: 30
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 22
under 914 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 106
1,524 to 2,437 m: 4
914 to 1,523 m: 60
under 914 m: 42 (1 997 est.)','0502bf9d0aba44f17e6df3ba9e174178e0e45468017451ba86dadc0a1d9af398','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bafb3db55bbb0771aff0e3b9fb99bbc4ef8daf10c7f9bc3ba4a056265132fd43',1998,'HN','Honduras','transportation',197,'Railways: 0 km
Highways:
total : 406 km
paved: 304 km
unpaved: 102 km
Ports and harbors: Cayman Brae, George Town
Merchant marine:
total: 54 ships (1 ,000 GRT or over) totaling 751 ,113
89
Cayman Islands (continued)
GRT/1.139.958DWT
ships by type: bulk 4, cargo 8, chemical tanker 4,
containers, oil tanker 6, refrigerated cargo 18, roll-on/
roll-off cargo 7, specialized tanker 1 , vehicle carrier 1
note: a flag of convenience registry; includes ships
from 1 0 countries: Greece 1 1 , US 8, UK 5, Cyprus 1 ,
Finland 1 , India 1 , Japan 1 , Norway 1 , Sweden 1 , and
Switzerland 1 (1997 est.)
Airports: 3 (1997 est.)
Airports— with paved runways:
total: 2
1,524 to 2,437 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)
Railways: 0 km
Highways:
total: 23,810 km
paved: 429 km
unpaved: 23,381 km (1995 est.)
Waterways: 800 km; traditional trade carried on by
means of shallow-draft dugouts; Oubangui is the most
important river
Ports and harbors: Bangui, Nola
Airports: 52 (1997 est.)
Airports— with paved runways:
total: 3
2,438 to 3,047m: 1
1,524 to 2,437 m: 2 (1 997 est.)
Airports— with unpaved runways:
total: 49
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 15 (1997 est.)
Railways:
total: 602 km (single track; note— some sections
abandoned, unusable, or operating at reduced
capacity)
narrow gauge: 602 km 0.91 4-m gauge
Highways:
total: 9,977 km
paved: 1 ,985 km (including 266 km of expressways)
unpaved: 7,992 km (1996 est.)
Waterways: Rio Lempa partially navigable
Ports and harbors: Acajutla, Puerto Cutuco, La
Libertad, La Union, Puerto El Triunfo
144
Merchant marine: none
Airports: 88(1 997 est.)
Airports— with paved runways:
total: 4
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2(1997 est.)
Airports— with unpaved runways:
total: 84
914 to 1,523 m: 18
under 914 m: 66(1997 est.)
Heliports: 1 (1997 est.)
Railways:
total: 595 km
narrow gauge: 190 km 1 .067-m gauge; 128 km
1.057-m gauge; 277 km 0.914-m gauge
note: in 1993, there was a total of 988 km of track
Highways:
total: 15,400 km
paved: 3,1 26 km
unpaved: 12,274 km (1996 est.)
Waterways: 465 km navigable by small craft
Ports and harbors: La Ceiba, Puerto Castilla,
Puerto Cortes, San Lorenzo, Tela, Puerto Lempira
Merchant marine:
total: 21 9 ships (1 ,000 GRT or over) totaling 545,829
GRT/801 ,456 DWT
ships by type: bulk 25, cargo 131 , chemical tanker 3,
container 7, liquefied gas tanker 1 , livestock carrier 2,
oil tanker 19, passenger 1 , passenger-cargo 3,
refrigerated cargo 18, roll-on/roll-off cargo 5,
short-sea passenger 3, vehicle carrier 1
note: a flag of convenience registry; Russia owns 7
ships, Vietnam 2, Singapore 2, North Korea 1,
Brazil 1, Japan 1, Iran 1 (1997 est.)
Airports: 122 (1997 est.)
Airports— with paved runways:
total: 12
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 1 1 0
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 20
under 914 m: 87 (1 997 est.)
Railways:
total: 34 km
standard gauge: 34 km 1 .435-m gauge (1 996 est.)
note: also has 43 km of metro with 38 stations
212
Highways:
total: 1 ,760 km
paved: 1 ,760 km
unpaved: 0 km (1 996 est.)
Ports and harbors: Hong Kong
Merchant marine:
total: 1 82 ships (1 ,000 GRT or over) totaling
5,644,279 GRT/9, 287, 704 DWT
ships by type: bulk 1 04, cargo 23, combination bulk 2,
container 42, liquefied gas tanker 1, multifunction
large load carrier 2, oil tanker 2, refrigerated cargo 1 ,
roll-on/roll-off cargo 1 , short-sea passenger 1 , vehicle
carrier 3
note: a flag of convenience registry; includes ships
from 13 countries among which are UK 26, South
Africa 9, China 9, Japan 8, Bermuda 3, Germany 3,
Israel 2, Canada 2, Belgium 1, and Norway 1; Hong
Kong owns an additional 459 ships (1 ,000 GRT or
over) totaling 17,179,262 DWT that operate under the
registries of The Bahamas, Barbados, Belize,
Bermuda, Cyprus, Hong Kong, Liberia, Malta,
Panama, Philippines, Saint Vincent and the
Grenadines, Singapore, and Vanuatu (1997 est.)
Airports: 3 (1998)
Airports— with paved runways:
total: 3
over 3,047 m: 2
1,524 to 2,437 m:1 (1998)
Heliports: 1 (1997 est.)','5ca46336e34176e130e9861c6d1800fb351758ac12f60781841549a40d2533ee','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88753703b4b1e8e2f742dd527605484bf4d883118f3b360652f230a4ef65a7ae',1998,'TD','Chad','transportation',206,'Railways: 0 km
Highways:
total: 32,700 km
paved: 262 km
unpaved: 32,438 km (1995 est.)
Waterways: 2,000 km navigable
Ports and harbors: none
Airports: 53 (1997 est.)
Airports— with paved runways:
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 47
1,524 to 2,437 m: 16
914 to 1,523 m: 21
under 914 m: 10 (1997 est.)','f8e1ef21032fb350b3b0ce9a65e20a60adacdb568c279243250e0b4fb202690f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a949ae368374d2e6fd2098a6aabc868ef76f31446dcb68e6505438087e64c2b2',1998,'CL','Chile','transportation',213,'Railways:
total: 6,782 km
broad gauge: 3,743 km 1 .676-m gauge (1 ,653 km
electrified)
narrow gauge: 1 16 km 1 .067-m gauge; 2,923 km
1.000-m gauge (40 km electrified) (1995)
Highways:
total: 79,800 km
paved: 11,012 km
unpaved: 68,788 km (1996 est.)
Waterways: 725 km
Pipelines: crude oil 755 km; petroleum products 785
km; natural gas 320 km
Ports and harbors: Antofagasta, Arica, Chanaral,
Coquimbo, Iquique, Puerto Montt, Punta Arenas, San
Antonio, San Vicente, Talcahuano, Valparaiso
Merchant marine:
total : 39 ships (1 ,000 GRT or over) totaling 473,173
GRT/770,619 DWT
ships by type: bulk 12, cargo 9, chemical tanker 4,
container 2, liquefied gas tanker 1 , oil tanker 4,
passenger 2, roll-on/roll-off cargo 3, vehicle carrier 2
(1997 est.)
Airports: 380 (1997 est.)
Airports— with paved runways:
total: 52
over 3,047 m: 5
2,438 to 3,047 m: 5
1,524 to 2,437 m: 18
914 to 1,523 m: 18
under 914 m: 6 (1997 est.)
Airports— with unpaved runways:
total: 328
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 15
914 to 1,523 m: 74
under 914 m: 234 (1997 est.)','93091c3eea7a024d057f071d1d1e3167853c7e7a426ec64e7d4e68404705d22a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f21a8f7c4e3ebaa0fc38b41b3dcf14eef8b51317326f36438f08ae6b0f8d6f1',1998,'HK','Hong Kong','transportation',220,'Railways:
total: 64,900 km (including 5,400 km of provincial
"local" rails)
standard gauge: 61 ,300 km 1 .435-m gauge (1 0,400
km electrified; 18,540 km double track)
narrow gauge: 3,600 km 0.750-m gauge local
industrial lines (1998 est.)
Highways:
tofa/:1.18 million km
paved: 241 ,300 km
unpaved: 938,700 km (1998 est.)
Waterways: 1 38,600 km; about 1 1 0,600 km
navigable
Pipelines: crude oil 9,070 km; petroleum products
560 km; natural gas 9,383 km (1998)
Ports and harbors: Dalian, Fuzhou, Guangzhou,
Haikou, Huangpu, Lianyungang, Nanjing, Nantong,
Ningbo, Qingdao, Qinhuangdao, Shanghai, Shantou,
Tianjin, Xiamen, Xingang, Yantai, Zhanjiang
Merchant marine:
total: 1 ,708 ships (1 ,000 GRT or over) totaling
16,139,185 GRT/24, 154, 260 DWT
ships by type: barge carrier 2, bulk 31 3, cargo 858,
chemical tanker 15, combination bulk 10, container
118, liquefied gas tanker 13, multifunction large-load
carrier 5, oil tanker 231 , passenger 6,
passenger-cargo 45, refrigerated cargo 25, roll-on/
roll-off cargo 24, short-sea passenger 43
note: China owns an additional 307 ships (1 ,000 GRT
or over) totaling 1 1 ,648,1 33 DWT operating under the
registries of Cyprus, Hong Kong, Liberia, Malta,
Marshall Islands, Panama, Singapore, Saint Vincent
and the Grenadines, and Vanuatu (1997 est.)
Airports: 206 (1996 est.)
Airports— with paved runways:
total: 192
over 3,047 m: 18
2,438 to 3,047 m: 65
1,524 to 2,437 m: 90
914 to 1,523 m: 13
under 914 m: 6(1996 est.)
Airports— with unpaved runways:
total: 14
1,524 to 2,437 m: 8
914 to 1,523 m: 5
under 914 m: 1 (1996 est.)','0e5d59f677e63ccb6799824645d001751bc7db34f228d9cc78953122f2e4f54e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f9852ce1d602116afb5946955e76147b8fca467f050a2a34392af3a906a7e74',1998,'CX','Christmas Island','transportation',228,'Railways: 24 km to serve phosphate mines
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Flying Fish Cove
Merchant marine: none
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)','56d440c9d8ecb50b9a752777810e18f64c2c5b309b4bdc699b5d1b8387d274c3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d39f2c5c51036629d942685655ca4ed7ec949a0d9ba8b388a10927ccd0b5f6d',1998,'AU','Australia','transportation',234,'Ports and harbors: none; offshore anchorage only
l Transnational Issues
Disputes— international: none
Ports and harbors: none; offshore anchorage only
Railways:
total: 862 meters; note— connects to Italy''s network at
Rome''s Saint Peter''s station
narrow gauge: 862 meters 1 .435-m gauge
Highways: none; all city streets
Ports and harbors: none
Airports: none
Heliports: 1
Ports and harbors: none; offshore anchorage only;
note— there is one boat landing area along the middle
of the west coast
Airports: airstrip constructed in 1937 for scheduled
refueling stop on the round-the-world flight of Amelia
Earhart and Fred Noonan— they left Lae, New
Guinea, for Howland Island, but were never seen
again; the airstrip is no longer serviceable
Transportation— note: Earhart Light is a day
beacon near the middle of the west coast that was
partially destroyed during World War II, but has since
been rebuilt; named in memory of famed aviatrix
Amelia Earhart','a9bff7a7cea812a8e6fec5891322d1a58b8f4eff90d8b80a0b356b46fdac2e1c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f253151973acdbdfa89754d4c92274dfd5374cdc3efe258b5d7f42f7caac001',1998,'CO','Colombia','transportation',241,'Railways:
total: 3,386 km
standard gauge: 150 km 1.435-m gauge (connects
Cerrejon coal mines to maritime port at Bahia Portete)
narrow gauge: 3,236 km 0.91 4-m gauge (1 ,830 km in
use) (1995)
Highways:
total: 107,000 km
paved: 12,733 km
unpaved: 94,267 km (1996 est.)
Waterways: 14,300 km, navigable by river boats
Pipelines: crude oil 3,585 km; petroleum products
1,350 km; natural gas 830 km; natural gas liquids
125 km
Ports and harbors: Barranquilla, Buenaventura,
Cartagena, Leticia, Puerto Bolivar, San Andres, Santa
Marta, Tumaco, Turbo
Merchant marine:
total: 19 ships (1 ,000 GRT or over) totaling 70,775
GRT/94,677 DWT
ships by type: bulk 5, cargo 8, container 1 ,
multi-function large load carrier 2, oil tanker 3 (1997
est.)
Airports: 1,136 (1997 est.)
Airports— with paved runways:
total: 86
over 3,047 m: 2
2,438 to 3,047 m: 10
1,524 to 2,437 m: 36
914 to 1,523 m: 31
under 914 m: 7(1997 est.)
Airports— with unpaved runways:
total: 1,050
2,438 to 3,047 m: 1
1,524 to 2,437 m: 65
914 to 1,523 m: 348
under 914 m: 636 (1997 est.)','ce6181250ef07190ab86350e98b8cffc52cf2043727d50229b4119e1d9759bb9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('072e7a7555908841ab5c1050b7beef7b0cc52a1dd5f5d103dc02740221c5e796',1998,'MZ','Mozambique','transportation',250,'Railways: 0 km
Highways:
total: 880 km
paved: 673 km
unpaved: 207 km (1 996 est.)
Ports and harbors: Fomboni, Moroni, Mutsamudu
Merchant marine: none
Airports: 4 (1997 est.)
Airports— with paved runways:
total:*
2,438 to 3,047 m: 1
914 to 1,523 m:3 (1997 est.)
Pipelines: petroleum products 212 km
Ports and harbors: Binga, Kariba
Airports: 468 (1997 est.)
Airports— with paved runways:
total: 20
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 7,523 m; 10 (1997 est.)
Airports— with unpaved runways:
total: 448
1,524 to 2,437 m: 3
914 to 1,523 m: 221
under 914 m: 224 (1997 est.)
Railways:
total: 4,600 km (498 km electrified); note— 1,108 km
belongs to the Taiwan Railway Administration and the
remaining 3,492 km is dedicated to industrial use
narrow gauge: 4,600 km 1 .067-m
Highways:
total: 19,701 km
paved: 17,238 km (including 447 km of expressways)
unpaved: 2,463 km (1996 est.)
Pipelines: petroleum products 615 km; natural gas
97 km
Ports and harbors: Chi-lung (Keelung), Hua-lien,
Kao-hsiung, Su-ao, T''ai-chung
Merchant marine:
total: 1 93 ships (1 ,000 GRT or over) totaling
5,621,906 GRT/8, 583, 808 DWT
ships by type: bulk 49, cargo 30, combination bulk 2,
container 81 , oil tanker 1 8, refrigerated cargo 1 1 ,
roll-on/roll-off cargo 2 (1997 est.)
Airports: 40 (1997 est.)
Airports— with paved runways:
total: 36
over 3,047 m: 8
2,438 to 3,047 m: 12
1,524 to 2,437 m: 5
914 to 1,523 m: 6
under 914 m: 5 (1997 est.)
Airports— with unpaved runways:
total: 4
1,524 to 2,437 m: 2
under 914 m: 2 (1997 est.)
Heliports: 1 (1 997 est.)','56be521e4ce31e24c467f8410a917545bb077539c1d50d773a4be0980133e242','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34a3354e04d45a869009f31f379a148d0c13dc9ba1e8fcd13e482362c5effc4f',1998,'CG','Congo','transportation',256,'Railways:
total: 5,138 km (1995); note— severely reduced
route-distance in use because of damage to facilities
by civil strife
narrow gauge: 3,987 km 1 .067-m gauge (858 km
electrified); 125 km 1.000-m gauge; 1,026 km
0.600-m gauge
Highways:
total: 145,000 km
paved: 2,500 km
unpaved: 142,500 km (1993 est.)
Waterways: 15,000 km including the Congo, its
tributaries, and unconnected lakes
Pipelines: petroleum products 390 km
Ports and harbors: Banana, Boma, Bukavu,
Bumba, Goma, Kalemie, Kindu, Kinshasa, Kisangani,
Matadi, Mbandaka
Merchant marine: none
Airports: 234 (1997 est.)
Airports— with paved runways:
total: 24
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 15
914 to 1,523 m: 2(1997 est.)
Airports— with unpaved runways:
total: 21 0
1,524 to 2,437 m: 20
914 to 1,523 m: 96
under 914 m: 94 (1997 est.)
Railways:
total : 795 km (includes 285 km private track)
narrow gauge: 795 km 1.067-m gauge (1995 est.)
Highways:
total: 12,800 km
paved: 1,242 km
unpaved: 1 1 ,558 km (1 996 est.)
Waterways: the Congo and Ubangi (Oubangui)
Rivers provide 1 ,1 20 km of commercially navigable
water transport; other rivers are used for local traffic
only
Pipelines: crude oil 25 km
Ports and harbors: Brazzaville, Impfondo, Ouesso,
Oyo, Pointe-Noire
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 2,91 8
GRT/4,100 DWT (1997
Airports: 37 (1997 est.)
Airports— with paved runways:
total: 4
over 3,047 m: 1
1,524 to 2,437 m: 3(1997 est.)
Airports— with unpaved runways:
total: 33
1,524 to 2,437 m: 8
91 4 to 1,523 m: 15
under 914 m: 10 (1997 est.)','9ba7b1b190f305c9680435afc7d6d36738fe682e5cf0ad5518f23dee0efd6f71','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8b0aaee3e02eebfb4f2725b48566b39a36cdf5b3cdf76886a494b912a6e067c',1998,'CK','Cook Islands','transportation',267,'Railways: 0 km
Highways:
total: 187 km
paved: 35 km
unpaved: 152 km (1980 est.)
Ports and harbors: Avarua, Avatiu
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 1 ,464
GRT/2,181 DWT (1997 est.)
Airports: 7 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 3(1997 est.)
Ports and harbors: none; offshore anchorage only;
note— there is one boat landing area in the middle of
the west coast and another near the southwest corner
of the island
Transportation— note: there is a day beacon near
the middle of the west coast','3738d994ea1b7e71f9c15efda3efff33cda63bcbb4e8b61fc434e7fb946d0be3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fe27bc18f63ee037892b084d775a9e14a220e9c756b8f5ab0e9fddb7d42ba99',1998,'DE','Germany','transportation',276,'Railways:
total: 950 km
narrow gauge: 950 km 1 .067-m gauge (260 km
electrified)
note; the entire system was shut down in June 1995
because of insolvency; most of system maintained in
good order to facilitate transfer in 1 997 to private
sector concessionaires
Highways:
total: 35,597 km
paved: 6,051 km
unpaved: 29,546 km (1996 est.)
Waterways: about 730 km, seasonally navigable
Pipelines: petroleum products 176 km
Ports and harbors: Caldera, Golfito, Moin, Puerto
Limon, Puerto Quepos, Puntarenas
Merchant marine: none
Airports: 158 (1997 est.)
Airports— with paved runways:
total: 27
2,438 to 3,047m: 2
1,524 to 2,437 m: 1
914 to 1,523 m : 18
under 91 4 m: 6 (1997 est.)
Airports— with unpaved runways:
total: 131
914 to 1,523 m: 31
under 914 m: 100 (1997 est.)
Railways: 0 km
Highwaysj:
total: 2, 70^ km
paved: 95,6 km
unpaved: 1 ,744 km (1 996 est.)
Waterways: 400 km
Ports and harbors: Banjul
Merchant marine: none
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (1997 est.)
Railways:
total: 43,966 km
standard gauge: 43,531 km 1.435-m; 40,355 km are
owned by Deutsche Bahn AG (DB); 17,015 km of the
DB system are electrified and 16,941 km are double-
or more-tracked
narrow gauge: 389 km 1 .000-m gauge (DB operates
146 km of 1 .000-m gauge); 7 km 0.900-m gauge; 39
km 0.750-m gauge
note: in addition to the DB system there are 54
privately-owned industrial or excursion railways,
ranging in route length from 2 km to 632 km, with a
total length of 3,465 km (1995)
Highways:
total: 633,000 km
paved: 627,303 km (including 1 1 ,300 km of
expressways)
unpaved: 5,697 km all-weather (1996 est.)
Waterways: western— 5,222 km, of which almost 70%
are usable by craft of 1 ,000-metric-ton capacity or larger;
major rivers include the Rhine and Elbe; Kiel Canal is an
important connection between the Baltic Sea and North
Sea; eastern— 2,31 9 km (1988)
Pipelines: crude oil 3,644 km; petroleum products
3,946 km; natural gas 97,564 km (1988)
180
Ports and harbors: Berlin, Bonn, Brake, Bremen,
Bremerhaven, Cologne, Dresden, Duisburg, Emden,
Hamburg, Karlsruhe, Kiel, Lubeck, Magdeburg,
Mannheim, Rostock, Stuttgart
Merchant marine:
total : 515 ships (1 ,000 GRT or over) totaling
6,448,105 GRT/7, 940, 824 DWT
ships by type: cargo 202, chemical tanker 1 0,
combination bulk 2, container 253, liquefied gas
tanker 6, multifunction large-load carrier 6, oil tanker
9, passenger 4, railcar carrier 2, refrigerated cargo 2,
roll-on/roll-off cargo 12, short-sea passenger 7
note: includes ships from the former East Germany and
West Germany; Germany owns 460 additional ships
(1 ,000 GRT or over) that operate under the registries of
Antigua and Barbuda, The Bahamas, Cyprus, Hong
Kong, Liberia, Malta, Norway, Netherlands Antilles,
Panama, Marshall Islands, Singapore, and Saint
Vincent and the Grenadines (1997 est.)
Airports: 620 (1997 est.)
Airports— with paved runways:
total: 321
over 3, 047 m: 14
2,438 to 3,047 m: 61
1,524 to 2,437 m: 70
914 to 1,523 m: 53
under 914 m: 123 (1997 est.)
Airports— with unpaved runways:
total: 299
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 6
914 to 1,523 m: 57
under 914 m: 228 (1 997 est.)
Heliports: 63 (1997 est.)
Railways:
total: 13,841 km in common carrier service; does not
include industrial lines
broad gauge: 13,841 km 1.520-m gauge (3,299 km
electrified) (1992)
Highways:
total: 141 ,076 km
paved: 11 3,566 km
unpaved: 27,510 km (1996 est.)
Waterways: 4,002 km on the Syr Darya and Ertis
Darya
Pipelines: crude oil 2,850 km; refined products
1,500 km; natural gas 3,480 km (1992)
Ports and harbors: Aqtau (Shevchenko), Atyrau
(Gur''yev), Oskemen (Ust-Kamenogorsk), Pavlodar,
Semey (Semipalatinsk)
Airports: 10 (1997 est.)
Airports— with paved runways:
total: 9
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)
Railways:
total: 275 km
standard gauge: 275 km 1.435-m gauge (262 km
electrified; 178 km double track) (1995)
Highways:
total: 5,160 km
paved: 5,1 60 km (including 115 km of expressways)
unpaved: 0 km (1996 est.)
Waterways: 37 km; Moselle
Pipelines: petroleum products 48 km
Ports and harbors: Mertert
Merchant marine:
total: 32 ships (1 ,000 GRT or over) totaling 775,336
GRT/1 ,028,012 DWT
ships by type: bulk 1 , cargo 1 , chemical tanker 1 ,
container 3, liquefied gas tanker 1 1 , oil tanker 5,
passenger 2, roll-on/roll-off cargo 8 (1997 est.)
Airports: 2 (1997 est.)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
under 914 m: 1 (1997 est.)
Railways: 0 km
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (1996 est.)
Ports and harbors: Macau
Merchant marine: none
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (1997 est.)
Railways:
total: 789 km
narrow gauge: 789 km 1.067-m gauge
Highways:
total: 28,400 km
paved: 5,254 km
unpaved: 23,146 km (1996 est.)
Waterways: Lake Nyasa (Lake Malawi); Shire River,
144 km
Ports and harbors: Chipoka, Monkey Bay, Nkhata
Bay, Nkhotakota
Airports: 45 (1997 est.)
Airports— with paved runways:
total: 6
over 3,047 m: 1
1,524 to 2,437 m:\\
914 to 1,523 m: 4(1997 est.)
Airports— with unpaved runways:
total: 39
1,524 to 2,437 m: 1
914 to 1,523 m: 14
under 914 m: 24(1997 est.)
Railways:
total: 1 ,328 km
broad gauge: 1,328 km 1.520-m gauge (1992)
Highways:
total: 12,300 km
paved: 10,738 km
unpaved: 1,562 km (1996 est.)
Waterways: 424 km (1994)
Pipelines: natural gas 310 km (1992)
Ports and harbors: none
Airports: 26 (1994 est.)
Airports— with paved runways:
total: 8
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
under 914 m: 3(1994 est.)
Airports— with unpaved runways:
total: 18
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m:b
under 914 m: 8 (1994 est.)
Railways:
total: 1.7 km
standard gauge: 1 .7 km 1 .435-m gauge
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (1996 est.)
Ports and harbors: Monaco
Merchant marine: none
Airports: linked to airport in Nice, France, by
helicopter service','366f127645c30bf29146d71872a383e0111d33b5d92f57fe100c7dfd790e1734','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6331c49e83ad5d235883d3c35d25689cbf809f238fdcceaae4ff2d3ac4b5a4f8',1998,'SI','Slovenia','transportation',289,'Railways:
total: 1 ,907 km
standard gauge: 1,907 km 1.435-m gauge (769 km
electrified)
note: some lines remain inoperative or not in use;
disrupted by territorial dispute (1997)
Highways:
total: 27,247 km
paved: 22,206 km (including 318 km of expressways)
unpaved: 5,041 km (1996 est.)
Waterways: 785 km perennially navigable; Sava
blocked by downed bridges
Pipelines: crude oil 670 km; petroleum products 20
km; natural gas 310 km (1992); note-under repair
following territorial dispute
Ports and harbors: Dubrovnik, Omisalj, Ploce,
Pula, Rijeka, Sibenik, Split, Zadar
Merchant marine:
total: 72 ships (1,000 GRT or over) totaling 793,1 14
GRT/1 ,187,908 DWT
ships by type: bulk 1 3, cargo 31 , chemical tanker 2,
combination bulk 5, container 5, liquefied gas 1,
multi-function large load carrier 3, oil tanker 2,
passenger 2, roll-on/roll-off cargo 3, short-sea
passenger 5
note: Croatia owns an additional 80 ships (1 ,000 GRT
120
or over) totaling 2,057,523 DWT operating under the
registries of Malta, Liberia, Cyprus, Panama, and
Saint Vincent and the Grenadines (1997 est.)
Airports: 71 (1997 est.)
Airports— with paved runways:
total: 20
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 91 4 m: 7(1997 est.)
Airports— with unpaved runways:
total: 51
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 42 (1997 est.)
Heliports: 2 (1997 est.)','c10b7f2339d8c9a9286420f2d6f692d5ae4380e557afe654b07d9689e3fadf02','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('276c108d8d8b37951792f1e76f8ddeddb79cb7f01ec8806a2af5452a8edaaabf',1998,'CU','Cuba','transportation',297,'Railways:
total: 4,677 km
standard gauge: 4 ,677 km 1.435-m gauge (132 km
electrified)
note: a large amount of track is in private use by sugar
plantations
Highways:
total: 27,700 km
paved: 15,484 km
unpaved: 12,216 km (1996 est.)
Waterways: 240 km
Ports and harbors: Cienfuegos, Havana,
Manzanillo, Mariel, Matanzas, Nuevitas, Santiago de
Merchant marine:
total: 1 7 ships (1 ,000 GRT or over) totaling 91 ,981
GRT/126,416 DWT
ships by type: cargo 9, liquefied gas tanker 1 , oil
tanker 1, refrigerated cargo 6
note: Cuba owns an additional 41 ships (1 ,000 GRT or
over) totaling 463,155 DWT operating under the
registries of Panama, Cyprus, Malta, and Belize (1 997
est.)
Airports: 171 (1997 est.)
Airports— with paved runways:
total: 77
over 3,047 m: 7
2,438 to 3,047 m: 9
1,524 to 2,437 m: 1 4
914 to 1,523 m: 11
under 914 m: 36 (1997 est.)
Airports— with unpaved runways:
total: 94
914 to 1,523 m: 33
under 914 m: 61 (1997 est.)','30233b492aef4e47c3bbb6c5e8856b0d6ad6a481ab315d5651bedfb9adb06e72','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f06a7c03c9152cb8c749ae93a6648c384a7a7b62449a2f8c643926a5500b7db6',1998,'CY','Cyprus','transportation',305,'Railways: 0 km
Highways:
total: Greek Cypriot area: 10,415 km; Turkish Cypriot
area: 2,350 km
paved: Greek Cypriot area: 5,947 km; Turkish Cypriot
area: 1,370 km
unpaved: Greek Cypriot area: 4,468 km (1996 est.);
Turkish Cypriot area: 980 km
Ports and harbors: Famagusta, Kyrenia, Larnaca,
Limassol, Paphos, Vasilikos Bay
Merchant marine:
total: 1 ,533 ships (1 ,000 GRT or over) totaling
23,330,565 GRT/37,272,825 DWT
ships by type: bulk 471 , cargo 568, chemical tanker
23, combination bulk 48, combination ore/oil 12,
container 139, liquefied gas tanker 5, oil tanker 142,
passenger 7, passenger-cargo 1, refrigerated cargo
54, roll-on/roll-off cargo 42, short-sea passenger 16,
specialized tanker 3, vehicle carrier 2
note: a flag of convenience registry; includes ships
from 45 countries among which are Greece 673,
Germany 159, Russia 57, Latvia 28, Netherlands 25,
Japan 24, Cuba 22, China 1 8, Belgium 1 7, and Poland
14; Cyprus owns 78 additional ships (1 ,000 GRT or
over) totaling 2,623,560 DWT that operate under the
registries of Antigua and Barbuda, The Bahamas,
Belize, Cambodia, Cayman Islands, Hong Kong,
Liberia, Malta, Panama, and Philippines (1997 est.)
Airports: 15 (1997 est.)
Airports— with paved runways:
total: 12
2,438 to 3,047 m: 8
914 to 1,523 m: 3
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total : 3
914 to 1,523 m: 1
under 914 m: 2 (1997 est.)
Heliports: 4 (1997 est.)
Railways:
total: 9,440 km
standard gauge: 9,344 km 1 .435-m standard gauge
(2,688 km electrified at three voltages; 1 ,885 km
double track)
narrow gauge: 96 km 0.760-m narrow gauge (1 996)
Highways:
total: 55,489 km
paved: 55,489 km (including 423 km of expressways)
unpaved: 0 km (1996 est.)
Waterways: NA km; the Elbe (Labe) is the principal
river
Pipelines: natural gas 5,400 km
Ports and harbors: Decin, Prague, Usti nad Labem
Merchant marine:
total : 5 ships (1 ,000 GRT or over) totaling 1 10,233
GRT/1 92,998 DWT
ships by type : bulk 3 under Maltese flag, cargo 2
under the Cypriot flag (1997 est.)
Airports: 66 (1997 est.)
Airports— with paved runways:
total: 33
128
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 10
914 to 1,523 m: 1
under 914 m: 13(1997 est.)
Airports— with unpaved runways:
total: 33
914 to 1,523 m: 17
under 914 m: 16 (1997 est.)
Heliports: 1 (1997 est.)','3020a53a9f6a6cd056ed797fdb223790919968509f11c5b45ec4ce87dd2a472c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d471650209b78a86858135b84b842887d3ea9b465a163e77ef218491a378ed9c',1998,'DK','Denmark','transportation',313,'Railways:
total: 3,358 km (510 km privately owned and
operated)
standard gauge: 3,358 km 1.435-m gauge (440 km
electrified; 760 km double track) (1996)
Highways:
total: 71,600 km
paved: 71,600 km (including 880 km of expressways)
unpaved: 0 km (1996 est.)
Waterways: 417 km
Pipelines: crude oil 1 1 0 km; petroleum products 578
km; natural gas 700 km
Ports and harbors: Alborg, Arhus, Copenhagen,
Esbjerg, Fredericia, Grena, Koge, Odense, Struer
Merchant marine:
total: 327 ships (1 ,000 GRT or over) totaling
4,972,331 GRT/6,894,091 DWT
ships by type: bulk 1 4, cargo 1 1 8, chemical tanker 1 6,
container 76, liquefied gas tanker 24, livestock carrier
6, oil tanker 25, railcar carrier 1 , refrigerated cargo 1 4,
roll-on/roll-off cargo 22, short-sea passenger 9,
specialized tanker 2
note: Denmark has created its own internal register,
called the Danish International Ship register (DIS);
DIS ships do not have to meet Danish manning
regulations, and they amount to a flag of convenience
within the Danish register (1997 est.)
Airports: 118 (1997 est.)
Airports— with paved runways:
total: 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 3
914 to 1,523 m: 13
under 914 m: 3(1997 est.)
Airports— with unpaved runways:
total: 90
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 82(1997 est.)
Railways:
total: 97 km (Djibouti segment of the Addis
Ababa-Djibouti railroad)
narrow gauge: 97 km 1 .000-m gauge
note: in April 1998, Djibouti and Ethiopia announced
plans to revitalize the century-old railroad that links
their capitals
Highways:
total: 2,890 km
paved: 364 km
unpaved: 2,526 km (1996 est.)
Ports and harbors: Djibouti
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 1 ,369
GRT/3,030DWT (1997 est.)
Airports: 11 (1997 est.)
Airports— with paved runways:
total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 9
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 2(1997 est.)','0c977ba2e67fa6d4fcf090a77bef72a247d44464b80423b1b5146e3dfb9ba32c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23d2e204b3b057e08d93a7d7bedbddd97494257a8629bb3ce49ba2ca4d733378',1998,'DM','Dominica','transportation',321,'Railways: 0 km
Highways:
total: 780 km
paved: 393 km
unpaved: 387 km (1 996 est.)
Ports and harbors: Portsmouth, Roseau
Merchant marine: none
Airports: 2 (1997 est.)
Airports— with paved runways:
totai: 2
914 to 1,523 m: 1
under 914 m: 1 (1997 est.)
I Military
Military branches: Commonwealth of Dominica
Police Force (includes Special Service Unit, Coast
Guard)
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
1 Transnational Issues
Disputes— international: none
Illicit drugs: transshipment point for narcotics bound
for the US and Europe; minor cannabis producer
Dominican
Republic
Railways:
total: 757 km
standard gauge: 375 km 1.435-m gauge (Central
Romana Railroad)
narrow gauge: 142 km 0.762-m gauge (Dominica
Government Railway); 240 km operated by sugar
companies in various gauges (0.558-m, 0.762-m,
1.067-m gauges) (1995)
Highways:
total: 12,600 km
paved: 6,224 km
unpaved: 6,376 km (1996 est.)
Pipelines: crude oil 96 km; petroleum products 8 km
Ports and harbors: Barahona, La Romana, Puerto
Plata, San Pedro de Macoris, Santo Domingo
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 1 ,587
GRT/1,165 DWT (1997 est.)
Airports: 36 (1997 est.)
Airports— with paved runways:
total: 14
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 3
under 914 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 22
1,524 to 2,437 m: 1
914 to 1,523 m: 6
under 91 4 m: 15 (1997 est.)','bd09df77bda582d6f13e2ddef43cf0ab9058c5500cfa61cf2ec75f155cac3717','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb3a94a300ab63e8d5163eaa1eed68bf812aa54fd723cb884b9bb309d4607b0c',1998,'PE','Peru','transportation',329,'Railways:
total: 965 km (single track)
narrow gauge: 965 km 1.067-m gauge
Highways:
total: 43,249 km
paved: 5,752 km
unpaved: 37,497 km (1996 est.)
Waterways: 1,500 km
Pipelines: crude oil 800 km; petroleum products
1 ,358 km
Ports and harbors: Esmeraldas, Guayaquil, La
Libertad, Manta, Puerto Bolivar, San Lorenzo
Merchant marine:
total: 1 8 ships (1 ,000 GRT or over) totaling 84,423
GRT/1 37,272 DWT
ships by type: liquefied gas tanker 1 , oil tanker 14,
passenger 3 (1997 est.)
Airports: 183 (1997 est.)
Airports— with paved runways:
total: 52
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 10
914 to 1,523 m: 16
under 914 m; 18 (1997 est.)
Airports— with unpaved runways:
total: 131
1,524 to 2,437 m: 3
914 to 1,523 m: 38
under 914 m: 90 (1997 est.)
Heliports: 1 (1997 est.)','f67ef51820d79774f0e4c929faa1f89522027031a2ede8fea80ac754387e536d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65cc3ada47aeed30f9c4bd7d98ffb76e652564d9c3f7f534eb2f651a30c3db18',1998,'SD','Sudan','transportation',338,'Railways:
total: 4,751 km
standard gauge: 4,751 km 1,435-m gauge (42 km
electrified; 951 km double track)
Highways:
total: 64,000 km
paved: 49,984 km
unpaved: 14,016 km (1996 est.)
Waterways: 3,500 km (including the Nile, Lake
Nasser, Alexandria-Cairo Waterway, and numerous
smaller canals in the delta); Suez Canal, 193.5 km
long (including approaches), used by oceangoing
vessels drawing up to 16.1 m of water
Pipelines: crude oil 1,171 km; petroleum products
596 km; natural gas 460 km
Ports and harbors: Alexandria, Al Ghardaqah,
Aswan, Asyut, Bur Safajah, Damietta, Marsa Matruh,
Port Said, Suez
Merchant marine:
total: 1 61 ships (1 ,000 GRT or over) totaling
1,225,989 GRT/1 ,899,81 8 DWT
ships by type: bulk 24, cargo 60, liquefied gas tanker
1, oil tanker 15, passenger 42, refrigerated cargo 1,
roll-on/roll-off cargo 15, short-sea passenger 3 (1997
est.)
Airports: 89 (1997 est.)
Airports— with paved runways:
total: 70
over 3,047 m: 11
2,438 to 3,047 m: 39
1,524 to 2,437 m: 15
914 to 1,523 m: 2
under 914 m: 3(1997 est.)
Airports— with unpaved runways:
total: 19
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 6
under 914 m: 9 (1997 est.)
Heliports: 2 (1997 est.)','9a2f4fd4745a452b1e796cec3f2d75bf157e3e2d8ef7c44e0e860bf5407a3304','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d35e65b935593b9784e59d3f6e115604b7801e780a561b499baf926229dd0b9f',1998,'GN','Guinea','transportation',350,'Railways:
total: 0 km
Highways:
total: 2,820 km
paved: 0 km
unpaved: 2,820 km (1995 est.)
Ports and harbors: Bata, Luba, Malabo
146
Merchant marine:
total: 19 ships (1 ,000 GRT or over) totaling 66,766
GRT/84,780 DWT
ships by type: bulk 1 , cargo 1 6, passenger 1 ,
passenger-cargo 1 (1997 est.)
Airports: 3 (1997 est.)
Airports— with paved runways:
total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
under 914 m: 1 (1997 est.)
Railways:
total: 307 km
narrow gauge: 307 km 0.950-m gauge (1995 est.)
note: nonoperational since 1 978 except for about a 5
km stretch that was reopened in Massawa in 1994;
rehabilitation of the remainder and of the rolling stock
is under way; links Ak''ordat and Asmara (formerly
Asmera) with the port of Massawa (formerly Mits''iwa)
Highways:
total: 4, 01 0 km
paved: 874 km
unpaved: 3,136 km (1996 est.)
Ports and harbors: Assab (Aseb), Massawa
(Mits''iwa)
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 5,51 6 GRT/
5,747 DWT
ships by type : oil tanker 1 , roll-on/roll-off cargo 1
(1997 est.)
Airports: 20 (1997 est.)
Airports— with paved runways:
total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 18
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 6
under 914 m: 3 (1997 est.)','e99035f58d5ca71d80506db5d30e6261d19f269191a98a025287d5e01a85fd8f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e9d64da06ae9666e8fecc313b986e9cff73caa890afc8585b1717eec9043260',1998,'EE','Estonia','transportation',360,'Railways:
total: 1 ,018 km common carrier lines only; does not
include dedicated industrial lines
broad gauge: 1 ,01 8 km 1 .520-m gauge (1 32 km
electrified) (1995)
Highways:
total: 15,304 km
paved: 8,142 km (including 65 km of expressways)
unpaved: 7,162 km (1996 est.)
Waterways: 500 km perennially navigable
Pipelines: natural gas 420 km (1992)
Ports and harbors: Haapsalu, Narva, Paldiski,
Parnu, Tallinn
Merchant marine:
total: 53 ships (1 ,000 GRT or over) totaling 368,340
GRT/455,696 DWT
ships by type: bulk 6, cargo 27, combination bulk 1 ,
container 5, oil tanker 2, roll-on/roll-off cargo 7,
short-sea passenger 5 (1997 est.)
Airports: 5 (1997 est.)
Airports— with paved runways:
total: 5
over 3,047 m: 1
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (1 997 est.)
I Military
Military branches: Ground Forces, Navy/Coast
Guard, Air and Air Defense Force (not officially
sanctioned), Maritime Border Guard, Volunteer
Defense League (Kaitseliit), Security Forces (internal
and border troops)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 351 ,148 (1 998 est.)
Military manpower— fit for military service:
males: 275,61 0(1 998 est.)
Military manpower— reaching military age
annually:
males: 10,424 (1998 est.)
Military expenditures— dollar figure: $35 million
(1995)
Military expenditures— percent of GDP: 1 .5%
(1995)
Transnationa Tissues
Disputes— international: Estonian and Russian
negotiators reached a technical border agreement in
December 1996 which has not been ratified; Estonia
claimed over 2,000 sq km territory in the Narva and
Pechory regions of Russia— based on boundary
established under the 1920 Peace Treaty of Tartu
Illicit drugs: transshipment point for opiates and
cannabis from Southwest Asia and the Caucasus, and
cocaine from Latin America to Western Europe and
Scandinavia
151
Ethiopia pW
Railways:
total: 681 km (Ethiopian segment of the Addis
Ababa-Djibouti railroad)
narrow gauge: 681 km 1.000-m gauge
note: in April 1998, Djibouti and Ethiopia announced
plans to revitalize the century-old railroad that links
their capitals
Highways:
total: 28,500 km
paved: 4,275 km
unpaved: 24,225 km (1996 est.)
Ports and harbors: none; Ethiopia is landlocked but
by agreement with Eritrea may use the ports of Assab
and Massawa
Merchant marine:
total: 1 3 ships (1 ,000 GRT or over) totaling 73,775
GRT/98,279 DWT
ships by type: cargo 8, oil tanker 2, roll-on/roll-off
cargo 3 (1997 est.)
Airports: 86 (1997 est.)
Airports— with paved runways:
total: 10
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 76
over 3,047 m: 3
2,438 to 3,047 m: 7
1,524 to 2,437 m: 10
914 to 1,523 m: 36
under 914 m: 20(1997 est.)
Ports and harbors: none; offshore anchorage only
Airports: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)','8b386ddc3b4818ca74a5b34af95ccf8b4925c55ddc59df54eb1646aa6b98bf8d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5b6bafb4887a74ca6aa2a5f0f8f81efeccb61873731578256193f52d18026ac',1998,'FO','Faroe Islands','transportation',369,'Railways: 0 km
Highways:
total: 458 km
paved: 450 km
unpaved: 8 km (1995 est.)
Ports and harbors: Torshavn, Klaksvik, Tvoroyri,
Runavik, Fuglafjorour
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 22,853
GRT/1 3,481 DWT
ships by type: cargo 2, oil tanker 1 , refrigerated cargo
1 , roll-on/roll-off cargo 1 , short-sea passenger 1 (1 997
est.)
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)
Mil i t a r y
Military branches: no organized native military
forces; only a small Police Force and Coast Guard are
maintained
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Military— note: defense is the responsibility of','609f51e4be9f74ba266ac32a7a83338fb91e1b7e17b3243c2e3463b8aa43ad32','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6885196155a500976d2cfb3c4a5f782254df18e4ec3c9bcdc54d45928c1967d',1998,'JE','Jersey','transportation',377,'Railways:
total: 597 km; note— belongs to the
government-owned Fiji Sugar Corporation
narrow gauge: 597 km 0.61 0-m gauge (1995)
Highways:
total: 3,440 km
paved: 1 ,692 km
unpaved: 1 ,748 km (1996 est.)
Waterways: 203 km; 1 22 km navigable by motorized
craft and 200-metric-ton barges
Ports and harbors: Labasa, Lautoka, Levuka,
Savusavu, Suva
Merchant marine:
total: 6 ships (1,000 GRT or over) totaling 17,800
GRT/1 8,034 DWT
ships by type: chemical tanker 2, oil tanker 1 ,
passenger 1 , roll-on/roll-off cargo 2 (1997 est.)
Airports: 24 (1997 est.)
Airports— with paved runways:
total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 21
914 to 1,523 m: 4
under 914 m: 17(1997 est.)
Railways:
total: 610 km
standard gauge: 610 km 1.435-m gauge (1996)
Highways:
total: 15,065 km
paved: 15,065 km (including 56 km of expressways)
unpaved: 0 km (1996)
Pipelines: crude oil 708 km; petroleum products 290
km; natural gas 89 km
Ports and harbors: Ashdod, Ashqelon, Elat (Eilat),
Hadera, Haifa, Tel Aviv-Yafo
Merchant marine:
total: 27 ships (1 ,000 GRT or over) totaling 803,383
GRT/947,678 DWT
ships by type: cargo 2, container 24, roll-on/roll-off
cargo 1 (1997 est.)
Airports: 54 (1997 est.)
Airports— with paved runways:
total: 31
over 3, 047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437m: 8
914 to 1,523 m: 9
under 914 m: 7 (1997 est.)
Airports— with unpaved runways:
total: 23
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 18 (1997 est.)
Heliports: 2 (1997 est.)
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Gorey, Saint Aubin, Saint Helier
Merchant marine: none
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m:\\ (1997 est.)
Ports and harbors: Johnston Island
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
2,438 to 3,047 m: 1 (1997 est.)
Railways: 0 km
Highways:
total: 4,450 km
paved: 3,587 km
unpaved: 863 km (1 996 est.)
Pipelines: crude oil 877 km; petroleum products
40 km; natural gas 165 km
Ports and harbors: Ash Shu''aybah, Ash Shuwaykh,
Kuwait, Mina'' ''Abd Allah, Mina1 al Ahmadi, Mina1 Su''ud
Merchant marine:
total: 42 ships (1 ,000 GRT or over) totaling 1 ,965,633
GRT/3, 109,720 DWT
ships by type: cargo 1 0, container 3, liquefied gas
tanker 7, livestock carrier 3, oil tanker 19 (1997 est.)
Airports: 8 (1997 est.)
Airports— with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047 m: 2 (1997 est.)
Airports— with unpaved runways:
total : 4
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 2 (1997 est.)
Heliports: 1 (1997 est.)
Railways: 0 km
Highways:
total: 5,562 km
paved: 975 km
unpaved: 4,587 km (1993)
Ports and harbors: Mueo, Noumea, Thio
Merchant marine: none
Airports: 30 (1997 est.)
Airports— with paved runways:
total: 5
over 3,047 m: 1
914 to 1,523 m: 3
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 25
914 to 1,523 m: 13
under 91 4 m: 12 (1997 est.)
Heliports: 7 (1997 est.)
Railways:
total: 1,201 km
standard gauge: 1 ,201 km 1 .435-m gauge (electrified
499 km) (1994)
Highways:
total: 14,910 km
paved: 12,226 km (including 231 km of expressways)
unpaved: 2,684 km (1996 est.)
Waterways: NA
Pipelines: crude oil 290 km; natural gas 305 km
Ports and harbors: Izola, Koper, Piran
Merchant marine:
total : 1 3 ships (1 ,000 GRT or over) totaling 223,976
GRT/373,462 DWT (controlled by Slovenian owners)
ships by type: bulk 8, cargo 5
note: ships operate under the flags of Antigua and
Barbuda, Liberia, Saint Vincent and the Grenadines,
and Singapore; no ships remain under the Slovenian
flag (1997 est.)
Airports: 14 (1997 est.)
Airports— with paved runways:
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 91 4 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 4(1 997 est.)
Railways:
total: 297 km; note— includes 71 km which are not in
use
narrow gauge: 297 km 1 .067-m gauge
Highways:
total: 2,885 km
paved: 81 4 km
unpaved: 2,071 km (1994 est.)
Ports and harbors: none
Airports: 18 (1997 est.)
Airports— with paved runways:
total: 1
2,438 to 3,047 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 17
914 to 1,523 m:7
under 914 m: 10(1997 est.)
446
f Military
Military branches: Umbutfo Swaziland Defense
Force (Army), Royal Swaziland Police Force
Military manpower— availability:
males age 15-49: 215,708 (1 998 est.)
Military manpower— fit for military service:
males: 125,580 (1998 est.)
Military expenditures— dollar figure: $22 million
(FY93/94)
Military expenditures— percent of GDP: NA%
Railways:
total: 1 1 ,837 km (includes 1 ,955 km of
privately-owned railways)
standard gauge: 1 1 ,837 km 1 .435-m gauge (7,31 7 km
electrified and 1 ,152 km double track) (1996)
Highways:
total: 138,000 km
paved: 105,018 km (including 1 ,330 km of
expressways)
unpaved: 32,982 km (1996 est.)
Waterways: 2,052 km navigable for small steamers
and barges
Pipelines: natural gas 84 km
Ports and harbors: Gavle, Goteborg, Halmstad,
Helsingborg, Hudiksvall, Kalmar, Karlshamn, Malmo,
Solvesborg, Stockholm, Sundsvall
Merchant marine:
total: 1 64 ships (1 ,000 GRT or over) totaling
2,036,831 GRT/1 ,91 9,367 DWT
ships by type: bulk 7, cargo 33, chemical tanker 27,
combination ore/oil 1 , liquefied gas tanker 1 , oil tanker
29, railcar carrier 1 , refrigerated cargo 1 , roll-on/roll-off
cargo 41 , short-sea passenger 7, specialized tanker
4, vehicle carrier 12 (1997 est.)
Airports: 255 (1997 est.)
Airports— with paved runways:
total : 145
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 83
914 to 1,523 m: 27
under 914 m: 24 (1997 est.)
Airports— with unpaved runways:
total: 110
914 to 1,523 m: 5
under 914 m:105 (1997 est.)
Heliports: 1 (1997 est.)','0de69f62b10f335678405f7b76c7cda4d526febfb05937caaa8aa19df9aa56f0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a86ffe20c20126f53c47521b851db88c352e5221fe83fb80acd8f86a1adf02fc',1998,'FI','Finland','transportation',385,'Railways:
total: 5,859 km
broad gauge: 5,859 km 1 .524-m gauge (2,073 km
electrified; 480 km double- or more-track) (1996)
Highways:
total : 77,782 km
paved: 49,780 km (including 431 km of expressways)
unpaved: 28,002 km (1996 est.)
Waterways: 6,675 km total (including Saimaa
Canal); 3,700 km suitable for steamers
Pipelines: natural gas 580 km
Railways:
total: 2,412 km
broad gauge: 2,379 km 1.520-m gauge (271 km
electrified) (1992)
narrow gauge: 33 km 0.750-m gauge (1994)
Highways:
total: 60,046 km
paved: 22,998 km
unpaved: 37,048 km (1995 est.)
Waterways: 300 km perennially navigable
Pipelines: crude oil 750 km; refined products
780 km; natural gas 560 km (1992)
Ports and harbors: Daugavpils, Liepaja, Riga,
Ventspils
Merchant marine:
total : 24 ships (1 ,000 GRT or over) totaling 293,799
GRT/440,575 DWT
ships by type: cargo 2, oil tanker 1 8, refrigerated
cargo 4 (1997 est.)
Airports: 50 (1994 est.)
Airports— with paved runways:
total: 36
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 27 (1994 est.)
Airports— with unpaved runways:
total: 14
2,438 to 3,047 m: 2
914 to 1,523 m: 2
under 914 m: 10(1994 est.)
Railways:
total: 222 km
standard gauge: 222 km 1 .435-m (from Beirut to the
Syrian border)
Highways:
total: 6,350 km
paved: 6,032 km
unpaved: 318 km (1996 est.)
Pipelines: crude oil 72 km (none in operation)
Ports and harbors: Al Batrun, Al Mina'', An Naqurah,
Antilyas, Az Zahrani, Beirut, Jubayl, Juniyah, Shikka,
Sidon, Tripoli, Tyre
Merchant marine:
total: 62 ships (1 ,000 GRT or over) totaling 258,383
GRT/392,087 DWT
ships by type: bulk 5, cargo 40, chemical tanker 1 ,
combination bulk 1 , combination ore/oil 1 , container 2,
livestock carrier 5, oil tanker 1 , roll-on/roll-off cargo 2,
specialized tanker 1, vehicle carrier 3 (1997 est.)
Airports: 9 (1997 est.)
Airports— with paved runways:
total: 7
over 3,047 m:1
2,438 to 3,047m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m:] (1997 est.)
Airports— with unpaved runways:
total: 2
914 to 1,523 m: 1
under 914m:1 (1997 est.)','43311ab273eef3582a30f4a2bd1bb74e277572c248e9129dc7bcbdc70f8c4112','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0d60ec0999c4ac645b1a894fa171e4d8bcfe7e44a32699e393c7aa9b86cf4e9',1998,'WF','Wallis and Futuna','transportation',389,'Railways:
total: 32,027 km
standard gauge: 31 ,928 km 1 .435-m gauge; 31 ,940
km are operated by French National Railways
(SNCF); 1 3,805 km of SNCF routes are electrified and
12,132 km are double- or multiple-tracked
narrow gauge: 99 km 1.000-m gauge
note: does not include 33 tourist railroads, totaling 469
km, many being of very narrow gauge (1996)
Highways:
total: 892,500 km
paved: 892,500 km (including 9,500 km of
expressways)
unpaved: 0 km (1996 est.)
Waterways: 14,932 km; 6,969 km heavily traveled
Pipelines: crude oil 3,059 km; petroleum products
4,487 km; natural gas 24,746 km
Ports and harbors: Bordeaux, Boulogne,
Cherbourg, Dijon, Dunkerque, La Pallice, Le Havre,
Lyon, Marseille, Mullhouse, Nantes, Paris, Rouen,
Saint Nazaire, Saint Malo, Strasbourg
Merchant marine:
total: 62 ships (1 ,000 GRT or over) totaling 1 ,528,1 07
GRT/2,354,235 DWT
ships by type: bulk 5, cargo 5, chemical tanker 8,
combination bulk 1, container 6, liquefied gas tanker
164
4, multi-function large load carrier 1, oil tanker 18,
passenger 2, roll-on/roll-off cargo 5, short-sea
passenger 6, specialized tanker 1
note: France also maintains a captive register for
French-owned ships in lies Kerguelen (French
Southern and Antarctic Lands) (1997 est.)
Airports: 473 (1997 est.)
Airports— with paved runways:
total: 266
over 3,047 m: 13
2,438 to 3,047m: 29
1,524 to 2,437 m: 95
914 to 1,523 m: 73
under 914 m: 56 (1997 est.)
Airports— with unpaved runways:
total: 207
1,524 to 2,437 m: 3
914 to 1,523 m: 75
under 914 m: 1 29 (1 997 est.)
Heliports: 3 (1997 est.)','7c466c7871f10676487da1afac253ca607ebad50e823a34b8a15c96029951a6d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('826f0dded575a584cac4a943ff16c5108eb8bf032855df994612a1059b260a70',1998,'PF','French Polynesia','transportation',400,'Railways: 0 km
Highways:
total: 792 km
paved: 792 km (1995 est.)
Ports and harbors: Mataura, Papeete, Rikitea,
Uturoa
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 4,127 GRT/
6,710 DWT
ships by type: passenger-cargo 2, refrigerated cargo
1 (1997 est.)
Airports: 43 (1997 est.)
Airports— with paved runways:
total: 25
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 14
under 914 m: 4 (1 997 est.)
Airports— with unpaved runways:
total: 18
914 to 1,523 m: 7
under 914 m: 1 1 (1 997 est.)','6ff8ca417363257bdec177924d75c899f24fe54a38ac48826dce50e57577220e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6aeb3bcbd19997dcecc03aa29cc6810350bf07cb36667cacf2a2fa5963d33e4',1998,'GA','Gabon','transportation',406,'Ports and harbors: none; offshore anchorage only
Merchant marine:
total: 61 ships (1 ,000 GRT or over) totaling 2,164,686
GRT/3, 805,91 3 DWT
Railways:
total: 649 km Gabon State Railways (OCTRA)
standard gauge: 649 km 1 .435-m gauge; single track
(1994)
Highways:
total: 7 ,670 km
paved: 629 km (including 30 km of expressways)
unpaved: 7,041 km (1996 est.)
Waterways: 1 ,600 km perennially navigable
Pipelines: crude oil 270 km; petroleum products
14 km
Ports and harbors: Cape Lopez, Kango,
Lambarene, Libreville, Mayumba, Owendo,
Port-Gentil
Merchant marine:
total: 3 bulk (1 ,000 GRT or over) totaling 37,003 GRT /
60,663 DWT (1997 est.)
Airports: 64 (1997 est.)
Airports— with paved runways:
total: 10
over 3,047 m: 1
2,438 to 3,047m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 54
1,524 to 2,437 m: 1 0
914 to 1,523 m: 18
under 91 4 m: 26 (1997 est.)','4540d5f3735e970343ab55ba82c8c2421323964ebaf9251286da649cc006be29','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae623c85e35db473b1f940a62a64ef0c63e01eb504db78db12e627e838981337',1998,'GE','Georgia','transportation',416,'Railways:
total: 1 ,583 km in common carrier service; does not
include industrial lines
broad gauge: 1 ,583 km 1 .520-m gauge (1 993)
Highways:
total: 20,700 km
paved: 19,354 km
unpaved: 1 ,346 km (1996 est.)
Pipelines: crude oil 370 km; refined products 300
km; natural gas 440 km (1992)
Ports and harbors: Bat''umi, P''ot''i, Sokhumi
Merchant marine:
total: 9 ships (1 ,000 GRT or over) totaling 87,730
GRT/1 22,769 DWT
ships by type: cargo 3, oil tanker 5, short-sea
passenger 1 (1997 est.)
Airports: 28 (1994 est.)
Airports— with paved runways:
total: 14
over 3,047 m: 1
2,438 to 3,047m: 7
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m:! (1994 est.)
Airports— with unpaved runways:
total : 14
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 5
under 91 4 m: 6(1994 est.)
Transportation— note: transportation network is in
poor condition and disrupted by ethnic conflict,
criminal activities, and fuel shortages; network lacks
maintenance and repair','623db4edb5b5972540360bd6360d6b5f4524de100bd18b8a835e2f2d3540d4a7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e534818ead1b84cbf5ded062dd30e4f2288af46a1f998d5e79e65f3333b83b6',1998,'NL','Netherlands','transportation',427,'Railways:
total: 953 km (undergoing major rehabilitation)
narrow gauge: 953 km 1 .067-m gauge (32 km double
track) (1997 est.)
Highways:
total: 39,409 km
paved: 1 1 ,653 km (including 30 km of expressways)
unpaved: 27,756 km (1997 est.)
Waterways: Volta, Ankobra, and Tano Rivers
provide 168 km of perennial navigation for launches
and lighters; Lake Volta provides 1 ,125 km of arterial
and feeder waterways
Pipelines: 0 km
Ports and harbors: Takoradi, Tema
Merchant marine:
total: 4 ships (1,000 GRT or over) totaling 17,037
GRT/22,747 DWT
ships by type: cargo 1 , oil tanker 1 , refrigerated cargo
2(1997 est.)
Airports: 12 (1997 est.)
182
Airports— with paved runways:
total: 6
2,438 to 3,047 m:1
1,524 to 2,437 m: 3
914 to 1,523 m: 2(1997 est.)
Airports— with unpaved runways:
total: 6
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 2 (1997 est.)
Railways:
total: 2,739 km
standard gauge: 2,739 km 1 .435-m gauge; (1 ,991 km
electrified) (1996)
Highways:
total: 127,000 km
paved: 1 14,427 km (including 2,360 km of
expressways)
unpaved: 12,573 km (1996 est.)
Waterways: 6,340 km, of which 35% is usable by
craft of 1 ,000 metric ton capacity or larger
Pipelines: crude oil 41 8 km; petroleum products 965
km; natural gas 10,230 km
Ports and harbors: Amsterdam, Delfzijl, Dordrecht,
Eemshaven, Groningen, Haarlem, Ijmuiden,
Maastricht, Rotterdam, Terneuzen, Utrecht
Merchant marine:
total: 453 ships (1 ,000 GRT or over) totaling
3,141,630 GRT/3, 597, 975 DWT
ships by type: bulk 2, cargo 269, chemical tanker 33,
combination bulk 2, container 44, liquefied gas tanker
16, livestock carrier 1, multifunction large-load carrier
7, oil tanker 28, passenger 6, refrigerated cargo 28,
roll-on/roll-off cargo 1 1 , short-sea passenger 3,
specialized tanker 3
note: many Dutch-owned ships are also operating
under the registry of Netherlands Antilles (1997 est.)
Airports: 28 (1997 est.)
Airports— with paved runways:
total: 19
over 3,047 m: 2
2,438 to 3,047m: 8
1,524 to 2,437 m: 5
914 to 1,523 m: 3
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 9
914 to 1,523 m: 3
under 914 m: 6 (1997 est.)
Heliports: 1 (1997 est.)
Railways: 0 km
Highways:
total: 600 km
paved: 300 km
unpaved: 300 km (1992 est.)
Ports and harbors: Kralendijk, Philipsburg,
Willemstad
Merchant marine:
total: 97 ships (1 ,000 GRT or over) totaling 894,479
GRT/1 ,230,865 DWT
ships by type: bulk 4, cargo 32, chemical tanker 1 ,
container 5, liquefied gas tanker 4, multifunction
large-load carrier 19, oil tanker 6, passenger 1 ,
refrigerated cargo 17, roll-on/roll-off cargo 8
note: a flag of convenience registry; includes ships of
2 countries: Belgium owns 9 ships, Germany 1 (1997
est.)
Airports: 5 (1997 est.)
Airports— with paved runways:
total: 5
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m;1
under 914 m: 1 (1997 est.)','61da062943e37159392c4c428143c3db2ef1acf3d3431570fa5e44b3f717f2cd','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cd21a83279d204d5f39057be50a1c0a56d51094c9745f357df73d0e5da8ccea',1998,'ES','Spain','transportation',434,'Railways:
total: NA km; 1 .000-m gauge system in dockyard area
only
Highways:
total: 49.9 km (including 12.9 km public highways)
paved: 49.9 km
unpaved: 0 km
Pipelines: 0 km
Ports and harbors: Gibraltar
Merchant marine:
total: 1 8 ships (1 ,000 GRT or over) totaling 360,880
GRT/627,429 DWT
ships by type: bulk 1 , cargo 1 , chemical tanker 2,
container 1 , oil tanker 1 2, roll-on/roll-off cargo 1 (1 997
est.)
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)
Ports and harbors: none; offshore anchorage only
Airports: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)','eaeaa26c28c2eed97761e5ee59191ab1382dc14933d8d8a8ea00e25ef345a62f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('291df6b8412af36d81322b73192a723066e1c2ae0489430784e8e1e505fe739b',1998,'GD','Grenada','transportation',443,'Railways: 0 km
Highways:
total: 1 ,040 km
paved: 638 km
unpaved: 402 km (1996 est.)
Ports and harbors: Grenville, Saint George''s
Merchant marine: none
Airports: 3 (1997 est.)
Airports— with paved runways:
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
under 914 m: 1 (1997 est.)','a46929d44787755c0459c763db79e71497dfe8ae317f81373da89090657c3d62','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b588b61675e8b176ac20135c066b7f0ff8ad59f751c6a8cb139bc4be43661f0c',1998,'GU','Guam','transportation',451,'Railways: 0 km
Highways:
total: 885 km
paved: 675 km
unpaved: 210 km
note: there is another 685 km of roads classified
non-public, including roads located on federal
government installations
Ports and harbors: Apra Harbor
Merchant marine: none
Airports: 5 (1997 est.)
Airports— with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
under 914 m: 1 (1997 est.)
Railways:
total: 884 km (1 02 km privately owned)
narrow gauge: 884 km 0.91 4-m gauge (single track)
Highways:
total: 13,100 km
paved: 3,616 km (including 140 km of expressways)
unpaved: 9,484 km (1996 est.)
Waterways: 260 km navigable year round; additional
730 km navigable during high-water season
Pipelines: crude oil 275 km
Ports and harbors: Champerico, Puerto Barrios,
Puerto Quetzal, San Jose, Santo Tomas de Castilla
Merchant marine: none
Airports: 479 (1997 est.)
Airports— with paved runways:
total : 12
over 3,047 m: 1
2,438 to 3,047 m : 1
1,524 to 2,437 m: 2
914 to 1,523 m: 6
under 914 m: 2(1997 est.)
Airports— with unpaved runways:
total: 467
2,438 to 3,047m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 124
under 914 m: 333 (1 997 est.)','da7eb9e5e137f4b01cb678d63104b09060102108efbc43dfe88c0ae42ae02795','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52cca4d9dccfa9ec0400abc2fcc5c215be3bc20097b2765b363051029f9b4f5f',1998,'GG','Guernsey','transportation',461,'Railways:
total: 1,086 km
standard gauge: 279 km 1 .435-m gauge
narrow gauge: 807 km 1 .000-m gauge (includes 662
km in common carrier service from Kankan to
Conakry)
Highways:
total: 30,500 km
paved: 5,033 km
unpaved: 25 ,467 km (1996 est.)
Waterways: 1 ,295 km navigable by shallow-draft
native craft
Ports and harbors: Boke, Conakry, Kamsar
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 4,722
GRT/6,226 DWT (1997 est.)
Airports: 15 (1997 est.)
Airports— with paved runways:
total: 5
over 3,047m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3(1997 est.)
Airports— with unpaved runways:
total: 10
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m: 1 (1997 est.)','6c07521eeefa72a4a3e6c0f65b2605d4591d77d3eb395712b9c2073f8c561c7e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a1e9d917d2e8b32a40d7a9dd52e81897727b50dfd991dc2987b06bc3b3a9aa8',1998,'GY','Guyana','transportation',472,'Railways:
total: 88 km
standard gauge: 40 km 1 .435-m gauge (dedicated to
ore transport)
narrow gauge: 48 km 0.914-m gauge (dedicated to
ore transport)
Highways:
total: 7, 970 km
paved: 590 km
unpaved: 7,380 km (1996 est.)
Waterways: 6,000 km total of navigable waterways;
Berbice, Demerara, and Essequibo Rivers are
navigable by oceangoing vessels for 150 km, 1 00 km,
and 80 km, respectively
Ports and harbors: Bartica, Georgetown, Linden,
New Amsterdam, Parika
Merchant marine:
total: 2 cargo ship (1 ,000 GRT or over) totaling 2,340
GRT/4,530 DWT (1997 est.)
Airports: 50 (1997 est.)
Airports— with paved runways:
total: 5
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m:1 (1997 est.)
Airports— with unpaved runways:
total: 45
1,524 to 2,437 m: 1
914 to 1,523 m: 10
under 914 m: 34 (1997 est.)
Railways:
total: 40 km (single track; privately owned industrial
line)— closed in early 1990s
narrow gauge: 40 km 0.760-m gauge
Highways:
total: 4,160 km
pavecf; 1,011 km
unpaved: 3,1 49 km (1 996 est.)
Waterways: NEGL; less than 100 km navigable
Ports and harbors: Cap-Haitien, Gonaives, Jacmel,
Jeremie, Les Cayes, Miragoane, Port-au-Prince,
Port-de-Paix, Saint-Marc
Merchant marine: none
Airports: 14 (1997 est.)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 1 1
914 to 1,523 m: 5
under 914 m: 6(1997 est.)
Ports and harbors: none; offshore anchorage only
Railways:
total: 166 km (single track)
standard gauge: 80 km 1.435-m gauge
narrow gauge: 86 km 1 .000-m gauge
Highways:
total: 4,530 km
paved: 1,178 km
unpaved: 3,352 km (1996 est.)
Waterways: 1 ,200 km; most important means of
transport; oceangoing vessels with drafts ranging up
to 7 m can navigate many of the principal waterways
Ports and harbors: Albina, Moengo, New Nickerie,
Paramaribo, Paranam, Wageningen
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 2,421 GRT/
2,990 DWT
ships by type: cargo 1 , container 1 (1 996 est.)
Airports: 45 (1997 est.)
Airports— with paved runways:
total: 5
over 3,047 m: 1
under 914 m: 4 (1 997 est.)
Airports— with unpaved runways:
total: 40
914 to 1,523 m: 7
under 91 4 m: 33 (1997 est.)
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Barentsburg, Longyearbyen,
Ny-Alesund, Pyramiden
Merchant marine: none
Airports: 4 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 3
under 91 4 m: 3 (1997 est.)
444','f5d6c0b48d156a42b3c1e55b432fcce0d49d789055778628cb76796a2233145d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a23c33bce65cf9983fe2732b4f762ddda53308e56cf69d48494776c51c98728',1998,'IS','Iceland','transportation',489,'Railways: 0 km
Highways:
total: 12,341 km
paved: 3,196 km
unpaved: 9,145 km (1996 est.)
217
Iceland (continued)
Ports and harbors: Akureyri, Hornafjordur,
Isafjordhur, Keflavik, Raufarhofn, Reykjavik,
Seydhisfjordhur, Straumsvik, Vestmannaeyjar
Merchant marine:
total: 5 ships (1 ,000 GRT or over) totaling 22,594
GRT/29,322 DWT
ships by type: cargo 1 , chemical tanker 1 , container 1 ,
oil tanker 1, refrigerated cargo 1 (1997 est.)
Airports: 90 (1997 est.)
Airports — with paved runways:
total: 1 1
over 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 6 (1997 est.)
Airports— with unpaved runways:
total: 79
1,524 to 2,437 m: 3
914 to 1,523 m: 22
under 914 m: 54 (1997 est.)
Ports and harbors: none; offshore anchorage only
Airports: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)','f6a05099fb8e64498614fda018be69a4cb85d63f289bcbfa98c7b56f3d397358','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13c2fa8b329bcf565ae172241f2744408b5af9663bd0fd9f61ae78af066bb97a',1998,'IN','India','transportation',498,'Railways:
total: 62,660 km (12,296 km electrified; 12,617 km
double track)
broad gauge: 39,61 2 km 1.676-m gauge
narrow gauge: 1 9,21 0 km 1 .000-m gauge; 3,838 km
0.762-m and 0.61 0-m gauge (1995 est.)
Highways:
total: 2.06 million km
paved: 1,034,120 km
unpaved: 1 ,025,880 km (1996 est.)
Waterways: 16,180 km; 3,631 km navigable by large
vessels
Pipelines: crude oil 3,005 km; petroleum products
2,687 km; natural gas 1,700 km (1995)
Ports and harbors: Calcutta, Chennai (Madras),
Cochin, Jawaharal Nehru, Kandla, Mumbai (Bombay),
Vishakhapatnam
Merchant marine:
total: 299 ships (1 ,000 GRT or over) totaling
6,605,619 GRT/1 0,988, 439 DWT
ships by type: bulk 126, cargo 58, chemical tanker 9,
combination bulk 1, combination ore/oil 3, container
11, liquefied gas tanker 9, oil tanker 75,
passenger-cargo 5, roli-on/roll-off cargo 1, short-sea
passenger 1 (1997 est.)
Airports: 343 (1997 est.)
Airports— with paved runways:
total: 237
over 3,047 m: 12
2,438 to 3,047 m: 47
1,524 to 2,437 m: 87
914 to 1,523 m: 12
under 914 m: 19 (1997 est.)
Airports— with unpaved runways:
total: 106
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
914 to 1,523 m: 47
under 914 m: 51 (1997 est.)
Heliports: 16 (1997 est.)
Ports and harbors: Calcutta (India), Chennai
(Madras; India), Colombo (Sri Lanka), Durban (South
Africa), Jakarta (Indonesia), Melbourne (Australia),
Mumbai (Bombay; India), Richard''s Bay (South Africa)','dccb714470c8efec2af25d6773db3789562ed257aed3f7452d1c15384984a695','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99c31ed1dbe5d4e6bedf1923823d9461f8289e031a7c3c04edd20ed6710ba132',1998,'IE','Ireland','transportation',505,'Railways:
total : 1 ,947 km
broad gauge: 1 ,947 km 1 .600-m gauge (38 km
electrified; 485 km double track) (1996)
Highways:
total: 92,500 km
paved: 87,042 km (including 80 km of expressways)
unpaved: 5,458 km (1996 est.)
Waterways: limited for commercial traffic
Pipelines: natural gas 225 km
Ports and harbors: Arklow, Cork, Drogheda,
Dublin, Foynes, Galway, Limerick, New Ross,
Waterford
Merchant marine:
total: 39 ships (1 ,000 GRT or over) totaling 1 1 6,059
GRT/149,149 DWT
ships by type: bulk 1 , cargo 30, chemical tanker 1 ,
container 3, oil tanker 2, short-sea passenger 2
(1997 est.)
Airports: 44 (1997 est.)
Airports— with paved runways:
total: 15
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 7 (1997 est.)
Airports— with unpaved runways:
total: 29
914 to 1,523m: 4
under 914 m: 25 (1 997 est.)','293f12cd6a2346f57e5976b96e8f9facd37d48c9210b406e402a5587f8d16701','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('badbddff90302eeb05e17c391581e3b95366fc835c905bdce47b0036bd1f2c68',1998,'TN','Tunisia','transportation',514,'Railways:
total: 19,437 km
standard gauge: 18,103 km 1.435-m gauge; Italian
Railways (FS) operates 15,942 km of the total
standard gauge routes (11,299 km electrified)
narrow gauge: 56 km 1 .000-m gauge (56 km
electrified); 1,278 km 0.950-m gauge (19 km
electrified) (1996)
Highways:
total: 31 7,000 km
paved: 317,000 km (including 9,500 km of
expressways)
unpaved: 0 km (1996 est.)
Waterways: 2,400 km for various types of
commercial traffic, although of limited overall value
Pipelines: crude oil 1,703 km; petroleum products
2,148 km; natural gas 19,400 km
Ports and harbors: Ancona, Augusta (Sicily), Bari,
Cagliari (Sardinia), Catania (Sicily), Gaeta, Genoa, La
Spezia, Livorno, Naples, Oristano (Sardinia), Palermo
(Sicily), Piombino, Porto Torres (Sardinia), Ravenna,
Savona, Trieste, Venice
Merchant marine:
total: 365 ships (1,000 GRT or over) totaling
5,032,728 GRT/7, 076, 307 DWT
ships by type: bulk 29, cargo 47, chemical tanker 39,
combination ore/oil 2, container 15, liquefied gas
tanker 30, multifunction large-load carrier 1 , oil tanker
98, passenger 5, roll-on/roll-off cargo 51 , short-sea
passenger 30, specialized tanker 1 1 , vehicle carrier 7
(1997 est.)
Airports: 136 (1997 est.)
Airports— with paved runways:
total: 96
over 3,047 m: 5
2,438 to 3,047 m: 33
1,524 to 2,437 m: 1 6
91 4 to 1,523 m: 30
under 914 m: 12(1997 est.)
Airports— with unpaved runways:
total: 40
1,524 to 2,437 m: 2
914 to 1,523 m: 20
under 91 4 m: 18 (1997 est.)
Heliports: 3 (1997 est.)
Railways:
total: 2,260 km
standard gauge: 492 km 1.435-m gauge
narrow gauge: 1 ,758 km 1 .000-m gauge
dual gauge: 1 0 km 1 .000-m and 1 .435-m gauges
(1993 est.)
Highways:
total: 23,100 km
paved: 18,226 km
unpaved : 4,874 km (1 996 est.)
Pipelines: crude oil 797 km; petroleum products 86
km; natural gas 742 km
Ports and harbors: Bizerte, Gabes, La Goulette,
Sfax, Sousse, Tunis, Zarzis
Merchant marine:
total: 20 ships (1,000 GRT or over) totaling 157,475
GRT/1 65,922 DWT
ships by type: bulk 5, cargo 5, chemical tanker 2,
liquefied gas tanker 1 , oil tanker 1 , roll-on/roll-off cargo
2, short-sea passenger 3, specialized tanker 1 (1997
est.)
Airports: 32 (1997 est.)
Airports— with paved runways:
total : 15
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 3(1997 est.)
Airports— with unpaved runways:
total: 17
1,524 to 2,437 m: 2
914 to 1,523 m: 8
under 914 m: 7 (1997 est.)
Railways:
total: 10,386 km
standard gauge: 1 0,386 km 1 .435-m gauge (1 ,093 km
electrified)
Highways:
tofa/: 381 ,631 km
paved: 95,408 km (including 1,405 km of
expressways)
unpaved: 286,223 km (1 996 est.)
Waterways: about 1,200 km
Pipelines: crude oil 1 ,738 km; petroleum products
2,321 km; natural gas 708 km
Ports and harbors: Gemlik, Hopa, Iskenderun,
Istanbul, Izmir, Kocaeli (Izmit), Icel (Mersin), Samsun,
Trabzon
Merchant marine:
total: 528 ships (1 ,000 GRT or over) totaling
6,205,399 GRT/1 0,400,71 6 DWT
ships by type: bulk 169, cargo 232, chemical tanker
26, combination bulk 5, combination ore/oil 10,
container 5, liquefied gas tanker 5, oil tanker 40,
passenger-cargo 1, refrigerated cargo 3, roll-on/
roll-off cargo 21 , short-sea passenger 9, specialized
tanker 2
note: Turkey owns an additional 41 ships (1 ,000 GRT
or over) totaling 313,523 DWT operating under the
reqistries of The Bahamas, Malta, and Panama (1997
est.)
Airports: 114 (1997 est.)
Airports— with paved runways:
total: 80
over 3,047 m: 17
2,438 to 3,047 m: 21
1,524 to 2,437 m: 18
914 to 1,523 m: 19
under 914 m: 5 (1 997 est.)
Airports— with unpaved runways:
total: 34
1,524 to 2,437 m:1
914 to 1,523 m: 8
under 914 m: 25 (1997 est.)
Heliports: 2 (1997 est.)
Railways:
total: 2,187 km
broad gauge: 2,187 km 1.520-m gauge (1996 est.)
Highways:
total: 24,000 km
paved: 19,488 km (note— these roads are said to be
hard-surfaced, meaning that some are paved and
some are all-weather gravel surfaced
unpaved: 4,512 km (1996 est.)
Waterways: the Amu Darya is an important inland
waterway
Pipelines: crude oil 250 km; natural gas 4,400 km
Ports and harbors: Turkmenbashi (formerly
Krasnowodsk)
Merchant marine:
total: 1 oil tanker ship (1 ,000 GRT or over) totaling
1,896 GRT/3,389 DWT (1997 est.)
Airports: 64 (1994 est.)
476
Airports— with paved runways:
total: 22
2,438 to 3,047 m: 1 3
7,524 fo 2,437 m: 8
914 to 1,523 m:] (1 994 est.)
Airports— with unpaved runways:
total: 42
914 to 1,523 m:7
under 914 m: 35 (1994 est.)','aa45d01d979baba61fff04281e9bee5fba9b68e7b841f09cd33d7a7c5f51767b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9ced7b61ff2178255faf9b46f7903bb8c7756036c8dc611f08541d6f66d523f',1998,'JM','Jamaica','transportation',523,'Railways:
total: 370 km
standard gauge: 370 km 1.435-m gauge; note-
207 km belong to the Jamaica Railway Corporation in
common carrier service, but are no longer operational;
the remaining track is privately owned and used to
transport bauxite
Highways:
total: 18,700 km
paved: 13,100 km
unpaved: 5,600 km (gravel 3,200 km; improved earth
2,400 km) (1997 est.)
Pipelines: petroleum products 10 km
Ports and harbors: Alligator Pond, Discovery Bay,
Kingston, Montego Bay, Ocho Rios, Port Antonio,
Rocky Point, Longswharf
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 5,931 GRT /
10,545 DWT
ships by type: bulk 1 , oil tanker 1 , roll-on/roll-oft cargo
1 (1997 est.)
Airports: 36 (1997 est.)
Airports— with paved runways:
total: 1 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
91 4 to 1,523 m: 3
under 914 m: 5 (1997 est.)
Airports— with unpaved runways:
total: 25
91 4 to 1,523 m: 2
under 914 m: 23 (1997 est.)','ea154ea738d526d7cf551776c0b589afb6019e7edc0c3c56ae0477c578e1de7c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd6b57d80b65f33881b9b4119e080bae5dcba654d9b2eeed18bfe973f4f7b679',1998,'JO','Jordan','transportation',531,'Railways:
total: 676 km
narrow gauge: 676 km 1 .050-m gauge; note— an
additional 1 10 km stretch of the old Hejaz railroad is
out of use
Highways:
total: 6,640 km
paved: 6,640 km
unpaved: 0 km (1996 est.)
Pipelines: crude oil 209 km
Ports and harbors: Al ''Aqabah
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 43,759
GRT/69,795 DWT
ships by type: bulk 3, cargo 1 (1 997 est.)
Airports: 17 (1997 est.)
Airports— with paved runways:
total: 14
over 3,047 m: 9
2,438 to 3,047 m: 4
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 3
914 to 1,523 m:\\
under 914 m: 2 (1997 est.)
Railways:
total: NA km; short line going to a jetty
Ports and harbors: none; offshore anchorage only
Airports: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
914 to 1,523mA (1997 est.)','3b4540674467aab15c0b193e2a26f21602361867a2d6d981efbecb5132d6d87e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55bd338ccbeb64f0d2a703a55ece2ff96a539f5aefbe61e74a1dc1fa6939897b',1998,'KE','Kenya','transportation',538,'Railways:
total: 2,652 km
narrow gauge: 2,652 km 1 .000-m gauge
Highways:
total: 63,800 km
paved: 8,868 km
unpaved: 54,932 km (1996 est.)
Waterways: part of Lake Victoria system is within
boundaries of Kenya
Pipelines: petroleum products 483 km
Ports and harbors: Kisumu, Lamu, Mombasa
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 4,883 GRT/
6,255 DWT
ships by type: oil tanker 1 , roll on/roll off 1 (1 997 est.)
Airports: 240 (1997 est.)
Airports— with paved runways:
total: 29
over 3,047 m: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 22
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 21 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 13
914 to 1,523 m: 114
under 914 m: 83 (1997 est.)','05ce8d008eeda5d8ad9172b67c9e5a007ed79b2264d16ca3700b7050c372099a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b11ac3eca032428668e13caf8787a2104db1b02d98db633ecff8f167ab64bd0d',1998,'WS','Samoa','transportation',545,'Ports and harbors: none; offshore anchorage only
Airports: lagoon was used as a halfway station
between Hawaii and American Samoa by Pan
American Airways for flying boats in 1937 and 1938
Highways: much of the road and many causeways
built during World War II are unserviceable and
overgrown
Ports and harbors: West Lagoon
Airports: airstrip has been overgrown by vegetation
and is no longer serviceable
Airports— with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)
Railways:
total: 355 km
broad gauge: 76 km 1.524-m gauge
narrow gauge: 279 km 0.91 4-m gauge
Highways:
total: 11,100 km
paved: 3,730 km (including 30 km of expressways)
unpaved: 7,370 km (1996 est.)
Waterways: 800 km navigable by shallow draft
vessels; 82 km Panama Canal
365
Panama (continued)
Pipelines: crude oi! 130 km
Ports and harbors: Balboa, Cristobal, Coco Solo,
Vacamonte, Manzanillo
Merchant marine:
total: 4,350 ships (1 ,000 GRT or over) totaling
89,622,1 12 GRT/137, 529, 188 DWT
ships by type: bulk 1 ,240, cargo 1 ,033, chemical
tanker 195, combination bulk 67, combination ore/oil
19, container 426, liquefied gas tanker 175, livestock
carrier 9, multifunction large-load carrier 5, oil tanker
524, passenger 40, passenger-cargo 6, railcar carrier
1 , refrigerated cargo 296, roll-on/roll-off cargo 101 ,
short-sea passenger 40, specialized tanker 15,
vehicle carrier 158
note: a flag of convenience registry; includes ships
from 76 countries among which are Japan 1,236,
Greece 418, Hong Kong 273, South Korea 247,
Taiwan 227, China 1 85, Singapore 1 1 9, US 1 1 2,
Switzerland 85, and Indonesia 60 (1997 est.)
Airports: 109 (1997 est.)
Airports— with paved runways:
total: 40
over 3,047 m: 1
2,438 to 3,047m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 14
under 914 m: 19 (1997 est.)
Airports— with unpaved runways:
total: 69
914 to 1,523 m: 1 7
under 914 m: 52 (1997 est.)
Railways: 0 km
Highways:
total: 790 km
paved: 332 km
unpaved: 458 km (1996 est.)
Ports and harbors: Apia, Asau, Mulifanua,
Salelologa
Merchant marine:
total: 1 roll-on/roll-off cargo ship (1,000 GRT or over)
totaling 3,838 GRT/5,536 DWT (1997 est.)
Airports: 3 (1997 est.)
Airports— with paved runways:
total: 1
2,438 to 3,047 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 2
under 914 m: 2(1997 est.)','de07798aa3dc078d32c84ae8fbaba99a645487c226c82884b6a802060ba9bd90','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71f97de03434917456273d7f7f86487c6591aa1295466dd1e3641bcfef86e0fa',1998,'KI','Kiribati','transportation',554,'Railways: 0 km
Highways:
total: 670 km (1996 est.)
paved: NA km
unpaved: NA km
Waterways: small network of canals, totaling 5 km,
in Line Islands
Ports and harbors: Banaba, Betio, English Harbor,
Kanton
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 3,248 GRT /
4,496 DWT
ships by type: oil tanker 1 , passenger-cargo 1
(1997 est.)
Airports: 21 (1997 est.)
Airports— with paved runways:
total: 4
1,524 to 2,437 m: 4 (1 997 est.)
Airports— with unpaved runways:
total: 17
914 to 1,523 m: 12
under 914 m: 5(1997 est.)
Railways:
total: 5,000 km
standard gauge: 4,095 km 1.435-m gauge (3,500 km
electrified; 159 km double track)
narrow gauge: 665 km 0.762-m gauge
dual gauge : 240 km (standard and broad gauge)
(1996 est.)
Highways:
total: 31 ,200 km
paved: 1 ,997 km
unpaved: 29,203 km (1996 est.)
Waterways: 2,253 km; mostly navigable by small
craft only
Pipelines: crude oil 37 km
Ports and harbors: Ch''ongjin, Haeju, Hungnam
(Hamhung), Kimch''aek, Kosong, Najin, Namp''o,
Sinuiju, Songnim, Sonbong (formerly Unggi),
Ungsang, Wonsan
Merchant marine:
total: 1 05 ships (1 ,000 GRT or over) totaling 663,527
GRT/930,587 DWT
ships by type: bulk 7, cargo 87, combination bulk 1 ,
multifunction large-load carrier 1, oil tanker 3,
passenger 3, passenger-cargo 1 , short-sea
passenger 2
note: North Korea owns an additional 1 ship (1 ,000
GRT or over) totaling 15,143 DWT operating under
the registry of Honduras (1997 est.)
Airports: 49 (1994 est.)
Airports— with paved runways:
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 15
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 2 (1994 est.)
Airports— with unpaved runways:
total: 27
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 12
under 914 m: 6(1994 est.)
Railways:
total: 3,081 km
standard gauge: 3,081 km 1.435-m gauge (560 km
electrified) (1996 est.)
Highways:
total: 83,400 km
paved: 63,467 km (including 1 ,920 km of
expressways)
unpaved: 19,933 km (1996 est.)
Waterways: 1 ,609 km; use restricted to small native
craft
Pipelines: petroleum products 455 km; note—
additionally, there is a parallel petroleum, oils, and
lubricants (POL) pipeline being completed
Ports and harbors: Chinhae, Inch''on, Kunsan,
Masan, Mokp''o, P''ohang, Pusan, Tonghae-hang,
Ulsan, Yosu
Merchant marine:
total: 474 ships (1 ,000 GRT or over) totaling
6,749,052 GRT/1 0,447,597 DWT
ships by type: bulk 118, cargo 131 , chemical tanker
28, combination bulk 3, combination ore/oil 1,
container 70, liquefied gas tanker 12, multifunction
large-load carrier 1, oil tanker 72, refrigerated cargo
22, roll-on/roll-off cargo 1 , short-sea passenger 2,
vehicle carrier 13
note: South Korea owns an additional 273 ships
(1 ,000 GRT or over) totaling 1 1 ,985,267 DWT
operating under the registries of Cambodia, Cyprus,
Liberia, Malta, Panama, and Singapore (1997 est.)
Airports: 103 (1997 est.)
Airports— with paved runways:
total: 67
over 3,047m: 1
2,438 to 3,047 m: 18
1,524 to 2,437 m: 15
914 to 1,523 m: 14
under 914 m: 19(1997 est.)
Airports— with unpaved runways:
total: 36
914 to 1,523 m: 4
under 914 m: 32 (1 997 est.)
Heliports: 202 (1997 est.)','8f83eb11c129c38664693cddfca3834df484d47e22929e3c414abd7fe4d0ab14','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4ee2097cad03377bb7e9567e7cb3f5c789f6d6f034c5906acb61cb4dfa698df',1998,'KG','Kyrgyzstan','transportation',562,'Railways:
total: 370 km in common carrier service; does not
include industrial lines
broad gauge: 370 km 1.520-m gauge (1990)
Highways:
total: 18,500 km
paved: 16,854 km (including 140 km of expressways)
unpaved: 1 ,646 km (1 996 est.)
Waterways: 600 km (1990)
Pipelines: natural gas 200 km
Ports and harbors: Balykchy (Ysyk-Kol or
Rybach''ye)
Airports: 54 (1994 est.)
Airports— with paved runways:
total: 14
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 9
263
Kyrgyzstan (continued)
under 914 m:1 (1994 est.)
Airports— with unpaved runways:
total: 40
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 32 (1994 est.)
Railways: 0 km
Highways:
total: 22,321 km
paved: 3,502 km
unpaved: 18,819 km (1997 est.)
Waterways: about 4,587 km, primarily Mekong and
tributaries; 2,897 additional kilometers are sectionally
navigable by craft drawing less than 0.5 m
265
Laos (continued)
Pipelines: petroleum products 136 km
Ports and harbors: none
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 2,370
GRT/3,000 DWT (1997 est.)
Airports: 52 (1997 est.)
Airports— with paved runways:
total: 9
over 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (1997 est.)
Airports— with unpaved runways:
total: 43
1,524 to 2,437 m: 1
914 to 1,523 m: 17
under 914 m: 25 (1997 est.)','4c60d1fdea8812496725e7311c9db995c892161281442d1e60967d29f56fb1b2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad55619eeb07b512f8fc6224b3c1f94aa3111e407a98543ed52614a615ce2c92',1998,'ZA','South Africa','transportation',577,'Railways:
total: 2.6 km; note— owned by, operated by, and
included in the statistics of South Africa
narrow gauge: 2.6 km 1 .067-m gauge (1 995)
Highways:
total: 4,955 km
paved: 887 km
unpaved: 4,068 km (1996 est.)
Ports and harbors: none
Airports: 29 (1997 est.)
Airports— with paved runways:
total: 3
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 26
914 to 1,523 m: 4
under 914 m: 22 (1997 est.)
Railways:
total: 490 km (single track); note— three rail systems
owned and operated by foreign steel and financial
interests in conjunction with Liberian Government;
one of these, the Lamco Railroad, closed in 1989 after
iron ore production ceased; the other two were shut
down by the civil war
standard gauge: 345 km 1 .435-m gauge
narrow gauge: 145 km 1.067-m gauge
Highways:
total: 10,600 km
paved: 657 km
unpaved: 9,943 km (1996 est.)
Ports and harbors: Buchanan, Greenville, Harper,
Monrovia
Merchant marine:
total: 1 ,620 ships (1 ,000 GRT or over) totaling
59.521.524 GRT/97, 187,450 DWT
ships by type: barge carrier 4, bulk 413, cargo 117,
chemical tanker 143, combination bulk 28,
combination ore/oil 54, container 168, liquefied gas
tanker 89, multifunction large-load carrier 1 , oil tanker
424, passenger 35, refrigerated cargo 67, roll-on/
roll-off cargo 21 , short-sea passenger 4, specialized
tanker 11, vehicle carrier 41
note: a flag of convenience registry; includes ships
from 54 countries among which are Germany 1 98, US
181, Norway 1 53, Greece 1 48, Japan 1 37, Hong Kong
109, China 58, UK 48, Singapore 43, and Monaco 41
(1997 est.)
Airports: 46 (1997 est.)
Airports— with paved runways:
total: 2
over 3,047m: 1
1.524 to 2,437 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 44
1,524 to 2,437 m: 3
914 to 1,523 m: 6
under 914 m;35 (1997 est.)','03bc2c912ff89500f85d0d9028f06e0e475885dd3e86f8ef47289e9432c35b29','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ac743bd9c15e30198bd3e385a305af2de6ed44c889b164a41224d68ebf17aeb',1998,'LY','Libya','transportation',585,'Railways:
note : Libya has had no railroad in operation since
1965, all previous systems having been dismantled;
current plans are to construct a 1 .435-m standard
gauge line from the Tunisian frontier to Tripoli and
Misratah, then inland to Sabha, center of a
mineral-rich area, but there has been no progress;
other plans made jointly with Egypt would establish a
rail line from As Sallum, Egypt, to Tobruk with
completion set for mid-1994; no progress has been
reported
Highways:
total: 83,200 km
paved: 47,590 km
unpaved: 35,610 km (1996 est.)
Waterways: none
Pipelines: crude oil 4,383 km; petroleum products
443 km (includes liquefied petroleum gas or LPG 256
km); natural gas 1,947 km
Ports and harbors: Ai Khums, Banghazi, Darnah,
Marsa al Burayqah, Misratah, Ra''s Lanuf, Tobruk,
Tripoli, Zuwarah
Merchant marine:
total: 30 ships (1 ,000 GRT or over) totaling 61 5,505
GRT/1 ,044,175 DWT
ships by type: cargo 9, chemical tanker 1 , liquefied
276
gas tanker 3, oil tanker 9, roll-on/roll-off cargo 4,
short-sea passenger 4 (1997 est.)
Airports: 145 (1997 est.)
Airports— with paved runways:
total: 60
over 3,047 m: 24
2,438 to 3,047 m: 5
1,524 to 2,437 m: 23
914 to 1,523 m: 5
under 914 m: 3(1997 est.)
Airports— with unpaved runways:
total: 85
over 3, 047 m; 5
2,438 to 3,047m: 2
1,524 to 2,437 m: 15
914 to 1,523 m: 43
under 914 m: 20(1997 est.)','21175d22c7c23e2ed8aa2818f14eaf7070d8c71dd4db6a6b8c07037b0c86840d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7340492916b5c714c0a8b6c66a65b80ffa74ed3dc6a202ef6d023d7e4a7602b',1998,'CH','Switzerland','transportation',595,'Railways:
total: 2,002 km
broad gauge: 2 ,002 km 1.524-m gauge (122 km
electrified) (1994)
Highways:
total: 65,135 km
paved: 57,058 km (including 404 km of expressways)
unpaved: 8, 077 km (1996 est.)
Waterways: 600 km perennially navigable
Pipelines: crude oil, 105 km; natural gas 760 km
(1992)
Ports and harbors: Kaunas, Klaipeda
Merchant marine:
total: 51 ships (1 ,000 GRT or over) totaling 307,947
GRT/341 ,733 DWT
ships by type: cargo 25, combination bulk 1 1 , oil
tanker 2, railcar carrier 1 , refrigerated cargo 8, roll-on/
roll-off cargo 1, short-sea passenger 3 (1997 est.)
Airports: 96 (1994 est.)
Airports— with paved runways:
total: 25
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 2
under 914 m: 14 (1994 est.)
Airports— with unpaved runways:
total: 71
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 6
under 914 m: 6 3(1 994 est.)','7c9355d21206fd0706c51edf194ee965f0c5c2d3be1c71eb5ded16132cf67c41','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1a12b747891e4c04610d14748b57c523539849928651e98cd7e40001b22a2da',1998,'MV','Maldives','transportation',606,'Railways:
total: 1 ,648 km
narrow gauge: 1 ,648 km 1 .000-m gauge (148 km
electrified)
Highways:
total: 94,500 km
paved: 70,970 km (including 580 km of expressways)
unpaved: 23,530 km (1996 est.)
Waterways: 7,296 km (Peninsular Malaysia 3,209
km, Sabah 1,569 km, Sarawak 2,518 km)
Pipelines: crude oil 1,307 km; natural gas 379 km
Ports and harbors: Bintulu, Kota Kinabalu,
Kuantan, Kuching, Kudat, Labuan, Lahad Datu,
Lumut, Miri, Pasir Gudang, Penang, Port Dickson,
Port Kelang, Sandakan, Sibu, Tanjong Berhala,
Tanjong Kidurong, Tawau
Merchant marine:
total: 359 ships (1 ,000 GRT or over) totaling
4,586,576 GRT/6,747,771 DWT
ships by type: bulk 57, cargo 1 32, chemical tanker 23,
container 48, liquefied gas tanker 1 7, livestock carrier
1 , oil tanker 63, refrigerated cargo 2, roll-on/roll-off
cargo 5, short-sea passenger 1 , specialized tanker 2,
vehicle carrier 8 (1997 est.)
Airports: 114 (1997 est.)
Airports— with paved runways:
total: 33
over 3,047m: 5
2,438 to 3,047 m: 4
1,524 to 2,437 m: 11
914 to 1,523 m: 6
under 914 m: 7(1997 est.)
Airports— with unpaved runways:
total: 81
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 72(1997 est.)
Heliports: 1 (1 997 est.)
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km; note— Male has 9.6 km of coral
highways within the city (1988 est.)
Ports and harbors: Gan, Male
Merchant marine:
total: 20 ships (1 ,000 GRT or over) totaling 70,703
GRT/1 08,485 DWT
ships by type: cargo 17, container 1 , oil tanker 1 ,
short-sea passenger 1 (1997 est.)
Airports: 2 (1997 est.)
Airports— with paved runways:
total: 2
over 3,047 m: 1
2,438 to 3,047 m:] (1997 est.)
Railways:
total: 641 km; (linked to Senegal''s rail system through
Kayes)
narrow gauge: 641 km 1.000-m gauge (1995)
Highways:
total: 15,100 km
paved: 1 ,827 km
unpaved: 13,273 km (1996 est.)
Waterways: 1,815 km navigable
Ports and harbors: Koulikoro
Airports: 28 (1997 est.)
296
Airports— with paved runways:
total: 6
2,438 to 3,047m: 4
914 to 1,523 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 22
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 8
under 914 m: 10 (1997 est.)
Railways: 0 km
Highways:
total: 1 ,582 km
paved: 1,471 km
unpaved: 1 1 1 km (1993 est.)
Ports and harbors: Marsaxlokk, Valletta
Merchant marine:
total: 1 ,287 ships (1 ,000 GRT or over) totaling
22,396,164 GRT/37,390,720 DWT
ships by type: bulk 350, cargo 404, chemical tanker 38,
combination bulk 20, combination ore/oil 15, container
55, liquefied gas tanker 1 , livestock carrier 2,
multifunction large-load carrier 3, oil tanker 269,
passenger 7, passenger-cargo 1 , railcar carrier 1 ,
refrigerated cargo 43, roll-on/roll-off cargo 42, short-sea
passenger 17, specialized tanker 3, vehicle carrier 16
note: a flag of convenience registry; includes ships
from 51 countries among which includes Greece 477,
Russia 61 , Switzerland 51 , Italy 50, Norway 49,
Croatia 39, Turkey 38, Germany 30, Georgia 23, and
Monaco 23 (1997 est.)
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (1997 est.)
Railways:
total: 52 km (27 km electrified)
Highways:
total: 640 km
paved: 320 km
unpaved: 320 km
Ports and harbors: Castletown, Douglas, Peel,
Ramsey
Merchant marine:
total : 140 ships (1,000 GRT or over) totaling
4,481 ,925 GRT/7, 663, 593 DWT
ships by type: bulk 28, cargo 8, chemical tanker 8,
combination bulk 3, container 14, liquefied gas tanker
9, oil tanker 46, passenger 2, railroad carrier 1,
refrigerated cargo 3, roll-on/roll-off cargo 15,
short-sea passenger 1 , vehicle carrier 2
note: a flag of convenience registry; UK owns 1 1
ships, Switzerland 2, South Africa 1, Denmark 1,
Sweden 1, Belgium 1, and Netherlands 1 (1997 est.)
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)','877010a36d6e35afbb78cd996a5e70f2dd063a9aed3677a30643a03fe09ebe7d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df57e6009162267b791b44ec25097a8753066e209ca98eb2d5a29d8c216ff690',1998,'MH','Marshall Islands','transportation',619,'Railways: 0 km
Highways:
total : NA km
paved: NA km
unpaved: NA km
note: paved roads on major islands (Majuro,
Kwajalein), otherwise stone-, coral-, or
laterite-surfaced roads and tracks
Ports and harbors: Majuro
Merchant marine:
total: 128 ships (1 ,000 GRT or over) totaling
6,274,057 GRT/1 0,641 ,686 DWT
ships by type: bulk 57, cargo 5, chemical tanker 1 ,
combination ore/oil 1 , container 25, oil tanker 36,
roll-on/roll-off cargo 2, vehicle carrier 1
note: a flag of convenience registry; includes the ships
of Canada 1 , China 1 , Germany 1 , Japan 1 , and US 7
(1997 est.)
Airports: 16 (1997 est.)
Airports— with paved runways:
total: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 12
914 to 1,523 m: 7
under 914 m: 5 (1997 est.)','f5644de52f8c2ac15ad193b70f071b3fc7c57adee00cb9ca522b03ebf215e1fd','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('556f6c50f60501d56b0be6b5e922752a6f3927eda3e5b84f880cac85695d8857',1998,'MR','Mauritania','transportation',624,'Railways:
total: 704 km (single track); note— owned and
operated by government mining company
standard gauge: 704 km 1 .435-m gauge (1995)
Highways:
total: 7,660 km
paved: 866 km
unpaved: 6,794 km (1996 est.)
Waterways: mostly ferry traffic on the Senegal River
Ports and harbors: Bogue, Kaedi, Nouadhibou,
Nouakchott, Rosso
Merchant marine: none
Airports: 26 (1997 est.)
Airports— with paved runways:
total: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 18
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 9
under 914 m: 2 (1997 est.)','cec11579eaf3c4cae5ec7195cb6df6d00ea8e3cbc9b391133d8b05e94b917071','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c47fdcfe09d6d76e898c621bd0b6ca16dc4667a2d046c18a82130e8c7be298ca',1998,'MU','Mauritius','transportation',631,'Railways: 0 km
Highways:
total : 1 ,860 km
paved: 1 ,732 km (including 30 km of expressways)
unpaved: 128 km (1996 est.)
Ports and harbors: Port Louis
Merchant marine:
total: 20 ships (1 ,000 GRT or over) totaling 241 ,799
GRT/336,316 DWT
ships by type: cargo 7, combination bulk 2, container
6, liquefied gas tanker 1 , oil tanker 1 , refrigerated
cargo 3
note: a flag of convenience registry; India owns 1 ship
(1997 est.)
Airports: 5 (1997 est.)
Airports— with paved runways:
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (1997 est.)','25d48c81d85ae874401a6764add788e03656739dec54b1df84802d09478a4c3e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0652c2edf587834759d7359a01ecb3286bdf4e408497ad1bc244d7f7589fb093',1998,'YT','Mayotte','transportation',640,'Railways: 0 km
Highways:
total: 93 km
paved: 72 km
unpaved: 21 km
Ports and harbors: Dzaoudzi
Merchant marine: none
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)
309
Mayotte (continued)','d60fd161229ce176ecb34d1e5fde21d0273eaaa8dabfc3db5e75ab02fc7ff811','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39d49d1cbc7223d6c26d71cbcbef85a529ef355bab8e521d3faf6e4be334397b',1998,'MX','Mexico','transportation',642,'Railways:
total: 20,567 km
standard gauge: 20,477 km 1.435-m gauge (246 km
electrified)
narrow gauge: 90 km 0.91 4-m gauge (1994)
Highways:
total: 252,000 km
paved: 94,248 km (including 6,740 km of
expressways)
unpaved: 157,752 km (1996 est.)
Waterways: 2,900 km navigable rivers and coastal
canals
Pipelines: crude oil 28,200 km; petroleum products
10,150 km; natural gas 13,254 km; petrochemical
1 ,400 km
Ports and harbors: Acapulco, Aitamira,
Coatzacoalcos, Ensenada, Guaymas, La Paz, Lazaro
Cardenas, Manzanillo, Mazatlan, Progreso, Salina
Cruz, Tampico, Topolobampo, Tuxpan, Veracruz
Merchant marine:
total: 53 ships (1 ,000 GRT or over) totaling 899,224
GRT/1 ,312,505 DWT
ships by type: bulk 2, cargo 1 , chemical tanker 4,
combination bulk 1, container 4, liquefied gas tanker
7, oil tanker 29, roll-on/roll-off cargo 2, short-sea
passenger 3 (1997 est.)
Airports: 1,810 (1997 est.)
Airports— with paved runways:
total: 231
over 3,047 m: 9
2,438 to 3,047 m: 25
1,524 to 2,437 m: 94
914 to 1,523 m: 78
under 914 m: 25 (1 997 est.)
Airports— with unpaved runways:
total: 1 ,579
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 65
914 to 1,523 m: 472
under 91 4 m: 1,040 (1997 est.)
Heliports: 1 (1997 est.)
Railways:
total: 3,072 km
broad gauge: 2,769 km 1.668-m gauge (528 km
electrified; 426 km double track)
narrow gauge: 303 km 1.000-m gauge (1996)
Highways:
total: 68,732 km
paved: 59,1 10 km (including 687 km of expressways)
unpaved: 9,622 km (1995 est.)
Waterways: 820 km navigable; relatively
unimportant to national economy, used by
shallow-draft craft limited to 300 metric-ton cargo
capacity
Pipelines: crude oil 22 km; petroleum products 58
km; natural gas 700 km
note: the secondary lines for the natural gas pipeline
that will be 300 km long have not yet been built
Ports and harbors: Aveiro, Funchal (Madeira
Islands), Horta (Azores), Leixoes, Lisbon, Porto,
Ponta Delgada (Azores), Praia da Vitoria (Azores),
Setubal, Viana do Castelo
Merchant marine:
total: 1 07 ships (1 ,000 GRT or over) totaling 736,478
GRT/1, 139,1 80 DWT
ships by type: bulk 8, cargo 60, chemical tanker 1 0,
container 6, liquefied gas tanker 9, oil tanker 8,
refrigerated cargo 1 , roll-on/roli-off cargo 2, short-sea
passenger 3
note: Portugal has created a captive register on
Madeira for Portuguese-owned ships; ships on the
Madeira Register (MAR) will have taxation and
crewing benefits of a flag of convenience (1997 est.)
Airports: 69 (1997 est.)
Airports— with paved runways:
total: 41
over 3,047 m: 5
2,438 to 3,047 m: 8
1,524 to 2,437 m: 4
914 to 1,523 m: 18
under 914 m: 6(1997 est.)
Airports— with unpaved runways:
total: 28
914 to 1,523 m: 1
under 914 m:21 (1997 est.)
Railways:
total: 2,835 km (in addition, there are 224 km not
restored to service after war damage)
standard gauge: 151 km 1.435-m gauge
narrow gauge: 2,454 km 1.000-m gauge
other gauge: 230 km NA-m dual gauge (three rails)
Highways:
total: 93,300 km
paved: 23,418 km
unpaved: 69,882 km (1996 est.)
Waterways: 17,702 km navigable; more than 5,149
km navigable at all times by vessels up to 1 .8 m draft
Pipelines: petroleum products 150 km
Ports and harbors: Cam Ranh, Da Nang,
Haiphong, Ho Chi Minh City, Hong Gai, Qui Nhon,
NhaTrang
Merchant marine:
total: 121 ships (1,000 GRT or over) totaling 487,427
GRT/750,000 DWT
ships by type: bulk 7, cargo 97, chemical tanker 1 ,
combination bulk 1 , oil tanker 9, refrigerated cargo 5,
roll-on/roll-off cargo 1
note: Vietnam owns an additional 7 ships (1 ,000 GRT
or over) totaling 97,531 DWT operating under the
registries of The Bahamas, Honduras, Liberia, Malta,
and Panama (1997 est.)
Airports: 48 (1994 est.)
Airports— with paved runways:
total: 36
over 3,047 m: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 13
under 914 m: 7 (1994 est.)
Airports— with unpaved runways:
total: 12
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 5 (1994 est.)','e9acce7ff16511d2a4969f745c9bfde24528ca4a4a657b48b54638ba5f89f022','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d17732bb89a3d5e444c5ffb9ddaff16038fbf00a22abccc9aa0a5f56d5db94b7',1998,'MS','Montserrat','transportation',648,'Railways: 0 km
Highways:
total: 269 km
paved: 203 km
unpaved: 66 km (1995)
Ports and harbors: Plymouth (abandoned)
Merchant marine: none
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)','910d30c61a6d6e10b1abba23b171a22a3292e7140171d309900a4051c8566849','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('584a1b538707c3be1d8c93b7754167b8e92ed2c8763040e52dd0311b2c6bcf3a',1998,'GI','Gibraltar','transportation',655,'Railways:
total: 1,907 km
standard gauge: 1 ,907 km 1.435-m gauge (1003 km
electrified; 246 km double track) (1994)
Highways:
total: 60,626 km
paved: 30,556 km (including 21 9 km of expressways)
unpaved: 30,070 km (1996 est.)
Pipelines: crude oil 362 km; petroleum products 491
km (abandoned); natural gas 241 km
Ports and harbors: Agadir, El Jadida, Casablanca,
El Jorf Lasfar, Kenitra, Mohammedia, Nador, Rabat,
Safi, Tangier; also Spanish-controlled Ceuta and
Melilla
Merchant marine:
total: 40 ships (1 ,000 GRT or over) totaling 205,053
GRT/259,339 DWT
ships by type: cargo 9, chemical tanker 6, container 2,
324
oil tanker 3, refrigerated cargo 1 1 , roll-on/roll-off cargo
8, short-sea passenger 1 (1997 est.)
Airports: 70 (1997 est.)
Airports— with paved runways:
total: 26
over 3,047 m: 11
2,438 to 3,047 m: 4
1,524 to 2,437 m: 7
914 to 1,523 m: 3
under 91 4 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 44
2,438 to 3,047 m:\\
1,524 to 2,437 m: 1 1
914 to 1,523 m: 21
under 914 m: 11 (1997 est.)
Heliports: 1 (1997 est.)','24e542cec7952de5b5825cdbff350165412634951c3b336f5d73c6ca928252e7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f865b102260bf18be02b1c06bd1e9e0467c43d0031713ed24ed3bc89289e64c1',1998,'NR','Nauru','transportation',663,'Ports and harbors: none; offshore anchorage only
Railways:
total: 101 km; note— all in Kosi close to Indian border
narrow gauge: 101 km 0.762-m gauge
Highways:
total: 7,700 km
paved: 3, 196 km
unpaved: 4,504 km (1996 est.)
Ports and harbors: none
Airports: 45 (1997 est.)
Airports— with paved runways:
total: 5
over 3,047m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (1997 est.)
333
Nepal (continued)
Airports— with unpaved runways:
total: 40
1,524 to 2,437 m: 2
914 to 1,523 m: 9
under 914 m: 29 (1997 est.)','6045343dfe9746f077ce6abefcec34dade56b860623c6aeb3d84627d1c9f95ce','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c8d3155d6fd4590edff8c16d7a3c61f0e63c067c1e3ac7b29230b6fbefa72ee',1998,'NZ','New Zealand','transportation',674,'Railways:
total: 3,973 km
narrow gauge: 3,973 km 1.067-m gauge (519 km
electrified)
Highways:
total: 92,200 km
paved: 53,568 km (including at least 144 km of
expressways)
unpaved: 38,632 km (1994 est.)
Waterways: 1 ,609 km; of little importance to
Pipelines: petroleum products 160 km; natural gas
1 ,000 km; liquefied petroleum gas or LPG 150 km
Ports and harbors: Auckland, Christchurch,
Dunedin, Tauranga, Wellington
Merchant marine:
total: 1 6 ships (1 ,000 GRT or over) totaling 1 55,478
GRT/1 95,836 DWT
ships by type: bulk 4, cargo 1 , liquefied gas tanker 1 ,
oil tanker 3, railcar carrier 1 , roll-on/roll-off cargo 6
(1997 est.)
Airports: 111 (1997 est.)
Airports— with paved runways:
total: 44
over 3,047 m: 2
1,524 to 2,437 m: 8
914 to 1,523 m: 31
under 914 m: 3 (1997 est.)
Airports— with unpaved runways:
total: 67
1,524 to 2,437 m: 1
91 4 to 1,523 m: 23
under 914 m: 43 (1997 est.)
Railways: 0 km
Highways:
total: 680 km
paved: 184 km
unpaved: 496 km (1996 est.)
Ports and harbors: Neiafu, Nukualofa, Pangai
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 1 1 ,278
GRT/1 6,441 DWT
ships by type: bulk 1 , liquefied gas tanker 2, roll-on/
roll-off cargo 1 (1997 est.)
Airports: 6 (1997 est.)
Airports— with paved runways:
total: 1
2,438 to 3,047 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (1997 est.)
I Military
Military branches: Tonga Defense Services
(includes, Royal Tongan Marines, Tongan Royal
Guards, Maritime Force, Police); note— a new Air
Wing which will be subordinate to the Defense
Ministry is being developed
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Railways:
note: minimal agricultural railroad system near San
Fernando; railway service was discontinued in 1968
Highways:
total: 8,320 km
paved : 4,252 km
unpaved: 4,068 km (1996 est.)
Pipelines: crude oil 1,032 km; petroleum products
19 km; natural gas 904 km
Ports and harbors: Pointe-a-Pierre, Point Fortin,
Point Lisas, Port-of-Spain, Scarborough, Tembladora
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 1 ,336
GRT/2,567 DWT (1997 est.)
Airports: 6 (1997 est.)
Airports— with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2(1997 est.)
Ports and harbors: none; offshore anchorage only
Airports: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
under 914 m: 1 (1997 est.)
Railways: 0 km
Highways:
total: 120 km (lie Uvea 100 km, lie Futuna 20 km)
paved: 16 km (all on He Uvea)
unpaved: 104 km (lie Uvea 84 km, lie Futuna 20 km)
Waterways: none
Ports and harbors: Leava, Mata-Utu
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling 44,160
GRT/41 ,656 DWT
ships by type: oil tanker 1 , passenger 1 (1 997 est.)
Airports: 2 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)','588951b9b80558e32752c34a1baca5845b222ebb2ea76e06ae8d98c0769b5c97','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ef3b46b12d2559c4b982524295a5d380347277abb1f54adb62d3fe0ac43db0a',1998,'NI','Nicaragua','transportation',682,'Railways:
total: 0 km
narrow gauge: 0 km 1 .067-m gauge; note — part of the
previous 376 km system was closed and dismantled in
1993 and, in 1994, the remainder was closed, the
track and rolling stock being sold for scrap
Highways:
total: 18,000 km
paved: 1,818 km
unpaved: 16,182 km (1996 est.)
Waterways: 2,220 km, including 2 large lakes
Pipelines: crude oil 56 km
Ports and harbors: Bluefields, Corinto, El Bluff,
Puerto Cabezas, Puerto Sandino, Rama, San Juan
del Sur
Merchant marine: none
Airports: 185 (1997 est.)
Airports— with paved runways:
total: 13
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 5 {1 997 est.)
Airports— with unpaved runways:
total: 172
1,524 to 2,437 m: 1
914 to 1,523 m: 27
under 914 m: 144 (1997 est.)','62424527d2e0b914055904ad7653e824679513268b503cc3a346e12c666a8025','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbaa60c7b3250450168e324307a5b7a4f41aa07c1a79b9b6d132d34a010c34f1',1998,'NG','Nigeria','transportation',685,'Railways: 0 km
Highways:
total: 10,100 km
paved: 798 km
unpaved : 9,302 km (1 996 est.)
Waterways: Niger river is navigable 300 km from
Niamey to Gaya on the Benin frontier from
mid-December through March
Ports and harbors: none
Airports: 27 (1997 est.)
Airports— with paved runways:
total: 9
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 18
1,524 to 2,437 m: 1
914 to 1,523 m: 14
under 914 m: 3 (1 997 est.)
Railways:
total: 3,557 km
narrow gauge: 3,505 km 1 .067-m gauge
standard gauge: 52 km 1.435-m gauge (1995)
Highways:
total: 32,105 km
paved: 26,005 km (including 2,044 km of
expressways)
unpaved: 6,100 km (1994 est.)
note: many of the roads reported as paved may be
graveled; because of poor maintenance, much of the
road system is barely useable
Waterways: 8,575 km consisting of the Niger and
Benue rivers and smaller rivers and creeks
Pipelines: crude oil 2,042 km; petroleum products
3,000 km; natural gas 500 km
Ports and harbors: Calabar, Lagos, Onne, Port
Harcourt, Sapele, Warri
Merchant marine:
total: 39 ships (1 ,000 GRT or over) totaling 379,21 0
GRT/643,851 DWT
ships by type: bulk 1 , cargo 14, chemical tanker 3, oil
tanker 20, roll-on/roll-off cargo 1 (1997 est.)
Airports: 72 (1997 est.)
Airports— with paved runways:
total: 36
over 3,047 m: 6
2,438 to 3,047 m: 10
1,524 to 2,437 m: 10
914 to 1,523 m: 8
under 914 m: 2(1997 est.)
Airports— with unpaved runways:
total: 36
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m:U
under 914 m: 20 (1 997 est.)
Heliports: 1 (1997 est.)','5a6c995a48acfde81f292d28c8ba488d2420363ed030e2f10ec85db08cc11d04','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df2dada05208ee23ba72d6522345550fab37c4548af9d992af855f5146a1861b',1998,'NU','Niue','transportation',697,'Railways: 0 km
Highways:
total: 234 km
paved: 0 km
unpaved : 234 km
Ports and harbors: none; offshore anchorage only
Merchant marine: none
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)','b399263dbd0b9ab6132cd5a550126618e0976ed91e3ce8802151e2c8a4ce429a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b64580101b125289c5c373b902b67e78dd05fcde33542151e218527e94905d3',1998,'NF','Norfolk Island','transportation',704,'Railways: 0 km
Highways:
total: 80 km
paved : 53 km
unpaved: 27 km
Ports and harbors: none; loading jetties at Kingston
and Cascade
Merchant marine: none
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)','aa628e166775de57ae5de3621dd42310109b8ed4531cbcb81febcade21eea24e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7ce0afe1686d4b243a011d6fd8982438f2b24b0de3a9e49df5988ee5a9a7414',1998,'MP','Northern Mariana Islands','transportation',708,'Railways: 0 km
Highways:
total: 362 km (1991 est.)
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: Saipan, Tinian
Merchant marine: none
Airports: 5 (1997 est.)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2, 437 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (1997 est.)
Heliports: 1 (1997 est.)
Ports and harbors: none; two offshore anchorages
for large ships
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
2,438 to 3,047 m: 1 (1997 est.)
Transportation— note: formerly an important
commercial aviation base, now occasionally used by
US military, some commercial cargo planes, and for
emergency landings','18b20426e3bed78c80475fec40d7876b45d56890be6b1838bfc010738d4dd079','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7e5367d55745233ab9684436d0d13f41f9e1671ec75c0b6862b3c36c9acfd6b',1998,'OM','Oman','transportation',717,'Railways: 0 km
Highways:
total: 32,800 km
paved: 9,840 km (including 550 km of expressways)
unpaved: 22, 960 km (1996 est.)
Pipelines: crude oil 1 ,300 km; natural gas 1 ,030 km
Ports and harbors: Matrah, Mina'' al Fahl, Mina''
Raysut
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 16,306
GRT/8,210 DWT
ships by type: cargo 1 , passenger 1 , passenger-cargo
1 (1 996 est.)
Airports: 138 (1997 est.)
Airports— with paved runways:
total: 6
over 3,047 m: 4
2,438 to 3,047 m: 1
914 to 1,523 m ;1 (1997 est.)
Airports— with unpaved runways:
total: 132
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 57
914 to 1,523 m: 32
under 914 m: 35 (1 997 est.)
Heliports: 1 (1997 est.)
357
Oman (continued)
Ports and harbors: Bangkok (Thailand), Hong
Kong, Kao-hsiung (Taiwan), Los Angeles (US),
Manila (Philippines), Pusan (South Korea), San
Francisco (US), Seattle (US), Shanghai (China),
Singapore, Sydney (Australia), Vladivostok (Russia),
Wellington (NZ), Yokohama (Japan)','06fdb7d564e64d99592401726e7f795f2aff48b0ab48123426b95e8fe17bda71','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34671a290405e2ae0c1e9098dff83a23e52325985df79df19fc2d4d804cc5e3b',1998,'PK','Pakistan','transportation',725,'Railways:
total: 8,163 km
broad gauge: 7,71 8 km 1 ,676-m gauge (293 km
electrified; 1,037 km double track)
narrow gauge: 445 km 1.000-m gauge (1996 est.)
Highways:
total: 224,774 km
paved: 128,121 km
unpaved : 96,653 km (1996 est.)
Pipelines: crude oil 250 km; petroleum products 885
km; natural gas 4,044 km (1987)
Ports and harbors: Karachi, Port Muhammad bin
Qasim
Merchant marine:
total: 24 ships (1 ,000 GRT or over) totaling 416,875
GRT/684,580 DWT
ships by type: bulk 5, cargo 1 5, container 3, oil tanker
1 (1 997 est.)
Airports: 115 (1997 est.)
Airports— with paved runways:
total: 80
over 3,047 m: 11
2,438 to 3,047 m: 20
1,524 to 2,437 m: 31
914 to 1,523 m: 15
under 914 m: 3 (1997 est.)
Airports— with unpaved runways:
total: 35
over 3,047 m: 1
1,524 to 2,437 m: 8
914 to 1,523 m: 8
under 91 4 m: 18 (1997 est.)
Heliports: 6 (1997 est.)
Railways: 0 km
Highways:
total: N km
paved: 36 km
unpaved: 25 km
Ports and harbors: Koror
Merchant marine: none
Airports: 3 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 2
1,524 to 2,437 m: 2 (1997 est.)','f2964ff3a36e03c035e57753c318f70cc4db2f68492379aa604fd8f6736fce52','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('136ca505eef1bc564b353cdc9ad63df6111b37b7425540e92def3c016a3f02b2',1998,'PG','Papua New Guinea','transportation',734,'Railways: 0 km
Highways:
total: 19,600 km
paved: 686 km
unpaved: 18,914 km (1996 est.)
Waterways: 10,940 km
Ports and harbors: Kieta, Lae, Madang, Port
Moresby, Rabaul
Merchant marine:
total: 17 ships (1 ,000 GRT or over) totaling 32,859
GRT/45,270 DWT
ships by type: bulk 2, cargo 4, chemical tanker 1 ,
combination ore/oil 5, container 1 , oil tanker 2, roll-on/
roll-off 2 (1997 est.)
Airports: 495 (1997 est.)
Airports— with paved runways:
total: 19
2,438 to 3,047 m: 1
1,524 to 2,437 m: 13
914 to 1,523 m: 4
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 476
1,524 to 2,437 m: 13
914 to 1,523 m: 59
under 914 m: 404 (1997 est.)
Heliports: 2 (1997 est.)','bbd86c97d5d3378ae4260ce0bed8fe899564a0a4aeb42e0887a25212f6da7c0a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8a0121f5e9c3b0fd9c3fe2faac38d1fb1bd66e35a8f98d08d52d0b2025f0d02',1998,'PH','Philippines','transportation',740,'Ports and harbors: small Chinese port facilities on
Woody Island and Duncan Island being expanded
Airports: 1 (1997 est.)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)
Railways:
total: 897 km of which 492 km in operation
narrow gauge: 492 km 1.067-m gauge (1996)
Highways:
total: 156,997 km (1996 est.)
paved: NA km
unpaved: NA km
note: probably less than 30,000 km are designated
arterial roads and not all of these are all-weather
roads
Waterways: 3,219 km; limited to shallow-draft (less
than 1 .5 m) vessels
Pipelines: petroleum products 357 km
Ports and harbors: Batangas, Cagayan de Oro,
Cebu, Davao, Guimaras Island, lligan, Iloilo, Jolo,
Legaspi, Manila, Masao, Puerto Princesa, San
Fernando, Subic Bay, Zamboanga
Merchant marine:
total: 535 ships (1 ,000 GRT or over) totaling
7,334,164 GRT/11, 511, 707 DWT
ships by type: bulk 206, cargo 1 30, chemical tanker 5,
combination bulk 12, container 11, liquefied gas
tanker 10, livestock carrier 12, oil tanker 48,
passenger 4, passenger-cargo 13, refrigerated cargo
20, roll-on/roll-off cargo 15, short-sea passenger 31,
vehicle carrier 18
note : a flag of convenience registry; Japan owns 21
ships, Hong Kong 4, Cyprus 1 , Denmark 1 , Greece 1 ,
Netherlands 1, Norway 1, Panama 1 , Singapore 1 ,
and Taiwan 1 (1997 est.)
Airports: 262 (1997 est.)
Airports— with paved runways:
total: 75
over 3,047 m: 3
2,438 to 3,047 m: 7
1,524 to 2,437 m: 25
914 to 1,523 m: 30
under 914 m: 10(1997 est.)
Airports— with unpaved runways:
total : 187
1,524 to 2,437 m: 3
914 to 1,523 m: 63
under 914 m: 121 (1997 est.)
Heliports: 1 (1997 est.)
Railways: 0 km
Highways:
total: 6.4 km
paved: 0 km
unpaved: 6.4 km
Ports and harbors: Bounty Bay
Merchant marine: none
Airports: none
Ports and harbors: none
Airports: 4 (1997 est.)
Airports— with paved runways:
total: 1
914 to 1,523 mA (1997 est.)
Airports— with unpaved runways:
total: 3
914 to 1,523 mA
under 914 m: 2(1997 est.)','2b49fb1cb5bc4a89ea35369ee86a818b5196551d37232bb9de1543236339c176','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d04b32efd8b5344cc351d1252abd47c5a4234084e1bfe5ff433b44f9d25cc6dd',1998,'DO','Dominican Republic','transportation',757,'Railways:
total: 96 km
narrow gauge: 96 km 1 .000-m gauge, rural,
narrow-gauge system for hauling sugarcane; no
passenger service
Highways:
total: 14,400 km
paved : 14,400 km
unpaved: 0 km (1996 est.)
Ports and harbors: Guanica, Guayanilla,
Guayama, Playa de Ponce, San Juan
Merchant marine: none
Airports: 30 (1997 est.)
Airports— with paved runways:
total: 21
over 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 9
under 974 /T7: 6 (1997 est.)
Airports— with unpaved runways:
total: 9
914 to 1,523 m: 2
under 914 m: 7(1997 est.)','4f0039e51477c03a03e68fdf3157c6604da313311405875f6a23d12b2ee3b228','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('322743bdb618226fc9e9eb9c392ae5705c9bed987fb0f30ebd226509f5724048',1998,'QA','Qatar','transportation',764,'Railways: 0 km
Highways:
total : 1 ,230 km
paved: 1,107 km
unpaved: 123 km (1996 est.)
Pipelines: crude oil 235 km; natural gas 400 km
Ports and harbors: Doha, Halul Island, Umm Sa''id
Merchant marine:
total: 21 ships (1,000 GRT or over) totaling 618,447
GRT/1 ,031,135 DWT
ships by type: combination ore/oil 2, container 3,
cargo 1 1 , oil tanker 5 (1 997 est.)
Airports: 4 (1997 est.)
Airports— with paved runways:
total: 2
over 3,047 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (1997 est.)
Heliports: 1 (1997 est.)','d75194073491b2bc58bffb6404ea4fcd08f5738abad91dccc48ed614246ff919','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad26566ead01c3469be53a486f1ac7f8e9837be3ad6dbc912cb66ed2a05dbb05',1998,'UA','Ukraine','transportation',773,'Railways:
total: 1 1 ,365 km
broad gauge: 45 km 1.524-m gauge
standard gauge: 10,893 km 1 .435-m gauge (3,723 km
electrified; 3,060 km double track)
narrow gauge: 427 km 0.760-m gauge (1994)
Highways:
total: 153,170 km
paved: 78,1 1 7 km (including 1 1 3 km of expressways)
unpaved: 75,053 km (1995 est.)
Waterways: 1,724 km (1984)
Pipelines: crude oil 2,800 km; petroleum products
1 ,429 km; natural gas 6,400 km (1992)
Ports and harbors: Braila, Constanta, Galati,
Mangalia, Sulina, Tulcea
Merchant marine:
total: 227 ships (1 ,000 GRT or over) totaling
2,332,117 GRT/3,464,613 DWT
ships by type: bulk 39, cargo 1 60, container 2, oil
tanker 12, passenger 1 , passenger-cargo 1 , railcar
carrier 2, roll-on/roll-off cargo 10
note: Romania owns an additional 1 1 ships (1 ,000
GRT or over) totaling 827,625 DWT operating under
the registries of The Bahamas, Cyprus, Liberia, and
Malta (1997 est.)
Airports: 24 (1997 est.)
Airports— with paved runways:
total: 19
over 3,047 m: 4
2,438 to 3,047 m: 5
1,524 to 2,437 m: 10(1997 est.)
Airports— with unpaved runways:
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m:) (1997 est.)
Heliports: 1 (1997 est.)
Railways:
total: 154,000 km; note— 87,000 km in common
carrier service (38,000 km electrified); 67,000 km
serve specific industries and are not available for
common carrier use
broad gauge: 154,000 km 1 .520-m gauge (1 January
1994)
Highways:
total: 948,000 km (including 416,000 km which serve
specific industries or farms and are not maintained by
governmental highway maintenance departments)
paved: 336,000 km
unpaved: 612,000 km (including 411,000 km of
graveled or other forms of macadam surface and
201,000 km of unstabilized earth) (1995 est.)
Waterways: total navigable routes in general use
1 01 ,000 km; routes with navigation guides serving the
Russian River Fleet 95,900 km; routes with night
navigational aids 60,400 km; man-made navigable
routes 16,900 km (1 January 1994)
Pipelines: crude oil 48,000 km; petroleum products
15,000 km; natural gas 140,000 km (30 June 1993)
Ports and harbors: Arkhangelsk, Astrakhan'',
Kaliningrad, Kazan'', Khabarovsk, Kholmsk,
Krasnoyarsk, Moscow, Murmansk, Nakhodka,
Nevel''sk, Novorossiysk, Petropavlovsk, St.
Petersburg, Rostov, Sochi, Tuapse, Vladivostok,
Volgograd, Vostochnyy, Vyborg
392
1996 which has not been ratified; Estonia claimed
over 2,000 sq km of territory in the Narva and Pechora
regions of Russia— based on boundary established
under the 1920 Peace Treaty of Tartu; based on the
1920 Treaty of Riga, Latvia had claimed the Abrene/
Pytaiovo section of border ceded by the Latvian Soviet
Socialist Republic to Russia in 1944; draft treaty
delimiting the boundary with Latvia has not been
signed; has made no territorial claim in Antarctica (but
has reserved the right to do so) and does not
recognize the claims of any other nation; 1 997 border
agreement with Lithuania not yet ratified; Svalbard is
the focus of a maritime boundary dispute in the
Barents Sea between Norway and Russia
Illicit drugs: limited cultivation of cannabis and
opium poppy, mostly for domestic consumption;
government has active eradication program;
increasingly used as transshipment point for
Southwest and Southeast Asian opiates and cannabis
and Latin American cocaine to Western Europe, the
US, and growing domestic market','1ed1495ca85dd1a06db747c377758ace0bad13118b943c6b9a3401316d2ea72b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ef36f11eed7098746dc59057ef8f9e045452b20e6e5e17428eb3cb40ceb3ed4',1998,'RW','Rwanda','transportation',776,'Merchant marine:
total: 540 ships (1,000 GRT or over) totaling
4,531 ,937 GRT/6, 253, 940 DWT
ships by type: barge carrier 1 , bulk 1 8, cargo 291 ,
combination bulk 21 , combination ore/oii 1 2, container
24, multifunction large-load carrier 2, oil tanker 107,
passenger 2, passenger-cargo 4, refrigerated cargo
20, roll-on/roll-off cargo 28, short-sea passenger 9,
specialized tanker 1
note: Russia owns an additional 176 ships (1,000
GRT or over) totaling 3,240,776 DWT operating under
the registries of The Bahamas, Cambodia, Cyprus,
Honduras, Liberia, Malta, Panama, Saint Vincent and
the Grenadines, and Singapore (1997 est.)
Airports: 2,51 7 (1994 est.)
Airports— with paved runways:
total: 630
over 3,047 m: 54
2,438 to 3,047 m: 202
1,524 to 2, 437 m: 108
914 to 1,523 m: 115
under 914 m: 151 (1994 est.)
Airports— with unpaved runways:
total: 1 ,887
over 3,047 m: 25
2,438 to 3,047 m: 45
1,524 to 2,437 m: 134
91 4 to 1,523 m: 291
under 914 m: 1 ,392 (1 994 est.)','779f21a3880ec879ea7f52429b7cab21e705bf0b8baf53d3994217eea05fefe8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c41af9cf064d7c1ef277f0d9be2435b49d03dcd4a081c9e68e662e05ec6336f7',1998,'UG','Uganda','transportation',784,'Railways: 0 km
Highways:
total: 12,000 km
paved: 1 ,000 km
unpaved: 1 1 ,000 km (1 997 est.)
Waterways: Lac Kivu navigable by shallow-draft
barges and native craft
Ports and harbors: Cyangugu, Gisenyi, Kibuye
Airports: 7 (1997 est.)
Airports— with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m:1 (1997 est.)
Airports— with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (1997 est.)
Railways: 0 km
Highways:
total: NA km (Saint Helena 1 1 8 km, Ascension NA km,
Tristan da Cunha NA km)
paved: 180.7 km (Saint Helena 98 km, Ascension 80
km, Tristan da Cunha 2.70 km)
unpaved: NA km (Saint Helena 20 km, Ascension NA
km, Tristan da Cunha NA km)
396
Ports and harbors: Georgetown (on Ascension),
Jamestown
Merchant marine: none
Airports: 1 (1 997 est.)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (1997 est.)','cb145de2e0af4faf21cb551de2489a7fbcd205c51cc7b4845bb70be0b1e778a9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83916eaa06e9b8ef91a3e1579e07ffbb180d876b423ee97347110722886af6da',1998,'TT','Trinidad and Tobago','transportation',792,'Railways:
total: 58 km
narrow gauge: 58 km 0.762-m gauge on Saint Kitts to
serve sugarcane plantations (1995)
Highways:
total: 320 km
paved: 136 km
unpaved: 184 km (1996 est.)
Ports and harbors: Basseterre, Charlestown
Merchant marine: none
Airports: 2 (1997 est.)
Airports— with paved runways:
total: 2
1,524 to 2,437 m: 1
under 914 m: 1 (1997 est.)','cea4d032d0c3aa1f42cc9af66db36f35009308534b8427b79cfedb228b131b08','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d7cd4b53d4a76d1b3c7e088adba0160987ce20c5f7d7ceb7bf5760b52ec2e96',1998,'MQ','Martinique','transportation',796,'Railways: 0 km
Highways:
total: 1,210 km
paved: 63 km
unpaved: 1,147 km (1996 est.)
Ports and harbors: Castries, Vieux Fort
Merchant marine: none
Airports: 2 (1997 est.)
Airports— with paved runways:
total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (1 997 est.)
Railways: Okm
Highways:
total: 114 km
paved: 69 km
unpaved : 45 km (1994 est.)
Ports and harbors: Saint Pierre
Merchant marine: none
Airports: 2 (1997 est.)
Airports— with paved runways:
total: 2
914 to 1,523 m: 2(1997 est.)','75ae7951b54d9c1a1fccfff9d8cc4f06a0c28670f46206f604f7d317e211b990','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79fecd084fa4ad74966416b904a83771f6884138499d29b89d45bf816d75f775',1998,'IT','Italy','transportation',808,'Railways: 0 km; note— there is a 1 .5 km cable
railway connecting the city of San Marino to Borgo
Maggiore
Highways:
total: 220 km
paved: NA km
unpaved: NA km
Ports and harbors: none
Airports: none
Railways:
total: 5,249 km (1 ,564 km double track)
standard gauge : 3,741 km 1 .435-m gauge (3,1 1 9 km
electrified; 808 km nongovernment owned)
narrow gauge: 1 ,438 km 1 .000-m gauge (1 ,088 km
electrified; 1,364 km nongovernment owned)
other gauge: 70 km0.750-m or0.800-m gauge (1996)
Highways:
total: 71 ,1 17 km (including 1 ,594 km of expressways)
paved: NA km
unpaved: NA km (1996 est.)
Waterways: 65 km; Rhine (Basel to Rheinfelden,
Schaffhausen to Bodensee); 12 navigable lakes
Pipelines: crude oil 314 km; natural gas 1 ,506 km
Ports and harbors: Basel
Merchant marine:
total: 22 ships (1 ,000 GRT or over) totaling 424,261
GRT/733,551 DWT
ships by type: bulk 13, cargo 1 , chemical tanker 5, oil
tanker 2, roll-on/roll-off cargo 1 (1997 est.)
Airports: 67 (1997 est.)
Airports— with paved runways:
total: 42
over 3,047 m: 4
2,438 to 3,047 m: 5
1,524 to 2,437 m: 12
914 to 1,523 m: 6
under 914 m: 15 {1997 est.)
Airports— with unpaved runways:
total: 25
914 to 1,523 m: 1
under 914 m: 24 (1997 est.)
Railways:
total: 1 ,998 km
broad gauge: 1 ,766 km 1 .435-m gauge
narrow gauge: 232 km 1.050-m gauge
Highways:
total: 40,480 km
paved: 9,310 km (including 866 km of expressways)
unpaved: 31, 170 km (1996 est.)
Waterways: 870 km; minimal economic importance
Pipelines: crude oil 1,304 km; petroleum products
515 km
Ports and harbors: Baniyas, Jablah, Latakia,
Tartus
Merchant marine:
total: 125 ships (1 ,000 GRT or over) totaling 376,903
GRT/555,679 DWT
ships by type: bulk 1 1 , cargo 110, livestock carrier 3,
roll-on/roll-off cargo 1 (1997 est.)
Airports: 104 (1997 est.)
Airports— with paved runways:
total: 24
over 3,047 m: 5
2,438 to 3,047 m: 16
914 to 1,523 m: 1
under 914 m: 2(1997 est.)
Airports— with unpaved runways:
total: 80
1,524 to 2,437 m: 3
914 to 1,523 m: 14
under 914 m: 63 (1997 est.)
Heliports: 2 (1997 est.)','30a7c963c46a0aadd4c9e4c99b9c02de0f6f9a0210eb157dba833d1cf1e9a130','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('991093022387b81795dd6e4be9a678de2bbc8383bbebd51e1d59c77f17ea39c4',1998,'SA','Saudi Arabia','transportation',816,'Railways:
total: 1 ,390 km
standard gauge: 1 ,390 km 1 .435-m gauge (448 km
double track) (1992)
Highways:
total: 162,000 km
paved; 69,1 74 km
unpaved: 92,826 km (1996 est.)
Pipelines: crude oil 6,400 km; petroleum products
150 km; natural gas 2,200 km (includes natural gas
liquids 1,600 km)
Ports and harbors: Ad Dammam, Al Jubayl, Duba,
Jiddah, Jizan, Rabigh, Ra''s al Khafji, Al Mishab, Ras
Tanura, Yanbu1 al Bahr, Yanbu'' al Sinaiyah
Merchant marine:
total: 76 ships (1 ,000 GRT or over) totaling 1 ,009,059
GRT/1 ,329,377 DWT
ships by type: bulk 1 , cargo 1 3, chemical tanker 6,
container 3, liquefied gas tanker 1 , livestock carrier 5,
oil tanker 22, passenger 1 , refrigerated cargo 4,
roll-on/roll-off cargo 12, short-sea passenger 8 (1997
est.)
Airports: 202 (1997 est.)
Airports— with paved runways:
total: 70
over 3,047 m: 30
2,438 to 3,047 m: 12
1,524 to 2,437 m: 23
914 to 1,523 m: 3
under 914 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 132
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 77
914 to 1,523 m: 36
under 914 m: 13 (1997 est.)
Heliports: 4 (1997 est.)','d9b5ddb4745b87969443f6bc9f7eb15cd62014db0cd6ab388dab0d961e895cf6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('814d5d4a89000ae7fbe8efd10cc6a2c2ca27543d2a5eb43d7e53569d4d7eea47',1998,'ML','Mali','transportation',823,'Railways:
total: 904 km
narrow gauge: 904 km 1 .000-meter gauge (70 km
double track) (1995)
Highways:
total: 14,576 km
paved: 4,271 km
unpaved: 10,305 km (1996 est.)
Waterways: 897 km total; 785 km on the Senegal
river, and 1 12 km on the Saloum river
Ports and harbors: Dakar, Kaolack, Matam, Podor,
Richard-Toll, Saint-Louis, Ziguinchor
Merchant marine:
total: 1 bulk ship, 1,995 GRT/3,775 DWT (1997 est.)
Airports: 20 (1997 est.)
Airports— with paved runways:
total: 10
over 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 2 (1997 est.)
Airports— with unpaved runways:
total: 10
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m: 1 (1997 est.)','86d6a6732f09ffd1432847ce7ace82f9b71cd597e35caff2008cd3f0e98a738b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d161d44e809b4e9051ed8b9d5094e1fc8def7b7898d39111e65b78a6120cdde',1998,'SL','Sierra Leone','transportation',839,'Railways: 0 km
Highways:
total: 280 km
paved: 176 km
unpaved: 104 km (1996 est.)
Ports and harbors: Victoria
Merchant marine: none
Airports: 14 (1997 est.)
Airports— with paved runways:
total: 8
2,438 to 3,047m: 1
914 to 1,523 m: 5
under 91 4 m: 2(1997 est.)
Airports— with unpaved runways:
total: 6
914 to 1,523 m: 2
under 914 m: 4 (1 997 est.)
Railways:
total: 84 km used on a limited basis because the mine
at Marampa is closed
narrow gauge: 84 km 1 .067-m gauge
Highways:
total: 1 1 ,700 km
paved: 1 ,287 km
unpaved: 10,413 km (1996 est.)
Waterways: 800 km; 600 km navigable year round
Ports and harbors: Bonthe, Freetown, Pepel
Merchant marine: none
Airports: 10 (1997 est.)
Airports— with paved runways:
total: 3
over 3,047 m: 1
914 to 1,523 m: 2(1997 est.)
Airports— with unpaved runways:
total: 7
914 to 1,523 m: 5
under 914 m: 2(1997 est.)
Heliports: 1 (1997 est.)
J. Military
Military branches: Army, Navy, Police, Security
Forces
Military manpower— availability:
males age 15-49: 1 ,074,728 (1 998 est.)
Military manpower— fit for military service:
males: 521 ,580 (1998 est.)
Military expenditures— dollar figure: $14 million
(FY92/93)
Military expenditures— percent of GDP: 2.6%
(FY92/93)
l Transnational Issues
Disputes— international: none
Geograp by
Location: Southeastern Asia, islands between
Malaysia and Indonesia
Geographic coordinates: 1 22 N, 103 48 E
Map references: Southeast Asia
Area:
total: 647.5 sq km
land: 637.5 sq km
water: 10 sq km
Area— comparative: slightly more than 3.5 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 193 km
Maritime claims:
exclusive fishing zone: within and beyond territorial
sea, as defined in treaties and practice
territorial sea: 3 nm
Climate: tropical; hot, humid, rainy; no pronounced
rainy or dry seasons; thunderstorms occur on 40% of
all days (67% of days in April)
Terrain: lowland; gently undulating central plateau
contains water catchment area and nature preserve
Elevation extremes:
lowest point: Singapore Strait 0 m
highest point: Bukit Timah 1 66 m
Natural resources: fish, deepwater ports
Land use:
arable land: 2%
permanent crops: 6%
permanent pastures: NA%
forests and woodland: 5%
other: 87% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment— current issues: industrial pollution;
limited natural fresh water resources; limited land
availability presents waste disposal problems;
seasonal smoke/haze resulting from forest fires in','18e4c4319934f5a360419d30d67a2ad03f60d39d009dd4a128ae9f1f9de558c5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1af0b9ede77e6097d9e438216493f78f1668942dbb89a62476fba0af383d559',1998,'SB','Solomon Islands','transportation',853,'Railways: 0 km
Highways:
total: 1,360 km
paved: 34 km
unpaved: 1 ,326 km (includes about 800 km of private
plantation roads) (1996 est.)
Ports and harbors: Aola Bay, Honiara, Lofung,
Noro, Viru Harbor, Yandina
Merchant marine: none
Airports: 32 (1997 est.)
Airports— with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 30
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 20 (1997 est.)
Railways:
total: 21,431 km
narrow gauge: 20,995 km 1.067-m gauge (9,087 km
electrified); 436 km 0.61 0-m gauge (1995)
Highways:
total: 331 ,265 km
paved: 137,475 km (including 1 ,142 km of
expressways)
unpaved : 193,790 km (1995 est.)
Pipelines: crude oil 931 km; petroleum products
1 ,748 km; natural gas 322 km
Ports and harbors: Cape Town, Durban, East
London, Mosselbaai, Port Elizabeth, Richards Bay,
Saldanha
Merchant marine:
total: 9 ships (1 ,000 GRT or over) totaling 274,797
GRT/270,837 DWT
ships by type: container 6, oil tanker 2, roll-on/roll-off
cargo 1 (1997 est.)
Airports: 750 (1997 est.)
Airports— with paved runways:
total : 143
over 3,047 m: 10
2,438 to 3,047m: 4
1,524 to 2,437 m: 46
914 to 1,523 m: 74
under 914 m: 9 (1997 est.)
Airports— with unpaved runways:
total: 607
1,524 to 2,437 m: 35
914 to 1,523 m: 308
under 914 m: 264(1997 est.)
Ports and harbors: Grytviken
Airports: none','eabc4278649200b8f45b77675c6c1cbcf57f431cc2862c28229d037bc3a51237','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9258692d38ca5371791071c4f1ba1df9146856a25698f82729df6c1e198f8bf3',1998,'LK','Sri Lanka','transportation',861,'Railways:
total: 1,501 km
broad gauge: 1 ,442 km 1 .676-m gauge
narrow gauge: 59 km 0.762-m gauge (1995)
438
Highways:
total: 99,200 km
paved: 39,680 km
unpaved: 59,520 km (1996 est.)
Waterways: 430 km; navigable by shallow-draft craft
Pipelines: crude oil and petroleum products 62 km
(1987)
Ports and harbors: Colombo, Galle, Jaffna,
Trincomalee
Merchant marine:
total: 24 ships (1 ,000 GRT or over) totaling 204,542
GRT/31 7,253 DWT
ships by type : bulk 2, cargo 13, container 1 , oil tanker
2, refrigerated cargo 6 (1997 est.)
Airports: 13 (1997 est.)
Airports— with paved runways:
total: 12
over 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 6(1997 est.)
Airports— with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (1997 est.)','ccf6ecd79dfc15649c21cedfd6fbdd73a62a8a05ea129f8509d2cf5247dc4e8e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('682501de3a479d8cccc6fb95be3d64b045d9e15e047e39897169c5d680595f9f',1998,'SR','Suriname','transportation',865,'Railways:
total: 5,516 km
narrow gauge: 4,800 km 1.067-m gauge; 716 km
1.6096-m gauge plantation line
Highways:
total: 1 1 ,900 km
paved: 4,320 km
unpaved: 7,580 km (1996 est.)
Waterways: 5,310 km navigable
Pipelines: refined products 815 km
Ports and harbors: Juba, Khartoum, Kusti, Malakal,
Nimule, Port Sudan, Sawakin
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 38,093
GRT/49,727 DWT
ships by type: cargo 2, roll-on/roll-off cargo 2 (1 997
est.)
Airports: 65 (1997 est.)
Airports— with paved runways:
total: 12
over 3,047 m: 1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3 (1 997 est.)
Airports— with unpaved runways:
total: 53
1,524 to 2,437 m: 13
914 to 1,523 m: 29
under 914 m: 11 (1997 est.)
Heliports: 1 (1997 est.)','6d29526c7a09c4f3ea35e76bd8f6807fb824d42ea3bc92e8b3ff6383234b4edc','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bef6778b97ff86db0aa10e41db170b2fb4614c70aae52c9bd61db3af33c7856',1998,'ZW','Zimbabwe','transportation',877,'Railways:
total: 3,569 km (1995)
narrow gauge: 2,600 km 1.000-m gauge; 969 km
1.067-m gauge
note: the Tanzania-Zambia Railway Authority
(TAZARA), which operates 1,860 km of 1.067-m
narrow gauge track between Dar es Salaam and New
Kapiri Mposhi in Zambia (of which 969 km are in
Tanzania and 891 km are in Zambia) is not a part of
Tanzania Railways Corporation; because of the
difference in gauge, this system does not connect to
Tanzania Railways
Highways:
total: 88,200 km
paved: 3,704 km
unpaved: 84,496 km (1996 est.)
Waterways: Lake Tanganyika, Lake Victoria, Lake
Nyasa
Pipelines: crude oil 982 km
Ports and harbors: Bukoba, Dar es Salaam,
Kigoma, Kilwa Masoko, Lindi, Mtwara, Mwanza,
Pangani, Tanga, Wete, Zanzibar
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 30,371
GRT/41 ,269 DWT
ships by type: cargo 3, oil tanker 2, passenger-cargo
2, roll-on/roll-off cargo 1 (1997 est.)
Airports: 123 (1997 est.)
Airports— with paved runways:
total: 1 1
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 1
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 112
1,524 to 2,437 m:M
914 to 1,523 m: 60
under 914 m: 35 (1 997 est.)
I Military
Military branches: Tanzanian People''s Defense
Force or TPDF (includes Army, Navy, and Air Force),
paramilitary Police Field Force Unit, Militia
Military manpower— availability:
males age 15-49: 6,935,184 (1998 est.)
Military manpower— fit for military service:
males: 4,014,130 (1998 est.)
Military expenditures— dollar figure: $69 million
(FY94/95)
Military expenditures— percent of GDP: NA%','eee4f1b66d32221566568af5389fbff8a42cce9c07d7b6ef1845703e0953aa8b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d16a4f572bda15e96f8d6b6e46fc9006f5e5f5108eb38e0963d853dcb3bae650',1998,'TH','Thailand','transportation',882,'Railways:
total: 4,623 km
narrow gauge: 4,623 km 1.000-m gauge (99 km
double track)
Highways:
total: 64,600 km
paved: 62,985 km
unpaved: 1,615 km (1996 est.)
Waterways: 3,999 km principal waterways; 3,701
km with navigable depths of 0.9 m or more throughout
the year; numerous minor waterways navigable by
shallow-draft native craft
Pipelines: petroleum products 67 km; natural gas
350 km
Ports and harbors: Bangkok, Laem Chabang,
Pattani, Phuket, Sattahip, Si Racha, Songkhla
Merchant marine:
total: 304 ships (1 ,000 GRT or over) totaling
1 ,997,060 GRT/3,270,988 DWT
ships by type: bulk 48, cargo 145, chemical tanker 7,
461
Thailand (continued)
container 9, liquefied gas tanker 13, multi-function
large load carrier 3, oil tanker 62, passenger 1,
refrigerated cargo 1 1 , roll-on/roll-off cargo 2,
short-sea passenger 1 , specialized tanker 2 (1 997
est.)
Airports: 106 (1997 est.)
Airports— with paved runways:
total: 55
over 3,047 m: 6
2,438 to 3,047 m: 9
1,524 to 2,437 m: 16
914 to 1,523 m: 20
under 914 m: 4(1997 est.)
Airports— with unpaved runways:
total: 51
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 15
under 914 m: 34 (1997 est.)
Heliports: 3 (1997 est.)
Railways:
total: 525 km (1995)
narrow gauge: 525 km 1 .000-m gauge
Highways:
total: 7, 520 km
paved: 2,376 km
unpaved: 5,144 km (1996 est.)
Waterways: 50 km Mono river
Ports and harbors: Kpeme, Lome
Merchant marine: none
Airports: 9 (1997 est.)
Airports— with paved runways:
total: 2
2,438 to 3,047 m: 2(1997 est.)
Airports— with unpaved runways:
total: 7
914 to 1,523 m: 5
under 914 m: 2 (1997 est.)','e35c018f996e5ed7cdbd656169240a7fdec4050a1d3c9920f8227e774505890d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33de1957e6ea09c154f65c41aeb6eacef7867b0f98d5ac28fd325941b9c3fda4',1998,'TK','Tokelau','transportation',891,'Railways: 0 km
Highways:
total: HA km
paved: NA km
unpaved: NA km
Ports and harbors: none; offshore anchorage only
Merchant marine: none
Airports: none; lagoon landings by amphibious
aircraft from Western Samoa','fc41af170aab5da8a173f7b883ba8351eebd90ca91a79e40cb63741a18bc3042','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ea19687cc735f66a601c23aed152098607af6ced223bf4e5214a7fae2c1f925',1998,'AE','United Arab Emirates','transportation',907,'Railways: 0 km
Highways:
total: 4,835 km
paved: 4,835 km
unpaved: 0 km (1 996 est.)
Pipelines: crude oil 830 km; natural gas, including
natural gas liquids, 870 km
Ports and harbors: ''Ajman, Al Fujayrah, Das Island,
Khawr Fakkan, Mina1 Jabal ''Ali, Mina1 Khalid, Mina''
Rashid, Mina'' Saqr, Mina'' Zayid, Umm al Qaywayn
Merchant marine:
total: 67 ships (1 ,000 GRT or over) totaling 945,320
GRT/1 ,592,164 DWT
ships by type: bulk 3, cargo 18, chemical tanker 3,
container 7, liquefied gas tanker 1 , livestock carrier 1 ,
oil tanker 27, refrigerated cargo 1 , roll-on/roll-off cargo
6 (1997 est.)
Airports: 40 (1997 est.)
Airports— with paved runways:
total: 22
over 3,047 m: 9
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 4(1997 est.)
Airports— with unpaved runways:
total: 18
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 8
under 914 m: 5 (1 997 est.)
Heliports: 2 (1997 est.)
I Military
Military branches: Army, Navy, Air Force,
paramilitary (includes Federal Police Force)
Military manpower— military age: 1 8 years of age
Military manpower— availability:
males age 15-49: 791 ,770 (1 998 est.)
note: includes non-nationals
Military manpower— fit for military service:
males : 425,373 (1998 est.)
Military manpower— reaching military age
annually:
males: 22,040 (1998 est.)
Military expenditures— dollar figure: $1 .59 billion
(1994)
Military expenditures— percent of GDP: 4.3%
(1994)
487
United Arab Emirates (continued)','02726fb6c407104190f7ac5225e48154a8c28720b4162bad31afc6f98d6988c4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f62208ba7e0c6739191daa23062bccad79d99a26f94d5fecea68ee9506f29fa1',1998,'UY','Uruguay','transportation',915,'Railways:
total: 2,998 km (918 km closed) (1997)
standard gauge: 2,075 km 1 .435-m gauge
Highways:
total: 8,420 km
paved: 7,578 km
unpaved: 842 km (1996 est.)
Waterways: 1 ,600 km; used by coastal and
shallow-draft river craft
Ports and harbors: Fray Bentos, Montevideo,
Nueva Palmira, Paysandu, Punta del Este, Colonia,
Piriapolis
Merchant marine:
total : 2 oil tanker ships (1 ,000 GRT or over) totaling
44,042 GRT/83,684 DWT (1997 est.)
Airports: 64 (1997 est.)
Airports— with paved runways:
total: 1 5
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 8
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 49
1,524 to 2,437 m: 2
914 to 1,523 m: 14
under 914 m: 33 (1997 est.)','0b78bfe808071adf2ef03fb222a6e835fa4496b692b5f5aa83c4f6285f9ee068','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba10f5755353c6a50ef7140f4ad59dbeee04b68ca7e77dfdd0c24b83fcd4dc75',1998,'UZ','Uzbekistan','transportation',924,'Railways:
total: 3,380 km in common carrier service; does not
include industrial lines
broad gauge: 3,380 km 1 .520-m gauge (300 km
electrified) (1993)
Highways:
total: 81,600 km
paved: 71 ,237 km (note— these roads are said to be
hard surfaced, meaning that some are paved and
some are all-weather gravel surfaced)
unpaved: 10,363 km dirt (1996 est.)
Waterways: 1,100(1990)
Pipelines: crude oil 250 km; petroleum products 40
km; natural gas 810 km (1992)
Ports and harbors: Termiz (Amu Darya river)
Airports: 3 (1997 est.)
Airports— with paved runways:
total: 3
over 3,047 m: 2
2,438 to 3,047 m:] (1997 est.)','9c5f2889b9d1e76dba4470c535497fde5b2519db4692a1117a6555098dd74572','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('924fe50b9e1426faf46b5525c9859538d1d352e21f41f4d9e74b25660e9e6df4',1998,'VU','Vanuatu','transportation',930,'Railways: 0 km
Highways:
total: 1 ,070 km
paved: 256 km
unpaved: 814 km (1996 est.)
Ports and harbors: Forari, Port-Vila, Santo (Espiritu
Santo)
Merchant marine:
total: 88 ships (1 ,000 GRT or over) totaling 1 ,407,737
GRT/1 ,761,413 DWT
ships by type: bulk 31 , cargo 24, chemical tanker 2,
combination bulk 1 , liquefied gas tanker 4, oi! tanker 5,
refrigerated cargo 13, vehicle carrier 8
note: a flag of convenience registry; includes ships
from 1 5 countries among which are ships of Japan 30,
India 10, US 8, Netherlands 6, Greece 4, Hong Kong
4, Australia 2, Canada 1 , China 1 , and Poland 1 (1 997
est.)
Airports: 31 (1997 est.)
Airports— with paved runways:
total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 29
1,524 to 2,437 m: 1
914 to 1,523 m: 10
under 914 m: 18(1997 est.)','7f2bf926ea8d1a24c62c109b48170661be7e7ab1200372a91d1c59e50c6210cb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd4409dd55cd30dacdfeb5bec5ec4287b9e9e6c5770dda9fd0e25f441b9a0113',1998,'PR','Puerto Rico','transportation',938,'Railways: 0 km
Highways:
total: 856 km
paved: NA km
unpaved: NA km
Ports and harbors: Charlotte Amalie, Christiansted,
Cruz Bay, Port Alucroix
Merchant marine: none
Airports: 2
note: international airports on Saint Thomas and Saint
Croix; there is an airfield on St. John (1997 est.)
Airports— with paved runways:
total: 2
1,524 to 2,437 m: 2 (1997 est.)','dcb16919dd34b5dd2ad8052e6008fa72435e2cd634305a00fcdaef3c0a60331f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6f136c6f742c968162fdcd2c1ae901ba8aad84d8fa461b8ba056f26ff1fc5c5',1998,'EH','Western Sahara','transportation',946,'Railways: 0 km
Highways:
total: 6,200 km
pavecf: 1,350 km
unpaved: 4,850 km (1991 est.)
Ports and harbors: Ad Dakhla, Cabo Bojador, El
Aaiun
Airports: 12 (1997 est.)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 3 (1997 est.)
Airports— with unpaved runways:
total: 9
1,524 to 2,437 m: 1
914 to 1,523 m: 5
under 914 m: 3 (1997 est.)
Heliports: 1 (1997 est.)
Railways:
total: 1 ,201 ,337 km includes about 190,000 to
195,000 km of electrified routes of which 147,760 km
are in Europe, 24,509 km in the Far East, 1 1 ,050 km
in Africa, 4,223 km in South America, and 4,160 km in
North America; note— fastest speed in daily service is
300 km/hr attained by France''s Societe Nationale des
Chemins-de-Fer Francais (SNCF) Le Train a Grande
Vitesse (TGV) — Atlantique line
broad gauge: 251 ,1 53 km
standard gauge: 71 0,754 km
narrow gauge: 239,430 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Chiba, Houston, Kawasaki,
Kobe, Marseille, Mina1 al Ahmadi (Kuwait), New
Orleans, New York, Rotterdam, Yokohama
Merchant marine:
total: 27,052 ships (1,000 GRT or over) totaling
477,514,362 GRT/743, 923,664 DWT
ships by type: barge carrier 21 , bulk 5,623, cargo
8,426, chemical tanker 1 ,048, combination bulk 321 ,
combination ore/oil 246, container 2,378, liquefied gas
tanker 768, livestock carrier 58, multifunction
large-load carrier 86, oil tanker 4,435, passenger 306,
passenger-cargo 126, railcar carrier 20, refrigerated
cargo 1,056, roll-on/roll-off cargo 1,084, short-sea
passenger 491, specialized tanker 93, vehicle carrier
466 (1997 est.)','dce670252289e6103de3b0cfb49f39e6045120f317e063b28aa8066e8448ebcc','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5530b1f49c66ea25fe8f4d23466de369ae34088dc3344388dc88cefa85c8a4f',1998,'YE','Yemen','transportation',954,'Railways: 0 km
Highways:
total: 64,725 km
paved: 5,243 km
unpaved: 59,482 km (1996 est.)
Pipelines: crude oil 644 km; petroleum products 32
km
Ports and harbors: Aden, Al Hudaydah, Al Mukalla,
As Salif, Mocha, Nishtun
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 1 2,059
GRT/1 8,563 DWT
ships by type: cargo 1 , oil tanker 2 (1 997 est.)
Airports: 48 (1997 est.)
Airports— with paved runways:
total: 1 1
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 37
over 3,047 m: 2
2,438 to 3,047 m: 10
1,524 to 2,437 m: 10
914 to 1,523 m: 12
under 914 m: 3(1997 est.)
516','d861867cca07e1a46e6d33625b1468464308455b742c9c0e21ba24705b1a58a6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c288ecd63f7d7d1414da8ee7839891812b3e77eb79e4d9898554d038e017b7a7',1998,'ZM','Zambia','transportation',962,'Railways:
total: 2, 164 km (1995)
narrow gauge: 2,164 km 1.067-m gauge (13 km
double track)
note: the total includes 891 km of the
Tanzania-Zambia Railway Authority (TAZARA), which
operates 1 ,860 km of 1 .067-m narrow gauge track
between Dar es Salaam and New Kapiri Mposhi
where it connects to the Zambia Railways system;
TAZARA is not a part of Zambia Railways
Highways:
total: 39,700 km
paved: 7,265 km (including 60 km of expressways)
unpaved: 32,435 km (1 996 est.)
Waterways: 2,250 km, including Zambezi and
Luapula rivers, Lake Tanganyika
Pipelines: crude oil 1 ,724 km
Ports and harbors: Mpulungu
518
Airports: 111 (1997 est.)
Airports— with paved runways:
total: 12
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 2
under 914 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 99
2,438 to 3,047 m:1
1,524 to 2,437 m: 2
914 to 1,523 m: 64
under 914 m: 32 (1997 est.)
I Military
Military branches: Army, Air Force, paramilitary
forces, Police
Military manpower— availability:
ma/es age 15-49: 2,037,123 (1 998 est.)
Military manpower— fit for military service:
males: 1,078,085 (1998 est.)
Military expenditures— dollar figure: $96 million
(1995)
Military expenditures— percent of GDP: 2.7%
(1995)
Railways:
total: 2,759 km (1995)
narrow gauge: 2,759 km 1.067-m gauge (313 km
electrified; 42 km double track) (1995 est.)
Highways:
total: 18,338 km
paved: 8,692 km
unpaved: 9,646 km (1996 est.)
Waterways: the Mazoe and Zambezi rivers are used
for transporting chrome ore from Harare to','381d8ffed94cd8b24e23434e9719e2c84d2a89e6e59836ade80af14ff721fc7c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

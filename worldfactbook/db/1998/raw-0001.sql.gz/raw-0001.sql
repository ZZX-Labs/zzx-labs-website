SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8fa8c185ebb142844291653a94f287e1bd4e3c5f2b13a4a82250320000c1868',1998,'','','raw',1,'UNITED STATES. tal E
INTELLIGENCE AGENCY
a
Enjoy this wonderful eBook from All You Can Books audiobooks and ebooks service.
Visit us at AllYouCanBooks.com for more great titles you can enjoy anytime, anywhere.
THE 1998
(Osh \\AO) 54 fF D)
1 325\\( Gi b 3XOXO) 6
UNITED STATES. CENTRAL
INTELLIGENCE AGENCY
Produced by Dr. Gregory B. Newby
The CIA World Factbook 1998
TABLE OF CONTENTS
Countries are listed in alphabetical order. Notes and appendixes follow the country listings.','ae962a167c4b7ebf379842d01d0427a8028b3b538422caf7b5bdede59f960b10','internet-archive','1998-cia-world-factbook-united-states-central-intelligence-agency','txt','ed8d799a5289d0958a7a95ba11403072d40c0ab0f88fcf382252becb0759ed16','https://archive.org/download/1998-cia-world-factbook-united-states-central-intelligence-agency/1998-cia-world-factbook-united-states-central-intelligence-agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0dc5535844a024bd5ef82fe2a4c63c0902b218c75f3145aa3af72300d286a73a',1998,'ZW','Zimbabwe','raw',2,'Notes and Definitions
Appendixes
Appendix A: Abbreviations
Appendix B: United Nations System
Appendix C: International Organizations and Groups
Appendix D: Selected International Environmental Agreements
Appendix E: Weights and Measures
Appendix F: Cross-Reference List of Country Data Codes
Appendix G: Cross-Reference List of Hydrographic Codes
Appendix H: Cross-Reference List of Geographic Names
History
Contributors and Copyright Information
Purchase Information','2f1b752aa64e74780a1aba6fd9eb62da8e2b9ba4c2843a2124b0ab6a3f47d852','internet-archive','1998-cia-world-factbook-united-states-central-intelligence-agency','txt','ed8d799a5289d0958a7a95ba11403072d40c0ab0f88fcf382252becb0759ed16','https://archive.org/download/1998-cia-world-factbook-united-states-central-intelligence-agency/1998-cia-world-factbook-united-states-central-intelligence-agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('779ef0ceea33fd89ea5268df78b8669ca921062f8dd53fab5f70a14dbd7f41e2',1998,'AF','Afghanistan','raw',3,'@Afghanistan:Geography
Location: Southern Asia, north and west of Pakistan, east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area: total: 647,500 sq km land: 647,500 sq km water: 0 sq km
Area-comparative: slightly smaller than Texas
Land boundaries:
total: 5,529 km
border countries: China 76 km, Iran 936 km, Pakistan 2,430 km,
Tajikistan 1,206 km, Turkmenistan 744 km, Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: arid to semiarid; cold winters and hot summers
Terrain: mostly rugged mountains; plains in north and southwest
Elevation extremes: lowest point: Amu Darya 258 m highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum, coal, copper, talc, barites, sulfur, lead, zinc, iron ore, salt, precious and
semiprecious stones
Land use: arable land: 12% permanent crops: 0% permanent pastures: 46% forests and woodland: 3% other: 39%
(1993 est.)
Irrigated land: 30,000 sq km (1993 est.)
Natural hazards: damaging earthquakes occur in Hindu Kush mountains; flooding
Environment-current issues: soil degradation; overgrazing; deforestation (much of the remaining forests are being
cut down for fuel and building materials); desertification
Environment-international agreements: party to: Desertification, Endangered Species, Environmental
Modification, Marine Dumping, Nuclear Test Ban signed, but not ratified: Biodiversity, Climate Change,
Hazardous Wastes, Law of the Sea, Marine Life Conservation
Geography-note: landlocked
@Afghanistan:People
Population: 24,792,375 (July 1998 est.)
Age structure: 0-14 years: 43% (male 5,425,510; female 5,216,954) 15-64 years: 54% (male 6,978,549; female
6,494,253) 65 years and over: 3% (male 357,780; female 319,329) (July 1998 est.)
Population growth rate: 4.21% (1998 est.) note: this rate reflects the continued return of refugees
Birth rate: 42.37 births/1,000 population (1998 est.)
Death rate: 17.4 deaths/1,000 population (1998 est.)
Net migration rate: 17.14 migrant(s)/1,000 population (1998 est.)
Sex ratio: at birth: 1.05 male(s)/female under 15 years: 1.03 male(s)/female 15-64 years: 1.07 male(s)/female 65
years and over: 1.12 male(s)/female (1998 est.)
Infant mortality rate: 143.63 deaths/1,000 live births (1998 est.)
Life expectancy at birth: total population: 46.83 years male: 47.35 years female: 46.29 years (1998 est.)
Total fertility rate: 6.01 children born/woman (1998 est.)
Nationality: noun: Afghan(s) adjective: Afghan
Ethnic groups: Pashtun 38%, Tajik 25%, Uzbek 6%, Hazara 19%, minor ethnic groups (Aimaks, Turkmen, Baloch,
and others)
Religions: Sunni Muslim 84%, Shi''a Muslim 15%, other 1%
Languages: Pashtu 35%, Afghan Persian (Dari) 50%, Turkic languages (primarily Uzbek and Turkmen) 11%, 30
minor languages (primarily Balochi and Pashai) 4%, much bilingualism
Literacy: definition: age 15 and over can read and write total population: 31.5% male: 47.2% female: 15% (1995
est.)
@Afghanistan:Government
Country name: conventional long form: Islamic State of Afghanistan; note-the self-proclaimed Taliban
government refers to the country as Islamic Emirate of Afghanistan conventional short form: Afghanistan local
long form: Dowlat-e Eslami-ye Afghanestan local short form: Afghanestan former: Republic of Afghanistan
Data code: AF
Government type: transitional government
National capital: Kabul
Administrative divisions: 30 provinces (velayat, singular-velayat);
Badakhshan, Badghis, Baghlan, Balkh, Bamian, Farah, Faryab, Ghazni,
Ghowr, Helmand, Herat, Jowzjan, Kabol, Kandahar, Kapisa, Konar,
Kondoz, Laghman, Lowgar, Nangarhar, Nimruz, Oruzgan, Paktia, Paktika,
Parvan, Samangan, Sar-e Pol, Takhar, Vardak, Zabol
note: there may be two new provinces of Nurestan (Nuristan) and Khowst
Independence: 19 August 1919 (from UK control over Afghan foreign affairs)
National holiday: Victory of the Muslim Nation, 28 April; Remembrance
Day for Martyrs and Disabled, 4 May; Independence Day, 19 August
Constitution: none
Legal system: a new legal system has not been adopted but all factions tacitly agree they will follow Shari''a
(Islamic law)
Suffrage: undetermined; previously males 15-50 years of age
Executive branch: on 27 September 1996, the ruling members of the Afghan Government were displaced by
members of the Islamic Taliban movement; the Islamic State of Afghanistan has no functioning government at this
time, and the country remains divided among fighting factions note: the Taliban have declared themselves the
legitimate government of Afghanistan; the UN has deferred a decision on credentials and the Organization of the
Islamic Conference has left the Afghan seat vacant until the question of legitimacy can be resolved through
negotiations among the warring factions; the country is essentially divided along ethnic lines; the Taliban controls
the capital of Kabul and approximately two-thirds of the country including the predominately ethnic Pashtun areas
in southern Afghanistan; opposing factions have their stronghold in the ethnically diverse north-General
DOSTAM''s National Islamic Movement controls several northcentral provinces and Commander MASOOD
controls the ethnic Tajik majority areas of the northeast
Legislative branch: non-functioning as of June 1993
Judicial branch: non-functioning as of March 1995, although there are local Shari''a (Islamic law) courts throughout
the country
Political parties and leaders: Taliban (Religious Students Movement),
Mohammad OMAR; United Islamic Front for the Salvation of Afghanistan
[comprised of Jumbesh-i-Melli Islami (National Islamic Movement),
Abdul Rashid DOSTAM; Jamiat-i-Islami (Islamic Society), Burhanuddin
RABBANI and Ahmad Shah MASOOD; and Hizbi Wahdat-Khalili faction
(islamic Unity Party), Abdul Karim KHALILI]; other smaller parties are
Hizbi Islami-Gulbuddin (Islamic Party), Gulbuddin HIKMATYAR faction;
Hizbi Islami-Khalis (Islamic Party), Yunis KHALIS faction;
Ittihad-i-Islami Barai Azadi Afghanistan (Islamic Union for the
Liberation of Afghanistan), Abdul Rasul SAY YAF;
Harakat-Inqilab-i-Islami (Islamic Revolutionary Movement), Mohammad
Nabi MOHAMMADI; Jabha-i-Najat-i-Milli Afghanistan (Afghanistan
National Liberation Front), Sibghatullah MOJADDEDI;
Mahaz-i-Milli-Islami (National Islamic Front), Sayed Ahamad GAILANI;
Hizbi Wahdat-Akbari faction (Islamic Unity Party), Mohammad Akbar
AKBARIT; Harakat-i-Islami (Islamic Movement), Mohammed Asif MOHSENI
Political pressure groups and leaders: tribal elders represent
traditional Pashtun leadership; Afghan refugees in Pakistan,
Australia, US, and elsewhere have organized politically; Peshawar,
Pakistan-based groups such as the Coordination Council for National
Unity and Understanding in Afghanistan (CUNUA), Ishaq GAILANI; Writers
Union of Free Afghanistan (WUFA), A. Rasul AMIN; Mellat (Social
Democratic Party), leader NA
International organization participation: ASDB, CP, ECO, ESCAP, FAO,
G-77, IAEA, IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF,
Intelsat, IOC, IOM (observer), ITU, NAM, OIC, UN, UNCTAD, UNESCO,
UNIDO, UPU, WFTU, WHO, WMO, WToO
Diplomatic representation in the US: note: embassy operations suspended 21 August 1997 chief of mission:
Ambassador (vacant) chancery: 2341 Wyoming Avenue NW, Washington, DC 20008 telephone: [1] (202) 234-
3770 FAX: [1] (202) 328-3516 consulate(s) general: New York
Diplomatic representation from the US: the US embassy in Kabul has been closed since January 1989 due to
security concerns
Flag description: three equal horizontal bands of green (top), white, and black with a gold emblem centered on the
three bands; the emblem features a temple-like structure with Islamic inscriptions above and below, encircled by a
wreath on the left and right and by a bolder Islamic inscription above, all of which are encircled by two crossed
scimitars note: the Taliban uses a plain white flag
@Afghanistan:Economy
Economy-overview: Afghanistan is an extremely poor, landlocked country, highly dependent on farming and
livestock raising (sheep and goats). Economic considerations have played second fiddle to political and military
upheavals during more than 18 years of war, including the nearly 10-year Soviet military occupation (which ended
15 February 1989). During the war one-third of the population fled the country, with Pakistan and Iran sheltering a
combined peak of more than 6 million refugees. Now, only 750,000 registered Afghan refugees remain in Pakistan
and about 1.2 million in Iran. Another 1 million have probably moved into and around urban areas within
Afghanistan. Gross domestic product has fallen substantially over the past 18 years because of the loss of labor and
capital and the disruption of trade and transport. Much of the population continues to suffer from insufficient food,
clothing, housing, and medical care. Inflation remains a serious problem throughout the country, with one estimate
putting the rate at 240% in Kabul in 1996. Numerical data are likely to be either unavailable or unreliable.
GDP: purchasing power parity-$19.3 billion (1997 est.)
GDP-real growth rate: NA%
GDP-per capita: purchasing power parity-$800 (1997 est.)
GDP-composition by sector: agriculture: 53% industry: 28.5% services: 18.5% (1990)
Inflation rate-consumer price index: 240% (1996 est.)
Labor force: total: 7.1 million by occupation: agriculture and animal husbandry 67.8%, industry 10.2%,
construction 6.3%, commerce 5.0%, services and other 10.7% (1980 est.)
Unemployment rate: 8% (1995 est.)
Budget: revenues: $NA expenditures: $NA, including capital expenditures of $NA
Industries: small-scale production of textiles, soap, furniture, shoes, fertilizer, and cement; handwoven carpets;
natural gas, oil, coal, copper
Electricity-capacity: 494,000 kW (1995)
Electricity-production: 655 million kWh (1995)
Electricity-consumption per capita: 37 kWh (1995)
Agriculture-products: wheat, fruits, nuts, karakul pelts; wool, mutton
Exports: total value: $80 million (1996 est.) commodities: fruits and nuts, handwoven carpets, wool, cotton, hides
and pelts, precious and semi-precious gems partners: FSU, Pakistan, Iran, Germany, India, UK, Belgium,
Luxembourg, Czechoslovakia
Imports: total value: $150 million (1996 est.) commodities: food and petroleum products; most consumer goods
partners: FSU, Pakistan, Iran, Japan, Singapore, India, South Korea, Germany
Debt-external: $2.3 billion (March 1991 est.)
Economic aid: recipient: ODA; about $45 million in UN aid plus additional bilateral aid and aid in kind (1997)
note: US provided $450 million in bilateral assistance (1985-93); US continues to contribute to multilateral
assistance through the UN programs of food aid, immunization, land mine removal, and a wide range of aid to
refugees and displaced persons
Currency: 1 afghani (AF) = 100 puls
Exchange rates: afghanis (Af) per US$1-17,000 (December 1996), 7,000 (January 1995), 1,900 (January 1994),
1,019 (March 1993), 850 (1991); note-these rates reflect the free market exchange rates rather than the official
exchange rate, which was fixed at 50.600 afghanis to the dollar until 1996, when it rose to 2,262.65 per dollar, and
finally became fixed again at 3,000.00 per dollar on April 1996
Fiscal year: 21 March-20 March','2709db695e7b32e43425f9f664876bb5765e4f6575a9a87b621fed7b53bbe0c6','internet-archive','1998-cia-world-factbook-united-states-central-intelligence-agency','txt','ed8d799a5289d0958a7a95ba11403072d40c0ab0f88fcf382252becb0759ed16','https://archive.org/download/1998-cia-world-factbook-united-states-central-intelligence-agency/1998-cia-world-factbook-united-states-central-intelligence-agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c773851af77a18357206273d39126bb38b6e7a35e6d75e4fb583605342ef7781',1998,'','','raw',1,'The Central Intelligence Agency (CIA) prepares The
World Factbook in printed, CD-ROM, and Internet
versions. US Government officials may obtain information
about availability of the Factbook directly from their own
organizations or through liaison channels to the CIA.
Other users may obtain sales information about printed
copies and CD-ROMs from the following:
Superintendent of Documents
P.O. Box 371954
Pittsburgh, PA 15250-7954
Telephone: [1] (202) 512-1800
FAX: [1] (202) 512-2250
http://www.access.gpo.gov/su_docs/
National Technical Information Service
5285 Port Royal Road
Springfield, VA 221 61
Telephone: [1] (703) 605-6000
FAX: [1] (703) 605-6900
http://www.ntis.gov/
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
101 Independence Avenue, SE
Washington, DC 20540-4230
Telephone: [1] (202) 707-9527
FAX: [1] (202) 707-0380
The Internet version may be accessed through the
following World-Wide Web uniform resource locator
(URL):
http://www.cia.gov
Printed by Printing & Photography Group
REPRODUCTION QUALITY NOTICE
This document is the best quality available. The copy furnished
to DTIC contained pages that may have the following quality
problems:
• Pages smaller or larger than normal.
• Pages with background color or light colored printing.
• Pages with small type or poor printing; and or
• Pages with continuous tone material or color
photographs.
Due to various output media available these conditions may or
may not cause poor legibility in the microfiche or hardcopy output
you receive.
o''.
If this block is checked, the copy furnished to DTIC
contained pages with color printing, that when reproduced in
Black and White, may change detail of the original copy.
Central Intelligence Agency
Washington, D. C. 20505
7 December 1998
Dear World Factbook Customer:
We have enclosed a copy of CIA''s publication The World
Factbook 1998. This data-rich edition contains full-color
maps and flags for all countries; a brief history of basic
intelligence and the role played by the Factbook; and basic
geographic, economic, political, social, and military facts
and figures for all countries of the world. We also have
delivered a copy of the Factbook to your organization''s main
library.
In 1998 we continue the production strategy we pursued
last year, printing a limited number of hard copies in favor
of more cost-effective and searchable electronic vehicles.
A CD-ROM version of The World Factbook 1998 can be ordered
from CIA at no cost by telephoning (703) 482-5203. The
Factbook is also available on the Internet
(http/ /www. cia.gov) . Those who are on the classified
Intelink system can access the publication by going to the
CIA home page, clicking on the "References and Background
Material" section, and selecting "CIA Factbooks and
Information." Additional printed copies of The World
Factbook may be purchased from the Government Printing
Office by telephoning (202) 512-1800.
We hope the Factbook will serve you and your staff as a
valuable reference aid and research tool. We welcome
comments and questions on the Factbook Program. Please
direct them to David Jones, Program Director for The World
Factbook at (703) 482-9549.
Sincerely,
Teresa L . Smith
Acting Director of Support Services
Enclosure
DISTRIBUTION STATEMENT A
Approved for Public Release
Distribution Unlimited
*1: dxA>ss//(p^//)mr
& fl/i/3 -
i''LUKyft- 7\\J U cylO^O 0 At
~ ''Ofl&yco,
.
Central
Intelligence
Agency
The
World
Factbook
1998
The World Factbook is prepared by the Central
Intelligence Agency for the use of US Government
officials, and the style, format, coverage, and
content are designed to meet their specific
requirements. Information is provided by the Bureau
of Labor Statistics (Department of Labor), Bureau of
the Census (Department of Commerce), Central
Intelligence Agency, Council of Managers of
National Antarctic Programs, Defense Intelligence
Agency (Department of Defense), Defense Special
Weapons Agency (Department of Defense),
Department of State, Fish and Wildlife Service
(Department of the Interior), Maritime Administration
(Department of Transportation), National Imagery
and Mapping Agency (Department of Defense),
Antarctic Information Program (National Science
Foundation), Naval Facilities Engineering
Command (Department of Defense), Office of
Insular Affairs (Department of the Interior), Office of
Naval Intelligence (Department of Defense), US
Board on Geographic Names (Department of the
Interior), US Coast Guard (Department of
Transportation), and other public and private
sources.
The Factbook is in the public domain. Accordingly, it
may be copied freely without permission of the
Central Intelligence Agency (CIA). The official seal
of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50
U.S.C. section 403m). Misuse of the official seal of
the CIA could result in civil and criminal penalties. Reproduced From
Comments and queries are welcome and may be Best Available Copy
addressed to:
Central Intelligence Agency
Attn.: Office of Public Affairs
Washington, DC 20505
Telephone: [1] (703) 482-0623
FAX: [1] (703) 482-1739
DTIC QUALITY INSPECTED 2
19990407 117
A Brief History of Basic Intelligence and
The World Factbook
The Intelligence Cycle is the process by which information
is acquired, converted into intelligence , and made available to
policymakers. Information is raw data from any source , data
that may be fragmentary, contradictory unreliable,
ambiguous, deceptive, or wrong. Intelligence is information
that has been collected, integrated, evaluated, analyzed, and
interpreted. Finished intelligence is the final product of the
Intelligence Cycle ready to be delivered to the policymaker.
The three types of finished intelligence are: basic, current,
and estimative. Basic intelligence provides the fundamental
and factual reference material on a country or issue. Current
intelligence reports on new developments. Estimative
intelligence judges probable outcomes. The three are
mutually supportive: basic intelligence is the foundation on
which the other two are constructed; current intelligence
continually updates the inventory of knowledge; and
estimative intelligence revises overall interpretations of
country and issue prospects for guidance of basic and current
intelligence. The World Factbook, The President''s Daily Brief,
and the National Intelligence Estimates are examples of the
three types of finished intelligence.
The United States has carried on foreign intelligence
activities since the days of George Washington, but only since
World War II have they been coordinated on a
governmentwide basis. Three programs have highlighted the
development of coordinated basic intelligence since that time:
(1) the Joint Army Navy intelligence Studies (JANIS), (2) the
National Intelligence Survey (NIS), and (3) CIA''s World
Factbook.
During World War II, intelligence consumers realized that
the production of basic intelligence by different components of
the US Government resulted in a great duplication of effort
and conflicting information. The Japanese attack on Pearl
Harbor in 1 941 brought home to leaders in Congress and the
executive branch the need for integrating departmental
reports to national policymakers. Detailed coordinated
information was needed not only on such major powers as
Germany and Japan, but also on places of little previous
interest. In the Pacific Theater, for example, the Navy and
Marines had to launch amphibious operations against many
islands about which information was unconfirmed or
nonexistent. Intelligence authorities resolved that the United
States should never again be caught unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train
(Office of Naval Intelligence— ONI), and Gen. William J.
Donovan (Director of the Office of Strategic Services— OSS)
decided that a joint effort should be initiated. A steering
committee was appointed on 27 April 1943 that
recommended the formation of a Joint Intelligence Study
Publishing Board to assemble, edit, coordinate, and publish
the Joint Army Navy Intelligence Studies (JANIS). JANIS was
the first interdepartmental basic intelligence program to fulfill
the needs of the US Government for an authoritative and
coordinated appraisal of strategic basic intelligence. Between
April 1943 and July 1947, the board published 34 JANIS
studies. JANIS performed well in the war effort, and
numerous letters of commendation were received, including a
statement from Adm. Forrest Sherman, Chief of Staff, Pacific
Ocean Areas, which said, "JANIS has become the
indispensable reference work for the shore-based planners."
The need for more comprehensive basic intelligence in
the postwar world was well expressed in 1946 by George S.
Pettee, a noted author on national security. He wrote in The
Future of American Secret Intelligence (Infantry Journal
Press, 1 946, page 46) that world leadership in peace requires
even more elaborate intelligence than war. "The conduct of
peace involves all countries, all human activities — not just
the enemy and his war production."
The Central Intelligence Agency was established on 26
July 1947 and officially began operating on 18 September
1947. Effective 1 October 1947, the Director of Central
Intelligence assumed operational responsibility for JANIS. On
13 January 1948, the National Security Council issued
Intelligence Directive (NSCID) No. 3, which authorized the
National Intelligence Survey (NIS) program as a peacetime
replacement for the wartime JANIS program. Before
adequate NIS country sections could be produced,
government agencies had to develop more comprehensive
gazetteers and better maps. The US Board on Geographic
Names (BGN) compiled the names; the Department of the
Interior produced the gazetteers; and CIA produced the
maps.
The Hoover Commission''s Clark Committee, set up in
1954 to study the structure and administration of the CIA,
reported to Congress in 1 955 that: "The National Intelligence
Survey is an invaluable publication which provides the
essential elements of basic intelligence on all areas of the
world. . . . There will always be a continuing requirement for
keeping the Survey up-to-date." The Factbookms created as
an annual summary and update to the encyclopedic NIS
studies. The first classified Factbookms published in August
1 962, and the first unclassified version was published in June
1 971 . The NIS program was terminated in 1 973 except for the
Factbook, map, and gazetteer components. The 1975
Factbookms the first to be made available to the public with
sales through the US Government Printing Office (GPO).The
1 996 edition was the first to be printed by GPO. The year
1 998 marks the 51 st anniversary of the establishment of the
Central Intelligence Agency and the 55th year of continuous
basic intelligence support to the US Government by The
World Factbook and its two predecessor programs.
Contents
Page
Page
Page
Notes and Definitions
vii','fa8eacdc3f242a31e3b9ac0303cffc04deddf8f64c3e4f9fc8eb57f0524a55ba','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('166ad879a552269a8f0f3fdf1d9ead2883df59951272baf273ca7f1bb73ed388',1998,'PF','French Polynesia','raw',2,'167
Korea, South
257
British Virgin Islands
67
French Southern and Antarctic Lands
168','e46420e67b43d08c8ade690657ce7b29753ede5f2bd3722a98fa83fb6104bfac','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c78f3cc9811e30faba66d907f35cb0f4c469c9c3c5e8f5ea0bd6911d9ac8a380',1998,'US','United States','raw',3,'491
Man, Isle of
299
s~
Saint Helena
395
Central America and the Caribbean
South America
Europe
Central Balkan Region
Middle East
Africa
Central Africa
Asia
Commonwealth of Independent States
Southeast Asia
Oceania
Arctic Region
Antarctic Region
Standard Time Zones of the World
Political Map of the World
v
Notes and Definitions
There have been some significant changes in this edition. The country name
Western Samoa has been changed to Samoa. The spelling of Kazakhstan
includes the letter “h” once again; the spelling Kazakstan is no longer used.
Introduction is a category with two entries— Current issues and Historical
perspective— that appears in only a few country profiles at this time. In the future,
this category may be added to more countries.
Abbreviations: This information is included in Appendix A: Abbreviations,
which includes all abbreviations and acronyms used in the Factbook, with their
expansions.
Administrative divisions: This entry generally gives the numbers, designatory
terms, and first-order administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet acted on
by BGN are noted.
Age structure: This entry provides the distribution of the population according to
age. Information is included by sex and age group (0-14 years, 15-64 years, 65
years and over).The age structure of a population will affect a country’s investment
pattern. Countries with young populations (high percentage under age 1 5) need to
invest more in schools, while countries with older populations (high percentage
ages 65 and over) need to invest more in the health sector. The age structure can
also be used to help predict potential political issues. For example, the rapid
growth of a young adult population unable to find employment can lead to unrest.
Agriculture— products: This entry is a rank ordering of major crops and products
starting with the most important.
Airports: This entry gives the total number of airports. The runway(s) may be
paved (concrete or asphalt surfaces) or unpaved (grass, dirt, sand, or gravel
surfaces), but must be usable. Not all airports have facilities for refueling,
maintenance, or air traffic control.
Airports— with paved runways: This entry gives the total number of airports with
paved runways (concrete or asphalt surfaces). For airports with more than one
runway, only the longest runway is included according to the following five
groups— (1) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1,524 to 2,437 m, (4) 914 to
l, 523 m, and (5) under 914 m. Only airports with usable runways are included in
this listing. Not all airports have facilities for refueling, maintenance, or air traffic
control.
Airports— with unpaved runways: This entry gives the total number of airports
with unpaved runways (grass, dirt, sand, or gravel surfaces). For airports with
more than one runway, only the longest runway is included according to the
following five groups— (1 ) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1 ,524 to 2,437
m, (4) 914 to 1 ,523 m, and (5) under 914 m. Only airports with usable runways are
included in this listing. Not all airports have facilities for refueling, maintenance, or
air traffic control.
Appendixes: This section includes Factbook-re\\a\\e6 material by topic.
Area: This entry includes three subfields. Total area is the sum of all land and
water areas delimited by international boundaries and/or coastlines. Land area is
the aggregate of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers). Water area is
the sum of all water surfaces delimited by international boundaries and/or
coastlines, including inland water bodies (lakes, reservoirs, rivers).
VII
Notes and Definitions (continued)
Area— comparative: This entry provides an area comparison based on total area
equivalents. Most entities are compared with the entire US or one of the 50 states
based on area measurements (1990 revised) provided by the US Bureau of the
Census. The smaller entities are compared with Washington, DC (178 sq km, 69
sq mi) or The Mall in Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Birth rate: This entry gives the average annual number of births during a year per
1,000 population at midyear; also known as crude birth rate. The birth rate is
usually the dominant factor in determining the rate of population growth. It
depends on both the level of fertility and the age structure of the population.
Budget: This entry includes revenues, total expenditures, and capita!
expenditures.
Climate: This entry includes a brief description of typical weather regimes
throughout the year.
Coastline: This entry gives the total length of the boundary between the land area
(including islands) and the sea.
Communications: This category deals with the means of exchanging information
and includes the radio, telephone, and television entries.
Communications— note: This entry includes miscellaneous communications
information of significance not included elsewhere.
Constitution: This entry includes the dates of adoption, revisions, and major
amendments.
Country map: Most versions of the Factbook provide a country map in color. The
maps were produced from the best information available at the time of preparation.
Names and/or boundaries may have changed subsequently.
Country name: This entry includes all forms of the country’s name approved by
the US Board on Geographic Names (Italy is used as an example): conventional
long form (Italian Republic), conventional short form (Italy), local long form
(Repubblica Italiana), local short form (Italia), former(Kingdom of Italy), as well as
the abbreviation . See the Terminology note regarding the use of the term
“country.”
Currency: This entry identifies the national medium of exchange and its basic
subunit.
Current issues: This entry at the beginning of a country profile briefly
characterizes major geographic, social, political, and military developments in the
past 12 months and may include a statement about one or two key future trends.
This entry appears for only a few countries at the present time, but may be added
to more countries in the future.
Data code: This entry gives the official US Government digraph that precisely
identifies every land entity without overlap, duplication, or omission. AF, for
example, is the data code for Afghanistan. This two-letter country code is a
standardized geopolitical data element promulgated in the Federal Information
Processing Standards Publication (FIPS) 10-4 by the National Institute of
Standards and Technology at the US Department of Commerce and maintained
by the Office of the Geographer and Globa! Issues at the US Department of State.
The data code is used to eliminate confusion and incompatibility in the collection,
processing, and dissemination of area-specific data and is particularly useful for
interchanging data between databases. Appendix F cross-references various
country codes and Appendix G does the same thing for hydrographic codes.
Data codes— country: This information is presented in Appendix F:
Cross-Reference List of Country Data Codes which includes the US
Government approved Federal Information Processing Standards (FIPS) codes,
the International Organization for Standardization (ISO) codes, and Internet codes
for land entities.
Data codes— hydrographic: This information is presented in Appendix G:
Cross-Reference List of Hydrographic Data Codes which includes the
International Hydrographic Organization (IHO) codes, Aeronautical Chart and
Information Center (ACIC; now National Imagery and Mapping Agency or NIMA)
codes, and Defense Intelligence Agency (DIA) codes for hydrographic entities.
The US Government has not yet approved a standard for hydrographic data codes
similar to the FIPS 10-4 standard for country data codes.
Dates of information: The information cutoff date was 1 January 1 998, although
a few important changes after that date have been included. Most demographic
statistics are estimates for 1998.
Death rate: This entry gives the average annual number of deaths during a year
per 1,000 population at midyear; also known as crude death rate. The death rate,
while only a rough indicator of the mortality situation in a country, accurately
indicates the current mortality impact on population growth. This indicator is
significantly affected by age distribution, and most countries will eventually show
a rise in the overall death rate, in spite of continued decline in mortality at all ages,
as declining fertility results in an aging population.
Debt— external: This entry gives the total amount of public foreign financial
obligations.
Dependency status: This entry describes the formal relationship between a
particular nonindependent entity and an independent state.
Dependent areas: This entry contains an alphabetical listing of all
nonindependent entities associated in some way with a particular independent
state.
Diplomatic representation: The US Government has diplomatic relations with
184 independent states, including 178 of the 185 UN members (excluded UN
members are Bhutan, Cuba, Iran, Iraq, North Korea, former Yugoslavia, and the
US itself). In addition, the US has diplomatic relations with 6 independent states
that are not in the UN— Holy See, Kiribati, Nauru, Switzerland, Tonga, and Tuvalu.
Diplomatic representation from the US: This entry includes the chief of mission,
embassy address, mailing address, telephone number, FAX number, branch office
locations, consulate general locations, and consulate locations.
Diplomatic representation in the US: This entry includes the chief of the foreign
mission , chancery address, telephone number, FAX number, consulate general
locations, consulate locations, honorary consulate general locations, and
honorary consulate locations.
IX
Notes and Definitions (continued)
Disputes— international: This entry includes a wide variety of situations that
range from traditional bilateral boundary disputes to unilateral claims of one sort
or another. Information regarding disputes over international terrestrial and
maritime boundaries has been reviewed by the US Department of State.
References to other situations involving borders or frontiers may also be included,
such as resource disputes, geopolitical questions, or irredentist issues; however,
inclusion does not necessarily constitute official acceptance or recognition by the
US Government.
Economic aid: This entry refers to bilateral commitments of official development
assistance (ODA) and other official flows (OOF). ODA is defined as financial
assistance, which is concessional in character, has the main objective to promote
economic development and welfare of LDCs, and contains a grant element of at
least 25%. OOF transactions are also official government assistance, but with a
main objective other than economic development and with a grant element less
than 25%. OOF transactions include official export credits (such as Ex-lm Bank
credits), official equity and portfolio investment, and debt reorganization by the
official sector that does not meet concessional terms. Aid is considered to have
been committed when agreements are initialed by the parties involved and
constitute a formal declaration of intent. The entry is separated into two
components— donor and recipient.
Economy: This category includes the entries dealing with the size, development,
and management of productive resources, i.e., land, labor, and capital.
Economy— overview: This entry briefly describes the type of economy, including
the degree of market orientation, the level of economic development, the most
important natural resources, and the unique areas of specialization. It also
characterizes major economic events and policy changes in the most recent 12
months and may include a statement about one or two key future macroeconomic
trends.
Electricity— capacity: This entry gives the maximum designed potential for
electricity production expressed in kilowatts.
Electricity— consumption per capita: This entry gives the figure for annual
electricity generation plus imports, minus exports, and divided by total population
for the same year expressed in kilowatt hours.
Electricity — prod u cti on : This entry gives the annual amount of electricity actually
generated expressed in kilowatt hours.
Elevation extremes: This entry includes both the highest point and the lowest
point.
Entities: Some of the independent states, dependencies, areas of special
sovereignty, and governments included in this publication are not independent,
and others are not officially recognized by the US Government. "Independent
state” refers to a people politically organized into a sovereign state with a definite
territory. “Dependencies” and “areas of special sovereignty” refer to a broad
category of political entities that are associated in some way with an independent
state. “Country” names used in the table of contents or for page headings are
usually the short-form names as approved by the US Board on Geographic Names
and may include independent states, dependencies, and areas of special
sovereignty, or other geographic entities. There are a total of 266 separate
geographic entities in The World Factbookihat may be categorized as follows:
INDEPENDENT STATES
191 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, Samoa, San Marino, SaoTome and Principe, Saudi
Arabia, Senegal, Serbia and Montenegro, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
OTHER
1 Taiwan
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia— Ashmore and Cartier Islands, Christmas Island, Cocos (Keeling)
Islands, Coral Sea Islands, Heard Island and McDonald Islands, Norfolk
Island
1 China— Hong Kong
2 Denmark— Faroe Islands, Greenland
16 France— Bassas da India, Clipperton Island, Europa Island, French Guiana,
French Polynesia, French Southern and Antarctic Lands, Glorioso Islands,
Guadeloupe, Juan de Nova Island, Martinique, Mayotte, New Caledonia,
Reunion, Saint Pierre and Miquelon, Tromelin Island, Wallis and Futuna
2 Netherlands— Aruba, Netherlands Antilles
3 New Zealand— Cook Islands, Niue, Tokelau
3 Norway— Bouvet Island, Jan Mayen, Svalbard
XI
Notes and Definitions (continued)
1 Portugal— Macau
15 UK— Anguilla, Bermuda, British Indian Ocean Territory, British Virgin Islands,
Cayman Islands, Falkland Islands, Gibraltar, Guernsey, Jersey, Isle of Man,
Montserrat, Pitcairn Islands, Saint Helena, South Georgia and the South
Sandwich Islands, Turks and Caicos Islands
14 US— American Samoa, Baker Island, Guam, Howland Island, Jarvis Island,
Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island, Northern
Mariana Islands, Palmyra Atoll, Puerto Rico, Virgin Islands, Wake Island
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West Bank, Western
Sahara
OTHER ENTITIES
4 oceans— Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean
1 World
266 Total
Environment— current issues: This entry lists the most pressing and important
environmental problems.
Environment— international agreements: This entry separates country
participation in international environmental agreements into two levels— party to
and signed but not ratified l Agreements are listed in alphabetical order by the
abbreviated form of the full name.
Environmental agreements: This information is presented in Appendix D:
Selected International Environmental Agreements, which includes the name,
abbreviation, date opened for signature, date entered into force, objective, and
parties by category.
Ethnic groups: This entry provides a rank ordering of ethnic groups starting with
the largest and sometimes includes the percent of total population.
Exchange rates: This entry provides the official value of a country’s monetary unit
at a given date or over a given period of time, as expressed in units of local
currency per US dollar and as determined by international market forces or official
fiat.
Executive branch: This entry includes several subfields. Chief of state includes
the name and title of the titular leader of the country who represents the state at
official and ceremonial functions but may not be involved with the day-to-day
activities of the government. Head of government includes the name and title of
the administrative leader who is designated to manage the day-to-day activities of
the government. Cabinet includes the official name for this body of advisers and
the method for selection of members. Elections includes the nature of election
process or accession to power, date of the last election, and date of the next
election. Election results includes the percent of vote for each candidate in the last
election. In the UK, the monarch is the chief of state, and the prime minister is the
head of government. In the US, the President is both the chief of state and the
head of government.
xii
Exports: This entry includes three subfields. Total value is the total US dollar
amount of exports on an f.o.b. basis. Commodities is a rank ordering of exported
products starting with the most important and sometimes includes the percent of
dollar value. Partners is a rank ordering of trading partners starting with the most
important and sometimes includes the percent of dollar value.
Fiscal year: This entry identifies the beginning and ending months for a country’s
accounting period of 12 months, which often is the calendar year but may begin in
any month. FY93/94 refers to the fiscal year that began in calendar year 1 993 and
ended in calendar year 1 994. All yearly references are for the calendar year (CY)
unless indicated as a noncalendar fiscal year (FY).
Flag description: This entry provides a written flag description produced from
actual flags or the best information available at the time the entry was written. The
flags of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not have flags.
Flag graphic: Most versions of the Factbook include a color flag at the beginning
of the country profile. The flag graphics were produced from actual flags or the
best information available at the time of preparation. The flags of independent
states are used by their dependencies unless there is an officially recognized local
flag. Some disputed and other areas do not have flags.
GDP: This entry gives the gross domestic product (GDP) or value of all final goods
and services produced within a nation in a given year. GDP dollar estimates in the
Factbook are derived from purchasing power parity (PPP) calculations. See the
note on GDP methodology for more information.
GDP methodology: In the Economy section, GDP dollar estimates for all
countries are derived from purchasing power parity (PPP) calculations rather than
from conversions at official currency exchange rates. The PPP method involves
the use of standardized international dollar price weights, which are applied to the
quantities of final goods and services produced in a given economy. The data
derived from the PPP method provide a better comparison of economic well-being
between countries. The division of a GDP estimate in domestic currency by the
corresponding PPP estimate in dollars gives the PPP conversion rate. When
converted at PPP rates, $1 ,000 will buy the same market basket of goods in any
country. Whereas PPP estimates for OECD countries are quite reliable, PPP
estimates for developing countries are often rough approximations. Most of the
GDP estimates are based on extrapolation of PPP numbers published by the UN
International Comparison Program (UNICP) and by Professors Robert Summers
and Alan Heston of the University of Pennsylvania and their colleagues. In
contrast, currency exchange rates depend on a variety of international and
domestic financial forces that often have little relation to domestic output. In
developing countries with weak currencies the exchange rate estimate of GDP in
dollars is typically one-fourth to one-half the PPP estimate. Furthermore,
exchange rates may suddenly go up or down by 10% or more because of market
forces or official fiat whereas real output has remained unchanged. On 1 2 January
1994, for example, the 14 countries of the African Financial Community (whose
currencies are tied to the French franc) devalued their currencies by 50%. This
move, of course, did not cut the real output of these countries by half. One
important caution: the proportion of, say, defense expenditures as a percentage of
GDP in local currency accounts may differ substantially from the proportion when
GDP accounts are expressed in PPP terms, as, for example, when an observer
tries to estimate the dollar level of Russian or Japanese military expenditures.
xiii
Notes and Definitions (continued)
Note: the numbers for GDP and other economic data can not be chained together
from successive volumes of the Factbook because of changes in the US dollar
measuring rod, revisions of data by statistical agencies, use of new or different
sources of information, and changes in national statistical methods and practices.
For statistical series on GDP and other economic variables, see the Handbook of
International Economic Statistics available from the same sources as The World
Factbook.
GDP— composition by sector: This entry gives the percentage contribution of
agriculture, industry, and services to total GDP.
GDP— per capita: This entry shows GDP on a purchasing power parity basis
divided by population as of 1 July for the same year.
GDP— real growth rate: This entry gives GDP growth on an annua! basis
adjusted for inflation and expressed as a percent.
Geographic coordinates: This entry includes rounded latitude and longitude
figures for the purpose of finding the approximate geographic center of an entity
and is based on the Gazetteer of Conventional Names, Third Edition, August 1 988,
US Board on Geographic Names and on other sources.
Geographic names: This information is presented in Appendix H:
Cross-Reference List of Geographic Names which indicates where various
geographic names— including alternate','d5ebeefd408865d688c1d98317a37a94f7bd777b8444ae398fe4ee7487283cf0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ddfa97b19248f3fc80140d09e7d0b5154017e1979ff5f14340a90133b2c420e',1998,'US','United States','raw',4,'names, former names, political or
geographical portions of larger entities, and the location of all US Foreign Service
Posts— can be found in The World Factbook. Spellings are normally, but not
always, those approved by the US Board on Geographic Names (BGN). Alternate
names are included in parentheses, while additional information is included in
brackets.
Geography: This category includes the entries dealing with the natural
environment and the effects of human activity.
Geography— note: This entry includes miscellaneous geographic information of
significance not included elsewhere.
GNP: Gross national product (GNP) is the value of all final goods and services
produced within a nation in a given year, plus income earned by its citizens abroad,
minus income earned by foreigners from domestic production. The Factbook uses
GDP rather than GNP to measure national production.
Government: This category includes the entries dealing with the system for the
adoption and administration of public policy.
Government type: This entry gives the basic form of government (e.g., republic,
constitutional monarchy, federal republic, parliamentary democracy, military
dictatorship).
Government— note: This entry includes miscellaneous government information
of significance not included elsewhere.
Gross domestic product: see GDP
Gross national product: see GNP
Gross world product: see GWP
GWP: This entry gives the gross world product (GWP) or aggregate value of all
final goods and services produced worldwide in a given year.
Heliports: This entry gives the total number of established helicopter takeoff and
landing sites (which may or may not have fuel or other services).
Highways: This entry includes the total length of the highway system as well as
the length of the pa ved and unpaved components.
Historical perspective: This entry at the beginning of a country profile contains a
brief summary of the background information necessary to understand the current
situation in a country. The entry appears for only a few countries at the present
time, but may be added to more countries in the future.
Illicit drugs: This entry gives information on the five categories of illicit drugs —
narcotics, stimulants, depressants (sedatives), hallucinogens, and cannabis.
These categories include many drugs legally produced and prescribed by doctors
as well as those illegally produced and sold outside of medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana (pot,
Acapulco gold, grass, reefer), tetrahydrocannabinol (THC, Marinol), hashish
(hash), and hashish oil (hash oil).
Coca (mostly Erythroxylum coca) is a bush with leaves that contain the
stimulant used to make cocaine. Coca is not to be confused with cocoa, which
comes from cacao seeds and is used in making chocolate, cocoa, and cocoa
butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chloral hydrate, barbiturates (Amytal, Nembutal, Seconal, phenobarbital),
benzodiazepines (Librium, Valium), methaqualone (Quaalude), glutethimide
(Doriden), and others (Equanil, Placidyl, Valmid).
Drugs are any chemical substances that effect a physical, mental, emotional,
or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that results in
physical, mental, emotional, or behavioral impairment in an individual.
Hallucinogens are drugs that affect sensation, thinking, self-awareness, and
emotion. Hallucinogens include LSD (acid, microdot), mescaline and peyote
(mexc, buttons, cactus), amphetamine variants (PMA, STP, DOB), phencyclidine
(POP, angel dust, hog), phencyclidine analogues (PCE, PCPy, TCP), and others
(psilocybin, psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant (Cannabis
sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a trade name for methaqualone, a pharmaceutical depressant.
Marijuana is the dried leaves of the cannabis or hemp plant (Cannabis sativa).
Methaqualone is a pharmaceutical depressant, referred to as mandrax in
Southwest Asia.
Narcotics are drugs that relieve pain, often induce sleep, and refer to opium,
opium derivatives, and synthetic substitutes. Natural narcotics include opium
(paregoric, parepectolin), morphine (MS-Contin, Roxanol), codeine (Tylenol with
codeine, Empirin with codeine, Robitussan AC), and thebaine. Semisynthetic
xv
Notes and Definitions (continued)
narcotics include heroin (horse, smack), and hydromorphone (Dilaudid). Synthetic
narcotics include meperidine or Pethidine (Demerol, Mepergan), methadone
(Dolophine, Methadose), and others (Darvon, Lomotil).
Opium is the brown, gummy exudate of the incised, unripe seedpod of the
opium poppy.
Opium poppy (Papaver somniferum) is the source for the natural and
semisynthetic narcotics.
Poppy straw concentrate is the alkaloid derived from the mature, dried opium
poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha edulis that is
chewed or drunk as tea.
Quaaludes is the North American slang term for methaqualone, a
pharmaceutical depressant.
Stimulants are drugs that relieve mild depression, increase energy and activity,
and include cocaine (coke, snow, crack), amphetamines (Desoxyn, Dexedrine),
phenmetrazine (Preludin), methylphenidate (Ritalin), and others (Cylert, Sanorex,
Tenuate).
Imports: This entry includes three subfields. Total value is the total US dollar
amount of imports on a c.i.f. or f.o.b. basis. Commodities is a rank ordering of
imported products starting with the most important and sometimes includes the
percent of dollar value. Partners is a rank ordering of trading partners starting with
the most important and sometimes includes the percent of dollar value.
Independence: This entry gives the date that sovereignty was achieved and from
what nation.
Industrial production growth rate: This entry gives the annual percentage
increase in industrial production (includes manufacturing, mining, and
construction).
Industries: This entry provides a rank ordering of industries starting with the
largest by value of annual output.
Infant mortality rate: This entry gives the number of deaths of infants under one
year old in a given year per 1 ,000 live births occurring in the same year. The infant
mortality rate is often used an indicator of the level of health in a country.
Inflation rate— consumer price index: This entry furnishes the annual percent
change in consumer prices compared with the previous year’s consumer prices.
International disputes: see Disputes — international
International organization participation:This entry lists in alphabetical order by
abbreviation those international organizations in which the subject country is a
member or participates in some other way.
International organizations: This information is presented in Appendix C:
International Organizations and Groups which includes the name, abbreviation,
address, telephone, FAX, date established, aim, and members by category.
Introduction: This category includes two entries — Current issues and Historical
perspective. At present it appears in only a few country profiles, but may be added
to others in the future.
Irrigated land: This entry gives the number of square kilometers of land area that
is artificially supplied with water.
Judicial branch: This entry contains the name(s) of the highest court(s) and a
brief description of the selection process for members.
Labor force: This entry contains the total labor force figure and a rank ordering of
component parts by occupation.
Land boundaries: This entry contains the total length of all land boundaries and
the individual lengths for each of the contiguous border countries.
Land use: This entry contains the percentage shares of total land area for five
different types of land use. Arable land— land cultivated for crops that are
replanted after each harvest like wheat, maize, and rice. Permanent crops— land
cultivated for crops that are not replanted after each harvest like citrus, coffee, and
rubber. Permanent pastures— land permanently used for herbaceous forage
crops. Forests and woodland— land under dense or open stands of trees. Other —
any land type not specifically mentioned above, such as urban areas, roads,
desert, etc.
Languages: This entry provides a rank ordering of languages starting with the
largest and sometimes includes the percent of total population speaking that
language.
Legal system: This entry contains a brief description of the legal system’s
historical roots, role in government, and acceptance of International Court of
Justice (ICJ) jurisdiction.
Legislative branch: This entry contains information on the structure (unicameral,
bicameral, tricameral), formal name, number of seats, and term of office. Elections
includes the nature of election process or accession to power, date of the last
election, and date of the next election. Election results includes the percent of vote
and/or number of seats held by each party in the last election.
Life expectancy at birth: This entry contains the average number of years to be
lived by a group of people born in the same year, if mortality at each age remains
constant in the future. The entry includes total population as well as the male and
female components. Life expectancy at birth is also a measure of overall quality of
life in a country and summarizes the mortality at all ages. It can also be thought of
as indicating the potential return on investment in human capital and is necessary
for the calculation of various actuarial measures.
Literacy: This entry includes a definition of literacy and Census Bureau
percentages for the total population, males, and females. There are no universal
definitions and standards of literacy. Unless otherwise specified, all rates are
based on the most common definition — the ability to read and write at a specified
age. Detailing the standards that individual countries use to assess the ability to
read and write is beyond the scope of the Factbook. Information on literacy, while
not a perfect measure of educational results, is probably the most easily available
and valid for international comparisons. Low levels of literacy, and education in
general, can impede the economic development of a country in the current rapidly
changing, technology-driven world.
Location: This entry identifies the country’s regional location, neighboring
countries, and adjacent bodies of water.
xvii
Notes and Definitions (continued)
Map references: This entry includes the name of the Factbook reference map on
which a country may be found. The entry on Geographic coordinates may be
helpful in finding some smaller countries.
Maritime claims: This entry includes the following claims: contiguous zone,
continental shelf, exclusive economic zone, exclusive fishing zone, extended
fishing zone, none (usually for a landlocked country), other (unique maritime
claims like Libya’s Gulf of Sidra Closing Line or North Korea’s Military Boundary
Line), and territorial sea. The proximity of neighboring states may prevent some
national claims from being extended the full distance.
Merchant marine: Merchant marine may be defined as all ships engaged in the
carriage of goods; all commercial vessels (as opposed to all nonmilitary ships),
which excludes tugs, fishing vessels, offshore oil rigs, etc.; or a grouping of
merchant ships by nationality or register. This entry contains information in two
subfields— fofa/ and ships by type. Total includes the total number of ships (1 ,000
GRT or over), total DWT for those ships, and total GRT for those ships. Ships by
type includes a listing of barge carriers, bulk cargo ships, cargo ships, combination
bulk carriers, combination ore/oil carriers, container ships, intermodal ships,
liquefied gas tankers, livestock carriers, multifunction large-load carriers, oil
tankers, passenger ships, passenger-cargo ships, railcar carriers, refrigerated
cargo ships, roll-on/roll-off cargo ships, short-sea passenger ships, specialized
tankers, tanker tug-barges, and vehicle carriers.
A captive register is a register of ships maintained by a territory, possession,
or colony primarily or exclusively for the use of ships owned in the parent country;
it is also referred to as an offshore register, the offshore equivalent of an internal
register. Ships on a captive register will fly the same flag as the parent country, or
a local variant of it, but will be subject to the maritime laws and taxation rules of
the offshore territory. Although the nature of a captive register makes it especially
desirable for ships owned in the parent country, just as in the internal register, the
ships may also be owned abroad. The captive register then acts as a flag of
convenience register, except that it is not the register of an independent state.
A flag of convenience register is a national register offering registration to a
merchant ship not owned in the flag state. The major flags of convenience (FOC)
attract ships to their registers by virtue of low fees, low or nonexistent taxation of
profits, and liberal manning requirements. True FOC registers are characterized by
having relatively few of the registered ships actually owned in the flag state. Thus,
while virtually any flag can be used for ships under a given set of circumstances,
an FOC register is one where the majority of the merchant fleet is owned abroad.
It is also referred to as an open register.
A flag state is the nation in which a ship is registered and which holds legal
jurisdiction over operation of the ship, whether at home or abroad. Maritime
legislation of the flag state determines how a ship is crewed and taxed and
whether a foreign-owned ship may be placed on the register.
An internal register is a register of ships maintained as a subset of a national
register. Ships on the internal register fly the national flag and have that nationality
but are subject to a separate set of maritime rules from those on the main national
register. These differences usually include lower taxation of profits, use of foreign
nationals as crew members, and, usually, ownership outside the flag state (when
it functions as an FOC register). The Norwegian International Ship Register and
Danish International Ship Register are the most notable examples of an internal
register. Both have been instrumental in stemming flight from the national flag to
flags of convenience and in attracting foreign-owned ships to the Norwegian and
Danish flags.
A merchant ship is a vessel that carries goods against payment of freight; it is
commonly used to denote any nonmilitary ship but accurately restricted to
commercial vessels only.
A register is the record of a ship’s ownership and nationality as listed with the
maritime authorities of a country; also, it is the compendium of such individual
ships’ registrations. Registration of a ship provides it with a nationality and makes
it subject to the laws of the country in which registered (the flag state) regardless
of the nationality of the ship’s ultimate owner.
Military: This category includes the entries dealing with a country’s military
structure, manpower, and expenditures.
Military branches: This entry lists the names of the ground, naval, air, marine,
and other defense or military-type forces.
Military expenditures— dollar figure: This entry gives current military
expenditures in US dollars; the figure is calculated by multiplying the estimated
defense spending in percentage terms by the gross domestic product (GDP)
calculated on an exchange rate basis not purchasing power parity (PPP) terms.
The figure should be treated with caution because of different price patterns and
accounting methods among nations, as well as wide variations in the strength of
their currencies.
Military expenditures— percent of GDP: This entry gives current military
expenditures as an estimated percent of gross domestic product (GDP).
Military manpower— availability: This entry gives the total numbers of males
and females age 15-49 and assumes that every individual is fit to serve.
Military manpower— fit for military service: This entry gives the number of
males and females age 1 5-49 fit for military service. This is a more refined
measure of potential military manpower availability which tries to correct for the
health situation in the country and reduces the maximum potential number to a
more realistic estimate of the actual number fit to serve.
Military manpower— military age: This entry gives the minimum age at which an
individual may volunteer for military service or be subject to conscription.
Military manpower— reaching military age annually: This entry gives the
number of draft-age males and females entering the military manpower pool in any
given year and is a measure of the availability of draft-age young adults.
Military— note: This entry includes miscellaneous military information of
significance not included elsewhere.
Money figures: All money figures are expressed in contemporaneous US dollars
unless otherwise indicated.
National capital: This entry gives the location of the seat of government.
National holiday: This entry gives the primary national day of celebration —
usually independence day.
Nationality: This entry provides the identifying terms for citizens— noun and
adjective.
Natural hazards: This entry lists potential natural disasters.
xix
Notes and Definitions (continued)
Natural resources: This entry lists a country’s mineral, petroleum, hydropower,
and other resources of commercial importance.
Net migration rate: This entry includes the figure for the difference between the
number of persons entering and leaving a country during the year per 1 ,000
persons (based on midyear population). An excess of persons entering the
country is referred to as net immigration (e.g., 3.56 migrants/1 ,000 population); an
excess of persons leaving the country as net emigration (e.g., -9.26 migrants/
1 ,000 population). The net migration rate indicates the contribution of migration to
the overall level of population change. High levels of migration can cause problems
such as increasing unemployment and potential ethnic strife (if people are coming
in) or reducing the labor force, perhaps in certain key sectors (if people are
leaving).
People: This category includes the entries dealing with the characteristics of the
people and their society.
People— note: This entry includes miscellaneous demographic information of
significance not included elsewhere.
Pipelines: This entry gives the lengths and types of pipelines for transporting
products like natural gas, crude oil, or petroleum products.
Political parties and leaders: This entry includes a listing of significant political
organizations and their leaders.
Political pressure groups and leaders: This entry includes a listing of
organizations with leaders involved in politics, but not standing for legislative
election.
Population: This entry gives an estimate from the US Bureau of the Census
based on statistics from population censuses, vital statistics registration systems,
or sample surveys pertaining to the recent past and on assumptions about future
trends. The total population presents one overall measure of the potential impact
of the country on the world and within its region. Note: starting with the 1993
Factbook, demographic estimates for some countries (mostly African) have taken
into account the effects of the growing incidence of AIDS infections. In 1 998 these
countries are Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Central African Republic, Democratic Republic of the Congo, Republic
of the Congo, Cote d’Ivoire, Ethiopia, Guyana, Haiti, Honduras, Kenya, Lesotho,
Malawi, Namibia, Nigeria, Rwanda, South Africa, Swaziland, Tanzania, Thailand,
Uganda, Zambia, and Zimbabwe.
Population growth rate: The average annual percent change in the population,
resulting from a surplus (or deficit) of births over deaths and the balance of
migrants entering and leaving a country. The rate may be positive or negative. Also
known as growth rate or average annual rate of growth. The growth rate is a factor
in determining how great a burden would be imposed on a country by the changing
needs of its people for infrastructure (e.g., schools, hospitals, housing, roads),
resources (e.g., food, water, electricity), and jobs. Rapid population growth can be
seen as threatening by neighboring countries.
Ports and harbors: This entry lists the major ports and harbors selected on the
basis of overall importance to each country. This is determined by evaluating a
number of factors (e.g., dollar value of goods handled, gross tonnage, facilities,
military significance).
Radio broadcast stations; This entry includes the total number of AM, FM, and
shortwave broadcast stations.
Radios: This entry gives the total number of radio receivers.
Railways: This entry includes the total length of the railway network and
component parts by gauge: broad, dual , narrow, standard, and other
Reference maps: This section includes world, regional, and special or current
interest maps.
Religions: This entry includes a rank ordering of religions starting with the largest
and sometimes includes the percent of total population.
Sex ratio: This entry includes the number of males for each female in five age
groups —at birth, under 15 years, 15-64 years, 65 years and over, and for the total
population. Sex ratio at birth has recently emerged as an indicator of certain kinds
of sex discrimination in some countries. For instance, high sex ratios at birth in
some Asian countries are now attributed to sex-selective abortion and infanticide
due to a strong preference for sons. This will affect future marriage patterns and
fertility patterns. Eventually it could cause unrest among young adult males who
are unable to find partners. The sex ratio at birth for the World is 1 .06 (1 998 est.).
Suffrage: This entry gives the age at enfranchisement and whether the right to
vote is universal or restricted.
Telephone numbers: All telephone numbers in the Factbook consist of the
country code in brackets, the city or area code (where required) in parentheses,
and the local number. The one component that is not presented is the international
access code, which varies from country to country. For example, an international
direct dial telephone call placed from the US to Madrid, Spain, would be as follows:
011 [34] (1) 577-xxxx, where
01 1 is the international access code for station-to-station calls
(01 is for calls other than station-to-station calls),
[34] is the country code for Spain,
(1 ) is the city code for Madrid,
577 is the local exchange, and
xxxx is the local telephone number.
An international direct dial telephone call placed from another country to the US
would be as follows:
international access code + [1] (202) 939-xxxx, where
[1] is the country code for the US,
(202) is the area code for Washington, DC,
939 is the local exchange, and
xxxx is the local telephone number.
Telephone system : This entry includes a brief characterization of the system with
details on the domestic and international components. The following terms and
abbreviations are used throughout the entry:
Arabsat— Arab Satellite Communications Organization (Riyadh, Saudi
Arabia).
Autodin— Automatic Digital Network (US Department of Defense).
xxi
Notes and Definitions (continued)
CB — citizen’s band mobile radio communications.
cellular telephone system— the telephones in this system are radio
transceivers, with each instrument having its own private radio frequency and
sufficient radiated power to reach the booster station in its area (cell), from which
the telephone signal is fed to a regular telephone exchange.
Central American Microwave System— a trunk microwave radio relay system
that links the countri','38401cd76e3ab80be958c789581c9b2632b4d381819c9ea8d549e6b2f364b810','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19ff57c36ac2dc92ecb8a8588eedb5891b4444e307e6e21c576301b1dbf11eb8',1998,'US','United States','raw',5,'es of Central America and Mexico with each other.
coaxial cable— a multichannel communication cable consisting of a central
conducting wire, surrounded by and insulated from a cylindrical conducting shell;
a large number of telephone channels can be made available within the insulated
space by the use of a large number of carrier frequencies.
Comsat— Communications Satellite Corporation (US).
DSN— Defense Switched Network (formerly Automatic Voice Network or
Autovon); basic general-purpose, switched voice network of the Defense
Communications System (US Department of Defense).
Eutelsat— European Telecommunications Satellite Organization (Paris).
fiber-optic cable— a multichannel communications cable using a thread of
optical glass fibers as a transmission medium in which the signal (voice, video,
etc.) is in the form of a coded pulse of light.
HF— high-frequency; any radio frequency in the 3,000- to 30,000-kHz range.
Inmarsat— International Mobile Satellite Organization (London); provider of
global mobile satellite communications for commercial, distress, and safety
applications at sea, in the air, and on land.
Intelsat— Internationa! Telecommunications Satellite Organization
(Washington, DC).
Intersputnik— International Organization of Space Communications (Moscow);
first established in the former Soviet Union and the East European countries, it is
now marketing its services worldwide with earth stations in North America, Africa,
and East Asia.
landline— communication wire or cable of any sort that is installed on poles or
buried in the ground.
Marecs— Maritime European Communications Satellite used in the Inmarsat
system on lease from the European Space Agency.
Marisat— satellites of the Comsat Corporation that participate in the Inmarsat
system.
Medarabtel— the Middle East Telecommunications Project of the Internationa!
Telecommunications Union (ITU) providing a modern telecommunications
network, primarily by microwave radio relay, linking Algeria, Djibouti, Egypt,
Jordan, Libya, Morocco, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, and
Yemen; it was initially started in Morocco in 1 970 by the Arab Telecommunications
Union (ATU) and was known at that time as the Middle East Mediterranean
Telecommunications Network.
microwave radio relay— transmission of long distance telephone calls and
television programs by highly directional radio microwaves that are received and
sent on from one booster station to another on an optica! path.
NMT— Nordic Mobile Telephone; an analog cellular telephone system that was
developed jointly by the national telecommunications authorities of the Nordic
countries (Denmark, Finland, Iceland, Norway, and Sweden).
Orbita— a Russian television service; also the trade name of a packet-switched
digital telephone network.
radiotelephone communications— the two-way transmission and reception of
sounds by broadcast radio on authorized frequencies using telephone handsets.
satellite communication system— a communication system consisting of two or
more earth stations and at least one satellite that provides long distance
transmission of voice, data, and television; the system usually serves as a trunk
connection between telephone exchanges; if the earth stations are in the same
country, it is a domestic system.
satellite earth station— a communications facility with a microwave radio
transmitting and receiving antenna and required receiving and transmitting
equipment for communicating with satellites.
satellite link— a radio connection between a satellite and an earth station
permitting communication between them, either one-way (down link from satellite
to earth station— television receive-only transmission) or two-way (telephone
channels).
SHF— super-high-frequency; any radio frequency in the 3,000- to 30,000-MHz
range.
shortwave— radio frequencies (from 1 .605 to 30 MHz) that fall above the
commercial broadcast band and are used for communication over long distances.
Solidaridad— geosynchronous satellites in Mexico’s system of international
telecommunications in the Western Hemisphere.
Statsionar— Russia’s geostationary system for satellite telecommunications.
submarine cable— a cable designed for service under water.
TAT— Trans-Atlantic Telephone; any of a number of high-capacity submarine
coaxial telephone cables linking Europe with North America.
telefax— facsimile service between subscriber stations via the public switched
telephone network or the international Datel network.
telegraph— a telecommunications system designed for unmodulated electric
impulse transmission.
telex— a communication service involving teletypewriters connected by wire
through automatic exchanges.
tropospheric scatter— a form of microwave radio transmission in which the
troposphere is used to scatter and reflect a fraction of the incident radio waves
back to earth; powerful, highly directional antennas are used to transmit and
receive the microwave signals; reliable over-the-horizon communications are
realized for distances up to 600 miles in a single hop; additional hops can extend
the range of this system for very long distances.
trunk network— a network of switching centers, connected by multichannel
trunk lines.
UHF— ultra-high-frequency; any radio frequency in the 300- to 3,000-MHz
range.
VHF— very-high-frequency; any radio frequency in the 30- to 300-MHz range.
Telephones: This entry gives the total number of subscribers.
Television— broadcast stations: This entry gives the total number of separate
broadcast stations plus any repeater stations.
Televisions: This entry gives the total number of television sets.
Terminology: Due to the highly structured nature of the Factbook database, some
collective generic terms have to be used. “Country,” “Country name,” “National
capital,” and “Government,” for example are used collectively to include dependent
areas, uninhabited islands, areas of special sovereignty, and other entities. The
term “Military” is also used as an umbrella term for various civil defense, security,
and defense activities.
Notes and Definitions (continued)
Terrain: This entry contains a brief description of the topography.
Total fertility rate: This entry gives a figure for the average number of children that
would be born per woman if all women lived to the end of their childbearing years
and bore children according to a given fertility rate at each age. The total fertility
rate is a more direct measure of the level of fertility than the crude birth rate, since
it refers to births per woman. This indicator shows the potential for population
growth in the country. High rates will also place some limits on the labor force
participation rates for women. Large numbers of children born to women indicate
large family sizes that might limit the capacity of the families to educate their
children.
Transnational Issues: This category includes only two entries at the present
time— Disputes— international and Illicit drugs— that deal with current issues
going beyond national boundaries.
Transportation: This category includes the entries dealing with the movement of
people or material.
Transportation— note: This entry includes miscellaneous transportation
information of significance not included elsewhere.
Unemployment rate: This entry contains the percent of the labor force that is
without jobs. Substantial underemployment might be noted.
United Nations System: This information is presented in Appendix B: United
Nations System as a chart, table, or text (depending on the version of the
Factbook) that shows the organization of the UN in detail.
Waterways: This entry gives the total length and individual names of navigable
rivers, canals, and other inland bodies of water.
Weights and measures: This information is presented in Appendix E: Weights
and Measures and includes mathematical notations (mathematical powers and
names), metric interrelationships (prefix; symbol; length, weight, or capacity; area;
volume), and standard conversion factors.
Years: All year references are for the calendar year (CY) unless indicated as fiscal
year (FY). The calendar year is an accounting period of 1 2 months from 1 January
to 31 December. The fiscal year is an accounting period of 12 months other than
1 January to 31 December. FY93/94 refers to the fiscal year that began in calendar
year 1993 and ended in calendar year 1994.
Note: Information for the US and US dependencies was compiled from material in
the public domain and does not represent Intelligence Community estimates. The
Handbook of International Economic Statistics, published annually in September
by the Central Intelligence Agency, contains detailed economic information for the
Organization for Economic Cooperation and Development (OECD) countries, the
successor nations to the Soviet Union, and selected other countries. The
Handbook can be obtained wherever the Factbook is available.
Guide to Country Profiles (Categories, Fields, and Subfields)','7cee965635b251f64d76a20150c2b25bb396007b0e358a9efa4e09eb6702ffb1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('460627d7f4953e85e4b9bc10afb7ed7484e4dcb2b3503d2b96ad6dfb8f6453ec',1998,'TN','Tunisia','raw',6,'470
Pitcairn Islands
375
Turkey
472
IV
Page
Appendixes
A: Abbreviations
524
B: United Nations System
532
C: International Organizations and Groups
533
D: Selected International Environmental Agreements
581
E: Weights and Measures
588
F: Cross-Reference List of Country Data Codes
601
G: Cross-Reference List of Hydrographic Data Codes
609
H: Cross-Reference List of Geographic Names
614
Reference Maps
North America','41ea8eb9cfed9c48c32ec62190c1f58c9e16af97128509c5f065cef976871b7e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee46f50c85de6a62284b5160811e95e8abeb9ac7d26d037decee579f7ca82ec3',1998,'','','raw',1,'The Project Gutenberg EBook of The 1998 CIA World Factbook, by
United States. Central Intelligence Agency.
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 1998 CIA World Factbook
Author: United States. Central Intelligence Agency.
Posting Date: February 21, 2010 [EBook #2016]
Release Date: December, 1999
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 1998 CIA WORLD FACTBOOK ***
Produced by Dr. Gregory B. Newby
This etext was prepared by Dr. Gregory B. Newby, as taken from
the CIA''s online version of the book published at the address:
http://www.odci.gov/cia/publications/factbook/guide.html Note
the original book includes maps and other graphics. These are
not included in the Project Gutenberg edition. The tables may
not correctly align due to limitations of HTML conversion, but
are otherwise intact. It is past experience that the CIA does
not maintain past versions of The Factbook online. Hopefully,
the Project Gutenberg edition will be useful to you for a long
time in the future.
The CIA World Factbook 1998
TABLE OF CONTENTS
Countries are listed in alphabetical order. Notes and
appendixes follow the country listings.','a4b1e654bb5df3d1ac8b868b4e695fef737378a18e9871147df0501de4e99222','internet-archive','theciaworldfactb02016gut','txt','45cd7379acaac708944be59dffda0052f9375dc2089f97d8189436e1e34df097','https://archive.org/download/theciaworldfactb02016gut/2016.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cef9fb9ac6f81143f826631aab4cee807f7cfc978829ba4eea431df324a84e21',1998,'ZW','Zimbabwe','raw',2,'Notes and Definitions
Appendixes
Appendix A: Abbreviations
Appendix B: United Nations System
Appendix C: International Organizations and Groups
Appendix D: Selected International Environmental Agreements
Appendix E: Weights and Measures
Appendix F: Cross-Reference List of Country Data Codes
Appendix G: Cross-Reference List of Hydrographic Codes
Appendix H: Cross-Reference List of Geographic Names
History
Contributors and Copyright Information
Purchase Information
______________________________________________________________________','5296dbc67f9a9e3333f62b6d9117af24a6766695357b35a3841d6802970552b0','internet-archive','theciaworldfactb02016gut','txt','45cd7379acaac708944be59dffda0052f9375dc2089f97d8189436e1e34df097','https://archive.org/download/theciaworldfactb02016gut/2016.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('466408da00cd803f31cb895968d45550b88472db38bdb6c1eb5b861abdad4251',1998,'AF','Afghanistan','raw',3,'@Afghanistan:Geography
Location: Southern Asia, north and west of Pakistan, east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area:
total: 647,500 sq km
land: 647,500 sq km
water: 0 sq km
Area-comparative: slightly smaller than Texas
Land boundaries:
total: 5,529 km
border countries: China 76 km, Iran 936 km, Pakistan 2,430 km,
Tajikistan 1,206 km, Turkmenistan 744 km, Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: arid to semiarid; cold winters and hot summers
Terrain: mostly rugged mountains; plains in north and southwest
Elevation extremes:
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum, coal, copper, talc,
barites, sulfur, lead, zinc, iron ore, salt, precious and semiprecious
stones
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 3%
other: 39% (1993 est.)
Irrigated land: 30,000 sq km (1993 est.)
Natural hazards: damaging earthquakes occur in Hindu Kush mountains;
flooding
Environment-current issues: soil degradation; overgrazing;
deforestation (much of the remaining forests are being cut down for
fuel and building materials); desertification
Environment-international agreements:
party to: Desertification, Endangered Species, Environmental
Modification, Marine Dumping, Nuclear Test Ban
signed, but not ratified: Biodiversity, Climate Change, Hazardous
Wastes, Law of the Sea, Marine Life Conservation
Geography-note: landlocked
@Afghanistan:People
Population: 24,792,375 (July 1998 est.)
Age structure:
0-14 years: 43% (male 5,425,510; female 5,216,954)
15-64 years: 54% (male 6,978,549; female 6,494,253)
65 years and over: 3% (male 357,780; female 319,329) (July 1998 est.)
Population growth rate: 4.21% (1998 est.)
note: this rate reflects the continued return of refugees
Birth rate: 42.37 births/1,000 population (1998 est.)
Death rate: 17.4 deaths/1,000 population (1998 est.)
Net migration rate: 17.14 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.07 male(s)/female
65 years and over: 1.12 male(s)/female (1998 est.)
Infant mortality rate: 143.63 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 46.83 years
male: 47.35 years
female: 46.29 years (1998 est.)
Total fertility rate: 6.01 children born/woman (1998 est.)
Nationality:
noun: Afghan(s)
adjective: Afghan
Ethnic groups: Pashtun 38%, Tajik 25%, Uzbek 6%, Hazara 19%, minor
ethnic groups (Aimaks, Turkmen, Baloch, and others)
Religions: Sunni Muslim 84%, Shi''a Muslim 15%, other 1%
Languages: Pashtu 35%, Afghan Persian (Dari) 50%, Turkic languages
(primarily Uzbek and Turkmen) 11%, 30 minor languages (primarily
Balochi and Pashai) 4%, much bilingualism
Literacy:
definition: age 15 and over can read and write
total population: 31.5%
male: 47.2%
female: 15% (1995 est.)
@Afghanistan:Government
Country name:
conventional long form: Islamic State of Afghanistan; note-the
self-proclaimed Taliban government refers to the country as Islamic
Emirate of Afghanistan
conventional short form: Afghanistan
local long form: Dowlat-e Eslami-ye Afghanestan
local short form: Afghanestan
former: Republic of Afghanistan
Data code: AF
Government type: transitional government
National capital: Kabul
Administrative divisions: 30 provinces (velayat, singular-velayat);
Badakhshan, Badghis, Baghlan, Balkh, Bamian, Farah, Faryab, Ghazni,
Ghowr, Helmand, Herat, Jowzjan, Kabol, Kandahar, Kapisa, Konar,
Kondoz, Laghman, Lowgar, Nangarhar, Nimruz, Oruzgan, Paktia, Paktika,
Parvan, Samangan, Sar-e Pol, Takhar, Vardak, Zabol
note: there may be two new provinces of Nurestan (Nuristan) and Khowst
Independence: 19 August 1919 (from UK control over Afghan foreign
affairs)
National holiday: Victory of the Muslim Nation, 28 April; Remembrance
Day for Martyrs and Disabled, 4 May; Independence Day, 19 August
Constitution: none
Legal system: a new legal system has not been adopted but all factions
tacitly agree they will follow Shari''a (Islamic law)
Suffrage: undetermined; previously males 15-50 years of age
Executive branch: on 27 September 1996, the ruling members of the
Afghan Government were displaced by members of the Islamic Taliban
movement; the Islamic State of Afghanistan has no functioning
government at this time, and the country remains divided among
fighting factions
note: the Taliban have declared themselves the legitimate government
of Afghanistan; the UN has deferred a decision on credentials and the
Organization of the Islamic Conference has left the Afghan seat vacant
until the question of legitimacy can be resolved through negotiations
among the warring factions; the country is essentially divided along
ethnic lines; the Taliban controls the capital of Kabul and
approximately two-thirds of the country including the predominately
ethnic Pashtun areas in southern Afghanistan; opposing factions have
their stronghold in the ethnically diverse north-General DOSTAM''s
National Islamic Movement controls several northcentral provinces and
Commander MASOOD controls the ethnic Tajik majority areas of the
northeast
Legislative branch: non-functioning as of June 1993
Judicial branch: non-functioning as of March 1995, although there are
local Shari''a (Islamic law) courts throughout the country
Political parties and leaders: Taliban (Religious Students Movement),
Mohammad OMAR; United Islamic Front for the Salvation of Afghanistan
[comprised of Jumbesh-i-Melli Islami (National Islamic Movement),
Abdul Rashid DOSTAM; Jamiat-i-Islami (Islamic Society), Burhanuddin
RABBANI and Ahmad Shah MASOOD; and Hizbi Wahdat-Khalili faction
(Islamic Unity Party), Abdul Karim KHALILI]; other smaller parties are
Hizbi Islami-Gulbuddin (Islamic Party), Gulbuddin HIKMATYAR faction;
Hizbi Islami-Khalis (Islamic Party), Yunis KHALIS faction;
Ittihad-i-Islami Barai Azadi Afghanistan (Islamic Union for the
Liberation of Afghanistan), Abdul Rasul SAYYAF;
Harakat-Inqilab-i-Islami (Islamic Revolutionary Movement), Mohammad
Nabi MOHAMMADI; Jabha-i-Najat-i-Milli Afghanistan (Afghanistan
National Liberation Front), Sibghatullah MOJADDEDI;
Mahaz-i-Milli-Islami (National Islamic Front), Sayed Ahamad GAILANI;
Hizbi Wahdat-Akbari faction (Islamic Unity Party), Mohammad Akbar
AKBARI; Harakat-i-Islami (Islamic Movement), Mohammed Asif MOHSENI
Political pressure groups and leaders: tribal elders represent
traditional Pashtun leadership; Afghan refugees in Pakistan,
Australia, US, and elsewhere have organized politically; Peshawar,
Pakistan-based groups such as the Coordination Council for National
Unity and Understanding in Afghanistan (CUNUA), Ishaq GAILANI; Writers
Union of Free Afghanistan (WUFA), A. Rasul AMIN; Mellat (Social
Democratic Party), leader NA
International organization participation: AsDB, CP, ECO, ESCAP, FAO,
G-77, IAEA, IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF,
Intelsat, IOC, IOM (observer), ITU, NAM, OIC, UN, UNCTAD, UNESCO,
UNIDO, UPU, WFTU, WHO, WMO, WToO
Diplomatic representation in the US:
note: embassy operations suspended 21 August 1997
chief of mission: Ambassador (vacant)
chancery: 2341 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] (202) 234-3770
FAX: [1] (202) 328-3516
consulate(s) general: New York
Diplomatic representation from the US: the US embassy in Kabul has
been closed since January 1989 due to security concerns
Flag description: three equal horizontal bands of green (top), white,
and black with a gold emblem centered on the three bands; the emblem
features a temple-like structure with Islamic inscriptions above and
below, encircled by a wreath on the left and right and by a bolder
Islamic inscription above, all of which are encircled by two crossed
scimitars
note: the Taliban uses a plain white flag
@Afghanistan:Economy
Economy-overview: Afghanistan is an extremely poor, landlocked
country, highly dependent on farming and livestock raising (sheep and
goats). Economic considerations have played second fiddle to political
and military upheavals during more than 18 years of war, including the
nearly 10-year Soviet military occupation (which ended 15 February
1989). During the war one-third of the population fled the country,
with Pakistan and Iran sheltering a combined peak of more than 6
million refugees. Now, only 750,000 registered Afghan refugees remain
in Pakistan and about 1.2 million in Iran. Another 1 million have
probably moved into and around urban areas within Afghanistan. Gross
domestic product has fallen substantially over the past 18 years
because of the loss of labor and capital and the disruption of trade
and transport. Much of the population continues to suffer from
insufficient food, clothing, housing, and medical care. Inflation
remains a serious problem throughout the country, with one estimate
putting the rate at 240% in Kabul in 1996. Numerical data are likely
to be either unavailable or unreliable.
GDP: purchasing power parity-$19.3 billion (1997 est.)
GDP-real growth rate: NA%
GDP-per capita: purchasing power parity-$800 (1997 est.)
GDP-composition by sector:
agriculture: 53%
industry: 28.5%
services: 18.5% (1990)
Inflation rate-consumer price index: 240% (1996 est.)
Labor force:
total: 7.1 million
by occupation: agriculture and animal husbandry 67.8%, industry 10.2%,
construction 6.3%, commerce 5.0%, services and other 10.7% (1980 est.)
Unemployment rate: 8% (1995 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Industries: small-scale production of textiles, soap, furniture,
shoes, fertilizer, and cement; handwoven carpets; natural gas, oil,
coal, copper
Electricity-capacity: 494,000 kW (1995)
Electricity-production: 655 million kWh (1995)
Electricity-consumption per capita: 37 kWh (1995)
Agriculture-products: wheat, fruits, nuts, karakul pelts; wool, mutton
Exports:
total value: $80 million (1996 est.)
commodities: fruits and nuts, handwoven carpets, wool, cotton, hides
and pelts, precious and semi-precious gems
partners: FSU, Pakistan, Iran, Germany, India, UK, Belgium,
Luxembourg, Czechoslovakia
Imports:
total value: $150 million (1996 est.)
commodities: food and petroleum products; most consumer goods
partners: FSU, Pakistan, Iran, Japan, Singapore, India, South Korea,','2e3bb889511abf75e37a431ef0c2fd6c556e3cb57715d549eaf3ba15c1a01e3a','internet-archive','theciaworldfactb02016gut','txt','45cd7379acaac708944be59dffda0052f9375dc2089f97d8189436e1e34df097','https://archive.org/download/theciaworldfactb02016gut/2016.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01a80ee0e3abb10eef2b313b30ef888e11feab01c9374b6c4ecfe9209c8b5a75',1998,'DE','Germany','raw',4,'Debt-external: $2.3 billion (March 1991 est.)
Economic aid:
recipient: ODA; about $45 million in UN aid plus additional bilateral
aid and aid in kind (1997)
note: US provided $450 million in bilateral assistance (1985-93); US
continues to contribute to multilateral assistance through the UN
programs of food aid, immunization, land mine removal, and a wide
range of aid to refugees and displaced persons
Currency: 1 afghani (AF) = 100 puls
Exchange rates: afghanis (Af) per US$1-17,000 (December 1996), 7,000
(January 1995), 1,900 (January 1994), 1,019 (March 1993), 850 (1991);
note-these rates reflect the free market exchange rates rather than
the official exchange rate, which was fixed at 50.600 afghanis to the
dollar until 1996, when it rose to 2,262.65 per dollar, and finally
became fixed again at 3,000.00 per dollar on April 1996
Fiscal year: 21 March-20 March','c8740f8144a6193ba71d5f7aefa556a084bd2d9cac9fdeffcbe25455b6105c1d','internet-archive','theciaworldfactb02016gut','txt','45cd7379acaac708944be59dffda0052f9375dc2089f97d8189436e1e34df097','https://archive.org/download/theciaworldfactb02016gut/2016.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
